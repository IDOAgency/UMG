package com.techempower;

import java.util.Hashtable;
import java.util.Vector;

class DataMappingCache {
  protected static Hashtable fieldMappings = new Hashtable();
  
  protected static Hashtable setMethodMappings = new Hashtable();
  
  protected static Hashtable getMethodMappings = new Hashtable();
  
  public static Vector getFieldMappings(Class paramClass) { return (Vector)fieldMappings.get(paramClass); }
  
  public static Vector getSetMethodMappings(Class paramClass) { return (Vector)setMethodMappings.get(paramClass); }
  
  public static Vector getGetMethodMappings(Class paramClass) { return (Vector)getMethodMappings.get(paramClass); }
  
  public static void putFieldMappings(Class paramClass, Vector paramVector) { fieldMappings.put(paramClass, paramVector); }
  
  public static void putSetMethodMappings(Class paramClass, Vector paramVector) { setMethodMappings.put(paramClass, paramVector); }
  
  public static void putGetMethodMappings(Class paramClass, Vector paramVector) { getMethodMappings.put(paramClass, paramVector); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\DataMappingCache.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */