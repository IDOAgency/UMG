/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.BasicHelper;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormRadioButtonGroup
/*     */   extends FormElement
/*     */ {
/*  39 */   public static final String[] DEFAULT_VALUES = new String[0];
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String DEFAULT_SELECTION = "";
/*     */ 
/*     */ 
/*     */   
/*     */   protected String selection;
/*     */ 
/*     */ 
/*     */   
/*     */   protected Vector values;
/*     */ 
/*     */ 
/*     */   
/*     */   protected Vector labels;
/*     */ 
/*     */ 
/*     */   
/*     */   protected String startingSelection;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean incrementTabIndex = true;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean showLabels = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormRadioButtonGroup(String paramString1, String paramString2, String[] paramArrayOfString1, String[] paramArrayOfString2, boolean paramBoolean) {
/*  73 */     super(paramString1, paramString2, paramBoolean);
/*  74 */     setLabelList(paramArrayOfString2);
/*  75 */     setValueList(paramArrayOfString1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormRadioButtonGroup(String paramString1, String paramString2, String[] paramArrayOfString, boolean paramBoolean) {
/*  89 */     super(paramString1, paramString2, paramBoolean);
/*  90 */     setValueList(paramArrayOfString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormRadioButtonGroup(String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
/* 104 */     super(paramString1, paramString2, paramBoolean);
/* 105 */     setValueList(paramString3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public FormRadioButtonGroup(String paramString1, String paramString2, boolean paramBoolean) { this(paramString1, "", paramString2, paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   public FormRadioButtonGroup(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2, boolean paramBoolean) { this(paramString, "", paramArrayOfString1, paramArrayOfString2, paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public FormRadioButtonGroup(String paramString, String[] paramArrayOfString, boolean paramBoolean) { this(paramString, "", paramArrayOfString, paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public FormRadioButtonGroup(String paramString1, String paramString2) { this(paramString1, "", paramString2, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   public FormRadioButtonGroup(String paramString) { this(paramString, "", DEFAULT_VALUES, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String paramString) {
/* 173 */     if (!isReadOnly()) {
/* 174 */       this.selection = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueList(String paramString) {
/* 182 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ",");
/*     */     
/* 184 */     int i = stringTokenizer.countTokens();
/* 185 */     boolean bool = false;
/* 186 */     this.values = new Vector(i);
/*     */     
/* 188 */     while (stringTokenizer.hasMoreTokens())
/*     */     {
/* 190 */       this.values.addElement(stringTokenizer.nextToken().trim());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueList(String[] paramArrayOfString) {
/* 199 */     this.values = new Vector(paramArrayOfString.length);
/* 200 */     for (byte b = 0; b < paramArrayOfString.length; b++)
/*     */     {
/* 202 */       this.values.addElement(paramArrayOfString[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabelList(String[] paramArrayOfString) {
/* 211 */     if (paramArrayOfString != null) {
/*     */       
/* 213 */       this.labels = new Vector(paramArrayOfString.length);
/* 214 */       for (byte b = 0; b < paramArrayOfString.length; b++)
/*     */       {
/* 216 */         this.labels.addElement(paramArrayOfString[b]);
/*     */       }
/*     */     } else {
/*     */       
/* 220 */       setShowLabels(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public void setStartingValue(String paramString) { this.startingSelection = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 240 */   public String getStartingValue() { return this.startingSelection; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 252 */   public void setValue(Context paramContext) { setValue(paramContext.getRequestValue(getName(), this.selection)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 261 */   protected String getValue() { return this.selection; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 269 */   public String getStringValue() { return getValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 279 */   public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 290 */   public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 299 */   public int getIntegerValue() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getValueList() {
/* 307 */     null = new String[this.values.size()];
/* 308 */     return (String[])this.values.toArray(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 317 */   public Vector getValuesVector() { return this.values; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render() {
/* 325 */     StringBuffer stringBuffer = new StringBuffer(100);
/*     */     
/* 327 */     for (byte b = 0; b < this.values.size(); b++)
/*     */     {
/* 329 */       stringBuffer.append(renderSingle(b));
/*     */     }
/*     */     
/* 332 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String renderSingle(int paramInt) {
/* 343 */     if (paramInt >= 0 && 
/* 344 */       paramInt < this.values.size()) {
/*     */ 
/*     */       
/* 347 */       String str = (String)this.values.elementAt(paramInt);
/*     */       
/* 349 */       StringBuffer stringBuffer = new StringBuffer(50);
/* 350 */       stringBuffer.append("<input type=\"radio\" name=\"");
/* 351 */       stringBuffer.append(getName());
/* 352 */       stringBuffer.append("\" value=\"");
/* 353 */       stringBuffer.append(str);
/* 354 */       stringBuffer.append('"');
/* 355 */       if (str.equals(getStringValue()))
/*     */       {
/* 357 */         stringBuffer.append(" checked");
/*     */       }
/* 359 */       stringBuffer.append(getElementTabIndexString(paramInt));
/* 360 */       stringBuffer.append(getFormEvents());
/* 361 */       stringBuffer.append(getEnabledString());
/* 362 */       stringBuffer.append(getId());
/* 363 */       stringBuffer.append('>');
/* 364 */       if (this.showLabels)
/*     */       {
/* 366 */         if (this.labels != null) {
/*     */           
/* 368 */           String str1 = (String)this.labels.elementAt(paramInt);
/* 369 */           stringBuffer.append(str1);
/*     */         }
/*     */         else {
/*     */           
/* 373 */           stringBuffer.append(str);
/*     */         } 
/*     */       }
/*     */       
/* 377 */       return stringBuffer.toString();
/*     */     } 
/*     */ 
/*     */     
/* 381 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String renderSingle(String paramString) {
/* 393 */     for (byte b = 0; b < this.values.size(); b++) {
/*     */       
/* 395 */       String str = (String)this.values.elementAt(b);
/* 396 */       if (str.equals(paramString))
/*     */       {
/* 398 */         return renderSingle(b);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 403 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormSingleValidation validate() {
/* 411 */     FormSingleValidation formSingleValidation = new FormSingleValidation(this);
/*     */     
/* 413 */     if (isRequired())
/*     */     {
/*     */       
/* 416 */       requiredValidation(formSingleValidation);
/*     */     }
/*     */ 
/*     */     
/* 420 */     customValidation(formSingleValidation);
/*     */     
/* 422 */     return formSingleValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
/* 434 */     if (getStringValue().length() == 0)
/*     */     {
/* 436 */       paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is unselected.", 
/* 437 */           "Please provide input in the area named " + getDisplayName() + ".", 
/* 438 */           "Please provide input in this field.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 448 */   public boolean isDefault() { return DEFAULT_VALUES.equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 458 */   public boolean isUnchanged() { return this.startingSelection.equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 467 */   public boolean isIncrementTabIndex() { return this.incrementTabIndex; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 476 */   public void setShowLabels(boolean paramBoolean) { this.showLabels = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 485 */   public boolean setIncrementTabIndex(boolean paramBoolean) { return this.incrementTabIndex = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getElementTabIndexString(int paramInt) {
/* 493 */     if (isIncrementTabIndex() && this.tabIndex >= 0) {
/* 494 */       return " tabindex=\"" + (this.tabIndex + paramInt) + "\" ";
/*     */     }
/* 496 */     return "";
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormRadioButtonGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */