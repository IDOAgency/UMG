package com.techempower;

public class SqlJoin implements SqlReservedWords {
  protected SqlTable srcTable;
  
  protected String[] srcColumns;
  
  protected SqlTable destTable;
  
  protected String[] destColumns;
  
  protected int joinType;
  
  protected int queryMode;
  
  public SqlJoin(SqlTable paramSqlTable1, String[] paramArrayOfString1, SqlTable paramSqlTable2, String[] paramArrayOfString2, int paramInt1, int paramInt2) {
    this.srcTable = paramSqlTable1;
    this.srcColumns = paramArrayOfString1;
    this.destTable = paramSqlTable2;
    this.destColumns = paramArrayOfString2;
    this.joinType = paramInt1;
    this.queryMode = paramInt2;
  }
  
  public SqlTable getSrcTable() { return this.srcTable; }
  
  public SqlTable getDestTable() { return this.destTable; }
  
  public int getJoinType() { return this.joinType; }
  
  public String getJoinCondition() {
    String str = "";
    if (this.srcTable != null && this.destTable != null && 
      this.srcColumns != null && this.destColumns != null && 
      this.srcColumns.length == this.destColumns.length)
      for (byte b = 0; b < this.srcColumns.length; b++) {
        if (str.length() > 0)
          str = String.valueOf(str) + " AND "; 
        str = String.valueOf(str) + this.srcTable.getFullName() + "." + this.srcColumns[b] + getJoinOperator(true) + 
          " " + "=" + " " + 
          this.destTable.getFullName() + "." + this.destColumns[b] + getJoinOperator(false);
      }  
    return str;
  }
  
  protected String getJoinOperator(boolean paramBoolean) {
    if (this.queryMode == 0) {
      if (this.joinType == 1 && !paramBoolean)
        return "(+)"; 
      if (this.joinType == 2 && paramBoolean)
        return "(+)"; 
    } 
    return "";
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\SqlJoin.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */