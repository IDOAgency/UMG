/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.ConnectorFactory;
/*     */ import com.techempower.EnhancedProperties;
/*     */ import com.techempower.gemini.pyxis.BasicSecurity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicServiceSettings
/*     */   implements GeminiConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "srvc";
/*     */   public static final String DEFAULT_URL_PREFIX = "";
/*     */   protected String urlDirectoryPrefix;
/*     */   protected boolean useURLDirectoryPrefix;
/*     */   protected GeminiApplication application;
/*     */   protected ComponentLog log;
/*     */   protected ConnectorFactory connectorFactory;
/*     */   protected BasicSecurity securityManager;
/*     */   
/*     */   public BasicServiceSettings(GeminiApplication paramGeminiApplication) {
/*  48 */     this.urlDirectoryPrefix = "";
/*  49 */     this.useURLDirectoryPrefix = false;
/*     */ 
/*     */ 
/*     */     
/*  53 */     this.connectorFactory = null;
/*  54 */     this.securityManager = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.application = paramGeminiApplication;
/*     */ 
/*     */     
/*  70 */     this.log = paramGeminiApplication.getLog("srvc");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public void configure(EnhancedProperties paramEnhancedProperties) { customConfigure(paramEnhancedProperties); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void customConfigure(EnhancedProperties paramEnhancedProperties) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public ConnectorFactory getConnectorFactory() { return this.connectorFactory; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public BasicSecurity getSecurity() { return this.securityManager; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public String getURLDirectoryPrefix() { return this.urlDirectoryPrefix; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public boolean useURLDirectoryPrefix() { return this.useURLDirectoryPrefix; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\BasicServiceSettings.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */