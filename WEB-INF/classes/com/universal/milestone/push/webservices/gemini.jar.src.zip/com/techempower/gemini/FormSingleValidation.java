package com.techempower.gemini;

public class FormSingleValidation {
  public FormElement element = null;
  
  public boolean isError = false;
  
  public String error = null;
  
  public String instruction = null;
  
  public String inline = null;
  
  public FormSingleValidation(FormElement paramFormElement, boolean paramBoolean, String paramString1, String paramString2, String paramString3) {
    this.element = paramFormElement;
    this.instruction = paramString2;
    this.isError = paramBoolean;
    this.error = paramString1;
    this.inline = paramString3;
  }
  
  public FormSingleValidation(FormElement paramFormElement, boolean paramBoolean, String paramString1, String paramString2) { this(paramFormElement, paramBoolean, paramString1, paramString2, paramString2); }
  
  public FormSingleValidation(FormElement paramFormElement) { this.element = paramFormElement; }
  
  public void setError(String paramString1, String paramString2, String paramString3) {
    this.isError = true;
    this.error = paramString1;
    this.instruction = paramString2;
    this.inline = paramString3;
  }
  
  public void setError(String paramString1, String paramString2) { setError(paramString1, paramString2, paramString2); }
  
  public boolean isSet() {
    return !(!this.isError || (
      this.error == null && 
      this.instruction == null && 
      this.inline == null));
  }
  
  public FormSingleValidation() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormSingleValidation.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */