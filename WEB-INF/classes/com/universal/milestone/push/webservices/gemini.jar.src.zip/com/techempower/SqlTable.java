package com.techempower;

import java.util.Vector;

public class SqlTable implements SqlReservedWords {
  protected String tableName;
  
  protected String username;
  
  protected Vector columnSelections;
  
  protected Vector orderByColumns;
  
  protected String fullName;
  
  public SqlTable(String paramString) { this(paramString, null, null); }
  
  public SqlTable(String paramString1, String paramString2) { this(paramString1, paramString2, null); }
  
  public SqlTable(String paramString1, String paramString2, Vector paramVector) {
    this.tableName = paramString1;
    this.username = paramString2;
    this.columnSelections = paramVector;
    this.fullName = "";
    if (paramString2 != null && paramString2.length() > 0)
      this.fullName = String.valueOf(this.fullName) + paramString2 + "."; 
    if (paramString1 == null)
      paramString1 = ""; 
    this.fullName = String.valueOf(this.fullName) + paramString1;
  }
  
  public String getFullName() { return this.fullName; }
  
  public String getTableName() { return this.tableName; }
  
  public String getUsername() { return this.username; }
  
  public void addColumnSelection(String paramString) {
    if (this.columnSelections == null)
      this.columnSelections = new Vector(1); 
    if (!this.columnSelections.contains(paramString))
      this.columnSelections.addElement(paramString); 
  }
  
  public void addColumnSelections(Vector paramVector) {
    for (byte b = 0; paramVector != null && b < paramVector.size(); b++)
      addColumnSelection((String)paramVector.elementAt(b)); 
  }
  
  public Vector getColumnSelections() { return this.columnSelections; }
  
  public void addOrderByColumn(String paramString) {
    if (this.orderByColumns == null)
      this.orderByColumns = new Vector(1); 
    this.orderByColumns.addElement(paramString);
  }
  
  public String getSelectionClause() {
    String str = "";
    for (byte b = 0; this.columnSelections != null && b < this.columnSelections.size(); b++) {
      String str1 = (String)this.columnSelections.elementAt(b);
      if (str.length() > 0)
        str = String.valueOf(str) + ", "; 
      str = String.valueOf(str) + getFullName() + "." + str1;
    } 
    return str;
  }
  
  public String getOrderByClause() {
    String str = "";
    for (byte b = 0; this.orderByColumns != null && b < this.orderByColumns.size(); b++) {
      String str1 = (String)this.orderByColumns.elementAt(b);
      if (str.length() > 0)
        str = String.valueOf(str) + ", "; 
      str = String.valueOf(str) + getFullName() + "." + str1;
    } 
    return str;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof SqlTable) {
      SqlTable sqlTable = (SqlTable)paramObject;
      return stringsMatchIgnoreCase(getFullName(), sqlTable.getFullName());
    } 
    return super.equals(paramObject);
  }
  
  public static boolean stringsMatchIgnoreCase(String paramString1, String paramString2) {
    if (paramString1 == null && paramString2 == null)
      return true; 
    if (paramString1 == null || paramString2 == null)
      return false; 
    return paramString1.equalsIgnoreCase(paramString2);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\SqlTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */