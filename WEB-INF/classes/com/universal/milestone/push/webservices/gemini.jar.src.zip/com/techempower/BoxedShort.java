package com.techempower;

public final class BoxedShort {
  private short shortValue;
  
  public BoxedShort(short paramShort) { this.shortValue = paramShort; }
  
  public short get() { return this.shortValue; }
  
  public void set(short paramShort) { this.shortValue = paramShort; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\BoxedShort.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */