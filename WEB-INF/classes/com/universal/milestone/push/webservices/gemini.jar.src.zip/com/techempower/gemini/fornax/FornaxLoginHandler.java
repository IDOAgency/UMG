package com.techempower.gemini.fornax;

import com.techempower.ComponentLog;
import com.techempower.gemini.Context;
import com.techempower.gemini.Dispatcher;
import com.techempower.gemini.Form;
import com.techempower.gemini.FormElement;
import com.techempower.gemini.FormHidden;
import com.techempower.gemini.FormPasswordField;
import com.techempower.gemini.FormTextField;
import com.techempower.gemini.FormValidation;
import com.techempower.gemini.GeminiApplication;
import com.techempower.gemini.Handler;
import com.techempower.gemini.pyxis.BasicSecurity;

public class FornaxLoginHandler implements Handler, FornaxConstants {
  public static final String COMPONENT_CODE = "hLog";
  
  public GeminiApplication application;
  
  public ComponentLog log;
  
  public FornaxSettings fornaxSettings;
  
  public FornaxLoginHandler(GeminiApplication paramGeminiApplication) {
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("hLog");
    this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
  }
  
  public String getDescription() { return "Login"; }
  
  public boolean acceptRequest(Dispatcher paramDispatcher, Context paramContext, String paramString) {
    if (paramString.equalsIgnoreCase("fornax-login"))
      return handleRequest(paramDispatcher, paramContext, paramString); 
    return false;
  }
  
  public boolean handleRequest(Dispatcher paramDispatcher, Context paramContext, String paramString) {
    BasicSecurity basicSecurity = this.fornaxSettings.getSecurity();
    boolean bool = Boolean.valueOf(paramContext.getRequestValue("logout", "false")).booleanValue();
    Form form = buildLoginForm(paramContext);
    paramContext.putDelivery("Form", form);
    if (bool) {
      basicSecurity.logout(paramContext);
      paramContext.putDelivery("Confirmation", "Thank you for using Fornax.<br>To login again, enter your user name and password below.");
    } else if (!form.isUnchanged()) {
      FormValidation formValidation = form.validate();
      FormElement formElement = form.getElement("username");
      String str = formElement.getStringValue();
      if (formValidation.isGood()) {
        String str1 = form.getStringValue("password");
        boolean bool1 = basicSecurity.login(paramContext, str, str1);
        if (bool1)
          return paramDispatcher.redispatch(paramContext, "fornax-main-menu"); 
        paramContext.putDelivery("Message", "Invalid login.  Please try again.");
        paramContext.putDelivery("FormValidation", formValidation);
      } else {
        paramContext.putDelivery("Message", "Please provide a user name and passwod in order to login.");
        paramContext.putDelivery("FormValidation", formValidation);
      } 
    } 
    return paramContext.includeJSP("login.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix());
  }
  
  protected boolean cookieLogon(Dispatcher paramDispatcher, Context paramContext, String paramString) { return false; }
  
  protected Form buildLoginForm(Context paramContext) {
    Form form = new Form(this.application, "LoginForm", this.application.getInfrastructure().getServletURL(), "POST");
    form.addElement(new FormHidden("cmd", "fornax-login", true));
    form.addElement(new FormTextField("username", true, 30));
    form.addElement(new FormPasswordField("password", true, 30));
    form.setValues(paramContext);
    return form;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxLoginHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */