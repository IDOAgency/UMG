package com.techempower.gemini;

import com.techempower.BasicHelper;
import com.techempower.UtilityConstants;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.StringTokenizer;

public class FormDateField extends FormElement implements UtilityConstants {
  public static final int DEFAULT_LENGTH = 20;
  
  public static final String DEFAULT_VALUE = "";
  
  public static final int DEFAULT_MINIMUM_YEAR = 1900;
  
  public static final int DEFAULT_MAXIMUM_YEAR = 2200;
  
  public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("M/d/yy");
  
  protected String value;
  
  protected String startingValue;
  
  protected int length;
  
  protected int maxLength;
  
  protected int minimumYear = 1900;
  
  protected int maximumYear = 2200;
  
  public FormDateField(String paramString1, String paramString2, boolean paramBoolean, int paramInt) {
    super(paramString1, paramString2, paramBoolean);
    setLength(paramInt);
    setMaxLength(paramInt);
  }
  
  public FormDateField(String paramString, Date paramDate, boolean paramBoolean, int paramInt) {
    super(paramString, paramBoolean);
    setValue(paramDate);
    setStartingValue(getValue());
    setLength(paramInt);
    setMaxLength(paramInt);
  }
  
  public FormDateField(String paramString, Calendar paramCalendar, boolean paramBoolean, int paramInt) {
    super(paramString, paramBoolean);
    setValue(paramCalendar);
    setStartingValue(getValue());
    setLength(paramInt);
    setMaxLength(paramInt);
  }
  
  public FormDateField(String paramString, boolean paramBoolean, int paramInt) { this(paramString, "", paramBoolean, paramInt); }
  
  public FormDateField(String paramString, int paramInt) { this(paramString, "", false, paramInt); }
  
  public FormDateField(String paramString) { this(paramString, "", false, 20); }
  
  public void setLength(int paramInt) { this.length = paramInt; }
  
  public int getLength() { return this.length; }
  
  public String getStartingValue() { return this.startingValue; }
  
  public void setValue(String paramString) { this.value = paramString; }
  
  public void setValue(Date paramDate) {
    String str = "";
    if (paramDate != null)
      str = DATE_FORMAT.format(paramDate); 
    setValue(str);
  }
  
  public void setValue(Calendar paramCalendar) {
    if (paramCalendar != null)
      setValue(paramCalendar.getTime()); 
  }
  
  public void setStartingValue(String paramString) { this.startingValue = paramString; }
  
  public void setValue(Context paramContext) { this.value = paramContext.getRequestValue(getName(), this.value); }
  
  protected String getValue() { return this.value; }
  
  public String getStringValue() { return getValue(); }
  
  public Date getDateValue() {
    Calendar calendar = getCalendarValue();
    if (calendar != null)
      return calendar.getTime(); 
    return null;
  }
  
  public Calendar getCalendarValue() {
    String str = getStringValue();
    return BasicHelper.parseDate(str);
  }
  
  public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
  
  public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
  
  public int getIntegerValue() { return 0; }
  
  public String render() {
    StringBuffer stringBuffer = new StringBuffer(60);
    stringBuffer.append("<input type=\"text\"");
    stringBuffer.append(getClassName());
    stringBuffer.append(" name=\"");
    stringBuffer.append(getName());
    stringBuffer.append("\" value=\"");
    stringBuffer.append(getRenderableValue());
    stringBuffer.append("\" size=\"");
    stringBuffer.append(getLength());
    stringBuffer.append("\" maxlength=\"");
    stringBuffer.append(getMaxLength());
    stringBuffer.append('"');
    stringBuffer.append(getTabIndex());
    stringBuffer.append(getFormEvents());
    stringBuffer.append(getEnabledString());
    stringBuffer.append(getReadOnlyString());
    stringBuffer.append(getId());
    stringBuffer.append('>');
    return stringBuffer.toString();
  }
  
  public FormSingleValidation validate() {
    FormSingleValidation formSingleValidation = new FormSingleValidation(this);
    if (isRequired())
      requiredValidation(formSingleValidation); 
    customValidation(formSingleValidation);
    return formSingleValidation;
  }
  
  protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
    if (getStringValue().length() == 0) {
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is empty.", 
          "Please provide input in the field named " + getDisplayName() + ".", 
          "This field requires input.");
    } else if (getStringValue().length() > getLength()) {
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is too long.", 
          "Please keep the input in field " + getDisplayName() + " to " + 
          getLength() + " characters or less.", 
          "The value entered in this field must be less then " + (getLength() + 1) + " characters long.");
    } else {
      String str = getStringValue();
      try {
        StringTokenizer stringTokenizer = new StringTokenizer(str, "-/.");
        String str1 = stringTokenizer.nextToken();
        String str2 = stringTokenizer.nextToken();
        String str3 = stringTokenizer.nextToken();
        int i = Integer.parseInt(str1) - 1;
        int j = Integer.parseInt(str2);
        int k = Integer.parseInt(str3);
        if (k < 100)
          if (k > 50) {
            k += 1900;
          } else {
            k += 2000;
          }  
        if (!paramFormSingleValidation.isSet() && (
          i > 11 || 
          i < 0))
          paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " has an invalid month.", 
              String.valueOf(getDisplayName()) + " has an invalid month.", 
              "This field has an invalid month."); 
        if (!paramFormSingleValidation.isSet() && (
          k > this.maximumYear || 
          k < this.minimumYear))
          paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " has an invalid year (" + this.minimumYear + "-" + this.maximumYear + ").", 
              String.valueOf(getDisplayName()) + " has an invalid year.  Valid years are from " + 
              this.minimumYear + " to " + this.maximumYear + ".", 
              "This field's year must be in the range " + this.minimumYear + "-" + this.maximumYear); 
        if (!paramFormSingleValidation.isSet()) {
          int m = UtilityConstants.MONTH_DAYS[i];
          if (i == 2)
            if ((k % 4 == 0 && k % 100 != 0) || k % 400 == 0)
              m = 29;  
          if (j < 1 || 
            j > m)
            paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " has an invalid day.", 
                String.valueOf(getDisplayName()) + " should have a day between 1 and " + m, 
                "This field should have a \"day\" between 1 and " + m); 
        } 
      } catch (Exception exception) {
        paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is incorrectly formatted.  Format: mm/dd/yy", 
            String.valueOf(getDisplayName()) + " is incorrectly formatted.  The correct format is mm/dd/yy.", 
            "This field's date is incorrectly formatterd.  The correct format is mm/dd/yy.");
      } 
    } 
  }
  
  protected void customValidation(FormSingleValidation paramFormSingleValidation) {}
  
  public boolean isDefault() { return "".equals(getValue()); }
  
  public boolean isUnchanged() { return this.startingValue.equals(getValue()); }
  
  public int getMaxLength() { return this.maxLength; }
  
  public void setMaxLength(int paramInt) { this.maxLength = paramInt; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormDateField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */