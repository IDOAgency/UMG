/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.BasicHelper;
/*     */ import com.techempower.UtilityConstants;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormDateField
/*     */   extends FormElement
/*     */   implements UtilityConstants
/*     */ {
/*     */   public static final int DEFAULT_LENGTH = 20;
/*     */   public static final String DEFAULT_VALUE = "";
/*     */   public static final int DEFAULT_MINIMUM_YEAR = 1900;
/*     */   public static final int DEFAULT_MAXIMUM_YEAR = 2200;
/*  58 */   public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("M/d/yy");
/*     */   
/*     */   protected String value;
/*     */   
/*     */   protected String startingValue;
/*     */   
/*     */   protected int length;
/*     */   
/*     */   protected int maxLength;
/*     */   
/*  68 */   protected int minimumYear = 1900;
/*  69 */   protected int maximumYear = 2200;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormDateField(String paramString1, String paramString2, boolean paramBoolean, int paramInt) {
/*  85 */     super(paramString1, paramString2, paramBoolean);
/*  86 */     setLength(paramInt);
/*  87 */     setMaxLength(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormDateField(String paramString, Date paramDate, boolean paramBoolean, int paramInt) {
/* 100 */     super(paramString, paramBoolean);
/* 101 */     setValue(paramDate);
/* 102 */     setStartingValue(getValue());
/* 103 */     setLength(paramInt);
/* 104 */     setMaxLength(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormDateField(String paramString, Calendar paramCalendar, boolean paramBoolean, int paramInt) {
/* 117 */     super(paramString, paramBoolean);
/* 118 */     setValue(paramCalendar);
/* 119 */     setStartingValue(getValue());
/* 120 */     setLength(paramInt);
/* 121 */     setMaxLength(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public FormDateField(String paramString, boolean paramBoolean, int paramInt) { this(paramString, "", paramBoolean, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public FormDateField(String paramString, int paramInt) { this(paramString, "", false, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public FormDateField(String paramString) { this(paramString, "", false, 20); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   public void setLength(int paramInt) { this.length = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   public int getLength() { return this.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public String getStartingValue() { return this.startingValue; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   public void setValue(String paramString) { this.value = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Date paramDate) {
/* 196 */     String str = "";
/* 197 */     if (paramDate != null)
/*     */     {
/* 199 */       str = DATE_FORMAT.format(paramDate);
/*     */     }
/* 201 */     setValue(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Calendar paramCalendar) {
/* 209 */     if (paramCalendar != null)
/*     */     {
/* 211 */       setValue(paramCalendar.getTime());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 223 */   public void setStartingValue(String paramString) { this.startingValue = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 235 */   public void setValue(Context paramContext) { this.value = paramContext.getRequestValue(getName(), this.value); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 244 */   protected String getValue() { return this.value; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 252 */   public String getStringValue() { return getValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Date getDateValue() {
/* 260 */     Calendar calendar = getCalendarValue();
/* 261 */     if (calendar != null)
/* 262 */       return calendar.getTime(); 
/* 263 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Calendar getCalendarValue() {
/* 271 */     String str = getStringValue();
/* 272 */     return BasicHelper.parseDate(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 284 */   public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 295 */   public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 304 */   public int getIntegerValue() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render() {
/* 312 */     StringBuffer stringBuffer = new StringBuffer(60);
/*     */     
/* 314 */     stringBuffer.append("<input type=\"text\"");
/* 315 */     stringBuffer.append(getClassName());
/* 316 */     stringBuffer.append(" name=\"");
/* 317 */     stringBuffer.append(getName());
/* 318 */     stringBuffer.append("\" value=\"");
/* 319 */     stringBuffer.append(getRenderableValue());
/* 320 */     stringBuffer.append("\" size=\"");
/* 321 */     stringBuffer.append(getLength());
/* 322 */     stringBuffer.append("\" maxlength=\"");
/* 323 */     stringBuffer.append(getMaxLength());
/* 324 */     stringBuffer.append('"');
/* 325 */     stringBuffer.append(getTabIndex());
/* 326 */     stringBuffer.append(getFormEvents());
/* 327 */     stringBuffer.append(getEnabledString());
/* 328 */     stringBuffer.append(getReadOnlyString());
/* 329 */     stringBuffer.append(getId());
/* 330 */     stringBuffer.append('>');
/*     */     
/* 332 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormSingleValidation validate() {
/* 340 */     FormSingleValidation formSingleValidation = new FormSingleValidation(this);
/*     */     
/* 342 */     if (isRequired())
/*     */     {
/*     */       
/* 345 */       requiredValidation(formSingleValidation);
/*     */     }
/*     */ 
/*     */     
/* 349 */     customValidation(formSingleValidation);
/*     */     
/* 351 */     return formSingleValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
/* 363 */     if (getStringValue().length() == 0) {
/*     */       
/* 365 */       paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is empty.", 
/* 366 */           "Please provide input in the field named " + getDisplayName() + ".", 
/* 367 */           "This field requires input.");
/*     */     }
/* 369 */     else if (getStringValue().length() > getLength()) {
/*     */       
/* 371 */       paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is too long.", 
/* 372 */           "Please keep the input in field " + getDisplayName() + " to " + 
/* 373 */           getLength() + " characters or less.", 
/* 374 */           "The value entered in this field must be less then " + (getLength() + 1) + " characters long.");
/*     */     }
/*     */     else {
/*     */       
/* 378 */       String str = getStringValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 386 */         StringTokenizer stringTokenizer = new StringTokenizer(str, "-/.");
/* 387 */         String str1 = stringTokenizer.nextToken();
/* 388 */         String str2 = stringTokenizer.nextToken();
/* 389 */         String str3 = stringTokenizer.nextToken();
/*     */         
/* 391 */         int i = Integer.parseInt(str1) - 1;
/* 392 */         int j = Integer.parseInt(str2);
/* 393 */         int k = Integer.parseInt(str3);
/*     */ 
/*     */         
/* 396 */         if (k < 100)
/*     */         {
/* 398 */           if (k > 50) {
/* 399 */             k += 1900;
/*     */           } else {
/* 401 */             k += 2000;
/*     */           } 
/*     */         }
/*     */         
/* 405 */         if (!paramFormSingleValidation.isSet() && (
/* 406 */           i > 11 || 
/* 407 */           i < 0))
/*     */         {
/*     */           
/* 410 */           paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " has an invalid month.", 
/* 411 */               String.valueOf(getDisplayName()) + " has an invalid month.", 
/* 412 */               "This field has an invalid month.");
/*     */         }
/*     */ 
/*     */         
/* 416 */         if (!paramFormSingleValidation.isSet() && (
/* 417 */           k > this.maximumYear || 
/* 418 */           k < this.minimumYear))
/*     */         {
/*     */           
/* 421 */           paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " has an invalid year (" + this.minimumYear + "-" + this.maximumYear + ").", 
/* 422 */               String.valueOf(getDisplayName()) + " has an invalid year.  Valid years are from " + 
/* 423 */               this.minimumYear + " to " + this.maximumYear + ".", 
/* 424 */               "This field's year must be in the range " + this.minimumYear + "-" + this.maximumYear);
/*     */         }
/*     */ 
/*     */         
/* 428 */         if (!paramFormSingleValidation.isSet())
/*     */         {
/* 430 */           int m = UtilityConstants.MONTH_DAYS[i];
/*     */ 
/*     */           
/* 433 */           if (i == 2)
/*     */           {
/* 435 */             if ((k % 4 == 0 && k % 100 != 0) || k % 400 == 0)
/*     */             {
/* 437 */               m = 29;
/*     */             }
/*     */           }
/*     */ 
/*     */           
/* 442 */           if (j < 1 || 
/* 443 */             j > m)
/*     */           {
/*     */             
/* 446 */             paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " has an invalid day.", 
/* 447 */                 String.valueOf(getDisplayName()) + " should have a day between 1 and " + m, 
/* 448 */                 "This field should have a \"day\" between 1 and " + m);
/*     */           }
/*     */         }
/*     */       
/* 452 */       } catch (Exception exception) {
/*     */         
/* 454 */         paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is incorrectly formatted.  Format: mm/dd/yy", 
/* 455 */             String.valueOf(getDisplayName()) + " is incorrectly formatted.  The correct format is mm/dd/yy.", 
/* 456 */             "This field's date is incorrectly formatterd.  The correct format is mm/dd/yy.");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void customValidation(FormSingleValidation paramFormSingleValidation) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 474 */   public boolean isDefault() { return "".equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 484 */   public boolean isUnchanged() { return this.startingValue.equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 492 */   public int getMaxLength() { return this.maxLength; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 500 */   public void setMaxLength(int paramInt) { this.maxLength = paramInt; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormDateField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */