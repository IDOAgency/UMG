/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.DataEntity;
/*     */ import com.techempower.DatabaseConnector;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxContentTypeInstancesGroupVariant
/*     */   extends DataEntity
/*     */   implements FornaxConstants, FornaxDBConstants
/*     */ {
/*  37 */   protected int variantID = -1;
/*  38 */   protected int variantVariantTypeID = -1;
/*  39 */   protected int variantInstancesGroupID = -1;
/*  40 */   protected int variantTemplateID = -1;
/*  41 */   protected int variantGenerationDestinationID = -1;
/*     */   protected boolean variantIsEnabledForGeneration = false;
/*  43 */   protected String variantFileNamePrefix = "";
/*  44 */   protected String variantFileNameTitle = "";
/*  45 */   protected String variantFileNameSuffix = "";
/*  46 */   protected String variantFileNameExtension = "";
/*  47 */   protected String variantFileNameNumberingMode = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializationComplete() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getCustomSetMethodBindings() {
/*  67 */     Hashtable hashtable = new Hashtable();
/*     */     
/*  69 */     hashtable.put("VariantID", "setID");
/*  70 */     hashtable.put("VariantTypeID", "setVariantTypeID");
/*  71 */     hashtable.put("VariantInstancesGroupID", "setInstancesGroupID");
/*  72 */     hashtable.put("VariantTemplateID", "setTemplateID");
/*  73 */     hashtable.put("VariantGenerationDestinationID", "setGenerationDestinationID");
/*  74 */     hashtable.put("VariantIsEnabledForGeneration", "setIsEnabledForGeneration");
/*  75 */     hashtable.put("VariantFileNamePrefix", "setFileNamePrefix");
/*  76 */     hashtable.put("VariantFileNameTitle", "setFileNameTitle");
/*  77 */     hashtable.put("VariantFileNameSuffix", "setFileNameSuffix");
/*  78 */     hashtable.put("VariantFileNameExtension", "setFileNameExtension");
/*  79 */     hashtable.put("VariantFileNameNumberingMode", "setFileNameNumberingMode");
/*     */     
/*  81 */     return hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public int getIdentity() { return this.variantID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public String getTableName() { return "fnContentTypeInstancesGroupVariant"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public String getIdentityColumnName() { return "VariantID"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public int getID() { return this.variantID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public int getVariantTypeID() { return this.variantVariantTypeID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public int getInstancesGroupID() { return this.variantInstancesGroupID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public int getTemplateID() { return this.variantTemplateID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public int getGenerationDestinationID() { return this.variantGenerationDestinationID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   public boolean isEnabledForGeneration() { return this.variantIsEnabledForGeneration; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIsEnabledForGenerationAsString() {
/* 168 */     if (this.variantIsEnabledForGeneration) {
/* 169 */       return "T";
/*     */     }
/* 171 */     return "F";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public String getFileNamePrefix() { return this.variantFileNamePrefix; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 186 */   public String getFileNameTitle() { return this.variantFileNameTitle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   public String getFileNameSuffix() { return this.variantFileNameSuffix; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   public String getFileNameExtension() { return this.variantFileNameExtension; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 204 */   public String getFileNameNumberingMode() { return this.variantFileNameNumberingMode; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 219 */   public void setID(int paramInt) { this.variantID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 230 */   public void setVariantTypeID(int paramInt) { this.variantVariantTypeID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 241 */   public void setInstancesGroupID(int paramInt) { this.variantInstancesGroupID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 252 */   public void setTemplateID(int paramInt) { this.variantTemplateID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 263 */   public void setGenerationDestinationID(int paramInt) { this.variantGenerationDestinationID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsEnabledForGeneration(String paramString) {
/* 274 */     this.variantIsEnabledForGeneration = false;
/*     */     
/* 276 */     if (paramString.trim().equalsIgnoreCase("T"))
/*     */     {
/* 278 */       this.variantIsEnabledForGeneration = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileNamePrefix(String paramString) {
/* 291 */     if (paramString != null) {
/* 292 */       this.variantFileNamePrefix = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileNameTitle(String paramString) {
/* 303 */     if (paramString != null) {
/* 304 */       this.variantFileNameTitle = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileNameSuffix(String paramString) {
/* 315 */     if (paramString != null) {
/* 316 */       this.variantFileNameSuffix = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileNameExtension(String paramString) {
/* 327 */     if (paramString != null) {
/* 328 */       this.variantFileNameExtension = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileNameNumberingMode(String paramString) {
/* 339 */     if (paramString != null) {
/* 340 */       this.variantFileNameNumberingMode = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int runUpdate(DatabaseConnector paramDatabaseConnector) {
/* 348 */     String str1 = "IDENTITY_VALUE";
/* 349 */     String str2 = "ROWCOUNT_VALUE";
/*     */     
/* 351 */     boolean bool = false;
/*     */     
/* 353 */     String str3 = new String("");
/* 354 */     String str4 = new String("select @@identity as 'IDENTITY_VALUE'");
/* 355 */     String str5 = new String("select @@rowcount as 'ROWCOUNT_VALUE'");
/*     */ 
/*     */     
/* 358 */     if (this.variantID == -1) {
/*     */       
/* 360 */       bool = true;
/*     */       
/* 362 */       str3 = String.valueOf(str3) + "INSERT INTO " + getTableName() + 
/* 363 */         "          ( " + "variantTypeID" + ", " + 
/* 364 */         "variantInstancesGroupID" + ", " + 
/* 365 */         "variantTemplateID" + ", " + 
/* 366 */         "variantGenerationDestinationID" + ", " + 
/* 367 */         "variantIsEnabledForGeneration" + ", " + 
/* 368 */         "variantFileNamePrefix" + ", " + 
/* 369 */         "variantFileNameTitle" + ", " + 
/* 370 */         "variantFileNameSuffix" + ", " + 
/* 371 */         "variantFileNameExtension" + ", " + 
/* 372 */         "variantFileNameNumberingMode" + 
/* 373 */         "          ) " + 
/* 374 */         "   VALUES (" + getVariantTypeID() + ", " + 
/* 375 */         getInstancesGroupID() + ", " + 
/* 376 */         getTemplateID() + ", " + 
/* 377 */         getGenerationDestinationID() + ",' " + 
/* 378 */         getIsEnabledForGenerationAsString() + "', '" + 
/* 379 */         getFileNamePrefix() + "', '" + 
/* 380 */         getFileNameTitle() + "', '" + 
/* 381 */         getFileNameSuffix() + "', '" + 
/* 382 */         getFileNameExtension() + "', '" + 
/* 383 */         getFileNameNumberingMode() + "'" + 
/* 384 */         "          )";
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 389 */       str3 = String.valueOf(str3) + "UPDATE " + getTableName() + 
/* 390 */         "   SET " + "variantTypeID" + "=" + getVariantTypeID() + ", " + 
/* 391 */         "variantInstancesGroupID" + "=" + getInstancesGroupID() + ", " + 
/* 392 */         "variantTemplateID" + "=" + getTemplateID() + "," + 
/* 393 */         "variantGenerationDestinationID" + "=" + getGenerationDestinationID() + "," + 
/* 394 */         "variantIsEnabledForGeneration" + "='" + getIsEnabledForGenerationAsString() + "'," + 
/* 395 */         "variantFileNamePrefix" + "='" + getFileNamePrefix() + "'," + 
/* 396 */         "variantFileNameTitle" + "='" + getFileNameTitle() + "'," + 
/* 397 */         "variantFileNameSuffix" + "='" + getFileNameSuffix() + "'," + 
/* 398 */         "variantFileNameExtension" + "='" + getFileNameExtension() + "'," + 
/* 399 */         "variantFileNameNumberingMode" + "='" + getFileNameNumberingMode() + "'";
/*     */ 
/*     */       
/* 402 */       str3 = String.valueOf(str3) + " WHERE " + getIdentityColumnName() + "=" + getID();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 408 */     if (bool) {
/* 409 */       str3 = String.valueOf(str3) + "; " + str4;
/*     */     } else {
/* 411 */       str3 = String.valueOf(str3) + "; " + str5;
/*     */     } 
/*     */     
/* 414 */     str3 = "BEGIN TRAN; " + str3 + "; " + "COMMIT TRAN";
/*     */     
/* 416 */     System.out.println("Running sql stmt:\n" + str3);
/*     */ 
/*     */     
/* 419 */     paramDatabaseConnector.setQuery(str3);
/* 420 */     paramDatabaseConnector.runQuery();
/*     */ 
/*     */     
/* 423 */     if (paramDatabaseConnector.more()) {
/*     */       
/* 425 */       paramDatabaseConnector.first();
/*     */ 
/*     */ 
/*     */       
/* 429 */       if (bool) {
/* 430 */         int j = paramDatabaseConnector.getInt("IDENTITY_VALUE", -1);
/*     */       }
/* 432 */       int i = paramDatabaseConnector.getInt("ROWCOUNT_VALUE", -1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 445 */     paramDatabaseConnector.close();
/*     */     
/* 447 */     return -1;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstancesGroupVariant.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */