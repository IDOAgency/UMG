/*     */ package com.techempower;
/*     */ 
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnhancedProperties
/*     */   extends Properties
/*     */ {
/*     */   protected TechEmpowerApplication application;
/*     */   
/*  54 */   public EnhancedProperties(TechEmpowerApplication paramTechEmpowerApplication) { setApplication(paramTechEmpowerApplication); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnhancedProperties() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public void setApplication(TechEmpowerApplication paramTechEmpowerApplication) { this.application = paramTechEmpowerApplication; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public TechEmpowerApplication getApplication() { return this.application; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public long getLongProperty(String paramString) { return getLongProperty(paramString, 0L); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLongProperty(String paramString, long paramLong) {
/*  96 */     long l = paramLong;
/*     */ 
/*     */     
/*     */     try {
/* 100 */       l = Long.parseLong(getProperty(paramString));
/*     */     }
/* 102 */     catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public int getIntegerProperty(String paramString) { return getIntegerProperty(paramString, 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntegerProperty(String paramString, int paramInt) {
/* 123 */     int i = paramInt;
/*     */ 
/*     */     
/*     */     try {
/* 127 */       i = Integer.parseInt(getProperty(paramString));
/*     */     }
/* 129 */     catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public double getDoubleProperty(String paramString) { return getDoubleProperty(paramString, 0.0D); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoubleProperty(String paramString, double paramDouble) {
/* 150 */     double d = paramDouble;
/*     */ 
/*     */     
/*     */     try {
/* 154 */       d = Double.parseDouble(getProperty(paramString));
/*     */     }
/* 156 */     catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   public float getFloatProperty(String paramString) { return getFloatProperty(paramString, 0.0F); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloatProperty(String paramString, float paramFloat) {
/* 177 */     float f = paramFloat;
/*     */ 
/*     */     
/*     */     try {
/* 181 */       f = Float.parseFloat(getProperty(paramString));
/*     */     }
/* 183 */     catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 188 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 196 */   public boolean getYesNoProperty(String paramString) { return getYesNoProperty(paramString, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getYesNoProperty(String paramString, boolean paramBoolean) {
/* 204 */     boolean bool = paramBoolean;
/*     */     
/* 206 */     String str = getProperty(paramString);
/* 207 */     if (str != null)
/*     */     {
/* 209 */       if (str.equalsIgnoreCase("Yes")) {
/* 210 */         bool = true;
/* 211 */       } else if (str.equalsIgnoreCase("No")) {
/* 212 */         bool = false;
/*     */       } 
/*     */     }
/* 215 */     return bool;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\EnhancedProperties.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */