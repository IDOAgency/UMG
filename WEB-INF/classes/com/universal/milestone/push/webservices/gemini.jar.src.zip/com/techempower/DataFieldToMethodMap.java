package com.techempower;

import java.lang.reflect.Method;

class DataFieldToMethodMap extends DataFieldToObjectEntityMap {
  public Method method;
  
  public DataFieldToMethodMap(Method paramMethod, String paramString, int paramInt) {
    this.method = paramMethod;
    this.fieldName = paramString;
    this.fieldType = paramInt;
  }
  
  public DataFieldToMethodMap() {}
  
  public String toString() { return "DFTMM [" + this.fieldName + "; " + this.fieldType + "]"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\DataFieldToMethodMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */