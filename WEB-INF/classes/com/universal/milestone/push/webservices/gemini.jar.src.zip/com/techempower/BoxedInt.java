package com.techempower;

public final class BoxedInt {
  private int intValue;
  
  public BoxedInt(int paramInt) { this.intValue = paramInt; }
  
  public int get() { return this.intValue; }
  
  public void set(int paramInt) { this.intValue = paramInt; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\BoxedInt.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */