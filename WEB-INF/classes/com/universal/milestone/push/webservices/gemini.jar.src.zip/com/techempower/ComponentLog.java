package com.techempower;

public class ComponentLog {
  protected Log log;
  
  protected String componentCode;
  
  public ComponentLog(Log paramLog, String paramString) {
    this.log = paramLog;
    this.componentCode = paramString;
  }
  
  public void debug(String paramString) { this.log.debug(this.componentCode, paramString); }
  
  public void log(String paramString) { this.log.log(this.componentCode, paramString); }
  
  public void assert(boolean paramBoolean, String paramString) { this.log.assert(this.componentCode, paramBoolean, paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\ComponentLog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */