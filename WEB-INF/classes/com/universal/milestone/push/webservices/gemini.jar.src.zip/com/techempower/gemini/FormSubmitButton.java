/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.BasicHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormSubmitButton
/*     */   extends FormSubmissionElement
/*     */ {
/*     */   public static final String DEFAULT_VALUE = "Submit";
/*     */   protected String value;
/*     */   protected String startingValue;
/*     */   protected boolean submitted = false;
/*     */   
/*     */   public FormSubmitButton(String paramString1, String paramString2, boolean paramBoolean) {
/*  55 */     super(paramString1, paramString2, paramBoolean);
/*     */ 
/*     */ 
/*     */     
/*  59 */     setReadOnly(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public FormSubmitButton(String paramString1, String paramString2) { this(paramString1, paramString2, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String paramString) {
/*  75 */     if (!isReadOnly()) {
/*  76 */       this.value = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Context paramContext) {
/*  91 */     String str = paramContext.getRequestValue(getName(), "");
/*  92 */     this.submitted = !(str.length() <= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public void setStartingValue(String paramString) { this.startingValue = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public String getStartingValue() { return this.startingValue; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   protected String getValue() { return this.value; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public String getStringValue() { return getValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public int getIntegerValue() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render() {
/* 167 */     StringBuffer stringBuffer = new StringBuffer(60);
/*     */     
/* 169 */     stringBuffer.append("<input type=\"submit\" name=\"");
/* 170 */     stringBuffer.append(getName());
/* 171 */     stringBuffer.append("\" value=\"");
/* 172 */     stringBuffer.append(getRenderableValue());
/* 173 */     stringBuffer.append('"');
/* 174 */     stringBuffer.append(getTabIndex());
/* 175 */     stringBuffer.append(getFormEvents());
/* 176 */     stringBuffer.append(getEnabledString());
/* 177 */     stringBuffer.append(getReadOnlyString());
/* 178 */     stringBuffer.append(getId());
/* 179 */     stringBuffer.append('>');
/*     */     
/* 181 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 190 */   public FormSingleValidation validate() { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 211 */   public boolean isDefault() { return "Submit".equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 221 */   public boolean isUnchanged() { return this.startingValue.equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 229 */   public boolean isSubmitted() { return this.submitted; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormSubmitButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */