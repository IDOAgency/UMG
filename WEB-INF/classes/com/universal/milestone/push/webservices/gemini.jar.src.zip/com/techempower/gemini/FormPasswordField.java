/*     */ package com.techempower.gemini;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormPasswordField
/*     */   extends FormTextField
/*     */ {
/*  43 */   public FormPasswordField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2) { super(paramString1, paramString2, paramBoolean, paramInt1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public FormPasswordField(String paramString1, String paramString2, boolean paramBoolean, int paramInt) { this(paramString1, paramString2, paramBoolean, paramInt, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public FormPasswordField(String paramString, boolean paramBoolean, int paramInt) { this(paramString, "", paramBoolean, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public FormPasswordField(String paramString, int paramInt) { this(paramString, "", false, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public FormPasswordField(String paramString) { this(paramString, "", false, 20); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render() {
/*  85 */     StringBuffer stringBuffer = new StringBuffer(60);
/*     */     
/*  87 */     stringBuffer.append("<input type=\"password\"");
/*  88 */     stringBuffer.append(getClassName());
/*  89 */     stringBuffer.append(" name=\"");
/*  90 */     stringBuffer.append(getName());
/*  91 */     stringBuffer.append("\" value=\"");
/*  92 */     stringBuffer.append(getRenderableValue());
/*  93 */     stringBuffer.append("\" size=\"");
/*  94 */     stringBuffer.append(getLength());
/*  95 */     stringBuffer.append("\" maxlength=\"");
/*  96 */     stringBuffer.append(getMaxLength());
/*  97 */     stringBuffer.append("\"");
/*  98 */     stringBuffer.append(getTabIndex());
/*  99 */     stringBuffer.append(getFormEvents());
/* 100 */     stringBuffer.append(getEnabledString());
/* 101 */     stringBuffer.append(getReadOnlyString());
/* 102 */     stringBuffer.append(getId());
/* 103 */     stringBuffer.append('>');
/*     */     
/* 105 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormPasswordField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */