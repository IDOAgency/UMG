/*     */ package com.techempower.gemini.pyxis;
/*     */ 
/*     */ import com.techempower.BasicHelper;
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.ConnectorFactory;
/*     */ import com.techempower.DatabaseConnector;
/*     */ import com.techempower.EnhancedProperties;
/*     */ import com.techempower.gemini.Context;
/*     */ import com.techempower.gemini.GeminiApplication;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicSecurity
/*     */   implements PyxisConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "secu";
/*  43 */   private static Random random = new Random();
/*     */ 
/*     */ 
/*     */   
/*     */   protected GeminiApplication application;
/*     */ 
/*     */ 
/*     */   
/*     */   protected ComponentLog log;
/*     */ 
/*     */ 
/*     */   
/*     */   protected PyxisSettings settings;
/*     */ 
/*     */   
/*     */   protected ConnectorFactory connectorFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicSecurity(GeminiApplication paramGeminiApplication) {
/*  63 */     this.application = paramGeminiApplication;
/*  64 */     this.log = this.application.getLog("secu");
/*  65 */     this.settings = new PyxisSettings(this.application);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(EnhancedProperties paramEnhancedProperties) {
/*  73 */     this.settings.configure(paramEnhancedProperties);
/*  74 */     this.connectorFactory = this.settings.getConnectorFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicUser getUser(String paramString1, String paramString2) {
/*  86 */     DatabaseConnector databaseConnector = this.connectorFactory.getConnector(
/*  87 */         "SELECT * FROM " + this.settings.getUsersTable() + 
/*  88 */         " WHERE " + "UserUsername" + " = " + BasicHelper.prepareString(paramString1) + 
/*  89 */         " AND " + "UserPassword" + " = " + BasicHelper.prepareString(paramString2) + 
/*  90 */         ";");
/*  91 */     databaseConnector.runQuery();
/*     */ 
/*     */     
/*  94 */     if (databaseConnector.more()) {
/*     */       
/*  96 */       BasicUser basicUser = constructUser();
/*  97 */       basicUser.initializeByMethods(databaseConnector);
/*  98 */       return basicUser;
/*     */     } 
/*     */     
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicUser getUser(int paramInt) {
/* 113 */     DatabaseConnector databaseConnector = this.connectorFactory.getConnector(
/* 114 */         "SELECT * FROM " + this.settings.getUsersTable() + 
/* 115 */         " WHERE " + "UserID" + " = " + paramInt + 
/* 116 */         ";");
/* 117 */     databaseConnector.runQuery();
/*     */ 
/*     */     
/* 120 */     if (databaseConnector.more()) {
/*     */       
/* 122 */       BasicUser basicUser = constructUser();
/* 123 */       basicUser.initializeByMethods(databaseConnector);
/* 124 */       return basicUser;
/*     */     } 
/*     */     
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean login(Context paramContext, String paramString1, String paramString2) {
/* 151 */     BasicUser basicUser = getUser(paramString1, paramString2);
/*     */     
/* 153 */     if (basicUser != null) {
/*     */       
/* 155 */       paramContext.putSessionValue("Pyxis.User", basicUser);
/* 156 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 160 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   public void logout(Context paramContext) { paramContext.removeSessionValue("Pyxis.User"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public BasicUser getLogin(Context paramContext) { return (BasicUser)paramContext.getSessionValue("Pyxis.User"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   public boolean isLoggedIn(Context paramContext) { return !(getLogin(paramContext) == null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAdministrator(Context paramContext) {
/* 202 */     BasicUser basicUser = getLogin(paramContext);
/* 203 */     return basicUser.isAdministrator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUser(Context paramContext) {
/* 214 */     BasicUser basicUser = getLogin(paramContext);
/* 215 */     return basicUser.isUser();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGuest(Context paramContext) {
/* 226 */     BasicUser basicUser = getLogin(paramContext);
/* 227 */     return basicUser.isGuest();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 238 */   public String randomPassword() { return randomPassword(this.settings.getRandomPasswordLength()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 252 */   protected BasicUser constructUser() { return new BasicUser(this.settings); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String randomPassword(int paramInt) {
/* 267 */     int i = paramInt;
/* 268 */     String str = "";
/*     */     
/* 270 */     while (i > 0) {
/*     */       
/* 272 */       int j = random.nextInt(3);
/*     */       
/* 274 */       switch (j) {
/*     */         
/*     */         case 0:
/* 277 */           str = String.valueOf((char)(97 + random.nextInt(26))) + str;
/*     */           break;
/*     */         case 1:
/* 280 */           str = String.valueOf((char)(65 + random.nextInt(26))) + str;
/*     */           break;
/*     */         case 2:
/* 283 */           str = String.valueOf((char)(48 + random.nextInt(10))) + str;
/*     */           break;
/*     */       } 
/*     */       
/* 287 */       i--;
/*     */     } 
/*     */     
/* 290 */     return str;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\pyxis\BasicSecurity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */