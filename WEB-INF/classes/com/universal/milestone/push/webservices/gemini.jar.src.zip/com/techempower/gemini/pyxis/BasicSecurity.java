package com.techempower.gemini.pyxis;

import com.techempower.BasicHelper;
import com.techempower.ComponentLog;
import com.techempower.ConnectorFactory;
import com.techempower.DatabaseConnector;
import com.techempower.EnhancedProperties;
import com.techempower.gemini.Context;
import com.techempower.gemini.GeminiApplication;
import java.util.Random;

public class BasicSecurity implements PyxisConstants {
  public static final String COMPONENT_CODE = "secu";
  
  private static Random random = new Random();
  
  protected GeminiApplication application;
  
  protected ComponentLog log;
  
  protected PyxisSettings settings;
  
  protected ConnectorFactory connectorFactory;
  
  public BasicSecurity(GeminiApplication paramGeminiApplication) {
    this.application = paramGeminiApplication;
    this.log = this.application.getLog("secu");
    this.settings = new PyxisSettings(this.application);
  }
  
  public void configure(EnhancedProperties paramEnhancedProperties) {
    this.settings.configure(paramEnhancedProperties);
    this.connectorFactory = this.settings.getConnectorFactory();
  }
  
  public BasicUser getUser(String paramString1, String paramString2) {
    DatabaseConnector databaseConnector = this.connectorFactory.getConnector(
        "SELECT * FROM " + this.settings.getUsersTable() + 
        " WHERE " + "UserUsername" + " = " + BasicHelper.prepareString(paramString1) + 
        " AND " + "UserPassword" + " = " + BasicHelper.prepareString(paramString2) + 
        ";");
    databaseConnector.runQuery();
    if (databaseConnector.more()) {
      BasicUser basicUser = constructUser();
      basicUser.initializeByMethods(databaseConnector);
      return basicUser;
    } 
    return null;
  }
  
  public BasicUser getUser(int paramInt) {
    DatabaseConnector databaseConnector = this.connectorFactory.getConnector(
        "SELECT * FROM " + this.settings.getUsersTable() + 
        " WHERE " + "UserID" + " = " + paramInt + 
        ";");
    databaseConnector.runQuery();
    if (databaseConnector.more()) {
      BasicUser basicUser = constructUser();
      basicUser.initializeByMethods(databaseConnector);
      return basicUser;
    } 
    return null;
  }
  
  public boolean login(Context paramContext, String paramString1, String paramString2) {
    BasicUser basicUser = getUser(paramString1, paramString2);
    if (basicUser != null) {
      paramContext.putSessionValue("Pyxis.User", basicUser);
      return true;
    } 
    return false;
  }
  
  public void logout(Context paramContext) { paramContext.removeSessionValue("Pyxis.User"); }
  
  public BasicUser getLogin(Context paramContext) { return (BasicUser)paramContext.getSessionValue("Pyxis.User"); }
  
  public boolean isLoggedIn(Context paramContext) { return !(getLogin(paramContext) == null); }
  
  public boolean isAdministrator(Context paramContext) {
    BasicUser basicUser = getLogin(paramContext);
    return basicUser.isAdministrator();
  }
  
  public boolean isUser(Context paramContext) {
    BasicUser basicUser = getLogin(paramContext);
    return basicUser.isUser();
  }
  
  public boolean isGuest(Context paramContext) {
    BasicUser basicUser = getLogin(paramContext);
    return basicUser.isGuest();
  }
  
  public String randomPassword() { return randomPassword(this.settings.getRandomPasswordLength()); }
  
  protected BasicUser constructUser() { return new BasicUser(this.settings); }
  
  public static String randomPassword(int paramInt) {
    int i = paramInt;
    String str = "";
    while (i > 0) {
      int j = random.nextInt(3);
      switch (j) {
        case 0:
          str = String.valueOf((char)(97 + random.nextInt(26))) + str;
          break;
        case 1:
          str = String.valueOf((char)(65 + random.nextInt(26))) + str;
          break;
        case 2:
          str = String.valueOf((char)(48 + random.nextInt(10))) + str;
          break;
      } 
      i--;
    } 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\pyxis\BasicSecurity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */