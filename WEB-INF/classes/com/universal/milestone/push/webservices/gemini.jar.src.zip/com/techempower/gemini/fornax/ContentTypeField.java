package com.techempower.gemini.fornax;

import java.util.Hashtable;

public class ContentTypeField implements FornaxDBConstants {
  protected int mFieldID;
  
  protected int mFieldContentTypeID;
  
  protected String mFieldName;
  
  protected String mFieldDescription;
  
  protected int mDataTypeID;
  
  protected String mDataTypeName;
  
  protected String mDataTypeDescription;
  
  public ContentTypeField(Hashtable paramHashtable) {
    this.mFieldID = ((Integer)paramHashtable.get("instanceFieldID")).intValue();
    this.mFieldContentTypeID = ((Integer)paramHashtable.get("instanceContentTypeID")).intValue();
    this.mFieldName = (String)paramHashtable.get("instanceFieldName");
    this.mFieldDescription = (String)paramHashtable.get("instanceFieldDescription");
    this.mDataTypeID = ((Integer)paramHashtable.get("instanceDataTypeID")).intValue();
    this.mDataTypeName = (String)paramHashtable.get("instanceDataTypeName");
    this.mDataTypeDescription = (String)paramHashtable.get("instanceDataTypeDescription");
  }
  
  public int getFieldID() { return this.mFieldID; }
  
  public int getFieldContentTypeID() { return this.mFieldContentTypeID; }
  
  public String getFieldName() { return this.mFieldName; }
  
  public String getFieldDescription() { return this.mFieldDescription; }
  
  public int getDataTypeID() { return this.mDataTypeID; }
  
  public String getDataTypeName() { return this.mDataTypeName; }
  
  public String getDataTypeDescription() { return this.mDataTypeDescription; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\ContentTypeField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */