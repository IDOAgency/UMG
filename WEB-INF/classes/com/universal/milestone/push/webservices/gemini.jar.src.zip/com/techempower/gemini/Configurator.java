/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.EnhancedProperties;
/*     */ import com.techempower.Version;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Configurator
/*     */   implements GeminiConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "conf";
/*     */   public static final String CONFIGURATION_FILENAME_EXT = ".conf";
/*     */   protected boolean configured;
/*     */   protected GeminiApplication application;
/*     */   protected ComponentLog log;
/*     */   
/*     */   protected Configurator(GeminiApplication paramGeminiApplication) {
/*  49 */     this.configured = false;
/*  50 */     this.application = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     this.application = paramGeminiApplication;
/*  63 */     this.log = paramGeminiApplication.getLog("conf");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure() {
/*  76 */     Version version = this.application.getVersion();
/*     */     
/*  78 */     this.log.debug("Configuring " + version.getProductName() + " system.");
/*     */ 
/*     */     
/*     */     try {
/*  82 */       String str = String.valueOf(version.getProductName()) + ".conf";
/*     */ 
/*     */       
/*  85 */       InputStream inputStream = ClassLoader.getSystemResourceAsStream(str);
/*     */ 
/*     */       
/*  88 */       if (inputStream == null) {
/*  89 */         inputStream = new FileInputStream(str);
/*     */       }
/*     */       
/*  92 */       EnhancedProperties enhancedProperties = new EnhancedProperties(this.application);
/*  93 */       enhancedProperties.load(inputStream);
/*     */ 
/*     */       
/*  96 */       inputStream.close();
/*     */ 
/*     */       
/*  99 */       configureWithProps(enhancedProperties, version);
/*     */ 
/*     */       
/* 102 */       this.configured = true;
/*     */ 
/*     */       
/* 105 */       this.log.log("Configuration complete.");
/*     */     }
/* 107 */     catch (IOException iOException) {
/*     */       
/* 109 */       this.log.debug("Cannot read configuration file: " + iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File findConfigurationFile(String paramString) {
/* 124 */     String str1 = String.valueOf(paramString) + ".conf";
/*     */     
/* 126 */     File file = new File(str1);
/*     */     
/* 128 */     if (file.exists())
/*     */     {
/* 130 */       return file;
/*     */     }
/*     */ 
/*     */     
/* 134 */     String str2 = System.getProperty("java.class.path");
/* 135 */     StringTokenizer stringTokenizer = new StringTokenizer(str2, ";");
/*     */     
/* 137 */     while (stringTokenizer.hasMoreTokens()) {
/*     */       
/* 139 */       String str = stringTokenizer.nextToken();
/*     */       
/* 141 */       if (!str.endsWith(".jar") && 
/* 142 */         !str.endsWith(".zip")) {
/*     */         
/* 144 */         if (!str.endsWith(File.separator))
/*     */         {
/* 146 */           str = String.valueOf(str) + File.separator;
/*     */         }
/*     */         
/* 149 */         file = new File(String.valueOf(str) + str1);
/* 150 */         if (file.exists()) {
/* 151 */           return file;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 156 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureIfNecessary() {
/* 164 */     if (!isConfigured()) {
/* 165 */       configure();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public boolean isConfigured() { return this.configured; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configureWithProps(EnhancedProperties paramEnhancedProperties, Version paramVersion) {
/* 185 */     this.application.getApplicationLog().configure(paramEnhancedProperties, paramVersion);
/*     */ 
/*     */     
/* 188 */     this.application.getSessionManager().configure(paramEnhancedProperties);
/*     */ 
/*     */     
/* 191 */     this.application.getBugTool().configure(paramEnhancedProperties, paramVersion);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     if (this.application.getEmailServicer() != null)
/* 197 */       this.application.getEmailServicer().configure(paramEnhancedProperties); 
/* 198 */     if (this.application.getEmailTransport() != null)
/* 199 */       this.application.getEmailTransport().configure(paramEnhancedProperties); 
/* 200 */     if (this.application.getEmailTemplater() != null) {
/* 201 */       this.application.getEmailTemplater().configure(paramEnhancedProperties);
/*     */     }
/*     */     
/* 204 */     if (this.application.getFornaxSettings() != null) {
/* 205 */       this.application.getFornaxSettings().configure(paramEnhancedProperties);
/*     */     }
/*     */     
/* 208 */     if (this.application.getSecurity() != null) {
/* 209 */       this.application.getSecurity().configure(paramEnhancedProperties);
/*     */     }
/*     */     
/* 212 */     customConfiguration(paramEnhancedProperties, paramVersion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void customConfiguration(EnhancedProperties paramEnhancedProperties, Version paramVersion) {
/* 228 */     this.log.debug("Default custom configuration called.");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 235 */     this.application.getInfrastructure().configure(paramEnhancedProperties, paramVersion);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\Configurator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */