package com.techempower.gemini.fornax;

import com.techempower.BasicHelper;
import com.techempower.DataEntity;
import com.techempower.DatabaseConnector;
import java.util.Calendar;
import java.util.Hashtable;

public class FornaxContentTypeInstance extends DataEntity implements FornaxConstants, FornaxDBConstants {
  protected int instanceID;
  
  protected int instanceContentTypeID;
  
  protected String instanceName;
  
  protected String instanceDescription;
  
  protected boolean instanceIsDisabled;
  
  protected boolean instanceIsQueuedForDeletion;
  
  protected Calendar instanceDateCreated;
  
  protected int instanceLastModifiedByUserID;
  
  protected Calendar instanceLastModifiedTimestamp;
  
  public FornaxContentTypeInstance() {
    this.instanceID = -1;
    this.instanceContentTypeID = -1;
    this.instanceName = "";
    this.instanceDescription = "";
    this.instanceIsDisabled = false;
    this.instanceIsQueuedForDeletion = false;
    this.instanceDateCreated = null;
    this.instanceLastModifiedByUserID = -1;
    this.instanceLastModifiedTimestamp = null;
    this.instanceDateCreated = FornaxHelper.getInitializedCalendar("1900-01-01 00:00:00AM");
    this.instanceLastModifiedTimestamp = FornaxHelper.getInitializedCalendar("1900-01-01 00:00:00AM");
  }
  
  public void initializationComplete() {}
  
  public Hashtable getCustomSetMethodBindings() {
    Hashtable hashtable = new Hashtable();
    hashtable.put("InstanceID", "setID");
    hashtable.put("InstanceContentTypeID", "setContentTypeID");
    hashtable.put("InstanceName", "setName");
    hashtable.put("InstanceDescription", "setDescription");
    hashtable.put("InstanceIsDisabled", "setIsDisabled");
    hashtable.put("InstanceIsQueuedForDeletion", "setIsQueuedForDeletion");
    hashtable.put("InstanceDateCreated", "setDateCreated");
    hashtable.put("InstanceLastModifiedByUserID", "setLastModifiedByUserID");
    hashtable.put("InstanceLastModifiedTimestamp", "setLastModifiedTimestamp");
    return hashtable;
  }
  
  public int getIdentity() { return this.instanceID; }
  
  public String getTableName() { return "fnContentTypeInstance"; }
  
  public String getIdentityColumnName() { return "InstanceID"; }
  
  public int getID() { return this.instanceID; }
  
  public int getContentTypeID() { return this.instanceContentTypeID; }
  
  public String getName() { return this.instanceName; }
  
  public String getDescription() { return this.instanceDescription; }
  
  public boolean isDisabled() { return this.instanceIsDisabled; }
  
  public String getIsDisabledAsString() {
    if (this.instanceIsDisabled)
      return "T"; 
    return "F";
  }
  
  public boolean isQueuedForDeletion() { return this.instanceIsQueuedForDeletion; }
  
  public String getIsQueuedForDeletionAsString() {
    if (this.instanceIsQueuedForDeletion)
      return "T"; 
    return "F";
  }
  
  public Calendar getDateCreated() { return this.instanceDateCreated; }
  
  public String getDateCreatedAsString() {
    Calendar calendar = FornaxHelper.getInitializedCalendar("1900-01-01 00:00:00AM");
    if (this.instanceDateCreated.getTime().equals(calendar.getTime()))
      return "---"; 
    return BasicHelper.getCalendarAsString(this.instanceDateCreated, 3, 2, "/", "   ");
  }
  
  public int getLastModifiedByUserID() { return this.instanceLastModifiedByUserID; }
  
  public Calendar getLastModifiedTimestamp() { return this.instanceLastModifiedTimestamp; }
  
  public String getLastModifiedTimestampAsString() {
    Calendar calendar = FornaxHelper.getInitializedCalendar("1900-01-01 00:00:00AM");
    if (this.instanceLastModifiedTimestamp.getTime().equals(calendar.getTime()))
      return "---"; 
    return BasicHelper.getCalendarAsString(this.instanceLastModifiedTimestamp, 3, 2, "/", "   ");
  }
  
  public void setID(int paramInt) { this.instanceID = paramInt; }
  
  public void setContentTypeID(int paramInt) { this.instanceContentTypeID = paramInt; }
  
  public void setName(String paramString) {
    if (paramString != null)
      this.instanceName = paramString; 
  }
  
  public void setDescription(String paramString) {
    if (paramString != null)
      this.instanceDescription = paramString; 
  }
  
  public void setIsDisabled(String paramString) {
    this.instanceIsDisabled = false;
    if (paramString.trim().equalsIgnoreCase("T"))
      this.instanceIsDisabled = true; 
  }
  
  public void setIsQueuedForDeletion(String paramString) {
    this.instanceIsQueuedForDeletion = false;
    if (paramString.trim().equalsIgnoreCase("T"))
      this.instanceIsQueuedForDeletion = true; 
  }
  
  public void setDateCreated(Calendar paramCalendar) { this.instanceDateCreated = paramCalendar; }
  
  public void setLastModifiedByUserID(int paramInt) { this.instanceLastModifiedByUserID = paramInt; }
  
  public void setLastModifiedTimestamp(Calendar paramCalendar) { this.instanceLastModifiedTimestamp = paramCalendar; }
  
  public int runUpdate(DatabaseConnector paramDatabaseConnector, boolean paramBoolean) {
    String str1 = "IDENTITY_VALUE";
    String str2 = "ROWCOUNT_VALUE";
    boolean bool = false;
    String str3 = new String("");
    String str4 = new String("select @@identity as 'IDENTITY_VALUE'");
    String str5 = new String("select @@rowcount as 'ROWCOUNT_VALUE'");
    if (this.instanceID == -1) {
      bool = true;
      str3 = String.valueOf(str3) + "INSERT INTO " + getTableName() + 
        "          ( " + "instanceContentTypeID" + ", " + 
        "instanceName" + ", " + 
        "instanceDescription" + ", " + 
        "instanceIsDisabled" + ", " + 
        "instanceIsQueuedForDeletion" + ", " + 
        "instanceDateCreated" + ", " + 
        "instanceLastModifiedByUserID" + ", " + 
        "instanceLastModifiedTimeStamp" + 
        "          ) " + 
        "   VALUES (" + getContentTypeID() + ", '" + 
        getName() + "', '" + 
        getDescription() + "', '" + 
        getIsDisabledAsString() + "', '" + 
        getIsQueuedForDeletionAsString() + "', " + 
        "CURRENT_TIMESTAMP" + ", " + 
        getLastModifiedByUserID() + ", " + 
        "CURRENT_TIMESTAMP" + 
        "          )";
    } else {
      str3 = String.valueOf(str3) + "UPDATE " + getTableName() + 
        "   SET " + "instanceName" + "='" + getName() + "'," + 
        "instanceDescription" + "='" + getDescription() + "'," + 
        "instanceIsDisabled" + "='" + getIsDisabledAsString() + "'," + 
        "instanceIsQueuedForDeletion" + "='" + getIsQueuedForDeletionAsString() + "'";
      if (paramBoolean)
        str3 = String.valueOf(str3) + ",instanceLastModifiedByUserID=" + getLastModifiedByUserID() + "," + 
          "instanceLastModifiedTimeStamp" + "=" + "CURRENT_TIMESTAMP"; 
      str3 = String.valueOf(str3) + " WHERE " + getIdentityColumnName() + "=" + getID();
    } 
    if (bool) {
      str3 = String.valueOf(str3) + "; " + str4;
    } else {
      str3 = String.valueOf(str3) + "; " + str5;
    } 
    str3 = "BEGIN TRAN; " + str3 + "; " + "COMMIT TRAN";
    System.out.println("Running sql stmt:\n" + str3);
    paramDatabaseConnector.setQuery(str3);
    paramDatabaseConnector.runQuery();
    if (paramDatabaseConnector.more()) {
      paramDatabaseConnector.first();
      if (bool)
        int j = paramDatabaseConnector.getInt("IDENTITY_VALUE", -1); 
      int i = paramDatabaseConnector.getInt("ROWCOUNT_VALUE", -1);
    } 
    paramDatabaseConnector.close();
    return -1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstance.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */