package com.techempower.gemini;

public abstract class FormSubmissionElement extends FormElement {
  public FormSubmissionElement(String paramString1, String paramString2, boolean paramBoolean) { super(paramString1, paramString2, paramBoolean); }
  
  public abstract boolean isSubmitted();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormSubmissionElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */