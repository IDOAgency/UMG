package com.techempower.gemini;

import com.techempower.TechEmpowerApplication;
import com.techempower.gemini.fornax.FornaxSettings;
import com.techempower.gemini.pyxis.BasicSecurity;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GeminiApplication extends TechEmpowerApplication implements GeminiConstants {
  protected BasicInfrastructure infrastructure = constructInfrastructure();
  
  protected Configurator configurator = constructConfigurator();
  
  protected Dispatcher dispatcher = constructDispatcher();
  
  protected SessionManager sessionManager = constructSessionManager();
  
  protected BugTool bugTool = constructBugTool();
  
  protected EmailServicer emailServicer = constructEmailServicer();
  
  protected EmailTemplater emailTemplater = constructEmailTemplater();
  
  protected EmailTransport emailTransport = constructEmailTransport();
  
  protected FornaxSettings fornaxSettings = constructFornaxSettings();
  
  protected BasicSecurity security = constructSecurity();
  
  protected static GeminiApplication instance;
  
  protected BasicInfrastructure constructInfrastructure() { return new BasicInfrastructure(this); }
  
  protected Configurator constructConfigurator() { return new Configurator(this); }
  
  protected Dispatcher constructDispatcher() { return new Dispatcher(this); }
  
  protected SessionManager constructSessionManager() { return new SessionManager(this); }
  
  protected BugTool constructBugTool() { return new BugTool(this); }
  
  protected EmailServicer constructEmailServicer() { return new EmailServicer(this); }
  
  protected EmailTransport constructEmailTransport() { return new EmailTransport(this); }
  
  protected EmailTemplater constructEmailTemplater() { return null; }
  
  protected FornaxSettings constructFornaxSettings() { return null; }
  
  protected BasicSecurity constructSecurity() { return null; }
  
  public BasicInfrastructure getInfrastructure() { return this.infrastructure; }
  
  public Configurator getConfigurator() { return this.configurator; }
  
  public Dispatcher getDispatcher() { return this.dispatcher; }
  
  public EmailServicer getEmailServicer() { return this.emailServicer; }
  
  public EmailTransport getEmailTransport() { return this.emailTransport; }
  
  public EmailTemplater getEmailTemplater() { return this.emailTemplater; }
  
  public FornaxSettings getFornaxSettings() { return this.fornaxSettings; }
  
  public BasicSecurity getSecurity() { return this.security; }
  
  public Context getContext(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, ServletContext paramServletContext) { return new Context(paramHttpServletRequest, paramHttpServletResponse, paramServletContext, this.dispatcher); }
  
  public BugTool getBugTool() { return this.bugTool; }
  
  public SessionManager getSessionManager() { return this.sessionManager; }
  
  public final String getGeminiVersion() { return "1.14"; }
  
  public static GeminiApplication getInstance() {
    if (instance == null)
      instance = new GeminiApplication(); 
    return instance;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\GeminiApplication.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */