package com.techempower.gemini.fornax;

import com.techempower.ComponentLog;
import com.techempower.gemini.Context;
import com.techempower.gemini.Dispatcher;
import com.techempower.gemini.GeminiApplication;
import com.techempower.gemini.Handler;
import com.techempower.gemini.pyxis.BasicSecurity;

public class FornaxGenerationHandler implements Handler, FornaxConstants {
  public static final String COMPONENT_CODE = "hLog";
  
  public GeminiApplication application;
  
  public ComponentLog log;
  
  public FornaxSettings fornaxSettings;
  
  protected String navigationCommandPrefix;
  
  public FornaxGenerationHandler(GeminiApplication paramGeminiApplication) {
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("hLog");
    this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
    this.navigationCommandPrefix = new String(String.valueOf(paramGeminiApplication.getInfrastructure().getServletURL()) + "?" + "cmd" + "=" + "fornax-");
  }
  
  public String getDescription() { return "GenerationManagement"; }
  
  public boolean acceptRequest(Dispatcher paramDispatcher, Context paramContext, String paramString) {
    BasicSecurity basicSecurity = this.fornaxSettings.getSecurity();
    if (basicSecurity != null && basicSecurity.isLoggedIn(paramContext)) {
      if (paramString.equalsIgnoreCase("fornax-generation-run"))
        return handleRequest(paramDispatcher, paramContext, paramString); 
      return false;
    } 
    return paramDispatcher.redispatch(paramContext, "fornax-login");
  }
  
  public boolean handleRequest(Dispatcher paramDispatcher, Context paramContext, String paramString) {
    if (paramString.equalsIgnoreCase("fornax-generation-run"))
      return runGeneration(paramContext); 
    return false;
  }
  
  public boolean runGeneration(Context paramContext) {
    this.log.debug("Generation running starting ....");
    Generator generator = new Generator(this.fornaxSettings);
    generator.startGeneration();
    String str1 = generator.getReportString();
    this.log.debug("Generation running ended ....");
    buildGenerationManagementElements(paramContext);
    paramContext.putDelivery("StatusReport", new String(str1));
    String str2 = "generation-status.jsp";
    return paramContext.includeJSP(str2, String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix());
  }
  
  protected void buildGenerationManagementElements(Context paramContext) {
    paramContext.putDelivery("LinkMainMenu", new String(String.valueOf(this.navigationCommandPrefix) + "main-menu"));
    paramContext.putDelivery("LinkLogout", new String(String.valueOf(this.navigationCommandPrefix) + "login" + "&" + "logout" + "=true"));
    paramContext.putDelivery("LinkRunGeneration", new String(String.valueOf(this.navigationCommandPrefix) + "generation-run"));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxGenerationHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */