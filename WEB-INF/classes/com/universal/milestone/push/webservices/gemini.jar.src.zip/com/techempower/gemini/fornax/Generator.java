package com.techempower.gemini.fornax;

import java.util.Hashtable;
import java.util.Vector;

public class Generator implements FornaxDBConstants, FornaxSQLStatements {
  boolean debug;
  
  FornaxSettings mSettings;
  
  protected Report mReport;
  
  public Generator(FornaxSettings paramFornaxSettings) {
    this.debug = true;
    this.mSettings = null;
    this.mSettings = paramFornaxSettings;
    this.mReport = (new ReportManager(this.mSettings)).getReport();
  }
  
  public void startGeneration() {
    Vector vector1 = new Vector();
    Vector vector2 = new Vector();
    Vector vector3 = new Vector();
    Vector vector4 = new Vector();
    DataObjectManager dataObjectManager = new DataObjectManager(this.mSettings);
    DBRecordManager dBRecordManager = new DBRecordManager();
    GeneratorFileManager generatorFileManager = new GeneratorFileManager();
    vector1 = dataObjectManager.buildContentInfo();
    Hashtable hashtable1 = dataObjectManager.getGroupTable();
    Hashtable hashtable2 = dataObjectManager.getContentTypeTable();
    this.mReport.startReport();
    for (byte b = 0; b < vector1.size(); b++) {
      ContentType contentType = (ContentType)vector1.elementAt(b);
      if (this.mSettings.isMultiGroup())
        this.mReport.startContentTypeReport(contentType); 
      vector2 = contentType.getGroups();
      for (byte b1 = 0; b1 < vector2.size(); b1++) {
        ContentTypeInstanceGroup contentTypeInstanceGroup = (ContentTypeInstanceGroup)vector2.elementAt(b1);
        vector4 = contentTypeInstanceGroup.getGroupVariants();
        this.mReport.startContentTypeGroupReport(contentTypeInstanceGroup);
        this.mReport.startListPageReport();
        this.mReport.addNewListPageLineReport();
        VariantGenerationManager variantGenerationManager = new VariantGenerationManager(null, hashtable2, this);
        variantGenerationManager.setListPage(contentTypeInstanceGroup.getGroupListPage());
        if (contentTypeInstanceGroup.isListPageGenerated()) {
          if (this.debug)
            System.out.println("  List page generation START "); 
          variantGenerationManager.setInstances(contentTypeInstanceGroup.getGroupContentTypeInstances());
          variantGenerationManager.loadTemplate(contentTypeInstanceGroup.getGroupListPage().getListPageTemplate(), true);
          variantGenerationManager.generateListPage();
          if (this.debug)
            System.out.println("  List Page generation END "); 
        } else {
          variantGenerationManager.deleteListPage();
          this.mReport.updateLine("File not generated", " ");
        } 
        this.mReport.startContentItemReport();
        for (byte b2 = 0; b2 < vector4.size(); b2++) {
          Variant variant = (Variant)vector4.elementAt(b2);
          System.out.println("************   GENERATION START FOR GROUP [" + contentTypeInstanceGroup.getGroupName() + "]  *****************");
          if (this.debug)
            System.out.println("  VariantID = [" + variant.getVariantID() + "]"); 
          this.mReport.addSpacerLine();
          if (this.debug)
            System.out.println("  Generation of content pages START "); 
          VariantGenerationManager variantGenerationManager1 = new VariantGenerationManager(variant, hashtable2, this);
          variantGenerationManager1.setInstances(contentTypeInstanceGroup.getGroupContentTypeInstances());
          variantGenerationManager1.setContentType(contentType);
          variantGenerationManager1.setSingletonFlag(contentTypeInstanceGroup.isSingleton());
          if (contentTypeInstanceGroup.isInstanceGenerationEnabled() && variant.isEnabledForGeneration()) {
            variantGenerationManager1.loadTemplate(variant.getVariantTemplate(), false);
            variantGenerationManager1.generate();
          } else {
            this.mReport.noInstanceFileGeneration();
            variantGenerationManager1.deleteInstanceFiles();
          } 
          if (this.debug)
            System.out.println("  Generation of content pages END  "); 
        } 
        this.mReport.addSpacerLine();
      } 
    } 
    this.mReport.addSpacerLine();
    this.mReport.endReport();
  }
  
  public Report getReport() { return this.mReport; }
  
  public String getReportString() { return this.mReport.getHTMLReportString(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\Generator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */