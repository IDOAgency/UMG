package com.techempower.gemini.fornax;

import java.util.Vector;

public class DeltaTemplateFieldManager {
  protected boolean debug;
  
  protected ContentTypeInstanceGroup mGroup;
  
  protected ContentTypeInstance mCurrentInstance;
  
  public DeltaTemplateFieldManager(ContentTypeInstanceGroup paramContentTypeInstanceGroup, ContentTypeInstance paramContentTypeInstance) {
    this.debug = false;
    this.mGroup = paramContentTypeInstanceGroup;
    this.mCurrentInstance = paramContentTypeInstance;
  }
  
  public ContentTypeInstance getDeltaInstance(String paramString) {
    Vector vector2 = new Vector();
    ContentTypeInstance contentTypeInstance = null;
    int i = 0;
    int j = Integer.parseInt(paramString);
    Vector vector1 = this.mGroup.getGroupContentTypeInstances();
    for (byte b = 0; b < vector1.size(); b++) {
      ContentTypeInstance contentTypeInstance1 = (ContentTypeInstance)vector1.elementAt(b);
      if (!contentTypeInstance1.isDisabled() && !contentTypeInstance1.isQueuedForDeletion()) {
        if (this.mCurrentInstance.equals(contentTypeInstance1))
          i = b; 
        vector2.addElement(contentTypeInstance1);
      } 
    } 
    int k = i + j;
    try {
      contentTypeInstance = (ContentTypeInstance)vector2.elementAt(k);
    } catch (Exception exception) {
      contentTypeInstance = null;
    } 
    return contentTypeInstance;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\DeltaTemplateFieldManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */