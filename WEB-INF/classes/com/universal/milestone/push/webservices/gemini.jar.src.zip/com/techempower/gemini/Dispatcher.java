/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.ServletException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Dispatcher
/*     */   implements GeminiConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "disp";
/*     */   public static final int REDISPATCH_LIMIT = 5;
/*     */   public static final String INTERNAL_ERROR_PAGE = "internal-error-handler";
/*     */   protected GeminiApplication application;
/*     */   protected Vector dispatchHandlers;
/*     */   protected Handler defaultHandler;
/*     */   protected ComponentLog log;
/*     */   
/*     */   public Dispatcher(GeminiApplication paramGeminiApplication) {
/*  66 */     this.dispatchHandlers = new Vector();
/*  67 */     this.defaultHandler = new BasicHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     this.application = paramGeminiApplication;
/*  87 */     this.log = paramGeminiApplication.getLog("disp");
/*  88 */     installHandlers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void installHandlers() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   protected void setDefaultHandler(Handler paramHandler) { this.defaultHandler = paramHandler; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getHandlerDescriptions() {
/* 127 */     String[] arrayOfString = new String[this.dispatchHandlers.size()];
/*     */ 
/*     */     
/* 130 */     for (byte b = 0; b < arrayOfString.length; b++) {
/*     */       
/* 132 */       Handler handler = (Handler)this.dispatchHandlers.elementAt(b);
/* 133 */       if (handler == null) {
/* 134 */         this.log.debug("Handler " + b + " is null!");
/*     */       } else {
/* 136 */         arrayOfString[b] = handler.getDescription();
/*     */       } 
/*     */     } 
/* 139 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void displayHandlerDescriptions() {
/* 147 */     String[] arrayOfString = getHandlerDescriptions();
/* 148 */     for (byte b = 0; b < arrayOfString.length; b++)
/*     */     {
/* 150 */       this.log.debug(String.valueOf(b) + ": " + arrayOfString[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dispatch(Context paramContext) {
/* 170 */     if (paramContext != null) {
/*     */ 
/*     */       
/* 173 */       String str = paramContext.getCommand();
/* 174 */       if (str == null) {
/* 175 */         str = paramContext.gatherCommand();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 182 */         if (str != null) {
/*     */           
/* 184 */           this.log.debug(String.valueOf(paramContext.getClientIP()) + "; dispatching: " + str);
/*     */           
/* 186 */           for (byte b = 0; b < this.dispatchHandlers.size(); b++) {
/*     */             
/* 188 */             Handler handler = (Handler)this.dispatchHandlers.elementAt(b);
/*     */ 
/*     */             
/* 191 */             if (handler.acceptRequest(this, paramContext, str))
/*     */             {
/* 193 */               return true;
/*     */             }
/*     */           } 
/*     */           
/* 197 */           this.log.debug("No handler for: " + str);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 202 */           this.log.debug(String.valueOf(paramContext.getClientIP()) + "; dispatching with no command specified.");
/*     */         } 
/*     */ 
/*     */         
/* 206 */         if (str == null)
/* 207 */           str = getDefaultCommand(); 
/* 208 */         if (this.defaultHandler.handleRequest(this, paramContext, str)) {
/* 209 */           return true;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 214 */         this.log.log("Default handler's handleRequest method returned false!");
/* 215 */         return false;
/*     */       
/*     */       }
/* 218 */       catch (Exception exception) {
/*     */ 
/*     */ 
/*     */         
/* 222 */         handleException(paramContext, exception);
/*     */ 
/*     */         
/* 225 */         return false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     this.log.log("Error: dispatch() called with a null Context.");
/* 233 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean redispatch(Context paramContext, String paramString) {
/* 277 */     paramContext.incrementDispatches();
/* 278 */     int i = paramContext.getDispatches();
/*     */     
/* 280 */     this.log.debug("Redispatching: " + paramString + " (" + i + ")");
/*     */     
/* 282 */     if (i <= 5) {
/*     */       
/* 284 */       paramContext.setCommand(paramString);
/*     */     }
/*     */     else {
/*     */       
/* 288 */       this.log.log("Dispatcher redispatched " + i + " times.");
/* 289 */       this.log.log("This is likely the cause of a dispatch loop; redirecting to home.");
/* 290 */       paramContext.setCommand(getRedispatchLimitCommand());
/*     */     } 
/*     */     
/* 293 */     return dispatch(paramContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 307 */   public String getCommandParameterName() { return "cmd"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 322 */   public String getDefaultCommand() { return "home"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 330 */   public Vector getDispatchHandlers() { return this.dispatchHandlers; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 349 */   protected String getErrorHandlerPage() { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 368 */   public String getRedispatchLimitCommand() { return "home"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleException(Context paramContext, Exception paramException) {
/* 379 */     if (paramException instanceof ServletException) {
/*     */       
/* 381 */       ServletException servletException = (ServletException)paramException;
/* 382 */       this.log.log("InfrastructureServlet caught exception:\n" + servletException.getRootCause());
/*     */     }
/*     */     else {
/*     */       
/* 386 */       this.log.log("InfrastructureServlet caught exception:\n" + paramException);
/*     */     } 
/*     */     
/* 389 */     String str = getErrorHandlerPage();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 395 */     if (!paramContext.getReferencedJSP().equals(str) && 
/* 396 */       !paramContext.getReferencedJSP().equals("internal-error-handler")) {
/*     */ 
/*     */ 
/*     */       
/* 400 */       if (str != null)
/*     */       {
/* 402 */         paramContext.putDelivery("Exception", paramException);
/* 403 */         paramContext.setReferencedJSP(str);
/* 404 */         paramContext.includeJSP(str);
/*     */       
/*     */       }
/*     */       else
/*     */       {
/*     */         
/* 410 */         paramContext.setReferencedJSP("internal-error-handler");
/* 411 */         paramContext.print("<html>");
/* 412 */         paramContext.print("<head><title>Internal error</title></head>");
/* 413 */         paramContext.print("<body bgcolor=white text=black>");
/* 414 */         paramContext.print("<p><font face='Arial, Helvetica' size='4'><b>Internal error</b></font></p>");
/* 415 */         paramContext.print("<p><font face='Arial, Helvetica' size='2'>An exception was caught by InfrastructureServlet / InfrastructureJSP:</font></p>");
/* 416 */         paramContext.print("<p><pre><font size=-1>");
/* 417 */         paramContext.printException(paramException);
/* 418 */         paramContext.print("");
/* 419 */         paramContext.print("</font></pre></p>");
/* 420 */         if (paramException instanceof ServletException) {
/*     */           
/* 422 */           ServletException servletException = (ServletException)paramException;
/* 423 */           paramContext.print("<p><font face='Arial, Helvetica' size='2'>Root cause:</font></p>");
/* 424 */           paramContext.print("<p><pre><font size=-1>");
/* 425 */           paramContext.printException(servletException.getRootCause());
/* 426 */           paramContext.print("");
/* 427 */           paramContext.print("</font></pre></p>");
/*     */         } 
/* 429 */         paramContext.print("</body>");
/* 430 */         paramContext.print("</html>");
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 435 */       this.log.log("Exception received from error handler.  Not processing.");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\Dispatcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */