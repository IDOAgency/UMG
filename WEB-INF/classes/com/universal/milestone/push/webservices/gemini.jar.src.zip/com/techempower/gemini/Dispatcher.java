package com.techempower.gemini;

import com.techempower.ComponentLog;
import java.util.Vector;
import javax.servlet.ServletException;

public class Dispatcher implements GeminiConstants {
  public static final String COMPONENT_CODE = "disp";
  
  public static final int REDISPATCH_LIMIT = 5;
  
  public static final String INTERNAL_ERROR_PAGE = "internal-error-handler";
  
  protected GeminiApplication application;
  
  protected Vector dispatchHandlers;
  
  protected Handler defaultHandler;
  
  protected ComponentLog log;
  
  public Dispatcher(GeminiApplication paramGeminiApplication) {
    this.dispatchHandlers = new Vector();
    this.defaultHandler = new BasicHandler();
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("disp");
    installHandlers();
  }
  
  protected void installHandlers() {}
  
  protected void setDefaultHandler(Handler paramHandler) { this.defaultHandler = paramHandler; }
  
  public String[] getHandlerDescriptions() {
    String[] arrayOfString = new String[this.dispatchHandlers.size()];
    for (byte b = 0; b < arrayOfString.length; b++) {
      Handler handler = (Handler)this.dispatchHandlers.elementAt(b);
      if (handler == null) {
        this.log.debug("Handler " + b + " is null!");
      } else {
        arrayOfString[b] = handler.getDescription();
      } 
    } 
    return arrayOfString;
  }
  
  public void displayHandlerDescriptions() {
    String[] arrayOfString = getHandlerDescriptions();
    for (byte b = 0; b < arrayOfString.length; b++)
      this.log.debug(String.valueOf(b) + ": " + arrayOfString[b]); 
  }
  
  public boolean dispatch(Context paramContext) {
    if (paramContext != null) {
      String str = paramContext.getCommand();
      if (str == null)
        str = paramContext.gatherCommand(); 
      try {
        if (str != null) {
          this.log.debug(String.valueOf(paramContext.getClientIP()) + "; dispatching: " + str);
          for (byte b = 0; b < this.dispatchHandlers.size(); b++) {
            Handler handler = (Handler)this.dispatchHandlers.elementAt(b);
            if (handler.acceptRequest(this, paramContext, str))
              return true; 
          } 
          this.log.debug("No handler for: " + str);
        } else {
          this.log.debug(String.valueOf(paramContext.getClientIP()) + "; dispatching with no command specified.");
        } 
        if (str == null)
          str = getDefaultCommand(); 
        if (this.defaultHandler.handleRequest(this, paramContext, str))
          return true; 
        this.log.log("Default handler's handleRequest method returned false!");
        return false;
      } catch (Exception exception) {
        handleException(paramContext, exception);
        return false;
      } 
    } 
    this.log.log("Error: dispatch() called with a null Context.");
    return false;
  }
  
  public boolean redispatch(Context paramContext, String paramString) {
    paramContext.incrementDispatches();
    int i = paramContext.getDispatches();
    this.log.debug("Redispatching: " + paramString + " (" + i + ")");
    if (i <= 5) {
      paramContext.setCommand(paramString);
    } else {
      this.log.log("Dispatcher redispatched " + i + " times.");
      this.log.log("This is likely the cause of a dispatch loop; redirecting to home.");
      paramContext.setCommand(getRedispatchLimitCommand());
    } 
    return dispatch(paramContext);
  }
  
  public String getCommandParameterName() { return "cmd"; }
  
  public String getDefaultCommand() { return "home"; }
  
  public Vector getDispatchHandlers() { return this.dispatchHandlers; }
  
  protected String getErrorHandlerPage() { return null; }
  
  public String getRedispatchLimitCommand() { return "home"; }
  
  public void handleException(Context paramContext, Exception paramException) {
    if (paramException instanceof ServletException) {
      ServletException servletException = (ServletException)paramException;
      this.log.log("InfrastructureServlet caught exception:\n" + servletException.getRootCause());
    } else {
      this.log.log("InfrastructureServlet caught exception:\n" + paramException);
    } 
    String str = getErrorHandlerPage();
    if (!paramContext.getReferencedJSP().equals(str) && 
      !paramContext.getReferencedJSP().equals("internal-error-handler")) {
      if (str != null) {
        paramContext.putDelivery("Exception", paramException);
        paramContext.setReferencedJSP(str);
        paramContext.includeJSP(str);
      } else {
        paramContext.setReferencedJSP("internal-error-handler");
        paramContext.print("<html>");
        paramContext.print("<head><title>Internal error</title></head>");
        paramContext.print("<body bgcolor=white text=black>");
        paramContext.print("<p><font face='Arial, Helvetica' size='4'><b>Internal error</b></font></p>");
        paramContext.print("<p><font face='Arial, Helvetica' size='2'>An exception was caught by InfrastructureServlet / InfrastructureJSP:</font></p>");
        paramContext.print("<p><pre><font size=-1>");
        paramContext.printException(paramException);
        paramContext.print("");
        paramContext.print("</font></pre></p>");
        if (paramException instanceof ServletException) {
          ServletException servletException = (ServletException)paramException;
          paramContext.print("<p><font face='Arial, Helvetica' size='2'>Root cause:</font></p>");
          paramContext.print("<p><pre><font size=-1>");
          paramContext.printException(servletException.getRootCause());
          paramContext.print("");
          paramContext.print("</font></pre></p>");
        } 
        paramContext.print("</body>");
        paramContext.print("</html>");
      } 
    } else {
      this.log.log("Exception received from error handler.  Not processing.");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\Dispatcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */