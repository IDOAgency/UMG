/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.Version;
/*     */ import java.io.IOException;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InfrastructureServlet
/*     */   extends HttpServlet
/*     */   implements GeminiConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "svlt";
/*  83 */   protected GeminiApplication application = getApplication();
/*  84 */   protected ComponentLog log = this.application.getLog("svlt");
/*  85 */   protected Version version = this.application.getVersion();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  98 */     displayBanner();
/*  99 */     this.log.debug("Starting up.");
/* 100 */     configure();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public GeminiApplication getApplication() { return GeminiApplication.getInstance(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public void configure() { this.application.getConfigurator().configureIfNecessary(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public void destroy() { super.destroy(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
/* 142 */     Context context = this.application.getContext(paramHttpServletRequest, paramHttpServletResponse, 
/* 143 */         getServletContext());
/*     */     
/* 145 */     handleRequest(context, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
/* 154 */     Context context = this.application.getContext(paramHttpServletRequest, paramHttpServletResponse, 
/* 155 */         getServletContext());
/*     */     
/* 157 */     handleRequest(context, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleRequest(Context paramContext, boolean paramBoolean) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   public String getServletName() { return String.valueOf(this.version.getProductName()) + " Servlet version " + this.version.getVersionString(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServletInfo() {
/* 189 */     return String.valueOf(getServletName()) + 
/* 190 */       " - Copyright (c) " + this.version.getCopyrightYears() + 
/* 191 */       " " + this.version.getClientName() + 
/* 192 */       " - developed by " + this.version.getDeveloperName() + ".";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   protected void displayBanner() { this.log.debug(getServletName()); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\InfrastructureServlet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */