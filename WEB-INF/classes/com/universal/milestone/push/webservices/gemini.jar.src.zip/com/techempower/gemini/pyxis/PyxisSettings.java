package com.techempower.gemini.pyxis;

import com.techempower.BasicConnectorFactory;
import com.techempower.EnhancedProperties;
import com.techempower.gemini.BasicServiceSettings;
import com.techempower.gemini.GeminiApplication;

public class PyxisSettings extends BasicServiceSettings implements PyxisConstants {
  public static final int DEFAULT_PASSWORD_SIZE = 8;
  
  protected int randomPasswordLength = 8;
  
  protected String usersTable = "pxUsers";
  
  protected String groupsTable = "pxGroups";
  
  protected String usersToGroupsTable = "pxMapUsersToGroups";
  
  public PyxisSettings(GeminiApplication paramGeminiApplication) { super(paramGeminiApplication); }
  
  public void customConfigure(EnhancedProperties paramEnhancedProperties) {
    this.randomPasswordLength = paramEnhancedProperties.getIntegerProperty("Pyxis.RandomPasswordLength", this.randomPasswordLength);
    this.usersTable = paramEnhancedProperties.getProperty("Pyxis.UsersTable", this.usersTable);
    this.groupsTable = paramEnhancedProperties.getProperty("Pyxis.GroupsTable", this.groupsTable);
    this.usersToGroupsTable = paramEnhancedProperties.getProperty("Pyxis.UsersToGroupsTable", this.usersToGroupsTable);
    this.connectorFactory = new BasicConnectorFactory("Pyxis.");
    this.connectorFactory.configure(paramEnhancedProperties, this.application);
  }
  
  public int getRandomPasswordLength() { return this.randomPasswordLength; }
  
  public String getUsersTable() { return this.usersTable; }
  
  public String getGroupsTable() { return this.groupsTable; }
  
  public String getUsersToGroupsTable() { return this.usersToGroupsTable; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\pyxis\PyxisSettings.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */