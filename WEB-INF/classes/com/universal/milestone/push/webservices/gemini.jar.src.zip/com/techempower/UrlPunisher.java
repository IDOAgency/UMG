/*     */ package com.techempower;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UrlPunisher
/*     */   implements Runnable
/*     */ {
/*     */   protected String url;
/*     */   protected int id;
/*     */   protected boolean stillNeeded;
/*  45 */   protected static String correctResponse = null;
/*     */   
/*  47 */   protected static Random random = new Random();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlPunisher(String paramString, int paramInt) {
/*     */     this.id = 0;
/*     */     this.stillNeeded = true;
/*  58 */     this.url = paramString;
/*  59 */     this.id = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  68 */     byte[] arrayOfByte = new byte[4000];
/*     */     
/*  70 */     while (isStillNeeded()) {
/*     */       
/*  72 */       String str = "";
/*     */ 
/*     */       
/*     */       try {
/*  76 */         long l = System.currentTimeMillis();
/*     */         
/*  78 */         URL uRL = new URL(this.url);
/*  79 */         URLConnection uRLConnection = uRL.openConnection();
/*  80 */         uRLConnection.setUseCaches(false);
/*  81 */         uRLConnection.setDoInput(true);
/*  82 */         InputStream inputStream = uRLConnection.getInputStream();
/*     */         
/*  84 */         int i = 0;
/*  85 */         while (!i) {
/*     */           
/*  87 */           Thread.yield();
/*     */           
/*  89 */           i = inputStream.read(arrayOfByte, 0, 4000);
/*     */           
/*  91 */           if (i > 0) {
/*     */             
/*  93 */             String str1 = new String(arrayOfByte, 0, i);
/*  94 */             str = String.valueOf(str) + str1;
/*     */           } 
/*     */         } 
/*     */         
/*  98 */         if (correctResponse == null) {
/*     */           
/* 100 */           correctResponse = str;
/*     */ 
/*     */         
/*     */         }
/* 104 */         else if (correctResponse.equals(str)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 110 */           long l1 = System.currentTimeMillis() - l;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 115 */         inputStream.close();
/*     */       }
/* 117 */       catch (MalformedURLException malformedURLException) {
/*     */ 
/*     */       
/*     */       }
/* 121 */       catch (IOException iOException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 128 */         Thread.sleep(random.nextInt(60000));
/*     */       }
/* 130 */       catch (InterruptedException interruptedException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public boolean isStillNeeded() { return this.stillNeeded; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public void setStillNeeded(boolean paramBoolean) { this.stillNeeded = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 158 */     String str = "http://tiamat.techempower.com/tempest/?cmd=user-articles";
/* 159 */     if (paramArrayOfString.length == 1)
/*     */     {
/* 161 */       str = paramArrayOfString[0];
/*     */     }
/*     */     
/* 164 */     for (byte b = 0; b < 'È'; b++) {
/*     */       
/* 166 */       UrlPunisher urlPunisher = new UrlPunisher(str, b);
/* 167 */       Thread thread = new Thread(urlPunisher);
/* 168 */       thread.start();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\UrlPunisher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */