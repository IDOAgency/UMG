/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.HttpJspPage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InfrastructureJSP
/*     */   implements HttpJspPage, GeminiConstants
/*     */ {
/*     */   private ServletConfig config;
/*     */   
/*     */   public final void init(ServletConfig paramServletConfig) throws ServletException {
/*  83 */     this.config = paramServletConfig;
/*  84 */     jspInit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void jspInit() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public final ServletConfig getServletConfig() { return this.config; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public String getServletInfo() { return "Infrastructure JSP"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public final void destroy() { jspDestroy(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void jspDestroy() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public GeminiApplication getApplication() { return GeminiApplication.getInstance(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void service(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws ServletException, IOException {
/*     */     GeminiApplication geminiApplication;
/* 147 */     HttpServletRequest httpServletRequest = (HttpServletRequest)paramServletRequest;
/* 148 */     HttpServletResponse httpServletResponse = (HttpServletResponse)paramServletResponse;
/*     */ 
/*     */ 
/*     */     
/* 152 */     Context context = (Context)httpServletRequest.getAttribute("Context");
/*     */ 
/*     */     
/* 155 */     if (context != null) {
/*     */ 
/*     */       
/* 158 */       geminiApplication = context.getApplication();
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 163 */       geminiApplication = getApplication();
/*     */     } 
/*     */ 
/*     */     
/* 167 */     Configurator configurator = geminiApplication.getConfigurator();
/* 168 */     if (!configurator.isConfigured()) {
/* 169 */       configurator.configure();
/*     */     }
/* 171 */     if (geminiApplication.getInfrastructure().canInvokeJSPsDirectly() == false && context == null) {
/*     */       
/* 173 */       httpServletResponse.sendRedirect(geminiApplication.getInfrastructure().getServletCmdURL("home"));
/*     */     } else {
/*     */       Dispatcher dispatcher;
/*     */ 
/*     */ 
/*     */       
/* 179 */       if (context == null) {
/*     */ 
/*     */         
/* 182 */         dispatcher = geminiApplication.getDispatcher();
/* 183 */         context = geminiApplication.getContext(httpServletRequest, httpServletResponse, 
/* 184 */             getServletConfig().getServletContext());
/* 185 */         httpServletRequest.setAttribute("Context", context);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 190 */         dispatcher = context.getDispatcher();
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 195 */         _jspService(httpServletRequest, httpServletResponse);
/*     */       }
/* 197 */       catch (Exception exception) {
/*     */ 
/*     */         
/* 200 */         dispatcher.handleException(context, exception);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract void _jspService(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\InfrastructureJSP.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */