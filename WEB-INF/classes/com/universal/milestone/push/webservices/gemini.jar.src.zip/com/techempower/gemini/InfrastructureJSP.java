package com.techempower.gemini;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.HttpJspPage;

public abstract class InfrastructureJSP implements HttpJspPage, GeminiConstants {
  private ServletConfig config;
  
  public final void init(ServletConfig paramServletConfig) throws ServletException {
    this.config = paramServletConfig;
    jspInit();
  }
  
  public void jspInit() {}
  
  public final ServletConfig getServletConfig() { return this.config; }
  
  public String getServletInfo() { return "Infrastructure JSP"; }
  
  public final void destroy() { jspDestroy(); }
  
  public void jspDestroy() {}
  
  public GeminiApplication getApplication() { return GeminiApplication.getInstance(); }
  
  public final void service(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws ServletException, IOException {
    GeminiApplication geminiApplication;
    HttpServletRequest httpServletRequest = (HttpServletRequest)paramServletRequest;
    HttpServletResponse httpServletResponse = (HttpServletResponse)paramServletResponse;
    Context context = (Context)httpServletRequest.getAttribute("Context");
    if (context != null) {
      geminiApplication = context.getApplication();
    } else {
      geminiApplication = getApplication();
    } 
    Configurator configurator = geminiApplication.getConfigurator();
    if (!configurator.isConfigured())
      configurator.configure(); 
    if (geminiApplication.getInfrastructure().canInvokeJSPsDirectly() == false && context == null) {
      httpServletResponse.sendRedirect(geminiApplication.getInfrastructure().getServletCmdURL("home"));
    } else {
      Dispatcher dispatcher;
      if (context == null) {
        dispatcher = geminiApplication.getDispatcher();
        context = geminiApplication.getContext(httpServletRequest, httpServletResponse, 
            getServletConfig().getServletContext());
        httpServletRequest.setAttribute("Context", context);
      } else {
        dispatcher = context.getDispatcher();
      } 
      try {
        _jspService(httpServletRequest, httpServletResponse);
      } catch (Exception exception) {
        dispatcher.handleException(context, exception);
      } 
    } 
  }
  
  public abstract void _jspService(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\InfrastructureJSP.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */