package com.techempower.gemini;

import com.techempower.ComponentLog;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

public class FormValidation {
  public static final String COMPONENT_CODE = "fval";
  
  protected ComponentLog log;
  
  protected boolean errors;
  
  protected Form form;
  
  protected Vector validations;
  
  protected Vector valErrors;
  
  protected Vector valElements;
  
  protected Vector valInstructions;
  
  protected Hashtable inlineInstructions;
  
  public FormValidation(Form paramForm) {
    this.errors = false;
    this.form = paramForm;
    this.log = paramForm.getApplication().getLog("fval");
  }
  
  public void processForm() {
    this.validations = new Vector();
    this.valErrors = new Vector();
    this.valInstructions = new Vector();
    this.valElements = new Vector();
    this.inlineInstructions = new Hashtable();
    this.errors = false;
    Iterator iterator = this.form.getElements();
    while (iterator.hasNext()) {
      FormElement formElement = (FormElement)iterator.next();
      FormSingleValidation formSingleValidation = formElement.validate();
      if (formSingleValidation != null && formSingleValidation.isError) {
        this.errors = true;
        this.validations.addElement(formSingleValidation);
        if (formSingleValidation.error != null)
          this.valErrors.addElement(formSingleValidation.error); 
        if (formSingleValidation.element != null)
          this.valElements.addElement(formSingleValidation.element); 
        if (formSingleValidation.instruction != null)
          this.valInstructions.addElement(formSingleValidation.instruction); 
        if (formSingleValidation.inline != null)
          this.inlineInstructions.put(formSingleValidation.element, formSingleValidation.inline); 
      } 
    } 
  }
  
  public void reprocessForm() { processForm(); }
  
  public Vector getValidations() { return this.validations; }
  
  public Vector getErrorStrings() { return this.valErrors; }
  
  public Vector getInstructions() { return this.valInstructions; }
  
  public Vector getErroredElements() { return this.valElements; }
  
  public Hashtable getInlineInstructions() { return this.inlineInstructions; }
  
  public String getInlineInstructions(FormElement paramFormElement) {
    String str = (String)this.inlineInstructions.get(paramFormElement);
    if (str != null)
      return str; 
    return "";
  }
  
  public boolean isErrored(FormElement paramFormElement) { return getErroredElements().contains(paramFormElement); }
  
  public boolean hasErrors() { return this.errors; }
  
  public boolean isGood() { return hasErrors() ^ true; }
  
  public Form getForm() { return this.form; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormValidation.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */