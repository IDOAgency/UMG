/*     */ package com.techempower;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface UtilityConstants
/*     */ {
/*  38 */   public static final String[] DAYS_OF_WEEK = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", 
/*  39 */       "Saturday" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final String[] DAYS_ABBREVIATED = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String[] MONTH_NAMES = { 
/*  53 */       "January", "February", "March", "April", "May", "June", "July", 
/*  54 */       "August", "September", "October", "November", "December" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String[] MONTH_NAMES_ABBREVIATED = { 
/*  61 */       "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", 
/*  62 */       "Nov", "Dec" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int[] MONTH_DAYS = { 
/*  70 */       31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String[] PERMITTED_DATE_FORMATS = { 
/*  81 */       "MM-dd-yyyy hh:mm:ss.SSS", 
/*  82 */       "MM-dd-yyyy hh:mm:ss.SSS a", 
/*  83 */       "MM-dd-yyyy hh:mm:ss.SSSa", 
/*  84 */       "MM-dd-yyyy hh:mm:ss a", 
/*  85 */       "MM-dd-yyyy hh:mm:ssa", 
/*  86 */       "MM-dd-yyyy hh:mm a", 
/*  87 */       "MM-dd-yyyy hh:mma", 
/*  88 */       "MM-dd-yyyy", 
/*     */       
/*  90 */       "MM/dd/yyyy hh:mm:ss.SSS", 
/*  91 */       "MM/dd/yyyy hh:mm:ss.SSS a", 
/*  92 */       "MM/dd/yyyy hh:mm:ss.SSSa", 
/*  93 */       "MM/dd/yyyy hh:mm:ss a", 
/*  94 */       "MM/dd/yyyy hh:mm:ssa", 
/*  95 */       "MM/dd/yyyy hh:mm a", 
/*  96 */       "MM/dd/yyyy hh:mma", 
/*  97 */       "MM/dd/yyyy", 
/*     */       
/*  99 */       "MMM d yyyy hh:mm:ss.SSS", 
/* 100 */       "MMM d yyyy hh:mm:ss.SSS a", 
/* 101 */       "MMM d yyyy hh:mm:ss.SSSa", 
/* 102 */       "MMM d yyyy hh:mm:ss a", 
/* 103 */       "MMM d yyyy hh:mm:ssa", 
/* 104 */       "MMM d yyyy hh:mm a", 
/* 105 */       "MMM d yyyy hh:mma", 
/* 106 */       "MMM d yyyy", 
/*     */       
/* 108 */       "MMM. d yyyy hh:mm:ss.SSS", 
/* 109 */       "MMM. d yyyy hh:mm:ss.SSS a", 
/* 110 */       "MMM. d yyyy hh:mm:ss.SSSa", 
/* 111 */       "MMM. d yyyy hh:mm:ss a", 
/* 112 */       "MMM. d yyyy hh:mm:ssa", 
/* 113 */       "MMM. d yyyy hh:mm a", 
/* 114 */       "MMM. d yyyy hh:mma", 
/* 115 */       "MMM. d yyyy", 
/*     */       
/* 117 */       "MMM. d, yyyy hh:mm:ss.SSS", 
/* 118 */       "MMM. d, yyyy hh:mm:ss.SSS a", 
/* 119 */       "MMM. d, yyyy hh:mm:ss.SSSa", 
/* 120 */       "MMM. d, yyyy hh:mm:ss a", 
/* 121 */       "MMM. d, yyyy hh:mm:ssa", 
/* 122 */       "MMM. d, yyyy hh:mm a", 
/* 123 */       "MMM. d, yyyy hh:mma", 
/* 124 */       "MMM. d, yyyy",
/*     */       
/* 126 */       "MMM d, yyyy hh:mm:ss.SSS", 
/* 127 */       "MMM d, yyyy hh:mm:ss.SSS a", 
/* 128 */       "MMM d, yyyy hh:mm:ss.SSSa", 
/* 129 */       "MMM d, yyyy hh:mm:ss a", 
/* 130 */       "MMM d, yyyy hh:mm:ssa", 
/* 131 */       "MMM d, yyyy hh:mm a", 
/* 132 */       "MMM d, yyyy hh:mma", 
/* 133 */       "MMM d, yyyy" };
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\UtilityConstants.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */