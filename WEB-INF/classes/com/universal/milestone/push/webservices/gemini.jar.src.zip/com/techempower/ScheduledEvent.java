package com.techempower;

public class ScheduledEvent {
  public static String COMPONENT_CODE = "sevt";
  
  protected long scheduledTime = 0L;
  
  protected boolean executing = false;
  
  public ScheduledEvent() {
    SimpleDate simpleDate = new SimpleDate();
    setScheduledTime(simpleDate);
  }
  
  public long getDefaultScheduledTime() { return getScheduledTime(); }
  
  public long getScheduledTime() { return this.scheduledTime; }
  
  public void setScheduledTime(SimpleDate paramSimpleDate) { this.scheduledTime = paramSimpleDate.getAsLong(); }
  
  public boolean requiresOwnThread() { return false; }
  
  public void setExecuting(boolean paramBoolean) { this.executing = paramBoolean; }
  
  public boolean isExecuting() { return this.executing; }
  
  public void execute(Scheduler paramScheduler) { paramScheduler.removeEvent(this); }
  
  public String toString() { return "[Event: " + this.scheduledTime + "]"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\ScheduledEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */