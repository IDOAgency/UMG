/*     */ package com.techempower;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScheduledEvent
/*     */ {
/*  34 */   public static String COMPONENT_CODE = "sevt";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   protected long scheduledTime = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean executing = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledEvent() {
/*  52 */     SimpleDate simpleDate = new SimpleDate();
/*  53 */     setScheduledTime(simpleDate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public long getDefaultScheduledTime() { return getScheduledTime(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public long getScheduledTime() { return this.scheduledTime; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public void setScheduledTime(SimpleDate paramSimpleDate) { this.scheduledTime = paramSimpleDate.getAsLong(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public boolean requiresOwnThread() { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void setExecuting(boolean paramBoolean) { this.executing = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public boolean isExecuting() { return this.executing; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public void execute(Scheduler paramScheduler) { paramScheduler.removeEvent(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   public String toString() { return "[Event: " + this.scheduledTime + "]"; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\ScheduledEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */