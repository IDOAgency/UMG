package com.techempower.gemini;

import com.techempower.BasicHelper;

public class GeminiHelper extends BasicHelper implements GeminiConstants {
  public static int getBrowserType(Context paramContext) {
    String str = paramContext.getHeader("User-Agent");
    if (str != null) {
      str = str.toLowerCase();
      for (byte b = 0; b < GeminiConstants.BROWSER_TYPE_CHECK_ORDER.length; b++) {
        if (str.indexOf(GeminiConstants.BROWSER_USER_AGENT_IDS[GeminiConstants.BROWSER_TYPE_CHECK_ORDER[b]]) != -1)
          return GeminiConstants.BROWSER_TYPE_CHECK_ORDER[b]; 
      } 
    } 
    return -1;
  }
  
  public static String getBrowserTypeName(int paramInt) {
    if (paramInt >= 0 && paramInt < GeminiConstants.BROWSER_NAMES.length)
      return GeminiConstants.BROWSER_NAMES[paramInt]; 
    return new String("");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\GeminiHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */