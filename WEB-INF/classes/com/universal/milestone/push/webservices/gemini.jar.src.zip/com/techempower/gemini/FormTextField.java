package com.techempower.gemini;

import com.techempower.BasicHelper;

public class FormTextField extends FormElement {
  public static final int DEFAULT_LENGTH = 20;
  
  public static final String DEFAULT_VALUE = "";
  
  protected String value;
  
  protected String startingValue;
  
  protected int length;
  
  protected int maxLength;
  
  public FormTextField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2) {
    super(paramString1, paramString2, paramBoolean);
    setLength(paramInt1);
    setMaxLength(paramInt2);
  }
  
  public FormTextField(String paramString1, String paramString2, boolean paramBoolean, int paramInt) { this(paramString1, paramString2, paramBoolean, paramInt, paramInt); }
  
  public FormTextField(String paramString, boolean paramBoolean, int paramInt) { this(paramString, "", paramBoolean, paramInt); }
  
  public FormTextField(String paramString, int paramInt) { this(paramString, "", false, paramInt); }
  
  public FormTextField(String paramString) { this(paramString, "", false, 20); }
  
  public void setLength(int paramInt) { this.length = paramInt; }
  
  public int getLength() { return this.length; }
  
  public void setValue(String paramString) {
    if (!isReadOnly())
      this.value = paramString; 
  }
  
  public void setStartingValue(String paramString) { this.startingValue = paramString; }
  
  public String getStartingValue() { return this.startingValue; }
  
  public void setValue(Context paramContext) { setValue(paramContext.getRequestValue(getName(), this.value)); }
  
  protected String getValue() { return this.value; }
  
  public String getStringValue() { return getValue(); }
  
  public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
  
  public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
  
  public int getIntegerValue() { return 0; }
  
  public String render() {
    StringBuffer stringBuffer = new StringBuffer(60);
    stringBuffer.append("<input type=\"text\"");
    stringBuffer.append(getClassName());
    stringBuffer.append(" name=\"");
    stringBuffer.append(getName());
    stringBuffer.append("\" value=\"");
    stringBuffer.append(getRenderableValue());
    stringBuffer.append("\" size=\"");
    stringBuffer.append(getLength());
    stringBuffer.append("\" maxlength=\"");
    stringBuffer.append(getMaxLength());
    stringBuffer.append('"');
    stringBuffer.append(getTabIndex());
    stringBuffer.append(getFormEvents());
    stringBuffer.append(getEnabledString());
    stringBuffer.append(getReadOnlyString());
    stringBuffer.append(getId());
    stringBuffer.append('>');
    return stringBuffer.toString();
  }
  
  public FormSingleValidation validate() {
    FormSingleValidation formSingleValidation = new FormSingleValidation(this);
    if (isRequired())
      requiredValidation(formSingleValidation); 
    customValidation(formSingleValidation);
    return formSingleValidation;
  }
  
  protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
    if (getStringValue().length() == 0) {
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is empty.", 
          "Please provide input in the field named " + getDisplayName() + ".", 
          "Please provide input in this field.");
    } else if (getStringValue().length() > getMaxLength()) {
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is too long.", 
          "Please keep the input in field " + getDisplayName() + " to " + 
          getMaxLength() + " characters or less.", 
          "Please keep the input in this field to " + 
          getMaxLength() + " characters or less.");
    } 
  }
  
  public boolean isDefault() { return "".equals(getValue()); }
  
  public boolean isUnchanged() { return this.startingValue.equals(getValue()); }
  
  public int getMaxLength() { return this.maxLength; }
  
  public void setMaxLength(int paramInt) { this.maxLength = paramInt; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormTextField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */