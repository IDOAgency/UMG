/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.BasicHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormTextField
/*     */   extends FormElement
/*     */ {
/*     */   public static final int DEFAULT_LENGTH = 20;
/*     */   public static final String DEFAULT_VALUE = "";
/*     */   protected String value;
/*     */   protected String startingValue;
/*     */   protected int length;
/*     */   protected int maxLength;
/*     */   
/*     */   public FormTextField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2) {
/*  60 */     super(paramString1, paramString2, paramBoolean);
/*  61 */     setLength(paramInt1);
/*  62 */     setMaxLength(paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public FormTextField(String paramString1, String paramString2, boolean paramBoolean, int paramInt) { this(paramString1, paramString2, paramBoolean, paramInt, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public FormTextField(String paramString, boolean paramBoolean, int paramInt) { this(paramString, "", paramBoolean, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public FormTextField(String paramString, int paramInt) { this(paramString, "", false, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public FormTextField(String paramString) { this(paramString, "", false, 20); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public void setLength(int paramInt) { this.length = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public int getLength() { return this.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String paramString) {
/* 120 */     if (!isReadOnly()) {
/* 121 */       this.value = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public void setStartingValue(String paramString) { this.startingValue = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public String getStartingValue() { return this.startingValue; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 153 */   public void setValue(Context paramContext) { setValue(paramContext.getRequestValue(getName(), this.value)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   protected String getValue() { return this.value; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   public String getStringValue() { return getValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 200 */   public int getIntegerValue() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render() {
/* 208 */     StringBuffer stringBuffer = new StringBuffer(60);
/*     */     
/* 210 */     stringBuffer.append("<input type=\"text\"");
/* 211 */     stringBuffer.append(getClassName());
/* 212 */     stringBuffer.append(" name=\"");
/* 213 */     stringBuffer.append(getName());
/* 214 */     stringBuffer.append("\" value=\"");
/* 215 */     stringBuffer.append(getRenderableValue());
/* 216 */     stringBuffer.append("\" size=\"");
/* 217 */     stringBuffer.append(getLength());
/* 218 */     stringBuffer.append("\" maxlength=\"");
/* 219 */     stringBuffer.append(getMaxLength());
/* 220 */     stringBuffer.append('"');
/* 221 */     stringBuffer.append(getTabIndex());
/* 222 */     stringBuffer.append(getFormEvents());
/* 223 */     stringBuffer.append(getEnabledString());
/* 224 */     stringBuffer.append(getReadOnlyString());
/* 225 */     stringBuffer.append(getId());
/* 226 */     stringBuffer.append('>');
/*     */     
/* 228 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormSingleValidation validate() {
/* 236 */     FormSingleValidation formSingleValidation = new FormSingleValidation(this);
/*     */     
/* 238 */     if (isRequired())
/*     */     {
/*     */       
/* 241 */       requiredValidation(formSingleValidation);
/*     */     }
/*     */ 
/*     */     
/* 245 */     customValidation(formSingleValidation);
/*     */     
/* 247 */     return formSingleValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
/* 259 */     if (getStringValue().length() == 0) {
/*     */       
/* 261 */       paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is empty.", 
/* 262 */           "Please provide input in the field named " + getDisplayName() + ".", 
/* 263 */           "Please provide input in this field.");
/*     */     }
/* 265 */     else if (getStringValue().length() > getMaxLength()) {
/*     */       
/* 267 */       paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is too long.", 
/* 268 */           "Please keep the input in field " + getDisplayName() + " to " + 
/* 269 */           getMaxLength() + " characters or less.", 
/* 270 */           "Please keep the input in this field to " + 
/* 271 */           getMaxLength() + " characters or less.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 281 */   public boolean isDefault() { return "".equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 291 */   public boolean isUnchanged() { return this.startingValue.equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 299 */   public int getMaxLength() { return this.maxLength; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 307 */   public void setMaxLength(int paramInt) { this.maxLength = paramInt; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormTextField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */