/*     */ package com.techempower.gemini.pyxis;
/*     */ 
/*     */ import com.techempower.BoxedInt;
/*     */ import com.techempower.DataEntity;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicUser
/*     */   extends DataEntity
/*     */   implements PyxisConstants
/*     */ {
/*     */   protected int userID;
/*     */   protected String userUsername;
/*     */   private String userPassword;
/*     */   protected String userFirstname;
/*     */   protected String userLastname;
/*     */   private int[] userGroups;
/*     */   private boolean memberAdministrators;
/*     */   private boolean memberUsers;
/*     */   private boolean memberGuests;
/*     */   protected PyxisSettings settings;
/*     */   
/*     */   public BasicUser(PyxisSettings paramPyxisSettings) {
/*  44 */     this.userID = 0;
/*  45 */     this.userUsername = "";
/*  46 */     this.userPassword = "";
/*  47 */     this.userFirstname = "";
/*  48 */     this.userLastname = "";
/*  49 */     this.userGroups = new int[0];
/*     */ 
/*     */     
/*  52 */     this.memberAdministrators = false;
/*  53 */     this.memberUsers = false;
/*  54 */     this.memberGuests = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.settings = paramPyxisSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserGroups(int[] paramArrayOfInt) {
/*  79 */     this.userGroups = paramArrayOfInt;
/*     */     
/*  81 */     evaluateGroups();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserGroups(ArrayList paramArrayList) {
/*  90 */     this.userGroups = new int[paramArrayList.size()];
/*     */     
/*  92 */     for (byte b = 0; b < paramArrayList.size(); b++) {
/*     */       
/*  94 */       BoxedInt boxedInt = (BoxedInt)paramArrayList.get(b);
/*  95 */       this.userGroups[b] = boxedInt.get();
/*     */     } 
/*     */     
/*  98 */     evaluateGroups();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public void setUserID(int paramInt) { this.userID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public void setUserUsername(String paramString) { this.userUsername = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   public void setUserPassword(String paramString) { this.userPassword = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public void setUserFirstname(String paramString) { this.userFirstname = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public void setUserLastname(String paramString) { this.userLastname = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public int getUserID() { return this.userID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   public String getUserUsername() { return this.userUsername; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public final String getUserPassword() { return this.userPassword; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public String getUserFirstname() { return this.userFirstname; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public String getUserLastname() { return this.userLastname; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public final boolean isAdministrator() { return this.memberAdministrators; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   public final boolean isUser() { return this.memberUsers; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   public final boolean isGuest() { return this.memberGuests; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isMember(int paramInt) {
/* 223 */     for (byte b = 0; b < this.userGroups.length; b++) {
/*     */       
/* 225 */       if (this.userGroups[b] == paramInt) {
/* 226 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 230 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void evaluateGroups() {
/* 243 */     this.memberAdministrators = false;
/* 244 */     this.memberUsers = false;
/* 245 */     this.memberGuests = false;
/*     */ 
/*     */     
/* 248 */     for (byte b = 0; b < this.userGroups.length; b++) {
/*     */       
/* 250 */       if (this.userGroups[b] == 1000) {
/* 251 */         this.memberAdministrators = true;
/* 252 */       } else if (this.userGroups[b] == 1) {
/* 253 */         this.memberUsers = true;
/* 254 */       } else if (this.userGroups[b] == 0) {
/* 255 */         this.memberGuests = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 274 */   public int getIdentity() { return this.userID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 289 */   public String getTableName() { return this.settings.getUsersTable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 302 */   public String getIdentityColumnName() { return "UserID"; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\pyxis\BasicUser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */