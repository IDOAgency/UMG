/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeneratorFileManager
/*     */   implements FornaxDBConstants
/*     */ {
/*     */   protected static final String DEFAULT_GENERATION_FILEMODE = "rw";
/*     */   protected static final String DEFAULT_ACCESS_FILEMODE = "r";
/*     */   protected String generatedFileName;
/*     */   protected String generationFileMode;
/*     */   protected Generator mGenerator;
/*     */   
/*  51 */   public void setGenerator(Generator paramGenerator) { this.mGenerator = paramGenerator; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteContentTypeInstanceFile(ContentTypeInstance paramContentTypeInstance, Variant paramVariant) {
/*  61 */     String str = getFileName(paramContentTypeInstance, paramVariant, true);
/*  62 */     System.out.println("  ***   Deleting INSTANCE file START  ***  instanceID[" + paramContentTypeInstance.getInstanceID() + "]");
/*     */     
/*  64 */     deleteFile(str);
/*     */     
/*  66 */     System.out.println("  ****  Deleting INSTANCE file END    *** ");
/*     */ 
/*     */     
/*  69 */     this.mGenerator.getReport().updateLine(str, "DELETED FILE");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteListPageFile(ListPage paramListPage) {
/*  79 */     String str = getListPageFileName(paramListPage);
/*     */ 
/*     */     
/*  82 */     System.out.println("  ***   Deleting LIST PAGE file START  ***  " + str);
/*     */     
/*  84 */     deleteFile(str);
/*     */     
/*  86 */     System.out.println("  ****  Deleting LIST PAGE file END    *** ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteFile(String paramString) {
/*  97 */     System.out.println("        Deleting File Name : " + paramString);
/*     */     
/*  99 */     File file = new File(paramString);
/*     */ 
/*     */     
/*     */     try {
/* 103 */       file.delete();
/*     */     }
/* 105 */     catch (Exception exception) {
/*     */       
/* 107 */       System.out.println("ERROR : File " + paramString + "can not be deleted.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateContentFiles(ContentTypeInstance paramContentTypeInstance, Variant paramVariant, String paramString) {
/* 120 */     String str = getFileName(paramContentTypeInstance, paramVariant, true);
/*     */ 
/*     */     
/* 123 */     deleteFile(str);
/*     */ 
/*     */     
/* 126 */     FileWriter fileWriter = createNewFile(str);
/*     */     
/* 128 */     System.out.println("  ***   Generating INSTANCE file to disk START . . . *** ");
/* 129 */     System.out.println("        File Name : " + str);
/*     */ 
/*     */     
/* 132 */     if (fileWriter != null) {
/*     */       
/*     */       try {
/*     */         
/* 136 */         fileWriter.write(paramString);
/* 137 */         fileWriter.flush();
/* 138 */         fileWriter.close();
/*     */ 
/*     */       
/*     */       }
/* 142 */       catch (Exception exception) {
/*     */ 
/*     */         
/* 145 */         this.mGenerator.getReport().updateLine(str, "Error writing to file. " + exception.toString());
/* 146 */         System.out.println("Exception Error : Error writing to file. ");
/*     */       } 
/*     */     }
/*     */     
/* 150 */     System.out.println("  ***   Generating INSTANCE file to disk DONE   ***");
/*     */ 
/*     */     
/* 153 */     this.mGenerator.getReport().updateLine(str, "Generation Successful");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateListPageFile(ListPage paramListPage, String paramString) {
/* 166 */     String str = getListPageFileName(paramListPage);
/*     */ 
/*     */     
/* 169 */     deleteFile(str);
/*     */ 
/*     */     
/* 172 */     FileWriter fileWriter = createNewFile(str);
/*     */     
/* 174 */     System.out.println("  ***   Generating LIST PAGE file to disk START . . . *** ");
/* 175 */     System.out.println("        File Name : " + str);
/*     */ 
/*     */     
/* 178 */     if (fileWriter != null) {
/*     */       
/*     */       try {
/*     */         
/* 182 */         fileWriter.write(paramString);
/* 183 */         fileWriter.flush();
/* 184 */         fileWriter.close();
/*     */       
/*     */       }
/* 187 */       catch (Exception exception) {
/*     */         
/* 189 */         System.out.println("Exception Error : Error writing to List Page. ");
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 194 */     System.out.println("  ***   Generating LIST PAGE file to disk DONE *** ");
/*     */ 
/*     */     
/* 197 */     this.mGenerator.getReport().updateLine(str, "Generation Successful! ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedReader getTemplateFile(Template paramTemplate) {
/* 211 */     BufferedReader bufferedReader = null;
/* 212 */     FilePath filePath = paramTemplate.getFilePath();
/* 213 */     String str = "";
/*     */     
/* 215 */     if (filePath != null) {
/*     */       
/* 217 */       if (!filePath.isFilePathRelative())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 223 */         str = String.valueOf(filePath.getFormattedFilePathName()) + paramTemplate.getTemplateFileName();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 230 */         bufferedReader = new BufferedReader(new FileReader(str));
/*     */       
/*     */       }
/* 233 */       catch (Exception exception) {
/*     */         
/* 235 */         System.out.println("template file not found");
/*     */       } 
/*     */     } 
/*     */     
/* 239 */     return bufferedReader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileWriter createNewFile(String paramString) {
/* 250 */     FileWriter fileWriter = null;
/*     */ 
/*     */     
/*     */     try {
/* 254 */       fileWriter = new FileWriter(paramString, false);
/*     */     
/*     */     }
/* 257 */     catch (Exception exception) {
/*     */       
/* 259 */       System.out.println("Expeption Error : Can not create a new file " + paramString);
/*     */     } 
/*     */     
/* 262 */     return fileWriter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileName(ContentTypeInstance paramContentTypeInstance, Variant paramVariant, boolean paramBoolean) {
/* 273 */     String str = "";
/* 274 */     GenerationDestination generationDestination = paramVariant.getVariantGenerationDestination();
/* 275 */     FilePath filePath = generationDestination.getFilePath();
/*     */ 
/*     */     
/* 278 */     if (filePath != null)
/*     */     {
/*     */       
/* 281 */       if (paramBoolean)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 291 */         str = filePath.getFormattedFilePathName();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 297 */     str = String.valueOf(str) + paramVariant.getVariantFileNamePrefix() + paramVariant.getVariantFileNameTitle() + 
/* 298 */       paramVariant.getVariantFileNameSuffix();
/*     */ 
/*     */     
/* 301 */     if (paramVariant.getVariantFileNameNumberingMode().equalsIgnoreCase("S")) {
/*     */       
/* 303 */       str = String.valueOf(str) + (new Integer(paramContentTypeInstance.getSequenceNO())).toString() + "." + paramVariant.getVariantFileNameExt();
/*     */     }
/* 305 */     else if (paramVariant.getVariantFileNameNumberingMode().equalsIgnoreCase("I")) {
/*     */       
/* 307 */       str = String.valueOf(str) + (new Integer(paramContentTypeInstance.getInstanceID())).toString() + "." + paramVariant.getVariantFileNameExt();
/*     */     }
/*     */     else {
/*     */       
/* 311 */       str = String.valueOf(str) + "." + paramVariant.getVariantFileNameExt();
/*     */     } 
/*     */     
/* 314 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getListPageFileName(ListPage paramListPage) {
/* 324 */     null = "";
/* 325 */     GenerationDestination generationDestination = paramListPage.getListPageGenerationDestination();
/* 326 */     FilePath filePath = generationDestination.getFilePath();
/*     */ 
/*     */     
/* 329 */     if (filePath != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 338 */       null = filePath.getFormattedFilePathName();
/*     */     }
/*     */ 
/*     */     
/* 342 */     return String.valueOf(null) + paramListPage.getListPageFileNamePrefix() + paramListPage.getListPageFileNameTitle() + 
/* 343 */       paramListPage.getListPageFileNameSuffix() + "." + paramListPage.getListPageFileNameExt();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\GeneratorFileManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */