package com.techempower.gemini;

import com.techempower.ComponentLog;
import com.techempower.EnhancedProperties;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class SessionManager {
  public static final String COMPONENT_CODE = "mSes";
  
  public static final int DEFAULT_TIMEOUT = 3600;
  
  protected int timeoutSeconds;
  
  protected GeminiApplication application;
  
  protected ComponentLog log;
  
  public SessionManager(GeminiApplication paramGeminiApplication) {
    this.timeoutSeconds = 3600;
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("mSes");
  }
  
  public void configure(EnhancedProperties paramEnhancedProperties) { setTimeoutSeconds(paramEnhancedProperties.getIntegerProperty("SessionTimeout", this.timeoutSeconds)); }
  
  public void setTimeoutMinutes(int paramInt) { this.timeoutSeconds = paramInt * 60; }
  
  public void setTimeoutSeconds(int paramInt) { this.timeoutSeconds = paramInt; }
  
  public HttpSession getSession(HttpServletRequest paramHttpServletRequest) {
    HttpSession httpSession = paramHttpServletRequest.getSession(true);
    if (httpSession.isNew())
      httpSession.setMaxInactiveInterval(this.timeoutSeconds); 
    return httpSession;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\SessionManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */