/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.EnhancedProperties;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionManager
/*     */ {
/*     */   public static final String COMPONENT_CODE = "mSes";
/*     */   public static final int DEFAULT_TIMEOUT = 3600;
/*     */   protected int timeoutSeconds;
/*     */   protected GeminiApplication application;
/*     */   protected ComponentLog log;
/*     */   
/*     */   public SessionManager(GeminiApplication paramGeminiApplication) {
/*  50 */     this.timeoutSeconds = 3600;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     this.application = paramGeminiApplication;
/*  64 */     this.log = paramGeminiApplication.getLog("mSes");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public void configure(EnhancedProperties paramEnhancedProperties) { setTimeoutSeconds(paramEnhancedProperties.getIntegerProperty("SessionTimeout", this.timeoutSeconds)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public void setTimeoutMinutes(int paramInt) { this.timeoutSeconds = paramInt * 60; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public void setTimeoutSeconds(int paramInt) { this.timeoutSeconds = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpSession getSession(HttpServletRequest paramHttpServletRequest) {
/*  99 */     HttpSession httpSession = paramHttpServletRequest.getSession(true);
/*     */ 
/*     */     
/* 102 */     if (httpSession.isNew())
/*     */     {
/* 104 */       httpSession.setMaxInactiveInterval(this.timeoutSeconds);
/*     */     }
/*     */     
/* 107 */     return httpSession;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\SessionManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */