package com.techempower.gemini.fornax;

import com.techempower.DatabaseConnector;

public class FornaxDBConnector implements FornaxConstants {
  protected static FornaxConnectorFactory connectorFactory = new FornaxConnectorFactory();
  
  public static FornaxConnectorFactory getConnectorFactory() { return null; }
  
  public static DatabaseConnector getConnector(String paramString) { return connectorFactory.getConnector(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxDBConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */