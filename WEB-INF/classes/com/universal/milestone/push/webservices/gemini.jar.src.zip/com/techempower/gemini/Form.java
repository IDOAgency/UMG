/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Form
/*     */ {
/*     */   public static final String COMPONENT_CODE = "form";
/*     */   public static final String POST = "POST";
/*     */   public static final String GET = "GET";
/*     */   protected GeminiApplication application;
/*     */   protected ComponentLog log;
/*     */   protected Vector formElements;
/*     */   protected Vector formSubmissions;
/*     */   protected String formName;
/*     */   protected String formAction;
/*     */   protected String formMethod;
/*     */   
/*     */   public Form(GeminiApplication paramGeminiApplication) {
/* 117 */     this.formElements = new Vector();
/* 118 */     this.formSubmissions = new Vector();
/* 119 */     this.formName = "Form";
/* 120 */     this.formAction = "";
/* 121 */     this.formMethod = "POST";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     this.application = paramGeminiApplication;
/* 135 */     this.log = paramGeminiApplication.getLog("form");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Form(GeminiApplication paramGeminiApplication, String paramString1, String paramString2, String paramString3) {
/*     */     this.formElements = new Vector();
/*     */     this.formSubmissions = new Vector();
/*     */     this.formName = "Form";
/*     */     this.formAction = "";
/*     */     this.formMethod = "POST";
/* 151 */     this.application = paramGeminiApplication;
/* 152 */     this.log = paramGeminiApplication.getLog("form");
/*     */     
/* 154 */     setName(paramString1);
/* 155 */     setAction(paramString2);
/* 156 */     setMethod(paramString3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormValidation validate() {
/* 165 */     FormValidation formValidation = new FormValidation(this);
/* 166 */     formValidation.processForm();
/*     */     
/* 168 */     return formValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   public String toString() { return "Form [\"" + getName() + "\"; " + this.formElements.size() + " element(s)]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String dumpContents() {
/* 186 */     StringBuffer stringBuffer = new StringBuffer(500);
/*     */ 
/*     */     
/* 189 */     for (byte b = 0; b < this.formElements.size(); b++) {
/*     */       
/* 191 */       FormElement formElement = (FormElement)this.formElements.elementAt(b);
/* 192 */       stringBuffer.append(formElement.getDisplayName());
/* 193 */       stringBuffer.append(": ");
/* 194 */       if (formElement instanceof FormCheckBox) {
/*     */         
/* 196 */         FormCheckBox formCheckBox = (FormCheckBox)formElement;
/* 197 */         if (formCheckBox.isChecked()) {
/* 198 */           stringBuffer.append("checked");
/*     */         } else {
/* 200 */           stringBuffer.append("not checked");
/*     */         } 
/*     */       } else {
/*     */         
/* 204 */         stringBuffer.append(formElement.getStringValue());
/*     */       } 
/* 206 */       stringBuffer.append("\r\n");
/*     */     } 
/*     */     
/* 209 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 219 */   public String render() { return render(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render(FormValidation paramFormValidation) {
/* 235 */     StringBuffer stringBuffer = new StringBuffer(500);
/* 236 */     stringBuffer.append(renderStart());
/* 237 */     stringBuffer.append("<table border=\"1\" cellspacing=\"1\" cellpadding=\"1\">");
/*     */ 
/*     */ 
/*     */     
/* 241 */     for (byte b = 0; b < this.formElements.size(); b++) {
/*     */ 
/*     */       
/* 244 */       FormElement formElement = (FormElement)this.formElements.elementAt(b);
/* 245 */       if (paramFormValidation != null && paramFormValidation.getErroredElements().contains(formElement)) {
/*     */         
/* 247 */         stringBuffer.append("<tr><td><b>");
/* 248 */         stringBuffer.append(formElement.getName());
/* 249 */         stringBuffer.append(":</b></td><td>");
/* 250 */         stringBuffer.append(formElement.render());
/* 251 */         stringBuffer.append("</td></tr>");
/*     */       }
/*     */       else {
/*     */         
/* 255 */         stringBuffer.append("<tr><td>");
/* 256 */         stringBuffer.append(formElement.getName());
/* 257 */         stringBuffer.append(":</td><td>");
/* 258 */         stringBuffer.append(formElement.render());
/* 259 */         stringBuffer.append("</td></tr>");
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 264 */     stringBuffer.append("</table>");
/* 265 */     stringBuffer.append(renderEnd());
/*     */     
/* 267 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String renderStart() {
/* 275 */     StringBuffer stringBuffer = new StringBuffer(60);
/* 276 */     stringBuffer.append("<form name=\"");
/* 277 */     stringBuffer.append(this.formName);
/* 278 */     stringBuffer.append("\" action=\"");
/* 279 */     stringBuffer.append(this.formAction);
/* 280 */     stringBuffer.append("\" method=\"");
/* 281 */     stringBuffer.append(this.formMethod);
/* 282 */     stringBuffer.append("\">");
/*     */     
/* 284 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 292 */   public String renderEnd() { return "</form>"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   public void setName(String paramString) { this.formName = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 309 */   public String getName() { return this.formName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 317 */   public GeminiApplication getApplication() { return this.application; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 325 */   public void setAction(String paramString) { this.formAction = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 334 */   public String getAction() { return this.formAction; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 342 */   public void setMethod(String paramString) { this.formMethod = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 350 */   public String getMethod() { return this.formMethod; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 358 */   public Iterator getElements() { return this.formElements.iterator(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addElementsFromForm(Form paramForm) {
/* 368 */     Iterator iterator = paramForm.getElements();
/*     */ 
/*     */     
/* 371 */     while (iterator.hasNext()) {
/*     */ 
/*     */       
/* 374 */       FormElement formElement = (FormElement)iterator.next();
/* 375 */       addElement(formElement);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 384 */   public void addElement(FormElement paramFormElement) { this.formElements.addElement(paramFormElement); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSubmissionElement(FormSubmissionElement paramFormSubmissionElement) {
/* 393 */     this.formSubmissions.addElement(paramFormSubmissionElement);
/*     */ 
/*     */     
/* 396 */     this.formElements.addElement(paramFormSubmissionElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeElement(String paramString) {
/* 404 */     FormElement formElement = getElement(paramString);
/* 405 */     removeElement(formElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeElement(FormElement paramFormElement) {
/* 413 */     if (paramFormElement != null)
/*     */     {
/* 415 */       this.formElements.remove(paramFormElement);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeSubmissionElement(FormSubmissionElement paramFormSubmissionElement) {
/* 424 */     if (paramFormSubmissionElement != null) {
/*     */       
/* 426 */       this.formSubmissions.remove(paramFormSubmissionElement);
/*     */ 
/*     */       
/* 429 */       removeElement(paramFormSubmissionElement);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormElement getElement(int paramInt) {
/* 442 */     if (paramInt >= 0 && paramInt < this.formElements.size())
/*     */     {
/* 444 */       return (FormElement)this.formElements.elementAt(paramInt);
/*     */     }
/*     */ 
/*     */     
/* 448 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormElement getElement(String paramString) {
/* 461 */     for (byte b = 0; b < this.formElements.size(); b++) {
/*     */       
/* 463 */       FormElement formElement = (FormElement)this.formElements.elementAt(b);
/* 464 */       if (formElement.getName().equalsIgnoreCase(paramString)) {
/* 465 */         return formElement;
/*     */       }
/*     */     } 
/*     */     
/* 469 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringValue(String paramString) {
/* 481 */     FormElement formElement = getElement(paramString);
/* 482 */     if (formElement != null) {
/* 483 */       return formElement.getStringValue();
/*     */     }
/* 485 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntegerValue(String paramString) {
/* 497 */     FormElement formElement = getElement(paramString);
/* 498 */     if (formElement != null) {
/* 499 */       return formElement.getIntegerValue();
/*     */     }
/* 501 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRenderableValue(String paramString) {
/* 513 */     FormElement formElement = getElement(paramString);
/* 514 */     if (formElement != null) {
/* 515 */       return formElement.getRenderableValue();
/*     */     }
/* 517 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValues(Context paramContext) {
/* 530 */     for (byte b = 0; b < this.formElements.size(); b++) {
/*     */       
/* 532 */       FormElement formElement = (FormElement)this.formElements.elementAt(b);
/* 533 */       formElement.setValue(paramContext);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUnchanged() {
/* 548 */     for (byte b = 0; b < this.formElements.size(); b++) {
/*     */       
/* 550 */       FormElement formElement = (FormElement)this.formElements.elementAt(b);
/* 551 */       if (!formElement.isUnchanged()) {
/* 552 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 556 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 567 */   public boolean isChanged() { return isUnchanged() ^ true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSubmitted() {
/* 584 */     for (byte b = 0; b < this.formSubmissions.size(); b++) {
/*     */       
/* 586 */       FormSubmissionElement formSubmissionElement = (FormSubmissionElement)this.formSubmissions.elementAt(b);
/* 587 */       if (formSubmissionElement.isSubmitted()) {
/* 588 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 592 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void revertCheckBoxes() {
/* 620 */     for (byte b = 0; b < this.formElements.size(); b++) {
/*     */       
/* 622 */       FormElement formElement = (FormElement)this.formElements.elementAt(b);
/* 623 */       if (formElement instanceof FormCheckBox) {
/* 624 */         formElement.revert();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getChangedElements() {
/* 637 */     Vector vector = new Vector();
/*     */ 
/*     */ 
/*     */     
/* 641 */     for (byte b = 0; b < this.formElements.size(); b++) {
/*     */       
/* 643 */       FormElement formElement = (FormElement)this.formElements.elementAt(b);
/* 644 */       if (!formElement.isUnchanged()) {
/* 645 */         vector.addElement(formElement);
/*     */       }
/*     */     } 
/* 648 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 656 */   public boolean isNew() { return isUnchanged(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\Form.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */