/*    */ package com.techempower.gemini.fornax;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentTypeFieldInteger
/*    */   extends ContentTypeField
/*    */   implements FornaxDBConstants
/*    */ {
/*    */   protected int mValueID;
/*    */   protected int mInstanceID;
/*    */   protected String mFieldValue;
/*    */   
/*    */   public ContentTypeFieldInteger(Hashtable paramHashtable) {
/* 49 */     super(paramHashtable);
/*    */     
/* 51 */     this.mValueID = ((Integer)paramHashtable.get("intergerValueID")).intValue();
/* 52 */     this.mInstanceID = ((Integer)paramHashtable.get("integerValueInstance")).intValue();
/* 53 */     this.mFieldValue = (String)paramHashtable.get("integerValueData");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 64 */   public int getValueID() { return this.mValueID; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 73 */   public int getInstanceID() { return this.mInstanceID; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 82 */   public String getFieldValue() { return this.mFieldValue; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\ContentTypeFieldInteger.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */