package com.techempower.gemini.fornax;

import java.util.Hashtable;

public class TemplateTagContentItem extends TemplateTag implements FornaxDBConstants {
  protected boolean debug = false;
  
  protected String mDelta;
  
  protected String mField;
  
  protected String mBeforeHTML;
  
  protected String mAfterHTML;
  
  protected Hashtable mContentTypeTable;
  
  public TemplateTagContentItem(Hashtable paramHashtable1, Hashtable paramHashtable2) {
    super(paramHashtable1, false);
    this.mDelta = (String)paramHashtable1.get("delta=");
    this.mField = (String)paramHashtable1.get("field=");
    this.mBeforeHTML = (String)paramHashtable1.get("before=");
    this.mAfterHTML = (String)paramHashtable1.get("after=");
    this.mContentTypeTable = paramHashtable2;
  }
  
  public String getDelta() { return this.mDelta; }
  
  public String getField() { return this.mField; }
  
  public String getBeforeHTML() { return this.mBeforeHTML; }
  
  public String getAfterHTML() { return this.mAfterHTML; }
  
  public String render(Hashtable paramHashtable) {
    String str1 = null;
    String str2 = "";
    ReserveWordTemplateFieldManager reserveWordTemplateFieldManager = new ReserveWordTemplateFieldManager();
    ContentTypeInstance contentTypeInstance = (ContentTypeInstance)paramHashtable.get("instance");
    ContentTypeInstanceGroup contentTypeInstanceGroup = (ContentTypeInstanceGroup)paramHashtable.get("group");
    Variant variant = (Variant)paramHashtable.get("groupVariant");
    Generator generator = (Generator)paramHashtable.get("generator");
    ContentType contentType = (ContentType)paramHashtable.get("contenttype");
    if (contentType == null) {
      contentType = (ContentType)this.mContentTypeTable.get(this.mContentType.toUpperCase());
      if (contentType != null)
        contentTypeInstanceGroup = contentType.getGroupByName(this.mContentTypeGroup); 
    } 
    if (this.mDelta.trim() != "")
      if (contentTypeInstanceGroup != null) {
        DeltaTemplateFieldManager deltaTemplateFieldManager = new DeltaTemplateFieldManager(contentTypeInstanceGroup, contentTypeInstance);
        ContentTypeInstance contentTypeInstance1 = deltaTemplateFieldManager.getDeltaInstance(this.mDelta);
        if (contentTypeInstance1 != null) {
          contentTypeInstance = contentTypeInstance1;
        } else {
          generator.getReport().updateLine("", "Delta field will be skipped.");
          contentTypeInstanceGroup = null;
          str1 = null;
        } 
      } else {
        generator.getReport().updateLine("", "Error : Group does not match content type.");
        contentTypeInstanceGroup = null;
        str1 = null;
      }  
    if (reserveWordTemplateFieldManager.isReserveWord(this.mField)) {
      if (contentTypeInstanceGroup != null) {
        reserveWordTemplateFieldManager.setInstance(contentTypeInstance);
        reserveWordTemplateFieldManager.setContentType(contentType);
        Variant variant1 = contentTypeInstanceGroup.getVariantByVariantTypeCode(this.mVariant);
        if (variant1 != null) {
          reserveWordTemplateFieldManager.setVariant(variant1);
        } else {
          if (this.mVariant != null)
            generator.getReport().updateLine("", "Syntax Error : Variant [" + this.mVariant + "] not valid. "); 
          if (variant != null) {
            reserveWordTemplateFieldManager.setVariant(variant);
          } else {
            generator.getReport().updateLine("", "Syntax Error : Variant [" + variant + "] not valid. ");
            this.mField = "";
          } 
        } 
        str1 = reserveWordTemplateFieldManager.render(this.mField);
      } else {
        generator.getReport().updateLine("", "Error : Could not render field due to invalid type [" + this.mContentType + "] OR typegroup[" + this.mContentTypeGroup + "].");
        str1 = null;
      } 
    } else if (contentTypeInstance != null) {
      str1 = contentTypeInstance.getFieldValueByName(this.mField);
    } 
    if (str1 == null) {
      generator.getReport().updateLine("", "Syntax Error : Field [" + this.mField + "] not valid. ");
      System.out.println("  Could not find field data " + this.mField + " for InstanceID[" + contentTypeInstance.getInstanceID() + "]");
      str2 = "";
    } else {
      str2 = String.valueOf(this.mBeforeHTML) + str1 + this.mAfterHTML;
    } 
    if (this.debug)
      System.out.println("Rendered field " + this.mField + " to = " + str1); 
    return str2;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\TemplateTagContentItem.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */