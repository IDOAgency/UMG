/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.DataEntity;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxVariantType
/*     */   extends DataEntity
/*     */   implements FornaxConstants
/*     */ {
/*  37 */   protected int variantTypeID = -1;
/*  38 */   protected String variantTypeCode = "";
/*  39 */   protected String variantTypeDescription = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializationComplete() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getCustomSetMethodBindings() {
/*  60 */     Hashtable hashtable = new Hashtable();
/*     */     
/*  62 */     hashtable.put("VariantTypeID", "setID");
/*  63 */     hashtable.put("VariantTypeCode", "setCode");
/*  64 */     hashtable.put("VariantTypeDescription", "setDescription");
/*     */     
/*  66 */     return hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public int getIdentity() { return this.variantTypeID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public String getTableName() { return "fnVariantType"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public String getIdentityColumnName() { return "VariantTypeID"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public int getID() { return this.variantTypeID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public String getCode() { return this.variantTypeCode; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public String getDescription() { return this.variantTypeDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public void setID(int paramInt) { this.variantTypeID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCode(String paramString) {
/* 145 */     if (paramString != null) {
/* 146 */       this.variantTypeCode = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String paramString) {
/* 154 */     if (paramString != null)
/* 155 */       this.variantTypeDescription = paramString; 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxVariantType.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */