package com.techempower.gemini.fornax;

import com.techempower.ComponentLog;
import com.techempower.DatabaseConnector;
import com.techempower.JdbcConnector;
import com.techempower.gemini.Context;
import com.techempower.gemini.Form;
import com.techempower.gemini.FormCheckBox;
import com.techempower.gemini.FormComplexDateField;
import com.techempower.gemini.FormFloatField;
import com.techempower.gemini.FormHidden;
import com.techempower.gemini.FormIntegerField;
import com.techempower.gemini.FormTextArea;
import com.techempower.gemini.FormTextField;
import com.techempower.gemini.GeminiApplication;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Vector;

public class FornaxContentTypeInstanceManager implements FornaxConstants {
  public static final String COMPONENT_CODE = "fMng";
  
  public GeminiApplication application;
  
  public ComponentLog log;
  
  public FornaxSettings fornaxSettings;
  
  protected Form form;
  
  protected final int PAGE_SIZE = 6;
  
  protected int browserType;
  
  protected Vector contentTypeInstances;
  
  public FornaxContentTypeInstanceManager(GeminiApplication paramGeminiApplication) {
    this.form = null;
    this.PAGE_SIZE = 6;
    this.browserType = -1;
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("fMng");
    this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
  }
  
  public String getDescription() { return "Fornax ContentTypeInstance Manager"; }
  
  public FornaxContentTypeInstance getContentTypeInstance(int paramInt1, int paramInt2, boolean paramBoolean) {
    FornaxContentTypeInstance fornaxContentTypeInstance;
    if (paramInt1 == -1) {
      fornaxContentTypeInstance = new FornaxContentTypeInstance();
      fornaxContentTypeInstance.setContentTypeID(paramInt2);
    } else {
      String str = 
        
        "SELECT * FROM fnContentTypeInstance WHERE InstanceID = " + 
        paramInt1;
      Vector vector = 
        this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
          "com.techempower.gemini.fornax.FornaxContentTypeInstance", 
          true, 
          this.fornaxSettings);
      if (vector.size() == 1) {
        fornaxContentTypeInstance = (FornaxContentTypeInstance)vector.get(0);
        if (paramBoolean) {
          fornaxContentTypeInstance.setID(-1);
          fornaxContentTypeInstance.setIsDisabled("F");
          fornaxContentTypeInstance.setIsQueuedForDeletion("F");
          fornaxContentTypeInstance.setDateCreated(FornaxHelper.getInitializedCalendar("1900-01-01 00:00:00AM"));
          fornaxContentTypeInstance.setLastModifiedByUserID(-1);
          fornaxContentTypeInstance.setLastModifiedTimestamp(FornaxHelper.getInitializedCalendar("1900-01-01 00:00:00AM"));
        } 
      } else {
        fornaxContentTypeInstance = null;
      } 
    } 
    if (this.form != null && fornaxContentTypeInstance != null)
      addContentTypeInstanceFullFormData(fornaxContentTypeInstance); 
    return fornaxContentTypeInstance;
  }
  
  public Vector getContentTypeInstances(int paramInt) {
    this.contentTypeInstances = 
      getContentTypeInstances(paramInt, 1, 0, 0);
    return this.contentTypeInstances;
  }
  
  public Vector getContentTypeInstances(int paramInt1, int paramInt2, int paramInt3) {
    this.contentTypeInstances = 
      getContentTypeInstances(paramInt1, 1, paramInt2, paramInt3);
    return this.contentTypeInstances;
  }
  
  public Vector getContentTypeInstances(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Vector vector;
    this.log.debug("Requesting page: " + paramInt2);
    String str = 
      
      "SELECT * FROM fnContentTypeInstance WHERE InstanceContentTypeID = " + 
      paramInt1;
    switch (paramInt3) {
      case 0:
        str = String.valueOf(str) + " ORDER BY InstanceID";
        break;
      case 1:
        str = String.valueOf(str) + " ORDER BY InstanceName";
        break;
      case 2:
        str = String.valueOf(str) + " ORDER BY InstanceLastModifiedTimestamp";
        break;
      default:
        str = String.valueOf(str) + " ORDER BY InstanceID";
        break;
    } 
    switch (paramInt4) {
      case 0:
        str = String.valueOf(str) + " ASC";
        break;
      case 1:
        str = String.valueOf(str) + " DESC";
        break;
      default:
        str = String.valueOf(str) + " ASC";
        break;
    } 
    this.contentTypeInstances = null;
    this.contentTypeInstances = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxContentTypeInstance", 
        true, 
        this.fornaxSettings);
    if (paramInt2 == 0) {
      vector = this.contentTypeInstances;
    } else if (paramInt2 == -1) {
      vector = 
        this.fornaxSettings.getFornaxHelper().getPageOfVectorObjects(this.contentTypeInstances, 1, 6);
    } else if (paramInt2 == -2) {
      vector = 
        this.fornaxSettings.getFornaxHelper().getPageOfVectorObjects(this.contentTypeInstances, getPageCount(), 6);
    } else {
      vector = 
        this.fornaxSettings.getFornaxHelper().getPageOfVectorObjects(this.contentTypeInstances, paramInt2, 6);
    } 
    if (this.form != null)
      for (byte b = 0; b < vector.size(); b++)
        addContentTypeInstanceFormData((FornaxContentTypeInstance)vector.get(b));  
    this.log.debug("Number of instances fetched (after): " + vector.size());
    return vector;
  }
  
  public Vector getContentTypeInstancesForGroup(int paramInt, String paramString) {
    String str = 
      
      " SELECT cti.* FROM fnMapContentTypeInstanceToInstancesGroup mp INNER JOIN fnContentTypeInstance cti ON cti.InstanceID = mp.InstanceID AND mp.InstancesGroupID = " + 
      paramInt + 
      " WHERE cti.InstanceIsQueuedForDeletion = '" + paramString + "'" + 
      " ORDER BY mp.InstanceSequenceNumber ASC";
    return this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxContentTypeInstance", 
        true, 
        this.fornaxSettings);
  }
  
  Vector getContentTypeInstanceFieldValues(int paramInt1, int paramInt2) {
    FornaxContentTypeInstanceFieldValueManager fornaxContentTypeInstanceFieldValueManager = 
      new FornaxContentTypeInstanceFieldValueManager(this.application);
    Vector vector = 
      fornaxContentTypeInstanceFieldValueManager.getContentTypeInstanceFieldValues(paramInt1, paramInt2);
    if (this.form != null)
      if (vector.size() > 0)
        addContentTypeInstanceFieldValuesFormData(vector);  
    return vector;
  }
  
  public int getPageCount() {
    if (this.contentTypeInstances != null)
      return (int)Math.ceil((this.contentTypeInstances.size() / 6.0F)); 
    return 0;
  }
  
  public void setForm(Form paramForm) { this.form = paramForm; }
  
  public void setBrowserType(int paramInt) { this.browserType = paramInt; }
  
  protected void addContentTypeInstanceFormData(FornaxContentTypeInstance paramFornaxContentTypeInstance) {
    FormCheckBox formCheckBox1 = new FormCheckBox("instance-disabled-" + paramFornaxContentTypeInstance.getID());
    formCheckBox1.setValue(Integer.toString(paramFornaxContentTypeInstance.getID()));
    formCheckBox1.setStartingChecked(paramFornaxContentTypeInstance.isDisabled());
    formCheckBox1.setChecked(paramFornaxContentTypeInstance.isDisabled());
    FormCheckBox formCheckBox2 = new FormCheckBox("instance-queued-for-deletion-" + paramFornaxContentTypeInstance.getID());
    formCheckBox2.setValue(Integer.toString(paramFornaxContentTypeInstance.getID()));
    formCheckBox2.setStartingChecked(paramFornaxContentTypeInstance.isQueuedForDeletion());
    formCheckBox2.setChecked(paramFornaxContentTypeInstance.isQueuedForDeletion());
    this.form.addElement(formCheckBox1);
    this.form.addElement(formCheckBox2);
  }
  
  protected void addContentTypeInstanceFullFormData(FornaxContentTypeInstance paramFornaxContentTypeInstance) {
    FormHidden formHidden1 = new FormHidden("instance-id", 
        Integer.toString(paramFornaxContentTypeInstance.getID()), 
        true);
    FormHidden formHidden2 = new FormHidden("instance-content-type-id", 
        Integer.toString(paramFornaxContentTypeInstance.getContentTypeID()), 
        true);
    byte b1 = 23;
    if (this.browserType == 0 || 
      this.browserType == 1)
      b1 = 40; 
    FormTextField formTextField = new FormTextField("instance-name", 
        paramFornaxContentTypeInstance.getName(), 
        true, 
        b1, 
        50);
    formTextField.setClassName("contentText");
    formTextField.setDisplayName("\"Content Item Name\"");
    byte b2 = 28;
    if (this.browserType == 0 || 
      this.browserType == 1)
      b2 = 55; 
    FormTextArea formTextArea = new FormTextArea("instance-description", 
        paramFornaxContentTypeInstance.getDescription(), 
        false, 
        10, 
        b2, 
        "virtual");
    formTextArea.setClassName("contentText");
    FormCheckBox formCheckBox1 = new FormCheckBox("instance-disabled");
    formCheckBox1.setValue(Integer.toString(paramFornaxContentTypeInstance.getID()));
    formCheckBox1.setStartingChecked(paramFornaxContentTypeInstance.isDisabled());
    formCheckBox1.setChecked(paramFornaxContentTypeInstance.isDisabled());
    FormCheckBox formCheckBox2 = new FormCheckBox("instance-queued-for-deletion");
    formCheckBox2.setValue(Integer.toString(paramFornaxContentTypeInstance.getID()));
    formCheckBox2.setStartingChecked(paramFornaxContentTypeInstance.isQueuedForDeletion());
    formCheckBox2.setChecked(paramFornaxContentTypeInstance.isQueuedForDeletion());
    this.form.addElement(formHidden1);
    this.form.addElement(formHidden2);
    this.form.addElement(formTextField);
    this.form.addElement(formTextArea);
    this.form.addElement(formCheckBox1);
    this.form.addElement(formCheckBox2);
  }
  
  protected void addContentTypeInstanceFieldValuesFormData(Vector paramVector) {
    for (byte b = 0; b < paramVector.size(); b++) {
      FornaxContentTypeInstanceFieldValue fornaxContentTypeInstanceFieldValue = (FornaxContentTypeInstanceFieldValue)paramVector.get(b);
      String str = fornaxContentTypeInstanceFieldValue.getDataTypeName();
      if (str.equalsIgnoreCase("DATE")) {
        addDateTimeFieldFormElement(fornaxContentTypeInstanceFieldValue);
      } else if (str.equalsIgnoreCase("INTEGER")) {
        addIntegerFieldFormElement(fornaxContentTypeInstanceFieldValue);
      } else if (str.equalsIgnoreCase("FLOATINGPOINT")) {
        addFloatingPointFieldFormElement(fornaxContentTypeInstanceFieldValue);
      } else if (str.equalsIgnoreCase("STRING")) {
        addStringFieldFormElement(fornaxContentTypeInstanceFieldValue);
      } 
    } 
  }
  
  protected void addDateTimeFieldFormElement(FornaxContentTypeInstanceFieldValue paramFornaxContentTypeInstanceFieldValue) {
    byte b = 23;
    if (this.browserType == 0 || 
      this.browserType == 1)
      b = 40; 
    FormComplexDateField formComplexDateField = new FormComplexDateField(paramFornaxContentTypeInstanceFieldValue.getFieldName(), 
        paramFornaxContentTypeInstanceFieldValue.getFieldValue(), 
        paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired(), 
        26);
    if (paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired()) {
      formComplexDateField.setClassName("contentText");
    } else {
      formComplexDateField.setClassName("contentText");
    } 
    formComplexDateField.setDisplayName("\"" + paramFornaxContentTypeInstanceFieldValue.getFieldName() + "\"");
    if (this.form != null)
      this.form.addElement(formComplexDateField); 
  }
  
  protected void addIntegerFieldFormElement(FornaxContentTypeInstanceFieldValue paramFornaxContentTypeInstanceFieldValue) {
    byte b = 10;
    if (this.browserType == 0 || 
      this.browserType == 1)
      b = 15; 
    FormIntegerField formIntegerField = new FormIntegerField(paramFornaxContentTypeInstanceFieldValue.getFieldName(), 
        paramFornaxContentTypeInstanceFieldValue.getFieldValue(), 
        paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired(), 
        (int)paramFornaxContentTypeInstanceFieldValue.getFieldNumericValueMin(), 
        (int)paramFornaxContentTypeInstanceFieldValue.getFieldNumericValueMax(), 
        b, 
        15);
    if (paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired()) {
      formIntegerField.setClassName("contentText");
    } else {
      formIntegerField.setClassName("contentText");
    } 
    formIntegerField.setDisplayName("\"" + paramFornaxContentTypeInstanceFieldValue.getFieldName() + "\"");
    if (this.form != null)
      this.form.addElement(formIntegerField); 
  }
  
  protected void addFloatingPointFieldFormElement(FornaxContentTypeInstanceFieldValue paramFornaxContentTypeInstanceFieldValue) {
    byte b = 10;
    if (this.browserType == 0 || 
      this.browserType == 1)
      b = 15; 
    FormFloatField formFloatField = new FormFloatField(paramFornaxContentTypeInstanceFieldValue.getFieldName(), 
        paramFornaxContentTypeInstanceFieldValue.getFieldValue(), 
        paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired(), 
        paramFornaxContentTypeInstanceFieldValue.getFieldNumericValueMin(), 
        paramFornaxContentTypeInstanceFieldValue.getFieldNumericValueMax(), 
        b, 
        25);
    if (paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired()) {
      formFloatField.setClassName("contentText");
    } else {
      formFloatField.setClassName("contentText");
    } 
    formFloatField.setDisplayName("\"" + paramFornaxContentTypeInstanceFieldValue.getFieldName() + "\"");
    if (this.form != null)
      this.form.addElement(formFloatField); 
  }
  
  protected void addStringFieldFormElement(FornaxContentTypeInstanceFieldValue paramFornaxContentTypeInstanceFieldValue) {
    if (paramFornaxContentTypeInstanceFieldValue.getFieldStringMaxLength() <= 50) {
      byte b = 23;
      if (this.browserType == 0 || 
        this.browserType == 1)
        b = 40; 
      FormTextField formTextField = new FormTextField(paramFornaxContentTypeInstanceFieldValue.getFieldName(), 
          paramFornaxContentTypeInstanceFieldValue.getFieldValue(), 
          paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired(), 
          b, 
          paramFornaxContentTypeInstanceFieldValue.getFieldStringMaxLength());
      if (paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired()) {
        formTextField.setClassName("contentText");
      } else {
        formTextField.setClassName("contentText");
      } 
      formTextField.setDisplayName("\"" + paramFornaxContentTypeInstanceFieldValue.getFieldName() + "\"");
      if (this.form != null)
        this.form.addElement(formTextField); 
    } else {
      byte b = 28;
      if (this.browserType == 0 || 
        this.browserType == 1)
        b = 55; 
      FormTextArea formTextArea = new FormTextArea(paramFornaxContentTypeInstanceFieldValue.getFieldName(), 
          paramFornaxContentTypeInstanceFieldValue.getFieldValue(), 
          paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired(), 
          10, 
          b, 
          "virtual");
      formTextArea.setMaxLength(paramFornaxContentTypeInstanceFieldValue.getFieldStringMaxLength());
      if (paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired()) {
        formTextArea.setClassName("contentText");
      } else {
        formTextArea.setClassName("contentText");
      } 
      formTextArea.setDisplayName("\"" + paramFornaxContentTypeInstanceFieldValue.getFieldName() + "\"");
      if (this.form != null)
        this.form.addElement(formTextArea); 
    } 
  }
  
  protected boolean updateContentTypeInstance(Context paramContext, Form paramForm, int paramInt, ArrayList paramArrayList) {
    int i = paramForm.getIntegerValue("instance-id");
    int j = paramForm.getIntegerValue("instance-content-type-id");
    this.log.debug("Preparing to update instanceID:" + i + ", and TypeID: " + j);
    if (paramInt != 2 || (paramInt == 2 && i > 0 && j > 0)) {
      FornaxContentTypeInstance fornaxContentTypeInstance = getContentTypeInstance(i, j, false);
      fornaxContentTypeInstance.setContentTypeID(paramForm.getIntegerValue("instance-content-type-id"));
      fornaxContentTypeInstance.setName(paramForm.getStringValue("instance-name"));
      fornaxContentTypeInstance.setDescription(paramForm.getStringValue("instance-description"));
      fornaxContentTypeInstance.setIsDisabled("F");
      fornaxContentTypeInstance.setIsQueuedForDeletion("F");
      FormCheckBox formCheckBox;
      if ((formCheckBox = (FormCheckBox)paramForm.getElement("instance-disabled")) != null)
        if (formCheckBox.isChecked())
          fornaxContentTypeInstance.setIsDisabled("T");  
      if ((formCheckBox = (FormCheckBox)paramForm.getElement("instance-queued-for-deletion")) != null)
        if (formCheckBox.isChecked())
          fornaxContentTypeInstance.setIsQueuedForDeletion("T");  
      if (this.fornaxSettings.getSecurity() != null) {
        fornaxContentTypeInstance.setLastModifiedByUserID(this.fornaxSettings.getSecurity().getLogin(paramContext).getUserID());
      } else {
        this.log.debug("no security context available at this time...");
      } 
      this.log.debug("running update....");
      int k = fornaxContentTypeInstance.runUpdate(this.fornaxSettings.getConnector(""), true);
      this.log.debug("return value retrieved as: " + k);
      if (i == -1 && k == -1) {
        paramArrayList.add(new String(
              "cnTypeInstMgr::updateContentTypeInstance\nDB ERROR, The INSERT failed [ContentTypeID: " + 
              j + 
              ", InstanceID: " + i + 
              ", return value: " + k + "]"));
        return false;
      } 
      if (i != -1 && k != 1) {
        paramArrayList.add(new String(
              "cnTypeInstMgr::updateContentTypeInstance\nDB ERROR, The UPDATE failed [ContentTypeID: " + 
              j + 
              ", InstanceID: " + i + 
              ", return value: " + k + "]"));
        return false;
      } 
      if (i == -1 && k != -1)
        i = k; 
      Vector vector = getContentTypeInstanceFieldValues(i, j);
      for (byte b = 0; b < vector.size(); b++) {
        FornaxContentTypeInstanceFieldValue fornaxContentTypeInstanceFieldValue = (FornaxContentTypeInstanceFieldValue)vector.get(b);
        String str = paramForm.getStringValue(fornaxContentTypeInstanceFieldValue.getFieldName());
        if (str != null) {
          fornaxContentTypeInstanceFieldValue.setFieldValue(str);
          int m = fornaxContentTypeInstanceFieldValue.runUpdate(this.fornaxSettings.getConnector(""));
          this.log.debug("return value for field update retrieved as: " + m);
          if (m == -1)
            paramArrayList.add(new String(
                  "cnTypeInstMgr::updateContentTypeInstance\nDB ERROR, The fieldValue INSERT?UPDATE failed [ContentTypeID: " + 
                  j + 
                  ", InstanceID: " + i + 
                  ", FieldName: " + fornaxContentTypeInstanceFieldValue.getFieldName() + 
                  ", return value: " + m + "]")); 
        } 
      } 
      if (!updateInstancesGroupMapping(j, i))
        paramArrayList.add(new String(
              "cnTypeInstMgr::updateContentTypeInstance\nDB ERROR, An error occurred while updating the instance group mapping [ContentTypeID: " + 
              j + 
              ", InstanceID: " + i + 
              ", DefaultGroupID detected as: " + 
              getDefaultGroupID(j) + "]")); 
      return !(k == -1);
    } 
    paramArrayList.add(new String(
          "cnTypeInstMgr::updateContentTypeInstance\nGENERAL ERROR, either the instance or content type id was invalid [ContentTypeID: " + 
          j + 
          ", InstanceID: " + i + "]"));
    this.log.debug("Either the ContentTypeID or InstanceID was invalid.");
    return false;
  }
  
  protected void updateInstanceStatusFlags(Context paramContext, Form paramForm, Vector paramVector) {
    boolean bool = false;
    for (byte b = 0; b < paramVector.size(); b++) {
      FornaxContentTypeInstance fornaxContentTypeInstance = (FornaxContentTypeInstance)paramVector.get(b);
      fornaxContentTypeInstance.setIsDisabled("F");
      fornaxContentTypeInstance.setIsQueuedForDeletion("F");
      FormCheckBox formCheckBox;
      if ((formCheckBox = (FormCheckBox)paramForm.getElement("instance-disabled-" + fornaxContentTypeInstance.getID())) != null) {
        if (formCheckBox.isChecked())
          fornaxContentTypeInstance.setIsDisabled("T"); 
        if (formCheckBox.getStartingChecked() != formCheckBox.isChecked())
          bool = true; 
      } 
      if ((formCheckBox = (FormCheckBox)paramForm.getElement("instance-queued-for-deletion-" + fornaxContentTypeInstance.getID())) != null) {
        if (formCheckBox.isChecked())
          fornaxContentTypeInstance.setIsQueuedForDeletion("T"); 
        if (formCheckBox.getStartingChecked() != formCheckBox.isChecked())
          bool = true; 
      } 
      if (bool) {
        this.log.debug("Status changes WERE made to instanceID: " + fornaxContentTypeInstance.getID());
        if (paramContext != null) {
          fornaxContentTypeInstance.setLastModifiedByUserID(this.fornaxSettings.getSecurity().getLogin(paramContext).getUserID());
        } else {
          this.log.debug("unabled to update last modified by user ID for instanceID: " + fornaxContentTypeInstance.getID());
        } 
      } 
      fornaxContentTypeInstance.runUpdate(this.fornaxSettings.getConnector(""), bool);
      if (bool)
        resynchInstanceLastModifiedTimeStamp(fornaxContentTypeInstance); 
      bool = false;
    } 
  }
  
  protected int getDefaultGroupID(int paramInt) {
    return FornaxContentTypeManager.getDefaultInstancesGroupID(paramInt, 
        this.fornaxSettings.getConnector(""));
  }
  
  protected boolean updateInstancesGroupMapping(int paramInt1, int paramInt2) {
    boolean bool = true;
    int i = getDefaultGroupID(paramInt1);
    isInstanceMappedToGroup(i, 
        paramInt2, 
        this.fornaxSettings.getConnector(""));
    String str = 
      
      "BEGIN TRAN; DECLARE @iNextSeqNo int; SELECT @iNextSeqNo = max(InstanceSequenceNumber) FROM fnMapContentTypeInstanceToInstancesGroup WHERE InstancesGroupID = " + 
      i + ";" + 
      
      " INSERT INTO fnMapContentTypeInstanceToInstancesGroup(InstanceID," + 
      " InstancesGroupID," + 
      " InstanceSequenceNumber)" + 
      " VALUES (" + paramInt2 + "," + i + ", @iNextSeqNo);" + 
      
      " SELECT count(InstanceID) as 'InstanceCount'" + 
      " FROM fnMapContentTypeInstanceToInstancesGroup" + 
      " WHERE InstanceID = " + paramInt2 + 
      " AND InstancesGroupID = " + i + ";" + 
      
      " COMMIT TRAN;";
    DatabaseConnector databaseConnector = 
      this.fornaxSettings.getConnector(str);
    databaseConnector.runQuery();
    int j = -1;
    if (databaseConnector.more()) {
      databaseConnector.first();
      if ((j = databaseConnector.getInt("InstanceCount", -1)) != 1)
        bool = false; 
    } 
    databaseConnector.close();
    return bool;
  }
  
  protected void resynchInstanceLastModifiedTimeStamp(FornaxContentTypeInstance paramFornaxContentTypeInstance) {
    JdbcConnector jdbcConnector = (JdbcConnector)this.fornaxSettings.getConnector("select InstanceLastModifiedTimestamp from fnContentTypeInstance where InstanceID = " + paramFornaxContentTypeInstance.getID());
    jdbcConnector.runQuery();
    if (jdbcConnector.more()) {
      jdbcConnector.first();
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(jdbcConnector.getDate("InstanceLastModifiedTimestamp"));
      paramFornaxContentTypeInstance.setLastModifiedTimestamp(calendar);
    } 
    jdbcConnector.close();
  }
  
  public static boolean isInstanceMappedToGroup(int paramInt1, int paramInt2, DatabaseConnector paramDatabaseConnector) {
    boolean bool = false;
    String str = 
      
      "SELECT count(InstanceID) as 'InstanceCount' FROM fnMapContentTypeInstanceToInstancesGroup mp WHERE mp.InstancesGroupID = " + 
      paramInt1 + 
      " AND mp.InstanceID = " + paramInt2;
    paramDatabaseConnector.setQuery(str);
    paramDatabaseConnector.runQuery();
    if (paramDatabaseConnector.more()) {
      paramDatabaseConnector.first();
      if (paramDatabaseConnector.getInt("InstanceCount", -1) == 1)
        bool = true; 
    } 
    paramDatabaseConnector.close();
    return bool;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstanceManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */