/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.DataEntity;
/*     */ import com.techempower.DatabaseConnector;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxContentTypeInstancesGroup
/*     */   extends DataEntity
/*     */   implements FornaxConstants, FornaxDBConstants
/*     */ {
/*  37 */   protected int instancesGroupID = -1;
/*  38 */   protected int instancesGroupContentTypeID = -1;
/*  39 */   protected int instancesGroupListPageID = -1;
/*  40 */   protected String instancesGroupName = "";
/*  41 */   protected String instancesGroupDescription = "";
/*     */   protected boolean instancesGroupIsSingleton = false;
/*     */   protected boolean instancesGroupIsListPageGenerated = false;
/*     */   protected boolean instancesGroupIsInstanceGenerationEnabled = false;
/*  45 */   protected int instancesGroupInstancesCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializationComplete() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getCustomSetMethodBindings() {
/*  65 */     Hashtable hashtable = new Hashtable();
/*     */     
/*  67 */     hashtable.put("InstancesGroupID", "setID");
/*  68 */     hashtable.put("InstancesGroupContentTypeID", "setContentTypeID");
/*  69 */     hashtable.put("InstancesGroupListPageID", "setListPageID");
/*  70 */     hashtable.put("InstancesGroupName", "setName");
/*  71 */     hashtable.put("InstancesGroupDescription", "setDescription");
/*  72 */     hashtable.put("InstancesGroupIsSingleton", "setIsSingleton");
/*  73 */     hashtable.put("InstancesGroupIsListPageGenerated", "setIsListPageGenerated");
/*  74 */     hashtable.put("InstancesGroupIsInstanceGenerationEnabled", "setIsInstanceGenerationEnabled");
/*  75 */     hashtable.put("InstancesGroupInstancesCount", "setInstancesCount");
/*     */     
/*  77 */     return hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public int getIdentity() { return this.instancesGroupID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public String getTableName() { return "fnContentTypeInstancesGroup"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public String getIdentityColumnName() { return "InstancesGroupID"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public int getID() { return this.instancesGroupID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   public int getContentTypeID() { return this.instancesGroupContentTypeID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public int getListPageID() { return this.instancesGroupListPageID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public String getName() { return this.instancesGroupName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public String getDescription() { return this.instancesGroupDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   public boolean isSingleton() { return this.instancesGroupIsSingleton; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIsSingletonAsString() {
/* 164 */     if (this.instancesGroupIsSingleton)
/*     */     {
/* 166 */       return "T";
/*     */     }
/*     */ 
/*     */     
/* 170 */     return "F";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   public boolean isListPageGenerated() { return this.instancesGroupIsListPageGenerated; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIsListPageGeneratedAsString() {
/* 186 */     if (this.instancesGroupIsListPageGenerated)
/*     */     {
/* 188 */       return "T";
/*     */     }
/*     */ 
/*     */     
/* 192 */     return "F";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   public boolean isInstanceGenerationEnabled() { return this.instancesGroupIsInstanceGenerationEnabled; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIsInstanceGenerationEnabledAsString() {
/* 207 */     if (this.instancesGroupIsInstanceGenerationEnabled)
/*     */     {
/* 209 */       return "T";
/*     */     }
/*     */ 
/*     */     
/* 213 */     return "F";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 222 */   public int getInstancesCount() { return this.instancesGroupInstancesCount; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 237 */   public void setID(int paramInt) { this.instancesGroupID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   public void setContentTypeID(int paramInt) { this.instancesGroupContentTypeID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 259 */   public void setListPageID(int paramInt) { this.instancesGroupListPageID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String paramString) {
/* 270 */     if (paramString != null) {
/* 271 */       this.instancesGroupName = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String paramString) {
/* 282 */     if (paramString != null) {
/* 283 */       this.instancesGroupDescription = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsSingleton(String paramString) {
/* 294 */     this.instancesGroupIsSingleton = false;
/*     */     
/* 296 */     if (paramString.trim().equalsIgnoreCase("T"))
/*     */     {
/* 298 */       this.instancesGroupIsSingleton = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsListPageGenerated(String paramString) {
/* 310 */     this.instancesGroupIsListPageGenerated = false;
/*     */ 
/*     */     
/* 313 */     if (paramString.trim().equalsIgnoreCase("T"))
/*     */     {
/* 315 */       this.instancesGroupIsListPageGenerated = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsInstanceGenerationEnabled(String paramString) {
/* 331 */     this.instancesGroupIsInstanceGenerationEnabled = false;
/*     */     
/* 333 */     if (paramString.trim().equalsIgnoreCase("T"))
/*     */     {
/* 335 */       this.instancesGroupIsInstanceGenerationEnabled = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 349 */   public void setInstancesCount(int paramInt) { this.instancesGroupInstancesCount = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int runUpdate(DatabaseConnector paramDatabaseConnector) {
/* 357 */     String str1 = "IDENTITY_VALUE";
/* 358 */     String str2 = "ROWCOUNT_VALUE";
/*     */     
/* 360 */     boolean bool = false;
/*     */     
/* 362 */     String str3 = new String("");
/* 363 */     String str4 = new String("select @@identity as 'IDENTITY_VALUE'");
/* 364 */     String str5 = new String("select @@rowcount as 'ROWCOUNT_VALUE'");
/*     */ 
/*     */     
/* 367 */     if (this.instancesGroupID == -1) {
/*     */       
/* 369 */       bool = true;
/*     */       
/* 371 */       str3 = String.valueOf(str3) + "INSERT INTO " + getTableName() + 
/* 372 */         "          ( " + "InstancesGroupContentTypeID" + ", " + 
/* 373 */         "InstancesGroupListPageID" + ", " + 
/* 374 */         "InstancesGroupName" + ", " + 
/* 375 */         "InstancesGroupDescription" + ", " + 
/* 376 */         "InstancesGroupIsSingleton" + ", " + 
/* 377 */         "InstancesGroupIsListPageGenerated" + ", " + 
/* 378 */         "InstancesGroupIsInstanceGenerationEnabled" + 
/* 379 */         "          ) " + 
/* 380 */         "   VALUES (" + getContentTypeID() + ", " + 
/* 381 */         getListPageID() + ", '" + 
/* 382 */         getName() + "', '" + 
/* 383 */         getDescription() + "', '" + 
/* 384 */         getIsSingletonAsString() + "', '" + 
/* 385 */         getIsListPageGeneratedAsString() + "', '" + 
/* 386 */         getIsInstanceGenerationEnabledAsString() + "'" + 
/* 387 */         "          )";
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 392 */       str3 = String.valueOf(str3) + "UPDATE " + getTableName() + 
/* 393 */         "   SET " + "InstancesGroupContentTypeID" + "=" + getContentTypeID() + ", " + 
/* 394 */         "InstancesGroupListPageID" + "=" + getListPageID() + ", " + 
/* 395 */         "InstancesGroupName" + "='" + getName() + "'," + 
/* 396 */         "InstancesGroupDescription" + "='" + getDescription() + "'," + 
/* 397 */         "InstancesGroupIsSingleton" + "='" + getIsSingletonAsString() + "'," + 
/* 398 */         "InstancesGroupIsListPageGenerated" + "='" + getIsListPageGeneratedAsString() + "'," + 
/* 399 */         "InstancesGroupIsInstanceGenerationEnabled" + "='" + getIsInstanceGenerationEnabledAsString() + "'";
/*     */ 
/*     */       
/* 402 */       str3 = String.valueOf(str3) + " WHERE " + getIdentityColumnName() + "=" + getID();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 408 */     if (bool) {
/* 409 */       str3 = String.valueOf(str3) + "; " + str4;
/*     */     } else {
/* 411 */       str3 = String.valueOf(str3) + "; " + str5;
/*     */     } 
/*     */     
/* 414 */     str3 = "BEGIN TRAN; " + str3 + "; " + "COMMIT TRAN";
/*     */     
/* 416 */     System.out.println("Running sql stmt:\n" + str3);
/*     */ 
/*     */     
/* 419 */     paramDatabaseConnector.setQuery(str3);
/* 420 */     paramDatabaseConnector.runQuery();
/*     */ 
/*     */     
/* 423 */     if (paramDatabaseConnector.more()) {
/*     */       
/* 425 */       paramDatabaseConnector.first();
/*     */ 
/*     */ 
/*     */       
/* 429 */       if (bool) {
/* 430 */         int j = paramDatabaseConnector.getInt("IDENTITY_VALUE", -1);
/*     */       }
/* 432 */       int i = paramDatabaseConnector.getInt("ROWCOUNT_VALUE", -1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 445 */     paramDatabaseConnector.close();
/*     */     
/* 447 */     return -1;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstancesGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */