package com.techempower.gemini.fornax;

import com.techempower.DataEntity;
import com.techempower.DatabaseConnector;
import java.util.Hashtable;

public class FornaxContentTypeInstancesGroup extends DataEntity implements FornaxConstants, FornaxDBConstants {
  protected int instancesGroupID = -1;
  
  protected int instancesGroupContentTypeID = -1;
  
  protected int instancesGroupListPageID = -1;
  
  protected String instancesGroupName = "";
  
  protected String instancesGroupDescription = "";
  
  protected boolean instancesGroupIsSingleton = false;
  
  protected boolean instancesGroupIsListPageGenerated = false;
  
  protected boolean instancesGroupIsInstanceGenerationEnabled = false;
  
  protected int instancesGroupInstancesCount = 0;
  
  public void initializationComplete() {}
  
  public Hashtable getCustomSetMethodBindings() {
    Hashtable hashtable = new Hashtable();
    hashtable.put("InstancesGroupID", "setID");
    hashtable.put("InstancesGroupContentTypeID", "setContentTypeID");
    hashtable.put("InstancesGroupListPageID", "setListPageID");
    hashtable.put("InstancesGroupName", "setName");
    hashtable.put("InstancesGroupDescription", "setDescription");
    hashtable.put("InstancesGroupIsSingleton", "setIsSingleton");
    hashtable.put("InstancesGroupIsListPageGenerated", "setIsListPageGenerated");
    hashtable.put("InstancesGroupIsInstanceGenerationEnabled", "setIsInstanceGenerationEnabled");
    hashtable.put("InstancesGroupInstancesCount", "setInstancesCount");
    return hashtable;
  }
  
  public int getIdentity() { return this.instancesGroupID; }
  
  public String getTableName() { return "fnContentTypeInstancesGroup"; }
  
  public String getIdentityColumnName() { return "InstancesGroupID"; }
  
  public int getID() { return this.instancesGroupID; }
  
  public int getContentTypeID() { return this.instancesGroupContentTypeID; }
  
  public int getListPageID() { return this.instancesGroupListPageID; }
  
  public String getName() { return this.instancesGroupName; }
  
  public String getDescription() { return this.instancesGroupDescription; }
  
  public boolean isSingleton() { return this.instancesGroupIsSingleton; }
  
  public String getIsSingletonAsString() {
    if (this.instancesGroupIsSingleton)
      return "T"; 
    return "F";
  }
  
  public boolean isListPageGenerated() { return this.instancesGroupIsListPageGenerated; }
  
  public String getIsListPageGeneratedAsString() {
    if (this.instancesGroupIsListPageGenerated)
      return "T"; 
    return "F";
  }
  
  public boolean isInstanceGenerationEnabled() { return this.instancesGroupIsInstanceGenerationEnabled; }
  
  public String getIsInstanceGenerationEnabledAsString() {
    if (this.instancesGroupIsInstanceGenerationEnabled)
      return "T"; 
    return "F";
  }
  
  public int getInstancesCount() { return this.instancesGroupInstancesCount; }
  
  public void setID(int paramInt) { this.instancesGroupID = paramInt; }
  
  public void setContentTypeID(int paramInt) { this.instancesGroupContentTypeID = paramInt; }
  
  public void setListPageID(int paramInt) { this.instancesGroupListPageID = paramInt; }
  
  public void setName(String paramString) {
    if (paramString != null)
      this.instancesGroupName = paramString; 
  }
  
  public void setDescription(String paramString) {
    if (paramString != null)
      this.instancesGroupDescription = paramString; 
  }
  
  public void setIsSingleton(String paramString) {
    this.instancesGroupIsSingleton = false;
    if (paramString.trim().equalsIgnoreCase("T"))
      this.instancesGroupIsSingleton = true; 
  }
  
  public void setIsListPageGenerated(String paramString) {
    this.instancesGroupIsListPageGenerated = false;
    if (paramString.trim().equalsIgnoreCase("T"))
      this.instancesGroupIsListPageGenerated = true; 
  }
  
  public void setIsInstanceGenerationEnabled(String paramString) {
    this.instancesGroupIsInstanceGenerationEnabled = false;
    if (paramString.trim().equalsIgnoreCase("T"))
      this.instancesGroupIsInstanceGenerationEnabled = true; 
  }
  
  public void setInstancesCount(int paramInt) { this.instancesGroupInstancesCount = paramInt; }
  
  public int runUpdate(DatabaseConnector paramDatabaseConnector) {
    String str1 = "IDENTITY_VALUE";
    String str2 = "ROWCOUNT_VALUE";
    boolean bool = false;
    String str3 = new String("");
    String str4 = new String("select @@identity as 'IDENTITY_VALUE'");
    String str5 = new String("select @@rowcount as 'ROWCOUNT_VALUE'");
    if (this.instancesGroupID == -1) {
      bool = true;
      str3 = String.valueOf(str3) + "INSERT INTO " + getTableName() + 
        "          ( " + "InstancesGroupContentTypeID" + ", " + 
        "InstancesGroupListPageID" + ", " + 
        "InstancesGroupName" + ", " + 
        "InstancesGroupDescription" + ", " + 
        "InstancesGroupIsSingleton" + ", " + 
        "InstancesGroupIsListPageGenerated" + ", " + 
        "InstancesGroupIsInstanceGenerationEnabled" + 
        "          ) " + 
        "   VALUES (" + getContentTypeID() + ", " + 
        getListPageID() + ", '" + 
        getName() + "', '" + 
        getDescription() + "', '" + 
        getIsSingletonAsString() + "', '" + 
        getIsListPageGeneratedAsString() + "', '" + 
        getIsInstanceGenerationEnabledAsString() + "'" + 
        "          )";
    } else {
      str3 = String.valueOf(str3) + "UPDATE " + getTableName() + 
        "   SET " + "InstancesGroupContentTypeID" + "=" + getContentTypeID() + ", " + 
        "InstancesGroupListPageID" + "=" + getListPageID() + ", " + 
        "InstancesGroupName" + "='" + getName() + "'," + 
        "InstancesGroupDescription" + "='" + getDescription() + "'," + 
        "InstancesGroupIsSingleton" + "='" + getIsSingletonAsString() + "'," + 
        "InstancesGroupIsListPageGenerated" + "='" + getIsListPageGeneratedAsString() + "'," + 
        "InstancesGroupIsInstanceGenerationEnabled" + "='" + getIsInstanceGenerationEnabledAsString() + "'";
      str3 = String.valueOf(str3) + " WHERE " + getIdentityColumnName() + "=" + getID();
    } 
    if (bool) {
      str3 = String.valueOf(str3) + "; " + str4;
    } else {
      str3 = String.valueOf(str3) + "; " + str5;
    } 
    str3 = "BEGIN TRAN; " + str3 + "; " + "COMMIT TRAN";
    System.out.println("Running sql stmt:\n" + str3);
    paramDatabaseConnector.setQuery(str3);
    paramDatabaseConnector.runQuery();
    if (paramDatabaseConnector.more()) {
      paramDatabaseConnector.first();
      if (bool)
        int j = paramDatabaseConnector.getInt("IDENTITY_VALUE", -1); 
      int i = paramDatabaseConnector.getInt("ROWCOUNT_VALUE", -1);
    } 
    paramDatabaseConnector.close();
    return -1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstancesGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */