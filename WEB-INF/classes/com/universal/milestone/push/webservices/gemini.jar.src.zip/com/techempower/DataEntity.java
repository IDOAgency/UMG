/*      */ package com.techempower;
/*      */ 
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class DataEntity
/*      */ {
/*      */   public static final int IDENTITY_NOT_RETURNED = -1;
/*      */   public static final int CANNOT_RUN_QUERY = -2;
/*      */   public static final String IDENTITY_RESULT_NAME = "Identity";
/*      */   public static final int ALT_SQL_TYPE_NCHAR = -8;
/*      */   public static final int ALT_SQL_TYPE_NVARCHAR = -9;
/*      */   public static final int KNOWN_SQL_TYPE_THRESHOLD = -10;
/*      */   protected boolean newDataEntity = true;
/*      */   
/*      */   public void initializeByMethods(DatabaseConnector paramDatabaseConnector) {
/*      */     try {
/*  112 */       Vector vector = getMethodMappingCache(paramDatabaseConnector);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  118 */       for (byte b = 0; b < vector.size(); b++) {
/*      */         
/*  120 */         DataFieldToMethodMap dataFieldToMethodMap = (DataFieldToMethodMap)vector.elementAt(b);
/*      */ 
/*      */         
/*  123 */         invokeMemberSetMethod(dataFieldToMethodMap.method, paramDatabaseConnector, dataFieldToMethodMap.fieldName, 
/*  124 */             dataFieldToMethodMap.fieldType);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  129 */       customInitialization(paramDatabaseConnector);
/*      */ 
/*      */       
/*  132 */       setNew(false);
/*      */ 
/*      */ 
/*      */       
/*  136 */       initializationComplete();
/*      */     }
/*  138 */     catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initializeByVariables(DatabaseConnector paramDatabaseConnector) {
/*      */     try {
/*  156 */       Vector vector = getFieldMappingCache(paramDatabaseConnector);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  162 */       for (byte b = 0; b < vector.size(); b++) {
/*      */         
/*  164 */         DataFieldToVariableMap dataFieldToVariableMap = (DataFieldToVariableMap)vector.elementAt(b);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  169 */         setMemberVariable(dataFieldToVariableMap.variable, paramDatabaseConnector, dataFieldToVariableMap.fieldName, 
/*  170 */             dataFieldToVariableMap.fieldType);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  175 */       customInitialization(paramDatabaseConnector);
/*      */ 
/*      */       
/*  178 */       setNew(false);
/*      */ 
/*      */ 
/*      */       
/*  182 */       initializationComplete();
/*      */     }
/*  184 */     catch (Exception exception) {
/*      */       
/*  186 */       System.out.println("DataEntity.initializeByVariables, exception: " + exception);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  206 */   public boolean isNew() { return this.newDataEntity; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  215 */   public void setNew(boolean paramBoolean) { this.newDataEntity = paramBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  229 */   public int getIdentity() { return 0; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  244 */   public String getTableName() { return null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  257 */   public String getIdentityColumnName() { return null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  278 */   public boolean useMethodsForUpdate() { return false; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  290 */   public Hashtable getCustomMethodBindings() { return getCustomSetMethodBindings(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  304 */   public Hashtable getCustomSetMethodBindings() { return null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  315 */   public Hashtable getCustomGetMethodBindings() { return null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  325 */   public Hashtable getCustomVariableBindings() { return null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  341 */   public String getUpdateSpName() { return null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int updateDatabase(DatabaseConnector paramDatabaseConnector) {
/*      */     Vector vector;
/*  377 */     String str1 = getUpdateSpName();
/*  378 */     String str2 = getTableName();
/*  379 */     String str3 = getIdentityColumnName();
/*      */     
/*  381 */     int i = getIdentity();
/*      */ 
/*      */     
/*  384 */     if (useMethodsForUpdate()) {
/*  385 */       vector = getGetMethodMappingCache();
/*      */     } else {
/*  387 */       vector = getFieldMappingCache(null);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  394 */     if (vector != null) {
/*      */ 
/*      */       
/*  397 */       StringBuffer stringBuffer = new StringBuffer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  403 */       if (str1 != null) {
/*      */         
/*  405 */         stringBuffer.append(str1);
/*  406 */         stringBuffer.append(' ');
/*      */         
/*  408 */         StringList stringList = new StringList(", ");
/*      */         
/*  410 */         for (byte b = 0; b < vector.size(); b++) {
/*      */           
/*  412 */           DataFieldToObjectEntityMap dataFieldToObjectEntityMap = (DataFieldToObjectEntityMap)vector.elementAt(b);
/*      */ 
/*      */           
/*      */           try {
/*      */             Object object;
/*      */             
/*  418 */             if (useMethodsForUpdate()) {
/*  419 */               object = invokeMemberGetMethod(((DataFieldToMethodMap)dataFieldToObjectEntityMap).method);
/*      */             } else {
/*  421 */               object = ((DataFieldToVariableMap)dataFieldToObjectEntityMap).variable.get(this);
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  426 */             if (object instanceof String) {
/*  427 */               stringList.add(BasicHelper.prepareString((String)object));
/*      */             } else {
/*  429 */               stringList.add(object.toString());
/*      */             } 
/*  431 */           } catch (IllegalAccessException illegalAccessException) {}
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  438 */         stringBuffer.append(stringList.toString());
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  443 */       else if (str2 != null && i == 0) {
/*      */         
/*  445 */         stringBuffer.append("INSERT INTO ");
/*  446 */         stringBuffer.append(str2);
/*      */         
/*  448 */         StringList stringList1 = new StringList(", ");
/*  449 */         StringList stringList2 = new StringList(", ");
/*      */         
/*  451 */         for (byte b = 0; b < vector.size(); b++) {
/*      */           
/*  453 */           DataFieldToObjectEntityMap dataFieldToObjectEntityMap = (DataFieldToObjectEntityMap)vector.elementAt(b);
/*      */ 
/*      */           
/*  456 */           if (!dataFieldToObjectEntityMap.fieldName.equals(str3)) {
/*      */             try {
/*      */               Object object;
/*      */ 
/*      */ 
/*      */               
/*  462 */               if (useMethodsForUpdate()) {
/*  463 */                 object = invokeMemberGetMethod(((DataFieldToMethodMap)dataFieldToObjectEntityMap).method);
/*      */               } else {
/*  465 */                 object = ((DataFieldToVariableMap)dataFieldToObjectEntityMap).variable.get(this);
/*      */               } 
/*      */               
/*  468 */               if (object != null) {
/*      */ 
/*      */                 
/*  471 */                 stringList1.add(dataFieldToObjectEntityMap.fieldName);
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  476 */                 if (object instanceof String) {
/*  477 */                   stringList2.add(BasicHelper.prepareString((String)object));
/*  478 */                 } else if (object instanceof java.sql.Date) {
/*  479 */                   stringList2.add("'" + object.toString() + "'");
/*  480 */                 } else if (object instanceof Date) {
/*      */                   
/*  482 */                   Date date = (Date)object;
/*  483 */                   Timestamp timestamp = new Timestamp(date.getTime());
/*  484 */                   stringList2.add("'" + timestamp.toString() + "'");
/*      */                 } else {
/*      */                   
/*  487 */                   stringList2.add(object.toString());
/*      */                 } 
/*      */               } 
/*  490 */             } catch (IllegalAccessException illegalAccessException) {}
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  498 */         stringBuffer.append(" (");
/*  499 */         stringBuffer.append(stringList1);
/*  500 */         stringBuffer.append(") VALUES (");
/*  501 */         stringBuffer.append(stringList2);
/*  502 */         stringBuffer.append(");");
/*      */ 
/*      */       
/*      */       }
/*  506 */       else if (str3 != null && str2 != null && i > 0) {
/*      */         
/*  508 */         stringBuffer.append("UPDATE ");
/*  509 */         stringBuffer.append(str2);
/*      */         
/*  511 */         StringList stringList = new StringList(", ");
/*      */         
/*  513 */         for (byte b = 0; b < vector.size(); b++) {
/*      */           
/*  515 */           DataFieldToObjectEntityMap dataFieldToObjectEntityMap = (DataFieldToObjectEntityMap)vector.elementAt(b);
/*      */ 
/*      */           
/*  518 */           if (!dataFieldToObjectEntityMap.fieldName.equals(str3)) {
/*      */             try {
/*      */               Object object;
/*      */ 
/*      */ 
/*      */               
/*  524 */               if (useMethodsForUpdate()) {
/*  525 */                 object = invokeMemberGetMethod(((DataFieldToMethodMap)dataFieldToObjectEntityMap).method);
/*      */               } else {
/*  527 */                 object = ((DataFieldToVariableMap)dataFieldToObjectEntityMap).variable.get(this);
/*      */               } 
/*      */               
/*  530 */               if (object != null)
/*      */               {
/*      */ 
/*      */ 
/*      */                 
/*  535 */                 if (object instanceof String) {
/*  536 */                   stringList.add(String.valueOf(dataFieldToObjectEntityMap.fieldName) + " = " + BasicHelper.prepareString((String)object));
/*  537 */                 } else if (object instanceof java.sql.Date) {
/*  538 */                   stringList.add(String.valueOf(dataFieldToObjectEntityMap.fieldName) + " = '" + object.toString() + "'");
/*  539 */                 } else if (object instanceof Date) {
/*      */                   
/*  541 */                   Date date = (Date)object;
/*  542 */                   Timestamp timestamp = new Timestamp(date.getTime());
/*  543 */                   stringList.add(String.valueOf(dataFieldToObjectEntityMap.fieldName) + " = '" + timestamp.toString() + "'");
/*      */                 } else {
/*      */                   
/*  546 */                   stringList.add(String.valueOf(dataFieldToObjectEntityMap.fieldName) + " = " + object.toString());
/*      */                 } 
/*      */               }
/*  549 */             } catch (IllegalAccessException illegalAccessException) {}
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  557 */         stringBuffer.append(" SET ");
/*  558 */         stringBuffer.append(stringList);
/*  559 */         stringBuffer.append(" WHERE (");
/*  560 */         stringBuffer.append(str3);
/*  561 */         stringBuffer.append(" = ");
/*  562 */         stringBuffer.append(i);
/*  563 */         stringBuffer.append(");");
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/*  572 */         System.out.println("DataEntity: Stored proc. and table names are null.  Cannot update.");
/*      */       } 
/*      */ 
/*      */       
/*  576 */       if (stringBuffer.length() > 0)
/*      */       {
/*      */         
/*  579 */         paramDatabaseConnector.setQuery(stringBuffer.toString());
/*      */         
/*  581 */         if (debugQueries()) {
/*  582 */           System.out.println("DataEntity updateDatabase query:\n" + stringBuffer);
/*      */         }
/*      */         
/*  585 */         paramDatabaseConnector.runQuery();
/*      */ 
/*      */         
/*  588 */         if (paramDatabaseConnector.more()) {
/*      */           
/*  590 */           int j = paramDatabaseConnector.getInt("Identity");
/*  591 */           paramDatabaseConnector.close();
/*      */           
/*  593 */           if (j > 0) {
/*  594 */             return j;
/*      */           }
/*      */         } else {
/*      */           
/*  598 */           paramDatabaseConnector.close();
/*      */         } 
/*      */         
/*  601 */         return -1;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  607 */       System.out.println("DataEntity: Field cache not ready for this class.  Cannot update.");
/*      */     } 
/*      */ 
/*      */     
/*  611 */     return -2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  628 */   protected boolean caseSensitiveBinding() { return false; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void customInitialization(DatabaseConnector paramDatabaseConnector) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initializationComplete() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Vector getFieldMappingCache(DatabaseConnector paramDatabaseConnector) {
/*  667 */     Vector vector = DataMappingCache.getFieldMappings(getClass());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  672 */     if (vector == null && paramDatabaseConnector != null) {
/*      */       
/*  674 */       buildFieldCache(paramDatabaseConnector);
/*  675 */       vector = DataMappingCache.getFieldMappings(getClass());
/*      */     } 
/*      */     
/*  678 */     return vector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Vector getMethodMappingCache(DatabaseConnector paramDatabaseConnector) {
/*  686 */     Vector vector = DataMappingCache.getSetMethodMappings(getClass());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  691 */     if (vector == null && paramDatabaseConnector != null) {
/*      */       
/*  693 */       buildMethodCache(paramDatabaseConnector);
/*  694 */       vector = DataMappingCache.getSetMethodMappings(getClass());
/*      */     } 
/*      */     
/*  697 */     return vector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  707 */   protected Vector getGetMethodMappingCache() { return DataMappingCache.getGetMethodMappings(getClass()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void buildMethodCache(DatabaseConnector paramDatabaseConnector) {
/*  720 */     Vector vector1 = new Vector();
/*  721 */     Vector vector2 = new Vector();
/*      */ 
/*      */     
/*  724 */     String[] arrayOfString = paramDatabaseConnector.getFieldNames();
/*  725 */     int[] arrayOfInt = paramDatabaseConnector.getFieldTypes();
/*      */ 
/*      */     
/*  728 */     Method[] arrayOfMethod = getClass().getMethods();
/*      */ 
/*      */     
/*  731 */     for (byte b = 0; b < arrayOfMethod.length; b++) {
/*      */ 
/*      */       
/*  734 */       for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/*      */         boolean bool;
/*      */ 
/*      */         
/*  738 */         if (caseSensitiveBinding()) {
/*  739 */           bool = arrayOfMethod[b].getName().equals("set" + arrayOfString[b1]);
/*      */         } else {
/*  741 */           bool = arrayOfMethod[b].getName().equalsIgnoreCase("set" + arrayOfString[b1]);
/*      */         } 
/*  743 */         if (bool)
/*      */         {
/*      */           
/*  746 */           vector1.addElement(new DataFieldToMethodMap(arrayOfMethod[b], 
/*  747 */                 arrayOfString[b1], arrayOfInt[b1]));
/*      */         }
/*      */ 
/*      */         
/*  751 */         if (caseSensitiveBinding()) {
/*  752 */           bool = arrayOfMethod[b].getName().equals("get" + arrayOfString[b1]);
/*      */         } else {
/*  754 */           bool = arrayOfMethod[b].getName().equalsIgnoreCase("get" + arrayOfString[b1]);
/*      */         } 
/*      */         
/*  757 */         if (!bool)
/*      */         {
/*  759 */           if (caseSensitiveBinding()) {
/*  760 */             bool = arrayOfMethod[b].getName().equals("is" + arrayOfString[b1]);
/*      */           } else {
/*  762 */             bool = arrayOfMethod[b].getName().equalsIgnoreCase("is" + arrayOfString[b1]);
/*      */           } 
/*      */         }
/*  765 */         if (bool)
/*      */         {
/*      */           
/*  768 */           vector2.addElement(new DataFieldToMethodMap(arrayOfMethod[b], 
/*  769 */                 arrayOfString[b1], arrayOfInt[b1]));
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  775 */     processCustomBindingsMap(vector1, arrayOfString, arrayOfInt, arrayOfMethod, 
/*  776 */         getCustomMethodBindings());
/*  777 */     processCustomBindingsMap(vector2, arrayOfString, arrayOfInt, arrayOfMethod, 
/*  778 */         getCustomGetMethodBindings());
/*      */ 
/*      */     
/*  781 */     DataMappingCache.putSetMethodMappings(getClass(), vector1);
/*  782 */     DataMappingCache.putGetMethodMappings(getClass(), vector2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void processCustomBindingsMap(Vector paramVector, String[] paramArrayOfString, int[] paramArrayOfInt, Method[] paramArrayOfMethod, Hashtable paramHashtable) {
/*  791 */     if (paramHashtable != null) {
/*      */       
/*  793 */       Enumeration enumeration = paramHashtable.keys();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  799 */       while (enumeration.hasMoreElements()) {
/*      */         
/*  801 */         int i = 0;
/*  802 */         String str2 = (String)enumeration.nextElement();
/*  803 */         String str1 = (String)paramHashtable.get(str2);
/*      */ 
/*      */         
/*  806 */         for (byte b = 0; b < paramArrayOfString.length; b++) {
/*      */           
/*  808 */           if (paramArrayOfString[b].equals(str2)) {
/*      */             
/*  810 */             i = paramArrayOfInt[b];
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */         
/*  816 */         if (i > -10)
/*      */         {
/*      */           
/*  819 */           for (byte b1 = 0; b1 < paramArrayOfMethod.length; b1++) {
/*      */             
/*  821 */             if (paramArrayOfMethod[b1].getName().equals(str1)) {
/*      */ 
/*      */               
/*  824 */               paramVector.addElement(new DataFieldToMethodMap(paramArrayOfMethod[b1], 
/*  825 */                     str2, i));
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void buildFieldCache(DatabaseConnector paramDatabaseConnector) {
/*  844 */     Vector vector1 = new Vector();
/*      */ 
/*      */     
/*  847 */     String[] arrayOfString = paramDatabaseConnector.getFieldNames();
/*  848 */     int[] arrayOfInt = paramDatabaseConnector.getFieldTypes();
/*      */ 
/*      */     
/*  851 */     Vector vector2 = new Vector();
/*  852 */     Class clazz = getClass();
/*  853 */     while (clazz != null) {
/*      */       
/*  855 */       Field[] arrayOfField = clazz.getDeclaredFields();
/*  856 */       for (byte b1 = 0; b1 < arrayOfField.length; b1++)
/*  857 */         vector2.addElement(arrayOfField[b1]); 
/*  858 */       clazz = clazz.getSuperclass();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  866 */     for (byte b = 0; b < vector2.size(); b++) {
/*      */       
/*  868 */       Field field = (Field)vector2.elementAt(b);
/*      */ 
/*      */       
/*  871 */       for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/*      */         boolean bool;
/*      */ 
/*      */         
/*  875 */         if (caseSensitiveBinding()) {
/*  876 */           bool = field.getName().equals(arrayOfString[b1]);
/*      */         } else {
/*  878 */           bool = field.getName().equalsIgnoreCase(arrayOfString[b1]);
/*      */         } 
/*  880 */         if (bool)
/*      */         {
/*      */           
/*  883 */           vector1.addElement(new DataFieldToVariableMap(field, 
/*  884 */                 arrayOfString[b1], arrayOfInt[b1]));
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  890 */     Hashtable hashtable = getCustomVariableBindings();
/*  891 */     if (hashtable != null) {
/*      */       
/*  893 */       Enumeration enumeration = hashtable.keys();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  898 */       while (enumeration.hasMoreElements()) {
/*      */         
/*  900 */         int i = 0;
/*  901 */         String str1 = (String)enumeration.nextElement();
/*  902 */         String str2 = (String)hashtable.get(str1);
/*      */ 
/*      */         
/*  905 */         for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/*      */           
/*  907 */           if (arrayOfString[b1].equals(str1)) {
/*      */             
/*  909 */             i = arrayOfInt[b1];
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */         
/*  915 */         if (i > -10)
/*      */         {
/*      */           
/*  918 */           for (byte b2 = 0; b2 < vector2.size(); b2++) {
/*      */             
/*  920 */             Field field = (Field)vector2.elementAt(b2);
/*      */             
/*  922 */             if (field.getName().equals(str2)) {
/*      */ 
/*      */ 
/*      */               
/*  926 */               vector1.addElement(new DataFieldToVariableMap(field, 
/*  927 */                     str1, i));
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  936 */     DataMappingCache.putFieldMappings(getClass(), vector1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void invokeMemberSetMethod(Method paramMethod, DatabaseConnector paramDatabaseConnector, String paramString, int paramInt) {
/*      */     try {
/*  953 */       if (paramInt == 4) {
/*      */         
/*  955 */         paramMethod.invoke(this, new Object[] { new Integer(paramDatabaseConnector.getInt(paramString)) });
/*      */       }
/*  957 */       else if (paramInt == -6) {
/*      */         
/*  959 */         paramMethod.invoke(this, new Object[] { new Byte(paramDatabaseConnector.getByte(paramString)) });
/*      */       }
/*  961 */       else if (paramInt == 5) {
/*      */         
/*  963 */         paramMethod.invoke(this, new Object[] { new Short(paramDatabaseConnector.getShort(paramString)) });
/*      */       }
/*  965 */       else if (paramInt == -5) {
/*      */         
/*  967 */         paramMethod.invoke(this, new Object[] { new Long(paramDatabaseConnector.getLong(paramString)) });
/*      */       }
/*  969 */       else if (paramInt == 8) {
/*      */         
/*  971 */         paramMethod.invoke(this, new Object[] { new Double(paramDatabaseConnector.getDouble(paramString)) });
/*      */       }
/*  973 */       else if (paramInt == 6) {
/*      */         
/*  975 */         paramMethod.invoke(this, new Object[] { new Float(paramDatabaseConnector.getFloat(paramString)) });
/*      */       }
/*  977 */       else if (paramInt == 2) {
/*      */         
/*  979 */         paramMethod.invoke(this, new Object[] { new Float(paramDatabaseConnector.getFloat(paramString)) });
/*      */       }
/*  981 */       else if (paramInt == -7) {
/*      */         
/*  983 */         paramMethod.invoke(this, new Object[] { new Boolean(paramDatabaseConnector.getBoolean(paramString)) });
/*      */       }
/*  985 */       else if (paramInt == 12 || 
/*  986 */         paramInt == 1 || 
/*  987 */         paramInt == -8 || 
/*  988 */         paramInt == -9) {
/*      */         
/*  990 */         paramMethod.invoke(this, new Object[] { paramDatabaseConnector.getFieldByName(paramString) });
/*      */       }
/*  992 */       else if (paramInt == 91 || 
/*  993 */         paramInt == 93) {
/*      */         
/*  995 */         Class[] arrayOfClass = paramMethod.getParameterTypes();
/*  996 */         if (arrayOfClass.length == 1) {
/*      */ 
/*      */           
/*  999 */           if (arrayOfClass[0].getName().indexOf("java.util.Calendar") > -1)
/*      */           {
/*      */ 
/*      */             
/* 1003 */             Calendar calendar = Calendar.getInstance();
/* 1004 */             calendar.setTime(paramDatabaseConnector.getDate(paramString));
/* 1005 */             paramMethod.invoke(this, new Object[] { calendar });
/*      */           }
/*      */           else
/*      */           {
/* 1009 */             paramMethod.invoke(this, new Object[] { paramDatabaseConnector.getDate(paramString) });
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 1014 */           System.out.println("DataEntity: method " + paramMethod.getName() + " does not take 1 parameter.");
/*      */         }
/*      */       
/*      */       } 
/* 1018 */     } catch (InvocationTargetException invocationTargetException) {
/*      */       
/* 1020 */       System.out.println("InvocationTargetException: " + invocationTargetException);
/*      */     }
/* 1022 */     catch (IllegalAccessException illegalAccessException) {
/*      */       
/* 1024 */       System.out.println("IllegalAccessException: " + illegalAccessException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object invokeMemberGetMethod(Method paramMethod) {
/*      */     try {
/* 1040 */       return paramMethod.invoke(this, new Object[0]);
/*      */     }
/* 1042 */     catch (InvocationTargetException invocationTargetException) {
/*      */       
/* 1044 */       System.out.println("InvocationTargetException: " + invocationTargetException);
/*      */     }
/* 1046 */     catch (IllegalAccessException illegalAccessException) {
/*      */       
/* 1048 */       System.out.println("IllegalAccessException: " + illegalAccessException);
/*      */     } 
/*      */     
/* 1051 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setMemberVariable(Field paramField, DatabaseConnector paramDatabaseConnector, String paramString, int paramInt) {
/*      */     try {
/* 1069 */       if (paramInt == 4) {
/*      */         
/* 1071 */         paramField.set(this, new Integer(paramDatabaseConnector.getInt(paramString)));
/*      */       }
/* 1073 */       else if (paramInt == -6) {
/*      */         
/* 1075 */         paramField.set(this, new Byte(paramDatabaseConnector.getByte(paramString)));
/*      */       }
/* 1077 */       else if (paramInt == 5) {
/*      */         
/* 1079 */         paramField.set(this, new Short(paramDatabaseConnector.getShort(paramString)));
/*      */       }
/* 1081 */       else if (paramInt == -5) {
/*      */         
/* 1083 */         paramField.set(this, new Long(paramDatabaseConnector.getLong(paramString)));
/*      */       }
/* 1085 */       else if (paramInt == 8) {
/*      */         
/* 1087 */         paramField.set(this, new Double(paramDatabaseConnector.getDouble(paramString)));
/*      */       }
/* 1089 */       else if (paramInt == 6) {
/*      */         
/* 1091 */         paramField.set(this, new Float(paramDatabaseConnector.getFloat(paramString)));
/*      */       }
/* 1093 */       else if (paramInt == 2) {
/*      */         
/* 1095 */         paramField.set(this, new Float(paramDatabaseConnector.getFloat(paramString)));
/*      */       }
/* 1097 */       else if (paramInt == -7) {
/*      */         
/* 1099 */         paramField.set(this, new Boolean(paramDatabaseConnector.getBoolean(paramString)));
/*      */       }
/* 1101 */       else if (paramInt == 12 || 
/* 1102 */         paramInt == 1 || 
/* 1103 */         paramInt == -8 || 
/* 1104 */         paramInt == -9) {
/*      */         
/* 1106 */         paramField.set(this, paramDatabaseConnector.getFieldByName(paramString));
/*      */       }
/* 1108 */       else if (paramInt == 91 || 
/* 1109 */         paramInt == 93) {
/*      */         
/* 1111 */         if (paramField.getType().getName().indexOf("java.util.Calendar") > -1)
/*      */         {
/*      */ 
/*      */           
/* 1115 */           Calendar calendar = Calendar.getInstance();
/* 1116 */           calendar.setTime(paramDatabaseConnector.getDate(paramString));
/* 1117 */           paramField.set(this, calendar);
/*      */         }
/*      */         else
/*      */         {
/* 1121 */           paramField.set(this, paramDatabaseConnector.getDate(paramString));
/*      */         }
/*      */       
/*      */       } 
/* 1125 */     } catch (IllegalAccessException illegalAccessException) {
/*      */       
/* 1127 */       System.out.println("IllegalAccessException: " + illegalAccessException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1138 */   public boolean debugQueries() { return false; }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\DataEntity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */