/*     */ package com.techempower.gemini;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormFloatField
/*     */   extends FormTextField
/*     */ {
/*     */   public static final int DEFAULT_TEXT_LENGTH = 10;
/*     */   public static final float DEFAULT_MINIMUM = 0.0F;
/*     */   public static final float DEFAULT_MAXIMUM = 10000.0F;
/*  47 */   protected float min = 0.0F;
/*  48 */   protected float max = 10000.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormFloatField(String paramString1, String paramString2, boolean paramBoolean, float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
/*  67 */     super(paramString1, paramString2, paramBoolean, paramInt1, paramInt2);
/*  68 */     setMinimum(paramFloat1);
/*  69 */     setMaximum(paramFloat2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public FormFloatField(String paramString1, String paramString2, boolean paramBoolean, float paramFloat1, float paramFloat2, int paramInt) { this(paramString1, paramString2, paramBoolean, paramFloat1, paramFloat2, paramInt, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public FormFloatField(String paramString1, String paramString2, boolean paramBoolean, float paramFloat1, float paramFloat2) { this(paramString1, paramString2, paramBoolean, paramFloat1, paramFloat2, 10); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public FormFloatField(String paramString1, String paramString2, float paramFloat1, float paramFloat2) { this(paramString1, paramString2, false, paramFloat1, paramFloat2, 10); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public FormFloatField(String paramString, float paramFloat1, float paramFloat2) { this(paramString, "", false, paramFloat1, paramFloat2, 10); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormFloatField(String paramString) {
/* 111 */     this(paramString, "", false, 0.0F, 10000.0F, 
/* 112 */         10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public void setMinimum(float paramFloat) { this.min = paramFloat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public float getMinimum() { return this.min; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public void setMaximum(float paramFloat) { this.max = paramFloat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public float getMaximum() { return this.max; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloatValue() {
/*     */     try {
/* 155 */       return Float.parseFloat(getValue());
/*     */     
/*     */     }
/* 158 */     catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 164 */       return 0.0F;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public int getIntegerValue() { return (int)getFloatValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
/* 182 */     super.requiredValidation(paramFormSingleValidation);
/* 183 */     if (!paramFormSingleValidation.isSet()) {
/*     */       
/* 185 */       float f = getFloatValue();
/*     */       
/* 187 */       if (f < getMinimum()) {
/*     */         
/* 189 */         paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is lower than " + getMinimum() + ".", 
/* 190 */             String.valueOf(getDisplayName()) + " cannot be lower than " + getMinimum() + ".", 
/* 191 */             "The field's value cannot be less than " + getMinimum() + ".");
/*     */       }
/* 193 */       else if (f > getMaximum()) {
/*     */         
/* 195 */         paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is higher than " + getMaximum() + ".", 
/* 196 */             String.valueOf(getDisplayName()) + " cannot be higher than " + getMaximum() + ".", 
/* 197 */             "The field's value cannot be less than " + getMinimum() + ".");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormFloatField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */