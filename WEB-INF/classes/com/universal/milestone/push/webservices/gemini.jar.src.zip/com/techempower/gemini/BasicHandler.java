package com.techempower.gemini;

public class BasicHandler implements Handler {
  public String getDescription() { return "Basic"; }
  
  public boolean acceptRequest(Dispatcher paramDispatcher, Context paramContext, String paramString) { return handleRequest(paramDispatcher, paramContext, paramString); }
  
  public boolean handleRequest(Dispatcher paramDispatcher, Context paramContext, String paramString) {
    paramContext.print("Basic handler received request.");
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\BasicHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */