/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.EnhancedProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmailServicer
/*     */ {
/*     */   public static final String COMPONENT_CODE = "emsv";
/*     */   public static final int DEFAULT_SERVICER_THREADS = 5;
/*     */   protected GeminiApplication application;
/*     */   protected ComponentLog log;
/*     */   protected int threadCount;
/*     */   protected EmailServicerThread[] threads;
/*     */   protected boolean initialConf;
/*     */   
/*     */   public EmailServicer(GeminiApplication paramGeminiApplication) {
/*  50 */     this.threadCount = 5;
/*     */     
/*  52 */     this.initialConf = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     this.application = paramGeminiApplication;
/*  65 */     this.log = paramGeminiApplication.getLog("emsv");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(EnhancedProperties paramEnhancedProperties) {
/*  73 */     this.threadCount = paramEnhancedProperties.getIntegerProperty("EmailerThreads", this.threadCount);
/*     */ 
/*     */ 
/*     */     
/*  77 */     if (!this.initialConf || this.threads.length != this.threadCount) {
/*     */ 
/*     */       
/*  80 */       this.initialConf = true;
/*     */ 
/*     */       
/*  83 */       EmailServicerThread[] arrayOfEmailServicerThread = new EmailServicerThread[this.threadCount];
/*     */ 
/*     */       
/*  86 */       for (byte b = 0; b < arrayOfEmailServicerThread.length; b++) {
/*     */         
/*  88 */         if (this.threads != null && 
/*  89 */           b < this.threads.length && 
/*  90 */           this.threads[b] != null) {
/*     */ 
/*     */           
/*  93 */           arrayOfEmailServicerThread[b] = this.threads[b];
/*     */         }
/*     */         else {
/*     */           
/*  97 */           arrayOfEmailServicerThread[b] = new EmailServicerThread(b, this.application);
/*  98 */           arrayOfEmailServicerThread[b].start();
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 103 */       if (this.threads != null)
/*     */       {
/* 105 */         for (int i = arrayOfEmailServicerThread.length; i < this.threads.length; i++)
/*     */         {
/* 107 */           this.threads[i].setKeepRunning(false);
/*     */         }
/*     */       }
/*     */ 
/*     */       
/* 112 */       this.threads = arrayOfEmailServicerThread;
/*     */       
/* 114 */       this.log.log(String.valueOf(this.threadCount) + " threads created for outgoing e-mail delivery.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public int getThreads() { return this.threadCount; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBusyThreads() {
/* 131 */     byte b1 = 0;
/*     */     
/* 133 */     for (byte b2 = 0; b2 < this.threads.length; b2++) {
/*     */       
/* 135 */       if (this.threads[b2].getBacklog() > 0) {
/* 136 */         b1++;
/*     */       }
/*     */     } 
/* 139 */     return b1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBacklog() {
/* 147 */     int i = 0;
/*     */     
/* 149 */     for (byte b = 0; b < this.threads.length; b++)
/*     */     {
/* 151 */       i += this.threads[b].getBacklog();
/*     */     }
/*     */     
/* 154 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendMail(EmailPackage paramEmailPackage) {
/*     */     try {
/* 167 */       byte b1 = 0;
/* 168 */       int i = this.threads[b1].getBacklog();
/*     */ 
/*     */       
/* 171 */       for (byte b2 = 1; b2 < this.threads.length; b2++) {
/*     */         
/* 173 */         if (this.threads[b2].getBacklog() < i) {
/*     */           
/* 175 */           b1 = b2;
/* 176 */           i = this.threads[b1].getBacklog();
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 181 */       if (this.threads[b1].queueMail(paramEmailPackage) == false) {
/* 182 */         this.log.debug("Could not queue mail.");
/*     */       }
/* 184 */     } catch (Exception exception) {
/*     */       
/* 186 */       this.log.debug("Exception while queuing mail: " + exception);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\EmailServicer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */