/*     */ package com.techempower;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConsoleThreadKiller
/*     */   extends Thread
/*     */ {
/*     */   public static final String COMPONENT_CODE = "ctkl";
/*     */   protected ThreadGroup threadGroup;
/*  41 */   protected byte[] buffer = new byte[1024];
/*  42 */   protected Thread[] list = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ComponentLog log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConsoleThreadKiller(TechEmpowerApplication paramTechEmpowerApplication) {
/*  54 */     super("ConsoleThreadKiller");
/*     */ 
/*     */     
/*  57 */     setDaemon(true);
/*     */ 
/*     */     
/*  60 */     this.log = paramTechEmpowerApplication.getLog("ctkl");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public ConsoleThreadKiller() { this(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  77 */     this.threadGroup = getThreadGroup();
/*  78 */     while (this.threadGroup.getParent() != null) {
/*  79 */       this.threadGroup = this.threadGroup.getParent();
/*     */     }
/*     */     
/*  82 */     setPriority(10);
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/*     */       try {
/*  88 */         if (System.in.available() > 0)
/*     */         {
/*  90 */           int i = System.in.read(this.buffer);
/*  91 */           String str = new String(this.buffer, 0, i - 2);
/*     */           
/*  93 */           processCommand(str);
/*     */         }
/*     */       
/*  96 */       } catch (IOException iOException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 104 */         Thread.yield();
/* 105 */         Thread.sleep(200L);
/*     */       }
/* 107 */       catch (InterruptedException interruptedException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processCommand(String paramString) {
/* 118 */     if (paramString.startsWith("l")) {
/*     */       
/* 120 */       this.log.debug("Thread list:");
/* 121 */       updateActiveThreads();
/* 122 */       listThreads();
/*     */     }
/* 124 */     else if (paramString.startsWith("k")) {
/*     */ 
/*     */       
/*     */       try {
/* 128 */         String str = paramString.substring(1);
/* 129 */         int i = Integer.parseInt(str);
/*     */         
/* 131 */         Thread thread = this.list[i];
/* 132 */         if (thread == this)
/*     */         {
/* 134 */           this.log.debug("Cannot kill the thread-killer!");
/*     */         }
/* 136 */         else if (thread != null)
/*     */         {
/* 138 */           this.log.debug("Stopping thread: " + thread);
/* 139 */           thread.stop();
/* 140 */           this.log.debug("Thread stopped.");
/*     */           
/* 142 */           updateActiveThreads();
/* 143 */           listThreads();
/*     */         }
/*     */         else
/*     */         {
/* 147 */           this.log.debug("Not a valid thread number.");
/*     */         }
/*     */       
/* 150 */       } catch (Exception exception) {
/*     */         
/* 152 */         this.log.debug("Not a valid thread number or could not stop thread.");
/* 153 */         this.log.debug("Exception: " + exception);
/*     */       }
/*     */     
/* 156 */     } else if (paramString.startsWith("f")) {
/*     */       
/* 158 */       this.log.debug("Thread list flushed.");
/* 159 */       this.list = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateActiveThreads() {
/* 168 */     int i = this.threadGroup.activeCount();
/* 169 */     this.list = new Thread[i];
/* 170 */     this.threadGroup.enumerate(this.list, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void listThreads() {
/* 178 */     for (byte b = 0; b < this.list.length; b++) {
/*     */       
/* 180 */       if (this.list[b] != null)
/*     */       {
/* 182 */         this.log.debug("thd. " + b + ": " + this.list[b]);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   public String toString() { return "ConsoleThreadKiller"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 200 */     ConsoleThreadKiller consoleThreadKiller = new ConsoleThreadKiller();
/* 201 */     consoleThreadKiller.start();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\ConsoleThreadKiller.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */