package com.techempower.gemini;

import com.techempower.BasicHelper;
import java.util.StringTokenizer;
import java.util.Vector;

public class FormDropDownMenu extends FormElement {
  public static final String DEFAULT_VALUES = "";
  
  public static final String DEFAULT_SELECTION = "";
  
  protected String selection;
  
  protected Vector values;
  
  protected Vector menuText;
  
  protected String startingSelection;
  
  protected String onChangeAction;
  
  public FormDropDownMenu(String paramString1, String paramString2, String[] paramArrayOfString1, String[] paramArrayOfString2, boolean paramBoolean) {
    super(paramString1, paramString2, paramBoolean);
    setMenuTextList(paramArrayOfString2);
    setValueList(paramArrayOfString1);
  }
  
  public FormDropDownMenu(String paramString1, String paramString2, Integer[] paramArrayOfInteger, String[] paramArrayOfString, boolean paramBoolean) {
    super(paramString1, paramString2, paramBoolean);
    setMenuTextList(paramArrayOfString);
    setValueList(paramArrayOfInteger);
  }
  
  public FormDropDownMenu(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean) {
    super(paramString1, paramString2, paramBoolean);
    setMenuTextList(paramString4);
    setValueList(paramString3);
  }
  
  public FormDropDownMenu(String paramString1, String paramString2, String[] paramArrayOfString, boolean paramBoolean) { this(paramString1, paramString2, paramArrayOfString, paramArrayOfString, paramBoolean); }
  
  public FormDropDownMenu(String paramString1, String paramString2, String paramString3, boolean paramBoolean) { this(paramString1, paramString2, paramString3, paramString3, paramBoolean); }
  
  public FormDropDownMenu(String paramString1, String paramString2, boolean paramBoolean) { this(paramString1, "", paramString2, paramBoolean); }
  
  public FormDropDownMenu(String paramString, String[] paramArrayOfString, boolean paramBoolean) { this(paramString, "", paramArrayOfString, paramBoolean); }
  
  public FormDropDownMenu(String paramString1, String paramString2) { this(paramString1, "", paramString2, false); }
  
  public FormDropDownMenu(String paramString) { this(paramString, "", "", false); }
  
  public void setValue(String paramString) {
    if (!isReadOnly())
      this.selection = paramString; 
  }
  
  public void setValueList(String paramString) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, ",");
    int i = stringTokenizer.countTokens();
    boolean bool = false;
    this.values = new Vector(i);
    while (stringTokenizer.hasMoreTokens())
      this.values.addElement(stringTokenizer.nextToken().trim()); 
  }
  
  public void setValueList(String[] paramArrayOfString) {
    this.values = new Vector(paramArrayOfString.length);
    for (byte b = 0; b < paramArrayOfString.length; b++)
      this.values.addElement(paramArrayOfString[b]); 
  }
  
  public void setValueList(Integer[] paramArrayOfInteger) {
    this.values = new Vector(paramArrayOfInteger.length);
    for (byte b = 0; b < paramArrayOfInteger.length; b++)
      this.values.addElement(paramArrayOfInteger[b].toString()); 
  }
  
  public void appendOption(String paramString1, String paramString2) {
    this.values.addElement(paramString1);
    if (paramString2 != null) {
      this.menuText.addElement(paramString2);
    } else {
      this.menuText.addElement(paramString1);
    } 
  }
  
  public void setStartingValue(String paramString) { this.startingSelection = paramString; }
  
  public String getStartingValue() { return this.startingSelection; }
  
  public void setValue(Context paramContext) { setValue(paramContext.getRequestValue(getName(), this.selection)); }
  
  protected String getValue() { return this.selection; }
  
  public String getAction() { return this.onChangeAction; }
  
  public String getStringValue() { return getValue(); }
  
  public int getIntegerValue() {
    try {
      return Integer.parseInt(getValue());
    } catch (NumberFormatException numberFormatException) {
      return 0;
    } 
  }
  
  public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
  
  public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
  
  public String[] getValueList() {
    null = new String[this.values.size()];
    return (String[])this.values.toArray(null);
  }
  
  public Vector getValuesVector() { return this.values; }
  
  public String render() {
    String str = " ";
    if (getAction() != null)
      str = " onChange=\"" + getAction() + "\" "; 
    StringBuffer stringBuffer = new StringBuffer(100);
    stringBuffer.append("<select name=\"");
    stringBuffer.append(getName());
    stringBuffer.append('"');
    stringBuffer.append(getTabIndex());
    stringBuffer.append(getFormEvents());
    stringBuffer.append(getEnabledString());
    stringBuffer.append(getId());
    stringBuffer.append(getClassName());
    stringBuffer.append(str);
    stringBuffer.append('>');
    for (byte b = 0; b < this.values.size(); b++) {
      String str1 = (String)this.values.elementAt(b);
      stringBuffer.append("<option value=\"");
      stringBuffer.append(str1);
      stringBuffer.append('"');
      if (str1.equals(getStringValue()))
        stringBuffer.append(" selected"); 
      stringBuffer.append('>');
      stringBuffer.append(this.menuText.elementAt(b));
    } 
    stringBuffer.append("</select>");
    return stringBuffer.toString();
  }
  
  public FormSingleValidation validate() {
    FormSingleValidation formSingleValidation = new FormSingleValidation(this);
    if (isRequired())
      requiredValidation(formSingleValidation); 
    customValidation(formSingleValidation);
    return formSingleValidation;
  }
  
  protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
    if (getStringValue().length() == 0)
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is unselected.", 
          "Please select a value from the dropdown menu named " + getDisplayName() + ".", 
          "This dropdown requires a value to be selected"); 
  }
  
  public boolean isDefault() { return "".equals(getValue()); }
  
  public boolean isUnchanged() { return this.startingSelection.equals(getValue()); }
  
  public void setMenuTextList(String paramString) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, ",");
    int i = stringTokenizer.countTokens();
    boolean bool = false;
    this.menuText = new Vector(i);
    while (stringTokenizer.hasMoreTokens())
      this.menuText.addElement(stringTokenizer.nextToken().trim()); 
  }
  
  public void setMenuTextList(String[] paramArrayOfString) {
    this.menuText = new Vector(paramArrayOfString.length);
    for (byte b = 0; b < paramArrayOfString.length; b++)
      this.menuText.addElement(paramArrayOfString[b]); 
  }
  
  public String[] getMenuTextList() {
    null = new String[this.menuText.size()];
    return (String[])this.menuText.toArray(null);
  }
  
  public void setAction(String paramString) { this.onChangeAction = paramString; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormDropDownMenu.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */