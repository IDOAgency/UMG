package com.techempower.gemini;

public class FormIntegerField extends FormTextField {
  public static final int DEFAULT_TEXT_LENGTH = 10;
  
  public static final int DEFAULT_MINIMUM = 0;
  
  public static final int DEFAULT_MAXIMUM = 10000;
  
  protected int min = 0;
  
  protected int max = 10000;
  
  public FormIntegerField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramString1, paramString2, paramBoolean, paramInt3, paramInt4);
    setMinimum(paramInt1);
    setMaximum(paramInt2);
  }
  
  public FormIntegerField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) { this(paramString1, paramString2, paramBoolean, paramInt1, paramInt2, paramInt3, paramInt3); }
  
  public FormIntegerField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2) { this(paramString1, paramString2, paramBoolean, paramInt1, paramInt2, 10); }
  
  public FormIntegerField(String paramString1, String paramString2, int paramInt1, int paramInt2) { this(paramString1, paramString2, false, paramInt1, paramInt2, 10); }
  
  public FormIntegerField(String paramString, int paramInt1, int paramInt2) { this(paramString, "", false, paramInt1, paramInt2, 10); }
  
  public FormIntegerField(String paramString) { this(paramString, "", false, 0, 10000, 10); }
  
  public void setMinimum(int paramInt) { this.min = paramInt; }
  
  public int getMinimum() { return this.min; }
  
  public void setMaximum(int paramInt) { this.max = paramInt; }
  
  public int getMaximum() { return this.max; }
  
  public int getIntegerValue() {
    try {
      return Integer.parseInt(getValue());
    } catch (NumberFormatException numberFormatException) {
      return 0;
    } 
  }
  
  protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
    super.requiredValidation(paramFormSingleValidation);
    if (!paramFormSingleValidation.isSet())
      if (getIntegerValue() < getMinimum()) {
        paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is lower than " + getMinimum() + ".", 
            String.valueOf(getDisplayName()) + " cannot be lower than " + getMinimum() + ".", 
            "The field's value cannot be less than " + getMinimum() + ".");
      } else if (getIntegerValue() > getMaximum()) {
        paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is higher than " + getMaximum() + ".", 
            String.valueOf(getDisplayName()) + " cannot be higher than " + getMaximum() + ".", 
            "The field's value cannot be greater than " + getMinimum() + ".");
      }  
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormIntegerField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */