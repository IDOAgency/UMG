/*     */ package com.techempower.gemini;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormIntegerField
/*     */   extends FormTextField
/*     */ {
/*     */   public static final int DEFAULT_TEXT_LENGTH = 10;
/*     */   public static final int DEFAULT_MINIMUM = 0;
/*     */   public static final int DEFAULT_MAXIMUM = 10000;
/*  46 */   protected int min = 0;
/*  47 */   protected int max = 10000;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormIntegerField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  66 */     super(paramString1, paramString2, paramBoolean, paramInt3, paramInt4);
/*  67 */     setMinimum(paramInt1);
/*  68 */     setMaximum(paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public FormIntegerField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) { this(paramString1, paramString2, paramBoolean, paramInt1, paramInt2, paramInt3, paramInt3); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public FormIntegerField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2) { this(paramString1, paramString2, paramBoolean, paramInt1, paramInt2, 10); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public FormIntegerField(String paramString1, String paramString2, int paramInt1, int paramInt2) { this(paramString1, paramString2, false, paramInt1, paramInt2, 10); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public FormIntegerField(String paramString, int paramInt1, int paramInt2) { this(paramString, "", false, paramInt1, paramInt2, 10); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public FormIntegerField(String paramString) { this(paramString, "", false, 0, 10000, 10); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public void setMinimum(int paramInt) { this.min = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public int getMinimum() { return this.min; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   public void setMaximum(int paramInt) { this.max = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   public int getMaximum() { return this.max; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntegerValue() {
/*     */     try {
/* 154 */       return Integer.parseInt(getValue());
/*     */     
/*     */     }
/* 157 */     catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 163 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
/* 171 */     super.requiredValidation(paramFormSingleValidation);
/* 172 */     if (!paramFormSingleValidation.isSet())
/*     */     {
/* 174 */       if (getIntegerValue() < getMinimum()) {
/*     */         
/* 176 */         paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is lower than " + getMinimum() + ".", 
/* 177 */             String.valueOf(getDisplayName()) + " cannot be lower than " + getMinimum() + ".", 
/* 178 */             "The field's value cannot be less than " + getMinimum() + ".");
/*     */       }
/* 180 */       else if (getIntegerValue() > getMaximum()) {
/*     */         
/* 182 */         paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is higher than " + getMaximum() + ".", 
/* 183 */             String.valueOf(getDisplayName()) + " cannot be higher than " + getMaximum() + ".", 
/* 184 */             "The field's value cannot be greater than " + getMinimum() + ".");
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormIntegerField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */