package com.techempower.gemini.fornax;

import com.techempower.SimpleDate;
import java.io.File;

public class ReportManager {
  protected Report mReport;
  
  public ReportManager(FornaxSettings paramFornaxSettings) {
    String str1 = paramFornaxSettings.getGenerationLogDir();
    String str2 = ".html";
    SimpleDate simpleDate = new SimpleDate();
    String str3 = String.valueOf(str1) + "report-" + simpleDate + str2;
    this.mReport = new Report(new File(str3), paramFornaxSettings);
  }
  
  public Report getReport() { return this.mReport; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\ReportManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */