/*    */ package com.techempower.gemini.fornax;
/*    */ 
/*    */ import com.techempower.SimpleDate;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReportManager
/*    */ {
/*    */   protected Report mReport;
/*    */   
/*    */   public ReportManager(FornaxSettings paramFornaxSettings) {
/* 38 */     String str1 = paramFornaxSettings.getGenerationLogDir();
/* 39 */     String str2 = ".html";
/* 40 */     SimpleDate simpleDate = new SimpleDate();
/* 41 */     String str3 = String.valueOf(str1) + "report-" + simpleDate + str2;
/*    */     
/* 43 */     this.mReport = new Report(new File(str3), paramFornaxSettings);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public Report getReport() { return this.mReport; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\ReportManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */