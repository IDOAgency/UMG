/*      */ package com.techempower.gemini;
/*      */ 
/*      */ import com.techempower.ComponentLog;
/*      */ import java.io.IOException;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ import javax.servlet.RequestDispatcher;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.http.Cookie;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.HttpSession;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Context
/*      */ {
/*      */   public static final String COMPONENT_CODE = "ctxt";
/*      */   protected GeminiApplication application;
/*      */   protected ComponentLog log;
/*      */   protected BasicInfrastructure infrastructure;
/*      */   protected HttpServletRequest request;
/*      */   protected HttpServletResponse response;
/*      */   protected HttpSession session;
/*      */   protected ServletContext servletContext;
/*      */   protected Hashtable deliveries;
/*      */   protected String referencedJSP;
/*      */   protected Dispatcher dispatcher;
/*      */   protected boolean newSession;
/*      */   protected int dispatches;
/*      */   protected String command;
/*      */   
/*      */   public Context(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, ServletContext paramServletContext, Dispatcher paramDispatcher) {
/*   83 */     this.referencedJSP = null;
/*      */     
/*   85 */     this.newSession = false;
/*   86 */     this.dispatches = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  105 */     this.request = paramHttpServletRequest;
/*  106 */     this.response = paramHttpServletResponse;
/*  107 */     this.servletContext = paramServletContext;
/*  108 */     this.dispatcher = paramDispatcher;
/*  109 */     this.command = null;
/*      */ 
/*      */     
/*  112 */     this.application = getApplication();
/*  113 */     this.infrastructure = this.application.getInfrastructure();
/*      */ 
/*      */     
/*  116 */     this.log = this.application.getLog("ctxt");
/*      */ 
/*      */     
/*  119 */     paramHttpServletRequest.setAttribute("Context", this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  125 */     this.session = this.application.getSessionManager().getSession(paramHttpServletRequest);
/*  126 */     this.newSession = this.session.isNew();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void displaySessionInfo() {
/*  139 */     this.log.debug("Session: " + this.session);
/*  140 */     this.log.debug("Session.isNew: " + this.session.isNew());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void displayAllRequestHeaders() {
/*  149 */     Enumeration enumeration = this.request.getHeaderNames();
/*  150 */     while (enumeration.hasMoreElements()) {
/*      */       
/*  152 */       String str = (String)enumeration.nextElement();
/*  153 */       this.log.debug(String.valueOf(str) + " = " + this.request.getHeader(str));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  162 */   public String toString() { return "Context [" + getClientIP() + "]"; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  170 */   public String getSessionDescription() { return "session timeout: " + this.session.getMaxInactiveInterval() + "s"; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  179 */   public GeminiApplication getApplication() { return GeminiApplication.getInstance(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  187 */   public BasicInfrastructure getInfrastructure() { return this.infrastructure; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  195 */   public int getDispatches() { return this.dispatches; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  203 */   public void incrementDispatches() { this.dispatches++; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  211 */   public String getCommand() { return this.command; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  222 */   public void setCommand(String paramString) { this.command = paramString; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String gatherCommand() {
/*  232 */     this.command = getRequestValue(this.dispatcher.getCommandParameterName(), 
/*  233 */         this.dispatcher.getDefaultCommand());
/*      */     
/*  235 */     return this.command;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void putDelivery(String paramString, Object paramObject) {
/*  249 */     if (this.deliveries == null) {
/*  250 */       this.deliveries = new Hashtable();
/*      */     }
/*  252 */     this.deliveries.put(paramString, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  264 */   public void putIntDelivery(String paramString, int paramInt) { putDelivery(paramString, new Integer(paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getDelivery(String paramString) {
/*  278 */     if (this.deliveries != null) {
/*  279 */       return this.deliveries.get(paramString);
/*      */     }
/*  281 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object removeDelivery(String paramString) {
/*  294 */     if (this.deliveries != null) {
/*  295 */       return this.deliveries.remove(paramString);
/*      */     }
/*  297 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getIntDelivery(String paramString) {
/*      */     try {
/*  313 */       Integer integer = (Integer)getDelivery(paramString);
/*  314 */       return integer.intValue();
/*      */     }
/*  316 */     catch (Exception exception) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  321 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  330 */   public String getStringDelivery(String paramString) { return (String)getDelivery(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  339 */   public Hashtable getHashtableDelivery(String paramString) { return (Hashtable)getDelivery(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  348 */   public Vector getVectorDelivery(String paramString) { return (Vector)getDelivery(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  356 */   public void setDispatcher(Dispatcher paramDispatcher) { this.dispatcher = paramDispatcher; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  364 */   public Dispatcher getDispatcher() { return this.dispatcher; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  372 */   public HttpServletRequest getRequest() { return this.request; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  380 */   public HttpServletResponse getResponse() { return this.response; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  388 */   public HttpSession getSession() { return this.session; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  396 */   public ServletContext getServletContext() { return this.servletContext; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  404 */   public boolean isNewSession() { return this.newSession; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void print(String paramString) {
/*      */     try {
/*  418 */       this.response.getWriter().println(paramString);
/*      */     }
/*  420 */     catch (IOException iOException) {
/*      */       
/*  422 */       this.log.debug("IOException on print().");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void printException(Throwable paramThrowable) {
/*      */     try {
/*  434 */       paramThrowable.printStackTrace(this.response.getWriter());
/*      */     }
/*  436 */     catch (IOException iOException) {
/*      */       
/*  438 */       this.log.log("Exception while attempting to print exception to Context:\n" + iOException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush() {
/*      */     try {
/*  449 */       this.response.getWriter().flush();
/*      */     }
/*  451 */     catch (IOException iOException) {
/*      */       
/*  453 */       this.log.debug("IOException on flush().");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  462 */   public String getHeader(String paramString) { return this.request.getHeader(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRequestValue(String paramString1, String paramString2) {
/*      */     try {
/*  478 */       String str = getRequestValue(paramString1);
/*  479 */       if (str != null) {
/*  480 */         return str;
/*      */       }
/*  482 */       return paramString2;
/*      */     }
/*  484 */     catch (IllegalArgumentException illegalArgumentException) {
/*      */       
/*  486 */       this.log.debug("Illegal argument exception: " + paramString1);
/*  487 */       return paramString2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  501 */   public String getParameter(String paramString1, String paramString2) { return getRequestValue(paramString1, paramString2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRequestValue(String paramString) {
/*      */     try {
/*  514 */       return this.request.getParameter(paramString);
/*      */     }
/*  516 */     catch (IllegalArgumentException illegalArgumentException) {
/*      */       
/*  518 */       this.log.debug("Illegal argument exception: " + paramString);
/*  519 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  531 */   public String getParameter(String paramString) { return getRequestValue(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getIntRequestValue(String paramString, int paramInt) {
/*  547 */     int i = paramInt;
/*      */     
/*      */     try {
/*  550 */       i = Integer.parseInt(this.request.getParameter(paramString));
/*      */     }
/*  552 */     catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  557 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  570 */   public int getIntRequestValue(String paramString) { return getIntRequestValue(paramString, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  580 */   public Object getSessionValue(String paramString) { return this.session.getAttribute(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  591 */   public void putSessionValue(String paramString, Object paramObject) { this.session.setAttribute(paramString, paramObject); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeSessionValue(String paramString) {
/*  601 */     if (this.session.getAttribute(paramString) != null) {
/*  602 */       this.session.removeAttribute(paramString);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Cookie getCookie(String paramString) {
/*  614 */     Cookie cookie = null;
/*  615 */     Cookie[] arrayOfCookie = this.request.getCookies();
/*      */     
/*  617 */     if (arrayOfCookie != null)
/*      */     {
/*  619 */       for (byte b = 0; b < arrayOfCookie.length; b++) {
/*      */         
/*  621 */         if (arrayOfCookie[b].getName().equals(paramString)) {
/*      */           
/*  623 */           cookie = arrayOfCookie[b];
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     }
/*  629 */     return cookie;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCookieValue(String paramString) {
/*  642 */     String str = null;
/*  643 */     Cookie cookie = getCookie(paramString);
/*      */     
/*  645 */     if (cookie != null) {
/*  646 */       str = cookie.getValue();
/*      */     }
/*  648 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  660 */   public void setCookie(String paramString1, String paramString2) { setCookie(paramString1, paramString2, 2592000); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCookie(String paramString1, String paramString2, int paramInt) {
/*  672 */     Cookie cookie = new Cookie(paramString1, paramString2);
/*  673 */     cookie.setMaxAge(paramInt);
/*      */     
/*  675 */     this.response.addCookie(cookie);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteCookie(String paramString) {
/*  686 */     Cookie cookie = new Cookie(paramString, "");
/*  687 */     cookie.setMaxAge(0);
/*      */     
/*  689 */     this.response.addCookie(cookie);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  697 */   public String getClientIP() { return this.request.getRemoteAddr(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  705 */   public String getRequestMethod() { return this.request.getMethod(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  718 */   public void sendHTTPRedirect(String paramString) { this.response.sendRedirect(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean sendHTTPRedirectCaught(String paramString) {
/*      */     try {
/*  729 */       sendHTTPRedirect(paramString);
/*  730 */       return true;
/*      */     }
/*  732 */     catch (IOException iOException) {
/*      */       
/*  734 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean sendSecureCMDRedirect(String paramString) {
/*      */     try {
/*  751 */       this.response.sendRedirect(String.valueOf(this.infrastructure.getSecureDomain()) + 
/*  752 */           this.infrastructure.getServletCmdURL(paramString));
/*  753 */       return true;
/*      */     }
/*  755 */     catch (IOException iOException) {
/*      */       
/*  757 */       this.log.debug("Exception while secure redirect to command " + paramString + ": " + iOException);
/*  758 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getReferencedJSP() {
/*  777 */     if (this.referencedJSP != null) {
/*  778 */       return this.referencedJSP;
/*      */     }
/*  780 */     return "none";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  792 */   public void setReferencedJSP(String paramString) { this.referencedJSP = paramString; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logJSPInvokation(String paramString) {
/*  800 */     this.infrastructure.getRequestLog().log(this, String.valueOf('/') + paramString + 
/*  801 */         getCustomRequestMark(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  823 */   public String getCustomRequestMark(String paramString) { return ""; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  851 */   public String getCustomCookie() { return "-"; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  870 */   public void setContentType(String paramString) { this.response.setContentType(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  906 */   public boolean includeJSP(String paramString) { return includeJSP(paramString, "text/html"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  922 */   public boolean includeJSP(String paramString1, String paramString2) { return includeJSP(paramString1, "", false, paramString2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  941 */   public boolean includeJSP(String paramString1, String paramString2, boolean paramBoolean) { return includeJSP(paramString1, paramString2, paramBoolean, "text/html"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean includeJSP(String paramString1, String paramString2, boolean paramBoolean, String paramString3) {
/*      */     try {
/*  966 */       if (this.referencedJSP == null) {
/*      */ 
/*      */ 
/*      */         
/*  970 */         this.referencedJSP = paramString1;
/*  971 */         setContentType(paramString3);
/*      */       } 
/*      */       
/*  974 */       logJSPInvokation(paramString1);
/*      */       
/*  976 */       if (paramBoolean) {
/*      */         
/*  978 */         RequestDispatcher requestDispatcher = this.servletContext.getRequestDispatcher(
/*  979 */             String.valueOf(paramString2) + paramString1);
/*  980 */         requestDispatcher.include(this.request, this.response);
/*      */       }
/*      */       else {
/*      */         
/*  984 */         RequestDispatcher requestDispatcher = this.servletContext.getRequestDispatcher(
/*  985 */             String.valueOf(this.infrastructure.getJspDirectory()) + paramString1);
/*  986 */         requestDispatcher.include(this.request, this.response);
/*      */       } 
/*      */       
/*  989 */       return true;
/*      */     }
/*  991 */     catch (Exception exception) {
/*      */       
/*  993 */       this.log.debug("Exception while including " + paramString1 + ": " + exception);
/*  994 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean forwardJSP(String paramString) {
/*      */     try {
/* 1011 */       this.referencedJSP = paramString;
/* 1012 */       logJSPInvokation(paramString);
/* 1013 */       RequestDispatcher requestDispatcher = this.servletContext.getRequestDispatcher(
/* 1014 */           String.valueOf(this.infrastructure.getJspDirectory()) + paramString);
/* 1015 */       requestDispatcher.forward(this.request, this.response);
/*      */       
/* 1017 */       return true;
/*      */     }
/* 1019 */     catch (Exception exception) {
/*      */       
/* 1021 */       this.log.debug("Exception while including " + paramString + ": " + exception);
/* 1022 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAllSessionValues() {
/*      */     try {
/* 1037 */       Enumeration enumeration = this.session.getAttributeNames();
/* 1038 */       Vector vector = new Vector();
/* 1039 */       while (enumeration.hasMoreElements())
/*      */       {
/* 1041 */         vector.add(enumeration.nextElement());
/*      */       }
/*      */       
/* 1044 */       for (byte b = 0; b < vector.size(); b++)
/*      */       {
/* 1046 */         this.session.removeAttribute((String)vector.elementAt(b));
/*      */       }
/*      */     }
/* 1049 */     catch (Exception exception) {
/*      */       
/* 1051 */       this.log.debug("Exception while removing all session values: " + exception);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExpiration(int paramInt) {
/* 1068 */     this.response.setDateHeader("Expires", System.currentTimeMillis() + 
/* 1069 */         paramInt * 1000L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1081 */   public String encodeURL(String paramString) { return this.response.encodeURL(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1089 */   public String makeLink(String paramString) { return "<a href=\"" + encodeURL(paramString) + "\">"; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String makeLink(String paramString1, String paramString2) {
/* 1098 */     return "<a href=\"" + encodeURL(paramString1) + 
/* 1099 */       "\" target=\"" + paramString2 + 
/* 1100 */       "\">";
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\Context.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */