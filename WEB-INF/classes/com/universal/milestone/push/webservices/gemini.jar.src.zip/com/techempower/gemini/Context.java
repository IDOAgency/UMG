package com.techempower.gemini;

import com.techempower.ComponentLog;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Context {
  public static final String COMPONENT_CODE = "ctxt";
  
  protected GeminiApplication application;
  
  protected ComponentLog log;
  
  protected BasicInfrastructure infrastructure;
  
  protected HttpServletRequest request;
  
  protected HttpServletResponse response;
  
  protected HttpSession session;
  
  protected ServletContext servletContext;
  
  protected Hashtable deliveries;
  
  protected String referencedJSP;
  
  protected Dispatcher dispatcher;
  
  protected boolean newSession;
  
  protected int dispatches;
  
  protected String command;
  
  public Context(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, ServletContext paramServletContext, Dispatcher paramDispatcher) {
    this.referencedJSP = null;
    this.newSession = false;
    this.dispatches = 0;
    this.request = paramHttpServletRequest;
    this.response = paramHttpServletResponse;
    this.servletContext = paramServletContext;
    this.dispatcher = paramDispatcher;
    this.command = null;
    this.application = getApplication();
    this.infrastructure = this.application.getInfrastructure();
    this.log = this.application.getLog("ctxt");
    paramHttpServletRequest.setAttribute("Context", this);
    this.session = this.application.getSessionManager().getSession(paramHttpServletRequest);
    this.newSession = this.session.isNew();
  }
  
  public void displaySessionInfo() {
    this.log.debug("Session: " + this.session);
    this.log.debug("Session.isNew: " + this.session.isNew());
  }
  
  public void displayAllRequestHeaders() {
    Enumeration enumeration = this.request.getHeaderNames();
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      this.log.debug(String.valueOf(str) + " = " + this.request.getHeader(str));
    } 
  }
  
  public String toString() { return "Context [" + getClientIP() + "]"; }
  
  public String getSessionDescription() { return "session timeout: " + this.session.getMaxInactiveInterval() + "s"; }
  
  public GeminiApplication getApplication() { return GeminiApplication.getInstance(); }
  
  public BasicInfrastructure getInfrastructure() { return this.infrastructure; }
  
  public int getDispatches() { return this.dispatches; }
  
  public void incrementDispatches() { this.dispatches++; }
  
  public String getCommand() { return this.command; }
  
  public void setCommand(String paramString) { this.command = paramString; }
  
  public String gatherCommand() {
    this.command = getRequestValue(this.dispatcher.getCommandParameterName(), 
        this.dispatcher.getDefaultCommand());
    return this.command;
  }
  
  public void putDelivery(String paramString, Object paramObject) {
    if (this.deliveries == null)
      this.deliveries = new Hashtable(); 
    this.deliveries.put(paramString, paramObject);
  }
  
  public void putIntDelivery(String paramString, int paramInt) { putDelivery(paramString, new Integer(paramInt)); }
  
  public Object getDelivery(String paramString) {
    if (this.deliveries != null)
      return this.deliveries.get(paramString); 
    return null;
  }
  
  public Object removeDelivery(String paramString) {
    if (this.deliveries != null)
      return this.deliveries.remove(paramString); 
    return null;
  }
  
  public int getIntDelivery(String paramString) {
    try {
      Integer integer = (Integer)getDelivery(paramString);
      return integer.intValue();
    } catch (Exception exception) {
      return 0;
    } 
  }
  
  public String getStringDelivery(String paramString) { return (String)getDelivery(paramString); }
  
  public Hashtable getHashtableDelivery(String paramString) { return (Hashtable)getDelivery(paramString); }
  
  public Vector getVectorDelivery(String paramString) { return (Vector)getDelivery(paramString); }
  
  public void setDispatcher(Dispatcher paramDispatcher) { this.dispatcher = paramDispatcher; }
  
  public Dispatcher getDispatcher() { return this.dispatcher; }
  
  public HttpServletRequest getRequest() { return this.request; }
  
  public HttpServletResponse getResponse() { return this.response; }
  
  public HttpSession getSession() { return this.session; }
  
  public ServletContext getServletContext() { return this.servletContext; }
  
  public boolean isNewSession() { return this.newSession; }
  
  public void print(String paramString) {
    try {
      this.response.getWriter().println(paramString);
    } catch (IOException iOException) {
      this.log.debug("IOException on print().");
    } 
  }
  
  public void printException(Throwable paramThrowable) {
    try {
      paramThrowable.printStackTrace(this.response.getWriter());
    } catch (IOException iOException) {
      this.log.log("Exception while attempting to print exception to Context:\n" + iOException);
    } 
  }
  
  public void flush() {
    try {
      this.response.getWriter().flush();
    } catch (IOException iOException) {
      this.log.debug("IOException on flush().");
    } 
  }
  
  public String getHeader(String paramString) { return this.request.getHeader(paramString); }
  
  public String getRequestValue(String paramString1, String paramString2) {
    try {
      String str = getRequestValue(paramString1);
      if (str != null)
        return str; 
      return paramString2;
    } catch (IllegalArgumentException illegalArgumentException) {
      this.log.debug("Illegal argument exception: " + paramString1);
      return paramString2;
    } 
  }
  
  public String getParameter(String paramString1, String paramString2) { return getRequestValue(paramString1, paramString2); }
  
  public String getRequestValue(String paramString) {
    try {
      return this.request.getParameter(paramString);
    } catch (IllegalArgumentException illegalArgumentException) {
      this.log.debug("Illegal argument exception: " + paramString);
      return null;
    } 
  }
  
  public String getParameter(String paramString) { return getRequestValue(paramString); }
  
  public int getIntRequestValue(String paramString, int paramInt) {
    int i = paramInt;
    try {
      i = Integer.parseInt(this.request.getParameter(paramString));
    } catch (Exception exception) {}
    return i;
  }
  
  public int getIntRequestValue(String paramString) { return getIntRequestValue(paramString, 0); }
  
  public Object getSessionValue(String paramString) { return this.session.getAttribute(paramString); }
  
  public void putSessionValue(String paramString, Object paramObject) { this.session.setAttribute(paramString, paramObject); }
  
  public void removeSessionValue(String paramString) {
    if (this.session.getAttribute(paramString) != null)
      this.session.removeAttribute(paramString); 
  }
  
  public Cookie getCookie(String paramString) {
    Cookie cookie = null;
    Cookie[] arrayOfCookie = this.request.getCookies();
    if (arrayOfCookie != null)
      for (byte b = 0; b < arrayOfCookie.length; b++) {
        if (arrayOfCookie[b].getName().equals(paramString)) {
          cookie = arrayOfCookie[b];
          break;
        } 
      }  
    return cookie;
  }
  
  public String getCookieValue(String paramString) {
    String str = null;
    Cookie cookie = getCookie(paramString);
    if (cookie != null)
      str = cookie.getValue(); 
    return str;
  }
  
  public void setCookie(String paramString1, String paramString2) { setCookie(paramString1, paramString2, 2592000); }
  
  public void setCookie(String paramString1, String paramString2, int paramInt) {
    Cookie cookie = new Cookie(paramString1, paramString2);
    cookie.setMaxAge(paramInt);
    this.response.addCookie(cookie);
  }
  
  public void deleteCookie(String paramString) {
    Cookie cookie = new Cookie(paramString, "");
    cookie.setMaxAge(0);
    this.response.addCookie(cookie);
  }
  
  public String getClientIP() { return this.request.getRemoteAddr(); }
  
  public String getRequestMethod() { return this.request.getMethod(); }
  
  public void sendHTTPRedirect(String paramString) { this.response.sendRedirect(paramString); }
  
  public boolean sendHTTPRedirectCaught(String paramString) {
    try {
      sendHTTPRedirect(paramString);
      return true;
    } catch (IOException iOException) {
      return false;
    } 
  }
  
  public boolean sendSecureCMDRedirect(String paramString) {
    try {
      this.response.sendRedirect(String.valueOf(this.infrastructure.getSecureDomain()) + 
          this.infrastructure.getServletCmdURL(paramString));
      return true;
    } catch (IOException iOException) {
      this.log.debug("Exception while secure redirect to command " + paramString + ": " + iOException);
      return false;
    } 
  }
  
  public String getReferencedJSP() {
    if (this.referencedJSP != null)
      return this.referencedJSP; 
    return "none";
  }
  
  public void setReferencedJSP(String paramString) { this.referencedJSP = paramString; }
  
  public void logJSPInvokation(String paramString) {
    this.infrastructure.getRequestLog().log(this, String.valueOf('/') + paramString + 
        getCustomRequestMark(paramString));
  }
  
  public String getCustomRequestMark(String paramString) { return ""; }
  
  public String getCustomCookie() { return "-"; }
  
  public void setContentType(String paramString) { this.response.setContentType(paramString); }
  
  public boolean includeJSP(String paramString) { return includeJSP(paramString, "text/html"); }
  
  public boolean includeJSP(String paramString1, String paramString2) { return includeJSP(paramString1, "", false, paramString2); }
  
  public boolean includeJSP(String paramString1, String paramString2, boolean paramBoolean) { return includeJSP(paramString1, paramString2, paramBoolean, "text/html"); }
  
  public boolean includeJSP(String paramString1, String paramString2, boolean paramBoolean, String paramString3) {
    try {
      if (this.referencedJSP == null) {
        this.referencedJSP = paramString1;
        setContentType(paramString3);
      } 
      logJSPInvokation(paramString1);
      if (paramBoolean) {
        RequestDispatcher requestDispatcher = this.servletContext.getRequestDispatcher(
            String.valueOf(paramString2) + paramString1);
        requestDispatcher.include(this.request, this.response);
      } else {
        RequestDispatcher requestDispatcher = this.servletContext.getRequestDispatcher(
            String.valueOf(this.infrastructure.getJspDirectory()) + paramString1);
        requestDispatcher.include(this.request, this.response);
      } 
      return true;
    } catch (Exception exception) {
      this.log.debug("Exception while including " + paramString1 + ": " + exception);
      return false;
    } 
  }
  
  public boolean forwardJSP(String paramString) {
    try {
      this.referencedJSP = paramString;
      logJSPInvokation(paramString);
      RequestDispatcher requestDispatcher = this.servletContext.getRequestDispatcher(
          String.valueOf(this.infrastructure.getJspDirectory()) + paramString);
      requestDispatcher.forward(this.request, this.response);
      return true;
    } catch (Exception exception) {
      this.log.debug("Exception while including " + paramString + ": " + exception);
      return false;
    } 
  }
  
  public void removeAllSessionValues() {
    try {
      Enumeration enumeration = this.session.getAttributeNames();
      Vector vector = new Vector();
      while (enumeration.hasMoreElements())
        vector.add(enumeration.nextElement()); 
      for (byte b = 0; b < vector.size(); b++)
        this.session.removeAttribute((String)vector.elementAt(b)); 
    } catch (Exception exception) {
      this.log.debug("Exception while removing all session values: " + exception);
    } 
  }
  
  public void setExpiration(int paramInt) {
    this.response.setDateHeader("Expires", System.currentTimeMillis() + 
        paramInt * 1000L);
  }
  
  public String encodeURL(String paramString) { return this.response.encodeURL(paramString); }
  
  public String makeLink(String paramString) { return "<a href=\"" + encodeURL(paramString) + "\">"; }
  
  public String makeLink(String paramString1, String paramString2) {
    return "<a href=\"" + encodeURL(paramString1) + 
      "\" target=\"" + paramString2 + 
      "\">";
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\Context.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */