/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.EnhancedProperties;
/*     */ import java.util.Properties;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Transport;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmailTransport
/*     */ {
/*     */   public static final String COMPONENT_CODE = "emxp";
/*     */   public static final String DEFAULT_MAIL_SERVER = "mail";
/*     */   protected GeminiApplication application;
/*     */   protected ComponentLog log;
/*     */   protected String defaultMailServer;
/*     */   protected Properties defaultMailProps;
/*     */   
/*     */   public EmailTransport(GeminiApplication paramGeminiApplication) {
/*  45 */     this.defaultMailServer = "mail";
/*  46 */     this.defaultMailProps = new Properties();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     this.application = paramGeminiApplication;
/*  58 */     this.log = paramGeminiApplication.getLog("emxp");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(EnhancedProperties paramEnhancedProperties) {
/*  66 */     this.defaultMailServer = paramEnhancedProperties.getProperty("MailServer", this.defaultMailServer);
/*  67 */     this.defaultMailProps.put("mail.smtp.host", this.defaultMailServer);
/*  68 */     this.log.debug("Mail server set to " + this.defaultMailServer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendEmail(EmailPackage paramEmailPackage) {
/*     */     Properties properties;
/*  80 */     if (paramEmailPackage.getMailServer() == null) {
/*     */       
/*  82 */       properties = this.defaultMailProps;
/*     */     }
/*     */     else {
/*     */       
/*  86 */       properties = new Properties();
/*  87 */       properties.put("mail.smtp.host", paramEmailPackage.getMailServer());
/*     */     } 
/*     */     
/*  90 */     Session session = Session.getDefaultInstance(properties, null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  96 */       MimeMessage mimeMessage = new MimeMessage(session);
/*  97 */       mimeMessage.addFrom(InternetAddress.parse(paramEmailPackage.getAuthor(), false));
/*  98 */       mimeMessage.addRecipients(Message.RecipientType.TO, 
/*  99 */           InternetAddress.parse(paramEmailPackage.getRecipient(), false));
/* 100 */       mimeMessage.setSubject(paramEmailPackage.getSubject());
/* 101 */       mimeMessage.setText(paramEmailPackage.getBody());
/* 102 */       Transport.send(mimeMessage);
/* 103 */       paramEmailPackage.setSent(true);
/*     */     }
/* 105 */     catch (Exception exception) {
/*     */       
/* 107 */       paramEmailPackage.setSent(false);
/* 108 */       this.log.debug("Email transport exception:" + exception);
/*     */     }
/*     */     finally {
/*     */       
/* 112 */       Object object = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\EmailTransport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */