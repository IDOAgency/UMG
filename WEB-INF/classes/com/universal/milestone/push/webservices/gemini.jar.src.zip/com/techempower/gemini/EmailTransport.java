package com.techempower.gemini;

import com.techempower.ComponentLog;
import com.techempower.EnhancedProperties;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailTransport {
  public static final String COMPONENT_CODE = "emxp";
  
  public static final String DEFAULT_MAIL_SERVER = "mail";
  
  protected GeminiApplication application;
  
  protected ComponentLog log;
  
  protected String defaultMailServer;
  
  protected Properties defaultMailProps;
  
  public EmailTransport(GeminiApplication paramGeminiApplication) {
    this.defaultMailServer = "mail";
    this.defaultMailProps = new Properties();
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("emxp");
  }
  
  public void configure(EnhancedProperties paramEnhancedProperties) {
    this.defaultMailServer = paramEnhancedProperties.getProperty("MailServer", this.defaultMailServer);
    this.defaultMailProps.put("mail.smtp.host", this.defaultMailServer);
    this.log.debug("Mail server set to " + this.defaultMailServer);
  }
  
  public void sendEmail(EmailPackage paramEmailPackage) {
    Properties properties;
    if (paramEmailPackage.getMailServer() == null) {
      properties = this.defaultMailProps;
    } else {
      properties = new Properties();
      properties.put("mail.smtp.host", paramEmailPackage.getMailServer());
    } 
    Session session = Session.getDefaultInstance(properties, null);
    try {
      MimeMessage mimeMessage = new MimeMessage(session);
      mimeMessage.addFrom(InternetAddress.parse(paramEmailPackage.getAuthor(), false));
      mimeMessage.addRecipients(Message.RecipientType.TO, 
          InternetAddress.parse(paramEmailPackage.getRecipient(), false));
      mimeMessage.setSubject(paramEmailPackage.getSubject());
      mimeMessage.setText(paramEmailPackage.getBody());
      Transport.send(mimeMessage);
      paramEmailPackage.setSent(true);
    } catch (Exception exception) {
      paramEmailPackage.setSent(false);
      this.log.debug("Email transport exception:" + exception);
    } finally {
      Object object = null;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\EmailTransport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */