package com.techempower.gemini.fornax;

import com.techempower.DataEntity;
import java.util.Hashtable;

public class FornaxGenerationDestination extends DataEntity implements FornaxConstants {
  protected int generationDestinationID = -1;
  
  protected int generationDestinationFilePathID = -1;
  
  protected String generationDestinationName = "";
  
  protected String generationDestinationDescription = "";
  
  protected String generationDestinationServerNetworkName = "";
  
  protected String generationDestinationServerDNSName = "";
  
  protected String generationDestinationServerIPAddress = "";
  
  protected String generationDestinationLogonUserName = "";
  
  protected String generationDestinationLogonPassword = "";
  
  public void initializationComplete() {}
  
  public Hashtable getCustomSetMethodBindings() {
    Hashtable hashtable = new Hashtable();
    hashtable.put("GenerationDestinationID", "setID");
    hashtable.put("GenerationDestinationFilePathID", "setFilePathID");
    hashtable.put("GenerationDestinationName", "setName");
    hashtable.put("GenerationDestinationDescription", "setDescription");
    hashtable.put("GenerationDestinationServerNetworkName", "setServerNetworkName");
    hashtable.put("GenerationDestinationServerDNSName", "setServerDNSName");
    hashtable.put("GenerationDestinationServerIPAddress", "setServerIPAddress");
    hashtable.put("GenerationDestinationLogonUserName", "setLogonUserName");
    hashtable.put("GenerationDestinationLogonPassword", "setLogonPassword");
    return hashtable;
  }
  
  public int getIdentity() { return this.generationDestinationID; }
  
  public String getTableName() { return "fnGenerationDestination"; }
  
  public String getIdentityColumnName() { return "GenerationDestinationID"; }
  
  public int getID() { return this.generationDestinationID; }
  
  public int getFilePathID() { return this.generationDestinationFilePathID; }
  
  public String getName() { return this.generationDestinationName; }
  
  public String getDescription() { return this.generationDestinationDescription; }
  
  public String getServerNetworkName() { return this.generationDestinationServerNetworkName; }
  
  public String getServerDNSName() { return this.generationDestinationServerDNSName; }
  
  public String getServerIPAddress() { return this.generationDestinationServerIPAddress; }
  
  public String getLogonUserName() { return this.generationDestinationLogonUserName; }
  
  public String getLogonPassword() { return this.generationDestinationLogonPassword; }
  
  public void setID(int paramInt) { this.generationDestinationID = paramInt; }
  
  public void setFilePathID(int paramInt) { this.generationDestinationFilePathID = paramInt; }
  
  public void setName(String paramString) {
    if (paramString != null)
      this.generationDestinationName = paramString; 
  }
  
  public void setDescription(String paramString) {
    if (paramString != null)
      this.generationDestinationDescription = paramString; 
  }
  
  public void setServerNetworkName(String paramString) {
    if (paramString != null)
      this.generationDestinationServerNetworkName = paramString; 
  }
  
  public void setServerDNSName(String paramString) {
    if (paramString != null)
      this.generationDestinationServerDNSName = paramString; 
  }
  
  public void setServerIPAddress(String paramString) {
    if (paramString != null)
      this.generationDestinationServerIPAddress = paramString; 
  }
  
  public void setLogonUserName(String paramString) {
    if (paramString != null)
      this.generationDestinationLogonUserName = paramString; 
  }
  
  public void setLogonPassword(String paramString) {
    if (paramString != null)
      this.generationDestinationLogonPassword = paramString; 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxGenerationDestination.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */