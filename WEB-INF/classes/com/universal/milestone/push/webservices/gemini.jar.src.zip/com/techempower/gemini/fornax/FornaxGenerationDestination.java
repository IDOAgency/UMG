/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.DataEntity;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxGenerationDestination
/*     */   extends DataEntity
/*     */   implements FornaxConstants
/*     */ {
/*  37 */   protected int generationDestinationID = -1;
/*  38 */   protected int generationDestinationFilePathID = -1;
/*  39 */   protected String generationDestinationName = "";
/*  40 */   protected String generationDestinationDescription = "";
/*  41 */   protected String generationDestinationServerNetworkName = "";
/*  42 */   protected String generationDestinationServerDNSName = "";
/*  43 */   protected String generationDestinationServerIPAddress = "";
/*  44 */   protected String generationDestinationLogonUserName = "";
/*  45 */   protected String generationDestinationLogonPassword = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializationComplete() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getCustomSetMethodBindings() {
/*  65 */     Hashtable hashtable = new Hashtable();
/*     */     
/*  67 */     hashtable.put("GenerationDestinationID", "setID");
/*  68 */     hashtable.put("GenerationDestinationFilePathID", "setFilePathID");
/*  69 */     hashtable.put("GenerationDestinationName", "setName");
/*  70 */     hashtable.put("GenerationDestinationDescription", "setDescription");
/*  71 */     hashtable.put("GenerationDestinationServerNetworkName", "setServerNetworkName");
/*  72 */     hashtable.put("GenerationDestinationServerDNSName", "setServerDNSName");
/*  73 */     hashtable.put("GenerationDestinationServerIPAddress", "setServerIPAddress");
/*  74 */     hashtable.put("GenerationDestinationLogonUserName", "setLogonUserName");
/*  75 */     hashtable.put("GenerationDestinationLogonPassword", "setLogonPassword");
/*     */     
/*  77 */     return hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public int getIdentity() { return this.generationDestinationID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public String getTableName() { return "fnGenerationDestination"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public String getIdentityColumnName() { return "GenerationDestinationID"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public int getID() { return this.generationDestinationID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   public int getFilePathID() { return this.generationDestinationFilePathID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public String getName() { return this.generationDestinationName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public String getDescription() { return this.generationDestinationDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public String getServerNetworkName() { return this.generationDestinationServerNetworkName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   public String getServerDNSName() { return this.generationDestinationServerDNSName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   public String getServerIPAddress() { return this.generationDestinationServerIPAddress; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   public String getLogonUserName() { return this.generationDestinationLogonUserName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   public String getLogonPassword() { return this.generationDestinationLogonPassword; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public void setID(int paramInt) { this.generationDestinationID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   public void setFilePathID(int paramInt) { this.generationDestinationFilePathID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String paramString) {
/* 216 */     if (paramString != null) {
/* 217 */       this.generationDestinationName = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String paramString) {
/* 228 */     if (paramString != null) {
/* 229 */       this.generationDestinationDescription = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServerNetworkName(String paramString) {
/* 240 */     if (paramString != null) {
/* 241 */       this.generationDestinationServerNetworkName = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServerDNSName(String paramString) {
/* 252 */     if (paramString != null) {
/* 253 */       this.generationDestinationServerDNSName = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServerIPAddress(String paramString) {
/* 264 */     if (paramString != null) {
/* 265 */       this.generationDestinationServerIPAddress = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogonUserName(String paramString) {
/* 276 */     if (paramString != null) {
/* 277 */       this.generationDestinationLogonUserName = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogonPassword(String paramString) {
/* 288 */     if (paramString != null)
/* 289 */       this.generationDestinationLogonPassword = paramString; 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxGenerationDestination.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */