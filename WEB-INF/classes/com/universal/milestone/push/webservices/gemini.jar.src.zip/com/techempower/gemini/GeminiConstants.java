package com.techempower.gemini;

import com.techempower.UtilityConstants;

public interface GeminiConstants extends UtilityConstants {
  public static final String GEMINI_VERSION = "1.14";
  
  public static final String CMD = "cmd";
  
  public static final String CMD_HOME = "home";
  
  public static final String CMD_DEFAULT = "home";
  
  public static final String CMD_REDISPATCH_LIMIT_HIT = "home";
  
  public static final int DEFAULT_COOKIE_MAX_AGE = 2592000;
  
  public static final int BROWSER_TYPE_COUNT = 9;
  
  public static final int BROWSER_TYPE_UNKNOWN = -1;
  
  public static final int BROWSER_TYPE_IE_4_X = 0;
  
  public static final int BROWSER_TYPE_IE_5_X = 1;
  
  public static final int BROWSER_TYPE_NETSCAPE_3_X = 2;
  
  public static final int BROWSER_TYPE_NETSCAPE_4_X = 3;
  
  public static final int BROWSER_TYPE_NETSCAPE_6_X = 4;
  
  public static final int BROWSER_TYPE_AOL = 5;
  
  public static final int BROWSER_TYPE_HOT_JAVA = 6;
  
  public static final int BROWSER_TYPE_OPERA = 7;
  
  public static final int BROWSER_TYPE_WEB_TV = 8;
  
  public static final String BROWSER_IE_4_X = "msie 4";
  
  public static final String BROWSER_IE_5_X = "msie 5";
  
  public static final String BROWSER_NETSCAPE_3_X = "mozilla/3.";
  
  public static final String BROWSER_NETSCAPE_4_X = "mozilla/4.";
  
  public static final String BROWSER_NETSCAPE_6_X = "gecko";
  
  public static final String BROWSER_AOL = "aol";
  
  public static final String BROWSER_HOT_JAVA = "sun";
  
  public static final String BROWSER_OPERA = "opera";
  
  public static final String BROWSER_WEB_TV = "webtv";
  
  public static final String BROWSER_NAME_IE_4_X = "Microsoft Internet Explorer 4.x";
  
  public static final String BROWSER_NAME_IE_5_X = "Microsoft Internet Explorer 5.x";
  
  public static final String BROWSER_NAME_NETSCAPE_3_X = "Netscape Navigator v3.x";
  
  public static final String BROWSER_NAME_NETSCAPE_4_X = "Netscape Navigator v4.x";
  
  public static final String BROWSER_NAME_NETSCAPE_6_X = "Netscape Navigator v6.x";
  
  public static final String BROWSER_NAME_AOL = "AOL Web Browser v4.x/5.x";
  
  public static final String BROWSER_NAME_HOT_JAVA = "Hot Java Web Browser";
  
  public static final String BROWSER_NAME_OPERA = "Opera Web Browser";
  
  public static final String BROWSER_NAME_WEB_TV = "WebTV";
  
  public static final int[] BROWSER_TYPE_CHECK_ORDER = { 5, 
      6, 
      7, 
      8, 
      
      1, 
      2, 
      3, 
      4 };
  
  public static final String[] BROWSER_USER_AGENT_IDS = { "msie 4", 
      "msie 5", 
      "mozilla/3.", 
      "mozilla/4.", 
      "gecko", 
      "aol", 
      "sun", 
      "opera", 
      "webtv" };
  
  public static final String[] BROWSER_NAMES = { "Microsoft Internet Explorer 4.x", 
      "Microsoft Internet Explorer 5.x", 
      "Netscape Navigator v3.x", 
      "Netscape Navigator v4.x", 
      "Netscape Navigator v6.x", 
      "AOL Web Browser v4.x/5.x", 
      "Hot Java Web Browser", 
      "Opera Web Browser", 
      "WebTV" };
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\GeminiConstants.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */