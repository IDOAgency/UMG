package com.techempower;

public class Version {
  protected static Version instance = new Version();
  
  protected String versionString = String.valueOf(getMajorVersion()) + "." + 
    BasicHelper.zeroPad(getMinorVersion(), 2) + 
    "(" + BasicHelper.zeroPad(getMicroVersion(), 2) + ")";
  
  public int getMajorVersion() { return 1; }
  
  public int getMinorVersion() { return 1; }
  
  public int getMicroVersion() { return 0; }
  
  public String getProductCode() { return "GA"; }
  
  public String getProductName() { return "Example"; }
  
  public String getClientName() { return "Example"; }
  
  public String getDeveloperName() { return "TechEmpower, Inc."; }
  
  public String getCopyrightYears() { return "2001"; }
  
  public String getVersionString() { return this.versionString; }
  
  public static Version getInstance() { return instance; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\Version.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */