/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.gemini.Context;
/*     */ import com.techempower.gemini.Dispatcher;
/*     */ import com.techempower.gemini.Form;
/*     */ import com.techempower.gemini.FormSubmitButton;
/*     */ import com.techempower.gemini.FormValidation;
/*     */ import com.techempower.gemini.GeminiApplication;
/*     */ import com.techempower.gemini.GeminiHelper;
/*     */ import com.techempower.gemini.Handler;
/*     */ import com.techempower.gemini.pyxis.BasicSecurity;
/*     */ import com.techempower.gemini.pyxis.BasicUser;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxNavigationHandler
/*     */   implements Handler, FornaxConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "hLog";
/*     */   public GeminiApplication application;
/*     */   public ComponentLog log;
/*     */   public FornaxSettings fornaxSettings;
/*     */   protected String navigationCommandPrefix;
/*     */   
/*     */   public FornaxNavigationHandler(GeminiApplication paramGeminiApplication) {
/*  60 */     this.application = paramGeminiApplication;
/*  61 */     this.log = paramGeminiApplication.getLog("hLog");
/*  62 */     this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
/*  63 */     this.navigationCommandPrefix = new String(String.valueOf(paramGeminiApplication.getInfrastructure().getServletURL()) + "?" + "cmd" + "=" + "fornax-");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public String getDescription() { return "NavigationManagement"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean acceptRequest(Dispatcher paramDispatcher, Context paramContext, String paramString) {
/*  82 */     BasicSecurity basicSecurity = this.fornaxSettings.getSecurity();
/*     */     
/*  84 */     if (basicSecurity != null && basicSecurity.isLoggedIn(paramContext)) {
/*     */       
/*  86 */       if (paramString.equalsIgnoreCase("fornax-login") || 
/*  87 */         paramString.equalsIgnoreCase("fornax-main-menu") || 
/*  88 */         paramString.equalsIgnoreCase("fornax-content-type-list") || 
/*  89 */         paramString.equalsIgnoreCase("fornax-content-type-instances-list") || 
/*  90 */         paramString.equalsIgnoreCase("fornax-content-editor") || 
/*  91 */         paramString.equalsIgnoreCase("fornax-generation-management"))
/*     */       {
/*     */         
/*  94 */         return handleRequest(paramDispatcher, paramContext, paramString);
/*     */       }
/*  96 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 101 */     return paramDispatcher.redispatch(paramContext, "fornax-login");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleRequest(Dispatcher paramDispatcher, Context paramContext, String paramString) {
/* 112 */     if (paramString.equalsIgnoreCase("fornax-login"))
/*     */     {
/* 114 */       return paramContext.includeJSP("login.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix());
/*     */     }
/* 116 */     if (paramString.equalsIgnoreCase("fornax-main-menu")) {
/*     */       
/* 118 */       buildMainMenuElements(paramContext);
/* 119 */       return paramContext.includeJSP("main-menu.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix());
/*     */     } 
/* 121 */     if (paramString.equalsIgnoreCase("fornax-content-type-list")) {
/*     */       
/* 123 */       buildContentTypesManagementElements(paramContext);
/* 124 */       return paramContext.includeJSP("content-type-list.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix());
/*     */     } 
/* 126 */     if (paramString.equalsIgnoreCase("fornax-content-type-instances-list")) {
/*     */       
/* 128 */       buildContentTypeInstancesListElements(paramContext);
/* 129 */       return paramContext.includeJSP("content-type-instances-list.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix());
/*     */     } 
/* 131 */     if (paramString.equalsIgnoreCase("fornax-content-editor")) {
/*     */       
/* 133 */       if (buildContentTypeInstanceEditElements(paramDispatcher, paramContext)) {
/* 134 */         return paramContext.includeJSP("content-editor.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix());
/*     */       }
/* 136 */       paramContext.removeDelivery("Form");
/* 137 */       return paramDispatcher.redispatch(paramContext, "fornax-content-type-instances-list");
/*     */     } 
/*     */     
/* 140 */     if (paramString.equalsIgnoreCase("fornax-generation-management")) {
/*     */       
/* 142 */       if (buildGenerationManagementElements(paramContext)) {
/* 143 */         return paramContext.includeJSP("generation-management.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix());
/*     */       }
/* 145 */       paramContext.removeDelivery("Form");
/* 146 */       return paramDispatcher.redispatch(paramContext, "fornax-generation-run");
/*     */     } 
/*     */     
/* 149 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void buildMainMenuElements(Context paramContext) {
/* 156 */     BasicUser basicUser = this.fornaxSettings.getSecurity().getLogin(paramContext);
/* 157 */     String str = new String("");
/*     */     
/* 159 */     if (basicUser != null) {
/* 160 */       str = String.valueOf(basicUser.getUserFirstname()) + " " + basicUser.getUserLastname();
/*     */     }
/* 162 */     paramContext.putDelivery("LinkContentManagement", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-list"));
/* 163 */     paramContext.putDelivery("LinkGenerationManagement", new String(String.valueOf(this.navigationCommandPrefix) + "generation-management"));
/* 164 */     paramContext.putDelivery("LinkLogout", new String(String.valueOf(this.navigationCommandPrefix) + "login" + "&" + "logout" + "=true"));
/* 165 */     paramContext.putDelivery("LoggedInUserName", str);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void buildContentTypesManagementElements(Context paramContext) {
/* 171 */     int i = paramContext.getIntRequestValue("sort-mode", 0);
/* 172 */     int j = paramContext.getIntRequestValue("sort-direction", 0);
/*     */     
/* 174 */     paramContext.putDelivery("LinkMainMenu", new String(String.valueOf(this.navigationCommandPrefix) + "main-menu"));
/* 175 */     paramContext.putDelivery("LinkLogout", new String(String.valueOf(this.navigationCommandPrefix) + "login" + "&" + "logout" + "=true"));
/* 176 */     paramContext.putDelivery("LinkContentTypeInstancesList", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + "&" + "content-type-id" + "="));
/*     */     
/* 178 */     paramContext.putDelivery("LinkSortByID", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-list" + "&" + "sort-mode" + "=" + Character.MIN_VALUE + "&" + "sort-direction" + "="));
/* 179 */     paramContext.putDelivery("LinkSortByName", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-list" + "&" + "sort-mode" + "=" + '\001' + "&" + "sort-direction" + "="));
/* 180 */     paramContext.putDelivery("LinkSortByInstancesCount", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-list" + "&" + "sort-mode" + "=" + '\002' + "&" + "sort-direction" + "="));
/*     */     
/* 182 */     FornaxContentTypeManager fornaxContentTypeManager = new FornaxContentTypeManager(this.application);
/*     */     
/* 184 */     paramContext.putDelivery("ContentTypes", fornaxContentTypeManager.getContentTypes(0, i, j));
/*     */     
/* 186 */     paramContext.putDelivery("sort-mode", new Integer(i));
/* 187 */     paramContext.putDelivery("sort-direction", new Integer(j));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void buildContentTypeInstancesListElements(Context paramContext) {
/* 194 */     int i = paramContext.getIntRequestValue("content-type-id", -1);
/* 195 */     int j = paramContext.getIntRequestValue("instances-list-mode", -1);
/* 196 */     int k = paramContext.getIntRequestValue("paging-mode", 0);
/* 197 */     int m = paramContext.getIntRequestValue("current-page", 1) + k;
/* 198 */     int n = paramContext.getIntRequestValue("sort-mode", 0);
/* 199 */     int i1 = paramContext.getIntRequestValue("sort-direction", 0);
/*     */ 
/*     */     
/* 202 */     FornaxContentTypeManager fornaxContentTypeManager = new FornaxContentTypeManager(this.application);
/* 203 */     FornaxContentTypeInstanceManager fornaxContentTypeInstanceManager = new FornaxContentTypeInstanceManager(this.application);
/*     */ 
/*     */     
/* 206 */     int i2 = m;
/*     */     
/* 208 */     if (m == -1) {
/* 209 */       m = 1;
/* 210 */     } else if (m == -2) {
/* 211 */       fornaxContentTypeInstanceManager.getContentTypeInstances(i, m, n, i1);
/* 212 */       m = fornaxContentTypeInstanceManager.getPageCount();
/*     */     } 
/*     */ 
/*     */     
/* 216 */     String str = "&content-type-id=" + i + "&" + "paging-mode" + "=" + Character.MIN_VALUE + "&" + "current-page" + "=" + m + "&" + "sort-mode" + "=" + n + "&" + "sort-direction" + "=" + i1;
/*     */ 
/*     */     
/* 219 */     Form form = buildContentTypeInstancesListForm(paramContext, str);
/*     */ 
/*     */     
/* 222 */     fornaxContentTypeInstanceManager.setForm(form);
/*     */ 
/*     */     
/* 225 */     paramContext.putDelivery("ContentType", fornaxContentTypeManager.getContentType(i));
/* 226 */     Vector vector = fornaxContentTypeInstanceManager.getContentTypeInstances(i, i2, n, i1);
/* 227 */     paramContext.putDelivery("ContentTypeInstances", vector);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 234 */     paramContext.putDelivery("LinkMainMenu", new String(String.valueOf(this.navigationCommandPrefix) + "main-menu"));
/* 235 */     paramContext.putDelivery("LinkLogout", new String(String.valueOf(this.navigationCommandPrefix) + "login" + "&" + "logout" + "=true"));
/* 236 */     paramContext.putDelivery("LinkContentManagement", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-list"));
/* 237 */     paramContext.putDelivery("LinkGenerationManagement", new String(String.valueOf(this.navigationCommandPrefix) + "generation-management"));
/* 238 */     paramContext.putDelivery("LinkContentTypeInstanceAdd", new String(String.valueOf(this.navigationCommandPrefix) + "content-editor" + "&" + "edit-mode" + "=" + Character.MIN_VALUE + "&" + "edit-action" + "=" + Character.MIN_VALUE + str + "&" + "instance-id" + "=" + "-1"));
/* 239 */     paramContext.putDelivery("LinkContentTypeInstanceCopy", new String(String.valueOf(this.navigationCommandPrefix) + "content-editor" + "&" + "edit-mode" + "=" + '\001' + "&" + "edit-action" + "=" + Character.MIN_VALUE + str + "&" + "instance-id" + "="));
/* 240 */     paramContext.putDelivery("LinkContentTypeInstanceEdit", new String(String.valueOf(this.navigationCommandPrefix) + "content-editor" + "&" + "edit-mode" + "=" + '\002' + "&" + "edit-action" + "=" + Character.MIN_VALUE + str + "&" + "instance-id" + "="));
/* 241 */     paramContext.putDelivery("LinkPageBackward", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + "&" + "content-type-id" + "=" + i + "&" + "paging-mode" + "=" + -1 + "&" + "current-page" + "=" + m + "&" + "sort-mode" + "=" + n + "&" + "sort-direction" + "=" + i1));
/* 242 */     paramContext.putDelivery("LinkPageForward", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + "&" + "content-type-id" + "=" + i + "&" + "paging-mode" + "=" + '\001' + "&" + "current-page" + "=" + m + "&" + "sort-mode" + "=" + n + "&" + "sort-direction" + "=" + i1));
/* 243 */     paramContext.putDelivery("LinkSortByID", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + "&" + "content-type-id" + "=" + i + "&" + "paging-mode" + "=" + Character.MIN_VALUE + "&" + "current-page" + "=" + m + "&" + "sort-mode" + "=" + Character.MIN_VALUE + "&" + "sort-direction" + "="));
/* 244 */     paramContext.putDelivery("LinkSortByName", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + "&" + "content-type-id" + "=" + i + "&" + "paging-mode" + "=" + Character.MIN_VALUE + "&" + "current-page" + "=" + m + "&" + "sort-mode" + "=" + '\001' + "&" + "sort-direction" + "="));
/* 245 */     paramContext.putDelivery("LinkSortByLastModifiedTimestamp", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + "&" + "content-type-id" + "=" + i + "&" + "paging-mode" + "=" + Character.MIN_VALUE + "&" + "current-page" + "=" + m + "&" + "sort-mode" + "=" + '\002' + "&" + "sort-direction" + "="));
/*     */     
/* 247 */     paramContext.putDelivery("current-page", new Integer(m));
/* 248 */     paramContext.putDelivery("number-of-pages", new Integer(fornaxContentTypeInstanceManager.getPageCount()));
/* 249 */     paramContext.putDelivery("sort-mode", new Integer(n));
/* 250 */     paramContext.putDelivery("sort-direction", new Integer(i1));
/*     */ 
/*     */     
/* 253 */     form.setValues(paramContext);
/*     */     
/* 255 */     if (form.isSubmitted()) {
/*     */       
/* 257 */       if (j == 1)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 262 */         this.log.debug("Updating form now....");
/* 263 */         fornaxContentTypeInstanceManager.updateInstanceStatusFlags(paramContext, form, vector);
/*     */       }
/*     */       else
/*     */       {
/* 267 */         this.log.debug("(2) reverting now...");
/* 268 */         form.revertCheckBoxes();
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 273 */       this.log.debug("(1) reverting now...");
/* 274 */       form.revertCheckBoxes();
/*     */     } 
/*     */ 
/*     */     
/* 278 */     paramContext.putDelivery("Form", form);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Form buildContentTypeInstancesListForm(Context paramContext, String paramString) {
/* 284 */     String str = String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + paramString + "&" + "instances-list-mode" + "=" + '\001';
/*     */     
/* 286 */     Form form = new Form(this.application, 
/* 287 */         "ContentTypeInstancesListForm", 
/* 288 */         str, 
/* 289 */         "POST");
/*     */     
/* 291 */     form.addSubmissionElement(new FormSubmitButton("submit-button", "Save Status Changes"));
/*     */     
/* 293 */     return form;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean buildContentTypeInstanceEditElements(Dispatcher paramDispatcher, Context paramContext) {
/*     */     Form form;
/* 300 */     int i = paramContext.getIntRequestValue("edit-mode", 0);
/* 301 */     int j = paramContext.getIntRequestValue("edit-action", 0);
/* 302 */     int k = paramContext.getIntRequestValue("instance-id", -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 308 */     int m = k;
/* 309 */     boolean bool = false;
/*     */     
/* 311 */     if (i == 1) {
/*     */       
/* 313 */       m = -1;
/* 314 */       bool = true;
/*     */     } 
/*     */ 
/*     */     
/* 318 */     int n = paramContext.getIntRequestValue("content-type-id", -1);
/* 319 */     int i1 = paramContext.getIntRequestValue("paging-mode", 0);
/* 320 */     int i2 = paramContext.getIntRequestValue("current-page", 1) + i1;
/* 321 */     int i3 = paramContext.getIntRequestValue("sort-mode", 0);
/* 322 */     int i4 = paramContext.getIntRequestValue("sort-direction", 0);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 327 */     String str1 = new String("&content-type-id=" + n + "&" + "paging-mode" + "=" + Character.MIN_VALUE + "&" + "current-page" + "=" + i2 + "&" + "sort-mode" + "=" + i3 + "&" + "sort-direction" + "=" + i4);
/*     */ 
/*     */     
/* 330 */     String str2 = new String("&content-type-id=" + n + "&" + "paging-mode" + "=" + Character.MIN_VALUE + "&" + "current-page" + "=" + -2 + "&" + "sort-mode" + "=" + Character.MIN_VALUE + "&" + "sort-direction" + "=" + Character.MIN_VALUE);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 335 */     if (i == 2) {
/* 336 */       form = buildContentTypeInstanceEditElementsForm(paramContext, m, str1, i, j);
/*     */     } else {
/* 338 */       form = buildContentTypeInstanceEditElementsForm(paramContext, m, str2, i, j);
/*     */     } 
/*     */ 
/*     */     
/* 342 */     FornaxContentTypeManager fornaxContentTypeManager = new FornaxContentTypeManager(this.application);
/* 343 */     FornaxContentTypeInstanceManager fornaxContentTypeInstanceManager = new FornaxContentTypeInstanceManager(this.application);
/*     */     
/* 345 */     fornaxContentTypeInstanceManager.setForm(form);
/*     */     
/* 347 */     this.log.debug("Browser currently detected as: " + GeminiHelper.getBrowserTypeName(GeminiHelper.getBrowserType(paramContext)));
/*     */     
/* 349 */     fornaxContentTypeInstanceManager.setBrowserType(GeminiHelper.getBrowserType(paramContext));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 355 */     paramContext.putDelivery("ContentType", fornaxContentTypeManager.getContentType(n));
/* 356 */     paramContext.putDelivery("ContentTypeInstance", fornaxContentTypeInstanceManager.getContentTypeInstance(k, n, bool));
/* 357 */     paramContext.putDelivery("ContentTypeInstanceFieldValues", fornaxContentTypeInstanceManager.getContentTypeInstanceFieldValues(k, n));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 362 */     paramContext.putDelivery("edit-mode", new Integer(i));
/* 363 */     paramContext.putDelivery("edit-action", new Integer(j));
/* 364 */     paramContext.putDelivery("content-type-id", new Integer(n));
/* 365 */     paramContext.putDelivery("instance-id", new Integer(k));
/*     */     
/* 367 */     paramContext.putDelivery("LinkMainMenu", new String(String.valueOf(this.navigationCommandPrefix) + "main-menu"));
/* 368 */     paramContext.putDelivery("LinkLogout", new String(String.valueOf(this.navigationCommandPrefix) + "login" + "&" + "logout" + "=true"));
/* 369 */     paramContext.putDelivery("LinkContentTypeInstancesList", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + str1));
/*     */ 
/*     */     
/* 372 */     form.setValues(paramContext);
/*     */     
/* 374 */     if (form.isSubmitted()) {
/*     */       
/* 376 */       this.log.debug("submission detected");
/*     */ 
/*     */       
/* 379 */       if (j == 0)
/*     */       {
/* 381 */         this.log.debug("Save in progress....");
/*     */ 
/*     */         
/* 384 */         if (!form.isUnchanged())
/*     */         {
/* 386 */           this.log.debug("Form has changes....");
/*     */ 
/*     */           
/* 389 */           FormValidation formValidation = form.validate();
/*     */           
/* 391 */           if (formValidation.isGood()) {
/*     */             
/* 393 */             this.log.debug("Form contents are valid...");
/*     */ 
/*     */ 
/*     */             
/* 397 */             ArrayList arrayList = new ArrayList();
/*     */ 
/*     */             
/* 400 */             if (fornaxContentTypeInstanceManager.updateContentTypeInstance(paramContext, form, i, arrayList)) {
/* 401 */               this.log.debug("Update completed successfullly");
/*     */             } else {
/* 403 */               this.log.debug("Update failed!!");
/*     */             } 
/*     */ 
/*     */             
/* 407 */             for (byte b = 0; arrayList.size() < 0; b++)
/*     */             {
/* 409 */               this.log.debug((String)arrayList.get(b));
/*     */             }
/* 411 */             return false;
/*     */           } 
/*     */ 
/*     */           
/* 415 */           this.log.debug("Form validation has errors");
/* 416 */           paramContext.putDelivery("FormValidation", formValidation);
/*     */         }
/*     */       
/*     */       }
/*     */       else
/*     */       {
/* 422 */         this.log.debug("EDT: (2) reverting checkboxes");
/* 423 */         form.revertCheckBoxes();
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 428 */       this.log.debug("EDT: (1) reverting checkboxes");
/* 429 */       form.revertCheckBoxes();
/*     */     } 
/*     */     
/* 432 */     paramContext.putDelivery("Form", form);
/* 433 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Form buildContentTypeInstanceEditElementsForm(Context paramContext, int paramInt1, String paramString, int paramInt2, int paramInt3) {
/* 439 */     String str = String.valueOf(this.navigationCommandPrefix) + "content-editor" + "&" + "edit-mode" + "=" + paramInt2 + "&" + "edit-action" + "=" + paramInt3 + paramString + "&" + "instance-id" + "=" + paramInt1;
/*     */     
/* 441 */     Form form = new Form(this.application, 
/* 442 */         "ContentTypeInstanceEditForm", 
/* 443 */         str, 
/* 444 */         "POST");
/* 445 */     if (paramInt2 == 0 || paramInt2 == 1) {
/* 446 */       form.addSubmissionElement(new FormSubmitButton("submit-button", "Create Content Item"));
/*     */     } else {
/* 448 */       form.addSubmissionElement(new FormSubmitButton("submit-button", "Save Changes"));
/*     */     } 
/* 450 */     return form;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean buildGenerationManagementElements(Context paramContext) {
/* 456 */     paramContext.putDelivery("LinkMainMenu", new String(String.valueOf(this.navigationCommandPrefix) + "main-menu"));
/* 457 */     paramContext.putDelivery("LinkLogout", new String(String.valueOf(this.navigationCommandPrefix) + "login" + "&" + "logout" + "=true"));
/* 458 */     paramContext.putDelivery("LinkRunGeneration", new String(String.valueOf(this.navigationCommandPrefix) + "generation-run"));
/*     */ 
/*     */ 
/*     */     
/* 462 */     String str = "";
/*     */ 
/*     */     
/* 465 */     Form form = buildGenerationManagerForm(paramContext, str);
/*     */ 
/*     */     
/* 468 */     FornaxGenerationManager fornaxGenerationManager = new FornaxGenerationManager(this.application);
/*     */ 
/*     */     
/* 471 */     fornaxGenerationManager.constructGenerationManagementElements(paramContext, form);
/*     */ 
/*     */     
/* 474 */     form.setValues(paramContext);
/*     */     
/* 476 */     if (form.isSubmitted()) {
/*     */ 
/*     */       
/* 479 */       if (!form.isUnchanged())
/*     */       {
/* 481 */         this.log.debug("Form has changes....");
/*     */ 
/*     */         
/* 484 */         FormValidation formValidation = form.validate();
/*     */         
/* 486 */         if (formValidation.isGood()) {
/*     */           
/* 488 */           this.log.debug("Form contents are valid...");
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 493 */           this.log.debug("Updating form now....");
/* 494 */           fornaxGenerationManager.updateGenerationManagementElements(paramContext, form);
/* 495 */           return false;
/*     */         } 
/*     */ 
/*     */         
/* 499 */         this.log.debug("Form validation has errors");
/* 500 */         paramContext.putDelivery("FormValidation", formValidation);
/*     */       
/*     */       }
/*     */       else
/*     */       {
/* 505 */         this.log.debug("NO changes were made to the form, so its contents must be valid...");
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 510 */         this.log.debug("Updating form now....");
/* 511 */         fornaxGenerationManager.updateGenerationManagementElements(paramContext, form);
/* 512 */         return false;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 517 */       this.log.debug("(2) reverting now...");
/* 518 */       form.revertCheckBoxes();
/*     */     } 
/*     */ 
/*     */     
/* 522 */     paramContext.putDelivery("Form", form);
/* 523 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Form buildGenerationManagerForm(Context paramContext, String paramString) {
/* 530 */     String str = String.valueOf(this.navigationCommandPrefix) + "generation-management";
/*     */     
/* 532 */     Form form = new Form(this.application, 
/* 533 */         "GenerationForm", 
/* 534 */         str, 
/* 535 */         "POST");
/*     */     
/* 537 */     form.addSubmissionElement(new FormSubmitButton("submit-button", "Generate"));
/*     */     
/* 539 */     return form;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxNavigationHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */