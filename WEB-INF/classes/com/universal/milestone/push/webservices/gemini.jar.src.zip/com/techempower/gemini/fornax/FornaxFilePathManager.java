package com.techempower.gemini.fornax;

import com.techempower.ComponentLog;
import com.techempower.gemini.Form;
import com.techempower.gemini.GeminiApplication;
import java.util.Vector;

public class FornaxFilePathManager implements FornaxConstants {
  public static final String COMPONENT_CODE = "fMng";
  
  public GeminiApplication application;
  
  public ComponentLog log;
  
  public FornaxSettings fornaxSettings;
  
  protected Vector filePaths;
  
  public FornaxFilePathManager(GeminiApplication paramGeminiApplication) {
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("fMng");
    this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
  }
  
  public String getDescription() { return "Fornax File Path Manager"; }
  
  public FornaxFilePath getFilePath(int paramInt) {
    String str = 
      
      "SELECT * FROM fnFilePath WHERE FilePathID = " + 
      paramInt;
    Vector vector = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxFilePath", 
        true, 
        this.fornaxSettings);
    if (vector.size() == 1)
      return (FornaxFilePath)vector.get(0); 
    return null;
  }
  
  public Vector getFilePaths() {
    String str = 
      
      "SELECT * FROM fnFilePath ORDER BY FilePathID";
    this.filePaths = null;
    this.filePaths = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxFilePath", 
        true, 
        this.fornaxSettings);
    return this.filePaths;
  }
  
  public void updateFilePath(Form paramForm, FornaxFilePath paramFornaxFilePath) {
    String str = paramForm.getStringValue("file-path-" + paramFornaxFilePath.getID());
    if (str != null)
      paramFornaxFilePath.setPathName(str); 
    paramFornaxFilePath.updateDatabase(this.fornaxSettings.getConnector(""));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxFilePathManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */