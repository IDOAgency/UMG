/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.gemini.Form;
/*     */ import com.techempower.gemini.GeminiApplication;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxFilePathManager
/*     */   implements FornaxConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "fMng";
/*     */   public GeminiApplication application;
/*     */   public ComponentLog log;
/*     */   public FornaxSettings fornaxSettings;
/*     */   protected Vector filePaths;
/*     */   
/*     */   public FornaxFilePathManager(GeminiApplication paramGeminiApplication) {
/*  60 */     this.application = paramGeminiApplication;
/*  61 */     this.log = paramGeminiApplication.getLog("fMng");
/*  62 */     this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public String getDescription() { return "Fornax File Path Manager"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FornaxFilePath getFilePath(int paramInt) {
/*  80 */     String str = 
/*     */ 
/*     */       
/*  83 */       "SELECT * FROM fnFilePath WHERE FilePathID = " + 
/*  84 */       paramInt;
/*     */     
/*  86 */     Vector vector = 
/*  87 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/*  88 */         "com.techempower.gemini.fornax.FornaxFilePath", 
/*  89 */         true, 
/*  90 */         this.fornaxSettings);
/*     */     
/*  92 */     if (vector.size() == 1)
/*     */     {
/*  94 */       return (FornaxFilePath)vector.get(0);
/*     */     }
/*     */ 
/*     */     
/*  98 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getFilePaths() {
/* 109 */     String str = 
/*     */ 
/*     */       
/* 112 */       "SELECT * FROM fnFilePath ORDER BY FilePathID";
/*     */ 
/*     */ 
/*     */     
/* 116 */     this.filePaths = null;
/* 117 */     this.filePaths = 
/* 118 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/* 119 */         "com.techempower.gemini.fornax.FornaxFilePath", 
/* 120 */         true, 
/* 121 */         this.fornaxSettings);
/*     */     
/* 123 */     return this.filePaths;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateFilePath(Form paramForm, FornaxFilePath paramFornaxFilePath) {
/* 133 */     String str = paramForm.getStringValue("file-path-" + paramFornaxFilePath.getID());
/*     */     
/* 135 */     if (str != null) {
/* 136 */       paramFornaxFilePath.setPathName(str);
/*     */     }
/* 138 */     paramFornaxFilePath.updateDatabase(this.fornaxSettings.getConnector(""));
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxFilePathManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */