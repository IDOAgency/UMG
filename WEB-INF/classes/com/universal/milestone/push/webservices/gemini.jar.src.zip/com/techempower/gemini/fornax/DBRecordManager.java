package com.techempower.gemini.fornax;

import com.techempower.DatabaseConnector;

public class DBRecordManager implements FornaxDBConstants, FornaxSQLStatements {
  protected boolean debug = true;
  
  public void deleteContentTypeInstance(int paramInt) {
    Integer integer = new Integer(paramInt);
    System.out.println("  ***   Deleting Record from database START  *** ");
    String str = FornaxHelper.replaceParameters("DELETE FROM fnContentTypeDateValue WHERE DateValueInstanceID = @instanceID", "@instanceID", integer.toString());
    if (this.debug)
      System.out.println(str); 
    DatabaseConnector databaseConnector = FornaxDBConnector.getConnector(str);
    databaseConnector.runQuery();
    str = FornaxHelper.replaceParameters("DELETE FROM fnContentTypeIntegerValue WHERE IntegerValueInstanceID = @instanceID", "@instanceID", integer.toString());
    databaseConnector.setQuery(str);
    databaseConnector.runQuery();
    str = FornaxHelper.replaceParameters("DELETE FROM fnContentTypeFloatingPointValue WHERE FloatingPointValueInstanceID = @instanceID", "@instanceID", integer.toString());
    databaseConnector.setQuery(str);
    databaseConnector.runQuery();
    str = FornaxHelper.replaceParameters("DELETE FROM fnContentTypeStringValue WHERE StringValueInstanceID = @instanceID", "@instanceID", integer.toString());
    databaseConnector.setQuery(str);
    databaseConnector.runQuery();
    str = FornaxHelper.replaceParameters("DELETE FROM fnMapContentTypeInstanceToInstancesGroup WHERE InstanceID = @instanceID", "@instanceID", integer.toString());
    databaseConnector.setQuery(str);
    databaseConnector.runQuery();
    str = FornaxHelper.replaceParameters("DELETE FROM fnContentTypeInstance WHERE InstanceID = @instanceID", "@instanceID", integer.toString());
    databaseConnector.setQuery(str);
    databaseConnector.runQuery();
    System.out.println("        InstanceID[" + paramInt + "]");
    System.out.println("  ***   Deleting Record from database END  *** ");
    databaseConnector.close();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\DBRecordManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */