/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentTypeInstance
/*     */   implements FornaxDBConstants
/*     */ {
/*     */   protected boolean debug;
/*     */   protected int mInstanceID;
/*     */   protected String mName;
/*     */   protected String mDescription;
/*     */   protected int mGroupID;
/*     */   protected String mGroupName;
/*     */   protected int mContentTypeID;
/*     */   protected String mContentTypeName;
/*     */   protected int mSequenceNO;
/*     */   protected boolean mIsDisabled;
/*     */   protected boolean mIsQueuedForDeletion;
/*     */   protected String mDateCreated;
/*     */   protected int mLastModifiedUserID;
/*     */   protected String mLastModifiedTimestamp;
/*     */   protected Vector mFields;
/*     */   
/*     */   public ContentTypeInstance(Hashtable paramHashtable) {
/*  37 */     this.debug = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     this.mFields = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     this.mInstanceID = ((Integer)paramHashtable.get("instanceID")).intValue();
/*  61 */     this.mName = (String)paramHashtable.get("instanceName");
/*  62 */     this.mDescription = (String)paramHashtable.get("instanceDescription");
/*  63 */     this.mGroupID = ((Integer)paramHashtable.get("instanceGroupID")).intValue();
/*  64 */     this.mGroupName = (String)paramHashtable.get("instancesGroupName");
/*  65 */     this.mContentTypeID = ((Integer)paramHashtable.get("instanceContentTypeID")).intValue();
/*  66 */     this.mContentTypeName = (String)paramHashtable.get("ContentTypeName");
/*  67 */     this.mSequenceNO = ((Integer)paramHashtable.get("instanceSequenceNumber")).intValue();
/*  68 */     this.mIsDisabled = ((Boolean)paramHashtable.get("instanceIsDisabled")).booleanValue();
/*  69 */     this.mIsQueuedForDeletion = ((Boolean)paramHashtable.get("instanceIsQueuedForDeletion")).booleanValue();
/*  70 */     this.mDateCreated = (String)paramHashtable.get("instanceDateCreated");
/*  71 */     this.mLastModifiedUserID = ((Integer)paramHashtable.get("instanceLastModifiedByUserID")).intValue();
/*  72 */     this.mLastModifiedTimestamp = (String)paramHashtable.get("instanceLastModifiedTimeStamp");
/*  73 */     this.mFields = (Vector)paramHashtable.get("instanceFields");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public int getInstanceID() { return this.mInstanceID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public String getName() { return this.mName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public String getDescription() { return this.mDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public int getGroupID() { return this.mGroupID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public String getGroupName() { return this.mGroupName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public String getContentTypeName() { return this.mContentTypeName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public int getSequenceNO() { return this.mSequenceNO; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public boolean isDisabled() { return this.mIsDisabled; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public boolean isQueuedForDeletion() { return this.mIsQueuedForDeletion; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public String getDateCreated() { return this.mDateCreated; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   public int getLastModifiedByUserID() { return this.mLastModifiedUserID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   public String getLastModifiedTimestamp() { return this.mLastModifiedTimestamp; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldValueByName(String paramString) {
/* 193 */     String str = null;
/*     */ 
/*     */     
/* 196 */     if (this.debug) {
/*     */       
/* 198 */       System.out.println("fieldname " + paramString);
/* 199 */       System.out.println(" there are this may fields = " + this.mFields.size());
/*     */     } 
/*     */     
/* 202 */     for (byte b = 0; b < this.mFields.size(); b++) {
/*     */ 
/*     */       
/* 205 */       ContentTypeField contentTypeField = (ContentTypeField)this.mFields.elementAt(b);
/*     */       
/* 207 */       if (this.debug)
/*     */       {
/* 209 */         System.out.println("the field name from the obj is = " + contentTypeField.getFieldName());
/*     */       }
/*     */       
/* 212 */       if (contentTypeField.getFieldName().equalsIgnoreCase(paramString)) {
/*     */ 
/*     */         
/* 215 */         if (this.debug)
/*     */         {
/* 217 */           System.out.println("found the field ... and now trying to get the value . . .");
/*     */         }
/*     */         
/* 220 */         if (this.mFields.elementAt(b) instanceof ContentTypeFieldDate) {
/*     */           
/* 222 */           ContentTypeFieldDate contentTypeFieldDate = (ContentTypeFieldDate)this.mFields.elementAt(b);
/* 223 */           str = contentTypeFieldDate.getFieldValue();
/*     */           break;
/*     */         } 
/* 226 */         if (this.mFields.elementAt(b) instanceof ContentTypeFieldInteger) {
/*     */           
/* 228 */           ContentTypeFieldInteger contentTypeFieldInteger = (ContentTypeFieldInteger)this.mFields.elementAt(b);
/* 229 */           str = contentTypeFieldInteger.getFieldValue();
/*     */           break;
/*     */         } 
/* 232 */         if (this.mFields.elementAt(b) instanceof ContentTypeFieldFloat) {
/*     */           
/* 234 */           ContentTypeFieldFloat contentTypeFieldFloat = (ContentTypeFieldFloat)this.mFields.elementAt(b);
/* 235 */           str = contentTypeFieldFloat.getFieldValue();
/*     */           break;
/*     */         } 
/* 238 */         if (this.mFields.elementAt(b) instanceof ContentTypeFieldString) {
/*     */           
/* 240 */           ContentTypeFieldString contentTypeFieldString = (ContentTypeFieldString)this.mFields.elementAt(b);
/* 241 */           str = contentTypeFieldString.getFieldValue();
/*     */         } 
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 250 */     return str;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\ContentTypeInstance.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */