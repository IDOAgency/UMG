/*    */ package com.techempower.gemini.pyxis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PyxisStandardGroup
/*    */   extends BasicUserGroup
/*    */ {
/* 51 */   public PyxisStandardGroup(PyxisSettings paramPyxisSettings) { super(paramPyxisSettings); }
/*    */   
/*    */   public void setGroupID(int paramInt) {}
/*    */   
/*    */   public void setName(String paramString) {}
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\pyxis\PyxisStandardGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */