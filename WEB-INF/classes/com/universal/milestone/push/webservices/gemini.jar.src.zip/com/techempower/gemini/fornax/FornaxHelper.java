package com.techempower.gemini.fornax;

import com.techempower.BasicHelper;
import com.techempower.DataEntity;
import com.techempower.DatabaseConnector;
import com.techempower.gemini.GeminiApplication;
import java.util.Calendar;
import java.util.StringTokenizer;
import java.util.Vector;

public class FornaxHelper extends BasicHelper implements FornaxConstants {
  protected FornaxSettings fornaxSettings;
  
  public FornaxHelper(FornaxSettings paramFornaxSettings) { this.fornaxSettings = paramFornaxSettings; }
  
  public static Vector getDataEntities(Class paramClass, DatabaseConnector paramDatabaseConnector, boolean paramBoolean) {
    Vector vector = new Vector();
    while (paramDatabaseConnector.more()) {
      try {
        DataEntity dataEntity = (DataEntity)paramClass.newInstance();
        if (paramBoolean) {
          dataEntity.initializeByMethods(paramDatabaseConnector);
        } else {
          dataEntity.initializeByVariables(paramDatabaseConnector);
        } 
        vector.addElement(dataEntity);
      } catch (Exception exception) {}
      paramDatabaseConnector.next();
    } 
    paramDatabaseConnector.close();
    return vector;
  }
  
  public static Vector buildCacheVector(String paramString1, String paramString2, boolean paramBoolean, FornaxSettings paramFornaxSettings) {
    DatabaseConnector databaseConnector = paramFornaxSettings.getConnector(paramString1);
    null = new Vector();
    try {
      databaseConnector.runQuery();
      return getDataEntities(Class.forName(paramString2), databaseConnector, paramBoolean);
    } catch (Exception exception) {
    
    } finally {
      databaseConnector.close();
    } 
    return null;
  }
  
  public static void installHandlers(GeminiApplication paramGeminiApplication) {
    paramGeminiApplication.getDispatcher().getDispatchHandlers().addElement(new FornaxLoginHandler(paramGeminiApplication));
    paramGeminiApplication.getDispatcher().getDispatchHandlers().addElement(new FornaxNavigationHandler(paramGeminiApplication));
    paramGeminiApplication.getDispatcher().getDispatchHandlers().addElement(new FornaxGenerationHandler(paramGeminiApplication));
    paramGeminiApplication.getApplicationLog().log("FRNX: Handlers successfully installed.");
  }
  
  public static String replaceParameters(String paramString1, String paramString2, String paramString3) {
    while (paramString1.indexOf(paramString2) > -1) {
      StringBuffer stringBuffer = new StringBuffer(paramString1);
      int i = paramString1.indexOf(paramString2);
      int j = paramString1.indexOf(paramString2) + paramString2.length();
      paramString1 = stringBuffer.replace(i, j, paramString3).toString();
    } 
    return paramString1;
  }
  
  public static Vector getPageOfVectorObjects(Vector paramVector, int paramInt1, int paramInt2) {
    if (paramVector != null) {
      int i = paramVector.size();
      int j = (paramInt1 - 1) * paramInt2;
      int k = paramInt1 * paramInt2 - 1;
      if (j < 0)
        j = 0; 
      if (k > i - 1)
        k = i - 1; 
      Vector vector = new Vector();
      for (int m = j; m <= k; m++)
        vector.add(paramVector.get(m)); 
      return vector;
    } 
    return null;
  }
  
  public static Calendar getInitializedCalendar(String paramString) {
    Calendar calendar = null;
    try {
      calendar = BasicHelper.parseComplexDate(paramString);
    } catch (Exception exception) {
      System.out.println("Exception raised: " + exception.toString());
    } 
    if (calendar != null) {
      calendar.set(14, 0);
    } else {
      calendar = Calendar.getInstance();
      calendar.clear();
      calendar.set(1900, 0, 1, 0, 0, 0);
      calendar.set(14, 0);
    } 
    return calendar;
  }
  
  public static String formatFilePath(String paramString) {
    String str = "";
    if (paramString.startsWith("\\\\"))
      str = "\\\\\\\\"; 
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, "\\");
    while (stringTokenizer.hasMoreTokens())
      str = String.valueOf(str) + stringTokenizer.nextToken() + "\\\\"; 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */