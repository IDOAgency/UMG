/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Report
/*     */   implements Cloneable
/*     */ {
/*     */   private String mstrSection;
/*     */   private String mstrDateTime;
/*     */   private Vector mvectActions;
/*     */   private String mstrError;
/*     */   private FornaxSettings mFornaxSettings;
/*     */   private File mfLogFile;
/*     */   private FileWriter mWriter;
/*     */   private PrintWriter mErrorStream;
/*     */   private Exception mException;
/*     */   protected String mHTMLReport;
/*     */   
/*     */   public Report(File paramFile, FornaxSettings paramFornaxSettings) {
/*  33 */     this.mstrSection = "";
/*  34 */     this.mstrDateTime = "none";
/*  35 */     this.mvectActions = new Vector(3);
/*  36 */     this.mstrError = "none";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  43 */     this.mException = null;
/*     */ 
/*     */ 
/*     */     
/*  47 */     this.mHTMLReport = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     this.mfLogFile = paramFile;
/* 128 */     this.mstrError = "none";
/* 129 */     setDateTime();
/* 130 */     this.mFornaxSettings = paramFornaxSettings;
/*     */ 
/*     */     
/*     */     try {
/* 134 */       this.mWriter = new FileWriter(this.mfLogFile.getPath(), false);
/* 135 */       this.mErrorStream = new PrintWriter(this.mWriter);
/*     */     }
/* 137 */     catch (IOException iOException) {
/*     */       
/* 139 */       this.mstrError = iOException.toString();
/* 140 */       this.mfLogFile = null;
/* 141 */       this.mWriter = null;
/* 142 */       System.out.println(iOException);
/*     */     } 
/*     */   }
/*     */   private static final String REPORT_HEADER = "<table width='800' cellpadding='0' cellspacing='0' border='0'> <tr><td colspan='5' class='pageHeaderText'>&nbsp;GENERATION STATUS REPORT</td></tr> <tr><td colspan='5'>&nbsp;</td></tr> <tr><td colspan='5'> <table cellpadding='0' cellspacing='0' border='0' align='center' width='95%'> <tr><td width='15%'>&nbsp;</td><td width='25%'>&nbsp;</td><td width='25%'>&nbsp;</td><td width='15%'>&nbsp;</td> <td width='20%' align='right' valign='middle'>&nbsp;</td></tr> "; private static final String REPORT_LINE_SPACER = "<tr><td colspan='5'>&nbsp;</td></tr>"; private static final String REPORT_END = "</table></td></tr><tr><td colspan='5'>&nbsp;</td></tr></table> "; private static final String REPORT_CONTENTTYPE_HEADER = "<!-- content type header --> <tr class='listHeaderText'><td colspan='3' class='listHeaderText'>&nbsp;&nbsp;@CONTENTTYPE</td> <td colspan='2' align='right' class='listHeaderText'>&nbsp;</td></tr> ";
/*     */   private static final String REPORT_CONTENTTYPEGROUP_HEADER = "<!-- content type group header -->  <tr>  <td colspan='5' class='contentTextLightBlue'><img src='../images/pixel.gif' width='5' height='1'><B>@GROUP</B></td>  </tr> ";
/*     */   private static final String REPORT_LISTPAGE_HEADER = "<!-- LIST PAGE --> <tr><td algin='left' class='fieldHeaderText' colspan='5'>LIST PAGE</td></tr> <tr> <td align='left' class='fieldHeaderText'>&nbsp;</td> <td align='left' class='fieldHeaderText'>&nbsp;</td> <td align='left' class='fieldHeaderText'>File Name</td> <td align='left' class='fieldHeaderText'>Date / Time </td> <td align='left' class='fieldHeaderText' colspan='1'>Notes</td> </tr> <tr><td colspan='5' bgcolor='#001752'><img src='../images/pixel.gif' width='1' height='2'></td> </tr>\t";
/*     */   private static final String REPORT_LISTPAGE_LINE = "<tr><td align='left' valign='top' class='contentText'> &nbsp;</td> <td align='left' valign='top' class='contentText'>&nbsp;</td> <td align='left' valign='top' class='contentText'> NO FILE GENERATED </td> <td align='left' valign='top' class='contentText'> NONE </td> <td align='left' valign='top' class='contentText'> NO ERRORS </td> </tr>";
/*     */   private static final String REPORT_CONTENT_ITEM_HEADER = "<!-- CONTENT ITEMS  --> <tr><td algin='left' class='fieldHeaderText' colspan='5' >CONTENT ITEM</td></tr><tr> <td align='left' class='fieldHeaderText'>[ID]&nbsp;Variant</td> <td align='left' class='fieldHeaderText'>[ID]&nbsp;Content Item</td> <td align='left' class='fieldHeaderText'>File Name</td> <td align='left' class='fieldHeaderText'>Date / Time</td> <td align='left' class='fieldHeaderText'>Notes</td> </tr> <tr><td colspan='5' bgcolor='#001752'><img src='../images/pixel.gif' width='1' height='2'></td></tr>\t";
/*     */   private static final String REPORT_CONTENT_ITEM_LINE = "<tr><td align='left' valign='top' class='contentText'> [@VARIANT_ID] @VARIANT_TYPE </td> <td align='left' valign='top' class='contentText'> [@INSTANCE_ID] @INSTANCE_NAME</td> <td align='left' valign='top' class='contentText'> NO FILE GENERATED </td><td align='left' valign='top' class='contentText'> NONE </td><td align='left' valign='top' class='contentText'> NO ERRORS </td> </tr>";
/*     */   private static final String REPORT_NO_INSTANCE_FILE_LINE = "<tr><td align='left' valign='top' class='contentText'> &nbsp; </td> <td align='left' valign='top' class='contentText' colspan='4'> Instance File not enabled for generation for this group.</td> </tr>";
/*     */   
/* 153 */   public void startReport() { writeToReport("<table width='800' cellpadding='0' cellspacing='0' border='0'> <tr><td colspan='5' class='pageHeaderText'>&nbsp;GENERATION STATUS REPORT</td></tr> <tr><td colspan='5'>&nbsp;</td></tr> <tr><td colspan='5'> <table cellpadding='0' cellspacing='0' border='0' align='center' width='95%'> <tr><td width='15%'>&nbsp;</td><td width='25%'>&nbsp;</td><td width='25%'>&nbsp;</td><td width='15%'>&nbsp;</td> <td width='20%' align='right' valign='middle'>&nbsp;</td></tr> "); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startContentTypeReport(ContentType paramContentType) {
/* 162 */     String str = FornaxHelper.replaceParameters("<!-- content type header --> <tr class='listHeaderText'><td colspan='3' class='listHeaderText'>&nbsp;&nbsp;@CONTENTTYPE</td> <td colspan='2' align='right' class='listHeaderText'>&nbsp;</td></tr> ", "@CONTENTTYPE", paramContentType.getContentTypeName());
/* 163 */     writeToReport(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startContentTypeGroupReport(ContentTypeInstanceGroup paramContentTypeInstanceGroup) {
/* 172 */     String str = FornaxHelper.replaceParameters("<!-- content type group header -->  <tr>  <td colspan='5' class='contentTextLightBlue'><img src='../images/pixel.gif' width='5' height='1'><B>@GROUP</B></td>  </tr> ", "@GROUP", paramContentTypeInstanceGroup.getGroupName());
/* 173 */     writeToReport(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 181 */   public void startListPageReport() { writeToReport("<!-- LIST PAGE --> <tr><td algin='left' class='fieldHeaderText' colspan='5'>LIST PAGE</td></tr> <tr> <td align='left' class='fieldHeaderText'>&nbsp;</td> <td align='left' class='fieldHeaderText'>&nbsp;</td> <td align='left' class='fieldHeaderText'>File Name</td> <td align='left' class='fieldHeaderText'>Date / Time </td> <td align='left' class='fieldHeaderText' colspan='1'>Notes</td> </tr> <tr><td colspan='5' bgcolor='#001752'><img src='../images/pixel.gif' width='1' height='2'></td> </tr>\t"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 193 */   public void addNewListPageLineReport() { writeToReport("<tr><td align='left' valign='top' class='contentText'> &nbsp;</td> <td align='left' valign='top' class='contentText'>&nbsp;</td> <td align='left' valign='top' class='contentText'> NO FILE GENERATED </td> <td align='left' valign='top' class='contentText'> NONE </td> <td align='left' valign='top' class='contentText'> NO ERRORS </td> </tr>"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   public void noInstanceFileGeneration() { writeToReport("<tr><td align='left' valign='top' class='contentText'> &nbsp; </td> <td align='left' valign='top' class='contentText' colspan='4'> Instance File not enabled for generation for this group.</td> </tr>"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateLine(String paramString1, String paramString2) {
/* 215 */     if (paramString1 != "")
/*     */     {
/*     */       
/* 218 */       this.mHTMLReport = replaceWithUpdate("NO FILE GENERATED", paramString1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 223 */     if (paramString2 != "")
/*     */     {
/* 225 */       this.mHTMLReport = replaceWithUpdate("NO ERRORS", paramString2);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 230 */     setDateTime();
/* 231 */     this.mHTMLReport = FornaxHelper.replaceParameters(this.mHTMLReport, "NONE", this.mstrDateTime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String replaceWithUpdate(String paramString1, String paramString2) {
/* 240 */     StringBuffer stringBuffer = new StringBuffer(this.mHTMLReport);
/* 241 */     int i = this.mHTMLReport.lastIndexOf(paramString1) + paramString1.length();
/* 242 */     int j = this.mHTMLReport.lastIndexOf(paramString1);
/*     */     
/* 244 */     if (j != -1)
/*     */     {
/* 246 */       stringBuffer = stringBuffer.replace(this.mHTMLReport.lastIndexOf(paramString1), this.mHTMLReport.lastIndexOf(paramString1) + paramString1.length(), paramString2);
/*     */     }
/*     */     
/* 249 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 258 */   public void addSpacerLine() { writeToReport("<tr><td colspan='5'>&nbsp;</td></tr>"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 266 */   public void startContentItemReport() { writeToReport("<!-- CONTENT ITEMS  --> <tr><td algin='left' class='fieldHeaderText' colspan='5' >CONTENT ITEM</td></tr><tr> <td align='left' class='fieldHeaderText'>[ID]&nbsp;Variant</td> <td align='left' class='fieldHeaderText'>[ID]&nbsp;Content Item</td> <td align='left' class='fieldHeaderText'>File Name</td> <td align='left' class='fieldHeaderText'>Date / Time</td> <td align='left' class='fieldHeaderText'>Notes</td> </tr> <tr><td colspan='5' bgcolor='#001752'><img src='../images/pixel.gif' width='1' height='2'></td></tr>\t"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addNewContentItem(Variant paramVariant, ContentTypeInstance paramContentTypeInstance) {
/* 277 */     String str = FornaxHelper.replaceParameters("<tr><td align='left' valign='top' class='contentText'> [@VARIANT_ID] @VARIANT_TYPE </td> <td align='left' valign='top' class='contentText'> [@INSTANCE_ID] @INSTANCE_NAME</td> <td align='left' valign='top' class='contentText'> NO FILE GENERATED </td><td align='left' valign='top' class='contentText'> NONE </td><td align='left' valign='top' class='contentText'> NO ERRORS </td> </tr>", "@VARIANT_ID", (new Integer(paramVariant.getVariantID())).toString());
/* 278 */     str = FornaxHelper.replaceParameters(str, "@VARIANT_TYPE", paramVariant.getVariantTypeCode());
/* 279 */     str = FornaxHelper.replaceParameters(str, "@INSTANCE_ID", (new Integer(paramContentTypeInstance.getInstanceID())).toString());
/* 280 */     str = FornaxHelper.replaceParameters(str, "@INSTANCE_NAME", paramContentTypeInstance.getName());
/*     */     
/* 282 */     writeToReport(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endReport() {
/* 292 */     writeToReport("</table></td></tr><tr><td colspan='5'>&nbsp;</td></tr></table> ");
/*     */     
/*     */     try {
/* 295 */       this.mWriter.write(this.mHTMLReport);
/* 296 */       this.mWriter.flush();
/* 297 */       this.mWriter.close();
/*     */     }
/* 299 */     catch (Exception exception) {
/*     */       
/* 301 */       System.out.println("Error : " + exception.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 311 */   protected void writeToReport(String paramString) { this.mHTMLReport = this.mHTMLReport.concat(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 321 */   public String getHTMLReportString() { return this.mHTMLReport; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 330 */   public void setDateTime(String paramString) { this.mstrDateTime = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 338 */   public void setDateTime() { setDateTime(DateFormat.getDateTimeInstance(3, 2).format(new Date())); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\Report.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */