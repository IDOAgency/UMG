package com.techempower.gemini.fornax;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.util.Date;
import java.util.Vector;

public class Report implements Cloneable {
  private String mstrSection;
  
  private String mstrDateTime;
  
  private Vector mvectActions;
  
  private String mstrError;
  
  private FornaxSettings mFornaxSettings;
  
  private File mfLogFile;
  
  private FileWriter mWriter;
  
  private PrintWriter mErrorStream;
  
  private Exception mException;
  
  protected String mHTMLReport;
  
  private static final String REPORT_HEADER = "<table width='800' cellpadding='0' cellspacing='0' border='0'> <tr><td colspan='5' class='pageHeaderText'>&nbsp;GENERATION STATUS REPORT</td></tr> <tr><td colspan='5'>&nbsp;</td></tr> <tr><td colspan='5'> <table cellpadding='0' cellspacing='0' border='0' align='center' width='95%'> <tr><td width='15%'>&nbsp;</td><td width='25%'>&nbsp;</td><td width='25%'>&nbsp;</td><td width='15%'>&nbsp;</td> <td width='20%' align='right' valign='middle'>&nbsp;</td></tr> ";
  
  private static final String REPORT_LINE_SPACER = "<tr><td colspan='5'>&nbsp;</td></tr>";
  
  private static final String REPORT_END = "</table></td></tr><tr><td colspan='5'>&nbsp;</td></tr></table> ";
  
  private static final String REPORT_CONTENTTYPE_HEADER = "<!-- content type header --> <tr class='listHeaderText'><td colspan='3' class='listHeaderText'>&nbsp;&nbsp;@CONTENTTYPE</td> <td colspan='2' align='right' class='listHeaderText'>&nbsp;</td></tr> ";
  
  private static final String REPORT_CONTENTTYPEGROUP_HEADER = "<!-- content type group header -->  <tr>  <td colspan='5' class='contentTextLightBlue'><img src='../images/pixel.gif' width='5' height='1'><B>@GROUP</B></td>  </tr> ";
  
  private static final String REPORT_LISTPAGE_HEADER = "<!-- LIST PAGE --> <tr><td algin='left' class='fieldHeaderText' colspan='5'>LIST PAGE</td></tr> <tr> <td align='left' class='fieldHeaderText'>&nbsp;</td> <td align='left' class='fieldHeaderText'>&nbsp;</td> <td align='left' class='fieldHeaderText'>File Name</td> <td align='left' class='fieldHeaderText'>Date / Time </td> <td align='left' class='fieldHeaderText' colspan='1'>Notes</td> </tr> <tr><td colspan='5' bgcolor='#001752'><img src='../images/pixel.gif' width='1' height='2'></td> </tr>\t";
  
  private static final String REPORT_LISTPAGE_LINE = "<tr><td align='left' valign='top' class='contentText'> &nbsp;</td> <td align='left' valign='top' class='contentText'>&nbsp;</td> <td align='left' valign='top' class='contentText'> NO FILE GENERATED </td> <td align='left' valign='top' class='contentText'> NONE </td> <td align='left' valign='top' class='contentText'> NO ERRORS </td> </tr>";
  
  private static final String REPORT_CONTENT_ITEM_HEADER = "<!-- CONTENT ITEMS  --> <tr><td algin='left' class='fieldHeaderText' colspan='5' >CONTENT ITEM</td></tr><tr> <td align='left' class='fieldHeaderText'>[ID]&nbsp;Variant</td> <td align='left' class='fieldHeaderText'>[ID]&nbsp;Content Item</td> <td align='left' class='fieldHeaderText'>File Name</td> <td align='left' class='fieldHeaderText'>Date / Time</td> <td align='left' class='fieldHeaderText'>Notes</td> </tr> <tr><td colspan='5' bgcolor='#001752'><img src='../images/pixel.gif' width='1' height='2'></td></tr>\t";
  
  private static final String REPORT_CONTENT_ITEM_LINE = "<tr><td align='left' valign='top' class='contentText'> [@VARIANT_ID] @VARIANT_TYPE </td> <td align='left' valign='top' class='contentText'> [@INSTANCE_ID] @INSTANCE_NAME</td> <td align='left' valign='top' class='contentText'> NO FILE GENERATED </td><td align='left' valign='top' class='contentText'> NONE </td><td align='left' valign='top' class='contentText'> NO ERRORS </td> </tr>";
  
  private static final String REPORT_NO_INSTANCE_FILE_LINE = "<tr><td align='left' valign='top' class='contentText'> &nbsp; </td> <td align='left' valign='top' class='contentText' colspan='4'> Instance File not enabled for generation for this group.</td> </tr>";
  
  public Report(File paramFile, FornaxSettings paramFornaxSettings) {
    this.mstrSection = "";
    this.mstrDateTime = "none";
    this.mvectActions = new Vector(3);
    this.mstrError = "none";
    this.mException = null;
    this.mHTMLReport = "";
    this.mfLogFile = paramFile;
    this.mstrError = "none";
    setDateTime();
    this.mFornaxSettings = paramFornaxSettings;
    try {
      this.mWriter = new FileWriter(this.mfLogFile.getPath(), false);
      this.mErrorStream = new PrintWriter(this.mWriter);
    } catch (IOException iOException) {
      this.mstrError = iOException.toString();
      this.mfLogFile = null;
      this.mWriter = null;
      System.out.println(iOException);
    } 
  }
  
  public void startReport() { writeToReport("<table width='800' cellpadding='0' cellspacing='0' border='0'> <tr><td colspan='5' class='pageHeaderText'>&nbsp;GENERATION STATUS REPORT</td></tr> <tr><td colspan='5'>&nbsp;</td></tr> <tr><td colspan='5'> <table cellpadding='0' cellspacing='0' border='0' align='center' width='95%'> <tr><td width='15%'>&nbsp;</td><td width='25%'>&nbsp;</td><td width='25%'>&nbsp;</td><td width='15%'>&nbsp;</td> <td width='20%' align='right' valign='middle'>&nbsp;</td></tr> "); }
  
  public void startContentTypeReport(ContentType paramContentType) {
    String str = FornaxHelper.replaceParameters("<!-- content type header --> <tr class='listHeaderText'><td colspan='3' class='listHeaderText'>&nbsp;&nbsp;@CONTENTTYPE</td> <td colspan='2' align='right' class='listHeaderText'>&nbsp;</td></tr> ", "@CONTENTTYPE", paramContentType.getContentTypeName());
    writeToReport(str);
  }
  
  public void startContentTypeGroupReport(ContentTypeInstanceGroup paramContentTypeInstanceGroup) {
    String str = FornaxHelper.replaceParameters("<!-- content type group header -->  <tr>  <td colspan='5' class='contentTextLightBlue'><img src='../images/pixel.gif' width='5' height='1'><B>@GROUP</B></td>  </tr> ", "@GROUP", paramContentTypeInstanceGroup.getGroupName());
    writeToReport(str);
  }
  
  public void startListPageReport() { writeToReport("<!-- LIST PAGE --> <tr><td algin='left' class='fieldHeaderText' colspan='5'>LIST PAGE</td></tr> <tr> <td align='left' class='fieldHeaderText'>&nbsp;</td> <td align='left' class='fieldHeaderText'>&nbsp;</td> <td align='left' class='fieldHeaderText'>File Name</td> <td align='left' class='fieldHeaderText'>Date / Time </td> <td align='left' class='fieldHeaderText' colspan='1'>Notes</td> </tr> <tr><td colspan='5' bgcolor='#001752'><img src='../images/pixel.gif' width='1' height='2'></td> </tr>\t"); }
  
  public void addNewListPageLineReport() { writeToReport("<tr><td align='left' valign='top' class='contentText'> &nbsp;</td> <td align='left' valign='top' class='contentText'>&nbsp;</td> <td align='left' valign='top' class='contentText'> NO FILE GENERATED </td> <td align='left' valign='top' class='contentText'> NONE </td> <td align='left' valign='top' class='contentText'> NO ERRORS </td> </tr>"); }
  
  public void noInstanceFileGeneration() { writeToReport("<tr><td align='left' valign='top' class='contentText'> &nbsp; </td> <td align='left' valign='top' class='contentText' colspan='4'> Instance File not enabled for generation for this group.</td> </tr>"); }
  
  public void updateLine(String paramString1, String paramString2) {
    if (paramString1 != "")
      this.mHTMLReport = replaceWithUpdate("NO FILE GENERATED", paramString1); 
    if (paramString2 != "")
      this.mHTMLReport = replaceWithUpdate("NO ERRORS", paramString2); 
    setDateTime();
    this.mHTMLReport = FornaxHelper.replaceParameters(this.mHTMLReport, "NONE", this.mstrDateTime);
  }
  
  public String replaceWithUpdate(String paramString1, String paramString2) {
    StringBuffer stringBuffer = new StringBuffer(this.mHTMLReport);
    int i = this.mHTMLReport.lastIndexOf(paramString1) + paramString1.length();
    int j = this.mHTMLReport.lastIndexOf(paramString1);
    if (j != -1)
      stringBuffer = stringBuffer.replace(this.mHTMLReport.lastIndexOf(paramString1), this.mHTMLReport.lastIndexOf(paramString1) + paramString1.length(), paramString2); 
    return stringBuffer.toString();
  }
  
  public void addSpacerLine() { writeToReport("<tr><td colspan='5'>&nbsp;</td></tr>"); }
  
  public void startContentItemReport() { writeToReport("<!-- CONTENT ITEMS  --> <tr><td algin='left' class='fieldHeaderText' colspan='5' >CONTENT ITEM</td></tr><tr> <td align='left' class='fieldHeaderText'>[ID]&nbsp;Variant</td> <td align='left' class='fieldHeaderText'>[ID]&nbsp;Content Item</td> <td align='left' class='fieldHeaderText'>File Name</td> <td align='left' class='fieldHeaderText'>Date / Time</td> <td align='left' class='fieldHeaderText'>Notes</td> </tr> <tr><td colspan='5' bgcolor='#001752'><img src='../images/pixel.gif' width='1' height='2'></td></tr>\t"); }
  
  public void addNewContentItem(Variant paramVariant, ContentTypeInstance paramContentTypeInstance) {
    String str = FornaxHelper.replaceParameters("<tr><td align='left' valign='top' class='contentText'> [@VARIANT_ID] @VARIANT_TYPE </td> <td align='left' valign='top' class='contentText'> [@INSTANCE_ID] @INSTANCE_NAME</td> <td align='left' valign='top' class='contentText'> NO FILE GENERATED </td><td align='left' valign='top' class='contentText'> NONE </td><td align='left' valign='top' class='contentText'> NO ERRORS </td> </tr>", "@VARIANT_ID", (new Integer(paramVariant.getVariantID())).toString());
    str = FornaxHelper.replaceParameters(str, "@VARIANT_TYPE", paramVariant.getVariantTypeCode());
    str = FornaxHelper.replaceParameters(str, "@INSTANCE_ID", (new Integer(paramContentTypeInstance.getInstanceID())).toString());
    str = FornaxHelper.replaceParameters(str, "@INSTANCE_NAME", paramContentTypeInstance.getName());
    writeToReport(str);
  }
  
  public void endReport() {
    writeToReport("</table></td></tr><tr><td colspan='5'>&nbsp;</td></tr></table> ");
    try {
      this.mWriter.write(this.mHTMLReport);
      this.mWriter.flush();
      this.mWriter.close();
    } catch (Exception exception) {
      System.out.println("Error : " + exception.toString());
    } 
  }
  
  protected void writeToReport(String paramString) { this.mHTMLReport = this.mHTMLReport.concat(paramString); }
  
  public String getHTMLReportString() { return this.mHTMLReport; }
  
  public void setDateTime(String paramString) { this.mstrDateTime = paramString; }
  
  public void setDateTime() { setDateTime(DateFormat.getDateTimeInstance(3, 2).format(new Date())); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\Report.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */