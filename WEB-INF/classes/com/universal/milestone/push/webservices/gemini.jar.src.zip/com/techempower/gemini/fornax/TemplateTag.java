package com.techempower.gemini.fornax;

import java.util.Hashtable;

public abstract class TemplateTag implements FornaxDBConstants {
  protected String mContentType;
  
  protected String mContentTypeGroup;
  
  protected String mVariant;
  
  protected boolean mIsLoop;
  
  public TemplateTag(Hashtable paramHashtable, boolean paramBoolean) {
    this.mContentType = (String)paramHashtable.get("type=");
    this.mContentTypeGroup = (String)paramHashtable.get("typegroup=");
    this.mVariant = (String)paramHashtable.get("variant=");
    this.mIsLoop = paramBoolean;
  }
  
  public String getContentType() { return this.mContentType; }
  
  public String getContentTypeGroup() { return this.mContentTypeGroup; }
  
  public String getVariant() { return this.mVariant; }
  
  public boolean isLoop() { return this.mIsLoop; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\TemplateTag.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */