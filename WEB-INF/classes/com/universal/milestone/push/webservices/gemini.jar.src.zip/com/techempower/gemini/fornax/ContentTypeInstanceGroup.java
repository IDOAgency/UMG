/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentTypeInstanceGroup
/*     */   implements FornaxDBConstants
/*     */ {
/*     */   protected int mGroupID;
/*     */   protected String mGroupName;
/*     */   protected String mGroupDescription;
/*     */   protected boolean mIsSingleton;
/*     */   protected boolean mIsListPageGenerated;
/*     */   protected boolean mIsInstanceGenerationEnabled;
/*     */   protected String mGroupContentTypeName;
/*     */   protected ListPage mGroupListPage;
/*     */   protected Vector mGroupContentTypeInstances;
/*     */   protected Vector mGroupVariants;
/*     */   
/*     */   public ContentTypeInstanceGroup(Hashtable paramHashtable) {
/*  54 */     this.mGroupID = ((Integer)paramHashtable.get("InstancesGroupID")).intValue();
/*  55 */     this.mGroupName = (String)paramHashtable.get("InstancesGroupName");
/*  56 */     this.mGroupDescription = (String)paramHashtable.get("InstancesGroupDescription");
/*  57 */     this.mIsSingleton = ((Boolean)paramHashtable.get("InstancesGroupIsSingleton")).booleanValue();
/*  58 */     this.mIsListPageGenerated = ((Boolean)paramHashtable.get("InstancesGroupIsListPageGenerated")).booleanValue();
/*  59 */     this.mIsInstanceGenerationEnabled = ((Boolean)paramHashtable.get("InstancesGroupIsInstanceGenerationEnabled")).booleanValue();
/*  60 */     this.mGroupContentTypeName = (String)paramHashtable.get("contentTypeName");
/*     */     
/*  62 */     this.mGroupListPage = (ListPage)paramHashtable.get("groupListPage");
/*  63 */     this.mGroupContentTypeInstances = (Vector)paramHashtable.get("groupInstances");
/*  64 */     this.mGroupVariants = (Vector)paramHashtable.get("groupVariants");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public String getGroupContentTypeName() { return this.mGroupContentTypeName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public ListPage getGroupListPage() { return this.mGroupListPage; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public String getGroupName() { return this.mGroupName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public String getGroupDescription() { return this.mGroupDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public boolean isSingleton() { return this.mIsSingleton; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public boolean isInstanceGenerationEnabled() { return this.mIsInstanceGenerationEnabled; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public boolean isListPageGenerated() { return this.mIsListPageGenerated; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public Vector getGroupContentTypeInstances() { return this.mGroupContentTypeInstances; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public Vector getGroupVariants() { return this.mGroupVariants; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Variant getVariantByVariantTypeCode(String paramString) {
/* 155 */     Variant variant = null;
/*     */     
/* 157 */     System.out.println("Looking for variant = " + paramString);
/*     */     
/* 159 */     for (byte b = 0; b < this.mGroupVariants.size(); b++) {
/*     */       
/* 161 */       variant = (Variant)this.mGroupVariants.elementAt(b);
/* 162 */       if (variant.getVariantTypeCode().equalsIgnoreCase(paramString)) {
/*     */         break;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 168 */       variant = null;
/*     */     } 
/*     */ 
/*     */     
/* 172 */     return variant;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\ContentTypeInstanceGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */