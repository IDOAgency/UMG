package com.techempower.gemini.fornax;

import java.util.Hashtable;
import java.util.Vector;

public class ContentTypeInstanceGroup implements FornaxDBConstants {
  protected int mGroupID;
  
  protected String mGroupName;
  
  protected String mGroupDescription;
  
  protected boolean mIsSingleton;
  
  protected boolean mIsListPageGenerated;
  
  protected boolean mIsInstanceGenerationEnabled;
  
  protected String mGroupContentTypeName;
  
  protected ListPage mGroupListPage;
  
  protected Vector mGroupContentTypeInstances;
  
  protected Vector mGroupVariants;
  
  public ContentTypeInstanceGroup(Hashtable paramHashtable) {
    this.mGroupID = ((Integer)paramHashtable.get("InstancesGroupID")).intValue();
    this.mGroupName = (String)paramHashtable.get("InstancesGroupName");
    this.mGroupDescription = (String)paramHashtable.get("InstancesGroupDescription");
    this.mIsSingleton = ((Boolean)paramHashtable.get("InstancesGroupIsSingleton")).booleanValue();
    this.mIsListPageGenerated = ((Boolean)paramHashtable.get("InstancesGroupIsListPageGenerated")).booleanValue();
    this.mIsInstanceGenerationEnabled = ((Boolean)paramHashtable.get("InstancesGroupIsInstanceGenerationEnabled")).booleanValue();
    this.mGroupContentTypeName = (String)paramHashtable.get("contentTypeName");
    this.mGroupListPage = (ListPage)paramHashtable.get("groupListPage");
    this.mGroupContentTypeInstances = (Vector)paramHashtable.get("groupInstances");
    this.mGroupVariants = (Vector)paramHashtable.get("groupVariants");
  }
  
  public String getGroupContentTypeName() { return this.mGroupContentTypeName; }
  
  public ListPage getGroupListPage() { return this.mGroupListPage; }
  
  public String getGroupName() { return this.mGroupName; }
  
  public String getGroupDescription() { return this.mGroupDescription; }
  
  public boolean isSingleton() { return this.mIsSingleton; }
  
  public boolean isInstanceGenerationEnabled() { return this.mIsInstanceGenerationEnabled; }
  
  public boolean isListPageGenerated() { return this.mIsListPageGenerated; }
  
  public Vector getGroupContentTypeInstances() { return this.mGroupContentTypeInstances; }
  
  public Vector getGroupVariants() { return this.mGroupVariants; }
  
  public Variant getVariantByVariantTypeCode(String paramString) {
    Variant variant = null;
    System.out.println("Looking for variant = " + paramString);
    for (byte b = 0; b < this.mGroupVariants.size(); b++) {
      variant = (Variant)this.mGroupVariants.elementAt(b);
      if (variant.getVariantTypeCode().equalsIgnoreCase(paramString))
        break; 
      variant = null;
    } 
    return variant;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\ContentTypeInstanceGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */