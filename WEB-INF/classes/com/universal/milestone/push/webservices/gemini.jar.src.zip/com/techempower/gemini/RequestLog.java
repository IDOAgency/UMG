package com.techempower.gemini;

import com.techempower.ComponentLog;
import com.techempower.LogWriter;
import com.techempower.LogWriterCloser;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

public class RequestLog implements LogWriter {
  public static final String COMPONENT_CODE = "reqL";
  
  public static final String DEFAULT_REQUESTLOG_DIR = "logs";
  
  public static final String DEFAULT_SOFTWARE_NAME = "Servlet-dispatched web application";
  
  public static final String DEFAULT_VERSION = "1.0";
  
  public static final String DEFAULT_LOGFILE_EXT = ".log";
  
  public static final String DEFAULT_LOGFILE_PREFIX = "ex";
  
  public static final String FIELDS = "date time c-ip cs-method cs-uri-stem sc-status cs(User-Agent) cs(Referer) cs(Cookie)";
  
  protected static SimpleDateFormat filenameFormat = new SimpleDateFormat("yyMMdd");
  
  protected static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  
  protected static SimpleDateFormat timeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  
  protected static TimeZone gmtTimeZone = TimeZone.getTimeZone("GMT");
  
  protected ComponentLog log;
  
  static  {
    filenameFormat.setTimeZone(gmtTimeZone);
    dateFormat.setTimeZone(gmtTimeZone);
    timeFormat.setTimeZone(gmtTimeZone);
  }
  
  protected String softwareName = "Servlet-dispatched web application";
  
  protected String version = "1.0";
  
  protected String logDirectory = "logs" + File.separator;
  
  protected String logFilenamePre = "ex";
  
  protected String logFilenameSuf = ".log";
  
  protected String logFilename = null;
  
  protected int lastDay = 0;
  
  protected Calendar cal = Calendar.getInstance(gmtTimeZone);
  
  protected boolean enabled = false;
  
  protected boolean initialized = false;
  
  protected FileWriter fileWriter = null;
  
  protected Object lockObject = new Object();
  
  protected LogWriterCloser closer = LogWriterCloser.getInstance();
  
  public RequestLog(String paramString1, String paramString2, String paramString3, ComponentLog paramComponentLog) {
    this.log = paramComponentLog;
    setSoftwareName(paramString1);
    setVersion(paramString2);
    setLogDirectory(paramString3);
    this.closer.addLogWriter(this, String.valueOf(paramString1) + " request log");
  }
  
  public void setSoftwareName(String paramString) { this.softwareName = paramString; }
  
  public void setVersion(String paramString) { this.version = paramString; }
  
  public void setLogDirectory(String paramString) {
    if (paramString.endsWith(File.separator)) {
      this.logDirectory = paramString;
    } else {
      this.logDirectory = String.valueOf(paramString) + File.separator;
    } 
    this.initialized = false;
  }
  
  public void setLogFilenamePrefix(String paramString) { this.logFilenamePre = paramString; }
  
  public String getLogFilenamePrefix() { return this.logFilenamePre; }
  
  public void setLogFilenameSuffix(String paramString) { this.logFilenameSuf = paramString; }
  
  public String getLogFilenameSuffix() { return this.logFilenameSuf; }
  
  public void enable() {
    this.enabled = true;
    this.initialized = false;
  }
  
  public void disable() { this.enabled = false; }
  
  public void log(Context paramContext, String paramString) {
    if (this.enabled) {
      this.cal = Calendar.getInstance(gmtTimeZone);
      if (needNewFile() || !this.initialized)
        initialize(); 
      writeLogEntry(String.valueOf(this.logDirectory) + this.logFilename, constructLogItem(paramContext, paramString));
    } 
  }
  
  public boolean isOpen() { return !(this.fileWriter == null); }
  
  public void closeFile() {
    synchronized (this.lockObject) {
      try {
        if (this.fileWriter != null)
          this.fileWriter.close(); 
      } catch (IOException iOException) {
        this.log.debug("IOException while closing request log!");
      } 
      this.fileWriter = null;
    } 
  }
  
  public void closeFile(String paramString) {
    this.log.debug(paramString);
    closeFile();
  }
  
  protected void openFile(String paramString) {
    try {
      this.fileWriter = new FileWriter(paramString, true);
    } catch (IOException iOException) {
      this.log.debug("IOException while opening request log!");
    } 
  }
  
  protected void writeLogEntry(String paramString1, String paramString2) {
    try {
      this.closer.access(this);
      synchronized (this.lockObject) {
        if (this.fileWriter == null)
          openFile(paramString1); 
        this.fileWriter.write(paramString2);
        this.fileWriter.flush();
      } 
    } catch (IOException iOException) {
      this.log.debug("Could not write to request log: " + iOException);
    } 
  }
  
  protected String constructLogItem(Context paramContext, String paramString) {
    StringBuffer stringBuffer = new StringBuffer(100);
    stringBuffer.append(timeFormat.format(this.cal.getTime()));
    stringBuffer.append(' ');
    stringBuffer.append(paramContext.getClientIP());
    stringBuffer.append(' ');
    stringBuffer.append(paramContext.getRequestMethod());
    stringBuffer.append(' ');
    stringBuffer.append(paramString);
    stringBuffer.append(" 200 ");
    stringBuffer.append(getContextHeader(paramContext, "User-Agent"));
    stringBuffer.append(' ');
    stringBuffer.append(getContextHeader(paramContext, "Referer"));
    stringBuffer.append(' ');
    stringBuffer.append(paramContext.getCustomCookie());
    stringBuffer.append("\r\n");
    return stringBuffer.toString();
  }
  
  protected String getContextHeader(Context paramContext, String paramString) {
    String str = paramContext.getHeader(paramString);
    if (str == null) {
      str = "-";
    } else {
      str = str.replace(' ', '+');
    } 
    return str;
  }
  
  protected boolean needNewFile() {
    int i = this.cal.get(5);
    if (i != this.lastDay) {
      this.lastDay = i;
      return true;
    } 
    return false;
  }
  
  protected void initialize() {
    this.initialized = true;
    String str = filenameFormat.format(this.cal.getTime());
    this.logFilename = String.valueOf(this.logFilenamePre) + str + this.logFilenameSuf;
    File file = new File(String.valueOf(this.logDirectory) + this.logFilename);
    this.log.log("Setting request log file to: " + this.logFilename);
    if (!file.exists()) {
      synchronized (this.lockObject) {
        closeFile();
        openFile(String.valueOf(this.logDirectory) + this.logFilename);
        writeHeader(this.cal);
      } 
    } else {
      this.log.log("Request log file already exists.  Appending.");
      synchronized (this.lockObject) {
        closeFile();
        openFile(String.valueOf(this.logDirectory) + this.logFilename);
      } 
    } 
  }
  
  protected void writeHeader(Calendar paramCalendar) {
    try {
      synchronized (this.lockObject) {
        this.fileWriter.write("#Software: " + this.softwareName + "\r\n");
        this.fileWriter.write("#Version: " + this.version + "\r\n");
        this.fileWriter.write("#Date: " + dateFormat.format(paramCalendar.getTime()) + "\r\n");
        this.fileWriter.write("#Fields: date time c-ip cs-method cs-uri-stem sc-status cs(User-Agent) cs(Referer) cs(Cookie)\r\n");
        this.fileWriter.flush();
      } 
    } catch (IOException iOException) {
      this.log.debug("Could not write request log header: " + iOException);
    } 
  }
  
  public RequestLog() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\RequestLog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */