package com.techempower.gemini;

import com.techempower.BasicHelper;
import java.util.ArrayList;
import java.util.Calendar;

public class FormComplexDateField extends FormTextField {
  static int DEFAULT_LENGTH = 50;
  
  static String DEFAULT_VALUE = "";
  
  static Calendar DEFAULT_MIN_DATE = Calendar.getInstance();
  
  static Calendar DEFAULT_MAX_DATE;
  
  static  {
    DEFAULT_MIN_DATE.set(1900, 0, 1, 0, 0, 0);
    DEFAULT_MIN_DATE.set(14, 0);
    DEFAULT_MIN_DATE.set(9, 0);
    DEFAULT_MAX_DATE = Calendar.getInstance();
    DEFAULT_MAX_DATE.set(9999, 11, 31, 11, 59, 59);
    DEFAULT_MAX_DATE.set(14, 999);
    DEFAULT_MAX_DATE.set(9, 1);
  }
  
  ArrayList dateFormatters = null;
  
  Calendar minDate = null;
  
  Calendar maxDate = null;
  
  public FormComplexDateField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2, Calendar paramCalendar1, Calendar paramCalendar2) {
    super(paramString1, paramString2, paramBoolean, paramInt1, paramInt2);
    setMinimum(paramCalendar1);
    setMaximum(paramCalendar2);
    this.dateFormatters = BasicHelper.DEFAULT_DATE_FORMATTERS;
  }
  
  public FormComplexDateField(String paramString1, String paramString2, boolean paramBoolean, int paramInt, Calendar paramCalendar1, Calendar paramCalendar2) { this(paramString1, paramString2, paramBoolean, paramInt, paramInt, paramCalendar1, paramCalendar2); }
  
  public FormComplexDateField(String paramString1, String paramString2, boolean paramBoolean, int paramInt) { this(paramString1, paramString2, paramBoolean, paramInt, paramInt, DEFAULT_MIN_DATE, DEFAULT_MAX_DATE); }
  
  public FormComplexDateField(String paramString, boolean paramBoolean, int paramInt) { this(paramString, DEFAULT_VALUE, paramBoolean, paramInt); }
  
  public FormComplexDateField(String paramString, int paramInt) { this(paramString, DEFAULT_VALUE, false, paramInt); }
  
  public FormComplexDateField(String paramString, Calendar paramCalendar1, Calendar paramCalendar2) { this(paramString, DEFAULT_VALUE, false, DEFAULT_LENGTH, paramCalendar1, paramCalendar2); }
  
  public FormComplexDateField(String paramString) { this(paramString, DEFAULT_VALUE, false, DEFAULT_LENGTH); }
  
  public void setMinimum(Calendar paramCalendar) { this.minDate = paramCalendar; }
  
  public Calendar getMinimum() { return this.minDate; }
  
  public void setMaximum(Calendar paramCalendar) { this.maxDate = paramCalendar; }
  
  public Calendar getMaximum() { return this.maxDate; }
  
  public Calendar getDateValue() {
    if (BasicHelper.isValidDate(this.value, this.dateFormatters))
      return BasicHelper.parseComplexDate(this.value, this.dateFormatters); 
    return null;
  }
  
  protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
    super.requiredValidation(paramFormSingleValidation);
    if (this.dateFormatters != null && this.dateFormatters.size() > 0)
      this.dateFormatters = BasicHelper.DEFAULT_DATE_FORMATTERS; 
    if (this.value.trim().equalsIgnoreCase("")) {
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is empty.", 
          "Please provide input in the field named " + getDisplayName() + ".", 
          "This field requires input");
    } else if (BasicHelper.isValidDate(this.value, this.dateFormatters)) {
      if (this.minDate == null)
        this.minDate = DEFAULT_MIN_DATE; 
      if (this.maxDate == null)
        this.maxDate = DEFAULT_MAX_DATE; 
      Calendar calendar = getDateValue();
      if (calendar.before(this.minDate)) {
        paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is earlier than " + BasicHelper.getCalendarAsString(getMinimum(), 1, 2, "/", "") + ".", 
            String.valueOf(getDisplayName()) + " cannot be earlier than " + BasicHelper.getCalendarAsString(getMinimum(), 1, 2, "/", "") + ".", 
            "This field's value cannot be earlier than " + BasicHelper.getCalendarAsString(getMinimum(), 1, 2, "/", "") + ".");
      } else if (calendar.after(this.maxDate)) {
        paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is later than " + BasicHelper.getCalendarAsString(getMaximum(), 1, 2, "/", "") + ".", 
            String.valueOf(getDisplayName()) + " cannot be later than " + BasicHelper.getCalendarAsString(getMaximum(), 1, 2, "/", "") + ".", 
            "This field's value cannot be later than " + BasicHelper.getCalendarAsString(getMinimum(), 1, 2, "/", "") + ".");
      } 
    } else {
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is not in a valid format.", 
          String.valueOf(getDisplayName()) + " contains an incorrectly formatted date.", 
          "This field's value is incorrectly formatted.");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormComplexDateField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */