/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.BasicHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormComplexDateField
/*     */   extends FormTextField
/*     */ {
/*  37 */   static int DEFAULT_LENGTH = 50;
/*  38 */   static String DEFAULT_VALUE = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   static Calendar DEFAULT_MIN_DATE = Calendar.getInstance(); static  {
/*  46 */     DEFAULT_MIN_DATE.set(1900, 0, 1, 0, 0, 0);
/*  47 */     DEFAULT_MIN_DATE.set(14, 0);
/*  48 */     DEFAULT_MIN_DATE.set(9, 0);
/*     */     
/*  50 */     DEFAULT_MAX_DATE = Calendar.getInstance();
/*  51 */     DEFAULT_MAX_DATE.set(9999, 11, 31, 11, 59, 59);
/*  52 */     DEFAULT_MAX_DATE.set(14, 999);
/*  53 */     DEFAULT_MAX_DATE.set(9, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   static Calendar DEFAULT_MAX_DATE;
/*     */   
/*  59 */   ArrayList dateFormatters = null;
/*     */   
/*  61 */   Calendar minDate = null;
/*  62 */   Calendar maxDate = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormComplexDateField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2, Calendar paramCalendar1, Calendar paramCalendar2) {
/*  74 */     super(paramString1, paramString2, paramBoolean, paramInt1, paramInt2);
/*  75 */     setMinimum(paramCalendar1);
/*  76 */     setMaximum(paramCalendar2);
/*     */     
/*  78 */     this.dateFormatters = BasicHelper.DEFAULT_DATE_FORMATTERS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public FormComplexDateField(String paramString1, String paramString2, boolean paramBoolean, int paramInt, Calendar paramCalendar1, Calendar paramCalendar2) { this(paramString1, paramString2, paramBoolean, paramInt, paramInt, paramCalendar1, paramCalendar2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public FormComplexDateField(String paramString1, String paramString2, boolean paramBoolean, int paramInt) { this(paramString1, paramString2, paramBoolean, paramInt, paramInt, DEFAULT_MIN_DATE, DEFAULT_MAX_DATE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public FormComplexDateField(String paramString, boolean paramBoolean, int paramInt) { this(paramString, DEFAULT_VALUE, paramBoolean, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public FormComplexDateField(String paramString, int paramInt) { this(paramString, DEFAULT_VALUE, false, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public FormComplexDateField(String paramString, Calendar paramCalendar1, Calendar paramCalendar2) { this(paramString, DEFAULT_VALUE, false, DEFAULT_LENGTH, paramCalendar1, paramCalendar2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public FormComplexDateField(String paramString) { this(paramString, DEFAULT_VALUE, false, DEFAULT_LENGTH); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public void setMinimum(Calendar paramCalendar) { this.minDate = paramCalendar; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public Calendar getMinimum() { return this.minDate; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public void setMaximum(Calendar paramCalendar) { this.maxDate = paramCalendar; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   public Calendar getMaximum() { return this.maxDate; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Calendar getDateValue() {
/* 171 */     if (BasicHelper.isValidDate(this.value, this.dateFormatters))
/*     */     {
/* 173 */       return BasicHelper.parseComplexDate(this.value, this.dateFormatters);
/*     */     }
/* 175 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
/* 187 */     super.requiredValidation(paramFormSingleValidation);
/*     */ 
/*     */ 
/*     */     
/* 191 */     if (this.dateFormatters != null && this.dateFormatters.size() > 0) {
/* 192 */       this.dateFormatters = BasicHelper.DEFAULT_DATE_FORMATTERS;
/*     */     }
/*     */     
/* 195 */     if (this.value.trim().equalsIgnoreCase("")) {
/*     */       
/* 197 */       paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is empty.", 
/* 198 */           "Please provide input in the field named " + getDisplayName() + ".", 
/* 199 */           "This field requires input");
/*     */     }
/* 201 */     else if (BasicHelper.isValidDate(this.value, this.dateFormatters)) {
/*     */ 
/*     */ 
/*     */       
/* 205 */       if (this.minDate == null) {
/* 206 */         this.minDate = DEFAULT_MIN_DATE;
/*     */       }
/* 208 */       if (this.maxDate == null) {
/* 209 */         this.maxDate = DEFAULT_MAX_DATE;
/*     */       }
/* 211 */       Calendar calendar = getDateValue();
/*     */       
/* 213 */       if (calendar.before(this.minDate))
/*     */       {
/* 215 */         paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is earlier than " + BasicHelper.getCalendarAsString(getMinimum(), 1, 2, "/", "") + ".", 
/* 216 */             String.valueOf(getDisplayName()) + " cannot be earlier than " + BasicHelper.getCalendarAsString(getMinimum(), 1, 2, "/", "") + ".", 
/* 217 */             "This field's value cannot be earlier than " + BasicHelper.getCalendarAsString(getMinimum(), 1, 2, "/", "") + ".");
/*     */       }
/* 219 */       else if (calendar.after(this.maxDate))
/*     */       {
/* 221 */         paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is later than " + BasicHelper.getCalendarAsString(getMaximum(), 1, 2, "/", "") + ".", 
/* 222 */             String.valueOf(getDisplayName()) + " cannot be later than " + BasicHelper.getCalendarAsString(getMaximum(), 1, 2, "/", "") + ".", 
/* 223 */             "This field's value cannot be later than " + BasicHelper.getCalendarAsString(getMinimum(), 1, 2, "/", "") + ".");
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 228 */       paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is not in a valid format.", 
/* 229 */           String.valueOf(getDisplayName()) + " contains an incorrectly formatted date.", 
/* 230 */           "This field's value is incorrectly formatted.");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormComplexDateField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */