/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.BasicHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormCheckBox
/*     */   extends FormElement
/*     */ {
/*     */   public static final String DEFAULT_VALUE = "y";
/*     */   public static final String DEFAULT_TEXT = "";
/*     */   protected String value;
/*     */   protected String text;
/*     */   protected boolean startingChecked = false;
/*     */   protected boolean checked = false;
/*     */   
/*     */   public FormCheckBox(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2) {
/*  68 */     super(paramString1, paramString2, paramBoolean1);
/*  69 */     setText(paramString3);
/*  70 */     setStartingChecked(paramBoolean2);
/*  71 */     setChecked(paramBoolean2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public FormCheckBox(String paramString1, String paramString2, String paramString3, boolean paramBoolean) { this(paramString1, paramString2, paramString3, paramBoolean, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public FormCheckBox(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2) { this(paramString1, "y", paramString2, paramBoolean1, paramBoolean2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public FormCheckBox(String paramString1, String paramString2, boolean paramBoolean) { this(paramString1, "y", paramString2, paramBoolean, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   public FormCheckBox(String paramString, boolean paramBoolean) { this(paramString, "y", "", paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public FormCheckBox(String paramString) { this(paramString, "y", "", false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   public void setChecked(boolean paramBoolean) { this.checked = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public boolean isChecked() { return this.checked; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String paramString) {
/* 158 */     if (!isReadOnly()) {
/*     */       
/* 160 */       if (this.value == null) {
/* 161 */         this.value = paramString;
/*     */       }
/*     */       
/* 164 */       setChecked(!(paramString == null || paramString.length() <= 0));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStartingValue(String paramString) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   public String getStartingValue() { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 200 */   public void setStartingChecked(boolean paramBoolean) { this.startingChecked = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 209 */   public boolean getStartingChecked() { return this.startingChecked; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public void revert() { setChecked(getStartingChecked()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 244 */   public void setValue(Context paramContext) { setValue(paramContext.getRequestValue(getName(), "")); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 254 */     if (this.text == null) {
/* 255 */       return "";
/*     */     }
/* 257 */     return this.text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 265 */   public void setText(String paramString) { this.text = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 274 */   protected String getValue() { return this.value; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 282 */   public String getStringValue() { return getValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 292 */   public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 303 */   public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntegerValue() {
/*     */     try {
/* 314 */       return Integer.parseInt(getValue());
/*     */     
/*     */     }
/* 317 */     catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 323 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render() {
/* 331 */     StringBuffer stringBuffer = new StringBuffer(60);
/*     */     
/* 333 */     stringBuffer.append("<input type=\"checkbox\" name=\"");
/* 334 */     stringBuffer.append(getName());
/* 335 */     stringBuffer.append("\" value=\"");
/* 336 */     stringBuffer.append(getValue());
/* 337 */     stringBuffer.append('"');
/*     */     
/* 339 */     if (isChecked()) {
/* 340 */       stringBuffer.append(" checked");
/*     */     }
/* 342 */     stringBuffer.append(getTabIndex());
/* 343 */     stringBuffer.append(getFormEvents());
/* 344 */     stringBuffer.append(getEnabledString());
/* 345 */     stringBuffer.append(getId());
/* 346 */     stringBuffer.append('>');
/* 347 */     stringBuffer.append(getText());
/*     */     
/* 349 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormSingleValidation validate() {
/* 369 */     FormSingleValidation formSingleValidation = new FormSingleValidation(this);
/*     */     
/* 371 */     if (isRequired())
/*     */     {
/*     */       
/* 374 */       requiredValidation(formSingleValidation);
/*     */     }
/*     */ 
/*     */     
/* 378 */     customValidation(formSingleValidation);
/*     */     
/* 380 */     return formSingleValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
/* 392 */     if (getStringValue().length() == 0)
/*     */     {
/* 394 */       paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is unchecked.", 
/* 395 */           "Please check the checkbox named " + getDisplayName() + ".", 
/* 396 */           "This checkbox field must be checked.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 406 */   public boolean isDefault() { return "y".equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 416 */   public boolean isUnchanged() { return !(getStartingChecked() != isChecked()); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormCheckBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */