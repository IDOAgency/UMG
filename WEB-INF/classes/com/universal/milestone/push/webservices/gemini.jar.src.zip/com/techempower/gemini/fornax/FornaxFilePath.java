/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.DataEntity;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxFilePath
/*     */   extends DataEntity
/*     */   implements FornaxConstants
/*     */ {
/*  37 */   protected int filePathID = -1;
/*  38 */   protected String filePathName = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean filePathIsRelative = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializationComplete() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getCustomSetMethodBindings() {
/*  59 */     Hashtable hashtable = new Hashtable();
/*     */     
/*  61 */     hashtable.put("FilePathID", "setID");
/*  62 */     hashtable.put("FilePathName", "setPathName");
/*  63 */     hashtable.put("FilePathIsRelative", "setPathIsRelative");
/*     */     
/*  65 */     return hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getCustomGetMethodBindings() {
/*  75 */     Hashtable hashtable = new Hashtable();
/*     */     
/*  77 */     hashtable.put("FilePathID", "getID");
/*  78 */     hashtable.put("FilePathName", "getPathName");
/*  79 */     hashtable.put("FilePathIsRelative", "getIsPathRelativeAsString");
/*     */     
/*  81 */     return hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public boolean useMethodsForUpdate() { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public int getIdentity() { return this.filePathID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public String getTableName() { return "fnFilePath"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public String getIdentityColumnName() { return "FilePathID"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public int getID() { return this.filePathID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public String getPathName() { return this.filePathName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public boolean isPathRelative() { return this.filePathIsRelative; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIsPathRelativeAsString() {
/* 156 */     if (this.filePathIsRelative) {
/* 157 */       return "T";
/*     */     }
/* 159 */     return "F";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public void setID(int paramInt) { this.filePathID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPathName(String paramString) {
/* 185 */     if (paramString != null) {
/* 186 */       this.filePathName = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPathIsRelative(String paramString) {
/* 197 */     this.filePathIsRelative = false;
/*     */     
/* 199 */     if (paramString.trim().equalsIgnoreCase("T"))
/*     */     {
/* 201 */       this.filePathIsRelative = true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxFilePath.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */