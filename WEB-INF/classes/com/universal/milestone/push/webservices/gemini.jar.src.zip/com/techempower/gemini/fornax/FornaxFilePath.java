package com.techempower.gemini.fornax;

import com.techempower.DataEntity;
import java.util.Hashtable;

public class FornaxFilePath extends DataEntity implements FornaxConstants {
  protected int filePathID = -1;
  
  protected String filePathName = "";
  
  protected boolean filePathIsRelative = false;
  
  public void initializationComplete() {}
  
  public Hashtable getCustomSetMethodBindings() {
    Hashtable hashtable = new Hashtable();
    hashtable.put("FilePathID", "setID");
    hashtable.put("FilePathName", "setPathName");
    hashtable.put("FilePathIsRelative", "setPathIsRelative");
    return hashtable;
  }
  
  public Hashtable getCustomGetMethodBindings() {
    Hashtable hashtable = new Hashtable();
    hashtable.put("FilePathID", "getID");
    hashtable.put("FilePathName", "getPathName");
    hashtable.put("FilePathIsRelative", "getIsPathRelativeAsString");
    return hashtable;
  }
  
  public boolean useMethodsForUpdate() { return true; }
  
  public int getIdentity() { return this.filePathID; }
  
  public String getTableName() { return "fnFilePath"; }
  
  public String getIdentityColumnName() { return "FilePathID"; }
  
  public int getID() { return this.filePathID; }
  
  public String getPathName() { return this.filePathName; }
  
  public boolean isPathRelative() { return this.filePathIsRelative; }
  
  public String getIsPathRelativeAsString() {
    if (this.filePathIsRelative)
      return "T"; 
    return "F";
  }
  
  public void setID(int paramInt) { this.filePathID = paramInt; }
  
  public void setPathName(String paramString) {
    if (paramString != null)
      this.filePathName = paramString; 
  }
  
  public void setPathIsRelative(String paramString) {
    this.filePathIsRelative = false;
    if (paramString.trim().equalsIgnoreCase("T"))
      this.filePathIsRelative = true; 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxFilePath.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */