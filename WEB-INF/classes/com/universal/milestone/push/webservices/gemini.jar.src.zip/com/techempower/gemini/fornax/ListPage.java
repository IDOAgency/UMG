package com.techempower.gemini.fornax;

import java.util.Hashtable;

public class ListPage implements FornaxDBConstants {
  protected int mListPageID;
  
  protected Template mListPageTemplate;
  
  protected GenerationDestination mListPageGenerationDestination;
  
  protected String mListPageFileNamePrefix;
  
  protected String mListPageFileNameTitle;
  
  protected String mListPageFileNameSuffix;
  
  protected String mListPageFileNameExt;
  
  public ListPage(Hashtable paramHashtable) {
    this.mListPageID = ((Integer)paramHashtable.get("listPageID")).intValue();
    this.mListPageTemplate = (Template)paramHashtable.get("listPageTemplate");
    this.mListPageGenerationDestination = (GenerationDestination)paramHashtable.get("listPageGenerationDestination");
    this.mListPageFileNamePrefix = (String)paramHashtable.get("listPageFileNamePrefix");
    this.mListPageFileNameTitle = (String)paramHashtable.get("listPageFileNameTitle");
    this.mListPageFileNameSuffix = (String)paramHashtable.get("listPageFileNameSuffix");
    this.mListPageFileNameExt = (String)paramHashtable.get("listPageFileNameExtension");
  }
  
  public int getListPageID() { return this.mListPageID; }
  
  public Template getListPageTemplate() { return this.mListPageTemplate; }
  
  public GenerationDestination getListPageGenerationDestination() { return this.mListPageGenerationDestination; }
  
  public String getListPageFileNamePrefix() { return this.mListPageFileNamePrefix; }
  
  public String getListPageFileNameTitle() { return this.mListPageFileNameTitle; }
  
  public String getListPageFileNameSuffix() { return this.mListPageFileNameSuffix; }
  
  public String getListPageFileNameExt() { return this.mListPageFileNameExt; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\ListPage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */