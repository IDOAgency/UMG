package com.techempower;

public interface LogWriter {
  void closeFile();
  
  void closeFile(String paramString);
  
  boolean isOpen();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\LogWriter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */