package com.techempower;

import java.util.Calendar;

public class SimpleDate implements UtilityConstants, Comparable {
  public Calendar calendar = Calendar.getInstance();
  
  public SimpleDate(Calendar paramCalendar) { this.calendar = paramCalendar; }
  
  public SimpleDate(int paramInt1, int paramInt2, int paramInt3) { this(paramInt1, paramInt2, paramInt3, false); }
  
  public SimpleDate(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    adjust(1, paramInt1);
    if (paramBoolean) {
      adjust(2, paramInt2 - 1);
    } else {
      adjust(2, paramInt2);
    } 
    adjust(5, paramInt3);
  }
  
  public SimpleDate(String paramString) { set(paramString); }
  
  public SimpleDate(long paramLong) { set(paramLong); }
  
  public void set(String paramString) {
    if (paramString.length() == 14)
      try {
        int i = Integer.parseInt(paramString.substring(0, 4));
        int j = Integer.parseInt(paramString.substring(4, 6));
        int k = Integer.parseInt(paramString.substring(6, 8));
        int m = Integer.parseInt(paramString.substring(8, 10));
        int n = Integer.parseInt(paramString.substring(10, 12));
        int i1 = Integer.parseInt(paramString.substring(12, 14));
        this.calendar.set(i, j, k, m, n, i1);
      } catch (NumberFormatException numberFormatException) {} 
  }
  
  public void set(long paramLong) { set(String.valueOf(paramLong)); }
  
  public void add(int paramInt1, int paramInt2) { this.calendar.add(paramInt1, paramInt2); }
  
  public void adjust(int paramInt1, int paramInt2) { this.calendar.set(paramInt1, paramInt2); }
  
  public String get() {
    int i = this.calendar.get(1);
    int j = this.calendar.get(2);
    int k = this.calendar.get(5);
    int m = this.calendar.get(11);
    int n = this.calendar.get(12);
    int i1 = this.calendar.get(13);
    StringBuffer stringBuffer = new StringBuffer(14);
    stringBuffer.append(i);
    stringBuffer.append(zeroPad(2, j));
    stringBuffer.append(zeroPad(2, k));
    stringBuffer.append(zeroPad(2, m));
    stringBuffer.append(zeroPad(2, n));
    stringBuffer.append(zeroPad(2, i1));
    return stringBuffer.toString();
  }
  
  public long getAsLong() {
    try {
      return Long.parseLong(get());
    } catch (NumberFormatException numberFormatException) {
      return 0L;
    } 
  }
  
  public boolean equals(SimpleDate paramSimpleDate) { return !(paramSimpleDate.getAsLong() != getAsLong()); }
  
  public String getClean() {
    int i = this.calendar.get(1);
    int j = this.calendar.get(2);
    int k = this.calendar.get(5);
    StringBuffer stringBuffer = new StringBuffer(11);
    stringBuffer.append(zeroPad(2, k));
    stringBuffer.append(' ');
    stringBuffer.append(UtilityConstants.MONTH_NAMES_ABBREVIATED[j]);
    stringBuffer.append(' ');
    stringBuffer.append(i);
    return stringBuffer.toString();
  }
  
  public String getFull() {
    int i = this.calendar.get(1);
    int j = this.calendar.get(2);
    int k = this.calendar.get(5);
    int m = this.calendar.get(7);
    int n = this.calendar.get(11);
    int i1 = this.calendar.get(12);
    int i2 = this.calendar.get(13);
    StringBuffer stringBuffer = new StringBuffer(24);
    stringBuffer.append(UtilityConstants.DAYS_ABBREVIATED[m - 1]);
    stringBuffer.append(' ');
    stringBuffer.append(zeroPad(2, k));
    stringBuffer.append(UtilityConstants.MONTH_NAMES_ABBREVIATED[j]);
    stringBuffer.append(' ');
    stringBuffer.append(i);
    stringBuffer.append(' ');
    stringBuffer.append(zeroPad(2, n));
    stringBuffer.append(':');
    stringBuffer.append(zeroPad(2, i1));
    stringBuffer.append(':');
    stringBuffer.append(zeroPad(2, i2));
    return stringBuffer.toString();
  }
  
  protected String zeroPad(int paramInt1, int paramInt2) { return BasicHelper.zeroPad(paramInt2, paramInt1); }
  
  public String toString() { return get(); }
  
  public String getYear() { return String.valueOf(this.calendar.get(1)); }
  
  public String getMonth() { return String.valueOf(this.calendar.get(2) + 1); }
  
  public String getDay() { return String.valueOf(this.calendar.get(5)); }
  
  public long getTimeInMillis() {
    if (this.calendar != null)
      return this.calendar.getTime().getTime(); 
    return 0L;
  }
  
  public int compareTo(Object paramObject) {
    SimpleDate simpleDate = (SimpleDate)paramObject;
    return (int)(getTimeInMillis() - simpleDate.getTimeInMillis());
  }
  
  public SimpleDate() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\SimpleDate.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */