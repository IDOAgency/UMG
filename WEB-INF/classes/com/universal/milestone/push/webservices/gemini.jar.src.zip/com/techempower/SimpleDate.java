/*     */ package com.techempower;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleDate
/*     */   implements UtilityConstants, Comparable
/*     */ {
/*  34 */   public Calendar calendar = Calendar.getInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public SimpleDate(Calendar paramCalendar) { this.calendar = paramCalendar; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public SimpleDate(int paramInt1, int paramInt2, int paramInt3) { this(paramInt1, paramInt2, paramInt3, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleDate(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
/*  64 */     adjust(1, paramInt1);
/*  65 */     if (paramBoolean) {
/*  66 */       adjust(2, paramInt2 - 1);
/*     */     } else {
/*  68 */       adjust(2, paramInt2);
/*  69 */     }  adjust(5, paramInt3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public SimpleDate(String paramString) { set(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public SimpleDate(long paramLong) { set(paramLong); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(String paramString) {
/* 107 */     if (paramString.length() == 14) {
/*     */       
/*     */       try {
/*     */         
/* 111 */         int i = Integer.parseInt(paramString.substring(0, 4));
/* 112 */         int j = Integer.parseInt(paramString.substring(4, 6));
/* 113 */         int k = Integer.parseInt(paramString.substring(6, 8));
/* 114 */         int m = Integer.parseInt(paramString.substring(8, 10));
/* 115 */         int n = Integer.parseInt(paramString.substring(10, 12));
/* 116 */         int i1 = Integer.parseInt(paramString.substring(12, 14));
/*     */         
/* 118 */         this.calendar.set(i, j, k, m, n, i1);
/*     */       }
/* 120 */       catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   public void set(long paramLong) { set(String.valueOf(paramLong)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public void add(int paramInt1, int paramInt2) { this.calendar.add(paramInt1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 153 */   public void adjust(int paramInt1, int paramInt2) { this.calendar.set(paramInt1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String get() {
/* 163 */     int i = this.calendar.get(1);
/* 164 */     int j = this.calendar.get(2);
/* 165 */     int k = this.calendar.get(5);
/* 166 */     int m = this.calendar.get(11);
/* 167 */     int n = this.calendar.get(12);
/* 168 */     int i1 = this.calendar.get(13);
/*     */     
/* 170 */     StringBuffer stringBuffer = new StringBuffer(14);
/* 171 */     stringBuffer.append(i);
/* 172 */     stringBuffer.append(zeroPad(2, j));
/* 173 */     stringBuffer.append(zeroPad(2, k));
/* 174 */     stringBuffer.append(zeroPad(2, m));
/* 175 */     stringBuffer.append(zeroPad(2, n));
/* 176 */     stringBuffer.append(zeroPad(2, i1));
/*     */     
/* 178 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getAsLong() {
/*     */     try {
/* 189 */       return Long.parseLong(get());
/*     */     }
/* 191 */     catch (NumberFormatException numberFormatException) {
/*     */       
/* 193 */       return 0L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   public boolean equals(SimpleDate paramSimpleDate) { return !(paramSimpleDate.getAsLong() != getAsLong()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClean() {
/* 212 */     int i = this.calendar.get(1);
/* 213 */     int j = this.calendar.get(2);
/* 214 */     int k = this.calendar.get(5);
/*     */     
/* 216 */     StringBuffer stringBuffer = new StringBuffer(11);
/* 217 */     stringBuffer.append(zeroPad(2, k));
/* 218 */     stringBuffer.append(' ');
/* 219 */     stringBuffer.append(UtilityConstants.MONTH_NAMES_ABBREVIATED[j]);
/* 220 */     stringBuffer.append(' ');
/* 221 */     stringBuffer.append(i);
/*     */     
/* 223 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFull() {
/* 233 */     int i = this.calendar.get(1);
/* 234 */     int j = this.calendar.get(2);
/* 235 */     int k = this.calendar.get(5);
/* 236 */     int m = this.calendar.get(7);
/* 237 */     int n = this.calendar.get(11);
/* 238 */     int i1 = this.calendar.get(12);
/* 239 */     int i2 = this.calendar.get(13);
/*     */     
/* 241 */     StringBuffer stringBuffer = new StringBuffer(24);
/* 242 */     stringBuffer.append(UtilityConstants.DAYS_ABBREVIATED[m - 1]);
/* 243 */     stringBuffer.append(' ');
/* 244 */     stringBuffer.append(zeroPad(2, k));
/* 245 */     stringBuffer.append(UtilityConstants.MONTH_NAMES_ABBREVIATED[j]);
/* 246 */     stringBuffer.append(' ');
/* 247 */     stringBuffer.append(i);
/* 248 */     stringBuffer.append(' ');
/* 249 */     stringBuffer.append(zeroPad(2, n));
/* 250 */     stringBuffer.append(':');
/* 251 */     stringBuffer.append(zeroPad(2, i1));
/* 252 */     stringBuffer.append(':');
/* 253 */     stringBuffer.append(zeroPad(2, i2));
/*     */     
/* 255 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 264 */   protected String zeroPad(int paramInt1, int paramInt2) { return BasicHelper.zeroPad(paramInt2, paramInt1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 272 */   public String toString() { return get(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 280 */   public String getYear() { return String.valueOf(this.calendar.get(1)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 288 */   public String getMonth() { return String.valueOf(this.calendar.get(2) + 1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 296 */   public String getDay() { return String.valueOf(this.calendar.get(5)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTimeInMillis() {
/* 304 */     if (this.calendar != null) {
/* 305 */       return this.calendar.getTime().getTime();
/*     */     }
/* 307 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Object paramObject) {
/* 333 */     SimpleDate simpleDate = (SimpleDate)paramObject;
/*     */     
/* 335 */     return (int)(getTimeInMillis() - simpleDate.getTimeInMillis());
/*     */   }
/*     */   
/*     */   public SimpleDate() {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\SimpleDate.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */