package com.techempower.gemini.fornax;

import com.techempower.DatabaseConnector;
import java.util.Hashtable;
import java.util.Vector;

public class DataObjectManager implements FornaxDBConstants, FornaxSQLStatements {
  boolean debug;
  
  Hashtable mGroupTable;
  
  Hashtable mContentTypeTable;
  
  FornaxSettings mSettings;
  
  public DataObjectManager(FornaxSettings paramFornaxSettings) {
    this.debug = false;
    this.mGroupTable = new Hashtable();
    this.mContentTypeTable = new Hashtable();
    this.mSettings = null;
    this.mSettings = paramFornaxSettings;
  }
  
  public Vector buildContentInfo() {
    Vector vector1 = new Vector();
    Vector vector2 = new Vector();
    vector2 = getContentTypeIDs();
    for (byte b = 0; b < vector2.size(); b++) {
      int i = ((Integer)vector2.elementAt(b)).intValue();
      Hashtable hashtable = getContentTypeInfo(i);
      Vector vector = buildGroupInfo(i);
      hashtable.put("contentTypeGroups", vector);
      ContentType contentType = new ContentType(hashtable);
      vector1.addElement(contentType);
      buildContentTypeHashtable(contentType, hashtable);
      hashtable.clear();
    } 
    return vector1;
  }
  
  public Vector buildGroupInfo(int paramInt) {
    Hashtable hashtable = new Hashtable();
    Vector vector1 = new Vector();
    Vector vector2 = new Vector();
    vector1 = getGroupIDs(paramInt);
    for (byte b = 0; b < vector1.size(); b++) {
      int i = ((Integer)vector1.elementAt(b)).intValue();
      hashtable = getGroupInfo(i);
      hashtable.put("groupInstances", getContentTypeInstances(i));
      hashtable.put("groupVariants", getGroupVariants(i));
      hashtable.put("groupListPage", getListPage(((Integer)hashtable.get("InstancesGroupListPageID")).intValue()));
      vector2.addElement(createContentTypeInstanceGroup(hashtable));
    } 
    return vector2;
  }
  
  private Vector getContentTypeIDs() {
    Vector vector = new Vector();
    DatabaseConnector databaseConnector = this.mSettings.getConnector("SELECT * from fnContentType ORDER BY ContentTypeID");
    databaseConnector.runQuery();
    while (databaseConnector.more()) {
      vector.addElement(new Integer(databaseConnector.getInt("contentTypeID")));
      databaseConnector.next();
    } 
    databaseConnector.close();
    return vector;
  }
  
  private Hashtable getContentTypeInfo(int paramInt) {
    Hashtable hashtable = new Hashtable();
    Integer integer = new Integer(paramInt);
    String str = FornaxHelper.replaceParameters("SELECT * from fnContentType WHERE ContentTypeID = @contentTypeID ", "@contentTypeID", integer.toString());
    DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
    databaseConnector.runQuery();
    hashtable.put("contentTypeID", new Integer(databaseConnector.getInt("contentTypeID")));
    hashtable.put("contentTypeName", databaseConnector.getField("contentTypeName"));
    hashtable.put("contentTypeDescription", databaseConnector.getField("contentTypeDescription"));
    hashtable.put("contentTypeIsSingleton", new Boolean(changeToBooleanString(databaseConnector.getField("contentTypeIsSingleton"))));
    hashtable.put("contentTypeIsListPageGenerated", new Boolean(changeToBooleanString(databaseConnector.getField("contentTypeIsListPageGenerated"))));
    int i = databaseConnector.getInt("contentTypeListPageID");
    hashtable.put("contentTypeListPage", getListPage(i));
    paramInt = databaseConnector.getInt("contentTypeID");
    hashtable.put("contentTypeFields", getContentTypeFields(paramInt));
    databaseConnector.close();
    return hashtable;
  }
  
  private Vector getGroupIDs(int paramInt) {
    String str;
    Vector vector = new Vector();
    Integer integer = new Integer(paramInt);
    if (this.mSettings.isMultiGroup()) {
      str = FornaxHelper.replaceParameters("SELECT * from fnContentTypeInstancesGroup WHERE InstancesGroupContentTypeID = @contentTypeID  ORDER BY InstancesGroupID", "@contentTypeID", integer.toString());
    } else {
      str = FornaxHelper.replaceParameters("SELECT TOP 1 * from fnContentTypeInstancesGroup WHERE InstancesGroupContentTypeID = @contentTypeID  ORDER BY InstancesGroupID", "@contentTypeID", integer.toString());
    } 
    DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
    databaseConnector.runQuery();
    while (databaseConnector.more()) {
      vector.addElement(new Integer(databaseConnector.getInt("InstancesGroupID")));
      databaseConnector.next();
    } 
    databaseConnector.close();
    return vector;
  }
  
  private Hashtable getGroupInfo(int paramInt) {
    Hashtable hashtable = new Hashtable();
    Integer integer = new Integer(paramInt);
    String str = FornaxHelper.replaceParameters("SELECT * from fnContentTypeInstancesGroup g INNER JOIN fnContentType c on g.InstancesGroupContentTypeID = c.ContentTypeID  WHERE g.InstancesGroupID = @groupID", "@groupID", integer.toString());
    DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
    databaseConnector.runQuery();
    hashtable.put("InstancesGroupID", new Integer(databaseConnector.getInt("InstancesGroupID")));
    hashtable.put("InstancesGroupName", databaseConnector.getField("InstancesGroupName"));
    hashtable.put("InstancesGroupDescription", databaseConnector.getField("InstancesGroupDescription"));
    hashtable.put("InstancesGroupIsSingleton", new Boolean(changeToBooleanString(databaseConnector.getField("InstancesGroupIsSingleton"))));
    hashtable.put("InstancesGroupIsListPageGenerated", new Boolean(changeToBooleanString(databaseConnector.getField("InstancesGroupIsListPageGenerated"))));
    hashtable.put("InstancesGroupIsInstanceGenerationEnabled", new Boolean(changeToBooleanString(databaseConnector.getField("InstancesGroupIsInstanceGenerationEnabled"))));
    hashtable.put("InstancesGroupListPageID", new Integer(databaseConnector.getInt("InstancesGroupListPageID")));
    hashtable.put("InstancesGroupContentTypeID", new Integer(databaseConnector.getInt("InstancesGroupContentTypeID")));
    hashtable.put("contentTypeName", databaseConnector.getField("contentTypeName"));
    return hashtable;
  }
  
  private ContentType getGroupContentType(int paramInt) {
    Hashtable hashtable = new Hashtable();
    Integer integer = new Integer(paramInt);
    String str = FornaxHelper.replaceParameters("SELECT ct.* from fnContentTypeInstancesGroup ctg INNER JOIN fnContentType ct on ctg.InstancesGroupContentTypeID = ct.ContentTypeID WHERE ctg.InstancesGroupContentTypeID = @contentTypeID", "@contentTypeID", integer.toString());
    DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
    databaseConnector.runQuery();
    hashtable.put("contentTypeID", new Integer(databaseConnector.getInt("contentTypeID")));
    hashtable.put("contentTypeName", databaseConnector.getField("contentTypeName"));
    hashtable.put("contentTypeDescription", databaseConnector.getField("contentTypeDescription"));
    hashtable.put("contentTypeIsSingleton", new Boolean(changeToBooleanString(databaseConnector.getField("contentTypeIsSingleton"))));
    hashtable.put("contentTypeIsListPageGenerated", new Boolean(changeToBooleanString(databaseConnector.getField("contentTypeIsListPageGenerated"))));
    int i = databaseConnector.getInt("contentTypeListPageID");
    hashtable.put("contentTypeListPage", getListPage(i));
    int j = databaseConnector.getInt("contentTypeID");
    hashtable.put("contentTypeFields", getContentTypeFields(j));
    ContentType contentType = new ContentType(hashtable);
    databaseConnector.close();
    return contentType;
  }
  
  private ListPage getListPage(int paramInt) {
    Hashtable hashtable = new Hashtable();
    Integer integer = new Integer(paramInt);
    String str = FornaxHelper.replaceParameters("SELECT * from fnListPage WHERE ListPageID = @listPageID", "@listPageID", integer.toString());
    DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
    databaseConnector.runQuery();
    hashtable.put("listPageID", new Integer(databaseConnector.getInt("listPageID")));
    hashtable.put("listPageFileNamePrefix", checkForNone(databaseConnector.getField("listPageFileNamePrefix")));
    hashtable.put("listPageFileNameTitle", checkForNone(databaseConnector.getField("listPageFileNameTitle")));
    hashtable.put("listPageFileNameSuffix", checkForNone(databaseConnector.getField("listPageFileNameSuffix")));
    hashtable.put("listPageFileNameExtension", checkForNone(databaseConnector.getField("listPageFileNameExtension")));
    int i = databaseConnector.getInt("listPageTemplateID");
    hashtable.put("listPageTemplate", createTemplate(i));
    int j = databaseConnector.getInt("listPageGenerationDestinationID");
    hashtable.put("listPageGenerationDestination", createGenerationDestination(j));
    ListPage listPage = new ListPage(hashtable);
    databaseConnector.close();
    return listPage;
  }
  
  private Vector getContentTypeFields(int paramInt) {
    Vector vector = new Vector();
    Hashtable hashtable = new Hashtable();
    Integer integer = new Integer(paramInt);
    String str = FornaxHelper.replaceParameters("SELECT * from fnContentTypeField ctf INNER JOIN fnContentTypeFieldDataType cdt on ctf.FieldDataTypeID = cdt.DataTypeID WHERE ctf.FieldContentTypeID = @contentTypeID", "@contentTypeID", integer.toString());
    DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
    databaseConnector.runQuery();
    while (databaseConnector.more()) {
      hashtable.put("instanceFieldID", new Integer(databaseConnector.getInt("instanceFieldID")));
      hashtable.put("instanceContentTypeID", new Integer(databaseConnector.getInt("instanceContentTypeID")));
      hashtable.put("instanceFieldName", databaseConnector.getField("instanceFieldName"));
      hashtable.put("instanceFieldDescription", databaseConnector.getField("instanceFieldDescription"));
      hashtable.put("instanceDataTypeID", new Integer(databaseConnector.getInt("instanceDataTypeID")));
      hashtable.put("instanceDataTypeName", databaseConnector.getField("instanceDataTypeName"));
      hashtable.put("instanceDataTypeDescription", databaseConnector.getField("instanceDataTypeDescription"));
      vector.addElement(createContentTypeField(hashtable));
      hashtable.clear();
      databaseConnector.next();
    } 
    databaseConnector.close();
    return vector;
  }
  
  private Vector getContentTypeInstances(int paramInt) {
    Vector vector = new Vector();
    Hashtable hashtable = new Hashtable();
    Integer integer = new Integer(paramInt);
    String str = FornaxHelper.replaceParameters("SELECT ctg.InstancesGroupID, ctg.InstanceSequenceNumber, cti.* , ct.* , g.InstancesGroupName FROM fnMapContentTypeInstanceToInstancesGroup ctg INNER JOIN fnContentTypeInstance cti on ctg.InstanceID = cti.instanceID INNER JOIN fnContentType ct on cti.InstanceContentTypeID = ct.ContentTypeID INNER JOIN fnContentTypeInstancesGroup g on ctg.InstancesGroupID = g.InstancesGroupID WHERE ctg.InstancesGroupID = @groupID ORDER BY cti.InstanceIsQueuedForDeletion ASC, cti.InstanceIsDisabled ASC, ctg.InstanceSequenceNumber", "@groupID", integer.toString());
    DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
    databaseConnector.runQuery();
    while (databaseConnector.more()) {
      hashtable.put("instanceID", new Integer(databaseConnector.getInt("instanceID")));
      hashtable.put("instanceName", databaseConnector.getField("instanceName"));
      hashtable.put("instanceDescription", databaseConnector.getField("instanceDescription"));
      hashtable.put("instanceGroupID", new Integer(databaseConnector.getInt("instanceGroupID")));
      hashtable.put("instancesGroupName", databaseConnector.getField("instancesGroupName"));
      hashtable.put("instanceContentTypeID", new Integer(databaseConnector.getInt("instanceContentTypeID")));
      hashtable.put("ContentTypeName", databaseConnector.getField("ContentTypeName"));
      hashtable.put("instanceSequenceNumber", new Integer(databaseConnector.getInt("instanceSequenceNumber")));
      hashtable.put("instanceIsQueuedForDeletion", new Boolean(changeToBooleanString(databaseConnector.getField("instanceIsQueuedForDeletion"))));
      hashtable.put("instanceIsDisabled", new Boolean(changeToBooleanString(databaseConnector.getField("instanceIsDisabled"))));
      hashtable.put("instanceDateCreated", databaseConnector.getField("instanceDateCreated"));
      hashtable.put("instanceLastModifiedByUserID", new Integer(databaseConnector.getInt("instanceLastModifiedByUserID")));
      hashtable.put("instanceLastModifiedTimeStamp", databaseConnector.getField("instanceLastModifiedTimeStamp"));
      int i = databaseConnector.getInt("instanceID");
      int j = databaseConnector.getInt("instanceContentTypeID");
      hashtable.put("instanceFields", getContentTypeInstanceFieldData(i, j));
      vector.addElement(createContentTypeInstance(hashtable));
      hashtable.clear();
      databaseConnector.next();
    } 
    databaseConnector.close();
    return vector;
  }
  
  private Vector getContentTypeInstanceFieldData(int paramInt1, int paramInt2) {
    Vector vector = new Vector();
    Hashtable hashtable = new Hashtable();
    Integer integer1 = new Integer(paramInt1);
    Integer integer2 = new Integer(paramInt2);
    String str = FornaxHelper.replaceParameters("SELECT \t* FROM fnContentTypeInstanceFieldValue WHERE instanceID = @instanceID and  InstanceContentTypeID = @contentTypeID", "@instanceID", integer1.toString());
    str = FornaxHelper.replaceParameters(str, "@contentTypeID", integer2.toString());
    DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
    databaseConnector.runQuery();
    while (databaseConnector.more()) {
      hashtable.put("instanceFieldID", new Integer(databaseConnector.getInt("instanceFieldID")));
      hashtable.put("instanceContentTypeID", new Integer(databaseConnector.getInt("instanceContentTypeID")));
      hashtable.put("instanceFieldName", databaseConnector.getField("instanceFieldName"));
      hashtable.put("instanceFieldDescription", databaseConnector.getField("instanceFieldDescription"));
      hashtable.put("instanceDataTypeID", new Integer(databaseConnector.getInt("instanceDataTypeID")));
      hashtable.put("instanceDataTypeName", databaseConnector.getField("instanceDataTypeName"));
      hashtable.put("instanceDataTypeDescription", databaseConnector.getField("instanceDataTypeDescription"));
      if (databaseConnector.getField("instanceDataTypeName").equalsIgnoreCase("DATE")) {
        String str1;
        int i;
        if (databaseConnector.getField("instanceFieldValue").equalsIgnoreCase("[none]")) {
          i = -1;
          str1 = "01/01/1900 12:00 AM PDT";
        } else {
          i = databaseConnector.getInt("dateValueID");
          str1 = databaseConnector.getField("instanceFieldValue");
        } 
        hashtable.put("dateValueID", new Integer(i));
        hashtable.put("dateValueData", str1);
        hashtable.put("dateValueInstance", new Integer(paramInt1));
        ContentTypeFieldDate contentTypeFieldDate = new ContentTypeFieldDate(hashtable);
        vector.addElement(contentTypeFieldDate);
      } else if (databaseConnector.getField("instanceDataTypeName").equalsIgnoreCase("INTEGER")) {
        String str1;
        int i;
        if (databaseConnector.getField("instanceFieldValue").equalsIgnoreCase("[none]")) {
          i = -1;
          str1 = "0";
        } else {
          i = databaseConnector.getInt("intergerValueID");
          str1 = databaseConnector.getField("instanceFieldValue");
        } 
        hashtable.put("intergerValueID", new Integer(i));
        hashtable.put("integerValueData", str1);
        hashtable.put("integerValueInstance", new Integer(paramInt1));
        ContentTypeFieldInteger contentTypeFieldInteger = new ContentTypeFieldInteger(hashtable);
        vector.addElement(contentTypeFieldInteger);
      } else if (databaseConnector.getField("instanceDataTypeName").equalsIgnoreCase("FLOATINGPOINT")) {
        String str1;
        int i;
        if (databaseConnector.getField("instanceFieldValue").equalsIgnoreCase("[none]")) {
          i = -1;
          str1 = "0";
        } else {
          i = databaseConnector.getInt("floatingPointValueID");
          str1 = databaseConnector.getField("instanceFieldValue");
        } 
        hashtable.put("floatingPointValueID", new Integer(i));
        hashtable.put("floatingPointValueData", str1);
        hashtable.put("floatingPointValueInstance", new Integer(paramInt1));
        ContentTypeFieldFloat contentTypeFieldFloat = new ContentTypeFieldFloat(hashtable);
        vector.addElement(contentTypeFieldFloat);
      } else if (databaseConnector.getField("instanceDataTypeName").equalsIgnoreCase("STRING")) {
        String str1;
        int i;
        if (databaseConnector.getField("instanceFieldValue").equalsIgnoreCase("[none]")) {
          i = -1;
          str1 = "";
        } else {
          i = databaseConnector.getInt("stringPointValueID");
          str1 = databaseConnector.getField("instanceFieldValue");
        } 
        hashtable.put("stringPointValueID", new Integer(i));
        hashtable.put("stringPointValueData", str1);
        hashtable.put("stringPointValueInstance", new Integer(paramInt1));
        ContentTypeFieldString contentTypeFieldString = new ContentTypeFieldString(hashtable);
        vector.addElement(contentTypeFieldString);
      } 
      hashtable.clear();
      databaseConnector.next();
    } 
    databaseConnector.close();
    return vector;
  }
  
  private Vector getGroupVariants(int paramInt) {
    Hashtable hashtable = new Hashtable();
    Vector vector = new Vector();
    Integer integer = new Integer(paramInt);
    String str = FornaxHelper.replaceParameters("SELECT * FROM fnContentTypeInstancesGroupVariant cg INNER JOIN fnVariantType v on v.VariantTypeID = cg.VariantTypeID WHERE cg.VariantInstancesGroupID = @groupID", "@groupID", integer.toString());
    DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
    databaseConnector.runQuery();
    while (databaseConnector.more()) {
      hashtable.put("variantID", new Integer(databaseConnector.getInt("variantID")));
      hashtable.put("variantTypeID", new Integer(databaseConnector.getInt("variantTypeID")));
      hashtable.put("variantTypeCode", databaseConnector.getField("variantTypeCode"));
      hashtable.put("variantTypeDescription", databaseConnector.getField("variantTypeDescription"));
      hashtable.put("variantInstancesGroupID", new Integer(databaseConnector.getInt("variantInstancesGroupID")));
      hashtable.put("variantIsEnabledForGeneration", new Boolean(changeToBooleanString(databaseConnector.getField("variantIsEnabledForGeneration"))));
      hashtable.put("variantFileNamePrefix", checkForNone(databaseConnector.getField("variantFileNamePrefix")));
      hashtable.put("variantFileNameTitle", checkForNone(databaseConnector.getField("variantFileNameTitle")));
      hashtable.put("variantFileNameSuffix", checkForNone(databaseConnector.getField("variantFileNameSuffix")));
      hashtable.put("variantFileNameExtension", checkForNone(databaseConnector.getField("variantFileNameExtension")));
      hashtable.put("variantFileNameNumberingMode", databaseConnector.getField("variantFileNameNumberingMode"));
      int i = databaseConnector.getInt("variantTemplateID");
      hashtable.put("variantTemplate", createTemplate(i));
      int j = databaseConnector.getInt("variantGenerationDestinationID");
      hashtable.put("variantGenerationDestination", createGenerationDestination(j));
      vector.addElement(createVariant(hashtable));
      if (this.debug)
        System.out.println("Is this variant enabled for generation ? = " + databaseConnector.getField("variantIsEnabledForGeneration")); 
      hashtable.clear();
      databaseConnector.next();
    } 
    return vector;
  }
  
  private Variant createVariant(Hashtable paramHashtable) { return new Variant(paramHashtable); }
  
  private ContentTypeInstanceGroup createContentTypeInstanceGroup(Hashtable paramHashtable) {
    ContentTypeInstanceGroup contentTypeInstanceGroup = new ContentTypeInstanceGroup(paramHashtable);
    buildGroupHashtable(contentTypeInstanceGroup, paramHashtable);
    return contentTypeInstanceGroup;
  }
  
  private Template createTemplate(int paramInt) {
    Hashtable hashtable = new Hashtable();
    Integer integer = new Integer(paramInt);
    String str = FornaxHelper.replaceParameters("SELECT * from fnContentTypeTemplate  WHERE ContentTypeTemplateID = @templateID", "@templateID", integer.toString());
    DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
    databaseConnector.runQuery();
    hashtable.put("contentTypeTemplateID", new Integer(databaseConnector.getInt("contentTypeTemplateID")));
    hashtable.put("contentTypeTemplateFileName", databaseConnector.getField("contentTypeTemplateFileName"));
    hashtable.put("contentTypeTemplateFileDescription", databaseConnector.getField("contentTypeTemplateFileDescription"));
    int i = databaseConnector.getInt("contentTypeTemplateFilePathID");
    hashtable.put("contentTypeTemplateFilePath", createFilePath(i));
    Template template = new Template(hashtable);
    databaseConnector.close();
    return template;
  }
  
  private GenerationDestination createGenerationDestination(int paramInt) {
    Hashtable hashtable = new Hashtable();
    Integer integer = new Integer(paramInt);
    String str = FornaxHelper.replaceParameters("SELECT * from fnGenerationDestination WHERE GenerationDestinationID = @destinationID", "@destinationID", integer.toString());
    DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
    databaseConnector.runQuery();
    hashtable.put("generationDestinationID", new Integer(databaseConnector.getInt("generationDestinationID")));
    hashtable.put("generationDestinationName", databaseConnector.getField("generationDestinationName"));
    hashtable.put("generationDestinationDesc", databaseConnector.getField("generationDestinationDesc"));
    hashtable.put("generationDestinationServerNetworkName", databaseConnector.getField("generationDestinationServerNetworkName"));
    hashtable.put("generationDestinationServerDNSName", databaseConnector.getField("generationDestinationServerDNSName"));
    hashtable.put("generationDestinationServerIPAddress", databaseConnector.getField("generationDestinationServerIPAddress"));
    hashtable.put("generationDestinationLogonUserName", databaseConnector.getField("generationDestinationLogonUserName"));
    hashtable.put("generationDestinationLogonPassword", databaseConnector.getField("generationDestinationLogonPassword"));
    int i = databaseConnector.getInt("generationDestinationFilePathID");
    hashtable.put("generationDestinationFilePath", createFilePath(i));
    GenerationDestination generationDestination = new GenerationDestination(hashtable);
    databaseConnector.close();
    return generationDestination;
  }
  
  private FilePath createFilePath(int paramInt) {
    Hashtable hashtable = new Hashtable();
    Integer integer = new Integer(paramInt);
    String str = FornaxHelper.replaceParameters("SELECT * from fnFilePath where FilePathID = @filePathID", "@filePathID", integer.toString());
    DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
    databaseConnector.runQuery();
    hashtable.put("filePathID", new Integer(databaseConnector.getInt("filePathID")));
    hashtable.put("filePathName", databaseConnector.getField("filePathName"));
    hashtable.put("filePathIsRelative", new Boolean(changeToBooleanString(databaseConnector.getField("filePathIsRelative"))));
    FilePath filePath = new FilePath(hashtable);
    databaseConnector.close();
    return filePath;
  }
  
  private ContentTypeField createContentTypeField(Hashtable paramHashtable) { return new ContentTypeField(paramHashtable); }
  
  private ContentTypeInstance createContentTypeInstance(Hashtable paramHashtable) { return new ContentTypeInstance(paramHashtable); }
  
  private void buildGroupHashtable(ContentTypeInstanceGroup paramContentTypeInstanceGroup, Hashtable paramHashtable) { this.mGroupTable.put(((String)paramHashtable.get("InstancesGroupName")).toUpperCase(), paramContentTypeInstanceGroup); }
  
  private void buildContentTypeHashtable(ContentType paramContentType, Hashtable paramHashtable) { this.mContentTypeTable.put(((String)paramHashtable.get("contentTypeName")).toUpperCase(), paramContentType); }
  
  public Hashtable getGroupTable() { return this.mGroupTable; }
  
  public Hashtable getContentTypeTable() { return this.mContentTypeTable; }
  
  public String changeToBooleanString(String paramString) {
    if (paramString.equalsIgnoreCase("T"))
      return "true"; 
    return "false";
  }
  
  public String checkForNone(String paramString) {
    if (paramString.equalsIgnoreCase("[none]"))
      return ""; 
    return paramString;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\DataObjectManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */