/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.DatabaseConnector;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataObjectManager
/*     */   implements FornaxDBConstants, FornaxSQLStatements
/*     */ {
/*     */   boolean debug;
/*     */   Hashtable mGroupTable;
/*     */   Hashtable mContentTypeTable;
/*     */   FornaxSettings mSettings;
/*     */   
/*     */   public DataObjectManager(FornaxSettings paramFornaxSettings) {
/*  37 */     this.debug = false;
/*     */     
/*  39 */     this.mGroupTable = new Hashtable();
/*  40 */     this.mContentTypeTable = new Hashtable();
/*  41 */     this.mSettings = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  48 */     this.mSettings = paramFornaxSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector buildContentInfo() {
/*  63 */     Vector vector1 = new Vector();
/*  64 */     Vector vector2 = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     vector2 = getContentTypeIDs();
/*     */ 
/*     */ 
/*     */     
/*  77 */     for (byte b = 0; b < vector2.size(); b++) {
/*     */       
/*  79 */       int i = ((Integer)vector2.elementAt(b)).intValue();
/*     */ 
/*     */       
/*  82 */       Hashtable hashtable = getContentTypeInfo(i);
/*     */ 
/*     */       
/*  85 */       Vector vector = buildGroupInfo(i);
/*  86 */       hashtable.put("contentTypeGroups", vector);
/*     */ 
/*     */       
/*  89 */       ContentType contentType = new ContentType(hashtable);
/*     */       
/*  91 */       vector1.addElement(contentType);
/*     */ 
/*     */       
/*  94 */       buildContentTypeHashtable(contentType, hashtable);
/*     */       
/*  96 */       hashtable.clear();
/*     */     } 
/*     */     
/*  99 */     return vector1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector buildGroupInfo(int paramInt) {
/* 122 */     Hashtable hashtable = new Hashtable();
/* 123 */     Vector vector1 = new Vector();
/* 124 */     Vector vector2 = new Vector();
/*     */ 
/*     */ 
/*     */     
/* 128 */     vector1 = getGroupIDs(paramInt);
/*     */ 
/*     */ 
/*     */     
/* 132 */     for (byte b = 0; b < vector1.size(); b++) {
/*     */       
/* 134 */       int i = ((Integer)vector1.elementAt(b)).intValue();
/*     */ 
/*     */       
/* 137 */       hashtable = getGroupInfo(i);
/*     */ 
/*     */       
/* 140 */       hashtable.put("groupInstances", getContentTypeInstances(i));
/*     */ 
/*     */       
/* 143 */       hashtable.put("groupVariants", getGroupVariants(i));
/*     */ 
/*     */       
/* 146 */       hashtable.put("groupListPage", getListPage(((Integer)hashtable.get("InstancesGroupListPageID")).intValue()));
/*     */ 
/*     */       
/* 149 */       vector2.addElement(createContentTypeInstanceGroup(hashtable));
/*     */     } 
/*     */ 
/*     */     
/* 153 */     return vector2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector getContentTypeIDs() {
/* 167 */     Vector vector = new Vector();
/*     */     
/* 169 */     DatabaseConnector databaseConnector = this.mSettings.getConnector("SELECT * from fnContentType ORDER BY ContentTypeID");
/* 170 */     databaseConnector.runQuery();
/* 171 */     while (databaseConnector.more()) {
/*     */       
/* 173 */       vector.addElement(new Integer(databaseConnector.getInt("contentTypeID")));
/* 174 */       databaseConnector.next();
/*     */     } 
/*     */     
/* 177 */     databaseConnector.close();
/* 178 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Hashtable getContentTypeInfo(int paramInt) {
/* 193 */     Hashtable hashtable = new Hashtable();
/*     */     
/* 195 */     Integer integer = new Integer(paramInt);
/*     */ 
/*     */     
/* 198 */     String str = FornaxHelper.replaceParameters("SELECT * from fnContentType WHERE ContentTypeID = @contentTypeID ", "@contentTypeID", integer.toString());
/* 199 */     DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
/* 200 */     databaseConnector.runQuery();
/*     */ 
/*     */     
/* 203 */     hashtable.put("contentTypeID", new Integer(databaseConnector.getInt("contentTypeID")));
/* 204 */     hashtable.put("contentTypeName", databaseConnector.getField("contentTypeName"));
/* 205 */     hashtable.put("contentTypeDescription", databaseConnector.getField("contentTypeDescription"));
/* 206 */     hashtable.put("contentTypeIsSingleton", new Boolean(changeToBooleanString(databaseConnector.getField("contentTypeIsSingleton"))));
/* 207 */     hashtable.put("contentTypeIsListPageGenerated", new Boolean(changeToBooleanString(databaseConnector.getField("contentTypeIsListPageGenerated"))));
/*     */ 
/*     */     
/* 210 */     int i = databaseConnector.getInt("contentTypeListPageID");
/* 211 */     hashtable.put("contentTypeListPage", getListPage(i));
/*     */ 
/*     */     
/* 214 */     paramInt = databaseConnector.getInt("contentTypeID");
/* 215 */     hashtable.put("contentTypeFields", getContentTypeFields(paramInt));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 220 */     databaseConnector.close();
/* 221 */     return hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector getGroupIDs(int paramInt) {
/*     */     String str;
/* 230 */     Vector vector = new Vector();
/*     */     
/* 232 */     Integer integer = new Integer(paramInt);
/*     */ 
/*     */     
/* 235 */     if (this.mSettings.isMultiGroup()) {
/* 236 */       str = FornaxHelper.replaceParameters("SELECT * from fnContentTypeInstancesGroup WHERE InstancesGroupContentTypeID = @contentTypeID  ORDER BY InstancesGroupID", "@contentTypeID", integer.toString());
/*     */     } else {
/* 238 */       str = FornaxHelper.replaceParameters("SELECT TOP 1 * from fnContentTypeInstancesGroup WHERE InstancesGroupContentTypeID = @contentTypeID  ORDER BY InstancesGroupID", "@contentTypeID", integer.toString());
/*     */     } 
/* 240 */     DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
/* 241 */     databaseConnector.runQuery();
/*     */     
/* 243 */     while (databaseConnector.more()) {
/*     */       
/* 245 */       vector.addElement(new Integer(databaseConnector.getInt("InstancesGroupID")));
/* 246 */       databaseConnector.next();
/*     */     } 
/*     */     
/* 249 */     databaseConnector.close();
/* 250 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Hashtable getGroupInfo(int paramInt) {
/* 268 */     Hashtable hashtable = new Hashtable();
/*     */     
/* 270 */     Integer integer = new Integer(paramInt);
/*     */ 
/*     */     
/* 273 */     String str = FornaxHelper.replaceParameters("SELECT * from fnContentTypeInstancesGroup g INNER JOIN fnContentType c on g.InstancesGroupContentTypeID = c.ContentTypeID  WHERE g.InstancesGroupID = @groupID", "@groupID", integer.toString());
/* 274 */     DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
/* 275 */     databaseConnector.runQuery();
/*     */     
/* 277 */     hashtable.put("InstancesGroupID", new Integer(databaseConnector.getInt("InstancesGroupID")));
/* 278 */     hashtable.put("InstancesGroupName", databaseConnector.getField("InstancesGroupName"));
/* 279 */     hashtable.put("InstancesGroupDescription", databaseConnector.getField("InstancesGroupDescription"));
/* 280 */     hashtable.put("InstancesGroupIsSingleton", new Boolean(changeToBooleanString(databaseConnector.getField("InstancesGroupIsSingleton"))));
/* 281 */     hashtable.put("InstancesGroupIsListPageGenerated", new Boolean(changeToBooleanString(databaseConnector.getField("InstancesGroupIsListPageGenerated"))));
/* 282 */     hashtable.put("InstancesGroupIsInstanceGenerationEnabled", new Boolean(changeToBooleanString(databaseConnector.getField("InstancesGroupIsInstanceGenerationEnabled"))));
/* 283 */     hashtable.put("InstancesGroupListPageID", new Integer(databaseConnector.getInt("InstancesGroupListPageID")));
/* 284 */     hashtable.put("InstancesGroupContentTypeID", new Integer(databaseConnector.getInt("InstancesGroupContentTypeID")));
/* 285 */     hashtable.put("contentTypeName", databaseConnector.getField("contentTypeName"));
/*     */     
/* 287 */     return hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ContentType getGroupContentType(int paramInt) {
/* 296 */     Hashtable hashtable = new Hashtable();
/*     */ 
/*     */ 
/*     */     
/* 300 */     Integer integer = new Integer(paramInt);
/*     */ 
/*     */     
/* 303 */     String str = FornaxHelper.replaceParameters("SELECT ct.* from fnContentTypeInstancesGroup ctg INNER JOIN fnContentType ct on ctg.InstancesGroupContentTypeID = ct.ContentTypeID WHERE ctg.InstancesGroupContentTypeID = @contentTypeID", "@contentTypeID", integer.toString());
/* 304 */     DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
/* 305 */     databaseConnector.runQuery();
/*     */ 
/*     */     
/* 308 */     hashtable.put("contentTypeID", new Integer(databaseConnector.getInt("contentTypeID")));
/* 309 */     hashtable.put("contentTypeName", databaseConnector.getField("contentTypeName"));
/* 310 */     hashtable.put("contentTypeDescription", databaseConnector.getField("contentTypeDescription"));
/* 311 */     hashtable.put("contentTypeIsSingleton", new Boolean(changeToBooleanString(databaseConnector.getField("contentTypeIsSingleton"))));
/* 312 */     hashtable.put("contentTypeIsListPageGenerated", new Boolean(changeToBooleanString(databaseConnector.getField("contentTypeIsListPageGenerated"))));
/*     */ 
/*     */     
/* 315 */     int i = databaseConnector.getInt("contentTypeListPageID");
/* 316 */     hashtable.put("contentTypeListPage", getListPage(i));
/*     */ 
/*     */     
/* 319 */     int j = databaseConnector.getInt("contentTypeID");
/* 320 */     hashtable.put("contentTypeFields", getContentTypeFields(j));
/*     */ 
/*     */     
/* 323 */     ContentType contentType = new ContentType(hashtable);
/*     */     
/* 325 */     databaseConnector.close();
/*     */     
/* 327 */     return contentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ListPage getListPage(int paramInt) {
/* 336 */     Hashtable hashtable = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 341 */     Integer integer = new Integer(paramInt);
/*     */     
/* 343 */     String str = FornaxHelper.replaceParameters("SELECT * from fnListPage WHERE ListPageID = @listPageID", "@listPageID", integer.toString());
/* 344 */     DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
/* 345 */     databaseConnector.runQuery();
/*     */ 
/*     */     
/* 348 */     hashtable.put("listPageID", new Integer(databaseConnector.getInt("listPageID")));
/* 349 */     hashtable.put("listPageFileNamePrefix", checkForNone(databaseConnector.getField("listPageFileNamePrefix")));
/* 350 */     hashtable.put("listPageFileNameTitle", checkForNone(databaseConnector.getField("listPageFileNameTitle")));
/* 351 */     hashtable.put("listPageFileNameSuffix", checkForNone(databaseConnector.getField("listPageFileNameSuffix")));
/* 352 */     hashtable.put("listPageFileNameExtension", checkForNone(databaseConnector.getField("listPageFileNameExtension")));
/*     */ 
/*     */ 
/*     */     
/* 356 */     int i = databaseConnector.getInt("listPageTemplateID");
/* 357 */     hashtable.put("listPageTemplate", createTemplate(i));
/*     */ 
/*     */     
/* 360 */     int j = databaseConnector.getInt("listPageGenerationDestinationID");
/* 361 */     hashtable.put("listPageGenerationDestination", createGenerationDestination(j));
/*     */ 
/*     */     
/* 364 */     ListPage listPage = new ListPage(hashtable);
/*     */     
/* 366 */     databaseConnector.close();
/* 367 */     return listPage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector getContentTypeFields(int paramInt) {
/* 377 */     Vector vector = new Vector();
/* 378 */     Hashtable hashtable = new Hashtable();
/*     */     
/* 380 */     Integer integer = new Integer(paramInt);
/*     */     
/* 382 */     String str = FornaxHelper.replaceParameters("SELECT * from fnContentTypeField ctf INNER JOIN fnContentTypeFieldDataType cdt on ctf.FieldDataTypeID = cdt.DataTypeID WHERE ctf.FieldContentTypeID = @contentTypeID", "@contentTypeID", integer.toString());
/* 383 */     DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
/* 384 */     databaseConnector.runQuery();
/*     */ 
/*     */     
/* 387 */     while (databaseConnector.more()) {
/*     */       
/* 389 */       hashtable.put("instanceFieldID", new Integer(databaseConnector.getInt("instanceFieldID")));
/* 390 */       hashtable.put("instanceContentTypeID", new Integer(databaseConnector.getInt("instanceContentTypeID")));
/* 391 */       hashtable.put("instanceFieldName", databaseConnector.getField("instanceFieldName"));
/* 392 */       hashtable.put("instanceFieldDescription", databaseConnector.getField("instanceFieldDescription"));
/* 393 */       hashtable.put("instanceDataTypeID", new Integer(databaseConnector.getInt("instanceDataTypeID")));
/* 394 */       hashtable.put("instanceDataTypeName", databaseConnector.getField("instanceDataTypeName"));
/* 395 */       hashtable.put("instanceDataTypeDescription", databaseConnector.getField("instanceDataTypeDescription"));
/*     */       
/* 397 */       vector.addElement(createContentTypeField(hashtable));
/* 398 */       hashtable.clear();
/* 399 */       databaseConnector.next();
/*     */     } 
/*     */     
/* 402 */     databaseConnector.close();
/* 403 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector getContentTypeInstances(int paramInt) {
/* 412 */     Vector vector = new Vector();
/* 413 */     Hashtable hashtable = new Hashtable();
/*     */ 
/*     */ 
/*     */     
/* 417 */     Integer integer = new Integer(paramInt);
/*     */ 
/*     */     
/* 420 */     String str = FornaxHelper.replaceParameters("SELECT ctg.InstancesGroupID, ctg.InstanceSequenceNumber, cti.* , ct.* , g.InstancesGroupName FROM fnMapContentTypeInstanceToInstancesGroup ctg INNER JOIN fnContentTypeInstance cti on ctg.InstanceID = cti.instanceID INNER JOIN fnContentType ct on cti.InstanceContentTypeID = ct.ContentTypeID INNER JOIN fnContentTypeInstancesGroup g on ctg.InstancesGroupID = g.InstancesGroupID WHERE ctg.InstancesGroupID = @groupID ORDER BY cti.InstanceIsQueuedForDeletion ASC, cti.InstanceIsDisabled ASC, ctg.InstanceSequenceNumber", "@groupID", integer.toString());
/* 421 */     DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
/* 422 */     databaseConnector.runQuery();
/*     */ 
/*     */     
/* 425 */     while (databaseConnector.more()) {
/*     */ 
/*     */       
/* 428 */       hashtable.put("instanceID", new Integer(databaseConnector.getInt("instanceID")));
/* 429 */       hashtable.put("instanceName", databaseConnector.getField("instanceName"));
/* 430 */       hashtable.put("instanceDescription", databaseConnector.getField("instanceDescription"));
/* 431 */       hashtable.put("instanceGroupID", new Integer(databaseConnector.getInt("instanceGroupID")));
/* 432 */       hashtable.put("instancesGroupName", databaseConnector.getField("instancesGroupName"));
/* 433 */       hashtable.put("instanceContentTypeID", new Integer(databaseConnector.getInt("instanceContentTypeID")));
/* 434 */       hashtable.put("ContentTypeName", databaseConnector.getField("ContentTypeName"));
/* 435 */       hashtable.put("instanceSequenceNumber", new Integer(databaseConnector.getInt("instanceSequenceNumber")));
/* 436 */       hashtable.put("instanceIsQueuedForDeletion", new Boolean(changeToBooleanString(databaseConnector.getField("instanceIsQueuedForDeletion"))));
/* 437 */       hashtable.put("instanceIsDisabled", new Boolean(changeToBooleanString(databaseConnector.getField("instanceIsDisabled"))));
/* 438 */       hashtable.put("instanceDateCreated", databaseConnector.getField("instanceDateCreated"));
/* 439 */       hashtable.put("instanceLastModifiedByUserID", new Integer(databaseConnector.getInt("instanceLastModifiedByUserID")));
/* 440 */       hashtable.put("instanceLastModifiedTimeStamp", databaseConnector.getField("instanceLastModifiedTimeStamp"));
/*     */       
/* 442 */       int i = databaseConnector.getInt("instanceID");
/* 443 */       int j = databaseConnector.getInt("instanceContentTypeID");
/* 444 */       hashtable.put("instanceFields", getContentTypeInstanceFieldData(i, j));
/*     */       
/* 446 */       vector.addElement(createContentTypeInstance(hashtable));
/* 447 */       hashtable.clear();
/* 448 */       databaseConnector.next();
/*     */     } 
/*     */     
/* 451 */     databaseConnector.close();
/* 452 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector getContentTypeInstanceFieldData(int paramInt1, int paramInt2) {
/* 465 */     Vector vector = new Vector();
/* 466 */     Hashtable hashtable = new Hashtable();
/*     */     
/* 468 */     Integer integer1 = new Integer(paramInt1);
/* 469 */     Integer integer2 = new Integer(paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 478 */     String str = FornaxHelper.replaceParameters("SELECT \t* FROM fnContentTypeInstanceFieldValue WHERE instanceID = @instanceID and  InstanceContentTypeID = @contentTypeID", "@instanceID", integer1.toString());
/* 479 */     str = FornaxHelper.replaceParameters(str, "@contentTypeID", integer2.toString());
/*     */     
/* 481 */     DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
/* 482 */     databaseConnector.runQuery();
/*     */ 
/*     */     
/* 485 */     while (databaseConnector.more()) {
/*     */       
/* 487 */       hashtable.put("instanceFieldID", new Integer(databaseConnector.getInt("instanceFieldID")));
/* 488 */       hashtable.put("instanceContentTypeID", new Integer(databaseConnector.getInt("instanceContentTypeID")));
/* 489 */       hashtable.put("instanceFieldName", databaseConnector.getField("instanceFieldName"));
/* 490 */       hashtable.put("instanceFieldDescription", databaseConnector.getField("instanceFieldDescription"));
/* 491 */       hashtable.put("instanceDataTypeID", new Integer(databaseConnector.getInt("instanceDataTypeID")));
/* 492 */       hashtable.put("instanceDataTypeName", databaseConnector.getField("instanceDataTypeName"));
/* 493 */       hashtable.put("instanceDataTypeDescription", databaseConnector.getField("instanceDataTypeDescription"));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 498 */       if (databaseConnector.getField("instanceDataTypeName").equalsIgnoreCase("DATE")) {
/*     */         String str1; int i;
/* 500 */         if (databaseConnector.getField("instanceFieldValue").equalsIgnoreCase("[none]")) {
/*     */           
/* 502 */           i = -1;
/*     */           
/* 504 */           str1 = "01/01/1900 12:00 AM PDT";
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 509 */           i = databaseConnector.getInt("dateValueID");
/* 510 */           str1 = databaseConnector.getField("instanceFieldValue");
/*     */         } 
/*     */         
/* 513 */         hashtable.put("dateValueID", new Integer(i));
/* 514 */         hashtable.put("dateValueData", str1);
/* 515 */         hashtable.put("dateValueInstance", new Integer(paramInt1));
/* 516 */         ContentTypeFieldDate contentTypeFieldDate = new ContentTypeFieldDate(hashtable);
/* 517 */         vector.addElement(contentTypeFieldDate);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 522 */       else if (databaseConnector.getField("instanceDataTypeName").equalsIgnoreCase("INTEGER")) {
/*     */         String str1; int i;
/* 524 */         if (databaseConnector.getField("instanceFieldValue").equalsIgnoreCase("[none]")) {
/*     */           
/* 526 */           i = -1;
/* 527 */           str1 = "0";
/*     */         }
/*     */         else {
/*     */           
/* 531 */           i = databaseConnector.getInt("intergerValueID");
/* 532 */           str1 = databaseConnector.getField("instanceFieldValue");
/*     */         } 
/*     */         
/* 535 */         hashtable.put("intergerValueID", new Integer(i));
/* 536 */         hashtable.put("integerValueData", str1);
/* 537 */         hashtable.put("integerValueInstance", new Integer(paramInt1));
/* 538 */         ContentTypeFieldInteger contentTypeFieldInteger = new ContentTypeFieldInteger(hashtable);
/* 539 */         vector.addElement(contentTypeFieldInteger);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 544 */       else if (databaseConnector.getField("instanceDataTypeName").equalsIgnoreCase("FLOATINGPOINT")) {
/*     */         String str1; int i;
/* 546 */         if (databaseConnector.getField("instanceFieldValue").equalsIgnoreCase("[none]")) {
/*     */           
/* 548 */           i = -1;
/* 549 */           str1 = "0";
/*     */         }
/*     */         else {
/*     */           
/* 553 */           i = databaseConnector.getInt("floatingPointValueID");
/* 554 */           str1 = databaseConnector.getField("instanceFieldValue");
/*     */         } 
/*     */         
/* 557 */         hashtable.put("floatingPointValueID", new Integer(i));
/* 558 */         hashtable.put("floatingPointValueData", str1);
/* 559 */         hashtable.put("floatingPointValueInstance", new Integer(paramInt1));
/* 560 */         ContentTypeFieldFloat contentTypeFieldFloat = new ContentTypeFieldFloat(hashtable);
/* 561 */         vector.addElement(contentTypeFieldFloat);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 566 */       else if (databaseConnector.getField("instanceDataTypeName").equalsIgnoreCase("STRING")) {
/*     */         String str1; int i;
/* 568 */         if (databaseConnector.getField("instanceFieldValue").equalsIgnoreCase("[none]")) {
/*     */           
/* 570 */           i = -1;
/* 571 */           str1 = "";
/*     */         }
/*     */         else {
/*     */           
/* 575 */           i = databaseConnector.getInt("stringPointValueID");
/* 576 */           str1 = databaseConnector.getField("instanceFieldValue");
/*     */         } 
/*     */         
/* 579 */         hashtable.put("stringPointValueID", new Integer(i));
/* 580 */         hashtable.put("stringPointValueData", str1);
/* 581 */         hashtable.put("stringPointValueInstance", new Integer(paramInt1));
/* 582 */         ContentTypeFieldString contentTypeFieldString = new ContentTypeFieldString(hashtable);
/* 583 */         vector.addElement(contentTypeFieldString);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 588 */       hashtable.clear();
/* 589 */       databaseConnector.next();
/*     */     } 
/*     */     
/* 592 */     databaseConnector.close();
/*     */     
/* 594 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector getGroupVariants(int paramInt) {
/* 604 */     Hashtable hashtable = new Hashtable();
/* 605 */     Vector vector = new Vector();
/*     */ 
/*     */ 
/*     */     
/* 609 */     Integer integer = new Integer(paramInt);
/*     */     
/* 611 */     String str = FornaxHelper.replaceParameters("SELECT * FROM fnContentTypeInstancesGroupVariant cg INNER JOIN fnVariantType v on v.VariantTypeID = cg.VariantTypeID WHERE cg.VariantInstancesGroupID = @groupID", "@groupID", integer.toString());
/* 612 */     DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
/* 613 */     databaseConnector.runQuery();
/*     */ 
/*     */     
/* 616 */     while (databaseConnector.more()) {
/*     */ 
/*     */       
/* 619 */       hashtable.put("variantID", new Integer(databaseConnector.getInt("variantID")));
/* 620 */       hashtable.put("variantTypeID", new Integer(databaseConnector.getInt("variantTypeID")));
/* 621 */       hashtable.put("variantTypeCode", databaseConnector.getField("variantTypeCode"));
/* 622 */       hashtable.put("variantTypeDescription", databaseConnector.getField("variantTypeDescription"));
/* 623 */       hashtable.put("variantInstancesGroupID", new Integer(databaseConnector.getInt("variantInstancesGroupID")));
/* 624 */       hashtable.put("variantIsEnabledForGeneration", new Boolean(changeToBooleanString(databaseConnector.getField("variantIsEnabledForGeneration"))));
/* 625 */       hashtable.put("variantFileNamePrefix", checkForNone(databaseConnector.getField("variantFileNamePrefix")));
/* 626 */       hashtable.put("variantFileNameTitle", checkForNone(databaseConnector.getField("variantFileNameTitle")));
/* 627 */       hashtable.put("variantFileNameSuffix", checkForNone(databaseConnector.getField("variantFileNameSuffix")));
/* 628 */       hashtable.put("variantFileNameExtension", checkForNone(databaseConnector.getField("variantFileNameExtension")));
/* 629 */       hashtable.put("variantFileNameNumberingMode", databaseConnector.getField("variantFileNameNumberingMode"));
/*     */       
/* 631 */       int i = databaseConnector.getInt("variantTemplateID");
/* 632 */       hashtable.put("variantTemplate", createTemplate(i));
/*     */       
/* 634 */       int j = databaseConnector.getInt("variantGenerationDestinationID");
/* 635 */       hashtable.put("variantGenerationDestination", createGenerationDestination(j));
/*     */ 
/*     */       
/* 638 */       vector.addElement(createVariant(hashtable));
/*     */ 
/*     */       
/* 641 */       if (this.debug) {
/* 642 */         System.out.println("Is this variant enabled for generation ? = " + databaseConnector.getField("variantIsEnabledForGeneration"));
/*     */       }
/* 644 */       hashtable.clear();
/* 645 */       databaseConnector.next();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 650 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 664 */   private Variant createVariant(Hashtable paramHashtable) { return new Variant(paramHashtable); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ContentTypeInstanceGroup createContentTypeInstanceGroup(Hashtable paramHashtable) {
/* 678 */     ContentTypeInstanceGroup contentTypeInstanceGroup = new ContentTypeInstanceGroup(paramHashtable);
/*     */     
/* 680 */     buildGroupHashtable(contentTypeInstanceGroup, paramHashtable);
/*     */     
/* 682 */     return contentTypeInstanceGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Template createTemplate(int paramInt) {
/* 691 */     Hashtable hashtable = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 696 */     Integer integer = new Integer(paramInt);
/*     */     
/* 698 */     String str = FornaxHelper.replaceParameters("SELECT * from fnContentTypeTemplate  WHERE ContentTypeTemplateID = @templateID", "@templateID", integer.toString());
/* 699 */     DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
/* 700 */     databaseConnector.runQuery();
/*     */ 
/*     */     
/* 703 */     hashtable.put("contentTypeTemplateID", new Integer(databaseConnector.getInt("contentTypeTemplateID")));
/* 704 */     hashtable.put("contentTypeTemplateFileName", databaseConnector.getField("contentTypeTemplateFileName"));
/* 705 */     hashtable.put("contentTypeTemplateFileDescription", databaseConnector.getField("contentTypeTemplateFileDescription"));
/*     */ 
/*     */     
/* 708 */     int i = databaseConnector.getInt("contentTypeTemplateFilePathID");
/* 709 */     hashtable.put("contentTypeTemplateFilePath", createFilePath(i));
/*     */ 
/*     */     
/* 712 */     Template template = new Template(hashtable);
/*     */     
/* 714 */     databaseConnector.close();
/* 715 */     return template;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GenerationDestination createGenerationDestination(int paramInt) {
/* 725 */     Hashtable hashtable = new Hashtable();
/*     */ 
/*     */     
/* 728 */     Integer integer = new Integer(paramInt);
/*     */     
/* 730 */     String str = FornaxHelper.replaceParameters("SELECT * from fnGenerationDestination WHERE GenerationDestinationID = @destinationID", "@destinationID", integer.toString());
/* 731 */     DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
/* 732 */     databaseConnector.runQuery();
/*     */ 
/*     */     
/* 735 */     hashtable.put("generationDestinationID", new Integer(databaseConnector.getInt("generationDestinationID")));
/* 736 */     hashtable.put("generationDestinationName", databaseConnector.getField("generationDestinationName"));
/* 737 */     hashtable.put("generationDestinationDesc", databaseConnector.getField("generationDestinationDesc"));
/* 738 */     hashtable.put("generationDestinationServerNetworkName", databaseConnector.getField("generationDestinationServerNetworkName"));
/* 739 */     hashtable.put("generationDestinationServerDNSName", databaseConnector.getField("generationDestinationServerDNSName"));
/* 740 */     hashtable.put("generationDestinationServerIPAddress", databaseConnector.getField("generationDestinationServerIPAddress"));
/* 741 */     hashtable.put("generationDestinationLogonUserName", databaseConnector.getField("generationDestinationLogonUserName"));
/* 742 */     hashtable.put("generationDestinationLogonPassword", databaseConnector.getField("generationDestinationLogonPassword"));
/*     */ 
/*     */     
/* 745 */     int i = databaseConnector.getInt("generationDestinationFilePathID");
/* 746 */     hashtable.put("generationDestinationFilePath", createFilePath(i));
/*     */ 
/*     */     
/* 749 */     GenerationDestination generationDestination = new GenerationDestination(hashtable);
/*     */     
/* 751 */     databaseConnector.close();
/* 752 */     return generationDestination;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FilePath createFilePath(int paramInt) {
/* 761 */     Hashtable hashtable = new Hashtable();
/*     */     
/* 763 */     Integer integer = new Integer(paramInt);
/*     */     
/* 765 */     String str = FornaxHelper.replaceParameters("SELECT * from fnFilePath where FilePathID = @filePathID", "@filePathID", integer.toString());
/* 766 */     DatabaseConnector databaseConnector = this.mSettings.getConnector(str);
/* 767 */     databaseConnector.runQuery();
/*     */     
/* 769 */     hashtable.put("filePathID", new Integer(databaseConnector.getInt("filePathID")));
/* 770 */     hashtable.put("filePathName", databaseConnector.getField("filePathName"));
/* 771 */     hashtable.put("filePathIsRelative", new Boolean(changeToBooleanString(databaseConnector.getField("filePathIsRelative"))));
/*     */     
/* 773 */     FilePath filePath = new FilePath(hashtable);
/*     */     
/* 775 */     databaseConnector.close();
/* 776 */     return filePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 785 */   private ContentTypeField createContentTypeField(Hashtable paramHashtable) { return new ContentTypeField(paramHashtable); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 794 */   private ContentTypeInstance createContentTypeInstance(Hashtable paramHashtable) { return new ContentTypeInstance(paramHashtable); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 803 */   private void buildGroupHashtable(ContentTypeInstanceGroup paramContentTypeInstanceGroup, Hashtable paramHashtable) { this.mGroupTable.put(((String)paramHashtable.get("InstancesGroupName")).toUpperCase(), paramContentTypeInstanceGroup); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 812 */   private void buildContentTypeHashtable(ContentType paramContentType, Hashtable paramHashtable) { this.mContentTypeTable.put(((String)paramHashtable.get("contentTypeName")).toUpperCase(), paramContentType); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 821 */   public Hashtable getGroupTable() { return this.mGroupTable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 829 */   public Hashtable getContentTypeTable() { return this.mContentTypeTable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String changeToBooleanString(String paramString) {
/* 838 */     if (paramString.equalsIgnoreCase("T")) {
/* 839 */       return "true";
/*     */     }
/* 841 */     return "false";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String checkForNone(String paramString) {
/* 849 */     if (paramString.equalsIgnoreCase("[none]")) {
/* 850 */       return "";
/*     */     }
/* 852 */     return paramString;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\DataObjectManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */