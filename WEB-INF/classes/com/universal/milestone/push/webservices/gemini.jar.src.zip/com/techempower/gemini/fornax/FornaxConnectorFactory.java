/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.ConnectorFactory;
/*     */ import com.techempower.DatabaseConnector;
/*     */ import com.techempower.EnhancedProperties;
/*     */ import com.techempower.JdbcConnector;
/*     */ import com.techempower.TechEmpowerApplication;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxConnectorFactory
/*     */   implements ConnectorFactory
/*     */ {
/*     */   public static final String COMPONENT_CODE = "cnfc";
/*     */   protected String propertyPrefix;
/*     */   protected String dbConnect;
/*     */   protected String dbLoginName;
/*     */   protected String dbLoginPass;
/*     */   protected String driverUrlPrefix;
/*     */   protected String driverClass;
/*     */   protected boolean driverJdbc1;
/*     */   protected boolean driverSupGetRow;
/*     */   protected boolean driverSupAbs;
/*     */   
/*     */   public FornaxConnectorFactory(String paramString) {
/*  60 */     this.propertyPrefix = "";
/*  61 */     this.dbConnect = "Berlin/TEWebsite_v2/sql70=true";
/*  62 */     this.dbLoginName = "tewebsite";
/*  63 */     this.dbLoginPass = "tewebsite";
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.driverUrlPrefix = "jdbc:JTurbo://";
/*  68 */     this.driverClass = "com.ashna.jturbo.driver.Driver";
/*  69 */     this.driverJdbc1 = false;
/*     */     
/*  71 */     this.driverSupGetRow = false;
/*  72 */     this.driverSupAbs = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     this.propertyPrefix = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FornaxConnectorFactory() {
/*  95 */     this("db.");
/*  96 */     configure();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(EnhancedProperties paramEnhancedProperties, TechEmpowerApplication paramTechEmpowerApplication) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure() {
/* 132 */     JdbcConnector.loadDriver(this.driverClass, this.driverUrlPrefix, this.driverSupAbs, 
/* 133 */         this.driverSupGetRow, this.driverJdbc1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatabaseConnector getConnector(String paramString) {
/* 144 */     JdbcConnector jdbcConnector = new JdbcConnector(this.driverUrlPrefix, this.dbConnect, paramString);
/* 145 */     jdbcConnector.setUsername(this.dbLoginName);
/* 146 */     jdbcConnector.setPassword(this.dbLoginPass);
/* 147 */     jdbcConnector.setForwardOnly(true);
/*     */     
/* 149 */     return jdbcConnector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatabaseConnector getScrollingConnector(String paramString) {
/* 159 */     JdbcConnector jdbcConnector = new JdbcConnector(this.driverUrlPrefix, this.dbConnect, paramString);
/* 160 */     jdbcConnector.setUsername(this.dbLoginName);
/* 161 */     jdbcConnector.setPassword(this.dbLoginPass);
/* 162 */     jdbcConnector.setForwardOnly(false);
/*     */     
/* 164 */     return jdbcConnector;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxConnectorFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */