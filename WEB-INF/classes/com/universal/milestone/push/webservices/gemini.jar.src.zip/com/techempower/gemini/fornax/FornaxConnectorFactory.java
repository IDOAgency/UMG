package com.techempower.gemini.fornax;

import com.techempower.ConnectorFactory;
import com.techempower.DatabaseConnector;
import com.techempower.EnhancedProperties;
import com.techempower.JdbcConnector;
import com.techempower.TechEmpowerApplication;

public class FornaxConnectorFactory implements ConnectorFactory {
  public static final String COMPONENT_CODE = "cnfc";
  
  protected String propertyPrefix;
  
  protected String dbConnect;
  
  protected String dbLoginName;
  
  protected String dbLoginPass;
  
  protected String driverUrlPrefix;
  
  protected String driverClass;
  
  protected boolean driverJdbc1;
  
  protected boolean driverSupGetRow;
  
  protected boolean driverSupAbs;
  
  public FornaxConnectorFactory(String paramString) {
    this.propertyPrefix = "";
    this.dbConnect = "Berlin/TEWebsite_v2/sql70=true";
    this.dbLoginName = "tewebsite";
    this.dbLoginPass = "tewebsite";
    this.driverUrlPrefix = "jdbc:JTurbo://";
    this.driverClass = "com.ashna.jturbo.driver.Driver";
    this.driverJdbc1 = false;
    this.driverSupGetRow = false;
    this.driverSupAbs = false;
    this.propertyPrefix = paramString;
  }
  
  public FornaxConnectorFactory() {
    this("db.");
    configure();
  }
  
  public void configure(EnhancedProperties paramEnhancedProperties, TechEmpowerApplication paramTechEmpowerApplication) {}
  
  public void configure() {
    JdbcConnector.loadDriver(this.driverClass, this.driverUrlPrefix, this.driverSupAbs, 
        this.driverSupGetRow, this.driverJdbc1);
  }
  
  public DatabaseConnector getConnector(String paramString) {
    JdbcConnector jdbcConnector = new JdbcConnector(this.driverUrlPrefix, this.dbConnect, paramString);
    jdbcConnector.setUsername(this.dbLoginName);
    jdbcConnector.setPassword(this.dbLoginPass);
    jdbcConnector.setForwardOnly(true);
    return jdbcConnector;
  }
  
  public DatabaseConnector getScrollingConnector(String paramString) {
    JdbcConnector jdbcConnector = new JdbcConnector(this.driverUrlPrefix, this.dbConnect, paramString);
    jdbcConnector.setUsername(this.dbLoginName);
    jdbcConnector.setPassword(this.dbLoginPass);
    jdbcConnector.setForwardOnly(false);
    return jdbcConnector;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxConnectorFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */