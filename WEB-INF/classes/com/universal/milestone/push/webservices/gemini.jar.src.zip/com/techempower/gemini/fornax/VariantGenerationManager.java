package com.techempower.gemini.fornax;

import java.io.BufferedReader;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

public class VariantGenerationManager implements FornaxDBConstants {
  protected boolean debug;
  
  protected Vector mBadTags;
  
  protected Vector mTemplateTags;
  
  protected String mTemplateString;
  
  protected Vector mInstances;
  
  protected GenerationDestination mDestination;
  
  protected GeneratorFileManager mFileManager;
  
  protected DBRecordManager mDBRecordManager;
  
  protected Variant mVariant;
  
  protected Hashtable mContentTypeTable;
  
  protected ListPage mListPage;
  
  protected boolean mIsGroupSingleton;
  
  protected Generator mGenerator;
  
  protected ContentType mContentType;
  
  public VariantGenerationManager(Variant paramVariant, Hashtable paramHashtable, Generator paramGenerator) {
    this.debug = false;
    this.mBadTags = new Vector();
    this.mTemplateTags = new Vector();
    this.mTemplateString = "";
    this.mInstances = new Vector();
    this.mFileManager = new GeneratorFileManager();
    this.mDBRecordManager = new DBRecordManager();
    this.mContentTypeTable = new Hashtable();
    this.mIsGroupSingleton = false;
    this.mVariant = paramVariant;
    this.mContentTypeTable = paramHashtable;
    this.mGenerator = paramGenerator;
    this.mFileManager.setGenerator(this.mGenerator);
  }
  
  public void setInstances(Vector paramVector) { this.mInstances = paramVector; }
  
  public void setSingletonFlag(boolean paramBoolean) { this.mIsGroupSingleton = paramBoolean; }
  
  public void setContentType(ContentType paramContentType) { this.mContentType = paramContentType; }
  
  public void setListPage(ListPage paramListPage) { this.mListPage = paramListPage; }
  
  public void loadTemplate(Template paramTemplate, boolean paramBoolean) {
    BufferedReader bufferedReader = this.mFileManager.getTemplateFile(paramTemplate);
    parseTemplate(bufferedReader, paramBoolean);
  }
  
  public void parseTemplate(BufferedReader paramBufferedReader, boolean paramBoolean) {
    String str1 = "";
    String str2 = "";
    boolean bool1 = true;
    boolean bool2 = true;
    String str3 = "";
    try {
      while (str1 != null) {
        str1 = paramBufferedReader.readLine().trim();
        if (str1.startsWith("[[")) {
          if (str1.indexOf("content-item") > 0) {
            str2 = readUntilEndTag(paramBufferedReader, "]]");
            if (str2 != null) {
              TemplateTagContentItem templateTagContentItem = parseContentItemString(str2);
              if (templateTagContentItem != null) {
                this.mTemplateTags.addElement(templateTagContentItem);
                this.mTemplateString = String.valueOf(this.mTemplateString) + "[[" + (this.mTemplateTags.size() - 1) + "]]" + "\n";
              } 
            } 
          } else if (str1.indexOf("content-loop") > 0) {
            TemplateTagContentLoop templateTagContentLoop = getContentLoop(str1);
            str2 = readUntilEndTag(paramBufferedReader, "[[content-endloop]]");
            if (str2 != null) {
              Vector vector = parseContentLoopString(str2);
              templateTagContentLoop.setContentItems(vector);
              if (vector.size() != 0) {
                this.mTemplateTags.addElement(templateTagContentLoop);
                this.mTemplateString = String.valueOf(this.mTemplateString) + "[[" + (this.mTemplateTags.size() - 1) + "]]" + "\n";
              } else {
                this.mBadTags.addElement(str2);
              } 
            } 
          } 
          str2 = "";
          continue;
        } 
        this.mTemplateString = String.valueOf(this.mTemplateString) + str1 + "\n";
      } 
    } catch (Exception exception) {}
  }
  
  public TemplateTagContentItem parseContentItemString(String paramString) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, "\n");
    Hashtable hashtable = new Hashtable();
    String str1 = "";
    String str2 = "";
    String str3 = "";
    String str4 = "";
    String str5 = "";
    String str6 = "";
    String str7 = "";
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken().trim();
      if (str.startsWith("type=")) {
        str1 = getText(str.substring("type=".length(), str.length()));
      } else if (str.startsWith("typegroup=")) {
        str2 = getText(str.substring("typegroup=".length(), str.length()));
      } else if (str.startsWith("variant=")) {
        str3 = getText(str.substring("variant=".length(), str.length()));
      } else if (str.startsWith("field=")) {
        str4 = getText(str.substring("field=".length(), str.length()));
      } else if (str.startsWith("before=")) {
        str5 = getText(str.substring("before=".length(), str.length()));
      } else if (str.startsWith("after=")) {
        str6 = getText(str.substring("after=".length(), str.length()));
      } else if (str.startsWith("delta=")) {
        str7 = getText(str.substring("delta=".length(), str.length()));
      } 
      hashtable.put("type=", str1);
      hashtable.put("typegroup=", str2);
      hashtable.put("variant=", str3);
      hashtable.put("field=", str4);
      hashtable.put("before=", str5);
      hashtable.put("after=", str6);
      hashtable.put("delta=", str7);
    } 
    TemplateTagContentItem templateTagContentItem = new TemplateTagContentItem(hashtable, this.mContentTypeTable);
    if (this.debug) {
      System.out.println("my contentType is = " + templateTagContentItem.getContentType());
      System.out.println("my group is = " + templateTagContentItem.getContentTypeGroup());
      System.out.println("my variant is = " + templateTagContentItem.getVariant());
      System.out.println("my delta is = " + templateTagContentItem.getDelta());
      System.out.println("my field = " + templateTagContentItem.getField());
      System.out.println("my before = " + templateTagContentItem.getBeforeHTML());
      System.out.println("my after  = " + templateTagContentItem.getAfterHTML());
    } 
    hashtable.clear();
    return templateTagContentItem;
  }
  
  public Vector parseContentLoopString(String paramString) {
    Vector vector = new Vector();
    int i = 0;
    int j = 0;
    if (paramString.indexOf("[[content-item") > 0) {
      while (paramString.indexOf("[[content-item", i) > 0) {
        i = paramString.indexOf("[[content-item", i) + 1;
        j = paramString.indexOf("]]", i);
        String str = paramString.substring(i + "[[content-item".length(), j);
        TemplateTagContentItem templateTagContentItem = parseContentItemString(str);
        if (templateTagContentItem != null) {
          vector.addElement(templateTagContentItem);
          continue;
        } 
        this.mBadTags.addElement(paramString);
      } 
    } else {
      this.mBadTags.addElement(paramString);
    } 
    return vector;
  }
  
  public String getText(String paramString) {
    byte b;
    boolean bool = false;
    String str = "";
    int i = paramString.indexOf("\"");
    if (paramString.endsWith("\"")) {
      b = paramString.length() - 1;
    } else {
      b = -1;
    } 
    if (b == -1)
      str = paramString; 
    if (i < b)
      str = paramString.substring(i + 1, b); 
    return str;
  }
  
  public String readUntilEndTag(BufferedReader paramBufferedReader, String paramString) {
    boolean bool = true;
    String str1 = "";
    String str2 = "";
    while (bool) {
      try {
        str2 = paramBufferedReader.readLine();
        if (this.debug)
          System.out.println(str2); 
        if (str2.indexOf(paramString) < 0) {
          str1 = String.valueOf(str1) + "\n" + str2;
          if (str2 == null) {
            System.out.println("Could not find an end tag. ");
            bool = false;
            str1 = null;
            this.mBadTags.addElement(str2);
          } 
          continue;
        } 
        str1 = String.valueOf(str1) + str2.substring(0, str2.indexOf(paramString));
        bool = false;
      } catch (Exception exception) {
        if (str2 == null)
          bool = false; 
        this.mBadTags.addElement(str2);
        System.out.println("Exception Error in VariantGenerationManger.readUntilEndTag() : Can not read line from Template file ");
      } 
    } 
    return str1;
  }
  
  public TemplateTagContentLoop getContentLoop(String paramString) {
    Hashtable hashtable = new Hashtable();
    if (paramString.indexOf("type=") > 0) {
      int i = paramString.indexOf("type=") + "type=".length() + 1;
      int j = paramString.indexOf("\"", i);
      hashtable.put("type=", paramString.substring(i, j));
    } 
    if (paramString.indexOf("typegroup=") > 0) {
      int i = paramString.indexOf("typegroup=") + "typegroup=".length() + 1;
      int j = paramString.indexOf("\"", i);
      hashtable.put("typegroup=", paramString.substring(i, j));
    } 
    if (paramString.indexOf("variant=") > 0) {
      int i = paramString.indexOf("variant=") + "variant=".length() + 1;
      int j = paramString.indexOf("\"", i);
      hashtable.put("variant=", paramString.substring(i, j));
    } 
    return new TemplateTagContentLoop(hashtable, this.mContentTypeTable);
  }
  
  public void generate() {
    byte b1 = 0;
    if (this.debug)
      System.out.println("  In VariantGenerationManger.generate() Looping thru instances............."); 
    for (byte b2 = 0; b2 < this.mInstances.size(); b2++) {
      ContentTypeInstance contentTypeInstance = (ContentTypeInstance)this.mInstances.elementAt(b2);
      this.mGenerator.getReport().addNewContentItem(this.mVariant, contentTypeInstance);
      if (contentTypeInstance.isQueuedForDeletion()) {
        this.mFileManager.deleteContentTypeInstanceFile(contentTypeInstance, this.mVariant);
        this.mDBRecordManager.deleteContentTypeInstance(contentTypeInstance.getInstanceID());
      } else if (contentTypeInstance.isDisabled()) {
        this.mGenerator.getReport().updateLine("No file generated.", "DISABLED");
        this.mFileManager.deleteContentTypeInstanceFile(contentTypeInstance, this.mVariant);
      } else if (this.mIsGroupSingleton && b1 >= 1) {
        this.mGenerator.getReport().updateLine("", "Group is a Singleton and has multiple instances enabled for generation.<br>  File not generated for instanceID [" + contentTypeInstance.getInstanceID() + "]");
        System.out.println("  ERROR : Group is a Singleton and has more than one instance enabled for generation.");
        System.out.println("          Instance file not generated for instanceID [" + contentTypeInstance.getInstanceID() + "]");
      } else {
        this.mFileManager.generateContentFiles(contentTypeInstance, this.mVariant, parseTemplateTags(contentTypeInstance, this.mTemplateTags, this.mTemplateString, this.mContentTypeTable));
        b1++;
      } 
    } 
  }
  
  public void generateListPage() { this.mFileManager.generateListPageFile(this.mListPage, parseTemplateTags(null, this.mTemplateTags, this.mTemplateString, this.mContentTypeTable)); }
  
  public void deleteListPage() { this.mFileManager.deleteListPageFile(this.mListPage); }
  
  public void deleteInstanceFiles() {
    for (byte b = 0; b < this.mInstances.size(); b++) {
      ContentTypeInstance contentTypeInstance = (ContentTypeInstance)this.mInstances.elementAt(b);
      this.mFileManager.deleteContentTypeInstanceFile(contentTypeInstance, this.mVariant);
    } 
  }
  
  public String parseTemplateTags(ContentTypeInstance paramContentTypeInstance, Vector paramVector, String paramString, Hashtable paramHashtable) {
    String str1 = "";
    String str2 = "";
    String str3 = "";
    Hashtable hashtable = new Hashtable();
    if (this.debug)
      System.out.println("  VariantGenerationManager.parseTemplateTag() "); 
    for (byte b = 0; b < paramVector.size(); b++) {
      String str = "[[" + (new Integer(b)).toString() + "]]";
      if (paramString.indexOf(str) != -1) {
        if (paramVector.elementAt(b) instanceof TemplateTagContentItem) {
          TemplateTagContentItem templateTagContentItem = (TemplateTagContentItem)paramVector.elementAt(b);
          if (templateTagContentItem != null)
            if (paramContentTypeInstance != null) {
              hashtable.put("instance", paramContentTypeInstance);
              hashtable.put("groupVariant", this.mVariant);
              hashtable.put("generator", this.mGenerator);
              hashtable.put("contentTypeTable", paramHashtable);
              str1 = templateTagContentItem.render(hashtable);
            } else {
              str1 = "";
            }  
        } else {
          TemplateTagContentLoop templateTagContentLoop = (TemplateTagContentLoop)paramVector.elementAt(b);
          if (templateTagContentLoop != null)
            str1 = templateTagContentLoop.render(this.mVariant, this.mGenerator); 
        } 
        StringBuffer stringBuffer = new StringBuffer(paramString);
        int i = paramString.indexOf(str);
        int j = i + str.length();
        if (str1 != null) {
          if (this.debug)
            System.out.println("  Replacing string template tag with = " + str2 + str1 + str3); 
          paramString = stringBuffer.replace(i, j, String.valueOf(str2) + str1 + str3).toString();
          str1 = "";
          str2 = "";
          str3 = "";
        } 
      } 
    } 
    return paramString;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\VariantGenerationManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */