/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariantGenerationManager
/*     */   implements FornaxDBConstants
/*     */ {
/*     */   protected boolean debug;
/*     */   protected Vector mBadTags;
/*     */   protected Vector mTemplateTags;
/*     */   protected String mTemplateString;
/*     */   protected Vector mInstances;
/*     */   protected GenerationDestination mDestination;
/*     */   protected GeneratorFileManager mFileManager;
/*     */   protected DBRecordManager mDBRecordManager;
/*     */   protected Variant mVariant;
/*     */   protected Hashtable mContentTypeTable;
/*     */   protected ListPage mListPage;
/*     */   protected boolean mIsGroupSingleton;
/*     */   protected Generator mGenerator;
/*     */   protected ContentType mContentType;
/*     */   
/*     */   public VariantGenerationManager(Variant paramVariant, Hashtable paramHashtable, Generator paramGenerator) {
/*  36 */     this.debug = false;
/*     */     
/*  38 */     this.mBadTags = new Vector();
/*  39 */     this.mTemplateTags = new Vector();
/*  40 */     this.mTemplateString = "";
/*  41 */     this.mInstances = new Vector();
/*     */     
/*  43 */     this.mFileManager = new GeneratorFileManager();
/*  44 */     this.mDBRecordManager = new DBRecordManager();
/*     */     
/*  46 */     this.mContentTypeTable = new Hashtable();
/*     */     
/*  48 */     this.mIsGroupSingleton = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     this.mVariant = paramVariant;
/*  58 */     this.mContentTypeTable = paramHashtable;
/*  59 */     this.mGenerator = paramGenerator;
/*  60 */     this.mFileManager.setGenerator(this.mGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public void setInstances(Vector paramVector) { this.mInstances = paramVector; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public void setSingletonFlag(boolean paramBoolean) { this.mIsGroupSingleton = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public void setContentType(ContentType paramContentType) { this.mContentType = paramContentType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public void setListPage(ListPage paramListPage) { this.mListPage = paramListPage; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadTemplate(Template paramTemplate, boolean paramBoolean) {
/* 102 */     BufferedReader bufferedReader = this.mFileManager.getTemplateFile(paramTemplate);
/* 103 */     parseTemplate(bufferedReader, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseTemplate(BufferedReader paramBufferedReader, boolean paramBoolean) {
/* 115 */     String str1 = "";
/* 116 */     String str2 = "";
/* 117 */     boolean bool1 = true;
/* 118 */     boolean bool2 = true;
/* 119 */     String str3 = "";
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 124 */       while (str1 != null)
/*     */       {
/* 126 */         str1 = paramBufferedReader.readLine().trim();
/*     */ 
/*     */         
/* 129 */         if (str1.startsWith("[[")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 135 */           if (str1.indexOf("content-item") > 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 141 */             str2 = readUntilEndTag(paramBufferedReader, "]]");
/*     */             
/* 143 */             if (str2 != null)
/*     */             {
/* 145 */               TemplateTagContentItem templateTagContentItem = parseContentItemString(str2);
/* 146 */               if (templateTagContentItem != null)
/*     */               {
/*     */                 
/* 149 */                 this.mTemplateTags.addElement(templateTagContentItem);
/*     */                 
/* 151 */                 this.mTemplateString = String.valueOf(this.mTemplateString) + "[[" + (this.mTemplateTags.size() - 1) + "]]" + "\n";
/*     */ 
/*     */               
/*     */               }
/*     */ 
/*     */             
/*     */             }
/*     */ 
/*     */           
/*     */           }
/* 161 */           else if (str1.indexOf("content-loop") > 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 170 */             TemplateTagContentLoop templateTagContentLoop = getContentLoop(str1);
/*     */ 
/*     */             
/* 173 */             str2 = readUntilEndTag(paramBufferedReader, "[[content-endloop]]");
/*     */             
/* 175 */             if (str2 != null) {
/*     */               
/* 177 */               Vector vector = parseContentLoopString(str2);
/* 178 */               templateTagContentLoop.setContentItems(vector);
/*     */ 
/*     */ 
/*     */               
/* 182 */               if (vector.size() != 0) {
/*     */ 
/*     */                 
/* 185 */                 this.mTemplateTags.addElement(templateTagContentLoop);
/*     */                 
/* 187 */                 this.mTemplateString = String.valueOf(this.mTemplateString) + "[[" + (this.mTemplateTags.size() - 1) + "]]" + "\n";
/*     */               
/*     */               }
/*     */               else {
/*     */                 
/* 192 */                 this.mBadTags.addElement(str2);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 198 */           str2 = "";
/*     */ 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */ 
/*     */         
/* 206 */         this.mTemplateString = String.valueOf(this.mTemplateString) + str1 + "\n";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 222 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateTagContentItem parseContentItemString(String paramString) {
/* 241 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, "\n");
/*     */ 
/*     */     
/* 244 */     Hashtable hashtable = new Hashtable();
/* 245 */     String str1 = "";
/* 246 */     String str2 = "";
/* 247 */     String str3 = "";
/* 248 */     String str4 = "";
/* 249 */     String str5 = "";
/* 250 */     String str6 = "";
/* 251 */     String str7 = "";
/*     */ 
/*     */     
/* 254 */     while (stringTokenizer.hasMoreTokens()) {
/*     */       
/* 256 */       String str = stringTokenizer.nextToken().trim();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 262 */       if (str.startsWith("type=")) {
/*     */         
/* 264 */         str1 = getText(str.substring("type=".length(), str.length()));
/*     */       }
/* 266 */       else if (str.startsWith("typegroup=")) {
/*     */         
/* 268 */         str2 = getText(str.substring("typegroup=".length(), str.length()));
/*     */       }
/* 270 */       else if (str.startsWith("variant=")) {
/*     */         
/* 272 */         str3 = getText(str.substring("variant=".length(), str.length()));
/*     */       }
/* 274 */       else if (str.startsWith("field=")) {
/*     */         
/* 276 */         str4 = getText(str.substring("field=".length(), str.length()));
/*     */       }
/* 278 */       else if (str.startsWith("before=")) {
/*     */         
/* 280 */         str5 = getText(str.substring("before=".length(), str.length()));
/*     */       }
/* 282 */       else if (str.startsWith("after=")) {
/*     */         
/* 284 */         str6 = getText(str.substring("after=".length(), str.length()));
/*     */       }
/* 286 */       else if (str.startsWith("delta=")) {
/*     */         
/* 288 */         str7 = getText(str.substring("delta=".length(), str.length()));
/*     */       } 
/*     */       
/* 291 */       hashtable.put("type=", str1);
/* 292 */       hashtable.put("typegroup=", str2);
/* 293 */       hashtable.put("variant=", str3);
/* 294 */       hashtable.put("field=", str4);
/* 295 */       hashtable.put("before=", str5);
/* 296 */       hashtable.put("after=", str6);
/* 297 */       hashtable.put("delta=", str7);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 302 */     TemplateTagContentItem templateTagContentItem = new TemplateTagContentItem(hashtable, this.mContentTypeTable);
/*     */ 
/*     */     
/* 305 */     if (this.debug) {
/*     */       
/* 307 */       System.out.println("my contentType is = " + templateTagContentItem.getContentType());
/* 308 */       System.out.println("my group is = " + templateTagContentItem.getContentTypeGroup());
/* 309 */       System.out.println("my variant is = " + templateTagContentItem.getVariant());
/* 310 */       System.out.println("my delta is = " + templateTagContentItem.getDelta());
/* 311 */       System.out.println("my field = " + templateTagContentItem.getField());
/* 312 */       System.out.println("my before = " + templateTagContentItem.getBeforeHTML());
/* 313 */       System.out.println("my after  = " + templateTagContentItem.getAfterHTML());
/*     */     } 
/*     */     
/* 316 */     hashtable.clear();
/* 317 */     return templateTagContentItem;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector parseContentLoopString(String paramString) {
/* 327 */     Vector vector = new Vector();
/*     */ 
/*     */ 
/*     */     
/* 331 */     int i = 0;
/* 332 */     int j = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     if (paramString.indexOf("[[content-item") > 0) {
/*     */       
/* 341 */       while (paramString.indexOf("[[content-item", i) > 0)
/*     */       {
/* 343 */         i = paramString.indexOf("[[content-item", i) + 1;
/*     */         
/* 345 */         j = paramString.indexOf("]]", i);
/* 346 */         String str = paramString.substring(i + "[[content-item".length(), j);
/* 347 */         TemplateTagContentItem templateTagContentItem = parseContentItemString(str);
/*     */         
/* 349 */         if (templateTagContentItem != null) {
/*     */           
/* 351 */           vector.addElement(templateTagContentItem);
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 356 */         this.mBadTags.addElement(paramString);
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 363 */       this.mBadTags.addElement(paramString);
/*     */     } 
/*     */     
/* 366 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String paramString) {
/*     */     byte b;
/* 376 */     boolean bool = false;
/*     */ 
/*     */     
/* 379 */     String str = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 385 */     int i = paramString.indexOf("\"");
/*     */     
/* 387 */     if (paramString.endsWith("\"")) {
/* 388 */       b = paramString.length() - 1;
/*     */     } else {
/* 390 */       b = -1;
/*     */     } 
/*     */ 
/*     */     
/* 394 */     if (b == -1)
/*     */     {
/* 396 */       str = paramString;
/*     */     }
/*     */ 
/*     */     
/* 400 */     if (i < b)
/*     */     {
/* 402 */       str = paramString.substring(i + 1, b);
/*     */     }
/*     */ 
/*     */     
/* 406 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readUntilEndTag(BufferedReader paramBufferedReader, String paramString) {
/* 416 */     boolean bool = true;
/* 417 */     String str1 = "";
/* 418 */     String str2 = "";
/*     */ 
/*     */     
/* 421 */     while (bool) {
/*     */ 
/*     */       
/*     */       try {
/* 425 */         str2 = paramBufferedReader.readLine();
/*     */ 
/*     */         
/* 428 */         if (this.debug)
/*     */         {
/* 430 */           System.out.println(str2);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 435 */         if (str2.indexOf(paramString) < 0) {
/*     */           
/* 437 */           str1 = String.valueOf(str1) + "\n" + str2;
/*     */ 
/*     */           
/* 440 */           if (str2 == null) {
/*     */             
/* 442 */             System.out.println("Could not find an end tag. ");
/* 443 */             bool = false;
/* 444 */             str1 = null;
/* 445 */             this.mBadTags.addElement(str2);
/*     */           } 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 452 */         str1 = String.valueOf(str1) + str2.substring(0, str2.indexOf(paramString));
/* 453 */         bool = false;
/*     */ 
/*     */       
/*     */       }
/* 457 */       catch (Exception exception) {
/*     */         
/* 459 */         if (str2 == null) {
/* 460 */           bool = false;
/*     */         }
/* 462 */         this.mBadTags.addElement(str2);
/* 463 */         System.out.println("Exception Error in VariantGenerationManger.readUntilEndTag() : Can not read line from Template file ");
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 470 */     return str1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateTagContentLoop getContentLoop(String paramString) {
/* 479 */     Hashtable hashtable = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 490 */     if (paramString.indexOf("type=") > 0) {
/*     */       
/* 492 */       int i = paramString.indexOf("type=") + "type=".length() + 1;
/* 493 */       int j = paramString.indexOf("\"", i);
/* 494 */       hashtable.put("type=", paramString.substring(i, j));
/*     */     } 
/*     */ 
/*     */     
/* 498 */     if (paramString.indexOf("typegroup=") > 0) {
/*     */       
/* 500 */       int i = paramString.indexOf("typegroup=") + "typegroup=".length() + 1;
/* 501 */       int j = paramString.indexOf("\"", i);
/* 502 */       hashtable.put("typegroup=", paramString.substring(i, j));
/*     */     } 
/*     */ 
/*     */     
/* 506 */     if (paramString.indexOf("variant=") > 0) {
/*     */       
/* 508 */       int i = paramString.indexOf("variant=") + "variant=".length() + 1;
/* 509 */       int j = paramString.indexOf("\"", i);
/* 510 */       hashtable.put("variant=", paramString.substring(i, j));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 515 */     return new TemplateTagContentLoop(hashtable, this.mContentTypeTable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generate() {
/* 529 */     byte b1 = 0;
/*     */ 
/*     */ 
/*     */     
/* 533 */     if (this.debug)
/*     */     {
/* 535 */       System.out.println("  In VariantGenerationManger.generate() Looping thru instances.............");
/*     */     }
/*     */ 
/*     */     
/* 539 */     for (byte b2 = 0; b2 < this.mInstances.size(); b2++) {
/*     */       
/* 541 */       ContentTypeInstance contentTypeInstance = (ContentTypeInstance)this.mInstances.elementAt(b2);
/*     */ 
/*     */       
/* 544 */       this.mGenerator.getReport().addNewContentItem(this.mVariant, contentTypeInstance);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 549 */       if (contentTypeInstance.isQueuedForDeletion()) {
/*     */ 
/*     */         
/* 552 */         this.mFileManager.deleteContentTypeInstanceFile(contentTypeInstance, this.mVariant);
/*     */ 
/*     */         
/* 555 */         this.mDBRecordManager.deleteContentTypeInstance(contentTypeInstance.getInstanceID());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 562 */       else if (contentTypeInstance.isDisabled()) {
/*     */ 
/*     */ 
/*     */         
/* 566 */         this.mGenerator.getReport().updateLine("No file generated.", "DISABLED");
/*     */ 
/*     */         
/* 569 */         this.mFileManager.deleteContentTypeInstanceFile(contentTypeInstance, this.mVariant);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 582 */       else if (this.mIsGroupSingleton && b1 >= 1) {
/*     */ 
/*     */         
/* 585 */         this.mGenerator.getReport().updateLine("", "Group is a Singleton and has multiple instances enabled for generation.<br>  File not generated for instanceID [" + contentTypeInstance.getInstanceID() + "]");
/*     */         
/* 587 */         System.out.println("  ERROR : Group is a Singleton and has more than one instance enabled for generation.");
/* 588 */         System.out.println("          Instance file not generated for instanceID [" + contentTypeInstance.getInstanceID() + "]");
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 594 */         this.mFileManager.generateContentFiles(contentTypeInstance, this.mVariant, parseTemplateTags(contentTypeInstance, this.mTemplateTags, this.mTemplateString, this.mContentTypeTable));
/*     */         
/* 596 */         b1++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 615 */   public void generateListPage() { this.mFileManager.generateListPageFile(this.mListPage, parseTemplateTags(null, this.mTemplateTags, this.mTemplateString, this.mContentTypeTable)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 623 */   public void deleteListPage() { this.mFileManager.deleteListPageFile(this.mListPage); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteInstanceFiles() {
/* 632 */     for (byte b = 0; b < this.mInstances.size(); b++) {
/*     */       
/* 634 */       ContentTypeInstance contentTypeInstance = (ContentTypeInstance)this.mInstances.elementAt(b);
/* 635 */       this.mFileManager.deleteContentTypeInstanceFile(contentTypeInstance, this.mVariant);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String parseTemplateTags(ContentTypeInstance paramContentTypeInstance, Vector paramVector, String paramString, Hashtable paramHashtable) {
/* 654 */     String str1 = "";
/* 655 */     String str2 = "";
/* 656 */     String str3 = "";
/* 657 */     Hashtable hashtable = new Hashtable();
/*     */ 
/*     */     
/* 660 */     if (this.debug)
/*     */     {
/* 662 */       System.out.println("  VariantGenerationManager.parseTemplateTag() ");
/*     */     }
/*     */ 
/*     */     
/* 666 */     for (byte b = 0; b < paramVector.size(); b++) {
/*     */       
/* 668 */       String str = "[[" + (new Integer(b)).toString() + "]]";
/*     */       
/* 670 */       if (paramString.indexOf(str) != -1) {
/*     */ 
/*     */         
/* 673 */         if (paramVector.elementAt(b) instanceof TemplateTagContentItem) {
/*     */           
/* 675 */           TemplateTagContentItem templateTagContentItem = (TemplateTagContentItem)paramVector.elementAt(b);
/* 676 */           if (templateTagContentItem != null)
/*     */           {
/* 678 */             if (paramContentTypeInstance != null)
/*     */             {
/*     */ 
/*     */               
/* 682 */               hashtable.put("instance", paramContentTypeInstance);
/* 683 */               hashtable.put("groupVariant", this.mVariant);
/* 684 */               hashtable.put("generator", this.mGenerator);
/* 685 */               hashtable.put("contentTypeTable", paramHashtable);
/*     */               
/* 687 */               str1 = templateTagContentItem.render(hashtable);
/*     */             
/*     */             }
/*     */             else
/*     */             {
/* 692 */               str1 = "";
/*     */             
/*     */             }
/*     */           
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 700 */           TemplateTagContentLoop templateTagContentLoop = (TemplateTagContentLoop)paramVector.elementAt(b);
/* 701 */           if (templateTagContentLoop != null)
/*     */           {
/* 703 */             str1 = templateTagContentLoop.render(this.mVariant, this.mGenerator);
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 709 */         StringBuffer stringBuffer = new StringBuffer(paramString);
/* 710 */         int i = paramString.indexOf(str);
/* 711 */         int j = i + str.length();
/*     */         
/* 713 */         if (str1 != null) {
/*     */ 
/*     */           
/* 716 */           if (this.debug)
/*     */           {
/* 718 */             System.out.println("  Replacing string template tag with = " + str2 + str1 + str3);
/*     */           }
/*     */           
/* 721 */           paramString = stringBuffer.replace(i, j, String.valueOf(str2) + str1 + str3).toString();
/* 722 */           str1 = "";
/* 723 */           str2 = "";
/* 724 */           str3 = "";
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 730 */     return paramString;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\VariantGenerationManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */