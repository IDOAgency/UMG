package com.techempower.gemini.fornax;

import com.techempower.ComponentLog;
import com.techempower.gemini.GeminiApplication;
import java.util.Hashtable;
import java.util.Vector;

public class FornaxVariantTypeManager implements FornaxConstants {
  public static final String COMPONENT_CODE = "fMng";
  
  public GeminiApplication application;
  
  public ComponentLog log;
  
  public FornaxSettings fornaxSettings;
  
  protected Vector variantTypes;
  
  public FornaxVariantTypeManager(GeminiApplication paramGeminiApplication) {
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("fMng");
    this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
  }
  
  public String getDescription() { return "Fornax Variant Type Manager"; }
  
  public FornaxVariantType getVariantType(int paramInt) {
    String str = 
      
      "SELECT * FROM fnVariantType WHERE VariantTypeID = " + 
      paramInt;
    Vector vector = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxVariantType", 
        true, 
        this.fornaxSettings);
    if (vector.size() == 1)
      return (FornaxVariantType)vector.get(0); 
    return null;
  }
  
  public Vector getVariantTypes() {
    String str = 
      
      "SELECT * FROM fnVariantType ORDER BY VariantTypeID";
    this.variantTypes = null;
    this.variantTypes = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxVariantType", 
        true, 
        this.fornaxSettings);
    return this.variantTypes;
  }
  
  public Hashtable getVariantTypesHashtable() {
    Hashtable hashtable = new Hashtable();
    Vector vector = getVariantTypes();
    for (byte b = 0; b < vector.size(); b++) {
      FornaxVariantType fornaxVariantType = (FornaxVariantType)vector.elementAt(b);
      hashtable.put(Integer.toString(fornaxVariantType.getID()), fornaxVariantType);
    } 
    return hashtable;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxVariantTypeManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */