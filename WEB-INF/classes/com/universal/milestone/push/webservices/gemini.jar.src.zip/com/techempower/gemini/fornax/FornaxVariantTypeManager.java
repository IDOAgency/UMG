/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.gemini.GeminiApplication;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxVariantTypeManager
/*     */   implements FornaxConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "fMng";
/*     */   public GeminiApplication application;
/*     */   public ComponentLog log;
/*     */   public FornaxSettings fornaxSettings;
/*     */   protected Vector variantTypes;
/*     */   
/*     */   public FornaxVariantTypeManager(GeminiApplication paramGeminiApplication) {
/*  60 */     this.application = paramGeminiApplication;
/*  61 */     this.log = paramGeminiApplication.getLog("fMng");
/*  62 */     this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public String getDescription() { return "Fornax Variant Type Manager"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FornaxVariantType getVariantType(int paramInt) {
/*  80 */     String str = 
/*     */ 
/*     */       
/*  83 */       "SELECT * FROM fnVariantType WHERE VariantTypeID = " + 
/*  84 */       paramInt;
/*     */     
/*  86 */     Vector vector = 
/*  87 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/*  88 */         "com.techempower.gemini.fornax.FornaxVariantType", 
/*  89 */         true, 
/*  90 */         this.fornaxSettings);
/*     */     
/*  92 */     if (vector.size() == 1)
/*     */     {
/*  94 */       return (FornaxVariantType)vector.get(0);
/*     */     }
/*     */ 
/*     */     
/*  98 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getVariantTypes() {
/* 109 */     String str = 
/*     */ 
/*     */       
/* 112 */       "SELECT * FROM fnVariantType ORDER BY VariantTypeID";
/*     */ 
/*     */ 
/*     */     
/* 116 */     this.variantTypes = null;
/* 117 */     this.variantTypes = 
/* 118 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/* 119 */         "com.techempower.gemini.fornax.FornaxVariantType", 
/* 120 */         true, 
/* 121 */         this.fornaxSettings);
/*     */     
/* 123 */     return this.variantTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getVariantTypesHashtable() {
/* 132 */     Hashtable hashtable = new Hashtable();
/*     */ 
/*     */     
/* 135 */     Vector vector = getVariantTypes();
/* 136 */     for (byte b = 0; b < vector.size(); b++) {
/*     */ 
/*     */       
/* 139 */       FornaxVariantType fornaxVariantType = (FornaxVariantType)vector.elementAt(b);
/*     */ 
/*     */       
/* 142 */       hashtable.put(Integer.toString(fornaxVariantType.getID()), fornaxVariantType);
/*     */     } 
/*     */     
/* 145 */     return hashtable;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxVariantTypeManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */