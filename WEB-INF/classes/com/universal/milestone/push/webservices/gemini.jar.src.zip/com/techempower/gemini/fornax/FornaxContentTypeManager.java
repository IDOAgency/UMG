/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.DatabaseConnector;
/*     */ import com.techempower.gemini.Context;
/*     */ import com.techempower.gemini.Form;
/*     */ import com.techempower.gemini.FormDropDownMenu;
/*     */ import com.techempower.gemini.FormHidden;
/*     */ import com.techempower.gemini.GeminiApplication;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxContentTypeManager
/*     */   implements FornaxConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "fMng";
/*     */   public GeminiApplication application;
/*     */   public ComponentLog log;
/*     */   public FornaxSettings fornaxSettings;
/*     */   protected final int PAGE_SIZE = 6;
/*     */   protected Vector contentTypes;
/*     */   
/*     */   public FornaxContentTypeManager(GeminiApplication paramGeminiApplication) {
/*  48 */     this.PAGE_SIZE = 6;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     this.application = paramGeminiApplication;
/*  63 */     this.log = paramGeminiApplication.getLog("fMng");
/*  64 */     this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public String getDescription() { return "Fornax Content Type Manager"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FornaxContentType getContentType(int paramInt) {
/*  81 */     String str = 
/*     */ 
/*     */ 
/*     */       
/*  85 */       "SELECT ContentType.*, ContentTypeInstancesCount.ContentTypeInstancesCount, ContentTypeInstancesGroupsCount.ContentTypeInstancesGroupsCount FROM (SELECT * FROM fnContentType WHERE ContentTypeID = " + 
/*  86 */       paramInt + 
/*  87 */       " )" + 
/*  88 */       " AS [ContentType]" + 
/*  89 */       " INNER JOIN (SELECT ct.ContentTypeID, count(ct.ContentTypeID) as 'ContentTypeInstancesCount'" + 
/*  90 */       " FROM fnContentType ct" + 
/*  91 */       " INNER JOIN fnContentTypeInstance ci" + 
/*  92 */       " ON ci.InstanceContentTypeID = ct.ContentTypeID" + 
/*  93 */       " WHERE ct.ContentTypeID = " + paramInt + 
/*  94 */       " GROUP BY ct.ContentTypeID)" + 
/*  95 */       " AS [ContentTypeInstancesCount]" + 
/*  96 */       " ON ContentType.ContentTypeID = ContentTypeInstancesCount.ContentTypeID" + 
/*  97 */       " INNER JOIN (SELECT ct.ContentTypeID, count(ct.ContentTypeID) as 'ContentTypeInstancesGroupsCount'" + 
/*  98 */       " FROM fnContentType ct" + 
/*  99 */       " INNER JOIN fnContentTypeInstancesGroup ctg" + 
/* 100 */       " ON ctg.InstancesGroupContentTypeID = ct.ContentTypeID" + 
/* 101 */       " WHERE ct.ContentTypeID = " + paramInt + 
/* 102 */       " GROUP BY ct.ContentTypeID)" + 
/* 103 */       " AS [ContentTypeInstancesGroupsCount]" + 
/* 104 */       " ON ContentType.ContentTypeID = ContentTypeInstancesGroupsCount.ContentTypeID";
/*     */     
/* 106 */     Vector vector = 
/* 107 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/* 108 */         "com.techempower.gemini.fornax.FornaxContentType", 
/* 109 */         true, 
/* 110 */         this.fornaxSettings);
/*     */     
/* 112 */     if (vector.size() == 1)
/*     */     {
/* 114 */       return (FornaxContentType)vector.get(0);
/*     */     }
/*     */ 
/*     */     
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getContentTypes() {
/* 128 */     this.contentTypes = 
/* 129 */       getContentTypes(1, 0, 0);
/*     */     
/* 131 */     return this.contentTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getContentTypes(int paramInt1, int paramInt2) {
/* 140 */     this.contentTypes = 
/* 141 */       getContentTypes(1, paramInt1, paramInt2);
/*     */     
/* 143 */     return this.contentTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getContentTypes(int paramInt1, int paramInt2, int paramInt3) {
/* 152 */     String str = 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 171 */       "SELECT ContentType.*, ContentTypeInstancesCount.ContentTypeInstancesCount, ContentTypeInstancesGroupsCount.ContentTypeInstancesGroupsCount FROM (SELECT * FROM fnContentType ) AS [ContentType] INNER JOIN (SELECT ct.ContentTypeID, count(ct.ContentTypeID) as 'ContentTypeInstancesCount' FROM fnContentType ct INNER JOIN fnContentTypeInstance ci ON ci.InstanceContentTypeID = ct.ContentTypeID GROUP BY ct.ContentTypeID) AS [ContentTypeInstancesCount] ON ContentType.ContentTypeID = ContentTypeInstancesCount.ContentTypeID INNER JOIN (SELECT ct.ContentTypeID, count(ct.ContentTypeID) as 'ContentTypeInstancesGroupsCount' FROM fnContentType ct INNER JOIN fnContentTypeInstancesGroup ctg ON ctg.InstancesGroupContentTypeID = ct.ContentTypeID GROUP BY ct.ContentTypeID) AS [ContentTypeInstancesGroupsCount] ON ContentType.ContentTypeID = ContentTypeInstancesGroupsCount.ContentTypeID";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     switch (paramInt2) {
/*     */       
/*     */       case 0:
/* 179 */         str = String.valueOf(str) + " ORDER BY ContentType.ContentTypeID"; break;
/*     */       case 1:
/* 181 */         str = String.valueOf(str) + " ORDER BY ContentType.ContentTypeName"; break;
/*     */       case 2:
/* 183 */         str = String.valueOf(str) + " ORDER BY ContentTypeInstancesCount.ContentTypeInstancesCount"; break;
/*     */       default:
/* 185 */         str = String.valueOf(str) + " ORDER BY ContentType.ContentTypeID";
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 190 */     switch (paramInt3) {
/*     */       
/*     */       case 0:
/* 193 */         str = String.valueOf(str) + " ASC"; break;
/*     */       case 1:
/* 195 */         str = String.valueOf(str) + " DESC"; break;
/*     */       default:
/* 197 */         str = String.valueOf(str) + " ASC";
/*     */         break;
/*     */     } 
/*     */     
/* 201 */     this.contentTypes = null;
/* 202 */     this.contentTypes = 
/* 203 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/* 204 */         "com.techempower.gemini.fornax.FornaxContentType", 
/* 205 */         true, 
/* 206 */         this.fornaxSettings);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 218 */     if (paramInt1 != 0) {
/*     */       
/* 220 */       Vector vector = 
/* 221 */         this.fornaxSettings.getFornaxHelper().getPageOfVectorObjects(this.contentTypes, paramInt1, 6);
/*     */       
/* 223 */       this.log.debug("returning partial page...");
/*     */       
/* 225 */       return vector;
/*     */     } 
/*     */ 
/*     */     
/* 229 */     this.log.debug("returning full page...");
/*     */     
/* 231 */     if (this.contentTypes == null)
/*     */     {
/* 233 */       this.log.debug("vector is NULL");
/*     */     }
/*     */     
/* 236 */     return this.contentTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPageCount() {
/* 248 */     if (this.contentTypes != null)
/*     */     {
/* 250 */       return (int)Math.ceil((this.contentTypes.size() / 6.0F));
/*     */     }
/* 252 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateContentTypeListPageFlag(Context paramContext, Form paramForm, Vector paramVector) {
/* 261 */     String str = "F";
/*     */ 
/*     */     
/* 264 */     for (byte b = 0; b < paramVector.size(); b++) {
/*     */       
/* 266 */       FornaxContentType fornaxContentType = (FornaxContentType)paramVector.elementAt(b);
/*     */ 
/*     */       
/* 269 */       if (this.fornaxSettings.isMultiGroup()) {
/*     */         
/* 271 */         FormDropDownMenu formDropDownMenu = (FormDropDownMenu)paramForm.getElement("content-type-listPage-generate-" + Integer.toString(fornaxContentType.getID()));
/*     */         
/* 273 */         if (formDropDownMenu != null)
/*     */         {
/* 275 */           str = formDropDownMenu.getStringValue();
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 280 */         FormHidden formHidden = (FormHidden)paramForm.getElement("content-type-listPage-generate-" + Integer.toString(fornaxContentType.getID()));
/* 281 */         if (formHidden != null)
/*     */         {
/* 283 */           str = formHidden.getStringValue();
/*     */         }
/*     */       } 
/*     */       
/* 287 */       fornaxContentType.setIsListPageGenerated(str);
/* 288 */       fornaxContentType.runUpdate(this.fornaxSettings.getConnector(""));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getDefaultInstancesGroupID(int paramInt, DatabaseConnector paramDatabaseConnector) {
/* 310 */     int i = -1;
/*     */     
/* 312 */     String str = 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 318 */       "SELECT ctig.InstancesGroupID FROM fnContentType ct INNER JOIN fnContentTypeInstancesGroup ctig ON ct.ContentTypeID = ctig.InstancesGroupContentTypeID WHERE lower(ct.ContentTypeName) = lower(ctig.InstancesGroupName) AND ct.ContentTypeID = " + 
/* 319 */       paramInt;
/*     */     
/* 321 */     paramDatabaseConnector.setQuery(str);
/* 322 */     paramDatabaseConnector.runQuery();
/* 323 */     if (paramDatabaseConnector.more()) {
/*     */       
/* 325 */       paramDatabaseConnector.first();
/* 326 */       i = paramDatabaseConnector.getInt("InstancesGroupID", -1);
/*     */     } 
/* 328 */     paramDatabaseConnector.close();
/*     */ 
/*     */ 
/*     */     
/* 332 */     return i;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */