/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.EnhancedProperties;
/*     */ import com.techempower.Version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BugTool
/*     */   implements GeminiConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "bugt";
/*     */   public static final String DEFAULT_BUG_URL = "http://tiamat.techempower.com/bugtool/bugreport.asp?";
/*     */   public static final String DEFAULT_COMMENT_URL = "http://tiamat.techempower.com:8012/submit-comment.jsp?";
/*     */   public static final String DEFAULT_FIELD_VALUE = "unknown";
/*     */   protected boolean bugToolEnabled;
/*     */   protected boolean commentToolEnabled;
/*     */   protected String bugReportURL;
/*     */   protected String bugReportProgram;
/*     */   protected String bugReportSection;
/*     */   protected boolean bugToolAdminOnly;
/*     */   protected String commentURL;
/*     */   protected String commentVersion;
/*     */   protected ComponentLog log;
/*     */   
/*     */   public BugTool(GeminiApplication paramGeminiApplication) {
/*  42 */     this.bugToolEnabled = false;
/*  43 */     this.commentToolEnabled = false;
/*  44 */     this.bugReportURL = "http://tiamat.techempower.com/bugtool/bugreport.asp?";
/*  45 */     this.bugReportProgram = "unknown";
/*  46 */     this.bugReportSection = "unknown";
/*  47 */     this.bugToolAdminOnly = false;
/*  48 */     this.commentURL = "http://tiamat.techempower.com:8012/submit-comment.jsp?";
/*  49 */     this.commentVersion = "unknown";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     this.log = paramGeminiApplication.getLog("bugt");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(EnhancedProperties paramEnhancedProperties, Version paramVersion) {
/*  73 */     this.bugReportProgram = paramVersion.getProductName();
/*  74 */     this.bugReportSection = "v" + paramVersion.getVersionString();
/*  75 */     this.commentVersion = "v" + paramVersion.getVersionString();
/*     */     
/*  77 */     this.bugToolEnabled = paramEnhancedProperties.getYesNoProperty("BugToolEnabled", this.bugToolEnabled);
/*  78 */     this.bugReportURL = paramEnhancedProperties.getProperty("BugToolURLPrefix", this.bugReportURL);
/*  79 */     this.bugToolAdminOnly = paramEnhancedProperties.getYesNoProperty("BugToolAdminOnly", this.bugToolAdminOnly);
/*  80 */     this.commentToolEnabled = paramEnhancedProperties.getYesNoProperty("CommentToolEnabled", this.commentToolEnabled);
/*  81 */     this.commentURL = paramEnhancedProperties.getProperty("CommentToolURLPrefix", this.commentURL);
/*     */     
/*  83 */     if (this.bugToolEnabled) {
/*     */       
/*  85 */       if (this.bugToolAdminOnly) {
/*  86 */         this.log.debug("Bug tool enabled only for administrators.");
/*     */       } else {
/*  88 */         this.log.debug("Bug tool enabled.");
/*     */       } 
/*     */     } else {
/*  91 */       this.log.debug("Bug tool not enabled.");
/*     */     } 
/*  93 */     if (this.commentToolEnabled) {
/*  94 */       this.log.debug("Comment tool enabled.");
/*     */     } else {
/*  96 */       this.log.debug("Comment tool not enabled.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public boolean isEnabled() { return isBugEnabled(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public boolean isBugEnabled() { return this.bugToolEnabled; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public boolean isCommentEnabled() { return this.commentToolEnabled; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBugReportLink(Context paramContext) {
/* 131 */     StringBuffer stringBuffer = new StringBuffer(getBugReportAnchor(paramContext, "<b>Report bug</b>"));
/* 132 */     String str = getCommentAnchor(paramContext, "<b>Submit comment</b>");
/*     */     
/* 134 */     if (str.length() > 0 && stringBuffer.length() > 0) {
/*     */       
/* 136 */       stringBuffer.append(" | ");
/* 137 */       stringBuffer.append(str);
/*     */     } 
/*     */     
/* 140 */     if (stringBuffer.length() > 0) {
/*     */       
/* 142 */       stringBuffer.insert(0, "<br><br><p><font face=\"Arial, Helvetica\" size=1>[ ");
/* 143 */       stringBuffer.append(" ]</font></p>");
/*     */     } 
/*     */     
/* 146 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBugReportAnchor(Context paramContext, String paramString) {
/* 159 */     StringBuffer stringBuffer = new StringBuffer(80);
/*     */ 
/*     */     
/* 162 */     if (this.bugToolEnabled) {
/*     */       
/* 164 */       String str = paramContext.getReferencedJSP();
/*     */       
/* 166 */       stringBuffer.append("<a href=\"");
/* 167 */       stringBuffer.append(this.bugReportURL);
/* 168 */       stringBuffer.append("Program=");
/* 169 */       stringBuffer.append(this.bugReportProgram.replace(' ', '+'));
/* 170 */       stringBuffer.append("&Section=");
/* 171 */       stringBuffer.append(this.bugReportSection.replace(' ', '+'));
/* 172 */       stringBuffer.append("&Screen=");
/* 173 */       stringBuffer.append(str);
/* 174 */       stringBuffer.append("&UserName=");
/* 175 */       stringBuffer.append(paramContext.getClientIP());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 180 */       stringBuffer.append("\" target=\"bugreportwindow\">");
/* 181 */       stringBuffer.append(paramString);
/* 182 */       stringBuffer.append("</a>");
/*     */     } 
/*     */     
/* 185 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCommentAnchor(Context paramContext, String paramString) {
/* 198 */     StringBuffer stringBuffer = new StringBuffer(80);
/*     */ 
/*     */     
/* 201 */     if (this.commentToolEnabled) {
/*     */       
/* 203 */       String str = paramContext.getReferencedJSP();
/*     */       
/* 205 */       stringBuffer.append("<a href=\"");
/* 206 */       stringBuffer.append(this.commentURL);
/* 207 */       stringBuffer.append("Screen=");
/* 208 */       stringBuffer.append(str);
/* 209 */       stringBuffer.append("&Version=");
/* 210 */       stringBuffer.append(this.commentVersion);
/* 211 */       stringBuffer.append("&Username=");
/* 212 */       stringBuffer.append(paramContext.getClientIP());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 217 */       stringBuffer.append("\" target=\"commentwindow\">");
/* 218 */       stringBuffer.append(paramString);
/* 219 */       stringBuffer.append("</a></b>");
/*     */     } 
/*     */     
/* 222 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\BugTool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */