/*      */ package com.techempower;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileWriter;
/*      */ import java.io.IOException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.text.DateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JdbcConnector
/*      */   implements DatabaseConnector
/*      */ {
/*      */   public static final String COMPONENT_CODE = "jdbc";
/*      */   public static final boolean DEBUG_ALSO_CONSOLE = true;
/*      */   public static final int DEBUG_HIGH = 3;
/*      */   public static final int DEBUG_MEDIUM = 2;
/*      */   public static final int DEBUG_LOW = 1;
/*      */   public static final long EXCESSIVE_FILE_SIZE = 2000000L;
/*      */   public static final String DEFAULT_DEBUG_FILE = "c:\\temp\\JdbcConnector-debug.txt";
/*      */   public static final String NULL_VALUE_REPLACE = "[none]";
/*      */   protected static final String DEFAULT_DRIVER_NAME = "sun.jdbc.odbc.JdbcOdbcDriver";
/*      */   protected static final String DEFAULT_JDBC_PREFIX = "jdbc:odbc:";
/*  102 */   protected static int debugLevel = 3;
/*  103 */   protected static Vector loadedDrivers = new Vector();
/*  104 */   protected static String defJdbcURLPrefix = "jdbc:odbc:";
/*  105 */   protected static Object lockObject = new Object();
/*      */   protected static boolean initialized = false;
/*  107 */   protected static long queryNumber = 0L;
/*  108 */   protected static String debugFilename = "c:\\temp\\JdbcConnector-debug.txt";
/*  109 */   protected static Hashtable dbConnections = new Hashtable(); private String username; private String password;
/*  110 */   protected static DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 2);
/*      */   
/*      */   protected int updateRowCount;
/*      */   protected String jdbcURLPrefix;
/*      */   
/*      */   public JdbcConnector(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2) {
/*  116 */     this.username = null;
/*  117 */     this.password = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  122 */     this.updateRowCount = -1;
/*  123 */     this.jdbcURLPrefix = defJdbcURLPrefix;
/*  124 */     this.driverInUse = null;
/*  125 */     this.forceNewConnection = false;
/*  126 */     this.forcedConnection = null;
/*  127 */     this.statement = null;
/*  128 */     this.resultSet = null;
/*  129 */     this.nextThrewException = true;
/*  130 */     this.readOnly = true;
/*  131 */     this.forwardOnly = false;
/*  132 */     this.query = null;
/*  133 */     this.connectString = null;
/*  134 */     this.rowCount = -1;
/*  135 */     this.rowNumber = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  157 */     debugFile("Constructor starting.");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  163 */     debugFile("Database connect string: " + paramString2);
/*  164 */     debugFile("JDBC prefix: " + paramString1);
/*  165 */     debugFile("Query: " + paramString3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  171 */     setReadOnly(paramBoolean1);
/*  172 */     setForwardOnly(paramBoolean2);
/*  173 */     setJdbcURLPrefix(paramString1);
/*      */     
/*  175 */     this.connectString = paramString2;
/*  176 */     this.query = paramString3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  184 */     if (!initialized)
/*      */     {
/*  186 */       synchronized (lockObject) {
/*      */         
/*  188 */         loadDriver("sun.jdbc.odbc.JdbcOdbcDriver", "jdbc:odbc:", false, false);
/*      */       } 
/*      */     }
/*      */     
/*  192 */     debugFile("Constructor finished.");
/*      */   }
/*      */   protected JdbcDriver driverInUse;
/*      */   protected boolean forceNewConnection;
/*      */   protected Connection forcedConnection;
/*      */   protected Statement statement;
/*      */   protected ResultSet resultSet;
/*      */   protected boolean nextThrewException;
/*      */   protected boolean readOnly;
/*      */   protected boolean forwardOnly;
/*      */   protected String query;
/*      */   protected String connectString;
/*      */   protected int rowCount;
/*      */   protected int rowNumber;
/*      */   
/*  207 */   public JdbcConnector(String paramString1, String paramString2, String paramString3) { this(paramString1, paramString2, paramString3, true, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  225 */   public JdbcConnector(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2) { this(defJdbcURLPrefix, paramString1, paramString2, paramBoolean1, paramBoolean2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  238 */   public JdbcConnector(String paramString1, String paramString2) { this(defJdbcURLPrefix, paramString1, paramString2, true, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  249 */   public JdbcConnector(String paramString) { this(defJdbcURLPrefix, paramString, "", true, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  261 */   public void finalize() { close(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  271 */   public void setUsername(String paramString) { this.username = paramString; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  281 */   public void setPassword(String paramString) { this.password = paramString; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setQuery(String paramString) {
/*  292 */     debugFile("setQuery: " + paramString);
/*      */ 
/*      */     
/*  295 */     close();
/*      */ 
/*      */     
/*  298 */     this.query = paramString;
/*      */ 
/*      */     
/*  301 */     this.nextThrewException = true;
/*      */ 
/*      */     
/*  304 */     if (!this.driverInUse.supportsGetRow) {
/*  305 */       this.rowNumber = 0;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  313 */   public String getQuery() { return this.query; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  330 */   public void setReadOnly(boolean paramBoolean) { this.readOnly = paramBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  338 */   public boolean getReadOnly() { return this.readOnly; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  352 */   public void setForceNewConnection(boolean paramBoolean) { this.forceNewConnection = paramBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  360 */   public boolean getForceNewConnection() { return this.forceNewConnection; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  376 */   public void setForwardOnly(boolean paramBoolean) { this.forwardOnly = paramBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  384 */   public boolean getForwardOnly() { return this.forwardOnly; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void first() {
/*  396 */     if (this.forwardOnly) {
/*      */       
/*  398 */       debugFile("call to first on a forward-only query.");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*      */     try {
/*  404 */       this.nextThrewException = this.resultSet.first() ^ true;
/*  405 */       if (!this.driverInUse.supportsGetRow) {
/*  406 */         this.rowNumber = 1;
/*      */       }
/*  408 */     } catch (Exception exception) {
/*      */       
/*  410 */       debugFile("Exception on first(): " + exception, 2);
/*  411 */       this.nextThrewException = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void next() {
/*      */     try {
/*  422 */       this.nextThrewException = this.resultSet.next() ^ true;
/*  423 */       if (!this.driverInUse.supportsGetRow) {
/*  424 */         this.rowNumber++;
/*      */       }
/*  426 */     } catch (Exception exception) {
/*      */       
/*  428 */       this.nextThrewException = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  439 */   public boolean more() { return this.nextThrewException ^ true; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveAbsolute(int paramInt) {
/*  449 */     if (this.forwardOnly) {
/*      */       
/*  451 */       debugFile("call to moveAbsolute on a forward-only query.");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*      */     try {
/*  457 */       if (this.driverInUse.supportsAbsolute)
/*      */       {
/*      */         
/*  460 */         this.resultSet.absolute(paramInt + 1);
/*  461 */         if (!this.driverInUse.supportsGetRow) {
/*  462 */           this.rowNumber = paramInt + 1;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  467 */         first();
/*  468 */         while (getRowNumber() < paramInt + 1 && more())
/*      */         {
/*  470 */           next();
/*      */         }
/*      */       }
/*      */     
/*  474 */     } catch (Exception exception) {
/*      */       
/*  476 */       debugFile("Exception while moving to absolute position " + paramInt + ": " + exception, 2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRowNumber() {
/*      */     try {
/*  488 */       if (this.driverInUse.supportsGetRow) {
/*  489 */         return this.resultSet.getRow();
/*      */       }
/*  491 */       return this.rowNumber;
/*      */     }
/*  493 */     catch (Exception exception) {
/*      */       
/*  495 */       debugFile("Exception while getting row number: " + exception, 2);
/*      */ 
/*      */       
/*  498 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getFieldNames() {
/*      */     try {
/*  508 */       ResultSetMetaData resultSetMetaData = this.resultSet.getMetaData();
/*  509 */       int i = resultSetMetaData.getColumnCount();
/*      */ 
/*      */       
/*  512 */       String[] arrayOfString = new String[i];
/*  513 */       for (byte b = 1; b < i + 1; b++)
/*      */       {
/*  515 */         arrayOfString[b - true] = resultSetMetaData.getColumnName(b);
/*      */       }
/*      */       
/*  518 */       return arrayOfString;
/*      */     }
/*  520 */     catch (Exception exception) {
/*      */       
/*  522 */       debugFile("Exception while gathering field names: " + exception, 2);
/*      */       
/*  524 */       return new String[0];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getFieldTypes() {
/*      */     try {
/*  534 */       ResultSetMetaData resultSetMetaData = this.resultSet.getMetaData();
/*  535 */       int i = resultSetMetaData.getColumnCount();
/*      */ 
/*      */       
/*  538 */       int[] arrayOfInt = new int[i];
/*  539 */       for (byte b = 1; b < i + 1; b++)
/*      */       {
/*  541 */         arrayOfInt[b - true] = resultSetMetaData.getColumnType(b);
/*      */       }
/*      */       
/*  544 */       return arrayOfInt;
/*      */     }
/*  546 */     catch (Exception exception) {
/*      */       
/*  548 */       debugFile("Exception while gathering field names: " + exception, 2);
/*      */       
/*  550 */       return new int[0];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFieldByName(String paramString) {
/*      */     try {
/*  562 */       return this.resultSet.getString(paramString);
/*      */     }
/*  564 */     catch (Exception exception) {
/*      */       
/*  566 */       debugFile("Exception while retrieving field " + paramString + ": " + exception, 2);
/*  567 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getField(String paramString) {
/*  579 */     String str = getFieldByName(paramString);
/*  580 */     if (str != null) {
/*  581 */       return str;
/*      */     }
/*  583 */     return "[none]";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getField(String paramString1, String paramString2) {
/*  595 */     String str = getFieldByName(paramString1);
/*  596 */     if (str != null) {
/*  597 */       return str;
/*      */     }
/*  599 */     return paramString2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getIntegerFieldByName(String paramString) {
/*      */     try {
/*  612 */       return this.resultSet.getInt(paramString);
/*      */     }
/*  614 */     catch (Exception exception) {
/*      */       
/*  616 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  628 */   public int getIntegerField(String paramString) { return getIntegerFieldByName(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  639 */   public int getInt(String paramString) { return getIntegerFieldByName(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String paramString, int paramInt) {
/*      */     try {
/*  652 */       return this.resultSet.getInt(paramString);
/*      */     }
/*  654 */     catch (Exception exception) {
/*      */       
/*  656 */       return paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString) {
/*      */     try {
/*  670 */       return this.resultSet.getDate(paramString);
/*      */     }
/*  672 */     catch (Exception exception) {
/*      */       
/*  674 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String paramString) {
/*      */     try {
/*  688 */       return this.resultSet.getBoolean(paramString);
/*      */     }
/*  690 */     catch (Exception exception) {
/*      */       
/*  692 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String paramString) {
/*      */     try {
/*  706 */       return this.resultSet.getFloat(paramString);
/*      */     }
/*  708 */     catch (Exception exception) {
/*      */       
/*  710 */       return 0.0F;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String paramString) {
/*      */     try {
/*  724 */       return this.resultSet.getDouble(paramString);
/*      */     }
/*  726 */     catch (Exception exception) {
/*      */       
/*  728 */       return 0.0D;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(String paramString) {
/*      */     try {
/*  742 */       return this.resultSet.getByte(paramString);
/*      */     }
/*  744 */     catch (Exception exception) {
/*      */       
/*  746 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(String paramString) {
/*      */     try {
/*  760 */       return this.resultSet.getShort(paramString);
/*      */     }
/*  762 */     catch (Exception exception) {
/*      */       
/*  764 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String paramString) {
/*      */     try {
/*  778 */       return this.resultSet.getLong(paramString);
/*      */     }
/*  780 */     catch (Exception exception) {
/*      */       
/*  782 */       return 0L;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRowCount() {
/*  796 */     if (this.resultSet != null) {
/*      */ 
/*      */       
/*  799 */       if (this.rowCount > -1) {
/*  800 */         return this.rowCount;
/*      */       }
/*  802 */       this.rowCount = 0;
/*      */ 
/*      */       
/*  805 */       first();
/*  806 */       while (more()) {
/*      */         
/*  808 */         this.rowCount++;
/*  809 */         next();
/*      */       } 
/*  811 */       first();
/*      */       
/*  813 */       return this.rowCount;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  818 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() {
/*  828 */     if (this.resultSet != null) {
/*      */ 
/*      */       
/*      */       try {
/*  832 */         this.resultSet.close();
/*      */       }
/*  834 */       catch (Exception exception) {
/*      */         
/*  836 */         debugFile("Exception while closing result set: " + exception, 2);
/*      */       } 
/*  838 */       this.resultSet = null;
/*      */     } 
/*      */ 
/*      */     
/*  842 */     if (this.statement != null) {
/*      */ 
/*      */       
/*      */       try {
/*  846 */         this.statement.close();
/*      */       }
/*  848 */       catch (Exception exception) {
/*      */         
/*  850 */         debugFile("Exception while closing statement: " + exception, 2);
/*      */       } 
/*  852 */       this.statement = null;
/*      */     } 
/*      */ 
/*      */     
/*  856 */     if (this.forcedConnection != null) {
/*      */ 
/*      */       
/*      */       try {
/*  860 */         this.forcedConnection.close();
/*      */       }
/*  862 */       catch (Exception exception) {
/*      */         
/*  864 */         debugFile("Exception while closing forced connection: " + exception, 2);
/*      */       } 
/*  866 */       this.forcedConnection = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  879 */   public void runQuery() { runQuery(false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int runUpdateQuery() {
/*  891 */     close();
/*      */ 
/*      */     
/*  894 */     queryNumber++;
/*      */ 
/*      */     
/*  897 */     this.rowCount = -1;
/*      */ 
/*      */     
/*  900 */     JdbcConnectionProfile jdbcConnectionProfile = getDbConnection(this.connectString, this.username, this.password);
/*      */     
/*  902 */     if (jdbcConnectionProfile != null) {
/*      */ 
/*      */ 
/*      */       
/*  906 */       if (this.forceNewConnection)
/*      */       {
/*  908 */         this.forcedConnection = jdbcConnectionProfile.connection;
/*      */       }
/*      */ 
/*      */       
/*  912 */       jdbcConnectionProfile.incrementLoad();
/*      */       
/*  914 */       debugFile("Creating the statement.");
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  919 */         this.statement = jdbcConnectionProfile.connection.createStatement();
/*  920 */         debugFile("Statement created.");
/*  921 */         this.updateRowCount = doUpdate(this.statement);
/*      */         
/*  923 */         jdbcConnectionProfile.close();
/*      */       }
/*  925 */       catch (SQLException sQLException) {
/*      */         
/*  927 */         debugFile("SQL Exception while creating statement or running query: " + sQLException, 2);
/*  928 */         return -1;
/*      */       } 
/*      */ 
/*      */       
/*  932 */       jdbcConnectionProfile.decrementLoad();
/*      */     }
/*      */     else {
/*      */       
/*  936 */       debugFile("No valid connection available, aborting query.", 3);
/*      */     } 
/*  938 */     debugFile("Returning from runQuery.");
/*  939 */     return this.updateRowCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doUpdate(Statement paramStatement) {
/*      */     try {
/*  949 */       paramStatement.execute(this.query);
/*  950 */       return paramStatement.getUpdateCount();
/*      */     }
/*  952 */     catch (SQLException sQLException) {
/*      */       
/*  954 */       debugFile("SQLException in doUpdate: " + sQLException);
/*  955 */       return -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  965 */   public void runQuerySafe() { runQuery(true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void runQuery(boolean paramBoolean) {
/*  981 */     close();
/*      */ 
/*      */     
/*  984 */     queryNumber++;
/*      */ 
/*      */     
/*  987 */     this.rowCount = -1;
/*      */ 
/*      */     
/*  990 */     JdbcConnectionProfile jdbcConnectionProfile = getDbConnection(this.connectString, this.username, this.password);
/*      */     
/*  992 */     if (jdbcConnectionProfile != null) {
/*      */ 
/*      */ 
/*      */       
/*  996 */       if (this.forceNewConnection)
/*      */       {
/*  998 */         this.forcedConnection = jdbcConnectionProfile.connection;
/*      */       }
/*      */ 
/*      */       
/* 1002 */       jdbcConnectionProfile.incrementLoad();
/*      */ 
/*      */       
/* 1005 */       if (paramBoolean) {
/*      */ 
/*      */         
/*      */         try {
/*      */           
/* 1010 */           generateStatement(jdbcConnectionProfile);
/*      */         }
/* 1012 */         catch (SQLException sQLException) {
/*      */           
/* 1014 */           debugFile("SQL Exception while creating statement: " + sQLException, 3);
/*      */ 
/*      */           
/* 1017 */           jdbcConnectionProfile.close();
/*      */           
/* 1019 */           throw new JdbcConnectorError("Creation of statement failed.", sQLException);
/*      */         } 
/*      */ 
/*      */         
/*      */         try {
/* 1024 */           generateResults(this.statement);
/*      */         }
/* 1026 */         catch (SQLException sQLException) {
/*      */ 
/*      */           
/* 1029 */           jdbcConnectionProfile.decrementLoad();
/*      */           
/* 1031 */           debugFile("SQL Exception while running query: " + sQLException, 3);
/* 1032 */           throw new JdbcConnectorError("runQuery failed.", sQLException);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1039 */         boolean bool = false;
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1044 */           generateStatement(jdbcConnectionProfile);
/*      */         }
/* 1046 */         catch (SQLException sQLException) {
/*      */ 
/*      */           
/* 1049 */           jdbcConnectionProfile.close();
/*      */           
/* 1051 */           debugFile("SQL Exception while creating statement: " + sQLException, 3);
/*      */           
/* 1053 */           bool = true;
/*      */         } 
/*      */         
/* 1056 */         if (!bool) {
/*      */           
/*      */           try {
/*      */ 
/*      */             
/* 1061 */             generateResults(this.statement);
/*      */           }
/* 1063 */           catch (SQLException sQLException) {
/*      */ 
/*      */             
/* 1066 */             jdbcConnectionProfile.decrementLoad();
/*      */ 
/*      */ 
/*      */             
/* 1070 */             if (sQLException.toString().indexOf("onnection reset by peer") >= 0) {
/*      */ 
/*      */               
/* 1073 */               jdbcConnectionProfile.close();
/*      */               
/* 1075 */               debugFile("SQL Exception while running query: " + sQLException, 3);
/*      */             } else {
/*      */               
/* 1078 */               debugFile("SQL Exception while running query: " + sQLException, 2);
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } else {
/*      */       
/* 1085 */       debugFile("No valid connection available, aborting query.", 3);
/*      */     } 
/*      */     
/* 1088 */     debugFile("Returning from runQuery.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJdbcURLPrefix(String paramString) {
/* 1099 */     this.jdbcURLPrefix = paramString;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1105 */     this.driverInUse = null;
/*      */ 
/*      */     
/* 1108 */     for (byte b = 0; b < loadedDrivers.size(); b++) {
/*      */ 
/*      */       
/* 1111 */       JdbcDriver jdbcDriver = (JdbcDriver)loadedDrivers.elementAt(b);
/* 1112 */       String str = jdbcDriver.urlPrefix;
/*      */ 
/*      */       
/* 1115 */       if (str.equals(this.jdbcURLPrefix)) {
/*      */         
/* 1117 */         this.driverInUse = jdbcDriver;
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1126 */     if (this.driverInUse == null)
/*      */     {
/* 1128 */       debugFile("No suitable driver found for prefix: " + this.jdbcURLPrefix + "!");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1137 */   public String getJdbcURLPrefix() { return this.jdbcURLPrefix; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateStatement(JdbcConnectionProfile paramJdbcConnectionProfile) throws SQLException {
/*      */     try {
/* 1152 */       debugFile("Creating the statement.");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1158 */       if (this.driverInUse.jdbc1)
/*      */       {
/*      */         
/* 1161 */         this.statement = paramJdbcConnectionProfile.connection.createStatement();
/* 1162 */         debugFile("Statement created.");
/*      */ 
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*      */         
/* 1169 */         char c1 = 'Ϭ';
/* 1170 */         char c2 = 'ϯ';
/*      */ 
/*      */         
/* 1173 */         if (this.forwardOnly)
/* 1174 */           c1 = 'ϫ'; 
/* 1175 */         if (!this.readOnly) {
/* 1176 */           c2 = 'ϰ';
/*      */         }
/*      */         
/* 1179 */         this.statement = paramJdbcConnectionProfile.connection.createStatement(c1, 
/* 1180 */             c2);
/*      */       }
/*      */     
/* 1183 */     } catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1188 */       this.nextThrewException = true;
/* 1189 */       this.resultSet = null;
/*      */       
/* 1191 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateResults(Statement paramStatement) throws SQLException {
/*      */     try {
/* 1203 */       this.resultSet = paramStatement.executeQuery(this.query);
/* 1204 */       debugFile("Results generated.");
/*      */       
/* 1206 */       next();
/*      */     }
/* 1208 */     catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1213 */       this.nextThrewException = true;
/* 1214 */       this.resultSet = null;
/*      */ 
/*      */       
/* 1217 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JdbcConnectionProfile getDbConnection(String paramString1, String paramString2, String paramString3) {
/* 1228 */     JdbcConnectionProfile jdbcConnectionProfile = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1233 */     if (this.forceNewConnection) {
/*      */       
/* 1235 */       jdbcConnectionProfile = new JdbcConnectionProfile(this);
/* 1236 */       jdbcConnectionProfile.establishDbConnection(paramString1, paramString2, paramString3);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 1245 */       String str = String.valueOf(paramString2) + "/" + paramString3 + "/" + paramString1;
/*      */ 
/*      */       
/* 1248 */       JdbcConnectionManager jdbcConnectionManager = (JdbcConnectionManager)dbConnections.get(str);
/*      */       
/* 1250 */       synchronized (lockObject) {
/*      */         
/* 1252 */         if (jdbcConnectionManager == null) {
/*      */ 
/*      */           
/* 1255 */           jdbcConnectionManager = new JdbcConnectionManager(this);
/* 1256 */           dbConnections.put(str, jdbcConnectionManager);
/*      */         } 
/*      */         
/* 1259 */         if (jdbcConnectionManager.size() < this.driverInUse.pooling) {
/*      */           
/* 1261 */           JdbcConnectionProfile jdbcConnectionProfile1 = new JdbcConnectionProfile(this);
/* 1262 */           jdbcConnectionProfile1.establishDbConnection(paramString1, paramString2, paramString3);
/*      */ 
/*      */           
/* 1265 */           if (jdbcConnectionProfile1.getConnection() != null)
/*      */           {
/* 1267 */             jdbcConnectionProfile = jdbcConnectionProfile1;
/*      */ 
/*      */             
/* 1270 */             jdbcConnectionManager.add(jdbcConnectionProfile1);
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1278 */           jdbcConnectionProfile = jdbcConnectionManager.getLowestLoad();
/*      */ 
/*      */ 
/*      */           
/* 1282 */           if (jdbcConnectionProfile != null && jdbcConnectionProfile.isClosed()) {
/*      */ 
/*      */             
/* 1285 */             jdbcConnectionProfile.establishDbConnection(paramString1, paramString2, paramString3);
/*      */ 
/*      */             
/* 1288 */             if (jdbcConnectionProfile.getConnection() == null) {
/* 1289 */               jdbcConnectionProfile = null;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1296 */     return jdbcConnectionProfile;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Connection establishDbConnection(String paramString1, String paramString2, String paramString3) {
/*      */     try {
/* 1310 */       String str = String.valueOf(this.jdbcURLPrefix) + paramString1;
/* 1311 */       debugFile("establishDbConnection(" + str + ", " + paramString2 + ", " + paramString3 + ")");
/* 1312 */       return DriverManager.getConnection(str, paramString2, paramString3);
/*      */     }
/* 1314 */     catch (SQLException sQLException) {
/*      */       
/* 1316 */       debugFile("SQL Exception while connecting: " + sQLException, 3);
/* 1317 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void loadDriver(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt) {
/* 1342 */     for (byte b = 0; b < loadedDrivers.size(); b++) {
/*      */       
/* 1344 */       JdbcDriver jdbcDriver = (JdbcDriver)loadedDrivers.elementAt(b);
/* 1345 */       if (jdbcDriver.className.equals(paramString1)) {
/*      */         return;
/*      */       }
/*      */     } 
/* 1349 */     debugFile("Loading JDBC driver: " + paramString1);
/*      */ 
/*      */     
/*      */     try {
/* 1353 */       Class.forName(paramString1);
/*      */ 
/*      */       
/* 1356 */       JdbcDriver jdbcDriver = new JdbcDriver(paramString1, paramString2, paramBoolean1, 
/* 1357 */           paramBoolean2, paramBoolean3, paramInt);
/* 1358 */       loadedDrivers.addElement(jdbcDriver);
/*      */     }
/* 1360 */     catch (ClassNotFoundException classNotFoundException) {
/*      */       
/* 1362 */       debugFile("ClassNotFound: " + classNotFoundException, 3);
/*      */     } 
/*      */ 
/*      */     
/* 1366 */     initialized = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1382 */   public static void loadDriver(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) { loadDriver(paramString1, paramString2, paramBoolean1, paramBoolean2, paramBoolean3, 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1398 */   public static void loadDriver(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2) { loadDriver(paramString1, paramString2, paramBoolean1, paramBoolean2, false, 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1406 */   public static long getQueryNumber() { return queryNumber; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setDebugLevel(int paramInt) {
/* 1418 */     if (debugLevel >= 1 && debugLevel <= 3) {
/* 1419 */       debugLevel = paramInt;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1427 */   public static void setDebugFilename(String paramString) { debugFilename = paramString; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1437 */   public static void setDefaultJdbcURLPrefix(String paramString) { defJdbcURLPrefix = paramString; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1445 */   public static String getDefaultJdbcURLPrefix() { return defJdbcURLPrefix; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1453 */   public static void debugFile(String paramString) { debugFile(paramString, 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void debugFile(String paramString, int paramInt) {
/* 1463 */     if (debugLevel <= paramInt)
/*      */     {
/* 1465 */       if (debugFilename != null) {
/*      */         
/*      */         try {
/*      */ 
/*      */ 
/*      */           
/* 1471 */           if (queryNumber % 500L == 0L) {
/*      */             
/* 1473 */             File file = new File(debugFilename);
/* 1474 */             if (file.exists())
/*      */             {
/* 1476 */               if (file.length() > 2000000L)
/*      */               {
/* 1478 */                 file.delete();
/*      */               }
/*      */             }
/*      */           } 
/*      */           
/* 1483 */           String str1 = "H";
/* 1484 */           if (paramInt == 2) {
/* 1485 */             str1 = "M";
/* 1486 */           } else if (paramInt == 1) {
/* 1487 */             str1 = "L";
/*      */           } 
/* 1489 */           Date date = new Date();
/* 1490 */           String str2 = 
/* 1491 */             "jdbc: " + str1 + " [" + dateFormat.format(date) + "] " + paramString;
/*      */           
/* 1493 */           FileWriter fileWriter = new FileWriter(debugFilename, true);
/* 1494 */           fileWriter.write(String.valueOf(str2) + "\r\n");
/* 1495 */           fileWriter.flush();
/* 1496 */           fileWriter.close();
/*      */ 
/*      */           
/* 1499 */           System.out.println(str2);
/*      */         }
/* 1501 */         catch (IOException iOException) {}
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class JdbcConnectionManager
/*      */     extends Vector
/*      */   {
/*      */     private final JdbcConnector this$0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     JdbcConnectionManager(JdbcConnector this$0) {
/* 1519 */       this.this$0 = this$0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public JdbcConnector.JdbcConnectionProfile add(JdbcConnector.JdbcConnectionProfile param1JdbcConnectionProfile) {
/* 1528 */       addElement(param1JdbcConnectionProfile);
/* 1529 */       param1JdbcConnectionProfile.setManager(this);
/*      */       
/* 1531 */       return param1JdbcConnectionProfile;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public JdbcConnector.JdbcConnectionProfile getLowestLoad() {
/* 1540 */       Enumeration enumeration = elements();
/* 1541 */       JdbcConnector.JdbcConnectionProfile jdbcConnectionProfile = null;
/*      */       
/* 1543 */       while (enumeration.hasMoreElements()) {
/*      */         
/* 1545 */         JdbcConnector.JdbcConnectionProfile jdbcConnectionProfile1 = (JdbcConnector.JdbcConnectionProfile)enumeration.nextElement();
/* 1546 */         if (jdbcConnectionProfile == null || jdbcConnectionProfile1.getLoad() < jdbcConnectionProfile.getLoad())
/*      */         {
/* 1548 */           jdbcConnectionProfile = jdbcConnectionProfile1;
/*      */         }
/*      */       } 
/*      */       
/* 1552 */       return jdbcConnectionProfile;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void dropProfile() {
/* 1560 */       if (size() > 0)
/* 1561 */         remove(0); 
/*      */     } }
/*      */   
/*      */   class JdbcConnectionProfile {
/*      */     private final JdbcConnector this$0;
/*      */     protected Object lockObject;
/*      */     public int load;
/*      */     private String connectString;
/*      */     
/*      */     JdbcConnectionProfile(JdbcConnector this$0) {
/* 1571 */       this.this$0 = this$0;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1576 */       this.lockObject = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1581 */       this.load = 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String username;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String password;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected JdbcConnector.JdbcConnectionManager manager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Connection connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void establishDbConnection(String param1String1, String param1String2, String param1String3) {
/* 1615 */       close();
/*      */       
/* 1617 */       synchronized (this.lockObject) {
/*      */         
/* 1619 */         if (this.connection == null) {
/*      */ 
/*      */           
/* 1622 */           this.username = param1String2;
/* 1623 */           this.password = param1String3;
/* 1624 */           this.connectString = param1String1;
/*      */           
/* 1626 */           String str = String.valueOf(this.this$0.jdbcURLPrefix) + param1String1;
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/* 1631 */             JdbcConnector.debugFile("establishDbConnection(" + str + ", " + param1String2 + 
/* 1632 */                 ", " + param1String3 + ")");
/* 1633 */             this.connection = DriverManager.getConnection(str, param1String2, param1String3);
/*      */           }
/* 1635 */           catch (SQLException sQLException) {
/*      */             
/* 1637 */             JdbcConnector.debugFile("SQL Exception while connecting: " + sQLException, 3);
/* 1638 */             this.connection = null;
/*      */           } 
/*      */ 
/*      */           
/* 1642 */           this.load = 0;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Connection getConnection() {
/* 1652 */       if (this.connection == null && this.connectString != null)
/* 1653 */         establishDbConnection(this.connectString, this.username, this.password); 
/* 1654 */       return this.connection;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1662 */     public void setManager(JdbcConnector.JdbcConnectionManager param1JdbcConnectionManager) { this.manager = param1JdbcConnectionManager; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isClosed() {
/*      */       try {
/* 1673 */         if (this.connection != null) {
/* 1674 */           return this.connection.isClosed();
/*      */         }
/* 1676 */       } catch (SQLException sQLException) {
/*      */         
/* 1678 */         JdbcConnector.debugFile("SQLException while determining connection's closed status: " + sQLException);
/*      */       } 
/*      */       
/* 1681 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {
/* 1689 */       if (this.connection != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1693 */           this.connection.close();
/*      */         }
/* 1695 */         catch (SQLException sQLException) {
/*      */           
/* 1697 */           JdbcConnector.debugFile("SQLException while closing connection: " + sQLException);
/*      */         } 
/* 1699 */         this.connection = null;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1708 */     public int incrementLoad() { return ++this.load; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int decrementLoad() {
/* 1716 */       this.load--;
/* 1717 */       if (this.load < 0)
/* 1718 */         this.load = 0; 
/* 1719 */       return this.load;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1727 */     public int getLoad() { return this.load; }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class JdbcDriver
/*      */   {
/*      */     public String className;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String urlPrefix;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean supportsAbsolute;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean supportsGetRow;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean jdbc1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int pooling;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public JdbcDriver(String param1String1, String param1String2, boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3, int param1Int) {
/* 1776 */       this.className = param1String1;
/* 1777 */       this.urlPrefix = param1String2;
/* 1778 */       this.supportsAbsolute = param1Boolean1;
/* 1779 */       this.supportsGetRow = param1Boolean2;
/* 1780 */       this.jdbc1 = param1Boolean3;
/* 1781 */       this.pooling = param1Int;
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\JdbcConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */