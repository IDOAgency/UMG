package com.techempower.gemini;

import com.techempower.gemini.pyxis.BasicSecurity;

public class FormAddRemoveMultiSelectBox extends FormMultiSelectBox {
  protected int[] selectionIDs = null;
  
  protected int[] valueIDs = null;
  
  protected String form1Name = "f" + BasicSecurity.randomPassword(5) + "f";
  
  protected String form2Name = "f" + BasicSecurity.randomPassword(5) + "f";
  
  protected String fmsbName = "s" + BasicSecurity.randomPassword(5) + "s";
  
  protected String divForm1Name = "d" + BasicSecurity.randomPassword(5) + "d";
  
  protected String divForm2Name = "d" + BasicSecurity.randomPassword(5) + "d";
  
  protected String divForm1Class = "c" + BasicSecurity.randomPassword(5) + "c";
  
  protected String divForm2Class = "c" + BasicSecurity.randomPassword(5) + "c";
  
  protected int divTop = 0;
  
  protected int divLeft = 0;
  
  protected int div1Top = 0;
  
  protected int div1Left = 0;
  
  protected int div2Top = 0;
  
  protected int div2Left = 0;
  
  public FormAddRemoveMultiSelectBox(String paramString, String[] paramArrayOfString1, int[] paramArrayOfInt1, String[] paramArrayOfString2, int[] paramArrayOfInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramString, paramArrayOfString1, paramArrayOfString2, paramBoolean1, paramBoolean2);
    this.div1Top = paramInt1;
    this.div1Left = paramInt2;
    this.div2Top = paramInt3;
    this.div2Left = paramInt4;
    this.fmsbName = String.valueOf(paramString) + "2";
    this.selectionIDs = paramArrayOfInt1;
    this.valueIDs = paramArrayOfInt2;
  }
  
  public FormAddRemoveMultiSelectBox(String paramString, String[] paramArrayOfString1, int[] paramArrayOfInt1, String[] paramArrayOfString2, int[] paramArrayOfInt2, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramString, paramArrayOfString1, paramArrayOfString2, paramBoolean);
    this.div1Top = paramInt1;
    this.div1Left = paramInt2;
    this.div2Top = paramInt3;
    this.div2Left = paramInt4;
    this.fmsbName = String.valueOf(paramString) + "2";
    this.selectionIDs = paramArrayOfInt1;
    this.valueIDs = paramArrayOfInt2;
  }
  
  public FormAddRemoveMultiSelectBox(String paramString, String[] paramArrayOfString, int[] paramArrayOfInt, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this(paramString, null, null, paramArrayOfString, paramArrayOfInt, paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public FormAddRemoveMultiSelectBox(String paramString, String[] paramArrayOfString, int[] paramArrayOfInt, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this(paramString, null, null, paramArrayOfString, paramArrayOfInt, paramBoolean1, paramBoolean2, paramInt1, paramInt2, paramInt3, paramInt4); }
  
  protected String getStyleSheet(String paramString, int paramInt1, int paramInt2) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("\n");
    stringBuffer.append("<style type=\"text/css\">\n");
    stringBuffer.append("." + paramString + "\n{\n");
    stringBuffer.append("position : absolute;\n");
    stringBuffer.append("top : " + paramInt1 + ";\n");
    stringBuffer.append("left : " + paramInt2 + ";\n");
    stringBuffer.append("z-index : 1;\n}\n");
    stringBuffer.append("</style>\n");
    return stringBuffer.toString();
  }
  
  protected String getJavaScriptHeader() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("\n");
    stringBuffer.append("<script language=\"JavaScript\">\n");
    return stringBuffer.toString();
  }
  
  protected String getJavaScriptEnd() { return "\n</script>\n"; }
  
  public String render() {
    String str1 = "";
    String str2 = isMultiple() ? " multiple " : " ";
    String str3 = " ";
    if (getAction() != null)
      str3 = " onChange=\"" + getAction() + "\" "; 
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(getStyleSheet(this.divForm1Class, this.div1Top, this.div1Left));
    stringBuffer.append(getStyleSheet(this.divForm2Class, this.div2Top, this.div2Left));
    stringBuffer.append(getJavaScriptHeader());
    stringBuffer.append("var " + this.fmsbName + " = new MultiSelectBox()" + ";\n");
    stringBuffer.append(String.valueOf(this.fmsbName) + ".name = \"" + this.fmsbName + "\";\n");
    stringBuffer.append(String.valueOf(this.fmsbName) + ".divName = \"" + this.divForm1Name + "\";\n");
    stringBuffer.append(String.valueOf(this.fmsbName) + ".divText = '" + "<div class=\"" + this.divForm1Class + "\" id=\"" + this.divForm1Name + "\" name=\"" + this.divForm1Name + "\">" + "';\n");
    stringBuffer.append(String.valueOf(this.fmsbName) + ".formName = \"" + this.form1Name + "\";\n");
    stringBuffer.append(String.valueOf(this.fmsbName) + ".formText = '" + "<form name=\"" + this.form1Name + "\">" + "';\n");
    stringBuffer.append(String.valueOf(this.fmsbName) + ".selectText = '" + "<select" + str2 + "name=\"" + this.fmsbName + "\" size=\"" + this.size + "\"" + str3 + " " + getClassName() + ">" + "';\n");
    stringBuffer.append(String.valueOf(this.fmsbName) + ".top = \"" + this.div1Top + "\";\n");
    stringBuffer.append(String.valueOf(this.fmsbName) + ".left = \"" + this.div1Left + "\";\n");
    stringBuffer.append(String.valueOf(this.fmsbName) + ".values = new Array();\n");
    stringBuffer.append(String.valueOf(this.fmsbName) + ".valueIDs = new Array();\n");
    if (this.values != null)
      for (byte b = 0; b < this.values.length; b++) {
        stringBuffer.append(String.valueOf(this.fmsbName) + ".values[" + b + "] = \"" + this.values[b] + "\";\n");
        stringBuffer.append(String.valueOf(this.fmsbName) + ".valueIDs[" + b + "] = \"" + this.valueIDs[b] + "\";\n");
      }  
    stringBuffer.append("var " + getName() + " = new MultiSelectBox()" + ";\n");
    stringBuffer.append(String.valueOf(getName()) + ".name = \"" + getName() + "\";\n");
    stringBuffer.append(String.valueOf(getName()) + ".divName = \"" + this.divForm2Name + "\";\n");
    stringBuffer.append(String.valueOf(getName()) + ".divText = '" + "<div class=\"" + this.divForm2Class + "\" id=\"" + this.divForm2Name + "\" name=\"" + this.divForm2Name + "\">" + "';\n");
    stringBuffer.append(String.valueOf(getName()) + ".formName = \"" + this.form2Name + "\";\n");
    stringBuffer.append(String.valueOf(getName()) + ".formText = '" + "<form name=\"" + this.form2Name + "\">" + "';\n");
    stringBuffer.append(String.valueOf(getName()) + ".selectText = '" + "<select" + str2 + "name=\"" + getName() + "\" size=\"" + this.size + "\"" + str3 + " " + getClassName() + ">" + "';\n");
    stringBuffer.append(String.valueOf(getName()) + ".top = \"" + this.div2Top + "\";\n");
    stringBuffer.append(String.valueOf(getName()) + ".left = \"" + this.div2Left + "\";\n");
    stringBuffer.append(String.valueOf(getName()) + ".values = new Array();\n");
    stringBuffer.append(String.valueOf(getName()) + ".valueIDs = new Array();\n");
    if (this.selections != null)
      for (byte b = 0; b < this.selections.length; b++) {
        stringBuffer.append(String.valueOf(getName()) + ".values[" + b + "] = \"" + this.selections[b] + "\";\n");
        stringBuffer.append(String.valueOf(getName()) + ".valueIDs[" + b + "] = \"" + this.selectionIDs[b] + "\";\n");
      }  
    stringBuffer.append(getJavaScriptEnd());
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\FormAddRemoveMultiSelectBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */