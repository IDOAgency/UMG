/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.gemini.Context;
/*     */ import com.techempower.gemini.Form;
/*     */ import com.techempower.gemini.FormDropDownMenu;
/*     */ import com.techempower.gemini.GeminiApplication;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxContentTypeInstancesGroupManager
/*     */   implements FornaxConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "fMng";
/*     */   public GeminiApplication application;
/*     */   public ComponentLog log;
/*     */   public FornaxSettings fornaxSettings;
/*     */   protected Vector contentTypeInstancesGroups;
/*     */   
/*     */   public FornaxContentTypeInstancesGroupManager(GeminiApplication paramGeminiApplication) {
/*  60 */     this.application = paramGeminiApplication;
/*  61 */     this.log = paramGeminiApplication.getLog("fMng");
/*  62 */     this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public String getDescription() { return "Fornax Content Type Instances Group Manager"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FornaxContentTypeInstancesGroup getContentTypeInstancesGroup(int paramInt) {
/*  82 */     String str = 
/*     */ 
/*     */ 
/*     */       
/*  86 */       "SELECT InstancesGroup.*, InstancesGroupCount.InstancesGroupInstancesCount FROM (SELECT * FROM fnContentTypeInstancesGroup WHERE InstancesGroupID = " + 
/*  87 */       paramInt + 
/*  88 */       " )" + 
/*  89 */       " AS [InstancesGroup]" + 
/*  90 */       " INNER JOIN (SELECT ctg.InstancesGroupID, count(ctg.InstancesGroupID) as 'InstancesGroupInstancesCount'" + 
/*  91 */       " FROM fnContentTypeInstancesGroup ctg" + 
/*  92 */       " INNER JOIN fnMapContentTypeInstanceToInstancesGroup mp" + 
/*  93 */       " ON mp.InstancesGroupID = ctg.InstancesGroupID" + 
/*  94 */       " WHERE ctg.InstancesGroupID = " + paramInt + 
/*  95 */       " GROUP BY ctg.InstancesGroupID)" + 
/*  96 */       " AS [InstancesGroupCount]" + 
/*  97 */       " ON InstancesGroupCount.InstancesGroupID = InstancesGroup.InstancesGroupID";
/*     */     
/*  99 */     Vector vector = 
/* 100 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/* 101 */         "com.techempower.gemini.fornax.FornaxContentTypeInstancesGroup", 
/* 102 */         true, 
/* 103 */         this.fornaxSettings);
/*     */     
/* 105 */     if (vector.size() == 1)
/*     */     {
/* 107 */       return (FornaxContentTypeInstancesGroup)vector.get(0);
/*     */     }
/*     */ 
/*     */     
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getContentTypeInstancesGroups(int paramInt) {
/* 122 */     String str1 = "";
/*     */ 
/*     */     
/* 125 */     if (!this.fornaxSettings.isMultiGroup())
/*     */     {
/* 127 */       str1 = "top 1";
/*     */     }
/*     */     
/* 130 */     String str2 = 
/*     */       
/* 132 */       "SELECT " + str1 + " InstancesGroup.*, InstancesGroupCount.InstancesGroupInstancesCount" + 
/*     */       
/* 134 */       " FROM (SELECT " + str1 + " *" + 
/* 135 */       " FROM fnContentTypeInstancesGroup" + 
/* 136 */       " WHERE InstancesGroupContentTypeID = " + paramInt + 
/* 137 */       " )" + 
/* 138 */       " AS [InstancesGroup]" + 
/* 139 */       " INNER JOIN (SELECT ctg.InstancesGroupID, count(ctg.InstancesGroupID) as 'InstancesGroupInstancesCount'" + 
/* 140 */       " FROM fnContentTypeInstancesGroup ctg" + 
/* 141 */       " INNER JOIN fnMapContentTypeInstanceToInstancesGroup mp" + 
/* 142 */       " ON mp.InstancesGroupID = ctg.InstancesGroupID" + 
/* 143 */       " WHERE ctg.InstancesGroupContentTypeID = " + paramInt + 
/* 144 */       " GROUP BY ctg.InstancesGroupID)" + 
/* 145 */       " AS [InstancesGroupCount]" + 
/* 146 */       " ON InstancesGroupCount.InstancesGroupID = InstancesGroup.InstancesGroupID";
/*     */ 
/*     */ 
/*     */     
/* 150 */     this.contentTypeInstancesGroups = null;
/* 151 */     this.contentTypeInstancesGroups = 
/* 152 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str2, 
/* 153 */         "com.techempower.gemini.fornax.FornaxContentTypeInstancesGroup", 
/* 154 */         true, 
/* 155 */         this.fornaxSettings);
/*     */     
/* 157 */     return this.contentTypeInstancesGroups;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateInstancesGroupsListPageFlag(Context paramContext, Form paramForm, Vector paramVector) {
/* 169 */     for (byte b = 0; b < paramVector.size(); b++) {
/*     */       
/* 171 */       FornaxContentTypeInstancesGroup fornaxContentTypeInstancesGroup = (FornaxContentTypeInstancesGroup)paramVector.elementAt(b);
/*     */       
/* 173 */       FormDropDownMenu formDropDownMenu = (FormDropDownMenu)paramForm.getElement("listPage-generate-" + Integer.toString(fornaxContentTypeInstancesGroup.getID()));
/* 174 */       if (formDropDownMenu != null) {
/*     */         
/* 176 */         fornaxContentTypeInstancesGroup.setIsListPageGenerated(formDropDownMenu.getStringValue());
/* 177 */         fornaxContentTypeInstancesGroup.runUpdate(this.fornaxSettings.getConnector(""));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstancesGroupManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */