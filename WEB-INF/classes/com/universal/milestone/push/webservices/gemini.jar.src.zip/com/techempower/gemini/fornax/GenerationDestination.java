package com.techempower.gemini.fornax;

import java.util.Hashtable;

public class GenerationDestination implements FornaxDBConstants {
  protected int mGenerationDestinationID;
  
  protected FilePath mGenerationDestinationFilePath;
  
  protected String mGenerationDestinationName;
  
  protected String mGenerationDestinationDesc;
  
  protected String mGenerationDestinationServerNetworkName;
  
  protected String mGenerationDestinationServerDNSName;
  
  protected String mGenerationDestinationServerIPAddress;
  
  protected String mGenerationDestinationLogonUserName;
  
  protected String mGenerationDestinationLogonPassword;
  
  public GenerationDestination(Hashtable paramHashtable) {
    this.mGenerationDestinationID = ((Integer)paramHashtable.get("generationDestinationID")).intValue();
    this.mGenerationDestinationFilePath = (FilePath)paramHashtable.get("generationDestinationFilePath");
    this.mGenerationDestinationName = (String)paramHashtable.get("generationDestinationName");
    this.mGenerationDestinationDesc = (String)paramHashtable.get("generationDestinationDesc");
    this.mGenerationDestinationServerNetworkName = (String)paramHashtable.get("generationDestinationServerNetworkName");
    this.mGenerationDestinationServerDNSName = (String)paramHashtable.get("generationDestinationServerDNSName");
    this.mGenerationDestinationServerIPAddress = (String)paramHashtable.get("generationDestinationServerIPAddress");
    this.mGenerationDestinationLogonUserName = (String)paramHashtable.get("generationDestinationLogonUserName");
    this.mGenerationDestinationLogonPassword = (String)paramHashtable.get("generationDestinationLogonPassword");
  }
  
  public int getGenerationDestinationID() { return this.mGenerationDestinationID; }
  
  public FilePath getFilePath() { return this.mGenerationDestinationFilePath; }
  
  public String getGenerationDestinationName() { return this.mGenerationDestinationName; }
  
  public String getGenerationDestinationDesc() { return this.mGenerationDestinationDesc; }
  
  public String getServerNetworkName() { return this.mGenerationDestinationServerNetworkName; }
  
  public String getServerDNSkName() { return this.mGenerationDestinationServerDNSName; }
  
  public String getServerIPAddress() { return this.mGenerationDestinationServerIPAddress; }
  
  public String getLogonUserName() { return this.mGenerationDestinationLogonUserName; }
  
  public String getLogonPassword() { return this.mGenerationDestinationLogonPassword; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\GenerationDestination.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */