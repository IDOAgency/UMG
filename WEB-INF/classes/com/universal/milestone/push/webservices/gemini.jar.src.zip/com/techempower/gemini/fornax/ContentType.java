package com.techempower.gemini.fornax;

import java.util.Hashtable;
import java.util.Vector;

public class ContentType implements FornaxDBConstants {
  protected int mContentTypeID;
  
  protected String mContentTypeName;
  
  protected String mContentTypeDescription;
  
  protected ListPage mContentTypeListPage;
  
  protected boolean mIsSingleton;
  
  protected boolean mIsListPageGenerated;
  
  protected Vector mFields;
  
  protected Vector mGroups;
  
  public ContentType(Hashtable paramHashtable) {
    this.mFields = new Vector();
    this.mGroups = new Vector();
    this.mContentTypeID = ((Integer)paramHashtable.get("contentTypeID")).intValue();
    this.mContentTypeName = (String)paramHashtable.get("contentTypeName");
    this.mContentTypeDescription = (String)paramHashtable.get("contentTypeDescription");
    this.mContentTypeListPage = (ListPage)paramHashtable.get("contentTypeListPage");
    this.mIsSingleton = ((Boolean)paramHashtable.get("contentTypeIsSingleton")).booleanValue();
    this.mIsListPageGenerated = ((Boolean)paramHashtable.get("contentTypeIsListPageGenerated")).booleanValue();
    this.mFields = (Vector)paramHashtable.get("contentTypeFields");
    this.mGroups = (Vector)paramHashtable.get("contentTypeGroups");
  }
  
  public int getContentTypeID() { return this.mContentTypeID; }
  
  public String getContentTypeName() { return this.mContentTypeName; }
  
  public String getContentTypeDescription() { return this.mContentTypeDescription; }
  
  public ListPage getContentTypeListPage() { return this.mContentTypeListPage; }
  
  public boolean getIsSingleton() { return this.mIsSingleton; }
  
  public Vector getContentTypeFields() { return this.mFields; }
  
  public Vector getGroups() { return this.mGroups; }
  
  public boolean isListPageGenerated() { return this.mIsListPageGenerated; }
  
  public ContentTypeInstanceGroup getGroupByName(String paramString) {
    ContentTypeInstanceGroup contentTypeInstanceGroup = null;
    for (byte b = 0; b < this.mGroups.size(); b++) {
      contentTypeInstanceGroup = (ContentTypeInstanceGroup)this.mGroups.elementAt(b);
      if (contentTypeInstanceGroup.getGroupName().equalsIgnoreCase(paramString))
        break; 
      contentTypeInstanceGroup = null;
    } 
    return contentTypeInstanceGroup;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\ContentType.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */