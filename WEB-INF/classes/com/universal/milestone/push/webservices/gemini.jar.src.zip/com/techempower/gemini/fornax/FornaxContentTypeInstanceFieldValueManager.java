/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.gemini.GeminiApplication;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxContentTypeInstanceFieldValueManager
/*     */   implements FornaxConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "fMng";
/*     */   public GeminiApplication application;
/*     */   public ComponentLog log;
/*     */   public FornaxSettings fornaxSettings;
/*     */   protected Vector contentTypeInstanceFieldValues;
/*     */   
/*     */   public FornaxContentTypeInstanceFieldValueManager(GeminiApplication paramGeminiApplication) {
/*  60 */     this.application = paramGeminiApplication;
/*  61 */     this.log = paramGeminiApplication.getLog("fMng");
/*  62 */     this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public String getDescription() { return "Fornax ContentTypeInstance Field Value Manager"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FornaxContentTypeInstanceFieldValue getContentTypeInstanceFieldValue(int paramInt1, int paramInt2) {
/*  80 */     String str = 
/*     */ 
/*     */       
/*  83 */       "SELECT * FROM fnContentTypeInstanceFieldValueWHERE InstanceID = " + 
/*  84 */       paramInt1 + 
/*  85 */       " AND InstanceFieldID = " + paramInt2;
/*     */     
/*  87 */     Vector vector = 
/*  88 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/*  89 */         "com.techempower.gemini.fornax.FornaxContentTypeInstanceFieldValue", 
/*  90 */         true, 
/*  91 */         this.fornaxSettings);
/*     */     
/*  93 */     if (vector.size() == 1)
/*     */     {
/*  95 */       return (FornaxContentTypeInstanceFieldValue)vector.get(0);
/*     */     }
/*     */ 
/*     */     
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getContentTypeInstanceFieldValues(int paramInt1, int paramInt2) {
/* 110 */     String str = 
/*     */ 
/*     */       
/* 113 */       "SELECT * FROM fnContentTypeInstanceFieldValue WHERE InstanceID = " + 
/* 114 */       paramInt1 + 
/* 115 */       " AND InstanceContentTypeID = " + paramInt2 + 
/* 116 */       " ORDER BY InstanceFieldSequenceNumber ASC";
/*     */ 
/*     */     
/* 119 */     this.contentTypeInstanceFieldValues = null;
/* 120 */     this.contentTypeInstanceFieldValues = 
/* 121 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/* 122 */         "com.techempower.gemini.fornax.FornaxContentTypeInstanceFieldValue", 
/* 123 */         true, 
/* 124 */         this.fornaxSettings);
/*     */     
/* 126 */     return this.contentTypeInstanceFieldValues;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstanceFieldValueManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */