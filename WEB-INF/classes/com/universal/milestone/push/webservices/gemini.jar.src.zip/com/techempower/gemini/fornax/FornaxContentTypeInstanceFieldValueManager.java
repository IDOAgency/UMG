package com.techempower.gemini.fornax;

import com.techempower.ComponentLog;
import com.techempower.gemini.GeminiApplication;
import java.util.Vector;

public class FornaxContentTypeInstanceFieldValueManager implements FornaxConstants {
  public static final String COMPONENT_CODE = "fMng";
  
  public GeminiApplication application;
  
  public ComponentLog log;
  
  public FornaxSettings fornaxSettings;
  
  protected Vector contentTypeInstanceFieldValues;
  
  public FornaxContentTypeInstanceFieldValueManager(GeminiApplication paramGeminiApplication) {
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("fMng");
    this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
  }
  
  public String getDescription() { return "Fornax ContentTypeInstance Field Value Manager"; }
  
  public FornaxContentTypeInstanceFieldValue getContentTypeInstanceFieldValue(int paramInt1, int paramInt2) {
    String str = 
      
      "SELECT * FROM fnContentTypeInstanceFieldValueWHERE InstanceID = " + 
      paramInt1 + 
      " AND InstanceFieldID = " + paramInt2;
    Vector vector = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxContentTypeInstanceFieldValue", 
        true, 
        this.fornaxSettings);
    if (vector.size() == 1)
      return (FornaxContentTypeInstanceFieldValue)vector.get(0); 
    return null;
  }
  
  public Vector getContentTypeInstanceFieldValues(int paramInt1, int paramInt2) {
    String str = 
      
      "SELECT * FROM fnContentTypeInstanceFieldValue WHERE InstanceID = " + 
      paramInt1 + 
      " AND InstanceContentTypeID = " + paramInt2 + 
      " ORDER BY InstanceFieldSequenceNumber ASC";
    this.contentTypeInstanceFieldValues = null;
    this.contentTypeInstanceFieldValues = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxContentTypeInstanceFieldValue", 
        true, 
        this.fornaxSettings);
    return this.contentTypeInstanceFieldValues;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstanceFieldValueManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */