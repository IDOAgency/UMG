/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReserveWordTemplateFieldManager
/*     */ {
/*     */   protected boolean debug = false;
/*     */   protected static final String SELF_ID = "_self_id";
/*     */   protected static final String SELF_URLREF = "_self_urlref";
/*     */   protected static final String SELF_FILENAME = "_self_filename";
/*     */   protected static final String SELF_TYPENAME = "_self_typename";
/*     */   protected static final String SELF_GROUPNAME = "_self_groupname";
/*     */   protected static final String SELF_VARIANTNAME = "_self_variantname";
/*     */   protected ContentTypeInstance mInstance;
/*     */   protected Variant mVariant;
/*     */   protected ContentType mContentType;
/*     */   
/*  72 */   public void setInstance(ContentTypeInstance paramContentTypeInstance) { this.mInstance = paramContentTypeInstance; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public void setContentType(ContentType paramContentType) { this.mContentType = paramContentType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public void setVariant(Variant paramVariant) { this.mVariant = paramVariant; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReserveWord(String paramString) {
/*  98 */     if (paramString.equalsIgnoreCase("_self_id"))
/*     */     {
/* 100 */       return true;
/*     */     }
/* 102 */     if (paramString.equalsIgnoreCase("_self_urlref"))
/*     */     {
/* 104 */       return true;
/*     */     }
/* 106 */     if (paramString.equalsIgnoreCase("_self_filename"))
/*     */     {
/* 108 */       return true;
/*     */     }
/* 110 */     if (paramString.equalsIgnoreCase("_self_typename"))
/*     */     {
/* 112 */       return true;
/*     */     }
/* 114 */     if (paramString.equalsIgnoreCase("_self_groupname"))
/*     */     {
/* 116 */       return true;
/*     */     }
/* 118 */     if (paramString.equalsIgnoreCase("_self_variantname"))
/*     */     {
/* 120 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 124 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render(String paramString) {
/* 135 */     String str = null;
/*     */     
/* 137 */     if (paramString.equalsIgnoreCase("_self_id")) {
/*     */       
/* 139 */       str = (new Integer(this.mInstance.getInstanceID())).toString();
/*     */     
/*     */     }
/* 142 */     else if (paramString.equalsIgnoreCase("_self_urlref")) {
/*     */ 
/*     */ 
/*     */       
/* 146 */       GeneratorFileManager generatorFileManager = new GeneratorFileManager();
/*     */ 
/*     */       
/* 149 */       str = generatorFileManager.getFileName(this.mInstance, this.mVariant, true);
/*     */     }
/* 151 */     else if (paramString.equalsIgnoreCase("_self_filename")) {
/*     */ 
/*     */       
/* 154 */       GeneratorFileManager generatorFileManager = new GeneratorFileManager();
/* 155 */       str = generatorFileManager.getFileName(this.mInstance, this.mVariant, false);
/*     */     }
/* 157 */     else if (paramString.equalsIgnoreCase("_self_typename")) {
/*     */ 
/*     */       
/* 160 */       str = this.mInstance.getContentTypeName();
/*     */     
/*     */     }
/* 163 */     else if (paramString.equalsIgnoreCase("_self_groupname")) {
/*     */       
/* 165 */       str = this.mInstance.getGroupName();
/*     */     }
/* 167 */     else if (paramString.equalsIgnoreCase("_self_variantname")) {
/*     */       
/* 169 */       str = this.mVariant.getVariantTypeCode();
/*     */     } 
/*     */     
/* 172 */     if (this.debug)
/*     */     {
/* 174 */       System.out.println("ReserveWord rendering = " + str);
/*     */     }
/*     */     
/* 177 */     return str;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\gemini.jar!\com\techempower\gemini\fornax\ReserveWordTemplateFieldManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */