package com.universal.milestone.push.webservices;

import java.rmi.Remote;
import java.rmi.RemoteException;
import weblogic.webservice.async.AsyncInfo;
import weblogic.webservice.async.FutureResult;

public interface PushPFM_WSPort extends Remote {
  String pushPFM(String paramString) throws RemoteException;
  
  FutureResult startPushPFM(String paramString, AsyncInfo paramAsyncInfo) throws RemoteException;
  
  String endPushPFM(FutureResult paramFutureResult) throws RemoteException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\save\PushReceive_client.jar!\co\\universal\milestone\push\webservices\PushPFM_WSPort.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */