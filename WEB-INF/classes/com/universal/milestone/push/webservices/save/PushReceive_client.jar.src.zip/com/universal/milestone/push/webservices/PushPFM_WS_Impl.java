/*    */ package com.universal.milestone.push.webservices;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import weblogic.webservice.core.rpc.ServiceImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PushPFM_WS_Impl
/*    */   extends ServiceImpl
/*    */   implements PushPFM_WS
/*    */ {
/*    */   PushPFM_WSPort mvar_PushPFM_WSPort;
/*    */   
/* 16 */   public PushPFM_WS_Impl() throws IOException { this("com/universal/milestone/push/webservices/PushPFM_WS.wsdl"); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 22 */   public PushPFM_WS_Impl(String paramString) throws IOException { super(paramString, "com.universal.milestone.push.webservices.PushPFM_WS", "PushPFM_WS"); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PushPFM_WSPort getPushPFM_WSPort() {
/* 38 */     if (this.mvar_PushPFM_WSPort == null) {
/* 39 */       this.mvar_PushPFM_WSPort = new PushPFM_WSPort_Stub(_getPort("PushPFM_WSPort"));
/*    */     }
/*    */ 
/*    */     
/* 43 */     return this.mvar_PushPFM_WSPort;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public PushPFM_WSPort getPushPFM_WSPort(String paramString1, String paramString2) {
/* 49 */     _setUser(paramString1, paramString2, getPushPFM_WSPort());
/*    */     
/* 51 */     return getPushPFM_WSPort();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\save\PushReceive_client.jar!\co\\universal\milestone\push\webservices\PushPFM_WS_Impl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */