package com.universal.milestone.push.webservices;

import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;
import weblogic.webservice.context.WebServiceContext;

public interface PushPFM_WS extends Service {
  WebServiceContext context();
  
  WebServiceContext joinContext();
  
  PushPFM_WSPort getPushPFM_WSPort() throws ServiceException;
  
  PushPFM_WSPort getPushPFM_WSPort(String paramString1, String paramString2) throws ServiceException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\save\PushReceive_client.jar!\co\\universal\milestone\push\webservices\PushPFM_WS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */