package com.universal.milestone.push.webservices;

import java.rmi.RemoteException;
import java.util.HashMap;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.soap.SOAPFaultException;
import weblogic.webservice.Port;
import weblogic.webservice.async.AsyncInfo;
import weblogic.webservice.async.FutureResult;
import weblogic.webservice.core.rpc.StubImpl;

public class PushPFM_WSPort_Stub extends StubImpl implements PushPFM_WSPort {
  public PushPFM_WSPort_Stub(Port paramPort) { super(paramPort, PushPFM_WSPort.class); }
  
  public String pushPFM(String paramString) throws RemoteException {
    HashMap hashMap = new HashMap();
    hashMap.put("string", _wrap(paramString));
    try {
      Object object = _invoke("pushPFM", hashMap);
      return (String)object;
    } catch (JAXRPCException jAXRPCException) {
      throw new RemoteException(jAXRPCException.getMessage(), jAXRPCException.getLinkedCause());
    } catch (SOAPFaultException sOAPFaultException) {
      throw new RemoteException("SOAP Fault:" + sOAPFaultException + "\nDetail:\n" + sOAPFaultException.getDetail(), sOAPFaultException);
    } catch (Throwable throwable) {
      throw new RemoteException(throwable.getMessage(), throwable);
    } 
  }
  
  public FutureResult startPushPFM(String paramString, AsyncInfo paramAsyncInfo) throws RemoteException {
    HashMap hashMap = new HashMap();
    hashMap.put("string", _wrap(paramString));
    try {
      return _startAsyncInvoke("pushPFM", hashMap, paramAsyncInfo);
    } catch (JAXRPCException jAXRPCException) {
      throw new RemoteException(jAXRPCException.getMessage(), jAXRPCException.getLinkedCause());
    } catch (SOAPFaultException sOAPFaultException) {
      throw new RemoteException("SOAP Fault:" + sOAPFaultException + "\nDetail:\n" + sOAPFaultException.getDetail(), sOAPFaultException);
    } 
  }
  
  public String endPushPFM(FutureResult paramFutureResult) throws RemoteException {
    try {
      Object object = paramFutureResult.getResult();
      return (String)object;
    } catch (JAXRPCException jAXRPCException) {
      throw new RemoteException(jAXRPCException.getMessage(), jAXRPCException.getLinkedCause());
    } catch (SOAPFaultException sOAPFaultException) {
      throw new RemoteException("SOAP Fault:" + sOAPFaultException + "\nDetail:\n" + sOAPFaultException.getDetail(), sOAPFaultException);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\save\PushReceive_client.jar!\co\\universal\milestone\push\webservices\PushPFM_WSPort_Stub.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */