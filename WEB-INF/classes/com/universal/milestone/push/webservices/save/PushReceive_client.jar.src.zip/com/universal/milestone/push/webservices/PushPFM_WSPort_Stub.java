/*    */ package com.universal.milestone.push.webservices;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import java.util.HashMap;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ import javax.xml.rpc.soap.SOAPFaultException;
/*    */ import weblogic.webservice.Port;
/*    */ import weblogic.webservice.async.AsyncInfo;
/*    */ import weblogic.webservice.async.FutureResult;
/*    */ import weblogic.webservice.core.rpc.StubImpl;
/*    */ 
/*    */ public class PushPFM_WSPort_Stub extends StubImpl implements PushPFM_WSPort {
/* 13 */   public PushPFM_WSPort_Stub(Port paramPort) { super(paramPort, PushPFM_WSPort.class); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String pushPFM(String paramString) throws RemoteException {
/* 23 */     HashMap hashMap = new HashMap();
/* 24 */     hashMap.put("string", _wrap(paramString));
/*    */     try {
/* 26 */       Object object = _invoke("pushPFM", hashMap);
/* 27 */       return (String)object;
/* 28 */     } catch (JAXRPCException jAXRPCException) {
/* 29 */       throw new RemoteException(jAXRPCException.getMessage(), jAXRPCException.getLinkedCause());
/* 30 */     } catch (SOAPFaultException sOAPFaultException) {
/* 31 */       throw new RemoteException("SOAP Fault:" + sOAPFaultException + "\nDetail:\n" + sOAPFaultException.getDetail(), sOAPFaultException);
/* 32 */     } catch (Throwable throwable) {
/* 33 */       throw new RemoteException(throwable.getMessage(), throwable);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FutureResult startPushPFM(String paramString, AsyncInfo paramAsyncInfo) throws RemoteException {
/* 42 */     HashMap hashMap = new HashMap();
/* 43 */     hashMap.put("string", _wrap(paramString));
/*    */     try {
/* 45 */       return _startAsyncInvoke("pushPFM", hashMap, paramAsyncInfo);
/* 46 */     } catch (JAXRPCException jAXRPCException) {
/* 47 */       throw new RemoteException(jAXRPCException.getMessage(), jAXRPCException.getLinkedCause());
/* 48 */     } catch (SOAPFaultException sOAPFaultException) {
/* 49 */       throw new RemoteException("SOAP Fault:" + sOAPFaultException + "\nDetail:\n" + sOAPFaultException.getDetail(), sOAPFaultException);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String endPushPFM(FutureResult paramFutureResult) throws RemoteException {
/*    */     try {
/* 57 */       Object object = paramFutureResult.getResult();
/* 58 */       return (String)object;
/* 59 */     } catch (JAXRPCException jAXRPCException) {
/* 60 */       throw new RemoteException(jAXRPCException.getMessage(), jAXRPCException.getLinkedCause());
/* 61 */     } catch (SOAPFaultException sOAPFaultException) {
/* 62 */       throw new RemoteException("SOAP Fault:" + sOAPFaultException + "\nDetail:\n" + sOAPFaultException.getDetail(), sOAPFaultException);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\classes\co\\universal\milestone\push\webservices\save\PushReceive_client.jar!\co\\universal\milestone\push\webservices\PushPFM_WSPort_Stub.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */