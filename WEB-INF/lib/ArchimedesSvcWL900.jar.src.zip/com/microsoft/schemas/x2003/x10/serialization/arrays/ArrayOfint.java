/**
 * Generated from schema type t=ArrayOfint@http://schemas.microsoft.com/2003/10/Serialization/Arrays
 */
package com.microsoft.schemas.x2003.x10.serialization.arrays;

public class ArrayOfint implements java.io.Serializable {

  private int[] _int;

  public int[] getInt() {
    return this._int;
  }

  public void setInt(int[] _int) {
    this._int = _int;
  }

}
