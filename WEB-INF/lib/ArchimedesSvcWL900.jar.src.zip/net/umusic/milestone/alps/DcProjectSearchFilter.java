/**
 * Generated from schema type t=dcProjectSearchFilter@http://alps.milestone.umusic.net/
 */
package net.umusic.milestone.alps;

public class DcProjectSearchFilter implements java.io.Serializable {

  private java.lang.String artistFirstName;

  public java.lang.String getArtistFirstName() {
    return this.artistFirstName;
  }

  public void setArtistFirstName(java.lang.String artistFirstName) {
    this.artistFirstName = artistFirstName;
  }

  private java.lang.String artistLastNameGroupName;

  public java.lang.String getArtistLastNameGroupName() {
    return this.artistLastNameGroupName;
  }

  public void setArtistLastNameGroupName(java.lang.String artistLastNameGroupName) {
    this.artistLastNameGroupName = artistLastNameGroupName;
  }

  private java.lang.String projectID;

  public java.lang.String getProjectID() {
    return this.projectID;
  }

  public void setProjectID(java.lang.String projectID) {
    this.projectID = projectID;
  }

  private java.lang.String projectTitle;

  public java.lang.String getProjectTitle() {
    return this.projectTitle;
  }

  public void setProjectTitle(java.lang.String projectTitle) {
    this.projectTitle = projectTitle;
  }

  private java.lang.String projectDescription;

  public java.lang.String getProjectDescription() {
    return this.projectDescription;
  }

  public void setProjectDescription(java.lang.String projectDescription) {
    this.projectDescription = projectDescription;
  }

  private com.microsoft.schemas.x2003.x10.serialization.arrays.ArrayOfint archimedesIDs;

  public com.microsoft.schemas.x2003.x10.serialization.arrays.ArrayOfint getArchimedesIDs() {
    return this.archimedesIDs;
  }

  public void setArchimedesIDs(com.microsoft.schemas.x2003.x10.serialization.arrays.ArrayOfint archimedesIDs) {
    this.archimedesIDs = archimedesIDs;
  }

  private boolean active;

  public boolean getActive() {
    return this.active;
  }

  public boolean isActive() {
    return this.active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  private com.microsoft.schemas.x2003.x10.serialization.arrays.ArrayOfint levelOfActivityID;

  public com.microsoft.schemas.x2003.x10.serialization.arrays.ArrayOfint getLevelOfActivityID() {
    return this.levelOfActivityID;
  }

  public void setLevelOfActivityID(com.microsoft.schemas.x2003.x10.serialization.arrays.ArrayOfint levelOfActivityID) {
    this.levelOfActivityID = levelOfActivityID;
  }

  private int rowsToReturn;

  public int getRowsToReturn() {
    return this.rowsToReturn;
  }

  public void setRowsToReturn(int rowsToReturn) {
    this.rowsToReturn = rowsToReturn;
  }

}
