/**
 * Generated from schema type t=dcDistributionCoData@http://alps.milestone.umusic.net/
 */
package net.umusic.milestone.alps;

public class DcDistributionCoData implements java.io.Serializable {

  private java.lang.String name;

  public java.lang.String getName() {
    return this.name;
  }

  public void setName(java.lang.String name) {
    this.name = name;
  }

  private java.lang.Integer iD;

  public java.lang.Integer getID() {
    return this.iD;
  }

  public void setID(java.lang.Integer iD) {
    this.iD = iD;
  }

  private java.lang.Integer sortOrder;

  public java.lang.Integer getSortOrder() {
    return this.sortOrder;
  }

  public void setSortOrder(java.lang.Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

}
