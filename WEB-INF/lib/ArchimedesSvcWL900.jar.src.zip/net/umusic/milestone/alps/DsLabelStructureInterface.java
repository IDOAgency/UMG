/**
 * Generated from schema type t=dsLabelStructureInterface@http://alps.milestone.umusic.net/
 */
package net.umusic.milestone.alps;

public class DsLabelStructureInterface implements java.io.Serializable {

  private java.lang.String company;

  public java.lang.String getCompany() {
    return this.company;
  }

  public void setCompany(java.lang.String company) {
    this.company = company;
  }

  private java.lang.String division;

  public java.lang.String getDivision() {
    return this.division;
  }

  public void setDivision(java.lang.String division) {
    this.division = division;
  }

  private java.lang.String entityName;

  public java.lang.String getEntityName() {
    return this.entityName;
  }

  public void setEntityName(java.lang.String entityName) {
    this.entityName = entityName;
  }

  private java.lang.String entityType;

  public java.lang.String getEntityType() {
    return this.entityType;
  }

  public void setEntityType(java.lang.String entityType) {
    this.entityType = entityType;
  }

  private java.lang.String environmentName;

  public java.lang.String getEnvironmentName() {
    return this.environmentName;
  }

  public void setEnvironmentName(java.lang.String environmentName) {
    this.environmentName = environmentName;
  }

  private java.lang.String familyName;

  public java.lang.String getFamilyName() {
    return this.familyName;
  }

  public void setFamilyName(java.lang.String familyName) {
    this.familyName = familyName;
  }

  private java.lang.Integer iD;

  public java.lang.Integer getID() {
    return this.iD;
  }

  public void setID(java.lang.Integer iD) {
    this.iD = iD;
  }

  private java.lang.String jDEReportingCo;

  public java.lang.String getJDEReportingCo() {
    return this.jDEReportingCo;
  }

  public void setJDEReportingCo(java.lang.String jDEReportingCo) {
    this.jDEReportingCo = jDEReportingCo;
  }

  private java.lang.String jDEReportingUnit;

  public java.lang.String getJDEReportingUnit() {
    return this.jDEReportingUnit;
  }

  public void setJDEReportingUnit(java.lang.String jDEReportingUnit) {
    this.jDEReportingUnit = jDEReportingUnit;
  }

  private java.lang.String label;

  public java.lang.String getLabel() {
    return this.label;
  }

  public void setLabel(java.lang.String label) {
    this.label = label;
  }

  private java.lang.String legacyOperatingCo;

  public java.lang.String getLegacyOperatingCo() {
    return this.legacyOperatingCo;
  }

  public void setLegacyOperatingCo(java.lang.String legacyOperatingCo) {
    this.legacyOperatingCo = legacyOperatingCo;
  }

  private java.lang.String legacyOperatingUnit;

  public java.lang.String getLegacyOperatingUnit() {
    return this.legacyOperatingUnit;
  }

  public void setLegacyOperatingUnit(java.lang.String legacyOperatingUnit) {
    this.legacyOperatingUnit = legacyOperatingUnit;
  }

  private java.lang.String legacySublabel;

  public java.lang.String getLegacySublabel() {
    return this.legacySublabel;
  }

  public void setLegacySublabel(java.lang.String legacySublabel) {
    this.legacySublabel = legacySublabel;
  }

  private java.lang.String legacySuperlabel;

  public java.lang.String getLegacySuperlabel() {
    return this.legacySuperlabel;
  }

  public void setLegacySuperlabel(java.lang.String legacySuperlabel) {
    this.legacySuperlabel = legacySuperlabel;
  }

}
