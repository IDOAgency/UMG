/**
 * Generated from schema type t=ArrayOfdcDistributionCoData@http://alps.milestone.umusic.net/
 */
package net.umusic.milestone.alps;

public class ArrayOfdcDistributionCoData implements java.io.Serializable {

  private net.umusic.milestone.alps.DcDistributionCoData[] dcDistributionCoData;

  public net.umusic.milestone.alps.DcDistributionCoData[] getDcDistributionCoData() {
    return this.dcDistributionCoData;
  }

  public void setDcDistributionCoData(net.umusic.milestone.alps.DcDistributionCoData[] dcDistributionCoData) {
    this.dcDistributionCoData = dcDistributionCoData;
  }

}
