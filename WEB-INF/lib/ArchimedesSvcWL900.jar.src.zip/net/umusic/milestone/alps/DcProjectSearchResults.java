/**
 * Generated from schema type t=dcProjectSearchResults@http://alps.milestone.umusic.net/
 */
package net.umusic.milestone.alps;

public class DcProjectSearchResults implements java.io.Serializable {

  private java.lang.String artist_First_Name;

  public java.lang.String getArtist_First_Name() {
    return this.artist_First_Name;
  }

  public void setArtist_First_Name(java.lang.String artist_First_Name) {
    this.artist_First_Name = artist_First_Name;
  }

  private java.lang.String artist_Last_Name_Group_Name;

  public java.lang.String getArtist_Last_Name_Group_Name() {
    return this.artist_Last_Name_Group_Name;
  }

  public void setArtist_Last_Name_Group_Name(java.lang.String artist_Last_Name_Group_Name) {
    this.artist_Last_Name_Group_Name = artist_Last_Name_Group_Name;
  }

  private java.lang.Integer project_ID;

  public java.lang.Integer getProject_ID() {
    return this.project_ID;
  }

  public void setProject_ID(java.lang.Integer project_ID) {
    this.project_ID = project_ID;
  }

  private java.lang.String project_Title;

  public java.lang.String getProject_Title() {
    return this.project_Title;
  }

  public void setProject_Title(java.lang.String project_Title) {
    this.project_Title = project_Title;
  }

  private java.lang.String project_Description;

  public java.lang.String getProject_Description() {
    return this.project_Description;
  }

  public void setProject_Description(java.lang.String project_Description) {
    this.project_Description = project_Description;
  }

  private java.util.Calendar create_Date;

  public java.util.Calendar getCreate_Date() {
    return this.create_Date;
  }

  public void setCreate_Date(java.util.Calendar create_Date) {
    this.create_Date = create_Date;
  }

  private java.lang.Integer archimedes_ID;

  public java.lang.Integer getArchimedes_ID() {
    return this.archimedes_ID;
  }

  public void setArchimedes_ID(java.lang.Integer archimedes_ID) {
    this.archimedes_ID = archimedes_ID;
  }

  private java.lang.String jDE_Project_;

  public java.lang.String getJDE_Project_() {
    return this.jDE_Project_;
  }

  public void setJDE_Project_(java.lang.String jDE_Project_) {
    this.jDE_Project_ = jDE_Project_;
  }

  private java.lang.String rMS_Project_;

  public java.lang.String getRMS_Project_() {
    return this.rMS_Project_;
  }

  public void setRMS_Project_(java.lang.String rMS_Project_) {
    this.rMS_Project_ = rMS_Project_;
  }

  private java.lang.String imprint;

  public java.lang.String getImprint() {
    return this.imprint;
  }

  public void setImprint(java.lang.String imprint) {
    this.imprint = imprint;
  }

  private java.lang.Boolean active;

  public java.lang.Boolean getActive() {
    return this.active;
  }

  public void setActive(java.lang.Boolean active) {
    this.active = active;
  }

  private java.lang.Integer artistRosterActivity;

  public java.lang.Integer getArtistRosterActivity() {
    return this.artistRosterActivity;
  }

  public void setArtistRosterActivity(java.lang.Integer artistRosterActivity) {
    this.artistRosterActivity = artistRosterActivity;
  }

}
