/**
 * Generated from schema type t=dcLabelData@http://alps.milestone.umusic.net/
 */
package net.umusic.milestone.alps;

public class DcLabelData implements java.io.Serializable {

  private java.lang.String distCoName;

  public java.lang.String getDistCoName() {
    return this.distCoName;
  }

  public void setDistCoName(java.lang.String distCoName) {
    this.distCoName = distCoName;
  }

  private java.lang.Integer distCoID;

  public java.lang.Integer getDistCoID() {
    return this.distCoID;
  }

  public void setDistCoID(java.lang.Integer distCoID) {
    this.distCoID = distCoID;
  }

  private java.lang.Boolean aPNGInd;

  public java.lang.Boolean getAPNGInd() {
    return this.aPNGInd;
  }

  public void setAPNGInd(java.lang.Boolean aPNGInd) {
    this.aPNGInd = aPNGInd;
  }

  private java.lang.Integer archimedesID;

  public java.lang.Integer getArchimedesID() {
    return this.archimedesID;
  }

  public void setArchimedesID(java.lang.Integer archimedesID) {
    this.archimedesID = archimedesID;
  }

  private java.lang.String entityName;

  public java.lang.String getEntityName() {
    return this.entityName;
  }

  public void setEntityName(java.lang.String entityName) {
    this.entityName = entityName;
  }

  private java.lang.String legacyOperatingCo;

  public java.lang.String getLegacyOperatingCo() {
    return this.legacyOperatingCo;
  }

  public void setLegacyOperatingCo(java.lang.String legacyOperatingCo) {
    this.legacyOperatingCo = legacyOperatingCo;
  }

  private java.lang.String legacyOperatingUnit;

  public java.lang.String getLegacyOperatingUnit() {
    return this.legacyOperatingUnit;
  }

  public void setLegacyOperatingUnit(java.lang.String legacyOperatingUnit) {
    this.legacyOperatingUnit = legacyOperatingUnit;
  }

  private java.lang.String legacySuperlabel;

  public java.lang.String getLegacySuperlabel() {
    return this.legacySuperlabel;
  }

  public void setLegacySuperlabel(java.lang.String legacySuperlabel) {
    this.legacySuperlabel = legacySuperlabel;
  }

  private java.lang.String legacySublabel;

  public java.lang.String getLegacySublabel() {
    return this.legacySublabel;
  }

  public void setLegacySublabel(java.lang.String legacySublabel) {
    this.legacySublabel = legacySublabel;
  }

  private java.lang.String levelOfActivity;

  public java.lang.String getLevelOfActivity() {
    return this.levelOfActivity;
  }

  public void setLevelOfActivity(java.lang.String levelOfActivity) {
    this.levelOfActivity = levelOfActivity;
  }

  private java.lang.String productionGroupCode;

  public java.lang.String getProductionGroupCode() {
    return this.productionGroupCode;
  }

  public void setProductionGroupCode(java.lang.String productionGroupCode) {
    this.productionGroupCode = productionGroupCode;
  }

  private java.lang.String entityType;

  public java.lang.String getEntityType() {
    return this.entityType;
  }

  public void setEntityType(java.lang.String entityType) {
    this.entityType = entityType;
  }

}
