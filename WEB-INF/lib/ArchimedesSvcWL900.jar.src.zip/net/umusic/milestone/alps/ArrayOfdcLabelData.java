/**
 * Generated from schema type t=ArrayOfdcLabelData@http://alps.milestone.umusic.net/
 */
package net.umusic.milestone.alps;

public class ArrayOfdcLabelData implements java.io.Serializable {

  private net.umusic.milestone.alps.DcLabelData[] dcLabelData;

  public net.umusic.milestone.alps.DcLabelData[] getDcLabelData() {
    return this.dcLabelData;
  }

  public void setDcLabelData(net.umusic.milestone.alps.DcLabelData[] dcLabelData) {
    this.dcLabelData = dcLabelData;
  }

}
