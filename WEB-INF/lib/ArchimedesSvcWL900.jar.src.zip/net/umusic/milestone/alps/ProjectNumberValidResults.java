/**
 * Generated from schema type t=ProjectNumberValidResults@http://alps.milestone.umusic.net/
 */
package net.umusic.milestone.alps;

public class ProjectNumberValidResults implements java.io.Serializable {

  private java.lang.String firstName;

  public java.lang.String getFirstName() {
    return this.firstName;
  }

  public void setFirstName(java.lang.String firstName) {
    this.firstName = firstName;
  }

  private java.lang.String lastName;

  public java.lang.String getLastName() {
    return this.lastName;
  }

  public void setLastName(java.lang.String lastName) {
    this.lastName = lastName;
  }

  private java.lang.Integer labelID;

  public java.lang.Integer getLabelID() {
    return this.labelID;
  }

  public void setLabelID(java.lang.Integer labelID) {
    this.labelID = labelID;
  }

  private java.lang.Integer divisionID;

  public java.lang.Integer getDivisionID() {
    return this.divisionID;
  }

  public void setDivisionID(java.lang.Integer divisionID) {
    this.divisionID = divisionID;
  }

  private java.lang.Integer companyID;

  public java.lang.Integer getCompanyID() {
    return this.companyID;
  }

  public void setCompanyID(java.lang.Integer companyID) {
    this.companyID = companyID;
  }

  private java.lang.Integer environmentID;

  public java.lang.Integer getEnvironmentID() {
    return this.environmentID;
  }

  public void setEnvironmentID(java.lang.Integer environmentID) {
    this.environmentID = environmentID;
  }

  private java.lang.Integer familyID;

  public java.lang.Integer getFamilyID() {
    return this.familyID;
  }

  public void setFamilyID(java.lang.Integer familyID) {
    this.familyID = familyID;
  }

  private java.lang.String operatingCo;

  public java.lang.String getOperatingCo() {
    return this.operatingCo;
  }

  public void setOperatingCo(java.lang.String operatingCo) {
    this.operatingCo = operatingCo;
  }

  private java.lang.String superLabel;

  public java.lang.String getSuperLabel() {
    return this.superLabel;
  }

  public void setSuperLabel(java.lang.String superLabel) {
    this.superLabel = superLabel;
  }

  private java.lang.String subLabel;

  public java.lang.String getSubLabel() {
    return this.subLabel;
  }

  public void setSubLabel(java.lang.String subLabel) {
    this.subLabel = subLabel;
  }

  private java.lang.String imprint;

  public java.lang.String getImprint() {
    return this.imprint;
  }

  public void setImprint(java.lang.String imprint) {
    this.imprint = imprint;
  }

  private java.lang.String projectNumber;

  public java.lang.String getProjectNumber() {
    return this.projectNumber;
  }

  public void setProjectNumber(java.lang.String projectNumber) {
    this.projectNumber = projectNumber;
  }

  private java.lang.Integer archieID;

  public java.lang.Integer getArchieID() {
    return this.archieID;
  }

  public void setArchieID(java.lang.Integer archieID) {
    this.archieID = archieID;
  }

  private java.lang.String description;

  public java.lang.String getDescription() {
    return this.description;
  }

  public void setDescription(java.lang.String description) {
    this.description = description;
  }

  private java.lang.String title;

  public java.lang.String getTitle() {
    return this.title;
  }

  public void setTitle(java.lang.String title) {
    this.title = title;
  }

  private java.lang.Boolean isValid;

  public java.lang.Boolean getIsValid() {
    return this.isValid;
  }

  public void setIsValid(java.lang.Boolean isValid) {
    this.isValid = isValid;
  }

}
