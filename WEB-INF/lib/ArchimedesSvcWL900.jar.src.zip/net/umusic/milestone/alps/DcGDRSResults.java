/**
 * Generated from schema type t=dcGDRSResults@http://alps.milestone.umusic.net/
 */
package net.umusic.milestone.alps;

public class DcGDRSResults implements java.io.Serializable {

  private java.lang.Integer releaseID;

  public java.lang.Integer getReleaseID() {
    return this.releaseID;
  }

  public void setReleaseID(java.lang.Integer releaseID) {
    this.releaseID = releaseID;
  }

  private java.lang.String status;

  public java.lang.String getStatus() {
    return this.status;
  }

  public void setStatus(java.lang.String status) {
    this.status = status;
  }

  private java.lang.Boolean forceNoDigitalRelease;

  public java.lang.Boolean getForceNoDigitalRelease() {
    return this.forceNoDigitalRelease;
  }

  public void setForceNoDigitalRelease(java.lang.Boolean forceNoDigitalRelease) {
    this.forceNoDigitalRelease = forceNoDigitalRelease;
  }

  private java.lang.String exceptionMessage;

  public java.lang.String getExceptionMessage() {
    return this.exceptionMessage;
  }

  public void setExceptionMessage(java.lang.String exceptionMessage) {
    this.exceptionMessage = exceptionMessage;
  }

}
