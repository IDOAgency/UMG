/**
 * Generated from schema type t=dsProjectStructureInterface@http://alps.milestone.umusic.net/
 */
package net.umusic.milestone.alps;

public class DsProjectStructureInterface implements java.io.Serializable {

  private java.lang.Integer aRLevelOfActivityID;

  public java.lang.Integer getARLevelOfActivityID() {
    return this.aRLevelOfActivityID;
  }

  public void setARLevelOfActivityID(java.lang.Integer aRLevelOfActivityID) {
    this.aRLevelOfActivityID = aRLevelOfActivityID;
  }

  private java.lang.Boolean active;

  public java.lang.Boolean getActive() {
    return this.active;
  }

  public void setActive(java.lang.Boolean active) {
    this.active = active;
  }

  private java.util.Calendar completedDate;

  public java.util.Calendar getCompletedDate() {
    return this.completedDate;
  }

  public void setCompletedDate(java.util.Calendar completedDate) {
    this.completedDate = completedDate;
  }

  private java.lang.String firstName;

  public java.lang.String getFirstName() {
    return this.firstName;
  }

  public void setFirstName(java.lang.String firstName) {
    this.firstName = firstName;
  }

  private java.lang.String imprint;

  public java.lang.String getImprint() {
    return this.imprint;
  }

  public void setImprint(java.lang.String imprint) {
    this.imprint = imprint;
  }

  private java.util.Calendar initiatedDate;

  public java.util.Calendar getInitiatedDate() {
    return this.initiatedDate;
  }

  public void setInitiatedDate(java.util.Calendar initiatedDate) {
    this.initiatedDate = initiatedDate;
  }

  private java.lang.String jDEProjectNumber;

  public java.lang.String getJDEProjectNumber() {
    return this.jDEProjectNumber;
  }

  public void setJDEProjectNumber(java.lang.String jDEProjectNumber) {
    this.jDEProjectNumber = jDEProjectNumber;
  }

  private java.lang.Integer labelID;

  public java.lang.Integer getLabelID() {
    return this.labelID;
  }

  public void setLabelID(java.lang.Integer labelID) {
    this.labelID = labelID;
  }

  private java.lang.String lastName;

  public java.lang.String getLastName() {
    return this.lastName;
  }

  public void setLastName(java.lang.String lastName) {
    this.lastName = lastName;
  }

  private java.lang.String name;

  public java.lang.String getName() {
    return this.name;
  }

  public void setName(java.lang.String name) {
    this.name = name;
  }

  private java.lang.Integer projectID;

  public java.lang.Integer getProjectID() {
    return this.projectID;
  }

  public void setProjectID(java.lang.Integer projectID) {
    this.projectID = projectID;
  }

  private java.lang.String rMSProjectNumber;

  public java.lang.String getRMSProjectNumber() {
    return this.rMSProjectNumber;
  }

  public void setRMSProjectNumber(java.lang.String rMSProjectNumber) {
    this.rMSProjectNumber = rMSProjectNumber;
  }

  private java.lang.String serviceException;

  public java.lang.String getServiceException() {
    return this.serviceException;
  }

  public void setServiceException(java.lang.String serviceException) {
    this.serviceException = serviceException;
  }

  private java.lang.String title;

  public java.lang.String getTitle() {
    return this.title;
  }

  public void setTitle(java.lang.String title) {
    this.title = title;
  }

}
