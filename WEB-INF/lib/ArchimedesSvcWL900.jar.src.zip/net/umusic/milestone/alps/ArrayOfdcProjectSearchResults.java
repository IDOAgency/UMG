/**
 * Generated from schema type t=ArrayOfdcProjectSearchResults@http://alps.milestone.umusic.net/
 */
package net.umusic.milestone.alps;

public class ArrayOfdcProjectSearchResults implements java.io.Serializable {

  private net.umusic.milestone.alps.DcProjectSearchResults[] dcProjectSearchResults;

  public net.umusic.milestone.alps.DcProjectSearchResults[] getDcProjectSearchResults() {
    return this.dcProjectSearchResults;
  }

  public void setDcProjectSearchResults(net.umusic.milestone.alps.DcProjectSearchResults[] dcProjectSearchResults) {
    this.dcProjectSearchResults = dcProjectSearchResults;
  }

}
