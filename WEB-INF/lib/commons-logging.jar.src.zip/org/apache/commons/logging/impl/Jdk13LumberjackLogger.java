/*     */ package org.apache.commons.logging.impl;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringWriter;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogRecord;
/*     */ import java.util.logging.Logger;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jdk13LumberjackLogger
/*     */   implements Log, Serializable
/*     */ {
/*     */   protected Logger logger;
/*     */   protected String name;
/*     */   private String sourceClassName;
/*     */   private String sourceMethodName;
/*     */   private boolean classAndMethodFound;
/*  68 */   protected static final Level dummyLevel = Level.FINE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jdk13LumberjackLogger(String name) {
/*     */     this.logger = null;
/*     */     this.name = null;
/*     */     this.sourceClassName = "unknown";
/*     */     this.sourceMethodName = "unknown";
/*     */     this.classAndMethodFound = false;
/*  80 */     this.name = name;
/*  81 */     this.logger = getLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void log(Level level, String msg, Throwable ex) {
/*  90 */     if (getLogger().isLoggable(level)) {
/*  91 */       LogRecord record = new LogRecord(level, msg);
/*  92 */       if (!this.classAndMethodFound) {
/*  93 */         getClassAndMethod();
/*     */       }
/*  95 */       record.setSourceClassName(this.sourceClassName);
/*  96 */       record.setSourceMethodName(this.sourceMethodName);
/*  97 */       if (ex != null) {
/*  98 */         record.setThrown(ex);
/*     */       }
/* 100 */       getLogger().log(record);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getClassAndMethod() {
/*     */     try {
/* 110 */       Throwable throwable = new Throwable();
/* 111 */       throwable.fillInStackTrace();
/* 112 */       StringWriter stringWriter = new StringWriter();
/* 113 */       PrintWriter printWriter = new PrintWriter(stringWriter);
/* 114 */       throwable.printStackTrace(printWriter);
/* 115 */       String traceString = stringWriter.getBuffer().toString();
/* 116 */       StringTokenizer tokenizer = new StringTokenizer(traceString, "\n");
/*     */       
/* 118 */       tokenizer.nextToken();
/* 119 */       String line = tokenizer.nextToken();
/* 120 */       while (line.indexOf(getClass().getName()) == -1) {
/* 121 */         line = tokenizer.nextToken();
/*     */       }
/* 123 */       while (line.indexOf(getClass().getName()) >= 0) {
/* 124 */         line = tokenizer.nextToken();
/*     */       }
/* 126 */       int start = line.indexOf("at ") + 3;
/* 127 */       int end = line.indexOf('(');
/* 128 */       String temp = line.substring(start, end);
/* 129 */       int lastPeriod = temp.lastIndexOf('.');
/* 130 */       this.sourceClassName = temp.substring(0, lastPeriod);
/* 131 */       this.sourceMethodName = temp.substring(lastPeriod + 1);
/* 132 */     } catch (Exception ex) {}
/*     */ 
/*     */     
/* 135 */     this.classAndMethodFound = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public void debug(Object message) { log(Level.FINE, String.valueOf(message), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   public void debug(Object message, Throwable exception) { log(Level.FINE, String.valueOf(message), exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   public void error(Object message) { log(Level.SEVERE, String.valueOf(message), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public void error(Object message, Throwable exception) { log(Level.SEVERE, String.valueOf(message), exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   public void fatal(Object message) { log(Level.SEVERE, String.valueOf(message), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   public void fatal(Object message, Throwable exception) { log(Level.SEVERE, String.valueOf(message), exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Logger getLogger() {
/* 211 */     if (this.logger == null) {
/* 212 */       this.logger = Logger.getLogger(this.name);
/*     */     }
/* 214 */     return this.logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public void info(Object message) { log(Level.INFO, String.valueOf(message), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 237 */   public void info(Object message, Throwable exception) { log(Level.INFO, String.valueOf(message), exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 245 */   public boolean isDebugEnabled() { return getLogger().isLoggable(Level.FINE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 253 */   public boolean isErrorEnabled() { return getLogger().isLoggable(Level.SEVERE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 261 */   public boolean isFatalEnabled() { return getLogger().isLoggable(Level.SEVERE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 269 */   public boolean isInfoEnabled() { return getLogger().isLoggable(Level.INFO); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 277 */   public boolean isTraceEnabled() { return getLogger().isLoggable(Level.FINEST); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 285 */   public boolean isWarnEnabled() { return getLogger().isLoggable(Level.WARNING); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 296 */   public void trace(Object message) { log(Level.FINEST, String.valueOf(message), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 308 */   public void trace(Object message, Throwable exception) { log(Level.FINEST, String.valueOf(message), exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 319 */   public void warn(Object message) { log(Level.WARNING, String.valueOf(message), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 331 */   public void warn(Object message, Throwable exception) { log(Level.WARNING, String.valueOf(message), exception); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\commons-logging.jar!\org\apache\commons\logging\impl\Jdk13LumberjackLogger.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */