/*     */ package org.apache.commons.logging.impl;
/*     */ 
/*     */ import org.apache.avalon.framework.logger.Logger;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AvalonLogger
/*     */   implements Log
/*     */ {
/*  58 */   private static Logger defaultLogger = null;
/*     */   public AvalonLogger(Logger logger) {
/*  60 */     this.logger = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   
/*     */   private Logger logger;
/*     */ 
/*     */   
/*     */   public AvalonLogger(String name) {
/*     */     this.logger = null;
/*  77 */     if (defaultLogger == null)
/*  78 */       throw new NullPointerException("default logger has to be specified if this constructor is used!"); 
/*  79 */     this.logger = defaultLogger.getChildLogger(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public Logger getLogger() { return this.logger; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public static void setDefaultLogger(Logger logger) { defaultLogger = logger; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public void debug(Object message, Throwable t) { if (getLogger().isDebugEnabled()) getLogger().debug(String.valueOf(message), t);
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public void debug(Object message) { if (getLogger().isDebugEnabled()) getLogger().debug(String.valueOf(message));
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public void error(Object message, Throwable t) { if (getLogger().isErrorEnabled()) getLogger().error(String.valueOf(message), t);
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   public void error(Object message) { if (getLogger().isErrorEnabled()) getLogger().error(String.valueOf(message));
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public void fatal(Object message, Throwable t) { if (getLogger().isFatalErrorEnabled()) getLogger().fatalError(String.valueOf(message), t);
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public void fatal(Object message) { if (getLogger().isFatalErrorEnabled()) getLogger().fatalError(String.valueOf(message));
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   public void info(Object message, Throwable t) { if (getLogger().isInfoEnabled()) getLogger().info(String.valueOf(message), t);
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 189 */   public void info(Object message) { if (getLogger().isInfoEnabled()) getLogger().info(String.valueOf(message));
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   public boolean isDebugEnabled() { return getLogger().isDebugEnabled(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 207 */   public boolean isErrorEnabled() { return getLogger().isErrorEnabled(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 216 */   public boolean isFatalEnabled() { return getLogger().isFatalErrorEnabled(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public boolean isInfoEnabled() { return getLogger().isInfoEnabled(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 234 */   public boolean isTraceEnabled() { return getLogger().isDebugEnabled(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 243 */   public boolean isWarnEnabled() { return getLogger().isWarnEnabled(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 255 */   public void trace(Object message, Throwable t) { if (getLogger().isDebugEnabled()) getLogger().debug(String.valueOf(message), t);
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 266 */   public void trace(Object message) { if (getLogger().isDebugEnabled()) getLogger().debug(String.valueOf(message));
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 278 */   public void warn(Object message, Throwable t) { if (getLogger().isWarnEnabled()) getLogger().warn(String.valueOf(message), t);
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 289 */   public void warn(Object message) { if (getLogger().isWarnEnabled()) getLogger().warn(String.valueOf(message));  }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\commons-logging.jar!\org\apache\commons\logging\impl\AvalonLogger.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */