/*     */ package org.apache.commons.logging.impl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.Priority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Log4JLogger
/*     */   implements Log, Serializable
/*     */ {
/*  55 */   private static final String FQCN = Log4JLogger.class.getName();
/*     */ 
/*     */   
/*  58 */   private Logger logger = null;
/*     */ 
/*     */   
/*  61 */   private String name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Priority traceLevel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static  {
/*  80 */     if (!Priority.class.isAssignableFrom(org.apache.log4j.Level.class))
/*     */     {
/*  82 */       throw new InstantiationError("Log4J 1.2 not available");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  90 */       traceLevel = (Priority)org.apache.log4j.Level.class.getDeclaredField("TRACE").get(null);
/*  91 */     } catch (Exception ex) {
/*     */       
/*  93 */       traceLevel = Priority.DEBUG;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Log4JLogger(String name) {
/* 108 */     this.name = name;
/* 109 */     this.logger = getLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Log4JLogger(Logger logger) {
/* 116 */     if (logger == null) {
/* 117 */       throw new IllegalArgumentException("Warning - null logger in constructor; possible log4j misconfiguration.");
/*     */     }
/*     */     
/* 120 */     this.name = logger.getName();
/* 121 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public void trace(Object message) { getLogger().log(FQCN, traceLevel, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public void trace(Object message, Throwable t) { getLogger().log(FQCN, traceLevel, message, t); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 177 */   public void debug(Object message) { getLogger().log(FQCN, Priority.DEBUG, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   public void debug(Object message, Throwable t) { getLogger().log(FQCN, Priority.DEBUG, message, t); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 199 */   public void info(Object message) { getLogger().log(FQCN, Priority.INFO, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 211 */   public void info(Object message, Throwable t) { getLogger().log(FQCN, Priority.INFO, message, t); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 222 */   public void warn(Object message) { getLogger().log(FQCN, Priority.WARN, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 234 */   public void warn(Object message, Throwable t) { getLogger().log(FQCN, Priority.WARN, message, t); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 245 */   public void error(Object message) { getLogger().log(FQCN, Priority.ERROR, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 257 */   public void error(Object message, Throwable t) { getLogger().log(FQCN, Priority.ERROR, message, t); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 268 */   public void fatal(Object message) { getLogger().log(FQCN, Priority.FATAL, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 280 */   public void fatal(Object message, Throwable t) { getLogger().log(FQCN, Priority.FATAL, message, t); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Logger getLogger() {
/* 288 */     if (this.logger == null) {
/* 289 */       this.logger = Logger.getLogger(this.name);
/*     */     }
/* 291 */     return this.logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 299 */   public boolean isDebugEnabled() { return getLogger().isDebugEnabled(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 307 */   public boolean isErrorEnabled() { return getLogger().isEnabledFor(Priority.ERROR); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 315 */   public boolean isFatalEnabled() { return getLogger().isEnabledFor(Priority.FATAL); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 323 */   public boolean isInfoEnabled() { return getLogger().isInfoEnabled(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 333 */   public boolean isTraceEnabled() { return getLogger().isEnabledFor(traceLevel); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 340 */   public boolean isWarnEnabled() { return getLogger().isEnabledFor(Priority.WARN); }
/*     */   
/*     */   public Log4JLogger() {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\commons-logging.jar!\org\apache\commons\logging\impl\Log4JLogger.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */