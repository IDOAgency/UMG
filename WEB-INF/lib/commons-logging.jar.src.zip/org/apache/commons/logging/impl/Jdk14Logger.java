/*     */ package org.apache.commons.logging.impl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jdk14Logger
/*     */   implements Log, Serializable
/*     */ {
/*  48 */   protected static final Level dummyLevel = Level.FINE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Logger logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jdk14Logger(String name) {
/*  72 */     this.logger = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     this.name = null;
/*     */     this.name = name;
/*     */     this.logger = getLogger();
/*     */   }
/*     */ 
/*     */   
/*     */   private void log(Level level, String msg, Throwable ex) {
/*  85 */     Logger logger = getLogger();
/*  86 */     if (logger.isLoggable(level)) {
/*     */       
/*  88 */       Throwable dummyException = new Throwable();
/*  89 */       StackTraceElement[] locations = dummyException.getStackTrace();
/*     */       
/*  91 */       String cname = "unknown";
/*  92 */       String method = "unknown";
/*  93 */       if (locations != null && locations.length > 2) {
/*  94 */         StackTraceElement caller = locations[2];
/*  95 */         cname = caller.getClassName();
/*  96 */         method = caller.getMethodName();
/*     */       } 
/*  98 */       if (ex == null) {
/*  99 */         logger.logp(level, cname, method, msg);
/*     */       } else {
/* 101 */         logger.logp(level, cname, method, msg, ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public void debug(Object message) { log(Level.FINE, String.valueOf(message), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public void debug(Object message, Throwable exception) { log(Level.FINE, String.valueOf(message), exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public void error(Object message) { log(Level.SEVERE, String.valueOf(message), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public void error(Object message, Throwable exception) { log(Level.SEVERE, String.valueOf(message), exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   public void fatal(Object message) { log(Level.SEVERE, String.valueOf(message), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   public void fatal(Object message, Throwable exception) { log(Level.SEVERE, String.valueOf(message), exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Logger getLogger() {
/* 180 */     if (this.logger == null) {
/* 181 */       this.logger = Logger.getLogger(this.name);
/*     */     }
/* 183 */     return this.logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public void info(Object message) { log(Level.INFO, String.valueOf(message), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 206 */   public void info(Object message, Throwable exception) { log(Level.INFO, String.valueOf(message), exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 214 */   public boolean isDebugEnabled() { return getLogger().isLoggable(Level.FINE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 222 */   public boolean isErrorEnabled() { return getLogger().isLoggable(Level.SEVERE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 230 */   public boolean isFatalEnabled() { return getLogger().isLoggable(Level.SEVERE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 238 */   public boolean isInfoEnabled() { return getLogger().isLoggable(Level.INFO); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 246 */   public boolean isTraceEnabled() { return getLogger().isLoggable(Level.FINEST); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   public boolean isWarnEnabled() { return getLogger().isLoggable(Level.WARNING); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 265 */   public void trace(Object message) { log(Level.FINEST, String.valueOf(message), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 277 */   public void trace(Object message, Throwable exception) { log(Level.FINEST, String.valueOf(message), exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 288 */   public void warn(Object message) { log(Level.WARNING, String.valueOf(message), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   public void warn(Object message, Throwable exception) { log(Level.WARNING, String.valueOf(message), exception); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\commons-logging.jar!\org\apache\commons\logging\impl\Jdk14Logger.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */