/*     */ package org.apache.commons.logging.impl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoOpLog
/*     */   implements Log, Serializable
/*     */ {
/*     */   public NoOpLog() {}
/*     */   
/*     */   public NoOpLog(String name) {}
/*     */   
/*     */   public void trace(Object message) {}
/*     */   
/*     */   public void trace(Object message, Throwable t) {}
/*     */   
/*     */   public void debug(Object message) {}
/*     */   
/*     */   public void debug(Object message, Throwable t) {}
/*     */   
/*     */   public void info(Object message) {}
/*     */   
/*     */   public void info(Object message, Throwable t) {}
/*     */   
/*     */   public void warn(Object message) {}
/*     */   
/*     */   public void warn(Object message, Throwable t) {}
/*     */   
/*     */   public void error(Object message) {}
/*     */   
/*     */   public void error(Object message, Throwable t) {}
/*     */   
/*     */   public void fatal(Object message) {}
/*     */   
/*     */   public void fatal(Object message, Throwable t) {}
/*     */   
/*  70 */   public final boolean isDebugEnabled() { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public final boolean isErrorEnabled() { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public final boolean isFatalEnabled() { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public final boolean isInfoEnabled() { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public final boolean isTraceEnabled() { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public final boolean isWarnEnabled() { return false; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\commons-logging.jar!\org\apache\commons\logging\impl\NoOpLog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */