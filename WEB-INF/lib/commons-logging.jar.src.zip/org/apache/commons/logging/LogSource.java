/*     */ package org.apache.commons.logging;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Hashtable;
/*     */ import org.apache.commons.logging.impl.NoOpLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogSource
/*     */ {
/*     */   protected static Hashtable logs;
/*     */   protected static boolean log4jIsAvailable;
/*     */   protected static boolean jdk14IsAvailable;
/*     */   protected static Constructor logImplctor;
/*     */   
/*     */   static  {
/*     */     String str;
/*  62 */     logs = new Hashtable();
/*     */ 
/*     */     
/*  65 */     log4jIsAvailable = false;
/*     */ 
/*     */     
/*  68 */     jdk14IsAvailable = false;
/*     */ 
/*     */     
/*  71 */     logImplctor = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  80 */       if (null != Class.forName("org.apache.log4j.Logger")) {
/*  81 */         log4jIsAvailable = true;
/*     */       } else {
/*  83 */         log4jIsAvailable = false;
/*     */       } 
/*  85 */     } catch (Throwable t) {
/*  86 */       log4jIsAvailable = false;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/*  91 */       if (null != Class.forName("java.util.logging.Logger") && null != Class.forName("org.apache.commons.logging.impl.Jdk14Logger")) {
/*     */         
/*  93 */         jdk14IsAvailable = true;
/*     */       } else {
/*  95 */         jdk14IsAvailable = false;
/*     */       } 
/*  97 */     } catch (Throwable t) {
/*  98 */       jdk14IsAvailable = false;
/*     */     } 
/*     */ 
/*     */     
/* 102 */     t = null;
/*     */     try {
/* 104 */       str = System.getProperty("org.apache.commons.logging.log");
/* 105 */       if (str == null) {
/* 106 */         str = System.getProperty("org.apache.commons.logging.Log");
/*     */       }
/* 108 */     } catch (Throwable t) {}
/*     */     
/* 110 */     if (str != null) {
/*     */       try {
/* 112 */         setLogImplementation(str);
/* 113 */       } catch (Throwable t) {
/*     */         try {
/* 115 */           setLogImplementation("org.apache.commons.logging.impl.NoOpLog");
/*     */         }
/* 117 */         catch (Throwable u) {}
/*     */       } 
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/* 123 */         if (log4jIsAvailable) {
/* 124 */           setLogImplementation("org.apache.commons.logging.impl.Log4JLogger");
/*     */         }
/* 126 */         else if (jdk14IsAvailable) {
/* 127 */           setLogImplementation("org.apache.commons.logging.impl.Jdk14Logger");
/*     */         } else {
/*     */           
/* 130 */           setLogImplementation("org.apache.commons.logging.impl.NoOpLog");
/*     */         }
/*     */       
/* 133 */       } catch (Throwable t) {
/*     */         try {
/* 135 */           setLogImplementation("org.apache.commons.logging.impl.NoOpLog");
/*     */         }
/* 137 */         catch (Throwable u) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setLogImplementation(String classname) throws LinkageError, ExceptionInInitializerError, NoSuchMethodException, SecurityException, ClassNotFoundException {
/*     */     try {
/* 169 */       Class logclass = Class.forName(classname);
/* 170 */       Class[] argtypes = new Class[1];
/* 171 */       argtypes[0] = "".getClass();
/* 172 */       logImplctor = logclass.getConstructor(argtypes);
/* 173 */     } catch (Throwable t) {
/* 174 */       logImplctor = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setLogImplementation(Class logclass) throws LinkageError, ExceptionInInitializerError, NoSuchMethodException, SecurityException {
/* 188 */     Class[] argtypes = new Class[1];
/* 189 */     argtypes[0] = "".getClass();
/* 190 */     logImplctor = logclass.getConstructor(argtypes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Log getInstance(String name) {
/* 196 */     Log log = (Log)logs.get(name);
/* 197 */     if (null == log) {
/* 198 */       log = makeNewLogInstance(name);
/* 199 */       logs.put(name, log);
/*     */     } 
/* 201 */     return log;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 207 */   public static Log getInstance(Class clazz) { return getInstance(clazz.getName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Log makeNewLogInstance(String name) {
/* 237 */     NoOpLog noOpLog = null;
/*     */     try {
/* 239 */       Object[] args = new Object[1];
/* 240 */       args[0] = name;
/* 241 */       noOpLog = (Log)logImplctor.newInstance(args);
/* 242 */     } catch (Throwable t) {
/* 243 */       noOpLog = null;
/*     */     } 
/* 245 */     if (null == noOpLog) {
/* 246 */       noOpLog = new NoOpLog(name);
/*     */     }
/* 248 */     return noOpLog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 258 */   public static String[] getLogNames() { return (String[])logs.keySet().toArray(new String[logs.size()]); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\commons-logging.jar!\org\apache\commons\logging\LogSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */