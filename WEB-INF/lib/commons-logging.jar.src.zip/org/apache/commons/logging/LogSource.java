package org.apache.commons.logging;

import java.lang.reflect.Constructor;
import java.util.Hashtable;
import org.apache.commons.logging.impl.NoOpLog;

public class LogSource {
  protected static Hashtable logs;
  
  protected static boolean log4jIsAvailable;
  
  protected static boolean jdk14IsAvailable;
  
  protected static Constructor logImplctor;
  
  static  {
    String str;
    logs = new Hashtable();
    log4jIsAvailable = false;
    jdk14IsAvailable = false;
    logImplctor = null;
    try {
      if (null != Class.forName("org.apache.log4j.Logger")) {
        log4jIsAvailable = true;
      } else {
        log4jIsAvailable = false;
      } 
    } catch (Throwable t) {
      log4jIsAvailable = false;
    } 
    try {
      if (null != Class.forName("java.util.logging.Logger") && null != Class.forName("org.apache.commons.logging.impl.Jdk14Logger")) {
        jdk14IsAvailable = true;
      } else {
        jdk14IsAvailable = false;
      } 
    } catch (Throwable t) {
      jdk14IsAvailable = false;
    } 
    t = null;
    try {
      str = System.getProperty("org.apache.commons.logging.log");
      if (str == null)
        str = System.getProperty("org.apache.commons.logging.Log"); 
    } catch (Throwable t) {}
    if (str != null) {
      try {
        setLogImplementation(str);
      } catch (Throwable t) {
        try {
          setLogImplementation("org.apache.commons.logging.impl.NoOpLog");
        } catch (Throwable u) {}
      } 
    } else {
      try {
        if (log4jIsAvailable) {
          setLogImplementation("org.apache.commons.logging.impl.Log4JLogger");
        } else if (jdk14IsAvailable) {
          setLogImplementation("org.apache.commons.logging.impl.Jdk14Logger");
        } else {
          setLogImplementation("org.apache.commons.logging.impl.NoOpLog");
        } 
      } catch (Throwable t) {
        try {
          setLogImplementation("org.apache.commons.logging.impl.NoOpLog");
        } catch (Throwable u) {}
      } 
    } 
  }
  
  public static void setLogImplementation(String classname) throws LinkageError, ExceptionInInitializerError, NoSuchMethodException, SecurityException, ClassNotFoundException {
    try {
      Class logclass = Class.forName(classname);
      Class[] argtypes = new Class[1];
      argtypes[0] = "".getClass();
      logImplctor = logclass.getConstructor(argtypes);
    } catch (Throwable t) {
      logImplctor = null;
    } 
  }
  
  public static void setLogImplementation(Class logclass) throws LinkageError, ExceptionInInitializerError, NoSuchMethodException, SecurityException {
    Class[] argtypes = new Class[1];
    argtypes[0] = "".getClass();
    logImplctor = logclass.getConstructor(argtypes);
  }
  
  public static Log getInstance(String name) {
    Log log = (Log)logs.get(name);
    if (null == log) {
      log = makeNewLogInstance(name);
      logs.put(name, log);
    } 
    return log;
  }
  
  public static Log getInstance(Class clazz) { return getInstance(clazz.getName()); }
  
  public static Log makeNewLogInstance(String name) {
    NoOpLog noOpLog = null;
    try {
      Object[] args = new Object[1];
      args[0] = name;
      noOpLog = (Log)logImplctor.newInstance(args);
    } catch (Throwable t) {
      noOpLog = null;
    } 
    if (null == noOpLog)
      noOpLog = new NoOpLog(name); 
    return noOpLog;
  }
  
  public static String[] getLogNames() { return (String[])logs.keySet().toArray(new String[logs.size()]); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\commons-logging.jar!\org\apache\commons\logging\LogSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */