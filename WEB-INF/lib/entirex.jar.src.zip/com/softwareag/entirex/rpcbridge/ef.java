package com.softwareag.entirex.rpcbridge;

public class ef extends Exception {
  public ef(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\ef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */