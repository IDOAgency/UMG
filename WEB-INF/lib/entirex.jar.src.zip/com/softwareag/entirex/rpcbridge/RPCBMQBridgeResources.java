package com.softwareag.entirex.rpcbridge;

public class RPCBMQBridgeResources extends d5 {
  protected String a() { return "RPCBMQBridge"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\RPCBMQBridgeResources.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */