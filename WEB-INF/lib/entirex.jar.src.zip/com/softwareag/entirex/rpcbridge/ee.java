package com.softwareag.entirex.rpcbridge;

class ee extends Exception {
  ee(String paramString1, String paramString2) { super("FormatBufferException: " + paramString2 + " (" + paramString1 + ")"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\ee.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */