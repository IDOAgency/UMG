package com.softwareag.entirex.rpcbridge;

class ec {
  private boolean a = false;
  
  private boolean b = false;
  
  private boolean c = false;
  
  private boolean d = false;
  
  private String e = "";
  
  boolean a() { return this.a; }
  
  ec() {}
  
  ec(String paramString) {
    int i = 0;
    int j = paramString.length();
    while (i < j) {
      switch (paramString.charAt(i++)) {
        case 'V':
          this.a = true;
        case 'U':
          this.b = true;
        case 'P':
          this.c = true;
        case 'A':
          this.d = true;
        case 'S':
          this.e = a(paramString, ++i);
          i += this.e.length();
      } 
    } 
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    if (this.a)
      stringBuffer.append('V'); 
    if (this.b)
      stringBuffer.append('U'); 
    if (this.c)
      stringBuffer.append('P'); 
    if (this.d)
      stringBuffer.append('A'); 
    if (this.e.length() > 0)
      stringBuffer.append("S=" + this.e); 
    return (stringBuffer.length() > 0) ? ('(' + stringBuffer.toString() + ')') : "";
  }
  
  String a(String paramString, int paramInt) {
    int i = paramString.indexOf(',', paramInt);
    if (i == -1)
      return null; 
    int j = Integer.parseInt(paramString.substring(paramInt, i));
    return paramString.substring(i + 1, i + j);
  }
  
  boolean b() { return this.c; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\ec.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */