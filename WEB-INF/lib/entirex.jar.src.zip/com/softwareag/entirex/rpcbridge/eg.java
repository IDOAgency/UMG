package com.softwareag.entirex.rpcbridge;

public class eg extends Exception {
  private Throwable a;
  
  private int b;
  
  public eg(int paramInt, Throwable paramThrowable) { this(paramInt, paramThrowable.toString(), paramThrowable); }
  
  public eg(int paramInt, String paramString) { this(paramInt, paramString, null); }
  
  public eg(int paramInt, String paramString, Throwable paramThrowable) {
    super(paramString);
    this.a = paramThrowable;
    this.b = paramInt;
  }
  
  public Throwable a() { return this.a; }
  
  public int b() { return this.b; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\eg.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */