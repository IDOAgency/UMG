package com.softwareag.entirex.rpcbridge;

class d9 {
  private ea a = new ea();
  
  private ea b = new ea();
  
  private int c = 0;
  
  static final int d = 1;
  
  static final int e = 2;
  
  static final int f = 3;
  
  d9(byte[] paramArrayOfByte) throws ee {
    ea ea1 = eb.a(new String(paramArrayOfByte));
    for (byte b1 = 0; b1 < ea1.b(); b1++) {
      ed ed = ea1.a(b1);
      if (ed.a())
        this.a.a(ed); 
      if (ed.b())
        try {
          this.b.a((ed)ed.clone());
        } catch (CloneNotSupportedException cloneNotSupportedException) {
          this.a.a(ed);
        }  
    } 
    if (!this.a.c()) {
      this.c++;
      this.a.a().k();
    } 
    if (!this.b.c()) {
      this.c += 2;
      this.b.a().k();
    } 
  }
  
  ea a() { return this.a; }
  
  ea b() { return this.b; }
  
  int c() { return this.c; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\d9.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */