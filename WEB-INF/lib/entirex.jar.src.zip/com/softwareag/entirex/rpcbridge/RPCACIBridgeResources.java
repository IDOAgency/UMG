package com.softwareag.entirex.rpcbridge;

public class RPCACIBridgeResources extends d5 {
  protected String a() { return "RPCACIBridge"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\RPCACIBridgeResources.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */