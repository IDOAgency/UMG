package com.softwareag.entirex.rpcbridge;

import com.softwareag.entirex.aci.c;
import com.softwareag.entirex.base.Command;
import java.util.Properties;

public interface aj {
  byte[] a(String paramString1, String paramString2, byte[] paramArrayOfByte) throws eg;
  
  void b(String paramString1, String paramString2, byte[] paramArrayOfByte) throws eg;
  
  byte[] a(String paramString1, String paramString2) throws eg;
  
  void b(String paramString1, String paramString2) throws eg;
  
  void c(String paramString1, String paramString2) throws eg;
  
  void d(String paramString1, String paramString2) throws eg;
  
  void d() throws eg;
  
  void e() throws eg;
  
  d8 a();
  
  void a(c paramc);
  
  void a(Properties paramProperties);
  
  Command[] b();
  
  void c() throws eg;
  
  String f();
  
  String m();
  
  String g();
  
  boolean h();
  
  d5 i();
  
  String j();
  
  boolean a(int paramInt);
  
  int k();
  
  String[][] l();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\aj.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */