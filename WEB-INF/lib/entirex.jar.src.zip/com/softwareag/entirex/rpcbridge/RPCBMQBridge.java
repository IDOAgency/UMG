package com.softwareag.entirex.rpcbridge;

import com.softwareag.entirex.aci.Broker;
import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.BrokerMessage;
import com.softwareag.entirex.aci.BrokerSecurity;
import com.softwareag.entirex.aci.BrokerService;
import com.softwareag.entirex.aci.EntireXSecurity;
import com.softwareag.entirex.aci.EntireXVersion;
import com.softwareag.entirex.aci.LocationTransparencyService;
import com.softwareag.entirex.aci.UnitofWork;
import com.softwareag.entirex.aci.c;
import com.softwareag.entirex.base.Command;
import java.util.Properties;
import java.util.ResourceBundle;

public class RPCBMQBridge implements aj {
  static final String a = "entirex.rpcbmqbridge.serveraddress";
  
  static final String b = "ACLASS/ASERVER/ASERVICE";
  
  static final String c = "entirex.rpcbmqbridge.brokerid";
  
  static final String d = "localhost";
  
  static final String e = "entirex.rpcbmqbridge.userid";
  
  static final String f = System.getProperty("user.name");
  
  static final String g = "entirex.rpcbmqbridge.password";
  
  static final String h = "entirex.rpcbmqbridge.marshalling";
  
  static final String i = "entirex.rpcbmqbridge.waittime";
  
  static final String j = "0S";
  
  static final String k = "entirex.rpcbmqbridge.properties";
  
  static final String l = "entirex.rpcbmqbridge.trace";
  
  static final String m = "entirex.rpcbmqbridge.compresslevel";
  
  static final String n = "0";
  
  static final String o = "entirex.rpcbmqbridge.security";
  
  static final String p = "";
  
  static final String q = "entirex.rpcbmqbridge.encryptionlevel";
  
  static final String r = "0";
  
  static final String s = "entirex.rpcbmqbridge.logicalbrokerid";
  
  static final String t = "";
  
  static final String u = "entirex.rpcbmqbridge.logicalservice";
  
  static final String v = "";
  
  static final String w = "entirex.rpcbmqbridge.logicalsetname";
  
  static final String x = "";
  
  static final String y = "1019";
  
  static final d5 z = (d5)ResourceBundle.getBundle("com.softwareag.entirex.rpcbridge.RPCBMQBridgeResources");
  
  private int[] aa = { 1110, 1120, 1130, 1140, 2000 };
  
  private Broker ab;
  
  private Broker ac;
  
  private BrokerService ad;
  
  private BrokerService ae;
  
  private UnitofWork af;
  
  private UnitofWork ag;
  
  private boolean ah = false;
  
  private String ai;
  
  private boolean aj = false;
  
  private boolean ak = false;
  
  private BrokerMessage al = new BrokerMessage();
  
  private c am;
  
  private boolean an;
  
  private static int ao = 0;
  
  private static final String ap = "Client";
  
  private static final String aq = "Server";
  
  static Class ar;
  
  public static void main(String[] paramArrayOfString) { ak.a((ar == null) ? (ar = class$("com.softwareag.entirex.rpcbridge.RPCBMQBridge")) : ar, paramArrayOfString); }
  
  public d8 a() { return null; }
  
  public void a(c paramc) { this.am = paramc; }
  
  public Command[] b() { return new Command[] { 
        new Command("-bmqserver", null, "entirex.rpcbmqbridge.serveraddress", 1, -1, "ACLASS/ASERVER/ASERVICE", "the server address for the BMQ,"), new Command("-bmqbroker", null, "entirex.rpcbmqbridge.brokerid", 1, -1, "localhost", "the ID of the broker for the BMQ,"), new Command("-bmquser", null, "entirex.rpcbmqbridge.userid", 1, -1, f, "the user ID for the BMQ,"), new Command("-bmqpassword", null, "entirex.rpcbmqbridge.password", 1, -1, "", "the password for the BMQ,"), new Command("-bmqtrace", null, "entirex.rpcbmqbridge.trace", 1, -1, "No", "the trace level for the BMQ side (values: yes, no),"), new Command("-bmqcompresslevel", null, "entirex.rpcbmqbridge.compresslevel", 1, -1, "0", "the compression level for the BMQ side,"), new Command("-bmqlogicalsetname", null, "entirex.rpcbmqbridge.logicalsetname", 1, -1, "", "the set name for logical names for the BMQ side,"), new Command("-bmqlogicalbrokerid", null, "entirex.rpcbmqbridge.logicalbrokerid", 1, -1, "", "the logical name for the broker for the BMQ side,"), new Command("-bmqlogicalservice", null, "entirex.rpcbmqbridge.logicalservice", 1, -1, "", "the logical name for the service for the BMQ side,"), new Command("-bmqsecurity", null, "entirex.rpcbmqbridge.security", 1, -1, "", "the security setting, values no, yes, auto, <name of BrokerSecurity object> for the BMQ side,"), 
        new Command("-bmqencryption", null, "entirex.rpcbmqbridge.encryptionlevel", 2, -1, "0", "the encryption level, values 0,1,2 for the BMQ side,"), new Command("-propertyfile", "-p", "entirex.server.properties", 1, -1, "entirex.rpcbmqbridge.properties", "the file name of the property file (default is 'entirex.server.properties'),") }; }
  
  public void a(Properties paramProperties) {
    paramProperties.put("entirex.rpcbmqbridge.waittime", "0S");
    paramProperties.put("entirex.rpcbmqbridge.marshalling", "");
  }
  
  public void c() { this.an = this.am.c("entirex.rpcbmqbridge.trace"); }
  
  public void d() {
    String str1 = this.am.d("entirex.rpcbmqbridge.userid");
    String str2 = this.am.d("entirex.rpcbmqbridge.logicalbrokerid");
    String str3 = this.am.d("entirex.rpcbmqbridge.logicalservice");
    String str4 = this.am.d("entirex.rpcbmqbridge.logicalsetname");
    String str5 = str1 + "Client" + ao;
    String str6 = str1 + "Server" + ao++;
    if (str3 != null && str3.length() > 0) {
      try {
        this.ad = LocationTransparencyService.lookupBrokerService(str3, str4);
        this.ab = this.ad.getBroker();
        this.ab.reconnect(str1, str5);
        this.ae = LocationTransparencyService.lookupBrokerService(str3, str4);
        this.ac = this.ae.getBroker();
        this.ac.reconnect(str1, str6);
      } catch (BrokerException brokerException) {
        System.out.println("Logical service not set: " + brokerException.toString());
      } 
    } else if (str2 != null && str2.length() > 0) {
      try {
        this.ab = LocationTransparencyService.lookupBroker(str2, str4);
        this.ab.reconnect(str1, str5);
        this.ac = LocationTransparencyService.lookupBroker(str2, str4);
        this.ac.reconnect(str1, str6);
        String str = this.am.d("entirex.rpcbmqbridge.serveraddress");
        this.ad = new BrokerService(this.ab, str);
        this.ae = new BrokerService(this.ac, str);
      } catch (BrokerException brokerException) {
        System.out.println("Logical broker not set: " + brokerException.toString());
      } 
    } else {
      String str7 = this.am.d("entirex.rpcbmqbridge.brokerid");
      if (str7.indexOf('?') != -1 && str7.toLowerCase().indexOf("poolsize=") == -1) {
        str7 = str7 + "&poolsize=" + this.am.k();
      } else if (str7.indexOf('?') == -1) {
        str7 = str7 + "?poolsize=" + this.am.k();
      } 
      this.ab = new Broker(str7 + "&client", str1, str5);
      this.ac = new Broker(str7 + "&server", str1, str6);
      String str8 = this.am.d("entirex.rpcbmqbridge.serveraddress");
      this.ad = new BrokerService(this.ab, str8);
      this.ae = new BrokerService(this.ac, str8);
    } 
    this.ae.setMaxReceiveLen(31000);
    this.ai = this.am.d("entirex.rpcbmqbridge.waittime");
  }
  
  private void n() {
    if (this.aj)
      return; 
    String str1 = this.am.d("entirex.rpcbmqbridge.password");
    String str2 = this.am.d("entirex.rpcbmqbridge.security");
    int i1 = this.am.b("entirex.rpcbmqbridge.encryptionlevel");
    if (str2.equals("") || str2.toLowerCase().startsWith("n")) {
      this.ab.logon();
    } else if (str2.equalsIgnoreCase("auto")) {
      this.ab.useEntireXSecurity(i1, true);
      this.ab.logon(str1);
    } else {
      try {
        BrokerSecurity brokerSecurity;
        if (str2.toLowerCase().startsWith("y")) {
          brokerSecurity = new EntireXSecurity();
        } else {
          brokerSecurity = (BrokerSecurity)Class.forName(str2).newInstance();
        } 
        this.ab.setSecurity(brokerSecurity, i1);
        this.ab.logon(str1);
      } catch (BrokerException brokerException) {
        throw brokerException;
      } catch (Exception exception) {
        System.out.println(exception);
        System.out.println("Illegal value for entirex.rpcbmqbridge.security = " + str2);
        System.exit(1);
      } 
    } 
    this.ab.setCompressionLevel(this.am.d("entirex.rpcbmqbridge.compresslevel"));
    this.aj = true;
  }
  
  private void o() {
    if (this.ak)
      return; 
    String str1 = this.am.d("entirex.rpcbmqbridge.password");
    String str2 = this.am.d("entirex.rpcbmqbridge.security");
    int i1 = this.am.b("entirex.rpcbmqbridge.encryptionlevel");
    if (str2.equals("") || str2.toLowerCase().startsWith("n")) {
      this.ac.logon();
    } else if (str2.equalsIgnoreCase("auto")) {
      this.ac.useEntireXSecurity(i1, true);
      this.ac.logon(str1);
    } else {
      try {
        BrokerSecurity brokerSecurity;
        if (str2.toLowerCase().startsWith("y")) {
          brokerSecurity = new EntireXSecurity();
        } else {
          brokerSecurity = (BrokerSecurity)Class.forName(str2).newInstance();
        } 
        this.ac.setSecurity(brokerSecurity, i1);
        this.ac.logon(str1);
      } catch (BrokerException brokerException) {
        throw brokerException;
      } catch (Exception exception) {
        System.out.println(exception);
        System.out.println("Illegal value for entirex.rpcbmqbridge.security = " + str2);
        System.exit(1);
      } 
    } 
    this.ac.setCompressionLevel(this.am.d("entirex.rpcbmqbridge.compresslevel"));
    this.ae.register();
    this.ak = true;
  }
  
  public byte[] a(String paramString1, String paramString2, byte[] paramArrayOfByte) throws eg { throw new eg(102, z.a("Bridge_17")); }
  
  public void b(String paramString1, String paramString2, byte[] paramArrayOfByte) throws eg { a(paramString1, paramString2, paramArrayOfByte, true); }
  
  private void a(String paramString1, String paramString2, byte[] paramArrayOfByte, boolean paramBoolean) throws eg {
    try {
      n();
      this.al.setMessage(paramArrayOfByte);
      if (!this.ah) {
        UnitofWork unitofWork = new UnitofWork(this.ad);
        unitofWork.sendCommit(this.al);
        unitofWork.endConversation();
      } else {
        if (this.af == null)
          this.af = new UnitofWork(this.ad); 
        this.af.send(this.al);
      } 
    } catch (BrokerException brokerException) {
      if (h())
        System.out.println(brokerException); 
      if (paramBoolean && (a(brokerException) || b(brokerException))) {
        this.aj = false;
        a(paramString1, paramString2, paramArrayOfByte, false);
      } else {
        throw new eg(2, brokerException);
      } 
    } 
  }
  
  public byte[] a(String paramString1, String paramString2) throws eg { return a(paramString1, paramString2, true); }
  
  private byte[] a(String paramString1, String paramString2, boolean paramBoolean) throws eg {
    byte[] arrayOfByte;
    try {
      o();
      if (!this.ah) {
        UnitofWork unitofWork = new UnitofWork(this.ae);
        arrayOfByte = unitofWork.receive(this.ai).getMessage();
        if (!unitofWork.getStatus().equals("RECV_ONLY")) {
          unitofWork.cancel();
          unitofWork.endConversation();
          throw new eg(105, z.a("Bridge_18"));
        } 
        unitofWork.commitEndConversation();
      } else if (this.ag == null) {
        BrokerMessage brokerMessage = UnitofWork.receiveAny(this.ae, this.ai);
        this.ag = brokerMessage.getUnitofWork();
        arrayOfByte = brokerMessage.getMessage();
      } else {
        arrayOfByte = this.ag.receive(this.ai).getMessage();
      } 
    } catch (BrokerException brokerException) {
      if (h())
        System.out.println(brokerException); 
      if (paramBoolean && (a(brokerException) || b(brokerException))) {
        this.ak = false;
        return a(paramString1, paramString2, false);
      } 
      if (c(brokerException))
        throw new eg(101, z.a("Bridge_19")); 
      if (brokerException.getErrorClass() == 74 && brokerException.getErrorCode() == 301) {
        eg eg = new eg(106, z.a("Bridge_20"));
        throw eg;
      } 
      if (brokerException.getErrorClass() == 3 && brokerException.getErrorCode() == 5) {
        this.ag = null;
        return a(paramString1, paramString2, paramBoolean);
      } 
      if (brokerException.getErrorClass() == 10 && brokerException.getErrorCode() == 50)
        throw new eg(107, z.a("Bridge_21")); 
      throw new eg(3, brokerException);
    } 
    return arrayOfByte;
  }
  
  public void b(String paramString1, String paramString2) throws eg { this.ah = true; }
  
  public void c(String paramString1, String paramString2) throws eg {
    try {
      if (this.af != null && this.af.getStatus() != null) {
        this.af.commitEndConversation();
        this.af = null;
      } 
      if (this.ag != null && this.ag.getStatus() != null) {
        this.ag.commitEndConversation();
        this.ag = null;
      } 
    } catch (BrokerException brokerException) {
      if (h())
        System.out.println(brokerException); 
      this.ah = false;
      throw new eg(103, brokerException);
    } 
    this.ah = false;
  }
  
  public void d(String paramString1, String paramString2) throws eg {
    try {
      if (this.af != null && this.af.getStatus() != null) {
        this.af.backout();
        this.af = null;
      } 
      if (this.ag != null && this.ag.getStatus() != null) {
        this.ag.backout();
        this.ag = null;
      } 
    } catch (BrokerException brokerException) {
      if (h())
        System.out.println(brokerException); 
      this.ah = false;
      throw new eg(104, brokerException);
    } 
    this.ah = false;
  }
  
  public void e() {
    try {
      if (this.aj) {
        this.ab.logoff();
        this.aj = false;
      } 
      if (this.ak) {
        this.ae.deregister();
        this.ac.logoff();
        this.ak = false;
      } 
    } catch (BrokerException brokerException) {
      if (h())
        System.out.println(brokerException); 
      throw new eg(4, brokerException);
    } 
  }
  
  private static boolean a(BrokerException paramBrokerException) { return ((paramBrokerException.getErrorClass() == 20 && paramBrokerException.getErrorCode() == 134) || (paramBrokerException.getErrorClass() == 2 && paramBrokerException.getErrorCode() == 2)); }
  
  private static boolean b(BrokerException paramBrokerException) { return (paramBrokerException.getErrorClass() == 13 && paramBrokerException.getErrorCode() == 313); }
  
  private static boolean c(BrokerException paramBrokerException) { return ((paramBrokerException.getErrorClass() == 3 && paramBrokerException.getErrorCode() == 3) || (paramBrokerException.getErrorClass() == 74 && paramBrokerException.getErrorCode() == 74) || (paramBrokerException.getErrorClass() == 74 && paramBrokerException.getErrorCode() == 300)); }
  
  public String f() { return (new EntireXVersion("Java RPCBMQBridge")).getVersionString(); }
  
  public String g() { return "entirex.rpcbmqbridge.properties"; }
  
  public boolean h() { return this.an; }
  
  public d5 i() { return z; }
  
  public String j() { return "1019"; }
  
  public int k() {
    int i1 = this.aa[0];
    for (byte b1 = 1; b1 < this.aa.length; b1++)
      i1 = Math.max(i1, this.aa[b1]); 
    return i1;
  }
  
  public boolean a(int paramInt) {
    boolean bool = false;
    for (byte b1 = 0; b1 < this.aa.length; b1++) {
      if (paramInt == this.aa[b1]) {
        bool = true;
        break;
      } 
    } 
    return bool;
  }
  
  public String[][] l() { return new String[][] { { "Target UOW Service", this.am.d("entirex.rpcbmqbridge.serveraddress") }, { "Target UOW Broker", this.am.d("entirex.rpcbmqbridge.brokerid") }, { "Target wait time", this.am.d("entirex.rpcbmqbridge.waittime") }, { "Target UOW Broker user ID", this.am.d("entirex.rpcbmqbridge.userid") }, { "Target UOW Broker password", this.am.d("entirex.rpcbmqbridge.password") }, { "Marshalling", this.am.d("entirex.rpcbmqbridge.marshalling") }, { "Target trace level", this.am.d("entirex.rpcbmqbridge.trace") } }; }
  
  public String m() { return "EntireX RPC BMQ Bridge"; }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\RPCBMQBridge.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */