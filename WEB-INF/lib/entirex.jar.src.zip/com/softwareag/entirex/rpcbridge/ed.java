package com.softwareag.entirex.rpcbridge;

class ed implements Cloneable {
  public static final int a = 0;
  
  public static final int b = 1;
  
  public static final int c = 2;
  
  public static final int d = 3;
  
  public static final int e = 4;
  
  public static final int f = 5;
  
  public static final int g = 6;
  
  public static final int h = 7;
  
  public static final int i = 8;
  
  public static final int j = 9;
  
  public static final int k = 10;
  
  public static final int l = 11;
  
  public static final int m = 12;
  
  public static final int n = 13;
  
  public static final int o = 14;
  
  public static final int p = 15;
  
  public static final int q = 16;
  
  public static final int r = 17;
  
  private char s;
  
  private char t;
  
  private ec u;
  
  private int v;
  
  private int w;
  
  private int x;
  
  private int y;
  
  private int z;
  
  private int aa;
  
  private ea ab;
  
  private boolean ac = false;
  
  ed(char paramChar1, char paramChar2, ec paramec, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    this.s = paramChar1;
    this.t = paramChar2;
    this.u = paramec;
    this.v = paramInt1;
    this.w = paramInt2;
    this.x = paramInt3;
    this.y = paramInt4;
    this.z = paramInt5;
    this.aa = n();
    if (this.aa == 16)
      this.ab = new ea(); 
  }
  
  boolean a() { return (this.s == 'O' || this.s == 'M'); }
  
  boolean b() { return (this.s == 'S' || this.s == 'M'); }
  
  int c() { return this.aa; }
  
  boolean d() { return (this.aa == 0 || this.aa == 1 || this.aa == 2 || this.aa == 3); }
  
  int e() { return this.v; }
  
  int f() { return this.v; }
  
  int g() { return this.w; }
  
  int h() { return (this.x == 0) ? 1 : ((this.y == 0) ? this.x : ((this.z == 0) ? (this.x * this.y) : (this.x * this.y * this.z))); }
  
  boolean i() { return (this.x == 0 && this.aa != 16 && this.aa != 17); }
  
  boolean j() { return this.ac; }
  
  void k() { this.ac = true; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(this.s);
    stringBuffer.append(this.t);
    stringBuffer.append(this.u.toString());
    stringBuffer.append(Integer.toString(this.v));
    stringBuffer.append(',');
    stringBuffer.append(Integer.toString(this.w));
    if (this.x != 0) {
      stringBuffer.append(',');
      stringBuffer.append(Integer.toString(this.x));
    } 
    if (this.y != 0) {
      stringBuffer.append(',');
      stringBuffer.append(Integer.toString(this.y));
    } 
    if (this.z != 0) {
      stringBuffer.append(',');
      stringBuffer.append(Integer.toString(this.z));
    } 
    return stringBuffer.toString();
  }
  
  private int n() {
    switch (this.t) {
      case 'A':
        return this.u.a() ? 1 : 0;
      case 'K':
        return this.u.a() ? 3 : 2;
      case 'B':
        return this.u.a() ? 5 : 4;
      case 'N':
        return 7;
      case 'P':
        return 6;
      case 'I':
        switch (this.v) {
          case 1:
            return 8;
          case 2:
            return 9;
          case 4:
            return 10;
        } 
        throw new IllegalArgumentException("Illegal len1 (I) '" + this.v + "'");
      case 'F':
        switch (this.v) {
          case 4:
            return 11;
          case 8:
            return 12;
        } 
        throw new IllegalArgumentException("Illegal len1 (F) '" + this.v + "'");
      case 'D':
        return 13;
      case 'T':
        return 14;
      case 'L':
        return 15;
      case 'G':
        return (this.w == 0) ? 17 : 16;
    } 
    throw new IllegalArgumentException("Illegal type '" + this.aa + "'");
  }
  
  void a(ed paramed) { this.ab.a(paramed); }
  
  ea l() { return this.ab; }
  
  boolean m() { return this.u.b(); }
  
  public Object clone() throws CloneNotSupportedException { return super.clone(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\ed.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */