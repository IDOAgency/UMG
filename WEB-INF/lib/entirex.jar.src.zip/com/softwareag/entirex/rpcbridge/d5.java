package com.softwareag.entirex.rpcbridge;

import java.text.MessageFormat;
import java.util.ListResourceBundle;
import java.util.MissingResourceException;

public class d5 extends ListResourceBundle {
  static final Object[][] a = { 
      { "Bridge_01", "{0}: setRequest: unexpected state " }, { "Bridge_02", "{0}: Compression=off not possible." }, { "Bridge_03", "{0}: Request valuebuffer: \"" }, { "Bridge_04", "{0}: unsupported command " }, { "Bridge_05", "{0}: Compression=off not possible." }, { "Bridge_06", "{0}: unsupported call type " }, { "Bridge_07", "{0}: Response valuebuffer: \"" }, { "Bridge_08", "{0}: createResponse: illegal state " }, { "Bridge_09", "{0}: getResponse: illegal state " }, { "Bridge_10", "{0}: getForwardMessage: illegal state " }, 
      { "Bridge_11", "{0}: getAction: illegal state " }, { "Bridge_12", "{0}: process request and reply: illegal action " }, { "Bridge_13", "{0}: message received from server does not fit buffer" }, { "Bridge_14", "{0}: transformation error on reply: " }, { "Bridge_15", "{0}: transformation error on request: " }, { "Bridge_16", "{0}: type of marshaling not allowed." }, { "Bridge_17", "{0}: mixture of IN and OUT parameters not possible." }, { "Bridge_18", "{0}: trying to read an UOW with multiple messages." }, { "Bridge_19", "{0}: No UnitofWork available." }, { "Bridge_20", "{0}: End of UnitofWork reached." }, 
      { "Bridge_21", "{0}: Shutdown IMMED required requested." } };
  
  public Object[][] getContents() { return a; }
  
  public String a(String paramString) { return a(paramString, null); }
  
  public String a(String paramString, Object[] paramArrayOfObject) {
    String str;
    try {
      boolean bool = (paramArrayOfObject == null) ? 1 : (paramArrayOfObject.length + 1);
      Object[] arrayOfObject = new Object[bool];
      arrayOfObject[0] = a();
      if (paramArrayOfObject != null)
        System.arraycopy(paramArrayOfObject, 0, arrayOfObject, 1, paramArrayOfObject.length); 
      str = getString(paramString);
      str = MessageFormat.format(str, arrayOfObject);
    } catch (NullPointerException nullPointerException) {
      str = "Key is null, " + nullPointerException.toString();
    } catch (MissingResourceException missingResourceException) {
      str = "Resource is missing, " + missingResourceException.toString();
    } catch (ClassCastException classCastException) {
      str = "Got no message, " + classCastException.toString();
    } 
    return str;
  }
  
  protected String a() { return "Bridge"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\d5.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */