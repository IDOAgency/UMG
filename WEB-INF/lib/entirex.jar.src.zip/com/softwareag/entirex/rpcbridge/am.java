package com.softwareag.entirex.rpcbridge;

import com.softwareag.entirex.aci.ao;
import com.softwareag.entirex.aci.be;

class am {
  private static final int a = 0;
  
  public static final int b = 1;
  
  public static final int c = 2;
  
  private static final int d = 3;
  
  public static final int e = 4;
  
  public static final int f = 5;
  
  private static final int g = 6;
  
  public static final int h = 7;
  
  public static final int i = 8;
  
  private int j = 0;
  
  private int k = 6;
  
  private ao l;
  
  private ao m;
  
  private byte[] n;
  
  private int o;
  
  private d9 p;
  
  private String q;
  
  private String r;
  
  private String s;
  
  private Integer t = new Integer(5);
  
  private an u = new an();
  
  private boolean v;
  
  private aj w;
  
  private String x;
  
  private d5 y;
  
  am(aj paramaj) {
    this.x = paramaj.f();
    this.y = paramaj.i();
    this.w = paramaj;
    ao.b(this.x);
  }
  
  void a() {
    this.j = 0;
    this.l = null;
    this.m = null;
    this.n = null;
  }
  
  void a(byte[] paramArrayOfByte) throws IllegalStateException {
    if (this.j != 0)
      throw new IllegalStateException(this.y.a("Bridge_01") + this.j); 
    this.o = 1110;
    try {
      String str;
      this.m = new ao(paramArrayOfByte);
      this.r = this.m.r();
      this.q = this.m.s();
      this.s = this.m.t();
      int i1 = this.m.v();
      if (i1 != this.t.intValue())
        this.t = new Integer(i1); 
      this.o = this.m.e();
      if (this.q.equals("SAGXLERR")) {
        this.j = 1;
        this.l = c(this.u.e());
        return;
      } 
      this.u.a();
      switch (i1) {
        case 7:
          this.l = ao.b(this.w.k());
          this.j = 1;
          return;
        case 2:
        case 5:
          if (this.w.a(this.o)) {
            this.n = this.m.c();
            if (this.m.y() == 0) {
              this.l = b(this.w.j(), "0010", this.y.a("Bridge_02"));
              this.j = 4;
            } else {
              this.p = new d9(this.m.b());
              if (j())
                System.out.println(this.y.a("Bridge_03") + new String(this.n) + '"'); 
              this.j = 2;
            } 
          } else {
            this.l = b(this.w.j(), "0011", this.y.a("Bridge_16"));
            this.j = 4;
          } 
          return;
        case 6:
          this.j = 1;
          str = this.m.ab();
          if (str.startsWith("PING")) {
            String str1 = this.x + " " + System.getProperty("os.name") + " " + System.getProperty("os.version") + " " + System.getProperty("os.arch") + ".";
            this.l = this.m.m(str1);
          } else {
            this.j = 4;
            this.l = b("0022", "0", this.y.a("Bridge_04") + i1);
          } 
          return;
        case 1:
          if (this.w.a(this.o)) {
            this.j = 5;
            this.n = this.m.c();
            if (this.m.y() == 0) {
              this.l = b("0007", "0010", this.y.a("Bridge_02"));
              this.j = 4;
            } else {
              byte[] arrayOfByte = this.m.b();
              if (arrayOfByte != null && arrayOfByte.length > 0) {
                this.p = new d9(arrayOfByte);
                this.k = 2;
              } else {
                this.l = c("".getBytes());
                this.k = 1;
              } 
            } 
          } else {
            this.l = b("0007", "0011", this.y.a("Bridge_16"));
            this.j = 4;
          } 
          return;
        case 3:
          this.j = 7;
          this.k = 1;
          this.l = c("".getBytes());
          return;
        case 4:
          this.j = 8;
          this.k = 1;
          this.l = c("".getBytes());
          return;
      } 
      this.l = b("0011", "0", this.y.a("Bridge_06") + i1);
      this.j = 4;
    } catch (ee ee) {
      ee.printStackTrace();
      this.l = b("0009", "0", ee.toString());
      this.j = 4;
    } catch (be be) {
      be.printStackTrace();
      this.l = b("0007", "0012", be.toString());
      this.j = 4;
    } 
  }
  
  private ao c(byte[] paramArrayOfByte) throws be, IllegalStateException {
    if (j())
      System.out.println(this.y.a("Bridge_07") + new String(paramArrayOfByte) + '"'); 
    if (this.j == 0)
      throw new IllegalStateException(this.y.a("Bridge_08") + this.j); 
    return this.m.f(paramArrayOfByte);
  }
  
  byte[] b(byte[] paramArrayOfByte) throws IllegalStateException {
    try {
      return c(paramArrayOfByte).d();
    } catch (be be) {
      be.printStackTrace();
      this.l = b("0007", "0013", be.toString());
      return this.l.d();
    } 
  }
  
  String b() { return this.q; }
  
  String c() { return this.r; }
  
  String d() { return this.s; }
  
  int e() { return this.o; }
  
  byte[] f() throws IllegalStateException {
    if (this.j == 1 || this.j == 4)
      return this.l.d(); 
    throw new IllegalStateException(this.y.a("Bridge_09") + this.j);
  }
  
  byte[] g() throws IllegalStateException {
    if (this.j != 2)
      throw new IllegalStateException(this.y.a("Bridge_10") + this.j); 
    return this.n;
  }
  
  int h() {
    switch (this.j) {
      case 0:
      case 3:
      case 6:
        throw new IllegalStateException(this.y.a("Bridge_11") + this.j);
    } 
    int i1 = this.j;
    if (this.k != 6) {
      this.j = this.k;
      this.k = 6;
    } 
    return i1;
  }
  
  d9 i() { return this.p; }
  
  byte[] a(String paramString1, String paramString2, String paramString3) { return b(paramString1, paramString2, paramString3).d(); }
  
  ao b(String paramString1, String paramString2, String paramString3) {
    this.u.a(paramString1, paramString2, paramString3);
    return (this.m != null) ? this.m.a(paramString1, paramString2, paramString3) : ao.a(paramString1, paramString2, paramString3, 1110);
  }
  
  boolean j() { return this.v; }
  
  void a(boolean paramBoolean) { this.v = paramBoolean; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\am.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */