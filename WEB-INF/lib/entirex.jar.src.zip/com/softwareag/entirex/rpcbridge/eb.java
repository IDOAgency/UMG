package com.softwareag.entirex.rpcbridge;

import java.io.EOFException;
import java.io.IOException;
import java.io.StringReader;

class eb {
  private String a;
  
  private StringReader b;
  
  static ea a(String paramString) throws ee {
    eb eb1 = new eb(paramString);
    return eb1.a();
  }
  
  private eb(String paramString) {
    this.b = new StringReader(paramString);
    this.a = paramString;
  }
  
  private ea a() throws ee {
    ea ea = new ea();
    try {
      while (true) {
        ed ed = f();
        if (ed == null)
          break; 
        ea.a(ed);
        if (ed.c() == 16)
          a(ed); 
      } 
    } catch (IOException iOException) {
      throw new ee(this.a, iOException.toString());
    } catch (NumberFormatException numberFormatException) {
      throw new ee(this.a, numberFormatException.toString());
    } finally {
      this.b = null;
      this.a = null;
    } 
    return ea;
  }
  
  public String toString() { return this.a; }
  
  private char b() throws IOException {
    int i = this.b.read();
    if (i == -1)
      throw new EOFException(); 
    return (char)i;
  }
  
  private ec c() throws IOException {
    this.b.mark(1);
    char c = b();
    if (c != '(') {
      this.b.reset();
      return new ec();
    } 
    StringBuffer stringBuffer = new StringBuffer();
    for (c = b(); c != ')'; c = b())
      stringBuffer.append(c); 
    return new ec(stringBuffer.toString());
  }
  
  private int d() throws IOException, NumberFormatException {
    char c = b();
    StringBuffer stringBuffer = new StringBuffer();
    do {
      stringBuffer.append(c);
      this.b.mark(1);
      c = b();
    } while (c >= '0' && c <= '9');
    this.b.reset();
    return Integer.parseInt(stringBuffer.toString());
  }
  
  private boolean e() throws IOException {
    this.b.mark(1);
    char c = b();
    if (c == ',')
      return true; 
    this.b.reset();
    return false;
  }
  
  private ed f() throws IOException, NumberFormatException {
    char c1 = b();
    if (c1 == '.')
      return null; 
    char c2 = b();
    ec ec = c();
    int i = d();
    e();
    int j = d();
    int k = 0;
    int m = 0;
    int n = 0;
    if (e()) {
      k = d();
      if (e()) {
        m = d();
        if (e())
          n = d(); 
      } 
    } 
    return new ed(c1, c2, ec, i, j, k, m, n);
  }
  
  private void a(ed paramed) throws IOException, NumberFormatException, ee {
    while (true) {
      ed ed1 = f();
      if (ed1 == null)
        throw new ee(this.a, "Missing end tag for Group"); 
      if (ed1.c() == 17)
        return; 
      paramed.a(ed1);
      if (ed1.c() == 16)
        a(ed1); 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\eb.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */