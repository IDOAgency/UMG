package com.softwareag.entirex.rpcbridge;

import com.softwareag.entirex.aci.h;
import com.softwareag.entirex.base.Command;
import java.util.Properties;

public class ap extends h {
  private aj a;
  
  ap(aj paramaj) {
    super(new Properties());
    this.a = paramaj;
    Command[] arrayOfCommand = paramaj.b();
    for (byte b = 0; b < arrayOfCommand.length; b++)
      add(arrayOfCommand[b]); 
  }
  
  protected void init() {
    super.init();
    add(new Command("-server", "-s", "entirex.server.serveraddress", 1, 2, "RPC/SRV1/CALLNAT", "the server address as 'RPC/<server address>/CALLNAT' or <server address> with class and service,"));
  }
  
  public void a() {
    Properties properties = c();
    this.a.a(properties);
    super.a();
    properties.put("entirex.server.name", this.a.f());
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\ap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */