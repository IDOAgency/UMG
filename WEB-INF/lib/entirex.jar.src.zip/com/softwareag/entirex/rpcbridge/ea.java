package com.softwareag.entirex.rpcbridge;

import java.util.NoSuchElementException;
import java.util.Vector;

class ea {
  private Vector a = new Vector();
  
  void a(ed paramed) { this.a.addElement(paramed); }
  
  ed a(int paramInt) throws ArrayIndexOutOfBoundsException { return (ed)this.a.elementAt(paramInt); }
  
  ed a() throws NoSuchElementException { return (ed)this.a.lastElement(); }
  
  int b() { return this.a.size(); }
  
  boolean c() { return (this.a.size() == 0); }
  
  public String toString() { return b(0).toString(); }
  
  private StringBuffer b(int paramInt) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < b(); b++) {
      ed ed = a(b);
      stringBuffer.append(paramInt + " entry " + b + ": " + ed.toString() + System.getProperty("line.separator"));
      if (ed.c() == 16)
        stringBuffer.append(ed.l().b(++paramInt)); 
    } 
    return stringBuffer;
  }
  
  ea d() { return a(new ea(), 1); }
  
  private ea a(ea paramea, int paramInt) {
    for (byte b = 0; b < b(); b++) {
      ed ed = a(b);
      if (ed.c() == 16) {
        ed.l().a(paramea, ed.h() * paramInt);
      } else {
        for (byte b1 = 0; b1 < paramInt; b1++)
          paramea.a(ed); 
      } 
    } 
    return paramea;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\ea.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */