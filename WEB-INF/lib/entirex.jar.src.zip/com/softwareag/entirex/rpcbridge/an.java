package com.softwareag.entirex.rpcbridge;

class an {
  private String a = "";
  
  private int b = 0;
  
  private int c = 0;
  
  void a() {
    this.b = 0;
    this.c = 0;
    this.a = "";
  }
  
  int b() { return this.c; }
  
  int c() { return this.b; }
  
  String d() { return this.a; }
  
  byte[] e() {
    StringBuffer stringBuffer = new StringBuffer(92);
    stringBuffer.append('+');
    String str = Integer.toString(this.c);
    for (int i = str.length(); i < 5; i++)
      stringBuffer.append('0'); 
    stringBuffer.append(str);
    stringBuffer.append('+');
    str = Integer.toString(this.b);
    for (int j = str.length(); j < 5; j++)
      stringBuffer.append('0'); 
    stringBuffer.append(str);
    stringBuffer.append(this.a);
    stringBuffer.setLength(92);
    return stringBuffer.toString().getBytes();
  }
  
  void a(String paramString1, String paramString2, String paramString3) {
    try {
      this.c = Integer.parseInt(paramString1);
    } catch (NumberFormatException numberFormatException) {
      this.c = -1;
    } 
    try {
      this.b = Integer.parseInt(paramString2);
    } catch (NumberFormatException numberFormatException) {
      this.b = -1;
    } 
    this.a = paramString3;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\an.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */