package com.softwareag.entirex.rpcbridge;

import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.BrokerMessage;
import com.softwareag.entirex.aci.BrokerService;
import com.softwareag.entirex.aci.Conversation;
import com.softwareag.entirex.aci.aq;
import com.softwareag.entirex.aci.b;
import java.util.Properties;

public class ak extends b {
  private static Class a;
  
  private al b;
  
  private BrokerMessage c = new BrokerMessage();
  
  private aj d;
  
  static Class e;
  
  static Class f;
  
  static Class g;
  
  static Class h;
  
  public static void b(String[] paramArrayOfString) {
    Class clazz = null;
    String str = System.getProperty("entirex.bridge.class", "");
    if (str.equals("file")) {
      clazz = (e == null) ? (e = class$("com.softwareag.entirex.rpcbridge.FileTargetTransporter")) : e;
    } else if (str.equals("uow")) {
      clazz = (f == null) ? (f = class$("com.softwareag.entirex.rpcbridge.RPCBMQBridge")) : f;
    } else if (str.equals("aci")) {
      clazz = (g == null) ? (g = class$("com.softwareag.entirex.rpcbridge.RPCACIBridge")) : g;
    } else if (str.equals("cache")) {
      clazz = (h == null) ? (h = class$("com.softwareag.entirex.rpcbridge.CacheTargetTransporter")) : h;
    } else {
      try {
        clazz = Class.forName(str);
      } catch (ClassNotFoundException classNotFoundException) {
        System.out.println(classNotFoundException);
        return;
      } 
    } 
    a(clazz, paramArrayOfString);
  }
  
  public static void a(Class paramClass, String[] paramArrayOfString) {
    try {
      if (paramClass == null)
        throw new IllegalArgumentException("RPC Bridge: no Transporter implementation"); 
      a = paramClass;
      ak ak1 = new ak();
      ak1.a(paramArrayOfString);
    } catch (Exception exception) {
      exception.printStackTrace();
      System.out.println(exception);
    } 
  }
  
  public ak(Properties paramProperties) throws aq {
    super(paramProperties);
    try {
      this.d = (aj)a.newInstance();
      this.d.a(this);
      if (paramProperties != null)
        b(); 
      this.b = new al(this.d, this.d.a());
      a(new ap(this.d));
      f(this.d.f());
      g(this.d.g());
    } catch (Exception exception) {
      throw new aq("1001", "0007", "Bridge cannot start: " + exception.toString(), 3, exception);
    } 
  }
  
  public ak() throws aq { this(null); }
  
  protected void b() throws aq { this.d.c(); }
  
  protected void a(BrokerService paramBrokerService) throws BrokerException {
    this.d.c();
    try {
      this.b.a();
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new aq("1001", "0007", "Bridge cannot start: " + illegalArgumentException.toString(), 3, illegalArgumentException);
    } 
  }
  
  protected void a(BrokerMessage paramBrokerMessage) throws BrokerException {
    Conversation conversation = null;
    try {
      conversation = paramBrokerMessage.getConversation();
      conversation.ignoreEOC(true);
      while (true) {
        byte[] arrayOfByte = this.b.a(paramBrokerMessage.getMessage());
        this.c.setMessage(arrayOfByte);
        conversation.send(this.c);
        if (this.b.d() || this.b.e()) {
          conversation.end();
          break;
        } 
        paramBrokerMessage = conversation.receive();
        if (paramBrokerMessage == null) {
          this.b.c();
          break;
        } 
      } 
    } catch (BrokerException brokerException) {
      if (brokerException.getErrorClass() == 3) {
        if (conversation != null)
          conversation.end(); 
      } else {
        throw brokerException;
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
      throw new aq("1001", "0007", "Unrecoverable error: " + exception.toString(), 3, exception);
    } 
  }
  
  protected void b(BrokerMessage paramBrokerMessage) throws BrokerException {
    try {
      byte[] arrayOfByte = this.b.a(paramBrokerMessage.getMessage());
      this.c.setMessage(arrayOfByte);
      paramBrokerMessage.reply(this.c);
    } catch (BrokerException brokerException) {
      if (brokerException.getErrorClass() != 3)
        throw brokerException; 
    } catch (Exception exception) {
      exception.printStackTrace();
      throw new aq("1001", "0007", "Unrecoverable error: " + exception.toString(), 3, exception);
    } 
  }
  
  protected void a() throws aq {
    if (this.b != null)
      this.b.b(); 
  }
  
  public String[][] getServerEnhancedInfo() {
    String[][] arrayOfString1 = super.getServerEnhancedInfo();
    if (arrayOfString1[0][0].equals("Server Type"))
      arrayOfString1[0][1] = this.d.m(); 
    String[][] arrayOfString2 = this.d.l();
    String[][] arrayOfString3 = new String[arrayOfString1.length + arrayOfString2.length][2];
    System.arraycopy(arrayOfString1, 0, arrayOfString3, 0, arrayOfString1.length);
    System.arraycopy(arrayOfString2, 0, arrayOfString3, arrayOfString1.length, arrayOfString2.length);
    return arrayOfString3;
  }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\ak.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */