package com.softwareag.entirex.rpcbridge;

public class al {
  private am a;
  
  private aj b;
  
  private d8 c;
  
  private boolean d = false;
  
  private boolean e = false;
  
  private boolean f = false;
  
  private boolean g;
  
  private String h;
  
  private String i;
  
  public al(aj paramaj) throws IllegalArgumentException { this(paramaj, new d8()); }
  
  public al(aj paramaj, d8 paramd8) throws IllegalArgumentException {
    if (paramaj == null)
      throw new IllegalArgumentException("Processor: no TargetTransporter specified"); 
    this.b = paramaj;
    this.c = paramd8;
    this.a = new am(paramaj);
    this.g = paramaj.h();
  }
  
  public void a() {
    try {
      this.b.d();
    } catch (eg eg) {
      System.err.println(eg.getMessage());
    } 
  }
  
  public void b() {
    try {
      this.b.e();
    } catch (eg eg) {
      System.err.println(eg.getMessage());
    } 
  }
  
  public void c() {
    this.f = false;
    this.e = true;
    try {
      this.b.d(" ", " ");
    } catch (eg eg) {}
  }
  
  public boolean d() { return this.d; }
  
  public boolean e() { return this.e; }
  
  public byte[] a(byte[] paramArrayOfByte) {
    this.d = false;
    this.e = false;
    this.a.a();
    this.a.a(this.g);
    if (this.g)
      System.out.println("Request:  \"" + new String(paramArrayOfByte) + '"'); 
    this.a.a(paramArrayOfByte);
    this.h = this.a.b();
    this.i = this.a.c();
    int j = this.a.h();
    byte[] arrayOfByte = a(j);
    if (this.g)
      System.out.println("Response: \"" + new String(arrayOfByte) + '"'); 
    return arrayOfByte;
  }
  
  private byte[] a(int paramInt) {
    try {
      int j;
      byte[] arrayOfByte;
      d9 d9;
      switch (paramInt) {
        case 1:
          return this.a.f();
        case 4:
          this.d = true;
          this.f = false;
          return this.a.f();
        case 2:
          d9 = this.a.i();
          arrayOfByte = this.a.g();
          j = d9.c();
          if (j != 2 && this.c != null)
            try {
              arrayOfByte = this.c.a(d9, arrayOfByte, this.a.e());
            } catch (ef ef) {
              return this.a.a(this.b.j(), "0015", this.b.i().a("Bridge_15") + ef.getMessage());
            }  
          switch (j) {
            case 1:
              this.b.b(this.h, this.i, arrayOfByte);
              arrayOfByte = new byte[0];
              break;
            case 2:
              arrayOfByte = this.b.a(this.h, this.i);
              if (this.c != null)
                try {
                  arrayOfByte = this.c.a(d9, arrayOfByte);
                } catch (ef ef) {
                  return this.a.a(this.b.j(), "0014", this.b.i().a("Bridge_14") + ef.getMessage());
                } catch (IndexOutOfBoundsException indexOutOfBoundsException) {} 
              break;
            case 3:
              arrayOfByte = this.b.a(this.h, this.i, arrayOfByte);
              if (this.c != null)
                try {
                  arrayOfByte = this.c.a(d9, arrayOfByte);
                } catch (ef ef) {
                  return this.a.a(this.b.j(), "0014", this.b.i().a("Bridge_14") + ":" + ef.toString());
                } catch (IndexOutOfBoundsException indexOutOfBoundsException) {} 
              break;
          } 
          return this.a.b(arrayOfByte);
        case 5:
          this.b.b(this.h, this.i);
          this.f = true;
          this.e = false;
          return a(this.a.h());
        case 7:
          this.b.c(this.h, this.i);
          this.f = false;
          this.e = true;
          return a(this.a.h());
        case 8:
          this.b.d(this.h, this.i);
          this.f = false;
          this.e = true;
          return a(this.a.h());
      } 
      this.d = true;
      this.f = false;
      return this.a.a(this.b.j(), Integer.toString(1), this.b.i().a("Bridge_12") + paramInt);
    } catch (eg eg) {
      return this.a.a(this.b.j(), Integer.toString(eg.b()), eg.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\al.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */