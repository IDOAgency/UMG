package com.softwareag.entirex.rpcbridge;

import com.softwareag.entirex.aci.Broker;
import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.BrokerMessage;
import com.softwareag.entirex.aci.BrokerSecurity;
import com.softwareag.entirex.aci.BrokerService;
import com.softwareag.entirex.aci.Conversation;
import com.softwareag.entirex.aci.EntireXSecurity;
import com.softwareag.entirex.aci.EntireXVersion;
import com.softwareag.entirex.aci.c;
import com.softwareag.entirex.base.Command;
import com.softwareag.entirex.base.s;
import java.util.Properties;
import java.util.ResourceBundle;

class RPCACIBridge implements aj {
  static final String a = "ACLASS/ASERVER/ASERVICE";
  
  static final String b = "localhost";
  
  static final String c = "entirex.rpcacibridge.serveraddress";
  
  static final String d = "entirex.rpcacibridge.brokerid";
  
  static final String e = "entirex.rpcacibridge.userid";
  
  static final String f = System.getProperty("user.name");
  
  static final String g = "entirex.rpcacibridge.password";
  
  static final String h = "entirex.rpcacibridge.marshalling";
  
  static final String i = "entirex.rpcacibridge.properties";
  
  static final String j = "entirex.rpcacibridge.trace";
  
  static final String k = "entirex.rpcacibridge.compresslevel";
  
  static final String l = "0";
  
  static final String m = "entirex.rpcacibridge.security";
  
  static final String n = "";
  
  static final String o = "entirex.rpcacibridge.encryptionlevel";
  
  static final String p = "0";
  
  static final String q = "entirex.rpcacibridge.logicalbrokerid";
  
  static final String r = "";
  
  static final String s = "entirex.rpcacibridge.logicalservice";
  
  static final String t = "";
  
  static final String u = "entirex.rpcacibridge.logicalsetname";
  
  static final String v = "";
  
  static final String w = "1018";
  
  static final d5 x = (d5)ResourceBundle.getBundle("com.softwareag.entirex.rpcbridge.RPCACIBridgeResources");
  
  private static final int y = 1;
  
  private static final int z = 2;
  
  private int aa;
  
  private int[] ab = { 1140, 2000 };
  
  private int[] ac = { 1140 };
  
  private int[] ad = { 2000 };
  
  private Broker ae;
  
  private BrokerService af;
  
  private Conversation ag = null;
  
  private boolean ah = false;
  
  private boolean ai = false;
  
  private c aj;
  
  private boolean ak;
  
  private static final byte[] al = { (s.a()).g };
  
  static Class am;
  
  public static void main(String[] paramArrayOfString) { ak.a((am == null) ? (am = class$("com.softwareag.entirex.rpcbridge.RPCACIBridge")) : am, paramArrayOfString); }
  
  public d8 a() { return new d8(); }
  
  public void a(c paramc) { this.aj = paramc; }
  
  public Command[] b() { return new Command[] { 
        new Command("-aciserver", null, "entirex.rpcacibridge.serveraddress", 1, -1, "ACLASS/ASERVER/ASERVICE", "the server address for the ACI server,"), new Command("-acibroker", null, "entirex.rpcacibridge.brokerid", 1, -1, "localhost", "the ID of the broker for the ACI server,"), new Command("-aciuser", null, "entirex.rpcacibridge.userid", 1, -1, f, "the user ID for the ACI server (default is value of user.name),"), new Command("-acipassword", null, "entirex.rpcacibridge.password", 1, -1, "", "the password for the ACI server,"), new Command("-acimarshalling", null, "entirex.rpcacibridge.marshalling", 1, -1, "", "the marshalling type, (values: natural, cobol, c),"), new Command("-acitrace", null, "entirex.rpcacibridge.trace", 1, -1, "No", "the trace level for the ACI server side (values: yes, no),"), new Command("-acicompresslevel", null, "entirex.rpcacibridge.compresslevel", 1, -1, "0", "the compression level for the ACI server side,"), new Command("-acilogicalsetname", null, "entirex.rpcacibridge.logicalsetname", 1, -1, "", "the set name for logical names for the ACI server side,"), new Command("-acilogicalbrokerid", null, "entirex.rpcacibridge.logicalbrokerid", 1, -1, "", "the logical name for the broker for the ACI server side,"), new Command("-acilogicalservice", null, "entirex.rpcacibridge.logicalservice", 1, -1, "", "the logical name for the service for the ACI server side,"), 
        new Command("-acisecurity", null, "entirex.rpcacibridge.security", 1, -1, "", "the security setting, values no, yes, auto, <name of BrokerSecurity object> for the ACI server side,"), new Command("-aciencryption", null, "entirex.rpcacibridge.encryptionlevel", 2, -1, "0", "the encryption level, values 0,1,2 for the ACI server side,"), new Command("-propertyfile", "-p", "entirex.server.properties", 1, -1, "entirex.rpcacibridge.properties", "the file name of the property file (default is 'entirex.server.properties'),") }; }
  
  public void a(Properties paramProperties) {}
  
  public void c() {
    this.ak = this.aj.c("entirex.rpcacibridge.trace");
    if (this.aj.d("entirex.rpcacibridge.marshalling").equalsIgnoreCase("natural")) {
      this.aa = 1;
      this.ab = this.ac;
    } else if (this.aj.d("entirex.rpcacibridge.marshalling").equalsIgnoreCase("cobol")) {
      this.aa = 2;
      this.ab = this.ad;
    } else if (this.aj.d("entirex.rpcacibridge.marshalling").equalsIgnoreCase("c")) {
      this.aa = 2;
      this.ab = this.ad;
    } 
  }
  
  public void d() {
    String str1 = this.aj.d("entirex.rpcacibridge.userid");
    String str2 = this.aj.d("entirex.rpcacibridge.brokerid");
    if (str2.indexOf('?') != -1 && str2.toLowerCase().indexOf("poolsize=") == -1) {
      str2 = str2 + "&poolsize=" + this.aj.k();
    } else if (str2.indexOf('?') == -1) {
      str2 = str2 + "?poolsize=" + this.aj.k();
    } 
    this.ae = new Broker(str2 + "&Bridge", str1);
    this.af = new BrokerService(this.ae, this.aj.d("entirex.rpcacibridge.serveraddress"));
    String str3 = this.aj.d("entirex.rpcacibridge.logicalbrokerid");
    String str4 = this.aj.d("entirex.rpcacibridge.logicalservice");
    String str5 = this.aj.d("entirex.rpcacibridge.logicalsetname");
    if (str4 != null && str4.length() > 0) {
      try {
        this.af.setLogicalService(str4, str5);
        this.ae = this.af.getBroker();
        this.ae.reconnect(str1);
      } catch (BrokerException brokerException) {
        System.out.println("Logical service not set: " + brokerException.toString());
      } 
    } else if (str3 != null && str3.length() > 0) {
      try {
        this.af.setLogicalBroker(str3, str5);
        this.ae = this.af.getBroker();
        this.ae.reconnect(str1);
      } catch (BrokerException brokerException) {
        System.out.println("Logical broker not set: " + brokerException.toString());
      } 
    } 
    this;
    if (this.aj.c("entirex.server.usecodepage"))
      try {
        this.af.useCodePage(true);
      } catch (BrokerException brokerException) {
        System.out.println("Failed to set usecodepage: " + brokerException);
      }  
    this;
    String str6 = this.aj.d("entirex.server.codepage");
    if (str6 != null && str6.length() > 0)
      try {
        this.af.setCharacterEncoding(str6);
      } catch (BrokerException brokerException) {
        System.out.println("Failed to set codepage: " + brokerException);
      }  
    this.af.setAdjustReceiveLen(true);
  }
  
  private void n() {
    if (!this.ah) {
      String str1 = this.aj.d("entirex.rpcacibridge.password");
      String str2 = this.aj.d("entirex.rpcacibridge.security");
      int i1 = this.aj.b("entirex.rpcacibridge.encryptionlevel");
      if (str2.equals("") || str2.toLowerCase().startsWith("n")) {
        this.ae.logon();
      } else if (str2.equalsIgnoreCase("auto")) {
        this.ae.useEntireXSecurity(i1, true);
        this.ae.logon(str1);
      } else {
        try {
          BrokerSecurity brokerSecurity;
          if (str2.toLowerCase().startsWith("y")) {
            brokerSecurity = new EntireXSecurity();
          } else {
            brokerSecurity = (BrokerSecurity)Class.forName(str2).newInstance();
          } 
          this.ae.setSecurity(brokerSecurity, i1);
          this.ae.logon(str1);
        } catch (BrokerException brokerException) {
          throw brokerException;
        } catch (Exception exception) {
          System.out.println(exception);
          System.out.println("Illegal value for " + "entirex.rpcacibridge.security" + " = " + str2);
          System.exit(1);
        } 
      } 
      this.ae.setCompressionLevel(this.aj.d("entirex.rpcacibridge.compresslevel"));
      this.ah = true;
    } 
  }
  
  public byte[] a(String paramString1, String paramString2, byte[] paramArrayOfByte) throws eg { return a(paramString1, paramString2, paramArrayOfByte, true); }
  
  private byte[] a(String paramString1, String paramString2, byte[] paramArrayOfByte, boolean paramBoolean) throws eg {
    try {
      n();
      if (paramArrayOfByte.length == 0)
        paramArrayOfByte = al; 
      return (this.ag == null) ? this.af.sendReceive(new BrokerMessage(paramArrayOfByte)).getMessage() : this.ag.sendReceive(new BrokerMessage(paramArrayOfByte)).getMessage();
    } catch (BrokerException brokerException) {
      if (paramBoolean && (a(brokerException) || b(brokerException))) {
        this.ah = false;
        return a(paramString1, paramString2, paramArrayOfByte, false);
      } 
      if (h())
        System.out.println(brokerException); 
      throw new eg(0, brokerException);
    } 
  }
  
  public void b(String paramString1, String paramString2, byte[] paramArrayOfByte) throws eg { b(paramString1, paramString2, paramArrayOfByte, true); }
  
  private void b(String paramString1, String paramString2, byte[] paramArrayOfByte, boolean paramBoolean) throws eg {
    try {
      n();
      if (paramArrayOfByte.length == 0)
        paramArrayOfByte = al; 
      if (this.ag == null) {
        this.af.send(new BrokerMessage(paramArrayOfByte));
      } else {
        this.ag.send(new BrokerMessage(paramArrayOfByte));
      } 
    } catch (BrokerException brokerException) {
      if (paramBoolean && (a(brokerException) || b(brokerException))) {
        this.ah = false;
        b(paramString1, paramString2, paramArrayOfByte, false);
      } else {
        if (h())
          System.out.println(brokerException); 
        throw new eg(2, brokerException);
      } 
    } 
  }
  
  public byte[] a(String paramString1, String paramString2) throws eg { return a(paramString1, paramString2, true); }
  
  private byte[] a(String paramString1, String paramString2, boolean paramBoolean) throws eg {
    try {
      n();
      o();
      return (this.ag == null) ? this.af.receive().getMessage() : this.ag.receive().getMessage();
    } catch (BrokerException brokerException) {
      if (paramBoolean && (a(brokerException) || b(brokerException))) {
        this.ah = false;
        this.ai = false;
        return a(paramString1, paramString2, false);
      } 
      if (h())
        System.out.println(brokerException); 
      throw new eg(3, brokerException);
    } 
  }
  
  private void o() {
    if (this.ai)
      return; 
    this.af.register();
    this.ai = true;
  }
  
  public void b(String paramString1, String paramString2) { this.ag = new Conversation(this.af); }
  
  public void c(String paramString1, String paramString2) {
    try {
      this.ag.end();
    } catch (BrokerException brokerException) {
      if (h())
        System.out.println(brokerException); 
      throw new eg(0, brokerException);
    } 
  }
  
  public void d(String paramString1, String paramString2) {
    try {
      this.ag.end();
    } catch (BrokerException brokerException) {
      if (h())
        System.out.println(brokerException); 
      throw new eg(0, brokerException);
    } 
  }
  
  public void e() {
    try {
      if (this.ai)
        this.af.deregister(); 
      this.ai = false;
      if (this.ah)
        this.ae.logoff(); 
      this.ah = false;
    } catch (BrokerException brokerException) {
      if (h())
        System.out.println(brokerException); 
      throw new eg(4, brokerException);
    } 
  }
  
  public String f() { return (new EntireXVersion("Java RPCACIBridge")).getVersionString(); }
  
  public String g() { return "entirex.rpcacibridge.properties"; }
  
  public boolean h() { return this.ak; }
  
  public d5 i() { return x; }
  
  public String j() { return "1018"; }
  
  private static boolean a(BrokerException paramBrokerException) { return ((paramBrokerException.getErrorClass() == 20 && paramBrokerException.getErrorCode() == 134) || (paramBrokerException.getErrorClass() == 2 && paramBrokerException.getErrorCode() == 2)); }
  
  private static boolean b(BrokerException paramBrokerException) { return (paramBrokerException.getErrorClass() == 13 && paramBrokerException.getErrorCode() == 313); }
  
  public int k() {
    int i1 = this.ab[0];
    for (byte b1 = 1; b1 < this.ab.length; b1++)
      i1 = Math.max(i1, this.ab[b1]); 
    return i1;
  }
  
  public boolean a(int paramInt) {
    boolean bool = false;
    for (byte b1 = 0; b1 < this.ab.length; b1++) {
      if (paramInt == this.ab[b1]) {
        bool = true;
        break;
      } 
    } 
    return bool;
  }
  
  public String[][] l() { return new String[][] { { "Target ACI Service", this.aj.d("entirex.rpcacibridge.serveraddress") }, { "Target ACI Broker", this.aj.d("entirex.rpcacibridge.brokerid") }, { "Target ACI Broker user ID", this.aj.d("entirex.rpcacibridge.userid") }, { "Target ACI Broker password", this.aj.d("entirex.rpcacibridge.password") }, { "Marshalling", this.aj.d("entirex.rpcacibridge.marshalling") }, { "Target trace level", this.aj.d("entirex.rpcacibridge.trace") } }; }
  
  public String m() { return "EntireX RPC ACI Server Bridge"; }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\RPCACIBridge.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */