package com.softwareag.entirex.rpcbridge;

import com.softwareag.entirex.aci.j;
import com.softwareag.entirex.base.s;
import java.io.ByteArrayOutputStream;

public class d8 {
  private boolean a = false;
  
  private ByteArrayOutputStream b = new ByteArrayOutputStream();
  
  private int c;
  
  private byte[] d;
  
  private int e;
  
  private s f = s.a();
  
  public byte[] a(d9 paramd9, byte[] paramArrayOfByte, int paramInt) throws ef {
    if (paramArrayOfByte == null || paramArrayOfByte.length == 0)
      return paramArrayOfByte; 
    this.e = paramInt;
    this.b.reset();
    this.d = paramArrayOfByte;
    this.c = 0;
    if (paramInt == 1140) {
      a(paramd9.a().d());
    } else {
      a(paramd9.a());
    } 
    this.d = null;
    paramArrayOfByte = this.b.toByteArray();
    this.b.reset();
    return paramArrayOfByte;
  }
  
  public byte[] a(d9 paramd9, byte[] paramArrayOfByte) throws ef {
    if (paramArrayOfByte == null || paramArrayOfByte.length == 0)
      return paramArrayOfByte; 
    this.b.reset();
    this.d = paramArrayOfByte;
    this.c = 0;
    if (this.e == 1140) {
      b(paramd9.b().d());
    } else {
      b(paramd9.b());
    } 
    this.d = null;
    paramArrayOfByte = this.b.toByteArray();
    this.b.reset();
    return paramArrayOfByte;
  }
  
  private void a(ea paramea) throws ef {
    int i = paramea.b();
    for (byte b1 = 0; b1 < i; b1++)
      a(paramea.a(b1)); 
  }
  
  private void b(ea paramea) throws ef {
    int i = paramea.b();
    for (byte b1 = 0; b1 < i; b1++)
      b(paramea.a(b1)); 
  }
  
  private void a(ed paramed) throws ef {
    int i = paramed.h();
    for (byte b1 = 0; b1 < i; b1++) {
      switch (paramed.c()) {
        case 0:
        case 2:
          if (paramed.j() && paramed.i()) {
            d(paramed.e());
            break;
          } 
          b(paramed.e());
          break;
        case 1:
        case 3:
          if (paramed.j() && paramed.i()) {
            int j = a();
            d(j);
            break;
          } 
          throw new ef("Variable sized fields only allowed as last prameter and not in arrays.");
        case 4:
        case 5:
          throw new ef("Data type 'binary' not supported.");
        case 6:
        case 7:
          if (paramed.m()) {
            this.c++;
          } else {
            b(1);
          } 
          b(paramed.f() + paramed.g());
          break;
        case 8:
          b(4);
          break;
        case 9:
          b(6);
          break;
        case 10:
          b(11);
          break;
        case 11:
        case 12:
          throw new ef("Data type 'float' not supported.");
        case 13:
          b(8);
          break;
        case 14:
          b(15);
          break;
        case 15:
          b(1);
          break;
        case 16:
          a(paramed.l());
          break;
        default:
          System.out.println("***** should not happen (" + paramed.c() + ")");
          break;
      } 
    } 
  }
  
  private void b(ed paramed) throws ef {
    int i = paramed.h();
    for (byte b1 = 0; b1 < i; b1++) {
      switch (paramed.c()) {
        case 0:
        case 2:
          if (paramed.j() && paramed.i()) {
            a(this.d.length - this.c, paramed.e());
            break;
          } 
          b(paramed.e());
          break;
        case 1:
        case 3:
          if (paramed.j() && paramed.i()) {
            int j = this.d.length - this.c;
            c(j);
            b(j);
            break;
          } 
          throw new ef("Variable sized fields only allowed as last prameter and not in arrays.");
        case 4:
        case 5:
          throw new ef("Data type 'binary' not supported.");
        case 6:
        case 7:
          if (paramed.m()) {
            this.b.write(43);
          } else {
            b(1);
          } 
          b(paramed.f() + paramed.g());
          break;
        case 8:
          b(4);
          break;
        case 9:
          b(6);
          break;
        case 10:
          b(11);
          break;
        case 11:
        case 12:
          throw new ef("Data type 'float' not supported.");
        case 13:
          b(8);
          break;
        case 14:
          b(15);
          break;
        case 15:
          b(1);
          break;
        case 16:
          b(paramed.l());
          break;
        default:
          System.out.println("***** should not happen (" + paramed.c() + ")");
          break;
      } 
    } 
  }
  
  private int a() {
    int i = 0;
    byte b1 = 0;
    for (int j = this.c; j < this.d.length; j++) {
      if (this.d[j] == this.f.e) {
        i = j - this.c;
        break;
      } 
      b1 = b1 * 10 + this.d[j] - this.f.j;
    } 
    this.c += i + 1;
    return b1;
  }
  
  private void b(int paramInt) {
    this.b.write(this.d, this.c, paramInt);
    this.c += paramInt;
  }
  
  private void c(int paramInt) {
    byte[] arrayOfByte = Integer.toString(paramInt).getBytes();
    this.b.write(arrayOfByte, 0, arrayOfByte.length);
    this.b.write(this.f.e);
  }
  
  private void d(int paramInt) {
    int i;
    for (i = paramInt; i > 0 && this.d[this.c - 1 + i] == this.f.g; i--);
    this.b.write(this.d, this.c, i);
    this.c += paramInt;
  }
  
  private void a(int paramInt1, int paramInt2) {
    if (paramInt1 >= paramInt2) {
      this.b.write(this.d, this.c, paramInt2);
    } else {
      this.b.write(this.d, this.c, paramInt1);
      for (byte b1 = 0; b1 < paramInt2 - paramInt1; b1++)
        this.b.write(this.f.g); 
    } 
    this.c += paramInt1;
  }
  
  private void e(int paramInt) {
    byte[] arrayOfByte = j.a(this.d, this.c, paramInt);
    this.c += paramInt;
    this.b.write(arrayOfByte, 0, arrayOfByte.length);
  }
  
  public void a(int paramInt) {
    if (this.e < 2000) {
      for (byte b1 = 0; b1 < paramInt; b1++) {
        int i = Integer.parseInt(new String(this.d, this.c, 2), 16);
        this.c += 2;
        if (i > 127) {
          this.b.write((byte)(i - 256));
        } else {
          this.b.write((byte)i);
        } 
      } 
    } else {
      e(paramInt);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\rpcbridge\d8.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */