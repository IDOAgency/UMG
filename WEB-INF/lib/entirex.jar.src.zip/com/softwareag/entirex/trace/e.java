package com.softwareag.entirex.trace;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;

public final class e {
  protected static final String a = "ERROR in Trace():";
  
  protected static final String b = "ERROR in Trace(): printLn failed, line=";
  
  protected static final String c = "00000000";
  
  protected static final int d = 0;
  
  protected static final int e = 10;
  
  protected static final int f = 20;
  
  protected static final int g = 30;
  
  protected static final int h = 40;
  
  private static int i;
  
  protected static final int j = -1;
  
  private static final String k = "(";
  
  private static final String l = ")";
  
  protected static int m = 8;
  
  protected static String[] n = { "default", "java.aci", "java.rpc", "java.brokeragent", "workbench", "xml.runtime", "xml.servlet", "java.utilities" };
  
  private static long o;
  
  private static String p;
  
  private static String q;
  
  private static String r;
  
  private static int s;
  
  private static String t;
  
  private static int u;
  
  private static String v;
  
  private static int w;
  
  private static boolean x;
  
  private static boolean y;
  
  private static boolean z;
  
  private static Properties aa;
  
  private static String ab;
  
  private static String ac;
  
  private static String ad;
  
  private static String ae;
  
  private static String af;
  
  private static boolean ag;
  
  private static String ah = new String("system properties");
  
  protected static long ai = (long)Math.pow(2.0D, 0.0D);
  
  protected static long aj = (long)Math.pow(2.0D, 1.0D);
  
  protected static long ak = (long)Math.pow(2.0D, 2.0D);
  
  protected static long al = (long)Math.pow(2.0D, 3.0D);
  
  protected static long am = (long)Math.pow(2.0D, 4.0D);
  
  protected static long an = (long)Math.pow(2.0D, 5.0D);
  
  protected static long ao = (long)Math.pow(2.0D, 6.0D);
  
  protected static long ap = (long)Math.pow(2.0D, 7.0D);
  
  protected static long aq = (long)Math.pow(2.0D, 8.0D);
  
  protected static long ar = (long)Math.pow(2.0D, 9.0D);
  
  protected static long as = (long)Math.pow(2.0D, 10.0D);
  
  protected static long at = (long)Math.pow(2.0D, 11.0D);
  
  protected static long au = (long)Math.pow(2.0D, 12.0D);
  
  protected static long av = (long)Math.pow(2.0D, 13.0D);
  
  protected static long aw = (long)Math.pow(2.0D, 14.0D);
  
  protected static long ax = (long)Math.pow(2.0D, 15.0D);
  
  protected static long ay = (long)Math.pow(2.0D, 16.0D);
  
  protected static long az = (long)Math.pow(2.0D, 17.0D);
  
  protected static long a0 = (long)Math.pow(2.0D, 18.0D);
  
  protected static long a1 = (long)Math.pow(2.0D, 19.0D);
  
  protected static long a2 = (long)Math.pow(2.0D, 20.0D);
  
  protected static long a3 = (long)Math.pow(2.0D, 21.0D);
  
  protected static long a4 = (long)Math.pow(2.0D, 22.0D);
  
  protected static long a5 = (long)Math.pow(2.0D, 23.0D);
  
  protected static long a6 = (long)Math.pow(2.0D, 24.0D);
  
  protected static long a7 = (long)Math.pow(2.0D, 25.0D);
  
  protected static long a8 = (long)Math.pow(2.0D, 26.0D);
  
  protected static long a9 = (long)Math.pow(2.0D, 27.0D);
  
  protected static long ba = (long)Math.pow(2.0D, 28.0D);
  
  protected static long bb = (long)Math.pow(2.0D, 29.0D);
  
  protected static long bc = (long)Math.pow(2.0D, 30.0D);
  
  protected static long bd = (long)Math.pow(2.0D, 31.0D);
  
  protected static final long be = 0L;
  
  protected static final long bf = an - 1L;
  
  protected static final long bg = as - 1L;
  
  protected static final long bh = (long)Math.pow(2.0D, 32.0D) - 1L;
  
  protected static final int bi = 0;
  
  protected static final int bj = 1;
  
  protected static final int bk = 2;
  
  protected static final int bl = 3;
  
  protected static final int bm = 4;
  
  protected static final int bn = 5;
  
  protected static final int bo = 6;
  
  protected static final int bp = 7;
  
  protected static final String[] bq = { 
      null, "MapNode", "MapValues", "XMLServletPool", "XMLServletSweeper", "PooledBroker", "PooledXMLRuntime", "RootTagHandler", "XMLMapEngine", "XMLRuntime", 
      "XMLServlet", "XMLServletSession", "XMLSessionResources", "XMLSessionResources.AdapterInfoList", "XMLServletSessions", "XMLTypeElement", "XMLValueElement", "Base64", "Marshal", "RPCServer", 
      "RPCService", "GenerateJava", "XMLRPCService", "GenerateEJB", "XMLAdapterReader", "ConfigurationReader", "ConfigurationFileParser", "DocumentHandler", "MessageHandler", "XMLRPCServer", 
      "XMLServletInitReader", "XMMReader", "XMLDocumentHandler", "SOAPDocumentHandler", "HTTPTransport", "TransportHandler", "EXXMessage", "EXXRPCMessage", "EXXRPCMessage1110", "EXXRPCMessage1120", 
      "EXXRPCMessage1130", "EXXRPCMessage1140", "EXXRPCMessage2000", "XMMInfoHandler", "EntireXFileLoader", "SAXParserLoader", "DocumentBuilderLoader", "EntireXClassLoader", "JavaCallbackTransport", null, 
      null, null };
  
  protected static final String[] br = { 
      null, "addAdapterInfo", "addPath", "addValue", "callParser", "characters", "checkHeadersAndParameters", "createAdapter", "[ctor]", "domAdd", 
      "endDocument", "endElement", "findChildType", "findValueElement", "getAdapterName", "getBroker", "getBrokerID", "getClone", "getHeader", "getInitDocument", 
      "getPoolKey", "getServerAdress", "getSession", "getNextFreeService", "init", "invoke", "invokeXML", "load", "loadParser", "map", 
      "mapChilds", "mapValues", "onPrepare", "onSweep", "post", "prepare", "register", "registerRpcType", "remove", "responseHtmlDefault", 
      "run", "service", "set", "startDocument", "startElement", "sweep", "sweepOut", "writeDocument", "writeFaultDocument", "markXmlNodeAsProgram", 
      "encode", "decode", "setVersion", "doConversation", "doNonConversation", "evaluateCall", "getServerStub", "callServerStub", "getServerRPCVersion", "buildCB", 
      "buildHeader", "doCall", "callServer", "checkServerCall", "processServerCall", "initServerCall", "getReply", "processInquire", "specialTextReply", "initHashtableSB", 
      "writeClientStub", "generateSubClasses", "writeSubClasses", "addData", "getData", "writeNew", "generate", "doGet", "getAdvancedBroker", "getAdvancedService", 
      "getSecurity", "getEncryption", "getNatSecu", "getCodepage", "generateBeanClass", "generateHomeInterface", "generateRemoteInterface", "writeHeader", "saveFile", "writeBodyRemoteInterface", 
      "writeBodyHomeInterface", "writeBodyBeanClass", "startXMLRPCServer", "read", "processRPCMessage", "setToIDS", "setFromIDS", "readXmlAdapter", "readXmmFile", "processXMLMessage", 
      "sendReceive", "convertValueBufferToValueTree", "convertValueTreeToValueBuffer", "ReadDocument", "Write", "SoapHeaderCheck", "setValue", "retrieveInformation", "generateBuildXML", "setFileName", 
      "writeBodyBuildScript", "getSAXParser", "getDocumentBuilder", "getLocationTransparencySetname", "destroy", "add", "get", "read IDL-XML mapping", null, null, 
      null };
  
  public e() {
    o = 0L;
    p = new String("NONE");
    q = new String(".");
    r = new String("STDOUT");
    s = 10;
    t = new String("UNLIMITED");
    u = -1;
    v = new String("UNLIMITED");
    w = -1;
    x = false;
    y = true;
    z = true;
    ab = new String("entirex.trace.properties");
    ac = new String("entirex.sdk.");
    ad = new String(".trace.propertiesfile");
    ae = new String();
    af = new String();
    ag = false;
    i = 30;
  }
  
  protected static void a(String paramString) {
    boolean bool = false;
    String str = null;
    if (aa == null) {
      aa = new Properties();
      try {
        if (System.getProperty(ac + paramString + ad) != null) {
          str = new String(System.getProperty(ac + paramString + ad));
        } else {
          for (byte b1 = 0; b1 < m; b1++) {
            if (System.getProperty(ac + n[b1] + ad) != null) {
              str = new String(System.getProperty(ac + n[b1] + ad));
              break;
            } 
          } 
        } 
        if (str != null) {
          File file = null;
          URL uRL = null;
          try {
            file = new File(str);
          } catch (Exception exception) {}
          if (file != null && !file.exists()) {
            try {
              uRL = new URL(str);
            } catch (MalformedURLException malformedURLException) {}
            if (uRL != null) {
              str = uRL.getFile();
            } else {
              Class clazz = null;
              try {
                clazz = Class.forName("com.softwareag.entirex.trace.Trace");
              } catch (ClassNotFoundException classNotFoundException) {}
              if (clazz != null) {
                uRL = clazz.getResource(str);
                if (uRL != null)
                  str = uRL.getFile(); 
              } 
            } 
          } 
        } 
      } catch (SecurityException securityException) {
        System.err.println(securityException.getMessage());
      } 
      try {
        if (str == null)
          str = System.getProperty("user.dir") + File.separator + ab; 
        aa.load(new FileInputStream(new File(str)));
        ah = str;
      } catch (IOException iOException) {
        aa = new Properties();
        try {
          str = System.getProperty("user.home") + File.separator + ab;
          aa.load(new FileInputStream(new File(str)));
          ah = str;
        } catch (IOException iOException1) {
          aa = new Properties();
          try {
            str = System.getProperty("entirex.home") + File.separator + "etc" + File.separator + ab;
            aa.load(new FileInputStream(new File(str)));
            ah = str;
          } catch (IOException iOException2) {
            bool = true;
            try {
              aa = System.getProperties();
              ah = "system properties";
            } catch (SecurityException securityException) {
              ah = null;
              System.err.println(securityException.getMessage());
            } 
          } 
        } catch (SecurityException securityException) {
          System.err.println(securityException.getMessage());
        } 
      } catch (SecurityException securityException) {
        System.err.println(securityException.getMessage());
      } 
      if (aa != null && ah != null)
        aa.put(ac + "default" + ad, ah); 
    } 
    try {
      if (!bool) {
        Properties properties = System.getProperties();
        Enumeration enumeration = aa.propertyNames();
        String str1 = new String();
        boolean bool1 = false;
        while (enumeration.hasMoreElements()) {
          str1 = enumeration.nextElement().toString().toLowerCase();
          if (str1 != null && properties.getProperty(str1) != null)
            aa.put(str1, properties.getProperty(str1)); 
        } 
      } 
    } catch (SecurityException securityException) {
      System.err.println(securityException.getMessage());
    } 
    af = "default";
    a(aa, af);
    a(aa, paramString);
    if (!paramString.equals("default"))
      af = paramString; 
    if (bool)
      aa = null; 
  }
  
  private static void a(Properties paramProperties, String paramString) {
    ae = ac + paramString + ".trace.";
    p = paramProperties.getProperty(ae + "level", p).toUpperCase();
    if (p.equals("NONE")) {
      o = 0L;
    } else if (p.equals("STANDARD")) {
      o = bf;
    } else if (p.equals("ADVANCED")) {
      o = bg;
    } else if (p.equals("SUPPORT")) {
      o = bh;
    } else {
      try {
        o = Long.parseLong(p);
      } catch (Exception exception) {
        o = 0L;
      } 
    } 
    q = paramProperties.getProperty(ae + "directory", q);
    if (!ag)
      try {
        if (q.equals("."))
          q = System.getProperty("user.dir"); 
        if (!q.endsWith(File.separator))
          q += File.separator; 
        b(q);
      } catch (SecurityException securityException) {
        System.err.println(securityException.getMessage());
      }  
    r = paramProperties.getProperty(ae + "filename", r).toUpperCase();
    i = 30;
    if (r.equals("STDOUT")) {
      i = 10;
    } else if (r.equals("STDERR")) {
      i = 20;
    } else if (r.equals("FILE")) {
      i = 30;
    } else if (r.length() == 0) {
      i = 10;
    } 
    t = paramProperties.getProperty(ae + "maxsize", t).toUpperCase();
    if (t.equals("UNLIMITED")) {
      u = -1;
    } else {
      u = Integer.parseInt(t);
    } 
    v = paramProperties.getProperty(ae + "rowlength", v).toUpperCase();
    if (v.equals("UNLIMITED")) {
      w = -1;
    } else {
      w = Integer.parseInt(v);
    } 
    x = Boolean.valueOf(paramProperties.getProperty(ae + "threadoriented", String.valueOf(x))).booleanValue();
    y = Boolean.valueOf(paramProperties.getProperty(ae + "singlefile", String.valueOf(y))).booleanValue();
    z = Boolean.valueOf(paramProperties.getProperty(ae + "showenvironment", String.valueOf(z))).booleanValue();
  }
  
  public static void a(String paramString1, String paramString2, String paramString3) {
    ag = true;
    if (aa == null)
      aa = new Properties(); 
    if (paramString2 != null && paramString3 != null)
      aa.put(paramString2, paramString3); 
    a(aa, paramString1);
  }
  
  protected static String a() { return "("; }
  
  protected static String b() { return ")"; }
  
  protected String c() { return r; }
  
  protected String d() { return q; }
  
  protected int e() { return i; }
  
  protected int f() { return u; }
  
  protected int g() { return w; }
  
  protected long h() { return o; }
  
  protected boolean i() { return x; }
  
  protected boolean j() { return z; }
  
  protected boolean k() { return y; }
  
  protected static Properties l() { return aa; }
  
  private static void b(String paramString) {
    try {
      File file = new File(paramString);
      if (!file.isDirectory())
        file.mkdirs(); 
    } catch (SecurityException securityException) {
      System.err.println(securityException.getMessage());
    } 
  }
  
  protected static void a(String paramString1, String paramString2, boolean paramBoolean) {
    int i1 = 0;
    StringBuffer stringBuffer = new StringBuffer();
    paramString2 = paramString2.substring(0, paramString2.length() - 4);
    File file = new File(paramString2 + ".log");
    if (!file.exists() || paramBoolean);
    while (file.exists() && i1 < s) {
      stringBuffer.setLength(0);
      stringBuffer.append("." + i1);
      while (stringBuffer.length() < 4)
        stringBuffer.insert(1, "0"); 
      if (file.renameTo(new File(paramString2 + stringBuffer.toString() + ".log")))
        i1 = s * 10; 
      i1++;
    } 
    if (i1 > 0 && i1 < s * 5) {
      i1 = s * 10;
      byte b1 = -1;
      file = new File(q);
      String[] arrayOfString2 = new String[file.list().length];
      String[] arrayOfString1 = file.list();
      long[] arrayOfLong1 = new long[arrayOfString1.length];
      long[] arrayOfLong2 = new long[file.list().length];
      for (byte b2 = 0; b2 < arrayOfString1.length; b2++) {
        arrayOfLong1[b2] = (new File(q + arrayOfString1[b2])).lastModified();
        if ((q + arrayOfString1[b2]).startsWith(paramString2)) {
          arrayOfString2[++b1] = arrayOfString1[b2];
          arrayOfLong2[b1] = arrayOfLong1[b2];
        } 
      } 
      try {
        String str = new String();
        long l1 = 0L;
        if (s < b1)
          s = b1; 
        for (byte b3 = 0; b3 < s - 1; b3++) {
          for (byte b4 = b3 + true; b4 < s; b4++) {
            if (arrayOfLong2[b3] > arrayOfLong2[b4]) {
              str = arrayOfString2[b3];
              arrayOfString2[b3] = arrayOfString2[b4];
              arrayOfString2[b4] = str;
              l1 = arrayOfLong2[b3];
              arrayOfLong2[b3] = arrayOfLong2[b4];
              arrayOfLong2[b4] = l1;
            } 
          } 
        } 
        if ((file = new File(paramString2 + ".log")).exists()) {
          (new File(q + arrayOfString2[0])).delete();
          file.renameTo(new File(q + arrayOfString2[0]));
        } 
      } catch (Exception exception) {
        System.err.println(exception.getMessage());
      } 
    } 
  }
  
  protected static String a(int paramInt) {
    String str = "";
    if (paramInt > 0 && paramInt < bq.length)
      str = bq[paramInt] + "."; 
    return str;
  }
  
  protected static String b(int paramInt) {
    String str = "";
    if (paramInt > 0 && paramInt < br.length)
      str = br[paramInt] + "()"; 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\trace\e.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */