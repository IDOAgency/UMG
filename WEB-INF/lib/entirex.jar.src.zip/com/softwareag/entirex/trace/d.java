package com.softwareag.entirex.trace;

import com.softwareag.entirex.aci.EntireXVersion;
import java.util.Hashtable;

public final class d {
  protected EntireXVersion a;
  
  protected String b = new String();
  
  protected String c = new String();
  
  protected int d = 0;
  
  protected long e = 0L;
  
  protected int f = 0;
  
  protected int g = 0;
  
  protected boolean h = false;
  
  protected boolean i = true;
  
  protected boolean j = true;
  
  protected boolean k = false;
  
  protected boolean l = false;
  
  protected String m = new String();
  
  protected e n = null;
  
  protected int o = 0;
  
  protected String p = null;
  
  protected Object q = null;
  
  protected Hashtable r;
  
  protected int s = 0;
  
  public d(String paramString, boolean paramBoolean) {
    this.n = new e();
    this.a = new EntireXVersion(paramString);
    this.m = paramString.trim().toLowerCase();
    this.s = a(paramString);
    this.r = new Hashtable();
    if (!paramBoolean) {
      this;
      e.a(this.m);
      this.b = this.n.c();
      this.c = this.n.d();
      this.d = this.n.e();
      this.e = this.n.h();
      this.f = this.n.f();
      this.g = this.n.g();
      this.h = this.n.i();
      this.i = this.n.j();
      this.j = this.n.k();
    } 
    this.l = paramBoolean;
    if (this.e > 0L)
      this.k = true; 
  }
  
  public int a(String paramString) {
    byte b1 = 0;
    paramString = paramString.trim().toLowerCase();
    for (int i1 = 0; i1 < e.m; i1++) {
      if (paramString.equals(e.n[i1])) {
        b1 = i1;
        i1 = e.m;
      } 
    } 
    return b1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\trace\d.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */