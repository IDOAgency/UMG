package com.softwareag.entirex.trace;

import com.softwareag.entirex.aci.EntireXVersion;
import java.io.IOException;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;

public final class Trace {
  private static Socket a = null;
  
  private static int b = 0;
  
  private static boolean c = false;
  
  private static boolean d = false;
  
  private static boolean e = false;
  
  private static boolean f = true;
  
  private static boolean g = false;
  
  private static boolean h = true;
  
  private static boolean i = true;
  
  private static boolean j = false;
  
  private static boolean k = false;
  
  protected static boolean l = true;
  
  private static String m = new String();
  
  private static String n = new String();
  
  private static String o = new String();
  
  private static String p = new String();
  
  private static StringBuffer q = new StringBuffer();
  
  private static f r = null;
  
  private static d s = null;
  
  private static final String[] t = { 
      "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
      "A", "B", "C", "D", "E", "F" };
  
  private static int u = 0;
  
  private static int v = 0;
  
  private static Hashtable w = null;
  
  private static Hashtable x = null;
  
  private static Object y;
  
  private static d z = null;
  
  private static int aa = 0;
  
  private static int ab = 0;
  
  private static int ac = 0;
  
  private static boolean ad = true;
  
  private static int ae = 0;
  
  private static Object af = null;
  
  private static boolean ag = true;
  
  private static String ah = new String();
  
  private static boolean ai = false;
  
  public static final long M1 = e.ai;
  
  public static final long M2 = e.an;
  
  public static final long M3 = e.a2;
  
  public static final long M4 = e.a8;
  
  public static final long MP1 = e.aj;
  
  public static final long MP2 = e.ao;
  
  public static final long MP3 = e.a3;
  
  public static final long MP4 = e.a9;
  
  public static final long MB1 = e.ak;
  
  public static final long MB2 = e.ap;
  
  public static final long MB3 = e.a4;
  
  public static final long MB4 = e.ba;
  
  public static final long CP1 = e.al;
  
  public static final long CP2 = e.aq;
  
  public static final long CP3 = e.a5;
  
  public static final long CP4 = e.bb;
  
  public static final long CB1 = e.am;
  
  public static final long CB2 = e.ar;
  
  public static final long CB3 = e.a6;
  
  public static final long CB4 = e.bc;
  
  public static final long RM = e.as;
  
  public static final long RPT = e.at;
  
  public static final long GUI = e.a0;
  
  public static final long NONE = 0L;
  
  public static final long STANDARD = e.bf;
  
  public static final long ADVANCED = e.bg;
  
  public static final long SUPPORT = e.bh;
  
  public static final int DEFAULT = 0;
  
  public static final int JAVA_ACI = 1;
  
  public static final int JAVA_RPC = 2;
  
  public static final int JAVA_BROKERAGENT = 3;
  
  public static final int WORKBENCH = 4;
  
  public static final int XML_RUNTIME = 5;
  
  public static final int XML_SERVLET = 6;
  
  public static final int JAVA_UTILITIES = 7;
  
  public static final int C_XMLADAPTERREADER = 24;
  
  public static final int C_BASE64 = 17;
  
  public static final int C_CONFIGURATIONREADER = 25;
  
  public static final int C_CONFIGURATIONFILEPARSER = 26;
  
  public static final int C_DOCUMENTBUILDERLOADER = 46;
  
  public static final int C_DOCUMENTHANDLER = 27;
  
  public static final int C_ENTIREXCLASSLOADER = 47;
  
  public static final int C_ENTIREXFILELOADER = 44;
  
  public static final int C_EXXMESSAGE = 36;
  
  public static final int C_EXXRPCMESSAGE = 37;
  
  public static final int C_EXXRPCMESSAGE1110 = 38;
  
  public static final int C_EXXRPCMESSAGE1120 = 39;
  
  public static final int C_EXXRPCMESSAGE1130 = 40;
  
  public static final int C_EXXRPCMESSAGE1140 = 41;
  
  public static final int C_EXXRPCMESSAGE2000 = 42;
  
  public static final int C_GENERATEJAVA = 21;
  
  public static final int C_G_EJB = 23;
  
  public static final int C_HTTPTRANSPORT = 34;
  
  public static final int C_JAVACALLBACKTRANSPORT = 48;
  
  public static final int C_MAPNODE = 1;
  
  public static final int C_MAPPING = 2;
  
  public static final int C_MARSHAL = 18;
  
  public static final int C_MESSAGEHANDLER = 28;
  
  public static final int C_POOLEDBROKER = 5;
  
  public static final int C_POOLEDXMLRUNTIME = 6;
  
  public static final int C_ROOTTAGHANDLER = 7;
  
  public static final int C_RPCSERVER = 19;
  
  public static final int C_RPCSERVICE = 20;
  
  public static final int C_SAXPARSERLOADER = 45;
  
  public static final int C_SOAPDOCUMENTHANDLER = 33;
  
  public static final int C_TRANSPORTHANDLER = 35;
  
  public static final int C_XMLDOCUMENTHANDLER = 32;
  
  public static final int C_XMLMAPENGINE = 8;
  
  public static final int C_XMLRUNTIME = 9;
  
  public static final int C_XMLRPCSERVER = 29;
  
  public static final int C_XMLRPCSERVICE = 22;
  
  public static final int C_XMLSERVLET = 10;
  
  public static final int C_XMLSERVLETINITREADER = 30;
  
  public static final int C_XMLSERVLETPOOL = 3;
  
  public static final int C_XMLSERVLETSESSION = 11;
  
  public static final int C_XMLSERVLETSESSIONS = 14;
  
  public static final int C_XMLSERVLETSWEEPER = 4;
  
  public static final int C_XMLSESSIONRESOURCES = 12;
  
  public static final int C_XMLSESSIONRESOURCES_ADAPTERINFOLIST = 13;
  
  public static final int C_XMLTYPEELEMENT = 15;
  
  public static final int C_XMLVALUEELEMENT = 16;
  
  public static final int C_XMMINFOHANDLER = 43;
  
  public static final int C_XMMREADER = 31;
  
  public static final int M_ADD = 115;
  
  public static final int M_ADDADAPTERINFO = 1;
  
  public static final int M_ADDDATA = 73;
  
  public static final int M_ADDPATH = 2;
  
  public static final int M_ADDVALUE = 3;
  
  public static final int M_BUILDCB = 59;
  
  public static final int M_BUILDHEADER = 60;
  
  public static final int M_CALLPARSER = 4;
  
  public static final int M_CALLSERVER = 62;
  
  public static final int M_CALLSERVERSTUB = 57;
  
  public static final int M_CHARACTERS = 5;
  
  public static final int M_CHECKHEADERSANDPARAMETERS = 6;
  
  public static final int M_CHECKSERVERCALL = 63;
  
  public static final int M_CONVERTVALUEBUFFERTOVALUETREE = 101;
  
  public static final int M_CONVERTVALUETREETOVALUEBUFFER = 102;
  
  public static final int M_CREATEADAPTER = 7;
  
  public static final int M_CTOR = 8;
  
  public static final int M_DECODE = 51;
  
  public static final int M_DESTROY = 114;
  
  public static final int M_DOCALL = 61;
  
  public static final int M_DOCONVERSATION = 53;
  
  public static final int M_DOGET = 77;
  
  public static final int M_DONONCONVERSATION = 54;
  
  public static final int M_DOMADD = 9;
  
  public static final int M_ENCODE = 50;
  
  public static final int M_ENDDOCUMENT = 10;
  
  public static final int M_ENDELEMENT = 11;
  
  public static final int M_EVALUATECALL = 55;
  
  public static final int M_FINDCHILDTYPE = 12;
  
  public static final int M_FINDVALUENODE = 13;
  
  public static final int M_G = 76;
  
  public static final int M_G_BC = 84;
  
  public static final int M_G_BX = 108;
  
  public static final int M_G_HI = 85;
  
  public static final int M_G_RI = 86;
  
  public static final int M_GENERATE = 76;
  
  public static final int M_GENERATESUBCLASSES = 71;
  
  public static final int M_GET = 116;
  
  public static final int M_GETADAPTERNAME = 14;
  
  public static final int M_GETADVANCEDBROKER = 78;
  
  public static final int M_GETADVANCEDSERVICE = 79;
  
  public static final int M_GETBROKER = 15;
  
  public static final int M_GETBROKERID = 16;
  
  public static final int M_GETCLONE = 17;
  
  public static final int M_GETCODEPAGE = 83;
  
  public static final int M_GETDATA = 74;
  
  public static final int M_GETDOCUMENTBUILDER = 112;
  
  public static final int M_GETENCRYPTION = 81;
  
  public static final int M_GETHEADER = 18;
  
  public static final int M_GETINITDOCUMENT = 19;
  
  public static final int M_GETLOCATIONTRANSPARENCYSETNAME = 113;
  
  public static final int M_GETNATSECU = 82;
  
  public static final int M_GETNEXTFREESERVICE = 23;
  
  public static final int M_GETPOOLKEY = 20;
  
  public static final int M_GETREPLY = 66;
  
  public static final int M_GETSAXPARSER = 111;
  
  public static final int M_GETSECURITY = 80;
  
  public static final int M_GETSERVERADRESS = 21;
  
  public static final int M_GETSERVERRPCVERSION = 58;
  
  public static final int M_GETSERVERSTUB = 56;
  
  public static final int M_GETSESSION = 22;
  
  public static final int M_INIT = 24;
  
  public static final int M_INITHASHTABLESB = 69;
  
  public static final int M_INITSERVERCALL = 65;
  
  public static final int M_INVOKE = 25;
  
  public static final int M_INVOKEXML = 26;
  
  public static final int M_LOAD = 27;
  
  public static final int M_LOADPARSER = 28;
  
  public static final int M_MAP = 29;
  
  public static final int M_MAPCHILDS = 30;
  
  public static final int M_MAPVALUES = 31;
  
  public static final int M_MARKXMLNODEASPROGRAM = 49;
  
  public static final int M_ONPREPARE = 32;
  
  public static final int M_ONSWEEP = 33;
  
  public static final int M_POST = 34;
  
  public static final int M_PREPARE = 35;
  
  public static final int M_PROCESSRPCMESSAGE = 94;
  
  public static final int M_PROCESSXMLMESSAGE = 99;
  
  public static final int M_PROCESSINQUIRE = 67;
  
  public static final int M_PROCESSSERVERCALL = 64;
  
  public static final int M_READ = 93;
  
  public static final int M_READDOCUMENT = 103;
  
  public static final int M_READMAPPING = 117;
  
  public static final int M_READ_XMLADAPTER = 97;
  
  public static final int M_READ_XMMFILE = 98;
  
  public static final int M_REGISTER = 36;
  
  public static final int M_REGISTERRPCTYPE = 37;
  
  public static final int M_REMOVE = 38;
  
  public static final int M_RESPONSEHTMLDEFAULT = 39;
  
  public static final int M_RETRIEVEINFORMATION = 107;
  
  public static final int M_RUN = 40;
  
  public static final int M_SENDRECEIVE = 100;
  
  public static final int M_SF = 88;
  
  public static final int M_SERVICE = 41;
  
  public static final int M_SET = 42;
  
  public static final int M_SETFILENAME = 109;
  
  public static final int M_SETTOIDS = 95;
  
  public static final int M_SETFROMIDS = 96;
  
  public static final int M_SETVALUE = 106;
  
  public static final int M_SETVERSION = 52;
  
  public static final int M_SOAPHEADERCHECK = 105;
  
  public static final int M_SPECIALTEXTREPLY = 68;
  
  public static final int M_STARTDOCUMENT = 43;
  
  public static final int M_STARTELEMENT = 44;
  
  public static final int M_SWEEP = 45;
  
  public static final int M_SWEEPOUT = 46;
  
  public static final int M_W_BBC = 91;
  
  public static final int M_W_BBS = 110;
  
  public static final int M_W_BHI = 90;
  
  public static final int M_W_BRI = 89;
  
  public static final int M_W_H = 87;
  
  public static final int M_WRITE = 104;
  
  public static final int M_WRITECLIENTSTUB = 70;
  
  public static final int M_WRITEDOCUMENT = 47;
  
  public static final int M_WRITEFAULTDOCUMENT = 48;
  
  public static final int M_WRITENEW = 75;
  
  public static final int M_WRITESUBCLASSES = 72;
  
  public static final int M_STARTXMLRPCSERVER = 92;
  
  public Trace() {
    if (h) {
      System.out.println("EntireX Trace: Sorry, but \"Trace\" is only for static use !");
      h = false;
    } 
  }
  
  private static void a(boolean paramBoolean) {
    if (ad) {
      s.h = paramBoolean;
      c = true;
      b();
    } 
  }
  
  private static void b() {
    if (ad) {
      if (u == 1 && ag && !g) {
        if (ag) {
          if (!s.j) {
            i = false;
          } else {
            o = s.m;
            p = s.c;
          } 
          if (s.e > 0L)
            ag = false; 
        } 
        if (c)
          s.h = s.n.i(); 
        l = !s.h;
        if (!i)
          l = false; 
        if (!s.j && s.e == 0L)
          e = true; 
      } 
      d = a();
    } 
  }
  
  private static boolean a(int paramInt, Object paramObject) {
    m = g();
    boolean bool = false;
    if (x != null) {
      w = x;
      x.clear();
    } 
    if (w == null)
      w = new Hashtable(); 
    if (paramObject.getClass().getSuperclass().toString().equals("class java.applet.Applet") && u < 1) {
      g = true;
      ad = false;
      bool = true;
      ae = paramInt;
      af = paramObject;
    } 
    if (ad) {
      ah = e.n[paramInt];
      s = (d)w.get(ah);
      if (s == null) {
        s = new d(ah, g);
        w.put(ah, s);
      } 
      if (s.e > 0L)
        u++; 
      if (u == 1 && z == null) {
        z = s;
        ac = paramInt;
        j = true;
        k = true;
        y = paramObject;
      } 
      s.o++;
      if (s.o == 1) {
        if (s.p == null)
          s.p = new String(m); 
        aa++;
      } 
      if (s.q == null) {
        s.q = paramObject;
        bool = true;
      } 
    } 
    return bool;
  }
  
  private static boolean b(int paramInt, Object paramObject) {
    m = g();
    boolean bool = false;
    if (ad) {
      c(paramInt);
      if (paramInt == ac && y.equals(paramObject)) {
        bool = true;
        s = z;
      } 
    } 
    return bool;
  }
  
  private static boolean c() {
    if (ad) {
      d();
      k();
    } 
    return d;
  }
  
  public static boolean on(int paramInt, Object paramObject) {
    if (a(paramInt, paramObject))
      b(); 
    return c();
  }
  
  public static boolean on(int paramInt, String paramString) { return on(paramInt, paramString); }
  
  public static boolean on(int paramInt, Object paramObject, boolean paramBoolean) {
    if (a(paramInt, paramObject))
      a(paramBoolean); 
    return c();
  }
  
  public static boolean on(int paramInt, String paramString, boolean paramBoolean) { return on(paramInt, paramString, paramBoolean); }
  
  public static void off(int paramInt, Object paramObject) {
    if (b(paramInt, paramObject)) {
      l();
      s.k = false;
    } 
    d = a();
    if (!d) {
      if (!s.h || i) {
        x = new Hashtable();
        x = w;
        ai = true;
      } 
      w.clear();
    } 
  }
  
  public static void off(Object paramObject) { off(ac, paramObject); }
  
  protected static boolean a() {
    boolean bool = true;
    Enumeration enumeration = w.elements();
    while (enumeration.hasMoreElements()) {
      d d1 = (d)enumeration.nextElement();
      if (d1.k)
        bool = false; 
    } 
    if (bool) {
      d = false;
    } else {
      d = true;
    } 
    return d;
  }
  
  private static void d() {
    String str = g();
    try {
      a(s.b, str);
    } catch (IOException iOException) {
      System.err.println("getUnitedInstance IOException " + iOException);
      System.err.println("can not create file");
    } 
  }
  
  private static void a(String paramString1, String paramString2) throws IOException {
    s.d = s.n.e();
    s.b = paramString1;
  }
  
  private static f e() {
    String str1 = new String();
    String str2 = g();
    if (g)
      s.d = 10; 
    r = (f)s.r.get(str2);
    if (r == null) {
      if (s.h || !i) {
        str1 = "." + str2;
        f = true;
      } 
      if (i) {
        s.m = o;
        s.c = p;
      } 
      switch (s.d) {
        case 30:
          if (f) {
            e.a(s.m + str2, s.c + "exx.sdk." + s.m + str1 + ".log", ai);
            ai = false;
            f = false;
          } 
          try {
            r = new f(s.m + str2, s.c + "exx.sdk." + s.m + str1 + ".log", true);
          } catch (IOException iOException) {}
          break;
        case 40:
          try {
            r = new f(s.m + str2, a, true);
          } catch (IOException iOException) {
            System.err.println("IOException by new TraceWriter TOSOCKET" + iOException);
          } 
          break;
        case 10:
          r = new f(s.m + str2, true, true);
          break;
        case 20:
          r = new f(s.m + str2, false, true);
          break;
        default:
          r = new f(s.m + str2, true, true);
          break;
      } 
      s.r.put(str2, r);
    } 
    return r;
  }
  
  private static void f() { r.a(); }
  
  private static void a(String paramString) {
    if (!g) {
      f f1 = null;
      if (paramString != null)
        f1 = (f)s.r.get(paramString); 
      if (f1 != null)
        r = f1; 
      if (r != null)
        if (s.o <= 1 || e || paramString == null) {
          s.r.clear();
          r.a();
        } else {
          s.r.remove(paramString);
          f.a(s.m + paramString);
        }  
    } 
  }
  
  private static String g() {
    m = Thread.currentThread().getName();
    int i1 = m.length();
    if (i1 < 16) {
      StringBuffer stringBuffer = new StringBuffer(m);
      stringBuffer.append("...............").setLength(16);
      m = stringBuffer.toString();
    } 
    if (i1 > 15)
      m = m.substring(0, 8) + "*" + m.substring(i1 - 7); 
    return m;
  }
  
  private static String b(String paramString) {
    String str = new String();
    if (paramString != null && !paramString.equals(""))
      try {
        int i1 = Integer.parseInt(paramString);
        str = a(i1, 8);
      } catch (Exception exception) {
        str = paramString;
      }  
    return str;
  }
  
  private static int h() { return b; }
  
  private static void a(int paramInt) { b = paramInt; }
  
  private static int i() { return ++b; }
  
  private static int j() { return --b; }
  
  private static void c(String paramString) {
    r = e();
    if (paramString != null)
      r.a(s.m + m, paramString); 
  }
  
  private static void a(StringBuffer paramStringBuffer) {
    String str = g();
    paramStringBuffer.insert(0, " ");
    paramStringBuffer.insert(0, o());
    paramStringBuffer.insert(0, "> ");
    paramStringBuffer.insert(0, str);
    if (paramStringBuffer.length() > s.g && s.g != -1) {
      if (s.f != -1)
        v += s.g; 
      c(paramStringBuffer.toString().substring(0, s.g));
      if (h() + 31 >= s.g) {
        b(s.g);
      } else {
        paramStringBuffer = new StringBuffer(paramStringBuffer.toString().substring(s.g, paramStringBuffer.length()));
        paramStringBuffer = paramStringBuffer.insert(0, d("+"));
        a(paramStringBuffer);
      } 
    } else {
      c(paramStringBuffer.toString());
      if (s.f != -1)
        v += paramStringBuffer.length(); 
    } 
    if (s.f > -1 && v >= s.f && !e) {
      e = true;
      b(0);
    } 
  }
  
  private static void b(int paramInt) {
    String str = g();
    if (d) {
      a(0);
      q = m();
      q.append(e.a());
      q.append(" Exit Trace");
      i();
      a(q);
      q = m();
      if (paramInt == 0) {
        q.append("Trace File Maximum Size (" + s.f + ") is reached.");
      } else {
        q.append("\"rowlength\" is to small.");
      } 
      a(q);
      j();
      q = m();
      q.append(e.b());
      q.append(" Exit Trace");
      a(q);
      r = (f)s.r.get(str);
      if (r != null && !g)
        try {
          f.a(str);
        } catch (SecurityException securityException) {
          System.err.println(securityException.getMessage());
        }  
      a(str);
      s.k = false;
      d = a();
      s.e = 0L;
    } 
  }
  
  private static void k() {
    if (d && j) {
      j = false;
      n = m;
      ab = s.s;
      String str1 = o();
      String str2 = n();
      a(0);
      if (s.i && !g)
        p(); 
      q = m();
      q.append(e.a());
      q.append(" Start Trace");
      i();
      a(q);
      q = m();
      q.append("EntireX ");
      q.append(s.a.getComponentName().toUpperCase());
      q.append(" ");
      s;
      q.append(EntireXVersion.getVersion());
      q.append("$Revision: 1.45 $".substring(10, "$Revision: 1.45 $".length() - 2));
      a(q);
      q = m();
      s;
      q.append("(c) Copyright Software AG 2001-" + EntireXVersion.getYear());
      q.append(". All rights reserved.");
      a(q);
      q = m();
      q.append("Compiled on ");
      s;
      q.append(EntireXVersion.getDate());
      a(q);
      q = m();
      q.append("Start at ");
      q.append(str2);
      q.append(" ");
      q.append(str1);
      a(q);
      j();
      q = m();
      q.append(e.b());
      q.append(" Start Trace");
      a(q);
    } 
  }
  
  private static void l() {
    String str = g();
    if (d && k) {
      k = false;
      String str1 = o();
      String str2 = n();
      q = m();
      q.append(e.a());
      q.append(" Stop Trace");
      a(q);
      i();
      q = m();
      q.append("Close at ");
      q.append(str2);
      q.append(" ");
      q.append(str1);
      a(q);
      j();
      q = m();
      q.append(e.b());
      q.append(" Stop Trace");
      a(q);
    } 
    a(str);
  }
  
  private static String a(int paramInt1, int paramInt2) {
    StringBuffer stringBuffer = new StringBuffer();
    boolean bool = false;
    if (paramInt2 < 2) {
      int i2 = ("" + paramInt1).length();
      if (paramInt2 < i2) {
        paramInt2 = i2;
        bool = true;
      } 
    } 
    for (int i1 = 4 * paramInt2; i1 > 0; i1 -= 4) {
      int i2 = paramInt1 >> i1 - 4 & 0xF;
      stringBuffer.append(t[i2]);
    } 
    if (bool)
      while (stringBuffer.toString().startsWith("0"))
        stringBuffer = new StringBuffer(stringBuffer.toString().substring(1, stringBuffer.toString().length()));  
    return stringBuffer.toString().toLowerCase();
  }
  
  private static void a(byte[] paramArrayOfByte) {
    String str1 = new String();
    String str2 = new String();
    String str3 = new String();
    String str4 = new String();
    String str5 = new String();
    StringBuffer stringBuffer = new StringBuffer();
    int i1 = 16;
    int i2 = 4;
    byte b1 = 8;
    for (byte b2 = 0; b2 < 3 * i1; b2++)
      stringBuffer.append(" "); 
    str3 = stringBuffer.toString();
    int i3 = paramArrayOfByte.length;
    int i4 = i3 % i1;
    int i5 = (i3 - i4) / i1;
    boolean bool1 = false;
    int i6 = 0;
    str2 = new String(paramArrayOfByte);
    stringBuffer.setLength(0);
    for (byte b3 = 0; b3 < str2.length(); b3++) {
      char c1 = str2.charAt(b3);
      if (Character.isWhitespace(c1) && !Character.isSpaceChar(c1)) {
        stringBuffer.append('.');
      } else if (Character.isISOControl(c1)) {
        stringBuffer.append('.');
      } else {
        stringBuffer.append(c1);
      } 
    } 
    if (str2.length() < paramArrayOfByte.length)
      for (int i9 = str2.length(); i9 < paramArrayOfByte.length; i9++)
        stringBuffer.append('-');  
    str2 = stringBuffer.toString();
    for (byte b4 = 0; b4 < paramArrayOfByte.length; b4++)
      str1 = str1 + a(paramArrayOfByte[b4], 2); 
    boolean bool2 = false;
    boolean bool3 = true;
    int i7 = -1;
    for (int i8 = 0; i8 < i5; i8++) {
      q = m();
      q.append(a(i1 * i6, b1));
      q.append(" ");
      str4 = str1.substring(i8 * 2 * i1, i8 * 2 * i1 + 2 * i1);
      if (i6 < i5 - 1) {
        str5 = str1.substring((i8 + 1) * 2 * i1, (i8 + 1) * 2 * i1 + 2 * i1);
      } else {
        str5 = "";
      } 
      if (str5.equals(str4)) {
        if (bool3)
          i7 = i6; 
        bool3 = false;
        bool2 = true;
      } else {
        bool3 = true;
      } 
      if (bool2 && bool3) {
        q.append("      -same line(s) as above-");
        a(q);
        bool2 = false;
      } else if ((!bool2 && bool3) || i6 == i7) {
        for (int i9 = 0; i9 < i1 / i2; i9++) {
          q.append(str4.substring(i9 * 2 * i2, (i9 + 1) * 2 * i2));
          q.append(" ");
        } 
        q.append(str2.substring(i8 * i1, i8 * i1 + i1));
        a(q);
      } 
      i6++;
    } 
    q = m();
    q.append(a(i1 * i6, b1));
    q.append(" ");
    str4 = str1.substring(i5 * 2 * i1, i5 * 2 * i1 + 2 * i4);
    if (str4.length() > 0) {
      while (str4.length() / 2 * i2 >= 1) {
        q.append(str4.substring(0, 2 * i2));
        q.append(" ");
        str4 = str4.substring(2 * i2, str4.length());
      } 
      q.append(str4 + str3.substring(0, 2 * i1 - 2 * i4 + i1 / i2 - i4 / i2) + str2.substring(i5 * i1, i5 * i1 + i4));
      a(q);
    } 
  }
  
  private static StringBuffer m() { return d("."); }
  
  private static StringBuffer d(String paramString) {
    if (paramString.length() > 1)
      paramString = paramString.substring(0, 1); 
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b1 = 0; b1 < h(); b1++)
      stringBuffer.append(paramString); 
    return stringBuffer;
  }
  
  private static String n() {
    Date date = new Date();
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    return simpleDateFormat.format(date);
  }
  
  private static String o() {
    Date date = new Date();
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss.SSS");
    return simpleDateFormat.format(date);
  }
  
  private static void p() {
    try {
      Properties properties = e.l();
      a("Trace-Settings", properties);
      properties = System.getProperties();
      a("Environment-Information", properties);
    } catch (SecurityException securityException) {
      System.err.println(securityException.getMessage());
    } 
  }
  
  private static void a(String paramString, Properties paramProperties) {
    if (paramProperties != null) {
      Enumeration enumeration = paramProperties.keys();
      String str = new String();
      q.setLength(0);
      q.append(paramString);
      a(q);
      while (enumeration.hasMoreElements()) {
        str = enumeration.nextElement().toString();
        q.setLength(0);
        q.append(str);
        q.append("=\"");
        if (!str.equals("line.separator")) {
          q.append(paramProperties.getProperty(str));
        } else {
          byte[] arrayOfByte = paramProperties.getProperty(str).getBytes();
          for (byte b1 = 0; b1 < arrayOfByte.length; b1++) {
            if (b1)
              q.append("+"); 
            q.append("0x");
            q.append(a((new Byte(arrayOfByte[b1])).intValue(), 2));
          } 
        } 
        q.append("\"");
        a(q);
      } 
      q.setLength(0);
      a(q);
    } 
  }
  
  public static boolean setAppletTraceProperties(int paramInt, String paramString1, String paramString2) {
    boolean bool = false;
    ah = e.n[paramInt];
    if (!ad)
      try {
        ab = paramInt;
        s = (d)w.get(ah);
        if (s == null) {
          s = new d(ah, true);
          w.put(ah, s);
        } 
        s;
        e.a(ah, paramString1, paramString2);
        s.e = s.n.h();
        s.d = s.n.e();
        s.f = s.n.f();
        s.g = s.n.g();
        s.h = s.n.i();
        s.j = s.n.k();
        if (s.e > 0L) {
          m = g();
          s.k = true;
          d = true;
          bool = true;
          if (ag) {
            ag = false;
            z = s;
            ac = s.s;
            y = af;
            j = true;
            k = true;
            k();
          } 
        } else {
          s.k = false;
          d = false;
        } 
      } catch (SecurityException securityException) {
        System.err.println(securityException.getMessage());
      }  
    if (s != null)
      s.o++; 
    return bool;
  }
  
  private static boolean c(int paramInt) {
    m = g();
    boolean bool = false;
    ad = true;
    d d1 = s;
    ah = e.n[paramInt];
    if (paramInt >= 0) {
      Enumeration enumeration = w.keys();
      while (enumeration.hasMoreElements()) {
        if (enumeration.nextElement().toString().equals(ah)) {
          d1 = (d)w.get(ah);
          bool = true;
          break;
        } 
      } 
    } 
    s = d1;
    return bool;
  }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, Vector paramVector) {
    if (d && c(paramInt1))
      if (paramVector == null) {
        String str = new String("null");
        enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
      } else {
        ab = paramInt1;
        if ((paramLong & s.e) == M1 || (paramLong & s.e) == M2 || (paramLong & s.e) == M3 || (paramLong & s.e) == M4) {
          i();
          q = m();
          q.append(e.a());
          q.append(" Enter: ");
          q.append(b(paramInt2, paramInt3));
          a(q);
          if (paramString != null && paramVector != null) {
            i();
            for (byte b1 = 0; b1 < paramVector.size(); b1++) {
              q = m();
              if (b1 < 10)
                q.append("0"); 
              q.append("" + b1);
              q.append(" P:");
              q.append(paramString);
              q.append("=\"");
              q.append(paramVector.elementAt(b1).toString());
              q.append("\"");
              a(q);
            } 
            j();
          } 
        } 
      }  
  }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, boolean[] paramArrayOfBoolean) {
    if (paramArrayOfBoolean == null) {
      String str = new String("null");
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfBoolean.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfBoolean[b1])); 
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, char[] paramArrayOfChar) {
    if (paramArrayOfChar == null) {
      String str = new String("null");
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfChar.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfChar[b1])); 
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, double[] paramArrayOfDouble) {
    if (paramArrayOfDouble == null) {
      String str = new String("null");
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfDouble.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfDouble[b1])); 
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, float[] paramArrayOfFloat) {
    if (paramArrayOfFloat == null) {
      String str = new String("null");
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfFloat.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfFloat[b1])); 
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, int[] paramArrayOfInt) {
    if (paramArrayOfInt == null) {
      String str = new String("null");
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfInt.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfInt[b1])); 
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, long[] paramArrayOfLong) {
    if (paramArrayOfLong == null) {
      String str = new String("null");
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfLong.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfLong[b1])); 
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, Object[] paramArrayOfObject) {
    if (paramArrayOfObject == null) {
      String str = new String("null");
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfObject.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfObject[b1])); 
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, String[] paramArrayOfString) {
    if (paramArrayOfString == null) {
      String str = new String("null");
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfString.length; b1++)
        vector.addElement(new String(paramArrayOfString[b1])); 
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  private static void a(long paramLong, int paramInt1, String paramString1, int paramInt2, int paramInt3, String paramString2, String paramString3) {
    if (d && c(paramInt1)) {
      if (paramString3 == null)
        paramString3 = new String("null"); 
      ab = paramInt1;
      boolean bool = false;
      if (paramString1.equals("CP")) {
        if ((paramLong & s.e) == CP1 || (paramLong & s.e) == CP2 || (paramLong & s.e) == CP3 || (paramLong & s.e) == CP4)
          bool = true; 
      } else if ((paramLong & s.e) == M1 || (paramLong & s.e) == M2 || (paramLong & s.e) == M3 || (paramLong & s.e) == M4) {
        bool = true;
      } 
      if (bool) {
        i();
        q = m();
        q.append(e.a());
        q.append(" ");
        q.append(paramString1);
        q.append(": ");
        q.append(b(paramInt2, paramInt3));
        a(q);
        if (paramString2 != null) {
          i();
          q = m();
          q.append("P:");
          q.append(paramString2);
          q.append("=\"");
          q.append(paramString3);
          q.append("\"");
          a(q);
          j();
        } 
      } 
    } 
  }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3) { a(paramLong, paramInt1, "Enter", paramInt2, paramInt3, null, null); }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString1, String paramString2) { a(paramLong, paramInt1, "Enter", paramInt2, paramInt3, paramString1, paramString2); }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, int paramInt4) { a(paramLong, paramInt1, "Enter", paramInt2, paramInt3, paramString, (new String()).valueOf(paramInt4)); }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, float paramFloat) { a(paramLong, paramInt1, "Enter", paramInt2, paramInt3, paramString, (new String()).valueOf(paramFloat)); }
  
  public static void enterMethod(long paramLong1, int paramInt1, int paramInt2, int paramInt3, String paramString, long paramLong2) { a(paramLong1, paramInt1, "Enter", paramInt2, paramInt3, paramString, (new String()).valueOf(paramLong2)); }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, boolean paramBoolean) { a(paramLong, paramInt1, "Enter", paramInt2, paramInt3, paramString, (new String()).valueOf(paramBoolean)); }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, double paramDouble) { a(paramLong, paramInt1, "Enter", paramInt2, paramInt3, paramString, (new String()).valueOf(paramDouble)); }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, Object paramObject) {
    if (paramObject == null) {
      String str = new String("null");
      a(paramLong, paramInt1, "Enter", paramInt2, paramInt3, paramString, str);
    } else {
      a(paramLong, paramInt1, "Enter", paramInt2, paramInt3, paramString, (new String()).valueOf(paramObject));
    } 
  }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, char paramChar) { a(paramLong, paramInt1, "Enter", paramInt2, paramInt3, paramString, (new String()).valueOf(paramChar)); }
  
  public static void enterMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, byte[] paramArrayOfByte) {
    a(paramLong, paramInt1, "Enter", paramInt2, paramInt3, null, null);
    if (paramArrayOfByte == null) {
      String str = new String("null");
      enterMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else if ((paramLong & s.e) == M1 || (paramLong & s.e) == M2 || (paramLong & s.e) == M3 || (paramLong & s.e) == M4) {
      a(paramLong, paramInt1, "Enter: ", paramInt2, paramInt3, paramString, paramArrayOfByte);
    } 
  }
  
  public static void enterCheckpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3) { a(paramLong, paramInt1, "CP", paramInt2, paramInt3, null, null); }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, Vector paramVector) {
    if (d && c(paramInt1))
      if (paramVector == null) {
        String str = new String("null");
        leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
      } else {
        ab = paramInt1;
        if ((paramLong & s.e) == M1 || (paramLong & s.e) == M2 || (paramLong & s.e) == M3 || (paramLong & s.e) == M4) {
          if (paramString != null && paramVector != null) {
            i();
            for (byte b1 = 0; b1 < paramVector.size(); b1++) {
              q = m();
              if (b1 < 10)
                q.append("0"); 
              q.append("" + b1);
              q.append(" P:");
              q.append(paramString);
              q.append("=\"");
              q.append(paramVector.elementAt(b1).toString());
              q.append("\"");
              a(q);
            } 
            j();
          } 
          q = m();
          q.append(e.b());
          q.append(" Leave: ");
          q.append(b(paramInt2, paramInt3));
          a(q);
          j();
        } 
      }  
  }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, boolean[] paramArrayOfBoolean) {
    if (paramArrayOfBoolean == null) {
      String str = new String("null");
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfBoolean.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfBoolean[b1])); 
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, char[] paramArrayOfChar) {
    if (paramArrayOfChar == null) {
      String str = new String("null");
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfChar.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfChar[b1])); 
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, double[] paramArrayOfDouble) {
    if (paramArrayOfDouble == null) {
      String str = new String("null");
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfDouble.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfDouble[b1])); 
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, float[] paramArrayOfFloat) {
    if (paramArrayOfFloat == null) {
      String str = new String("null");
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfFloat.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfFloat[b1])); 
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, int[] paramArrayOfInt) {
    if (paramArrayOfInt == null) {
      String str = new String("null");
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfInt.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfInt[b1])); 
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, long[] paramArrayOfLong) {
    if (paramArrayOfLong == null) {
      String str = new String("null");
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfLong.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfLong[b1])); 
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, Object[] paramArrayOfObject) {
    if (paramArrayOfObject == null) {
      String str = new String("null");
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfObject.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfObject[b1])); 
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, String[] paramArrayOfString) {
    if (paramArrayOfString == null) {
      String str = new String("null");
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfString.length; b1++)
        vector.addElement(new String(paramArrayOfString[b1])); 
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  private static void b(long paramLong, int paramInt1, String paramString1, int paramInt2, int paramInt3, String paramString2, String paramString3) {
    if (d && c(paramInt1)) {
      if (paramString3 == null)
        paramString3 = new String("null"); 
      ab = paramInt1;
      boolean bool = false;
      if (paramString1.equals("CP")) {
        if ((paramLong & s.e) == CP1 || (paramLong & s.e) == CP2 || (paramLong & s.e) == CP3 || (paramLong & s.e) == CP4)
          bool = true; 
      } else if ((paramLong & s.e) == M1 || (paramLong & s.e) == M2 || (paramLong & s.e) == M3 || (paramLong & s.e) == M4) {
        bool = true;
      } 
      if (bool) {
        q = m();
        q.append(e.b());
        q.append(" ");
        q.append(paramString1);
        q.append(": ");
        q.append(b(paramInt2, paramInt3));
        if (paramString2 != null) {
          q.append(" P:");
          q.append(paramString2);
          q.append("=\"");
          q.append(paramString3);
          q.append("\"");
        } 
        a(q);
        j();
      } 
    } 
  }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3) { b(paramLong, paramInt1, "Leave", paramInt2, paramInt3, null, null); }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString1, String paramString2) { b(paramLong, paramInt1, "Leave", paramInt2, paramInt3, paramString1, paramString2); }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, int paramInt4) { b(paramLong, paramInt1, "Leave", paramInt2, paramInt3, paramString, (new String()).valueOf(paramInt4)); }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, float paramFloat) { b(paramLong, paramInt1, "Leave", paramInt2, paramInt3, paramString, (new String()).valueOf(paramFloat)); }
  
  public static void leaveMethod(long paramLong1, int paramInt1, int paramInt2, int paramInt3, String paramString, long paramLong2) { b(paramLong1, paramInt1, "Leave", paramInt2, paramInt3, paramString, (new String()).valueOf(paramLong2)); }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, boolean paramBoolean) { b(paramLong, paramInt1, "Leave", paramInt2, paramInt3, paramString, (new String()).valueOf(paramBoolean)); }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, double paramDouble) { b(paramLong, paramInt1, "Leave", paramInt2, paramInt3, paramString, (new String()).valueOf(paramDouble)); }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, Object paramObject) {
    if (paramObject == null) {
      String str = new String("null");
      b(paramLong, paramInt1, "Leave", paramInt2, paramInt3, paramString, str);
    } else {
      b(paramLong, paramInt1, "Leave", paramInt2, paramInt3, paramString, (new String()).valueOf(paramObject));
    } 
  }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, char paramChar) { b(paramLong, paramInt1, "Leave", paramInt2, paramInt3, paramString, (new String()).valueOf(paramChar)); }
  
  public static void leaveMethod(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, byte[] paramArrayOfByte) {
    if (paramArrayOfByte == null) {
      String str = new String("null");
      leaveMethod(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else if ((paramLong & s.e) == M1 || (paramLong & s.e) == M2 || (paramLong & s.e) == M3 || (paramLong & s.e) == M4) {
      a(paramLong, paramInt1, "Leave: ", paramInt2, paramInt3, paramString, paramArrayOfByte);
    } 
    b(paramLong, paramInt1, "Leave", paramInt2, paramInt3, null, null);
  }
  
  public static void leaveCheckpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3) { b(paramLong, paramInt1, "CP", paramInt2, paramInt3, null, null); }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, Vector paramVector) {
    if (d && c(paramInt1))
      if (paramVector == null) {
        String str = new String("null");
        checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
      } else {
        ab = paramInt1;
        if ((paramLong & s.e) == CP1 || (paramLong & s.e) == CP2 || (paramLong & s.e) == CP3 || (paramLong & s.e) == CP4) {
          i();
          q = m();
          q.append(e.a());
          q.append(" CP:");
          q.append(b(paramInt2, paramInt3));
          if (!paramString.equals("") && paramVector.size() != 0) {
            a(q);
            for (byte b1 = 0; b1 < paramVector.size(); b1++) {
              q = m();
              if (b1 < 10)
                q.append("0"); 
              q.append("" + b1);
              q.append(" P:");
              q.append(paramString);
              q.append("=\"");
              q.append(paramVector.elementAt(b1).toString());
              q.append("\"");
              a(q);
            } 
            q = m();
            q.append(e.b());
            q.append(" CP:");
            q.append(b(paramInt2, paramInt3));
          } else {
            q.append(" ");
            q.append(e.b());
          } 
          a(q);
          j();
        } 
      }  
  }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, String[] paramArrayOfString) {
    if (d && c(paramInt1))
      if (paramArrayOfString == null) {
        String str = new String("null");
        checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
      } else {
        ab = paramInt1;
        if ((paramLong & s.e) == CP1 || (paramLong & s.e) == CP2 || (paramLong & s.e) == CP3 || (paramLong & s.e) == CP4) {
          i();
          q = m();
          q.append(e.a());
          q.append(" CP:");
          q.append(b(paramInt2, paramInt3));
          a(q);
          for (byte b1 = 0; b1 < paramArrayOfString.length; b1++) {
            q = m();
            q.append("P:");
            q.append(paramString);
            q.append("[");
            if (b1 < 10)
              q.append("0"); 
            q.append("" + b1);
            q.append("]=\"");
            q.append(paramArrayOfString[b1]);
            q.append("\"");
            a(q);
          } 
          q = m();
          q.append(e.b());
          q.append(" CP:");
          q.append(b(paramInt2, paramInt3));
          a(q);
          j();
        } 
      }  
  }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, boolean[] paramArrayOfBoolean) {
    if (paramArrayOfBoolean == null) {
      String str = new String("null");
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      String[] arrayOfString = new String[paramArrayOfBoolean.length];
      for (byte b1 = 0; b1 < paramArrayOfBoolean.length; b1++)
        arrayOfString[b1] = (new String()).valueOf(paramArrayOfBoolean[b1]); 
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, arrayOfString);
    } 
  }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, char[] paramArrayOfChar) {
    if (paramArrayOfChar == null) {
      String str = new String("null");
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      String[] arrayOfString = new String[paramArrayOfChar.length];
      for (byte b1 = 0; b1 < paramArrayOfChar.length; b1++)
        arrayOfString[b1] = (new String()).valueOf(paramArrayOfChar[b1]); 
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, arrayOfString);
    } 
  }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, double[] paramArrayOfDouble) {
    if (paramArrayOfDouble == null) {
      String str = new String("null");
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      String[] arrayOfString = new String[paramArrayOfDouble.length];
      for (byte b1 = 0; b1 < paramArrayOfDouble.length; b1++)
        arrayOfString[b1] = (new String()).valueOf(paramArrayOfDouble[b1]); 
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, arrayOfString);
    } 
  }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, float[] paramArrayOfFloat) {
    if (paramArrayOfFloat == null) {
      String str = new String("null");
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      String[] arrayOfString = new String[paramArrayOfFloat.length];
      for (byte b1 = 0; b1 < paramArrayOfFloat.length; b1++)
        arrayOfString[b1] = (new String()).valueOf(paramArrayOfFloat[b1]); 
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, arrayOfString);
    } 
  }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, int[] paramArrayOfInt) {
    if (paramArrayOfInt == null) {
      String str = new String("null");
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      String[] arrayOfString = new String[paramArrayOfInt.length];
      for (byte b1 = 0; b1 < paramArrayOfInt.length; b1++)
        arrayOfString[b1] = (new String()).valueOf(paramArrayOfInt[b1]); 
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, arrayOfString);
    } 
  }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, long[] paramArrayOfLong) {
    if (paramArrayOfLong == null) {
      String str = new String("null");
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      String[] arrayOfString = new String[paramArrayOfLong.length];
      for (byte b1 = 0; b1 < paramArrayOfLong.length; b1++)
        arrayOfString[b1] = (new String()).valueOf(paramArrayOfLong[b1]); 
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, arrayOfString);
    } 
  }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, Object[] paramArrayOfObject) {
    if (paramArrayOfObject == null) {
      String str = new String("null");
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      String[] arrayOfString = new String[paramArrayOfObject.length];
      for (byte b1 = 0; b1 < paramArrayOfObject.length; b1++)
        arrayOfString[b1] = (new String()).valueOf(paramArrayOfObject[b1]); 
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, arrayOfString);
    } 
  }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString1, String paramString2) {
    if (d && c(paramInt1)) {
      if (paramString2 == null)
        paramString2 = new String("null"); 
      ab = paramInt1;
      if ((paramLong & s.e) == CP1 || (paramLong & s.e) == CP2 || (paramLong & s.e) == CP3 || (paramLong & s.e) == CP4) {
        i();
        q = m();
        q.append(e.a());
        q.append(" CP:");
        q.append(b(paramInt2, paramInt3));
        if (!paramString1.equals("")) {
          q.append(" P:");
          q.append(paramString1);
          q.append("=\"");
          q.append(paramString2);
          q.append("\"");
        } else if (paramString1.equals("") && !paramString2.equals("")) {
          q.append(" I:");
          q.append(paramString2);
        } 
        q.append(" ");
        q.append(e.b());
        a(q);
        j();
      } 
    } 
  }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3) { checkpoint(paramLong, paramInt1, paramInt2, paramInt3, "", ""); }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString) { checkpoint(paramLong, paramInt1, paramInt2, paramInt3, "", paramString); }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, int paramInt4) { checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramInt4)); }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, float paramFloat) { checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramFloat)); }
  
  public static void checkpoint(long paramLong1, int paramInt1, int paramInt2, int paramInt3, String paramString, long paramLong2) { checkpoint(paramLong1, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramLong2)); }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, boolean paramBoolean) { checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramBoolean)); }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, double paramDouble) { checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramDouble)); }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, Object paramObject) {
    if (paramObject == null) {
      paramObject = new String("null");
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, paramObject);
    } else {
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramObject));
    } 
  }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, char paramChar) { checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramChar)); }
  
  public static void checkpoint(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, byte[] paramArrayOfByte) {
    if (paramArrayOfByte == null) {
      String str = new String("null");
      checkpoint(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else if ((paramLong & s.e) == CB1 || (paramLong & s.e) == CB2 || (paramLong & s.e) == CB3 || (paramLong & s.e) == CB4 || (paramLong & s.e) == CP1 || (paramLong & s.e) == CP2 || (paramLong & s.e) == CP3 || (paramLong & s.e) == CP4) {
      a(paramLong, paramInt1, "", paramInt2, paramInt3, paramString, paramArrayOfByte);
    } 
  }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, Vector paramVector) {
    if (d && c(paramInt1))
      if (paramVector == null) {
        String str = new String("null");
        parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
      } else {
        ab = paramInt1;
        if ((paramLong & s.e) == MP1 || (paramLong & s.e) == MP2 || (paramLong & s.e) == MP3 || (paramLong & s.e) == MP4 || (paramLong & s.e) == CP1 || (paramLong & s.e) == CP2 || (paramLong & s.e) == CP3 || (paramLong & s.e) == CP4)
          for (byte b1 = 0; b1 < paramVector.size(); b1++) {
            q = m();
            if (b1 < 10)
              q.append("0"); 
            q.append("" + b1);
            q.append(" P:");
            q.append(b(paramInt2, paramInt3));
            q.append(" ");
            q.append(paramString);
            q.append("=\"");
            q.append(paramVector.elementAt(b1).toString());
            q.append("\"");
            a(q);
          }  
      }  
  }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, boolean[] paramArrayOfBoolean) {
    if (paramArrayOfBoolean == null) {
      String str = new String("null");
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfBoolean.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfBoolean[b1])); 
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, char[] paramArrayOfChar) {
    if (paramArrayOfChar == null) {
      String str = new String("null");
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfChar.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfChar[b1])); 
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, double[] paramArrayOfDouble) {
    if (paramArrayOfDouble == null) {
      String str = new String("null");
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfDouble.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfDouble[b1])); 
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, float[] paramArrayOfFloat) {
    if (paramArrayOfFloat == null) {
      String str = new String("null");
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfFloat.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfFloat[b1])); 
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, int[] paramArrayOfInt) {
    if (paramArrayOfInt == null) {
      String str = new String("null");
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfInt.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfInt[b1])); 
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, long[] paramArrayOfLong) {
    if (paramArrayOfLong == null) {
      String str = new String("null");
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfLong.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfLong[b1])); 
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, Object[] paramArrayOfObject) {
    if (paramArrayOfObject == null) {
      String str = new String("null");
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfObject.length; b1++)
        vector.addElement((new String()).valueOf(paramArrayOfObject[b1])); 
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, String[] paramArrayOfString) {
    if (paramArrayOfString == null) {
      String str = new String("null");
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfString.length; b1++)
        vector.addElement(new String(paramArrayOfString[b1])); 
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, vector);
    } 
  }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString1, String paramString2) {
    if (d && c(paramInt1)) {
      if (paramString2 == null)
        paramString2 = new String("null"); 
      ab = paramInt1;
      if ((paramLong & s.e) == MP1 || (paramLong & s.e) == MP2 || (paramLong & s.e) == MP3 || (paramLong & s.e) == MP4 || (paramLong & s.e) == CP1 || (paramLong & s.e) == CP2 || (paramLong & s.e) == CP3 || (paramLong & s.e) == CP4) {
        i();
        q = m();
        q.append("P:");
        q.append(b(paramInt2, paramInt3));
        q.append(" ");
        q.append(paramString1);
        q.append("=\"");
        q.append(paramString2);
        q.append("\"");
        a(q);
        j();
      } 
    } 
  }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, boolean paramBoolean) { parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramBoolean)); }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, byte[] paramArrayOfByte) {
    if (paramArrayOfByte == null) {
      String str = new String("null");
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else if ((paramLong & s.e) == CB1 || (paramLong & s.e) == CB2 || (paramLong & s.e) == CB3 || (paramLong & s.e) == CB4 || (paramLong & s.e) == MB1 || (paramLong & s.e) == MB2 || (paramLong & s.e) == MB3 || (paramLong & s.e) == MB4) {
      a(paramLong, paramInt1, "Method", paramInt2, paramInt3, paramString, paramArrayOfByte);
    } 
  }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, char paramChar) { parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramChar)); }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, double paramDouble) { parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramDouble)); }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, float paramFloat) { parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramFloat)); }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, int paramInt4) { parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramInt4)); }
  
  public static void parameter(long paramLong1, int paramInt1, int paramInt2, int paramInt3, String paramString, long paramLong2) { parameter(paramLong1, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramLong2)); }
  
  public static void parameter(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString, Object paramObject) {
    if (paramObject == null) {
      String str = new String("null");
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, str);
    } else {
      parameter(paramLong, paramInt1, paramInt2, paramInt3, paramString, (new String()).valueOf(paramObject));
    } 
  }
  
  private static void a(long paramLong, int paramInt1, String paramString1, int paramInt2, int paramInt3, String paramString2, byte[] paramArrayOfByte) {
    if (d && c(paramInt1)) {
      ab = paramInt1;
      i();
      q = m();
      q.append(e.a());
      q.append(" Buffer: ");
      if (!paramString1.equals("") && paramInt2 > 0 && paramInt3 > 0) {
        q.append(paramString1);
        q.append(": ");
        q.append(b(paramInt2, paramInt3));
        q.append(" - ");
      } else if (!paramString1.equals("")) {
        q.append(paramString1);
        q.append(" - ");
      } else if (paramInt2 > 0 && paramInt3 > 0) {
        q.append(b(paramInt2, paramInt3));
        q.append(" - ");
      } 
      q.append(paramString2);
      a(q);
      q = m();
      q.append("address=\"" + paramArrayOfByte);
      q.append("\", length=" + paramArrayOfByte.length);
      a(q);
      a(paramArrayOfByte);
      q = m();
      q.append(e.b());
      q.append(" End of Buffer");
      a(q);
      j();
    } 
  }
  
  public static void showMemoryUsage(long paramLong, int paramInt) {
    if (d && c(paramInt)) {
      ab = paramInt;
      if ((paramLong & s.e) == RM) {
        i();
        q = m();
        q.append(e.a());
        q.append(" R:MemoryUsage");
        long l1 = Runtime.getRuntime().totalMemory();
        long l2 = l1 - Runtime.getRuntime().freeMemory();
        q.append(": ");
        q.append(a(l2));
        q.append(" ( " + l2);
        q.append(" bytes), reserved: ");
        q.append(a(l1));
        q.append(e.b());
        a(q);
        j();
      } 
    } 
  }
  
  private static String a(long paramLong) {
    StringBuffer stringBuffer = new StringBuffer();
    String[] arrayOfString = { "", "bytes", "kB", "MB", "GB", "TB" };
    byte b1 = 1;
    long l1 = paramLong;
    while (paramLong / 1024L > 0L) {
      l1 = paramLong;
      b1++;
      paramLong /= 1024L;
    } 
    int i1 = (int)(l1 % 1024L);
    int i2 = i1 / 100;
    stringBuffer.append(paramLong);
    if (i2 > 0) {
      stringBuffer.append(".");
      stringBuffer.append(i2);
    } 
    stringBuffer.append(" ");
    stringBuffer.append(arrayOfString[b1]);
    return stringBuffer.toString();
  }
  
  public static void startThreadID(long paramLong, int paramInt) {
    if (d && c(paramInt)) {
      ab = paramInt;
      if ((paramLong & s.e) == RPT) {
        i();
        q = m();
        q.append(e.a());
        q.append(" R:block-start-threadID=\"");
        q.append(z.p);
        q.append("\" ");
        q();
        q.append(e.b());
        a(q);
        j();
      } 
    } 
  }
  
  public static void endThreadID(long paramLong, int paramInt) {
    if (d && c(paramInt)) {
      ab = paramInt;
      if ((paramLong & s.e) == RPT) {
        i();
        q = m();
        q.append(e.a());
        q.append(" R:block-end-threadID=\"");
        q.append(m);
        q.append("\" ");
        q();
        q.append(e.b());
        a(q);
        j();
      } 
    } 
  }
  
  private static void q() {
    int i1 = Thread.currentThread().activeCount();
    q.append("[" + i1);
    q.append(" active thread(s)] ");
  }
  
  public static void guiInfo(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString) {
    if (d && c(paramInt1)) {
      ab = paramInt1;
      if ((paramLong & s.e) == GUI) {
        i();
        q = m();
        q.append(e.a());
        q.append(" Event:");
        q.append(b(paramInt2, paramInt3));
        if (!paramString.equals("")) {
          q.append(" I:");
          q.append(paramString);
        } 
        q.append(" ");
        q.append(e.b());
        a(q);
        j();
      } 
    } 
  }
  
  public static void guiInfo(long paramLong, int paramInt1, int paramInt2, int paramInt3) { guiInfo(paramLong, paramInt1, paramInt2, paramInt3, ""); }
  
  private static String b(int paramInt1, int paramInt2) {
    null = "";
    return e.a(paramInt1) + e.b(paramInt2);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\trace\Trace.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */