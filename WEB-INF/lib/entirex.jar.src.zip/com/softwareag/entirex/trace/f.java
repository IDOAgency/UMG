package com.softwareag.entirex.trace;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Enumeration;
import java.util.Hashtable;

public final class f {
  private PrintWriter a = null;
  
  private OutputStream b = null;
  
  private int c = 0;
  
  private boolean d = false;
  
  private String e = null;
  
  private static Hashtable f = new Hashtable();
  
  private static String g = "Semaphore";
  
  public f(String paramString, boolean paramBoolean1, boolean paramBoolean2) { a(paramString, paramBoolean1, paramBoolean2); }
  
  public f(String paramString1, String paramString2, boolean paramBoolean) throws IOException {
    String str = paramString2;
    str = str.replace('*', '_');
    paramString2 = str;
    a(paramString1, paramString2, paramBoolean);
  }
  
  public f(String paramString, Socket paramSocket, boolean paramBoolean) throws IOException { a(paramString, paramSocket, paramBoolean); }
  
  public void a(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
    if (Trace.l)
      paramString = "00000000"; 
    PrintWriter printWriter = (PrintWriter)f.get(paramString);
    synchronized (g) {
      if (printWriter == null) {
        this.d = paramBoolean2;
        if (paramBoolean1) {
          printWriter = new PrintWriter(System.out, this.d);
          this.c = 10;
        } else {
          printWriter = new PrintWriter(System.err, this.d);
          this.c = 20;
        } 
        if (printWriter != null)
          f.put(paramString, printWriter); 
        this.e = "";
      } 
    } 
  }
  
  public void a(String paramString1, String paramString2, boolean paramBoolean) throws IOException {
    try {
      if (Trace.l)
        paramString1 = "00000000"; 
      PrintWriter printWriter = (PrintWriter)f.get(paramString1);
      synchronized (g) {
        if (printWriter == null) {
          this.d = paramBoolean;
          this.b = new FileOutputStream(paramString2);
          printWriter = new PrintWriter(this.b, this.d);
          if (printWriter != null)
            f.put(paramString1, printWriter); 
          this.c = 30;
          this.e = paramString2;
        } 
      } 
      if (Trace.a());
    } catch (IOException iOException) {
      throw iOException;
    } catch (Throwable throwable) {}
  }
  
  public void a(String paramString, Socket paramSocket, boolean paramBoolean) throws IOException {
    if (Trace.l)
      paramString = "00000000"; 
    PrintWriter printWriter = (PrintWriter)f.get(paramString);
    synchronized (g) {
      if (printWriter == null) {
        this.d = paramBoolean;
        this.b = paramSocket.getOutputStream();
        printWriter = new PrintWriter(this.b, this.d);
        if (printWriter != null)
          f.put(paramString, printWriter); 
        this.c = 40;
      } 
    } 
  }
  
  public static void a(String paramString) {
    if (Trace.l)
      paramString = "00000000"; 
    PrintWriter printWriter = (PrintWriter)f.get(paramString);
    synchronized (g) {
      if (printWriter != null) {
        printWriter.close();
        f.remove(paramString);
      } 
    } 
  }
  
  public void a() {
    Enumeration enumeration = f.elements();
    while (enumeration.hasMoreElements()) {
      PrintWriter printWriter = (PrintWriter)enumeration.nextElement();
      synchronized (g) {
        printWriter.close();
      } 
    } 
    f.clear();
  }
  
  public static PrintWriter b(String paramString) {
    PrintWriter printWriter = null;
    if (Trace.l)
      paramString = "00000000"; 
    printWriter = (PrintWriter)f.get(paramString);
    if (printWriter == null)
      System.err.println("TraceWriter.getPrintWriter == 0 threadID:" + paramString); 
    return printWriter;
  }
  
  public void a(String paramString1, String paramString2) {
    if (paramString2 != null) {
      if (Trace.l)
        paramString1 = "00000000"; 
      PrintWriter printWriter = (PrintWriter)f.get(paramString1);
      synchronized (g) {
        if (printWriter != null) {
          printWriter.println(paramString2);
          if (Trace.a() && printWriter.checkError()) {
            System.err.println("TraceWriter.printLn() : Error during write checkError");
            Error error = new Error("ERROR in Trace(): printLn failed, line=" + paramString2);
            throw error;
          } 
        } else {
          System.err.println("TraceWriter.printLn() : no PrintWriter for tID:" + paramString1);
        } 
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\trace\f.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */