package com.softwareag.entirex.base;

import com.softwareag.entirex.trace.Trace;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class EntireXFileLoader {
  protected boolean a = false;
  
  protected boolean b = false;
  
  protected String c;
  
  protected String d;
  
  protected String e;
  
  protected URL f;
  
  protected boolean g;
  
  protected boolean h;
  
  protected boolean i;
  
  protected boolean j;
  
  protected boolean k;
  
  protected boolean l;
  
  protected File m;
  
  protected JarEntry n;
  
  protected long o;
  
  protected String p;
  
  public EntireXFileLoader() { this(null); }
  
  public EntireXFileLoader(String paramString) { this(paramString, null); }
  
  public EntireXFileLoader(String paramString1, String paramString2) {
    a();
    this.b = Trace.on(7, this);
    setWorkingDirectory(paramString2);
    setFileName(paramString1);
  }
  
  protected void a() {
    this.c = null;
    this.d = null;
    this.e = null;
    this.f = null;
    this.g = false;
    this.h = false;
    this.i = false;
    this.j = false;
    this.k = false;
    this.l = false;
    this.m = null;
    this.n = null;
    this.o = 0L;
    this.p = null;
  }
  
  public void setWorkingDirectory(String paramString) {
    if (paramString == null)
      try {
        paramString = System.getProperty("user.dir");
        this.j = true;
        if (this.a)
          System.out.println("EntireXFileLoader.setWorkingDirectory() isUserDir"); 
      } catch (Exception exception) {} 
    if (this.a)
      System.out.println("EntireXFileLoader.setWorkingDirectory()=" + paramString); 
    this.e = paramString;
  }
  
  public String b() { return this.e; }
  
  public void setFileName(String paramString) {
    this.c = paramString;
    if (this.c != null) {
      this.d = paramString;
      if (this.a)
        System.out.println("First trial with fileName='" + this.c + "'"); 
      if (this.b)
        Trace.checkpoint(Trace.CP4, 7, 44, 109, "First trial with fileName='" + this.c + "'"); 
      boolean bool = l();
      if (!bool) {
        c();
        if (this.a)
          System.out.println("Second trial with fileName='" + this.c + "'"); 
        if (this.b)
          Trace.checkpoint(Trace.CP4, 7, 44, 109, "Second trial with fileName='" + this.c + "'"); 
        bool = l();
        if (!bool) {
          bool = m();
          if (!bool) {
            if (this.a)
              System.out.println("Last trial. Check the classpath and look into the JAR files."); 
            if (this.b)
              Trace.checkpoint(Trace.CP4, 7, 44, 109, "Last trial. Check the classpath and look into the JAR files."); 
            try {
              String str = System.getProperty("java.class.path");
              if (str != null) {
                if (this.a)
                  System.out.println("java.class.path=" + str); 
                if (this.b)
                  Trace.checkpoint(Trace.CP4, 7, 44, 109, "java.class.path", str); 
                Vector vector = new Vector();
                StringTokenizer stringTokenizer = new StringTokenizer(str, File.pathSeparator);
                String str1 = null;
                while (stringTokenizer.hasMoreElements()) {
                  str1 = (String)stringTokenizer.nextElement();
                  if (str1.toLowerCase().endsWith(".jar")) {
                    vector.addElement(str1);
                    if (this.b)
                      Trace.checkpoint(Trace.CP4, 7, 44, 109, "jar file name", str1); 
                  } 
                } 
                if (this.a)
                  System.out.println("VECTOR=" + vector); 
                bool = a(vector);
              } 
            } catch (Exception exception) {}
            if (!bool) {
              if (this.a)
                System.out.println("Could not find any fileName='" + this.c + "'"); 
              if (this.b)
                Trace.checkpoint(Trace.CP4, 7, 44, 109, "Could not find any fileName='" + this.c + "'"); 
            } 
          } 
        } 
      } 
    } 
  }
  
  protected void c() {
    if (this.e != null) {
      if (!this.e.endsWith(File.separator) && !this.e.endsWith("/"))
        this.e += File.separator; 
      if (this.c.startsWith(File.separator) || this.c.startsWith("/"))
        this.c = this.c.substring(1); 
      File file = new File(this.e + this.c);
      boolean bool = false;
      try {
        this.c = file.getCanonicalPath();
        bool = true;
      } catch (Exception exception) {
        this.c = file.getAbsolutePath();
      } 
      if (this.a)
        System.out.println("EntireXFileLoader.prepare() new " + (bool ? "resolved " : "") + "fileName='" + this.c + "'"); 
    } 
  }
  
  protected boolean a(Vector paramVector) {
    boolean bool = false;
    for (byte b1 = 0; b1 < paramVector.size(); b1++) {
      try {
        File file = new File((String)paramVector.elementAt(b1));
        JarFile jarFile = new JarFile(file);
        if (jarFile != null) {
          JarEntry jarEntry = jarFile.getJarEntry(this.d);
          if (jarEntry != null) {
            this.f = new URL("jar", "", file.toURL() + "!/" + jarEntry.getName());
            if (this.a)
              System.out.println("url=" + this.f); 
            this.i = true;
            bool = true;
            break;
          } 
        } 
      } catch (Exception exception) {}
    } 
    return bool;
  }
  
  public String getFileName() { return this.c; }
  
  public long d() { return this.o; }
  
  public boolean e() { return this.g; }
  
  public boolean f() { return this.h; }
  
  public boolean g() { return this.i; }
  
  public boolean h() { return this.j; }
  
  public InputStream getFileAsInputStream() throws IOException {
    if (this.a)
      System.out.println("EntireXFileLoader.getFileAsInputStream()"); 
    if (this.i) {
      JarURLConnection jarURLConnection = (JarURLConnection)this.f.openConnection();
      return jarURLConnection.getInputStream();
    } 
    if (this.h) {
      HttpURLConnection httpURLConnection = (HttpURLConnection)this.f.openConnection();
      return httpURLConnection.getInputStream();
    } 
    return this.g ? this.f.openStream() : new FileInputStream(this.c);
  }
  
  public Reader i() throws IOException {
    if (this.a)
      System.out.println("EntireXFileLoader.getFileAsReader()"); 
    return new InputStreamReader(getFileAsInputStream());
  }
  
  public byte[] j() throws IOException {
    if (this.a)
      System.out.println("EntireXFileLoader.getFileAsbyteArray()"); 
    int i1 = (int)d();
    byte[] arrayOfByte = new byte[i1];
    InputStream inputStream = getFileAsInputStream();
    if (f()) {
      byte b1 = 1;
      char c1 = 'Ѐ';
      byte[] arrayOfByte1 = new byte[c1];
      byte[] arrayOfByte2 = new byte[c1];
      BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
      while ((i1 = bufferedInputStream.read(arrayOfByte1)) != -1) {
        if (b1 > 1) {
          System.arraycopy(arrayOfByte, 0, arrayOfByte2, 0, arrayOfByte.length);
          arrayOfByte = new byte[arrayOfByte.length + i1];
          System.arraycopy(arrayOfByte2, 0, arrayOfByte, 0, arrayOfByte2.length);
          System.arraycopy(arrayOfByte1, 0, arrayOfByte, arrayOfByte2.length, i1);
        } else {
          arrayOfByte = new byte[i1];
          System.arraycopy(arrayOfByte1, 0, arrayOfByte, 0, i1);
        } 
        arrayOfByte2 = new byte[arrayOfByte.length];
        b1++;
      } 
      i1 = arrayOfByte.length;
      this.o = i1;
      bufferedInputStream.close();
    } else {
      DataInputStream dataInputStream = new DataInputStream(inputStream);
      dataInputStream.readFully(arrayOfByte, 0, i1);
      dataInputStream.close();
    } 
    inputStream.close();
    return arrayOfByte;
  }
  
  public String k() {
    if (this.a)
      System.out.println("EntireXFileLoader.getFileAsString()"); 
    return new String(j());
  }
  
  protected boolean l() {
    if (this.b) {
      Trace.checkpoint(Trace.CP4, 7, 44, 35, "fileName", this.c);
      Trace.checkpoint(Trace.CP4, 7, 44, 35, "workingDirectory", this.e);
    } 
    if (this.a)
      System.out.println("EntireXFileLoader.prepare() fileName='" + this.c + "'"); 
    this.k = false;
    this.l = false;
    this.p = null;
    this.h = false;
    this.i = false;
    this.g = false;
    if (this.c != null) {
      boolean bool = this.c.startsWith("/");
      a(bool);
      if (!this.k) {
        this.m = new File(this.c);
        if (!a(this.m)) {
          this.m = new File("/" + this.c);
          if (a(this.m)) {
            if (this.a)
              System.out.println("EntireXFileLoader.prepare() found file with slash"); 
            this.o = this.m.length();
            this.l = true;
            try {
              this.p = this.m.getCanonicalPath();
            } catch (Exception exception) {
              this.p = this.m.getAbsolutePath();
            } 
          } 
        } else {
          if (this.a)
            System.out.println("EntireXFileLoader.prepare() found file"); 
          this.o = this.m.length();
          this.k = true;
          try {
            this.p = this.m.getCanonicalPath();
          } catch (Exception exception) {
            this.p = this.m.getAbsolutePath();
          } 
        } 
        if (!this.k && !this.l) {
          this.f = a(this, this.c);
          if (this.f == null) {
            this.f = a(this, "/" + this.c);
            this.l = a(this.f);
            if (this.l) {
              if (this.a)
                System.out.println("EntireXFileLoader.prepare() found urlresource with slash"); 
              this.p = this.f.toExternalForm();
            } 
          } else {
            this.k = a(this.f);
            if (this.k) {
              if (this.a)
                System.out.println("EntireXFileLoader.prepare() found urlresource"); 
              this.p = this.f.toExternalForm();
            } 
          } 
          if (!this.k && !this.l) {
            try {
              this.f = new URL(this.c);
              this.k = a(this.f);
              if (this.k) {
                if (this.a)
                  System.out.println("EntireXFileLoader.prepare() found url"); 
                this.p = this.f.toExternalForm();
              } 
            } catch (Exception exception) {}
            if (!this.k && !this.l)
              try {
                this.f = new URL("file://" + this.c);
                if (this.f == null) {
                  this.f = new URL("file:///" + this.c);
                  this.l = a(this.f);
                  if (this.l) {
                    if (this.a)
                      System.out.println("EntireXFileLoader.prepare() found created url with slash"); 
                    this.p = this.f.toExternalForm();
                  } 
                } else {
                  this.k = a(this.f);
                  if (this.k) {
                    if (this.a)
                      System.out.println("EntireXFileLoader.prepare() found created url"); 
                    this.p = this.f.toExternalForm();
                  } 
                } 
              } catch (Exception exception) {} 
          } 
          if (this.f != null)
            if (this.f.getProtocol().equalsIgnoreCase("jar")) {
              try {
                if (this.a)
                  System.out.println("EntireXFileLoader.prepare() found url jar"); 
                JarURLConnection jarURLConnection = (JarURLConnection)this.f.openConnection();
                if (jarURLConnection != null) {
                  if (this.a)
                    System.out.println("EntireXFileLoader.prepare() found urlcon"); 
                  this.i = true;
                  this.n = jarURLConnection.getJarEntry();
                  if (this.n != null)
                    this.o = this.n.getSize(); 
                  if (this.a)
                    System.out.println("EntireXFileLoader.prepare() jarEntry=" + this.n); 
                  if (this.n != null)
                    this.p = this.f.toExternalForm() + "/!" + this.n.getName(); 
                } 
              } catch (Exception exception) {}
            } else if (this.f.getProtocol().equalsIgnoreCase("http") && (this.k || this.l)) {
              if (this.a)
                System.out.println("EntireXFileLoader.prepare() found url http"); 
              this.h = true;
            } else if (this.f.getProtocol().equalsIgnoreCase("file") && (this.k || this.l)) {
              if (this.a)
                System.out.println("EntireXFileLoader.prepare() found url file"); 
              this.g = true;
            }  
        } 
        if (this.i && this.n == null) {
          this.i = false;
        } else if (this.f != null && !this.k && !this.l) {
          if (this.a)
            System.out.println("EntireXFileLoader.prepare() url=" + this.f); 
          this.m = new File(this.f.getFile());
          this.k = a(this.m);
          if (this.k) {
            this.c = this.f.getFile();
            this.o = this.m.length();
            this.g = true;
            try {
              this.p = this.m.getCanonicalPath();
            } catch (Exception exception) {
              this.p = this.m.getAbsolutePath();
            } 
          } else {
            this.k = a(this.f);
            if (this.k) {
              this.g = true;
              this.p = this.c;
            } 
          } 
        } 
        if (this.l) {
          this.c = "/" + this.c;
        } else if (!this.k) {
          this.c = this.d;
          if (this.a)
            System.out.println("EntireXFileLoader.prepare() FILE NOT FOUND !"); 
          if (this.b)
            Trace.checkpoint(Trace.CP4, 7, 44, 35, "FILE " + this.c + " NOT FOUND !"); 
          try {
            this.f = new URL(this.c);
          } catch (Exception exception) {}
        } 
        if (this.a)
          System.out.println("EntireXFileLoader.prepare() fileName=" + this.c + ", j:" + this.i + ", u:" + this.g + ", h:" + this.h + ", " + this.o); 
      } 
    } 
    if (this.b && (this.k || this.l) && this.p != null)
      Trace.checkpoint(Trace.CP1, 7, 44, 35, "Use File '" + this.p + "'"); 
    return (this.k || this.l);
  }
  
  protected boolean a(URL paramURL) {
    boolean bool = false;
    if (paramURL != null) {
      bool = a(new File(paramURL.getFile()));
      if (!bool)
        if (paramURL.getProtocol().equalsIgnoreCase("http")) {
          try {
            HttpURLConnection httpURLConnection = (HttpURLConnection)paramURL.openConnection();
            httpURLConnection.setDoInput(true);
            InputStream inputStream = httpURLConnection.getInputStream();
            bool = a(inputStream);
            this.h = bool;
          } catch (Exception exception) {}
        } else {
          try {
            URLConnection uRLConnection = paramURL.openConnection();
            uRLConnection.setDoInput(true);
            InputStream inputStream = uRLConnection.getInputStream();
            bool = a(inputStream);
            this.g = bool;
          } catch (Exception exception) {}
        }  
    } 
    if (this.a)
      System.out.println("EntireXFileLoader.checkURL(" + paramURL + ")=" + bool); 
    return bool;
  }
  
  protected boolean a(InputStream paramInputStream) {
    boolean bool = false;
    if (paramInputStream != null)
      try {
        this.o = paramInputStream.available();
        if (this.o > 0L) {
          bool = true;
        } else {
          boolean bool1 = paramInputStream.markSupported();
          if (bool1)
            paramInputStream.mark(1); 
          int i1 = paramInputStream.read();
          if (i1 != -1) {
            bool = true;
            this.o = 1L;
            while ((i1 = paramInputStream.read()) != -1)
              this.o++; 
          } 
          if (bool1)
            paramInputStream.reset(); 
        } 
      } catch (Exception exception) {} 
    if (this.a)
      System.out.println("EntireXFileLoader.checkStream(in)=" + bool + (bool ? (",size=" + this.o) : "")); 
    return bool;
  }
  
  protected boolean a(File paramFile) {
    boolean bool = false;
    if (paramFile != null)
      bool = (paramFile.exists() && paramFile.canRead() && !paramFile.isDirectory()); 
    if (this.a)
      System.out.println("EntireXFileLoader.checkFile(" + paramFile + ")=" + bool); 
    return bool;
  }
  
  protected URL a(Object paramObject, String paramString) {
    URL uRL = null;
    if (paramObject != null)
      uRL = paramObject.getClass().getResource(paramString); 
    return uRL;
  }
  
  protected boolean m() { return false; }
  
  protected void a(boolean paramBoolean) {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\base\EntireXFileLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */