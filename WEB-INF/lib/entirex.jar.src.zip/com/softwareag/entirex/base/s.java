package com.softwareag.entirex.base;

import java.io.UnsupportedEncodingException;
import java.util.Hashtable;

public class s {
  private static final s a = new s();
  
  private static final Hashtable b = new Hashtable();
  
  public final byte c;
  
  public final byte d;
  
  public final byte e;
  
  public final byte f;
  
  public final byte g;
  
  public final byte h;
  
  public final byte i;
  
  public final byte j;
  
  public final byte k;
  
  public final byte l;
  
  public final byte m;
  
  public final byte n;
  
  public final byte o;
  
  public final byte p;
  
  public final byte q;
  
  public final byte r;
  
  public final byte s;
  
  public final byte[] t;
  
  public final byte[] u;
  
  public final byte v;
  
  public final byte w;
  
  public final byte x;
  
  public final byte y;
  
  public final byte z;
  
  public final byte[] aa;
  
  public final byte[] ab;
  
  public final byte ac;
  
  public final byte ad;
  
  public final byte ae;
  
  public final byte af;
  
  private String ag = null;
  
  public static s a() { return a; }
  
  public static s a(String paramString) throws UnsupportedEncodingException {
    s s1;
    if (paramString == null) {
      s1 = a;
    } else {
      s1 = (s)b.get(paramString);
      if (s1 == null) {
        s1 = new s(paramString);
        b.put(paramString, s1);
      } 
    } 
    return s1;
  }
  
  private s() {
    byte[] arrayOfByte = ".=,{ -+EMS0123456789ABCDEFYXO()*".getBytes();
    this.c = arrayOfByte[0];
    this.d = arrayOfByte[1];
    this.e = arrayOfByte[2];
    this.f = arrayOfByte[3];
    this.g = arrayOfByte[4];
    this.h = arrayOfByte[5];
    this.i = arrayOfByte[6];
    this.v = arrayOfByte[7];
    this.w = arrayOfByte[8];
    this.x = arrayOfByte[9];
    this.j = arrayOfByte[10];
    this.k = arrayOfByte[11];
    this.l = arrayOfByte[12];
    this.m = arrayOfByte[13];
    this.n = arrayOfByte[14];
    this.o = arrayOfByte[15];
    this.p = arrayOfByte[16];
    this.q = arrayOfByte[17];
    this.r = arrayOfByte[18];
    this.s = arrayOfByte[19];
    this.t = new byte[10];
    System.arraycopy(arrayOfByte, 10, this.t, 0, 10);
    this.u = new byte[16];
    System.arraycopy(arrayOfByte, 10, this.u, 0, 16);
    this.y = arrayOfByte[26];
    this.z = arrayOfByte[27];
    this.ac = arrayOfByte[28];
    this.ad = arrayOfByte[29];
    this.ae = arrayOfByte[30];
    this.af = arrayOfByte[31];
    this.aa = new byte[13];
    this.aa[0] = this.i;
    this.aa[1] = this.j;
    this.aa[2] = this.c;
    this.aa[3] = this.j;
    this.aa[4] = this.j;
    this.aa[5] = this.j;
    this.aa[6] = this.j;
    this.aa[7] = this.j;
    this.aa[8] = this.j;
    this.aa[9] = this.v;
    this.aa[10] = this.i;
    this.aa[11] = this.j;
    this.aa[12] = this.j;
    this.ab = new byte[22];
    this.ab[0] = this.i;
    this.ab[1] = this.j;
    this.ab[2] = this.c;
    this.ab[3] = this.j;
    this.ab[4] = this.j;
    this.ab[5] = this.j;
    this.ab[6] = this.j;
    this.ab[7] = this.j;
    this.ab[8] = this.j;
    this.ab[9] = this.j;
    this.ab[10] = this.j;
    this.ab[11] = this.j;
    this.ab[12] = this.j;
    this.ab[13] = this.j;
    this.ab[14] = this.j;
    this.ab[15] = this.j;
    this.ab[16] = this.j;
    this.ab[17] = this.j;
    this.ab[18] = this.v;
    this.ab[19] = this.i;
    this.ab[20] = this.j;
    this.ab[21] = this.j;
  }
  
  public String b() { return this.ag; }
  
  private s(String paramString) throws UnsupportedEncodingException {
    this.ag = paramString;
    byte[] arrayOfByte = ".=,{ -+EMS0123456789ABCDEFYXO()*".getBytes(paramString);
    this.c = arrayOfByte[0];
    this.d = arrayOfByte[1];
    this.e = arrayOfByte[2];
    this.f = arrayOfByte[3];
    this.g = arrayOfByte[4];
    this.h = arrayOfByte[5];
    this.i = arrayOfByte[6];
    this.v = arrayOfByte[7];
    this.w = arrayOfByte[8];
    this.x = arrayOfByte[9];
    this.j = arrayOfByte[10];
    this.k = arrayOfByte[11];
    this.l = arrayOfByte[12];
    this.m = arrayOfByte[13];
    this.n = arrayOfByte[14];
    this.o = arrayOfByte[15];
    this.p = arrayOfByte[16];
    this.q = arrayOfByte[17];
    this.r = arrayOfByte[18];
    this.s = arrayOfByte[19];
    this.t = new byte[10];
    System.arraycopy(arrayOfByte, 10, this.t, 0, 10);
    this.u = new byte[16];
    System.arraycopy(arrayOfByte, 10, this.u, 0, 16);
    this.y = arrayOfByte[26];
    this.z = arrayOfByte[27];
    this.ac = arrayOfByte[28];
    this.ad = arrayOfByte[29];
    this.ae = arrayOfByte[30];
    this.af = arrayOfByte[31];
    this.aa = new byte[13];
    this.aa[0] = this.i;
    this.aa[1] = this.j;
    this.aa[2] = this.c;
    this.aa[3] = this.j;
    this.aa[4] = this.j;
    this.aa[5] = this.j;
    this.aa[6] = this.j;
    this.aa[7] = this.j;
    this.aa[8] = this.j;
    this.aa[9] = this.v;
    this.aa[10] = this.i;
    this.aa[11] = this.j;
    this.aa[12] = this.j;
    this.ab = new byte[22];
    this.ab[0] = this.i;
    this.ab[1] = this.j;
    this.ab[2] = this.c;
    this.ab[3] = this.j;
    this.ab[4] = this.j;
    this.ab[5] = this.j;
    this.ab[6] = this.j;
    this.ab[7] = this.j;
    this.ab[8] = this.j;
    this.ab[9] = this.j;
    this.ab[10] = this.j;
    this.ab[11] = this.j;
    this.ab[12] = this.j;
    this.ab[13] = this.j;
    this.ab[14] = this.j;
    this.ab[15] = this.j;
    this.ab[16] = this.j;
    this.ab[17] = this.j;
    this.ab[18] = this.v;
    this.ab[19] = this.i;
    this.ab[20] = this.j;
    this.ab[21] = this.j;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\base\s.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */