package com.softwareag.entirex.base;

import com.softwareag.entirex.trace.Trace;
import java.io.IOException;
import java.io.InputStream;
import javax.servlet.ServletContext;

public class a4 extends XMLFileLoader {
  protected ServletContext a;
  
  protected boolean b;
  
  public a4(String paramString, ServletContext paramServletContext) { this(paramString, null, paramServletContext); }
  
  public a4(String paramString1, String paramString2, ServletContext paramServletContext) {
    a();
    super.b = Trace.on(7, this);
    setWorkingDirectory(paramString2);
    a(paramServletContext);
    setFileName(paramString1);
  }
  
  protected void a() {
    super.a();
    this.a = null;
    this.b = false;
  }
  
  public void a(ServletContext paramServletContext) {
    this.a = paramServletContext;
    if (n()) {
      if (super.a)
        System.out.println("EntireXFileLoader running in Servlet environment."); 
      if (super.b)
        Trace.checkpoint(Trace.CP4, 7, 44, 109, "Running in Servlet environment."); 
    } 
  }
  
  public boolean n() { return (this.a != null); }
  
  public InputStream getFileAsInputStream() throws IOException {
    if (super.a)
      System.out.println("EntireXFileLoader.getFileAsInputStream()"); 
    return this.b ? this.a.getResourceAsStream(this.c) : super.getFileAsInputStream();
  }
  
  protected boolean m() {
    if (n()) {
      setWorkingDirectory(null);
      this.c = this.d;
      c();
      if (super.a)
        System.out.println("Third trial with fileName='" + this.c + "'"); 
      if (super.b)
        Trace.checkpoint(Trace.CP4, 7, 44, 109, "Third trial with fileName='" + this.c + "'"); 
      return l();
    } 
    return super.m();
  }
  
  protected void a(boolean paramBoolean) {
    if (n() && paramBoolean) {
      InputStream inputStream = this.a.getResourceAsStream(this.c);
      this.k = a(inputStream);
      this.b = this.k;
      if (this.k) {
        this.p = this.a.getRealPath(this.c);
        if (this.p == null)
          this.p = this.c; 
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\base\a4.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */