package com.softwareag.entirex.base;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class a5 {
  private static ResourceBundle a = null;
  
  protected String b = null;
  
  protected String c = null;
  
  protected String d = null;
  
  protected int e = 0;
  
  public static final Hashtable f;
  
  private String a(byte[] paramArrayOfByte) {
    String str = "UTF-8";
    this.e = 0;
    byte b1 = paramArrayOfByte[0] & 0xFF;
    byte b2 = paramArrayOfByte[1] & 0xFF;
    byte b3 = paramArrayOfByte[2] & 0xFF;
    byte b4 = paramArrayOfByte[3] & 0xFF;
    if (b1 == 254 && b2 == 255 && (b3 != 0 || b4 != 0)) {
      str = "UTF-16BE";
      this.e = 4;
    } else if (b1 == 255 && b2 == 254 && (b3 != 0 || b4 != 0)) {
      str = "UTF-16LE";
      this.e = 4;
    } else if (b1 == 239 && b2 == 187 && b3 == 191) {
      str = "UTF-8";
      this.e = 3;
    } else if (b1 == 0 && b2 == 0 && b3 == 0 && b4 == 60) {
      str = "ISO-10646-UCS-4";
    } else if (b1 == 60 && b2 == 0 && b3 == 0 && b4 == 0) {
      str = "ISO-10646-UCS-4";
    } else if (b1 == 0 && b2 == 0 && b3 == 60 && b4 == 0) {
      str = "ISO-10646-UCS-4";
    } else if (b1 == 0 && b2 == 60 && b3 == 0 && b4 == 0) {
      str = "ISO-10646-UCS-4";
    } else if (b1 == 0 && b2 == 60 && b3 == 0 && b4 == 63) {
      str = "UTF-16BE";
    } else if (b1 == 60 && b2 == 0 && b3 == 63 && b4 == 0) {
      str = "UTF-16LE";
    } else if (b1 == 76 && b2 == 111 && b3 == 167 && b4 == 148) {
      str = "CP500";
    } 
    return str;
  }
  
  public void a(BufferedInputStream paramBufferedInputStream) throws IOException {
    String str = null;
    if (paramBufferedInputStream != null) {
      byte[] arrayOfByte = new byte[4];
      byte b1 = 0;
      try {
        paramBufferedInputStream.mark(6);
        while (b1 < 4) {
          arrayOfByte[b1] = (byte)paramBufferedInputStream.read();
          b1++;
        } 
        paramBufferedInputStream.reset();
      } catch (IOException iOException) {
        throw new IOException("Found no valid XML declaration.");
      } 
      str = a(arrayOfByte);
      a(paramBufferedInputStream, str);
    } 
  }
  
  private void a(BufferedInputStream paramBufferedInputStream, String paramString) throws IOException, UnsupportedEncodingException {
    int i = 1000;
    int j = 1;
    String str1 = ">";
    byte[] arrayOfByte1 = null;
    int k = 0;
    k = paramBufferedInputStream.available();
    if (k < i)
      i = k; 
    byte[] arrayOfByte2 = new byte[i];
    arrayOfByte1 = str1.getBytes(paramString);
    j = arrayOfByte1.length;
    paramBufferedInputStream.mark(i);
    byte b1 = 0;
    int m = j;
    boolean bool = false;
    for (byte b2 = 0; b2 < j; b2++)
      arrayOfByte2[b2] = (byte)paramBufferedInputStream.read(); 
    i -= 2;
    while (!bool && b1 < i) {
      if (arrayOfByte2[b1] == arrayOfByte1[0]) {
        bool = true;
        if (j > 1)
          for (byte b3 = 1; bool && b3 < j; b3++) {
            bool = false;
            if (arrayOfByte2[b1 + b3] == arrayOfByte1[b3])
              bool = true; 
          }  
      } 
      if (!bool) {
        arrayOfByte2[m] = (byte)paramBufferedInputStream.read();
        b1++;
        m++;
      } 
    } 
    paramBufferedInputStream.reset();
    String str2 = new String(arrayOfByte2, 0, m, paramString);
    b(str2);
  }
  
  public void a(BufferedReader paramBufferedReader) throws IOException {
    StringBuffer stringBuffer = new StringBuffer();
    paramBufferedReader.mark(1000);
    int i = 0;
    char c1 = Character.MIN_VALUE;
    byte b1 = 0;
    boolean bool = true;
    while (bool && b1 < 'Ϩ') {
      i = paramBufferedReader.read();
      if (i == -1)
        throw new IOException("Invalid XML file."); 
      c1 = (char)i;
      if (c1 == '>')
        bool = false; 
      stringBuffer.append(c1);
      b1++;
    } 
    paramBufferedReader.reset();
    String str = stringBuffer.toString();
    b(str);
  }
  
  private void b(String paramString) {
    int i = 0;
    int j = 0;
    int k = 0;
    i = paramString.indexOf(" encoding=");
    if (i >= 0) {
      j = paramString.indexOf("\"", i);
      k = paramString.indexOf("\"", j + 1);
      if (j == -1 || k == -1) {
        j = paramString.indexOf("'", i);
        k = paramString.indexOf("'", j + 1);
      } 
      if (j == -1 || k == -1) {
        this.b = "UTF-8";
      } else {
        this.b = paramString.substring(j + 1, k);
      } 
    } else {
      this.b = "UTF-8";
    } 
    i = paramString.indexOf("version");
    if (i >= 0) {
      j = paramString.indexOf("\"", i);
      k = paramString.indexOf("\"", j + 1);
      if (j == -1 && k == -1) {
        j = paramString.indexOf("'", i);
        k = paramString.indexOf("'", j + 1);
      } 
      this.d = paramString.substring(j + 1, k);
    } else {
      this.d = "1.0";
    } 
    this.c = a(this.b);
    a();
  }
  
  protected void a() {}
  
  public String b() { return this.b; }
  
  public String c() { return this.c; }
  
  public String d() { return this.d; }
  
  public int e() { return this.e; }
  
  public boolean f() { return true; }
  
  private static void g() {
    if (a == null)
      try {
        a = ResourceBundle.getBundle("com.softwareag.entirex.base.Charsets");
      } catch (MissingResourceException missingResourceException) {} 
  }
  
  public static String a(String paramString) {
    String str = null;
    if (a != null && paramString != null)
      try {
        str = a.getString(paramString.toUpperCase());
      } catch (MissingResourceException missingResourceException) {} 
    return str;
  }
  
  static  {
    g();
    f = new Hashtable();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\base\a5.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */