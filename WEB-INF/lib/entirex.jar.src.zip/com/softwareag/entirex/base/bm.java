package com.softwareag.entirex.base;

public class bm {
  private byte[] a = new byte[512];
  
  private int b = 0;
  
  protected final void b(byte[] paramArrayOfByte) {
    int i = paramArrayOfByte.length;
    if (i == 0)
      return; 
    int j = this.b + i;
    if (j > this.a.length) {
      int k = 2 * this.a.length;
      if (k < j)
        k = j; 
      byte[] arrayOfByte = new byte[k];
      System.arraycopy(this.a, 0, arrayOfByte, 0, this.b);
      this.a = arrayOfByte;
    } 
    System.arraycopy(paramArrayOfByte, 0, this.a, this.b, i);
    this.b = j;
  }
  
  protected final void a(byte paramByte, int paramInt) {
    int i = this.b + paramInt;
    if (i > this.a.length) {
      int j = 2 * this.a.length;
      if (j < i)
        j = i; 
      byte[] arrayOfByte = new byte[j];
      System.arraycopy(this.a, 0, arrayOfByte, 0, this.b);
      this.a = arrayOfByte;
    } 
    for (byte b1 = 0; b1 < paramInt; b1++)
      this.a[this.b++] = paramByte; 
  }
  
  protected final void a(byte paramByte) {
    int i = this.b + 1;
    if (i > this.a.length) {
      byte[] arrayOfByte = new byte[2 * this.a.length];
      System.arraycopy(this.a, 0, arrayOfByte, 0, this.b);
      this.a = arrayOfByte;
    } 
    this.a[this.b++] = paramByte;
  }
  
  public final void d() { this.b = 0; }
  
  public final byte[] e() {
    byte[] arrayOfByte = new byte[this.b];
    System.arraycopy(this.a, 0, arrayOfByte, 0, this.b);
    return arrayOfByte;
  }
  
  public final void a(byte[] paramArrayOfByte, int paramInt) { System.arraycopy(this.a, 0, paramArrayOfByte, paramInt, this.b); }
  
  public final void a(bm parambm, int paramInt) { System.arraycopy(this.a, 0, parambm.a, paramInt, this.b); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\base\bm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */