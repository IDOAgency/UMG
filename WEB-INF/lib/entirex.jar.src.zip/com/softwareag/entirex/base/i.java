package com.softwareag.entirex.base;

import com.softwareag.entirex.aci.j;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Properties;

public class i {
  private static final String a = System.getProperty("line.separator");
  
  private static byte[] b = { 
      -31, -46, -61, -76, -91, 118, -121, 120, -47, 2, 
      67, -12, -75, -106, 71, 56 };
  
  static Class c;
  
  static Class d;
  
  static Class e;
  
  static Class f;
  
  public static void a(String paramString, Properties paramProperties) {
    try {
      Class clazz = Class.forName("javax.crypto.spec.SecretKeySpec");
    } catch (ClassNotFoundException classNotFoundException) {
      return;
    } 
    Enumeration enumeration = paramProperties.keys();
    StringBuffer stringBuffer = null;
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      if (str.endsWith("password")) {
        String[] arrayOfString = b(str, paramProperties);
        String str1 = arrayOfString[0];
        if (str1 != null && str1.length() > 0) {
          byte[] arrayOfByte = a(str1.getBytes(), 1);
          if (arrayOfByte != null) {
            if (stringBuffer == null)
              stringBuffer = a(paramString); 
            if (stringBuffer != null)
              a(stringBuffer, str, new String(j.a(arrayOfByte))); 
          } 
          continue;
        } 
        String str2 = arrayOfString[1];
        if (str2 != null && str2.length() > 0) {
          byte[] arrayOfByte = a(j.a(str2), 2);
          if (arrayOfByte != null) {
            String str3 = new String(arrayOfByte);
            paramProperties.put(str, str3);
          } 
        } 
      } 
    } 
    if (stringBuffer != null)
      a(paramString, stringBuffer); 
  }
  
  private static byte[] a(byte[] paramArrayOfByte, int paramInt) {
    byte[] arrayOfByte = null;
    try {
      Class clazz1;
      Class clazz2 = (clazz1 = Class.forName("javax.crypto.spec.SecretKeySpec")).forName("javax.crypto.Cipher");
      Class[] arrayOfClass1 = { (c == null) ? (c = class$("[B")) : c, (d == null) ? (d = class$("java.lang.String")) : d };
      Constructor constructor = clazz1.getConstructor(arrayOfClass1);
      Object[] arrayOfObject1 = { b, "AES" };
      Object object1 = constructor.newInstance(arrayOfObject1);
      Class[] arrayOfClass2 = { (d == null) ? (d = class$("java.lang.String")) : d };
      Method method1 = clazz2.getMethod("getInstance", arrayOfClass2);
      Object[] arrayOfObject2 = { "AES" };
      Object object2 = method1.invoke(clazz2, arrayOfObject2);
      Class[] arrayOfClass3 = { int.class, (e == null) ? (e = class$("java.security.Key")) : e };
      Method method2 = clazz2.getMethod("init", arrayOfClass3);
      Object[] arrayOfObject3 = { new Integer(paramInt), object1 };
      method2.invoke(object2, arrayOfObject3);
      Class[] arrayOfClass4 = { (c == null) ? (c = class$("[B")) : c };
      Method method3 = clazz2.getMethod("doFinal", arrayOfClass4);
      Object[] arrayOfObject4 = { paramArrayOfByte };
      arrayOfByte = (byte[])method3.invoke(object2, arrayOfObject4);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return arrayOfByte;
  }
  
  private static String[] b(String paramString, Properties paramProperties) {
    String[] arrayOfString = new String[2];
    arrayOfString[0] = (String)paramProperties.get(paramString);
    arrayOfString[1] = (String)paramProperties.get(paramString + ".e");
    return arrayOfString;
  }
  
  private static void a(StringBuffer paramStringBuffer, String paramString1, String paramString2) {
    if (paramStringBuffer != null && paramString1 != null && paramString2 != null) {
      int j = a(paramStringBuffer, paramString1 + ".e=");
      if (j > -1) {
        j += paramString1.length() + 3;
        int k = a(paramStringBuffer, a, j);
        if (k == -1)
          k = paramStringBuffer.length(); 
        a(paramStringBuffer, j, k, paramString2);
        j = a(paramStringBuffer, paramString1 + "=");
        if (j > -1) {
          j += paramString1.length() + 1;
          k = a(paramStringBuffer, a, j);
          if (k == -1)
            k = paramStringBuffer.length(); 
          a(paramStringBuffer, j, k, "");
        } 
      } else {
        j = a(paramStringBuffer, paramString1 + "=");
        if (j > -1) {
          j += paramString1.length() + 1;
          int k = a(paramStringBuffer, a, j);
          if (k == -1)
            k = paramStringBuffer.length(); 
          a(paramStringBuffer, j, k, a + paramString1 + ".e=" + paramString2);
        } 
      } 
    } 
  }
  
  private static void a(String paramString, StringBuffer paramStringBuffer) {
    if (paramString != null) {
      File file = new File(paramString);
      try {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file.getAbsolutePath()));
        bufferedWriter.write(new String(paramStringBuffer));
        bufferedWriter.close();
      } catch (FileNotFoundException fileNotFoundException) {
        System.out.println("Error with file " + paramString + ", " + fileNotFoundException.toString() + ".");
      } catch (IOException iOException) {
        System.out.println("IOException: " + iOException.toString());
      } 
    } else {
      System.out.println("File name is null.");
    } 
  }
  
  private static StringBuffer a(String paramString) {
    StringBuffer stringBuffer = new StringBuffer();
    if (paramString != null) {
      File file = new File(paramString);
      try {
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file.getAbsolutePath()));
        String str;
        while ((str = bufferedReader.readLine()) != null) {
          stringBuffer.append(str);
          stringBuffer.append(a);
        } 
        bufferedReader.close();
      } catch (FileNotFoundException fileNotFoundException) {
        System.out.println("File " + paramString + " does not exist. (" + fileNotFoundException.toString() + ")");
      } catch (IOException iOException) {
        System.out.println("IOException: " + iOException.toString());
      } 
    } else {
      System.out.println("File name is null.");
    } 
    return stringBuffer;
  }
  
  private static int a(StringBuffer paramStringBuffer, String paramString) {
    int j = -1;
    try {
      Class[] arrayOfClass = { (d == null) ? (d = class$("java.lang.String")) : d };
      Object[] arrayOfObject = { paramString };
      Integer integer = (Integer)((f == null) ? (f = class$("java.lang.StringBuffer")) : f).getMethod("indexOf", arrayOfClass).invoke(paramStringBuffer, arrayOfObject);
      j = integer.intValue();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return j;
  }
  
  private static int a(StringBuffer paramStringBuffer, String paramString, int paramInt) {
    int j = -1;
    try {
      Class[] arrayOfClass = { (d == null) ? (d = class$("java.lang.String")) : d, int.class };
      Object[] arrayOfObject = { paramString, new Integer(paramInt) };
      Integer integer = (Integer)((f == null) ? (f = class$("java.lang.StringBuffer")) : f).getMethod("indexOf", arrayOfClass).invoke(paramStringBuffer, arrayOfObject);
      j = integer.intValue();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return j;
  }
  
  private static void a(StringBuffer paramStringBuffer, int paramInt1, int paramInt2, String paramString) {
    try {
      Class[] arrayOfClass = { int.class, int.class, (d == null) ? (d = class$("java.lang.String")) : d };
      Object[] arrayOfObject = { new Integer(paramInt1), new Integer(paramInt2), paramString };
      ((f == null) ? (f = class$("java.lang.StringBuffer")) : f).getMethod("replace", arrayOfClass).invoke(paramStringBuffer, arrayOfObject);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\base\i.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */