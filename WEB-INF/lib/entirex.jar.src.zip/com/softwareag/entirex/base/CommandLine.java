package com.softwareag.entirex.base;

import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

public abstract class CommandLine {
  private Hashtable a = null;
  
  private Hashtable b = null;
  
  private Hashtable c = null;
  
  private Properties d = null;
  
  private Properties e = null;
  
  private Properties f = null;
  
  private Properties g = null;
  
  private Properties h = null;
  
  public CommandLine(Properties paramProperties, boolean paramBoolean) {
    this.h = new Properties();
    this.g = new Properties(this.h);
    this.f = new Properties(this.g);
    this.e = new Properties(this.f);
    this.d = new Properties(this.e);
    if (paramProperties != null)
      a(paramProperties); 
    if (paramBoolean)
      importSystemProperties(); 
    init();
  }
  
  public CommandLine() {
    this.h = new Properties();
    this.d = new Properties(this.h);
    init();
  }
  
  protected void init() {
    if (this.a != null)
      return; 
    this.a = new Hashtable();
    this.b = new Hashtable();
    this.c = new Hashtable();
    add(new Command("-help", 3, "false", "display this usage message"));
  }
  
  public void parse(String[] paramArrayOfString) {
    for (byte b1 = 0; b1 < paramArrayOfString.length; b1++) {
      if (paramArrayOfString[b1].startsWith("-")) {
        Command command = (Command)this.a.get(paramArrayOfString[b1].toLowerCase());
        if (command == null) {
          String str = (String)this.b.get(paramArrayOfString[b1].toLowerCase());
          if (str != null)
            command = (Command)this.a.get(str); 
        } 
        if (command != null) {
          paramArrayOfString[b1] = null;
          switch (command.d()) {
            case 3:
              if (paramArrayOfString.length > b1 + true) {
                if (paramArrayOfString[b1 + true].startsWith("-")) {
                  command.a("true");
                  break;
                } 
                if (paramArrayOfString[b1 + true].toLowerCase().startsWith("true") || paramArrayOfString[b1 + true].toLowerCase().startsWith("on")) {
                  command.a("true");
                  paramArrayOfString[++b1] = null;
                  break;
                } 
                if (paramArrayOfString[b1 + 1].toLowerCase().startsWith("false") || paramArrayOfString[b1 + 1].toLowerCase().startsWith("off")) {
                  command.a("false");
                  paramArrayOfString[++b1] = null;
                } 
                break;
              } 
              command.a("true");
              break;
            case 1:
            case 2:
              if (paramArrayOfString.length > b1 + 1) {
                command.a(paramArrayOfString[++b1]);
                paramArrayOfString[b1] = null;
                break;
              } 
              System.out.println("Value missing for keyword " + command.a());
              break;
            default:
              System.out.println("Unknown type:" + command.d());
              break;
          } 
        } 
      } 
    } 
    byte b2 = 0;
    for (byte b3 = 0; b3 < paramArrayOfString.length; b3++) {
      if (paramArrayOfString[b3] != null && !paramArrayOfString[b3].startsWith("-")) {
        Enumeration enumeration = this.a.elements();
        while (enumeration.hasMoreElements()) {
          Command command = (Command)enumeration.nextElement();
          if (command.h() == b2) {
            command.a(paramArrayOfString[b3]);
            paramArrayOfString[b3] = null;
            b2++;
            break;
          } 
        } 
      } 
    } 
    for (byte b4 = 0; b4 < paramArrayOfString.length; b4++) {
      if (paramArrayOfString[b4] != null)
        System.out.println("Unknown argument: " + paramArrayOfString[b4]); 
    } 
    if (this.d != null) {
      Enumeration enumeration = this.a.elements();
      while (enumeration.hasMoreElements()) {
        Command command = (Command)enumeration.nextElement();
        String str = command.c();
        if (str != null) {
          String str1 = command.e();
          if (str1 != null)
            this.d.put(str, str1); 
          String str2 = command.f();
          if (str2 != null)
            this.h.put(str, str2); 
        } 
      } 
    } 
  }
  
  protected void add(Command paramCommand) {
    String str = paramCommand.a();
    if (str != null) {
      this.a.put(str, paramCommand);
      String str1 = paramCommand.c();
      if (str1 != null)
        this.c.put(str1, str); 
      String str2 = paramCommand.b();
      if (str2 != null)
        this.b.put(str2, str); 
      String str3 = paramCommand.f();
      if (str1 != null && str3 != null && this.h != null)
        this.h.put(str1, str3); 
    } 
  }
  
  protected Properties c() { return this.h; }
  
  public Properties getProperties() { return this.d; }
  
  public void list(PrintStream paramPrintStream) {
    Enumeration enumeration = this.a.elements();
    while (enumeration.hasMoreElements()) {
      Command command = (Command)enumeration.nextElement();
      switch (command.d()) {
        case 3:
          paramPrintStream.println(command.a() + ": " + command.e() + " (Type: " + command.d() + ", default: " + command.f() + ")");
        case 2:
          paramPrintStream.println(command.a() + ": " + command.e() + " (Type: " + command.d() + ", default: " + command.f() + ")");
        case 1:
          paramPrintStream.println(command.a() + ": " + command.e() + " (Type: " + command.d() + ", default: " + command.f() + ")");
      } 
    } 
  }
  
  public String getString(String paramString) {
    String str = null;
    Command command = a(paramString);
    if (command != null && command.d() == 1) {
      str = command.e();
      if (str == null)
        str = command.f(); 
    } 
    return str;
  }
  
  public int getInt(String paramString) {
    Command command = a(paramString);
    if (command != null && command.d() == 2) {
      String str = command.e();
      if (str == null)
        str = command.f(); 
      if (str != null) {
        if (str.startsWith("+"))
          str = str.substring(1); 
        return Integer.parseInt(str);
      } 
      return -1;
    } 
    return -1;
  }
  
  public boolean getBoolean(String paramString) {
    Command command = a(paramString);
    if (command != null && command.d() == 3) {
      String str = command.e();
      if (str == null)
        str = command.f(); 
      return (str != null) ? str.equals("true") : 0;
    } 
    return false;
  }
  
  private Command a(String paramString) {
    Command command = (Command)this.a.get(paramString);
    if (command == null) {
      String str = (String)this.b.get(paramString);
      if (str != null)
        command = (Command)this.a.get(str); 
    } 
    if (command == null) {
      String str = (String)this.c.get(paramString);
      if (str != null)
        command = (Command)this.a.get(str); 
    } 
    return command;
  }
  
  public void usage(String paramString) {
    System.out.println("Usage " + paramString + ":");
    Enumeration enumeration = this.a.keys();
    String[] arrayOfString = new String[this.a.size()];
    byte b1 = 0;
    int i = 0;
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      arrayOfString[b1++] = str;
      if (i < str.length())
        i = str.length(); 
    } 
    k.a(arrayOfString);
    for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
      Command command = (Command)this.a.get(arrayOfString[b2]);
      System.out.println("\t" + command.a() + ":" + a(i - command.a().length() + 1) + command.g());
    } 
  }
  
  private String a(int paramInt) {
    StringBuffer stringBuffer = new StringBuffer(paramInt);
    for (byte b1 = 0; b1 < paramInt; b1++)
      stringBuffer.append(' '); 
    return new String(stringBuffer);
  }
  
  protected void a(Properties paramProperties) {
    if (this.g != null && paramProperties != null) {
      Enumeration enumeration = paramProperties.keys();
      while (enumeration.hasMoreElements()) {
        String str = (String)enumeration.nextElement();
        Object object = paramProperties.get(str);
        if (object != null && (!(object instanceof String) || ((String)object).length() != 0))
          this.g.put(str, object); 
      } 
    } 
  }
  
  public void importSystemProperties() {
    Properties properties = System.getProperties();
    if (this.h.size() > 0) {
      Enumeration enumeration = properties.keys();
      while (enumeration.hasMoreElements()) {
        String str = (String)enumeration.nextElement();
        if (this.h.containsKey(str))
          this.e.put(str, properties.get(str)); 
      } 
    } 
  }
  
  protected void b(Properties paramProperties) {}
  
  public void importPluginProperties() { b(this.f); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\base\CommandLine.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */