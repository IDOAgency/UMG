package com.softwareag.entirex.base;

public class ac {
  public static int a(byte[] paramArrayOfByte, s params) { return a(paramArrayOfByte, 0, paramArrayOfByte.length, params); }
  
  public static int a(byte[] paramArrayOfByte, int paramInt1, int paramInt2, s params) {
    byte b = 0;
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      b = b * 10 + paramArrayOfByte[i] - params.j; 
    return b;
  }
  
  public static int b(byte[] paramArrayOfByte, int paramInt1, int paramInt2, s params) {
    byte b = 0;
    boolean bool = false;
    bool = (paramArrayOfByte[paramInt1] == params.h) ? 1 : 0;
    for (int i = paramInt1 + 1; i < paramInt1 + paramInt2; i++)
      b = b * 10 + paramArrayOfByte[i] - params.j; 
    return bool ? -b : b;
  }
  
  public static byte[] a(int paramInt) {
    s s = s.a();
    return a(paramInt, s);
  }
  
  public static byte[] a(int paramInt, s params) {
    byte[] arrayOfByte = new byte[1];
    if (paramInt >= 0 && paramInt <= 9) {
      arrayOfByte[0] = params.t[paramInt];
    } else {
      String str = Integer.toString(paramInt);
      arrayOfByte = new byte[str.length()];
      for (byte b = 0; b < arrayOfByte.length; b++) {
        switch (str.charAt(b)) {
          case '0':
            arrayOfByte[b] = params.j;
            break;
          case '1':
            arrayOfByte[b] = params.k;
            break;
          case '2':
            arrayOfByte[b] = params.l;
            break;
          case '3':
            arrayOfByte[b] = params.m;
            break;
          case '4':
            arrayOfByte[b] = params.n;
            break;
          case '5':
            arrayOfByte[b] = params.o;
            break;
          case '6':
            arrayOfByte[b] = params.p;
            break;
          case '7':
            arrayOfByte[b] = params.q;
            break;
          case '8':
            arrayOfByte[b] = params.r;
            break;
          case '9':
            arrayOfByte[b] = params.s;
            break;
        } 
      } 
    } 
    return arrayOfByte;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\base\ac.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */