package com.softwareag.entirex.base;

import java.io.UnsupportedEncodingException;
import java.util.NoSuchElementException;

public class r {
  private byte[] a;
  
  private byte[] b;
  
  private static final String c = "00000000";
  
  private static final String d = "Successful response                     ";
  
  private int e;
  
  private int f;
  
  private s g;
  
  private byte[] h;
  
  private byte[][] i;
  
  public r(byte[][] paramArrayOfByte) { this(null, 0, 0, paramArrayOfByte, s.a()); }
  
  public r(byte[][] paramArrayOfByte, s params) { this(null, 0, 0, paramArrayOfByte, params); }
  
  public r(byte[] paramArrayOfByte, int paramInt1, int paramInt2, s params) { this(paramArrayOfByte, paramInt1, paramInt2, (byte[][])null, params); }
  
  public r(byte[] paramArrayOfByte, int paramInt1, int paramInt2, byte[][] paramArrayOfByte1, s params) {
    this.i = paramArrayOfByte1;
    this.g = params;
    g();
    a(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public r(byte[] paramArrayOfByte, int paramInt1, int paramInt2, String[] paramArrayOfString, s params) {
    this.g = params;
    this.i = a(paramArrayOfString);
    g();
    a(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  private void g() {
    if (this.g == null || this.g.b() == null) {
      this.a = "00000000".getBytes();
      this.b = "Successful response                     ".getBytes();
    } else {
      try {
        this.a = "00000000".getBytes(this.g.b());
        this.b = "Successful response                     ".getBytes(this.g.b());
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        this.a = "00000000".getBytes();
        this.b = "Successful response                     ".getBytes();
      } 
    } 
  }
  
  public void a(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    this.h = paramArrayOfByte;
    this.e = paramInt1;
    this.f = paramInt1 + paramInt2;
  }
  
  public boolean a() {
    while (this.e < this.f && this.h[this.e] == this.g.e)
      this.e++; 
    return (this.e < this.f);
  }
  
  public String b() {
    if (this.h[this.e] == this.g.e)
      this.e++; 
    if (this.e >= this.f)
      throw new NoSuchElementException(); 
    int j = this.e;
    while (this.e < this.f && this.h[this.e] != this.g.d)
      this.e++; 
    return new String(this.h, j, this.e - j);
  }
  
  public int c() {
    boolean bool = false;
    byte b1 = -1;
    if (this.h[this.e] == this.g.e)
      this.e++; 
    if (this.e >= this.f)
      throw new NoSuchElementException(); 
    int j = this.e;
    while (this.e < this.f && this.h[this.e] != this.g.d)
      this.e++; 
    if (this.i != null) {
      int k = this.i.length;
      for (byte b2 = 0; b2 < k; b2++) {
        bool = true;
        int m = this.i[b2].length;
        if (m == this.e - j) {
          for (int n = 0; j + n < this.e && n < m; n++) {
            if (this.h[j + n] != this.i[b2][n]) {
              bool = false;
              break;
            } 
          } 
        } else {
          bool = false;
        } 
        if (bool) {
          b1 = b2;
          break;
        } 
      } 
    } 
    return b1;
  }
  
  public String d() {
    String str = null;
    if (this.h[this.e] == this.g.d)
      this.e++; 
    if (this.e >= this.f)
      throw new NoSuchElementException(); 
    int j = this.e;
    while (this.e < this.f && this.h[this.e] != this.g.e)
      this.e++; 
    if (this.e - j == 8 && a(this.a)) {
      str = "00000000";
    } else {
      str = new String(this.h, j, this.e - j);
    } 
    return str;
  }
  
  public String a(int paramInt) {
    String str = null;
    if (this.h[this.e] == this.g.d || this.h[this.e] == this.g.e)
      this.e++; 
    if (this.e + paramInt > this.f)
      throw new NoSuchElementException(); 
    int j = this.e;
    if (this.e - j == 40 && a(this.b)) {
      str = "Successful response                     ";
    } else {
      str = new String(this.h, j, paramInt);
    } 
    this.e += paramInt;
    return str;
  }
  
  public int e() {
    byte b1 = 0;
    if (this.h[this.e] == this.g.d)
      this.e++; 
    if (this.e >= this.f)
      throw new NoSuchElementException(); 
    int j = this.e;
    while (this.e < this.f && this.h[this.e] != this.g.e) {
      b1 = 10 * b1 + this.h[this.e] - this.g.j;
      this.e++;
    } 
    return b1;
  }
  
  public byte[] f() {
    if (this.h[this.e] == this.g.d)
      this.e++; 
    if (this.e >= this.f)
      throw new NoSuchElementException(); 
    int j = this.e;
    while (this.e < this.f && this.h[this.e] != this.g.e)
      this.e++; 
    byte[] arrayOfByte = new byte[this.e - j];
    System.arraycopy(this.h, j, arrayOfByte, 0, this.e - j);
    return arrayOfByte;
  }
  
  public byte[] b(int paramInt) {
    if (this.h[this.e] == this.g.d || this.h[this.e] == this.g.e)
      this.e++; 
    if (this.e + paramInt > this.f)
      throw new NoSuchElementException(); 
    byte[] arrayOfByte = new byte[paramInt];
    System.arraycopy(this.h, this.e, arrayOfByte, 0, paramInt);
    this.e += paramInt;
    return arrayOfByte;
  }
  
  private boolean a(byte[] paramArrayOfByte) {
    boolean bool = true;
    for (int j = this.e; j < this.e + paramArrayOfByte.length; j++) {
      if (this.h[j] != paramArrayOfByte[j - this.e]) {
        bool = false;
        break;
      } 
    } 
    return bool;
  }
  
  private byte[][] a(String[] paramArrayOfString) {
    byte[][] arrayOfByte = new byte[paramArrayOfString.length][];
    String str = this.g.b();
    if (str == null) {
      for (byte b1 = 0; b1 < paramArrayOfString.length; b1++)
        arrayOfByte[b1] = paramArrayOfString[b1].getBytes(); 
    } else {
      try {
        for (byte b1 = 0; b1 < paramArrayOfString.length; b1++)
          arrayOfByte[b1] = paramArrayOfString[b1].getBytes(str); 
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        for (byte b1 = 0; b1 < paramArrayOfString.length; b1++)
          arrayOfByte[b1] = paramArrayOfString[b1].getBytes(); 
      } 
    } 
    return arrayOfByte;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\base\r.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */