package com.softwareag.entirex.base;

import java.lang.reflect.Method;

public class k {
  static Class a;
  
  public static void a(Object[] paramArrayOfObject) {
    try {
      Class clazz = Class.forName("java.util.Arrays");
      Class[] arrayOfClass = { (a == null) ? (a = class$("[Ljava.lang.Object;")) : a };
      Method method = clazz.getMethod("sort", arrayOfClass);
      Object[] arrayOfObject = { paramArrayOfObject };
      method.invoke(clazz, arrayOfObject);
    } catch (Exception exception) {}
  }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\base\k.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */