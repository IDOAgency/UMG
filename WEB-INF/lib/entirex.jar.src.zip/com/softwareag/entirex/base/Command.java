package com.softwareag.entirex.base;

public class Command {
  private String a;
  
  private String b;
  
  private String c;
  
  private int d;
  
  private int e;
  
  private String f;
  
  private String g;
  
  private String h;
  
  public static final int OPTION_TYPE_STRING = 1;
  
  public static final int OPTION_TYPE_INT = 2;
  
  public static final int OPTION_TYPE_BOOLEAN = 3;
  
  public Command(String paramString1, int paramInt, String paramString2, String paramString3) { this(paramString1, null, null, paramInt, -1, paramString2, paramString3); }
  
  public Command(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2, String paramString4, String paramString5) {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.f = paramString4;
    this.e = paramInt2;
    this.d = paramInt1;
    this.h = paramString5;
  }
  
  public int compareTo(Object paramObject) {
    Command command = (Command)paramObject;
    return a().compareTo(command.a());
  }
  
  String a() { return this.a; }
  
  String b() { return this.b; }
  
  String c() { return this.c; }
  
  int d() { return this.d; }
  
  void a(String paramString) { this.g = paramString; }
  
  String e() { return this.g; }
  
  String f() { return this.f; }
  
  String g() { return this.h; }
  
  int h() { return this.e; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\base\Command.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */