package com.softwareag.entirex.base;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class XMLFileLoader extends EntireXFileLoader {
  protected a5 a;
  
  protected String b;
  
  protected String c;
  
  public XMLFileLoader() { this(null); }
  
  public XMLFileLoader(String paramString) {
    super(paramString);
    n();
  }
  
  private void n() {
    if (super.a)
      System.out.println("XMLFileLoader.setDefaults()"); 
    this.c = "UTF8";
    try {
      this.b = System.getProperty("file.encoding");
    } catch (Exception exception) {}
    this.a = null;
  }
  
  public InputStream getFileAsInputStream() throws IOException {
    if (super.a)
      System.out.println("XMLFileLoader.getFileAsInputStream()"); 
    BufferedInputStream bufferedInputStream = new BufferedInputStream(super.getFileAsInputStream());
    this.a = new a5();
    this.a.a(bufferedInputStream);
    this.c = this.a.c();
    if (super.a)
      System.out.println("XMLFileLoader.sJavaEncoding=" + this.c); 
    if (this.c != null) {
      this.b = this.a.b();
      if (super.a)
        System.out.println("XMLFileLoader.sEncoding=" + this.b); 
    } 
    return bufferedInputStream;
  }
  
  public Reader i() throws IOException {
    if (super.a)
      System.out.println("XMLFileLoader.getFileAsReader()"); 
    InputStreamReader inputStreamReader = null;
    BufferedInputStream bufferedInputStream = new BufferedInputStream(getFileAsInputStream());
    if (this.c != null) {
      inputStreamReader = new InputStreamReader(bufferedInputStream, this.c);
    } else if (this.b != null) {
      inputStreamReader = new InputStreamReader(bufferedInputStream, this.b);
    } else {
      inputStreamReader = new InputStreamReader(bufferedInputStream);
    } 
    return inputStreamReader;
  }
  
  public String getEncoding() {
    if (super.a)
      System.out.println("XMLFileLoader.sEncoding=" + this.b); 
    return this.b;
  }
  
  public String getJavaEncoding() {
    if (super.a)
      System.out.println("XMLFileLoader.sJavaEncoding=" + this.c); 
    return this.c;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\base\XMLFileLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */