package com.softwareag.entirex.base;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class EntireXClassLoader extends ClassLoader {
  private static final boolean a = false;
  
  private String b;
  
  private String c;
  
  private JarFile d;
  
  private String e;
  
  private String f;
  
  public EntireXClassLoader(String paramString) { this(null, paramString); }
  
  public EntireXClassLoader(File paramFile, String paramString) {
    this.c = paramString;
    this.b = "";
    this.e = "";
    try {
      this.f = System.getProperty("java.class.path");
    } catch (Exception exception) {
      this.f = null;
    } 
    this.d = null;
    boolean bool = false;
    if (paramFile != null)
      try {
        if (paramFile.exists() && paramFile.canRead()) {
          this.d = new JarFile(paramFile);
          bool = true;
        } 
      } catch (Exception exception) {} 
    if (paramString != null) {
      this.b = paramString;
      this.e = this.b;
      int i = paramString.toLowerCase().lastIndexOf(".class");
      if (i > 0) {
        this.b = paramString.substring(0, i);
        this.e = this.b.replace(File.separatorChar, '.');
        this.e = this.b.replace('/', '.');
      } 
      i = this.b.lastIndexOf(File.separator) + 1;
      if (this.b.lastIndexOf("/") + 1 > i)
        i = this.b.lastIndexOf("/") + 1; 
      if (i > 0 && i <= this.b.length()) {
        this.b = this.b.substring(i);
        this.e = this.e.substring(0, this.e.length() - this.b.length());
      } 
      if (!bool)
        this.e = ""; 
    } 
  }
  
  public Class findClass(String paramString) throws ClassNotFoundException {
    Class clazz = null;
    if (paramString != null) {
      int i = paramString.lastIndexOf(".");
      if (i < paramString.length() && this.b.equals(paramString.substring(i + 1))) {
        byte[] arrayOfByte = a(this.c);
        if (arrayOfByte != null) {
          try {
            clazz = defineClass(paramString, arrayOfByte, 0, arrayOfByte.length);
          } catch (NoClassDefFoundError noClassDefFoundError) {
            if (this.e != null && this.e.trim().length() > 0)
              try {
                clazz = defineClass(this.e + paramString, arrayOfByte, 0, arrayOfByte.length);
              } catch (NoClassDefFoundError noClassDefFoundError1) {
              
              } catch (ClassFormatError classFormatError) {
                throw new ClassNotFoundException(this.e + paramString);
              }  
          } catch (ClassFormatError classFormatError) {
            throw new ClassNotFoundException(paramString);
          } 
        } else {
          throw new ClassNotFoundException(paramString);
        } 
      } else {
        clazz = Class.forName(paramString);
      } 
    } 
    return clazz;
  }
  
  private byte[] a(String paramString) {
    byte[] arrayOfByte = null;
    try {
      int i = 0;
      InputStream inputStream = null;
      JarEntry jarEntry = null;
      if (this.d != null)
        jarEntry = this.d.getJarEntry(paramString); 
      if (jarEntry != null) {
        i = (int)jarEntry.getSize();
        inputStream = this.d.getInputStream(jarEntry);
      } else {
        File file = new File(paramString);
        i = (int)file.length();
        inputStream = new FileInputStream(file);
      } 
      DataInputStream dataInputStream = new DataInputStream(inputStream);
      arrayOfByte = new byte[i];
      dataInputStream.readFully(arrayOfByte, 0, i);
    } catch (Exception exception) {}
    return arrayOfByte;
  }
  
  public Object getObject() throws ClassNotFoundException, InstantiationException, IllegalAccessException, NullPointerException, NoClassDefFoundError { return loadClass(this.e + this.b, true).newInstance(); }
  
  public Object getObject(Class[] paramArrayOfClass, Object[] paramArrayOfObject) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException, NullPointerException, NoClassDefFoundError {
    Object object = null;
    Class clazz = findClass(this.b);
    if (paramArrayOfClass == null || paramArrayOfObject == null) {
      object = clazz.newInstance();
    } else {
      Constructor constructor = clazz.getConstructor(paramArrayOfClass);
      object = constructor.newInstance(paramArrayOfObject);
    } 
    return object;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\base\EntireXClassLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */