package com.softwareag.entirex.cis;

import com.softwareag.entirex.aci.BrokerService;
import java.io.IOException;

public class dv extends InfoService {
  protected dv(BrokerService paramBrokerService) { super(paramBrokerService); }
  
  protected short b() { return 15; }
  
  protected void a(byte[] paramArrayOfByte, int paramInt) {
    super.a(paramArrayOfByte, paramInt);
    dw dw = (dw)d();
    if (dw != null) {
      int i = dw.b();
      byte b = 0;
      while (b < i) {
        try {
          if (paramInt >= 4) {
            byte[] arrayOfByte1 = new byte[256];
            byte[] arrayOfByte2 = new byte[96];
            byte[] arrayOfByte3 = new byte[32];
            byte[] arrayOfByte4 = new byte[28];
            byte[] arrayOfByte5 = new byte[16];
            int j = this.i.read(arrayOfByte3);
            if (j > 0)
              dw.a = (new String(arrayOfByte3)).trim(); 
            j = this.i.read(arrayOfByte4);
            if (j > 0)
              dw.b = (new String(arrayOfByte4)).trim(); 
            j = this.i.read(arrayOfByte4);
            if (j > 0)
              dw.c = new String(arrayOfByte4); 
            j = this.i.read(arrayOfByte3);
            if (j > 0)
              dw.d = new String(arrayOfByte3); 
            dw.e = this.i.readShort();
            dw.f = this.i.readShort();
            dw.g = this.i.readShort();
            this.i.readShort();
            j = this.i.read(arrayOfByte5);
            if (j > 0)
              dw.i = (new String(arrayOfByte5)).trim(); 
            j = this.i.read(arrayOfByte2);
            if (j > 0)
              dw.j = (new String(arrayOfByte2)).trim(); 
            dw.k = this.i.readInt();
            dw.l = this.i.readInt();
            dw.m = this.i.readInt();
            dw.n = this.i.readInt();
            dw.o = this.i.readInt();
            dw.p = this.i.readInt();
            dw.q = this.i.readInt();
            dw.r = this.i.readInt();
            dw.s = this.i.readInt();
            j = this.i.read(arrayOfByte5);
            if (j > 0)
              dw.t = (new String(arrayOfByte5)).trim(); 
            j = this.i.read(arrayOfByte1);
            if (j > 0)
              dw.u = (new String(arrayOfByte1)).trim(); 
          } 
        } catch (IOException iOException) {
          iOException.printStackTrace();
        } 
        b++;
        dw = (dw)e();
      } 
    } 
  }
  
  protected ds[] f() { return new dw[h()]; }
  
  protected ds g() { return new dw(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\cis\dv.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */