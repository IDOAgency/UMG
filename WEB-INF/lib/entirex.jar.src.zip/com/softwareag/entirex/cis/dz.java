package com.softwareag.entirex.cis;

import com.softwareag.entirex.aci.BrokerService;
import java.io.IOException;

public class dz extends InfoService {
  protected dz(BrokerService paramBrokerService) { super(paramBrokerService); }
  
  protected short b() { return 18; }
  
  protected void a(byte[] paramArrayOfByte, int paramInt) {
    super.a(paramArrayOfByte, paramInt);
    dt dt = (dt)d();
    if (dt != null) {
      int i = dt.b();
      byte b = 0;
      while (b < i) {
        try {
          byte[] arrayOfByte1 = new byte[256];
          byte[] arrayOfByte2 = new byte[32];
          byte[] arrayOfByte3 = new byte[28];
          byte[] arrayOfByte4 = new byte[16];
          int j = this.i.read(arrayOfByte2);
          if (j > 0)
            dt.a = (new String(arrayOfByte2)).trim(); 
          j = this.i.read(arrayOfByte3);
          if (j > 0)
            dt.b = (new String(arrayOfByte3)).trim(); 
          j = this.i.read(arrayOfByte3);
          if (j > 0)
            dt.c = new String(arrayOfByte3); 
          j = this.i.read(arrayOfByte2);
          if (j > 0)
            dt.d = (new String(arrayOfByte2)).trim(); 
          dt.e = this.i.readShort();
          dt.f = this.i.readShort();
          dt.g = this.i.readShort();
          this.i.readShort();
          j = this.i.read(arrayOfByte4);
          if (j > 0)
            dt.h = (new String(arrayOfByte4)).trim(); 
          j = this.i.read(arrayOfByte2);
          if (j > 0)
            dt.i = (new String(arrayOfByte2)).trim(); 
          j = this.i.read(arrayOfByte2);
          if (j > 0)
            dt.j = (new String(arrayOfByte2)).trim(); 
          j = this.i.read(arrayOfByte2);
          if (j > 0)
            dt.k = (new String(arrayOfByte2)).trim(); 
          dt.l = this.i.readInt();
          dt.m = this.i.readInt();
          dt.n = this.i.readInt();
          dt.o = this.i.readInt();
          dt.p = this.i.readInt();
          dt.q = this.i.readInt();
          dt.r = this.i.readInt();
          dt.s = this.i.readInt();
          dt.t = this.i.readInt();
          if (paramInt >= 2)
            dt.u = this.i.readInt(); 
          if (paramInt >= 4) {
            j = this.i.read(arrayOfByte4);
            if (j > 0)
              dt.v = (new String(arrayOfByte4)).trim(); 
            j = this.i.read(arrayOfByte1);
            if (j > 0)
              dt.w = (new String(arrayOfByte1)).trim(); 
            dt.x = this.i.readByte();
            dt.y = this.i.readByte();
            this.i.read(dt.z);
          } 
        } catch (IOException iOException) {
          iOException.printStackTrace();
        } 
        b++;
        dt = (dt)e();
      } 
    } 
  }
  
  protected ds[] f() { return new dt[h()]; }
  
  protected ds g() { return new dt(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\cis\dz.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */