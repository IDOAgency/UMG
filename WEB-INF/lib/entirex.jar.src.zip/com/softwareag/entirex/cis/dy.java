package com.softwareag.entirex.cis;

import java.io.PrintStream;

public class dy extends ds {
  String a;
  
  String b;
  
  String c;
  
  String d;
  
  String e;
  
  int f;
  
  int g;
  
  int h;
  
  String i;
  
  String j;
  
  byte k;
  
  byte l;
  
  byte[] m = new byte[2];
  
  public void a(PrintStream paramPrintStream) {
    super.a(paramPrintStream);
    paramPrintStream.println("User ID:" + this.b + ", Token:" + this.e);
    paramPrintStream.print("Physical User Id:" + this.c);
    paramPrintStream.println(", Physical User Id Char:" + this.d);
    paramPrintStream.println("Topic:" + this.a);
    paramPrintStream.println("Last activity: " + this.g + ", subscription time: " + this.f + ", expiration time: " + this.h);
    paramPrintStream.println("Last commited publication: " + this.i + ", last received publication: " + this.j + ", durable: " + this.k + ", swappedOut: " + this.l);
  }
  
  public String k() { return this.b; }
  
  public String l() { return this.c; }
  
  public String m() { return this.d; }
  
  public String n() { return this.e; }
  
  public int o() { return this.g; }
  
  public String p() { return this.a; }
  
  public int q() { return this.f; }
  
  public int r() { return this.h; }
  
  public String s() { return this.i; }
  
  public String t() { return this.j; }
  
  public boolean u() { return (this.k == 1); }
  
  public boolean v() { return (this.l == 1); }
  
  public boolean w() { return (this.k == 0 || this.l == 0); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\cis\dy.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */