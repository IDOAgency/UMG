package com.softwareag.entirex.cis;

import com.softwareag.entirex.aci.BrokerService;
import java.io.IOException;

public class dx extends InfoService {
  protected dx(BrokerService paramBrokerService) { super(paramBrokerService); }
  
  protected short b() { return 14; }
  
  protected void a(byte[] paramArrayOfByte, int paramInt) {
    super.a(paramArrayOfByte, paramInt);
    dy dy = (dy)d();
    if (dy != null) {
      int i = dy.b();
      byte b = 0;
      while (b < i) {
        try {
          if (paramInt >= 4) {
            byte[] arrayOfByte1 = new byte[96];
            byte[] arrayOfByte2 = new byte[32];
            byte[] arrayOfByte3 = new byte[28];
            byte[] arrayOfByte4 = new byte[16];
            int j = this.i.read(arrayOfByte1);
            if (j > 0)
              dy.a = (new String(arrayOfByte1)).trim(); 
            j = this.i.read(arrayOfByte2);
            if (j > 0)
              dy.b = (new String(arrayOfByte2)).trim(); 
            j = this.i.read(arrayOfByte3);
            if (j > 0)
              dy.c = (new String(arrayOfByte3)).trim(); 
            j = this.i.read(arrayOfByte3);
            if (j > 0)
              dy.d = new String(arrayOfByte3); 
            j = this.i.read(arrayOfByte2);
            if (j > 0)
              dy.e = (new String(arrayOfByte2)).trim(); 
            dy.f = this.i.readInt();
            dy.g = this.i.readInt();
            dy.h = this.i.readInt();
            j = this.i.read(arrayOfByte4);
            if (j > 0)
              dy.i = (new String(arrayOfByte4)).trim(); 
            j = this.i.read(arrayOfByte4);
            if (j > 0)
              dy.j = (new String(arrayOfByte4)).trim(); 
            dy.k = this.i.readByte();
            dy.l = this.i.readByte();
            this.i.read(dy.m);
          } 
        } catch (IOException iOException) {
          iOException.printStackTrace();
        } 
        b++;
        dy = (dy)e();
      } 
    } 
  }
  
  protected ds[] f() { return new dy[h()]; }
  
  protected ds g() { return new dy(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\cis\dx.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */