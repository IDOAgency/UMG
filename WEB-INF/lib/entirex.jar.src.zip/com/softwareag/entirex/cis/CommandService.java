package com.softwareag.entirex.cis;

import com.softwareag.entirex.aci.Broker;
import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.BrokerMessage;
import com.softwareag.entirex.aci.BrokerService;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class CommandService {
  private static final String a = "SAG/ETBCIS/CMD";
  
  private static final int b = 32;
  
  private static final int c = 1;
  
  private String d;
  
  private String e;
  
  private String f;
  
  public CommandService(String paramString1, String paramString2, String paramString3) {
    if (paramString1 == null || paramString1.length() == 0)
      paramString1 = "localhost"; 
    this.d = paramString1;
    if (paramString2 == null || paramString2.length() == 0)
      paramString2 = "JavaCIS"; 
    this.e = paramString2;
    this.f = paramString3;
  }
  
  public int shutdownServer(String paramString) {
    if (paramString == null || paramString.length() == 0)
      paramString = "0000000000000000000000000000"; 
    return a((short)1, (short)8, (short)3, paramString, "                 ");
  }
  
  public int shutdownServerQuiesce(String paramString) {
    if (paramString == null || paramString.length() == 0)
      paramString = "0000000000000000000000000000"; 
    return a((short)1, (short)8, (short)4, paramString, "                 ");
  }
  
  private int a(short paramShort1, short paramShort2, short paramShort3, String paramString1, String paramString2) {
    byte[] arrayOfByte = new byte[32];
    Broker broker = new Broker(this.d, this.e);
    BrokerService brokerService = new BrokerService(broker, "SAG/ETBCIS/CMD");
    brokerService.setMaxReceiveLen(32);
    BrokerMessage brokerMessage = new BrokerMessage();
    int i = 0;
    try {
      try {
        broker.logon();
      } catch (BrokerException brokerException) {
        if (brokerException.getErrorClass() == 20 && brokerException.getErrorCode() == 379) {
          broker.useEntireXSecurity();
          broker.logon(this.f);
        } else {
          throw brokerException;
        } 
      } 
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
      dataOutputStream.writeShort(1);
      dataOutputStream.writeShort(paramShort1);
      dataOutputStream.writeShort(paramShort2);
      dataOutputStream.writeShort(paramShort3);
      byte[] arrayOfByte1 = paramString1.getBytes();
      System.arraycopy(arrayOfByte1, 0, arrayOfByte, 0, 28);
      dataOutputStream.write(arrayOfByte, 0, 28);
      byte[] arrayOfByte2 = paramString2.getBytes();
      System.arraycopy(arrayOfByte2, 0, arrayOfByte, 0, 16);
      dataOutputStream.write(arrayOfByte, 0, 16);
      brokerMessage.setMessage(byteArrayOutputStream.toByteArray());
      brokerMessage = brokerService.sendReceive(brokerMessage);
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(brokerMessage.getMessage());
      DataInputStream dataInputStream = new DataInputStream(byteArrayInputStream);
      i = dataInputStream.readInt();
      switch (i) {
        case 2:
          System.out.println("Command request returned: invalid CIS version.");
          break;
        case 3:
          System.out.println("Command request returned: object-type missing.");
          break;
        case 5:
          System.out.println("Command request returned: object-type invalid.");
          break;
        case 20:
          System.out.println("Command request returned: user not authorized.");
          break;
        case 21:
          System.out.println("Command request returned: invalid command.");
          break;
        case 22:
          System.out.println("Command request returned: invalid option.");
          break;
        case 23:
          System.out.println("Command request returned: shutdown only allowed for servers.");
          break;
        case 24:
          System.out.println("Command request returned: server not found.");
          break;
        case 25:
          System.out.println("Command request returned: purge unit of work failed.");
          break;
        default:
          System.out.println("Command request returned: unknown error:" + i + ".");
          break;
        case 0:
          break;
      } 
      broker.logoff();
    } catch (IOException iOException) {
      System.out.println(iOException);
    } catch (BrokerException brokerException) {
      brokerException.printStackTrace();
    } 
    return i;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\cis\CommandService.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */