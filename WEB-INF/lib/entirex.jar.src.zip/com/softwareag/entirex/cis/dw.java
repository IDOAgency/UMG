package com.softwareag.entirex.cis;

import java.io.PrintStream;

public class dw extends ds {
  String a;
  
  String b;
  
  String c;
  
  String d;
  
  short e;
  
  short f;
  
  short g;
  
  short h;
  
  String i;
  
  String j;
  
  int k;
  
  int l;
  
  int m;
  
  int n;
  
  int o;
  
  int p;
  
  int q;
  
  int r;
  
  int s;
  
  String t;
  
  String u;
  
  public void a(PrintStream paramPrintStream) {
    super.a(paramPrintStream);
    paramPrintStream.println("User ID:" + this.a + ", Token:" + this.d);
    paramPrintStream.print("Physical User Id:" + this.b);
    paramPrintStream.println(", Physical User Id Char:" + this.c);
    paramPrintStream.println("Character set: " + this.e + ", Endian: " + this.f + ", status: " + this.g);
    paramPrintStream.println("Active publications: " + this.k + ", active topics: " + this.l + ", last activity: " + this.m + ", non activity: " + this.n);
    paramPrintStream.println("Wait for new publications: " + this.o + ", number: " + this.p + ", wait for old publications: " + this.q + ", number: " + this.r);
    paramPrintStream.println("Total number publications: " + this.s);
    paramPrintStream.println("IP address: " + this.t + ", host name: " + this.u);
  }
  
  public String k() { return this.a; }
  
  public String l() { return this.b; }
  
  public String m() { return this.c; }
  
  public String n() { return this.d; }
  
  public short o() { return this.e; }
  
  public short p() { return this.f; }
  
  public short q() { return this.g; }
  
  public String r() { return this.i; }
  
  public String s() { return this.j; }
  
  public int t() { return this.l; }
  
  public int u() { return this.m; }
  
  public int v() { return this.n; }
  
  public int w() { return this.o; }
  
  public int x() { return this.p; }
  
  public int y() { return this.q; }
  
  public int z() { return this.r; }
  
  public int aa() { return this.s; }
  
  public String ab() { return this.t; }
  
  public String ac() { return this.u; }
  
  public int ad() { return this.k; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\cis\dw.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */