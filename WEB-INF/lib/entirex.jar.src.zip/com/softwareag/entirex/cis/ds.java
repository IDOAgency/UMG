package com.softwareag.entirex.cis;

import java.io.PrintStream;
import java.util.Calendar;

public class ds {
  int a;
  
  int b;
  
  int c;
  
  int d;
  
  int e;
  
  int f;
  
  int g;
  
  int h;
  
  int i;
  
  int j;
  
  public int a() { return this.a; }
  
  public int b() { return this.b; }
  
  public int c() { return this.c; }
  
  public int d() { return this.d; }
  
  public int e() { return this.e; }
  
  public int f() { return this.f; }
  
  public int g() { return this.g; }
  
  public int h() { return this.h; }
  
  public int i() { return this.i; }
  
  public void a(PrintStream paramPrintStream) {
    paramPrintStream.println();
    paramPrintStream.print("Total number of objects:" + this.j);
    paramPrintStream.println(", Current number of objects:" + this.b);
    paramPrintStream.print("Maximal length of class name:" + this.c);
    paramPrintStream.print(", Maximal length of server name:" + this.d);
    paramPrintStream.println(", Maximal length of service name:" + this.e);
    paramPrintStream.print("Maximal length of user Id:" + this.f);
    paramPrintStream.print(", Maximal length of token:" + this.g);
    paramPrintStream.println(", Maximal length of topic name:" + this.h);
    Calendar calendar = Calendar.getInstance();
    calendar.set(1970, 0, 1, 0, 0, 0);
    calendar.add(13, this.i);
    paramPrintStream.println("Request timestamp in seconds:" + this.i + ", " + calendar.getTime());
  }
  
  public int j() { return this.j; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\cis\ds.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */