package com.softwareag.entirex.cis;

import com.softwareag.entirex.aci.Broker;
import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.BrokerMessage;
import com.softwareag.entirex.aci.BrokerService;
import com.softwareag.entirex.aci.Conversation;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class InfoService {
  private static final String a = "SAG/ETBCIS/INFO";
  
  private static final int b = 7168;
  
  private static final int[] c = { 32, 32, 32, 40 };
  
  private int d = 0;
  
  private int e = 0;
  
  private int f = 0;
  
  private BrokerService g;
  
  private ds[] h;
  
  protected DataInputStream i;
  
  public static void a(String[] paramArrayOfString) {
    String str1 = "localhost";
    if (paramArrayOfString.length > 0)
      str1 = paramArrayOfString[0]; 
    String str2 = System.getProperty("user.name");
    if (paramArrayOfString.length > 1)
      str2 = paramArrayOfString[1]; 
    if (str1 == null || str1.length() == 0)
      str1 = "localhost"; 
    if (str2 == null || str2.length() == 0)
      str2 = "JavaCIS"; 
    try {
      Broker broker = new Broker(str1, str2);
      broker.logon();
      BrokerService brokerService = new BrokerService(broker, "SAG/ETBCIS/INFO");
      dr dr = new dr(brokerService);
      dr.a();
      ds[] arrayOfds = dr.c();
      for (byte b1 = 0; arrayOfds != null && b1 < arrayOfds.length; b1++)
        arrayOfds[b1].a(System.out); 
      du du = new du(brokerService);
      du.a();
      arrayOfds = du.c();
      for (byte b2 = 0; arrayOfds != null && b2 < arrayOfds.length; b2++)
        arrayOfds[b2].a(System.out); 
      dv dv = new dv(brokerService);
      dv.a();
      arrayOfds = dv.c();
      for (byte b3 = 0; arrayOfds != null && b3 < arrayOfds.length; b3++)
        arrayOfds[b3].a(System.out); 
      dx dx = new dx(brokerService);
      dx.a();
      arrayOfds = dx.c();
      for (byte b4 = 0; arrayOfds != null && b4 < arrayOfds.length; b4++)
        arrayOfds[b4].a(System.out); 
      broker.logoff();
    } catch (BrokerException brokerException) {
      brokerException.printStackTrace();
    } 
  }
  
  public static boolean checkToken(BrokerService paramBrokerService, String paramString) throws BrokerException {
    boolean bool = false;
    dr dr = new dr(paramBrokerService);
    dr.a();
    ds[] arrayOfds = dr.c();
    for (byte b1 = 0; arrayOfds != null && b1 < arrayOfds.length && !bool; b1++)
      bool = ((dt)arrayOfds[b1]).n().equals(paramString); 
    du du = new du(paramBrokerService);
    du.a();
    arrayOfds = du.c();
    for (byte b2 = 0; arrayOfds != null && b2 < arrayOfds.length && !bool; b2++)
      bool = ((dt)arrayOfds[b2]).n().equals(paramString); 
    dv dv = new dv(paramBrokerService);
    dv.a();
    arrayOfds = dv.c();
    for (byte b3 = 0; arrayOfds != null && b3 < arrayOfds.length && !bool; b3++)
      bool = ((dw)arrayOfds[b3]).n().equals(paramString); 
    dx dx = new dx(paramBrokerService);
    dx.a();
    arrayOfds = dx.c();
    for (byte b4 = 0; arrayOfds != null && b4 < arrayOfds.length && !bool; b4++)
      bool = (!((dy)arrayOfds[b4]).u() && ((dy)arrayOfds[b4]).n().equals(paramString)); 
    dz dz = new dz(paramBrokerService);
    dz.a();
    arrayOfds = dz.c();
    for (byte b5 = 0; arrayOfds != null && b5 < arrayOfds.length && !bool; b5++)
      bool = ((dt)arrayOfds[b5]).n().equals(paramString); 
    return bool;
  }
  
  public InfoService(BrokerService paramBrokerService) { this.g = paramBrokerService; }
  
  public int a() throws BrokerException {
    byte[] arrayOfByte1 = new byte[32];
    byte[] arrayOfByte2 = new byte[96];
    this.g.setMaxReceiveLen(7168);
    this.g.setAdjustReceiveLen(true);
    Conversation conversation = new Conversation(this.g);
    BrokerMessage brokerMessage = new BrokerMessage();
    short s = (short)this.g.getBroker().getCISVersion();
    byte b1 = 0;
    try {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
      dataOutputStream.writeInt(7168 - c[s - 1]);
      dataOutputStream.writeShort(s);
      dataOutputStream.writeShort(0);
      dataOutputStream.writeShort(b());
      dataOutputStream.write(arrayOfByte1, 0, 32);
      dataOutputStream.write(arrayOfByte1, 0, 28);
      dataOutputStream.write(arrayOfByte1, 0, 32);
      dataOutputStream.write(arrayOfByte1, 0, 32);
      dataOutputStream.write(arrayOfByte1, 0, 32);
      dataOutputStream.write(arrayOfByte1, 0, 32);
      dataOutputStream.write(arrayOfByte1, 0, 32);
      dataOutputStream.writeShort(0);
      if (s >= 2) {
        dataOutputStream.write(arrayOfByte1, 0, 16);
        dataOutputStream.write(arrayOfByte1, 0, 1);
        dataOutputStream.write(arrayOfByte1, 0, 32);
        dataOutputStream.write(arrayOfByte1, 0, 32);
        dataOutputStream.write(arrayOfByte1, 0, 32);
        dataOutputStream.write(arrayOfByte1, 0, 32);
        dataOutputStream.write(arrayOfByte1, 0, 32);
        dataOutputStream.write(arrayOfByte1, 0, 32);
      } 
      if (s >= 4) {
        dataOutputStream.write(arrayOfByte2, 0, 96);
        dataOutputStream.write(arrayOfByte1, 0, 16);
        dataOutputStream.write(arrayOfByte1, 0, 2);
      } 
      brokerMessage.setMessage(byteArrayOutputStream.toByteArray());
      brokerMessage = conversation.sendReceive(brokerMessage);
      a(brokerMessage.getMessage(), s);
      while (this.d < this.e) {
        brokerMessage = conversation.receive();
        a(brokerMessage.getMessage(), s);
      } 
      conversation.end();
    } catch (IOException iOException) {
      System.out.println(iOException);
    } 
    return b1;
  }
  
  protected void a(byte[] paramArrayOfByte, int paramInt) {
    try {
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
      this.i = new DataInputStream(byteArrayInputStream);
      int j = this.i.readInt();
      switch (j) {
        case 0:
          break;
        case 2:
          System.out.println("Info request returned: invalid CIS version.");
          break;
        case 3:
          System.out.println("Info request returned: object-type missing.");
          break;
        case 4:
          break;
        case 5:
          System.out.println("Info request returned: object-type invalid.");
          break;
        case 6:
          System.out.println("Info request returned: invalid info-level.");
          break;
        case 7:
          System.out.println("Info request returned: BLOCK-LENGTH too short for OBJECT-TYPE.");
          break;
        case 8:
          System.out.println("Info request returned: User selection must be unique.");
          break;
        case 9:
          System.out.println("Info request returned: Service selection must be unique.");
          break;
        case 10:
          System.out.println("Info request returned: Topic name must be specified.");
          break;
        default:
          System.out.println("Info request returned: unknown error:" + j + ".");
          break;
      } 
      if (j == 0) {
        this.e = this.i.readInt();
        if (this.h == null)
          this.h = f(); 
        this.f = this.d;
        ds ds1 = d();
        ds1.j = this.e;
        ds1.a = j;
        ds1.b = this.i.readInt();
        this.d += ds1.b;
        ds1.c = this.i.readInt();
        ds1.d = this.i.readInt();
        ds1.e = this.i.readInt();
        ds1.f = this.i.readInt();
        ds1.g = this.i.readInt();
        if (paramInt >= 4) {
          ds1.h = this.i.readInt();
          ds1.i = this.i.readInt();
        } 
      } 
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
  }
  
  protected short b() { return 0; }
  
  public ds[] c() { return this.h; }
  
  protected ds d() {
    if (this.h == null)
      return null; 
    if (this.h[this.f] == null)
      this.h[this.f] = g(); 
    return this.h[this.f];
  }
  
  protected ds e() {
    if (this.f < this.h.length - 1) {
      if (this.h[++this.f] == null)
        this.h[this.f] = g(); 
      return this.h[this.f];
    } 
    return null;
  }
  
  protected ds[] f() { return new ds[this.e]; }
  
  protected ds g() { return new ds(); }
  
  protected int h() throws BrokerException { return this.e; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\cis\InfoService.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */