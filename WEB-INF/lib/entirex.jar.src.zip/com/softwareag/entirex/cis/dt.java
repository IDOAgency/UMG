package com.softwareag.entirex.cis;

import java.io.PrintStream;

public class dt extends ds {
  String a;
  
  String b;
  
  String c;
  
  String d;
  
  short e;
  
  short f;
  
  short g;
  
  String h;
  
  String i;
  
  String j;
  
  String k;
  
  int l;
  
  int m;
  
  int n;
  
  int o;
  
  int p;
  
  int q;
  
  int r;
  
  int s;
  
  int t;
  
  int u;
  
  String v;
  
  String w;
  
  byte x;
  
  byte y;
  
  byte[] z = new byte[2];
  
  public void a(PrintStream paramPrintStream) {
    super.a(paramPrintStream);
    paramPrintStream.println("User ID:" + this.a + ", Token:" + this.d);
    paramPrintStream.print("Physical User Id:" + this.b);
    paramPrintStream.println(", Physical User Id Char:" + this.c);
    paramPrintStream.println("Character set: " + this.e + ", Endian: " + this.f + ", status: " + this.g);
    paramPrintStream.println("wait for conversation type: " + this.h + ", Service: " + this.i + " / " + this.j + " / " + this.k);
    paramPrintStream.println("Active conversations: " + this.l + ", active servers: " + this.m + ", last activity: " + this.n + ", non activity: " + this.o);
    paramPrintStream.println("Wait for new conversations: " + this.p + ", number: " + this.q + ", wait for old conversations: " + this.r + ", number: " + this.s);
    paramPrintStream.println("Total number conversations: " + this.t + ", total number units of work: " + this.u);
    paramPrintStream.println("IP address: " + this.v + ", host name: " + this.w + ", receive option: " + this.x + ", attach manager: " + this.y);
  }
  
  public String k() { return this.a; }
  
  public String l() { return this.b; }
  
  public String m() { return this.c; }
  
  public String n() { return this.d; }
  
  public short o() { return this.e; }
  
  public short p() { return this.f; }
  
  public short q() { return this.g; }
  
  public String r() { return this.h; }
  
  public String s() { return this.i; }
  
  public String t() { return this.j; }
  
  public String u() { return this.k; }
  
  public int v() { return this.l; }
  
  public int w() { return this.m; }
  
  public int x() { return this.n; }
  
  public int y() { return this.o; }
  
  public int z() { return this.p; }
  
  public int aa() { return this.q; }
  
  public int ab() { return this.r; }
  
  public int ac() { return this.s; }
  
  public int ad() { return this.t; }
  
  public int ae() { return this.u; }
  
  public String af() { return this.v; }
  
  public String ag() { return this.w; }
  
  public byte ah() { return this.x; }
  
  public byte ai() { return this.y; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\cis\dt.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */