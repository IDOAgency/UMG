package com.softwareag.entirex.argus.base;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class Protocol {
  public static final int a = 0;
  
  public static final int b = 1;
  
  public static final int c = 2;
  
  public static final int d = 3;
  
  public static final int e = 4;
  
  public static final int f = 5;
  
  public static final int g = 6;
  
  public static final int h = 7;
  
  public static final int i = 8;
  
  public static final int j = 9;
  
  private static final String k = "UTF-8";
  
  private static final String l = "INIT";
  
  private static final String m = "LOGON";
  
  private static final String n = "TRACE";
  
  private static final String o = "STOP";
  
  private static final String p = "RESTART";
  
  private static final String q = "GETSI";
  
  private static final String r = "GETCSI";
  
  private static final String s = "GETTAB";
  
  private static final String t = "GETTABNUM";
  
  private static final String u = "DATA";
  
  private static final String v = "TAB";
  
  private static final String w = "TABNAME";
  
  private static final String x = "TABINDEX";
  
  private static final String y = "row";
  
  private static final String z = "tabitem";
  
  private static final String aa = "header";
  
  private static final String ab = "column";
  
  private static final String ac = "name";
  
  private static final String ad = "CODEPAGE";
  
  private static final String ae = "LOGON-LEVEL";
  
  private static final String af = "TRACE-RESPONSE";
  
  private static final String ag = "STOP-RESPONSE";
  
  private static final String ah = "RESTART-RESPONSE";
  
  private static final String ai = "GETSI-RESPONSE";
  
  private static final String aj = "GETCSI-RESPONSE";
  
  private static final String ak = "GETTAB-RESPONSE";
  
  private static final String al = "GETTABNUM-RESPONSE";
  
  private static final String am = "<?xml version=\"1.0\" encoding=\"";
  
  private static final String an = "\"?>";
  
  private static final String ao = "<RPC-SERVER-AGENT Version=\"1.0\">";
  
  private static final String ap = "</RPC-SERVER-AGENT>";
  
  private static final String aq = "<INIT/>";
  
  private static final String ar = "<STOP/>";
  
  private static final String as = "<RESTART/>";
  
  private static final String at = "<GETSI/>";
  
  private static final String au = "<GETCSI/>";
  
  private static final String av = "<GETTABNUM/>";
  
  private static final String aw = "<LOGON>";
  
  private static final String ax = "</LOGON>";
  
  private static final String ay = "<USER>";
  
  private static final String az = "</USER>";
  
  private static final String a0 = "<PASSWORD>";
  
  private static final String a1 = "</PASSWORD>";
  
  private static final String a2 = "<TRACE>";
  
  private static final String a3 = "</TRACE>";
  
  private static final String a4 = "<TRACE-LEVEL>";
  
  private static final String a5 = "</TRACE-LEVEL>";
  
  private static final String a6 = "<TRACE-FILE>";
  
  private static final String a7 = "</TRACE-FILE>";
  
  private static final String a8 = "<GETTAB>";
  
  private static final String a9 = "</GETTAB>";
  
  private static final String ba = "<DATA>";
  
  private static final String bb = "</DATA>";
  
  private static final String bc = "<row>";
  
  private static final String bd = "</row>";
  
  private static final String be = "<tabitem>";
  
  private static final String bf = "</tabitem>";
  
  private static final String bg = "<TAB>";
  
  private static final String bh = "</TAB>";
  
  private static final String bi = "<TABNAME>";
  
  private static final String bj = "</TABNAME>";
  
  private static final String bk = "<TABINDEX>";
  
  private static final String bl = "</TABINDEX>";
  
  private static final String bm = "<header>";
  
  private static final String bn = "</header>";
  
  private static final String bo = "<column>";
  
  private static final String bp = "</column>";
  
  private static final String bq = "<name>";
  
  private static final String br = "</name>";
  
  private static final String bs = "<LOGON-LEVEL>";
  
  private static final String bt = "</LOGON-LEVEL>";
  
  private static final String bu = "<STOP-RESPONSE>";
  
  private static final String bv = "</STOP-RESPONSE>";
  
  private static final String bw = "<RESTART-RESPONSE>";
  
  private static final String bx = "</RESTART-RESPONSE>";
  
  private static final String by = "<GETSI-RESPONSE>";
  
  private static final String bz = "</GETSI-RESPONSE>";
  
  private static final String b0 = "<GETCSI-RESPONSE>";
  
  private static final String b1 = "</GETCSI-RESPONSE>";
  
  private static final String b2 = "<GETTABNUM-RESPONSE>";
  
  private static final String b3 = "</GETTABNUM-RESPONSE>";
  
  private static final String b4 = "<GETTAB-RESPONSE>";
  
  private static final String b5 = "</GETTAB-RESPONSE>";
  
  private Socket b6;
  
  private DataOutputStream b7;
  
  private DataInputStream b8;
  
  private String b9;
  
  private int ca;
  
  private String cb = "UTF-8";
  
  private int cc = 403773846;
  
  private byte[] cd;
  
  private byte[] ce;
  
  private byte[] cf;
  
  private int cg;
  
  private Vector ch = new Vector();
  
  private Vector ci = new Vector();
  
  private Vector cj = new Vector();
  
  private String[] ck;
  
  private String[][] cl;
  
  private String cm;
  
  private int cn;
  
  private DocumentBuilderFactory co;
  
  private DocumentBuilder cp;
  
  private Document cq;
  
  private InputSource cr;
  
  private Node cs;
  
  private NodeList ct;
  
  private String cu;
  
  private String cv;
  
  private NamedNodeMap cw;
  
  private final String cx = System.getProperty("line.separator", "\n");
  
  public Protocol() {}
  
  public Protocol(String paramString1, String paramString2, int paramInt1, int paramInt2) throws Exception {
    try {
      Logger.traceWithPrefixAndNewline(paramString1, "Protocol(" + paramString1 + "," + paramString2 + "," + paramInt1 + "," + paramInt2 + ")");
      this.cm = paramString1;
      this.b6 = new Socket(paramString2, paramInt1);
      Logger.traceWithPrefixAndNewline(paramString1, "Protocol(" + paramString1 + "," + paramString2 + "," + paramInt1 + "," + paramInt2 + ") new Socket() successful.");
      this.b6.setSoTimeout(paramInt2 * 1000);
      this.b6.setSoLinger(true, paramInt2);
      this.b8 = new DataInputStream(new BufferedInputStream(this.b6.getInputStream()));
      this.b7 = new DataOutputStream(new BufferedOutputStream(this.b6.getOutputStream()));
      return;
    } catch (Exception exception) {
      Logger.traceWithPrefixAndNewline(paramString1, "Protocol(" + paramString1 + "," + paramString2 + "," + paramInt1 + "," + paramInt2 + ") new Socket() failed. " + exception.getMessage());
      close();
      throw exception;
    } 
  }
  
  public Protocol(String paramString, Socket paramSocket) throws Exception {
    try {
      Logger.traceWithPrefixAndNewline(paramString, "Protocol(" + paramString + "," + paramSocket + ")");
      this.cm = paramString;
      this.b6 = paramSocket;
      this.b8 = new DataInputStream(new BufferedInputStream(this.b6.getInputStream()));
      this.b7 = new DataOutputStream(new BufferedOutputStream(this.b6.getOutputStream()));
      return;
    } catch (IOException iOException) {
      close();
      throw iOException;
    } catch (Exception exception) {
      Logger.traceWithPrefixAndNewline(paramString, "Protocol(" + paramString + "," + paramSocket + ") failed. " + exception.getMessage());
      close();
      throw exception;
    } 
  }
  
  private String c() throws Exception {
    a("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<INIT/>" + "</RPC-SERVER-AGENT>");
    this.cb = a("CODEPAGE", d());
    return this.cb;
  }
  
  public String logon(String paramString1, String paramString2) throws Exception {
    a("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<LOGON>" + "<USER>" + paramString1 + "</USER>" + "<PASSWORD>" + paramString2 + "</PASSWORD>" + "</LOGON>" + "</RPC-SERVER-AGENT>");
    return a("LOGON-LEVEL", d(), this.cb);
  }
  
  public String trace(String paramString1, String paramString2) throws Exception {
    a("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<TRACE>" + "<TRACE-LEVEL>" + paramString1 + "</TRACE-LEVEL>" + "<TRACE-FILE>" + paramString2 + "</TRACE-FILE>" + "</TRACE>" + "</RPC-SERVER-AGENT>");
    return a("TRACE-RESPONSE", d(), this.cb);
  }
  
  public String stop() throws Exception {
    a("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<STOP/>" + "</RPC-SERVER-AGENT>");
    String str = a("STOP-RESPONSE", d());
    Logger.traceWithPrefixAndNewline(this.cm, "Protocol.stop() return:" + str);
    return str;
  }
  
  public String restart() throws Exception {
    a("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<RESTART/>" + "</RPC-SERVER-AGENT>");
    return a("RESTART-RESPONSE", d());
  }
  
  public String[][] getServerInfo() throws Exception {
    a("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<GETSI/>" + "</RPC-SERVER-AGENT>");
    this.cd = d();
    if (a("GETSI-RESPONSE", this.cd).equals("0")) {
      this.ch = a(this.cd, false);
      this.cl = new String[this.ch.size()][2];
      for (byte b10 = 0; b10 < this.ch.size(); b10++) {
        this.ci = (Vector)this.ch.elementAt(b10);
        for (byte b11 = 0; b11 < this.ci.size(); b11++)
          this.cl[b10][b11] = (String)this.ci.elementAt(b11); 
      } 
    } else {
      this.cl = null;
    } 
    return this.cl;
  }
  
  public String[] getServerTableNames() throws Exception {
    String[] arrayOfString = null;
    a("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<GETTABNUM/>" + "</RPC-SERVER-AGENT>");
    this.cd = d();
    if (a("GETTABNUM-RESPONSE", this.cd).equals("0")) {
      this.ch = a(this.cd);
      arrayOfString = new String[this.ch.size()];
      for (byte b10 = 0; b10 < this.ch.size(); b10++)
        arrayOfString[b10] = (String)this.ch.elementAt(b10); 
    } 
    return arrayOfString;
  }
  
  public String[][] getServerTable(int paramInt) throws Exception {
    a("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<GETTAB>" + String.valueOf(paramInt) + "</GETTAB>" + "</RPC-SERVER-AGENT>");
    this.cd = d();
    if (a("GETTAB-RESPONSE", this.cd).equals("0")) {
      this.ch = a(this.cd, true);
      this.cl = new String[this.ch.size()][((Vector)this.ch.elementAt(0)).size()];
      for (byte b10 = 0; b10 < this.ch.size(); b10++) {
        this.ci = (Vector)this.ch.elementAt(b10);
        for (byte b11 = 0; b11 < this.ci.size(); b11++)
          this.cl[b10][b11] = (String)this.ci.elementAt(b11); 
      } 
    } 
    return this.cl;
  }
  
  public String[][] getEnhancedServerInfo() throws Exception {
    a("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<GETCSI/>" + "</RPC-SERVER-AGENT>");
    this.cd = d();
    if (a("GETCSI-RESPONSE", this.cd).equals("0")) {
      this.ch = a(this.cd, false);
      this.cl = new String[this.ch.size()][2];
      for (byte b10 = 0; b10 < this.ch.size(); b10++) {
        this.ci = (Vector)this.ch.elementAt(b10);
        for (byte b11 = 0; b11 < this.ci.size(); b11++)
          this.cl[b10][b11] = (String)this.ci.elementAt(b11); 
      } 
    } else {
      this.cl = null;
    } 
    return this.cl;
  }
  
  public void a(int paramInt) throws Exception {
    Logger.traceWithPrefixAndNewline(this.cm, "Protocol.setLogon()");
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<LOGON-LEVEL>" + String.valueOf(paramInt) + "</LOGON-LEVEL>" + "</RPC-SERVER-AGENT>");
    a(stringBuffer.toString());
  }
  
  public void b(int paramInt) throws Exception {
    Logger.traceWithPrefixAndNewline(this.cm, "Protocol.setLogon()");
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<STOP-RESPONSE>" + String.valueOf(paramInt) + "</STOP-RESPONSE>" + "</RPC-SERVER-AGENT>");
    a(stringBuffer.toString());
  }
  
  public void c(int paramInt) throws Exception {
    Logger.traceWithPrefixAndNewline(this.cm, "Protocol.setLogon()");
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<RESTART-RESPONSE>" + String.valueOf(paramInt) + "</RESTART-RESPONSE>" + "</RPC-SERVER-AGENT>");
    a(stringBuffer.toString());
  }
  
  public void a(String[][] paramArrayOfString) throws Exception {
    Logger.traceWithPrefixAndNewline(this.cm, "Protocol.setTable()");
    StringBuffer stringBuffer = new StringBuffer();
    if (paramArrayOfString.length == 0) {
      stringBuffer.append("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<GETTAB-RESPONSE>" + "1" + "</GETTAB-RESPONSE>" + "</RPC-SERVER-AGENT>");
    } else {
      stringBuffer.append("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<GETTAB-RESPONSE>" + "0" + "</GETTAB-RESPONSE>" + "<DATA>" + "<header>");
      for (byte b10 = 0; b10 < paramArrayOfString[0].length; b10++)
        stringBuffer.append("<column><name>" + paramArrayOfString[0][b10] + "</name>" + "</column>"); 
      stringBuffer.append("</header>");
      for (byte b11 = 1; b11 < paramArrayOfString.length; b11++) {
        stringBuffer.append("<row>");
        for (byte b12 = 0; b12 < paramArrayOfString[b11].length; b12++)
          stringBuffer.append("<tabitem>" + paramArrayOfString[b11][b12] + "</tabitem>"); 
        stringBuffer.append("</row>");
      } 
      stringBuffer.append("</DATA></RPC-SERVER-AGENT>");
    } 
    a(stringBuffer.toString());
  }
  
  public void b(String[][] paramArrayOfString) throws Exception {
    Logger.traceWithPrefixAndNewline(this.cm, "Protocol.setServerInfo()");
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<GETSI-RESPONSE>" + "0" + "</GETSI-RESPONSE>" + "<DATA>");
    for (byte b10 = 0; b10 < paramArrayOfString.length; b10++) {
      stringBuffer.append("<row>");
      for (byte b11 = 0; b11 < paramArrayOfString[b10].length; b11++) {
        if (paramArrayOfString[b10][b11] != "") {
          stringBuffer.append("<tabitem>" + paramArrayOfString[b10][b11] + "</tabitem>");
        } else {
          stringBuffer.append("<tabitem>-</tabitem>");
        } 
      } 
      stringBuffer.append("</row>");
    } 
    stringBuffer.append("</DATA></RPC-SERVER-AGENT>");
    a(stringBuffer.toString());
  }
  
  public void c(String[][] paramArrayOfString) throws Exception {
    Logger.traceWithPrefixAndNewline(this.cm, "Protocol.setServerEnhancedInfo()");
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<GETCSI-RESPONSE>" + "0" + "</GETCSI-RESPONSE>" + "<DATA>");
    for (byte b10 = 0; b10 < paramArrayOfString.length; b10++) {
      stringBuffer.append("<row>");
      for (byte b11 = 0; b11 < paramArrayOfString[b10].length; b11++) {
        if (paramArrayOfString[b10][b11] != "") {
          stringBuffer.append("<tabitem>" + paramArrayOfString[b10][b11] + "</tabitem>");
        } else {
          stringBuffer.append("<tabitem>-</tabitem>");
        } 
      } 
      stringBuffer.append("</row>");
    } 
    stringBuffer.append("</DATA></RPC-SERVER-AGENT>");
    a(stringBuffer.toString());
  }
  
  public void a(String[] paramArrayOfString) throws Exception {
    Logger.traceWithPrefixAndNewline(this.cm, "Protocol.setTableNames()");
    StringBuffer stringBuffer = new StringBuffer();
    if (paramArrayOfString.length == 0) {
      stringBuffer.append("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<GETTABNUM-RESPONSE>" + "1" + "</GETTABNUM-RESPONSE>");
      stringBuffer.append("</RPC-SERVER-AGENT>");
    } else {
      stringBuffer.append("<?xml version=\"1.0\" encoding=\"" + this.cb + "\"?>" + "<RPC-SERVER-AGENT Version=\"1.0\">" + "<GETTABNUM-RESPONSE>" + "0" + "</GETTABNUM-RESPONSE>");
      for (byte b10 = 0; b10 < paramArrayOfString.length; b10++)
        stringBuffer.append("<TAB><TABNAME>" + paramArrayOfString[b10] + "</TABNAME>" + "<TABINDEX>" + String.valueOf(b10) + "</TABINDEX>" + "</TAB>"); 
      stringBuffer.append("</RPC-SERVER-AGENT>");
    } 
    a(stringBuffer.toString());
  }
  
  public int a() { return this.cn; }
  
  public int b() {
    Logger.traceWithPrefixAndNewline(this.cm, "Protocol.getCommand()");
    byte b10 = 0;
    this.cd = d();
    Logger.traceBuffer(this.cm, "Protocol.getCommand()", this.cd);
    if (b("LOGON", this.cd)) {
      b10 = 1;
    } else if (b("STOP", this.cd)) {
      b10 = 2;
    } else if (b("GETSI", this.cd)) {
      b10 = 4;
    } else if (b("GETCSI", this.cd)) {
      b10 = 5;
    } else if (b("GETTABNUM", this.cd)) {
      b10 = 6;
    } else if (b("GETTAB", this.cd)) {
      this.cn = Integer.parseInt(a("GETTAB", this.cd));
      b10 = 7;
    } else if (b("RESTART", this.cd)) {
      b10 = 3;
    } else if (b("TRACE", this.cd)) {
      b10 = 8;
    } 
    return b10;
  }
  
  public void close() {
    Logger.traceWithPrefixAndNewline(this.cm, "Protocol.close()");
    if (this.b6 != null)
      try {
        this.b6.close();
      } catch (Exception exception) {
        Logger.traceWithPrefixAndNewline(this.cm, "Protocol.close() for Socket failed. " + exception.getMessage());
      }  
    if (this.b7 != null)
      try {
        this.b7.close();
      } catch (Exception exception) {
        Logger.traceWithPrefixAndNewline(this.cm, "Protocol.close() for DataOutputStream failed. " + exception.getMessage());
      }  
    if (this.b8 != null)
      try {
        this.b8.close();
        return;
      } catch (Exception exception) {
        Logger.traceWithPrefixAndNewline(this.cm, "Protocol.close() for DataOutputStream failed. " + exception.getMessage());
        return;
      }  
  }
  
  private void a(String paramString) throws Exception {
    try {
      this.cd = paramString.getBytes(this.cb);
      this.ce = new byte[8 + this.cd.length];
      System.arraycopy(d(this.cd.length + 4), 0, this.ce, 0, 4);
      System.arraycopy(d(this.cc), 0, this.ce, 4, 4);
      System.arraycopy(this.cd, 0, this.ce, 8, this.cd.length);
      Logger.traceBuffer(this.cm, "Protocol.send() buffer ", this.ce);
      this.b7.write(this.ce);
      this.b7.flush();
      return;
    } catch (Exception exception) {
      close();
      throw exception;
    } 
  }
  
  private byte[] d() throws Exception {
    try {
      boolean bool = false;
      int i1 = 0;
      int i2 = 0;
      i2 = this.b8.readInt();
      i1 = this.b8.readInt();
      if (i1 == this.cc)
        bool = true; 
      if (i2 > 0) {
        this.cf = new byte[i2 - 4];
        this.cd = new byte[4 + i2];
        this.b8.readFully(this.cf);
        System.arraycopy(d(i2), 0, this.cd, 0, 4);
        System.arraycopy(d(this.cc), 0, this.cd, 4, 4);
        System.arraycopy(this.cf, 0, this.cd, 8, this.cf.length);
        Logger.traceBuffer(this.cm, "Protocol.receive() buffer ", this.cd);
      } 
    } catch (Exception exception) {
      close();
      throw exception;
    } 
    return this.cf;
  }
  
  private byte[] d(int paramInt) {
    byte[] arrayOfByte = new byte[4];
    arrayOfByte[0] = (byte)(paramInt >> 24);
    arrayOfByte[1] = (byte)(paramInt >> 16);
    arrayOfByte[2] = (byte)(paramInt >> 8);
    arrayOfByte[3] = (byte)paramInt;
    return arrayOfByte;
  }
  
  private String a(String paramString, byte[] paramArrayOfByte) { return a(paramString, paramArrayOfByte, this.cb); }
  
  private String a(String paramString1, byte[] paramArrayOfByte, String paramString2) {
    String str = "";
    try {
      this.co = DocumentBuilderFactory.newInstance();
      this.co.setIgnoringComments(true);
      this.cp = this.co.newDocumentBuilder();
      this.cr = new InputSource(new ByteArrayInputStream(paramArrayOfByte));
      if (paramString2 != null)
        this.cr.setEncoding(paramString2); 
      this.cq = this.cp.parse(this.cr);
      this.cs = this.cq.getFirstChild();
      this.cw = this.cs.getAttributes();
      this.cu = this.cs.getNodeName();
      this.cv = this.cs.getNodeValue();
      while (this.cs.hasChildNodes()) {
        this.cs = this.cs.getFirstChild();
        this.cu = this.cs.getNodeName();
        this.cv = this.cs.getNodeValue();
        this.cw = this.cs.getAttributes();
        if (this.cu.equals(paramString1)) {
          this.cs = this.cs.getFirstChild();
          if (this.cs.getNodeType() == 3) {
            this.cu = this.cs.getNodeName();
            this.cv = this.cs.getNodeValue();
            this.cw = this.cs.getAttributes();
            str = this.cv;
          } 
        } 
      } 
    } catch (Exception exception) {}
    return str;
  }
  
  private Node a(String paramString, Node paramNode) {
    Node node = null;
    if (paramNode != null)
      if (paramNode.getNodeName().equals(paramString)) {
        node = paramNode;
      } else if (paramNode.getNextSibling() != null) {
        node = a(paramString, paramNode.getNextSibling());
      } else if (paramNode.hasChildNodes()) {
        node = a(paramString, paramNode.getFirstChild());
      }  
    return node;
  }
  
  private Vector a(byte[] paramArrayOfByte) {
    Node node1 = null;
    Node node2 = null;
    Node node3 = null;
    try {
      this.co = DocumentBuilderFactory.newInstance();
      this.co.setIgnoringComments(true);
      this.cp = this.co.newDocumentBuilder();
      this.cr = new InputSource(new ByteArrayInputStream(paramArrayOfByte));
      this.cr.setEncoding(this.cb);
      this.cq = this.cp.parse(this.cr);
      node1 = this.cq.getFirstChild();
      this.ch = new Vector();
      do {
        node1 = a("TAB", node1);
        node2 = node1.getFirstChild();
        node2 = a("TABNAME", node2);
        node3 = node2.getFirstChild();
        if (node3.getNodeType() == 3)
          this.ch.addElement(node3.getNodeValue()); 
        node1 = node1.getNextSibling();
      } while (node1 != null);
    } catch (Exception exception) {}
    return this.ch;
  }
  
  private boolean b(String paramString, byte[] paramArrayOfByte) {
    Node node = null;
    try {
      this.co = DocumentBuilderFactory.newInstance();
      this.co.setIgnoringComments(true);
      this.cp = this.co.newDocumentBuilder();
      this.cr = new InputSource(new ByteArrayInputStream(paramArrayOfByte));
      this.cr.setEncoding(this.cb);
      this.cq = this.cp.parse(this.cr);
      node = this.cq.getFirstChild();
      while (node.hasChildNodes()) {
        node = node.getFirstChild();
        this.cu = node.getNodeName();
        if (this.cu.equals(paramString))
          return true; 
      } 
      return false;
    } catch (Exception exception) {
      return false;
    } 
  }
  
  private Vector a(byte[] paramArrayOfByte, boolean paramBoolean) {
    try {
      this.co = DocumentBuilderFactory.newInstance();
      this.co.setIgnoringComments(true);
      this.cp = this.co.newDocumentBuilder();
      this.cr = new InputSource(new ByteArrayInputStream(paramArrayOfByte));
      this.cr.setEncoding(this.cb);
      this.cq = this.cp.parse(this.cr);
      this.cs = this.cq.getFirstChild();
      this.cs = a("DATA", this.cs);
      Node node1 = this.cs;
      Node node2 = null;
      Node node3 = this.cs;
      Node node4 = null;
      Node node5 = null;
      Node node6 = null;
      this.ch = new Vector();
      if (paramBoolean) {
        node3 = a("header", node3);
        this.cj = new Vector();
        node4 = node3.getFirstChild();
        do {
          node4 = a("column", node4);
          node5 = a("name", node4.getFirstChild());
          node6 = node5.getFirstChild();
          if (node6.getNodeType() == 3)
            this.cj.addElement(node6.getNodeValue()); 
          node4 = node4.getNextSibling();
        } while (node4 != null);
        this.ch.addElement(this.cj);
        node1 = node3;
      } 
      do {
        node1 = a("row", node1);
        node2 = node1.getFirstChild();
        this.ci = new Vector();
        do {
          node2 = a("tabitem", node2);
          node6 = node2.getFirstChild();
          if (node6.getNodeType() == 3)
            this.ci.addElement(node6.getNodeValue()); 
          node2 = node2.getNextSibling();
        } while (node2 != null);
        this.ch.addElement(this.ci);
        node1 = node1.getNextSibling();
      } while (node1 != null);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return this.ch;
  }
  
  public static void b(String[] paramArrayOfString) throws Exception {
    Protocol protocol = new Protocol();
    protocol.c(paramArrayOfString);
  }
  
  public void c(String[] paramArrayOfString) throws Exception {
    String str1 = "localhost";
    String str2 = "2001";
    String str3 = "5";
    String str4 = "1";
    String str5 = "password";
    String str6 = "user";
    String str7 = "0";
    Vector vector = new Vector();
    boolean bool = true;
    try {
      for (byte b11 = 0; b11 < paramArrayOfString.length; b11++) {
        System.out.println("args[" + b11 + "]=" + paramArrayOfString[b11]);
        if (paramArrayOfString[b11].equalsIgnoreCase("-cmd"))
          while (b11 < paramArrayOfString.length - 1 && !paramArrayOfString[++b11].substring(0, 1).equalsIgnoreCase("-")) {
            System.out.println("while " + paramArrayOfString[b11]);
            vector.addElement(paramArrayOfString[b11]);
          }  
        if (paramArrayOfString[b11].equalsIgnoreCase("-usr"))
          str6 = paramArrayOfString[++b11]; 
        if (paramArrayOfString[b11].equalsIgnoreCase("-pwd"))
          str5 = paramArrayOfString[++b11]; 
        if (paramArrayOfString[b11].equalsIgnoreCase("-host"))
          str1 = paramArrayOfString[++b11]; 
        if (paramArrayOfString[b11].equalsIgnoreCase("-port"))
          str2 = paramArrayOfString[++b11]; 
        if (paramArrayOfString[b11].equalsIgnoreCase("-repeat"))
          str4 = paramArrayOfString[++b11]; 
        if (paramArrayOfString[b11].equalsIgnoreCase("-index"))
          str7 = paramArrayOfString[++b11]; 
        if (paramArrayOfString[b11].equalsIgnoreCase("-time"))
          str3 = paramArrayOfString[++b11]; 
        if (paramArrayOfString[b11].equalsIgnoreCase("-server"))
          bool = false; 
      } 
      System.out.println("---");
    } catch (Exception exception) {
      System.out.print("USAGE: com.softwareag.entirex.argus.Protocol -index <index> -host <hostname> -port <port> -cmd <command> -usr <user> -pwd <password> -repeat <counter>");
      System.exit(1);
    } 
    if (bool) {
      System.out.println("Running as Client");
      System.out.println("Calling Server: " + str1 + ":" + str2 + "(" + str3 + ")");
      System.out.println("Repeat: " + str4);
      System.out.println("Command Counter: " + vector.size());
    } else {
      System.out.println("Running as Server");
      System.out.println("Listen to Port: " + str2 + "(" + str3 + ")");
      System.out.println("Repeat: " + str4);
      System.out.println("Command Counter: " + vector.size());
    } 
    Protocol protocol = null;
    String str8 = null;
    for (byte b10 = 0; b10 < Integer.parseInt(str4); b10++) {
      try {
        if (bool) {
          protocol = new Protocol(null, str1, Integer.parseInt(str2), Integer.parseInt(str3));
          for (byte b11 = 0; b11 < vector.size(); b11++) {
            str8 = (String)vector.elementAt(b11);
            System.out.println("sCommand=" + str8);
            if (str8.equalsIgnoreCase("logon")) {
              protocol.logon(str6, str5);
            } else if (str8.equalsIgnoreCase("stop")) {
              protocol.stop();
            } else if (str8.equalsIgnoreCase("restart")) {
              protocol.restart();
            } else if (str8.equalsIgnoreCase("getsi")) {
              protocol.getServerInfo();
            } else if (str8.equalsIgnoreCase("getcsi")) {
              protocol.getEnhancedServerInfo();
            } else if (str8.equalsIgnoreCase("gettabnum")) {
              protocol.getServerTableNames();
            } else if (str8.equalsIgnoreCase("gettab")) {
              protocol.getServerTable(Integer.parseInt(str7));
            } else if (str8.equalsIgnoreCase("trace")) {
              protocol.trace("levelString", "fileName");
            } 
          } 
        } else {
          Logger.traceWithPrefixAndNewline(this.cm, "main: new Protocol()");
          ServerSocket serverSocket = new ServerSocket(Integer.parseInt(str2));
          serverSocket.setSoTimeout(Integer.parseInt(str3));
          protocol = new Protocol(null, serverSocket.accept());
          Logger.traceWithPrefixAndNewline(this.cm, "main: getCommand()");
          while (true) {
            int i2;
            int i1 = protocol.b();
            Logger.traceWithPrefixAndNewline(this.cm, "main: getCommand()=" + i1);
            switch (i1) {
              case 1:
                a(1);
                break;
              case 2:
                b(2);
                break;
              case 3:
                c(3);
                break;
              case 4:
                b(new String[][] { { "state", "Init" }, { "uptime", "2003" }, { "worker", "12" }, { "high", "100" }, { "name", "localhost" }, { "address", "1999" } });
                break;
              case 5:
                c(new String[][] { { "aaa", "0" }, { "bbb", "1" }, { "ccc", "2" }, { "ddd", "3" }, { "eee", "4" }, { "fff", "5" } });
                break;
              case 6:
                a(new String[] { "1. Table", "2. Table", "3. Table" });
                break;
              case 7:
                i2 = Integer.parseInt(a("GETTAB", this.cd));
                Logger.traceWithPrefixAndNewline(this.cm, "main: table index=" + i2);
                if (i2 == 0) {
                  a(new String[][] { { "1.Table", "9" }, { "def", "99" }, { "ghi", "999" }, { "jkl", "9999" } });
                  break;
                } 
                if (i2 == 1) {
                  a(new String[][] { { "2.Table", "9" }, { "def", "99" }, { "ghi", "999" }, { "jkl", "9999" } });
                  break;
                } 
                a(new String[][] { { "3.Table", "9" }, { "def", "99" }, { "ghi", "999" }, { "jkl", "9999" } });
                break;
            } 
          } 
        } 
        protocol.close();
      } catch (Exception exception) {
        System.out.println("error: " + exception);
        if (protocol != null)
          protocol.close(); 
      } finally {
        try {
          if (protocol != null)
            protocol.close(); 
        } catch (Exception exception) {
          System.out.println("error finally: " + exception);
        } 
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\argus\base\Protocol.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */