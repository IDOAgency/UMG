package com.softwareag.entirex.argus.base;

import com.softwareag.entirex.aci.Dump;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Logger {
  private static int a = Integer.parseInt(System.getProperty("entirex.trace", "0"));
  
  private static String b = System.getProperty("file.separator", "/");
  
  private static String c = System.getProperty("java.io.tmpdir", "");
  
  private static File d = null;
  
  private static FileWriter e = null;
  
  private static FileWriter a(String paramString) {
    if (a > 0)
      try {
        if (paramString == null) {
          d = null;
          e = null;
        } else {
          String str;
          d = new File((str = String.valueOf((new SimpleDateFormat("yyyy-MM-dd")).format(new Date())) + "-EntireX-" + paramString + ".txt").valueOf(c) + str);
          e = new FileWriter(d.getCanonicalPath(), true);
        } 
      } catch (Exception exception) {
        exception.printStackTrace(System.err);
      }  
    return e;
  }
  
  public static String getTraceFilename(String paramString) {
    String str = "undefined";
    try {
      str = d.getCanonicalPath();
    } catch (Exception exception) {}
    return str;
  }
  
  public static boolean active() { return (a > 0); }
  
  public static void traceWithPrefixAndNewline(String paramString1, String paramString2) {
    if (a > 0)
      try {
        e = a(paramString1);
        if (e == null) {
          Dump.setTrace(a, new PrintWriter(System.err), false);
        } else {
          Dump.setTrace(a, new PrintWriter(e), false);
        } 
        Dump.log(paramString2);
        e.close();
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public static void traceWithPrefix(String paramString1, String paramString2) {
    if (a > 0)
      try {
        e = a(paramString1);
        if (e == null) {
          Dump.setTrace(a);
        } else {
          Dump.setTrace(a, new PrintWriter(e), false);
        } 
        Dump.logNoNewline(paramString2);
        e.close();
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public static void traceWithNewline(String paramString1, String paramString2) {
    if (a > 0)
      try {
        e = a(paramString1);
        if (e == null) {
          Dump.setTrace(a);
        } else {
          Dump.setTrace(a, new PrintWriter(e), false);
        } 
        Dump.logNoPrefix(paramString2);
        e.close();
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public static void trace(String paramString1, String paramString2) {
    if (a > 0)
      try {
        e = a(paramString1);
        if (e == null) {
          Dump.setTrace(a);
        } else {
          Dump.setTrace(a, new PrintWriter(e), false);
        } 
        Dump.logNoPrefixNoNewline(paramString2);
        e.close();
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public static void traceStack(String paramString1, String paramString2, Exception paramException) {
    if (a > 0)
      try {
        e = a(paramString1);
        if (e == null) {
          Dump.setTrace(a);
        } else {
          Dump.setTrace(a, new PrintWriter(e), false);
        } 
        Dump.logNoPrefix(paramString2);
        if (e == null) {
          paramException.printStackTrace();
        } else {
          paramException.printStackTrace(new PrintWriter(e));
        } 
        e.close();
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public static void traceBuffer(String paramString1, String paramString2, byte[] paramArrayOfByte) {
    if (a > 0)
      try {
        e = a(paramString1);
        if (e == null) {
          Dump.setTrace(a);
        } else {
          Dump.setTrace(a, new PrintWriter(e), false);
        } 
        Dump.dumpBytes(String.valueOf(paramString2) + " ", paramArrayOfByte, paramArrayOfByte.length, 2);
        e.close();
        return;
      } catch (Exception exception) {
        return;
      }  
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\argus\base\Logger.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */