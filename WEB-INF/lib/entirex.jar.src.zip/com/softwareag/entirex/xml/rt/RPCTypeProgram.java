package com.softwareag.entirex.xml.rt;

import java.io.UnsupportedEncodingException;

public class RPCTypeProgram extends RPCTypeStructure {
  private String a = null;
  
  private String b;
  
  private int c;
  
  private int d;
  
  private int e;
  
  private int f;
  
  protected int g;
  
  private static final int h = 0;
  
  private static final int i = 1;
  
  private static final int j = 2;
  
  private int k;
  
  private int l;
  
  private long m = 0L;
  
  private XMLTypeElement n = null;
  
  private XMLTypeElement o = null;
  
  RPCTypeProgram(String paramString) { this(paramString, "", 0, 0, 0, 0); }
  
  public RPCTypeProgram(String paramString1, String paramString2, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(a3.b(paramString1), 21, 3);
    this.a = paramString1;
    if (!paramString2.endsWith("."))
      paramString2 = paramString2 + '.'; 
    this.b = paramString2;
    this.c = paramInt1;
    this.d = paramInt2;
    this.e = paramInt3;
    this.f = 0;
    this.g = paramInt4;
    this.k = 0;
    this.l = 0;
  }
  
  public void setAssociatedProgramXmlToRpc(XMLTypeElement paramXMLTypeElement) { this.n = paramXMLTypeElement; }
  
  public void setAssociatedProgramRpcToXml(XMLTypeElement paramXMLTypeElement) { this.o = paramXMLTypeElement; }
  
  public XMLTypeElement getAssociatedProgramXmlToRpc() { return this.n; }
  
  public XMLTypeElement getAssociatedProgramRpcToXml() { return this.o; }
  
  public void setParameterCount(long paramLong) { this.m = paramLong; }
  
  public long getParameterCount() { return this.m; }
  
  public cp createValueNode() { return new ct(this); }
  
  public byte[] getFormatBuffer() { return this.b.getBytes(); }
  
  public byte[] getFormatBuffer(String paramString) {
    byte[] arrayOfByte = null;
    try {
      arrayOfByte = this.b.getBytes(paramString);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      arrayOfByte = this.b.getBytes();
    } 
    return arrayOfByte;
  }
  
  public int getInLength() { return this.c; }
  
  public int getInOutLength() { return this.d; }
  
  public int getOutLength() { return this.e; }
  
  public int getRequiredProtocol() { return this.g; }
  
  public RPCTypeLibrary getLibrary() { return (RPCTypeLibrary)super.e; }
  
  public String getOriginalName() { return this.a; }
  
  protected int c() { return this.f; }
  
  protected void a(int paramInt) { this.f = paramInt; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\RPCTypeProgram.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */