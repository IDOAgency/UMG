package com.softwareag.entirex.xml.rt;

import java.util.Hashtable;
import java.util.Vector;

public class a7 {
  protected Vector a = new Vector();
  
  protected String b = null;
  
  protected Hashtable c = new Hashtable();
  
  protected a7 d;
  
  private StringBuffer e = new StringBuffer();
  
  protected at f = new at();
  
  public a7(String paramString1, String paramString2, String paramString3) { this.b = av.a(null, paramString1, paramString2, paramString3); }
  
  public void a(StringBuffer paramStringBuffer) { this.e.append(paramStringBuffer); }
  
  public void a(String paramString) { this.e.append(paramString); }
  
  public String a() { return this.e.toString(); }
  
  public a7 a(a7 parama7) {
    parama7.b(this);
    this.a.addElement(parama7);
    String str = parama7.d();
    Vector vector = (Vector)this.c.get(str);
    if (vector == null) {
      vector = new Vector();
      this.c.put(str, vector);
    } 
    vector.addElement(parama7);
    return parama7;
  }
  
  public a7 a(a7 parama7, int paramInt) {
    parama7.b(this);
    int i = this.a.size();
    if (i <= paramInt) {
      this.a.addElement(parama7);
    } else {
      int j = 0;
      String str1 = null;
      for (byte b1 = 0; b1 < paramInt; b1++) {
        str1 = ((a7)this.a.get(b1)).d();
        j += b(str1);
      } 
      str1 = ((a7)this.a.get(paramInt)).d();
      if (str1.equals(parama7.d())) {
        j += b(str1);
        j++;
      } 
      this.a.insertElementAt(parama7, j);
    } 
    String str = parama7.d();
    Vector vector = (Vector)this.c.get(str);
    if (vector == null) {
      vector = new Vector();
      this.c.put(str, vector);
    } 
    vector.addElement(parama7);
    return parama7;
  }
  
  public int b() { return this.a.size(); }
  
  public int b(String paramString) {
    null = 0;
    Vector vector = (Vector)this.c.get(paramString);
    return (vector != null) ? vector.size() : 0;
  }
  
  public a7 a(int paramInt) {
    a7 a71 = null;
    if (this.a.size() > paramInt)
      a71 = (a7)this.a.elementAt(paramInt); 
    return a71;
  }
  
  public a7 c(String paramString) {
    a7 a71 = null;
    Vector vector = (Vector)this.c.get(paramString);
    if (vector != null)
      a71 = (a7)vector.elementAt(0); 
    return a71;
  }
  
  public a7 a(String paramString, int paramInt) {
    a7 a71 = null;
    Vector vector = (Vector)this.c.get(paramString);
    if (vector != null && paramInt < vector.size())
      a71 = (a7)vector.elementAt(paramInt); 
    return a71;
  }
  
  public void a(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    a8 a8 = new a8(paramString1, paramString2, paramString4, paramString5);
    this.f.a(a8);
  }
  
  public String d(String paramString) { return this.f.a(paramString); }
  
  public void b(a7 parama7) { this.d = parama7; }
  
  public a7 c() { return this.d; }
  
  public String d() { return this.b; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\a7.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */