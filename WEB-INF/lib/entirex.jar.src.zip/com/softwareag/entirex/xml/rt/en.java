package com.softwareag.entirex.xml.rt;

import java.util.Hashtable;

public class en {
  static Hashtable a = new Hashtable();
  
  private en(String paramString) {}
  
  protected static eo a(String paramString) {
    eo eo = (eo)a.get(paramString);
    if (eo == null) {
      eo = new eo(paramString);
      a.put(paramString, eo);
    } 
    return eo;
  }
  
  static  {
    String str = null;
    str = "UTF8";
    a.put(str, new eo(str));
    str = System.getProperty("file.encoding");
    a.put(str, new eo(str));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\en.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */