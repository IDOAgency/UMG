package com.softwareag.entirex.xml.rt;

class cr extends cp {
  public cr(RPCTypeArray paramRPCTypeArray) {
    this.d = null;
    this.b = paramRPCTypeArray;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\cr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */