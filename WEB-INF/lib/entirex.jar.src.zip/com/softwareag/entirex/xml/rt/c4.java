package com.softwareag.entirex.xml.rt;

import java.util.Hashtable;
import java.util.Vector;

public class c4 {
  private Vector a = new Vector();
  
  private Hashtable b = new Hashtable();
  
  int c = 0;
  
  public void a(dd paramdd) {
    String str = paramdd.a().c();
    dd dd1 = (dd)this.b.get(str);
    if (dd1 == null) {
      this.b.put(str, paramdd);
      this.a.addElement(paramdd);
      this.c++;
    } else {
      dd1.a(paramdd.b());
    } 
  }
  
  public int a() { return this.c; }
  
  public String a(String paramString) {
    String str = null;
    dd dd = (dd)this.b.get(paramString);
    if (dd != null)
      str = dd.b(); 
    return str;
  }
  
  public dd b(String paramString) { return (dd)this.b.get(paramString); }
  
  public dd a(int paramInt) {
    dd dd = null;
    if (paramInt >= 0 && paramInt < a())
      dd = (dd)this.a.elementAt(paramInt); 
    return dd;
  }
  
  public void c(String paramString) {
    dd dd = (dd)this.b.get(paramString);
    if (dd != null) {
      this.b.remove(paramString);
      for (byte b1 = 0; b1 < this.a.size(); b1++) {
        if (dd == (dd)this.a.get(b1)) {
          this.a.remove(b1);
          break;
        } 
      } 
      this.c--;
    } 
  }
  
  public Object clone() {
    c4 c41 = new c4();
    for (byte b1 = 0; b1 < a(); b1++)
      c41.a((dd)a(b1).clone()); 
    c41.c = this.c;
    return c41;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\c4.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */