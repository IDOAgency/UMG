package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.Conversation;
import com.softwareag.entirex.base.a4;
import com.softwareag.entirex.trace.Trace;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

final class dq {
  private final String a = "charset";
  
  private String b;
  
  private long c;
  
  private String d;
  
  private String e;
  
  private String f;
  
  private String g;
  
  private String h;
  
  private String i;
  
  private String j;
  
  private String k;
  
  private Conversation l = null;
  
  private String m;
  
  private String n;
  
  private String o;
  
  private String p;
  
  private String q;
  
  private String r;
  
  private String s;
  
  private String t;
  
  private String u;
  
  private String v;
  
  private String w;
  
  private String x;
  
  private String y;
  
  private String z;
  
  private String aa;
  
  private String ab;
  
  private String ac;
  
  private byte[] ad;
  
  private Vector ae;
  
  private Vector af;
  
  private String ag;
  
  private XMLRPCService ah;
  
  private String ai;
  
  dq(XMLRPCService paramXMLRPCService, String paramString) {
    synchronized (this) {
      if (XMLServlet.ap && paramString != null)
        Trace.checkpoint(Trace.CP2, 6, 11, 8, "SessionId", paramString); 
      this.b = paramString;
      a(paramXMLRPCService);
      this.w = XMLServlet.getServletInitFileName();
      this.x = XMLServlet.getServletLocationTransparencyInitFile();
      this.y = XMLServlet.getServletLocationTransparencyInitConfig();
      this.z = "";
    } 
  }
  
  public void a() {
    this.ag = null;
    this.c = System.currentTimeMillis();
    this.d = null;
    this.e = null;
    this.h = null;
    this.i = null;
    this.j = null;
    this.k = null;
    this.ae = new Vector();
    this.af = new Vector();
    this.g = null;
    this.f = null;
    this.p = null;
    this.q = null;
    this.r = null;
    this.m = null;
    this.n = null;
    this.o = null;
    this.aa = null;
    this.ab = null;
    this.ai = null;
  }
  
  public void a(XMLRPCService paramXMLRPCService) {
    this.ah = paramXMLRPCService;
    a();
    if (this.ah != null)
      this.ah.resume(); 
  }
  
  private void b(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws XMLException, BrokerException, IOException {
    if (!this.ah.isConversational()) {
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP1, 6, 11, 35, "New SessionID:", this.b); 
      c(paramHttpServletRequest, paramHttpServletResponse);
      b();
      paramHttpServletResponse.setHeader("exx-xml-info", "NEW SESSION");
    } else if (XMLServlet.ap) {
      Trace.checkpoint(Trace.CP1, 6, 11, 35, "SessionId", this.b);
    } 
    int i1 = paramHttpServletRequest.getContentLength();
    boolean bool = false;
    if (this.ac != null && this.ac.trim().length() > 0) {
      i1 = 0;
      bool = true;
    } 
    if (i1 < 0) {
      String str = "Incoming document is empty.";
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP1, 6, 11, 35, str); 
      a(paramHttpServletResponse, str);
      paramHttpServletResponse.setHeader("exx-xml-error", str);
      try {
        paramHttpServletResponse.sendError(400, str);
      } catch (IllegalStateException illegalStateException) {}
      throw new XMLException(54);
    } 
    if (i1 == 0) {
      try {
        BufferedInputStream bufferedInputStream = null;
        if (bool) {
          try {
            a4 a4 = new a4(this.ac, null, null);
            bufferedInputStream = new BufferedInputStream(a4.getFileAsInputStream());
          } catch (Exception exception) {
            bufferedInputStream = new BufferedInputStream(paramHttpServletRequest.getInputStream());
          } 
        } else {
          bufferedInputStream = new BufferedInputStream(paramHttpServletRequest.getInputStream());
        } 
        int i2 = 0;
        byte b1 = 1;
        char c1 = 'Ѐ';
        byte[] arrayOfByte1 = new byte[c1];
        byte[] arrayOfByte2 = new byte[c1];
        this.ad = new byte[0];
        while ((i2 = bufferedInputStream.read(arrayOfByte1)) != -1) {
          if (XMLServlet.ap)
            Trace.checkpoint(Trace.CP4, 6, 11, 35, b1 + " " + new String(arrayOfByte1, 0, i2)); 
          if (b1 > 1) {
            System.arraycopy(this.ad, 0, arrayOfByte2, 0, this.ad.length);
            this.ad = new byte[this.ad.length + i2];
            System.arraycopy(arrayOfByte2, 0, this.ad, 0, arrayOfByte2.length);
            System.arraycopy(arrayOfByte1, 0, this.ad, arrayOfByte2.length, i2);
          } else {
            this.ad = new byte[i2];
            System.arraycopy(arrayOfByte1, 0, this.ad, 0, i2);
          } 
          arrayOfByte2 = new byte[this.ad.length];
          b1++;
        } 
      } catch (Exception exception) {
        throw new XMLException(52, exception.toString());
      } 
    } else {
      try {
        this.ad = new byte[i1];
        BufferedInputStream bufferedInputStream = new BufferedInputStream(paramHttpServletRequest.getInputStream());
        try {
          cy cy = new cy();
          cy.a(bufferedInputStream);
          this.ag = cy.c();
        } catch (Exception exception) {}
        DataInputStream dataInputStream = new DataInputStream(bufferedInputStream);
        dataInputStream.readFully(this.ad, 0, i1);
      } catch (EOFException eOFException) {
        throw new XMLException(55);
      } catch (Exception exception) {
        throw new XMLException(52, exception.toString());
      } 
    } 
    if (XMLServlet.ap) {
      String str = "";
      try {
        str = "=" + System.getProperty("file.encoding");
      } catch (Exception exception) {}
      Trace.checkpoint(Trace.CP1, 6, 11, 35, "XML-InString (platform-encoding" + str + "): ", "\r\n" + new String(this.ad));
      if (this.ag != null)
        Trace.checkpoint(Trace.CP1, 6, 11, 35, "XML-InString (encoding=" + this.ag + "): ", "\r\n" + new String(this.ad, this.ag)); 
    } 
  }
  
  private void c(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws XMLException, BrokerException, IOException {
    Enumeration enumeration = paramHttpServletRequest.getHeaderNames();
    String str = "header";
    for (byte b1 = 0; b1 < 2; b1++) {
      while (enumeration.hasMoreElements()) {
        String str1 = (String)enumeration.nextElement();
        if (str1.toLowerCase().startsWith("exx-")) {
          String str3 = null;
          if (!b1) {
            str3 = paramHttpServletRequest.getHeader(str1);
          } else {
            str3 = paramHttpServletRequest.getParameter(str1);
          } 
          b(str1, str3);
          if (XMLServlet.ap) {
            String str5 = str3;
            if (str1.equals("exx-password") || str1.equals("exx-rpc-password"))
              str5 = a(str5); 
            Trace.checkpoint(Trace.CP2, 6, 11, 6, "HTTP-" + str + ": " + str1, str5);
          } 
          if (str1.equalsIgnoreCase("exx-xml-adapter")) {
            this.e = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-brokerID")) {
            this.f = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-userID")) {
            this.h = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-password")) {
            this.i = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-rpc-userID")) {
            this.j = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-rpc-password")) {
            this.k = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-service")) {
            this.g = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-use-security")) {
            this.m = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-natural-security")) {
            this.n = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-encryption-level")) {
            this.o = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-logical-brokerID")) {
            this.p = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-logical-service")) {
            this.q = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-logicalsetname")) {
            this.r = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-use-codepage")) {
            this.aa = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-compresslevel")) {
            this.s = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-xmm")) {
            this.u = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-test")) {
            this.ab = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-input-file")) {
            this.ac = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-natural-library")) {
            this.v = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-compression")) {
            this.t = str3;
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-xml-init") || str1.equalsIgnoreCase("exx-locationtransparency-init") || str1.equalsIgnoreCase("exx-locationtransparency-config") || str1.equalsIgnoreCase("exx-trace-propertiesfile") || str1.equalsIgnoreCase("exx-sweeptime") || str1.equalsIgnoreCase("exx-default-waittime")) {
            if (XMLServlet.ap) {
              String str5 = "WARNING: " + str1 + " is an init parameter. The using here takes no effect.";
              Trace.checkpoint(Trace.CP1, 6, 11, 6, str5);
            } 
            continue;
          } 
          if (str1.equalsIgnoreCase("exx-conv") || str1.equalsIgnoreCase("exx-xml-info") || str1.equalsIgnoreCase("exx-xml-error") || str1.equalsIgnoreCase("exx-xml-buddy") || str1.equalsIgnoreCase("exx-xml-sessionID"))
            continue; 
          String str4 = "Wrong HTTP-" + str + ": " + str1 + ".";
          if (XMLServlet.ap)
            Trace.checkpoint(Trace.CP1, 6, 11, 6, str4); 
          a(paramHttpServletResponse, str4);
          paramHttpServletResponse.setHeader("exx-xml-error", str4);
          try {
            paramHttpServletResponse.sendError(400, str4);
          } catch (IllegalStateException illegalStateException) {}
          throw new XMLException(52, "( " + str4 + " )");
        } 
        String str2 = null;
        if (!b1) {
          str2 = paramHttpServletRequest.getHeader(str1);
          if (str1.equalsIgnoreCase("SOAPAction")) {
            this.ai = str2;
          } else if (!str1.equalsIgnoreCase("content-length") && !str1.equalsIgnoreCase("accept") && str2 != null) {
            paramHttpServletResponse.setHeader(str1, str2);
          } 
        } else {
          str2 = paramHttpServletRequest.getParameter(str1);
        } 
        if (XMLServlet.ap)
          Trace.checkpoint(Trace.CP2, 6, 11, 6, "HTTP-" + str + ": " + str1, str2); 
      } 
      enumeration = paramHttpServletRequest.getParameterNames();
      str = "parameter";
    } 
  }
  
  private void b() {
    this.e = a("exx-xml-adapter", this.e);
    this.f = a("exx-brokerID", this.f);
    this.aa = a("exx-use-codepage", this.aa);
    this.t = a("exx-compression", this.t);
    this.s = a("exx-compresslevel", this.s);
    this.o = a("exx-encryption-level", this.o);
    this.ac = a("exx-input-file", this.ac);
    this.r = a("exx-logicalsetname", this.r);
    this.p = a("exx-logical-brokerID", this.p);
    this.q = a("exx-logical-service", this.q);
    this.v = a("exx-natural-library", this.v);
    this.n = a("exx-natural-security", this.n);
    this.i = a("exx-password", this.i);
    this.k = a("exx-rpc-password", this.k);
    this.j = a("exx-rpc-userID", this.j);
    this.m = a("exx-use-security", this.m);
    this.g = a("exx-service", this.g);
    this.ab = a("exx-test", this.ab);
    this.h = a("exx-userID", this.h);
    this.u = a("exx-xmm", this.u);
  }
  
  private String a(String paramString1, String paramString2) {
    String str = paramString2;
    if (paramString2 == null && paramString1 != null) {
      String str1 = null;
      try {
        str1 = System.getProperty(paramString1);
      } catch (Exception exception) {}
      if (str1 != null && str1.trim().length() > 0) {
        str = str1.trim();
        if (XMLServlet.ap) {
          String str2 = str1;
          if (paramString1.equals("exx-password") || paramString1.equals("exx-rpc-password"))
            str2 = a(str2); 
          Trace.checkpoint(Trace.CP2, 6, 11, 6, "SYSTEM Property: " + paramString1, str2);
        } 
      } 
    } 
    return str;
  }
  
  protected void a(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws XMLException, BrokerException, IOException {
    if (XMLServlet.ap) {
      Trace.enterMethod(Trace.M3, 6, 11, 26);
      Trace.showMemoryUsage(Trace.RM, 5);
    } 
    String str = XMLServlet.a(paramHttpServletRequest, "exx-conv");
    try {
      this.e = null;
      this.u = null;
      b(paramHttpServletRequest, paramHttpServletResponse);
      paramHttpServletResponse.setHeader("exx-xml-sessionID", this.b);
      if (this.d != null)
        paramHttpServletResponse.setHeader("exx-xml-buddy", this.d); 
      String str1 = paramHttpServletRequest.getContentType();
      if (str1 == null || str1.length() <= 0)
        str1 = "text/xml"; 
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP2, 6, 11, 26, "request contentType", str1); 
      paramHttpServletResponse.setContentType(str1);
      String str2 = paramHttpServletRequest.getCharacterEncoding();
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP2, 6, 11, 26, "request charSet", str2); 
      int i1 = paramHttpServletRequest.getContentLength();
      this.l = this.ah.g();
      if (XMLServlet.ap) {
        Trace.checkpoint(Trace.CP1, 6, 11, 26, "Before xmlrt Call, request content length", i1);
        if (this.l == null) {
          Trace.checkpoint(Trace.CP2, 6, 11, 26, "No conversation object exists");
        } else {
          Trace.checkpoint(Trace.CP2, 6, 11, 26, "Conversation object exists");
        } 
      } 
      if (i1 < 1) {
        paramHttpServletResponse.setHeader("exx-xml-error", "no input");
        try {
          paramHttpServletResponse.sendError(400, "no input");
        } catch (IllegalStateException illegalStateException) {}
        return;
      } 
      ay ay = new ay();
      String str3 = this.f;
      if (str3 != null)
        ay.a(str3); 
      str3 = this.g;
      if (str3 != null)
        ay.b(str3); 
      str3 = this.p;
      if (str3 != null)
        ay.c(str3); 
      str3 = this.q;
      if (str3 != null)
        ay.d(str3); 
      str3 = this.r;
      if (str3 != null)
        ay.e(str3); 
      str3 = this.h;
      if (str3 != null)
        ay.f(str3); 
      str3 = this.i;
      if (str3 != null)
        ay.p(str3); 
      str3 = this.j;
      if (str3 != null)
        ay.g(str3); 
      str3 = this.k;
      if (str3 != null)
        ay.q(str3); 
      str3 = this.m;
      if (str3 != null)
        ay.h(str3); 
      str3 = this.o;
      if (str3 != null)
        ay.i(str3); 
      str3 = this.n;
      if (str3 != null)
        ay.j(str3); 
      str3 = this.v;
      if (str3 != null)
        ay.k(str3); 
      if (this.z != null && this.z.trim().length() > 0)
        ay.n(this.z); 
      str3 = this.aa;
      if (str3 != null)
        ay.o(str3); 
      str3 = this.s;
      if (str3 != null)
        ay.m(str3); 
      str3 = this.t;
      if (str3 != null)
        ay.l(str3); 
      str3 = this.ai;
      if (str3 != null)
        ay.r(str3); 
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP4, 6, 11, 26, "esd before=" + XMLServlet.getXMLRuntimeRepository().u()); 
      XMLServlet.getXMLRuntimeRepository().a(ay);
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP4, 6, 11, 26, "esd after=" + XMLServlet.getXMLRuntimeRepository().u()); 
      this.ah.a(XMLServlet.getXMLRuntimeRepository());
      this.ah.b(str2);
      if (this.aa != null) {
        if (XMLServlet.ap)
          Trace.checkpoint(Trace.CP2, 6, 11, 26, "useCodepage( " + XMLServlet.b(this.aa) + " )"); 
        this.ah.i().c(XMLServlet.b(this.aa));
      } 
      if (this.e != null) {
        if (XMLServlet.ap)
          Trace.checkpoint(Trace.CP2, 6, 11, 26, "loading XMLAdapter " + this.e); 
        this.ah.a(this.e, XMLServlet.getXMLRuntimeRepository());
      } else if (this.u != null) {
        if (XMLServlet.ap)
          Trace.checkpoint(Trace.CP2, 6, 11, 26, "loading XMM file " + this.u); 
        this.ah.a(this.u, XMLServlet.getXMLRuntimeRepository());
      } 
      if (str != null && str.equalsIgnoreCase("open")) {
        if (this.l != null)
          this.l = null; 
        this.ah.h();
        if (XMLServlet.ap)
          Trace.checkpoint(Trace.CP2, 6, 11, 26, "New conversation created"); 
        this.ah.setPoolKey(this.b);
      } 
      this.ah.invokeXML(new ByteArrayInputStream(this.ad), paramHttpServletResponse.getOutputStream());
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP1, 6, 11, 26, "after invokeXML"); 
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP4, 6, 11, 26, "esd current=" + XMLServlet.getXMLRuntimeRepository().u()); 
      if (this.l != null && str != null)
        if (str.equalsIgnoreCase("COMMIT")) {
          this.l.end();
          this.l = null;
          if (XMLServlet.ap)
            Trace.checkpoint(Trace.CP2, 6, 11, 26, "Conversation ended with commit"); 
        } else if (str.equalsIgnoreCase("BACKOUT")) {
          this.l.cancel();
          this.l = null;
          if (XMLServlet.ap)
            Trace.checkpoint(Trace.CP2, 6, 11, 26, "Conversation ended with backout"); 
        } else if (!str.equalsIgnoreCase("OPEN") && XMLServlet.ap) {
          Trace.checkpoint(Trace.CP2, 6, 11, 26, "Close conversation failed,  " + str + " is an unknown command!");
        }  
      this.l = this.ah.g();
      if (this.l == null)
        this.ah.setPoolKey(null); 
      this.ah.isConversational((this.l != null));
      str2 = this.ah.e();
      if (str2 != null) {
        if (XMLServlet.ap)
          Trace.checkpoint(Trace.CP2, 6, 11, 26, "response charSet", str2); 
        try {
          String str4 = null;
          int i2 = str1.toLowerCase().indexOf("charset");
          if (i2 != -1) {
            str4 = str1.substring(i2);
            if (str4.length() > "charset".length()) {
              str4 = str2.substring("charset".length());
              if (str4.length() > 0) {
                StringTokenizer stringTokenizer = new StringTokenizer(str4, "=,;");
                str4 = (String)stringTokenizer.nextElement();
                if (!str4.equals(str2))
                  str1 = str1.substring(0, i2) + "charset" + "=" + str2 + str1.substring(str1.indexOf(str4, i2), str4.length()); 
              } 
            } 
          } else {
            str1 = str1 + "; " + "charset" + "=" + str2;
          } 
        } catch (Exception exception) {}
      } 
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP2, 6, 11, 26, "response contentType", str1); 
      paramHttpServletResponse.setContentType(str1);
    } catch (IOException iOException) {
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP1, 6, 11, 26, "IOException", iOException.toString()); 
      paramHttpServletResponse.setHeader("exx-xml-error", iOException.toString());
      try {
        paramHttpServletResponse.sendError(400, iOException.toString());
      } catch (IllegalStateException illegalStateException) {}
    } catch (XMLException xMLException) {
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP1, 6, 11, 26, "XMLException", xMLException.toString()); 
      paramHttpServletResponse.setHeader("exx-xml-error", xMLException.toString());
      try {
        paramHttpServletResponse.sendError(400, xMLException.toString());
      } catch (IllegalStateException illegalStateException) {}
    } catch (BrokerException brokerException) {
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP1, 6, 11, 26, "BrokerException", brokerException.toString()); 
      paramHttpServletResponse.setHeader("exx-xml-error", brokerException.toString());
      try {
        paramHttpServletResponse.sendError(400, brokerException.toString());
      } catch (IllegalStateException illegalStateException) {}
    } catch (IllegalStateException illegalStateException) {
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP1, 6, 11, 26, "IllegalStateException", illegalStateException.toString()); 
    } catch (RuntimeException runtimeException) {
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP1, 6, 11, 26, "RuntimeException", runtimeException.toString()); 
      runtimeException.printStackTrace();
      throw runtimeException;
    } catch (Exception exception) {
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP1, 6, 11, 26, "Other Exception", exception.toString()); 
    } finally {
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP1, 6, 11, 26, "finally clearing in use flag", this.b); 
      this.ah.beFree();
      if (XMLServlet.ap) {
        Trace.showMemoryUsage(Trace.RM, 5);
        Trace.leaveMethod(Trace.M3, 6, 11, 26);
      } 
    } 
  }
  
  private void a(HttpServletResponse paramHttpServletResponse, String paramString) throws IOException {
    if (XMLServlet.ap)
      Trace.checkpoint(Trace.CP1, 6, 11, 39, paramString); 
    paramHttpServletResponse.setContentType("text/html");
    PrintWriter printWriter = paramHttpServletResponse.getWriter();
    printWriter.println("<html>");
    printWriter.println("<head>");
    printWriter.println("<title>" + XMLServlet.a + " Info Page</title>");
    printWriter.println("</head>");
    printWriter.println("<body>");
    printWriter.println("<h1>" + XMLServlet.a + "</h1>");
    printWriter.println("Servlet Container: <b>" + XMLServlet.getServerInfo() + "</b><br></br>");
    printWriter.println("supported Servlet API version: <b>" + XMLServlet.getServletAPIVersion() + "</b><p></p>");
    if (this.ae != null) {
      if (this.ae.isEmpty()) {
        if (this.w != null) {
          this.ae.addElement("exx-xml-init");
          this.af.addElement(this.w);
        } 
        if (this.y != null) {
          this.ae.addElement("exx-locationtransparency-config");
          this.af.addElement(this.y);
        } 
        if (this.x != null) {
          this.ae.addElement("exx-locationtransparency-init");
          this.af.addElement(this.x);
        } 
        if (this.q != null) {
          this.ae.addElement("exx-logical-service");
          this.af.addElement(this.q);
        } 
        if (this.p != null) {
          this.ae.addElement("exx-logical-brokerID");
          this.af.addElement(this.p);
        } 
        if (this.r != null) {
          this.ae.addElement("exx-logicalsetname");
          this.af.addElement(this.r);
        } 
        if (this.f != null) {
          this.ae.addElement("exx-brokerID");
          this.af.addElement(this.f);
        } 
        if (this.g != null) {
          this.ae.addElement("exx-service");
          this.af.addElement(this.g);
        } 
        if (this.h != null) {
          this.ae.addElement("exx-userID");
          this.af.addElement(this.h);
        } 
        if (this.i != null) {
          this.ae.addElement("exx-password");
          this.af.addElement(a(this.i));
        } 
        if (this.m != null) {
          this.ae.addElement("exx-use-security");
          this.af.addElement(this.m);
          if (this.o != null) {
            this.ae.addElement("exx-encryption-level");
            this.af.addElement(this.o);
          } 
        } 
        if (this.j != null) {
          this.ae.addElement("exx-rpc-userID");
          this.af.addElement(this.j);
        } 
        if (this.k != null) {
          this.ae.addElement("exx-rpc-password");
          this.af.addElement(a(this.k));
        } 
        if (this.n != null) {
          this.ae.addElement("exx-natural-security");
          this.af.addElement(this.n);
        } 
        if (this.aa != null) {
          this.ae.addElement("exx-use-codepage");
          this.af.addElement(this.aa);
        } 
        if (this.s != null) {
          this.ae.addElement("exx-compresslevel");
          this.af.addElement(this.s);
        } 
        if (this.t != null) {
          this.ae.addElement("exx-compression");
          this.af.addElement(this.t);
        } 
        if (this.u != null) {
          this.ae.addElement("exx-xmm");
          this.af.addElement(this.u);
        } 
      } 
      printWriter.println("<table border=\"1\">");
      printWriter.println("<tr><th bgcolor=\"#d0d0d0\">Header/Parameter</th><th bgcolor=\"#d0d0d0\">Value</th></tr>");
      for (byte b1 = 0; b1 < this.ae.size(); b1++) {
        boolean bool = (b1 % 2 == 1) ? 1 : 0;
        printWriter.print("<tr><td align=\"right\"");
        if (bool)
          printWriter.print(" bgcolor=\"#f0f0f0\""); 
        printWriter.print(">");
        printWriter.print((String)this.ae.elementAt(b1));
        printWriter.print("</td><td");
        if (bool)
          printWriter.print(" bgcolor=\"#f0f0f0\""); 
        printWriter.print(">");
        printWriter.print((String)this.af.elementAt(b1));
        printWriter.println("</td></tr>");
      } 
      printWriter.println("</table><p/>");
      Vector vector = new Vector();
      int i1 = 0;
      ArrayList arrayList = ar.r();
      if (arrayList != null) {
        i1 = arrayList.size();
        for (String str : arrayList)
          vector.addElement(str); 
      } 
      arrayList = ar.s();
      if (arrayList != null)
        for (String str : arrayList)
          vector.addElement(str);  
      if (vector != null) {
        printWriter.println("<table border=\"1\">");
        String str = null;
        for (byte b2 = 0; b2 < i1; b2++) {
          boolean bool = (b2 % 2 == 1) ? 1 : 0;
          str = (String)vector.elementAt(b2);
          ay ay = XMLServlet.getXMLRuntimeRepository().n(str);
          if (b2 == 0) {
            printWriter.print("<tr><th bgcolor=\"#d0d0d0\">");
            printWriter.print("exx-xmm");
            if (ay != null) {
              printWriter.print("</th><th bgcolor=\"#d0d0d0\">");
              printWriter.print("exx-brokerID");
              printWriter.print("</th><th bgcolor=\"#d0d0d0\">");
              printWriter.print("exx-service");
            } 
            printWriter.println("</th></tr>");
          } 
          printWriter.print("<tr><td");
          if (bool)
            printWriter.print(" bgcolor=\"#f0f0f0\""); 
          printWriter.print(">");
          printWriter.print(str);
          if (ay != null) {
            printWriter.print("</td><td");
            if (bool)
              printWriter.print(" bgcolor=\"#f0f0f0\""); 
            printWriter.print(">");
            printWriter.print(ay.b());
            printWriter.print("</td><td");
            if (bool)
              printWriter.print(" bgcolor=\"#f0f0f0\""); 
            printWriter.print(">");
            printWriter.print(ay.c());
          } 
          printWriter.println("</td></tr>");
        } 
        for (int i2 = i1; i2 < vector.size(); i2++) {
          boolean bool = ((i2 - i1) % 2 == 1) ? 1 : 0;
          str = (String)vector.elementAt(i2);
          ay ay = XMLServlet.getXMLRuntimeRepository().n(str);
          if (i2 == i1) {
            printWriter.println("</table><p/>");
            printWriter.println("<table border=\"1\">");
            printWriter.print("<tr><th bgcolor=\"#d0d0d0\">");
            printWriter.print("exx-xml-adapter");
            if (ay != null) {
              printWriter.print("</th><th bgcolor=\"#d0d0d0\">");
              printWriter.print("exx-brokerID");
              printWriter.print("</th><th bgcolor=\"#d0d0d0\">");
              printWriter.print("exx-service");
            } 
            printWriter.println("</th></tr>");
          } 
          printWriter.print("<tr><td");
          if (bool)
            printWriter.print(" bgcolor=\"#f0f0f0\""); 
          printWriter.print(">");
          printWriter.print(str);
          if (ay != null) {
            printWriter.print("</td><td");
            if (bool)
              printWriter.print(" bgcolor=\"#f0f0f0\""); 
            printWriter.print(">");
            printWriter.print(ay.b());
            printWriter.print("</td><td");
            if (bool)
              printWriter.print(" bgcolor=\"#f0f0f0\""); 
            printWriter.print(">");
            printWriter.print(ay.c());
          } 
          printWriter.println("</td></tr>");
        } 
        printWriter.println("</table>");
      } 
    } 
    printWriter.println("<p><h2>" + paramString + "</h2></p>");
    printWriter.println("</body>");
    printWriter.println("</html>");
    printWriter.flush();
    if (XMLServlet.getServletAPIVersion() >= 2.2D)
      paramHttpServletResponse.flushBuffer(); 
  }
  
  private void b(String paramString1, String paramString2) {
    if (this.ae != null) {
      if (paramString1.equals("exx-password") || paramString1.equals("exx-rpc-password"))
        paramString2 = a(paramString2); 
      if (!this.ae.contains(paramString1)) {
        this.ae.addElement(paramString1);
        this.af.addElement(paramString2);
        if (XMLServlet.ap)
          Trace.parameter(Trace.MP4, 6, 11, 3, "add new header/parameter", paramString1 + ":" + paramString2); 
      } else {
        int i1 = this.ae.indexOf(paramString1);
        this.af.setElementAt(paramString2, i1);
        if (XMLServlet.ap)
          Trace.parameter(Trace.MP1, 6, 11, 3, "change header/parameter", paramString1 + ":" + paramString2); 
      } 
    } 
  }
  
  private String a(String paramString) {
    if (paramString == null)
      return "null"; 
    StringBuffer stringBuffer = new StringBuffer();
    while (stringBuffer.length() < paramString.length())
      stringBuffer.append("*"); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\dq.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */