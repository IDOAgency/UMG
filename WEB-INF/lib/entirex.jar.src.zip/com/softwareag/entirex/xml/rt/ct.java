package com.softwareag.entirex.xml.rt;

class ct extends cu {
  public ct(RPCTypeProgram paramRPCTypeProgram) { super(paramRPCTypeProgram); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\ct.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */