package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.ao;
import com.softwareag.entirex.base.a5;
import java.util.Properties;

public class bo {
  private int a = 2;
  
  private int b = 0;
  
  private String c = null;
  
  private boolean d = false;
  
  private String e = null;
  
  private String f = null;
  
  private String g = null;
  
  private String h = null;
  
  private String i = null;
  
  private String j = null;
  
  private String k = null;
  
  private boolean l = false;
  
  private boolean m = false;
  
  private String n = null;
  
  private int o = 0;
  
  private int p = 0;
  
  private String q = null;
  
  private String r = null;
  
  private String s = null;
  
  private String t = null;
  
  private cw u = null;
  
  private boolean v = false;
  
  private int w = 0;
  
  private String x = null;
  
  private int y = 1;
  
  private Properties z = new Properties();
  
  private String aa = null;
  
  private String ab = null;
  
  private String ac = null;
  
  private String ad = null;
  
  private String ae = null;
  
  public String a() { return this.j; }
  
  public String b() { return this.g; }
  
  public void a(boolean paramBoolean) { this.m = paramBoolean; }
  
  public void a(int paramInt) { this.b = paramInt; }
  
  public String c() { return this.x; }
  
  public String d() { return this.i; }
  
  public void a(String paramString) {
    this.r = paramString;
    this.i = a3.b(paramString);
  }
  
  public String e() { return (this.n == null) ? "" : this.n; }
  
  public String f() {
    StringBuffer stringBuffer = new StringBuffer();
    boolean bool = false;
    if (this.ac != null) {
      stringBuffer.append("Faultcode:" + this.ac);
      bool = true;
    } 
    if (this.ab != null) {
      if (bool)
        stringBuffer.append(", "); 
      stringBuffer.append("Faultstring:" + this.ab);
      bool = true;
    } 
    if (this.ad != null) {
      if (bool)
        stringBuffer.append(", "); 
      stringBuffer.append("Details:" + this.ad);
      bool = true;
    } 
    if (this.ae != null) {
      if (bool)
        stringBuffer.append(", "); 
      stringBuffer.append("Faultactor:" + this.ae);
    } 
    return new String(stringBuffer);
  }
  
  public String g() { return this.e; }
  
  public String h() {
    if (ad()) {
      if (this.f == null) {
        this.f = a5.a(c());
        if (this.f == null) {
          String str = System.getProperty("file.encoding");
          if (str != null) {
            this.f = a5.a(str);
            if (this.f == null)
              this.f = str; 
          } 
        } 
      } 
    } else {
      String str = System.getProperty("file.encoding");
      if (str != null) {
        this.f = a5.a(str);
        if (this.f == null)
          this.f = str; 
      } 
    } 
    return this.f;
  }
  
  public void b(String paramString) { this.f = paramString; }
  
  public void a(int paramInt1, int paramInt2, String paramString) {
    this.o = paramInt1;
    this.p = paramInt2;
    this.q = paramString;
    this.l = true;
  }
  
  public void b(boolean paramBoolean) { this.v = paramBoolean; }
  
  public String i() {
    for (String str = "" + this.o; str.length() < 4; str = "0" + str);
    return str;
  }
  
  public String j() { return this.r; }
  
  public String k() {
    for (String str = "" + this.p; str.length() < 4; str = "0" + str);
    return str;
  }
  
  public int l() { return this.b; }
  
  public boolean m() { return this.l; }
  
  public void c(String paramString) { this.x = paramString; }
  
  public String d(String paramString) { return (String)this.z.get(paramString); }
  
  public void e(String paramString) { this.e = paramString; }
  
  public void n() {
    this.i = null;
    this.r = null;
    this.h = null;
    this.k = null;
    this.aa = null;
    this.l = false;
    this.m = false;
    this.n = null;
    this.o = 0;
    this.p = 0;
    this.q = null;
    this.ab = null;
    this.ac = null;
    this.ad = null;
    this.ae = null;
  }
  
  public boolean o() { return this.v; }
  
  public void a(ex paramex) {}
  
  public void f(String paramString) { this.j = paramString; }
  
  public bo() {}
  
  public String p() {
    String str = null;
    if (this.v)
      str = this.x; 
    if (str == null || str.equals(""))
      str = this.j; 
    return str;
  }
  
  public bo(ao paramao) {
    this.w = paramao.e();
    this.a = paramao.y();
    this.k = paramao.r();
    this.r = paramao.s();
    this.h = a3.b(this.k);
    this.i = a3.b(this.r);
    this.t = paramao.t();
  }
  
  public void g(String paramString) { this.g = paramString; }
  
  public bo(ao paramao, ar paramar) {
    this.w = paramao.e();
    this.a = paramao.y();
    this.k = paramao.r();
    this.r = paramao.s();
    this.h = a3.b(this.k);
    this.i = a3.b(this.r);
    this.t = paramao.t();
    this.u = paramar.m(this.h);
  }
  
  public boolean q() { return this.m; }
  
  public void b(int paramInt) { this.w = paramInt; }
  
  public void h(String paramString) { this.n = paramString; }
  
  public int r() { return this.w; }
  
  public int s() { return this.o; }
  
  public int t() { return this.a; }
  
  public int u() { return this.p; }
  
  public void c(int paramInt) { this.a = paramInt; }
  
  public String v() { return (this.q == null) ? "" : this.q; }
  
  public String w() { return this.c; }
  
  public void a(String paramString1, String paramString2) { this.z.setProperty(paramString1, paramString2); }
  
  public void i(String paramString) { this.c = paramString; }
  
  public Properties x() { return this.z; }
  
  public String y() { return this.h; }
  
  public ex z() { return null; }
  
  public void j(String paramString) {
    this.k = paramString;
    this.h = a3.b(paramString);
  }
  
  public void k(String paramString) { this.h = paramString; }
  
  public void l(String paramString) { this.i = paramString; }
  
  public String aa() { return this.k; }
  
  public Properties ab() {
    Properties properties = new Properties();
    if (ac() != null) {
      properties.put("LB", ac());
    } else {
      properties.put("LB", aa());
    } 
    properties.put("PM", j());
    if (this.t != null) {
      properties.put("UID", this.t);
    } else {
      properties.put("UID", "XML-CLIENT");
    } 
    return properties;
  }
  
  public String ac() { return this.s; }
  
  public void m(String paramString) { this.s = paramString; }
  
  public void c(boolean paramBoolean) { this.d = paramBoolean; }
  
  public boolean ad() { return this.d; }
  
  protected void b(String paramString1, String paramString2) {
    if (paramString1.equals("faultstring")) {
      this.ab = paramString2;
    } else if (paramString1.equals("faultcode")) {
      this.ac = paramString2;
    } else if (paramString1.equals("detail")) {
      this.ad = paramString2;
    } else if (paramString1.equals("faultactor")) {
      this.ae = paramString2;
    } else if (!paramString1.equals("user") && paramString1.equals("rpc-user")) {
    
    } 
  }
  
  protected String n(String paramString) {
    String str = null;
    if (paramString.equals("faultstring")) {
      str = this.ab;
    } else if (paramString.equals("faultcode")) {
      str = this.ac;
    } else if (paramString.equals("faultactor")) {
      str = this.ae;
    } else if (paramString.equals("detail")) {
      str = this.ad;
    } else if (paramString.equals("user")) {
      str = this.t;
    } else if (paramString.equals("rpc-user")) {
    
    } 
    return str;
  }
  
  protected void d(int paramInt) { this.y = paramInt; }
  
  protected int ae() { return this.y; }
  
  protected void o(String paramString) {
    if (paramString != null && paramString.length() > 0) {
      byte b1 = 0;
      int i1 = paramString.length();
      if (paramString.charAt(0) == '"')
        b1 = 1; 
      if (paramString.charAt(i1 - 1) == '"')
        i1--; 
      this.aa = paramString.substring(b1, i1);
    } else {
      this.aa = paramString;
    } 
  }
  
  protected String af() { return this.aa; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\bo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */