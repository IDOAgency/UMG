package com.softwareag.entirex.xml.rt;

public interface bk {
  boolean isConversational();
  
  void isConversational(boolean paramBoolean);
  
  boolean isInUse();
  
  void beFree();
  
  void reserve();
  
  void resume();
  
  String getPoolKey();
  
  void setPoolKey(String paramString);
  
  boolean isTimedOut(int paramInt);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\bk.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */