package com.softwareag.entirex.xml.rt;

import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ep {
  private String a = null;
  
  private String b = null;
  
  private eq c = new eq();
  
  protected ep(String paramString1, String paramString2) {
    this.a = paramString2;
    this.b = paramString1;
  }
  
  private void b(Element paramElement) {
    byte b1 = 0;
    if (paramElement.hasAttributes()) {
      NamedNodeMap namedNodeMap = paramElement.getAttributes();
      Node node = namedNodeMap.getNamedItem(this.b);
      if (node != null && node.getNodeType() == 2)
        a(paramElement, node.getNodeValue()); 
    } 
    if (paramElement.hasChildNodes()) {
      NodeList nodeList = paramElement.getChildNodes();
      int i = nodeList.getLength();
      for (b1 = 0; b1 < i; b1++) {
        Node node = nodeList.item(b1);
        if (node.getNodeType() == 1)
          b((Element)node); 
      } 
    } 
  }
  
  private void a(Element paramElement, String paramString) { this.c.a(paramString, paramElement); }
  
  protected void a(Element paramElement) {
    b(paramElement);
    this.c.c();
    c(paramElement);
  }
  
  private void c(Element paramElement) {
    byte b1 = 0;
    if (paramElement.hasAttributes()) {
      NamedNodeMap namedNodeMap = paramElement.getAttributes();
      Node node = namedNodeMap.getNamedItem(this.a);
      if (node != null && node.getNodeType() == 2)
        this.c.a(paramElement, node.getNodeValue()); 
    } 
    if (paramElement.hasChildNodes()) {
      NodeList nodeList = paramElement.getChildNodes();
      for (b1 = 0; b1 < nodeList.getLength(); b1++) {
        Node node = nodeList.item(b1);
        if (node.getNodeType() == 1)
          c((Element)node); 
      } 
    } 
  }
  
  protected void a() { this.c.b(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\ep.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */