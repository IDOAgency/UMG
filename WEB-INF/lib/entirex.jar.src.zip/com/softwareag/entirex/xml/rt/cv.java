package com.softwareag.entirex.xml.rt;

class com/softwareag/entirex/xml/rt/cv implements MapEntries.com/softwareag/entirex/xml/rt/bc {
  private String a;
  
  private String b;
  
  private final StringMapEntries c;
  
  public com/softwareag/entirex/xml/rt/cv(StringMapEntries paramStringMapEntries, String paramString1, String paramString2) {
    this.c = paramStringMapEntries;
    this.a = paramString1;
    this.b = paramString2;
  }
  
  public String a() { return this.a; }
  
  public String b() { return this.b; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\cv.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */