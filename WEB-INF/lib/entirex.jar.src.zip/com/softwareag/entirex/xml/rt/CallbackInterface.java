package com.softwareag.entirex.xml.rt;

import java.io.InputStream;
import java.io.OutputStream;

public interface CallbackInterface {
  InputStream invoke(OutputStream paramOutputStream);
  
  void onError(XMLException paramXMLException);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\CallbackInterface.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */