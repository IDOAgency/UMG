package com.softwareag.entirex.xml.rt;

import java.util.Vector;

public class df {
  int a = 0;
  
  protected static final int b = 0;
  
  protected static final int c = 1;
  
  protected static final int d = 2;
  
  protected static final int e = 3;
  
  Vector f = new Vector();
  
  boolean g = false;
  
  public void a(int paramInt) {
    this.f.addElement(new dg(paramInt));
    this.a++;
  }
  
  public void a(int paramInt1, int paramInt2) {
    this.f.addElement(new dg(paramInt1, paramInt2));
    this.a++;
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3) {
    this.f.addElement(new dg(paramInt1, paramInt2, paramInt3));
    this.a++;
  }
  
  public int a() {
    int i = -1;
    if (this.a > 0) {
      dg dg = (dg)this.f.get(this.a - 1);
      i = dg.a();
      this.f.remove(this.a - 1);
      this.a--;
    } 
    return i;
  }
  
  public int b(int paramInt) {
    int i = -1;
    if (paramInt >= 0 && paramInt <= this.a) {
      dg dg = (dg)this.f.get(paramInt);
      i = dg.a();
    } 
    return i;
  }
  
  public int c(int paramInt) {
    int i = 0;
    if (paramInt >= 0 && paramInt <= this.a) {
      dg dg = (dg)this.f.get(paramInt);
      i = dg.b();
    } 
    return i;
  }
  
  public int d(int paramInt) {
    int i = -1;
    if (paramInt >= 0 && paramInt <= this.a) {
      dg dg = (dg)this.f.get(paramInt);
      i = dg.c();
    } 
    return i;
  }
  
  public int b() {
    int i = -1;
    int j = this.f.size();
    if (j > 0) {
      dg dg = (dg)this.f.get(j - 1);
      i = dg.a();
    } 
    return i;
  }
  
  public void b(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0 && paramInt1 <= this.a) {
      dg dg = (dg)this.f.get(paramInt1);
      dg.a(paramInt2);
    } 
  }
  
  public void e(int paramInt) {
    dg dg = (dg)this.f.get(this.a - 1);
    dg.a(paramInt);
  }
  
  public int c() { return this.f.size(); }
  
  protected void d() {
    if (!this.g) {
      dg dg = (dg)this.f.get(this.a - 1);
      dg.b(1);
      this.g = true;
    } 
  }
  
  protected void e() {
    if (this.a > 0 && this.g == true) {
      dg dg = (dg)this.f.get(this.a - 1);
      int i = dg.b();
      if (i == 1) {
        dg.b(2);
      } else {
        dg.b(3);
      } 
      this.g = false;
    } 
  }
  
  public void f(int paramInt) { c(this.a - 1, paramInt); }
  
  public void c(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0 && paramInt1 <= this.a) {
      dg dg = (dg)this.f.get(paramInt1);
      dg.c(paramInt2);
    } 
  }
  
  public int[] g(int paramInt) {
    byte b1 = 0;
    int[] arrayOfInt = null;
    if (paramInt >= 0 && paramInt <= this.a) {
      boolean bool;
      int[] arrayOfInt1;
      int i;
      dg dg = (dg)this.f.get(paramInt);
      switch (dg.b()) {
        case 1:
          i = paramInt;
          arrayOfInt1 = new int[3];
          b1 = 1;
          arrayOfInt1[0] = dg.c();
          bool = false;
          while (!bool && ++i < this.a) {
            dg dg1 = (dg)this.f.get(i);
            arrayOfInt1[i - paramInt] = dg1.c();
            b1++;
            if (dg1.b() == 2)
              bool = true; 
          } 
          arrayOfInt = new int[b1];
          for (i = 0; i < b1; i++)
            arrayOfInt[i] = arrayOfInt1[i]; 
          break;
        case 2:
          arrayOfInt = new int[1];
          arrayOfInt[0] = dg.c();
          b1 = 1;
          break;
        case 3:
          arrayOfInt = new int[1];
          arrayOfInt[0] = dg.c();
          b1 = 1;
          break;
      } 
    } 
    return arrayOfInt;
  }
  
  public String toString() {
    String str = "";
    str = str + "Size = " + c() + "[]=";
    for (byte b1 = 0; b1 < c(); b1++)
      str = str + b(b1) + ","; 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\df.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */