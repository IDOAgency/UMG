package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class ek implements ej {
  bo a = null;
  
  CallbackInterface b = null;
  
  public void a(bo parambo) { this.a = parambo; }
  
  public void a(CallbackInterface paramCallbackInterface) { this.b = paramCallbackInterface; }
  
  public InputStream a(OutputStream paramOutputStream, Properties paramProperties) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M1, 5, 48, 100); 
    InputStream inputStream = null;
    try {
      if (this.a.q()) {
        XMLException xMLException = null;
        this.b.onError(xMLException);
      } else {
        inputStream = this.b.invoke(paramOutputStream);
      } 
    } catch (Exception exception) {
      throw new XMLException(exception);
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M1, 5, 48, 100); 
    return inputStream;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\ek.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */