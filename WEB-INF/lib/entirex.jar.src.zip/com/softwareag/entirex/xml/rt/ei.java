package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.EntireXVersion;
import com.softwareag.entirex.trace.Trace;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.CharArrayWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;

public class ei implements ej {
  private HttpURLConnection a = null;
  
  private DataOutputStream b = null;
  
  private DataInputStream c = null;
  
  private int d = 0;
  
  private boolean e = false;
  
  private bo f = null;
  
  private final String g = "EntireX/" + EntireXVersion.getVersion();
  
  public void a(bo parambo) { this.f = parambo; }
  
  public InputStream a(OutputStream paramOutputStream, Properties paramProperties) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 34, 100); 
    HttpURLConnection httpURLConnection = null;
    BufferedInputStream bufferedInputStream = null;
    InputStream inputStream = null;
    int i = 0;
    String str1 = null;
    String str2 = null;
    String str3 = null;
    String str4 = "text/xml";
    String str5 = "close";
    String str6 = "text/xml";
    String str7 = "POST";
    if (paramProperties == null) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 34, 100, "Internal error: Transport properties were not set."); 
      throw new XMLException(79, "Internal error: Transport properties were not set.");
    } 
    String str8 = null;
    str8 = (String)paramProperties.get("url");
    if (str8 != null)
      str2 = str8; 
    str8 = (String)paramProperties.get("encoding");
    if (str8 != null)
      str3 = str8; 
    str8 = (String)paramProperties.get("contentType");
    if (str8 != null)
      str4 = str8; 
    if (str2 == null || str2.equals("")) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 34, 100, "Target host was not set."); 
      throw new XMLException(79, "Target host was not set.");
    } 
    if (str3 == null || str3.equals("")) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 34, 100, "Document encoding was not set."); 
      throw new XMLException(79, "Document encoding was not set.");
    } 
    try {
      URL uRL = new URL(str2);
      if (uRL == null) {
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP1, 5, 34, 100, "Illegal host address (" + str2 + ")."); 
        throw new XMLException(79, "Illegal host address (" + str2 + ").");
      } 
      httpURLConnection = (HttpURLConnection)uRL.openConnection();
      if (httpURLConnection == null) {
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP1, 5, 34, 100, "Connection failed."); 
        throw new XMLException(79, "Connection failed.");
      } 
      httpURLConnection.setDoInput(true);
      httpURLConnection.setDoOutput(true);
      httpURLConnection.setAllowUserInteraction(false);
      httpURLConnection.setRequestProperty("Content-type", str4 + "; Charset=" + str3);
      httpURLConnection.setRequestProperty("Connection", str5);
      httpURLConnection.setRequestProperty("Accept", str6);
      httpURLConnection.setUseCaches(false);
      httpURLConnection.setRequestMethod(str7);
      Properties properties = this.f.x();
      if (!properties.isEmpty()) {
        Enumeration enumeration = properties.keys();
        while (enumeration.hasMoreElements()) {
          String str9 = (String)enumeration.nextElement();
          String str10 = (String)properties.get(str9);
          httpURLConnection.setRequestProperty(str9, str10);
        } 
      } 
      OutputStream outputStream = httpURLConnection.getOutputStream();
      if (outputStream == null) {
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP1, 5, 34, 100, "OutputStream is undefined."); 
        throw new XMLException(79, "OutputStream is undefined.");
      } 
      byte[] arrayOfByte = ((ByteArrayOutputStream)paramOutputStream).toByteArray();
      outputStream.write(arrayOfByte);
      outputStream.flush();
      outputStream.close();
      if (XMLRPCService.a) {
        Trace.checkpoint(Trace.CP1, 5, 34, 100, "HTTP-Target:" + str2);
        Trace.checkpoint(Trace.CP1, 5, 34, 100, "Waiting for reply");
      } 
      int j = httpURLConnection.getResponseCode();
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP2, 5, 34, 100, "Response code:" + j); 
      str1 = httpURLConnection.getContentEncoding();
      if (str1 != null && !str1.equals("")) {
        paramProperties.setProperty("encoding", str1);
      } else if (XMLRPCService.a) {
        Trace.checkpoint(Trace.CP3, 5, 34, 100, "Info: Content encoding is not set.");
      } 
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 34, 100, "Response Code" + j); 
      if (j >= 300) {
        inputStream = httpURLConnection.getErrorStream();
        if (inputStream == null)
          new XMLException(52, "Response Code" + j); 
      } else {
        inputStream = httpURLConnection.getInputStream();
        if (inputStream == null)
          new XMLException(54); 
      } 
      bufferedInputStream = new BufferedInputStream(inputStream);
    } catch (MalformedURLException malformedURLException) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 34, 100, malformedURLException.toString()); 
      throw new XMLException(79, malformedURLException.toString());
    } catch (IOException iOException) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 34, 100, iOException.toString()); 
      throw new XMLException(iOException);
    } 
    str4 = httpURLConnection.getContentType();
    if (XMLRPCService.a)
      Trace.checkpoint(Trace.CP1, 5, 34, 100, "Content type:" + str4); 
    if (str4 != null)
      if (str4.indexOf("html") >= 0) {
        this.f.d(0);
      } else {
        this.f.d(1);
      }  
    ByteArrayInputStream byteArrayInputStream = null;
    i = httpURLConnection.getContentLength();
    if (XMLRPCService.a)
      Trace.checkpoint(Trace.CP2, 5, 34, 100, "Received document: Content length\n" + i); 
    try {
      cy cy = new cy();
      cy.a(bufferedInputStream);
      int j = cy.e();
      if (j > 0) {
        bufferedInputStream.read(new byte[j], 0, j);
        i -= j;
      } 
      if (str1 == null || str1.equals("")) {
        str1 = cy.b();
        paramProperties.setProperty("encoding", str1);
      } 
      if (i > 0) {
        byte[] arrayOfByte = new byte[i];
        for (byte b1 = 0; b1 < i; b1++)
          arrayOfByte[b1] = (byte)bufferedInputStream.read(); 
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP2, 5, 34, 100, "Received document:\n" + new String(arrayOfByte)); 
        byteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
      } else {
        InputStreamReader inputStreamReader = new InputStreamReader(bufferedInputStream, str1);
        CharArrayWriter charArrayWriter = new CharArrayWriter();
        while (true) {
          int k = inputStreamReader.read();
          if (k == -1)
            break; 
          charArrayWriter.write(k);
        } 
        if (charArrayWriter.size() == 0) {
          if (XMLRPCService.a)
            Trace.checkpoint(Trace.CP1, 5, 34, 100, "Incoming document is empty."); 
          throw new XMLException(79, "Incoming document is empty.");
        } 
        String str = charArrayWriter.toString().trim();
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP2, 5, 34, 100, "Received document:\n" + str); 
        byteArrayInputStream = new ByteArrayInputStream(str.getBytes(str1));
      } 
    } catch (IOException iOException) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP2, 5, 34, 100, "Error during storing inputstream."); 
      throw new XMLException(79);
    } 
    httpURLConnection.disconnect();
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 34, 100); 
    return byteArrayInputStream;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\ei.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */