package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;
import java.util.Vector;

public class XMLTypeElement extends BaseNodeImpl {
  public static final int VSIZE = -1;
  
  protected at a = new at();
  
  public static final int NVS_NONE = 0;
  
  public static final int NVS_FIELD = 1;
  
  public static final int NVS_ARRAY_ALL = 2;
  
  public static final int NVS_ARRAY_TRIM = 3;
  
  public static final int NVS_ELEMENT_NULLVALUE = 4;
  
  protected static final int b = 0;
  
  protected static final int c = 1;
  
  protected static final int d = 2;
  
  private int e = 1;
  
  private int f = 1;
  
  private String g = null;
  
  private String h = null;
  
  private int i = 0;
  
  private au j = new au();
  
  private av k = null;
  
  private bd l = null;
  
  private int m = 0;
  
  private String n = null;
  
  private String o = null;
  
  private String p = null;
  
  private String q = null;
  
  private String r = null;
  
  private int s = 0;
  
  private int t = 0;
  
  protected static int u = 0;
  
  protected static int v = 1;
  
  protected static int w = 2;
  
  protected static int x = 3;
  
  private int y = 0;
  
  protected void a(int paramInt) { this.y = paramInt; }
  
  protected void b(int paramInt) { this.t = paramInt; }
  
  protected int a() { return this.t; }
  
  public String getInternalDataFormat() { return this.n; }
  
  public int getInternalDataType() { return this.m; }
  
  public void setNullValue(String paramString) { this.o = a3.a(paramString, this.m, this.n); }
  
  public String getNullValue() {
    if (this.o == null)
      this.o = a3.at[this.m]; 
    return this.o;
  }
  
  public void setInternalDataFormat(String paramString) { this.n = paramString; }
  
  public void setInternalDataType(String paramString) { this.m = a3.a(paramString); }
  
  public void setLength(String paramString) { this.p = paramString; }
  
  public String getXMLSchemaType() { return this.q; }
  
  public void setXMLSchemaType(String paramString) { this.q = paramString; }
  
  public void addNameSpaceDefinition(String paramString1, String paramString2) { this.j.a(paramString1, paramString2); }
  
  public int getNumberOfNamespaceDefinitions() { return this.j.c(); }
  
  public au getNamespaceContainer() { return this.j; }
  
  public XMLTypeElement(String paramString) { this(paramString, 1, 1); }
  
  public XMLTypeElement(String paramString, int paramInt1, int paramInt2) { this(null, null, paramString, paramInt1, paramInt2); }
  
  public XMLTypeElement(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2) {
    this.k = new av(paramString2, paramString1, paramString3);
    setName(this.k.c());
    this.e = paramInt1;
    this.f = paramInt2;
    this.g = null;
    if ((paramString1 != null && !paramString1.equals("")) || (paramString2 != null && !paramString2.equals("")))
      this.j.a(paramString1, paramString2); 
    if (this.e == 0) {
      if (paramInt2 == 1) {
        this.i = 1;
      } else {
        this.i = 3;
      } 
    } else if (this.e == this.f) {
      this.i = 0;
    } else {
      this.i = 3;
    } 
  }
  
  public void setDefaultValue(String paramString) { this.g = paramString; }
  
  public String getDefaultValue() { return this.g; }
  
  public void setNullValueSuppression(int paramInt) { this.i = paramInt; }
  
  public int getNullValueSuppression() { return this.i; }
  
  public int getMinOccur() { return this.e; }
  
  public int getMaxOccur() { return this.f; }
  
  public boolean isSized() { return (this.f >= 1 || this.f <= 0); }
  
  public void setContextInfo(String paramString) { this.h = paramString; }
  
  public String getContextInfo() { return this.h; }
  
  public Object clone() {
    XMLTypeElement xMLTypeElement = new XMLTypeElement(this.k.d(), this.k.e(), this.k.a(), getMinOccur(), getMaxOccur());
    xMLTypeElement.m = this.m;
    xMLTypeElement.n = this.n;
    xMLTypeElement.o = this.o;
    xMLTypeElement.p = this.p;
    xMLTypeElement.q = this.q;
    xMLTypeElement.r = this.r;
    xMLTypeElement.s = this.s;
    xMLTypeElement.l = this.l;
    xMLTypeElement.y = this.y;
    xMLTypeElement.j = this.j;
    int i1 = getAttributes().a();
    for (byte b1 = 0; b1 < i1; b1++) {
      a8 a8 = getAttributes().a(b1);
      xMLTypeElement.getAttributes().a((a8)a8.clone());
    } 
    return xMLTypeElement;
  }
  
  public c3 createValueNode() { return new c3(this); }
  
  public at getAttributes() { return this.a; }
  
  public void setAttributes(at paramat) { this.a = paramat; }
  
  public void addAttribute(a8 parama8) { this.a.a(parama8); }
  
  public void addAttribute(String paramString) { this.a.a(paramString, null); }
  
  public void addAttribute(String paramString1, String paramString2, int paramInt) { this.a.a(paramString1, paramString2, paramInt); }
  
  public void addAttribute(String paramString1, String paramString2, String paramString3, String paramString4) { this.a.a(paramString1, paramString2, paramString3, paramString4); }
  
  public void addAttribute(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt) { this.a.a(paramString1, paramString2, paramString3, paramString4, paramInt); }
  
  public void setNamespaceURI(String paramString) {
    int i1 = this.j.c();
    if (i1 == 0) {
      this.j.a(null, paramString);
    } else if (i1 == 1) {
      Vector vector = this.j.b();
      this.j.d();
      this.j.a(((aw)vector.get(0)).a(), paramString);
    } 
  }
  
  public void setNamespacePrefix(String paramString) {
    int i1 = this.j.c();
    if (i1 == 0) {
      this.j.a(paramString, "");
    } else if (i1 == 1) {
      Vector vector = this.j.b();
      this.j.d();
      this.j.a(paramString, ((aw)vector.get(0)).b());
    } 
  }
  
  public void setNamespaceURI(String paramString1, String paramString2) { this.j.a(paramString1, paramString2); }
  
  public String getInternalName() { return getName(); }
  
  public String getUri() { return this.k.e(); }
  
  public String getQName() { return this.k.b(); }
  
  public static XMLTypeElement register(BaseNode paramBaseNode, String paramString) { return register(paramBaseNode, null, null, paramString, 1, 1); }
  
  public static XMLTypeElement register(BaseNode paramBaseNode, String paramString, int paramInt1, int paramInt2) { return register(paramBaseNode, null, null, paramString, paramInt1, paramInt2); }
  
  public static XMLTypeElement register(BaseNode paramBaseNode, String paramString1, String paramString2, String paramString3) { return register(paramBaseNode, paramString1, paramString2, paramString3, 1, 1); }
  
  public static XMLTypeElement register(BaseNode paramBaseNode, String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2) {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M3, 5, 15, 36, "name", paramString3); 
    XMLTypeElement xMLTypeElement = null;
    String str = av.a(paramString2, paramString3);
    if (paramBaseNode != null) {
      BaseNode baseNode = paramBaseNode.getChild(str);
      if (baseNode != null) {
        if (baseNode instanceof XMLTypeElement) {
          if (XMLRPCService.a)
            Trace.leaveMethod(Trace.M3, 5, 15, 36); 
          xMLTypeElement = (XMLTypeElement)baseNode;
        } else if (XMLRPCService.a) {
          Trace.leaveMethod(Trace.M3, 5, 15, 36);
          String str1 = new String("registered " + str + " is no XMLTypeElement!");
          Trace.checkpoint(Trace.CP3, 5, 15, 36, str1);
        } 
      } else {
        if (XMLRPCService.a)
          Trace.leaveMethod(Trace.M3, 5, 15, 36); 
        xMLTypeElement = new XMLTypeElement(paramString1, paramString2, paramString3, paramInt1, paramInt2);
        xMLTypeElement = (XMLTypeElement)paramBaseNode.addChild(xMLTypeElement);
      } 
    } else {
      xMLTypeElement = new XMLTypeElement(paramString1, paramString2, paramString3, paramInt1, paramInt2);
      if (XMLRPCService.a)
        Trace.leaveMethod(Trace.M3, 5, 15, 36); 
    } 
    return xMLTypeElement;
  }
  
  public void setEncoding(String paramString) { this.r = paramString; }
  
  public String getEncoding() { return this.r; }
  
  public void setUseIncomingEncoding(String paramString) {
    if (paramString != null)
      if (paramString.equalsIgnoreCase("true")) {
        this.s = 1;
      } else {
        this.s = 2;
      }  
  }
  
  public int getUseIncomingEncoding() { return this.s; }
  
  public BaseNode addChild(BaseNode paramBaseNode) { return addChild(paramBaseNode, true); }
  
  protected void a(String paramString1, String paramString2, String paramString3, String paramString4) {
    if (this.l == null) {
      this.l = new bd(paramString1, paramString2, paramString3, paramString4);
    } else {
      this.l.a(paramString1, paramString2, paramString3, paramString4);
    } 
  }
  
  protected bd c() { return this.l; }
  
  protected static void a(XMLTypeElement paramXMLTypeElement, int paramInt) {
    System.err.println(paramInt + ": " + paramXMLTypeElement.getInternalName() + " internaltype=" + paramXMLTypeElement.getInternalDataType());
    at at1 = paramXMLTypeElement.getAttributes();
    for (byte b1 = 0; b1 < at1.a(); b1++)
      System.err.println(paramInt + ":(Attribute) = " + at1.a(b1).c() + " internaltype=" + at1.a(b1).n()); 
    if (paramXMLTypeElement.l != null);
    int i1 = paramXMLTypeElement.getChildCount();
    for (byte b2 = 0; b2 < i1; b2++)
      a((XMLTypeElement)paramXMLTypeElement.getChild(b2), paramInt + 1); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\XMLTypeElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */