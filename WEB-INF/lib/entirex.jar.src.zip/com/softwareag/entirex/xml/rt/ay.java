package com.softwareag.entirex.xml.rt;

public class ay {
  private String a = null;
  
  private String b = null;
  
  private String c = null;
  
  private String d = null;
  
  private String e = null;
  
  private String f = null;
  
  private String g = null;
  
  private String h = null;
  
  private String i = null;
  
  private String j = null;
  
  private String k = null;
  
  private String l = null;
  
  private String m = null;
  
  private String n = null;
  
  private String o = null;
  
  private String p = null;
  
  private String q = null;
  
  private String r = null;
  
  protected ay() {
    this.a = null;
    this.b = null;
    this.c = null;
    this.d = null;
    this.e = null;
    this.f = null;
    this.g = null;
    this.h = null;
    this.i = null;
    this.j = null;
    this.k = null;
    this.l = null;
    this.m = null;
    this.n = null;
    this.o = null;
    this.p = null;
    this.q = null;
    this.r = null;
  }
  
  protected ay(ay paramay) {
    this.a = paramay.a;
    this.b = paramay.b;
    this.c = paramay.c;
    this.d = paramay.d;
    this.e = paramay.e;
    this.f = paramay.f;
    this.g = paramay.g;
    this.h = paramay.h;
    this.i = paramay.i;
    this.j = paramay.j;
    this.k = paramay.k;
    this.l = paramay.l;
    this.m = paramay.m;
    this.l = paramay.l;
    this.n = paramay.n;
    this.o = paramay.o;
    this.r = paramay.r;
  }
  
  protected void a() {
    a(a3.i);
    b(a3.j);
    e(a3.l);
    f(a3.m);
    g(a3.n);
    h(a3.o);
    i(a3.p);
    j(a3.q);
    k(a3.k);
    l(null);
    m(null);
    n("60S");
    o("false");
    this.r = null;
  }
  
  public ay a(ay paramay) {
    ay ay1 = new ay(this);
    if (paramay != null) {
      String str = paramay.b();
      if (str != null && str.trim().length() > 0)
        ay1.a(str); 
      str = paramay.c();
      if (str != null && str.trim().length() > 0)
        ay1.b(str); 
      str = paramay.d();
      if (str != null && str.trim().length() > 0)
        ay1.c(str); 
      str = paramay.e();
      if (str != null && str.trim().length() > 0)
        ay1.d(str); 
      str = paramay.f();
      if (str != null && str.trim().length() > 0)
        ay1.e(str); 
      str = paramay.g();
      if (str != null && str.trim().length() > 0)
        ay1.f(str); 
      str = paramay.s();
      if (str != null && str.trim().length() > 0)
        ay1.p(str); 
      str = paramay.h();
      if (str != null && str.trim().length() > 0)
        ay1.g(str); 
      str = paramay.t();
      if (str != null && str.trim().length() > 0)
        ay1.q(str); 
      str = paramay.i();
      if (str != null && str.trim().length() > 0)
        ay1.h(str); 
      str = paramay.j();
      if (str != null && str.trim().length() > 0)
        ay1.i(str); 
      str = paramay.k();
      if (str != null && str.trim().length() > 0)
        ay1.j(str); 
      str = paramay.l();
      if (str != null && str.trim().length() > 0)
        ay1.k(str); 
      str = paramay.m();
      if (str != null && str.trim().length() > 0)
        ay1.l(str); 
      str = paramay.n();
      if (str != null && str.trim().length() > 0)
        ay1.m(str); 
      str = paramay.q();
      if (str != null && str.trim().length() > 0)
        ay1.n(str); 
      str = paramay.r();
      if (str != null && str.trim().length() > 0)
        ay1.o(str); 
    } 
    return ay1;
  }
  
  protected String b() { return this.a; }
  
  protected String c() { return this.b; }
  
  protected String d() { return this.c; }
  
  protected String e() { return this.d; }
  
  protected String f() { return this.e; }
  
  protected String g() { return this.f; }
  
  protected String h() { return this.g; }
  
  protected String i() { return this.h; }
  
  protected String j() {
    String str = "0";
    if (this.i != null)
      str = this.i; 
    return str;
  }
  
  protected String k() { return this.j; }
  
  protected String l() { return this.k; }
  
  protected String m() { return this.l; }
  
  protected String n() {
    String str = "0";
    if (this.m != null)
      str = this.m; 
    return str;
  }
  
  protected String o() { return null; }
  
  protected String p() { return null; }
  
  protected String q() { return this.n; }
  
  protected String r() { return this.o; }
  
  protected String s() { return this.p; }
  
  protected String t() { return this.q; }
  
  protected String u() { return this.r; }
  
  protected void a(String paramString) { this.a = paramString; }
  
  protected void b(String paramString) { this.b = paramString; }
  
  protected void c(String paramString) { this.c = paramString; }
  
  protected void d(String paramString) { this.d = paramString; }
  
  protected void e(String paramString) { this.e = paramString; }
  
  protected void f(String paramString) { this.f = paramString; }
  
  protected void g(String paramString) { this.g = paramString; }
  
  protected void h(String paramString) { this.h = paramString; }
  
  protected void i(String paramString) { this.i = paramString; }
  
  protected void j(String paramString) { this.j = paramString; }
  
  protected void k(String paramString) { this.k = paramString; }
  
  protected void l(String paramString) { this.l = paramString; }
  
  protected void m(String paramString) { this.m = paramString; }
  
  protected void n(String paramString) { this.n = paramString; }
  
  protected void o(String paramString) { this.o = paramString; }
  
  protected void p(String paramString) { this.p = paramString; }
  
  protected void q(String paramString) { this.q = paramString; }
  
  protected void r(String paramString) { this.r = paramString; }
  
  public String toString() {
    StringBuffer stringBuffer1 = new StringBuffer();
    StringBuffer stringBuffer2 = new StringBuffer();
    int i1 = 0;
    if (s() != null)
      i1 = s().length(); 
    if (t() != null && t().length() > i1)
      i1 = t().length(); 
    for (byte b1 = 0; b1 < i1; b1++)
      stringBuffer2.append("*"); 
    stringBuffer1.append("ExxSD[");
    stringBuffer1.append("b=" + b());
    stringBuffer1.append(",s=" + c());
    stringBuffer1.append(",logB=" + d());
    stringBuffer1.append(",logS=" + e());
    stringBuffer1.append(",logN=" + f());
    stringBuffer1.append(",secu=" + i());
    stringBuffer1.append(",el=" + j());
    stringBuffer1.append(",u=" + g());
    if (s() != null)
      stringBuffer1.append(",pw=" + stringBuffer2.toString().substring(0, s().length())); 
    stringBuffer1.append(",c=" + m());
    stringBuffer1.append(",cl=" + n());
    stringBuffer1.append(",nat=" + k());
    stringBuffer1.append(",lib=" + l());
    stringBuffer1.append(",ru=" + h());
    if (t() != null)
      stringBuffer1.append(",rpw=" + stringBuffer2.toString().substring(0, t().length())); 
    stringBuffer1.append(",wt=" + q());
    stringBuffer1.append(",uc=" + this.o);
    stringBuffer1.append("]");
    return stringBuffer1.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\ay.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */