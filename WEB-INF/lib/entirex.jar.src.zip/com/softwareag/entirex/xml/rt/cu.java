package com.softwareag.entirex.xml.rt;

class cu extends cp {
  public cu(RPCTypeStructure paramRPCTypeStructure) {
    this.d = null;
    this.b = paramRPCTypeStructure;
  }
  
  public cu(RPCTypeStructure paramRPCTypeStructure, cq paramcq) {
    this.d = paramcq;
    this.b = paramRPCTypeStructure;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\cu.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */