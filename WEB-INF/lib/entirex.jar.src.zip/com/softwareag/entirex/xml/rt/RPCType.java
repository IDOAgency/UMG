package com.softwareag.entirex.xml.rt;

public class RPCType extends BaseNodeImpl implements as, z, s {
  public static final int VSIZE = -1;
  
  public static final int DIRECT_IN = 1;
  
  public static final int DIRECT_OUT = 2;
  
  public static final int DIRECT_INOUT = 3;
  
  public static final int TYPE_NONE = 0;
  
  public static final int TYPE_BINARY = 1;
  
  public static final int TYPE_BOOLEAN = 2;
  
  public static final int TYPE_DATE = 3;
  
  public static final int TYPE_FLOAT = 4;
  
  public static final int TYPE_INTEGER = 5;
  
  public static final int TYPE_NUMBER = 6;
  
  public static final int TYPE_STRING = 7;
  
  public static final int TYPE_TIME = 8;
  
  public static final int TYPE_LIBRARY = 20;
  
  public static final int TYPE_PROGRAM = 21;
  
  public static final int TYPE_ARRAY = 30;
  
  public static final int TYPE_GROUP = 31;
  
  public static final int TYPE_STRUCTURE = 32;
  
  private static final int a = 1;
  
  private static final int b = 19;
  
  private static final int c = 20;
  
  private static final int d = 29;
  
  private static final int e = 30;
  
  private static final int f = 40;
  
  private int g = 0;
  
  private static int h = 0;
  
  protected int i = 3;
  
  protected int j = 0;
  
  private boolean k = false;
  
  private boolean l = false;
  
  protected boolean m = true;
  
  public int getRpcTypeId() { return this.g; }
  
  public void setRpcTypeId(int paramInt) { this.g = paramInt; }
  
  public RPCType(int paramInt) { this("?" + h++, paramInt); }
  
  public RPCType(int paramInt1, int paramInt2) { this("?" + h++, paramInt1, paramInt2); }
  
  public RPCType(String paramString, int paramInt) { this("?" + h++, paramInt, 3); }
  
  public RPCType(String paramString, int paramInt1, int paramInt2) {
    super(paramString);
    this.g = paramInt1;
    this.i = paramInt2;
  }
  
  public boolean isContainer() {
    boolean bool = false;
    if (30 <= this.g && this.g <= 40)
      bool = true; 
    return bool;
  }
  
  public boolean isScalar() {
    boolean bool = false;
    if (1 <= this.g && this.g <= 19)
      bool = true; 
    return bool;
  }
  
  public void setDirection(int paramInt) {
    this.i = paramInt;
    if (isContainer())
      for (byte b1 = 0; b1 < getChildCount(); b1++) {
        RPCType rPCType = (RPCType)getChild(b1);
        rPCType.setDirection(paramInt);
      }  
  }
  
  public int getDirection() { return this.i; }
  
  public boolean isDirection(int paramInt) { return (this.i == paramInt); }
  
  public void setAlignment(boolean paramBoolean) { this.l = paramBoolean; }
  
  public boolean getAlignment() { return this.l; }
  
  public final boolean isVariableSized() { return this.k; }
  
  public void setSize(int paramInt) { setSize(paramInt, false); }
  
  public void setVarialeSize(int paramInt) { setSize(this.j, true); }
  
  public void setVSize() { setSize(-1, true); }
  
  public void setVSize(int paramInt) { setSize(this.j, true); }
  
  public void setSize(int paramInt, boolean paramBoolean) {
    this.j = paramInt;
    this.k = paramBoolean;
  }
  
  public final int getSize() { return this.j; }
  
  public cp createValueNode() { return new co((RPCTypeScalar)this, null); }
  
  protected boolean a() { return this.m; }
  
  public String toString() { return "RPCType: " + getName() + " (" + (isContainer() ? "Container" : "Scalar") + ", " + this.i + ", " + this.j + ")"; }
  
  public static void printRpcTypeTree(RPCType paramRPCType, int paramInt) {
    System.out.println(paramInt + "." + paramRPCType.getName() + "(" + paramRPCType.getRpcTypeId() + "),dir=" + paramRPCType.getDirection());
    for (byte b1 = 0; b1 < paramRPCType.getChildCount(); b1++) {
      int n = paramInt + 1;
      printRpcTypeTree((RPCType)paramRPCType.getChild(b1), n);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\RPCType.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */