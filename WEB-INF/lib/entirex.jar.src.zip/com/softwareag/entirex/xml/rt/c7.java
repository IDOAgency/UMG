package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.base.a5;
import com.softwareag.entirex.trace.Trace;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.Vector;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public abstract class c7 extends c8 {
  private StringBuffer a = null;
  
  protected c0 b = null;
  
  protected String c = "1.0";
  
  protected String d = null;
  
  protected c7() {}
  
  protected c7(c0 paramc0) { this.b = paramc0; }
  
  protected void a(c0 paramc0) { this.b = paramc0; }
  
  protected void a(String paramString) { this.c = paramString; }
  
  protected String a() { return this.c; }
  
  protected void b(String paramString) { this.d = paramString; }
  
  protected String b() { return this.d; }
  
  public void a(Document paramDocument) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 32, 93); 
    Element element = paramDocument.getDocumentElement();
    if (element != null) {
      a(element);
    } else {
      throw new XMLException(87, "DOM without root element");
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 32, 93); 
  }
  
  public boolean a(Element paramElement) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M3, 5, 27, 103); 
    boolean bool = false;
    boolean bool1 = this.b.a(paramElement);
    if (bool1)
      for (Node node = paramElement.getFirstChild(); node != null; node = node.getNextSibling()) {
        if (node.getNodeType() == 1 && a((Element)node) == true)
          this.b.k(); 
      }  
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M3, 5, 27, 103); 
    return bool1;
  }
  
  private void d() {
    Trace.enterMethod(Trace.M3, 5, 27, 47);
    this.a = new StringBuffer();
    this.a.append("<?xml version=\"" + this.c + "\" encoding=\"" + this.d + "\" ?> ");
    super.b.d();
    b(this.b.c());
    Trace.checkpoint(Trace.CP2, 5, 27, 47, "XML-OutString: ", this.a.toString());
    Trace.leaveMethod(Trace.M3, 5, 27, 47);
  }
  
  private void b(c3 paramc3) {
    byte b1 = 0;
    XMLTypeElement xMLTypeElement = paramc3.d();
    String str = xMLTypeElement.getQName();
    bg.a(paramc3);
    this.a.append("<");
    this.a.append(str);
    c4 c4 = paramc3.k();
    if (c4 != null) {
      int k = c4.a();
      for (b1 = 0; b1 < k; b1++) {
        dd dd = c4.a(b1);
        this.a.append(" ");
        this.a.append(dd.a().h());
        this.a.append("=\"");
        String str1 = dd.b();
        this.a.append(bg.a(dd));
        this.a.append("\"");
      } 
    } 
    au au = xMLTypeElement.getNamespaceContainer();
    super.b.a(au);
    Vector vector = super.b.a();
    int i = vector.size();
    for (b1 = 0; b1 < i; b1++) {
      aw aw = (aw)vector.get(b1);
      this.a.append(" xmlns");
      if (!aw.a().equals("")) {
        this.a.append(":");
        this.a.append(aw.a());
      } 
      this.a.append("=\"");
      this.a.append(aw.b());
      this.a.append("\"");
    } 
    super.b.e();
    int j = paramc3.g();
    if (paramc3.c().equals("") && j == 0) {
      this.a.append("/>");
    } else {
      this.a.append(">");
      this.a.append(bg.a(paramc3));
      if (j > 0) {
        au au1 = (au)super.b.clone();
        for (b1 = 0; b1 < j; b1++) {
          b((c3)paramc3.a(b1));
          super.b = (au)au1.clone();
        } 
      } 
      this.a.append("</");
      this.a.append(str);
      this.a.append(">");
    } 
  }
  
  public void a(OutputStream paramOutputStream) {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 32, 104); 
    this.e = paramOutputStream;
    this.d = this.b.o();
    super.c = a5.a(this.d);
    if (super.c == null)
      super.c = this.d; 
    this.b.a().f(this.d);
    try {
      super.b.d();
      if (XMLRPCService.a) {
        d();
        super.b.d();
      } 
      paramOutputStream.write(("<?xml version=\"" + this.c + "\" encoding=\"").getBytes(super.c));
      paramOutputStream.write(this.d.getBytes(super.c));
      paramOutputStream.write("\" ?> ".getBytes(super.c));
      d(this.b.c());
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      new XMLException(80, unsupportedEncodingException.toString());
    } catch (IOException iOException) {
      new XMLException(80, iOException.toString());
    } finally {
      this.e = null;
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 32, 104); 
  }
  
  public void a(Writer paramWriter) {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 32, 104); 
    this.f = paramWriter;
    this.d = this.b.o();
    this.b.a().f(this.d);
    try {
      super.b.d();
      if (XMLRPCService.a) {
        d();
        super.b.d();
      } 
      paramWriter.write("<?xml version=\"" + this.c + "\" encoding=\"");
      paramWriter.write(this.d);
      paramWriter.write("\" ?> ");
      c(this.b.c());
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      new XMLException(80, unsupportedEncodingException.toString());
    } catch (IOException iOException) {
      new XMLException(80, iOException.toString());
    } finally {
      this.f = null;
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 32, 104); 
  }
  
  private void c(c3 paramc3) {
    if (!paramc3.b()) {
      byte b1 = 0;
      XMLTypeElement xMLTypeElement = paramc3.d();
      String str = xMLTypeElement.getQName();
      this.f.write("<");
      this.f.write(str);
      c4 c4 = paramc3.k();
      if (c4 != null) {
        int k = c4.a();
        for (b1 = 0; b1 < k; b1++) {
          dd dd = c4.a(b1);
          this.f.write(" ");
          this.f.write(dd.a().h());
          this.f.write("=\"");
          this.f.write(bg.a(dd));
          this.f.write("\"");
        } 
      } 
      super.b.a(xMLTypeElement.getNamespaceContainer());
      Vector vector1 = super.b.a();
      int i = vector1.size();
      for (b1 = 0; b1 < i; b1++) {
        aw aw = (aw)vector1.get(b1);
        this.f.write(" xmlns");
        if (!aw.a().equals("")) {
          this.f.write(":");
          this.f.write(aw.a());
        } 
        this.f.write("=\"");
        this.f.write(aw.b());
        this.f.write("\"");
      } 
      super.b.e();
      Vector vector2 = paramc3.h();
      int j = vector2.size();
      if (paramc3.c().equals("") && j == 0) {
        this.f.write("/>");
      } else {
        this.f.write(">");
        a(paramc3);
        this.f.write(bg.a(paramc3));
        if (j > 0) {
          au au = (au)super.b.clone();
          for (b1 = 0; b1 < j; b1++) {
            c((c3)vector2.get(b1));
            super.b = (au)au.clone();
          } 
        } 
        this.f.write("</");
        this.f.write(str);
        this.f.write(">");
      } 
    } 
  }
  
  private void d(c3 paramc3) {
    if (!paramc3.b()) {
      byte b1 = 0;
      XMLTypeElement xMLTypeElement = paramc3.d();
      String str = xMLTypeElement.getQName();
      this.e.write("<".getBytes(super.c));
      this.e.write(str.getBytes(super.c));
      c4 c4 = paramc3.k();
      if (c4 != null) {
        int k = c4.a();
        for (b1 = 0; b1 < k; b1++) {
          dd dd = c4.a(b1);
          this.e.write(" ".getBytes(super.c));
          this.e.write(dd.a().h().getBytes(super.c));
          this.e.write("=\"".getBytes(super.c));
          this.e.write(bg.a(dd, super.d, super.c).getBytes(super.c));
          this.e.write("\"".getBytes(super.c));
        } 
      } 
      super.b.a(xMLTypeElement.getNamespaceContainer());
      Vector vector = super.b.a();
      int i = vector.size();
      for (b1 = 0; b1 < i; b1++) {
        aw aw = (aw)vector.get(b1);
        this.e.write(" xmlns".getBytes(super.c));
        if (!aw.a().equals("")) {
          this.e.write(":".getBytes(super.c));
          this.e.write(aw.a().getBytes(super.c));
        } 
        this.e.write("=\"".getBytes(super.c));
        this.e.write(aw.b().getBytes(super.c));
        this.e.write("\"".getBytes(super.c));
      } 
      super.b.e();
      int j = paramc3.g();
      if (paramc3.c().equals("") && j == 0) {
        this.e.write("/>".getBytes(super.c));
      } else {
        this.e.write(">".getBytes(super.c));
        a(paramc3);
        this.e.write(bg.a(paramc3, super.d, super.c).getBytes(super.c));
        if (j > 0) {
          au au = (au)super.b.clone();
          for (b1 = 0; b1 < j; b1++) {
            d((c3)paramc3.a(b1));
            super.b = (au)au.clone();
          } 
        } 
        this.e.write("</".getBytes(super.c));
        this.e.write(str.getBytes(super.c));
        this.e.write(">".getBytes(super.c));
      } 
    } 
  }
  
  public XMLTypeElement c() {
    XMLTypeElement xMLTypeElement1;
    XMLTypeElement xMLTypeElement2;
    XMLTypeElement xMLTypeElement3 = (xMLTypeElement2 = (xMLTypeElement1 = new XMLTypeElement("XML_FAULT")).register(xMLTypeElement1, "", "", "Fault", 1, 1)).register(xMLTypeElement2, "", "", "faultcode", 1, 1);
    xMLTypeElement3.setContextInfo("faultcode");
    XMLTypeElement xMLTypeElement4 = XMLTypeElement.register(xMLTypeElement2, "", "", "faultstring", 1, 1);
    xMLTypeElement4.setContextInfo("faultstring");
    XMLTypeElement xMLTypeElement5 = XMLTypeElement.register(xMLTypeElement2, "", "", "faultactor", 1, 1);
    xMLTypeElement5.setContextInfo("faultactor");
    XMLTypeElement xMLTypeElement6 = XMLTypeElement.register(xMLTypeElement2, "", "", "detail", 0, 1);
    xMLTypeElement6.setNullValueSuppression(1);
    return xMLTypeElement1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\c7.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */