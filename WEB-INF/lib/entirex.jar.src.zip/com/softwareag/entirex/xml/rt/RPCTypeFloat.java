package com.softwareag.entirex.xml.rt;

public class RPCTypeFloat extends RPCTypeScalar {
  private static final int a = 4;
  
  public RPCTypeFloat() { this(4, 3, 4); }
  
  public RPCTypeFloat(String paramString) { this(paramString, 4, 3, 4); }
  
  public RPCTypeFloat(int paramInt) { this(4, 3, paramInt); }
  
  public RPCTypeFloat(String paramString, int paramInt) { this(paramString, 4, 3, paramInt); }
  
  public RPCTypeFloat(String paramString, int paramInt1, int paramInt2) { this(paramString, 4, paramInt2, paramInt1); }
  
  public RPCTypeFloat(int paramInt1, int paramInt2) { this(4, paramInt2, paramInt1); }
  
  public RPCTypeFloat(int paramInt1, int paramInt2, int paramInt3) {
    super(paramInt1, paramInt2);
    this.j = paramInt3;
  }
  
  public RPCTypeFloat(String paramString, int paramInt1, int paramInt2, int paramInt3) {
    super(paramString, paramInt1, paramInt2);
    this.j = paramInt3;
  }
  
  public void setDefaultValue(double paramDouble) { setDefaultValue(toString(paramDouble)); }
  
  public static final String toString(double paramDouble) { return "" + paramDouble; }
  
  public final double fromString(String paramString) {
    double d = 0.0D;
    try {
      d = Double.valueOf(paramString).doubleValue();
    } catch (NumberFormatException numberFormatException) {
      if (super.a != null)
        d = Double.valueOf(super.a).doubleValue(); 
    } 
    return d;
  }
  
  public cp createValueNode() { return new co(this, super.a); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\RPCTypeFloat.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */