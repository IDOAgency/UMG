package com.softwareag.entirex.xml.rt;

public abstract class dl {
  protected ar a = null;
  
  protected bo b = null;
  
  protected boolean c = a3.a;
  
  protected byte[] d = null;
  
  public dl(ar paramar, bo parambo) {
    this.a = paramar;
    this.b = parambo;
  }
  
  public ar h() { return this.a; }
  
  public bo i() { return this.b; }
  
  public byte[] b() { return this.d; }
  
  public void b(byte[] paramArrayOfByte) { this.d = paramArrayOfByte; }
  
  public void a(boolean paramBoolean) { this.c = paramBoolean; }
  
  public abstract byte[] b(RPCType paramRPCType, cp paramcp) throws XMLException;
  
  public abstract void a(RPCType paramRPCType, cp paramcp) throws XMLException;
  
  protected abstract void a(cp paramcp) throws XMLException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\dl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */