package com.softwareag.entirex.xml.rt;

public class RPCTypeArray extends a2 {
  public RPCTypeArray() { this(30, 3, 0, false); }
  
  public RPCTypeArray(String paramString) { this(paramString, 30, 3, 0, false); }
  
  public RPCTypeArray(int paramInt) { this(30, 3, paramInt, false); }
  
  public RPCTypeArray(int paramInt, boolean paramBoolean) { this(30, 3, paramInt, paramBoolean); }
  
  public RPCTypeArray(String paramString, int paramInt) { this(paramString, 30, 3, paramInt, false); }
  
  public RPCTypeArray(String paramString, int paramInt, boolean paramBoolean) { this(paramString, 30, 3, paramInt, paramBoolean); }
  
  public RPCTypeArray(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    super(paramInt1, paramInt2);
    if (paramBoolean) {
      setVSize(paramInt3);
    } else {
      setSize(paramInt3);
    } 
  }
  
  public RPCTypeArray(String paramString, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    super(paramString, paramInt1, paramInt2);
    if (paramBoolean) {
      setVSize(paramInt3);
    } else {
      setSize(paramInt3);
    } 
  }
  
  public cp createValueNode() { return new cr(this); }
  
  public RPCType getElementType() { return (RPCType)getChild(0); }
  
  public String toString() { return "RPCTypeArray: " + getName() + " fixed size: " + this.j; }
  
  public static RPCTypeArray create(String paramString, int paramInt, RPCType paramRPCType) {
    RPCTypeArray rPCTypeArray = new RPCTypeArray(paramString, paramInt);
    rPCTypeArray.setDirection(paramRPCType.getDirection());
    rPCTypeArray.addChild(paramRPCType);
    return rPCTypeArray;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt, s params) {
    RPCTypeArray rPCTypeArray = new RPCTypeArray(paramString, paramInt);
    rPCTypeArray.setDirection(params.getDirection());
    rPCTypeArray.addChild(params);
    return rPCTypeArray;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt, z paramz) {
    RPCTypeArray rPCTypeArray = new RPCTypeArray(paramString, paramInt);
    rPCTypeArray.setDirection(paramz.getDirection());
    rPCTypeArray.addChild(paramz);
    return rPCTypeArray;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt, boolean paramBoolean, s params) {
    RPCTypeArray rPCTypeArray = new RPCTypeArray(paramString, paramInt, paramBoolean);
    rPCTypeArray.setDirection(params.getDirection());
    rPCTypeArray.addChild(params);
    return rPCTypeArray;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt, boolean paramBoolean, z paramz) {
    RPCTypeArray rPCTypeArray = new RPCTypeArray(paramString, paramInt, paramBoolean);
    rPCTypeArray.setDirection(paramz.getDirection());
    rPCTypeArray.addChild(paramz);
    return rPCTypeArray;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt, boolean paramBoolean, RPCType paramRPCType) {
    RPCTypeArray rPCTypeArray = new RPCTypeArray(paramString, paramInt, paramBoolean);
    rPCTypeArray.setDirection(paramRPCType.getDirection());
    rPCTypeArray.addChild(paramRPCType);
    return rPCTypeArray;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt1, int paramInt2, RPCType paramRPCType) {
    RPCTypeArray rPCTypeArray1 = new RPCTypeArray(paramString, paramInt1);
    rPCTypeArray1.setDirection(paramRPCType.getDirection());
    RPCTypeArray rPCTypeArray2 = new RPCTypeArray(paramInt2);
    rPCTypeArray2.setDirection(paramRPCType.getDirection());
    RPCType rPCType = (RPCType)rPCTypeArray1.addChild(rPCTypeArray2);
    rPCType.addChild(paramRPCType);
    return rPCTypeArray1;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt1, int paramInt2, s params) {
    RPCTypeArray rPCTypeArray1 = new RPCTypeArray(paramString, paramInt1);
    rPCTypeArray1.setDirection(params.getDirection());
    RPCTypeArray rPCTypeArray2 = new RPCTypeArray(paramInt2);
    rPCTypeArray2.setDirection(params.getDirection());
    RPCType rPCType = (RPCType)rPCTypeArray1.addChild(rPCTypeArray2);
    rPCType.addChild(params);
    return rPCTypeArray1;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt1, int paramInt2, z paramz) {
    RPCTypeArray rPCTypeArray1 = new RPCTypeArray(paramString, paramInt1);
    rPCTypeArray1.setDirection(paramz.getDirection());
    RPCTypeArray rPCTypeArray2 = new RPCTypeArray(paramInt2);
    rPCTypeArray2.setDirection(paramz.getDirection());
    RPCType rPCType = (RPCType)rPCTypeArray1.addChild(rPCTypeArray2);
    rPCType.addChild(paramz);
    return rPCTypeArray1;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2, RPCType paramRPCType) {
    RPCTypeArray rPCTypeArray1 = new RPCTypeArray(paramString, paramInt1, paramBoolean1);
    rPCTypeArray1.setDirection(paramRPCType.getDirection());
    RPCTypeArray rPCTypeArray2 = new RPCTypeArray(paramInt2, paramBoolean2);
    rPCTypeArray2.setDirection(paramRPCType.getDirection());
    RPCType rPCType = (RPCType)rPCTypeArray1.addChild(rPCTypeArray2);
    rPCType.setDirection(paramRPCType.getDirection());
    rPCType.addChild(paramRPCType);
    return rPCTypeArray1;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2, s params) {
    RPCTypeArray rPCTypeArray1 = new RPCTypeArray(paramString, paramInt1, paramBoolean1);
    rPCTypeArray1.setDirection(params.getDirection());
    RPCTypeArray rPCTypeArray2 = new RPCTypeArray(paramInt2, paramBoolean2);
    rPCTypeArray2.setDirection(params.getDirection());
    RPCType rPCType = (RPCType)rPCTypeArray1.addChild(rPCTypeArray2);
    rPCType.setDirection(params.getDirection());
    rPCType.addChild(params);
    return rPCTypeArray1;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2, z paramz) {
    RPCTypeArray rPCTypeArray1 = new RPCTypeArray(paramString, paramInt1, paramBoolean1);
    rPCTypeArray1.setDirection(paramz.getDirection());
    RPCTypeArray rPCTypeArray2 = new RPCTypeArray(paramInt2, paramBoolean2);
    rPCTypeArray2.setDirection(paramz.getDirection());
    RPCType rPCType = (RPCType)rPCTypeArray1.addChild(rPCTypeArray2);
    rPCType.setDirection(paramz.getDirection());
    rPCType.addChild(paramz);
    return rPCTypeArray1;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt1, int paramInt2, int paramInt3, RPCType paramRPCType) {
    RPCTypeArray rPCTypeArray1 = new RPCTypeArray(paramString, paramInt1);
    rPCTypeArray1.setDirection(paramRPCType.getDirection());
    RPCTypeArray rPCTypeArray2 = new RPCTypeArray(paramInt2);
    rPCTypeArray2.setDirection(paramRPCType.getDirection());
    RPCTypeArray rPCTypeArray3 = new RPCTypeArray(paramInt3);
    rPCTypeArray3.setDirection(paramRPCType.getDirection());
    RPCType rPCType = (RPCType)rPCTypeArray1.addChild(rPCTypeArray2);
    rPCType = (RPCType)rPCType.addChild(rPCTypeArray3);
    rPCType.addChild(paramRPCType);
    return rPCTypeArray1;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt1, int paramInt2, int paramInt3, s params) {
    RPCTypeArray rPCTypeArray1 = new RPCTypeArray(paramString, paramInt1);
    rPCTypeArray1.setDirection(params.getDirection());
    RPCTypeArray rPCTypeArray2 = new RPCTypeArray(paramInt2);
    rPCTypeArray2.setDirection(params.getDirection());
    RPCTypeArray rPCTypeArray3 = new RPCTypeArray(paramInt3);
    rPCTypeArray3.setDirection(params.getDirection());
    RPCType rPCType = (RPCType)rPCTypeArray1.addChild(rPCTypeArray2);
    rPCType = (RPCType)rPCType.addChild(rPCTypeArray3);
    rPCType.addChild(params);
    return rPCTypeArray1;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt1, int paramInt2, int paramInt3, z paramz) {
    RPCTypeArray rPCTypeArray1 = new RPCTypeArray(paramString, paramInt1);
    rPCTypeArray1.setDirection(paramz.getDirection());
    RPCTypeArray rPCTypeArray2 = new RPCTypeArray(paramInt2);
    rPCTypeArray2.setDirection(paramz.getDirection());
    RPCTypeArray rPCTypeArray3 = new RPCTypeArray(paramInt3);
    rPCTypeArray3.setDirection(paramz.getDirection());
    RPCType rPCType = (RPCType)rPCTypeArray1.addChild(rPCTypeArray2);
    rPCType = (RPCType)rPCType.addChild(rPCTypeArray3);
    rPCType.addChild(paramz);
    return rPCTypeArray1;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2, int paramInt3, boolean paramBoolean3, RPCType paramRPCType) {
    RPCTypeArray rPCTypeArray1 = new RPCTypeArray(paramString, paramInt1, paramBoolean1);
    rPCTypeArray1.setDirection(paramRPCType.getDirection());
    RPCTypeArray rPCTypeArray2 = new RPCTypeArray(paramInt2, paramBoolean2);
    rPCTypeArray2.setDirection(paramRPCType.getDirection());
    RPCTypeArray rPCTypeArray3 = new RPCTypeArray(paramInt3, paramBoolean3);
    rPCTypeArray3.setDirection(paramRPCType.getDirection());
    RPCType rPCType = (RPCType)rPCTypeArray1.addChild(rPCTypeArray2);
    rPCType = (RPCType)rPCType.addChild(rPCTypeArray3);
    rPCType.addChild(paramRPCType);
    return rPCTypeArray1;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2, int paramInt3, boolean paramBoolean3, s params) {
    RPCTypeArray rPCTypeArray1 = new RPCTypeArray(paramString, paramInt1, paramBoolean1);
    rPCTypeArray1.setDirection(params.getDirection());
    RPCTypeArray rPCTypeArray2 = new RPCTypeArray(paramInt2, paramBoolean2);
    rPCTypeArray2.setDirection(params.getDirection());
    RPCTypeArray rPCTypeArray3 = new RPCTypeArray(paramInt3, paramBoolean3);
    rPCTypeArray3.setDirection(params.getDirection());
    RPCType rPCType = (RPCType)rPCTypeArray1.addChild(rPCTypeArray2);
    rPCType = (RPCType)rPCType.addChild(rPCTypeArray3);
    rPCType.addChild(params);
    return rPCTypeArray1;
  }
  
  public static RPCTypeArray create(String paramString, int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2, int paramInt3, boolean paramBoolean3, z paramz) {
    RPCTypeArray rPCTypeArray1 = new RPCTypeArray(paramString, paramInt1, paramBoolean1);
    rPCTypeArray1.setDirection(paramz.getDirection());
    RPCTypeArray rPCTypeArray2 = new RPCTypeArray(paramInt2, paramBoolean2);
    rPCTypeArray2.setDirection(paramz.getDirection());
    RPCTypeArray rPCTypeArray3 = new RPCTypeArray(paramInt3, paramBoolean3);
    rPCTypeArray3.setDirection(paramz.getDirection());
    RPCType rPCType = (RPCType)rPCTypeArray1.addChild(rPCTypeArray2);
    rPCType = (RPCType)rPCType.addChild(rPCTypeArray3);
    rPCType.addChild(paramz);
    return rPCTypeArray1;
  }
  
  public void setDirection(int paramInt) {
    this.i = paramInt;
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      RPCType rPCType = (RPCType)getChild(b);
      rPCType.setDirection(paramInt);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\RPCTypeArray.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */