package com.softwareag.entirex.xml.rt;

public abstract class a2 extends RPCType {
  public a2() { this(31, 3); }
  
  public a2(String paramString) { this(paramString, 31, 3); }
  
  public a2(String paramString, int paramInt) { this(paramString, 31, paramInt); }
  
  public a2(int paramInt1, int paramInt2) { super(paramInt1, paramInt2); }
  
  public a2(String paramString, int paramInt1, int paramInt2) { super(paramString, paramInt1, paramInt2); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\a2.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */