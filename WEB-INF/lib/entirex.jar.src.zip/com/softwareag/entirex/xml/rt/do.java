package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.ao;
import com.softwareag.entirex.aci.bn;
import com.softwareag.entirex.trace.Trace;
import java.math.BigDecimal;

public class do extends dj {
  private static final int a = 1140;
  
  private int b = 0;
  
  public do(ar paramar, bo parambo) {
    super(paramar, parambo);
    b(1140);
    RPCType rPCType = super.a.g();
    rPCType = (RPCType)rPCType.getChild(super.b.y());
    rPCType = (RPCType)rPCType.getChild(super.b.d());
    byte[] arrayOfByte = ((RPCTypeProgram)rPCType).getFormatBuffer();
    bn bn = new bn();
    bn.a(arrayOfByte, null);
    bn.a(1140, (super.b.t() != 0), true);
    this.c = bn.b();
    this.e = ((RPCTypeProgram)rPCType).c();
    if (this.e == 0) {
      this.e = ((RPCTypeProgram)rPCType).getOutLength() + ((RPCTypeProgram)rPCType).getInOutLength();
      if (super.b.t() == 0)
        this.e += ((RPCTypeProgram)rPCType).getInLength(); 
      this.e += this.c.length;
      this.e += 692;
    } 
    this.d = bn.f();
  }
  
  public do(ar paramar, bo parambo, ao paramao) {
    super(paramar, parambo, paramao);
    b(1140);
  }
  
  protected void a(int paramInt) {
    if (this.e < paramInt) {
      RPCType rPCType = super.a.g();
      rPCType = (RPCType)rPCType.getChild(super.b.y());
      rPCType = (RPCType)rPCType.getChild(super.b.d());
      this.e = paramInt;
      ((RPCTypeProgram)rPCType).a(paramInt);
    } 
  }
  
  public void a(RPCType paramRPCType, cp paramcp, df paramdf, int paramInt) throws XMLException {
    super.a = (super.b.t() == 0);
    if (this.c == a3.a) {
      super.b = 1;
    } else {
      super.b = 2;
    } 
    a(paramRPCType, paramcp, 0);
  }
  
  public void a(RPCType paramRPCType, cp paramcp, int paramInt) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 41, 102); 
    RPCType rPCType = null;
    cp cp1 = paramcp;
    byte b1 = 0;
    boolean bool = false;
    int i = paramRPCType.getChildCount();
    Object object = null;
    for (b1 = 0; b1 < i; b1++) {
      rPCType = (RPCType)paramRPCType.getChild(b1);
      int j = rPCType.getRpcTypeId();
      int k = 1;
      if (paramRPCType.getRpcTypeId() == 30)
        k = paramRPCType.getSize(); 
      cp1 = (cp)paramcp.a(rPCType.getName(), 0);
      if (super.a || rPCType.getDirection() != super.b) {
        boolean bool1 = false;
        do {
          bool1 = false;
          try {
            String str2;
            String str1;
            switch (j) {
              case 1:
                k = rPCType.getSize();
                if (rPCType.isVariableSized()) {
                  if (k == -1) {
                    this.f.addDataBV(RPCTypeBinary.fromString(cp1.b()));
                    break;
                  } 
                  this.f.addDataBV(RPCTypeBinary.fromString(cp1.b()), k);
                  break;
                } 
                this.f.addDataB(RPCTypeBinary.fromString(cp1.b()), k);
                break;
              case 2:
                str1 = cp1.b();
                if (str1 != null) {
                  this.f.addDataA(str1.equals(a3.h) ? " " : "X", 1);
                  break;
                } 
                this.f.addDataA(" ", 1);
                break;
              case 3:
                this.f.addDataD(cp1.b(), 8);
                break;
              case 4:
                if (rPCType.getSize() == 4) {
                  this.f.addDataF(cp1.b(), 6);
                  break;
                } 
                this.f.addDataF(cp1.b(), 15);
                break;
              case 5:
                switch (rPCType.getSize()) {
                  case 1:
                    this.f.addDataI(cp1.b(), 4);
                    break;
                  case 2:
                    this.f.addDataI(cp1.b(), 6);
                    break;
                  case 4:
                    this.f.addDataI(cp1.b(), 11);
                    break;
                } 
                throw new XMLException(84);
              case 6:
                str2 = cp1.b();
                this.f.addDataN((str2 == null || str2.trim().equals("")) ? null : new BigDecimal(str2), ((RPCTypeNumber)rPCType).getDigitsBeforeDecimalPoint(), ((RPCTypeNumber)rPCType).getDigitsAfterDecimalPoint());
                break;
              case 7:
                k = rPCType.getSize();
                if (rPCType.isVariableSized()) {
                  if (k == -1) {
                    this.f.addDataAV(cp1.b());
                    break;
                  } 
                  this.f.addDataAV(cp1.b(), k);
                  break;
                } 
                this.f.addDataA(cp1.b(), k);
                break;
              case 8:
                this.f.addDataD(cp1.b(), 15);
                break;
              case 30:
                bool1 = true;
                b(rPCType, cp1);
                break;
              case 31:
              case 32:
                bool1 = true;
                b(rPCType, cp1);
                break;
              default:
                throw new XMLException(84);
            } 
          } catch (BrokerException brokerException) {
            throw new XMLException(brokerException);
          } 
          cp1 = (cp)cp1.i();
        } while (cp1 != null && bool1 != true);
      } 
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 41, 102); 
  }
  
  public void b(RPCType paramRPCType, cp paramcp, df paramdf, int paramInt) throws XMLException {
    super.a = (super.b.t() == 0);
    if (this.c == a3.a) {
      super.b = 2;
    } else {
      super.b = 1;
    } 
    b(paramRPCType, paramcp, 0);
  }
  
  public void b(RPCType paramRPCType, cp paramcp, int paramInt) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 41, 101); 
    RPCType rPCType = null;
    cp cp1 = paramcp;
    byte b1 = 0;
    byte b2 = 0;
    int i = paramRPCType.getChildCount();
    Object object = null;
    for (b1 = 0; b1 < i; b1++) {
      rPCType = (RPCType)paramRPCType.getChild(b1);
      int j = rPCType.getRpcTypeId();
      int k = 1;
      if (paramRPCType.getRpcTypeId() == 30)
        k = paramRPCType.getSize(); 
      cq cq = null;
      if (super.a || rPCType.getDirection() != super.b) {
        cp1 = paramcp;
        do {
          for (b2 = 0; b2 < k; b2++) {
            cp cp2 = null;
            try {
              switch (j) {
                case 1:
                  cp2 = ((RPCTypeBinary)rPCType).createValueNode();
                  if (rPCType.isVariableSized()) {
                    cp2.a(RPCTypeBinary.toString(this.f.getDataBV()));
                    break;
                  } 
                  cp2.a(RPCTypeBinary.toString(this.f.getDataB(rPCType.getSize())));
                  break;
                case 2:
                  cp2 = ((RPCTypeBoolean)rPCType).createValueNode();
                  cp2.a(this.f.getDataL() ? a3.g : a3.h);
                  break;
                case 3:
                  cp2 = ((RPCTypeDateTime)rPCType).createValueNode();
                  cp2.a(this.f.getDataDString(8));
                  break;
                case 4:
                  cp2 = ((RPCTypeFloat)rPCType).createValueNode();
                  if (rPCType.getSize() == 4) {
                    cp2.a(this.f.getDataF4String());
                    break;
                  } 
                  cp2.a(this.f.getDataF8String());
                  break;
                case 5:
                  cp2 = ((RPCTypeInt)rPCType).createValueNode();
                  switch (rPCType.getSize()) {
                    case 1:
                      cp2.a(this.f.getDataI1String());
                      break;
                    case 2:
                      cp2.a(this.f.getDataI2String());
                      break;
                    case 4:
                      cp2.a(this.f.getDataI4String());
                      break;
                  } 
                  throw new XMLException(84);
                case 6:
                  cp2 = ((RPCTypeNumber)rPCType).createValueNode();
                  cp2.a(this.f.getDataNString(((RPCTypeNumber)rPCType).getDigitsBeforeDecimalPoint(), ((RPCTypeNumber)rPCType).getDigitsAfterDecimalPoint()));
                  break;
                case 7:
                  cp2 = ((RPCTypeString)rPCType).createValueNode();
                  if (rPCType.isVariableSized()) {
                    cp2.a(this.f.getDataAV());
                    break;
                  } 
                  if (((RPCTypeString)rPCType).a()) {
                    cp2.a(this.f.getDataA(rPCType.getSize()).trim());
                    break;
                  } 
                  cp2.a(this.f.getDataA(rPCType.getSize()));
                  break;
                case 8:
                  cp2 = ((RPCTypeDateTime)rPCType).createValueNode();
                  cp2.a(this.f.getDataDString(15));
                  break;
                case 30:
                  cp2 = ((RPCTypeArray)rPCType).createValueNode();
                  break;
                case 31:
                case 32:
                  cp2 = ((RPCTypeStructure)rPCType).createValueNode();
                  break;
                default:
                  throw new XMLException(84);
              } 
            } catch (BrokerException brokerException) {
              throw new XMLException(brokerException);
            } 
            if (cq != null) {
              cq.c(cp2);
              cp2.d(cq);
            } 
            cp1.b(cp2);
            cq = cp2;
          } 
          cp1 = (cp)cp1.i();
        } while (cp1 != null);
        if (rPCType.isContainer()) {
          cp cp2 = null;
          String str = rPCType.getName();
          if (str.charAt(0) == '?') {
            cp2 = (cp)paramcp.a(0);
          } else {
            cp2 = (cp)paramcp.a(str, 0);
          } 
          a(rPCType, cp2);
        } 
      } 
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 41, 101); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\do.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */