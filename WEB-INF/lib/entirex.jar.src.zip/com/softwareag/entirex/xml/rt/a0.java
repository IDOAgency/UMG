package com.softwareag.entirex.xml.rt;

public abstract class a0 {
  public abstract XMLTypeElement a() throws XMLException;
  
  public abstract String[][] b();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\a0.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */