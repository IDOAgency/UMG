package com.softwareag.entirex.xml.rt;

public class cp extends cq {
  protected String a = null;
  
  public cp() {}
  
  public cp(RPCType paramRPCType) { this.b = paramRPCType; }
  
  public String a() {
    String str = null;
    if (this.b != null)
      str = this.b.getName(); 
    return str;
  }
  
  public void a(String paramString) {
    if (((RPCType)this.b).a()) {
      this.a = paramString.trim();
    } else {
      this.a = paramString;
    } 
  }
  
  public void b(String paramString) { this.a = paramString; }
  
  public String b() { return this.a; }
  
  public void c() { this.a = ""; }
  
  public RPCType d() { return (RPCType)this.b; }
  
  public static void a(cp paramcp, int paramInt) {
    System.out.print(paramInt + "." + paramcp.d().getName() + "(" + paramcp.d().getRpcTypeId() + ") = " + paramcp.b());
    cp cp1 = (cp)paramcp.i();
    if (cp1 == null) {
      System.out.print(" //-");
    } else {
      System.out.print(" //++" + ((cp)paramcp.i()).a() + "=" + ((cp)paramcp.i()).b());
    } 
    if (paramcp.j() == null) {
      System.out.print(" //-");
    } else {
      System.out.print(" //**" + ((cp)paramcp.j()).a() + "=" + ((cp)paramcp.j()).b());
    } 
    System.out.println();
    int i = paramcp.g();
    for (byte b = 0; b < i; b++) {
      int j = paramInt + 1;
      a((cp)paramcp.a(b), j);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\cp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */