package com.softwareag.entirex.xml.rt;

public class RPCTypeStructure extends a2 {
  public RPCTypeStructure() { this(32, 3); }
  
  public RPCTypeStructure(String paramString) { this(paramString, 32, 3); }
  
  public RPCTypeStructure(String paramString, int paramInt) { this(paramString, 32, paramInt); }
  
  public RPCTypeStructure(int paramInt1, int paramInt2) { super(paramInt1, paramInt2); }
  
  public RPCTypeStructure(String paramString, int paramInt1, int paramInt2) { super(paramString, paramInt1, paramInt2); }
  
  public cp createValueNode() { return new cu(this); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\RPCTypeStructure.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */