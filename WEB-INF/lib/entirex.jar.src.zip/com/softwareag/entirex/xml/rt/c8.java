package com.softwareag.entirex.xml.rt;

import java.io.OutputStream;
import java.io.Writer;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public abstract class c8 {
  protected c0 a = null;
  
  protected au b = new au();
  
  protected String c = null;
  
  protected boolean d = ar.a.getProperty("entirex.sdk.xml.runtime.useCharacterReference").equals("yes");
  
  protected OutputStream e = null;
  
  protected Writer f = null;
  
  protected void a(c0 paramc0) { this.a = paramc0; }
  
  protected void a(c3 paramc3, NamedNodeMap paramNamedNodeMap) {
    c3 c31 = (c3)paramc3.e();
    if (c31 != null)
      paramc3.b(c31.l()); 
    if (paramNamedNodeMap != null) {
      Node node = paramNamedNodeMap.getNamedItem("xml:space");
      if (node == null)
        node = paramNamedNodeMap.getNamedItemNS("http://www.w3.org/XML/1998/namespace", "space"); 
      if (node != null && node.getNodeType() == 2) {
        String str = node.getNodeValue();
        if (str.equals("preserve")) {
          paramc3.b(2);
        } else {
          paramc3.b(0);
        } 
      } 
    } 
  }
  
  protected void a(c3 paramc3) {
    c4 c4 = paramc3.k();
    c3 c31 = (c3)paramc3.e();
    if (c31 != null)
      paramc3.b(c31.l()); 
    String str = c4.a("'http://www.w3.org/XML/1998/namespace'space");
    if (str != null)
      if (str.equals("preserve")) {
        paramc3.b(2);
      } else {
        paramc3.b(0);
      }  
  }
  
  public abstract XMLTypeElement c();
  
  protected abstract void a(Document paramDocument) throws XMLException;
  
  protected abstract void a(Writer paramWriter) throws XMLException;
  
  protected abstract void a(OutputStream paramOutputStream) throws XMLException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\c8.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */