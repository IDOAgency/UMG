package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.base.a5;
import com.softwareag.entirex.trace.Trace;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.Hashtable;
import java.util.Vector;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class c0 {
  private InputStream a = null;
  
  private Reader b = null;
  
  private OutputStream c = null;
  
  private Writer d = null;
  
  private bo e = null;
  
  private ar f = null;
  
  private c3 g = null;
  
  private XMLTypeElement h = null;
  
  private XMLTypeElement i = null;
  
  private c3 j = null;
  
  private at k = null;
  
  private c4 l = null;
  
  private c8 m = null;
  
  private int n = 0;
  
  private String o = null;
  
  private static Hashtable p = new Hashtable();
  
  protected c0(ar paramar) { this.f = paramar; }
  
  protected bo a() { return this.e; }
  
  protected XMLTypeElement b() { return this.h; }
  
  protected c3 c() { return this.g; }
  
  protected ar d() { return this.f; }
  
  protected c3 e() {
    try {
      if (XMLRPCService.a)
        Trace.enterMethod(Trace.M1, 5, 27, 93); 
      if ((this.a == null && this.b == null) || this.e == null)
        throw new XMLException(75); 
      au au = new au();
      int i1 = 0;
      BufferedReader bufferedReader = null;
      String str = null;
      int i2 = 0;
      if (this.e.ae() == 1)
        if (this.a != null) {
          BufferedInputStream bufferedInputStream = new BufferedInputStream(this.a);
          String str1 = this.e.c();
          if (str1 == null) {
            cy cy = new cy(this.e);
            cy.a(bufferedInputStream);
            str = this.e.g();
            i2 = cy.e();
            this.e.d(cy.f() ? 1 : 0);
          } else {
            str = a5.a(str1);
            if (str == null)
              str = str1; 
          } 
          try {
            if (i2 > 0)
              bufferedInputStream.read(new byte[i2], 0, i2); 
            bufferedReader = new BufferedReader(new InputStreamReader(bufferedInputStream, str));
          } catch (UnsupportedEncodingException unsupportedEncodingException) {
            throw new XMLException(7, unsupportedEncodingException.toString());
          } 
        } else if (this.b != null) {
          bufferedReader = new BufferedReader(this.b);
          cy cy = new cy(this.e);
          cy.a(bufferedReader);
          this.e.d(cy.f() ? 1 : 0);
        } else {
          throw new XMLException(75);
        }  
      if (XMLRPCService.a && bufferedReader != null) {
        byte b1 = 0;
        int i3 = 100000;
        bufferedReader.mark(i3);
        StringBuffer stringBuffer = new StringBuffer();
        int i4 = 0;
        while (b1 < i3) {
          i4 = bufferedReader.read();
          if (i4 == -1)
            break; 
          b1++;
          stringBuffer.append((char)i4);
        } 
        Trace.checkpoint(Trace.CP1, 5, 27, 93, "Incoming document=", new String(stringBuffer));
        bufferedReader.reset();
      } 
      if (this.e.ae() == 1) {
        DocumentBuilder documentBuilder = null;
        try {
          documentBuilder = c1.a();
        } catch (Exception exception) {
          throw new XMLException(74, exception.toString());
        } 
        InputSource inputSource = new InputSource(new LineNumberReader(bufferedReader));
        Document document = null;
        try {
          document = documentBuilder.parse(inputSource);
        } catch (SAXException sAXException) {
          throw new XMLException(7, sAXException.toString());
        } catch (IOException iOException) {
          throw new XMLException(7, iOException.toString());
        } 
        c1.a(documentBuilder);
        c2 c2 = new c2(this.f, this.e);
        c2.a(document);
        this.o = c2.a();
        if (this.e.q()) {
          this.h = this.f.m();
          this.h = (XMLTypeElement)this.h.getChild(this.e.y());
          this.h = (XMLTypeElement)this.h.getChild(this.e.d());
          this.g = this.h.createValueNode();
        } else {
          this.h = this.f.j();
          this.g = this.h.createValueNode();
        } 
        this.i = this.h;
        this.j = this.g;
        i1 = d(this.o);
        this.m = c5.a(i1);
        this.m.a(this);
        this.m.a(document);
      } else {
        if (bufferedReader != null) {
          byte b1 = 0;
          StringBuffer stringBuffer = new StringBuffer();
          int i3 = 0;
          while (true) {
            i3 = bufferedReader.read();
            if (i3 == -1)
              break; 
            b1++;
            stringBuffer.append((char)i3);
          } 
          this.e.b("detail", new String(stringBuffer));
        } 
        String str1 = this.e.y();
        String str2 = this.e.d();
        XMLTypeElement xMLTypeElement = this.f.l();
        if (str1 == null || str2 == null) {
          String str3 = this.f.a("entirex.sdk.xml.runtime.defaultFaultDocumentFormat");
          xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(0);
          this.e.j("0");
          if (str3.equals("soap")) {
            xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(1);
            this.e.a("1");
          } else {
            xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(0);
            this.e.a("0");
          } 
        } else {
          xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(str1);
          if (xMLTypeElement != null)
            xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(str2); 
          if (xMLTypeElement == null) {
            String str3 = this.f.a("entirex.sdk.xml.runtime.defaultFaultDocumentFormat");
            xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(0);
            this.e.j("0");
            if (str3.equals("soap")) {
              xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(1);
              this.e.a("1");
            } else {
              xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(0);
              this.e.a("0");
            } 
          } 
        } 
        throw new XMLException(7);
      } 
      if (XMLRPCService.a)
        Trace.leaveMethod(Trace.M1, 5, 27, 93); 
    } catch (IOException iOException) {
      throw new XMLException(iOException);
    } 
    return this.g;
  }
  
  protected void a(c3 paramc3) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M1, 5, 27, 104); 
    int i1 = 0;
    XMLTypeElement xMLTypeElement = null;
    if (this.e.q()) {
      xMLTypeElement = this.f.l();
    } else {
      xMLTypeElement = this.f.i();
    } 
    xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(this.e.y());
    xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(this.e.d());
    xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(0);
    this.g = (c3)paramc3.a(0);
    this.j = this.g;
    if (this.j != null) {
      this.h = this.g.d();
      this.i = this.h;
    } else {
      this.g = xMLTypeElement.createValueNode();
      this.j = this.g;
      this.i = xMLTypeElement;
    } 
    a(xMLTypeElement, this.j);
    Vector vector = this.i.getNamespaceContainer().b();
    boolean bool = false;
    for (byte b1 = 0; !bool && b1 < vector.size(); b1++) {
      String str = ((aw)vector.get(b1)).b();
      Integer integer = (Integer)p.get(str);
      if (integer != null) {
        i1 = integer.intValue();
        bool = true;
      } 
    } 
    if (XMLRPCService.a)
      Trace.checkpoint(Trace.M1, 5, 27, 104, "Document format = " + i1); 
    this.m = c5.a(i1);
    this.m.a(this);
    if (this.c != null) {
      this.m.a(this.c);
    } else {
      this.m.a(this.d);
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M1, 5, 27, 104); 
  }
  
  public XMLTypeElement f() {
    boolean bool = false;
    XMLTypeElement xMLTypeElement = null;
    String str1 = this.e.y();
    String str2 = this.e.d();
    xMLTypeElement = d().l();
    if (xMLTypeElement != null && str1 != null && str2 != null) {
      xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(str1);
      if (xMLTypeElement != null) {
        xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(str2);
        if (xMLTypeElement != null)
          bool = true; 
      } 
    } 
    if (!bool || str1 == null || str2 == null) {
      xMLTypeElement = d().l();
      if (xMLTypeElement != null) {
        xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild("*");
        if (xMLTypeElement != null) {
          xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild("*");
          if (xMLTypeElement != null)
            bool = true; 
        } 
      } 
      if (!bool) {
        if (this.m == null)
          try {
            this.m = c5.a(d(this.o));
            this.m.a(this);
          } catch (Exception exception) {} 
        xMLTypeElement = this.m.c();
        if (xMLTypeElement != null)
          bool = true; 
      } 
    } 
    return xMLTypeElement;
  }
  
  public void g() throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M1, 5, 27, 48); 
    XMLTypeElement xMLTypeElement = f();
    c3 c31 = xMLTypeElement.createValueNode();
    b(xMLTypeElement, c31);
    a(xMLTypeElement, c31);
    this.h = xMLTypeElement;
    this.g = c31;
    if (this.c != null) {
      this.m.a(this.c);
    } else {
      this.m.a(this.d);
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M1, 5, 27, 48); 
  }
  
  public void a(bo parambo) { this.e = parambo; }
  
  public void a(InputStream paramInputStream) { this.a = paramInputStream; }
  
  public void a(OutputStream paramOutputStream) { this.c = paramOutputStream; }
  
  public void a(Reader paramReader) { this.b = paramReader; }
  
  public void a(Writer paramWriter) { this.d = paramWriter; }
  
  public String h() { return this.j.c(); }
  
  public void a(String paramString1, String paramString2) { this.e.a(paramString1, paramString2); }
  
  public void a(String paramString, int paramInt) {
    this.j = (c3)this.j.a(paramString, paramInt);
    this.l = this.j.k();
  }
  
  public String i() { return this.j.a(); }
  
  public String j() { return this.i.getInternalName(); }
  
  public void k() throws XMLException {
    this.i = (XMLTypeElement)this.i.getParent();
    this.j = (c3)this.j.e();
  }
  
  public void l() throws XMLException {
    this.j = (c3)this.j.e();
    this.l = this.j.k();
  }
  
  public Vector m() { return this.j.d().getNamespaceContainer().b(); }
  
  public void a(String paramString) {
    this.j = (c3)this.j.c(paramString);
    this.l = this.j.k();
  }
  
  public void a(int paramInt) { this.j = (c3)this.j.a(paramInt); }
  
  public void a(boolean paramBoolean) { this.j.a(paramBoolean); }
  
  public int n() { return this.j.g(); }
  
  public int b(String paramString) { return this.j.d(paramString); }
  
  public void c(String paramString) { this.j.a(bg.a(paramString, this.i.getInternalDataType(), this.i.getInternalDataFormat())); }
  
  private int d(String paramString) {
    int i1 = 0;
    Integer integer = (Integer)p.get(paramString);
    if (integer != null)
      i1 = integer.intValue(); 
    return i1;
  }
  
  private boolean a(XMLTypeElement paramXMLTypeElement, c3 paramc3) {
    byte b1 = 0;
    int i1 = 0;
    boolean bool = bg.b(paramc3);
    int i2 = 1;
    byte b2 = 1;
    at at1 = paramXMLTypeElement.getAttributes();
    c4 c41 = paramc3.k();
    int i3 = at1.a();
    for (b1 = 0; b1 < i3; b1++) {
      a8 a8 = at1.a(b1);
      String str = a8.c();
      int i7 = a8.f();
      dd dd = c41.b(str);
      if (dd == null) {
        if (i7 == 0 || (i7 == 4 && !bool)) {
          dd dd1 = a8.a();
          c41.a(dd1);
        } 
      } else if ((i7 == 1 && bg.b(dd)) || (i7 == 4 && bool == true)) {
        c41.c(str);
      } 
    } 
    int i4 = paramXMLTypeElement.getChildCount();
    int i5 = paramXMLTypeElement.getNullValueSuppression();
    for (b1 = 0; b1 < i4; b1++) {
      XMLTypeElement xMLTypeElement = (XMLTypeElement)paramXMLTypeElement.getChild(b1);
      String str = xMLTypeElement.getInternalName();
      int i7 = paramc3.d(str);
      int i8 = xMLTypeElement.getMinOccur();
      if (i8 == 0 && (xMLTypeElement.getChildCount() > 0 || xMLTypeElement.getDefaultValue() != null)) {
        int i9 = xMLTypeElement.getMaxOccur();
        if (i9 == 1)
          i8 = 1; 
      } 
      if (i7 < i8) {
        for (i1 = i7; i1 < i8; i1++)
          paramc3.a(xMLTypeElement.createValueNode(), b1); 
        i7 = i8;
      } 
      Vector vector = paramc3.e(str);
      for (i1 = --i7; i1 >= 0; i1--) {
        c3 c31 = (c3)vector.get(i1);
        i2 = (a(xMLTypeElement, c31) && i2) ? 1 : 0;
        if (i5 == 3) {
          b2 &= i2;
          if (b2 == 0)
            c31.a(false); 
        } 
      } 
    } 
    int i6 = paramXMLTypeElement.getNullValueSuppression();
    if (i6 != 0) {
      if (i6 == 1 || i6 == 2) {
        if (bool && i2 != 0 && paramc3.k().a() == 0) {
          paramc3.a(true);
        } else {
          i2 = 0;
        } 
      } else if (i6 == 3 && bool && i2 != 0 && paramc3.k().a() == 0) {
        paramc3.a(true);
      } 
    } else {
      i2 = 0;
    } 
    return i2;
  }
  
  private void b(XMLTypeElement paramXMLTypeElement, c3 paramc3) {
    byte b1 = 0;
    int i1 = paramXMLTypeElement.getChildCount();
    for (b1 = 0; b1 < i1; b1++) {
      XMLTypeElement xMLTypeElement = (XMLTypeElement)paramXMLTypeElement.getChild(b1);
      c3 c31 = xMLTypeElement.createValueNode();
      String str = xMLTypeElement.getContextInfo();
      if (str != null && !str.equals("")) {
        if (str.equals("faultcode")) {
          c31.a(this.e.i() + " " + this.e.k());
        } else if (str.equals("faultstring")) {
          c31.a(this.e.v());
        } else if (str.equals("faultactor")) {
          c31.a("EntireX XML Runtime");
        } else if (str.equals("detail")) {
          c31.a(this.e.e());
        } 
      } else {
        String str1 = xMLTypeElement.getName();
        if (str1 != null)
          if (str1.equalsIgnoreCase("faultcode")) {
            c31.a(this.e.i() + " " + this.e.k());
          } else if (str1.equalsIgnoreCase("faultstring")) {
            c31.a(this.e.v());
          } else if (str1.equalsIgnoreCase("faultactor")) {
            c31.a("EntireX XML Runtime");
          } else if (str1.equalsIgnoreCase("detail")) {
            c31.a(this.e.e());
          }  
      } 
      paramc3.b(c31);
      b(xMLTypeElement, c31);
    } 
  }
  
  protected String o() {
    String str = null;
    int i1 = this.g.d().getUseIncomingEncoding();
    if (i1 == 0)
      i1 = this.f.a(); 
    if (i1 != 2) {
      str = this.e.c();
      if (str == null) {
        str = this.g.d().getEncoding();
        if (str == null)
          if (this.e.q()) {
            str = this.f.e();
          } else {
            str = this.f.c();
          }  
      } 
    } else {
      str = this.g.d().getEncoding();
      if (str == null)
        if (this.e.q()) {
          str = this.f.e();
        } else {
          str = this.f.c();
        }  
    } 
    if (str == null || str.equals(""))
      str = this.f.b(); 
    if (str == null || str.equals("")) {
      str = "utf-8";
      this.e.f("utf-8");
    } 
    return str;
  }
  
  protected boolean a(Element paramElement) throws XMLException {
    boolean bool = false;
    byte b1 = 0;
    String str1 = paramElement.getPrefix();
    String str2 = paramElement.getNamespaceURI();
    String str3 = paramElement.getLocalName();
    String str4 = av.a(str2, str3);
    XMLTypeElement xMLTypeElement = (XMLTypeElement)this.i.getChild(str4);
    if (xMLTypeElement != null) {
      bool = true;
      c3 c31 = xMLTypeElement.createValueNode();
      NamedNodeMap namedNodeMap = paramElement.getAttributes();
      int i1 = namedNodeMap.getLength();
      if (i1 > 0) {
        this.k = xMLTypeElement.getAttributes();
        this.l = c31.k();
        for (b1 = 0; b1 < i1; b1++) {
          Node node1 = namedNodeMap.item(b1);
          if (node1.getNodeType() == 2) {
            String str = av.a(node1.getNamespaceURI(), node1.getLocalName());
            if (this.k != null) {
              a8 a8 = this.k.b(str);
              if (a8 != null) {
                int i2 = a8.n();
                String str5 = a8.m();
                String str6 = ((Attr)node1).getValue();
                str6 = bg.a(str6, i2, str5);
                this.l.a(a8.a(str6));
              } 
            } 
          } 
        } 
      } 
      c31 = (c3)this.j.b(c31);
      this.m.a(c31, namedNodeMap);
      for (Node node = paramElement.getFirstChild(); node != null; node = node.getNextSibling()) {
        if (node.getNodeType() == 3) {
          String str = node.getNodeValue();
          c31.a(bg.a(str, xMLTypeElement.getInternalDataType(), xMLTypeElement.getInternalDataFormat()));
        } 
      } 
      Vector vector = this.j.e(str4);
      if (vector.size() > 0) {
        c3 c32 = (c3)vector.lastElement();
        c32.c(c31);
      } 
      this.i = xMLTypeElement;
      this.j = c31;
    } 
    return bool;
  }
  
  protected int a(Element paramElement, int paramInt, boolean paramBoolean) throws XMLException {
    byte b1 = 0;
    byte b2 = 0;
    Object object = null;
    String str1 = null;
    String str2 = null;
    XMLTypeElement xMLTypeElement = null;
    String str3 = null;
    if (paramInt == -1) {
      if (paramBoolean) {
        xMLTypeElement = (XMLTypeElement)this.i.getChild(0);
      } else {
        str1 = paramElement.getNamespaceURI();
        str2 = paramElement.getLocalName();
        str3 = av.a(str1, str2);
        xMLTypeElement = (XMLTypeElement)this.i.getChild(str3);
      } 
    } else if (!paramBoolean) {
      str1 = paramElement.getNamespaceURI();
      str2 = paramElement.getLocalName();
      str3 = av.a(str1, str2);
      xMLTypeElement = (XMLTypeElement)this.i.getChild(str3);
    } else {
      byte b3 = -1;
      Vector vector = this.i.getChildren();
      int i1 = vector.size();
      for (byte b4 = 0; b4 < i1 && b3 < paramInt; b4++) {
        xMLTypeElement = (XMLTypeElement)vector.get(b4);
        if (xMLTypeElement.a() == XMLTypeElement.w)
          b3++; 
      } 
      if (b3 < paramInt)
        xMLTypeElement = null; 
    } 
    if (xMLTypeElement != null) {
      if (xMLTypeElement.a() == XMLTypeElement.w) {
        b1 = 2;
      } else {
        b1 = 1;
      } 
      c3 c31 = xMLTypeElement.createValueNode();
      NamedNodeMap namedNodeMap = paramElement.getAttributes();
      int i1 = namedNodeMap.getLength();
      if (i1 > 0) {
        this.k = xMLTypeElement.getAttributes();
        this.l = c31.k();
        for (b2 = 0; b2 < i1; b2++) {
          Node node1 = namedNodeMap.item(b2);
          if (node1.getNodeType() == 2) {
            String str = av.a(node1.getNamespaceURI(), node1.getLocalName());
            if (this.k != null) {
              a8 a8 = this.k.b(str);
              if (a8 != null) {
                int i2 = a8.n();
                String str4 = a8.m();
                String str5 = ((Attr)node1).getValue();
                str5 = bg.a(str5, i2, str4);
                this.l.a(a8.a(str5));
              } 
            } 
          } 
        } 
      } 
      c31 = (c3)this.j.b(c31);
      this.m.a(c31, namedNodeMap);
      for (Node node = paramElement.getFirstChild(); node != null; node = node.getNextSibling()) {
        if (node.getNodeType() == 3) {
          String str = node.getNodeValue();
          c31.a(bg.a(str, xMLTypeElement.getInternalDataType(), xMLTypeElement.getInternalDataFormat()));
        } 
      } 
      if (paramInt != -1) {
        str3 = xMLTypeElement.getInternalName();
        paramBoolean = false;
      } 
      Vector vector = null;
      if (paramBoolean) {
        vector = this.j.h();
      } else {
        vector = this.j.e(str3);
      } 
      if (vector.size() > 0) {
        c3 c32 = (c3)vector.lastElement();
        c32.c(c31);
      } 
      this.i = xMLTypeElement;
      this.j = c31;
    } 
    return b1;
  }
  
  static  {
    p.put("http://schemas.xmlsoap.org/soap/envelope", new Integer(11));
    p.put("http://schemas.xmlsoap.org/soap/envelope/", new Integer(11));
    p.put("http://www.w3.org/2002/06/soap-envelope", new Integer(12));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\c0.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */