package com.softwareag.entirex.xml.rt;

final class com/softwareag/entirex/xml/rt/bp {
  private byte[] a;
  
  private byte[] b;
  
  private int c;
  
  private final String d = "0123456789ABCDEF";
  
  private final bh e;
  
  com/softwareag/entirex/xml/rt/bp(bh parambh) {
    this.e = parambh;
    this.d = "0123456789ABCDEF";
    this.a = b();
    int i = (int)(System.currentTimeMillis() & 0xFFFFFFFFFFFFFFFFL);
    this.b = new byte[8];
    a(a(this.a), this.b, i);
    a(this.a, this.b, 0);
    this.c = 0;
  }
  
  final String a() {
    a(this.a, this.b, ++this.c);
    StringBuffer stringBuffer = new StringBuffer("XML");
    for (byte b1 = 0; b1 < this.b.length; b1++) {
      stringBuffer.append("0123456789ABCDEF".charAt(this.b[b1] >> 4 & 0xF));
      stringBuffer.append("0123456789ABCDEF".charAt(this.b[b1] & 0xF));
    } 
    return stringBuffer.toString().toUpperCase();
  }
  
  private final byte[] b() {
    byte[] arrayOfByte = new byte[8];
    byte b2 = 0;
    byte b1;
    for (b1 = 0; b1 < arrayOfByte.length; b1++) {
      byte b3 = 16 << (b1 + 2) % 4 | 8 >> (b1 + true) % 4;
      arrayOfByte[b1] = (byte)b3;
      b2 += true;
    } 
    b1 = 0;
    short s = 128;
    while (b2 < 32) {
      s >>= '\003';
      b1 += 3;
      if (s == 0)
        s = 128; 
      byte b3 = b1 / 8;
      if ((arrayOfByte[b3 % 8] & s) == 0) {
        arrayOfByte[b3 % 8] = (byte)(arrayOfByte[b3 % 8] | s);
        b2++;
      } 
    } 
    return arrayOfByte;
  }
  
  private final byte[] a(byte[] paramArrayOfByte) {
    byte[] arrayOfByte = new byte[paramArrayOfByte.length];
    for (byte b1 = 0; b1 < paramArrayOfByte.length; b1++)
      arrayOfByte[b1] = (byte)(paramArrayOfByte[b1] ^ 0xFFFFFFFF); 
    return arrayOfByte;
  }
  
  private final void a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt) {
    boolean bool = false;
    for (byte b1 = 0; b1 < paramArrayOfByte1.length; b1++) {
      short s = 128;
      for (byte b2 = 0; b2 < 8; b2++) {
        if ((paramArrayOfByte1[b1] & s) != 0) {
          if ((paramInt & true) != 0) {
            paramArrayOfByte2[b1] = (byte)(paramArrayOfByte2[b1] | s);
          } else {
            paramArrayOfByte2[b1] = (byte)(paramArrayOfByte2[b1] & (s ^ 0xFFFFFFFF));
          } 
          paramInt >>= 1;
        } 
        s >>= 1;
      } 
    } 
  }
  
  private final int a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2) {
    boolean bool = false;
    int i = 0;
    for (byte b1 = 0; b1 < paramArrayOfByte1.length; b1++) {
      short s = 128;
      for (byte b2 = 0; b2 < 8; b2++) {
        if ((paramArrayOfByte1[b1] & s) != 0) {
          i >>= true;
          i &= Integer.MAX_VALUE;
          if ((paramArrayOfByte2[b1] & s) != 0)
            i |= Integer.MIN_VALUE; 
        } 
        s >>= 1;
      } 
    } 
    return i;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\bp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */