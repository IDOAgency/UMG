package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class bi {
  private Hashtable a;
  
  private int b;
  
  private Vector c;
  
  private int d;
  
  private bj e;
  
  private int f;
  
  private int g;
  
  public bi(int paramInt1, int paramInt2) {
    synchronized (this) {
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP4, 6, 3, 8, "create pool"); 
      this.e = new bj(this, paramInt2 * 1000);
      this.f = paramInt2;
      this.g = paramInt1;
      this.a = new Hashtable();
      this.c = new Vector();
      this.d = -1;
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP4, 6, 3, 8, "creating FreePool with " + paramInt1 + " objects."); 
      h();
      this.b = 0;
      this.e.start();
    } 
  }
  
  private void h() {
    for (byte b1 = 0; b1 < this.g; b1++) {
      XMLRPCService xMLRPCService = new XMLRPCService();
      this.c.addElement(xMLRPCService);
    } 
  }
  
  public void a(bk parambk) {
    if (parambk != null && !this.a.contains(parambk)) {
      this.a.put(parambk.getPoolKey(), parambk);
      this.b++;
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP4, 6, 3, 115, "add a new pooled item"); 
    } 
  }
  
  public bk a(String paramString) {
    bk bk = null;
    if (paramString != null)
      bk = (bk)this.a.get(paramString); 
    if (bk == null) {
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP4, 6, 3, 116, "use one of the freePool"); 
      bk = b(paramString);
    } else {
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP4, 6, 3, 116, "use a pooled item"); 
      bk.reserve();
    } 
    return bk;
  }
  
  public void b(bk parambk) {
    if (XMLServlet.ap)
      Trace.checkpoint(Trace.CP4, 6, 3, 38, "try to remove pooled item"); 
    if (parambk != null && this.a.remove(parambk) != null) {
      this.b--;
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP4, 6, 3, 38, "remove pooled item"); 
    } 
  }
  
  protected void a() {
    Enumeration enumeration = e();
    while (enumeration.hasMoreElements()) {
      bk bk = (bk)enumeration.nextElement();
      if (!bk.isInUse()) {
        if (bk.isConversational()) {
          if (bk.isTimedOut(this.f * 1000))
            b(bk); 
          continue;
        } 
        if (bk.isTimedOut(this.f * 1000))
          b(bk); 
      } 
    } 
  }
  
  protected void b() {
    for (byte b1 = 0; b1 < this.c.size() && this.c.size() > this.g; b1++) {
      bk bk = (bk)this.c.elementAt(b1);
      if (!bk.isInUse()) {
        if (XMLServlet.ap)
          Trace.checkpoint(Trace.CP4, 6, 3, 45, "try to remove freePooled item " + b1 + "/" + this.c.size()); 
        if (bk.isTimedOut(this.f * 1000)) {
          this.c.removeElement(bk);
          if (XMLServlet.ap)
            Trace.checkpoint(Trace.CP4, 6, 3, 45, "getFreePoolList() - remove " + b1); 
          b1--;
        } 
      } 
    } 
  }
  
  public int c() { return this.a.size(); }
  
  public int d() { return this.c.size(); }
  
  public Enumeration e() { return this.a.elements(); }
  
  public XMLRPCService b(String paramString) {
    XMLRPCService xMLRPCService = null;
    boolean bool = true;
    if (XMLServlet.ap)
      Trace.checkpoint(Trace.CP4, 6, 3, 23, "getNextFreeService search " + this.d + " and above"); 
    for (int i = this.d + 1; i < this.c.size(); i++) {
      xMLRPCService = (XMLRPCService)this.c.elementAt(i);
      if (!xMLRPCService.isInUse()) {
        this.d = i;
        bool = false;
        break;
      } 
    } 
    if (bool) {
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP4, 6, 3, 23, "getNextFreeService search to " + this.d); 
      for (byte b1 = 0; b1 < this.d; b1++) {
        xMLRPCService = (XMLRPCService)this.c.elementAt(b1);
        if (!xMLRPCService.isInUse()) {
          this.d = b1;
          bool = false;
          break;
        } 
      } 
    } 
    if (bool) {
      xMLRPCService = new XMLRPCService();
      this.d = this.c.size();
      this.c.addElement(xMLRPCService);
    } 
    if (XMLServlet.ap)
      Trace.checkpoint(Trace.CP4, 6, 3, 23, "getNextFreeService new index=" + this.d); 
    xMLRPCService.setLibraryName("");
    xMLRPCService.setPoolKey(paramString);
    xMLRPCService.reserve();
    return xMLRPCService;
  }
  
  public int f() {
    byte b1 = 0;
    int i = this.c.size();
    for (byte b2 = 0; b2 < i; b2++) {
      XMLRPCService xMLRPCService = (XMLRPCService)this.c.elementAt(b2);
      if (!xMLRPCService.isInUse())
        b1++; 
    } 
    return b1;
  }
  
  public void g() {
    if (this.e != null) {
      this.e.a();
      this.e.interrupt();
      try {
        this.e.join(this.f);
      } catch (Exception exception) {
        if (XMLServlet.ap)
          Trace.checkpoint(Trace.CP4, 6, 3, 114, "join sweeper failed: " + exception); 
      } 
      this.a.clear();
      this.a = null;
      this.c.clear();
      this.c = null;
      this.e = null;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\bi.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */