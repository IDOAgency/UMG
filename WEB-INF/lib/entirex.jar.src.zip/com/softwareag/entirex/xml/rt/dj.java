package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.ao;

public abstract class dj extends dk {
  protected boolean a;
  
  public dj(ar paramar, bo parambo, ao paramao) { super(paramar, parambo, paramao); }
  
  public dj(ar paramar, bo parambo) { super(paramar, parambo); }
  
  public byte[] b(RPCType paramRPCType, cp paramcp) throws XMLException {
    a(paramRPCType, paramcp, new df(), 0);
    return this.f.e();
  }
  
  public void a(RPCType paramRPCType, cp paramcp) throws XMLException { b(paramRPCType, paramcp, new df(), 0); }
  
  public abstract void a(RPCType paramRPCType, cp paramcp, df paramdf, int paramInt) throws XMLException;
  
  public abstract void b(RPCType paramRPCType, cp paramcp, df paramdf, int paramInt) throws XMLException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\dj.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */