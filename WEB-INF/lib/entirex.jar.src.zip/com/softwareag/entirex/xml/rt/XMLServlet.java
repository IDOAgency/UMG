package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.Dump;
import com.softwareag.entirex.aci.EntireXVersion;
import com.softwareag.entirex.base.EntireXFileLoader;
import com.softwareag.entirex.base.a4;
import com.softwareag.entirex.trace.Trace;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.SAXParser;
import org.xml.sax.SAXException;

public class XMLServlet extends HttpServlet {
  protected static final String a = (new EntireXVersion("XMLServlet")).getVersionString();
  
  static final String b = "log";
  
  static final String c = "exx-xml-init";
  
  static final String d = "exx-locationtransparency-init";
  
  static final String e = "exx-locationtransparency-config";
  
  static final String f = "exx-sweeptime";
  
  static final String g = "exx-default-waittime";
  
  static final String h = "exx-trace-propertiesfile";
  
  static final String i = "exx-pool-min-size";
  
  static final String j = "exx-brokerID";
  
  static final String k = "exx-service";
  
  static final String l = "exx-xml-adapter";
  
  static final String m = "exx-xml-sessionID";
  
  static final String n = "exx-userID";
  
  static final String o = "exx-password";
  
  static final String p = "exx-rpc-userID";
  
  static final String q = "exx-rpc-password";
  
  static final String r = "exx-xml-info";
  
  static final String s = "exx-xml-error";
  
  static final String t = "exx-conv";
  
  static final String u = "exx-xml-buddy";
  
  static final String v = "exx-use-security";
  
  static final String w = "exx-natural-security";
  
  static final String x = "exx-encryption-level";
  
  static final String y = "exx-logical-brokerID";
  
  static final String z = "exx-logical-service";
  
  static final String aa = "exx-logicalsetname";
  
  static final String ab = "exx-use-codepage";
  
  static final String ac = "exx-test";
  
  static final String ad = "exx-compresslevel";
  
  static final String ae = "exx-xmm";
  
  static final String af = "exx-natural-library";
  
  static final String ag = "exx-trace";
  
  static final String ah = "exx-trace-level";
  
  static final String ai = "exx-input-file";
  
  static final String aj = "exx-compression";
  
  private static final String ak = "text/*";
  
  private static String al;
  
  private static double am;
  
  private static boolean an;
  
  private static ar ao = null;
  
  protected static boolean ap = false;
  
  private static String aq;
  
  private static String ar;
  
  private static String as;
  
  private static int at;
  
  private bh au;
  
  private dq av;
  
  private int aw;
  
  private int ax = 0;
  
  private String ay;
  
  public void init(ServletConfig paramServletConfig) throws ServletException {
    super.init(paramServletConfig);
    an = b(paramServletConfig.getInitParameter("log"));
    String str1 = paramServletConfig.getInitParameter("exx-trace-propertiesfile");
    if (str1 != null)
      try {
        Properties properties = System.getProperties();
        if (properties != null) {
          properties.put("entirex.sdk.default.trace.propertiesfile", str1);
          System.setProperties(properties);
        } 
      } catch (Exception exception) {} 
    ap = Trace.on(6, this);
    XMLRPCService.a = Trace.on(5, this);
    if (ap)
      Trace.enterMethod(Trace.M1, 6, 10, 24); 
    String str2 = paramServletConfig.getInitParameter("sweepTime");
    if (str2 == null)
      str2 = paramServletConfig.getInitParameter("exx-sweeptime"); 
    if (str2 != null) {
      if (ap)
        Trace.parameter(Trace.MP1, 6, 10, 24, "Sweep Time", str2); 
      try {
        Integer integer = new Integer(str2);
        at = integer.intValue();
      } catch (Exception exception) {
        if (ap)
          Trace.checkpoint(Trace.CP1, 6, 10, 24, "Wrong Format of Sweep Time parameter " + str2 + ": " + exception); 
        throw new ServletException("Error in Servlet Init: Wrong Format of Sweep Time parameter (" + str2 + ").");
      } 
    } 
    if (at <= 0) {
      at = 60;
      at = 10;
    } 
    str2 = paramServletConfig.getInitParameter("exx-pool-min-size");
    if (str2 != null) {
      if (ap)
        Trace.parameter(Trace.MP4, 6, 10, 24, "Pool Min Size", str2); 
      try {
        Integer integer = new Integer(str2);
        this.aw = integer.intValue();
      } catch (Exception exception) {
        if (ap)
          Trace.checkpoint(Trace.CP4, 6, 10, 24, "Wrong Format of Pool Min Size parameter " + str2 + ": " + exception); 
      } 
    } 
    if (this.aw <= 0)
      this.aw = 10; 
    as = paramServletConfig.getInitParameter("exx-xml-init");
    aq = paramServletConfig.getInitParameter("exx-locationtransparency-init");
    ar = paramServletConfig.getInitParameter("exx-locationtransparency-config");
    try {
      if (aq != null) {
        EntireXFileLoader entireXFileLoader = new EntireXFileLoader(aq, this.ay);
        aq = entireXFileLoader.getFileName();
        if (ap)
          Trace.parameter(Trace.MP4, 6, 12, 19, "locationTransparencyInitFile", aq); 
        Properties properties = System.getProperties();
        if (properties != null) {
          properties.put("entirex.location.transparency.ini", aq);
          System.setProperties(properties);
        } 
        if (ap)
          Trace.checkpoint(Trace.CP3, 6, 12, 8, "successfully setting of Property: exx-locationtransparency-init=" + aq); 
      } 
      if (ar != null) {
        Properties properties = System.getProperties();
        if (properties != null) {
          properties.put("entirex.location.transparency.config", ar);
          System.setProperties(properties);
        } 
        if (ap)
          Trace.checkpoint(Trace.CP3, 6, 12, 8, "successfully setting of Property: exx-locationtransparency-config=" + ar); 
      } 
    } catch (SecurityException securityException) {}
    ao = new ar();
    ao.b(true);
    if (ap)
      Trace.checkpoint(Trace.CP2, 6, 10, 24, "Create new XML Runtime Repository"); 
    ao.a("entirex.sdk.xml.runtime.throwJavaException", "no");
    try {
      a(paramServletConfig);
    } catch (XMLException xMLException) {
      if (ap)
        Trace.checkpoint(Trace.CP1, 6, 10, 24, "ServletException: " + xMLException); 
      throw new ServletException(xMLException.toString());
    } 
    al = paramServletConfig.getServletContext().getServerInfo();
    try {
      am = Double.parseDouble(paramServletConfig.getServletContext().getMajorVersion() + "." + paramServletConfig.getServletContext().getMinorVersion());
    } catch (Exception exception) {
      am = 0.0D;
    } finally {
      if (ap)
        Trace.leaveMethod(Trace.M1, 6, 10, 24); 
    } 
    if (ap) {
      Trace.checkpoint(Trace.CP4, 6, 10, 24, "config-list: start ---------");
      Enumeration enumeration = paramServletConfig.getInitParameterNames();
      while (enumeration.hasMoreElements()) {
        String str = (String)enumeration.nextElement();
        Trace.checkpoint(Trace.CP4, 6, 10, 24, str, paramServletConfig.getInitParameter(str));
      } 
      Trace.checkpoint(Trace.CP4, 6, 10, 24, "config-list: end -----------");
      Trace.checkpoint(Trace.CP4, 6, 10, 24, "attribute-list: start ---------");
      enumeration = paramServletConfig.getServletContext().getAttributeNames();
      while (enumeration.hasMoreElements()) {
        String str = (String)enumeration.nextElement();
        Trace.checkpoint(Trace.CP4, 6, 10, 24, str, "" + paramServletConfig.getServletContext().getAttribute(str));
      } 
      Trace.checkpoint(Trace.CP4, 6, 10, 24, "attribute-list: end -----------");
    } 
    this.ay = paramServletConfig.getServletContext().getRealPath("/");
    if (ap)
      if (this.ay == null) {
        Trace.checkpoint(Trace.CP1, 6, 12, 8, "WARNING: The directory of the web application could not read.");
        Trace.checkpoint(Trace.CP1, 6, 12, 8, "Hint: Check, if the WAR file is unpacked, see documentation of your webserver.");
      } else {
        Trace.checkpoint(Trace.CP2, 6, 12, 8, "real servlet path", this.ay);
      }  
    try {
      this.au = new bh(this.aw, at);
    } catch (Exception exception) {
      if (ap)
        Trace.checkpoint(Trace.CP1, 6, 10, 24, "ServletException: " + exception); 
      throw new ServletException("" + exception);
    } finally {
      if (ap)
        Trace.leaveMethod(Trace.M1, 6, 10, 24); 
    } 
  }
  
  public String getServletInfo() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(a);
    stringBuffer.append("<br />");
    stringBuffer.append("(c) Copyright SOFTWARE AG 2000-");
    stringBuffer.append((new EntireXVersion("XMLServlet")).getYear());
    stringBuffer.append(". All Rights Reserved.");
    return stringBuffer.toString();
  }
  
  public static double getServletAPIVersion() { return am; }
  
  public static String getServletInitFileName() { return as; }
  
  public static int getServletSweepTime() { return at; }
  
  public static String getServletLocationTransparencyInitFile() { return aq; }
  
  public static String getServletLocationTransparencyInitConfig() { return ar; }
  
  public static ar getXMLRuntimeRepository() { return ao; }
  
  public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws IOException, ServletException {
    if (ap)
      Trace.enterMethod(Trace.M3, 6, 10, 77); 
    this.av.a(paramHttpServletRequest, paramHttpServletResponse);
    this.av = null;
    if (ap)
      Trace.leaveMethod(Trace.M3, 6, 10, 77); 
  }
  
  public void doTrace(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws IOException, ServletException {
    String str = a(paramHttpServletRequest, "exx-trace");
    if (str != null)
      if (b(str)) {
        if (!ap) {
          if (an)
            log("enable XMLServlet tracing"); 
          ap = Trace.on(6, this);
          XMLRPCService.a = Trace.on(5, this);
        } else if (an) {
          log("XMLServlet Trace already enabled.");
        } 
      } else if (ap) {
        if (an)
          log("disable XMLServlet tracing"); 
        XMLRPCService.a = false;
        Trace.off(5, this);
        ap = false;
        Trace.off(6, this);
      } else if (an) {
        log("XMLServlet Trace already disabled.");
      }  
    str = a(paramHttpServletRequest, "exx-trace-level");
    int i1 = Dump.b();
    if (str != null) {
      try {
        i1 = Integer.parseInt(str);
      } catch (Exception exception) {}
      if (an)
        log("set Java ACI trace level to " + i1); 
      Dump.setTrace(i1);
    } 
    paramHttpServletResponse.setHeader("exx-trace", "" + ap);
    paramHttpServletResponse.setHeader("exx-trace-level", "" + i1);
  }
  
  public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws IOException, ServletException { doGet(paramHttpServletRequest, paramHttpServletResponse); }
  
  public void destroy() {
    if (an)
      log("starts destroying mechanism ..."); 
    if (this.au != null)
      this.au.g(); 
    ao = null;
    if (ap) {
      XMLRPCService.a = false;
      Trace.off(5, this);
      ap = false;
      Trace.off(6, this);
    } 
    super.destroy();
    if (an)
      log("destroying completed"); 
  }
  
  protected void a() { this.ax++; }
  
  protected void b() { this.ax--; }
  
  protected int c() { return this.ax; }
  
  protected void service(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws IOException, ServletException {
    a();
    if (ap) {
      Trace.enterMethod(Trace.M3, 6, 10, 41);
      Trace.checkpoint(Trace.CP2, 6, 10, 41, "serviceCounter", this.ax);
    } 
    try {
      if (this.au == null)
        try {
          this.au = new bh(this.aw, at);
        } catch (Exception exception) {
          throw new ServletException(exception.toString());
        }  
      XMLRPCService xMLRPCService = this.au.a(paramHttpServletRequest);
      this.av = new dq(xMLRPCService, xMLRPCService.getPoolKey());
      super.service(paramHttpServletRequest, paramHttpServletResponse);
      if (xMLRPCService.isConversational())
        this.au.a(xMLRPCService); 
    } catch (NullPointerException nullPointerException) {
      if (an)
        log("service()npe: " + nullPointerException); 
      System.err.println("service()npe: " + nullPointerException);
    } catch (Exception exception) {
      if (an)
        log("service()e: " + exception); 
      System.err.println("service()e: " + exception);
    } finally {
      b();
      if (ap)
        Trace.leaveMethod(Trace.M3, 6, 10, 41); 
    } 
  }
  
  protected static String a(HttpServletRequest paramHttpServletRequest, String paramString) {
    String str1 = paramHttpServletRequest.getHeader(paramString);
    String str2 = "header";
    if (str1 != null) {
      str1 = str1.trim();
      if (str1.length() < 1)
        str1 = null; 
    } 
    if (str1 == null) {
      str2 = "parameter";
      str1 = paramHttpServletRequest.getParameter(paramString);
      if (str1 != null) {
        str1 = str1.trim();
        if (str1.length() < 1)
          str1 = null; 
      } 
    } 
    if (str1 == null)
      str2 = "header/parameter"; 
    if (ap)
      Trace.checkpoint(Trace.CP2, 6, 10, 18, str2 + ": " + paramString + "=" + str1); 
    return str1;
  }
  
  static void a(String paramString) {
    if (ap || an)
      System.out.println(paramString); 
  }
  
  protected static boolean b(String paramString) {
    boolean bool = false;
    if (paramString != null && paramString.trim().length() > 0) {
      bool = Boolean.valueOf(paramString).booleanValue();
      if (!bool)
        bool = paramString.trim().toLowerCase().startsWith("y"); 
    } 
    return bool;
  }
  
  public static String getServerInfo() { return al; }
  
  private void a(ServletConfig paramServletConfig) throws ServletException {
    if (ap)
      Trace.checkpoint(Trace.CP1, 6, 10, 19, "name", as); 
    boolean bool = false;
    if (as != null && as.trim().length() > 0) {
      try {
        SAXParserLoader sAXParserLoader;
        SAXParser sAXParser = (sAXParserLoader = new SAXParserLoader()).getSAXParser();
        a4 a4 = new a4(as, this.ay, paramServletConfig.getServletContext());
        InputStream inputStream = a4.getFileAsInputStream();
        a6 a6 = new a6(ao);
        sAXParser.parse(inputStream, a6);
        a6.a(this.ay, paramServletConfig.getServletContext());
        ao.a(this.ay, paramServletConfig.getServletContext(), a3.b);
        bool = true;
      } catch (IOException iOException) {
        if (ap) {
          if (an)
            log(iOException.toString()); 
          Trace.checkpoint(Trace.CP1, 6, 10, 19, "IOException: " + iOException.getMessage());
        } 
        throw new XMLException(47, "( " + iOException.toString() + " )");
      } catch (XMLException xMLException) {
        if (ap) {
          if (an)
            log(xMLException.toString()); 
          Trace.checkpoint(Trace.CP1, 6, 10, 19, "XMLException: " + xMLException.getMessage());
        } 
        throw new XMLException(47, "( " + xMLException.toString() + " )");
      } catch (SAXException sAXException) {
        if (ap) {
          if (an)
            log(sAXException.toString()); 
          Trace.checkpoint(Trace.CP1, 6, 10, 19, "SAXException: " + sAXException.getMessage());
        } 
        throw new XMLException(47, "( " + sAXException.toString() + " )");
      } catch (OutOfMemoryError outOfMemoryError) {
        if (ap) {
          if (an)
            log(outOfMemoryError.toString()); 
          Trace.checkpoint(Trace.CP1, 6, 10, 19, "OutOfMemoryError: " + outOfMemoryError + ", increase the JVM memory !)");
        } 
        throw new XMLException(48, "( " + outOfMemoryError.toString() + ", increase the JVM memory !)");
      } 
      if (ap && bool) {
        Trace.checkpoint(Trace.CP1, 6, 10, 19, "Successfully reading of exx-xml-init file:" + as);
      } else if (ap) {
        Trace.checkpoint(Trace.CP1, 6, 10, 19, "Problems by reading exx-xml-init file:" + as);
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\XMLServlet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */