package com.softwareag.entirex.xml.rt;

public interface s extends BaseNode {
  int getDirection();
  
  void setDirection(int paramInt);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\s.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */