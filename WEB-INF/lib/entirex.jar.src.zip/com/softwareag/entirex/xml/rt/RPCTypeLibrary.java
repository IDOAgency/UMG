package com.softwareag.entirex.xml.rt;

public class RPCTypeLibrary extends RPCTypeStructure {
  private String a = null;
  
  public RPCTypeLibrary(String paramString) {
    super(a3.b(paramString), 20, 3);
    this.a = paramString;
  }
  
  public String getOriginalName() { return this.a; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\RPCTypeLibrary.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */