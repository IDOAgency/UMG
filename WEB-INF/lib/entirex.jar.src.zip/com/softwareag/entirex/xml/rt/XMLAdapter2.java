package com.softwareag.entirex.xml.rt;

public interface XMLAdapter2 extends XMLAdapter {
  BaseNode getXMLTypeIncomingRoot();
  
  BaseNode getXMLTypeOutgoingRoot();
  
  BaseNode getXMLTypeFaultRoot();
  
  String getVersion();
  
  String getFeature(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\XMLAdapter2.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */