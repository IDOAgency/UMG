package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.ao;

public class dh {
  protected static final int a = 0;
  
  protected static final int b = 1;
  
  boolean c = true;
  
  boolean d = false;
  
  boolean e = false;
  
  int f = 0;
  
  dl g = null;
  
  RPCType h = null;
  
  RPCType i = null;
  
  private dh() {}
  
  public dh(ar paramar, bo parambo, int paramInt) {
    switch (this.f) {
      case 0:
        switch (paramInt) {
          case 1110:
            this.g = new di(paramar, parambo);
            break;
          case 1120:
            this.g = new dm(paramar, parambo);
            break;
          case 1130:
            this.g = new dn(paramar, parambo);
            break;
          case 1140:
            this.g = new do(paramar, parambo);
            break;
          case 2000:
            this.g = new dp(paramar, parambo);
            break;
        } 
        break;
    } 
  }
  
  public dh(ar paramar, bo parambo, ao paramao) {
    switch (this.f) {
      case 0:
        switch (paramao.e()) {
          case 1110:
            this.g = new di(paramar, parambo, paramao);
          case 1120:
            this.g = new dm(paramar, parambo, paramao);
          case 1130:
            this.g = new dn(paramar, parambo, paramao);
          case 1140:
            this.g = new do(paramar, parambo, paramao);
            break;
          case 2000:
            this.g = new dp(paramar, parambo, paramao);
            break;
        } 
        break;
    } 
  }
  
  public byte[] a(cp paramcp) throws XMLException {
    null = null;
    RPCType rPCType = this.g.h().g();
    rPCType = (RPCType)rPCType.getChild(this.g.i().y());
    rPCType = (RPCType)rPCType.getChild(this.g.i().d());
    cp cp1 = (cp)paramcp.c(this.g.i().y());
    cp1 = (cp)cp1.c(this.g.i().d());
    this.g.a(paramcp);
    return this.g.b(rPCType, cp1);
  }
  
  public cp a() throws XMLException {
    cp cp1 = new cp(new RPCType("anchor", 0));
    RPCType rPCType = this.g.h().g();
    if (rPCType == null)
      throw new XMLException(82, "Empty Repository."); 
    rPCType = (RPCType)rPCType.getChild(this.g.i().y());
    if (rPCType == null)
      throw new XMLException(82, "Unknown library name:" + this.g.i().y()); 
    cp cp2 = rPCType.createValueNode();
    cp1.b(cp2);
    rPCType = (RPCType)rPCType.getChild(this.g.i().d());
    if (rPCType == null)
      throw new XMLException(82, "Unknown program name:" + this.g.i().d()); 
    cp cp3 = rPCType.createValueNode();
    cp2.b(cp3);
    this.g.a(rPCType, cp3);
    return cp1;
  }
  
  public byte[] b() {
    byte[] arrayOfByte = null;
    if (this.f == 0) {
      arrayOfByte = ((dk)this.g).a();
    } else {
      arrayOfByte = new byte[0];
    } 
    return arrayOfByte;
  }
  
  public byte[] c() { return this.g.b(); }
  
  public int d() { return ((dk)this.g).d(); }
  
  public void a(byte[] paramArrayOfByte, int paramInt) { ((dk)this.g).a(paramArrayOfByte, paramInt); }
  
  public void a(boolean paramBoolean) { this.g.c = paramBoolean; }
  
  public long e() { return ((dk)this.g).c(); }
  
  protected void a(int paramInt) { ((dk)this.g).a(paramInt); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\dh.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */