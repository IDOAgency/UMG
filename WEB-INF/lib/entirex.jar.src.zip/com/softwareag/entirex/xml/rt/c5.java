package com.softwareag.entirex.xml.rt;

public class c5 {
  protected static final int a = 0;
  
  protected static final int b = 1;
  
  protected static final int c = 11;
  
  protected static final int d = 12;
  
  private static boolean e = true;
  
  public static void a(boolean paramBoolean) { e = paramBoolean; }
  
  public static c8 a(int paramInt) throws XMLException {
    null = null;
    switch (paramInt) {
      case 0:
        return new c6();
      case 1:
        return new c9();
      case 11:
        return new da();
      case 12:
        return new dc();
    } 
    throw new XMLException(77);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\c5.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */