package com.softwareag.entirex.xml.rt;

public class cw {
  String a = null;
  
  String b = null;
  
  private cw() {}
  
  public cw(String paramString) {
    this.a = paramString;
    int i = this.a.indexOf(":");
    if (i >= 0) {
      this.b = this.a.substring(0, i);
    } else {
      this.b = this.a;
    } 
  }
  
  protected void a(String paramString) {}
  
  protected void b(String paramString) {}
  
  public String a() { return this.b; }
  
  public String b() { return this.a; }
  
  public String toString() { return "\nServerDescriptor\nName = " + this.a + "\nProtocol = " + this.b; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\cw.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */