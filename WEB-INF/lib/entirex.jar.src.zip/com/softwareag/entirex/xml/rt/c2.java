package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class c2 {
  private ar a = null;
  
  private bo b = null;
  
  private XMLTypeElement c = null;
  
  private XMLTypeElement d = null;
  
  private String e = null;
  
  private boolean f = false;
  
  public c2(ar paramar) {
    this.a = paramar;
    this.c = paramar.j();
    this.d = paramar.m();
  }
  
  public c2(ar paramar, bo parambo) {
    this.a = paramar;
    this.b = parambo;
    this.c = paramar.j();
    this.d = paramar.m();
  }
  
  protected void a(bo parambo) { this.b = parambo; }
  
  protected String a() { return (this.e == null) ? "" : this.e; }
  
  public void a(Document paramDocument) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M4, 5, 7, 107); 
    String str = this.b.af();
    if (str != null) {
      XMLTypeElement xMLTypeElement = this.c;
      xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(a3.v);
      if (xMLTypeElement != null) {
        xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(a3.w);
        if (xMLTypeElement != null) {
          xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild("SOAPAction");
          if (xMLTypeElement != null) {
            bd bd = xMLTypeElement.c();
            if (bd != null) {
              String str1 = bd.b(str);
              String str2 = bd.a(str);
              if (str1 == null || str2 == null) {
                xMLTypeElement = null;
              } else {
                this.b.j(str1);
                this.b.a(str2);
              } 
            } else {
              xMLTypeElement = null;
            } 
          } 
        } 
      } 
      if (xMLTypeElement == null) {
        this.b.j("0");
        if (this.a.a("entirex.sdk.xml.runtime.defaultFaultDocumentFormat").equalsIgnoreCase("soap")) {
          this.b.a("1");
        } else {
          this.b.a("0");
        } 
        throw new XMLException(77, "SOAPAction=" + str);
      } 
    } else {
      Element element = paramDocument.getDocumentElement();
      this.e = element.getNamespaceURI();
      if (!a(element, this.c, false)) {
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP1, 5, 7, 107, "Could not found a matching program in mapping description."); 
        if (b(element, this.d, false) == true) {
          if (XMLRPCService.a)
            Trace.checkpoint(Trace.CP1, 5, 7, 107, "Find a fault document."); 
          this.b.a(true);
        } else if (c(element, this.d, false) == true) {
          if (XMLRPCService.a)
            Trace.checkpoint(Trace.CP1, 5, 7, 107, "Find a fault document (default)."); 
          this.b.a(true);
        } else {
          String str1 = this.a.a("entirex.sdk.xml.runtime.defaultFaultDocumentFormat");
          this.b.j("0");
          if (str1.equals("soap")) {
            this.b.a("1");
          } else {
            this.b.a("0");
          } 
          if (XMLRPCService.a)
            Trace.checkpoint(Trace.CP1, 5, 7, 107, "Exception: 77"); 
          throw new XMLException(77);
        } 
      } 
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M4, 5, 7, 107); 
  }
  
  private boolean a(Element paramElement, XMLTypeElement paramXMLTypeElement, boolean paramBoolean) throws XMLException {
    boolean bool = false;
    String str1 = paramElement.getNamespaceURI();
    String str2 = paramElement.getLocalName();
    paramXMLTypeElement = (XMLTypeElement)paramXMLTypeElement.getChild(av.a(str1, str2));
    if (paramXMLTypeElement == null) {
      paramBoolean = false;
    } else {
      bd bd = paramXMLTypeElement.c();
      if (bd != null) {
        String str = null;
        paramBoolean = true;
        bool = true;
        if (this.b.y() == null || this.b.d() == null) {
          str = a(paramElement);
          String str3 = bd.b(str);
          String str4 = bd.a(str);
          if (str3 == null || str4 == null)
            throw new XMLException(77); 
          this.b.j(str3);
          this.b.a(str4);
        } else if (!this.b.y().equals(a3.b(bd.b(str))) || !this.b.d().equals(a3.b(bd.a(str)))) {
          throw new XMLException(7, "Unexpected document");
        } 
        if (XMLRPCService.a) {
          Trace.parameter(Trace.MP4, 5, 7, 107, "library", this.b.y());
          Trace.parameter(Trace.MP4, 5, 7, 107, "program", this.b.d());
        } 
      } else {
        NodeList nodeList = paramElement.getChildNodes();
        int i = nodeList.getLength();
        for (byte b1 = 0; !bool && b1 < i; b1++) {
          Node node = nodeList.item(b1);
          if (node.getNodeType() == 1)
            bool = a((Element)node, paramXMLTypeElement, paramBoolean); 
        } 
        paramBoolean = bool;
      } 
    } 
    return paramBoolean;
  }
  
  private boolean b(Element paramElement, XMLTypeElement paramXMLTypeElement, boolean paramBoolean) throws XMLException {
    boolean bool = true;
    String str1 = paramElement.getNamespaceURI();
    String str2 = paramElement.getTagName();
    String str3 = this.b.y();
    String str4 = this.b.d();
    if (str3 == null || str4 == null)
      return false; 
    paramXMLTypeElement = (XMLTypeElement)paramXMLTypeElement.getChild(str3);
    if (paramXMLTypeElement != null) {
      paramXMLTypeElement = (XMLTypeElement)paramXMLTypeElement.getChild(str4);
      if (paramXMLTypeElement != null)
        paramXMLTypeElement = (XMLTypeElement)paramXMLTypeElement.getChild(av.a(str1, str2)); 
    } 
    if (paramXMLTypeElement == null) {
      paramBoolean = false;
    } else {
      bd bd = paramXMLTypeElement.c();
      if (bd != null) {
        String str = null;
        paramBoolean = true;
        bool = true;
        if (this.b.y() == null || this.b.d() == null) {
          str = a(paramElement);
          String str5 = bd.b(str);
          String str6 = bd.a(str);
          if (str5 == null || str6 == null)
            throw new XMLException(77); 
          this.b.j(str5);
          this.b.a(str6);
        } else if (!this.b.y().equals(a3.b(bd.b(str))) || !this.b.d().equals(a3.b(bd.a(str)))) {
          throw new XMLException(7, "Unexpected document");
        } 
        if (XMLRPCService.a) {
          Trace.parameter(Trace.MP4, 5, 7, 107, "library", this.b.y());
          Trace.parameter(Trace.MP4, 5, 7, 107, "program", this.b.d());
        } 
      } else {
        NodeList nodeList = paramElement.getChildNodes();
        int i = nodeList.getLength();
        for (byte b1 = 0; !bool && b1 < i; b1++) {
          Node node = nodeList.item(b1);
          if (node.getNodeType() == 1)
            bool = a((Element)node, paramXMLTypeElement, paramBoolean); 
        } 
        paramBoolean = bool;
      } 
    } 
    return paramBoolean;
  }
  
  private boolean c(Element paramElement, XMLTypeElement paramXMLTypeElement, boolean paramBoolean) throws XMLException {
    boolean bool = true;
    String str1 = paramElement.getNamespaceURI();
    String str2 = paramElement.getTagName();
    paramXMLTypeElement = (XMLTypeElement)paramXMLTypeElement.getChild("0");
    if (paramXMLTypeElement == null)
      return false; 
    int i = paramXMLTypeElement.getChildCount();
    for (byte b1 = 0; b1 < i; b1++) {
      String str = "" + b1;
      XMLTypeElement xMLTypeElement = (XMLTypeElement)paramXMLTypeElement.getChild(str);
      if (xMLTypeElement == null)
        return false; 
      xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(av.a(str1, str2));
      if (xMLTypeElement == null) {
        paramBoolean = false;
      } else {
        bd bd = xMLTypeElement.c();
        if (bd != null) {
          this.b.j(bd.b(null));
          this.b.a(bd.a(null));
        } else {
          NodeList nodeList = paramElement.getChildNodes();
          int j = nodeList.getLength();
          bool = false;
          for (byte b2 = 0; !bool && b2 < j; b2++) {
            Node node = nodeList.item(b2);
            if (node.getNodeType() == 1)
              bool = d((Element)node, xMLTypeElement, paramBoolean); 
          } 
          paramBoolean = bool;
        } 
      } 
    } 
    return paramBoolean;
  }
  
  private boolean d(Element paramElement, XMLTypeElement paramXMLTypeElement, boolean paramBoolean) throws XMLException {
    boolean bool = false;
    String str1 = paramElement.getNamespaceURI();
    String str2 = paramElement.getLocalName();
    paramXMLTypeElement = (XMLTypeElement)paramXMLTypeElement.getChild(av.a(str1, str2));
    if (paramXMLTypeElement == null) {
      paramBoolean = false;
    } else {
      bd bd = paramXMLTypeElement.c();
      if (bd != null) {
        paramBoolean = true;
        bool = true;
        String str3 = bd.b(null);
        String str4 = bd.a(null);
        if (str3 == null || str4 == null)
          throw new XMLException(77); 
        this.b.j(str3);
        this.b.a(str4);
        if (XMLRPCService.a) {
          Trace.parameter(Trace.MP4, 5, 7, 107, "library", this.b.y());
          Trace.parameter(Trace.MP4, 5, 7, 107, "program", this.b.d());
        } 
      } else {
        NodeList nodeList = paramElement.getChildNodes();
        int i = nodeList.getLength();
        for (byte b1 = 0; !bool && b1 < i; b1++) {
          Node node = nodeList.item(b1);
          if (node.getNodeType() == 1)
            bool = d((Element)node, paramXMLTypeElement, paramBoolean); 
        } 
        paramBoolean = bool;
      } 
    } 
    return paramBoolean;
  }
  
  private String a(Element paramElement) {
    String str = null;
    for (Node node = paramElement.getFirstChild(); node != null; node = node.getNextSibling()) {
      if (node.getNodeType() == 3)
        str = node.getNodeValue(); 
    } 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\c2.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */