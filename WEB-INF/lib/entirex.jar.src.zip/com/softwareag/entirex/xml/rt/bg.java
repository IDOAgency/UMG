package com.softwareag.entirex.xml.rt;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

public class bg {
  private static final String a = "&apos;";
  
  private static final String b = "&quot;";
  
  private static final String c = "&lt;";
  
  private static final String d = "&gt;";
  
  private static final String e = "&amp;";
  
  private static String f = System.getProperty("file.encoding");
  
  protected static String a(String paramString1, int paramInt, String paramString2, boolean paramBoolean, String paramString3) {
    if (paramInt >= 4 && paramInt <= 6) {
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
      if (paramInt == 5) {
        if (paramString2 == null)
          paramString2 = a3.ac; 
        simpleDateFormat.applyPattern(a3.ag);
        Date date = simpleDateFormat.parse(paramString1, new ParsePosition(0));
        simpleDateFormat.applyPattern(paramString2);
        paramString1 = simpleDateFormat.format(date);
      } 
      if (paramInt == 4) {
        if (paramString2 == null)
          paramString2 = a3.ab; 
        simpleDateFormat.applyPattern(a3.af);
        Date date = simpleDateFormat.parse(paramString1, new ParsePosition(0));
        simpleDateFormat.applyPattern(paramString2);
        paramString1 = simpleDateFormat.format(date);
      } 
      if (paramInt == 6) {
        if (paramString2 == null)
          paramString2 = a3.ae; 
        simpleDateFormat.applyPattern(a3.ag);
        Date date = simpleDateFormat.parse(paramString1, new ParsePosition(0));
        simpleDateFormat.applyPattern(paramString2);
        paramString1 = simpleDateFormat.format(date);
      } 
    } 
    String str = null;
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    int i = paramString1.length();
    try {
      eo eo = en.a(paramString3);
      for (byte b1 = 0; b1 < i; b1++) {
        String str1 = paramString1.substring(b1, b1 + true);
        byte[] arrayOfByte = str1.getBytes(paramString3);
        int j = arrayOfByte.length;
        if (j == 1 && arrayOfByte[0] < 128 && arrayOfByte[0] >= 0) {
          switch (arrayOfByte[0]) {
            case 38:
              byteArrayOutputStream.write(eo.j);
              break;
            case 60:
              byteArrayOutputStream.write(eo.h);
              break;
            case 62:
              byteArrayOutputStream.write(eo.i);
              break;
            case 39:
              byteArrayOutputStream.write(eo.f);
              break;
            case 34:
              byteArrayOutputStream.write(eo.g);
              break;
            default:
              byteArrayOutputStream.write(arrayOfByte[0] & 0xFF);
              break;
          } 
        } else {
          for (byte b2 = 0; b2 < j; b2++) {
            if (!paramBoolean) {
              byteArrayOutputStream.write(arrayOfByte[b2] & 0xFF);
            } else {
              byteArrayOutputStream.write(("&#x" + Integer.toHexString(arrayOfByte[b2] & 0xFF) + ";").getBytes(paramString3));
            } 
          } 
        } 
      } 
      str = new String(byteArrayOutputStream.toByteArray(), paramString3);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
    
    } catch (IOException iOException) {}
    return str;
  }
  
  public static String a(c3 paramc3) { return a(paramc3, false, f); }
  
  public static String a(dd paramdd) { return a(paramdd, false, f); }
  
  public static String a(c3 paramc3, boolean paramBoolean, String paramString) {
    XMLTypeElement xMLTypeElement = paramc3.d();
    String str1 = paramc3.c();
    int i = xMLTypeElement.getInternalDataType();
    String str2 = xMLTypeElement.getInternalDataFormat();
    return a(str1, i, str2, paramBoolean, paramString);
  }
  
  public static String a(dd paramdd, boolean paramBoolean, String paramString) {
    a8 a8 = paramdd.a();
    String str1 = paramdd.b();
    int i = a8.n();
    String str2 = a8.m();
    return a(str1, i, str2, paramBoolean, paramString);
  }
  
  public static String a(String paramString1, int paramInt, String paramString2) throws XMLException {
    if (paramInt >= 4 && paramInt <= 6) {
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
      if (paramInt == 5) {
        Date date = null;
        if (paramString2 == null) {
          paramString2 = a3.ac;
          simpleDateFormat.applyPattern(paramString2);
          date = simpleDateFormat.parse(paramString1, new ParsePosition(0));
          if (date == null) {
            paramString2 = a3.ad;
            simpleDateFormat.applyPattern(paramString2);
            date = simpleDateFormat.parse(paramString1, new ParsePosition(0));
            if (date == null) {
              paramString2 = a3.ae;
              simpleDateFormat.applyPattern(paramString2);
              date = simpleDateFormat.parse(paramString1, new ParsePosition(0));
            } 
          } 
        } else {
          simpleDateFormat.applyPattern(paramString2);
          date = simpleDateFormat.parse(paramString1, new ParsePosition(0));
        } 
        if (date == null)
          throw new XMLException(89); 
        simpleDateFormat.applyPattern(a3.ag);
        paramString1 = simpleDateFormat.format(date);
      } else if (paramInt == 4) {
        if (paramString2 == null)
          paramString2 = a3.ab; 
        simpleDateFormat.applyPattern(paramString2);
        Date date = simpleDateFormat.parse(paramString1, new ParsePosition(0));
        if (date == null)
          throw new XMLException(89); 
        simpleDateFormat.applyPattern(a3.ag);
        paramString1 = simpleDateFormat.format(date);
      } else if (paramInt == 6) {
        Date date = null;
        if (paramString2 == null) {
          paramString2 = a3.ae;
          if (date == null) {
            paramString2 = a3.ac;
            simpleDateFormat.applyPattern(paramString2);
            date = simpleDateFormat.parse(paramString1, new ParsePosition(0));
            if (date == null) {
              paramString2 = a3.ad;
              simpleDateFormat.applyPattern(paramString2);
              date = simpleDateFormat.parse(paramString1, new ParsePosition(0));
            } 
          } 
        } else {
          simpleDateFormat.applyPattern(paramString2);
          date = simpleDateFormat.parse(paramString1, new ParsePosition(0));
        } 
        if (date == null)
          throw new XMLException(89); 
        simpleDateFormat.applyPattern(a3.ag);
        paramString1 = simpleDateFormat.format(date);
      } 
    } 
    return paramString1;
  }
  
  private static String a(String paramString) {
    String str = "";
    if (paramString != null)
      if (paramString.equalsIgnoreCase("integer")) {
        str = "0";
      } else if (paramString.equalsIgnoreCase("float")) {
        str = "0.0";
      } else if (paramString.equalsIgnoreCase("number")) {
        str = "0.0";
      } else if (paramString.equalsIgnoreCase("boolean")) {
        str = "false";
      }  
    return str;
  }
  
  protected static boolean b(c3 paramc3) {
    boolean bool = false;
    if (paramc3.d().getNullValueSuppression() != 0) {
      XMLTypeElement xMLTypeElement = paramc3.d();
      int i = xMLTypeElement.getInternalDataType();
      String str1 = xMLTypeElement.getNullValue();
      String str2 = paramc3.c();
      bool = a(i, str2, str1);
    } 
    return bool;
  }
  
  protected static boolean b(dd paramdd) {
    boolean bool = false;
    a8 a8 = paramdd.a();
    if (!a8.k()) {
      String str1 = paramdd.b();
      int i = a8.n();
      String str2 = a8.e();
      bool = a(i, str1, str2);
    } 
    return bool;
  }
  
  protected static boolean a(int paramInt, String paramString1, String paramString2) {
    boolean bool = false;
    if (paramString2 == null)
      paramString2 = a3.at[paramInt]; 
    switch (paramInt) {
      case 0:
        if (paramString1.equals(paramString2))
          bool = true; 
        break;
      case 1:
        if (Integer.parseInt(paramString1) == Integer.parseInt(paramString2))
          bool = true; 
        break;
      case 2:
      case 3:
        try {
          if (Double.parseDouble(paramString1) == Double.parseDouble(paramString2))
            bool = true; 
        } catch (NumberFormatException numberFormatException) {
          new XMLException(7, numberFormatException.toString());
        } 
        break;
      case 4:
        if (paramString1.equals(paramString2))
          bool = true; 
        break;
      case 5:
      case 6:
        if (paramString1.equals(paramString2))
          bool = true; 
        break;
      case 7:
        if (paramString1.equals(paramString2))
          bool = true; 
        break;
      case 8:
        if (paramString1.equals(paramString2))
          bool = true; 
        break;
    } 
    return bool;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\bg.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */