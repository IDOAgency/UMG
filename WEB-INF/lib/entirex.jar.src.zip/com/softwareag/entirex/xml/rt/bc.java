package com.softwareag.entirex.xml.rt;

public interface com/softwareag/entirex/xml/rt/bc {
  String a();
  
  String b();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\bc.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */