package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.base.a4;
import com.softwareag.entirex.trace.Trace;
import java.io.BufferedReader;
import java.io.LineNumberReader;
import javax.servlet.ServletContext;
import javax.xml.parsers.SAXParser;
import org.xml.sax.InputSource;

public class a9 extends XMMInfo {
  public a9(String paramString) { this(paramString, null); }
  
  public a9(String paramString1, String paramString2) { super(paramString1, paramString2); }
  
  public a9(String paramString1, String paramString2, ServletContext paramServletContext) {
    this.f = Trace.on(5, this);
    if (this.f)
      Trace.checkpoint(Trace.CP4, 6, 23, 8, "XMMInfo ctor"); 
    this.a = null;
    this.b = null;
    a(paramString1, paramString2, paramServletContext);
  }
  
  private void a(String paramString1, String paramString2, ServletContext paramServletContext) {
    if (this.f)
      Trace.checkpoint(Trace.CP4, 6, 23, 8, "XMMInfo reading XMM file=" + paramString1); 
    ay ay = new ay();
    try {
      ar ar = new ar();
      ar.a(ay);
      SAXParserLoader sAXParserLoader;
      SAXParser sAXParser = (sAXParserLoader = new SAXParserLoader()).getSAXParser();
      a4 a4 = new a4(paramString1, paramString2, paramServletContext);
      BufferedReader bufferedReader = new BufferedReader(a4.i());
      ba ba = new ba(ar);
      sAXParser.parse(new InputSource(new LineNumberReader(bufferedReader)), ba);
      ay = ar.u();
    } catch (Exception exception) {}
    this.a = ay.b();
    this.b = ay.c();
    this.c = ay.d();
    this.d = ay.e();
    this.e = ay.f();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\a9.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */