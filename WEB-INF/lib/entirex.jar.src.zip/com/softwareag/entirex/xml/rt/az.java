package com.softwareag.entirex.xml.rt;

public class az extends a0 {
  public XMLTypeElement a() throws XMLException {
    XMLTypeElement xMLTypeElement1;
    XMLTypeElement xMLTypeElement2;
    XMLTypeElement xMLTypeElement3 = (xMLTypeElement2 = (xMLTypeElement1 = new XMLTypeElement("0")).register(xMLTypeElement1, "", "", "0", 1, 1)).register(xMLTypeElement2, "", "", "Fault", 1, 1);
    xMLTypeElement3.a("en", "0", "1", null);
    XMLTypeElement xMLTypeElement4 = XMLTypeElement.register(xMLTypeElement3, "", "", "faultcode", 1, 1);
    xMLTypeElement4.setContextInfo("faultcode");
    XMLTypeElement xMLTypeElement5 = XMLTypeElement.register(xMLTypeElement3, "", "", "faultstring", 1, 1);
    xMLTypeElement5.setContextInfo("faultstring");
    XMLTypeElement xMLTypeElement6 = XMLTypeElement.register(xMLTypeElement3, "", "", "faultactor", 1, 1);
    xMLTypeElement6.setContextInfo("faultactor");
    XMLTypeElement xMLTypeElement7 = XMLTypeElement.register(xMLTypeElement3, "", "", "detail", 0, 1);
    xMLTypeElement7.setNullValueSuppression(1);
    return xMLTypeElement1;
  }
  
  public String[][] b() { return new String[][] { { "Fault/faultcode", "0/0@@faultcode" }, { "Fault/faultstring", "0/0@@faultstring" }, { "Fault/faultactor", "0/0@@faultactor" }, { "Fault/detail", "0/0@@detail" } }; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\az.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */