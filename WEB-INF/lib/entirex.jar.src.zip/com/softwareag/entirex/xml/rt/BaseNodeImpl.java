package com.softwareag.entirex.xml.rt;

import java.util.Hashtable;
import java.util.Vector;

public class BaseNodeImpl implements BaseNode {
  protected Vector a = new Vector();
  
  int b = 0;
  
  protected Hashtable c = new Hashtable();
  
  protected String d;
  
  protected BaseNode e;
  
  public BaseNodeImpl() { this(null, null); }
  
  public BaseNodeImpl(String paramString) { this(null, paramString); }
  
  public BaseNodeImpl(BaseNode paramBaseNode, String paramString) {
    this.d = paramString;
    this.e = paramBaseNode;
  }
  
  public String getName() { return this.d; }
  
  public void setName(String paramString) { this.d = paramString; }
  
  public void setParent(BaseNode paramBaseNode) { this.e = paramBaseNode; }
  
  public BaseNode getParent() { return this.e; }
  
  protected void b() {
    this.a.removeAllElements();
    this.c.clear();
    this.b = 0;
  }
  
  public BaseNode addChild(BaseNode paramBaseNode, boolean paramBoolean) {
    BaseNode baseNode = getChild(paramBaseNode.getName());
    if (paramBoolean && baseNode != null) {
      paramBaseNode = baseNode;
    } else {
      paramBaseNode.setParent(this);
      this.b++;
      this.a.addElement(paramBaseNode);
      this.c.put(paramBaseNode.getName(), paramBaseNode);
    } 
    return paramBaseNode;
  }
  
  public BaseNode addChild(BaseNode paramBaseNode) {
    paramBaseNode.setParent(this);
    this.b++;
    this.a.addElement(paramBaseNode);
    this.c.put(paramBaseNode.getName(), paramBaseNode);
    return paramBaseNode;
  }
  
  public BaseNode addRecursiveChild(BaseNode paramBaseNode) {
    BaseNode baseNode = getChild(paramBaseNode.getName());
    if (baseNode != null) {
      int i = paramBaseNode.getChildCount();
      for (byte b1 = 0; b1 < i; b1++)
        baseNode.addRecursiveChild(paramBaseNode.getChild(b1)); 
    } else {
      paramBaseNode.setParent(this);
      this.b++;
      this.a.addElement(paramBaseNode);
      this.c.put(paramBaseNode.getName(), paramBaseNode);
    } 
    return paramBaseNode;
  }
  
  public BaseNode getChild(String paramString) { return (BaseNode)this.c.get(paramString); }
  
  public int getChildCount() { return this.b; }
  
  public BaseNode getChild(int paramInt) {
    BaseNode baseNode = null;
    if (this.a != null && this.b > 0)
      baseNode = (BaseNode)this.a.elementAt(paramInt); 
    return baseNode;
  }
  
  public int getChildCount(String paramString) {
    byte b1 = 0;
    if (this.c.get(paramString) != null)
      b1 = 1; 
    return b1;
  }
  
  public BaseNode getChild(String paramString, int paramInt) { return (BaseNode)this.c.get(paramString); }
  
  public Vector getChildren() { return this.a; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\BaseNodeImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */