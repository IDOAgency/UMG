package com.softwareag.entirex.xml.rt;

final class cs {
  public static final int a = 0;
  
  public static final int b = 1;
  
  public static final int c = 2;
  
  public static final int d = 3;
  
  private static String[] e = new String[3];
  
  private static byte[][] f;
  
  private static int g;
  
  private String h;
  
  private byte[] i;
  
  public static final int a() { return g; }
  
  public static final int a(int paramInt) {
    int j = 0;
    boolean bool = false;
    j = paramInt / 3 * 4;
    switch (paramInt % 3) {
      case 1:
        j += 2;
        g = 2;
        return j;
      case 2:
        j += 3;
        g = 1;
        return j;
    } 
    j += 0;
    g = 0;
    return j;
  }
  
  public static final int b(int paramInt) {
    int j = 0;
    j = paramInt / 4 * 3;
    if (paramInt % 4 != 0)
      throw new XMLException(60, "Illegal length."); 
    return j;
  }
  
  public static final int a(String paramString) throws XMLException {
    byte b1 = 0;
    int j = paramString.length();
    for (int k = j - 1; k >= 0 && paramString.charAt(k) == '='; k--)
      b1++; 
    if (b1 > 2)
      throw new XMLException(60, "Illegal use of '='."); 
    return b1;
  }
  
  cs() { this(2); }
  
  cs(int paramInt) {
    this.h = e[paramInt];
    this.i = f[paramInt];
  }
  
  String a(byte[] paramArrayOfByte) {
    byte b3 = 0;
    int j = 0;
    int k = 0;
    byte b2 = 0;
    StringBuffer stringBuffer = new StringBuffer();
    j = a(paramArrayOfByte.length);
    k = a();
    byte b1;
    for (b1 = 0; b1 < paramArrayOfByte.length; b1++) {
      byte b5 = paramArrayOfByte[b1];
      byte b4 = 6 - b2 % 6;
      b3 |= (b5 & 0xFF) >>> 2 + b2;
      stringBuffer.append(this.h.charAt(b3 & 0x3F));
      b2 = 8 - b4;
      b3 = b5 << 6 - b2 & 0x3F;
      if (b2 == 6) {
        stringBuffer.append(this.h.charAt(b3 & 0x3F));
        b3 = 0;
        b2 = 0;
      } 
    } 
    if (b2 > 0) {
      stringBuffer.append(this.h.charAt(b3 & 0x3F));
      b3 = 0;
      b2 = 0;
    } 
    for (b1 = 0; b1 < k; b1++)
      stringBuffer.append("="); 
    return stringBuffer.toString();
  }
  
  byte[] b(String paramString) {
    byte b1 = 0;
    byte b2 = 0;
    byte b3 = 0;
    byte b4 = 0;
    b3 = 0;
    byte[] arrayOfByte = null;
    try {
      int j = paramString.length();
      int k = b(j);
      int m = a(paramString);
      k -= m;
      j -= m;
      byte[] arrayOfByte1 = new byte[k + 1];
      b2 = 0;
      for (b1 = 0; b1 < j; b1++) {
        b4 = 8 - b3 % 8;
        byte b5 = this.i[paramString.charAt(b1)];
        if (b4 <= 6) {
          arrayOfByte1[b2] = (byte)(arrayOfByte1[b2] | b5 >> 6 - b4);
          if (++b2 < arrayOfByte1.length)
            arrayOfByte1[b2] = (byte)(b5 << 8 - 6 - b4); 
        } else {
          arrayOfByte1[b2] = (byte)(b5 << 2);
        } 
        b3 = (b3 + 6) % 24;
      } 
      arrayOfByte = new byte[k];
      System.arraycopy(arrayOfByte1, 0, arrayOfByte, 0, k);
    } catch (XMLException xMLException) {}
    return arrayOfByte;
  }
  
  private static void a(String paramString, byte paramByte) {
    String str = "";
    byte b1;
    boolean bool;
    for (b1 = bool; b1 < 8; b1++) {
      byte b2 = (byte)(paramByte << b1);
      if (b1 % 8 == 0)
        str = str + ' '; 
      str = str + (((b2 & 0x80) != 0) ? 49 : 48);
    } 
  }
  
  static  {
    e[0] = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_";
    e[1] = "+-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    e[2] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    f = new byte[e.length][65535];
    for (byte b1 = 0; b1 < e.length; b1++) {
      String str = e[b1];
      for (byte b2 = 0; b2 < 64; b2 = (byte)(b2 + 1))
        f[b1][str.charAt(b2)] = b2; 
    } 
    g = 0;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\cs.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */