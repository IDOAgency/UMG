package com.softwareag.entirex.xml.rt;

public class aw {
  protected String a = null;
  
  protected String b = null;
  
  public aw(String paramString) { this.b = paramString; }
  
  public aw(String paramString1, String paramString2) {
    this.a = paramString1;
    this.b = paramString2;
  }
  
  public String a() {
    String str = this.a;
    if (str == null)
      str = ""; 
    return str;
  }
  
  public void a(String paramString) { this.a = paramString; }
  
  public String b() {
    String str = this.b;
    if (str == null)
      str = ""; 
    return str;
  }
  
  public void b(String paramString) { this.b = paramString; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\aw.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */