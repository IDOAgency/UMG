package com.softwareag.entirex.xml.rt;

public class dg {
  private int a;
  
  private int b = 0;
  
  private int c = -1;
  
  private dg() {}
  
  protected dg(int paramInt) { this.a = paramInt; }
  
  protected dg(int paramInt1, int paramInt2) {
    this.a = paramInt1;
    this.b = paramInt2;
  }
  
  protected dg(int paramInt1, int paramInt2, int paramInt3) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
  }
  
  protected int a() { return this.a; }
  
  protected int b() { return this.b; }
  
  protected int c() { return this.c; }
  
  protected void a(int paramInt) { this.a = paramInt; }
  
  protected void a(int paramInt1, int paramInt2, int paramInt3) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
  }
  
  protected void b(int paramInt) { this.b = paramInt; }
  
  protected void c(int paramInt) { this.c = paramInt; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\dg.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */