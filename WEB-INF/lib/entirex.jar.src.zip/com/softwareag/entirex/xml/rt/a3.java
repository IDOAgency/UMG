package com.softwareag.entirex.xml.rt;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

public class a3 {
  protected static boolean a = true;
  
  protected static boolean b = false;
  
  protected static final boolean c = true;
  
  protected static final boolean d = false;
  
  protected static final boolean e = true;
  
  protected static final boolean f = false;
  
  protected static String g = "true";
  
  protected static String h = "false";
  
  protected static String i = "localhost:1971";
  
  protected static String j = "RPC/SRV1/CALLNAT";
  
  protected static String k = "";
  
  protected static String l = "SetName";
  
  protected static String m = "xmluser";
  
  protected static String n = "xmlrpcuser";
  
  protected static String o = "false";
  
  protected static String p = "0";
  
  protected static String q = "false";
  
  protected static final String r = "faultactor";
  
  protected static final String s = "faultcode";
  
  protected static final String t = "faultstring";
  
  protected static final String u = "detail";
  
  protected static String v = "'http://schemas.xmlsoap.org/soap/envelope'Envelope";
  
  protected static String w = "'http://schemas.xmlsoap.org/soap/envelope'Header";
  
  protected static String x = "'http://schemas.xmlsoap.org/soap/envelope'Body";
  
  protected static String y = "'http://schemas.xmlsoap.org/soap/envelope'Fault";
  
  protected static String z = "http://schemas.xmlsoap.org/soap/encoding";
  
  protected static String aa = "'http://schemas.xmlsoap.org/soap/encoding'arrayType";
  
  protected static String ab = "yyyy-MM-dd";
  
  protected static String ac = "yyyy-MM-dd'T'HH:mm:ss";
  
  protected static String ad = "yyyy-MM-dd HH:mm:ss";
  
  protected static String ae = "HH:mm:ss";
  
  protected static String af = "yyyyMMdd";
  
  protected static String ag = "yyyyMMddHHmmssS";
  
  protected static String ah = "20000101";
  
  protected static String ai = "200001010000000";
  
  protected static final int aj = 0;
  
  protected static final int ak = 0;
  
  protected static final int al = 1;
  
  protected static final int am = 2;
  
  protected static final int an = 3;
  
  protected static final int ao = 4;
  
  protected static final int ap = 5;
  
  protected static final int aq = 6;
  
  protected static final int ar = 7;
  
  protected static final int as = 8;
  
  protected static String[] at = { "", "0", "0.0", "0.0", "", "", "", "false", "" };
  
  public static final int au = 0;
  
  public static final int av = 1;
  
  public static final int aw = 2;
  
  public static final int ax = 3;
  
  public static final int ay = 4;
  
  protected static final int az = 0;
  
  protected static final int a0 = 1;
  
  protected static final int a1 = 2;
  
  protected static final int a2 = 3;
  
  protected static final String a3 = "http://www.w3.org/XML/1998/namespace";
  
  protected static final String a4 = "'http://www.w3.org/XML/1998/namespace'space";
  
  protected static final String a5 = "http://schemas.xmlsoap.org/soap/envelope";
  
  protected static final String a6 = "http://schemas.xmlsoap.org/soap/envelope/";
  
  protected static final String a7 = "http://www.w3.org/2002/06/soap-envelope";
  
  protected static final int a8 = 0;
  
  protected static final int a9 = 1;
  
  protected static int a(String paramString) {
    byte b1 = 0;
    if (paramString != null)
      if (paramString.startsWith("i")) {
        b1 = 1;
      } else if (paramString.equals("float")) {
        b1 = 2;
      } else if (paramString.equals("number")) {
        b1 = 3;
      } else if (paramString.equals("string")) {
        b1 = 0;
      } else if (paramString.equals("date")) {
        b1 = 4;
      } else if (paramString.equals("dateTime")) {
        b1 = 5;
      } else if (paramString.equals("time")) {
        b1 = 6;
      } else if (paramString.equals("binary")) {
        b1 = 8;
      }  
    return b1;
  }
  
  protected static String a(String paramString1, int paramInt, String paramString2) {
    if (paramString1 != null && paramString1.length() != 0)
      try {
        if (paramInt >= 4 && paramInt <= 6) {
          SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
          if (paramInt == 4) {
            if (paramString2 == null)
              paramString2 = ab; 
            simpleDateFormat.applyPattern(paramString2);
            Date date = simpleDateFormat.parse(paramString1, new ParsePosition(0));
            if (date == null)
              throw new XMLException(89); 
            simpleDateFormat.applyPattern(af);
            paramString1 = simpleDateFormat.format(date);
          } else {
            paramString1 = bg.a(paramString1, paramInt, paramString2);
          } 
        } 
      } catch (XMLException xMLException) {} 
    return paramString1;
  }
  
  protected static String b(String paramString) {
    if (paramString != null) {
      paramString = paramString.replace('-', '_');
      paramString = paramString.replace('$', '_');
      paramString = paramString.replace('#', '_');
      paramString = paramString.replace('&', '_');
      paramString = paramString.replace('@', '_');
      paramString = paramString.replace('+', '_');
      paramString = paramString.replace('/', '_');
      paramString = paramString.toUpperCase();
    } 
    return paramString;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\a3.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */