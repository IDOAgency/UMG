package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;

public class da extends db {
  private static final String a = "faultactor";
  
  private static final String b = "faultcode";
  
  private static final String c = "faultstring";
  
  private static final String d = "detail";
  
  private static final String e = "";
  
  private static final String f = "";
  
  private static final String g = "id";
  
  private static final String h = "href";
  
  private static final String i = "arrayType";
  
  private static final String j = "http://schemas.xmlsoap.org/soap/encoding/";
  
  protected da() {
    super.f = "id";
    super.g = "href";
    super.i = "arrayType";
    super.h = "http://schemas.xmlsoap.org/soap/encoding/";
  }
  
  protected da(c0 paramc0) {
    super(paramc0);
    super.f = "id";
    super.g = "href";
    super.i = "arrayType";
    super.h = "http://schemas.xmlsoap.org/soap/encoding/";
  }
  
  public XMLTypeElement c() {
    XMLTypeElement xMLTypeElement1;
    XMLTypeElement xMLTypeElement2 = (xMLTypeElement1 = new XMLTypeElement("SOAP_FAULT")).register(xMLTypeElement1, "SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/", "Envelope", 1, 1);
    xMLTypeElement2.addNameSpaceDefinition("SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
    xMLTypeElement2.addNameSpaceDefinition("xsd", "http://www.w3.org/2001/XMLSchema");
    xMLTypeElement2.addNameSpaceDefinition("xsi", "http://www.w3.org/2001/XMLSchema-instance");
    xMLTypeElement2.addNameSpaceDefinition("SOAP-ENC", "http://schemas.xmlsoap.org/soap/encoding/");
    xMLTypeElement2.addAttribute("SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/", "encodingStyle", "http://schemas.xmlsoap.org/soap/encoding/", 0);
    XMLTypeElement xMLTypeElement3 = XMLTypeElement.register(xMLTypeElement2, "SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/", "Header", 0, 1);
    xMLTypeElement3.setNullValueSuppression(1);
    XMLTypeElement xMLTypeElement4;
    XMLTypeElement xMLTypeElement5;
    XMLTypeElement xMLTypeElement6 = (xMLTypeElement5 = (xMLTypeElement4 = XMLTypeElement.register(xMLTypeElement2, "SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/", "Body", 1, 1)).register(xMLTypeElement4, "SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/", "Fault", 1, 1)).register(xMLTypeElement5, "", "", "faultcode", 1, 1);
    xMLTypeElement6.setContextInfo("faultcode");
    XMLTypeElement xMLTypeElement7 = XMLTypeElement.register(xMLTypeElement5, "", "", "faultstring", 1, 1);
    xMLTypeElement7.setContextInfo("faultstring");
    XMLTypeElement xMLTypeElement8 = XMLTypeElement.register(xMLTypeElement5, "", "", "faultactor", 1, 1);
    xMLTypeElement8.setContextInfo("faultactor");
    XMLTypeElement xMLTypeElement9 = XMLTypeElement.register(xMLTypeElement5, "", "", "detail", 0, 1);
    xMLTypeElement9.setNullValueSuppression(1);
    return xMLTypeElement1;
  }
  
  protected void a() {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M3, 5, 33, 105); 
    if (super.c.b(a3.w) > 0) {
      super.c.a(a3.w);
      int k = super.c.n();
      for (byte b1 = 0; b1 < k; b1++) {
        super.c.a(b1);
        if (super.c.i().equals("SOAPAction")) {
          String str = super.c.h();
          if (str.charAt(0) != '"' && str.charAt(str.length() - 1) != '"')
            str = '"' + str + '"'; 
          super.c.a(super.c.i(), str);
          super.c.a(true);
        } 
        super.c.l();
      } 
      super.c.l();
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M3, 5, 33, 105); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\da.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */