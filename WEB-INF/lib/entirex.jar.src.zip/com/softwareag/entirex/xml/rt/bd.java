package com.softwareag.entirex.xml.rt;

import java.util.Enumeration;
import java.util.Hashtable;

public class bd {
  protected static final String a = "en";
  
  protected static final String b = "true";
  
  protected static final String c = "ev";
  
  protected static final String d = "an";
  
  protected static final String e = "av";
  
  int f = 0;
  
  private String g = null;
  
  private String h = null;
  
  private Hashtable i = null;
  
  private Hashtable j = null;
  
  protected bd(String paramString1, String paramString2, String paramString3) { this(paramString1, paramString2, paramString3, null); }
  
  protected bd(String paramString1, String paramString2, String paramString3, String paramString4) {
    if (paramString1.equals("true") || paramString1.equals("en")) {
      this.f = 1;
      this.g = paramString2;
      this.h = paramString3;
    } else if (paramString1.equals("ev")) {
      this.f = 3;
      this.j = new Hashtable();
      this.i = new Hashtable();
      this.j.put(paramString4, paramString2);
      this.i.put(paramString4, paramString3);
    } else if (paramString1.equals("an")) {
      this.f = 2;
      this.g = paramString2;
      this.h = paramString3;
    } else if (paramString1.equals("av")) {
      this.f = 4;
      this.j = new Hashtable();
      this.i = new Hashtable();
      this.j.put(paramString4, paramString2);
      this.i.put(paramString4, paramString3);
    } 
  }
  
  protected void a(String paramString1, String paramString2, String paramString3, String paramString4) {
    if (paramString1.equals("ev") || paramString1.equals("av")) {
      this.j.put(paramString4, paramString2);
      this.i.put(paramString4, paramString3);
    } else {
      throw new XMLException(27, "Redefintion of program mapping");
    } 
  }
  
  protected void a(bd parambd) {
    this.f = parambd.f;
    this.g = parambd.g;
    this.h = parambd.h;
    this.j = parambd.j;
    this.i = parambd.i;
  }
  
  protected String a(String paramString) {
    String str = null;
    if (this.f == 1 || this.f == 2) {
      str = this.h;
    } else {
      str = (String)this.i.get(paramString);
    } 
    return str;
  }
  
  protected String b(String paramString) {
    String str = null;
    if (this.f == 1 || this.f == 2) {
      str = this.g;
    } else {
      str = (String)this.j.get(paramString);
    } 
    return str;
  }
  
  void a() {
    Enumeration enumeration = this.j.keys();
    while (enumeration.hasMoreElements())
      System.out.println("KEY: " + (String)enumeration.nextElement()); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\bd.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */