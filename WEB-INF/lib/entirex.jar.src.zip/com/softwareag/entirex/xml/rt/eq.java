package com.softwareag.entirex.xml.rt;

import java.util.Enumeration;
import java.util.Hashtable;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class eq {
  private Hashtable a = new Hashtable();
  
  private int b = 1;
  
  public er a() {
    er er = null;
    String str;
    for (str = "" + this.b; this.a.get(str) != null; str = "" + this.b)
      this.b++; 
    er = new er(str);
    this.a.put(str, er);
    return er;
  }
  
  public er a(String paramString) {
    er er = null;
    if (this.a.get(paramString) == null) {
      er = new er(paramString);
      this.a.put(paramString, er);
    } 
    return er;
  }
  
  public er a(String paramString, Element paramElement) {
    er er = null;
    if (this.a.get(paramString) == null) {
      er = new er(paramString);
      this.a.put(paramString, er);
      er.a(paramElement);
    } 
    return er;
  }
  
  public er b(String paramString) {
    er er = null;
    if (paramString != null)
      er = (er)this.a.get(paramString); 
    return er;
  }
  
  public void b() {
    this.a.clear();
    this.b = 1;
  }
  
  public void c() {
    Enumeration enumeration = this.a.keys();
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      er er = (er)this.a.get(str);
      Element element = er.a();
      a(element);
    } 
  }
  
  public void a(Element paramElement, String paramString) {
    paramString = paramString.substring(1);
    er er = (er)this.a.get(paramString);
    Element element = er.a();
    for (Node node = element.getFirstChild(); node != null; node = node.getNextSibling()) {
      if (node.getNodeType() == 1)
        paramElement.appendChild(node.cloneNode(true)); 
    } 
    byte b1 = 0;
    NamedNodeMap namedNodeMap = element.getAttributes();
    int i = namedNodeMap.getLength();
    for (b1 = 0; b1 < i; b1++) {
      Node node1 = namedNodeMap.item(b1);
      if (node1.getNodeType() == 2) {
        Attr attr = (Attr)node1;
        String str1 = attr.getPrefix();
        String str2 = attr.getLocalName();
        String str3 = attr.getNamespaceURI();
        String str4 = attr.getValue();
        if (str1 == null) {
          str1 = "";
        } else if (str1.equals("xml")) {
          str3 = "http://www.w3.org/XML/1998/namespace";
        } 
        if (str3 == null)
          str3 = ""; 
        if (str1.equals("")) {
          paramElement.setAttributeNS(str3, str2, str4);
        } else {
          paramElement.setAttributeNS(str3, str1 + ":" + str2, str4);
        } 
      } 
    } 
  }
  
  private void a(Element paramElement) {
    byte b1 = 0;
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    for (b1 = 0; b1 < namedNodeMap.getLength(); b1++) {
      Node node1 = namedNodeMap.item(b1);
      if (node1.getNodeType() == 2) {
        Attr attr = (Attr)node1;
        String str1 = attr.getNamespaceURI();
        String str2 = attr.getLocalName();
        if (str1 == null && str2.equals("href")) {
          String str = attr.getValue();
          str = str.substring(1);
          er er = (er)this.a.get(str);
          Element element = er.a();
          for (Node node2 = element.getFirstChild(); node2 != null; node2 = node2.getNextSibling()) {
            if (node2.getNodeType() == 1)
              paramElement.appendChild(node2.cloneNode(true)); 
          } 
          NamedNodeMap namedNodeMap1 = element.getAttributes();
          int i = namedNodeMap1.getLength();
          for (b1 = 0; b1 < i; b1++) {
            Node node3 = namedNodeMap1.item(b1);
            if (node3.getNodeType() == 2) {
              Attr attr1 = (Attr)node3;
              String str3 = attr1.getPrefix();
              String str4 = attr1.getLocalName();
              String str5 = attr1.getNamespaceURI();
              String str6 = attr1.getValue();
              if (str3 == null) {
                str3 = "";
              } else if (str3.equals("xml")) {
                str5 = "http://www.w3.org/XML/1998/namespace";
              } 
              if (str5 == null)
                str5 = ""; 
              if (str3.equals("")) {
                paramElement.setAttributeNS(str5, str4, str6);
              } else {
                paramElement.setAttributeNS(str5, str3 + ":" + str4, str6);
              } 
            } 
          } 
        } 
      } 
    } 
    for (Node node = paramElement.getFirstChild(); node != null; node = node.getNextSibling()) {
      if (node.getNodeType() == 1)
        a((Element)node); 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\eq.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */