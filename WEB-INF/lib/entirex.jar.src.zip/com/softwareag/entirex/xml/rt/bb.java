package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.Dump;
import com.softwareag.entirex.base.EntireXClassLoader;
import com.softwareag.entirex.trace.Trace;
import java.io.File;
import java.util.ArrayList;

public class bb {
  private String a = null;
  
  private XMLAdapter b = null;
  
  private ar c = null;
  
  private boolean d = false;
  
  private a8 e = null;
  
  public bb(String paramString, ar paramar, boolean paramBoolean) {
    this.a = paramString;
    this.c = paramar;
    this.d = paramBoolean;
  }
  
  public bb(XMLAdapter paramXMLAdapter, ar paramar, boolean paramBoolean) {
    this.b = paramXMLAdapter;
    this.c = paramar;
    this.d = paramBoolean;
  }
  
  public void a() throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 24, 93); 
    if (this.b == null)
      this.b = a(this.a); 
    if (this.b != null && this.b instanceof XMLAdapter2) {
      if (this.a == null)
        this.a = this.b.getClass().getName(); 
      a((XMLAdapter2)this.b);
    } else {
      if (this.b != null && this.b instanceof XMLAdapter)
        throw new XMLException(29, "Adapter version not longer supported."); 
      throw new XMLException(30);
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 24, 93); 
  }
  
  protected XMLAdapter a(String paramString) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 24, 7, "name", paramString); 
    if (paramString == null)
      throw new XMLException(30); 
    try {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP4, 5, 24, 7, "trying to get adapter - Class.forName"); 
      Object object = null;
      if (paramString.toLowerCase().endsWith(".class") || paramString.indexOf("/") != -1 || paramString.indexOf(File.separator) != -1) {
        EntireXClassLoader entireXClassLoader = new EntireXClassLoader(paramString);
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP4, 5, 24, 7, "trying to get adapter - class.newInstance"); 
        object = entireXClassLoader.getObject(null, null);
      } else {
        Class clazz = Class.forName(paramString);
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP4, 5, 24, 7, "trying to get adapter - class.newInstance"); 
        if (clazz != null) {
          object = clazz.newInstance();
        } else {
          throw new XMLException(28, "( adapter: " + paramString + " )");
        } 
      } 
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP4, 5, 24, 7, "trying to get adapter - newInstance successful"); 
      if (object instanceof XMLAdapter)
        return (XMLAdapter)object; 
      throw new XMLException(29, "( adapter: " + paramString + " )");
    } catch (Exception exception) {
      if (XMLRPCService.a) {
        Trace.checkpoint(Trace.CP2, 5, 24, 7, exception.getClass().getName() + ": " + exception.toString());
        try {
          Trace.checkpoint(Trace.CP2, 5, 24, 7, "Current Classpath = " + System.getProperty("java.class.path"));
        } catch (SecurityException securityException) {}
      } 
      throw new XMLException(28, "( adapter " + paramString + " )");
    } catch (NoSuchMethodError noSuchMethodError) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 24, 7, "Problems while loading XmlAdapter " + paramString); 
      return null;
    } finally {
      if (XMLRPCService.a)
        Trace.leaveMethod(Trace.M2, 5, 24, 7); 
    } 
  }
  
  private void a(XMLAdapter2 paramXMLAdapter2) throws XMLException {
    if (XMLRPCService.a) {
      Trace.enterMethod(Trace.M3, 5, 24, 93);
      if (paramXMLAdapter2 != null)
        Trace.parameter(Trace.MP4, 5, 24, 93, "XmlAdapter2", paramXMLAdapter2.getClass().getName()); 
    } 
    int i = 0;
    BaseNode baseNode1 = null;
    try {
      baseNode1 = paramXMLAdapter2.getRPCTypeRoot();
    } catch (NoSuchMethodError noSuchMethodError) {
      if (XMLRPCService.a) {
        Trace.checkpoint(Trace.CP1, 5, 24, 93, "Problems while reading XmlAdapter2=" + paramXMLAdapter2.getClass().getName());
        Trace.leaveMethod(Trace.M4, 5, 24, 93);
      } 
      return;
    } 
    BaseNode baseNode2 = null;
    BaseNode baseNode3 = null;
    BaseNode baseNode4 = paramXMLAdapter2.getXMLTypeFaultRoot();
    MapEntries mapEntries = null;
    if (this.d) {
      baseNode2 = paramXMLAdapter2.getXMLTypeOutgoingRoot();
      baseNode3 = paramXMLAdapter2.getXMLTypeIncomingRoot();
    } else {
      baseNode2 = paramXMLAdapter2.getXMLTypeIncomingRoot();
      baseNode3 = paramXMLAdapter2.getXMLTypeOutgoingRoot();
    } 
    if (this.d) {
      mapEntries = this.b.getOutMappings();
    } else {
      mapEntries = this.b.getInMappings();
    } 
    if (mapEntries != null) {
      i = mapEntries.getEntryCount();
      for (byte b1 = 0; b1 < i; b1++) {
        MapEntries.com/softwareag/entirex/xml/rt/bc com/softwareag/entirex/xml/rt/bc = mapEntries.getEntry(b1);
        if (this.d) {
          this.c.c(com/softwareag/entirex/xml/rt/bc.b(), com/softwareag/entirex/xml/rt/bc.a());
        } else {
          this.c.c(com/softwareag/entirex/xml/rt/bc.a(), com/softwareag/entirex/xml/rt/bc.b());
        } 
      } 
    } 
    if (this.d) {
      mapEntries = this.b.getInMappings();
    } else {
      mapEntries = this.b.getOutMappings();
    } 
    if (mapEntries != null) {
      i = mapEntries.getEntryCount();
      for (byte b1 = 0; b1 < i; b1++) {
        MapEntries.com/softwareag/entirex/xml/rt/bc com/softwareag/entirex/xml/rt/bc = mapEntries.getEntry(b1);
        if (this.d) {
          this.c.b(com/softwareag/entirex/xml/rt/bc.b(), com/softwareag/entirex/xml/rt/bc.a());
        } else {
          this.c.b(com/softwareag/entirex/xml/rt/bc.a(), com/softwareag/entirex/xml/rt/bc.b());
        } 
      } 
    } 
    a(baseNode1, baseNode2, baseNode3, baseNode4);
    if (baseNode1 != null) {
      i = baseNode1.getChildCount();
      for (byte b1 = 0; b1 < i; b1++) {
        BaseNode baseNode = baseNode1.getChild(b1);
        this.c.a(baseNode);
      } 
    } 
    if (baseNode2 != null) {
      i = baseNode2.getChildCount();
      for (byte b1 = 0; b1 < i; b1++) {
        BaseNode baseNode = baseNode2.getChild(b1);
        this.c.c(baseNode);
      } 
    } 
    if (baseNode3 != null) {
      i = baseNode3.getChildCount();
      for (byte b1 = 0; b1 < i; b1++) {
        BaseNode baseNode = baseNode3.getChild(b1);
        this.c.b(baseNode);
      } 
    } 
    if (baseNode4 != null) {
      i = baseNode4.getChildCount();
      if (this.d) {
        for (byte b2 = 0; b2 < i; b2++) {
          BaseNode baseNode = baseNode4.getChild(b2);
          this.c.e(baseNode);
        } 
      } else {
        for (byte b2 = 0; b2 < i; b2++) {
          BaseNode baseNode = baseNode4.getChild(b2);
          this.c.d(baseNode);
        } 
      } 
      ArrayList arrayList = new ArrayList();
      arrayList.add("dummy");
      arrayList.add("dummy");
      int j = baseNode4.getChildCount();
      for (byte b1 = 0; b1 < j; b1++) {
        BaseNode baseNode = baseNode4.getChild(b1);
        arrayList.set(0, baseNode.getName());
        int k = baseNode.getChildCount();
        for (byte b2 = 0; b2 < k; b2++) {
          BaseNode baseNode5 = baseNode.getChild(b2);
          arrayList.set(1, baseNode5.getName());
          a(arrayList, baseNode5, 2, this.d);
        } 
      } 
    } 
    if (this.d) {
      b(baseNode1, baseNode2, baseNode3);
    } else {
      b(baseNode1, baseNode3, baseNode2);
    } 
    if (this.d) {
      c(baseNode1, baseNode2);
      d(baseNode1, baseNode3);
    } else {
      c(baseNode1, baseNode3);
      d(baseNode1, baseNode2);
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M3, 5, 24, 93); 
  }
  
  private void a(ArrayList paramArrayList, BaseNode paramBaseNode, int paramInt, boolean paramBoolean) throws XMLException {
    int i = 0;
    int j = paramBaseNode.getChildCount();
    for (byte b1 = 0; b1 < j; b1++) {
      XMLTypeElement xMLTypeElement = (XMLTypeElement)paramBaseNode.getChild(b1);
      String str1 = xMLTypeElement.getInternalName();
      i = paramArrayList.size();
      if (i <= paramInt) {
        paramArrayList.add(str1);
      } else {
        paramArrayList.set(paramInt, str1);
      } 
      String str2 = xMLTypeElement.getContextInfo();
      if (str2 != null) {
        String str3 = (String)paramArrayList.get(0);
        String str4 = (String)paramArrayList.get(1);
        String str5 = str3 + "/" + str4 + "@@" + str2;
        String str6 = str3 + "/" + str4;
        for (byte b2 = 2; b2 < paramInt; b2++)
          str6 = str6 + "/" + paramArrayList.get(b2); 
        if (paramBoolean) {
          this.c.d(str3, str4, str6, str5);
        } else {
          this.c.c(str3, str4, str5, str6);
        } 
      } 
      a(paramArrayList, xMLTypeElement, paramInt + 1, paramBoolean);
    } 
  }
  
  private void a(BaseNode paramBaseNode1, BaseNode paramBaseNode2, BaseNode paramBaseNode3, BaseNode paramBaseNode4) throws XMLException {
    if (this.d) {
      a(paramBaseNode1, paramBaseNode2);
      b(paramBaseNode1, paramBaseNode3);
    } else {
      a(paramBaseNode1, paramBaseNode3);
      b(paramBaseNode1, paramBaseNode2);
    } 
  }
  
  private void a(BaseNode paramBaseNode1, BaseNode paramBaseNode2) throws XMLException {
    byte b1 = 0;
    byte b2 = 0;
    int i = 0;
    int j = 0;
    String str1 = null;
    String str2 = null;
    ax ax = this.c.n();
    i = paramBaseNode1.getChildCount();
    for (b1 = 0; b1 < i; b1++) {
      RPCType rPCType = (RPCType)paramBaseNode1.getChild(b1);
      j = rPCType.getChildCount();
      for (b2 = 0; b2 < j; b2++) {
        RPCTypeProgram rPCTypeProgram = (RPCTypeProgram)rPCType.getChild(b2);
        rPCTypeProgram.setParameterCount(a(rPCTypeProgram.getFormatBuffer()));
      } 
    } 
    i = ax.getChildCount();
    for (b1 = 0; b1 < i; b1++) {
      ax ax1 = (ax)ax.getChild(b1);
      str1 = ax1.getName();
      j = ax1.getChildCount();
      for (b2 = 0; b2 < j; b2++) {
        ax ax2 = (ax)ax1.getChild(b2);
        str2 = ax2.getName();
        ArrayList arrayList = ax2.a();
        int k = arrayList.size();
        BaseNode baseNode = paramBaseNode2;
        for (byte b3 = 2; b3 < k; b3++) {
          ax ax3 = (ax)arrayList.get(b3);
          String str = ax3.getName();
          int m = ax3.c();
          if (m == 1) {
            baseNode = baseNode.getChild(str);
          } else {
            if (m == 4)
              throw new XMLException(61, "Program mapping on attributes is not supported."); 
            throw new XMLException(61, "Illegal program mapping.");
          } 
        } 
        if (baseNode != null)
          try {
            ((XMLTypeElement)baseNode).a("en", str1, str2, null);
          } catch (XMLException xMLException) {
            String str = "Redefintion of program mapping (Namespace=" + ((XMLTypeElement)baseNode).getUri() + ", QName=" + ((XMLTypeElement)baseNode).getQName() + ")";
            if (XMLRPCService.a)
              Trace.checkpoint(Trace.CP1, 5, 31, 98, str); 
            Dump.log(str);
            throw new XMLException(27, str);
          }  
      } 
    } 
  }
  
  private void b(BaseNode paramBaseNode1, BaseNode paramBaseNode2) throws XMLException {
    byte b1 = 0;
    byte b2 = 0;
    int i = 0;
    int j = 0;
    String str1 = null;
    String str2 = null;
    ax ax = this.c.o();
    i = ax.getChildCount();
    for (b1 = 0; b1 < i; b1++) {
      ax ax1 = (ax)ax.getChild(b1);
      str1 = ax1.getName();
      j = ax1.getChildCount();
      for (b2 = 0; b2 < j; b2++) {
        ax ax2 = (ax)ax1.getChild(b2);
        str2 = ax2.getName();
        a(ax2, paramBaseNode2, paramBaseNode1, str1, str2);
      } 
    } 
  }
  
  private void a(ax paramax, BaseNode paramBaseNode1, BaseNode paramBaseNode2, String paramString1, String paramString2) throws XMLException {
    RPCTypeProgram rPCTypeProgram = null;
    ax ax1 = paramax;
    BaseNode baseNode = paramBaseNode1;
    int i = paramax.getChildCount();
    for (byte b1 = 0; b1 < i; b1++) {
      ax1 = (ax)ax1.getChild(b1);
      String str = ax1.getName();
      baseNode = baseNode.getChild(str);
      ArrayList arrayList = ax1.a();
      rPCTypeProgram = a(arrayList, paramBaseNode2);
      if (rPCTypeProgram != null)
        break; 
      a(ax1, baseNode, paramBaseNode2, paramString1, paramString2);
    } 
    if (rPCTypeProgram != null)
      try {
        ((XMLTypeElement)baseNode).a("en", paramString1, paramString2, null);
      } catch (XMLException xMLException) {
        String str = "Redefintion of program mapping (Namespace=" + ((XMLTypeElement)baseNode).getUri() + ", QName=" + ((XMLTypeElement)baseNode).getQName() + ")";
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP1, 5, 31, 98, str); 
        Dump.log(str);
        throw new XMLException(27, str);
      }  
  }
  
  private RPCTypeProgram a(ArrayList paramArrayList, BaseNode paramBaseNode) throws XMLException {
    RPCTypeProgram rPCTypeProgram = null;
    byte b1 = 0;
    int i = paramArrayList.size();
    if (i > 0) {
      while (b1 < i) {
        ax ax = (ax)paramArrayList.get(b1++);
        if (ax.c() == 1) {
          String str = ax.e();
          paramBaseNode = paramBaseNode.getChild(str);
          continue;
        } 
        break;
      } 
      if (paramBaseNode != null && ((RPCType)paramBaseNode).getRpcTypeId() == 21)
        rPCTypeProgram = (RPCTypeProgram)paramBaseNode; 
    } 
    return rPCTypeProgram;
  }
  
  private void c(BaseNode paramBaseNode1, BaseNode paramBaseNode2) throws XMLException {
    if (paramBaseNode1 != null && paramBaseNode2 != null) {
      XMLTypeElement xMLTypeElement = this.c.i();
      ax ax = this.c.n();
      int i = paramBaseNode1.getChildCount();
      for (byte b1 = 0; b1 < i; b1++) {
        BaseNode baseNode1 = paramBaseNode1.getChild(b1);
        BaseNode baseNode2 = xMLTypeElement.addChild(new XMLTypeElement(baseNode1.getName()));
        ax ax1 = (ax)ax.getChild(baseNode1.getName());
        String str = baseNode1.getName();
        int j = baseNode1.getChildCount();
        for (byte b2 = 0; b2 < j; b2++) {
          BaseNode baseNode3 = baseNode1.getChild(b2);
          String str1 = baseNode3.getName();
          this.c.a(str, str1, this.a);
          BaseNode baseNode4 = baseNode2.addChild(new XMLTypeElement(str1));
          ax ax2 = (ax)ax1.getChild(str1);
          ArrayList arrayList = ax2.a();
          BaseNode baseNode5 = this.c.h();
          int k = arrayList.size();
          for (byte b3 = 2; b3 < k; b3++) {
            baseNode5 = baseNode5.getChild(((ax)arrayList.get(b3)).e());
            baseNode4 = baseNode4.addChild((XMLTypeElement)((XMLTypeElement)baseNode5).clone());
          } 
          a((XMLTypeElement)baseNode5, (XMLTypeElement)baseNode4);
        } 
      } 
    } 
  }
  
  private void d(BaseNode paramBaseNode1, BaseNode paramBaseNode2) throws XMLException {
    int i = 0;
    int j = 0;
    String str1 = null;
    String str2 = null;
    XMLTypeElement xMLTypeElement = this.c.k();
    ax ax = this.c.o();
    i = ax.getChildCount();
    for (byte b1 = 0; b1 < i; b1++) {
      ax ax1 = (ax)ax.getChild(b1);
      str1 = ax1.e();
      XMLTypeElement xMLTypeElement1 = (XMLTypeElement)xMLTypeElement.addChild(new XMLTypeElement(str1));
      j = ax1.getChildCount();
      for (byte b2 = 0; b2 < j; b2++) {
        ax ax2 = (ax)ax1.getChild(b2);
        str2 = ax2.e();
        XMLTypeElement xMLTypeElement2 = (XMLTypeElement)xMLTypeElement1.addChild(new XMLTypeElement(str2));
        a(ax2, xMLTypeElement2, paramBaseNode2);
      } 
    } 
  }
  
  private void a(BaseNode paramBaseNode1, BaseNode paramBaseNode2, BaseNode paramBaseNode3) throws XMLException {
    int i = paramBaseNode1.getChildCount();
    for (byte b1 = 0; b1 < i; b1++) {
      ax ax = (ax)paramBaseNode1.getChild(b1);
      XMLTypeElement xMLTypeElement = (XMLTypeElement)paramBaseNode3.getChild(ax.e());
      if (xMLTypeElement != null) {
        XMLTypeElement xMLTypeElement1 = (XMLTypeElement)paramBaseNode2.addChild(xMLTypeElement);
        a(ax, xMLTypeElement1, xMLTypeElement);
      } 
    } 
  }
  
  private void a(XMLTypeElement paramXMLTypeElement1, XMLTypeElement paramXMLTypeElement2) {
    for (byte b1 = 0; b1 < paramXMLTypeElement1.getChildCount(); b1++) {
      XMLTypeElement xMLTypeElement1 = (XMLTypeElement)paramXMLTypeElement1.getChild(b1);
      XMLTypeElement xMLTypeElement2 = (XMLTypeElement)paramXMLTypeElement2.addChild((XMLTypeElement)xMLTypeElement1.clone());
      a(xMLTypeElement1, xMLTypeElement2);
    } 
  }
  
  private void b(BaseNode paramBaseNode1, BaseNode paramBaseNode2, BaseNode paramBaseNode3) throws XMLException {
    c(paramBaseNode1, paramBaseNode2, this.c.n());
    d(paramBaseNode1, paramBaseNode3, this.c.o());
  }
  
  private void c(BaseNode paramBaseNode1, BaseNode paramBaseNode2, BaseNode paramBaseNode3) throws XMLException {
    int i = paramBaseNode1.getChildCount();
    for (byte b1 = 0; b1 < i; b1++) {
      BaseNode baseNode = paramBaseNode1.getChild(b1);
      if (((RPCType)baseNode).getDirection() != 1) {
        BaseNode baseNode1 = null;
        String str = baseNode.getName();
        if (str.charAt(0) == '?') {
          baseNode1 = paramBaseNode3.getChild(0);
        } else {
          baseNode1 = paramBaseNode3.getChild(str);
        } 
        this.e = null;
        BaseNode baseNode2 = e(baseNode1, paramBaseNode2);
        if (baseNode2 != null)
          if (this.e == null) {
            switch (((RPCType)baseNode).getRpcTypeId()) {
              case 3:
              case 8:
                if (((RPCTypeDateTime)baseNode).c() == 0) {
                  ((XMLTypeElement)baseNode2).setInternalDataType("date");
                  break;
                } 
                ((XMLTypeElement)baseNode2).setInternalDataType("dateTime");
                break;
              case 30:
                ((XMLTypeElement)baseNode2).b(XMLTypeElement.w);
                break;
            } 
          } else {
            switch (((RPCType)baseNode).getRpcTypeId()) {
              case 3:
              case 8:
                if (((RPCTypeDateTime)baseNode).c() == 0) {
                  this.e.f("date");
                  break;
                } 
                this.e.f("dateTime");
                break;
            } 
          }  
        if (baseNode1 != null)
          c(baseNode, paramBaseNode2, baseNode1); 
      } 
    } 
  }
  
  private BaseNode e(BaseNode paramBaseNode1, BaseNode paramBaseNode2) throws XMLException {
    BaseNode baseNode = paramBaseNode2;
    if (paramBaseNode1 != null) {
      ArrayList arrayList = ((ax)paramBaseNode1).a();
      int i = arrayList.size();
      if (i == 0) {
        baseNode = null;
      } else {
        ax ax = null;
        byte b1 = 2;
        while (i > b1) {
          ax = (ax)arrayList.get(b1++);
          String str = ax.e();
          if (ax.c() == 4) {
            this.e = ((XMLTypeElement)baseNode).getAttributes().b(str);
          } else if (str.charAt(0) == '?') {
            baseNode = baseNode.getChild(0);
          } else {
            baseNode = baseNode.getChild(str);
          } 
          if (baseNode == null)
            throw new XMLException(25); 
        } 
      } 
    } 
    if (baseNode == paramBaseNode2)
      baseNode = null; 
    return baseNode;
  }
  
  private BaseNode f(BaseNode paramBaseNode1, BaseNode paramBaseNode2) throws XMLException {
    BaseNode baseNode = paramBaseNode2;
    if (paramBaseNode1 != null) {
      ArrayList arrayList = ((ax)paramBaseNode1).a();
      int i = arrayList.size();
      if (i == 0) {
        baseNode = null;
      } else {
        ax ax = null;
        byte b1 = 0;
        while (i > b1) {
          ax = (ax)arrayList.get(b1++);
          String str = ax.e();
          if (str.charAt(0) == '?') {
            baseNode = baseNode.getChild(0);
          } else {
            baseNode = baseNode.getChild(str);
          } 
          if (baseNode == null)
            throw new XMLException(25); 
        } 
      } 
    } 
    if (baseNode == paramBaseNode2)
      baseNode = null; 
    return baseNode;
  }
  
  private void d(BaseNode paramBaseNode1, BaseNode paramBaseNode2, BaseNode paramBaseNode3) throws XMLException {
    ax ax1 = null;
    ax ax2 = null;
    int i = paramBaseNode3.getChildCount();
    for (byte b1 = 0; b1 < i; b1++) {
      ax1 = (ax)paramBaseNode3.getChild(b1);
      int j = ax1.getChildCount();
      for (byte b2 = 0; b2 < j; b2++) {
        ax2 = (ax)ax1.getChild(b2);
        e(paramBaseNode1, paramBaseNode2, ax2);
      } 
    } 
  }
  
  private void e(BaseNode paramBaseNode1, BaseNode paramBaseNode2, BaseNode paramBaseNode3) throws XMLException {
    int i = paramBaseNode3.getChildCount();
    for (byte b1 = 0; b1 < i; b1++) {
      BaseNode baseNode1 = null;
      BaseNode baseNode2 = paramBaseNode3.getChild(b1);
      if (((ax)baseNode2).c() != 4) {
        baseNode1 = paramBaseNode2.getChild(baseNode2.getName());
      } else {
        baseNode1 = paramBaseNode2;
      } 
      if (baseNode2 != null) {
        at at = ((XMLTypeElement)baseNode1).getAttributes();
        int j = at.a();
        for (byte b2 = 0; b2 < j; b2++) {
          a8 a81 = at.a(b2);
          BaseNode baseNode3 = baseNode2.getChild(a81.c());
          BaseNode baseNode4 = f(baseNode3, paramBaseNode1);
          if (baseNode4 != null)
            switch (((RPCType)baseNode4).getRpcTypeId()) {
              case 3:
              case 8:
                if (((RPCTypeDateTime)baseNode4).c() == 0) {
                  a81.f("date");
                  break;
                } 
                a81.f("dateTime");
                break;
            }  
        } 
        BaseNode baseNode = f(baseNode2, paramBaseNode1);
        if (baseNode != null)
          switch (((RPCType)baseNode).getRpcTypeId()) {
            case 3:
            case 8:
              if (((RPCTypeDateTime)baseNode).c() == 0) {
                ((XMLTypeElement)baseNode1).setInternalDataType("date");
                break;
              } 
              ((XMLTypeElement)baseNode1).setInternalDataType("dateTime");
              break;
            case 30:
              ((XMLTypeElement)baseNode1).b(XMLTypeElement.w);
              break;
          }  
        e(paramBaseNode1, baseNode1, baseNode2);
      } 
    } 
  }
  
  private long a(byte[] paramArrayOfByte) {
    long l = 0L;
    String str = new String(paramArrayOfByte);
    int i = str.length();
    char[] arrayOfChar = new char[i];
    str.getChars(0, i, arrayOfChar, 0);
    for (byte b1 = 0; b1 < i; b1++) {
      if (arrayOfChar[b1] == 'O' || arrayOfChar[b1] == 'S' || arrayOfChar[b1] == 'M')
        l++; 
    } 
    return l;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\bb.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */