package com.softwareag.entirex.xml.rt;

public class a1 extends a0 {
  public XMLTypeElement a() throws XMLException {
    XMLTypeElement xMLTypeElement1;
    XMLTypeElement xMLTypeElement2;
    XMLTypeElement xMLTypeElement3 = (xMLTypeElement2 = (xMLTypeElement1 = new XMLTypeElement("0")).register(xMLTypeElement1, "", "", "1", 1, 1)).register(xMLTypeElement2, "SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/", "Envelope", 1, 1);
    xMLTypeElement3.addNameSpaceDefinition("SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
    xMLTypeElement3.addNameSpaceDefinition("xsd", "http://www.w3.org/2001/XMLSchema");
    xMLTypeElement3.addNameSpaceDefinition("xsi", "http://www.w3.org/2001/XMLSchema-instance");
    xMLTypeElement3.addNameSpaceDefinition("SOAP-ENC", "http://schemas.xmlsoap.org/soap/encoding/");
    xMLTypeElement3.addAttribute("SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/", "encodingStyle", "http://schemas.xmlsoap.org/soap/encoding/", 0);
    XMLTypeElement xMLTypeElement4 = XMLTypeElement.register(xMLTypeElement3, "SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/", "Header", 0, 1);
    xMLTypeElement4.setNullValueSuppression(1);
    XMLTypeElement xMLTypeElement5;
    XMLTypeElement xMLTypeElement6 = (xMLTypeElement5 = XMLTypeElement.register(xMLTypeElement3, "SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/", "Body", 1, 1)).register(xMLTypeElement5, "SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/", "Fault", 1, 1);
    xMLTypeElement6.a("en", "0", "1", null);
    XMLTypeElement xMLTypeElement7 = XMLTypeElement.register(xMLTypeElement6, "", "", "faultcode", 1, 1);
    xMLTypeElement7.setContextInfo("faultcode");
    XMLTypeElement xMLTypeElement8 = XMLTypeElement.register(xMLTypeElement6, "", "", "faultstring", 1, 1);
    xMLTypeElement8.setContextInfo("faultstring");
    XMLTypeElement xMLTypeElement9 = XMLTypeElement.register(xMLTypeElement6, "", "", "faultactor", 1, 1);
    xMLTypeElement9.setContextInfo("faultactor");
    XMLTypeElement xMLTypeElement10 = XMLTypeElement.register(xMLTypeElement6, "", "", "detail", 0, 1);
    xMLTypeElement10.setNullValueSuppression(1);
    return xMLTypeElement1;
  }
  
  public String[][] b() { return new String[][] { { "'http://schemas.xmlsoap.org/soap/envelope/'Envelope/'http://schemas.xmlsoap.org/soap/envelope/'Body/'http://schemas.xmlsoap.org/soap/envelope/'Fault/faultcode", "0/1@@faultcode" }, { "'http://schemas.xmlsoap.org/soap/envelope/'Envelope/'http://schemas.xmlsoap.org/soap/envelope/'Body/'http://schemas.xmlsoap.org/soap/envelope/'Fault/faultstring", "0/1@@faultstring" }, { "'http://schemas.xmlsoap.org/soap/envelope/'Envelope/'http://schemas.xmlsoap.org/soap/envelope/'Body/'http://schemas.xmlsoap.org/soap/envelope/'Fault/faultactor", "0/1@@faultactor" }, { "'http://schemas.xmlsoap.org/soap/envelope/'Envelope/'http://schemas.xmlsoap.org/soap/envelope/'Body/'http://schemas.xmlsoap.org/soap/envelope/'Fault/detail", "0/1@@detail" } }; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\a1.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */