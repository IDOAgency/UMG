package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class eh {
  private cw a = null;
  
  private bo b = null;
  
  private Properties c = new Properties();
  
  public void a(cw paramcw) { this.a = paramcw; }
  
  public void a(bo parambo) { this.b = parambo; }
  
  private void a() { this.b.c((String)this.c.get("encoding")); }
  
  private void b() {
    this.c = new Properties();
    this.c.put("url", this.a.b());
    this.c.put("protocol", this.a.a());
    String str = this.b.p();
    this.c.put("encoding", (str != null) ? str : "utf-8");
  }
  
  public InputStream a(OutputStream paramOutputStream) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 35, 100); 
    InputStream inputStream = null;
    if (this.a == null || this.b == null)
      new XMLException(79, "Internal error: Missing required information"); 
    b();
    if (this.a.a().startsWith("http")) {
      ei ei = new ei();
      ei.a(this.b);
      try {
        inputStream = ei.a(paramOutputStream, this.c);
      } catch (XMLException xMLException) {
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.M2, 5, 35, 100, "Error during send and receive."); 
        this.b.a(xMLException.getErrorClass(), xMLException.getErrorCode(), xMLException.getErrorText());
        throw xMLException;
      } 
      if (XMLRPCService.a)
        Trace.leaveMethod(Trace.M2, 5, 35, 100); 
      a();
      return inputStream;
    } 
    if (this.a.a().equalsIgnoreCase("javaCallback")) {
      CallbackInterface callbackInterface = ar.x();
      if (callbackInterface != null) {
        synchronized (callbackInterface) {
          ek ek = new ek();
          ek.a(this.b);
          ek.a(callbackInterface);
          try {
            inputStream = ek.a(paramOutputStream, this.c);
          } catch (XMLException xMLException) {
            if (XMLRPCService.a)
              Trace.checkpoint(Trace.M2, 5, 35, 100, "Error during send and receive."); 
            this.b.a(xMLException.getErrorClass(), xMLException.getErrorCode(), xMLException.getErrorText());
            throw xMLException;
          } 
        } 
        return inputStream;
      } 
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.M2, 5, 35, 100, "Transport medium = null."); 
      this.b.a(2000, 81, "Transport medium = null.");
      throw new XMLException(81);
    } 
    if (XMLRPCService.a)
      Trace.checkpoint(Trace.M2, 5, 35, 100, "Unknown transport medium."); 
    this.b.a(2000, 81, "Unknown transport medium.");
    throw new XMLException(81);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\eh.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */