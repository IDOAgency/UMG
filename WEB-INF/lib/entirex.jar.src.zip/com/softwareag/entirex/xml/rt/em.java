package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;
import java.util.Properties;
import java.util.Stack;
import java.util.Vector;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class em extends DefaultHandler {
  private static final String a = "http://namespaces.softwareag.com/entirex/xml/runtime/configuration";
  
  private static final String b = "";
  
  private static final String c = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "EntireX");
  
  private static final String d = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "XmlRuntime");
  
  private static final String e = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "BrokerInfo");
  
  private static final String f = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "BrokerId");
  
  private static final String g = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "ServerAddress");
  
  private static final String h = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "Logical_BrokerId");
  
  private static final String i = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "Logical_Service");
  
  private static final String j = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "Logical_SetName");
  
  private static final String k = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "Options");
  
  private static final String l = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "TargetServer");
  
  private static final String m = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "adapters");
  
  private static final String n = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "exx-xml-adapter");
  
  private static final String o = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "xmms");
  
  private static final String p = av.a("http://namespaces.softwareag.com/entirex/xml/runtime/configuration", "exx-xmm");
  
  private static final String q = "name";
  
  private static final String r = "version";
  
  private static final String s = "compressionLevel";
  
  private static final String t = "encryptionLevel";
  
  private static final String u = "userID";
  
  private static final String v = "rpcUserID";
  
  private static final String w = "password";
  
  private static final String x = "rpcPassword";
  
  static XMLTypeElement y;
  
  private StringBuffer z = new StringBuffer();
  
  c3 aa = new c3(new XMLTypeElement("CONFIG"));
  
  private XMLTypeElement ab = null;
  
  private c3 ac = null;
  
  private Stack ad = new Stack();
  
  private boolean ae = false;
  
  private Stack af = new Stack();
  
  private Stack ag = new Stack();
  
  private int ah = 0;
  
  private boolean ai = false;
  
  public em(boolean paramBoolean) {
    this.ai = paramBoolean;
    this.ab = y;
    this.ac = this.aa;
  }
  
  public void startElement(String paramString1, String paramString2, String paramString3, Attributes paramAttributes) throws SAXException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 25, 44, "namespaceuri=" + paramString1 + ", localname=" + paramString2 + ", qname", paramString3); 
    try {
      BaseNode baseNode = null;
      String str = av.a(null, paramString1, paramString3, paramString2);
      this.ah++;
      baseNode = this.ab.getChild(str);
      if (baseNode == null) {
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP2, 5, 25, 44, "Warning: Find an unknown tag name in configuration file. (Tag=" + str + ")"); 
        this.ae = true;
        this.ad.push(str);
      } else {
        this.af.push(this.ab);
        this.ab = (XMLTypeElement)baseNode;
        if (this.ac != null) {
          if (this.ac.d(str) == 0) {
            this.ag.push(this.ac);
            c3 c31 = new c3(this.ab);
            this.ac.b(c31);
            this.ac = c31;
          } else {
            this.ag.push(this.ac);
            if (this.ac.d().isSized()) {
              c3 c31 = this.ab.createValueNode();
              this.ac.b(c31);
              this.ac = c31;
            } 
          } 
        } else {
          c3 c31 = this.ab.createValueNode();
          this.ac = c31;
        } 
        if (paramAttributes != null) {
          int i1 = paramAttributes.getLength();
          if (XMLRPCService.a)
            Trace.checkpoint(Trace.CP2, 5, 25, 44, "Number of attributes=" + i1); 
          for (byte b1 = 0; b1 < i1; b1++) {
            String str2 = paramAttributes.getURI(b1);
            String str1 = paramAttributes.getLocalName(b1);
            String str3 = paramAttributes.getQName(b1);
            if (XMLRPCService.a)
              Trace.checkpoint(Trace.CP2, 5, 25, 44, "namespaceuri=" + str2 + ", localname=" + str1 + ", qname=" + str3 + ", value", paramAttributes.getValue(b1)); 
            int i2 = paramAttributes.getQName(b1).indexOf(':');
            if (i2 >= 0) {
              str3 = paramAttributes.getQName(b1).substring(0, i2);
            } else {
              str3 = "";
            } 
            a8 a8 = this.ab.getAttributes().b(av.a(str2, str1));
            if (a8 != null)
              this.ac.k().a(a8.a(paramAttributes.getValue(str2, str1))); 
          } 
        } 
      } 
    } catch (Exception exception) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 26, 44, (new XMLException(5, exception.toString())).toString()); 
      throw new SAXException("XMLException", exception);
    } finally {
      if (XMLRPCService.a)
        Trace.leaveMethod(Trace.M2, 5, 25, 44); 
    } 
  }
  
  public void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2) throws SAXException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 25, 5); 
    try {
      if (!this.ae) {
        this.z = new StringBuffer();
        this.z.append(paramArrayOfChar, paramInt1, paramInt2);
        String str = this.z.toString();
        if (XMLRPCService.a)
          Trace.parameter(Trace.MP4, 5, 8, 5, "characters", str); 
        this.ac.a(str);
      } 
    } catch (Exception exception) {
      Trace.checkpoint(Trace.CP1, 5, 25, 5, "Error during parsing input document: " + this.ac.a());
      throw new SAXException("XMLException", exception);
    } finally {
      if (XMLRPCService.a)
        Trace.leaveMethod(Trace.M2, 5, 25, 5); 
    } 
  }
  
  public void endElement(String paramString1, String paramString2, String paramString3) throws SAXException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 25, 11, "name", paramString2); 
    this.ah--;
    if (this.ae) {
      if (this.ad.isEmpty()) {
        this.ae = false;
      } else {
        this.ad.pop();
        if (this.ad.isEmpty())
          this.ae = false; 
      } 
    } else {
      this.ab = (XMLTypeElement)this.af.pop();
      if (this.ah > 0)
        this.ac = (c3)this.ag.pop(); 
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 25, 11); 
  }
  
  public void startDocument() {
    if (XMLRPCService.a)
      Trace.checkpoint(Trace.CP2, 5, 25, 43); 
  }
  
  public void endDocument() {
    if (XMLRPCService.a)
      Trace.checkpoint(Trace.CP2, 5, 25, 10); 
  }
  
  public void startPrefixMapping(String paramString1, String paramString2) {}
  
  protected void a(ar paramar, Properties paramProperties) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M3, 5, 26, 36); 
    boolean bool = false;
    String str = null;
    try {
      c3 c31 = this.aa;
      c31 = (c3)c31.c(c);
      if (c31 != null) {
        c31 = (c3)c31.c(d);
        if (c31 != null) {
          c3 c32 = null;
          c3 c33 = null;
          c3 c34 = null;
          c32 = (c3)c31.c(e);
          if (c32 != null) {
            ay ay = paramar.u();
            if (ay == null) {
              ay = new ay();
              bool = true;
            } 
            if (c32.d(f) <= 1) {
              c33 = (c3)c32.c(f);
              if (c33 != null) {
                str = c33.c();
                if (str != null && !str.trim().equals(""))
                  if (paramProperties != null) {
                    if (paramProperties.get("entirex.sdk.xml.runtime.brokerid") == null)
                      paramProperties.put("entirex.sdk.xml.runtime.brokerid", str); 
                  } else {
                    ay.a(str);
                  }  
              } 
            } else {
              throw new XMLException(43, "Multiple definition of broker identifier.");
            } 
            if (c32.d(g) <= 1) {
              c33 = (c3)c32.c(g);
              if (c33 != null) {
                str = c33.c();
                if (str != null && !str.trim().equals(""))
                  if (paramProperties != null) {
                    if (paramProperties.get("entirex.sdk.xml.runtime.serveraddress") == null)
                      paramProperties.put("entirex.sdk.xml.runtime.serveraddress", str); 
                  } else {
                    ay.b(str);
                  }  
              } 
            } else {
              throw new XMLException(43, "Multiple definition of server address.");
            } 
            if (c32.d(h) <= 1) {
              c33 = (c3)c32.c(h);
              if (c33 != null) {
                str = c33.c();
                if (str != null && !str.trim().equals(""))
                  if (paramProperties != null) {
                    if (paramProperties.get("entirex.sdk.xml.runtime.logicalbrokerid") == null)
                      paramProperties.put("entirex.sdk.xml.runtime.logicalbrokerid", str); 
                  } else {
                    ay.c(str);
                  }  
              } 
            } else {
              throw new XMLException(43, "Multiple definition of logical broker identifier.");
            } 
            if (c32.d(i) <= 1) {
              c33 = (c3)c32.c(i);
              if (c33 != null) {
                str = c33.c();
                if (str != null && !str.trim().equals(""))
                  if (paramProperties != null) {
                    if (paramProperties.get("entirex.sdk.xml.runtime.logicalservice") == null)
                      paramProperties.put("entirex.sdk.xml.runtime.logicalservice", str); 
                  } else {
                    ay.d(str);
                  }  
              } 
            } else {
              throw new XMLException(43, "Multiple definition of logical service.");
            } 
            if (c32.d(j) <= 1) {
              c33 = (c3)c32.c(j);
              if (c33 != null) {
                str = c33.c();
                if (str != null && !str.trim().equals(""))
                  if (paramProperties != null) {
                    if (paramProperties.get("entirex.sdk.xml.runtime.logicalsetname") == null)
                      paramProperties.put("entirex.sdk.xml.runtime.logicalsetname", str); 
                  } else {
                    ay.e(str);
                  }  
              } 
            } else {
              throw new XMLException(43, "Multiple definition of logical set.");
            } 
            if (c32.d(k) <= 1) {
              c33 = (c3)c32.c(k);
              if (c33 != null) {
                c4 c4 = c33.k();
                str = c4.a("compressionLevel");
                if (str != null && !str.trim().equals(""))
                  if (paramProperties != null) {
                    if (paramProperties.get("entirex.sdk.xml.runtime.compresslevel") == null)
                      paramProperties.put("entirex.sdk.xml.runtime.compresslevel", str); 
                  } else {
                    ay.m(str);
                  }  
                str = c4.a("encryptionLevel");
                if (str != null && !str.trim().equals(""))
                  if (paramProperties != null) {
                    paramProperties.put("entirex.sdk.xml.runtime.encryptionlevel", str);
                  } else {
                    ay.i(str);
                  }  
                str = c4.a("userID");
                if (str != null && !str.trim().equals(""))
                  if (paramProperties != null) {
                    if (paramProperties.get("entirex.sdk.xml.runtime.userid") == null)
                      paramProperties.put("entirex.sdk.xml.runtime.userid", str); 
                  } else {
                    ay.f(str);
                  }  
                str = c4.a("rpcUserID");
                if (str != null && !str.trim().equals(""))
                  if (paramProperties != null) {
                    if (paramProperties.get("entirex.sdk.xml.runtime.rpcuserid") == null)
                      paramProperties.put("entirex.sdk.xml.runtime.rpcuserid", str); 
                  } else {
                    ay.g(str);
                  }  
                str = c4.a("password");
                if (str != null && !str.trim().equals(""))
                  if (paramProperties != null) {
                    if (paramProperties.get("entirex.sdk.xml.runtime.password") == null)
                      paramProperties.put("entirex.sdk.xml.runtime.password", str); 
                  } else {
                    ay.p(str);
                  }  
                str = c4.a("rpcPassword");
                if (str != null && !str.trim().equals(""))
                  if (paramProperties != null) {
                    if (paramProperties.get("entirex.sdk.xml.runtime.rpcpassword") == null)
                      paramProperties.put("entirex.sdk.xml.runtime.rpcpassword", str); 
                  } else {
                    ay.q(str);
                  }  
              } 
            } else {
              throw new XMLException(43, "Multiple definition of logical set.");
            } 
            if (bool)
              paramar.a(ay); 
          } 
          String str1 = null;
          cw cw = null;
          Vector vector = c31.e(l);
          int i1 = vector.size();
          for (byte b1 = 0; b1 < i1; b1++) {
            c32 = (c3)vector.get(b1);
            if (c32 != null) {
              if (c32.k() != null) {
                str1 = c32.k().a("name");
                if (str1 == null)
                  throw new XMLException(43, "Undefined or invalid target server definition."); 
                str1 = a(str1);
                cw = new cw(str1);
                paramar.b(str1, cw);
              } else {
                throw new XMLException(43, "Undefined or invalid target server definition.");
              } 
              c33 = (c3)c32.c(m);
              if (c33 != null) {
                String str2 = null;
                int i2 = c33.d(n);
                for (byte b2 = 0; b2 < i2; b2++) {
                  c34 = (c3)c33.a(n, b2);
                  str2 = c34.k().a("name");
                  if (str2 == null || str2.trim().equals(""))
                    throw new XMLException(43, "XMLAdapter name missing."); 
                  paramar.j(str2);
                  cw.b(str2);
                  paramar.a(str2, cw);
                } 
              } 
              c33 = (c3)c32.c(o);
              if (c33 != null) {
                String str2 = null;
                int i2 = c33.d(p);
                for (byte b2 = 0; b2 < i2; b2++) {
                  c34 = (c3)c33.a(p, b2);
                  str2 = c34.k().a("name");
                  if (str2 == null || str2.trim().equals(""))
                    throw new XMLException(43, "XMLAdapter name missing."); 
                  ar.h(str2);
                  cw.a(str2);
                  paramar.a(str2, cw);
                } 
              } 
            } 
          } 
        } 
      } 
    } catch (XMLException xMLException) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 26, 36, xMLException.toString()); 
    } finally {
      if (XMLRPCService.a)
        Trace.leaveMethod(Trace.M3, 5, 26, 36); 
    } 
  }
  
  private String a(String paramString) {
    StringBuffer stringBuffer = new StringBuffer();
    int i1 = paramString.length();
    char[] arrayOfChar = new char[i1];
    paramString.getChars(0, i1, arrayOfChar, 0);
    for (byte b1 = 0; b1 < i1; b1++) {
      switch (arrayOfChar[b1]) {
        case ' ':
          stringBuffer.append("%20");
          break;
        case '\\':
          if (b1 < i1 - 1) {
            if (arrayOfChar[b1 + true] == '/') {
              stringBuffer.append('/');
              b1++;
              break;
            } 
            stringBuffer.append(arrayOfChar[b1]);
            break;
          } 
          stringBuffer.append(arrayOfChar[b1]);
          break;
        default:
          stringBuffer.append(arrayOfChar[b1]);
          break;
      } 
    } 
    return new String(stringBuffer);
  }
  
  static  {
    XMLTypeElement xMLTypeElement1 = (y = new XMLTypeElement("CONFIG")).register(y, c, 1, 1);
    xMLTypeElement1.addAttribute("", "", "version", "", 1);
    XMLTypeElement xMLTypeElement2 = XMLTypeElement.register(xMLTypeElement1, d, 1, 1);
    xMLTypeElement2.addAttribute("", "", "version", "", 1);
    XMLTypeElement xMLTypeElement3;
    XMLTypeElement xMLTypeElement4;
    XMLTypeElement xMLTypeElement5;
    XMLTypeElement xMLTypeElement6;
    XMLTypeElement xMLTypeElement7;
    XMLTypeElement xMLTypeElement8;
    XMLTypeElement xMLTypeElement9 = (xMLTypeElement8 = (xMLTypeElement7 = (xMLTypeElement6 = (xMLTypeElement5 = (xMLTypeElement4 = (xMLTypeElement3 = XMLTypeElement.register(xMLTypeElement2, e, 1, 1)).register(xMLTypeElement3, f, 0, 1)).register(xMLTypeElement3, g, 0, 1)).register(xMLTypeElement3, h, 0, 1)).register(xMLTypeElement3, i, 0, 1)).register(xMLTypeElement3, j, 0, 1)).register(xMLTypeElement3, k, 0, 1);
    xMLTypeElement9.addAttribute("", "", "userID", "", 1);
    xMLTypeElement9.addAttribute("", "", "rpcUserID", "", 1);
    xMLTypeElement9.addAttribute("", "", "password", "", 1);
    xMLTypeElement9.addAttribute("", "", "rpcPassword", "", 1);
    xMLTypeElement9.addAttribute("", "", "compressionLevel", "", 1);
    xMLTypeElement9.addAttribute("", "", "compressionLevel", "", 1);
    XMLTypeElement xMLTypeElement10 = XMLTypeElement.register(xMLTypeElement2, l, 0, 0);
    xMLTypeElement10.addAttribute("", "", "name", "", 1);
    XMLTypeElement xMLTypeElement11;
    XMLTypeElement xMLTypeElement12 = (xMLTypeElement11 = XMLTypeElement.register(xMLTypeElement10, m, 0, 1)).register(xMLTypeElement11, n, 0, 0);
    xMLTypeElement12.addAttribute("", "", "name", "", 1);
    XMLTypeElement xMLTypeElement13;
    XMLTypeElement xMLTypeElement14 = (xMLTypeElement13 = XMLTypeElement.register(xMLTypeElement10, o, 0, 1)).register(xMLTypeElement13, p, 0, 0);
    xMLTypeElement14.addAttribute("", "", "name", "", 1);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\em.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */