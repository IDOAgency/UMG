package com.softwareag.entirex.xml.rt;

public class RPCTypeBoolean extends RPCTypeScalar {
  public RPCTypeBoolean() { this(2, 3); }
  
  public RPCTypeBoolean(String paramString) { this(paramString, 2, 3); }
  
  public RPCTypeBoolean(int paramInt) { super(2, paramInt); }
  
  public RPCTypeBoolean(String paramString, int paramInt) { this(paramString, 2, paramInt); }
  
  public RPCTypeBoolean(int paramInt1, int paramInt2) { super(paramInt1, paramInt2); }
  
  public RPCTypeBoolean(String paramString, int paramInt1, int paramInt2) { super(paramString, paramInt1, paramInt2); }
  
  public void setDefaultValue(boolean paramBoolean) { setDefaultValue(toString(paramBoolean)); }
  
  public static final String toString(boolean paramBoolean) {
    Boolean bool = new Boolean(paramBoolean);
    return bool.toString();
  }
  
  public static final boolean fromString(String paramString) {
    Boolean bool = new Boolean(paramString);
    return bool.booleanValue();
  }
  
  public cp createValueNode() { return new co(this, null); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\RPCTypeBoolean.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */