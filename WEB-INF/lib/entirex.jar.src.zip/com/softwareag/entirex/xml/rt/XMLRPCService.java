package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.Broker;
import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.Conversation;
import com.softwareag.entirex.aci.RPCService;
import com.softwareag.entirex.base.EntireXClassLoader;
import com.softwareag.entirex.base.EntireXFileLoader;
import com.softwareag.entirex.trace.Trace;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import javax.xml.parsers.SAXParser;
import org.xml.sax.InputSource;

public final class XMLRPCService extends RPCService implements bk {
  protected static boolean a = false;
  
  private ar b = new ar();
  
  private String c = null;
  
  private Conversation d = null;
  
  private Conversation e = null;
  
  private long f;
  
  private boolean g;
  
  private String h;
  
  private boolean i;
  
  private boolean j;
  
  private bo k;
  
  protected XMLRPCService() {
    this.f = System.currentTimeMillis();
    this.g = false;
    this.i = false;
    this.j = false;
    this.k = new bo();
    try {
      setServerAddress(a3.j);
      setCompression(true);
    } catch (BrokerException brokerException) {
      if (a)
        Trace.checkpoint(Trace.CP1, 5, 22, 8, brokerException.toString()); 
    } 
    setLibraryName(a3.k);
  }
  
  protected XMLRPCService(String paramString, ar paramar) {
    this();
    a(paramString, paramar);
  }
  
  public XMLRPCService(XMLAdapter paramXMLAdapter) {
    this();
    a = Trace.on(5, this);
    XMLAdapterInfo xMLAdapterInfo = paramXMLAdapter.getAdapterInfo();
    Broker broker = null;
    if (xMLAdapterInfo != null) {
      broker = new Broker(xMLAdapterInfo.getBrokerID(), a3.m);
      try {
        setServerAddress(xMLAdapterInfo.getServerAddress());
      } catch (BrokerException brokerException) {
        if (a)
          Trace.checkpoint(Trace.CP1, 5, 22, 8, brokerException.toString()); 
      } 
    } else {
      broker = new Broker(a3.i, a3.m);
    } 
    try {
      setBroker(broker);
    } catch (BrokerException brokerException) {
      if (a)
        Trace.checkpoint(Trace.CP1, 5, 22, 8, brokerException.toString()); 
    } 
    a(paramXMLAdapter);
  }
  
  public XMLRPCService(String paramString) {
    super(new Broker(a3.i, a3.m), a3.j, a3.k, true);
    a = Trace.on(5, this);
    ay ay = c(paramString);
    try {
      String str = ay.e();
      if (str != null && str.trim().length() > 0) {
        setLogicalService(str, ay.f());
      } else {
        String str1 = ay.d();
        if (str1 != null && str1.trim().length() > 0) {
          setLogicalBroker(str1, ay.f());
        } else {
          setBroker(new Broker(ay.b(), (ay.g() == null) ? a3.m : ay.g()));
          setServerAddress(ay.c());
        } 
      } 
    } catch (BrokerException brokerException) {
      if (a)
        Trace.checkpoint(Trace.CP1, 5, 22, 8, brokerException.toString()); 
    } 
  }
  
  public XMLRPCService(Broker paramBroker, XMLAdapter paramXMLAdapter) { this(paramBroker, (paramXMLAdapter.getAdapterInfo() != null) ? paramXMLAdapter.getAdapterInfo().getServerAddress() : null, paramXMLAdapter); }
  
  public XMLRPCService(Broker paramBroker, String paramString, XMLAdapter paramXMLAdapter) {
    super(paramBroker, paramString, a3.k, (paramXMLAdapter.getAdapterInfo() != null) ? paramXMLAdapter.getAdapterInfo().getCompression() : 1);
    a = Trace.on(5, this);
    a(paramXMLAdapter);
  }
  
  public XMLRPCService(Broker paramBroker, String paramString1, String paramString2, String paramString3, String paramString4, XMLAdapter paramXMLAdapter) {
    super((paramBroker == null) ? new Broker(a3.i, a3.m) : paramBroker, (paramString1 == null || paramString1.equals("")) ? a3.j : paramString1, a3.k, (paramXMLAdapter.getAdapterInfo() != null) ? paramXMLAdapter.getAdapterInfo().getCompression() : 1);
    a = Trace.on(5, this);
    try {
      if (paramString3 != null && !paramString3.equals("")) {
        setLogicalService(paramString3, paramString4);
      } else if (paramString2 != null && !paramString2.equals("")) {
        setLogicalBroker(paramString2, paramString4);
      } 
    } catch (BrokerException brokerException) {
      if (a)
        Trace.checkpoint(Trace.CP1, 5, 22, 8, brokerException.toString()); 
    } 
    a(paramXMLAdapter);
  }
  
  public XMLRPCService(String paramString1, String paramString2, XMLAdapter paramXMLAdapter) {
    super(new Broker(a3.i, a3.m), a3.j, a3.k, true);
    a = Trace.on(5, this);
    try {
      setLogicalService(paramString1, paramString2);
    } catch (BrokerException brokerException) {
      if (a)
        Trace.checkpoint(Trace.CP1, 5, 22, 8, brokerException.toString()); 
    } 
    a(paramXMLAdapter);
  }
  
  public XMLRPCService(String paramString1, String paramString2, String paramString3, XMLAdapter paramXMLAdapter) {
    super(new Broker(a3.i, a3.m), paramString1, a3.k, (paramXMLAdapter.getAdapterInfo() != null) ? paramXMLAdapter.getAdapterInfo().getCompression() : 1);
    a = Trace.on(5, this);
    try {
      setLogicalBroker(paramString2, paramString3);
    } catch (BrokerException brokerException) {
      if (a)
        Trace.checkpoint(Trace.CP1, 5, 22, 8, brokerException.toString()); 
    } 
    a(paramXMLAdapter);
  }
  
  protected XMLRPCService(Broker paramBroker, String paramString) { super(paramBroker, paramString, a3.k); }
  
  protected XMLRPCService(ar paramar) {
    this();
    try {
      setServerAddress(null);
      setBroker(null);
    } catch (BrokerException brokerException) {
      if (a)
        Trace.checkpoint(Trace.CP1, 5, 22, 8, brokerException.toString()); 
    } 
    a(paramar);
  }
  
  protected void a(ar paramar) { this.b = paramar; }
  
  public void setUserProperty(String paramString1, String paramString2) { this.b.a(paramString1, paramString2); }
  
  private void a(XMLAdapter paramXMLAdapter) {
    bb bb = new bb(paramXMLAdapter, this.b, a3.b);
    try {
      bb.a();
    } catch (XMLException xMLException) {
      Trace.checkpoint(Trace.CP1, 5, 20, 97, xMLException.toString());
    } 
  }
  
  public XMLRPCService(Broker paramBroker, String paramString1, String paramString2) {
    super(paramBroker, paramString1, a3.k, true);
    a = Trace.on(5, this);
    c(paramString2);
  }
  
  public XMLRPCService(Broker paramBroker, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    super((paramBroker == null) ? new Broker(a3.i, a3.m) : paramBroker, (paramString1 == null || paramString1.equals("")) ? a3.j : paramString1, a3.k, true);
    a = Trace.on(5, this);
    c(paramString5);
    try {
      if (paramString3 != null && !paramString3.equals("")) {
        setLogicalService(paramString3, paramString4);
      } else if (paramString2 != null && !paramString2.equals("")) {
        setLogicalBroker(paramString2, paramString4);
      } 
    } catch (BrokerException brokerException) {
      if (a)
        Trace.checkpoint(Trace.CP1, 5, 22, 8, brokerException.toString()); 
    } 
  }
  
  public XMLRPCService(String paramString1, String paramString2, String paramString3) {
    super(new Broker("localhost:1971", "USER"), "RPC/SRV1/CALLNAT", a3.k, true);
    a = Trace.on(5, this);
    c(paramString3);
    try {
      setLogicalService(paramString1, paramString2);
    } catch (BrokerException brokerException) {
      if (a)
        Trace.checkpoint(Trace.CP1, 5, 22, 8, brokerException.toString()); 
    } 
  }
  
  public XMLRPCService(String paramString1, String paramString2, String paramString3, String paramString4) {
    super(new Broker(a3.i, a3.m), paramString1, a3.k, true);
    a = Trace.on(5, this);
    c(paramString4);
    try {
      setLogicalBroker(paramString2, paramString3);
    } catch (BrokerException brokerException) {
      if (a)
        Trace.checkpoint(Trace.CP1, 5, 22, 8, brokerException.toString()); 
    } 
  }
  
  protected void a(String paramString, ar paramar) {
    if (paramString != null) {
      a(paramar);
      if (paramString.toLowerCase().endsWith("xmladapter.class") || paramString.toLowerCase().endsWith("xmladapter")) {
        Object object = null;
        try {
          if (paramString.toLowerCase().endsWith(".class") || paramString.indexOf("/") != -1 || paramString.indexOf(File.separator) != -1) {
            EntireXClassLoader entireXClassLoader = new EntireXClassLoader(paramString);
            object = entireXClassLoader.getObject(null, null);
          } else {
            Class clazz = Class.forName(paramString);
            object = clazz.newInstance();
          } 
          if (object != null) {
            if (object instanceof XMLAdapter) {
              XMLAdapterInfo xMLAdapterInfo = ((XMLAdapter)object).getAdapterInfo();
              Broker broker = null;
              String str = null;
              if (xMLAdapterInfo != null) {
                try {
                  if (xMLAdapterInfo.getBrokerID() != null)
                    broker = new Broker(xMLAdapterInfo.getBrokerID(), a3.m); 
                } catch (Exception exception) {
                  if (a)
                    Trace.checkpoint(Trace.CP1, 5, 22, 8, exception.toString()); 
                } 
                str = xMLAdapterInfo.getServerAddress();
              } 
              try {
                setServerAddress(str);
                setBroker(broker);
              } catch (BrokerException brokerException) {
                if (a)
                  Trace.checkpoint(Trace.CP1, 5, 22, 8, brokerException.toString()); 
              } 
              a((XMLAdapter)object);
            } else if (a) {
              Trace.checkpoint(Trace.CP1, 5, 22, 8, "Class is no valid XmlAdapter.");
            } 
          } else if (a) {
            Trace.checkpoint(Trace.CP1, 5, 22, 8, "No valid Class file found.");
          } 
        } catch (Exception exception) {
          if (a)
            Trace.checkpoint(Trace.CP1, 5, 22, 8, "No valid Class file found."); 
        } 
      } else {
        XMMInfo xMMInfo = new XMMInfo(paramString);
        Broker broker = null;
        String str = null;
        if (xMMInfo != null) {
          try {
            if (xMMInfo.getBrokerID() != null)
              broker = new Broker(xMMInfo.getBrokerID(), a3.m); 
          } catch (Exception exception) {
            if (a)
              Trace.checkpoint(Trace.CP1, 5, 22, 8, exception.toString()); 
          } 
          str = xMMInfo.getServerAddress();
        } 
        try {
          setServerAddress(str);
          setBroker(broker);
        } catch (BrokerException brokerException) {
          if (a)
            Trace.checkpoint(Trace.CP1, 5, 22, 8, brokerException.toString()); 
        } 
        c(paramString);
      } 
    } else if (a) {
      Trace.checkpoint(Trace.CP1, 5, 22, 8, "Invalid file name = " + paramString);
    } 
  }
  
  private ay c(String paramString) {
    bf bf = null;
    try {
      InputStreamReader inputStreamReader = null;
      EntireXFileLoader entireXFileLoader = new EntireXFileLoader(paramString);
      BufferedInputStream bufferedInputStream = new BufferedInputStream(entireXFileLoader.getFileAsInputStream());
      cy cy = new cy();
      cy.a(bufferedInputStream);
      String str = cy.c();
      inputStreamReader = new InputStreamReader(bufferedInputStream, str);
      SAXParserLoader sAXParserLoader;
      SAXParser sAXParser = (sAXParserLoader = new SAXParserLoader()).getSAXParser();
      bf = new bf(paramString, this.b, a3.b);
      InputSource inputSource = new InputSource(new LineNumberReader(inputStreamReader));
      sAXParser.parse(inputSource, bf);
      bf.a();
    } catch (Exception exception) {
      if (a || XMLServlet.ap)
        Trace.checkpoint(Trace.CP1, 5, 20, 98, exception.toString()); 
    } 
    return bf.b();
  }
  
  public String invokeXML(String paramString) throws BrokerException, XMLException {
    StringWriter stringWriter = new StringWriter();
    invokeXML(new StringReader(paramString), stringWriter);
    return stringWriter.toString();
  }
  
  public byte[] invokeXML(byte[] paramArrayOfByte) throws BrokerException, XMLException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    invokeXML(byteArrayInputStream, byteArrayOutputStream);
    return byteArrayOutputStream.toByteArray();
  }
  
  public void invokeXML(Reader paramReader, Writer paramWriter) throws BrokerException, XMLException {
    if (this.k == null)
      this.k = new bo(); 
    this.e = k();
    this.k.c(e());
    cz cz = new cz(this.b);
    cz.a(this);
    cz.a(paramReader, paramWriter, this.k);
    this.d = this.e;
    b(this.k.c());
  }
  
  public void invokeXML(InputStream paramInputStream, OutputStream paramOutputStream) throws BrokerException, XMLException {
    if (this.k == null)
      this.k = new bo(); 
    this.e = k();
    this.k.c(e());
    cz cz = new cz(this.b);
    cz.a(this);
    cz.a(paramInputStream, paramOutputStream, this.k);
    this.d = this.e;
    b(this.k.c());
  }
  
  protected void a(InputStream paramInputStream, OutputStream paramOutputStream, bo parambo) throws BrokerException, XMLException {
    this.e = k();
    cz cz = new cz(this.b);
    cz.a(this);
    cz.a(paramInputStream, paramOutputStream, parambo);
    this.d = this.e;
  }
  
  protected void b(String paramString) { this.c = paramString; }
  
  protected String e() { return this.c; }
  
  protected Conversation f() { return this.d; }
  
  protected Conversation g() {
    if (this.j) {
      this.j = false;
      if (this.e == null) {
        this.e = new Conversation(this);
        setConversation(this.e);
      } 
    } 
    return this.e;
  }
  
  protected void h() { this.j = true; }
  
  protected bo i() {
    if (this.k == null)
      this.k = new bo(); 
    return this.k;
  }
  
  public boolean isInUse() { return this.g; }
  
  public void beFree() {
    if (isConversational())
      resume(); 
    this.g = false;
  }
  
  public String getPoolKey() { return this.h; }
  
  public void setPoolKey(String paramString) { this.h = paramString; }
  
  public void reserve() { this.g = true; }
  
  public void resume() { this.f = System.currentTimeMillis(); }
  
  public boolean isConversational() { return this.i; }
  
  public void isConversational(boolean paramBoolean) { this.i = paramBoolean; }
  
  public boolean isTimedOut(int paramInt) {
    int m = (int)(System.currentTimeMillis() - this.f);
    return (m > paramInt);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\XMLRPCService.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */