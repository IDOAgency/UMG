package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.base.a5;

public class cy extends a5 {
  protected bo a = null;
  
  public cy() {}
  
  public cy(bo parambo) { this.a = parambo; }
  
  protected void a() {
    if (this.a != null) {
      this.a.c(this.b);
      if (this.c != null) {
        this.a.e(this.c);
      } else {
        this.a.e(this.b.toUpperCase());
      } 
      this.a.g(this.d);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\cy.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */