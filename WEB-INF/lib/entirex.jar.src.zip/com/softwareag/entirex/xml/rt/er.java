package com.softwareag.entirex.xml.rt;

import org.w3c.dom.Element;

public class er {
  private String a = null;
  
  private Element b = null;
  
  private int c = 0;
  
  private er() {}
  
  public er(String paramString) { this.a = paramString; }
  
  public void a(Element paramElement) { this.b = (Element)paramElement.cloneNode(true); }
  
  public Element a() { return this.b; }
  
  public String b() { return this.a; }
  
  public void a(String paramString) { this.a = paramString; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\er.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */