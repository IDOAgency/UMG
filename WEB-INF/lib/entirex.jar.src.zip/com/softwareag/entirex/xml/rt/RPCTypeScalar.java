package com.softwareag.entirex.xml.rt;

public class RPCTypeScalar extends RPCType {
  protected String a = null;
  
  public RPCTypeScalar() { this(0, 3); }
  
  public RPCTypeScalar(String paramString) { this(paramString, 0, 3); }
  
  public RPCTypeScalar(String paramString, int paramInt) { this(paramString, paramInt, 3); }
  
  public RPCTypeScalar(int paramInt1, int paramInt2) { super(paramInt1, paramInt2); }
  
  public RPCTypeScalar(String paramString, int paramInt1, int paramInt2) { super(paramString, paramInt1, paramInt2); }
  
  public cp createValueNode() { return new co(this, this.a); }
  
  public void setDefaultValue(String paramString) { this.a = paramString; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\RPCTypeScalar.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */