package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.base.XMLFileLoader;
import com.softwareag.entirex.trace.Trace;
import java.io.BufferedReader;
import java.io.LineNumberReader;
import javax.xml.parsers.SAXParser;
import org.xml.sax.InputSource;

public class XMMInfo {
  protected String a = null;
  
  protected String b = null;
  
  protected String c = null;
  
  protected String d = null;
  
  protected String e = null;
  
  protected boolean f = false;
  
  protected XMMInfo() {}
  
  public XMMInfo(String paramString) { this(paramString, null); }
  
  public XMMInfo(String paramString1, String paramString2) {
    this.f = Trace.on(5, this);
    if (this.f)
      Trace.checkpoint(Trace.CP4, 6, 23, 8, "XMMInfo ctor"); 
    this.a = null;
    this.b = null;
    a(paramString1, paramString2);
  }
  
  private void a(String paramString1, String paramString2) {
    if (this.f)
      Trace.checkpoint(Trace.CP4, 6, 23, 8, "XMMInfo reading XMM file=" + paramString1); 
    ay ay = new ay();
    try {
      ar ar = new ar();
      ar.a(ay);
      SAXParserLoader sAXParserLoader;
      SAXParser sAXParser = (sAXParserLoader = new SAXParserLoader()).getSAXParser();
      XMLFileLoader xMLFileLoader = new XMLFileLoader(paramString1);
      xMLFileLoader.setWorkingDirectory(paramString2);
      BufferedReader bufferedReader = new BufferedReader(xMLFileLoader.i());
      ba ba = new ba(ar);
      sAXParser.parse(new InputSource(new LineNumberReader(bufferedReader)), ba);
      ay = ar.u();
    } catch (Exception exception) {
      throw new IllegalArgumentException(exception.toString());
    } 
    this.a = ay.b();
    this.b = ay.c();
    this.c = ay.d();
    this.d = ay.e();
    this.e = ay.f();
  }
  
  public String getBrokerID() { return this.a; }
  
  public String getServerAddress() { return this.b; }
  
  public String getLogicalBrokerID() { return this.c; }
  
  public String getLogicalService() { return this.d; }
  
  public String getLogicalSetName() { return this.e; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\XMMInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */