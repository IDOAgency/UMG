package com.softwareag.entirex.xml.rt;

public class av {
  private static final String a = "'";
  
  private String b = null;
  
  private String c = null;
  
  private String d = null;
  
  private String e = null;
  
  private String f = null;
  
  public av(String paramString1, String paramString2, String paramString3) {
    this.b = paramString2;
    this.c = paramString1;
    this.d = paramString3;
    if ((this.c == null || this.c.equals("")) && this.b != null && this.b.equals("xml"))
      this.c = "http://www.w3.org/XML/1998/namespace"; 
    this.e = a(paramString1, paramString3);
    if (this.b == null || this.b.equals("")) {
      this.f = this.d;
    } else {
      this.f = this.b + ":" + this.d;
    } 
  }
  
  public String a() { return this.d; }
  
  public String b() { return this.f; }
  
  public String c() { return this.e; }
  
  public String d() {
    String str = this.b;
    if (str == null)
      str = ""; 
    return str;
  }
  
  public void a(String paramString) { this.b = paramString; }
  
  public String e() {
    if (this.c == null)
      this.c = ""; 
    return this.c;
  }
  
  public void b(String paramString) { this.c = paramString; }
  
  public static String a(String paramString1, String paramString2, String paramString3, String paramString4) {
    null = "";
    String str = "";
    if (paramString4.equals("")) {
      int i = paramString3.indexOf(":");
      if (i >= 0) {
        str = paramString3.substring(i + 1);
      } else {
        str = paramString3;
      } 
    } else {
      str = paramString4;
    } 
    if (paramString2 != null)
      if (paramString2.endsWith("/")) {
        null = "'" + paramString2.substring(0, paramString2.length() - 1) + "'";
      } else if (paramString2.length() > 0) {
        null = "'" + paramString2 + "'";
      }  
    return null + str;
  }
  
  public static String a(String paramString1, String paramString2) {
    null = "";
    int i = paramString2.lastIndexOf('\'');
    if (i == -1)
      i = 0; 
    int j = paramString2.indexOf(':', i);
    if (j >= 0)
      paramString2 = paramString2.substring(j + 1); 
    if (paramString1 != null)
      if (paramString1.endsWith("/")) {
        null = "'" + paramString1.substring(0, paramString1.length() - 1) + "'";
      } else if (paramString1.length() > 0) {
        null = "'" + paramString1 + "'";
      }  
    return null + paramString2;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\av.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */