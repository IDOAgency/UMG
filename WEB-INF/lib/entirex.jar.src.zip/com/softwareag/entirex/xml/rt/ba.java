package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ba extends DefaultHandler {
  private static final String a = "EntireXMapDef";
  
  private static final String b = "Description";
  
  private static final String c = "EntireXBrokerInfo";
  
  private static final String d = "BrokerId";
  
  private static final String e = "ServerAddress";
  
  private static final String f = "LogicalBrokerId";
  
  private static final String g = "LogicalService";
  
  private static final String h = "LogicalSet";
  
  private boolean i = false;
  
  private ay j = null;
  
  private boolean k = false;
  
  private boolean l = false;
  
  private boolean m = false;
  
  private ar n = null;
  
  private StringBuffer o = new StringBuffer();
  
  public ba(ar paramar) {
    this.i = Trace.on(5, this);
    this.n = paramar;
  }
  
  public void startDocument() {
    if (this.i)
      Trace.checkpoint(Trace.CP4, 5, 43, 43); 
    this.j = new ay();
  }
  
  public void startElement(String paramString1, String paramString2, String paramString3, Attributes paramAttributes) {
    try {
      if (paramString3.equals("EntireXMapDef")) {
        this.k = true;
      } else if (paramString3.equals("Description")) {
        if (this.k)
          this.l = true; 
      } else if (paramString3.equals("EntireXBrokerInfo") && this.l) {
        this.m = true;
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } finally {
      if (this.m && this.i)
        Trace.checkpoint(Trace.CP4, 5, 43, 44, "qName", paramString3); 
    } 
  }
  
  public void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2) throws SAXException {
    this.o = new StringBuffer();
    this.o.append(paramArrayOfChar, paramInt1, paramInt2);
    if (this.l && this.i) {
      String str = this.o.toString();
      if (str != null && str.trim().length() > 0)
        Trace.checkpoint(Trace.CP4, 5, 43, 5, "characters", str); 
    } 
  }
  
  public void endElement(String paramString1, String paramString2, String paramString3) throws SAXException {
    if (this.m && this.i)
      Trace.checkpoint(Trace.CP4, 5, 43, 11, "qName", paramString3); 
    try {
      if (paramString3.equals("EntireXMapDef")) {
        this.k = false;
      } else if (paramString3.equals("Description")) {
        if (this.k)
          this.l = false; 
      } else if (paramString3.equals("EntireXBrokerInfo")) {
        if (this.l)
          this.m = false; 
      } else if (paramString3.equals("BrokerId")) {
        if (this.m)
          a("BrokerId"); 
      } else if (paramString3.equals("ServerAddress")) {
        if (this.m)
          a("ServerAddress"); 
      } else if (paramString3.equals("LogicalBrokerId")) {
        if (this.m)
          a("LogicalBrokerId"); 
      } else if (paramString3.equals("LogicalService")) {
        if (this.m)
          a("LogicalService"); 
      } else if (paramString3.equals("LogicalSet") && this.m) {
        a("LogicalSet");
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public void endDocument() {
    if (this.i)
      Trace.checkpoint(Trace.CP4, 5, 43, 10); 
    this.n.a(this.j);
  }
  
  private void a(String paramString) {
    String str = this.o.toString().trim();
    if (str.length() > 0) {
      if (this.i)
        Trace.parameter(Trace.MP4, 5, 43, 106, paramString, str); 
      if (paramString.equals("BrokerId")) {
        this.j.a(str);
      } else if (paramString.equals("ServerAddress")) {
        this.j.b(str);
      } else if (paramString.equals("LogicalBrokerId")) {
        this.j.c(str);
      } else if (paramString.equals("LogicalService")) {
        this.j.d(str);
      } else if (paramString.equals("LogicalSet")) {
        this.j.e(str);
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\ba.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */