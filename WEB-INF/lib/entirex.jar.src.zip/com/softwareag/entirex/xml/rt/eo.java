package com.softwareag.entirex.xml.rt;

import java.io.IOException;

public class eo {
  private static final String a = "&apos;";
  
  private static final String b = "&quot;";
  
  private static final String c = "&lt;";
  
  private static final String d = "&gt;";
  
  private static final String e = "&amp;";
  
  protected byte[] f = null;
  
  protected byte[] g = null;
  
  protected byte[] h = null;
  
  protected byte[] i = null;
  
  protected byte[] j = null;
  
  public eo(String paramString) {
    try {
      this.f = "&apos;".getBytes(paramString);
      this.g = "&quot;".getBytes(paramString);
      this.h = "&lt;".getBytes(paramString);
      this.i = "&gt;".getBytes(paramString);
      this.j = "&amp;".getBytes(paramString);
    } catch (IOException iOException) {}
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\eo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */