package com.softwareag.entirex.xml.rt;

class c3 extends cq {
  protected c4 a = new c4();
  
  private c3 b = null;
  
  private int c = -1;
  
  private Object d = null;
  
  private String e = "";
  
  private int f = 0;
  
  private boolean g = false;
  
  public void a(boolean paramBoolean) { this.g = paramBoolean; }
  
  public boolean b() { return this.g; }
  
  public c3(XMLTypeElement paramXMLTypeElement) { this(null, paramXMLTypeElement, null); }
  
  protected c3(XMLTypeElement paramXMLTypeElement, c3 paramc3) { this(null, paramXMLTypeElement, paramc3); }
  
  protected c3(cq paramcq, XMLTypeElement paramXMLTypeElement, c3 paramc3) {
    super.b = paramXMLTypeElement;
    if (super.b != null) {
      this.e = ((XMLTypeElement)super.b).getNullValue();
    } else {
      this.e = "";
    } 
    if (paramcq != null)
      paramcq.b(paramc3); 
    if (paramc3 != null)
      b(paramc3); 
  }
  
  public Object clone() {
    c3 c31 = null;
    c31 = d().createValueNode();
    c31.e = this.e;
    c31.c = this.c;
    c31.a((c4)k().clone());
    return c31;
  }
  
  protected void f() { this.e = new String(((XMLTypeElement)super.b).getNullValue()); }
  
  public void a(String paramString) {
    if (paramString != null) {
      if (this.f == 0 || d().getInternalDataType() != 0) {
        this.e = paramString.trim();
      } else {
        this.e = paramString;
      } 
    } else {
      this.e = "";
    } 
  }
  
  public void b(String paramString) { this.e = paramString; }
  
  public String c() {
    String str = this.e;
    if (str.equals(((XMLTypeElement)super.b).getNullValue())) {
      String str1 = ((XMLTypeElement)super.b).getDefaultValue();
      if (str1 != null)
        str = str1; 
    } 
    if (this.f == 0)
      str = str.trim(); 
    return str;
  }
  
  public XMLTypeElement d() { return (XMLTypeElement)super.b; }
  
  protected static void a(c3 paramc3, int paramInt) {
    System.out.print(paramInt + ": " + ((XMLTypeElement)paramc3.b).getInternalName() + "  (" + ((paramc3.i() == null) ? "-" : "+") + ")" + "  value=" + paramc3.c());
    int i = paramc3.k().a();
    for (byte b1 = 0; b1 < i; b1++)
      System.out.print("  att=" + paramc3.a.a(b1).a().c() + " (" + paramc3.a.a(b1).b() + ")"); 
    System.out.println();
    for (byte b2 = 0; b2 < paramc3.g(); b2++)
      a((c3)paramc3.a(b2), paramInt + 1); 
  }
  
  public c4 k() { return this.a; }
  
  public void a(c4 paramc4) { this.a = paramc4; }
  
  protected void b(int paramInt) { this.f = paramInt; }
  
  protected int l() { return this.f; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\c3.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */