package com.softwareag.entirex.xml.rt;

public class RPCTypeString extends RPCTypeScalar {
  public RPCTypeString() { this(7, 3); }
  
  public RPCTypeString(String paramString) { this(paramString, 7, 3); }
  
  public RPCTypeString(int paramInt) { this(7, 3, paramInt); }
  
  public RPCTypeString(String paramString, int paramInt) { this(paramString, 7, 3, paramInt); }
  
  public RPCTypeString(String paramString, int paramInt1, int paramInt2) { this(paramString, 7, paramInt2, paramInt1); }
  
  public RPCTypeString(String paramString, int paramInt1, int paramInt2, int paramInt3) {
    super(paramString, paramInt1, paramInt2);
    this.j = paramInt3;
  }
  
  public RPCTypeString(int paramInt1, int paramInt2, int paramInt3) {
    super(paramInt1, paramInt2);
    this.j = paramInt3;
  }
  
  public RPCTypeString(int paramInt1, int paramInt2) {
    this.j = paramInt1;
    setDirection(paramInt2);
  }
  
  public cp createRPCValueNode() { return new co(this, ""); }
  
  protected void a(boolean paramBoolean) { this.m = paramBoolean; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\RPCTypeString.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */