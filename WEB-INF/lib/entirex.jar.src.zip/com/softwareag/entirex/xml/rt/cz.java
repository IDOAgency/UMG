package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.Broker;
import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.BrokerMessage;
import com.softwareag.entirex.aci.Conversation;
import com.softwareag.entirex.aci.ao;
import com.softwareag.entirex.aci.be;
import com.softwareag.entirex.base.s;
import com.softwareag.entirex.trace.Trace;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;

public class cz {
  private ar a = null;
  
  private c0 b = null;
  
  private bo c = null;
  
  private XMLRPCService d = null;
  
  public cz(ar paramar) {
    this.a = paramar;
    this.b = new c0(this.a);
  }
  
  public void a(XMLRPCService paramXMLRPCService) { this.d = paramXMLRPCService; }
  
  public cp a(cp paramcp, bo parambo) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M3, 5, 28, 94); 
    this.c = parambo;
    null = null;
    c3 c3 = null;
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(new byte[0]);
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    this.b.a(null);
    this.b.a(null);
    this.b.a(byteArrayInputStream);
    this.b.a(byteArrayOutputStream);
    this.b.a(this.c);
    de de = new de(this.a, this.c);
    c3 = de.a(paramcp);
    this.b.a(c3);
    eh eh = new eh();
    eh.a(this.c);
    String str1 = this.c.aa();
    String str2 = this.c.j();
    String str3 = this.a.e(str1, str2);
    if (XMLRPCService.a) {
      Trace.checkpoint(Trace.CP2, 5, 28, 99, "Library=" + str1 + " Program=" + str2);
      Trace.checkpoint(Trace.CP2, 5, 28, 99, "Mapping file=" + str3);
    } 
    eh.a(this.a.o(str3));
    InputStream inputStream = eh.a(byteArrayOutputStream);
    this.b.a(inputStream);
    c3 = this.b.e();
    return de.a(c3);
  }
  
  public void a(Reader paramReader, Writer paramWriter, bo parambo) throws XMLException, BrokerException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M1, 5, 28, 99); 
    this.c = parambo;
    try {
      this.b.a(null);
      this.b.a(null);
      this.b.a(paramReader);
      this.b.a(paramWriter);
      this.b.a(parambo);
      a();
    } catch (Exception exception) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 28, 99, "Exception:" + exception); 
      if (exception instanceof XMLException) {
        this.c.a(((XMLException)exception).getErrorClass(), ((XMLException)exception).getErrorCode(), ((XMLException)exception).getErrorText());
      } else {
        this.c.a(2000, 5, exception.toString());
      } 
      String str = this.a.a("entirex.sdk.xml.runtime.throwJavaException").toLowerCase();
      if (str != null && (str.startsWith("y") || str.equalsIgnoreCase("true"))) {
        if (exception instanceof XMLException)
          throw (XMLException)exception; 
        if (exception instanceof BrokerException)
          throw (BrokerException)exception; 
        throw new XMLException(5, exception.toString());
      } 
      parambo.a(true);
      parambo.b("faultcode", "Client");
      parambo.b("faultstring", exception.toString());
      de de = new de(this.a, this.c);
      c3 c3 = de.a(null);
      this.b.a(c3);
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M1, 5, 28, 99); 
  }
  
  public void a(InputStream paramInputStream, OutputStream paramOutputStream, bo parambo) throws XMLException, BrokerException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M1, 5, 28, 99); 
    this.c = parambo;
    try {
      this.b = new c0(this.a);
      this.b.a(null);
      this.b.a(null);
      this.b.a(paramInputStream);
      this.b.a(paramOutputStream);
      this.b.a(parambo);
      a();
    } catch (Exception exception) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 28, 99, "Exception:" + exception); 
      if (exception instanceof XMLException) {
        this.c.a(((XMLException)exception).getErrorClass(), ((XMLException)exception).getErrorCode(), ((XMLException)exception).getErrorText());
      } else {
        this.c.a(2000, 5, exception.toString());
      } 
      String str = this.a.a("entirex.sdk.xml.runtime.throwJavaException");
      if (str != null && (str.toLowerCase().startsWith("y") || str.equalsIgnoreCase("true"))) {
        if (exception instanceof XMLException)
          throw (XMLException)exception; 
        if (exception instanceof BrokerException)
          throw (BrokerException)exception; 
        throw new XMLException(5, exception.toString());
      } 
      parambo.a(true);
      parambo.b("faultcode", "Client");
      parambo.b("faultstring", exception.toString());
      de de = new de(this.a, this.c);
      c3 c3 = de.a(null);
      this.b.a(c3);
    } finally {
      if (XMLRPCService.a)
        Trace.leaveMethod(Trace.M1, 5, 28, 99); 
    } 
  }
  
  private void a() throws XMLException {
    if (XMLRPCService.a) {
      Trace.enterMethod(Trace.M1, 5, 28, 99);
      Trace.checkpoint(Trace.CP1, 5, 28, 99, "faultdoc = " + this.c.q());
    } 
    int i = 0;
    this.c.n();
    if (this.a.v())
      this.c.o(this.a.u().u()); 
    c3 c3 = this.b.e();
    if (this.c.q() == true) {
      XMLException xMLException = new XMLException(86);
      this.c.a(xMLException.getErrorClass(), xMLException.getErrorCode(), xMLException.getErrorText());
      this.b.g();
    } else {
      RPCType rPCType = this.a.g();
      rPCType = (RPCType)rPCType.getChild(this.c.y());
      rPCType = (RPCType)rPCType.getChild(this.c.d());
      this.c.b(((RPCTypeProgram)rPCType).g);
      if (this.a.v()) {
        String str = this.a.e(this.c.aa(), this.c.j());
        ay ay = this.a.n(str);
        if (ay != null) {
          ay ay1 = ay.a(this.a.u());
          try {
            String str3 = null;
            String str4 = ay1.g();
            if (str4 == null)
              str4 = a3.m; 
            this.d.setBroker(new Broker(ay1.b(), str4));
            this.d.setServerAddress(ay1.c());
            if (ay1.e() != null && !ay1.e().trim().equals("")) {
              this.d.setLogicalService(ay1.e(), ay1.f());
            } else if (ay1.d() != null && !ay1.d().trim().equals("")) {
              this.d.setLogicalBroker(ay1.d(), ay1.f());
            } 
            str3 = ay1.n();
            if (str3 != null && str3.trim().length() > 0)
              this.d.getBroker().setCompressionLevel(str3); 
            str3 = ay1.m();
            if (str3 != null && str3.trim().length() > 0) {
              boolean bool = (str3.equalsIgnoreCase("true") || str3.equalsIgnoreCase("yes"));
              if (bool)
                this.d.setCompression(bool); 
            } 
            str3 = ay1.i();
            if (str3 != null && str3.trim().length() > 0) {
              boolean bool = (str3.equalsIgnoreCase("true") || str3.equalsIgnoreCase("yes")) ? 1 : 0;
              if (bool) {
                str3 = ay1.j();
                if (str3 != null && str3.trim().length() > 0)
                  this.d.getBroker().useEntireXSecurity(Integer.parseInt(str3)); 
              } 
            } 
            str3 = ay1.g();
            if (str3 != null && str3.trim().length() > 0)
              this.d.getBroker().reconnect(str3); 
            str3 = ay1.s();
            if (str3 != null && str3.trim().length() > 0) {
              this.d.getBroker().logon(str3);
            } else {
              this.d.getBroker().logon();
            } 
            str3 = ay1.k();
            if (str3 != null && str3.trim().length() > 0) {
              boolean bool = (str3.equalsIgnoreCase("true") || str3.equalsIgnoreCase("yes"));
              if (bool) {
                this.d.setNaturalLogon(bool);
                str3 = ay1.l();
                if (str3 != null && str3.trim().length() > 0)
                  this.d.setLibraryName(str3); 
              } 
            } 
            str3 = ay1.h();
            if (str3 != null && str3.trim().length() > 0)
              this.d.setRPCUserId(str3); 
            str3 = ay1.t();
            if (str3 != null && str3.trim().length() > 0)
              this.d.setRPCPassword(str3); 
            str3 = ay1.q();
            if (str3 != null && str3.trim().length() > 0)
              this.d.setDefaultWaittime(str3); 
            str3 = ay1.r();
            if (str3 != null && str3.trim().length() > 0) {
              boolean bool = (str3.equalsIgnoreCase("true") || str3.equalsIgnoreCase("yes"));
              this.d.useCodePage(bool);
            } 
          } catch (BrokerException brokerException) {
            throw new XMLException(brokerException);
          } 
        } 
      } 
      this.c.c(this.d.useCodePage());
      String str1 = this.c.aa();
      String str2 = this.d.getLibraryName();
      if (str2.equals("")) {
        this.c.m(str1);
        this.d.setLibraryName(str1);
      } else {
        this.c.m(str2);
        this.d.setLibraryName(str2);
      } 
      try {
        this.d.setCharacterEncoding(this.c.h());
        this.d.useCodePage(this.c.ad());
        i = this.d.findRpcVersion(this.c.r());
      } catch (BrokerException brokerException) {
        throw new XMLException(brokerException);
      } 
      if (i < this.c.r())
        throw new XMLException(72); 
      de de = new de(this.a, this.c);
      cp cp = de.a(c3);
      this.c.c(this.d.getCompression() ? 2 : 0);
      dh dh = new dh(this.a, this.c, i);
      dh.a(a3.b);
      byte[] arrayOfByte1 = dh.a(cp);
      byte[] arrayOfByte2 = dh.b();
      ao ao = null;
      BrokerMessage brokerMessage1 = null;
      BrokerMessage brokerMessage2 = null;
      try {
        ao ao1 = new ao(arrayOfByte2, arrayOfByte1, this.c.ab(), i, s.a(this.c.h()));
        if (this.d.getNaturalLogon()) {
          ao1.j(this.d.getRPCUserId());
          ao1.k(this.d.getRPCPassword());
          ao1.c(this.d.getNaturalLogon());
        } 
        ao1.b(dh.e());
        ao1.f(this.c.t());
        this.d.setAdjustReceiveLen(true);
        this.d.setMaxReceiveLen(dh.d());
        Conversation conversation = this.d.g();
        if (conversation != null) {
          byte b1 = 2;
          Conversation conversation1 = this.d.f();
          if (conversation1 == null || conversation != conversation1)
            b1 = 1; 
          ao1.e(b1);
          brokerMessage1 = new BrokerMessage(ao1.d());
          brokerMessage2 = conversation.sendReceive(brokerMessage1);
        } else {
          brokerMessage1 = new BrokerMessage(ao1.d());
          brokerMessage2 = this.d.sendReceive(brokerMessage1);
        } 
        ao = new ao(brokerMessage2.getMessage());
      } catch (be be) {
        try {
          try {
            this.d.getController().a(brokerMessage2.getMessage(), s.a(this.c.p()));
          } catch (UnsupportedEncodingException unsupportedEncodingException) {
            throw new XMLException(unsupportedEncodingException);
          } 
        } catch (BrokerException brokerException) {
          throw new XMLException(brokerException);
        } 
      } catch (IOException iOException) {
        throw new XMLException(iOException);
      } catch (BrokerException brokerException) {
        throw new XMLException(brokerException);
      } 
      dh.a(this.d.getMaxReceiveLen());
      dh.a(ao.c(), i);
      cp = dh.a();
      c3 c31 = de.a(cp);
      this.b.a(c31);
      this.b = null;
      dh = null;
      de = null;
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M1, 5, 28, 99); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\cz.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */