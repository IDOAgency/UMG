package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;

public class bj extends Thread {
  private int a;
  
  private bi b;
  
  private boolean c;
  
  public bj(bi parambi, int paramInt) {
    this.a = paramInt;
    this.b = parambi;
    this.c = true;
    if (XMLServlet.ap)
      Trace.checkpoint(Trace.CP4, 6, 4, 8, "create sweeper with time " + paramInt + "ms."); 
  }
  
  public void run() {
    int i = this.a - this.a / 2;
    byte b1 = 0;
    while (this.c) {
      try {
        Thread.sleep(i);
      } catch (InterruptedException interruptedException) {}
      b1++;
      int j = this.b.d();
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP4, 6, 4, 40, "sweepUp().........." + j + "/" + this.b.c()); 
      this.b.a();
      if (b1 > 3) {
        b1 = 0;
        if (XMLServlet.ap)
          Trace.checkpoint(Trace.CP4, 6, 4, 40, "sweepUpFrees().........." + this.b.f()); 
        this.b.b();
      } 
    } 
  }
  
  public void a() { this.c = false; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\bj.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */