package com.softwareag.entirex.xml.rt;

public class c9 extends c7 {
  private static final String a = "1.1";
  
  public c9() { this.c = "1.1"; }
  
  public c9(c0 paramc0) {
    super(paramc0);
    this.c = "1.1";
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\c9.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */