package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.Dump;
import com.softwareag.entirex.base.a4;
import com.softwareag.entirex.trace.Trace;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Stack;
import javax.servlet.ServletContext;
import javax.xml.parsers.SAXParser;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class ar {
  protected static Properties a = new Properties();
  
  protected static final String b = "entirex.sdk.xml.runtime.throwJavaException";
  
  protected static final String c = "entirex.sdk.xml.runtime.useCharacterReference";
  
  protected static final String d = "entirex.sdk.xml.runtime.defaultFaultDocumentFormat";
  
  private RPCType e = new RPCTypeScalar("ROOT", 0);
  
  private XMLTypeElement f = new XMLTypeElement("ROOT");
  
  private XMLTypeElement g = new XMLTypeElement("ROOT");
  
  private XMLTypeElement h = new XMLTypeElement("ROOT");
  
  private XMLTypeElement i = new XMLTypeElement("ROOT");
  
  private ax j = new ax(0, "ROOT");
  
  private ax k = new ax(0, "ROOT");
  
  private XMLTypeElement l = new XMLTypeElement("ROOT");
  
  private XMLTypeElement m = new XMLTypeElement("ROOT");
  
  private ax n = new ax(0, "FAULTROOT");
  
  private ax o = new ax(0, "FAULTROOT");
  
  private ay p = new ay();
  
  private Hashtable q = new Hashtable();
  
  private Hashtable r = new Hashtable();
  
  private Hashtable s = new Hashtable();
  
  private Hashtable t = new Hashtable();
  
  private Hashtable u = new Hashtable();
  
  static ArrayList v;
  
  static ArrayList w;
  
  HashMap x = new HashMap();
  
  HashMap y = new HashMap();
  
  private int z = 0;
  
  private String aa = null;
  
  private String ab = null;
  
  private String ac = null;
  
  private String ad = null;
  
  private String ae = null;
  
  Stack af = new Stack();
  
  boolean ag = false;
  
  protected boolean ah = false;
  
  private static CallbackInterface ai;
  
  protected void a(String paramString1, String paramString2) { a.setProperty(paramString1, paramString2); }
  
  protected String a(String paramString) { return a.getProperty(paramString); }
  
  protected void b(String paramString) {
    if (paramString.equalsIgnoreCase("true")) {
      this.z = 1;
    } else {
      this.z = 2;
    } 
  }
  
  protected void c(String paramString) { this.aa = paramString; }
  
  protected void d(String paramString) { this.ab = paramString; }
  
  protected void e(String paramString) { this.ac = paramString; }
  
  protected void f(String paramString) { this.ad = paramString; }
  
  protected void g(String paramString) { this.ae = paramString; }
  
  protected int a() { return this.z; }
  
  protected String b() {
    String str = this.aa;
    if (str == null)
      str = "utf-8"; 
    return str;
  }
  
  protected String c() {
    String str = this.ab;
    if (str == null)
      str = "utf-8"; 
    return str;
  }
  
  protected String d() {
    String str = this.ac;
    if (str == null)
      str = "utf-8"; 
    return str;
  }
  
  protected String e() {
    String str = this.ad;
    if (str == null)
      str = "utf-8"; 
    return str;
  }
  
  protected String f() {
    String str = this.ae;
    if (str == null)
      str = "utf-8"; 
    return str;
  }
  
  public ar() {
    try {
      w();
    } catch (XMLException xMLException) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 9, 8, xMLException.toString()); 
    } 
    if (XMLRPCService.a) {
      Trace.checkpoint(Trace.CP4, 5, 9, 8);
      Trace.showMemoryUsage(Trace.RM, 5);
    } 
  }
  
  public RPCType g() { return this.e; }
  
  public XMLTypeElement h() { return this.f; }
  
  public XMLTypeElement i() { return this.h; }
  
  public XMLTypeElement j() { return this.g; }
  
  public XMLTypeElement k() { return this.i; }
  
  public XMLTypeElement l() { return this.l; }
  
  public XMLTypeElement m() { return this.m; }
  
  public ax n() { return this.j; }
  
  public ax o() { return this.k; }
  
  public ax p() { return this.n; }
  
  public ax q() { return this.o; }
  
  public static void h(String paramString) { w.add(paramString); }
  
  protected static ArrayList r() { return w; }
  
  protected void i(String paramString) {
    byte b1 = 0;
    int i1 = w.size();
    boolean bool = false;
    for (b1 = 0; b1 <= i1; b1++) {
      if (paramString.equals((String)w.get(b1))) {
        bool = true;
        break;
      } 
    } 
    if (bool == true)
      w.remove(b1); 
  }
  
  public void j(String paramString) { v.add(paramString); }
  
  protected static ArrayList s() { return v; }
  
  public void k(String paramString) {
    byte b1 = 0;
    int i1 = v.size();
    boolean bool = false;
    for (b1 = 0; b1 <= i1; b1++) {
      if (paramString.equals((String)v.get(b1))) {
        bool = true;
        break;
      } 
    } 
    if (bool == true)
      v.remove(b1); 
  }
  
  public void a(BaseNode paramBaseNode) { BaseNode baseNode = this.e.addRecursiveChild(paramBaseNode); }
  
  public void b(BaseNode paramBaseNode) { this.f.addRecursiveChild(paramBaseNode); }
  
  public void c(BaseNode paramBaseNode) { this.g.addRecursiveChild(paramBaseNode); }
  
  public void d(BaseNode paramBaseNode) { this.l.addRecursiveChild(paramBaseNode); }
  
  public void e(BaseNode paramBaseNode) { this.m.addRecursiveChild(paramBaseNode); }
  
  public void b(String paramString1, String paramString2) {
    String str1 = null;
    String str2 = null;
    int i1 = 0;
    int i2 = 0;
    i1 = paramString1.indexOf("/");
    str1 = paramString1.substring(0, i1);
    i2 = paramString1.indexOf("/", i1 + 1);
    if (i2 < 0) {
      str2 = paramString1.substring(i1 + 1);
    } else {
      str2 = paramString1.substring(i1 + 1, i2);
    } 
    a(str1, str2, paramString1, paramString2);
  }
  
  public void a(String paramString1, String paramString2, String paramString3, String paramString4) throws XMLException {
    String str1 = a3.b(paramString1);
    String str2 = a3.b(paramString2);
    int i1 = paramString3.indexOf("/");
    i1 = paramString3.indexOf("/", i1 + 1);
    if (i1 >= 0) {
      paramString3 = str1 + "/" + str2 + paramString3.substring(i1);
    } else {
      i1 = paramString3.indexOf('@');
      if (i1 >= 0) {
        paramString3 = str1 + "/" + str2 + paramString3.substring(i1);
      } else {
        paramString3 = str1 + "/" + str2;
      } 
    } 
    paramString4 = str1 + "/" + str2 + "/" + paramString4;
    this;
    ax.a(this.j, paramString3, paramString4, this.e, this.f);
  }
  
  public void c(String paramString1, String paramString2) {
    String str1 = null;
    String str2 = null;
    int i1 = 0;
    int i2 = 0;
    i1 = paramString2.indexOf("/");
    str1 = paramString2.substring(0, i1);
    i2 = paramString2.indexOf("/", i1 + 1);
    if (i2 < 0) {
      str2 = paramString2.substring(i1 + 1);
    } else {
      str2 = paramString2.substring(i1 + 1, i2);
    } 
    b(str1, str2, paramString1, paramString2);
  }
  
  public void b(String paramString1, String paramString2, String paramString3, String paramString4) throws XMLException {
    String str1 = a3.b(paramString1);
    String str2 = a3.b(paramString2);
    paramString3 = str1 + "/" + str2 + "/" + paramString3;
    int i1 = paramString4.indexOf("/");
    i1 = paramString4.indexOf("/", i1 + 1);
    if (i1 >= 0) {
      paramString4 = str1 + "/" + str2 + paramString4.substring(i1);
    } else {
      i1 = paramString4.indexOf('@');
      if (i1 >= 0) {
        paramString4 = str1 + "/" + str2 + paramString4.substring(i1);
      } else {
        paramString4 = str1 + "/" + str2;
      } 
    } 
    ax.a(this.k, paramString3, paramString4, this.g, this.e);
  }
  
  public void c(String paramString1, String paramString2, String paramString3, String paramString4) throws XMLException {
    String str1 = a3.b(paramString1);
    String str2 = a3.b(paramString2);
    int i1 = paramString3.indexOf("/");
    i1 = paramString3.indexOf("/", i1 + 1);
    if (i1 >= 0) {
      paramString3 = str1 + "/" + str2 + paramString3.substring(i1);
    } else {
      i1 = paramString3.indexOf('@');
      if (i1 >= 0) {
        paramString3 = str1 + "/" + str2 + paramString3.substring(i1);
      } else {
        paramString3 = str1 + "/" + str2;
      } 
    } 
    paramString4 = str1 + "/" + str2 + "/" + paramString4;
    this;
    ax.a(this.n, paramString3, paramString4, this.e, this.l);
  }
  
  public void d(String paramString1, String paramString2, String paramString3, String paramString4) throws XMLException {
    String str1 = a3.b(paramString1);
    String str2 = a3.b(paramString2);
    paramString3 = str1 + "/" + str2 + "/" + paramString3;
    int i1 = paramString4.indexOf("/");
    i1 = paramString4.indexOf("/", i1 + 1);
    if (i1 >= 0) {
      paramString4 = str1 + "/" + str2 + paramString4.substring(i1);
    } else {
      i1 = paramString4.indexOf('@');
      if (i1 >= 0) {
        paramString4 = str1 + "/" + str2 + paramString4.substring(i1);
      } else {
        paramString4 = str1 + "/" + str2;
      } 
    } 
    ax.a(this.o, paramString3, paramString4, this.m, this.e);
  }
  
  public BaseNode a(BaseNode paramBaseNode, RPCType paramRPCType) throws XMLException {
    BaseNode baseNode = null;
    if (paramBaseNode != null) {
      baseNode = paramBaseNode.getChild(paramRPCType.getName());
      if (baseNode == null) {
        baseNode = paramBaseNode.addChild(paramRPCType);
      } else if (((RPCType)baseNode).getRpcTypeId() == 21) {
        throw new XMLException(70, "The library/program definition exists.");
      } 
    } else {
      baseNode = this.e.getChild(paramRPCType.getName());
      if (baseNode == null)
        baseNode = this.e.addChild(paramRPCType); 
    } 
    return baseNode;
  }
  
  public BaseNode a(BaseNode paramBaseNode, XMLTypeElement paramXMLTypeElement) throws XMLException {
    BaseNode baseNode = null;
    if (paramBaseNode != null) {
      baseNode = paramBaseNode.getChild(paramXMLTypeElement.getName());
      if (baseNode == null) {
        baseNode = paramBaseNode.addChild(paramXMLTypeElement);
      } else {
        bd bd1 = paramXMLTypeElement.c();
        bd bd2 = ((XMLTypeElement)baseNode).c();
        if (bd1 != null && bd2 != null) {
          int i1 = bd1.f;
          int i2 = bd2.f;
          if (i1 == i2 && i1 == 3) {
            bd2.a(bd1);
          } else {
            throw new XMLException(70, "Redefintion of program marker.");
          } 
        } else if (bd1 != null || bd2 != null) {
          throw new XMLException(70, "Redefintion of program marker.");
        } 
      } 
    } else {
      baseNode = this.f.getChild(paramXMLTypeElement.getName());
      if (baseNode == null) {
        baseNode = this.f.addChild(paramXMLTypeElement);
      } else {
        bd bd1 = paramXMLTypeElement.c();
        bd bd2 = ((XMLTypeElement)baseNode).c();
        if (bd1 != null && bd2 != null) {
          int i1 = bd1.f;
          int i2 = bd2.f;
          if (i1 == i2 && i1 == 3) {
            bd2.a(bd1);
          } else {
            throw new XMLException(70, "Redefintion of program marker.");
          } 
        } else if (bd1 != null || bd2 != null) {
          throw new XMLException(70, "Redefintion of program marker.");
        } 
      } 
    } 
    return baseNode;
  }
  
  public BaseNode b(BaseNode paramBaseNode, XMLTypeElement paramXMLTypeElement) throws XMLException {
    BaseNode baseNode = null;
    if (paramBaseNode != null) {
      baseNode = paramBaseNode.getChild(paramXMLTypeElement.getName());
      if (baseNode == null) {
        baseNode = paramBaseNode.addChild(paramXMLTypeElement);
      } else {
        bd bd1 = paramXMLTypeElement.c();
        bd bd2 = ((XMLTypeElement)baseNode).c();
        if (bd1 != null && bd2 != null) {
          int i1 = bd1.f;
          int i2 = bd2.f;
          if (i1 == i2 && i1 == 3) {
            bd2.a(bd1);
          } else {
            throw new XMLException(70, "Redefintion of program marker.");
          } 
        } else if (bd1 != null || bd2 != null) {
          throw new XMLException(70, "Redefintion of program marker.");
        } 
      } 
    } else {
      baseNode = this.g.getChild(paramXMLTypeElement.getName());
      if (baseNode == null) {
        baseNode = this.g.addChild(paramXMLTypeElement);
      } else {
        bd bd1 = paramXMLTypeElement.c();
        bd bd2 = ((XMLTypeElement)baseNode).c();
        if (bd1 != null && bd2 != null) {
          int i1 = bd1.f;
          int i2 = bd2.f;
          if (i1 == i2 && i1 == 3) {
            bd2.a(bd1);
          } else {
            throw new XMLException(70, "Redefintion of program marker.");
          } 
        } else if (bd1 != null || bd2 != null) {
          throw new XMLException(70, "Redefintion of program marker.");
        } 
      } 
    } 
    return baseNode;
  }
  
  public BaseNode c(BaseNode paramBaseNode, XMLTypeElement paramXMLTypeElement) throws XMLException {
    BaseNode baseNode = null;
    if (paramBaseNode != null) {
      baseNode = paramBaseNode.getChild(paramXMLTypeElement.getName());
      if (baseNode == null) {
        baseNode = paramBaseNode.addChild(paramXMLTypeElement);
      } else {
        bd bd1 = paramXMLTypeElement.c();
        bd bd2 = ((XMLTypeElement)baseNode).c();
        if (bd1 != null && bd2 != null) {
          int i1 = bd1.f;
          int i2 = bd2.f;
          if (i1 == i2 && i1 == 3) {
            bd2.a(bd1);
          } else {
            throw new XMLException(70, "Redefintion of program marker.");
          } 
        } else if (bd1 != null || bd2 != null) {
          throw new XMLException(70, "Redefintion of program marker.");
        } 
      } 
    } else {
      baseNode = this.l.getChild(paramXMLTypeElement.getName());
      if (baseNode == null) {
        baseNode = this.l.addChild(paramXMLTypeElement);
      } else {
        bd bd1 = paramXMLTypeElement.c();
        bd bd2 = ((XMLTypeElement)baseNode).c();
        if (bd1 != null && bd2 != null) {
          int i1 = bd1.f;
          int i2 = bd2.f;
          if (i1 == i2 && i1 == 3) {
            bd2.a(bd1);
          } else {
            throw new XMLException(70, "Redefintion of program marker.");
          } 
        } else if (bd1 != null || bd2 != null) {
          throw new XMLException(70, "Redefintion of program marker.");
        } 
      } 
    } 
    return baseNode;
  }
  
  public BaseNode a(BaseNode paramBaseNode1, BaseNode paramBaseNode2) throws XMLException {
    BaseNode baseNode = null;
    if (paramBaseNode1 != null) {
      baseNode = paramBaseNode1.getChild(paramBaseNode2.getName());
      if (baseNode == null) {
        baseNode = paramBaseNode1.addChild(paramBaseNode2);
      } else {
        bd bd1 = ((XMLTypeElement)paramBaseNode2).c();
        bd bd2 = ((XMLTypeElement)baseNode).c();
        if (bd1 != null && bd2 != null) {
          int i1 = bd1.f;
          int i2 = bd2.f;
          if (i1 == i2 && i1 == 3) {
            bd2.a(bd1);
          } else {
            throw new XMLException(70, "Redefintion of program marker (fault tree).");
          } 
        } else if (bd1 != null || bd2 != null) {
          throw new XMLException(70, "Redefintion of program marker (fault tree).");
        } 
      } 
    } else {
      baseNode = this.m.getChild(paramBaseNode2.getName());
      if (baseNode == null) {
        baseNode = this.m.addChild(paramBaseNode2);
      } else {
        bd bd1 = ((XMLTypeElement)paramBaseNode2).c();
        bd bd2 = ((XMLTypeElement)baseNode).c();
        if (bd1 != null && bd2 != null) {
          int i1 = bd1.f;
          int i2 = bd2.f;
          if (i1 == i2 && i1 == 3) {
            bd2.a(bd1);
          } else {
            throw new XMLException(70, "Redefintion of program marker (fault tree).");
          } 
        } else if (bd1 != null || bd2 != null) {
          throw new XMLException(70, "Redefintion of program marker (fault tree).");
        } 
      } 
    } 
    return baseNode;
  }
  
  public void t() { a(null, null, a3.b); }
  
  public void l(String paramString) { a(paramString, null, a3.b); }
  
  public void a(ServletContext paramServletContext) throws XMLException { a(null, paramServletContext, a3.b); }
  
  public void a(boolean paramBoolean) throws XMLException { a(null, null, paramBoolean); }
  
  public void a(String paramString, ServletContext paramServletContext, boolean paramBoolean) throws XMLException {
    byte b1 = 0;
    int i1 = v.size();
    for (b1 = 0; b1 < i1; b1++) {
      String str = (String)v.get(b1);
      Dump.log("Loading XMLAdapter: " + str + ".");
      bb bb = new bb(str, this, paramBoolean);
      try {
        bb.a();
      } catch (XMLException xMLException) {
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP1, 5, 9, 93, "Loading XMLAdapter: " + str + " - Failed. Reason:" + xMLException.toString()); 
        Dump.log("Loading XMLAdapter: " + str + " - Failed. Reason:" + xMLException.toString());
        throw xMLException;
      } 
      Dump.log("Loading XMLAdapter: " + str + " - OK.");
    } 
    if (XMLRPCService.a)
      for (b1 = 0; b1 < i1; b1++)
        Trace.checkpoint(Trace.CP1, 5, 9, 93, "Loaded XMLAdapter: " + (String)v.get(b1));  
    i1 = w.size();
    for (b1 = 0; b1 < i1; b1++) {
      String str = (String)w.get(b1);
      Reader reader = null;
      Dump.log("Loading XMM File: " + str + ".");
      try {
        a4 a4 = new a4(str, paramString, paramServletContext);
        reader = a4.i();
      } catch (IOException iOException) {
        Dump.log("Loading XMM File: " + str + " - Failed. Reason:" + iOException.toString());
        throw new XMLException(iOException);
      } 
      try {
        SAXParserLoader sAXParserLoader;
        SAXParser sAXParser = (sAXParserLoader = new SAXParserLoader()).getSAXParser();
        bf bf = new bf(str, this, paramBoolean);
        InputSource inputSource = new InputSource(new LineNumberReader(reader));
        sAXParser.parse(inputSource, bf);
        bf.a();
      } catch (SAXException sAXException) {
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP1, 5, 9, 93, "Loading XMM File: " + str + " - Failed. Reason:" + sAXException.toString()); 
        Dump.log("Loading XMM File: " + str + " - Failed. Reason:" + sAXException.toString());
        throw new XMLException(3, sAXException.toString());
      } catch (IOException iOException) {
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP1, 5, 9, 93, "Loading XMM File: " + str + " - Failed. Reason:" + iOException.toString()); 
        Dump.log("Loading XMM File: " + str + " - Failed. Reason:" + iOException.toString());
        throw new XMLException(iOException);
      } catch (XMLException xMLException) {
        if (XMLRPCService.a)
          Trace.checkpoint(Trace.CP1, 5, 9, 93, "Loading XMM File: " + str + " - Failed. Reason:" + xMLException.toString()); 
        Dump.log("Loading XMM File: " + str + " - Failed. Reason:" + xMLException.toString());
        throw xMLException;
      } 
      Dump.log("Loading XMM File: " + str + " - OK.");
    } 
    if (XMLRPCService.a)
      for (b1 = 0; b1 < i1; b1++)
        Trace.checkpoint(Trace.CP1, 5, 9, 93, "Loaded XMM: " + (String)w.get(b1));  
  }
  
  public RPCType d(String paramString1, String paramString2) {
    RPCType rPCType = null;
    rPCType = (RPCType)this.e.getChild(paramString1);
    if (rPCType != null)
      rPCType = (RPCType)rPCType.getChild(paramString2); 
    return rPCType;
  }
  
  public cw m(String paramString) { return (cw)this.y.get(paramString); }
  
  protected void a(ay paramay) { this.p = paramay; }
  
  protected ay u() { return this.p; }
  
  protected String e(String paramString1, String paramString2) {
    String str = a3.b(paramString1 + "." + paramString2);
    return (String)this.q.get(str);
  }
  
  protected ay n(String paramString) { return (ay)this.r.get(paramString); }
  
  protected cw o(String paramString) { return (cw)this.s.get(paramString); }
  
  protected ay p(String paramString) { return (ay)this.t.get(paramString); }
  
  protected bo q(String paramString) { return (bo)this.u.get(paramString); }
  
  protected cw r(String paramString) { return (cw)this.y.get(paramString); }
  
  protected void a(String paramString1, String paramString2, String paramString3) {
    String str = a3.b(paramString1 + "." + paramString2);
    this.q.put(str, paramString3);
  }
  
  protected void a(String paramString, ay paramay) { this.r.put(paramString, paramay); }
  
  protected void a(String paramString, cw paramcw) { this.s.put(paramString, paramcw); }
  
  protected void b(String paramString, cw paramcw) { this.y.put(paramString, paramcw); }
  
  protected void b(String paramString, ay paramay) { this.t.put(paramString, paramay); }
  
  protected void a(String paramString, bo parambo) { this.u.put(paramString, parambo); }
  
  protected void s(String paramString) {
    this.u.remove(paramString);
    this.t.remove(paramString);
  }
  
  public void a(int paramInt) {}
  
  public void b(int paramInt) {}
  
  protected boolean v() { return this.ah; }
  
  protected void b(boolean paramBoolean) throws XMLException { this.ah = paramBoolean; }
  
  protected void w() {
    byte b1 = 2;
    a0[] arrayOfa0 = { new az(), new a1() };
    RPCType rPCType = g();
    rPCType = (RPCType)rPCType.addChild(new RPCTypeLibrary("0"));
    for (byte b2 = 0; b2 < b1; b2++) {
      XMLTypeElement xMLTypeElement = arrayOfa0[b2].a();
      e(xMLTypeElement);
      d(xMLTypeElement);
      String[][] arrayOfString = arrayOfa0[b2].b();
      String str = "" + b2;
      int i1 = arrayOfString.length;
      for (byte b3 = 0; b3 < i1; b3++) {
        c("0", str, arrayOfString[b3][1], arrayOfString[b3][0]);
        d("0", str, arrayOfString[b3][0], arrayOfString[b3][1]);
      } 
      rPCType.addChild(new RPCTypeProgram(str));
    } 
  }
  
  protected static void a(CallbackInterface paramCallbackInterface) { ai = paramCallbackInterface; }
  
  protected static CallbackInterface x() { return ai; }
  
  static  {
    a.setProperty("entirex.sdk.xml.runtime.throwJavaException", "yes");
    a.setProperty("entirex.sdk.xml.runtime.useCharacterReference", "no");
    a.setProperty("entirex.sdk.xml.runtime.defaultFaultDocumentFormat", "soap");
    v = new ArrayList();
    w = new ArrayList();
    ai = null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\ar.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */