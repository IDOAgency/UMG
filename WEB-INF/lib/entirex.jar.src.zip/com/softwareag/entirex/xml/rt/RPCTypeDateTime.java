package com.softwareag.entirex.xml.rt;

public class RPCTypeDateTime extends RPCTypeScalar {
  public static final int DATE = 0;
  
  public static final int TIME = 1;
  
  private int a = 0;
  
  public RPCTypeDateTime() { this(3, 3, 0); }
  
  public RPCTypeDateTime(int paramInt) { this((paramInt == 0) ? 3 : 8, 3, paramInt); }
  
  public RPCTypeDateTime(int paramInt1, int paramInt2) { this((paramInt1 == 0) ? 3 : 8, paramInt2, paramInt1); }
  
  public RPCTypeDateTime(String paramString) { this(paramString, 3, 3, 0); }
  
  public RPCTypeDateTime(String paramString, int paramInt) { this(paramString, (paramInt == 0) ? 3 : 8, 3, paramInt); }
  
  public RPCTypeDateTime(String paramString, int paramInt1, int paramInt2) { this(paramString, (paramInt1 == 0) ? 3 : 8, paramInt2, paramInt1); }
  
  public RPCTypeDateTime(int paramInt1, int paramInt2, int paramInt3) {
    super(paramInt1, paramInt2);
    this.a = paramInt3;
  }
  
  public RPCTypeDateTime(String paramString, int paramInt1, int paramInt2, int paramInt3) {
    super(paramString, paramInt1, paramInt2);
    this.a = paramInt3;
  }
  
  public void setDefaultValue(String paramString) { setDefaultValue(paramString); }
  
  protected int c() { return this.a; }
  
  public cp createValueNode() { return new co(this, super.a); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\RPCTypeDateTime.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */