package com.softwareag.entirex.xml.rt;

public interface BaseNode extends ChildContainer {
  BaseNode addChild(BaseNode paramBaseNode);
  
  BaseNode addChild(BaseNode paramBaseNode, boolean paramBoolean);
  
  BaseNode addRecursiveChild(BaseNode paramBaseNode);
  
  BaseNode getChild(String paramString);
  
  int getChildCount();
  
  BaseNode getChild(int paramInt);
  
  int getChildCount(String paramString);
  
  BaseNode getChild(String paramString, int paramInt);
  
  String getName();
  
  void setName(String paramString);
  
  BaseNode getParent();
  
  void setParent(BaseNode paramBaseNode);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\BaseNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */