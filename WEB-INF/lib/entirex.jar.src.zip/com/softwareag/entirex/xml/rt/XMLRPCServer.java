package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.BrokerMessage;
import com.softwareag.entirex.aci.BrokerService;
import com.softwareag.entirex.aci.Dump;
import com.softwareag.entirex.aci.EntireXVersion;
import com.softwareag.entirex.aci.ao;
import com.softwareag.entirex.aci.b;
import com.softwareag.entirex.aci.be;
import com.softwareag.entirex.trace.Trace;
import java.util.ArrayList;
import java.util.Properties;

public class XMLRPCServer extends b {
  private static final int a = 2000;
  
  private static final String b = EntireXVersion.getVersion() + " " + System.getProperty("os.name") + " " + System.getProperty("os.version") + " " + System.getProperty("os.arch") + ".";
  
  private static final String c = "EntireX XML RPC Server " + b;
  
  static ar d = new ar();
  
  private Properties e = new Properties();
  
  private el f = null;
  
  protected static final String g = "javax.xml.parsers.SAXParserFactory";
  
  protected static final String h = "javax.xml.parsers.SAXParser";
  
  protected static final String i = "javax.xml.parsers.DocumentBuilderFactory";
  
  protected static final String j = "javax.xml.parsers.DocumentBuilder";
  
  protected static final String k = "http.proxyHost";
  
  protected static final String l = "http.proxyPort";
  
  protected static final String m = "https.proxyHost";
  
  protected static final String n = "https.proxyPort";
  
  private static final String o = "entirex.sdk.xml.runtime.xmlparserfactory";
  
  private static final String p = "entirex.sdk.xml.runtime.xmlparser";
  
  private static final String q = "entirex.sdk.xml.runtime.documentbuilderfactory";
  
  private static final String r = "entirex.sdk.xml.runtime.documentbuilder";
  
  private static final String s = "entirex.sdk.xml.runtime.configurationfile";
  
  private static final String t = "entirex.xml.runtime.configuration.xml";
  
  private static final String u = "entirex.xml.runtime.properties";
  
  protected static final String v = "org.apache.xerces.jaxp.SAXParserFactoryImpl";
  
  protected static final String w = "org.apache.xerces.jaxp.SAXParserImpl";
  
  protected static final String x = "org.apache.xerces.jaxp.DocumentBuilderFactoryImpl";
  
  protected static final String y = "org.apache.xerces.jaxp.DocumentBuilderImpl";
  
  private String z = "entirex.xml.runtime.properties";
  
  private String aa = "entirex.xml.runtime.configuration.xml";
  
  protected static ar ad() { return d; }
  
  public XMLRPCServer() {
    XMLRPCService.a = Trace.on(5, this);
    if (XMLRPCService.a) {
      Trace.checkpoint(Trace.M1, 5, 29, 8);
      Trace.showMemoryUsage(Trace.RM, 5);
    } 
  }
  
  public void startXMLRPCServer(String[] paramArrayOfString) {
    if (XMLRPCService.a)
      Trace.checkpoint(Trace.M1, 5, 29, 92); 
    f(c);
    ao.b(c);
    ay ay = new ay();
    d.a(ay);
    g(this.z);
    a(paramArrayOfString);
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M1, 5, 29, 92); 
    Dump.log("Stopping XMLRPCServer.");
  }
  
  private void ae() {
    if (System.getProperty("javax.xml.parsers.SAXParserFactory") == null || System.getProperty("javax.xml.parsers.SAXParser") == null) {
      System.setProperty("javax.xml.parsers.SAXParserFactory", "org.apache.xerces.jaxp.SAXParserFactoryImpl");
      System.setProperty("javax.xml.parsers.SAXParser", "org.apache.xerces.jaxp.SAXParserImpl");
    } 
    if (System.getProperty("javax.xml.parsers.DocumentBuilderFactory") == null || System.getProperty("javax.xml.parsers.DocumentBuilder") == null) {
      System.setProperty("javax.xml.parsers.DocumentBuilderFactory", "org.apache.xerces.jaxp.DocumentBuilderFactoryImpl");
      System.setProperty("javax.xml.parsers.DocumentBuilder", "org.apache.xerces.jaxp.DocumentBuilderImpl");
    } 
  }
  
  protected void b() {
    Properties properties = ab();
    byte b1 = 17;
    String[][] arrayOfString = { 
        { "entirex.sdk.xml.runtime.name", "entirex.server.name" }, { "entirex.sdk.xml.runtime.brokerid", "entirex.server.brokerid" }, { "entirex.sdk.xml.runtime.serveraddress", "entirex.server.serveraddress" }, { "entirex.sdk.xml.runtime.logicalsetname", "entirex.server.logicalsetname" }, { "entirex.sdk.xml.runtime.logicalbrokerid", "entirex.server.logicalbrokerid" }, { "entirex.sdk.xml.runtime.logicalservice", "entirex.server.logicalservice" }, { "entirex.sdk.xml.runtime.userid", "entirex.server.userid" }, { "entirex.sdk.xml.runtime.password", "entirex.server.password" }, { "entirex.sdk.xml.runtime.compresslevel", "entirex.server.compresslevel" }, { "entirex.sdk.xml.runtime.security", "entirex.server.security" }, 
        { "entirex.sdk.xml.runtime.encryptionlevel", "entirex.server.encryptionlevel" }, { "entirex.sdk.xml.runtime.serverlog", "entirex.server.serverlog" }, { "entirex.sdk.xml.runtime.restartcycles", "entirex.server.restartcycles" }, { "entirex.sdk.xml.runtime.monitorport", "entirex.server.monitorport" }, { "entirex.trace", "entirex.trace" }, { "entirex.sdk.xml.runtime.verbose", "entirex.server.verbose" }, { "entirex.sdk.xml.runtime.codepage", "entirex.server.codepage" } };
    String str = null;
    for (byte b2 = 0; b2 < b1; b2++) {
      str = properties.getProperty(arrayOfString[b2][0]);
      if (str != null)
        properties.put(arrayOfString[b2][1], str); 
    } 
    str = properties.getProperty("entirex.sdk.xml.runtime.documentbuilder");
    if (str != null)
      System.setProperty("javax.xml.parsers.DocumentBuilder", str); 
    str = properties.getProperty("entirex.sdk.xml.runtime.documentbuilderfactory");
    if (str != null)
      System.setProperty("javax.xml.parsers.DocumentBuilderFactory", str); 
    str = properties.getProperty("entirex.sdk.xml.runtime.xmlparser");
    if (str != null)
      System.setProperty("javax.xml.parsers.SAXParser", str); 
    str = properties.getProperty("entirex.sdk.xml.runtime.xmlparserfactory");
    if (str != null)
      System.setProperty("javax.xml.parsers.SAXParserFactory", str); 
    str = properties.getProperty("entirex.sdk.xml.runtime.https.proxy");
    if (str != null)
      System.setProperty("https.proxyHost", str); 
    str = properties.getProperty("entirex.sdk.xml.runtime.https.port");
    if (str != null)
      System.setProperty("https.proxyPort", str); 
    str = properties.getProperty("entirex.sdk.xml.runtime.http.proxy");
    if (str != null)
      System.setProperty("http.proxyHost", str); 
    str = properties.getProperty("entirex.sdk.xml.runtime.http.port");
    if (str != null)
      System.setProperty("http.proxyPort", str); 
    ae();
    str = properties.getProperty("entirex.sdk.xml.runtime.defaultFaultDocumentFormat");
    if (str != null)
      d.a("entirex.sdk.xml.runtime.defaultFaultDocumentFormat", str); 
    str = properties.getProperty("entirex.sdk.xml.runtime.useCharacterReference");
    if (str != null)
      d.a("entirex.sdk.xml.runtime.useCharacterReference", str); 
  }
  
  protected void a(BrokerService paramBrokerService) throws BrokerException {}
  
  protected void a() {}
  
  protected byte[] b(byte[] paramArrayOfByte) {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M3, 5, 29, 53); 
    byte[] arrayOfByte = null;
    boolean bool = false;
    int i1 = 1110;
    ao ao1 = null;
    ao ao2 = null;
    BrokerMessage brokerMessage = null;
    dh dh = null;
    cp cp = null;
    try {
      byte[] arrayOfByte1;
      cz cz;
      bo bo;
      try {
        ao1 = new ao(paramArrayOfByte);
      } catch (Exception exception) {
        throw new XMLException(87, "Cannot create RPC Message.");
      } 
      i1 = ao1.e();
      int i2 = ao1.v();
      switch (i2) {
        case 3:
        case 4:
          arrayOfByte = paramArrayOfByte;
          break;
        case 7:
          try {
            String str = ao.c(paramArrayOfByte);
            ao2 = ao.b(2000);
            brokerMessage = new BrokerMessage(ao2.d());
            arrayOfByte = brokerMessage.getMessage();
          } catch (be be) {
            throw new XMLException(87, "Cannot create RPC Message.");
          } 
          break;
        case 6:
          ao2 = ao1.m(c);
          brokerMessage = new BrokerMessage(ao2.d());
          arrayOfByte = brokerMessage.getMessage();
          break;
        default:
          bo = new bo(ao1, ad());
          dh = new dh(ad(), bo, ao1);
          dh.a(a3.a);
          cp = dh.a();
          cz = new cz(ad());
          cp = cz.a(cp, bo);
          arrayOfByte1 = null;
          arrayOfByte1 = dh.a(cp);
          ao.d(bo.t());
          ao2 = ao1.f(arrayOfByte1);
          brokerMessage = new BrokerMessage(ao2.d());
          arrayOfByte = brokerMessage.getMessage();
          break;
      } 
    } catch (XMLException xMLException) {
      ao ao = null;
      ao = ao.a(xMLException.getErrorClass(), xMLException.getErrorCode(), xMLException.getErrorText(), i1);
      brokerMessage = new BrokerMessage(ao.d());
      arrayOfByte = brokerMessage.getMessage();
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M3, 5, 29, 53); 
    return arrayOfByte;
  }
  
  protected void g() {}
  
  protected void b(BrokerMessage paramBrokerMessage) throws BrokerException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M3, 5, 29, 54); 
    int i1 = 1110;
    ao ao1 = null;
    ao ao2 = null;
    BrokerMessage brokerMessage = null;
    dh dh = null;
    cp cp = null;
    try {
      byte[] arrayOfByte;
      cz cz;
      try {
        ao1 = new ao(paramBrokerMessage.getMessage());
      } catch (Exception exception) {
        throw new XMLException(87, "Cannot create RPC Message.");
      } 
      i1 = ao1.e();
      int i2 = ao1.v();
      switch (i2) {
        case 5:
          bo = new bo(ao1, ad());
          dh = new dh(ad(), bo, ao1);
          dh.a(a3.a);
          cp = dh.a();
          cz = new cz(ad());
          cp = cz.a(cp, bo);
          if (bo.q()) {
            String str = bo.f();
            bo.a(2000, 86, str);
            throw new XMLException(86, str);
          } 
          arrayOfByte = null;
          arrayOfByte = dh.a(cp);
          ao.d(bo.t());
          ao2 = ao1.f(arrayOfByte);
          brokerMessage = new BrokerMessage(ao2.d());
          paramBrokerMessage.reply(brokerMessage);
          break;
        case 7:
          try {
            String str = ao.c(paramBrokerMessage.getMessage());
            ao2 = ao.b(2000);
            brokerMessage = new BrokerMessage(ao2.d());
            paramBrokerMessage.reply(brokerMessage);
          } catch (be bo) {
            throw new XMLException(87, "Cannot create RPC Message.");
          } 
          break;
        case 6:
          ao2 = ao1.m(c);
          brokerMessage = new BrokerMessage(ao2.d());
          paramBrokerMessage.reply(brokerMessage);
          break;
      } 
    } catch (XMLException xMLException) {
      ao ao = null;
      ao = ao.a(xMLException.getErrorClass(), xMLException.getErrorCode(), xMLException.getErrorText() + xMLException.a(), i1);
      brokerMessage = new BrokerMessage(ao.d());
      paramBrokerMessage.reply(brokerMessage);
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M3, 5, 29, 54); 
  }
  
  protected void a(Exception paramException, boolean paramBoolean) {}
  
  protected void a(Properties paramProperties) { paramProperties.put("entirex.server.name", (new EntireXVersion("Java XML RPC Server")).getVersionString()); }
  
  public String[][] getServerEnhancedInfo() {
    String[][] arrayOfString = super.getServerEnhancedInfo();
    arrayOfString[0][1] = "EntireX XML RPC Server";
    arrayOfString[1][1] = EntireXVersion.getVersion();
    return arrayOfString;
  }
  
  public String[] getTableNames() { return new String[] { "Loaded XMMs and XMLAdapters" }; }
  
  public String[][] getTable(int paramInt) {
    null = null;
    switch (paramInt) {
      case 0:
        return af();
    } 
    return new String[0][0];
  }
  
  private String[][] af() {
    byte b1 = 0;
    cw cw = null;
    String[][] arrayOfString = null;
    String str = null;
    ArrayList arrayList1 = ar.r();
    ArrayList arrayList2 = ar.s();
    int i1 = arrayList1.size();
    int i2 = arrayList2.size();
    arrayOfString = new String[1 + i1 + i2][2];
    arrayOfString[0][0] = "XMM/XMLAdapter";
    arrayOfString[0][1] = "Target Service";
    for (b1 = 0; b1 < i1; b1++) {
      str = (String)arrayList1.get(b1);
      cw = d.o(str);
      arrayOfString[1 + b1][0] = str;
      arrayOfString[1 + b1][1] = cw.b();
    } 
    i1++;
    for (b1 = 0; b1 < i2; b1++) {
      str = (String)arrayList2.get(b1);
      cw = d.o(str);
      arrayOfString[i1][0] = str;
      arrayOfString[i1][1] = cw.b();
    } 
    return arrayOfString;
  }
  
  public void registerJavaCallback(CallbackInterface paramCallbackInterface) { ar.a(paramCallbackInterface); }
  
  public void start(String[] paramArrayOfString) {
    if (XMLRPCService.a)
      Trace.checkpoint(Trace.M1, 5, 29, 92); 
    a(new cx(d));
    startXMLRPCServer(paramArrayOfString);
  }
  
  public static void main(String[] paramArrayOfString) {
    XMLRPCServer xMLRPCServer = new XMLRPCServer();
    xMLRPCServer.a(new cx(d));
    xMLRPCServer.startXMLRPCServer(paramArrayOfString);
  }
  
  static  {
    d.a("entirex.sdk.xml.runtime.throwJavaException", "no");
    d.a("entirex.sdk.xml.runtime.useCharacterReference", "no");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\XMLRPCServer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */