package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.base.a5;
import com.softwareag.entirex.trace.Trace;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.Vector;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

abstract class db extends c8 {
  private static boolean a = false;
  
  protected StringBuffer b = null;
  
  protected c0 c = null;
  
  protected String d = "1.0";
  
  protected String e = null;
  
  protected String f = null;
  
  protected String g = null;
  
  protected String h = null;
  
  protected String i = null;
  
  protected db() {}
  
  protected db(c0 paramc0) { this.c = paramc0; }
  
  protected void a(c0 paramc0) { this.c = paramc0; }
  
  public void a(Document paramDocument) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 33, 93); 
    Element element = paramDocument.getDocumentElement();
    if (element != null) {
      ep ep = new ep(this.f, this.g);
      ep.a(element);
      a(element, 0, false);
    } else {
      throw new XMLException(87, "DOM without root element");
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 33, 93); 
  }
  
  private void b() {
    Trace.enterMethod(Trace.M3, 5, 27, 47);
    this.b = new StringBuffer();
    this.b.append("<?xml version=\"1.0\" encoding=\"");
    this.b.append(this.e);
    this.b.append("\" ?> ");
    super.b.d();
    b(this.c.c());
    Trace.checkpoint(Trace.CP2, 5, 27, 47, "XML-OutString: ", this.b.toString());
    Trace.leaveMethod(Trace.M3, 5, 27, 47);
  }
  
  private void b(c3 paramc3) {
    byte b1 = 0;
    XMLTypeElement xMLTypeElement = paramc3.d();
    String str = xMLTypeElement.getQName();
    bg.a(paramc3);
    this.b.append("<");
    this.b.append(str);
    c4 c4 = paramc3.k();
    if (c4 != null) {
      int m = c4.a();
      for (b1 = 0; b1 < m; b1++) {
        dd dd = c4.a(b1);
        this.b.append(" ");
        this.b.append(dd.a().h());
        this.b.append("=\"");
        String str1 = dd.b();
        if (dd.a().c().equals(a3.aa)) {
          int n = str1.indexOf("[V");
          if (n >= 0)
            dd.a(str1.substring(0, n) + "[]"); 
        } 
        this.b.append(bg.a(dd));
        this.b.append("\"");
      } 
    } 
    super.b.a(xMLTypeElement.getNamespaceContainer());
    Vector vector = super.b.a();
    int j = vector.size();
    for (b1 = 0; b1 < j; b1++) {
      aw aw = (aw)vector.get(b1);
      this.b.append(" xmlns");
      if (!aw.a().equals("")) {
        this.b.append(":");
        this.b.append(aw.a());
      } 
      this.b.append("=\"");
      this.b.append(aw.b());
      this.b.append("\"");
    } 
    super.b.e();
    int k = paramc3.g();
    if (paramc3.c().equals("") && k == 0) {
      this.b.append("/>");
    } else {
      this.b.append(">");
      this.b.append(bg.a(paramc3));
      if (k > 0) {
        au au = (au)super.b.clone();
        for (b1 = 0; b1 < k; b1++) {
          b((c3)paramc3.a(b1));
          super.b = (au)au.clone();
        } 
      } 
      this.b.append("</");
      this.b.append(str);
      this.b.append(">");
    } 
  }
  
  public void a(OutputStream paramOutputStream) {
    super.e = paramOutputStream;
    this.e = this.c.o();
    super.c = a5.a(this.e);
    if (super.c == null)
      super.c = this.e; 
    this.c.a().f(this.e);
    try {
      super.b.d();
      if (XMLRPCService.a) {
        b();
        super.b.d();
      } 
      paramOutputStream.write(("<?xml version=\"" + this.d + "\" encoding=\"").getBytes(super.c));
      paramOutputStream.write(this.e.getBytes(super.c));
      paramOutputStream.write("\" ?> ".getBytes(super.c));
      a();
      d(this.c.c());
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      new XMLException(80, unsupportedEncodingException.toString());
    } catch (IOException iOException) {
      new XMLException(80, iOException.toString());
    } finally {
      super.e = null;
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 32, 104); 
  }
  
  protected void a(Writer paramWriter) {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 32, 104); 
    super.f = paramWriter;
    this.e = this.c.o();
    this.c.a().f(this.e);
    try {
      super.b.d();
      if (XMLRPCService.a) {
        b();
        super.b.d();
      } 
      paramWriter.write("<?xml version=\"" + this.d + "\" encoding=\"");
      paramWriter.write(this.e);
      paramWriter.write("\" ?> ");
      a();
      c(this.c.c());
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      new XMLException(80, unsupportedEncodingException.toString());
    } catch (IOException iOException) {
      new XMLException(80, iOException.toString());
    } finally {
      super.f = null;
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 32, 104); 
  }
  
  private void c(c3 paramc3) {
    if (!paramc3.b()) {
      XMLTypeElement xMLTypeElement = paramc3.d();
      String str = null;
      byte b1 = 0;
      str = xMLTypeElement.getQName();
      super.f.write("<");
      super.f.write(str);
      c4 c4 = paramc3.k();
      if (c4 != null) {
        int m = c4.a();
        for (b1 = 0; b1 < m; b1++) {
          dd dd = c4.a(b1);
          super.f.write(" ");
          super.f.write(dd.a().h());
          super.f.write("=\"");
          if (dd.a().c().equals(a3.aa)) {
            String str1 = dd.b();
            int n = str1.indexOf("[V");
            if (n >= 0)
              dd.a(str1.substring(0, n) + "[]"); 
          } 
          super.f.write(bg.a(dd));
          super.f.write("\"");
        } 
      } 
      au au = paramc3.d().getNamespaceContainer();
      super.b.a(au);
      Vector vector1 = super.b.a();
      int j = vector1.size();
      for (b1 = 0; b1 < j; b1++) {
        aw aw = (aw)vector1.get(b1);
        super.f.write(" xmlns");
        if (!aw.a().equals("")) {
          super.f.write(":");
          super.f.write(aw.a());
        } 
        super.f.write("=\"");
        super.f.write(aw.b());
        super.f.write("\"");
      } 
      super.b.e();
      Vector vector2 = paramc3.h();
      int k = vector2.size();
      if (paramc3.c().equals("") && k == 0) {
        super.f.write("/>");
      } else {
        super.f.write(">");
        a(paramc3);
        super.f.write(bg.a(paramc3));
        if (k > 0) {
          au au1 = (au)super.b.clone();
          for (b1 = 0; b1 < k; b1++) {
            c((c3)vector2.get(b1));
            super.b = (au)au1.clone();
          } 
        } 
        super.f.write("</");
        super.f.write(str);
        super.f.write(">");
      } 
    } 
  }
  
  private void d(c3 paramc3) {
    if (!paramc3.b()) {
      XMLTypeElement xMLTypeElement = paramc3.d();
      byte b1 = 0;
      String str = xMLTypeElement.getQName();
      super.e.write("<".getBytes(this.e));
      super.e.write(str.getBytes(this.e));
      c4 c4 = paramc3.k();
      if (c4 != null) {
        int m = c4.a();
        for (b1 = 0; b1 < m; b1++) {
          dd dd = c4.a(b1);
          super.e.write(" ".getBytes(this.e));
          super.e.write(dd.a().h().getBytes(this.e));
          super.e.write("=\"".getBytes(this.e));
          if (dd.a().c().equals(a3.aa)) {
            String str1 = dd.b();
            int n = str1.indexOf("[V");
            if (n >= 0)
              dd.a(str1.substring(0, n) + "[]"); 
          } 
          super.e.write(bg.a(dd, super.d, super.c).getBytes(this.e));
          super.e.write("\"".getBytes(this.e));
        } 
      } 
      au au = paramc3.d().getNamespaceContainer();
      super.b.a(au);
      Vector vector = super.b.a();
      int j = vector.size();
      for (b1 = 0; b1 < j; b1++) {
        aw aw = (aw)vector.get(b1);
        super.e.write(" xmlns".getBytes(this.e));
        if (!aw.a().equals("")) {
          super.e.write(":".getBytes(this.e));
          super.e.write(aw.a().getBytes(this.e));
        } 
        super.e.write("=\"".getBytes(this.e));
        super.e.write(aw.b().getBytes(this.e));
        super.e.write("\"".getBytes(this.e));
      } 
      super.b.e();
      int k = paramc3.g();
      if (paramc3.c().equals("") && k == 0) {
        super.e.write("/>".getBytes(this.e));
      } else {
        super.e.write(">".getBytes(this.e));
        a(paramc3);
        super.e.write(bg.a(paramc3, super.d, super.c).getBytes(this.e));
        if (k > 0) {
          au au1 = (au)super.b.clone();
          for (b1 = 0; b1 < k; b1++) {
            d((c3)paramc3.a(b1));
            super.b = (au)au1.clone();
          } 
        } 
        super.e.write("</".getBytes(this.e));
        super.e.write(str.getBytes(this.e));
        super.e.write(">".getBytes(this.e));
      } 
    } 
  }
  
  protected abstract void a();
  
  public int a(Element paramElement, int paramInt, boolean paramBoolean) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M3, 5, 27, 103); 
    boolean bool = false;
    int j = this.c.a(paramElement, paramInt, paramBoolean);
    if (j == 0) {
      Attr attr = paramElement.getAttributeNodeNS(this.h, this.i);
      if (attr != null)
        j = this.c.a(paramElement, ++paramInt, true); 
      if (j == 0) {
        String str1 = paramElement.getLocalName();
        String str2 = paramElement.getNamespaceURI();
        if (str1.startsWith("ArrayOf")) {
          j = this.c.a(paramElement, ++paramInt, true);
        } else if (str1.equals("Array") && str2.equals(a3.z)) {
          j = this.c.a(paramElement, ++paramInt, true);
        } 
      } 
    } 
    if (j > 0) {
      boolean bool1 = (j == 2);
      byte b1 = -1;
      for (Node node = paramElement.getFirstChild(); node != null; node = node.getNextSibling()) {
        if (node.getNodeType() == 1) {
          int k = a((Element)node, b1, bool1);
          if (k > 0) {
            if (k == 2)
              b1++; 
            this.c.k();
          } 
        } 
      } 
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M3, 5, 27, 103); 
    return j;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\db.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */