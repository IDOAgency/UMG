package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.Dump;
import com.softwareag.entirex.aci.be;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class XMLException extends Exception {
  public static final int XMLRUNTIME_CLASS = 2000;
  
  private int a = 0;
  
  private int b = 2000;
  
  private String c = null;
  
  private String d = null;
  
  private String e = null;
  
  private String f = null;
  
  private Exception g = null;
  
  private static ResourceBundle h = null;
  
  protected static final int i = 1;
  
  protected static final int j = 2;
  
  protected static final int k = 3;
  
  protected static final int l = 4;
  
  protected static final int m = 5;
  
  protected static final int n = 6;
  
  protected static final int o = 7;
  
  protected static final int p = 8;
  
  protected static final int q = 9;
  
  protected static final int r = 21;
  
  protected static final int s = 22;
  
  protected static final int t = 23;
  
  protected static final int u = 24;
  
  protected static final int v = 25;
  
  protected static final int w = 26;
  
  protected static final int x = 27;
  
  protected static final int y = 28;
  
  protected static final int z = 29;
  
  protected static final int aa = 30;
  
  protected static final int ab = 31;
  
  protected static final int ac = 40;
  
  protected static final int ad = 41;
  
  protected static final int ae = 42;
  
  protected static final int af = 43;
  
  protected static final int ag = 44;
  
  protected static final int ah = 45;
  
  protected static final int ai = 46;
  
  protected static final int aj = 47;
  
  protected static final int ak = 48;
  
  protected static final int al = 49;
  
  protected static final int am = 50;
  
  protected static final int an = 51;
  
  protected static final int ao = 52;
  
  protected static final int ap = 53;
  
  protected static final int aq = 54;
  
  protected static final int ar = 55;
  
  protected static final int as = 56;
  
  protected static final int at = 57;
  
  protected static final int au = 58;
  
  protected static final int av = 59;
  
  protected static final int aw = 60;
  
  protected static final int ax = 61;
  
  protected static final int ay = 62;
  
  protected static final int az = 64;
  
  protected static final int a0 = 70;
  
  protected static final int a1 = 72;
  
  protected static final int a2 = 73;
  
  protected static final int a3 = 74;
  
  protected static final int a4 = 75;
  
  protected static final int a5 = 76;
  
  protected static final int a6 = 77;
  
  protected static final int a7 = 78;
  
  protected static final int a8 = 79;
  
  protected static final int a9 = 80;
  
  protected static final int ba = 81;
  
  protected static final int bb = 82;
  
  protected static final int bc = 84;
  
  protected static final int bd = 85;
  
  protected static final int be = 86;
  
  protected static final int bf = 87;
  
  protected static final int bg = 88;
  
  protected static final int bh = 89;
  
  protected XMLException(String paramString) { super(paramString); }
  
  protected XMLException(Exception paramException) {
    if (paramException instanceof java.io.IOException) {
      this.a = 4;
      this.b = 2000;
      this.c = paramException.toString();
    } else if (paramException instanceof BrokerException) {
      this.a = ((BrokerException)paramException).getErrorCode();
      this.b = ((BrokerException)paramException).getErrorClass();
      this.c = ((BrokerException)paramException).toString();
    } else if (paramException instanceof be) {
      this.d = ((be)paramException).l();
      this.e = ((be)paramException).k();
      this.c = ((be)paramException).toString();
    } 
    this.f = null;
    this.g = paramException;
  }
  
  protected XMLException(int paramInt) { this(paramInt, null); }
  
  protected XMLException(int paramInt, String paramString) {
    this.b = 2000;
    this.a = paramInt;
    b();
    this.f = paramString;
  }
  
  private void b() {
    if (h == null)
      e(); 
    if (h != null)
      this.c = h.getString(c()); 
  }
  
  public String getErrorText() { return (this.c == null) ? "" : this.c; }
  
  public int getErrorCode() { return this.a; }
  
  public int getErrorNumber() { return this.a; }
  
  private String c() {
    for (String str = "" + this.a; str.length() < 4; str = "0" + str);
    return str;
  }
  
  public int getErrorClass() { return this.b; }
  
  private String d() {
    for (String str = "" + this.b; str.length() < 4; str = "0" + str);
    return str;
  }
  
  public String getMessage() { return toString(); }
  
  public Exception getException() { return this.g; }
  
  public String toString() {
    String str = null;
    if (h == null)
      e(); 
    if (h != null) {
      str = h.getString("0000") + " ";
    } else {
      Dump.log("XMLException: Loading error messages failed.");
    } 
    if (str == null)
      str = ""; 
    if (this.b == 2000) {
      str = str + d() + " " + c() + " " + this.c;
    } else {
      str = this.c;
    } 
    if (this.f != null)
      str = str + " " + this.f; 
    return str;
  }
  
  protected String a() {
    String str = "";
    if (this.f != null)
      str = "(" + this.f + ")"; 
    return str;
  }
  
  private static void e() {
    if (h == null)
      try {
        h = ResourceBundle.getBundle("com.softwareag.entirex.xml.rt.XMLWrapperErrors");
      } catch (MissingResourceException missingResourceException) {} 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\XMLException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */