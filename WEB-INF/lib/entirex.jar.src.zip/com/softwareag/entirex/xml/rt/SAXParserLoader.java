package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

public class SAXParserLoader {
  private static SAXParserFactory a = null;
  
  private static boolean b = false;
  
  private static boolean c = false;
  
  private static boolean d = true;
  
  private static boolean e = true;
  
  private static boolean f = true;
  
  private static boolean g = true;
  
  private static final String h = "javax.xml.parsers.SAXParserFactory";
  
  private static final String i = "javax.xml.parsers.SAXParser";
  
  public static SAXParser getSAXParser() throws XMLException {
    SAXParser sAXParser = null;
    if (a == null)
      try {
        a = SAXParserFactory.newInstance();
      } catch (FactoryConfigurationError factoryConfigurationError) {
        if (XMLRPCService.a) {
          a();
          Trace.checkpoint(Trace.CP1, 5, 45, 111, factoryConfigurationError.toString());
        } 
        throw new XMLException(62, factoryConfigurationError.toString());
      }  
    try {
      sAXParser = a.newSAXParser();
    } catch (ParserConfigurationException parserConfigurationException) {
      if (XMLRPCService.a) {
        a();
        Trace.checkpoint(Trace.CP1, 5, 45, 111, parserConfigurationException.toString());
      } 
      throw new XMLException(21, parserConfigurationException.toString());
    } catch (SAXException sAXException) {
      if (XMLRPCService.a) {
        a();
        Trace.checkpoint(Trace.CP1, 5, 45, 111, sAXException.toString());
      } 
      throw new XMLException(21, sAXException.toString());
    } 
    a(sAXParser, "http://xml.org/sax/features/validation", b);
    a(sAXParser, "http://xml.org/sax/features/namespaces", d);
    a(sAXParser, "http://xml.org/sax/features/namespace-prefixes", e);
    a(sAXParser, "http://apache.org/xml/features/validation/dynamic", c);
    a(sAXParser, "http://apache.org/xml/features/validation/schema", f);
    a(sAXParser, "http://apache.org/xml/features/allow-java-encodings", g);
    return sAXParser;
  }
  
  private static void a(SAXParser paramSAXParser, String paramString, boolean paramBoolean) {
    try {
      paramSAXParser.getXMLReader().setFeature(paramString, paramBoolean);
    } catch (SAXNotRecognizedException sAXNotRecognizedException) {
      Trace.checkpoint(Trace.CP1, 5, 45, 111, "SetFeature failed (SAXNotRecognizedException: " + sAXNotRecognizedException.toString() + "):" + paramString, paramBoolean);
    } catch (SAXNotSupportedException sAXNotSupportedException) {
      Trace.checkpoint(Trace.CP1, 5, 45, 111, "SetFeature failed (SAXNotSupportedException: " + sAXNotSupportedException.toString() + "):" + paramString, paramBoolean);
    } catch (SAXException sAXException) {
      Trace.checkpoint(Trace.CP1, 5, 45, 111, "SetFeature failed (SAXException: " + sAXException.toString() + "):" + paramString, paramBoolean);
    } 
  }
  
  private static void a() {
    Trace.checkpoint(Trace.CP1, 5, 45, 111, "javax.xml.parsers.SAXParserFactory", System.getProperty("javax.xml.parsers.SAXParserFactory"));
    Trace.checkpoint(Trace.CP1, 5, 45, 111, "javax.xml.parsers.SAXParser", System.getProperty("javax.xml.parsers.SAXParser"));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\SAXParserLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */