package com.softwareag.entirex.xml.rt;

import java.math.BigDecimal;

public class RPCTypeNumber extends RPCTypeScalar {
  public static final char TYPE_N = 'N';
  
  public static final char TYPE_P = 'P';
  
  char a;
  
  boolean b = false;
  
  int c;
  
  int d;
  
  public int getDigitsBeforeDecimalPoint() { return this.c; }
  
  public int getDigitsAfterDecimalPoint() { return this.d; }
  
  public RPCTypeNumber(char paramChar, int paramInt1, int paramInt2) { this(6, 3, paramChar, paramInt1, paramInt2); }
  
  public RPCTypeNumber(String paramString, char paramChar, int paramInt1, int paramInt2) { this(paramString, 6, 3, paramChar, paramInt1, paramInt2); }
  
  public RPCTypeNumber(String paramString, char paramChar, int paramInt1, int paramInt2, int paramInt3) { this(paramString, 6, paramInt3, paramChar, paramInt1, paramInt2); }
  
  public RPCTypeNumber(char paramChar, int paramInt1, int paramInt2, int paramInt3) { this(6, paramInt3, paramChar, paramInt1, paramInt2); }
  
  public RPCTypeNumber(String paramString, int paramInt1, int paramInt2, char paramChar, int paramInt3, int paramInt4) {
    super(paramString, paramInt1, paramInt2);
    this.c = paramInt3;
    this.d = paramInt4;
    this.j = paramInt3 + paramInt4;
    this.a = paramChar;
  }
  
  public RPCTypeNumber(int paramInt1, int paramInt2, char paramChar, int paramInt3, int paramInt4) {
    super(paramInt1, paramInt2);
    this.c = paramInt3;
    this.d = paramInt4;
    this.j = paramInt3 + paramInt4;
    this.a = paramChar;
  }
  
  public String toString() { return "RPCTypeNumber: " + getName() + ", pre: " + this.c + ", post:" + this.d + ", size: " + this.j + ", direction:" + this.i + ", defaultValue:" + super.a; }
  
  public final BigDecimal fromString(String paramString) {
    BigDecimal bigDecimal = null;
    try {
      bigDecimal = new BigDecimal(paramString);
    } catch (Exception exception) {
      if (super.a != null) {
        bigDecimal = new BigDecimal(super.a);
      } else {
        bigDecimal = new BigDecimal(0.0D);
      } 
    } 
    return bigDecimal;
  }
  
  public void setUnsigned(boolean paramBoolean) { this.b = paramBoolean; }
  
  public boolean getUnsigned() { return this.b; }
  
  public static final String toString(BigDecimal paramBigDecimal) {
    String str = "";
    if (paramBigDecimal != null)
      str = paramBigDecimal.toString(); 
    return str;
  }
  
  public cp createValueNode() { return new co(this, super.a); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\RPCTypeNumber.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */