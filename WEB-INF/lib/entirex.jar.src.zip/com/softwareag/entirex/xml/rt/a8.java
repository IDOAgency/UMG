package com.softwareag.entirex.xml.rt;

public class a8 {
  private av a = null;
  
  private int b = 0;
  
  private int c = 1;
  
  private String d = null;
  
  private String e = null;
  
  private String f = null;
  
  private int g = 0;
  
  private String h = null;
  
  private String i = null;
  
  private String j = null;
  
  private boolean k = false;
  
  public a8(String paramString1, String paramString2) { this(null, null, paramString1, paramString2, 1); }
  
  public a8(String paramString1, String paramString2, int paramInt) { this(null, null, paramString1, paramString2, paramInt); }
  
  public a8(String paramString1, String paramString2, String paramString3, String paramString4) { this(paramString1, paramString2, paramString3, paramString4, 1); }
  
  public a8(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt) {
    this.a = new av(paramString2, paramString1, paramString3);
    this.c = paramInt;
    this.e = paramString4;
  }
  
  public dd a() { return new dd(this); }
  
  public dd a(String paramString) { return new dd(this, paramString); }
  
  public String b() { return (this.e == null) ? "" : this.e; }
  
  public String c() { return av.a(this.a.e(), this.a.a()); }
  
  public String d() { return this.a.a(); }
  
  public String e() { return this.h; }
  
  public int f() { return this.c; }
  
  public void a(int paramInt) { this.c = paramInt; }
  
  public String g() { return this.a.d(); }
  
  public String h() { return this.a.b(); }
  
  public String i() { return this.a.e(); }
  
  public String j() {
    String str = this.i;
    if (str == null)
      str = ""; 
    if (str.equals(""))
      str = b(); 
    return str;
  }
  
  public boolean k() { return (this.c == 0); }
  
  public void b(String paramString) {
    if (paramString != null) {
      this.i = paramString.trim();
    } else {
      this.i = "";
    } 
  }
  
  public void c(String paramString) { this.d = paramString; }
  
  public String l() { return this.d; }
  
  protected String m() { return this.f; }
  
  protected int n() { return this.g; }
  
  protected int o() { return this.b; }
  
  protected String p() { return this.j; }
  
  protected void d(String paramString) { this.j = paramString; }
  
  protected void e(String paramString) { this.f = paramString; }
  
  protected void f(String paramString) { this.g = a3.a(paramString); }
  
  public void g(String paramString) { this.h = a3.a(paramString, this.g, this.f); }
  
  protected void b(int paramInt) { this.b = paramInt; }
  
  public Object clone() {
    a8 a81 = new a8(g(), i(), d(), b(), f());
    a81.c(l());
    a81.i = this.i;
    a81.f = this.f;
    a81.g = this.g;
    a81.j = this.j;
    a81.h = this.h;
    a81.b = this.b;
    return a81;
  }
  
  protected boolean q() { return this.k; }
  
  protected void a(boolean paramBoolean) { this.k = paramBoolean; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\a8.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */