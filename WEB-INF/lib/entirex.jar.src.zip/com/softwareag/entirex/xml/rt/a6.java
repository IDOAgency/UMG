package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.base.EntireXClassLoader;
import com.softwareag.entirex.trace.Trace;
import java.io.File;
import javax.servlet.ServletContext;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class a6 extends DefaultHandler {
  private static final String a = "http://namespaces.softwareag.com/entirex/xml/rt";
  
  private static final String b = av.a("http://namespaces.softwareag.com/entirex/xml/rt", "EntireXXMLInit");
  
  private static final String c = av.a("http://namespaces.softwareag.com/entirex/xml/rt", "adapters");
  
  private static final String d = av.a("http://namespaces.softwareag.com/entirex/xml/rt", "exx-xml-adapter");
  
  private static final String e = av.a("http://namespaces.softwareag.com/entirex/xml/rt", "xmms");
  
  private static final String f = av.a("http://namespaces.softwareag.com/entirex/xml/rt", "exx-xmm");
  
  private ar g = null;
  
  private StringBuffer h = new StringBuffer();
  
  private a7 i = null;
  
  private a7 j = null;
  
  private int k = 0;
  
  public a6(ar paramar) {
    if (XMLServlet.ap)
      Trace.checkpoint(Trace.CP4, 6, 30, 8, "XMLServlet.bTraceOn=" + XMLServlet.ap); 
    this.g = paramar;
    this.i = new a7("", "", "XMMFILE");
    this.j = this.i;
  }
  
  public void startDocument() {
    if (XMLServlet.ap)
      Trace.checkpoint(Trace.CP4, 6, 30, 43); 
  }
  
  public void startElement(String paramString1, String paramString2, String paramString3, Attributes paramAttributes) {
    if (XMLServlet.ap)
      Trace.enterMethod(Trace.M4, 6, 30, 44, "qName", paramString3); 
    try {
      a7 a71 = new a7(paramString1, paramString3, paramString2);
      if (paramAttributes != null) {
        String str1 = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        for (byte b1 = 0; b1 < paramAttributes.getLength(); b1++) {
          str1 = paramAttributes.getURI(b1);
          str4 = paramAttributes.getLocalName(b1);
          str3 = paramAttributes.getQName(b1);
          int m = paramAttributes.getQName(b1).indexOf(':');
          if (m >= 0) {
            str2 = paramAttributes.getQName(b1).substring(0, m);
          } else {
            str2 = "";
          } 
          a71.a(str2, str1, str4, str3, paramAttributes.getValue(b1));
        } 
      } 
      this.j.a(a71);
      this.j = a71;
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    if (XMLServlet.ap)
      Trace.leaveMethod(Trace.M4, 6, 30, 44); 
  }
  
  public void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2) throws SAXException {
    if (XMLServlet.ap)
      Trace.enterMethod(Trace.M4, 6, 30, 5); 
    this.h = new StringBuffer();
    this.h.append(paramArrayOfChar, paramInt1, paramInt2);
    String str = this.h.toString();
    if (str != null)
      str = str.trim(); 
    if (XMLServlet.ap && str != null && str.length() > 0)
      Trace.checkpoint(Trace.CP4, 6, 30, 5, "characters", str); 
    this.j.a(str);
    if (XMLServlet.ap)
      Trace.leaveMethod(Trace.M4, 6, 30, 5); 
  }
  
  public void endElement(String paramString1, String paramString2, String paramString3) throws SAXException { this.j = this.j.c(); }
  
  public void endDocument() {
    if (XMLServlet.ap)
      Trace.checkpoint(Trace.CP4, 6, 30, 10); 
  }
  
  private void a(ay paramay, XMMInfo paramXMMInfo) {
    if (paramay != null && paramXMMInfo != null) {
      String str = paramay.b();
      if (str == null)
        paramay.a(paramXMMInfo.getBrokerID()); 
      str = paramay.c();
      if (str == null)
        paramay.b(paramXMMInfo.getServerAddress()); 
      str = paramay.d();
      if (str == null)
        paramay.c(paramXMMInfo.getLogicalBrokerID()); 
      str = paramay.e();
      if (str == null)
        paramay.d(paramXMMInfo.getLogicalService()); 
      str = paramay.f();
      if (str == null)
        paramay.e(paramXMMInfo.getLogicalSetName()); 
    } 
  }
  
  private void a(ay paramay, XMLAdapterInfo paramXMLAdapterInfo) {
    if (paramay != null && paramXMLAdapterInfo != null) {
      String str = paramay.b();
      if (str == null)
        paramay.a(paramXMLAdapterInfo.getBrokerID()); 
      str = paramay.c();
      if (str == null)
        paramay.b(paramXMLAdapterInfo.getServerAddress()); 
      str = paramay.m();
      if (str == null)
        paramay.l("" + paramXMLAdapterInfo.getCompression()); 
    } 
  }
  
  private void a(ay paramay, a7 parama7) {
    if (paramay != null && parama7 != null) {
      String str = parama7.d("exx-brokerID");
      if (str != null)
        paramay.a(str); 
      str = parama7.d("exx-service");
      if (str != null)
        paramay.b(str); 
      str = parama7.d("exx-logical-brokerID");
      if (str != null)
        paramay.c(str); 
      str = parama7.d("exx-logical-service");
      if (str != null)
        paramay.d(str); 
      str = parama7.d("exx-logicalsetname");
      if (str != null)
        paramay.e(str); 
      str = parama7.d("exx-userID");
      if (str != null)
        paramay.f(str); 
      str = parama7.d("exx-rpc-userID");
      if (str != null)
        paramay.g(str); 
      str = parama7.d("exx-use-security");
      if (str != null)
        paramay.h(str); 
      str = parama7.d("exx-encryption-level");
      if (str != null)
        paramay.i(str); 
      str = parama7.d("exx-natural-security");
      if (str != null)
        paramay.j(str); 
      str = parama7.d("exx-natural-library");
      if (str != null)
        paramay.k(str); 
      str = parama7.d("exx-use-codepage");
      if (str != null)
        paramay.o(str); 
      str = parama7.d("exx-compression");
      if (str != null)
        paramay.l(str); 
      str = parama7.d("exx-compresslevel");
      if (str != null)
        paramay.m(str); 
    } 
  }
  
  public void a(String paramString, ServletContext paramServletContext) {
    byte b1 = 0;
    if (XMLServlet.ap)
      Trace.enterMethod(Trace.M4, 6, 30, 36); 
    this.j = this.i;
    this.j = this.j.c(b);
    if (this.j != null) {
      int m = this.j.b();
      for (byte b2 = 0; b2 < m; b2++) {
        a7 a71 = this.j.a(b2);
        ay ay = new ay();
        a(ay, a71);
        if (b2 == 0)
          this.g.a(ay); 
        String str = "";
        if (a71.d().equals(e)) {
          str = f;
        } else if (a71.d().equals(c)) {
          str = d;
        } 
        int n = a71.b(str);
        for (byte b3 = 0; b3 < n; b3++) {
          a7 a72 = a71.a(str, b3);
          if (a72 != null) {
            ay ay1 = new ay(ay);
            String str1 = a72.a();
            if (XMLServlet.ap)
              Trace.checkpoint(Trace.CP4, 6, 30, 36, str, str1); 
            a(ay1, a72);
            if (a72.d().equals(f)) {
              a9 a9 = new a9(str1, paramString, paramServletContext);
              if (XMLServlet.ap)
                Trace.checkpoint(Trace.CP4, 6, 30, 36, "overwrite"); 
              a(ay1, a9);
            } else if (a72.d().equals(d)) {
              try {
                Object object = null;
                if (str1.toLowerCase().endsWith(".class") || str1.indexOf("/") != -1 || str1.indexOf(File.separator) != -1) {
                  EntireXClassLoader entireXClassLoader = new EntireXClassLoader(str1);
                  object = entireXClassLoader.getObject(null, null);
                } else {
                  Class clazz = Class.forName(str1);
                  object = clazz.newInstance();
                } 
                if (object != null && object instanceof XMLAdapter) {
                  XMLAdapterInfo xMLAdapterInfo = ((XMLAdapter)object).getAdapterInfo();
                  if (XMLServlet.ap)
                    Trace.checkpoint(Trace.CP4, 6, 30, 36, "overwrite"); 
                  a(ay1, xMLAdapterInfo);
                } 
              } catch (Exception exception) {
                if (XMLServlet.ap)
                  Trace.checkpoint(Trace.CP4, 6, 30, 36, "Problems while getting Xml adapter information: " + exception); 
              } 
            } 
            if (a71.d().equals(c)) {
              this.g.a(str1, ay1);
              this.g.j(str1);
              b1++;
            } else if (a71.d().equals(e)) {
              this.g.a(str1, ay1);
              this;
              ar.h(str1);
              b1++;
            } 
          } 
        } 
      } 
      if (b1 == 0 && XMLServlet.ap)
        Trace.checkpoint(Trace.CP4, 6, 30, 36, "Cannot find any adapter or xmm definition."); 
    } else if (XMLServlet.ap) {
      Trace.checkpoint(Trace.CP4, 6, 30, 36, "Cannot read xml-init-file.");
    } 
    if (XMLServlet.ap)
      Trace.leaveMethod(Trace.M4, 6, 30, 36, "number of entries", b1); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\a6.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */