package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.ao;
import com.softwareag.entirex.trace.Trace;
import java.math.BigDecimal;
import java.util.Vector;

public class dp extends dk {
  private static final int a = 2000;
  
  private int b = 0;
  
  public dp(ar paramar, bo parambo) {
    super(paramar, parambo);
    b(2000);
    RPCType rPCType = super.a.g();
    rPCType = (RPCType)rPCType.getChild(super.b.y());
    rPCType = (RPCType)rPCType.getChild(super.b.d());
    this.c = ((RPCTypeProgram)rPCType).getFormatBuffer();
    this.e = ((RPCTypeProgram)rPCType).c();
    if (this.e == 0) {
      this.e = ((RPCTypeProgram)rPCType).getOutLength() + ((RPCTypeProgram)rPCType).getInOutLength();
      this.e += this.c.length;
      this.e += 592;
    } 
    this.d = ((RPCTypeProgram)rPCType).getParameterCount();
  }
  
  protected void a(int paramInt) {
    if (this.e < paramInt) {
      RPCType rPCType = super.a.g();
      rPCType = (RPCType)rPCType.getChild(super.b.y());
      rPCType = (RPCType)rPCType.getChild(super.b.d());
      this.e = paramInt;
      ((RPCTypeProgram)rPCType).a(paramInt);
    } 
  }
  
  public dp(ar paramar, bo parambo, ao paramao) {
    super(paramar, parambo, paramao);
    b(2000);
  }
  
  public void a(RPCType paramRPCType, cp paramcp) throws XMLException {
    if (this.c == a3.a) {
      super.b = 2;
    } else {
      super.b = 1;
    } 
    a(paramRPCType, paramcp, false);
  }
  
  public void a(RPCType paramRPCType, cp paramcp, boolean paramBoolean) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 42, 101); 
    RPCType rPCType = null;
    cp cp1 = paramcp;
    int i = 0;
    byte b1 = 0;
    boolean bool = false;
    i = paramRPCType.getChildCount();
    for (b1 = 0; b1 < i; b1++) {
      rPCType = (RPCType)paramRPCType.getChild(b1);
      if (rPCType.getDirection() != super.b) {
        int j = rPCType.getRpcTypeId();
        cp cp2 = null;
        try {
          byte b2;
          int k;
          switch (j) {
            case 1:
              paramBoolean = false;
              cp2 = ((RPCTypeBinary)rPCType).createValueNode();
              if (rPCType.isVariableSized()) {
                cp2.a(RPCTypeBinary.toString(this.f.getDataBV()));
                break;
              } 
              cp2.a(RPCTypeBinary.toString(this.f.getDataB(rPCType.getSize())));
              break;
            case 2:
              paramBoolean = false;
              cp2 = ((RPCTypeBoolean)rPCType).createValueNode();
              cp2.a(this.f.getDataL() ? a3.g : a3.h);
              break;
            case 3:
              paramBoolean = false;
              cp2 = ((RPCTypeDateTime)rPCType).createValueNode();
              cp2.a(this.f.getDataDString(8));
              break;
            case 4:
              paramBoolean = false;
              cp2 = ((RPCTypeFloat)rPCType).createValueNode();
              if (rPCType.getSize() == 4) {
                cp2.a(this.f.getDataF4String());
                break;
              } 
              cp2.a(this.f.getDataF8String());
              break;
            case 5:
              paramBoolean = false;
              cp2 = ((RPCTypeInt)rPCType).createValueNode();
              switch (rPCType.getSize()) {
                case 1:
                  cp2.a(this.f.getDataI1String());
                  break;
                case 2:
                  cp2.a(this.f.getDataI2String());
                  break;
                case 4:
                  cp2.a(this.f.getDataI4String());
                  break;
              } 
              throw new XMLException(84);
            case 6:
              paramBoolean = false;
              cp2 = ((RPCTypeNumber)rPCType).createValueNode();
              cp2.a(this.f.getDataNString(((RPCTypeNumber)rPCType).getDigitsBeforeDecimalPoint(), ((RPCTypeNumber)rPCType).getDigitsAfterDecimalPoint()));
              break;
            case 7:
              paramBoolean = false;
              cp2 = ((RPCTypeString)rPCType).createValueNode();
              if (rPCType.isVariableSized()) {
                cp2.a(this.f.getDataAV());
                break;
              } 
              if (((RPCTypeString)rPCType).a()) {
                cp2.a(this.f.getDataA(rPCType.getSize()).trim());
                break;
              } 
              cp2.a(this.f.getDataA(rPCType.getSize()));
              break;
            case 8:
              paramBoolean = false;
              cp2 = ((RPCTypeDateTime)rPCType).createValueNode();
              cp2.a(this.f.getDataDString(15));
              break;
            case 30:
              k = 0;
              if (paramBoolean == true || b(rPCType)) {
                paramBoolean = true;
                k = this.f.getArrayIndex();
                int m = rPCType.getSize();
                if (rPCType.isVariableSized()) {
                  if (m > 0 && k > m)
                    throw new XMLException(64); 
                } else if (k != m) {
                  throw new XMLException(64);
                } 
              } else {
                k = rPCType.getSize();
              } 
              cp1 = rPCType.createValueNode();
              paramcp.b(cp1);
              for (b2 = 0; b2 < k; b2++)
                a((RPCType)paramRPCType.getChild(b1), cp1, paramBoolean); 
              break;
            case 31:
              paramBoolean = false;
              cp2 = ((RPCTypeStructure)rPCType).createValueNode();
              paramcp.b(cp2);
              a(rPCType, cp2, paramBoolean);
              break;
            case 32:
              paramBoolean = false;
              cp2 = ((RPCTypeStructure)rPCType).createValueNode();
              paramcp.b(cp2);
              a(rPCType, cp2, paramBoolean);
              break;
          } 
        } catch (BrokerException brokerException) {
          throw new XMLException(brokerException);
        } 
        if (!rPCType.isContainer())
          paramcp.b(cp2); 
      } 
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 42, 101); 
  }
  
  public byte[] b(RPCType paramRPCType, cp paramcp) throws XMLException {
    if (this.c == a3.a) {
      super.b = 1;
    } else {
      super.b = 2;
    } 
    return b(paramRPCType, paramcp, false);
  }
  
  public byte[] b(RPCType paramRPCType, cp paramcp, boolean paramBoolean) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 42, 102); 
    RPCType rPCType = null;
    cp cp1 = null;
    int i = 0;
    byte b1 = 0;
    boolean bool = false;
    byte b2 = 0;
    i = paramRPCType.getChildCount();
    for (b1 = 0; b1 < i; b1++) {
      rPCType = (RPCType)paramRPCType.getChild(b1);
      if (rPCType.getDirection() != super.b) {
        int j = rPCType.getRpcTypeId();
        Vector vector = paramcp.e(rPCType.getName());
        int k = vector.size();
        for (b2 = 0; b2 < k; b2++) {
          cp1 = (cp)vector.get(b2);
          try {
            int m;
            String str3;
            String str2;
            String str1;
            switch (j) {
              case 1:
                paramBoolean = false;
                this.b = rPCType.getSize();
                if (rPCType.isVariableSized()) {
                  if (this.b == -1) {
                    this.f.addDataBV(RPCTypeBinary.fromString(cp1.b()));
                    break;
                  } 
                  this.f.addDataBV(RPCTypeBinary.fromString(cp1.b()), this.b);
                  break;
                } 
                this.f.addDataB(RPCTypeBinary.fromString(cp1.b()), this.b);
                break;
              case 2:
                str1 = cp1.b();
                if (str1 != null) {
                  this.f.addDataA(str1.equals(a3.h) ? " " : "X", 1);
                  break;
                } 
                this.f.addDataA(" ", 1);
                break;
              case 3:
                paramBoolean = false;
                str2 = cp1.b();
                if (str2 == null || str2.length() == 0)
                  str2 = a3.ah; 
                this.f.addDataD(str2, 8);
                break;
              case 4:
                paramBoolean = false;
                if (rPCType.getSize() == 4) {
                  this.f.addDataF(cp1.b(), 6);
                  break;
                } 
                this.f.addDataF(cp1.b(), 15);
                break;
              case 5:
                paramBoolean = false;
                switch (rPCType.getSize()) {
                  case 1:
                    this.f.addDataI(cp1.b(), 4);
                    break;
                  case 2:
                    this.f.addDataI(cp1.b(), 6);
                    break;
                  case 4:
                    this.f.addDataI(cp1.b(), 11);
                    break;
                } 
                throw new XMLException(84);
              case 6:
                paramBoolean = false;
                str3 = cp1.b();
                this.f.addDataN((str3 == null || str3.trim().equals("")) ? null : new BigDecimal(str3), ((RPCTypeNumber)rPCType).getDigitsBeforeDecimalPoint(), ((RPCTypeNumber)rPCType).getDigitsAfterDecimalPoint());
                break;
              case 7:
                this.b = rPCType.getSize();
                if (rPCType.isVariableSized()) {
                  if (this.b == -1) {
                    this.f.addDataAV(cp1.b());
                    break;
                  } 
                  this.f.addDataAV(cp1.b(), this.b);
                  break;
                } 
                this.f.addDataA(cp1.b(), this.b);
                break;
              case 8:
                paramBoolean = false;
                str3 = cp1.b();
                if (str3 == null || str3.length() == 0)
                  str3 = a3.ai; 
                this.f.addDataD(str3, 15);
                break;
              case 30:
                m = cp1.g();
                if (paramBoolean == true || b(rPCType)) {
                  paramBoolean = true;
                  this.f.addArrayIndex(m);
                } 
                b(rPCType, cp1, paramBoolean);
                break;
              case 31:
              case 32:
                paramBoolean = false;
                b(rPCType, cp1, paramBoolean);
                break;
              default:
                throw new XMLException(84);
            } 
          } catch (BrokerException brokerException) {
            throw new XMLException(brokerException);
          } 
        } 
      } 
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 42, 102); 
    return this.f.e();
  }
  
  private boolean b(RPCType paramRPCType) {
    boolean bool = false;
    while (!bool && paramRPCType.getRpcTypeId() == 30) {
      if (paramRPCType.isVariableSized())
        bool = true; 
      paramRPCType = (RPCType)paramRPCType.getChild(0);
    } 
    return bool;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\dp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */