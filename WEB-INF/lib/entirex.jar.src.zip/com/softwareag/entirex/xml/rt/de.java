package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;
import java.util.ArrayList;
import java.util.Vector;

public class de {
  private ar a = null;
  
  private bo b = new bo();
  
  private c3 c = null;
  
  private cp d = null;
  
  private c3 e = null;
  
  private ax f = null;
  
  public de(ar paramar, bo parambo) {
    this.a = paramar;
    this.b = parambo;
  }
  
  protected c3 a(cp paramcp) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 2, 95); 
    df df = new df();
    cp cp1 = null;
    ax ax1 = null;
    String str1 = this.b.y();
    String str2 = this.b.d();
    this.f = this.a.n();
    if (!this.b.m()) {
      this.c = new c3(this.a.i());
    } else {
      this.c = new c3(this.a.l());
      this.f = this.a.p();
      if (paramcp == null) {
        RPCTypeScalar rPCTypeScalar = new RPCTypeScalar("root", 0);
        RPCTypeLibrary rPCTypeLibrary = (RPCTypeLibrary)rPCTypeScalar.addChild(new RPCTypeLibrary(str1));
        RPCTypeProgram rPCTypeProgram = (RPCTypeProgram)rPCTypeLibrary.addChild(new RPCTypeProgram(str2));
        paramcp = rPCTypeScalar.createValueNode();
        cp cp2 = (cp)paramcp.b(rPCTypeLibrary.createValueNode());
        cp2.b(rPCTypeProgram.createValueNode());
      } 
    } 
    ax1 = this.f;
    cp1 = (cp)paramcp.a(0);
    if (cp1 == null);
    ax1 = (ax)ax1.getChild(str1);
    if (ax1 == null)
      return this.c; 
    cp1 = (cp)cp1.a(0);
    if (cp1 == null);
    ax1 = (ax)ax1.getChild(str2);
    if (ax1 == null)
      return this.c; 
    ArrayList arrayList = ax1.a();
    if (arrayList.size() > 0) {
      String str = cp1.b();
      if (str != null)
        a(df, arrayList, str); 
    } 
    a(ax1, cp1, df);
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 2, 95); 
    return this.c;
  }
  
  protected cp a(c3 paramc3) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 2, 96); 
    df df = new df();
    String str1 = this.b.y();
    String str2 = this.b.d();
    ax ax1 = null;
    if (this.b.q()) {
      this.f = this.a.q();
    } else {
      this.f = this.a.o();
    } 
    RPCType rPCType = this.a.g();
    this.d = rPCType.createValueNode();
    ax1 = (ax)this.f.getChild(str1);
    if (ax1 == null);
    RPCTypeStructure rPCTypeStructure1 = (RPCTypeStructure)rPCType.getChild(str1);
    if (rPCTypeStructure1 == null)
      rPCTypeStructure1 = new RPCTypeLibrary(str1); 
    cp cp1 = (cp)this.d.b(new cu(rPCTypeStructure1));
    ax1 = (ax)ax1.getChild(str2);
    if (ax1 == null);
    RPCTypeStructure rPCTypeStructure2 = (RPCTypeStructure)rPCTypeStructure1.getChild(str2);
    if (rPCTypeStructure2 == null)
      rPCTypeStructure2 = new RPCTypeProgram(str2); 
    cp cp2 = (cp)cp1.b(new cu(rPCTypeStructure2));
    a(ax1, paramc3, df);
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 2, 96); 
    return this.d;
  }
  
  private void a(ax paramax, cp paramcp, df paramdf) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 2, 95, "mapChildsTOIDS", ""); 
    int i = paramax.getChildCount();
    Vector vector = paramax.getChildren();
    for (byte b1 = 0; b1 < i; b1++) {
      ArrayList arrayList2;
      byte b2;
      String str2;
      ArrayList arrayList1;
      cp cp1;
      int j;
      ax ax1 = (ax)vector.get(b1);
      String str1 = ax1.getName();
      switch (ax1.c()) {
        case 1:
          paramdf.e();
          cp1 = (cp)paramcp.c(str1);
          if (cp1 != null) {
            ArrayList arrayList = ax1.a();
            String str = cp1.b();
            if (arrayList.size() > 0 && str != null) {
              try {
                a(paramdf, arrayList, str);
              } catch (Exception exception) {}
              break;
            } 
            a(ax1, cp1, paramdf);
          } 
          break;
        case 3:
          j = 0;
          b2 = 0;
          bool = (str1.charAt(0) == '?') ? 1 : 0;
          paramdf.a(-1);
          paramdf.d();
          paramdf.f(paramcp.d().getSize());
          if (bool) {
            j = paramcp.g();
          } else {
            j = paramcp.d(str1);
          } 
          arrayList2 = ax1.a();
          for (b2 = 0; b2 < j; b2++) {
            paramdf.e(b2);
            cp cp2 = null;
            if (bool) {
              cp2 = (cp)paramcp.a(b2);
            } else {
              cp2 = (cp)paramcp.a(str1, b2);
            } 
            if (arrayList2.size() > 0) {
              String str = cp2.b();
              if (str != null)
                a(paramdf, arrayList2, str); 
            } 
            a(ax1, cp2, paramdf);
          } 
          paramdf.a();
          break;
        case 8:
          arrayList1 = ax1.a();
          str2 = this.b.n(str1);
          if (arrayList1.size() > 0 && str2 != null)
            try {
              a(paramdf, arrayList1, str2);
            } catch (Exception bool) {
              Exception exception;
            }  
          break;
        default:
          throw new XMLException(27, "Illegal map type");
      } 
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 2, 95, "mapChildsTOIDS", ""); 
  }
  
  private void a(ax paramax, c3 paramc3, df paramdf) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 2, 96, "mapChildsFromIDS", ""); 
    int i = paramax.getChildCount();
    Vector vector = paramax.getChildren();
    for (byte b1 = 0; b1 < i; b1++) {
      Vector vector1;
      ArrayList arrayList;
      boolean bool;
      byte b2;
      String str;
      int j;
      c3 c31;
      dd dd;
      ax ax1 = (ax)vector.get(b1);
      switch (ax1.c()) {
        case 1:
          paramdf.e();
          c31 = (c3)paramc3.c(ax1.getName());
          if (c31 != null) {
            ArrayList arrayList1 = ax1.a();
            String str1 = c31.c();
            if (arrayList1.size() > 0 && str1 != null)
              b(paramdf, arrayList1, str1); 
            a(ax1, c31, paramdf);
          } 
          break;
        case 3:
          j = 0;
          str = ax1.getName();
          b2 = 0;
          bool = (str.charAt(0) == '?') ? 1 : 0;
          paramdf.a(-1);
          paramdf.d();
          paramdf.f(paramc3.d().getMaxOccur());
          arrayList = ax1.a();
          vector1 = null;
          if (bool) {
            j = paramc3.g();
            vector1 = paramc3.h();
          } else {
            j = paramc3.d(str);
            vector1 = paramc3.e(str);
          } 
          if (arrayList.size() > 0)
            a(paramdf, arrayList, vector1); 
          for (b2 = 0; b2 < j; b2++) {
            paramdf.e(b2);
            a(ax1, (c3)vector1.get(b2), paramdf);
          } 
          paramdf.a();
          break;
        case 4:
          dd = paramc3.k().b(ax1.e());
          if (dd != null) {
            str = dd.b();
            b(paramdf, ax1.a(), str);
          } 
          break;
        case 8:
          break;
        default:
          throw new XMLException(27, "Illegal map type");
      } 
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M2, 5, 2, 96, "mapChildsFromIDS", ""); 
  }
  
  private void a(df paramdf, ArrayList paramArrayList, String paramString) throws XMLException {
    if (XMLRPCService.a)
      Trace.checkpoint(Trace.CP2, 5, 2, 95, "value=" + paramString); 
    byte b1 = -1;
    ax ax1 = null;
    XMLTypeElement xMLTypeElement = null;
    if (this.b.q()) {
      xMLTypeElement = this.a.l();
    } else {
      xMLTypeElement = this.a.i();
    } 
    xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(this.b.y());
    xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(this.b.d());
    if (this.c == null)
      this.c = xMLTypeElement.createValueNode(); 
    c3 c31 = this.c;
    c3 c32 = null;
    c3 c33 = null;
    int i = paramArrayList.size();
    for (byte b2 = 2; b2 < i; b2++) {
      dd dd;
      a8 a8;
      c4 c4;
      at at;
      boolean bool;
      c3 c34;
      int m;
      String str2;
      ax1 = (ax)paramArrayList.get(b2);
      if (XMLRPCService.a)
        Trace.parameter(Trace.MP2, 5, 2, 95, "mapnode", ax1.e()); 
      c32 = c31;
      String str1 = ax1.e();
      int j = ax1.c();
      int k = 0;
      if (j != 4) {
        if (str1.charAt(0) == '?') {
          xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(0);
          k = c31.g();
        } else {
          xMLTypeElement = (XMLTypeElement)xMLTypeElement.getChild(str1);
          k = c31.d(str1);
        } 
        if (xMLTypeElement == null)
          throw new XMLException(25); 
      } 
      switch (ax1.c()) {
        case 1:
          c34 = (c3)c31.c(str1);
          if (c34 == null) {
            c34 = xMLTypeElement.createValueNode();
            c3 c35 = (c3)c32.j();
            if (c35 != null) {
              c3 c36 = (c3)c35.c(str1);
              if (c36 != null) {
                c36.c(c34);
                c34.d(c36);
              } 
            } 
            c31.b(c34);
          } 
          c31 = c34;
          break;
        case 3:
          m = 0;
          try {
            m = paramdf.b(++b1);
          } catch (Exception exception) {
            throw new XMLException(25);
          } 
          bool = (str1.charAt(0) == '?') ? 1 : 0;
          ax1.a(m);
          if (m >= k) {
            if (k > 0) {
              if (bool) {
                c33 = (c3)c31.a(k - 1);
              } else {
                c33 = (c3)c31.a(str1, k - 1);
              } 
            } else {
              c3 c35 = (c3)c31.j();
              if (c35 != null) {
                Vector vector = null;
                if (bool) {
                  vector = c35.h();
                } else {
                  vector = c35.e(str1);
                } 
                if (vector.size() > 0)
                  c33 = (c3)vector.lastElement(); 
              } 
            } 
            for (int n = k; n < m + 1; n++) {
              c3 c35 = xMLTypeElement.createValueNode();
              if (c33 != null) {
                c33.c(c35);
                c35.d(c33);
              } 
              c33 = c35;
              c31.b(c35);
            } 
          } 
          if (bool) {
            c31 = (c3)c31.a(m);
            break;
          } 
          c31 = (c3)c31.a(str1, m);
          break;
        case 4:
          str2 = ax1.e();
          at = xMLTypeElement.getAttributes();
          c4 = c31.k();
          a8 = at.b(str2);
          dd = null;
          if (a8 != null)
            dd = a8.a(paramString); 
          c4.a(dd);
          return;
        case 8:
          this.b.b(str1, paramString);
          return;
        default:
          throw new XMLException(27, "Serious problems in mapping.");
      } 
    } 
    if (paramString == null)
      paramString = ""; 
    if (c31 != null) {
      c31.b(paramString);
      if (XMLRPCService.a) {
        String str = new String(c31.a() + "=" + paramString);
        Trace.checkpoint(Trace.CP2, 5, 2, 96, str);
      } 
    } else {
      throw new XMLException(31);
    } 
  }
  
  private void b(df paramdf, ArrayList paramArrayList, String paramString) throws XMLException {
    if (XMLRPCService.a)
      Trace.checkpoint(Trace.CP2, 5, 2, 96, "value=" + paramString); 
    byte b1 = -1;
    int i = 0;
    int j = paramArrayList.size();
    ax ax1 = null;
    RPCType rPCType = this.a.g();
    cp cp1 = this.d;
    cp cp2 = null;
    cp cp3 = null;
    if (cp1 == null)
      throw new XMLException(26, "Unexpected null pointer."); 
    for (byte b2 = 0; b2 < j; b2++) {
      cp2 = cp1;
      ax1 = (ax)paramArrayList.get(b2);
      if (XMLRPCService.a)
        Trace.parameter(Trace.MP2, 5, 2, 95, "mapnode", ax1.e()); 
      String str = ax1.e();
      int k = 0;
      boolean bool = (str.charAt(0) == '?') ? 1 : 0;
      if (bool) {
        rPCType = (RPCType)rPCType.getChild(0);
        k = cp1.g();
      } else {
        rPCType = (RPCType)rPCType.getChild(str);
        k = cp1.d(str);
      } 
      if (rPCType == null && ax1.c() != 8)
        throw new XMLException(25); 
      switch (ax1.c()) {
        case 1:
          cp4 = (cp)cp1.c(str);
          if (cp4 == null) {
            cp4 = rPCType.createValueNode();
            cp cp5 = (cp)cp2.j();
            if (cp5 != null) {
              cp cp6 = (cp)cp5.c(str);
              if (cp6 != null) {
                cp6.c(cp4);
                cp4.d(cp6);
              } 
            } 
            cp1.b(cp4);
          } 
          cp1 = cp4;
          break;
        case 3:
          b1++;
          try {
            i = paramdf.b(b1);
          } catch (Exception cp4) {
            throw new XMLException(25);
          } 
          ax1.a(i);
          if (i >= k) {
            if (k > 0) {
              if (bool) {
                cp3 = (cp)cp1.a(k - 1);
              } else {
                cp3 = (cp)cp1.a(str, k - 1);
              } 
            } else {
              cp4 = (cp)cp1.j();
              if (cp4 != null) {
                Vector vector = null;
                if (bool) {
                  vector = cp4.h();
                } else {
                  vector = cp4.e(str);
                } 
                if (vector.size() > 0)
                  cp3 = (cp)vector.lastElement(); 
              } 
            } 
            for (int m = k; m < i + 1; m++) {
              cp cp5 = rPCType.createValueNode();
              if (cp3 != null) {
                cp3.c(cp5);
                cp5.d(cp3);
              } 
              cp3 = cp5;
              cp1.b(cp5);
            } 
          } 
          if (bool) {
            cp1 = (cp)cp1.a(i);
            break;
          } 
          cp1 = (cp)cp1.a(str, i);
          break;
        case 8:
          this.b.b(str, paramString);
          return;
      } 
    } 
    if (cp1 != null) {
      if (paramString == null)
        paramString = ""; 
      cp1.b(paramString);
      if (XMLRPCService.a) {
        String str = new String(cp1.a() + "=" + paramString);
        Trace.checkpoint(Trace.CP2, 5, 2, 96, str);
      } 
    } else {
      throw new XMLException(31);
    } 
  }
  
  private void a(df paramdf, ArrayList paramArrayList, Vector paramVector) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 2, 96); 
    byte b1 = -1;
    ax ax1 = null;
    int i = paramArrayList.size();
    RPCType rPCType = this.a.g();
    cp cp1 = this.d;
    cp cp2 = null;
    cp cp3 = null;
    i--;
    for (byte b2 = 0; b2 < i; b2++) {
      cp cp4;
      int k;
      cp2 = cp1;
      ax1 = (ax)paramArrayList.get(b2);
      if (XMLRPCService.a)
        Trace.parameter(Trace.MP2, 5, 2, 95, "mapnode", ax1.e()); 
      String str = ax1.e();
      int j = 0;
      boolean bool = (str.charAt(0) == '?') ? 1 : 0;
      if (bool) {
        rPCType = (RPCType)rPCType.getChild(0);
        j = cp1.g();
      } else {
        rPCType = (RPCType)rPCType.getChild(str);
        j = cp1.d(str);
      } 
      if (rPCType == null)
        throw new XMLException(25); 
      switch (ax1.c()) {
        case 1:
          cp4 = (cp)cp1.c(str);
          if (cp4 == null) {
            cp4 = rPCType.createValueNode();
            cp cp5 = (cp)cp2.j();
            if (cp5 != null) {
              cp cp6 = (cp)cp5.c(str);
              if (cp6 != null) {
                cp6.c(cp4);
                cp4.d(cp6);
              } 
            } 
            cp1.b(cp4);
          } 
          cp1 = cp4;
          break;
        case 3:
          k = 0;
          b1++;
          try {
            k = paramdf.b(b1);
          } catch (Exception exception) {
            throw new XMLException(25);
          } 
          ax1.a(k);
          if (k >= j) {
            if (j > 0) {
              if (bool) {
                cp3 = (cp)cp1.a(j - 1);
              } else {
                cp3 = (cp)cp1.a(str, j - 1);
              } 
            } else {
              cp cp5 = (cp)cp1.j();
              if (cp5 != null) {
                Vector vector = cp5.h();
                if (bool) {
                  vector = cp5.h();
                } else {
                  vector = cp5.e(str);
                } 
                if (vector.size() > 0)
                  cp3 = (cp)vector.lastElement(); 
              } 
            } 
            for (int m = j; m < k + 1; m++) {
              cp cp5 = rPCType.createValueNode();
              if (cp3 != null) {
                cp3.c(cp5);
                cp5.d(cp3);
              } 
              cp3 = cp5;
              cp1.b(cp5);
            } 
          } 
          if (bool) {
            cp1 = (cp)cp1.a(k);
            break;
          } 
          cp1 = (cp)cp1.a(str, k);
          break;
      } 
    } 
    if (cp1 != null) {
      String str = ((ax)paramArrayList.get(i)).getName();
      int j = 0;
      boolean bool = (str.charAt(0) == '?') ? 1 : 0;
      if (bool) {
        rPCType = (RPCType)rPCType.getChild(0);
        j = cp1.g();
      } else {
        rPCType = (RPCType)rPCType.getChild(str);
        j = cp1.d(str);
      } 
      if (rPCType == null)
        throw new XMLException(25); 
      int k = paramVector.size();
      if (j > 0)
        if (bool) {
          cp3 = (cp)cp1.a(j - 1);
        } else {
          cp3 = (cp)cp1.a(str, j - 1);
        }  
      for (int m = j; m < k; m++) {
        cp cp4 = rPCType.createValueNode();
        if (m == 0) {
          cp cp5 = (cp)cp1.j();
          if (cp5 != null) {
            Vector vector = null;
            cp cp6 = null;
            if (bool) {
              vector = cp5.h();
            } else {
              vector = cp5.e(str);
            } 
            if (vector.size() > 0) {
              cp6 = (cp)vector.lastElement();
              if (cp6 != null) {
                cp6.c(cp4);
                cp4.d(cp6);
              } 
            } 
          } 
          cp3 = cp4;
        } else {
          cp3.c(cp4);
          cp4.d(cp3);
          cp3 = cp4;
        } 
        cp1.b(cp4);
      } 
      for (byte b3 = 0; b3 < k; b3++) {
        String str1 = ((c3)paramVector.get(b3)).c();
        ((cp)cp1.a(b3)).b(str1);
        if (XMLRPCService.a) {
          String str2 = new String(cp1.a() + "=" + str1);
          Trace.checkpoint(Trace.CP2, 5, 2, 96, str2);
        } 
      } 
    } else {
      throw new XMLException(31);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\de.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */