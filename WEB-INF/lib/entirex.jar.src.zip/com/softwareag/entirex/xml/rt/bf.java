package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.Dump;
import com.softwareag.entirex.trace.Trace;
import java.util.StringTokenizer;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class bf extends DefaultHandler {
  private static final String a = "http://namespace.softwareag.com/entirex/xml/mapping";
  
  private static final String b = "";
  
  private static final String c = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "EntireXMapDef");
  
  private static final String d = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "Description");
  
  private static final String e = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "EntireXBrokerInfo");
  
  private static final String f = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "EntireXIdl");
  
  private static final String g = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "EntireXXml");
  
  private static final String h = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "Mapping");
  
  private static final String i = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "IdlLibrary");
  
  private static final String j = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "IdlStructure");
  
  private static final String k = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "IdlProgram");
  
  private static final String l = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "IdlParameter");
  
  private static final String m = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "BrokerId");
  
  private static final String n = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "ServerAddress");
  
  private static final String o = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "LogicalBrokerId");
  
  private static final String p = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "LogicalService");
  
  private static final String q = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "LogicalSetName");
  
  private static final String r = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "Options");
  
  private static final String s = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "ToXml");
  
  private static final String t = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "FromXml");
  
  private static final String u = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "Method");
  
  private static final String v = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "MappingInfo");
  
  private static final String w = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "XmlNode");
  
  private static final String x = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "Fault");
  
  private static final String y = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "XmlAttribute");
  
  private static final String z = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "MapNode");
  
  private static final String aa = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "XmlNamespaceDef");
  
  private static final String ab = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "Comment");
  
  private static final String ac = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "DocTypeInclude");
  
  private static final String ad = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "StyleSheet");
  
  private static final String ae = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "ProcessingInstruction");
  
  private static final String af = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "TargetServer");
  
  private static final String ag = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "XmlAdapterList");
  
  private static final String ah = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "XmlAdapter");
  
  private static final String ai = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "XmmList");
  
  private static final String aj = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "Xmm");
  
  private static final String ak = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "Default");
  
  private static final String al = av.a("http://namespace.softwareag.com/entirex/xml/mapping", "Encoding");
  
  private static final String am = "xmmVersion";
  
  private static final String an = "alias";
  
  private static final String ao = "arrayDim";
  
  private static final String ap = "exx-compression";
  
  private static final String aq = "exx-compresslevel";
  
  private static final String ar = "default";
  
  private static final String as = "defaultEncoding";
  
  private static final String at = "dimensions";
  
  private static final String au = "direction";
  
  private static final String av = "encoding";
  
  private static final String aw = "exx-encryption-level";
  
  private static final String ax = "execute";
  
  private static final String ay = "format";
  
  private static final String az = "formatString";
  
  private static final String a0 = "from";
  
  private static final String a1 = "fromXmlEncoding";
  
  private static final String a2 = "fromXmlFaultEncoding";
  
  private static final String a3 = "in";
  
  private static final String a4 = "inout";
  
  private static final String a5 = "length";
  
  private static final String a6 = "max";
  
  private static final String a7 = "min";
  
  private static final String a8 = "protocol";
  
  private static final String a9 = "name";
  
  private static final String ba = "namespace";
  
  private static final String bb = "namespacePrefix";
  
  private static final String bc = "exx-natural-security";
  
  private static final String bd = "nparms";
  
  private static final String be = "nullSuppression";
  
  private static final String bf = "nullValue";
  
  private static final String bg = "options";
  
  private static final String bh = "out";
  
  private static final String bi = "parameter";
  
  private static final String bj = "prefix";
  
  private static final String bk = "programNode";
  
  private static final String bl = "relatedIdlFile";
  
  private static final String bm = "relatedIdlLibrary";
  
  private static final String bn = "relatedIdlProgram";
  
  private static final String bo = "rpcPath";
  
  private static final String bp = "exx-rpc-userID";
  
  private static final String bq = "subtype";
  
  private static final String br = "to";
  
  private static final String bs = "toXmlEncoding";
  
  private static final String bt = "toXmlFaultEncoding";
  
  private static final String bu = "trim";
  
  private static final String bv = "type";
  
  private static final String bw = "uri";
  
  private static final String bx = "useIncomingEncoding";
  
  private static final String by = "exx-userID";
  
  private static final String bz = "exx-use-security";
  
  private static final String b0 = "validate";
  
  private static final String b1 = "entirexVersion";
  
  private static final String b2 = "xmlPath";
  
  private ar b3 = null;
  
  private StringBuffer b4 = new StringBuffer();
  
  private a7 b5 = null;
  
  private a7 b6 = null;
  
  private String b7 = null;
  
  private boolean b8 = false;
  
  private String b9 = null;
  
  private String ca = null;
  
  private String cb = null;
  
  private String cc = null;
  
  private String cd = null;
  
  private String ce = null;
  
  private au cf = new au();
  
  private ay cg = null;
  
  public bf(String paramString, ar paramar, boolean paramBoolean) {
    if (XMLRPCService.a) {
      Trace.checkpoint(Trace.CP4, 5, 31, 8);
      Trace.showMemoryUsage(Trace.RM, 5);
    } 
    this.b3 = paramar;
    this.b5 = new a7("", "", "XMMFILE");
    this.b6 = this.b5;
    this.b8 = paramBoolean;
    this.b7 = paramString;
  }
  
  public void startElement(String paramString1, String paramString2, String paramString3, Attributes paramAttributes) throws SAXException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M4, 5, 31, 44, "qName", paramString3); 
    try {
      a7 a71 = new a7(paramString1, paramString3, paramString2);
      if (paramAttributes != null) {
        String str1 = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        int i1 = paramAttributes.getLength();
        for (byte b10 = 0; b10 < i1; b10++) {
          str1 = paramAttributes.getURI(b10);
          str4 = paramAttributes.getLocalName(b10);
          str3 = paramAttributes.getQName(b10);
          int i2 = paramAttributes.getQName(b10).indexOf(':');
          if (i2 >= 0) {
            str2 = paramAttributes.getQName(b10).substring(0, i2);
          } else {
            str2 = "";
          } 
          a71.a(str2, str1, str4, str3, paramAttributes.getValue(b10));
        } 
      } 
      this.b6.a(a71);
      this.b6 = a71;
    } catch (Exception exception) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.M1, 5, 31, 44, exception.toString()); 
      throw new SAXException(exception);
    } finally {
      if (XMLRPCService.a)
        Trace.leaveMethod(Trace.M4, 5, 31, 44); 
    } 
  }
  
  public void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2) throws SAXException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M4, 5, 31, 5); 
    try {
      this.b4 = new StringBuffer();
      this.b4.append(paramArrayOfChar, paramInt1, paramInt2);
      String str = this.b4.toString();
      if (XMLRPCService.a && str != null && str.trim().length() > 0)
        Trace.checkpoint(Trace.CP4, 5, 31, 5, "characters", str); 
      this.b6.a(str);
    } catch (Exception exception) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.M1, 5, 31, 5, exception.toString()); 
      throw new SAXException(exception);
    } finally {
      if (XMLRPCService.a)
        Trace.leaveMethod(Trace.M4, 5, 31, 5); 
    } 
  }
  
  public void endElement(String paramString1, String paramString2, String paramString3) throws SAXException { this.b6 = this.b6.c(); }
  
  public void startDocument() {
    if (XMLRPCService.a)
      Trace.checkpoint(Trace.CP4, 5, 31, 43); 
  }
  
  public void endDocument() {
    if (XMLRPCService.a)
      Trace.checkpoint(Trace.CP4, 5, 31, 10); 
  }
  
  protected void a() {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 31, 36); 
    this.b6 = this.b5;
    try {
      c();
      d();
      e();
      f();
      g();
      h();
    } catch (XMLException xMLException) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.M1, 5, 31, 36, "XMLException = ", xMLException.toString()); 
      throw xMLException;
    } 
    if (XMLRPCService.a) {
      Trace.showMemoryUsage(Trace.RM, 5);
      Trace.leaveMethod(Trace.M2, 5, 31, 36);
    } 
  }
  
  private void a(String paramString1, String paramString2) {}
  
  private void c() {
    this.b6 = this.b6.c(c);
    if (this.b6 == null)
      throw new XMLException(78, "Missing tag: " + c); 
    String str1 = this.b6.d("xmmVersion");
    String str2 = this.b6.d("entirexVersion");
    a(str1, str2);
    if (this.b6.b(d) > 1)
      throw new XMLException(78, "Multiple definition:" + d); 
    this.b6 = this.b6.c(d);
  }
  
  private void d() {
    a7 a71 = this.b6;
    int i1 = 0;
    int i2 = 0;
    byte b10 = 0;
    this.b6 = this.b6.c(g);
    this.b6 = this.b6.c(s);
    i1 = this.b6.b(u);
    for (b10 = 0; b10 < i1; b10++) {
      this.cf.d();
      this.b6 = this.b6.a(u, b10);
      this.b9 = this.b6.d("relatedIdlLibrary");
      this.ca = this.b6.d("relatedIdlProgram");
      this.cd = this.b6.d("useIncomingEncoding");
      this.ce = this.b6.d("encoding");
      this.cb = a3.b(this.b9);
      this.cc = a3.b(this.ca);
      XMLTypeElement xMLTypeElement = null;
      if (this.b8) {
        xMLTypeElement = this.b3.k();
      } else {
        xMLTypeElement = this.b3.i();
      } 
      xMLTypeElement = a(xMLTypeElement, this.cb, this.cc);
      if (this.b8) {
        a(xMLTypeElement, this.b3.j(), this.b6);
      } else {
        a(xMLTypeElement, null, this.b6);
      } 
      i2 = this.b6.b(x);
      if (i2 == 1) {
        this.cf.d();
        this.b6 = this.b6.c(x);
        this.cd = this.b6.d("useIncomingEncoding");
        this.ce = this.b6.d("encoding");
        xMLTypeElement = null;
        if (this.b8) {
          xMLTypeElement = this.b3.m();
        } else {
          xMLTypeElement = this.b3.l();
        } 
        xMLTypeElement = a(xMLTypeElement, this.cb, this.cc);
        a(xMLTypeElement, null, this.b6);
        this.b6 = this.b6.c();
      } 
      this.b6 = this.b6.c();
    } 
    this.b6 = this.b6.c();
    this.b6 = this.b6.c(t);
    i1 = this.b6.b(u);
    for (b10 = 0; b10 < i1; b10++) {
      this.cf.d();
      this.b6 = this.b6.a(u, b10);
      this.b9 = this.b6.d("relatedIdlLibrary");
      this.ca = this.b6.d("relatedIdlProgram");
      this.cd = this.b6.d("useIncomingEncoding");
      this.ce = this.b6.d("encoding");
      this.cb = a3.b(this.b9);
      this.cc = a3.b(this.ca);
      if (this.b8) {
        XMLTypeElement xMLTypeElement = this.b3.i();
        xMLTypeElement = a(xMLTypeElement, this.cb, this.cc);
        a(xMLTypeElement, null, this.b6);
      } else {
        a(this.b3.j(), null, this.b6);
      } 
      i2 = this.b6.b(x);
      if (i2 == 1) {
        this.cf.d();
        this.b6 = this.b6.c(x);
        this.cd = this.b6.d("useIncomingEncoding");
        this.ce = this.b6.d("encoding");
        XMLTypeElement xMLTypeElement = null;
        if (this.b8) {
          xMLTypeElement = this.b3.l();
        } else {
          xMLTypeElement = this.b3.m();
        } 
        xMLTypeElement = a(xMLTypeElement, this.cb, this.cc);
        a(xMLTypeElement, null, this.b6);
        this.b6 = this.b6.c();
      } 
      this.b6 = this.b6.c();
    } 
    this.b6 = this.b6.c();
    this.b6 = a71;
  }
  
  private XMLTypeElement a(XMLTypeElement paramXMLTypeElement, String paramString1, String paramString2) throws XMLException {
    if (paramXMLTypeElement != null) {
      if (paramXMLTypeElement.getChild(this.cb) == null)
        paramXMLTypeElement.addChild(new XMLTypeElement(paramString1, 1, 1)); 
      paramXMLTypeElement = (XMLTypeElement)paramXMLTypeElement.getChild(paramString1);
      if (paramXMLTypeElement.getChild(paramString2) == null) {
        paramXMLTypeElement.addChild(new XMLTypeElement(paramString2, 1, 1));
      } else {
        throw new XMLException(78, "Duplicate program name (" + paramString1 + "/" + paramString2 + ").");
      } 
      paramXMLTypeElement = (XMLTypeElement)paramXMLTypeElement.getChild(this.cc);
    } 
    return paramXMLTypeElement;
  }
  
  private void e() {
    a7 a71 = this.b6;
    this.b6 = this.b6.c(f);
    int i1 = this.b6.b(i);
    for (byte b10 = 0; b10 < i1; b10++) {
      this.b6 = this.b6.a(b10);
      String str = this.b6.d("name");
      RPCTypeLibrary rPCTypeLibrary = new RPCTypeLibrary(str);
      rPCTypeLibrary = (RPCTypeLibrary)this.b3.a(null, rPCTypeLibrary);
      int i2 = this.b6.b(k);
      for (byte b11 = 0; b11 < i2; b11++) {
        this.b6 = this.b6.a(k, b11);
        String str1 = this.b6.d("name");
        RPCTypeProgram rPCTypeProgram = new RPCTypeProgram(str1, this.b6.d("formatString"), Integer.parseInt(this.b6.d("in")), Integer.parseInt(this.b6.d("inout")), Integer.parseInt(this.b6.d("out")), Integer.parseInt(this.b6.d("protocol")));
        this.b3.a(str, str1, this.b7);
        String str2 = this.b6.d("nparms");
        if (str2 != null)
          rPCTypeProgram.setParameterCount(Long.parseLong(str2)); 
        this.b3.a(rPCTypeLibrary, rPCTypeProgram);
        a(rPCTypeProgram, this.b6);
        this.b6 = this.b6.c();
      } 
      this.b6 = this.b6.c();
    } 
    this.b6 = a71;
  }
  
  private void a(BaseNode paramBaseNode, a7 parama7) throws XMLException {
    int i1 = parama7.b();
    for (byte b10 = 0; b10 < i1; b10++) {
      a7 a71 = parama7.a(b10);
      RPCTypeDateTime rPCTypeDateTime = null;
      String str1 = a71.d("type");
      String str2 = a71.d("name");
      String str3 = a71.d("direction");
      byte b11 = -1;
      if (str3.equals("INOUT")) {
        b11 = 3;
      } else if (str3.equals("OUT")) {
        b11 = 2;
      } else if (str3.equals("IN")) {
        b11 = 1;
      } else {
        throw new XMLException(78, "Illegal value of direction attribute.");
      } 
      if (str1.equals("A")) {
        int i2 = Integer.parseInt(a71.d("length"));
        rPCTypeDateTime = new RPCTypeString(str2, 7, b11, i2);
        String str = a71.d("trim");
        if (str != null && str.equals("1"))
          ((RPCTypeString)rPCTypeDateTime).a(false); 
      } else if (str1.equals("AV")) {
        String str6 = a71.d("length");
        int i2 = -1;
        if (!str6.equalsIgnoreCase("UNLIMITED")) {
          i2 = Integer.parseInt(str6);
          if (i2 == 0)
            i2 = -1; 
        } 
        rPCTypeDateTime = new RPCTypeString(str2, 7, b11, i2);
        rPCTypeDateTime.setVSize(i2);
        String str7 = a71.d("trim");
        if (str7 != null && str7.equals("1"))
          ((RPCTypeString)rPCTypeDateTime).a(false); 
      } else if (str1.equals("B")) {
        int i2 = Integer.parseInt(a71.d("length"));
        RPCTypeBinary rPCTypeBinary = new RPCTypeBinary(str2, 1, b11, i2);
      } else if (str1.equals("BV")) {
        String str = a71.d("length");
        int i2 = -1;
        if (!str.equalsIgnoreCase("UNLIMITED")) {
          i2 = Integer.parseInt(str);
          if (i2 == 0)
            i2 = -1; 
        } 
        RPCTypeBinary rPCTypeBinary = new RPCTypeBinary(str2, 1, b11, i2);
        rPCTypeBinary.setVSize(i2);
      } else if (str1.equals("D")) {
        RPCTypeDateTime rPCTypeDateTime1 = new RPCTypeDateTime(str2, 3, b11, 0);
      } else if (str1.equals("F")) {
        int i2 = Integer.parseInt(a71.d("length"));
        RPCTypeFloat rPCTypeFloat = new RPCTypeFloat(str2, 4, b11, i2);
      } else if (str1.equals("G")) {
        RPCTypeStructure rPCTypeStructure = new RPCTypeStructure(str2, 31, b11);
        a(rPCTypeStructure, a71);
      } else if (str1.equals("I")) {
        int i2 = Integer.parseInt(a71.d("length"));
        RPCTypeInt rPCTypeInt = new RPCTypeInt(str2, 5, b11, i2);
      } else if (str1.equals("K")) {
        int i2 = Integer.parseInt(a71.d("length"));
        rPCTypeDateTime = new RPCTypeString(str2, 7, b11, i2);
        String str = a71.d("trim");
        if (str != null && str.equals("1"))
          ((RPCTypeString)rPCTypeDateTime).a(false); 
      } else if (str1.equals("KV")) {
        String str6 = a71.d("length");
        int i2 = -1;
        if (!str6.equalsIgnoreCase("UNLIMITED")) {
          i2 = Integer.parseInt(str6);
          if (i2 == 0)
            i2 = -1; 
        } 
        rPCTypeDateTime = new RPCTypeString(str2, 7, b11, i2);
        rPCTypeDateTime.setVSize(i2);
        String str7 = a71.d("trim");
        if (str7 != null && str7.equals("1"))
          ((RPCTypeString)rPCTypeDateTime).a(false); 
      } else if (str1.equals("L")) {
        RPCTypeBoolean rPCTypeBoolean = new RPCTypeBoolean(str2, 2, b11);
      } else if (str1.equals("N")) {
        int i2 = 0;
        int i3 = 0;
        String str = a71.d("length");
        int i4 = str.indexOf(".");
        if (i4 >= 0) {
          i2 = Integer.parseInt(str.substring(0, i4));
          i3 = Integer.parseInt(str.substring(i4 + 1));
        } else {
          i2 = Integer.parseInt(str);
          i3 = 0;
        } 
        RPCTypeNumber rPCTypeNumber = new RPCTypeNumber(str2, 6, b11, 'N', i2, i3);
      } else if (str1.equals("NU")) {
        int i2 = 0;
        int i3 = 0;
        String str = a71.d("length");
        int i4 = str.indexOf(".");
        if (i4 >= 0) {
          i2 = Integer.parseInt(str.substring(0, i4));
          i3 = Integer.parseInt(str.substring(i4 + 1));
        } else {
          i2 = Integer.parseInt(str);
          i3 = 0;
        } 
        RPCTypeNumber rPCTypeNumber = new RPCTypeNumber(str2, 6, b11, 'N', i2, i3);
        ((RPCTypeNumber)rPCTypeNumber).setUnsigned(true);
      } else if (str1.equals("P")) {
        int i2 = 0;
        int i3 = 0;
        String str = a71.d("length");
        int i4 = str.indexOf(".");
        if (i4 >= 0) {
          i2 = Integer.parseInt(str.substring(0, i4));
          i3 = Integer.parseInt(str.substring(i4 + 1));
        } else {
          i2 = Integer.parseInt(str);
          i3 = 0;
        } 
        RPCTypeNumber rPCTypeNumber = new RPCTypeNumber(str2, 6, b11, 'P', i2, i3);
      } else if (str1.equals("PU")) {
        int i2 = 0;
        int i3 = 0;
        String str = a71.d("length");
        int i4 = str.indexOf(".");
        if (i4 >= 0) {
          i2 = Integer.parseInt(str.substring(0, i4));
          i3 = Integer.parseInt(str.substring(i4 + 1));
        } else {
          i2 = Integer.parseInt(str);
          i3 = 0;
        } 
        RPCTypeNumber rPCTypeNumber = new RPCTypeNumber(str2, 6, b11, 'P', i2, i3);
        ((RPCTypeNumber)rPCTypeNumber).setUnsigned(true);
      } else if (str1.startsWith("S")) {
        RPCTypeStructure rPCTypeStructure = new RPCTypeStructure(str2, 32, b11);
        a(rPCTypeStructure, a71);
      } else if (str1.equals("T")) {
        rPCTypeDateTime = new RPCTypeDateTime(str2, 8, b11, 1);
      } else {
        throw new XMLException(78, "(Unknown RPC type)");
      } 
      String str4 = a71.d("options");
      if (str4 != null && str4.equalsIgnoreCase("ALIGN"))
        rPCTypeDateTime.setAlignment(true); 
      String str5 = a71.d("dimensions");
      if (str5 != null) {
        int i2 = Integer.parseInt(str5);
        String str = a71.d("arrayDim");
        int[] arrayOfInt = new int[3];
        boolean[] arrayOfBoolean = new boolean[3];
        byte b12 = 0;
        int i3 = -1;
        byte b13 = 0;
        int i4 = i2 - 1;
        for (b12 = 0; b12 < i4; b12++) {
          b13 = 0;
          i3 = str.indexOf(",", b13);
          String str6 = str.substring(b13, i3);
          if (str6.startsWith("V")) {
            if (str6.length() == 1) {
              arrayOfInt[b12] = -1;
              arrayOfBoolean[b12] = true;
            } else {
              arrayOfInt[b12] = Integer.parseInt(str6.substring(1));
              arrayOfBoolean[b12] = true;
            } 
          } else if (str6.equalsIgnoreCase("UNLIMITED")) {
            arrayOfInt[b12] = -1;
            arrayOfBoolean[b12] = true;
          } else {
            arrayOfInt[b12] = Integer.parseInt(str6);
          } 
          str = str.substring(i3 + 1);
        } 
        if (str.equalsIgnoreCase("V") || str.equalsIgnoreCase("UNLIMITED")) {
          arrayOfInt[b12] = -1;
          arrayOfBoolean[b12] = true;
        } else if (str.startsWith("V")) {
          arrayOfInt[b12] = Integer.parseInt(str.substring(1));
          arrayOfBoolean[b12] = true;
        } else {
          arrayOfInt[b12] = Integer.parseInt(str);
        } 
        RPCTypeArray rPCTypeArray = null;
        switch (i2) {
          case 3:
            rPCTypeArray = RPCTypeArray.create(str2, arrayOfInt[0], arrayOfBoolean[0], arrayOfInt[1], arrayOfBoolean[1], arrayOfInt[2], arrayOfBoolean[2], rPCTypeDateTime);
            break;
          case 2:
            rPCTypeArray = RPCTypeArray.create(str2, arrayOfInt[0], arrayOfBoolean[0], arrayOfInt[1], arrayOfBoolean[1], rPCTypeDateTime);
            break;
          case 1:
            rPCTypeArray = RPCTypeArray.create(str2, arrayOfInt[0], arrayOfBoolean[0], rPCTypeDateTime);
            break;
        } 
        this.b3.a(paramBaseNode, rPCTypeArray);
      } else {
        this.b3.a(paramBaseNode, rPCTypeDateTime);
      } 
    } 
  }
  
  private void f() {
    int i1 = 0;
    int i2 = 0;
    int i3 = 0;
    int i4 = 0;
    int i5 = 0;
    int i6 = 0;
    String str1 = null;
    String str2 = null;
    a7 a71 = this.b6;
    i1 = this.b6.b(h);
    if (i1 == 1) {
      this.b6 = this.b6.c(h);
      i2 = this.b6.b(s);
      if (i2 == 1) {
        this.b6 = this.b6.c(s);
        i3 = this.b6.b(u);
        for (byte b10 = 0; b10 < i3; b10++) {
          this.b6 = this.b6.a(u, b10);
          str1 = a3.b(this.b6.d("relatedIdlLibrary"));
          str2 = a3.b(this.b6.d("relatedIdlProgram"));
          i4 = this.b6.b(z);
          for (byte b11 = 0; b11 < i4; b11++) {
            a7 a72 = this.b6.a(z, b11);
            String str3 = a72.d("rpcPath");
            String str4 = a72.d("xmlPath");
            if (this.b8) {
              this.b3.b(str1, str2, str4, str3);
            } else {
              this.b3.a(str1, str2, str3, str4);
            } 
          } 
          i5 = this.b6.b(x);
          if (i5 == 1) {
            this.b6 = this.b6.c(x);
            i6 = this.b6.b(z);
            for (byte b12 = 0; b12 < i6; b12++) {
              a7 a72 = this.b6.a(z, b12);
              String str3 = a72.d("rpcPath");
              String str4 = a72.d("xmlPath");
              if (this.b8) {
                this.b3.d(str1, str2, str4, str3);
              } else {
                this.b3.c(str1, str2, str3, str4);
              } 
            } 
            this.b6 = this.b6.c();
          } 
          this.b6 = this.b6.c();
        } 
        this.b6 = this.b6.c();
      } else if (XMLRPCService.a) {
        Trace.checkpoint(Trace.M1, 5, 31, 117, "No mapping information available (ToXml).");
      } 
      i2 = this.b6.b(t);
      if (i2 == 1) {
        this.b6 = this.b6.c(t);
        i3 = this.b6.b(u);
        for (byte b10 = 0; b10 < i3; b10++) {
          this.b6 = this.b6.a(u, b10);
          str1 = a3.b(this.b6.d("relatedIdlLibrary"));
          str2 = a3.b(this.b6.d("relatedIdlProgram"));
          i4 = this.b6.b(z);
          for (byte b11 = 0; b11 < i4; b11++) {
            a7 a72 = this.b6.a(z, b11);
            String str3 = a72.d("xmlPath");
            String str4 = a72.d("rpcPath");
            if (this.b8) {
              this.b3.a(str1, str2, str4, str3);
            } else {
              this.b3.b(str1, str2, str3, str4);
            } 
          } 
          i5 = this.b6.b(x);
          if (i5 == 1) {
            this.b6 = this.b6.c(x);
            i6 = this.b6.b(s);
            for (byte b12 = 0; b12 < i6; b12++) {
              a7 a72 = this.b6.a(z, b12);
              String str3 = a72.d("xmlPath");
              String str4 = a72.d("rpcPath");
              if (this.b8) {
                this.b3.c(str1, str2, str4, str3);
              } else {
                this.b3.d(str1, str2, str3, str4);
              } 
            } 
            this.b6 = this.b6.c();
          } 
          this.b6 = this.b6.c();
        } 
        this.b6 = this.b6.c();
      } 
    } else if (XMLRPCService.a) {
      Trace.checkpoint(Trace.M1, 5, 31, 117, "No mapping information available (FromXml).");
    } 
    this.b6 = a71;
  }
  
  private void a(BaseNode paramBaseNode1, BaseNode paramBaseNode2, a7 parama7) throws XMLException {
    byte b10 = 0;
    int i1 = 0;
    int i2 = 0;
    int i3 = parama7.b(w);
    for (byte b11 = 0; b11 < i3; b11++) {
      a7 a71 = parama7.a(w, b11);
      String str1 = a71.d("name");
      String str2 = a71.d("default");
      String str3 = a71.d("format");
      String str4 = a71.d("length");
      String str5 = a71.d("min");
      String str6 = a71.d("max");
      String str7 = a71.d("type");
      String str8 = a71.d("nullSuppression");
      String str9 = a71.d("nullValue");
      String str10 = a71.d("programNode");
      String str11 = a71.d("namespacePrefix");
      String str12 = a71.d("trim");
      i2 = a71.b(aa);
      aw[] arrayOfaw = new aw[i2];
      for (b10 = 0; b10 < i2; b10++) {
        a7 a72 = a71.a(aa, b10);
        String str14 = a72.d("prefix");
        String str15 = a72.d("uri");
        arrayOfaw[b10] = new aw(str14, str15);
        this.cf.a(str14, str15);
      } 
      String str13 = this.cf.b(str11);
      XMLTypeElement xMLTypeElement1 = null;
      XMLTypeElement xMLTypeElement2 = null;
      int i4 = 1;
      byte b12 = 1;
      if (str5 != null)
        i4 = a(str5); 
      if (str6 != null)
        b12 = (a(str6) == 0) ? -1 : a(str6); 
      xMLTypeElement1 = new XMLTypeElement(str11, str13, str1, i4, b12);
      xMLTypeElement1.setEncoding(this.ce);
      xMLTypeElement1.setUseIncomingEncoding(this.cd);
      xMLTypeElement1.setNullValueSuppression(a(str8, i4, b12));
      xMLTypeElement1.setDefaultValue(str2);
      if (str3 != null) {
        int i6 = str3.indexOf(":");
        if (i6 > 0) {
          xMLTypeElement1.setInternalDataType(str3.substring(0, i6));
          xMLTypeElement1.setInternalDataFormat(str3.substring(i6 + 1));
        } else {
          xMLTypeElement1.setInternalDataType(str3);
        } 
      } 
      xMLTypeElement1.setLength(str4);
      xMLTypeElement1.setXMLSchemaType(str7);
      xMLTypeElement1.setNullValue(str9);
      if (str12 != null)
        xMLTypeElement1.a(2); 
      if (paramBaseNode2 != null) {
        xMLTypeElement2 = new XMLTypeElement(str11, str13, str1, i4, b12);
        xMLTypeElement2.setEncoding(this.ce);
        xMLTypeElement2.setUseIncomingEncoding(this.cd);
        xMLTypeElement2.setNullValueSuppression(a(str8, i4, b12));
        xMLTypeElement2.setDefaultValue(str2);
        if (str3 != null) {
          int i6 = str3.indexOf(":");
          if (i6 > 0) {
            xMLTypeElement2.setInternalDataType(str3.substring(0, i6));
            xMLTypeElement2.setInternalDataFormat(str3.substring(i6 + 1));
          } else {
            xMLTypeElement2.setInternalDataType(str3);
          } 
        } 
        xMLTypeElement2.setLength(str4);
        xMLTypeElement2.setXMLSchemaType(str7);
        xMLTypeElement2.setNullValue(str9);
        if (str12 != null)
          xMLTypeElement1.a(2); 
      } 
      int i5 = arrayOfaw.length;
      for (b10 = 0; b10 < i5; b10++) {
        String str14 = arrayOfaw[b10].a();
        String str15 = arrayOfaw[b10].b();
        xMLTypeElement1.getNamespaceContainer().a(str14, str15);
        if (paramBaseNode2 != null)
          xMLTypeElement2.getNamespaceContainer().a(str14, str15); 
      } 
      i1 = a71.b(y);
      for (b10 = 0; b10 < i1; b10++) {
        a7 a72 = a71.a(y, b10);
        String str14 = a72.d("name");
        String str15 = a72.d("namespacePrefix");
        String str16 = a72.d("default");
        String str17 = a72.d("nullValue");
        String str18 = a72.d("nullSuppression");
        String str19 = a72.d("type");
        String str20 = a72.d("format");
        String str21 = a72.d("length");
        String str22 = "";
        String str23 = "";
        if (str15 != null) {
          str22 = this.cf.b(str15);
          str23 = str15 + ":" + str14;
        } 
        a8 a81 = new a8(str15, str22, str14, str16, a(str18, i4, b12));
        if (str20 != null) {
          int i6 = str20.indexOf(':');
          if (i6 >= 0) {
            a81.f(str20.substring(0, i6));
            a81.e(str20.substring(i6 + 1));
          } else {
            a81.f(str20);
          } 
        } 
        a81.d(str19);
        a81.g(str17);
        xMLTypeElement1.addAttribute(a81);
        if (paramBaseNode2 != null)
          xMLTypeElement2.addAttribute(a81); 
      } 
      xMLTypeElement1 = (XMLTypeElement)paramBaseNode1.addChild(xMLTypeElement1);
      if (paramBaseNode2 != null)
        xMLTypeElement2 = (XMLTypeElement)paramBaseNode2.addChild(xMLTypeElement2); 
      if (str10 != null) {
        try {
          xMLTypeElement1.a(str10, this.b9, this.ca, str2);
        } catch (XMLException xMLException) {
          String str = "Redefintion of program mapping (Namespace=" + xMLTypeElement1.getUri() + ", QName=" + xMLTypeElement1.getQName() + ")";
          if (XMLRPCService.a)
            Trace.checkpoint(Trace.CP1, 5, 31, 98, str); 
          Dump.log(str);
          throw new XMLException(27, str);
        } 
        if (paramBaseNode2 != null)
          xMLTypeElement2.a(str10, this.b9, this.ca, str2); 
      } 
      if (paramBaseNode2 != null) {
        a(xMLTypeElement1, xMLTypeElement2, a71);
      } else {
        a(xMLTypeElement1, null, a71);
      } 
    } 
    if (i3 == 1) {
      int i4 = ((XMLTypeElement)paramBaseNode1.getChild(0)).getMaxOccur();
      if (i4 != 1) {
        ((XMLTypeElement)paramBaseNode1).b(XMLTypeElement.w);
        if (paramBaseNode2 != null)
          ((XMLTypeElement)paramBaseNode2).b(XMLTypeElement.w); 
      } 
    } 
  }
  
  public int a(String paramString) {
    int i1 = 0;
    if (paramString != null) {
      StringTokenizer stringTokenizer = new StringTokenizer(paramString, ",");
      String str = null;
      while (stringTokenizer.hasMoreElements()) {
        str = (String)stringTokenizer.nextElement();
        int i2 = -1;
        if (str != null && str.trim().equalsIgnoreCase("unlimited")) {
          i2 = 0;
        } else {
          try {
            i2 = Integer.parseInt(str);
          } catch (Exception exception) {}
        } 
        if (!i1 && i2 > 0) {
          i1 = i2;
          continue;
        } 
        if (i2 >= 0)
          i1 *= i2; 
      } 
    } 
    return i1;
  }
  
  protected ay b() { return this.cg; }
  
  private void g() {
    a7 a71 = this.b6;
    a7 a72 = this.b6.c(e);
    this.cg = null;
    if (this.b3.v()) {
      this.cg = this.b3.n(this.b7);
      if (this.cg == null)
        this.cg = new ay(); 
    } else {
      this.cg = new ay();
    } 
    a7 a73 = a72.c(m);
    a7 a74 = a72.c(n);
    a7 a75 = a72.c(o);
    a7 a76 = a72.c(p);
    a7 a77 = a72.c(q);
    a7 a78 = a72.c(r);
    if (this.b3.v()) {
      if (this.cg.b() == null && a73 != null)
        this.cg.a(a73.a()); 
      if (this.cg.c() == null && a74 != null)
        this.cg.b(a74.a()); 
      if (this.cg.d() == null && a75 != null)
        this.cg.c(a75.a()); 
      if (this.cg.e() == null && a76 != null)
        this.cg.d(a76.a()); 
      if (this.cg.f() == null && a77 != null)
        this.cg.e(a77.a()); 
      if (a78 != null) {
        String str = a78.d("exx-compression");
        if (this.cg.m() == null && str != null)
          this.cg.l(str); 
        str = a78.d("exx-compresslevel");
        if (this.cg.n() == null && str != null)
          this.cg.m(str); 
        str = a78.d("exx-encryption-level");
        if (this.cg.j() == null && str != null)
          this.cg.i(str); 
        str = a78.d("exx-natural-security");
        if (this.cg.k() == null && str != null)
          this.cg.j(str); 
        str = a78.d("exx-rpc-userID");
        if (this.cg.h() == null && str != null)
          this.cg.g(str); 
        str = a78.d("exx-userID");
        if (this.cg.g() == null && str != null)
          this.cg.f(str); 
        str = a78.d("exx-use-security");
        if (this.cg.i() == null && str != null)
          this.cg.h(str); 
      } 
    } else {
      if (a73 != null)
        this.cg.a(a73.a()); 
      if (a74 != null)
        this.cg.b(a74.a()); 
      if (a75 != null)
        this.cg.c(a75.a()); 
      if (a76 != null)
        this.cg.d(a76.a()); 
      if (a77 != null)
        this.cg.e(a77.a()); 
      if (a78 != null) {
        String str = a78.d("exx-compression");
        if (str != null)
          this.cg.l(str); 
        str = a78.d("exx-compresslevel");
        if (str != null)
          this.cg.m(str); 
        str = a78.d("exx-encryption-level");
        if (str != null)
          this.cg.i(str); 
        str = a78.d("exx-natural-security");
        if (str != null)
          this.cg.j(str); 
        str = a78.d("exx-rpc-userID");
        if (str != null)
          this.cg.g(str); 
        str = a78.d("exx-userID");
        if (str != null)
          this.cg.f(str); 
        str = a78.d("exx-use-security");
        if (str != null)
          this.cg.h(str); 
      } 
    } 
    if (this.b3.v())
      this.b3.a(this.b7, this.cg); 
    this.b3.a(this.cg);
    this.b6 = a71;
  }
  
  private void h() {
    a7 a71 = this.b6;
    String str = null;
    a7 a72 = this.b6.c(ak);
    if (a72 != null) {
      a7 a73 = a72.c(al);
      if (a73 != null) {
        str = a73.d("defaultEncoding");
        if (str != null)
          this.b3.c(str); 
        str = a73.d("useIncomingEncoding");
        if (str != null)
          this.b3.b(str); 
        str = a73.d("toXmlEncoding");
        if (str != null)
          this.b3.d(str); 
        str = a73.d("toXmlFaultEncoding");
        if (str != null)
          this.b3.f(str); 
        str = a73.d("fromXmlEncoding");
        if (str != null)
          this.b3.d(str); 
        str = a73.d("fromXmlFaultEncoding");
        if (str != null)
          this.b3.f(str); 
      } 
    } 
  }
  
  private int a(String paramString, int paramInt1, int paramInt2) {
    byte b10 = 0;
    if (paramString != null) {
      if (paramString.equals("NVS_FIELD") || paramString.equals("NVS_ATTRIBUTE_FIELD")) {
        b10 = 1;
      } else if (paramString.equals("NVS_ARRAY_ALL")) {
        b10 = 2;
      } else if (paramString.equals("NVS_ARRAY_TRIM")) {
        b10 = 3;
      } else if (paramString.equals("NVS_ATT_IFF_ELEMENT")) {
        b10 = 4;
      } 
    } else if (paramInt1 == 0) {
      if (paramInt2 == 1) {
        b10 = 1;
      } else {
        b10 = 3;
      } 
    } else if (paramInt1 == paramInt2) {
      b10 = 0;
    } else {
      b10 = 3;
    } 
    return b10;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\bf.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */