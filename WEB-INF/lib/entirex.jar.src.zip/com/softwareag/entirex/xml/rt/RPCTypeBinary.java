package com.softwareag.entirex.xml.rt;

public class RPCTypeBinary extends RPCTypeScalar {
  private static cs a = new cs();
  
  public RPCTypeBinary() { this(1, 3, 0); }
  
  public RPCTypeBinary(String paramString) { this(paramString, 1, 3, 0); }
  
  public RPCTypeBinary(int paramInt) { this(1, 3, paramInt); }
  
  public RPCTypeBinary(String paramString, int paramInt) { this(paramString, 1, 3, paramInt); }
  
  public RPCTypeBinary(String paramString, int paramInt1, int paramInt2) { this(paramString, 1, paramInt2, paramInt1); }
  
  public RPCTypeBinary(int paramInt1, int paramInt2) { this(1, paramInt2, paramInt1); }
  
  public RPCTypeBinary(String paramString, int paramInt1, int paramInt2, int paramInt3) {
    super(paramString, paramInt1, paramInt2);
    this.j = paramInt3;
  }
  
  public RPCTypeBinary(int paramInt1, int paramInt2, int paramInt3) {
    super(paramInt1, paramInt2);
    this.j = paramInt3;
  }
  
  public static final String toString(byte[] paramArrayOfByte) { return a.a(paramArrayOfByte); }
  
  public static final byte[] fromString(String paramString) { return a.b(paramString); }
  
  public cp createValueNode() { return new co(this, ""); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\RPCTypeBinary.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */