package com.softwareag.entirex.xml.rt;

public class dc extends db {
  private static final String a = "id";
  
  private static final String b = "hRef";
  
  protected dc() {
    this.f = "id";
    this.g = "hRef";
  }
  
  protected dc(c0 paramc0) {
    super(paramc0);
    this.f = "id";
    this.g = "hRef";
  }
  
  public XMLTypeElement c() { return null; }
  
  protected void a() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\dc.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */