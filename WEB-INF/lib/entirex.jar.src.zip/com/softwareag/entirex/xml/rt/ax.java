package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Vector;

class ax extends BaseNodeImpl {
  private static int a = 0;
  
  protected static final int b = 0;
  
  protected static final int c = 1;
  
  protected static final int d = 2;
  
  protected static final int e = 3;
  
  protected static final int f = 4;
  
  protected static final int g = 8;
  
  private ArrayList h = new ArrayList();
  
  private int i = 0;
  
  private int j = -1;
  
  public ax(int paramInt) {
    super("?" + a);
    a++;
    this.i = paramInt;
  }
  
  public ax(int paramInt, String paramString) {
    super(paramString);
    this.i = paramInt;
  }
  
  public ArrayList a() { return this.h; }
  
  public int c() { return this.i; }
  
  public void a(int paramInt) { this.j = paramInt; }
  
  public int d() { return this.j; }
  
  public String e() { return getName(); }
  
  public static void a(ax paramax, String paramString1, String paramString2, BaseNode paramBaseNode1, BaseNode paramBaseNode2) throws XMLException {
    ax ax1 = a(paramax, paramString1, paramBaseNode1, null);
    if (ax1 != null) {
      a(null, paramString2, paramBaseNode2, ax1.h);
      if (ax1.h.size() == 0)
        throw new XMLException(26, "(" + paramString1 + " / " + paramString2 + " )"); 
    } else {
      throw new XMLException(26, "(" + paramString1 + " / --- )");
    } 
  }
  
  public static ax a(ax paramax, String paramString, BaseNode paramBaseNode, ArrayList paramArrayList) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M3, 5, 1, 2, "path", paramString); 
    Vector vector = new Vector();
    int k = -1;
    int m = -1;
    String str = paramString;
    while (paramString.length() > 0) {
      m = paramString.indexOf("/");
      k = paramString.indexOf("'");
      if (m == k) {
        vector.addElement(paramString);
        paramString = "";
        continue;
      } 
      if (m < k && m != -1) {
        String str1 = paramString.substring(0, m);
        vector.addElement(str1);
        paramString = paramString.substring(m + 1);
        continue;
      } 
      if (m > k || m == -1) {
        String str1;
        k = paramString.indexOf("'", k + 1);
        if (k != -1 && paramString.substring(0, k).endsWith("/")) {
          paramString = paramString.substring(0, k - 1) + paramString.substring(k);
          k--;
        } 
        m = paramString.indexOf("/", k);
        if (m == -1) {
          str1 = paramString;
          paramString = "";
        } else {
          str1 = paramString.substring(0, m);
          paramString = paramString.substring(m + 1);
        } 
        vector.addElement(str1);
      } 
    } 
    byte b1 = 0;
    ax ax1 = paramax;
    Enumeration enumeration = vector.elements();
    while (enumeration.hasMoreElements()) {
      if (XMLRPCService.a)
        Trace.parameter(Trace.MP3, 5, 1, 2, "mapnode", (ax1 == null) ? "null" : ax1.getName()); 
      String str1 = (String)enumeration.nextElement();
      String str2 = null;
      String str3 = null;
      ax ax2 = null;
      int n = str1.indexOf("@@");
      if (n >= 0) {
        str3 = str1.substring(n + 2);
        str1 = str1.substring(0, n);
      } 
      n = str1.indexOf('@');
      if (n >= 0) {
        str2 = str1.substring(n + 1);
        str1 = str1.substring(0, n);
      } 
      if (str1 != null && str1.length() > 0) {
        String str4 = str1;
        n = str1.indexOf('*');
        if (n >= 0)
          str4 = str1.substring(0, n); 
        if (str4.equals("")) {
          ax2 = (ax1 == null) ? null : (ax)ax1.getChild(0);
        } else {
          ax2 = (ax1 == null) ? null : (ax)ax1.getChild(str4);
        } 
        if (ax2 == null) {
          if (XMLRPCService.a) {
            String str5 = new String("creating new child mapping" + str1 + " (parent:" + ax1 + ")");
            Trace.checkpoint(Trace.CP3, 5, 1, 2, str5);
          } 
          n = str1.indexOf('*');
          if (n >= 0) {
            if (n == 0) {
              ax2 = new ax(3);
            } else {
              ax2 = new ax(3, str1.substring(0, n));
            } 
          } else {
            ax2 = new ax(1, str1);
          } 
          if (paramArrayList == null) {
            if (ax1 != null) {
              b1++;
              ax1.addChild(ax2);
            } 
          } else {
            paramArrayList.add(ax2);
          } 
        } 
        ax1 = ax2;
        if (str2 != null) {
          ax2 = (ax)ax1.getChild(str2);
          if (ax2 == null) {
            b1++;
            ax2 = new ax(4, str2);
          } 
          if (paramArrayList == null) {
            ax1.addChild(ax2);
            ax1 = ax2;
          } else {
            paramArrayList.add(ax2);
          } 
        } 
        if (str3 != null) {
          ax2 = (ax)ax1.getChild(str3);
          if (ax2 == null) {
            b1++;
            ax2 = new ax(8, str3);
          } 
          if (paramArrayList == null) {
            ax1.addChild(ax2);
            ax1 = ax2;
            continue;
          } 
          paramArrayList.add(ax2);
        } 
      } 
    } 
    if (XMLRPCService.a) {
      Trace.checkpoint(Trace.CP3, 5, 1, 2, "nCreated", b1);
      Trace.leaveMethod(Trace.M3, 5, 1, 2);
    } 
    return ax1;
  }
  
  protected void b(int paramInt) {
    ArrayList arrayList = null;
    for (byte b1 = 0; b1 < paramInt; b1++)
      System.out.print("    "); 
    System.out.print("MapNode: " + getName() + "(" + c() + ") Attached=");
    arrayList = a();
    for (byte b2 = 0; b2 < arrayList.size(); b2++)
      System.out.print(((ax)arrayList.get(b2)).e() + ","); 
    System.out.println();
    int k = getChildCount();
    for (byte b3 = 0; b3 < k; b3++) {
      ax ax1 = (ax)getChild(b3);
      ax1.b(paramInt + 1);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\ax.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */