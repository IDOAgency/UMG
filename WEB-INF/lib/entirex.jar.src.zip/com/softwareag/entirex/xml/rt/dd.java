package com.softwareag.entirex.xml.rt;

public class dd {
  private a8 a = null;
  
  private String b = null;
  
  private boolean c = false;
  
  public dd(a8 parama8) { this.a = parama8; }
  
  public dd(a8 parama8, String paramString) {
    this.a = parama8;
    this.b = paramString;
  }
  
  public dd(String paramString) { this.b = paramString; }
  
  protected a8 a() { return this.a; }
  
  public String b() {
    String str = this.b;
    if (str == null)
      str = ""; 
    if (str.equals(""))
      str = this.a.b(); 
    return str;
  }
  
  public void a(String paramString) {
    if (paramString != null) {
      this.b = paramString.trim();
    } else {
      this.b = "";
    } 
  }
  
  public Object clone() {
    dd dd1 = new dd(this.a, this.b);
    dd1.c = this.c;
    return dd1;
  }
  
  protected boolean c() { return this.c; }
  
  protected void a(boolean paramBoolean) { this.c = paramBoolean; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\dd.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */