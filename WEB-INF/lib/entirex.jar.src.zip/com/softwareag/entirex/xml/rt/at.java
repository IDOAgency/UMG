package com.softwareag.entirex.xml.rt;

import java.util.Hashtable;
import java.util.Vector;

public class at {
  private Vector a = new Vector();
  
  private Hashtable b = new Hashtable();
  
  int c = 0;
  
  public void a(String paramString1, String paramString2) { a(null, null, paramString1, paramString2, 0); }
  
  public void a(String paramString1, String paramString2, int paramInt) { a(null, null, paramString1, paramString2, paramInt); }
  
  public void a(String paramString1, String paramString2, String paramString3, String paramString4) { a(paramString1, paramString2, paramString3, paramString4, 0); }
  
  public void a(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt) {
    a8 a81 = new a8(paramString1, paramString2, paramString3, paramString4, paramInt);
    String str = a81.c();
    a8 a82 = (a8)this.b.get(str);
    if (a82 == null) {
      this.b.put(str, a81);
      this.a.addElement(a81);
      this.c++;
    } else {
      a82.b(paramString4);
      a82.a(paramInt);
    } 
  }
  
  public void a(a8 parama8) {
    String str = parama8.c();
    a8 a81 = (a8)this.b.get(str);
    if (a81 == null) {
      this.b.put(str, parama8);
      this.a.addElement(parama8);
      this.c++;
    } else {
      a81.b(parama8.j());
      a81.a(parama8.f());
    } 
  }
  
  public int a() { return this.c; }
  
  public String a(String paramString) {
    String str = null;
    a8 a8 = (a8)this.b.get(paramString);
    if (a8 != null)
      str = a8.j(); 
    return str;
  }
  
  public a8 b(String paramString) { return (a8)this.b.get(paramString); }
  
  public a8 a(int paramInt) {
    a8 a8 = null;
    if (paramInt >= 0 && paramInt < a())
      a8 = (a8)this.a.elementAt(paramInt); 
    return a8;
  }
  
  public void c(String paramString) {
    a8 a8 = (a8)this.b.get(paramString);
    if (a8 != null) {
      this.b.remove(paramString);
      for (byte b1 = 0; b1 < this.a.size(); b1++) {
        if (a8 == (a8)this.a.get(b1)) {
          this.a.remove(b1);
          break;
        } 
      } 
      this.c--;
    } 
  }
  
  public Object clone() {
    at at1 = new at();
    for (byte b1 = 0; b1 < a(); b1++)
      at1.a((a8)a(b1).clone()); 
    at1.c = this.c;
    return at1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\at.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */