package com.softwareag.entirex.xml.rt;

public final class StringMapEntries implements MapEntries {
  private String[][] a;
  
  public StringMapEntries(String[][] paramArrayOfString) { this.a = paramArrayOfString; }
  
  public int getEntryCount() { return (this.a != null) ? this.a.length : 0; }
  
  public MapEntries.com/softwareag/entirex/xml/rt/bc getEntry(int paramInt) { return (paramInt >= 0 && paramInt < getEntryCount()) ? new com/softwareag/entirex/xml/rt/cv(this, this.a[paramInt][0], this.a[paramInt][1]) : null; }
  
  class com/softwareag/entirex/xml/rt/cv implements MapEntries.com/softwareag/entirex/xml/rt/bc {
    private String a;
    
    private String b;
    
    private final StringMapEntries c;
    
    public com/softwareag/entirex/xml/rt/cv(StringMapEntries this$0, String param1String1, String param1String2) {
      this.c = this$0;
      this.a = param1String1;
      this.b = param1String2;
    }
    
    public String a() { return this.a; }
    
    public String b() { return this.b; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\StringMapEntries.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */