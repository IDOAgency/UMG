package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;
import javax.servlet.http.HttpServletRequest;

final class bh extends bi {
  private static com/softwareag/entirex/xml/rt/bp a = null;
  
  public bh(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
    synchronized (getClass()) {
      if (a == null)
        a = new com/softwareag/entirex/xml/rt/bp(this); 
    } 
  }
  
  protected XMLRPCService a(HttpServletRequest paramHttpServletRequest) {
    synchronized (this) {
      String str = XMLServlet.a(paramHttpServletRequest, "exx-xml-sessionID");
      if (XMLServlet.ap)
        Trace.checkpoint(Trace.CP3, 6, 14, 22, "Getting session from session pool:", str); 
      XMLRPCService xMLRPCService = null;
      if (str != null) {
        xMLRPCService = (XMLRPCService)a(str);
        if (xMLRPCService != null)
          return xMLRPCService; 
      } 
      synchronized (a) {
        str = a.a();
      } 
      xMLRPCService = b(str);
      xMLRPCService.setLibraryName("");
      return xMLRPCService;
    } 
  }
  
  private final class com/softwareag/entirex/xml/rt/bp {
    private byte[] a;
    
    private byte[] b;
    
    private int c;
    
    private final String d = "0123456789ABCDEF";
    
    private final bh e;
    
    com/softwareag/entirex/xml/rt/bp(bh this$0) {
      this.e = this$0;
      this.d = "0123456789ABCDEF";
      this.a = b();
      int i = (int)(System.currentTimeMillis() & 0xFFFFFFFFFFFFFFFFL);
      this.b = new byte[8];
      a(a(this.a), this.b, i);
      a(this.a, this.b, 0);
      this.c = 0;
    }
    
    final String a() {
      a(this.a, this.b, ++this.c);
      StringBuffer stringBuffer = new StringBuffer("XML");
      for (byte b1 = 0; b1 < this.b.length; b1++) {
        stringBuffer.append("0123456789ABCDEF".charAt(this.b[b1] >> 4 & 0xF));
        stringBuffer.append("0123456789ABCDEF".charAt(this.b[b1] & 0xF));
      } 
      return stringBuffer.toString().toUpperCase();
    }
    
    private final byte[] b() {
      byte[] arrayOfByte = new byte[8];
      byte b2 = 0;
      byte b1;
      for (b1 = 0; b1 < arrayOfByte.length; b1++) {
        byte b3 = 16 << (b1 + 2) % 4 | 8 >> (b1 + true) % 4;
        arrayOfByte[b1] = (byte)b3;
        b2 += true;
      } 
      b1 = 0;
      short s = 128;
      while (b2 < 32) {
        s >>= '\003';
        b1 += 3;
        if (s == 0)
          s = 128; 
        byte b3 = b1 / 8;
        if ((arrayOfByte[b3 % 8] & s) == 0) {
          arrayOfByte[b3 % 8] = (byte)(arrayOfByte[b3 % 8] | s);
          b2++;
        } 
      } 
      return arrayOfByte;
    }
    
    private final byte[] a(byte[] param1ArrayOfByte) {
      byte[] arrayOfByte = new byte[param1ArrayOfByte.length];
      for (byte b1 = 0; b1 < param1ArrayOfByte.length; b1++)
        arrayOfByte[b1] = (byte)(param1ArrayOfByte[b1] ^ 0xFFFFFFFF); 
      return arrayOfByte;
    }
    
    private final void a(byte[] param1ArrayOfByte1, byte[] param1ArrayOfByte2, int param1Int) {
      boolean bool = false;
      for (byte b1 = 0; b1 < param1ArrayOfByte1.length; b1++) {
        short s = 128;
        for (byte b2 = 0; b2 < 8; b2++) {
          if ((param1ArrayOfByte1[b1] & s) != 0) {
            if ((param1Int & true) != 0) {
              param1ArrayOfByte2[b1] = (byte)(param1ArrayOfByte2[b1] | s);
            } else {
              param1ArrayOfByte2[b1] = (byte)(param1ArrayOfByte2[b1] & (s ^ 0xFFFFFFFF));
            } 
            param1Int >>= 1;
          } 
          s >>= 1;
        } 
      } 
    }
    
    private final int a(byte[] param1ArrayOfByte1, byte[] param1ArrayOfByte2) {
      boolean bool = false;
      int i = 0;
      for (byte b1 = 0; b1 < param1ArrayOfByte1.length; b1++) {
        short s = 128;
        for (byte b2 = 0; b2 < 8; b2++) {
          if ((param1ArrayOfByte1[b1] & s) != 0) {
            i >>= true;
            i &= Integer.MAX_VALUE;
            if ((param1ArrayOfByte2[b1] & s) != 0)
              i |= Integer.MIN_VALUE; 
          } 
          s >>= 1;
        } 
      } 
      return i;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\bh.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */