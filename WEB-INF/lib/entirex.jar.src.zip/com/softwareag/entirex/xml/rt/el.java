package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.base.EntireXFileLoader;
import com.softwareag.entirex.trace.Trace;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.util.Properties;
import javax.xml.parsers.SAXParser;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class el {
  private boolean a = false;
  
  public el() {}
  
  public el(boolean paramBoolean) { this.a = paramBoolean; }
  
  public void a(String paramString, ar paramar, Properties paramProperties) throws XMLException {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M2, 5, 25, 93); 
    SAXParser sAXParser = null;
    BufferedInputStream bufferedInputStream = null;
    InputStreamReader inputStreamReader = null;
    InputSource inputSource = null;
    try {
      SAXParserLoader sAXParserLoader;
      sAXParser = (sAXParserLoader = new SAXParserLoader()).getSAXParser();
    } catch (XMLException xMLException) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 25, 93, "Enviroment error: ParserFactory or Parser not found."); 
      throw new XMLException(21, xMLException.toString());
    } 
    try {
      EntireXFileLoader entireXFileLoader = new EntireXFileLoader(paramString);
      bufferedInputStream = new BufferedInputStream(entireXFileLoader.getFileAsInputStream());
      cy cy = new cy();
      cy.a(bufferedInputStream);
      String str = cy.c();
      inputStreamReader = new InputStreamReader(bufferedInputStream, str);
    } catch (IOException iOException) {
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 25, 93, iOException.toString()); 
      throw new XMLException(iOException);
    } 
    inputSource = new InputSource(new LineNumberReader(inputStreamReader));
    em em = new em(this.a);
    try {
      sAXParser.parse(inputSource, em);
      em.a(paramar, paramProperties);
    } catch (XMLException xMLException) {
      if (XMLRPCService.a) {
        Trace.checkpoint(Trace.CP1, 5, 25, 93, xMLException.toString());
        throw xMLException;
      } 
    } catch (SAXException sAXException) {
      int i = ((LineNumberReader)inputSource.getCharacterStream()).getLineNumber();
      if (XMLRPCService.a) {
        Trace.checkpoint(Trace.CP1, 5, 25, 93, "SAXException in line", i);
        Trace.checkpoint(Trace.CP1, 5, 25, 93, "SAXException text", sAXException);
      } 
      if (sAXException.getException() != null)
        throw new XMLException(7, sAXException.toString() + " ( in line " + i + ")"); 
      throw new XMLException(3, sAXException.toString());
    } catch (IOException iOException) {
      Trace.checkpoint(Trace.CP1, 5, 25, 93, "SAXException text", iOException.toString());
      throw new XMLException(iOException);
    } catch (IllegalArgumentException illegalArgumentException) {
      Trace.checkpoint(Trace.CP1, 5, 25, 93, illegalArgumentException.toString());
      throw new XMLException(5, illegalArgumentException.toString());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\el.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */