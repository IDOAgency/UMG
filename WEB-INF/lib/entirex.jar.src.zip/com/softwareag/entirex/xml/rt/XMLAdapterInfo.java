package com.softwareag.entirex.xml.rt;

public class XMLAdapterInfo {
  private String a = null;
  
  private String b = null;
  
  private boolean c = true;
  
  public XMLAdapterInfo() {
    this.a = null;
    this.c = true;
    this.b = null;
  }
  
  public void setBrokerID(String paramString) { this.a = paramString; }
  
  public void setServerAddress(String paramString) { this.b = paramString; }
  
  public void setCompression(boolean paramBoolean) { this.c = paramBoolean; }
  
  public boolean getCompression() { return this.c; }
  
  public String getBrokerID() { return this.a; }
  
  public String getServerAddress() { return this.b; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\XMLAdapterInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */