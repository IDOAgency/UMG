package com.softwareag.entirex.xml.rt;

import java.util.HashMap;
import java.util.Vector;

public class au {
  private HashMap a = new HashMap();
  
  private Vector b = new Vector();
  
  public void a(String paramString1, String paramString2) {
    if (paramString2 == null)
      paramString2 = ""; 
    if (paramString1 == null)
      paramString1 = ""; 
    Vector vector = (Vector)this.a.get(paramString1);
    if (vector != null) {
      if (!((String)vector.lastElement()).equals(paramString2)) {
        vector.addElement(paramString2);
        this.a.put(paramString1, vector);
        b(paramString1, paramString2);
      } 
    } else {
      vector = new Vector();
      vector.addElement(paramString2);
      this.a.put(paramString1, vector);
      b(paramString1, paramString2);
    } 
  }
  
  public void a(aw paramaw) { a(paramaw.a(), paramaw.b()); }
  
  public void a(au paramau) {
    Vector vector = paramau.b();
    int i = vector.size();
    for (byte b1 = 0; b1 < i; b1++)
      a((aw)vector.get(b1)); 
  }
  
  private void b(String paramString1, String paramString2) { this.b.add(new aw(paramString1, paramString2)); }
  
  public aw a(String paramString) {
    aw aw = null;
    Object object = null;
    if (paramString == null)
      paramString = ""; 
    Vector vector = (Vector)this.a.get(paramString);
    if (vector != null)
      aw = new aw(paramString, (String)vector.lastElement()); 
    return aw;
  }
  
  public Vector a() { return this.b; }
  
  public Vector b() {
    Vector vector = new Vector();
    Object[] arrayOfObject = this.a.keySet().toArray();
    for (byte b1 = 0; b1 < arrayOfObject.length; b1++)
      vector.add(new aw((String)arrayOfObject[b1], (String)((Vector)this.a.get(arrayOfObject[b1])).lastElement())); 
    return vector;
  }
  
  public String b(String paramString) {
    String str = null;
    if (paramString == null)
      paramString = ""; 
    Vector vector = (Vector)this.a.get(paramString);
    if (vector != null)
      str = (String)vector.lastElement(); 
    return str;
  }
  
  public int c() { return this.a.size(); }
  
  public void d() {
    this.a.clear();
    this.b.clear();
  }
  
  public void e() { this.b.clear(); }
  
  protected Object clone() {
    au au1 = new au();
    au1.b = (Vector)this.b.clone();
    au1.a = (HashMap)this.a.clone();
    return au1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\au.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */