package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.Marshal;
import com.softwareag.entirex.aci.ao;
import java.util.Vector;

public abstract class dk extends dl {
  private ao a = null;
  
  protected int b = -1;
  
  protected byte[] c = null;
  
  protected long d = 0L;
  
  protected int e = 0;
  
  protected Marshal f = null;
  
  private int g = 0;
  
  private int[] h = new int[3];
  
  private boolean i = false;
  
  public dk(ar paramar, bo parambo) { super(paramar, parambo); }
  
  public dk(ar paramar, bo parambo, ao paramao) {
    super(paramar, parambo);
    this.a = paramao;
    this.d = paramao.z();
  }
  
  protected void a(int paramInt) {}
  
  protected void b(int paramInt) {
    try {
      this.f = new Marshal(paramInt, super.b.h());
      this.f.setBuffer(b(), 0);
    } catch (BrokerException brokerException) {}
  }
  
  protected void c(int paramInt) {
    try {
      this.f = new Marshal(paramInt, super.b.h());
      super.d = new byte[0];
      this.f.setBuffer(super.d, 0);
    } catch (BrokerException brokerException) {}
  }
  
  protected void a(int paramInt, byte[] paramArrayOfByte) {
    try {
      this.f = new Marshal(paramInt, super.b.h());
      super.d = paramArrayOfByte;
      this.f.setBuffer(super.d, 0);
    } catch (BrokerException brokerException) {}
  }
  
  public byte[] a() {
    byte[] arrayOfByte = null;
    if (this.a != null) {
      arrayOfByte = this.a.b();
    } else {
      arrayOfByte = this.c;
    } 
    if (arrayOfByte == null)
      arrayOfByte = new byte[0]; 
    return arrayOfByte;
  }
  
  public void a(byte[] paramArrayOfByte) { this.c = paramArrayOfByte; }
  
  public byte[] b() {
    byte[] arrayOfByte = null;
    if (this.a != null) {
      arrayOfByte = this.a.c();
    } else {
      arrayOfByte = super.d;
    } 
    if (arrayOfByte == null)
      arrayOfByte = new byte[0]; 
    return arrayOfByte;
  }
  
  public void a(byte[] paramArrayOfByte, int paramInt) {
    super.d = paramArrayOfByte;
    a(paramInt, paramArrayOfByte);
  }
  
  public long c() { return this.d; }
  
  public int d() { return this.e; }
  
  public void d(int paramInt) { this.e = paramInt; }
  
  protected void a(RPCType paramRPCType) {
    this.g = 0;
    this.h = new int[3];
    this.i = false;
    this.h[0] = paramRPCType.getSize();
    this.g++;
    paramRPCType = (RPCType)paramRPCType.getChild(0);
    if (paramRPCType.getRpcTypeId() == 30) {
      this.h[1] = paramRPCType.getSize();
      this.g++;
      paramRPCType = (RPCType)paramRPCType.getChild(0);
      if (paramRPCType.getRpcTypeId() == 30) {
        this.h[2] = paramRPCType.getSize();
        this.g++;
        paramRPCType = (RPCType)paramRPCType.getChild(0);
      } 
    } 
    if (paramRPCType.getRpcTypeId() == 31 || paramRPCType.getRpcTypeId() == 32)
      this.i = true; 
  }
  
  protected int e() { return this.g; }
  
  protected int[] f() { return this.h; }
  
  protected boolean g() { return this.i; }
  
  protected void a(cp paramcp) throws XMLException {
    String str1 = super.b.y();
    String str2 = super.b.d();
    RPCType rPCType = super.a.g();
    rPCType = (RPCType)rPCType.getChild(str1);
    if (rPCType == null)
      new XMLException(82, "Library is not defined."); 
    paramcp = (cp)paramcp.c(str1);
    if (paramcp == null)
      paramcp = rPCType.createValueNode(); 
    rPCType = (RPCType)rPCType.getChild(str2);
    if (rPCType == null)
      new XMLException(82, "Program is not defined."); 
    paramcp = (cp)paramcp.c(str2);
    if (paramcp == null)
      paramcp = rPCType.createValueNode(); 
    c(rPCType, paramcp);
  }
  
  private void c(RPCType paramRPCType, cp paramcp) throws XMLException {
    byte b1 = 0;
    int j = 0;
    cp cp1 = null;
    int k = paramRPCType.getChildCount();
    boolean bool = (super.b.t() != 0) ? 1 : 0;
    for (b1 = 0; b1 < k; b1++) {
      RPCType rPCType = (RPCType)paramRPCType.getChild(b1);
      if ((super.c == a3.a && rPCType.getDirection() != 1) || (super.c == a3.b && rPCType.getDirection() != 2) || !bool)
        if (paramRPCType.getRpcTypeId() == 30) {
          cp1 = (cp)paramcp.a(b1);
          int m = paramRPCType.getSize();
          int n = paramcp.d(rPCType.getName());
          if (!paramRPCType.isVariableSized()) {
            for (j = n; j < m; j++)
              paramcp.b(rPCType.createValueNode()); 
            n = paramcp.d(rPCType.getName());
          } 
          Vector vector = paramcp.e(rPCType.getName());
          for (j = 0; j < n; j++) {
            cp1 = (cp)vector.get(j);
            c(rPCType, cp1);
          } 
        } else {
          if (paramcp.d(rPCType.getName()) == 0) {
            cp1 = rPCType.createValueNode();
            paramcp.b(cp1);
          } 
          if (rPCType.isContainer()) {
            cp1 = (cp)paramcp.c(rPCType.getName());
            c(rPCType, cp1);
          } 
        }  
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\dk.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */