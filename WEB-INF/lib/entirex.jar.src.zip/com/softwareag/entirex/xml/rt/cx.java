package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.aci.Dump;
import com.softwareag.entirex.aci.EntireXVersion;
import com.softwareag.entirex.aci.h;
import com.softwareag.entirex.base.Command;
import com.softwareag.entirex.trace.Trace;
import java.util.Properties;

public class cx extends h {
  static final String a = "entirex.sdk.xml.runtime.properties";
  
  static final String b = "entirex.sdk.xml.runtime.xml";
  
  static final String c = (new EntireXVersion("Java Server")).getVersionString();
  
  private ar d = null;
  
  protected void init() {
    super.init();
    add(new Command("-broker", "-b", "entirex.sdk.xml.runtime.brokerid", 1, 0, "localhost:1971", "the ID of the broker,"));
    add(new Command("-server", "-s", "entirex.sdk.xml.runtime.serveraddress", 1, 2, "RPC/XMLSRV1/CALLNAT", "the server address as 'RPC/<server address>/CALLNAT' or <server address> with class and service,"));
    add(new Command("-class", null, null, 1, 1, null, "the class as in '<class>/<server>/<service>',"));
    add(new Command("-service", null, null, 1, 3, null, "the service as in '<class>/<server>/<service>',"));
    add(new Command("-logicalsetname", null, "entirex.sdk.xml.runtime.logicalsetname", 1, -1, null, "the set name for logical names,"));
    add(new Command("-logicalbrokerid", null, "entirex.sdk.xml.runtime.logicalbrokerid", 1, -1, null, "the logical name for the broker,"));
    add(new Command("-logicalservice", null, "entirex.sdk.xml.runtime.logicalservice", 1, -1, null, "the logical name for the service,"));
    add(new Command("-user", null, "entirex.sdk.xml.runtime.userid", 1, -1, null, "the user ID for the broker,"));
    add(new Command("-password", null, "entirex.sdk.xml.runtime.password", 1, -1, null, "the password for the broker,"));
    add(new Command("-rpcuser", null, "entirex.sdk.xml.runtime.rpcuserid", 1, -1, null, "the rpc user ID for the broker,"));
    add(new Command("-rpcpassword", null, "entirex.sdk.xml.runtime.rpcpassword", 1, -1, null, "the rpc password for the broker,"));
    add(new Command("-compresslevel", null, "entirex.sdk.xml.runtime.compresslevel", 1, -1, "0", "the compression level, values 0 .. 9,"));
    add(new Command("-security", null, "entirex.sdk.xml.runtime.security", 1, -1, null, "the security setting, values no, yes, auto, <name of BrokerSecurity object>,"));
    add(new Command("-encryption", null, "entirex.sdk.xml.runtime.encryptionlevel", 2, -1, null, "the encryption level, values 0,1,2,"));
    add(new Command("-serverlog", null, "entirex.sdk.xml.runtime.serverlog", 1, -1, null, "the file name of the startup / shutdown log (only for Windows Services),"));
    add(new Command("-restartcycles", null, "entirex.sdk.xml.runtime.restartcycles", 2, -1, null, "the number of restart attempts if the broker is not available,"));
    add(new Command("-smhport", null, "entirex.sdk.xml.runtime.monitorport", 2, -1, null, "the port number for monitoring by SMH,"));
    add(new Command("-trace", null, "entirex.trace", 2, -1, null, "the trace level, values 0,1,2."));
    add(new Command("-verbose", null, "entirex.sdk.xml.runtime.verbose", 3, -1, null, "if set, more information in trace,"));
    add(new Command("-codepage", null, "entirex.sdk.xml.runtime.codepage", 1, -1, null, "the code page the server uses for the messages"));
    add(new Command("-propertyfile", "-p", "entirex.server.properties", 1, -1, "entirex.xml.runtime.properties", "the file name of the property file (default is 'entirex.xml.runtime.properties'),"));
    add(new Command("-configurationfile", "-c", "entirex.sdk.xml.runtime.configurationfile", 1, -1, "entirex.xml.runtime.configuration.xml", "the file name of the configuration file (default is 'entirex.xml.runtime.configuration.xml'),"));
    add(new Command("-jaxp.documentbuilder", null, "entirex.sdk.xml.runtime.documentbuilder", 1, -1, "org.apache.xerces.jaxp.DocumentBuilderImpl", "the documentbuilder class,"));
    add(new Command("-jaxp.documentbuilderfactory", null, "entirex.sdk.xml.runtime.documentbuilderfactory", 1, -1, "org.apache.xerces.jaxp.DocumentBuilderFactoryImpl", "the documentbuildfactory class,"));
    add(new Command("-jaxp.xmlparser", null, "entirex.sdk.xml.runtime.xmlparser", 1, -1, "org.apache.xerces.jaxp.SAXParserImpl", "the saxparser class,"));
    add(new Command("-jaxp.xmlparserfactory", null, "entirex.sdk.xml.runtime.xmlparserfactory", 1, -1, "org.apache.xerces.jaxp.SAXParserFactoryImpl", "the saxparserfactroy class,"));
    add(new Command("-http.proxy", null, "entirex.sdk.xml.runtime.http.proxy", 1, -1, null, "the http proxy,"));
    add(new Command("-http.port", null, "entirex.sdk.xml.runtime.http.port", 1, -1, null, "the http port,"));
    add(new Command("-https.proxy", null, "entirex.sdk.xml.runtime.https.proxy", 1, -1, null, "the https proxy,"));
    add(new Command("-https.port", null, "entirex.sdk.xml.runtime.https.port", 1, -1, null, "the https port"));
  }
  
  public cx(ar paramar) {
    super(new Properties());
    this.d = paramar;
  }
  
  public void a() {
    super.a();
    Properties properties = c();
    properties.put("entirex.sdk.xml.runtime.serveraddress", "RPC/XMLSRV1/CALLNAT");
    properties.put("entirex.sdk.xml.runtime.name", (new EntireXVersion("XML RPC Server")).getVersionString());
    importSystemProperties();
  }
  
  public void b(Properties paramProperties) {
    if (XMLRPCService.a)
      Trace.enterMethod(Trace.M1, 5, 29, 92); 
    String str = getProperties().getProperty("entirex.sdk.xml.runtime.configurationfile");
    if (XMLRPCService.a)
      Trace.checkpoint(Trace.CP1, 5, 29, 92, "configuration filename:", str); 
    try {
      el el = new el();
      el.a(str, this.d, paramProperties);
      this.d.a(a3.a);
    } catch (XMLException xMLException) {
      Dump.log("Reading configuration file (" + str + "). Failed");
      Dump.log(xMLException.toString());
      if (XMLRPCService.a)
        Trace.checkpoint(Trace.CP1, 5, 29, 92, "Loading configuration file:" + xMLException.toString()); 
      System.err.println("Reading configuration file (" + str + "). Failed");
      System.err.println(xMLException.toString());
      System.exit(1);
    } 
    if (XMLRPCService.a)
      Trace.leaveMethod(Trace.M1, 5, 29, 92, "reading configuration file:", str); 
    Dump.log("Reading configuration file. Done.");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\cx.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */