package com.softwareag.entirex.xml.rt;

import java.util.Hashtable;
import java.util.Vector;

public class cq {
  protected Vector a = new Vector();
  
  protected BaseNode b = null;
  
  protected Hashtable c = new Hashtable();
  
  protected cq d;
  
  private cq e = null;
  
  private cq f = null;
  
  public void a(cq paramcq) { this.d = paramcq; }
  
  public cq e() { return this.d; }
  
  protected void f() {
    this.a.removeAllElements();
    this.c.clear();
  }
  
  protected String a() { return this.b.getName(); }
  
  public cq b(cq paramcq) {
    paramcq.a(this);
    this.a.addElement(paramcq);
    String str = paramcq.b.getName();
    Vector vector = (Vector)this.c.get(str);
    if (vector == null) {
      vector = new Vector();
      this.c.put(str, vector);
    } 
    vector.addElement(paramcq);
    return paramcq;
  }
  
  public cq a(cq paramcq, int paramInt) {
    paramcq.a(this);
    int i = this.a.size();
    if (i <= paramInt) {
      this.a.addElement(paramcq);
    } else {
      int j = 0;
      String str1 = null;
      for (byte b1 = 0; b1 < paramInt; b1++) {
        str1 = ((cq)this.a.get(b1)).a();
        j += d(str1);
      } 
      str1 = ((cq)this.a.get(paramInt)).a();
      if (str1.equals(paramcq.a())) {
        j += d(str1);
        j++;
      } 
      this.a.insertElementAt(paramcq, j);
    } 
    String str = paramcq.a();
    Vector vector = (Vector)this.c.get(str);
    if (vector == null) {
      vector = new Vector();
      this.c.put(str, vector);
    } 
    vector.addElement(paramcq);
    return paramcq;
  }
  
  public cq c(String paramString) {
    cq cq1 = null;
    Vector vector = (Vector)this.c.get(paramString);
    if (vector != null)
      cq1 = (cq)vector.elementAt(0); 
    return cq1;
  }
  
  public int g() { return this.a.size(); }
  
  public cq a(int paramInt) {
    cq cq1 = null;
    if (this.a.size() > paramInt)
      cq1 = (cq)this.a.elementAt(paramInt); 
    return cq1;
  }
  
  public int d(String paramString) {
    null = 0;
    Vector vector = (Vector)this.c.get(paramString);
    return (vector != null) ? vector.size() : 0;
  }
  
  public cq a(String paramString, int paramInt) {
    cq cq1 = null;
    Vector vector = (Vector)this.c.get(paramString);
    if (vector != null && paramInt < vector.size())
      cq1 = (cq)vector.elementAt(paramInt); 
    return cq1;
  }
  
  public Vector h() { return this.a; }
  
  public Vector e(String paramString) {
    Vector vector = (Vector)this.c.get(paramString);
    if (vector == null)
      vector = new Vector(0); 
    return vector;
  }
  
  protected void c(cq paramcq) { this.e = paramcq; }
  
  protected cq i() { return this.e; }
  
  protected void d(cq paramcq) { this.f = paramcq; }
  
  protected cq j() { return this.f; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\cq.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */