package com.softwareag.entirex.xml.rt;

import com.softwareag.entirex.trace.Trace;
import java.util.ArrayList;
import java.util.HashSet;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

public class c1 {
  private static final String a = "javax.xml.parsers.DocumentBuilderFactory";
  
  private static final String b = "javax.xml.parsers.DocumentBuilder";
  
  private static DocumentBuilderFactory c = null;
  
  private static int d = 0;
  
  private static int e = 10;
  
  private static ArrayList f = new ArrayList(e);
  
  private static HashSet g = new HashSet();
  
  public static DocumentBuilder a() throws XMLException {
    DocumentBuilder documentBuilder = null;
    if (c == null)
      try {
        c = DocumentBuilderFactory.newInstance();
        c.setIgnoringComments(true);
        c.setNamespaceAware(true);
        c.setValidating(false);
        c.setExpandEntityReferences(false);
      } catch (FactoryConfigurationError factoryConfigurationError) {
        if (XMLRPCService.a) {
          c();
          Trace.checkpoint(Trace.CP1, 5, 46, 112, factoryConfigurationError.toString());
        } 
        throw new XMLException(73);
      }  
    try {
      documentBuilder = (DocumentBuilder)b();
    } catch (ParserConfigurationException parserConfigurationException) {
      if (XMLRPCService.a) {
        c();
        Trace.checkpoint(Trace.CP1, 5, 46, 112, parserConfigurationException.toString());
      } 
      throw new XMLException(74, parserConfigurationException.toString());
    } 
    return documentBuilder;
  }
  
  public static void a(DocumentBuilder paramDocumentBuilder) { a(paramDocumentBuilder); }
  
  private static void c() {
    Trace.checkpoint(Trace.CP1, 5, 45, 111, "javax.xml.parsers.DocumentBuilderFactory", System.getProperty("javax.xml.parsers.DocumentBuilderFactory"));
    Trace.checkpoint(Trace.CP1, 5, 45, 111, "javax.xml.parsers.DocumentBuilder", System.getProperty("javax.xml.parsers.DocumentBuilder"));
  }
  
  protected static Object b() throws ParserConfigurationException {
    Object object = null;
    synchronized (f) {
      if (d > 0) {
        object = f.get(d - 1);
        g.add(object);
        f.remove(d - 1);
        d--;
      } else {
        object = c.newDocumentBuilder();
      } 
    } 
    return object;
  }
  
  protected static void a(Object paramObject) {
    synchronized (f) {
      g.remove(paramObject);
      if (d < e) {
        f.add(d, paramObject);
        d++;
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\xml\rt\c1.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */