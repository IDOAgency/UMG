package com.softwareag.entirex.ba;

import com.softwareag.entirex.aci.Broker;
import com.softwareag.entirex.aci.BrokerException;
import com.softwareag.entirex.aci.LocationTransparencyService;
import com.softwareag.entirex.aci.p;

public final class BrokerAgent {
  private boolean a = false;
  
  private String b = null;
  
  private String c = null;
  
  private String d;
  
  private String e;
  
  private String f = null;
  
  private static final String g = System.getProperty("line.separator");
  
  static final String h = "where trace:      tracing ON or OFF" + g + "where port:       port number of the BrokerAgent" + g;
  
  static final String i = "where brokerid:   host:port" + g + "      or          any other legal broker address as in EntireX Java" + g + "      or          ETBnnnn/2 (when using Entire Broker 2.1)" + g + "      or          ETBnnnn::NET/2 (when using Entire Broker 2.1)" + g;
  
  static final String j = "for logical broker ids replace 'brokerid' by '[-logicalsetname [<set name>]] -logicalbrokerid <logical broker>'" + g + "where <set name>: the name of the set of rules for Location Transparency" + g + "                  for an empty <set name> the value 'DefaultSet' is used." + g + "<logical broker>: the name of the logical broker in the directory." + g;
  
  static final String k = "where commandport (optional) is the port, where the BrokerAgent receives commands." + g;
  
  private static final String l = g + "usage: 'java com.softwareag.entirex.ba.BrokerAgent trace port brokerid [commandport]'" + g + h + i + j + k + g;
  
  public static void main(String[] paramArrayOfString) {
    BrokerAgent brokerAgent = new BrokerAgent();
    if (brokerAgent.a(paramArrayOfString))
      if (brokerAgent.e != null && brokerAgent.e.length() > 0) {
        try {
          Broker broker = LocationTransparencyService.lookupBroker(brokerAgent.e, brokerAgent.d);
          p.a(brokerAgent.a, brokerAgent.b, broker.getBrokerID(), brokerAgent.f);
        } catch (BrokerException brokerException) {
          brokerException.printStackTrace();
        } 
      } else {
        p.a(brokerAgent.a, brokerAgent.b, brokerAgent.c, brokerAgent.f);
      }  
  }
  
  private boolean a(String[] paramArrayOfString) {
    byte b1 = 0;
    boolean bool1 = false;
    boolean bool2 = false;
    String[] arrayOfString = new String[paramArrayOfString.length];
    byte b2 = 0;
    if (paramArrayOfString.length > 0) {
      for (byte b3 = 0; b3 < paramArrayOfString.length; b3++) {
        if (paramArrayOfString[b3].equalsIgnoreCase("-logicalsetname")) {
          if (b3 < paramArrayOfString.length - 1 && !paramArrayOfString[b3 + true].startsWith("-"))
            this.d = paramArrayOfString[++b3]; 
        } else if (paramArrayOfString[b3].equalsIgnoreCase("-logicalbrokerid")) {
          if (b3 < paramArrayOfString.length - 1 && !paramArrayOfString[b3 + 1].startsWith("-")) {
            this.e = paramArrayOfString[++b3];
            bool2 = true;
          } else {
            bool1 = true;
            arrayOfString[b2++] = "-logicalbrokerid: value missing";
          } 
        } else if (paramArrayOfString[b3].startsWith("-")) {
          bool1 = true;
          arrayOfString[b2] = paramArrayOfString[b3];
          b2++;
        } else if (!b1) {
          this.a = paramArrayOfString[b3].equalsIgnoreCase("ON");
          b1++;
        } else if (b1 == 1) {
          this.b = paramArrayOfString[b3];
          b1++;
        } else if (b1 == 2) {
          if (bool2) {
            this.f = paramArrayOfString[b3];
          } else {
            this.c = paramArrayOfString[b3];
          } 
          b1++;
        } else if (b1 == 3) {
          if (!bool2)
            this.f = paramArrayOfString[b3]; 
          b1++;
        } else {
          bool1 = true;
          arrayOfString[b2] = paramArrayOfString[b3];
          b2++;
        } 
      } 
      if (this.b == null) {
        bool1 = true;
        arrayOfString[b2++] = "port missing";
      } 
      if (this.c == null && this.e == null) {
        bool1 = true;
        arrayOfString[b2++] = "broker ID or logical broker ID must be present";
      } 
    } else {
      bool1 = true;
    } 
    if (bool1) {
      if (b2 > 0)
        for (byte b3 = 0; b3 < b2; b3++)
          System.out.println("Invalid Parameter found: '" + arrayOfString[b3] + "'");  
      a();
    } 
    return !bool1;
  }
  
  private static void a() { System.out.println(l); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\ba\BrokerAgent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */