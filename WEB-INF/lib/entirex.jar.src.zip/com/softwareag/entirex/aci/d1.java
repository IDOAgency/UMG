package com.softwareag.entirex.aci;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.Principal;
import java.util.Properties;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.security.cert.X509Certificate;

abstract class d1 extends y implements d2 {
  private static final String a = "trust_store";
  
  private static final String b = "trust_passwd";
  
  private static final String c = "key_store";
  
  private static final String d = "key_store_passwd";
  
  private static final String e = "key_passwd";
  
  private static final String f = "verify_client";
  
  private static final String g = "verify_server";
  
  private KeyStore h = null;
  
  private KeyStore i = null;
  
  private char[] j = null;
  
  private boolean k;
  
  private boolean l;
  
  private final String m;
  
  private final int n;
  
  private SSLSocketFactory o;
  
  private SSLServerSocketFactory p;
  
  private void a(Properties paramProperties) throws GeneralSecurityException, IOException {
    String str2 = KeyStore.getDefaultType();
    char[] arrayOfChar1 = null;
    char[] arrayOfChar2 = null;
    String str1 = paramProperties.getProperty("key_passwd");
    if (str1 != null)
      this.j = str1.toCharArray(); 
    str1 = paramProperties.getProperty("key_store_passwd");
    if (str1 != null)
      arrayOfChar1 = str1.toCharArray(); 
    str1 = paramProperties.getProperty("trust_passwd");
    if (str1 != null)
      arrayOfChar2 = str1.toCharArray(); 
    String str3 = paramProperties.getProperty("key_store");
    String str4 = paramProperties.getProperty("trust_store");
    if (str3 != null) {
      if (Dump.c)
        Dump.log("Loading Keystore " + str3 + " of type " + str2); 
      this.h = KeyStore.getInstance(str2);
      this.h.load(new FileInputStream(str3), arrayOfChar1);
    } 
    if (str4 != null) {
      if (Dump.c)
        Dump.log("Loading Truststore " + str4 + " of type " + str2); 
      this.i = KeyStore.getInstance(str2);
      this.i.load(new FileInputStream(str4), arrayOfChar2);
    } 
    str1 = paramProperties.getProperty("verify_server");
    this.k = !Dump.c(str1);
    str1 = paramProperties.getProperty("verify_client");
    this.l = Dump.b(str1);
  }
  
  public d1(String paramString, int paramInt, Properties paramProperties) throws GeneralSecurityException, IOException {
    super(paramString, paramInt, paramProperties);
    this.m = paramString;
    this.n = paramInt;
    a(paramProperties);
  }
  
  public Socket b() throws IOException {
    try {
      if (this.o == null)
        this.o = a(this.h, this.j, this.i); 
      SSLSocket sSLSocket = (SSLSocket)this.o.createSocket(this.m, this.n);
      if (Dump.c)
        Dump.log("Starting SSL Handshake ..."); 
      sSLSocket.startHandshake();
      a(sSLSocket.getSession(), this.k);
      if (Dump.c)
        Dump.log("SSL Handshake completed"); 
      return sSLSocket;
    } catch (SSLException sSLException) {
      throw new ae("0401", new String[] { sSLException.getMessage() });
    } 
  }
  
  public ServerSocket c() throws IOException {
    try {
      if (this.p == null)
        this.p = b(this.h, this.j, this.i); 
      SSLServerSocket sSLServerSocket = (SSLServerSocket)this.p.createServerSocket(this.n);
      sSLServerSocket.setNeedClientAuth(this.l);
      if (Dump.c)
        Dump.log("Starting SSL Listening" + (this.l ? " with Client authentification" : "") + "..."); 
      return sSLServerSocket;
    } catch (SSLException sSLException) {
      throw new ae("0401", new String[] { sSLException.getMessage() });
    } 
  }
  
  private void a(SSLSession paramSSLSession, boolean paramBoolean) throws ae, SSLPeerUnverifiedException {
    String str = paramSSLSession.getPeerHost();
    X509Certificate x509Certificate = null;
    X509Certificate[] arrayOfX509Certificate = paramSSLSession.getPeerCertificateChain();
    if (arrayOfX509Certificate != null && arrayOfX509Certificate.length > 0)
      x509Certificate = arrayOfX509Certificate[0]; 
    if (Dump.c) {
      Dump.log("SSL Session: SessionId = " + paramSSLSession);
      Dump.log("SSL Session: CipherSuite = " + paramSSLSession.getCipherSuite());
      Dump.log("SSL Session: PeerHost = " + str);
      for (byte b1 = 0; b1 < arrayOfX509Certificate.length; b1++) {
        X509Certificate x509Certificate1 = arrayOfX509Certificate[b1];
        String str1 = "SSL PeerCertificate " + b1 + " ";
        Dump.log(str1 + "Serial Number = " + x509Certificate1.getSerialNumber());
        Principal principal = x509Certificate1.getIssuerDN();
        Dump.log(str1 + "Issuer = " + principal);
        Dump.log(str1 + "Subject = " + x509Certificate1.getSubjectDN());
        Dump.log(str1 + "Valid not before = " + x509Certificate1.getNotBefore());
        Dump.log(str1 + "Valid not after = " + x509Certificate1.getNotAfter());
        Dump.log(str1 + "Signature Algorithm = " + x509Certificate1.getSigAlgName());
      } 
    } 
    if (paramBoolean) {
      if (x509Certificate == null)
        throw new SSLPeerUnverifiedException("No server certificate"); 
      String str1 = x509Certificate.getSubjectDN().getName().toLowerCase();
      int i1 = str1.indexOf("cn=");
      if (i1 == -1)
        throw new ae("0403", new String[] { "CN not found" }); 
      int i2 = str1.indexOf(',', i1);
      if (i2 == -1)
        throw new ae("0403", new String[] { "CN incomplete" }); 
      String str2 = str1.substring(i1 + 3, i2);
      if (!str2.equalsIgnoreCase(str))
        throw new ae("0402", new String[] { str2, str }); 
    } 
  }
  
  protected abstract SSLSocketFactory a(KeyStore paramKeyStore1, char[] paramArrayOfChar, KeyStore paramKeyStore2) throws ae;
  
  protected abstract SSLServerSocketFactory b(KeyStore paramKeyStore1, char[] paramArrayOfChar, KeyStore paramKeyStore2) throws ae;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\d1.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */