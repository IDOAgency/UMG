package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.ac;
import com.softwareag.entirex.base.r;
import com.softwareag.entirex.base.s;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.net.InetAddress;
import java.util.Hashtable;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

final class q {
  private static final Hashtable a = new Hashtable();
  
  private boolean b = false;
  
  private static final byte c = -128;
  
  static final byte d = 34;
  
  static final byte e = 66;
  
  private static final byte f = 0;
  
  private static final byte g = 32;
  
  private static final byte h = 64;
  
  private static final byte i = -64;
  
  private static final byte j = -5;
  
  private static byte k = 0;
  
  private static final s l = s.a();
  
  private static final int m = 8;
  
  private int n = 0;
  
  private int o = 24;
  
  private t p;
  
  private static final int q = 28;
  
  private static final String r = "0000000000000000000000000000";
  
  private static final byte[] s = { 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0 };
  
  private String t = "0000000000000000000000000000";
  
  private byte[] u = s;
  
  private byte[] v = null;
  
  private byte[] w = null;
  
  private String x = null;
  
  private StringBuffer y = new StringBuffer();
  
  private Broker z;
  
  private static final byte[] aa = "SEND".getBytes();
  
  private static final byte[] ab = "RECEIVE".getBytes();
  
  private static final byte[] ac = "UNDO".getBytes();
  
  private static final byte[] ad = "EOC".getBytes();
  
  private static final byte[] ae = "REGISTER".getBytes();
  
  private static final byte[] af = "DEREGISTER".getBytes();
  
  private static final byte[] ag = "LOGON".getBytes();
  
  private static final byte[] ah = "LOGOFF".getBytes();
  
  private static final byte[] ai = "SYNCPOINT".getBytes();
  
  private static final byte[] aj = "KERNELVERS".getBytes();
  
  private static final byte[] ak = "SEND_PUB".getBytes();
  
  private static final byte[] al = "REC_PUB".getBytes();
  
  private static final byte[] am = "SUBSCRIBE".getBytes();
  
  private static final byte[] an = "UNSUBSCR".getBytes();
  
  private static final byte[] ao = "CNTRL_PUB".getBytes();
  
  private static final byte[] ap = "REPLYERROR".getBytes();
  
  static final byte[] aq = "ANY".getBytes();
  
  static final byte[] ar = "MSG".getBytes();
  
  static final byte[] as = "HOLD".getBytes();
  
  static final byte[] at = "IMMED".getBytes();
  
  static final byte[] au = "QUIESCE".getBytes();
  
  static final byte[] av = "CANCEL".getBytes();
  
  static final byte[] aw = "LAST".getBytes();
  
  static final byte[] ax = "NEXT".getBytes();
  
  static final byte[] ay = "PREVIEW".getBytes();
  
  static final byte[] az = "COMMIT".getBytes();
  
  static final byte[] a0 = "BACKOUT".getBytes();
  
  static final byte[] a1 = "ATTACH".getBytes();
  
  static final byte[] a2 = "SYNC".getBytes();
  
  static final byte[] a3 = "QUERY".getBytes();
  
  static final byte[] a4 = "DELETE".getBytes();
  
  static final byte[] a5 = "COMMITBOTH".getBytes();
  
  static final byte[] a6 = "EOC".getBytes();
  
  static final byte[] a7 = "EOCCANCEL".getBytes();
  
  static final byte[] a8 = "SETUSTATUS".getBytes();
  
  static final byte[] a9 = "DURABLE".getBytes();
  
  static final byte[] ba = "TERMINATE".getBytes();
  
  static final byte[] bb = "CHKSVC".getBytes();
  
  static final byte[] bc = "ACK".getBytes();
  
  private byte[] bd;
  
  private byte[] be;
  
  private int bf;
  
  private byte[] bg;
  
  private boolean bh = false;
  
  private int bi;
  
  private byte[] bj;
  
  private byte[] bk;
  
  private byte[] bl;
  
  private byte[] bm;
  
  private String bn;
  
  private byte[] bo;
  
  private byte[] bp = null;
  
  private byte[] bq = null;
  
  private byte[] br;
  
  private String bs;
  
  private String bt;
  
  private byte[] bu = null;
  
  private byte[] bv = null;
  
  private String bw = null;
  
  private int bx = 0;
  
  private int by = 0;
  
  private String bz;
  
  private String b0;
  
  private int b1;
  
  private byte[] b2;
  
  private byte[] b3;
  
  private String b4;
  
  private String b5;
  
  private byte[] b6;
  
  private String b7;
  
  private String b8;
  
  private byte[] b9;
  
  private byte[] ca;
  
  private String cb;
  
  private String cc;
  
  private byte[] cd;
  
  private String ce;
  
  private String cf;
  
  private int cg;
  
  private byte[] ch;
  
  private boolean ci = false;
  
  private boolean cj = false;
  
  private int ck = 0;
  
  private int cl = -1;
  
  static final int cm = 2;
  
  static final int cn = 1;
  
  static final int co = 0;
  
  static final int cp = -1;
  
  private boolean cq = false;
  
  private boolean cr = false;
  
  private String cs = null;
  
  private int ct = 0;
  
  private int cu = 0;
  
  private int cv = 0;
  
  private boolean cw = true;
  
  private BrokerSecurity cx;
  
  private BrokerSecurity cy;
  
  private boolean cz;
  
  private boolean c0 = true;
  
  private static final Hashtable c1 = new Hashtable();
  
  private int c2 = 0;
  
  private byte[] c3 = null;
  
  private final r c4 = new r(c6);
  
  private static final String[] c5 = { 
      "TXT", "EC", "SN", "SV", "UID", "SC", "TK", "F", "OP", "CID", 
      "W", "CUID", "ENV", "RL", "SL", "RETL", "UD", "CST", "MID", "MTYP", 
      "STORE", "MSTAT", "ADCNT", "PTIME", "NPW", "AERR", "BID", "UOWTIME", "UOWST", "USTATUS", 
      "UOWID", "UWSTATP", "API", "PU", "LS", "AC", "FL", "EL", "XO", "CTIM", 
      "CP", "UCL", "TOP", "UOWSTATADD", "PUBLID" };
  
  private static final byte[][] c6 = a(c5);
  
  private static final byte c7 = 0;
  
  private static final byte c8 = 1;
  
  private static final byte c9 = 2;
  
  private static final byte da = 3;
  
  private static final byte db = 4;
  
  private static final byte dc = 5;
  
  private static final byte dd = 6;
  
  private static final byte de = 7;
  
  private static final byte df = 8;
  
  private static final byte dg = 9;
  
  private static final byte dh = 10;
  
  private static final byte di = 11;
  
  private static final byte dj = 12;
  
  private static final byte dk = 13;
  
  private static final byte dl = 14;
  
  private static final byte dm = 15;
  
  private static final byte dn = 16;
  
  private static final byte do = 17;
  
  private static final byte dp = 18;
  
  private static final byte dq = 19;
  
  private static final byte dr = 20;
  
  private static final byte ds = 21;
  
  private static final byte dt = 22;
  
  private static final byte du = 23;
  
  private static final byte dv = 24;
  
  private static final byte dw = 25;
  
  private static final byte dx = 26;
  
  private static final byte dy = 27;
  
  private static final byte dz = 28;
  
  private static final byte d0 = 29;
  
  private static final byte d1 = 30;
  
  private static final byte d2 = 31;
  
  private static final byte d3 = 32;
  
  private static final byte d4 = 33;
  
  private static final byte d5 = 34;
  
  private static final byte d6 = 35;
  
  private static final byte d7 = 36;
  
  private static final byte d8 = 37;
  
  private static final byte d9 = 38;
  
  private static final byte ea = 39;
  
  private static final byte eb = 40;
  
  private static final byte ec = 41;
  
  private static final byte ed = 42;
  
  private static final byte ee = 43;
  
  private static final byte ef = 44;
  
  private static final short eg = 1;
  
  private static final short eh = 2;
  
  private static final short ei = 3;
  
  private static final short ej = 4;
  
  private static final short ek = 5;
  
  private static final short el = 6;
  
  boolean em = false;
  
  static final int en = 24;
  
  static final int eo = 28;
  
  private static final int ep = 1024;
  
  static final int eq = 3;
  
  static final int er = 4;
  
  static final int es = 8;
  
  static final int et = 12;
  
  static final int eu = 16;
  
  static final int ev = 20;
  
  static final int ew = 24;
  
  static final int ex = 25;
  
  private static final byte ey = 0;
  
  private static final byte ez = -1;
  
  private static final byte e0 = -18;
  
  private static final int e1 = 20;
  
  private static final int e2 = 44;
  
  private byte[] e3 = new byte[68];
  
  private byte[] e4 = new byte[72];
  
  private byte[] e5;
  
  private byte[] e6 = new byte[2048];
  
  private int e7;
  
  private static final boolean e8 = false;
  
  private static void af() throws BrokerException {
    if (k != 0)
      return; 
    if (l.g == 32) {
      k = Byte.MIN_VALUE;
      if (Dump.c)
        Dump.log("Running on an ASCII machine."); 
    } else if (l.g == 64) {
      if (l.f == -64) {
        k = 34;
        if (Dump.c)
          Dump.log("Running on an EBCDIC IBM machine."); 
      } else if (l.f == -5) {
        k = 66;
        if (Dump.c)
          Dump.log("Running on an EBCDIC Siemens machine."); 
      } else {
        BrokerException.a("0300", new String[] { Byte.toString(l.f) });
      } 
    } else {
      BrokerException.a("0301", new String[] { Byte.toString(l.g) });
    } 
  }
  
  q(Broker paramBroker) {
    this.p = t.a(paramBroker.getBrokerID());
    this.z = paramBroker;
    this.bg = this.p.toString().getBytes();
    this.bn = paramBroker.getUserID();
    this.bo = this.bn.getBytes();
    String str = paramBroker.getToken();
    if (str != null)
      this.bq = str.getBytes(); 
    this.br = paramBroker.getSecurityToken();
    this.bj = Dump.d().toUpperCase().getBytes();
    this.em = Dump.e();
  }
  
  void a(byte[] paramArrayOfByte) {
    if (paramArrayOfByte != null && paramArrayOfByte.length > 0)
      this.v = paramArrayOfByte; 
  }
  
  byte[] a() {
    byte[] arrayOfByte = this.w;
    this.w = null;
    return arrayOfByte;
  }
  
  void a(boolean paramBoolean) { this.bh = paramBoolean; }
  
  int b() { return this.bi; }
  
  void a(int paramInt) { this.bi = paramInt; }
  
  void a(String paramString) { this.bj = ((paramString == null) ? Dump.d() : paramString).toUpperCase().getBytes(); }
  
  String c() { return (this.bk == null) ? (String)null : (new String(this.bk)).trim(); }
  
  String d() { return (this.bl == null) ? (String)null : (new String(this.bl)).trim(); }
  
  String e() { return (this.bm == null) ? (String)null : (new String(this.bm)).trim(); }
  
  byte[] f() { return this.br; }
  
  String g() { return this.bs; }
  
  String h() { return this.bt; }
  
  void b(String paramString) { this.b0 = paramString; }
  
  int i() { return this.b1; }
  
  void b(byte[] paramArrayOfByte) { this.b2 = paramArrayOfByte; }
  
  byte[] j() { return this.b2; }
  
  String k() { return this.b8; }
  
  String l() { return (this.b9 == null) ? (String)null : new String(this.b9); }
  
  void c(String paramString) { this.ca = (paramString == null) ? null : paramString.getBytes(); }
  
  String m() { return (this.ca == null) ? null : new String(this.ca); }
  
  String n() { return this.cc; }
  
  void d(String paramString) { this.cd = a(paramString, false); }
  
  void e(String paramString) { this.ce = paramString; }
  
  String o() { return this.ce; }
  
  void f(String paramString) { this.cf = paramString; }
  
  String p() { return this.cf; }
  
  void b(int paramInt) { this.cg = paramInt; }
  
  void g(String paramString) {
    if (paramString != null)
      this.ch = a(paramString, false); 
  }
  
  int q() {
    if (this.cl == -1)
      try {
        this.cl = ((Integer)c1.get(new String(this.bg))).intValue();
      } catch (NullPointerException nullPointerException) {} 
    return this.cl;
  }
  
  String r() { return this.cs; }
  
  private static byte[][] a(String[] paramArrayOfString) {
    byte[][] arrayOfByte = new byte[paramArrayOfString.length][];
    for (byte b10 = 0; b10 < paramArrayOfString.length; b10++)
      arrayOfByte[b10] = paramArrayOfString[b10].getBytes(); 
    return arrayOfByte;
  }
  
  void a(BrokerService paramBrokerService) {
    this.bk = paramBrokerService.b();
    this.bl = paramBrokerService.a();
    this.bm = paramBrokerService.c();
  }
  
  void c(byte[] paramArrayOfByte) { this.bl = paramArrayOfByte; }
  
  void s() throws BrokerException {
    byte[] arrayOfByte = { l.af };
    this.bk = arrayOfByte;
    this.bl = arrayOfByte;
    this.bm = arrayOfByte;
  }
  
  void a(BrokerSecurity paramBrokerSecurity, int paramInt, boolean paramBoolean1, boolean paramBoolean2) throws BrokerException {
    if (this.cx != null && paramBrokerSecurity != null && (this.cj != paramBoolean1 || this.ck != paramInt))
      BrokerException.a("0119", null); 
    this.cj = paramBoolean1;
    this.ck = paramInt;
    this.cz = paramBoolean2;
    if (paramBoolean2) {
      if (paramBrokerSecurity != null && paramBrokerSecurity instanceof EntireXSecurity) {
        this.cy = new ab();
      } else {
        this.cy = paramBrokerSecurity;
      } 
    } else if (paramBrokerSecurity != null && paramBrokerSecurity instanceof EntireXSecurity) {
      this.cx = new ab();
    } else {
      this.cx = paramBrokerSecurity;
    } 
  }
  
  void b(boolean paramBoolean) { this.em = paramBoolean; }
  
  boolean t() { return this.em; }
  
  void u() throws BrokerException {
    this.br = this.z.getSecurityToken();
    this.bd = null;
    this.be = null;
    this.bs = null;
    this.bt = null;
    this.bk = null;
    this.bl = null;
    this.bm = null;
    this.bu = null;
    this.bx = 0;
    this.b0 = null;
    this.b4 = null;
    this.b5 = null;
    this.ca = null;
    this.cb = null;
    this.cf = null;
    this.ce = null;
    this.cd = null;
    this.cg = 0;
    this.ch = null;
    this.v = null;
    this.w = null;
    this.bi = 0;
    this.b3 = null;
    this.b2 = null;
    this.b6 = null;
    this.bf = 0;
    this.b9 = null;
    this.b1 = 0;
    this.b7 = null;
    this.b8 = null;
    this.cc = null;
  }
  
  void a(String paramString1, String paramString2) {
    this.bn = paramString1;
    this.bo = paramString1.getBytes();
    if (paramString2 == null) {
      this.bq = null;
    } else {
      this.bq = paramString2.getBytes();
    } 
  }
  
  private void ag() throws BrokerException {
    int i1 = ah();
    this.e7 = f(i1);
    a(i1, this.e7 - i1);
  }
  
  private void a(int paramInt1, int paramInt2) throws BrokerException {
    int i3;
    int i2;
    int i1;
    byte b10 = 44;
    if (this.v == null || this.bd == aj) {
      i3 = 0;
    } else {
      i3 = this.v.length;
    } 
    if (paramInt2 == 0) {
      i2 = 0;
    } else {
      i2 = this.o + paramInt1 + i3;
    } 
    if (i3 == 0) {
      i1 = 0;
    } else {
      i1 = this.o;
    } 
    this.e5[b10] = k;
    this.e5[b10 + 1] = 1;
    if (this.n <= 3) {
      this.e5[b10 + 2] = (byte)(this.n + 1);
    } else {
      this.e5[b10 + 2] = 5;
    } 
    this.e5[b10 + 3] = (byte)this.o;
    a(this.e5, b10 + 4, this.o + i3);
    a(this.e5, b10 + 8, i1);
    if (this.bd == aj) {
      a(this.e5, b10 + 12, -2147483648);
    } else {
      a(this.e5, b10 + 12, 0);
    } 
    if (this.n >= 8 && this.cq)
      this.e5[b10 + 12] = (byte)(this.e5[b10 + 12] | 0x40); 
    a(this.e5, b10 + 16, i2);
    a(this.e5, b10 + 20, this.o + paramInt1 + paramInt2 + i3);
    if (this.n >= 4) {
      this.e5[b10 + 24] = 3;
      if (this.cx != null) {
        if (this.n >= 8) {
          this.e5[b10 + 25] = (this.cx instanceof ab) ? -18 : -1;
        } else {
          this.e5[b10 + 25] = -1;
        } 
      } else {
        this.e5[b10 + 25] = 0;
      } 
      this.e5[b10 + 25 + 1] = 0;
      this.e5[b10 + 25 + 2] = 0;
    } 
    a(this.e5, 0, 44 + this.o + this.e7 + i3);
    a(this.e5, 4, 1161970502);
    a(this.e5, 8, this.bi + 1024);
    this.e5[12] = 1;
    this.e5[13] = 0;
    a(this.e5, 14, (short)1);
    if (this.u == null) {
      this.t = d(0);
      this.u = this.t.getBytes();
    } 
    if (this.u.length != 28)
      BrokerException.a("0309", new String[] { Integer.toString(this.u.length) }); 
    System.arraycopy(this.u, 0, this.e5, 16, 28);
  }
  
  private int ah() {
    int i1 = c(this.e6, 0);
    i1 += a(this.e6, i1, 7, this.bd);
    i1 += a(this.e6, i1, 4, this.bo);
    if (this.bd == aj) {
      this.e6[i1++] = l.c;
      return i1;
    } 
    if (this.n >= 3) {
      i1 += a(this.e6, i1, 8, this.be);
    } else if (this.be != null && this.be != aq && this.be != ar) {
      i1 += a(this.e6, i1, 8, this.be);
    } 
    if (this.n >= 8 && this.cr) {
      i1 += a(this.e6, i1, 44, this.bt);
    } else {
      i1 += a(this.e6, i1, 9, this.bs);
    } 
    if (this.n >= 8 && (this.cq || this.cr)) {
      i1 += a(this.e6, i1, 42, this.bl);
    } else {
      i1 += a(this.e6, i1, 5, this.bk);
      i1 += a(this.e6, i1, 2, this.bl);
      i1 += a(this.e6, i1, 3, this.bm);
    } 
    i1 += a(this.e6, i1, 10, this.bu);
    i1 += a(this.e6, i1, 12, this.b0);
    i1 += a(this.e6, i1, 6, this.bq);
    i1 += a(this.e6, i1, 19, this.b4);
    i1 += a(this.e6, i1, 23, this.b5);
    i1 += a(this.e6, i1, 20, this.ca);
    i1 += a(this.e6, i1, 21, this.cb);
    if (this.v != null)
      i1 += a(this.e6, i1, 14, ac.a(this.v.length)); 
    if (this.bi > 0)
      i1 += a(this.e6, i1, 13, ac.a(this.bi)); 
    if (this.n >= 3) {
      i1 += a(this.e6, i1, 29, this.cf);
      i1 += a(this.e6, i1, 30, this.ce);
      i1 += a(this.e6, i1, 27, this.cd);
      if (this.cg > 0)
        i1 += a(this.e6, i1, 31, ac.a(this.cg)); 
    } 
    if (this.em && this.n < 4)
      BrokerException.a("0116", new String[] { new String(this.bg) }); 
    if (this.n >= 4) {
      if (this.em || this.n >= 8)
        i1 += a(this.e6, i1, 34, this.bj); 
      i1 += a(this.e6, i1, 32, ac.a(this.n));
    } 
    if (this.ck != 0 && this.n < 6)
      BrokerException.a("0118", new String[] { new String(this.bg) }); 
    if (this.n >= 6) {
      if (this.ci) {
        byte[] arrayOfByte = new byte[1];
        arrayOfByte[0] = l.y;
        i1 += a(this.e6, i1, 36, arrayOfByte);
      } 
      if (this.ck != 0)
        i1 += a(this.e6, i1, 37, ac.a(this.ck)); 
    } 
    if (this.n == 6 && this.c2 != 0)
      i1 += a(this.e6, i1, 38, ac.a(this.c2)); 
    if (this.n >= 7) {
      if (this.ct != 0 && ((this.v != null && this.v.length > 0) || this.bi > 0)) {
        if (this.cw) {
          i1 += a(this.e6, i1, 40, ac.a(this.ct));
        } else {
          i1 += a(this.e6, i1, 40, ac.a(0));
          this.cw = true;
        } 
        if (this.v != null && this.v.length > 0)
          i1 += a(this.e6, i1, 41, Long.toString(this.cv)); 
      } 
    } else if (this.ct != 0 && ((this.v != null && this.v.length > 0) || this.bi > 0)) {
      BrokerException.a("0120", new String[] { new String(this.bg) });
    } 
    if (this.n >= 8)
      i1 += a(this.e6, i1, 43, this.ch); 
    this.e6[i1++] = l.c;
    return i1;
  }
  
  private int f(int paramInt) throws BrokerException {
    if (this.bd == aj)
      return paramInt; 
    if (this.b3 != null)
      paramInt += a(this.e6, paramInt, (short)1, this.b3, "MSGID"); 
    if (this.b2 != null)
      paramInt += a(this.e6, paramInt, (short)2, this.b2, "USERDATA"); 
    if (this.b6 != null)
      paramInt += a(this.e6, paramInt, (short)3, f(this.bn, this.b6), "NEWPASSW"); 
    if (this.bp != null) {
      paramInt += a(this.e6, paramInt, (short)4, f(this.bn, this.bp), "PASS");
      if (this.bd != ag && this.cx != null && this.cx instanceof ab)
        this.br = ((ab)this.cx).a(this.br); 
    } 
    if (this.br != null)
      paramInt += a(this.e6, paramInt, (short)5, this.br, "SECTOK"); 
    if (this.n >= 6 && this.c3 != null)
      paramInt += a(this.e6, paramInt, (short)6, this.c3, "TXDATA"); 
    return paramInt;
  }
  
  private int a(byte[] paramArrayOfByte1, int paramInt, short paramShort, byte[] paramArrayOfByte2, String paramString) {
    int i1 = paramArrayOfByte2.length;
    if (i1 > 0) {
      if (Dump.c) {
        this.y.append(',');
        this.y.append(paramString);
        this.y.append('=');
        Dump.a(paramArrayOfByte2, this.y);
      } 
      a(paramArrayOfByte1, paramInt, paramShort);
      a(paramArrayOfByte1, paramInt + 2, (short)i1);
      System.arraycopy(paramArrayOfByte2, 0, paramArrayOfByte1, paramInt + 4, i1);
      return 4 + i1;
    } 
    return 0;
  }
  
  private int a(byte[] paramArrayOfByte, int paramInt1, int paramInt2, String paramString) {
    int i1 = 0;
    if (paramString != null) {
      paramArrayOfByte[paramInt1] = l.e;
      i1++;
      byte[] arrayOfByte1 = paramString.getBytes();
      byte[] arrayOfByte2 = c6[paramInt2];
      if (Dump.c) {
        this.y.append(',');
        this.y.append(c5[paramInt2]);
        this.y.append('=');
        this.y.append(paramString);
      } 
      System.arraycopy(arrayOfByte2, 0, paramArrayOfByte, paramInt1 + i1, arrayOfByte2.length);
      i1 += arrayOfByte2.length;
      paramArrayOfByte[paramInt1 + i1] = l.d;
      System.arraycopy(arrayOfByte1, 0, paramArrayOfByte, paramInt1 + ++i1, arrayOfByte1.length);
      i1 += arrayOfByte1.length;
    } 
    return i1;
  }
  
  private int a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2) {
    int i1 = 0;
    if (paramArrayOfByte2 != null) {
      paramArrayOfByte1[paramInt1] = l.e;
      i1++;
      byte[] arrayOfByte = c6[paramInt2];
      if (Dump.c && paramInt2 != 7) {
        this.y.append(',');
        this.y.append(c5[paramInt2]);
        this.y.append('=');
        this.y.append(new String(paramArrayOfByte2));
      } 
      System.arraycopy(arrayOfByte, 0, paramArrayOfByte1, paramInt1 + i1, arrayOfByte.length);
      i1 += arrayOfByte.length;
      paramArrayOfByte1[paramInt1 + i1] = l.d;
      System.arraycopy(paramArrayOfByte2, 0, paramArrayOfByte1, paramInt1 + ++i1, paramArrayOfByte2.length);
      i1 += paramArrayOfByte2.length;
    } 
    return i1;
  }
  
  private int c(byte[] paramArrayOfByte, int paramInt) {
    null = 1;
    paramArrayOfByte[paramInt] = l.e;
    byte[] arrayOfByte = c6[26];
    if (Dump.c) {
      this.y.append(c5[26]);
      this.y.append('=');
      this.y.append(new String(this.bg));
    } 
    System.arraycopy(arrayOfByte, 0, paramArrayOfByte, paramInt + null, arrayOfByte.length);
    null += arrayOfByte.length;
    paramArrayOfByte[paramInt + null] = l.d;
    System.arraycopy(this.bg, 0, paramArrayOfByte, paramInt + ++null, this.bg.length);
    return this.bg.length;
  }
  
  static void a(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    paramArrayOfByte[paramInt1] = (byte)(paramInt2 >> 24);
    paramArrayOfByte[paramInt1 + 1] = (byte)(paramInt2 >> 16);
    paramArrayOfByte[paramInt1 + 2] = (byte)(paramInt2 >> 8);
    paramArrayOfByte[paramInt1 + 3] = (byte)paramInt2;
  }
  
  static void a(byte[] paramArrayOfByte, int paramInt, short paramShort) {
    paramArrayOfByte[paramInt] = (byte)(paramShort >> 8);
    paramArrayOfByte[paramInt + 1] = (byte)paramShort;
  }
  
  private void ai() throws BrokerException {
    boolean bool = true;
    this.bz = null;
    if (this.bd == aj)
      this.cl = this.p.a(); 
    byte[] arrayOfByte1 = this.p.b();
    int i1 = this.p.d();
    i1 = (arrayOfByte1[i1 - 1] == l.c) ? (i1 - 1) : i1;
    this.c4.a(arrayOfByte1, 0, i1);
    String str = null;
    byte[] arrayOfByte2 = null;
    int i2 = 0;
    while (this.c4.a()) {
      int i5 = this.c4.c();
      switch (i5) {
        case 1:
        case 9:
        case 11:
        case 19:
        case 21:
        case 25:
        case 28:
        case 29:
        case 30:
        case 33:
        case 39:
        case 44:
          arrayOfByte2 = null;
          str = this.c4.d().trim();
          if (i5 != 33 && str.length() == 0) {
            str = null;
            continue;
          } 
          break;
        case 0:
          arrayOfByte2 = null;
          str = this.c4.a(40);
          break;
        case 2:
        case 3:
        case 5:
        case 17:
        case 20:
        case 42:
        case 43:
          str = null;
          arrayOfByte2 = this.c4.f();
          break;
        case 15:
        case 22:
        case 31:
        case 32:
        case 38:
        case 40:
        case 41:
          str = null;
          arrayOfByte2 = null;
          i2 = this.c4.e();
          break;
        default:
          BrokerException.a("0307", new String[] { c5[i5] });
          break;
      } 
      if (Dump.c) {
        if (bool) {
          bool = false;
        } else {
          this.y.append(',');
        } 
        this.y.append(c5[i5]);
        this.y.append('=');
        if (str == null && arrayOfByte2 == null) {
          str = Integer.toString(i2);
        } else if (str == null) {
          str = new String(arrayOfByte2);
        } 
        this.y.append(str.trim());
      } 
      switch (i5) {
        case 1:
          if (str != null && !str.equals("00000000"))
            this.bz = str; 
          continue;
        case 0:
          if (str == null || str.length() != 40)
            BrokerException.a("0308", new String[] { str }); 
          this.x = str.trim();
          continue;
        case 9:
          this.bs = str;
          continue;
        case 44:
          this.bt = str;
          continue;
        case 5:
          this.bk = arrayOfByte2;
          continue;
        case 2:
          this.bl = arrayOfByte2;
          continue;
        case 3:
          this.bm = arrayOfByte2;
          continue;
        case 42:
          this.bl = arrayOfByte2;
          continue;
        case 15:
          this.bf = i2;
          continue;
        case 20:
          this.ca = arrayOfByte2;
          continue;
        case 17:
          this.b9 = arrayOfByte2;
          continue;
        case 19:
          this.b4 = str;
          continue;
        case 21:
          this.cb = str;
          continue;
        case 22:
          this.b1 = i2;
          continue;
        case 25:
          this.b7 = str;
          continue;
        case 11:
          this.b8 = str;
          continue;
        case 28:
          this.cc = str;
          continue;
        case 29:
          this.cf = str;
          continue;
        case 30:
          this.ce = str;
          continue;
        case 31:
          this.cg = i2;
          continue;
        case 43:
          this.ch = arrayOfByte2;
        case 32:
          c(i2);
          continue;
        case 33:
          if (str.length() != 28 || str.equals("0000000000000000000000000000"))
            BrokerException.a("0322", new String[] { str }); 
          if (this.t.equals("0000000000000000000000000000")) {
            this.t = str;
            this.u = this.t.getBytes();
          } 
          continue;
        case 38:
          this.c2 = i2;
          continue;
        case 40:
          this.cu = i2;
          continue;
        case 41:
          this.cv = i2;
          continue;
        case 39:
          this.cs = str;
          continue;
      } 
      BrokerException.a("0307", new String[] { c5[i5] });
    } 
    int i3 = this.p.d();
    int i4 = this.p.c();
    while (i3 < i4) {
      short s1 = b(arrayOfByte1, i3);
      short s2 = b(arrayOfByte1, i3 + 2);
      i3 += 4;
      switch (s1) {
        case 1:
          if (this.b3 == null)
            this.b3 = new byte[s2]; 
          System.arraycopy(arrayOfByte1, i3, this.b3, 0, s2);
          if (Dump.c) {
            if (bool) {
              bool = false;
            } else {
              this.y.append(',');
            } 
            this.y.append("MSGID=");
            this.y.append(new String(this.b3));
          } 
          break;
        case 2:
          if (s2 == 0)
            break; 
          if (this.b2 == null)
            this.b2 = new byte[s2]; 
          System.arraycopy(arrayOfByte1, i3, this.b2, 0, s2);
          if (Dump.c) {
            if (bool) {
              bool = false;
            } else {
              this.y.append(',');
            } 
            this.y.append("USERDATA=");
            this.y.append(new String(this.b2));
          } 
          break;
        case 5:
          if (this.br == null)
            this.br = new byte[s2]; 
          System.arraycopy(arrayOfByte1, i3, this.br, 0, s2);
          if (Dump.c) {
            if (bool) {
              bool = false;
            } else {
              this.y.append(',');
            } 
            this.y.append("SECTOK=");
            this.y.append(new String(this.br));
          } 
          break;
        case 6:
          this.c3 = new byte[s2];
          System.arraycopy(arrayOfByte1, i3, this.c3, 0, s2);
          if (Dump.c) {
            if (bool) {
              bool = false;
            } else {
              this.y.append(',');
            } 
            this.y.append("TXDATA=");
            this.y.append(new String(this.c3));
          } 
          break;
        default:
          BrokerException.a("0306", new String[] { Short.toString(s1) });
          break;
      } 
      i3 += s2;
    } 
    this.w = this.p.e();
  }
  
  void h(String paramString) {
    if (paramString == this.bw || (paramString != null && paramString.equals(this.bw))) {
      this.bu = this.bv;
      this.bx = this.by;
      return;
    } 
    this.bu = a(paramString, true);
    this.bw = paramString;
    this.bv = this.bu;
    this.by = this.bx;
  }
  
  private byte[] a(String paramString, boolean paramBoolean) {
    String str;
    byte[] arrayOfByte = null;
    int i1 = 0;
    if (paramBoolean) {
      str = "WaitTime: ";
    } else {
      str = "LifeTime: ";
    } 
    if (paramString == null)
      throw new IllegalArgumentException(str + "no argument"); 
    if (paramString.equals("NO") || paramString.equals("no")) {
      if (paramBoolean)
        this.bx = 0; 
      arrayOfByte = null;
    } else {
      try {
        int i2 = paramString.length();
        char c10 = Character.toUpperCase(paramString.charAt(i2 - 1));
        String str1 = paramString.substring(0, i2 - 1);
        int i3 = Integer.parseInt(str1);
        switch (c10) {
          case 'S':
            i1 = i3 * 1000;
            break;
          case 'M':
            i1 = i3 * 60 * 1000;
            break;
          case 'H':
            i1 = i3 * 3600 * 1000;
            break;
          case 'D':
            if (paramBoolean)
              throw new IllegalArgumentException(str + "wrong argument " + paramString); 
            break;
          default:
            throw new IllegalArgumentException(str + "wrong argument " + paramString);
        } 
        if (i3 > 99999)
          throw new IllegalArgumentException(str + "wrong argument " + paramString); 
        arrayOfByte = paramString.toUpperCase().getBytes();
      } catch (NumberFormatException numberFormatException) {
        throw new IllegalArgumentException(str + "wrong argument " + paramString);
      } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
        throw new IllegalArgumentException(str + "wrong argument " + paramString);
      } 
    } 
    if (paramBoolean)
      this.bx = i1; 
    return arrayOfByte;
  }
  
  static final int a(byte[] paramArrayOfByte, int paramInt) {
    null = (paramArrayOfByte[paramInt] & 0xFF) << 24;
    null |= (paramArrayOfByte[paramInt + 1] & 0xFF) << 16;
    null |= (paramArrayOfByte[paramInt + 2] & 0xFF) << 8;
    return paramArrayOfByte[paramInt + 3] & 0xFF;
  }
  
  static final short b(byte[] paramArrayOfByte, int paramInt) {
    byte b10 = (paramArrayOfByte[paramInt] & 0xFF) << 8;
    b10 |= paramArrayOfByte[paramInt + 1] & 0xFF;
    return (short)b10;
  }
  
  private void c(String paramString1, String paramString2) {
    if (this.bz == null)
      return; 
    if (this.bd == aj && this.bz.equals("00200182"))
      return; 
    throw new BrokerException(this.bz.substring(0, 4), this.bz.substring(4), this.x, paramString1, paramString2);
  }
  
  private byte[] f(String paramString, byte[] paramArrayOfByte) {
    if (this.n < 3)
      return paramArrayOfByte; 
    int i1 = paramArrayOfByte.length;
    byte[] arrayOfByte1 = paramString.getBytes();
    byte[] arrayOfByte2 = new byte[i1];
    byte b10 = 0;
    short s1 = 0;
    while (b10 < arrayOfByte1.length) {
      s1 += arrayOfByte1[b10] * (b10 + true);
      s1 &= 0xFF;
      b10++;
    } 
    for (b10 = 0; b10 < i1; b10++) {
      arrayOfByte2[b10] = (byte)(paramArrayOfByte[b10] ^ s1);
      s1 = s1 + 7 * (b10 + 1) & 0xFF;
    } 
    return arrayOfByte2;
  }
  
  final int v() {
    if (this.n == 0)
      g(null); 
    return this.n;
  }
  
  final void c(int paramInt) {
    if (paramInt > 8)
      paramInt = 8; 
    if (paramInt == this.n)
      return; 
    this.n = paramInt;
    if (this.n <= 3) {
      this.o = 24;
      this.e5 = this.e3;
    } else {
      this.o = 28;
      this.e5 = this.e4;
    } 
    if (this.n == 2 && this.p instanceof v)
      if (this.z.getBrokerID().indexOf('?') == -1) {
        this.p = t.a(this.z.getBrokerID() + "?poolsize=0");
      } else {
        this.p = t.a(this.z.getBrokerID() + "&poolsize=0");
      }  
    if (Dump.c)
      Dump.log("Using API version " + this.n + " for Broker " + new String(this.bg)); 
  }
  
  private void aj() throws BrokerException {
    if (this.n >= 7 && this.ct != 0) {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(512);
      Deflater deflater = new Deflater(this.ct);
      DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(byteArrayOutputStream, deflater);
      try {
        this.cv = this.v.length;
        deflaterOutputStream.write(this.v);
        deflaterOutputStream.close();
        deflater.end();
        if (byteArrayOutputStream.size() < this.cv) {
          this.v = byteArrayOutputStream.toByteArray();
          if (Dump.c) {
            Dump.log("Compressing with level " + this.ct + ", uncompressed length: " + this.cv + ", compressed length:" + this.v.length);
            Dump.dumpBytes("Compressed data: ", this.v, this.v.length, 4);
          } 
        } else {
          this.cw = false;
          Dump.log("Do not compress, uncompressed length: " + this.cv + ", compressed length:" + byteArrayOutputStream.size());
        } 
      } catch (Exception exception) {
        BrokerException.a("0331", new String[] { "compressing with level " + this.ct + " and UCL=" + this.cv + ", exception: " + exception.toString() });
      } 
    } 
  }
  
  private void ak() throws BrokerException {
    if (this.n >= 7 && this.cu != 0) {
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(this.w);
      Inflater inflater = new Inflater();
      InflaterInputStream inflaterInputStream = new InflaterInputStream(byteArrayInputStream, inflater, this.w.length);
      int i1 = 0;
      byte[] arrayOfByte = null;
      try {
        if (Dump.c) {
          Dump.log("decompressing with level " + this.cu + ", uncompressed length: " + this.cv + ", compressed length: " + this.w.length);
          Dump.dumpBytes("compressed data: ", this.w, this.w.length, 4);
        } 
        arrayOfByte = new byte[this.cv];
        i1 = inflaterInputStream.read(arrayOfByte);
        inflaterInputStream.close();
        inflater.end();
        this.w = arrayOfByte;
        if (Dump.c)
          Dump.dumpBytes("decompressed data:", this.w, this.w.length, 4); 
      } catch (Exception exception) {
        BrokerException.a("0332", new String[] { "decompressing with level " + this.ct + " and UCL=" + this.cv + ", " + i1 + " bytes read, exception: " + exception.toString() });
      } 
      if (i1 != this.cv)
        BrokerException.a("0332", new String[] { "decompression incomplete: read " + i1 + ", should be " + this.cv + " bytes, buffer of " + arrayOfByte.length + " bytes allocated." }); 
    } 
  }
  
  void b(String paramString1, String paramString2) {
    if (paramString1 != null) {
      this.bp = paramString1.getBytes();
    } else {
      this.bp = null;
    } 
    if (paramString2 != null)
      this.b6 = paramString2.getBytes(); 
    e(true);
    f(ag);
    this.bp = null;
  }
  
  void i(String paramString) {
    if (paramString != null) {
      this.bp = paramString.getBytes();
    } else {
      this.bp = null;
    } 
    e(false);
    this.ci = false;
  }
  
  void w() throws BrokerException { f(ah); }
  
  void d(byte[] paramArrayOfByte) {
    this.be = paramArrayOfByte;
    f(ae);
  }
  
  void c(boolean paramBoolean) {
    this.be = paramBoolean ? a9 : null;
    this.cr = true;
    f(am);
    this.cr = false;
  }
  
  void e(byte[] paramArrayOfByte) {
    this.be = paramArrayOfByte;
    f(af);
  }
  
  void x() throws BrokerException {
    this.cr = true;
    f(an);
    this.cr = false;
  }
  
  void a(String paramString, boolean paramBoolean, byte[] paramArrayOfByte) throws BrokerException { a(paramString, paramBoolean, paramArrayOfByte, false, false); }
  
  void a(String paramString, byte[] paramArrayOfByte) throws BrokerException {
    this.cr = true;
    a(paramString, true, paramArrayOfByte, true, false);
    this.cr = false;
  }
  
  void y() throws BrokerException { a(null, true, null, false, true); }
  
  private void a(String paramString, boolean paramBoolean1, byte[] paramArrayOfByte, boolean paramBoolean2, boolean paramBoolean3) throws BrokerException {
    if (paramBoolean2) {
      this.bt = paramString;
    } else if (!paramBoolean3) {
      this.bs = paramString;
    } 
    this.be = paramArrayOfByte;
    if (paramBoolean1 || paramBoolean2 || paramBoolean3)
      this.bu = null; 
    if ((this.cx != null && this.cj) || this.ct != 0) {
      Dump.dumpBytes("Sending Data ", this.v, this.v.length, 2);
      this.p.a(false);
    } 
    aj();
    if (this.cx != null && this.cj)
      this.cx.encryptData(this.v); 
    if (paramBoolean2) {
      f(ak);
    } else if (paramBoolean3) {
      f(ap);
    } else {
      f(aa);
    } 
    this.v = null;
    if (!paramBoolean1) {
      if (this.cx != null && this.cj)
        this.cx.decryptData(this.w); 
      ak();
      if ((this.cx != null && this.cj) || this.ct != 0)
        Dump.dumpBytes("Received Data ", this.w, this.w.length, 2); 
    } 
  }
  
  void b(String paramString, byte[] paramArrayOfByte) throws BrokerException {
    this.cr = false;
    a(paramString, paramArrayOfByte, false);
  }
  
  void j(String paramString) {
    this.cr = true;
    boolean bool = this.bh;
    this.bh = true;
    a(paramString, null, true);
    this.cr = false;
    this.bh = bool;
  }
  
  private void a(String paramString, byte[] paramArrayOfByte, boolean paramBoolean) throws BrokerException {
    if (paramBoolean) {
      this.bt = paramString;
    } else {
      this.bs = paramString;
    } 
    this.be = paramArrayOfByte;
    if ((this.cx != null && this.cj) || this.ct != 0)
      this.p.a(false); 
    if (paramBoolean) {
      f(al);
    } else {
      f(ab);
    } 
    if (this.cx != null && this.cj)
      this.cx.decryptData(this.w); 
    ak();
    if ((this.cx != null && this.cj) || this.ct != 0)
      Dump.dumpBytes("Received Data ", this.w, this.w.length, 2); 
  }
  
  void c(String paramString, byte[] paramArrayOfByte) throws BrokerException {
    this.bs = paramString;
    this.be = paramArrayOfByte;
    f(ad);
  }
  
  void d(String paramString, byte[] paramArrayOfByte) throws BrokerException {
    this.bs = paramString;
    this.be = paramArrayOfByte;
    f(ac);
  }
  
  void e(String paramString, byte[] paramArrayOfByte) throws BrokerException {
    this.bs = paramString;
    this.be = paramArrayOfByte;
    f(ai);
  }
  
  void a(String paramString1, byte[] paramArrayOfByte, String paramString2) throws BrokerException {
    this.cr = true;
    this.bt = paramString1;
    this.be = paramArrayOfByte;
    this.cf = paramString2;
    f(ao);
    this.cr = false;
  }
  
  String z() {
    f(aj);
    return this.x.startsWith("Version") ? this.x : "";
  }
  
  private void f(byte[] paramArrayOfByte) {
    String str = null;
    g(paramArrayOfByte);
    this.bd = paramArrayOfByte;
    if (this.cz)
      switch (q()) {
        case 2:
          this.cx = this.cy;
          e(true);
          break;
      }  
    if (Dump.c) {
      this.y.setLength(0);
      this.y.append(new String(paramArrayOfByte));
      this.y.append('(');
    } 
    ag();
    if (Dump.c) {
      if (this.t != null)
        this.y.append(",PU=" + this.t); 
      this.y.append(')');
      Dump.a(this.y);
      str = this.y.toString();
    } 
    if (paramArrayOfByte != aj && this.v != null)
      this.p.a(this.v); 
    try {
      this.p.a(this.bx, this.e5, this.e6, this.e7);
    } catch (BrokerException brokerException) {
      int i1 = brokerException.getErrorCode();
      if (i1 == 313 || i1 == 316) {
        this.t = "0000000000000000000000000000";
        this.u = s;
      } 
      throw (BrokerException)brokerException.fillInStackTrace();
    } 
    if (Dump.c) {
      this.y.setLength(0);
      this.y.append("  ");
      this.y.append(new String(paramArrayOfByte));
      this.y.append(" returns: ");
    } 
    ai();
    if (Dump.c)
      Dump.a(this.y); 
    if (this.bz != null)
      if (this.bz.equals("00200188") && this.be != null && (this.be == aq || this.be == ar)) {
        c(2);
        f(paramArrayOfByte);
      } else if (this.bz.equals("00200187") && this.be != null && this.be == ar) {
        c(2);
        f(paramArrayOfByte);
      } else if ((this.bz.equals("00200094") || this.bz.equals("00200377")) && this.bh) {
        if (this.bs != null && !this.bs.equals("NONE") && !this.bs.equals("NEW")) {
          if (this.bf <= this.bi)
            this.bf = this.bi + 100; 
          this.bi = this.bf;
          this.be = aw;
          this.bu = null;
          byte[] arrayOfByte = this.b9;
          f(ab);
          this.b9 = arrayOfByte;
        } 
        if (this.bt != null && !this.bt.equals("NONE") && !this.bt.equals("NEW")) {
          this.bi = this.bf;
          this.be = aw;
          this.ca = null;
          this.bu = null;
          byte[] arrayOfByte = this.b9;
          f(al);
          this.b9 = arrayOfByte;
        } 
      } else if (this.bz.equals("00100022")) {
        this.bz = null;
      } else if (this.bz.equals("00200379") && this.cz) {
        this.cx = this.cy;
        this.cl = 2;
        c1.put(new String(this.bg), new Integer(2));
        e(true);
        if (this.c0) {
          this.c0 = false;
          f(paramArrayOfByte);
        } 
      }  
    if (Dump.c) {
      c(str, this.y.toString());
    } else {
      c(null, null);
    } 
  }
  
  static String d(int paramInt) {
    StringBuffer stringBuffer1 = new StringBuffer(28);
    if (!Dump.c())
      try {
        String str = InetAddress.getLocalHost().getHostAddress();
        for (byte b10 = 0; b10 < str.length(); b10++) {
          if (str.charAt(b10) != '.')
            stringBuffer1.append(str.charAt(b10)); 
        } 
      } catch (Exception exception) {} 
    stringBuffer1.append(Integer.toString(paramInt));
    long l1 = System.currentTimeMillis();
    double d10 = l1 * Math.random();
    StringBuffer stringBuffer2 = new StringBuffer(Long.toHexString(Double.doubleToLongBits(d10)));
    stringBuffer2.reverse();
    stringBuffer2.setLength(stringBuffer2.length() - 2);
    stringBuffer1.append(stringBuffer2.toString());
    if (stringBuffer1.length() > 28) {
      stringBuffer1.setLength(28);
    } else {
      for (byte b10 = 0; stringBuffer1.length() < 28; b10++)
        stringBuffer1.append(stringBuffer2.charAt(b10)); 
    } 
    if (Dump.c)
      Dump.log("Generated UniqueID=" + new String(stringBuffer1)); 
    return stringBuffer1.toString();
  }
  
  String aa() { return this.p.f(); }
  
  void ab() throws BrokerException { this.p.j(); }
  
  String ac() { return this.t; }
  
  boolean k(String paramString) { return paramString.equals("0000000000000000000000000000"); }
  
  int ad() { return this.ct; }
  
  void e(int paramInt) { this.ct = paramInt; }
  
  private void g(byte[] paramArrayOfByte) {
    if (!this.b) {
      String str = new String(this.bg);
      af();
      int i1 = this.n;
      Integer integer = (Integer)a.get(str);
      if (integer == null) {
        c(3);
        if (paramArrayOfByte == null || paramArrayOfByte != aj) {
          z();
          if (Dump.f())
            a.put(str, new Integer(this.n)); 
          c1.put(str, new Integer(this.cl));
        } 
      } else {
        c(integer.intValue());
      } 
      this.b = true;
      if (i1 != 0 && i1 < this.n)
        c(i1); 
      if (this.n <= 3 && (paramArrayOfByte == null || paramArrayOfByte != aj)) {
        this.t = null;
        this.u = null;
      } 
    } 
  }
  
  private void e(boolean paramBoolean) {
    if (this.cx != null) {
      if (paramBoolean)
        this.ci = true; 
      synchronized (this.cx) {
        if (this.cx instanceof ab) {
          ((ab)this.cx).a(this.bn, this.bp, this.b6, this.br, this.cj);
        } else {
          this.cx.prepareLogon(this.bn, this.bp, this.b6, this.br);
        } 
        this.bp = this.cx.getPassword();
        this.b6 = this.cx.getNewpassword();
        this.br = this.cx.getSecurityToken();
      } 
    } else if (paramBoolean) {
      this.ci = false;
    } 
  }
  
  void d(boolean paramBoolean) { this.cq = paramBoolean; }
  
  boolean ae() { return this.cq; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\q.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */