package com.softwareag.entirex.aci;

import com.softwareag.entirex.trace.Trace;

public class j {
  private static boolean a = Trace.on(1, "Base64");
  
  private static final int b = 0;
  
  private static final int c = 1;
  
  private static final int d = 2;
  
  private static final int e = 3;
  
  private static final String[] f = new String[3];
  
  private static final byte[][] g;
  
  private static final String h;
  
  private static final byte[] i;
  
  public static final int a(int paramInt) { return paramInt / 3 * 4 + ((paramInt % 3 == 0) ? 0 : (paramInt % 3 + 1)); }
  
  public static final int b(int paramInt) { return paramInt / 4 * 3 + paramInt % 4 * 4 / 6; }
  
  public static final String a(byte[] paramArrayOfByte) {
    if (a) {
      Trace.enterMethod(Trace.M3, 2, 17, 50);
      Trace.parameter(Trace.MB3, 2, 17, 50, "in", paramArrayOfByte);
    } 
    byte b3 = 0;
    byte b2 = 0;
    StringBuffer stringBuffer = new StringBuffer();
    byte b1;
    boolean bool;
    for (b1 = bool; b1 < paramArrayOfByte.length; b1++) {
      byte b5 = paramArrayOfByte[b1];
      byte b4 = 6 - b2 % 6;
      b3 |= (b5 & 0xFF) >>> 2 + b2;
      stringBuffer.append(h.charAt(b3 & 0x3F));
      b2 = 8 - b4;
      b3 = b5 << 6 - b2 & 0x3F;
      if (b2 == 6) {
        stringBuffer.append(h.charAt(b3 & 0x3F));
        b3 = 0;
        b2 = 0;
      } 
    } 
    if (b2 > 0) {
      stringBuffer.append(h.charAt(b3 & 0x3F));
      b3 = 0;
      b2 = 0;
    } 
    if (a) {
      Trace.parameter(Trace.MP3, 2, 17, 50, "out", "(" + stringBuffer.length() + ")" + stringBuffer.toString());
      Trace.leaveMethod(Trace.M3, 2, 17, 50);
    } 
    return stringBuffer.toString();
  }
  
  public static final byte[] a(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    if (a) {
      Trace.enterMethod(Trace.M3, 2, 17, 51);
      Trace.parameter(Trace.MP3, 2, 17, 51, "in", "(" + paramInt2 + ")" + new String(paramArrayOfByte));
    } 
    byte b2 = 0;
    int m = paramInt2;
    int n = b(paramInt2);
    byte[] arrayOfByte = new byte[n];
    int k;
    byte b1;
    for (k = b1; k < m; k++) {
      byte b3 = 8 - b2 % 8;
      byte b4 = i[paramArrayOfByte[paramInt1 + k] & 0xFF];
      if (b3 <= 6) {
        arrayOfByte[b1++] = (byte)(arrayOfByte[b1++] | b4 >> 6 - b3);
        if (b1 < arrayOfByte.length)
          arrayOfByte[b1] = (byte)(b4 << 8 - 6 - b3); 
      } else {
        arrayOfByte[b1] = (byte)(b4 << 2);
      } 
      b2 = (b2 + 6) % 24;
    } 
    if (a) {
      Trace.parameter(Trace.MB3, 2, 17, 51, "out", arrayOfByte);
      Trace.leaveMethod(Trace.M3, 2, 17, 51);
    } 
    return arrayOfByte;
  }
  
  public static final byte[] a(String paramString) {
    if (a) {
      Trace.enterMethod(Trace.M3, 2, 17, 51);
      Trace.parameter(Trace.MP3, 2, 17, 51, "in", "(" + paramString.length() + ")" + paramString);
    } 
    byte b3 = 0;
    int k = paramString.length();
    int m = b(paramString.length());
    byte[] arrayOfByte1 = new byte[m + 1];
    for (byte b2 = 0, b1 = b2; b1 < k; b1++) {
      byte b4 = 8 - b3 % 8;
      byte b5 = i[paramString.charAt(b1)];
      if (b4 <= 6) {
        arrayOfByte1[b2++] = (byte)(arrayOfByte1[b2++] | b5 >> 6 - b4);
        if (b2 < arrayOfByte1.length)
          arrayOfByte1[b2] = (byte)(b5 << 8 - 6 - b4); 
      } else {
        arrayOfByte1[b2] = (byte)(b5 << 2);
      } 
      b3 = (b3 + 6) % 24;
    } 
    byte[] arrayOfByte2 = new byte[m];
    System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, m);
    if (a) {
      Trace.parameter(Trace.MB3, 2, 17, 51, "out", arrayOfByte1);
      Trace.leaveMethod(Trace.M3, 2, 17, 51);
    } 
    return arrayOfByte2;
  }
  
  static  {
    f[0] = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_";
    f[1] = "+-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    f[2] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    g = new byte[f.length][65535];
    for (byte b1 = 0; b1 < f.length; b1++) {
      String str = f[b1];
      for (byte b2 = 0; b2 < 64; b2 = (byte)(b2 + 1))
        g[b1][str.charAt(b2)] = b2; 
    } 
    h = f[2];
    i = g[2];
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\j.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */