package com.softwareag.entirex.aci;

class ab implements BrokerSecurity {
  private static final char[] a = { 
      's', 't', 'e', 'v', 'e', 'p', 'u', 'r', 'c', 'h', 
      'a', 's', 'e', '@', '#', '$', '?', 'C', 'R', 'O', 
      'M', 'P', 'T', 'O', 'N', '*', 't', 'a', 'v', 'e', 
      'r', 'n' };
  
  private byte[] b = null;
  
  private byte[] c = null;
  
  private byte[] d = null;
  
  public void prepareLogon(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3) { throw new IllegalAccessError(); }
  
  void a(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, boolean paramBoolean) {
    if (paramArrayOfByte3 == null) {
      this.d = new byte[] { 
          1, 35, 69, 103, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          -1, 1 };
      if (paramBoolean)
        this.d[31] = -1; 
    } else {
      this.d = paramArrayOfByte3;
    } 
    this.d[4] = 1;
    this.b = null;
    if (paramArrayOfByte1 != null && paramArrayOfByte1.length > 0) {
      this.b = b(paramArrayOfByte1);
      a(this.b, a(32));
      this.d[4] = -1;
    } 
    this.c = null;
    if (paramArrayOfByte2 != null && paramArrayOfByte2.length > 0) {
      this.c = b(paramArrayOfByte2);
      a(this.c, a(32));
      this.d[5] = -1;
    } 
  }
  
  byte[] a(byte[] paramArrayOfByte) {
    byte[] arrayOfByte = paramArrayOfByte;
    if (arrayOfByte != null)
      arrayOfByte[4] = -1; 
    return arrayOfByte;
  }
  
  public byte[] getPassword() { return this.b; }
  
  public byte[] getNewpassword() { return this.c; }
  
  public byte[] getSecurityToken() { return this.d; }
  
  public void encryptData(byte[] paramArrayOfByte) {
    if (paramArrayOfByte == null)
      return; 
    a(paramArrayOfByte, a(5));
  }
  
  public void decryptData(byte[] paramArrayOfByte) {
    if (paramArrayOfByte == null)
      return; 
    a(paramArrayOfByte, a(5));
  }
  
  private int[] a(int paramInt) {
    byte b2 = 0;
    int i = 0;
    int[] arrayOfInt = new int[256];
    byte b1;
    for (b1 = 0; b1 < 'Ā'; b1++)
      arrayOfInt[b1] = b1; 
    for (b1 = 0; b1 < 'Ā'; b1++) {
      int j = arrayOfInt[b1];
      i += j + (byte)a[b2];
      i &= 0xFF;
      arrayOfInt[b1] = arrayOfInt[i];
      arrayOfInt[i] = j;
      if (++b2 == paramInt)
        b2 = 0; 
    } 
    return arrayOfInt;
  }
  
  private void a(byte[] paramArrayOfByte, int[] paramArrayOfInt) {
    char c1 = Character.MIN_VALUE;
    int i = 0;
    int j = paramArrayOfByte.length;
    for (byte b1 = 0; b1 < j; b1++) {
      c1 = ++c1 & 0xFF;
      int k = paramArrayOfInt[c1];
      i += k;
      i &= 0xFF;
      int m = paramArrayOfInt[i];
      paramArrayOfInt[i] = k;
      paramArrayOfInt[c1] = m;
      paramArrayOfByte[b1] = (byte)(paramArrayOfByte[b1] ^ paramArrayOfInt[k + m & 0xFF]);
    } 
  }
  
  private static byte[] b(byte[] paramArrayOfByte) {
    byte[] arrayOfByte = new byte[32];
    for (byte b1 = 0; b1 < 32; b1++)
      arrayOfByte[b1] = 0; 
    System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, paramArrayOfByte.length);
    return arrayOfByte;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\ab.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */