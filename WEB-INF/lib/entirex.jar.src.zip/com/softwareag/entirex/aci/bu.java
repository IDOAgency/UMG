package com.softwareag.entirex.aci;

import java.util.Calendar;

class bu {
  static String a(String paramString1, String paramString2, String paramString3) throws BrokerException { return a(paramString1, paramString2, paramString3, ':'); }
  
  static String a(String paramString1, String paramString2, String paramString3, char paramChar) throws BrokerException {
    String str = "";
    if (paramString1 == null || paramString2 == null) {
      BrokerException.a("0210", null);
    } else if (paramString3 == null) {
      paramString1.trim();
      str = "U" + (paramString1 + "        ").substring(0, 8);
      if (str.length() != 9)
        BrokerException.a("0210", null); 
    } else {
      paramString1.trim();
      paramString2.trim();
      paramString3.trim();
      if (paramString1.length() == 0 || paramString2.length() == 0 || paramString3.length() == 0) {
        if (paramString3.length() == 0) {
          str = "U" + (paramString1 + "        ").substring(0, 8);
          if (str.length() != 9)
            BrokerException.a("0210", null); 
        } else {
          BrokerException.a("0210", null);
        } 
      } else {
        Calendar calendar = Calendar.getInstance();
        int i = calendar.get(12);
        int j = calendar.get(13);
        int k = calendar.get(11);
        long l = ((k % 10 + i % 10 * 10) * 10000 + (i / 10 * 10 + j / 10) * 100 + j % 10 * 10 + k / 10);
        char[] arrayOfChar = new char[8];
        arrayOfChar[0] = (char)(48 + k / 10);
        arrayOfChar[1] = (char)(48 + k % 10);
        arrayOfChar[2] = paramChar;
        arrayOfChar[3] = (char)(48 + i / 10);
        arrayOfChar[4] = (char)(48 + i % 10);
        arrayOfChar[5] = paramChar;
        arrayOfChar[6] = (char)(48 + j / 10);
        arrayOfChar[7] = (char)(48 + j % 10);
        str = "C" + new String(arrayOfChar) + a(paramString2, l) + a(paramString3, l) + a(paramString1, l) + " ";
      } 
    } 
    return str;
  }
  
  private static char a(int paramInt) { return (paramInt < 10) ? (char)(48 + paramInt) : (char)(65 + paramInt - 10); }
  
  static String a(String paramString, long paramLong) { return a(paramString, paramLong, 8); }
  
  public static String a(String paramString, long paramLong, int paramInt) {
    long l = paramLong;
    char[] arrayOfChar1 = new char[paramInt];
    char[] arrayOfChar2 = new char[2 * paramInt];
    paramString = paramString.toUpperCase();
    int i = paramString.length();
    byte b1;
    for (b1 = 0; b1 < paramInt; b1++) {
      long l1 = 455470314L * l;
      l = l1 % 2147483647L;
      long l2 = l % 1000L & 0xFFL;
      if (b1 < i) {
        char c = paramString.charAt(b1);
        arrayOfChar1[b1] = (char)(int)(c + l2);
      } else {
        arrayOfChar1[b1] = (char)(int)(l2 + 32L);
      } 
    } 
    for (byte b2 = 0, b1 = b2; b1 < paramInt; b1++) {
      char c = arrayOfChar1[b1];
      arrayOfChar2[b2++] = a((c & 0xF0) >> '\004');
      arrayOfChar2[b2++] = a(c & 0xF);
    } 
    return new String(arrayOfChar2);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\bu.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */