package com.softwareag.entirex.aci;

import java.awt.TextField;

class com/softwareag/entirex/aci/b5 extends TextField {
  private final Tester a;
  
  public com/softwareag/entirex/aci/b5(Tester paramTester, String paramString, int paramInt) {
    super(paramString, paramInt);
    this.a = paramTester;
    setEditable(false);
  }
  
  public boolean isFocusTraversable() { return false; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\b5.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */