package com.softwareag.entirex.aci;

class com/softwareag/entirex/aci/es extends RPCService {
  private final RPCServer a;
  
  com/softwareag/entirex/aci/es(RPCServer paramRPCServer, Broker paramBroker, String paramString) {
    super(paramBroker, paramString, null);
    this.a = paramRPCServer;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\es.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */