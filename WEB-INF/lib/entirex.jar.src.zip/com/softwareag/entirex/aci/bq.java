package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.ac;
import com.softwareag.entirex.base.s;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Properties;

class bq extends br {
  private String a = "   ";
  
  private static final int b = 0;
  
  private static final int c = 92;
  
  private static final int d = 9;
  
  private static final int e = 19;
  
  private static final int f = 29;
  
  private static final int g = 39;
  
  private static final int h = 49;
  
  private static final int i = 59;
  
  private static final int j = 10;
  
  private static final int k = 10;
  
  private static final int l = 10;
  
  private static final int m = 10;
  
  private static final int n = 10;
  
  private static final int o = 10;
  
  private static final int p = 77;
  
  private static final int q = 3;
  
  private static final int r = 80;
  
  private static final int s = 2;
  
  private static final int t = 69;
  
  private static final int u = 4;
  
  private static final int v = 73;
  
  private static final int w = 4;
  
  private static final int x = 82;
  
  private static final int y = 10;
  
  private com/softwareag/entirex/aci/bt z = new com/softwareag/entirex/aci/bt(this, null);
  
  public bq(byte[] paramArrayOfByte) throws be { this(paramArrayOfByte, s.a()); }
  
  public bq(byte[] paramArrayOfByte, s params) throws be {
    super(paramArrayOfByte, params);
    this.z = new com/softwareag/entirex/aci/bt(this, params.b(), null);
    g(ac.a(u(), 9, 10, params));
    h(ac.a(u(), 19, 10, params));
    byte[] arrayOfByte1 = new byte[ag()];
    System.arraycopy(paramArrayOfByte, af(), arrayOfByte1, 0, ag());
    d(arrayOfByte1);
    Dump.dumpBytes("RPCMessage2000: StringBuffer:", x(), x().length, 4);
    super.e = y();
    e(ac.a(u(), 29, 10, params));
    f(ac.a(u(), 39, 10, params));
    byte[] arrayOfByte2 = new byte[ae()];
    System.arraycopy(paramArrayOfByte, ad(), arrayOfByte2, 0, ae());
    b(arrayOfByte2);
    Dump.dumpBytes("RPCMessage2000: FormatBuffer:", v(), v().length, 4);
    i(ac.a(u(), 49, 10, params));
    j(ac.a(u(), 59, 10, params));
    byte[] arrayOfByte3 = new byte[ai()];
    System.arraycopy(paramArrayOfByte, ah(), arrayOfByte3, 0, ai());
    e(arrayOfByte3);
    Dump.dumpBytes("RPCMessage2000: ValueBuffer:", z(), z().length, 4);
    super.i = ac.a(u(), 82, 10, params);
    super.j = a(u(), 80);
    super.f = ac.a(u(), n(), o(), params);
    super.g = ac.a(u(), p(), q(), params);
    if (super.f != 0 || super.g != 0)
      throw new be(super.f, super.g, r()); 
  }
  
  public bq(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, Properties paramProperties, ao paramao, s params) {
    super(paramao, params);
    this.z = new com/softwareag/entirex/aci/bt(this, params.b(), null);
    if (paramProperties == null) {
      super.e = new Properties();
    } else {
      super.e = paramProperties;
    } 
    String str = (String)paramProperties.get("LanguageCode");
    this.a = (str == null) ? ao.q() : str;
    paramProperties.remove("LanguageCode");
    Integer integer1 = (Integer)paramProperties.get("PacketType");
    super.j = (integer1 == null) ? ao.m() : integer1.intValue();
    Integer integer2 = (Integer)paramProperties.get("NumberParameter");
    super.i = (integer2 == null) ? ao.h() : integer2.intValue();
    Boolean bool = (Boolean)paramProperties.get("ServerLogon");
    super.m = (bool == null) ? ao.p() : bool.booleanValue();
    if (super.m)
      try {
        a(super.m);
      } catch (Exception exception) {} 
    Integer integer3 = (Integer)paramProperties.get("RPCError");
    super.f = (integer3 == null) ? 0 : integer3.intValue();
    paramProperties.remove("RPCError");
    Integer integer4 = (Integer)paramProperties.get("UserError");
    super.g = (integer4 == null) ? 0 : integer4.intValue();
    paramProperties.remove("UserError");
    paramProperties.remove("NaturalErrorLine");
    paramProperties.remove("NaturalErrorProgram");
    paramProperties.remove("NaturalDynError");
    c(0);
    d(92);
    t();
    b(paramArrayOfByte1);
    e(af() + ag());
    e(paramArrayOfByte2);
    i(ad() + ae());
    byte[] arrayOfByte1 = new byte[92 + ag() + ae() + ai()];
    g(arrayOfByte1);
    System.arraycopy(x(), 0, arrayOfByte1, af(), ag());
    if (w())
      System.arraycopy(v(), 0, arrayOfByte1, ad(), ae()); 
    if (aa())
      System.arraycopy(z(), 0, arrayOfByte1, ah(), ai()); 
    byte[] arrayOfByte2 = u();
    for (byte b1 = 0; b1 < 92; b1++)
      arrayOfByte2[b1] = params.j; 
    if (super.o == null || super.o.b() == null) {
      System.arraycopy("2000*RPC*".getBytes(), 0, u(), 0, 9);
    } else {
      try {
        System.arraycopy("2000*RPC*".getBytes(params.b()), 0, u(), 0, 9);
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        System.arraycopy("2000*RPC*".getBytes(), 0, u(), 0, 9);
      } 
    } 
    s();
    a(ak(), u(), 69, 4);
    a(al(), u(), 73, 4);
    a(h(), 0, arrayOfByte2, 77, 3);
    a(m(g()), 0, arrayOfByte2, 80, 2);
    a(k(), arrayOfByte2, 82, 10);
    Dump.dumpBytes("RPCMessage2000: RPC Header:", u(), u().length, 4);
    System.arraycopy(u(), 0, arrayOfByte1, ab(), ac());
  }
  
  protected int a() { return 2000; }
  
  protected int b() { return 92; }
  
  protected int c() { return 0; }
  
  public String d() {
    String str = null;
    if (super.e != null)
      str = (String)super.e.get("LB"); 
    if (str == null)
      str = ""; 
    return str;
  }
  
  public void a(String paramString) {
    if (super.e == null)
      super.e = new Properties(); 
    super.e.put("LB", paramString);
  }
  
  public String e() {
    String str = null;
    if (super.e != null)
      str = (String)super.e.get("PM"); 
    if (str == null)
      str = ""; 
    return str;
  }
  
  public void b(String paramString) {
    if (super.e == null)
      super.e = new Properties(); 
    super.e.put("PM", paramString);
  }
  
  public String f() {
    String str = null;
    if (super.e != null)
      str = (String)super.e.get("UID"); 
    if (str == null)
      str = ""; 
    return str;
  }
  
  public void c(String paramString) {
    if (super.e == null)
      super.e = new Properties(); 
    super.e.put("UID", paramString);
  }
  
  public int g() { return super.j; }
  
  public void a(int paramInt) {
    super.j = paramInt;
    a(m(super.j), 0, u(), 80, 2);
  }
  
  public String h() {
    String str = this.a;
    if (str == null)
      str = ""; 
    return str;
  }
  
  public void d(String paramString) {
    if (paramString.length() > 3)
      throw new be(7, "language code longer than 3 characters"); 
    this.a = paramString;
    a(this.a, 0, u(), 77, 3);
  }
  
  public boolean i() {
    String str = (String)super.e.get("NS");
    super.m = (str != null);
    return super.m;
  }
  
  public void a(boolean paramBoolean) throws BrokerException {
    super.m = paramBoolean;
    super.e.put("NS", new String(bu.a((String)super.e.get("LB"), (String)super.e.get("UID"), am())));
  }
  
  public int j() { return 2; }
  
  public void b(int paramInt) {}
  
  public void b(boolean paramBoolean) throws BrokerException {}
  
  public long k() { return super.i; }
  
  public void a(long paramLong) {
    super.i = paramLong;
    a(super.i, u(), 82, 10);
  }
  
  private int a(byte[] paramArrayOfByte, int paramInt) {
    byte b1 = 0;
    return a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bt.a(this.z)) ? 5 : (a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bt.b(this.z)) ? 2 : (a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bt.c(this.z)) ? 2 : (a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bt.d(this.z)) ? 1 : (a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bt.e(this.z)) ? 3 : (a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bt.f(this.z)) ? 4 : (a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bt.g(this.z)) ? 7 : (a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bt.h(this.z)) ? 6 : b1)))))));
  }
  
  private byte[] m(int paramInt) {
    byte[] arrayOfByte = null;
    switch (paramInt) {
      case 4:
        arrayOfByte = com/softwareag/entirex/aci/bt.f(this.z);
        break;
      case 3:
        arrayOfByte = com/softwareag/entirex/aci/bt.e(this.z);
        break;
      case 7:
        arrayOfByte = com/softwareag/entirex/aci/bt.g(this.z);
        break;
      case 6:
        arrayOfByte = com/softwareag/entirex/aci/bt.h(this.z);
        break;
      case 2:
        arrayOfByte = com/softwareag/entirex/aci/bt.b(this.z);
        break;
      case 5:
        arrayOfByte = com/softwareag/entirex/aci/bt.a(this.z);
        break;
      case 1:
        arrayOfByte = com/softwareag/entirex/aci/bt.d(this.z);
        break;
    } 
    return arrayOfByte;
  }
  
  protected int l() { return 80; }
  
  protected int m() { return 2; }
  
  protected int n() { return 69; }
  
  protected int o() { return 4; }
  
  protected int p() { return 73; }
  
  protected int q() { return 4; }
  
  protected String r() {
    String str1 = "";
    String str2 = "";
    if (super.e != null)
      str1 = (String)super.e.get("ET"); 
    if (str1 != null) {
      str2 = ", ";
    } else {
      str1 = "";
    } 
    return "User error: " + super.g + str2 + str1;
  }
  
  protected void s() {
    a(af(), u(), 9, 10);
    a(ag(), u(), 19, 10);
    a(ah(), u(), 49, 10);
    a(ai(), u(), 59, 10);
    a(ad(), u(), 29, 10);
    a(ae(), u(), 39, 10);
  }
  
  public void t() {
    byte[] arrayOfByte;
    String str1 = null;
    String str2 = null;
    StringBuffer stringBuffer = new StringBuffer();
    Enumeration enumeration = super.e.propertyNames();
    while (enumeration.hasMoreElements()) {
      str1 = (String)enumeration.nextElement();
      str2 = super.e.getProperty(str1);
      if (str2 instanceof String) {
        stringBuffer.append(str1);
        stringBuffer.append("=");
        stringBuffer.append(Integer.toString(str2.length()));
        stringBuffer.append(",");
        stringBuffer.append(str2);
      } 
    } 
    if (super.o == null || super.o.b() == null) {
      arrayOfByte = stringBuffer.toString().getBytes();
    } else {
      try {
        arrayOfByte = stringBuffer.toString().getBytes(super.o.b());
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        arrayOfByte = stringBuffer.toString().getBytes();
      } 
    } 
    int i1 = ag();
    d(arrayOfByte);
    g(ab() + b());
    if (aj() != null && ag() > 0) {
      byte[] arrayOfByte1 = new byte[aj().length + arrayOfByte.length - i1];
      System.arraycopy(aj(), 0, arrayOfByte1, 0, af());
      System.arraycopy(x(), 0, arrayOfByte1, af(), ag());
      System.arraycopy(aj(), af() + i1, arrayOfByte1, af() + ag(), aj().length - af() - i1);
      g(arrayOfByte1);
      e(af() + ag());
      i(ad() + ae());
      s();
    } 
  }
  
  public void a(String paramString1, String paramString2) {}
  
  public void e(String paramString) {}
  
  class com/softwareag/entirex/aci/eu {}
  
  private class com/softwareag/entirex/aci/bt {
    private byte[] a;
    
    private byte[] b;
    
    private byte[] c;
    
    private byte[] d;
    
    private byte[] e;
    
    private byte[] f;
    
    private byte[] g;
    
    private byte[] h;
    
    private final bq i;
    
    private com/softwareag/entirex/aci/bt(bq this$0) {
      this.i = this$0;
      this.a = "OC".getBytes();
      this.b = "CC".getBytes();
      this.c = "  ".getBytes();
      this.d = "CE".getBytes();
      this.e = "CB".getBytes();
      this.f = "CO".getBytes();
      this.g = "IN".getBytes();
      this.h = "NC".getBytes();
      this.a = "OC".getBytes();
      this.b = "CC".getBytes();
      this.c = "  ".getBytes();
      this.d = "CE".getBytes();
      this.e = "CB".getBytes();
      this.f = "CO".getBytes();
      this.g = "IN".getBytes();
      this.h = "NC".getBytes();
    }
    
    private com/softwareag/entirex/aci/bt(bq this$0, String param1String) {
      this(this$0);
      try {
        this.a = "OC".getBytes(param1String);
        this.b = "CC".getBytes(param1String);
        this.c = "  ".getBytes(param1String);
        this.d = "CE".getBytes(param1String);
        this.e = "CB".getBytes(param1String);
        this.f = "CO".getBytes(param1String);
        this.g = "IN".getBytes(param1String);
        this.h = "NC".getBytes(param1String);
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
      
      } catch (NullPointerException nullPointerException) {}
    }
    
    com/softwareag/entirex/aci/bt(bq this$0, bq.com/softwareag/entirex/aci/eu param1com/softwareag/entirex/aci/eu) { this(this$0); }
    
    com/softwareag/entirex/aci/bt(bq this$0, String param1String, bq.com/softwareag/entirex/aci/eu param1com/softwareag/entirex/aci/eu) { this(this$0, param1String); }
    
    static byte[] a(com/softwareag/entirex/aci/bt param1com/softwareag/entirex/aci/bt) { return param1com/softwareag/entirex/aci/bt.h; }
    
    static byte[] b(com/softwareag/entirex/aci/bt param1com/softwareag/entirex/aci/bt) { return param1com/softwareag/entirex/aci/bt.b; }
    
    static byte[] c(com/softwareag/entirex/aci/bt param1com/softwareag/entirex/aci/bt) { return param1com/softwareag/entirex/aci/bt.c; }
    
    static byte[] d(com/softwareag/entirex/aci/bt param1com/softwareag/entirex/aci/bt) { return param1com/softwareag/entirex/aci/bt.a; }
    
    static byte[] e(com/softwareag/entirex/aci/bt param1com/softwareag/entirex/aci/bt) { return param1com/softwareag/entirex/aci/bt.d; }
    
    static byte[] f(com/softwareag/entirex/aci/bt param1com/softwareag/entirex/aci/bt) { return param1com/softwareag/entirex/aci/bt.e; }
    
    static byte[] g(com/softwareag/entirex/aci/bt param1com/softwareag/entirex/aci/bt) { return param1com/softwareag/entirex/aci/bt.g; }
    
    static byte[] h(com/softwareag/entirex/aci/bt param1com/softwareag/entirex/aci/bt) { return param1com/softwareag/entirex/aci/bt.f; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\bq.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */