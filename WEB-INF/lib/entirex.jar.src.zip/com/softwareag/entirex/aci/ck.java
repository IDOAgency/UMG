package com.softwareag.entirex.aci;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ck implements ActionListener {
  private final Tester2 a;
  
  ck(Tester2 paramTester2) { this.a = paramTester2; }
  
  public void actionPerformed(ActionEvent paramActionEvent) { Tester2.b(this.a, true); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\ck.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */