package com.softwareag.entirex.aci;

public interface c {
  public static final String a = "entirex.server.usecodepage";
  
  public static final String b = "entirex.server.codepage";
  
  public static final String c = "entirex.location.transparency.config";
  
  public static final String d = "entirex.location.transparency.ini";
  
  public static final String e = "entirex.server.logicalsetname";
  
  public static final String f = "entirex.server.brokerid";
  
  public static final String g = "entirex.server.logicalbrokerid";
  
  public static final String h = "entirex.server.serveraddress";
  
  public static final String i = "entirex.server.logicalservice";
  
  public static final String j = "entirex.server.userid";
  
  public static final String k = "entirex.server.password";
  
  public static final String l = "entirex.server.passwordencrypt";
  
  public static final String m = "entirex.server.waitattach";
  
  public static final String n = "entirex.server.waitserver";
  
  public static final String o = "entirex.server.security";
  
  public static final String p = "entirex.server.encryptionlevel";
  
  public static final String q = "entirex.server.encryption";
  
  public static final String r = "entirex.server.compresslevel";
  
  public static final String s = "entirex.server.maxservers";
  
  public static final String t = "entirex.server.minservers";
  
  public static final String u = "entirex.server.verbose";
  
  public static final String v = "entirex.server.fixedservers";
  
  public static final String w = "entirex.server.environment";
  
  public static final String x = "entirex.server.properties";
  
  public static final String y = "entirex.server.logfile";
  
  public static final String z = "entirex.server.serverlog";
  
  public static final String aa = "entirex.server.restartcycles";
  
  public static final String ab = "entirex.timeout";
  
  public static final String ac = "entirex.trace";
  
  public static final String ad = "entirex.server.name";
  
  public static final String ae = "entirex.server.monitorport";
  
  public static final String af = "entirex.server.monitorremote";
  
  int b(String paramString);
  
  boolean c(String paramString);
  
  String d(String paramString);
  
  int k();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\c.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */