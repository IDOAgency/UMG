package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.ac;
import com.softwareag.entirex.base.r;
import com.softwareag.entirex.base.s;
import java.text.MessageFormat;
import java.util.Hashtable;

public class bl {
  private static final int a = 0;
  
  private static final int b = 4;
  
  private static final int c = 12;
  
  private static final int d = 5;
  
  private static final int e = 17;
  
  private static final int f = 4;
  
  private static final int g = 21;
  
  private static final int h = 1;
  
  private static final int i = 22;
  
  private static final int j = 8;
  
  private static final int k = 30;
  
  private static final int l = 2;
  
  private static final int m = 69;
  
  private static final int n = 4;
  
  private static final int o = 73;
  
  private static final int p = 4;
  
  private static final int q = 69;
  
  private static final int r = 4;
  
  private static final int s = 32;
  
  private static final int t = 8;
  
  private static final int u = 40;
  
  private static final int v = 8;
  
  private static final int w = 77;
  
  private static final int x = 89;
  
  private static final int y = 9;
  
  private static final int z = 19;
  
  private static final String aa = "0000";
  
  private static final String ab = "0016";
  
  private static final String ac = "0018";
  
  private static final String ad = "0035";
  
  private static final String ae = "0036";
  
  private static final String af = "0037";
  
  private static final Hashtable ag = new Hashtable();
  
  private String ah = null;
  
  private static final String[] ai = { "ET", "EC" };
  
  private static final byte[] aj = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57 };
  
  private static final byte[] ak = { -16, -15, -14, -1, -12, -11, -10, -9, -8, -7 };
  
  void a(RPCService paramRPCService) { this.ah = (paramRPCService == null) ? null : (paramRPCService.getBroker().getBrokerID() + "@" + paramRPCService.toString() + "@" + paramRPCService.getLibraryName()); }
  
  public void a(byte[] paramArrayOfByte, s params) throws BrokerException { a(paramArrayOfByte, null, null, params); }
  
  public void a(byte[] paramArrayOfByte, String paramString1, String paramString2, s params) throws BrokerException {
    String str1 = "";
    int i1 = b(paramArrayOfByte, params);
    if (i1 == 0)
      BrokerException.a("0203", new String[] { new String(paramArrayOfByte, 0, 4) }); 
    byte b1 = (i1 < 2000) ? 69 : 69;
    byte b2 = (i1 < 2000) ? 4 : 4;
    int i2 = a(paramArrayOfByte, b1, b2, params);
    String str2 = new String(paramArrayOfByte, b1, b2);
    b1 = (i1 < 2000) ? 12 : 73;
    b2 = (i1 < 2000) ? 5 : 4;
    String str3 = new String(paramArrayOfByte, b1, b2);
    if (str3 != null && str3.length() == 5 && str3.charAt(0) == '0')
      str3 = str3.substring(1); 
    int i3 = ac.a(paramArrayOfByte, b1, b2, params);
    String str4 = "0000";
    String str5 = "0000";
    String str6 = null;
    String str7 = null;
    String str8 = null;
    if (i2 != 0 || i3 != 0) {
      String[] arrayOfString = a(paramArrayOfByte, i1, params);
      str6 = arrayOfString[0];
      str7 = arrayOfString[1];
      str8 = arrayOfString[2];
    } 
    if (i1 >= 2000) {
      switch (i2) {
        case 0:
          if (i3 > 0) {
            str1 = "NATUARL RPC Server returns: " + str6;
            str4 = "1014";
            str5 = str3;
          } 
          break;
        case 7:
          if (str7 != null && str8 != null) {
            str4 = str7;
            str5 = str8;
          } else {
            str4 = "1001";
            str5 = str2;
          } 
          str1 = str6;
          break;
        case 16:
          str1 = "Callee not found. Library: " + paramString1 + ", Program: " + paramString2 + str6;
          str4 = "1001";
          str5 = str2;
          break;
        case 5:
        case 8:
        case 9:
        case 10:
        case 11:
        case 12:
        case 18:
        case 24:
        case 25:
        case 26:
        case 27:
        case 28:
        case 31:
        case 34:
          str1 = str6;
          str4 = "1001";
          str5 = str2;
          break;
        case 17:
          str1 = str6;
          str4 = "1002";
          str5 = str3;
          break;
        case 20:
          str1 = "EntireX C RPC Server returns: " + str6;
          str4 = "1005";
          str5 = str3;
          break;
        case 32:
          str1 = "EntireX 3270 CICS Bridge returns:  " + str6;
          str4 = "1012";
          str5 = str3;
          break;
        case 38:
          str1 = "EntireX Java RPC Server returns:  " + str6;
          str4 = "1015";
          str5 = str3;
          break;
        case 2000:
          str1 = "EntireX Java XML RPC Server / XML Runtime returns: " + str6;
          str4 = "2000";
          str5 = str3;
          break;
        default:
          str1 = "Unknown error from partner, user error code: " + str3 + " " + str6;
          str4 = "1001";
          str5 = str2;
          break;
      } 
    } else {
      String str9 = (new String(paramArrayOfByte, 32, 8)).trim();
      String str10 = (new String(paramArrayOfByte, 40, 8)).trim();
      switch (i2) {
        case 0:
          switch (i3) {
            case 0:
              break;
            case 82:
              str1 = "Callee not found. Library: " + str9 + ", Program: " + str10 + a(str3, paramArrayOfByte);
              str4 = "1001";
              str5 = "0016";
              break;
            case 954:
              str1 = "Abnormal termination during program execution. Library: " + str9 + ", Program: " + str10 + a(str3, paramArrayOfByte);
              str4 = "1001";
              str5 = "0018";
              break;
          } 
          str1 = "Natural RPC Errors, see the Natural documentation under NATnnnn" + a(str3, paramArrayOfByte);
          str4 = "1014";
          str5 = str3;
          break;
        case 4:
          switch (i3) {
            case 0:
              str1 = "send data exceeds MAX_BUFF definition";
              str4 = "1001";
              str5 = "0004";
              break;
            case 6971:
              str1 = "Natural RPC Error, see the Natural documentation under NAT6971" + a(str3, paramArrayOfByte);
              str4 = "1014";
              str5 = "6971";
              break;
          } 
          break;
        case 5:
          str1 = "RPC working buffer too small";
          str4 = "1001";
          str5 = "0005";
          break;
        case 7:
          if (str7 != null && str8 != null) {
            str4 = str7;
            str5 = str8;
            str1 = str6;
            break;
          } 
          str4 = "1001";
          str5 = "0007";
          str1 = "internal error";
          break;
        case 8:
          switch (i3) {
            case 0:
              str1 = "invalid protocol version";
              str4 = "1001";
              str5 = "0008";
              break;
            case 6978:
              str1 = "Natural RPC Error, see the Natural documentation under NAT6978" + a(str3, paramArrayOfByte);
              str4 = "1014";
              str5 = "6978";
              break;
          } 
          break;
        case 9:
          str1 = "invalid format buffer";
          str4 = "1001";
          str5 = "0009";
          break;
        case 10:
          str1 = "invalid value buffer";
          str4 = "1001";
          str5 = "0010";
          break;
        case 11:
          str1 = "invalid call type";
          str4 = "1001";
          str5 = "0011";
          break;
        case 12:
          switch (i3) {
            case 0:
              str1 = "authorization or initialization failed";
              str4 = "1001";
              str5 = "0008";
              break;
            case 6975:
              str1 = "security error" + a(str3, paramArrayOfByte);
              str4 = "1014";
              str5 = "6975";
              break;
          } 
          break;
        case 16:
          str1 = "cannot find user program";
          str4 = "1001";
          str5 = "0016";
          break;
        case 20:
        case 35:
          str1 = "conversation already open";
          str4 = "1001";
          str5 = "0035";
          break;
        case 21:
        case 36:
          str1 = "conversation already closed";
          str4 = "1001";
          str5 = "0036";
          break;
        case 22:
        case 23:
        case 37:
          str1 = "nonconversational request rejected due to an open conversation";
          str4 = "1001";
          str5 = "0037";
          break;
        case 30:
          str1 = "invalid architecture byte";
          break;
        case 2000:
          str1 = "Error from EntireX Java XML RPC Server / XML Runtime returned.";
          str4 = "2000";
          str5 = str3;
          break;
        default:
          str1 = MessageFormat.format("rpcCall: error {0} returned from server application for program {1} in library {2}", new String[] { str2, str10, str9 });
          str4 = "0013";
          str5 = "0214";
          break;
      } 
      if (str6 != null && !str1.equals(str6))
        str1 = str1 + " (" + str6 + ")"; 
    } 
    if (i2 > 0 || i3 > 0)
      if (str4.equals("0000")) {
        BrokerException.a("0204", new String[] { str1 });
      } else {
        throw new BrokerException(str4, str5, str1, null, null);
      }  
  }
  
  int a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString, BrokerService paramBrokerService) throws BrokerException {
    int i1 = 0;
    if (paramInt3 == -1 && this.ah != null) {
      Integer integer = (Integer)ag.get(this.ah);
      if (integer != null) {
        paramInt3 = integer.intValue();
      } else {
        try {
          ao ao = ao.a(paramString, paramBrokerService.getEncodingConstants());
          BrokerMessage brokerMessage = new BrokerMessage(ao.d());
          brokerMessage = paramBrokerService.sendReceive(brokerMessage);
          paramInt3 = ao.b(brokerMessage.getMessage(), paramBrokerService.getEncodingConstants());
          ag.put(this.ah, new Integer(paramInt3));
          if (Dump.c)
            if (paramInt3 == 0 || paramInt3 == 1130) {
              Dump.log("Connected to pre-1140 version of a RPC Server");
            } else {
              Dump.log("Connected to " + ao.f());
              Dump.log("Maximum version supported by RPC Server is " + paramInt3);
            }  
        } catch (BrokerException brokerException) {
          if (brokerException.getErrorClass() != 1001 && (brokerException.getErrorClass() != 1014 || brokerException.getErrorCode() != 6975) && (brokerException.getErrorClass() != 13 || brokerException.getErrorCode() < 200 || brokerException.getErrorCode() >= 300))
            throw brokerException; 
          if (brokerException.getErrorClass() == 1001 && brokerException.getErrorCode() == 16)
            throw brokerException; 
        } 
      } 
    } 
    switch (paramInt3) {
      case 1140:
      case 2000:
        break;
      default:
        paramInt3 = (paramInt3 > paramInt4) ? paramInt4 : 0;
        break;
    } 
    if ((paramInt3 == 0 && paramInt1 >= 1140) || (paramInt3 > 0 && paramInt1 > paramInt3))
      BrokerException.a("0213", new String[] { Integer.toString(paramInt1) }); 
    if (paramInt2 == 1130) {
      if (paramInt1 > 1130) {
        BrokerException.a("0213", new String[] { Integer.toString(paramInt1) });
      } else if (i1 != paramInt1) {
        i1 = paramInt1;
      } 
    } else {
      if (paramInt2 == 1110 && paramInt1 <= 1130)
        i1 = paramInt1; 
      if (paramInt2 == 1140 && paramInt1 <= 1140)
        i1 = paramInt1; 
    } 
    if (i1 == 0) {
      i1 = (paramInt3 > paramInt1) ? paramInt3 : paramInt1;
    } else if (paramInt1 > i1) {
      i1 = paramInt1;
    } 
    if (Dump.c)
      Dump.log("Using RPC version " + i1); 
    return i1;
  }
  
  int b(byte[] paramArrayOfByte, s params) {
    int i1 = 0;
    try {
      i1 = ac.a(paramArrayOfByte, 0, 4, params);
    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
    switch (i1) {
      case 1110:
      case 1120:
      case 1130:
      case 1140:
      case 2000:
        return i1;
    } 
    i1 = 0;
  }
  
  private String[] a(byte[] paramArrayOfByte, int paramInt, s params) {
    String str1 = null;
    String str2 = null;
    String str3 = null;
    int i1 = 0;
    int i2 = 0;
    if (paramInt <= 1140) {
      i1 = ac.a(paramArrayOfByte, 77, 6, params);
      i2 = ac.a(paramArrayOfByte, 89, 6, params);
    } else if (paramInt == 2000) {
      i1 = ac.a(paramArrayOfByte, 9, 10, params);
      i2 = ac.a(paramArrayOfByte, 19, 10, params);
    } 
    r r1 = new r(paramArrayOfByte, i1, i2, ai, params);
    while (r1.a()) {
      int i3 = r1.c();
      int i4 = r1.e();
      if (i3 == 0) {
        str1 = r1.a(i4);
        continue;
      } 
      if (i3 == 1) {
        str2 = r1.a(i4);
        str3 = str2.substring(0, 4);
        str2 = str2.substring(4);
        continue;
      } 
      r1.b(i4);
    } 
    return new String[] { str1, str3, str2 };
  }
  
  private String a(String paramString, byte[] paramArrayOfByte) {
    String str = "";
    if (paramArrayOfByte[21] != 32)
      str = MessageFormat.format(", (NATURAL Error Info: Program={2},Error={0},Line={1},Status={3},Level={4})", new String[] { paramString, new String(paramArrayOfByte, 17, 4), (new String(paramArrayOfByte, 22, 8)).trim(), new String(paramArrayOfByte, 21, 1), new String(paramArrayOfByte, 30, 2) }); 
    return str;
  }
  
  private int a(byte[] paramArrayOfByte, int paramInt1, int paramInt2, s params) throws BrokerException {
    int i1 = 0;
    try {
      i1 = ac.a(paramArrayOfByte, paramInt1, paramInt2, params);
    } catch (NumberFormatException numberFormatException) {
      try {
        i1 = ac.a(a(paramArrayOfByte, paramInt1, paramInt2), params);
        throw new BrokerException("1001", "0039", " error code converted to ASCII, error code is " + i1, null, null);
      } catch (NumberFormatException numberFormatException1) {
        try {
          i1 = ac.a(b(paramArrayOfByte, paramInt1, paramInt2), params);
          throw new BrokerException("1001", "0039", " error code converted to EBCDIC, error code is " + i1, null, null);
        } catch (NumberFormatException numberFormatException2) {
          throw new BrokerException("1001", "0040", " error code can not be decoded.", null, null);
        } 
      } 
    } 
    return i1;
  }
  
  private byte[] a(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    for (byte b1 = 0; b1 < paramArrayOfByte.length; b1++) {
      for (byte b2 = 0; b2 < ak.length; b2++) {
        if (paramArrayOfByte[b1] == ak[b2]) {
          paramArrayOfByte[b1] = aj[b2];
          break;
        } 
      } 
    } 
    return paramArrayOfByte;
  }
  
  private byte[] b(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    for (byte b1 = 0; b1 < paramArrayOfByte.length; b1++) {
      for (byte b2 = 0; b2 < aj.length; b2++) {
        if (paramArrayOfByte[b1] == aj[b2]) {
          paramArrayOfByte[b1] = ak[b2];
          break;
        } 
      } 
    } 
    return paramArrayOfByte;
  }
  
  static String a(int paramInt) {
    String str;
    if (paramInt >= 0 && paramInt < 10) {
      str = "000" + Integer.toString(paramInt);
    } else if (paramInt >= 10 && paramInt < 100) {
      str = "00" + Integer.toString(paramInt);
    } else if (paramInt >= 100 && paramInt < 1000) {
      str = "0" + Integer.toString(paramInt);
    } else if (paramInt >= 1000 && paramInt < 10000) {
      str = Integer.toString(paramInt);
    } else {
      str = "****";
    } 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\bl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */