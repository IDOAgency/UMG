package com.softwareag.entirex.aci;

public abstract class BrokerCommunication {
  private q a;
  
  protected BrokerService b;
  
  private String c;
  
  boolean d;
  
  private String e;
  
  private byte[] f;
  
  boolean g;
  
  String h = null;
  
  String i;
  
  String j;
  
  int k = 0;
  
  String l;
  
  int m;
  
  String n;
  
  String o;
  
  boolean p = false;
  
  public BrokerService getBrokerService() { return this.b; }
  
  public byte[] getUserData() { return this.f; }
  
  public void setUserData(byte[] paramArrayOfByte) {
    if (paramArrayOfByte != null && paramArrayOfByte.length > 16)
      throw new IllegalArgumentException("setUserData: length exceeds 16 Bytes"); 
    this.f = paramArrayOfByte;
  }
  
  BrokerCommunication(BrokerService paramBrokerService) {
    this.b = paramBrokerService;
    this.c = "NEW";
    this.d = true;
    this.a = paramBrokerService.getBroker().a();
  }
  
  BrokerCommunication(BrokerService paramBrokerService, String paramString) throws BrokerException {
    this.b = paramBrokerService;
    this.c = paramString;
    this.d = false;
    this.a = paramBrokerService.getBroker().a();
  }
  
  BrokerCommunication(BrokerService paramBrokerService, ConversationState paramConversationState) throws IllegalArgumentException {
    this.b = paramBrokerService;
    if (paramConversationState == null)
      throw new IllegalArgumentException("ConversationState object is null"); 
    this.c = paramConversationState.a();
    this.d = false;
    this.a = paramBrokerService.getBroker().a();
  }
  
  public ConversationState saveState() throws IllegalArgumentException { return new ConversationState(this.c); }
  
  void a(BrokerService paramBrokerService) {
    this.b = paramBrokerService;
    this.a = paramBrokerService.getBroker().a();
  }
  
  public void dispose() throws BrokerException {}
  
  void a(byte[] paramArrayOfByte) {
    if (this.d)
      BrokerException.a("0111", null); 
    synchronized (this.a) {
      this.a.u();
      if (this.g)
        this.a.f(this.o); 
      this.a.c(this.c, paramArrayOfByte);
    } 
  }
  
  void b(byte[] paramArrayOfByte) {
    if (this.d)
      BrokerException.a("0112", null); 
    synchronized (this.a) {
      this.a.u();
      this.a.d(this.c, paramArrayOfByte);
    } 
  }
  
  BrokerMessage a(BrokerMessage paramBrokerMessage, String paramString, boolean paramBoolean, byte[] paramArrayOfByte) throws BrokerException {
    if (paramBrokerMessage == null)
      throw new IllegalArgumentException("send: no message"); 
    synchronized (this.a) {
      this.a.u();
      if (this.d)
        this.a.a(this.b); 
      if (!paramBoolean) {
        this.a.h(paramString);
        this.a.a(this.b.getMaxReceiveLen());
        this.a.a(this.b.d());
      } 
      this.a.a(paramBrokerMessage.getMessage());
      this.a.b(this.b.getEnvironment());
      this.a.b(this.f);
      if (this.g) {
        this.a.f(this.o);
        this.a.c(this.h);
        if (this.j != null)
          this.a.d(this.j); 
        this.a.b(this.k);
        this.a.g(this.l);
        if (this.p)
          this.a.e(this.n); 
      } 
      this.a.a(this.c, paramBoolean, paramArrayOfByte);
      String str = this.a.g();
      if (this.d) {
        this.c = str;
        this.d = false;
      } else if (!str.equals(this.c)) {
        BrokerException.a("0113", new String[] { this.c, str });
      } 
      if (this.g) {
        this.i = this.a.n();
        this.n = this.a.o();
        this.h = this.a.m();
        this.o = this.a.p();
      } 
      if (paramBoolean)
        return null; 
      BrokerMessage brokerMessage = new BrokerMessage();
      brokerMessage.setMessage(this.a.a());
      brokerMessage.a(this.b);
      brokerMessage.a(this.g ? (UnitofWork)this : null);
      brokerMessage.a(this.g ? null : (Conversation)this);
      if (this.b.d())
        this.b.setMaxReceiveLen(Math.max(this.b.getMaxReceiveLen(), this.a.b())); 
      return brokerMessage;
    } 
  }
  
  BrokerMessage a(String paramString, byte[] paramArrayOfByte) throws BrokerException {
    synchronized (this.a) {
      this.a.u();
      if (this.d)
        this.a.a(this.b); 
      this.a.h(paramString);
      this.a.b(this.b.getEnvironment());
      this.a.b(this.f);
      if (this.g) {
        this.a.e(this.n);
        this.a.f(this.o);
      } 
      if (paramArrayOfByte == null)
        if (this.g) {
          paramArrayOfByte = q.a2;
        } else {
          paramArrayOfByte = q.ar;
        }  
      int i1 = this.b.getMaxReceiveLen();
      this.a.a(i1);
      boolean bool = this.b.d();
      this.a.a(bool);
      this.a.b(this.c, paramArrayOfByte);
      if (bool)
        this.b.setMaxReceiveLen(Math.max(i1, this.a.b())); 
      String str = this.a.g();
      if (this.d) {
        this.c = str;
        this.d = false;
      } else if (!str.equals(this.c)) {
        BrokerException.a("0114", new String[] { this.c, str });
      } 
      this.e = this.a.l();
      this.f = this.a.j();
      if (this.g) {
        this.i = this.a.n();
        this.n = this.a.o();
        this.h = this.a.m();
        this.o = this.a.p();
        this.m = this.a.i();
      } 
      BrokerMessage brokerMessage = new BrokerMessage();
      brokerMessage.setMessage(this.a.a());
      brokerMessage.a(this.b);
      brokerMessage.a(this.a.k());
      brokerMessage.a(this.g ? (UnitofWork)this : null);
      brokerMessage.a(this.g ? null : (Conversation)this);
      return brokerMessage;
    } 
  }
  
  void c(byte[] paramArrayOfByte) {
    if (this.d)
      BrokerException.a("0115", new String[] { new String(paramArrayOfByte) }); 
    synchronized (this.a) {
      this.a.u();
      if (paramArrayOfByte == q.a5) {
        paramArrayOfByte = q.az;
        this.a.e("BOTH");
      } else {
        this.a.e(this.n);
      } 
      this.a.f(this.o);
      this.a.e(this.c, paramArrayOfByte);
      this.i = this.a.n();
      this.o = this.a.p();
      this.m = this.a.i();
    } 
  }
  
  static UnitofWork a(boolean paramBoolean, String paramString, BrokerService paramBrokerService) throws BrokerException {
    if (!paramBoolean && paramString == null)
      throw new IllegalArgumentException("query: no UOWID specified"); 
    q q1 = paramBrokerService.getBroker().a();
    synchronized (q1) {
      q1.u();
      q1.a(paramBrokerService);
      q1.e(paramString);
      if (paramBoolean) {
        try {
          q1.e(null, q.aw);
        } catch (BrokerException brokerException) {
          if (brokerException.getErrorClass() == 78 && brokerException.getErrorCode() == 305)
            return null; 
          throw brokerException;
        } 
      } else {
        q1.e(null, q.a3);
      } 
      String str = q1.g();
      UnitofWork unitofWork1 = new UnitofWork(paramBrokerService);
      UnitofWork unitofWork2 = unitofWork1;
      unitofWork2.c = str;
      unitofWork2.d = false;
      unitofWork1.n = q1.o();
      unitofWork1.i = q1.n();
      unitofWork1.o = q1.p();
      unitofWork1.m = q1.i();
      return unitofWork1;
    } 
  }
  
  static UnitofWork a(boolean paramBoolean, String paramString, Broker paramBroker) throws BrokerException {
    if (!paramBoolean && paramString == null)
      throw new IllegalArgumentException("query: no UOWID specified"); 
    q q1 = paramBroker.a();
    synchronized (q1) {
      q1.u();
      q1.e(paramString);
      if (paramBoolean) {
        try {
          q1.e(null, q.aw);
        } catch (BrokerException brokerException) {
          if (brokerException.getErrorClass() == 78 && brokerException.getErrorCode() == 305)
            return null; 
          throw brokerException;
        } 
      } else {
        q1.e(null, q.a3);
      } 
      String str = q1.g();
      BrokerService brokerService = new BrokerService(paramBroker, q1.c(), q1.d(), q1.e());
      UnitofWork unitofWork1 = new UnitofWork(brokerService);
      UnitofWork unitofWork2 = unitofWork1;
      unitofWork2.c = str;
      unitofWork2.d = false;
      unitofWork1.n = q1.o();
      unitofWork1.i = q1.n();
      unitofWork1.o = q1.p();
      unitofWork1.m = q1.i();
      return unitofWork1;
    } 
  }
  
  static void a(String paramString, Broker paramBroker) throws BrokerException {
    q q1 = paramBroker.a();
    synchronized (q1) {
      q1.u();
      q1.e(paramString);
      q1.e(null, q.a4);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\BrokerCommunication.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */