package com.softwareag.entirex.aci;

import java.io.IOException;

final class ah {
  private static final String a = "EC=00000000,TXT=";
  
  private static final String b = "EC=00000000,TXT=                                        ";
  
  private static final String c = "EC=00000000,TXT=                                        ,CID=0000000000000000";
  
  private static final String d = "EC=00000000,TXT=                                        ,RETL=00000000";
  
  private static final String e = "EC=00000000,TXT=                                        ,CID=0000000000000000,RETL=00000000";
  
  private static final int f = 14;
  
  private static String g;
  
  private int h = 0;
  
  private int i = 0;
  
  private int j = 0;
  
  private int k = 0;
  
  private int l = 0;
  
  private int m = 0;
  
  private int n = 0;
  
  private int o = 0;
  
  private int p = 0;
  
  private int q = 0;
  
  private int r;
  
  private short s = 0;
  
  private short t = 1;
  
  private int u = 0;
  
  private String v = null;
  
  private String w = null;
  
  private String x = null;
  
  private String y = null;
  
  private byte[] z = null;
  
  private byte[] aa = null;
  
  private byte[] ab = null;
  
  private byte[] ac = null;
  
  private char[] ad = null;
  
  private boolean ae = false;
  
  private int af;
  
  private int ag;
  
  private int ah = 0;
  
  private int ai;
  
  static void a(String paramString) throws IOException {
    String str = System.getProperty("os.name");
    if (!str.startsWith("Windows"))
      throw new IOException("Communication via the native Broker stubs not supported on this platform"); 
    try {
      System.loadLibrary("BrokerAgent");
    } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
      throw new IOException("Can't load native BrokerAgent library, check installation");
    } 
    System.out.println();
    System.out.println("Calls to " + paramString + " will use the native Broker stubs with API Version 2 !");
    System.out.println();
    g = paramString;
  }
  
  private int a(int paramInt) {
    int i1 = 0;
    int i2 = 0;
    if (this.s == 1) {
      if ((i2 = this.z[paramInt--]) < 0)
        i2 += 256; 
      if ((i1 = this.z[paramInt--]) < 0)
        i1 += 256; 
      i2 += i1 * 256;
      if ((i1 = this.z[paramInt--]) < 0)
        i1 += 256; 
      i2 += i1 * 65536;
      if ((i1 = this.z[paramInt--]) < 0)
        i1 += 256; 
      i2 += i1 * 16777216;
    } else {
      if ((i2 = this.z[paramInt--]) < 0)
        i2 += 256; 
      i2 *= 16777216;
      if ((i1 = this.z[paramInt--]) < 0)
        i1 += 256; 
      i2 += i1 * 65536;
      if ((i1 = this.z[paramInt--]) < 0)
        i1 += 256; 
      i2 += i1 * 256;
      if ((i1 = this.z[paramInt--]) < 0)
        i1 += 256; 
      i2 += i1;
    } 
    return i2;
  }
  
  private void a(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    if (this.s == 1) {
      paramArrayOfByte[paramInt1++] = (byte)(paramInt2 >> 24);
      paramArrayOfByte[paramInt1++] = (byte)(paramInt2 >> 16);
      paramArrayOfByte[paramInt1++] = (byte)(paramInt2 >> 8);
      paramArrayOfByte[paramInt1] = (byte)paramInt2;
    } else {
      paramInt1 += 3;
      paramArrayOfByte[paramInt1--] = (byte)(paramInt2 >> 24);
      paramArrayOfByte[paramInt1--] = (byte)(paramInt2 >> 16);
      paramArrayOfByte[paramInt1--] = (byte)(paramInt2 >> 8);
      paramArrayOfByte[paramInt1] = (byte)paramInt2;
    } 
  }
  
  private byte[] a(int paramInt, String paramString1, String paramString2) {
    int i1 = 0;
    byte b1 = 40;
    int i2 = this.i;
    int i3 = 89;
    int i4 = 32;
    boolean bool = true;
    int i6 = "EC=00000000,TXT=                                        ,CID=0000000000000000,RETL=00000000".length();
    int i7 = paramString2.length();
    String str1 = new String("EC=00000000,TXT=                                        ,CID=0000000000000000,RETL=00000000");
    if (this.ac[42] > 2) {
      i4 += 8;
    } else {
      b1 = 32;
    } 
    if (this.p > 0 && paramInt > 0) {
      this.p = paramInt;
      if (paramString1.equals("NONE") || paramString1.equals("NEW")) {
        i3 = 68;
        bool = false;
        i6 = "EC=00000000,TXT=                                        ,RETL=00000000".length();
        str1 = new String("EC=00000000,TXT=                                        ,RETL=00000000");
      } 
    } else if (paramInt > 0) {
      i2 = this.j;
      if (paramString1.equals("NONE") || paramString1.equals("NEW")) {
        str1 = new String("EC=00000000,TXT=                                        ,RETL=00000000");
        i6 = "EC=00000000,TXT=                                        ,RETL=00000000".length();
        bool = false;
        i3 = 68;
      } 
    } else if (this.m == 14) {
      StringBuffer stringBuffer = new StringBuffer(40);
      stringBuffer.append("BrokerAgent ");
      stringBuffer.append(EntireXVersion.getVersion());
      stringBuffer.append(' ');
      stringBuffer.append(System.getProperty("os.name"));
      stringBuffer.append(System.getProperty("os.version"));
      stringBuffer.setLength(40);
      for (byte b3 = 0; b3 < 40; b3++) {
        if (stringBuffer.charAt(b3) == '\000')
          stringBuffer.setCharAt(b3, ' '); 
      } 
      str1 = "EC=00000000,TXT=" + stringBuffer.toString();
      i6 = str1.length();
      bool = false;
    } else if (paramString1.equals("NONE") || paramString1.equals("NEW")) {
      str1 = new String("EC=00000000,TXT=                                        ");
      i6 = "EC=00000000,TXT=                                        ".length();
      bool = false;
    } else {
      str1 = new String("EC=00000000,TXT=                                        ,CID=0000000000000000");
      i6 = "EC=00000000,TXT=                                        ,CID=0000000000000000".length();
    } 
    i4 += paramInt;
    i1 = i4 + i6 + 1;
    if (i7 > i6)
      i7 = i6; 
    if (i7 > 56)
      i7 = 56; 
    int i9 = 0;
    String str2 = null;
    if (this.m == 14 || (this.m < 3 && this.ab != null && this.ab[472] > 32)) {
      StringBuffer stringBuffer = new StringBuffer("");
      if (this.ab != null && this.ab[472] > 32) {
        char c1 = 'ǘ';
        byte b3;
        for (b3 = 0; c1 < 'Ǹ' && this.ab[c1] != 0; b3++) {
          this.ad[b3] = (char)this.ab[c1];
          c1++;
        } 
        while (b3 < 32)
          this.ad[b3++] = ' '; 
        stringBuffer.append(",CUID=" + new String(this.ad, 0, 32));
        switch (this.ab[504]) {
          case 1:
            stringBuffer.append(",CST=NEW");
            break;
          case 2:
            stringBuffer.append(",CST=OLD");
            break;
          default:
            stringBuffer.append(",CST=NONE");
            break;
        } 
      } 
      if (this.m == 14)
        stringBuffer.append(",API=2"); 
      str2 = new String(stringBuffer);
      i9 = str2.length();
    } 
    i1 += i9;
    this.aa = new byte[i1];
    this.aa[0] = this.ac[0];
    this.aa[1] = this.ac[1];
    this.aa[2] = this.ac[2];
    this.aa[3] = this.ac[3];
    byte b2;
    for (b2 = 4; b2 < 32; b2++)
      this.aa[b2] = 0; 
    this.aa[16] = this.ac[40];
    this.aa[17] = this.ac[41];
    this.aa[18] = this.ac[42];
    this.aa[19] = this.ac[43];
    if (paramInt > 0) {
      byte b3 = b1;
      while (b3 < i4) {
        this.aa[b3] = this.z[i2];
        b3++;
        i2++;
      } 
    } 
    int i8 = i4;
    for (b2 = 0; b2 < i6; b2++) {
      this.aa[i8] = (byte)str1.charAt(b2);
      i8++;
    } 
    int i5 = i4;
    b2 = 0;
    while (b2 < i7) {
      this.aa[i5] = (byte)paramString2.charAt(b2);
      b2++;
      i5++;
    } 
    if (this.m < 3 || this.m == 14)
      for (b2 = 0; b2 < i9; b2++) {
        this.aa[i8] = (byte)str2.charAt(b2);
        i8++;
      }  
    i6 += i9;
    if (bool) {
      i5 = i1 - i6 + 60;
      if ((i2 = paramString1.length()) > 16)
        i2 = 16; 
      for (b2 = 0; b2 < i2; b2++) {
        this.aa[i5] = (byte)paramString1.charAt(b2);
        i5++;
      } 
    } 
    if (b1 == 32) {
      a(this.aa, 24, 16);
      a(this.aa, 20, paramInt + 16);
    } else {
      a(this.aa, 24, 24);
      a(this.aa, 36, i1 - 16);
      a(this.aa, 20, paramInt + 24);
    } 
    if (paramInt > 0) {
      i5 = i1 - i6 + i3;
      b2 = 0;
      this.aa[i5--] = (byte)(this.aa[i5--] + (byte)(paramInt % 10));
      while (b2 < 8 && paramInt /= 10 != 0)
        b2++; 
    } 
    this.aa[11] = 2;
    this.aa[28] = 92;
    this.aa[29] = -63;
    this.aa[30] = -43;
    this.aa[31] = -30;
    this.aa[i1 - 1] = 46;
    return this.aa;
  }
  
  private boolean a(int paramInt, String paramString) {
    this.af = this.j + paramString.length();
    int i1 = this.j;
    while (this.af < this.k) {
      if (this.y.substring(i1, this.af).equals(paramString)) {
        this.ag = this.af;
        while (this.ag < this.k) {
          if (this.z[this.ag] == 44 || this.z[this.ag] == 46)
            return true; 
          this.ab[paramInt++] = this.z[this.ag];
          this.ag++;
        } 
      } 
      i1++;
      this.af++;
    } 
    return false;
  }
  
  private boolean b(String paramString) {
    this.ah = this.j + paramString.length();
    int i1 = this.j;
    while (this.ah < this.k) {
      if (this.y.substring(i1, this.ah).equals(paramString))
        return true; 
      i1++;
      this.ah++;
    } 
    return false;
  }
  
  private boolean c(String paramString) {
    int i2 = this.ah;
    int i1 = i2;
    while (i2 < this.k && this.y.charAt(i2) != ',' && this.y.charAt(i2) != '.')
      i2++; 
    return this.y.substring(i1, i2).equals(paramString);
  }
  
  private int d(String paramString) {
    int i2 = this.j + paramString.length();
    int i1 = this.j;
    while (i2 < this.k) {
      if (this.y.substring(i1, i2).equals(paramString)) {
        for (i1 = i2; i1 < this.k; i1++) {
          if (this.z[i1] == 44 || this.z[i1] == 46)
            try {
              return Integer.parseInt(this.y.substring(i2, i1));
            } catch (NumberFormatException numberFormatException) {
              return 0;
            }  
        } 
        return 0;
      } 
      i1++;
      i2++;
    } 
    return 0;
  }
  
  private void a(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      for (byte b1 = 0; b1 < 8; b1++)
        this.ab[paramInt1--] = 48; 
    } else {
      for (byte b1 = 0; b1 < 8; b1++) {
        this.ab[paramInt1--] = (byte)(48 + paramInt2 % 10);
        paramInt2 /= 10;
      } 
    } 
  }
  
  private int a(byte[] paramArrayOfByte, int paramInt) {
    byte b1 = paramArrayOfByte[paramInt++];
    if (this.s == 0) {
      if (b1 < 0)
        b1 += 256; 
      b1 *= 256;
      if (paramInt < this.k) {
        if (paramArrayOfByte[paramInt] < 0) {
          b1 += 'Ā' + paramArrayOfByte[paramInt];
        } else {
          b1 += paramArrayOfByte[paramInt];
        } 
        return b1;
      } 
    } else {
      if (b1 < 0)
        b1 += 256; 
      if (paramInt < this.k) {
        if (paramArrayOfByte[paramInt] < 0) {
          b1 += ('Ā' + paramArrayOfByte[paramInt]) * 'Ā';
        } else {
          b1 += paramArrayOfByte[paramInt] * 256;
        } 
        return b1;
      } 
    } 
    return 0;
  }
  
  private boolean a() {
    int i1;
    if ((i1 = a(this.z, this.ai)) > 2 && i1 < 6) {
      char c1;
      if (i1 == 3) {
        c1 = 'ư';
      } else if (i1 == 4) {
        c1 = 'Ä';
      } else {
        c1 = 'ú';
      } 
      int i2 = a(this.z, this.ai + 2);
      i1 = 0;
      this.ai += 4;
      while (i1 < i2) {
        this.ab[c1++] = this.z[this.ai++];
        i1++;
      } 
      return true;
    } 
    return false;
  }
  
  public final byte[] a(byte[] paramArrayOfByte) {
    this.z = paramArrayOfByte;
    this.h = this.p = 0;
    this.h = paramArrayOfByte.length + 4;
    this.k = this.h - 4;
    int i1 = this.i = this.j = 0;
    this.ac = new byte[this.k];
    System.arraycopy(this.z, 0, this.ac, 0, this.k);
    this.ad = new char[this.k];
    int i2;
    for (i2 = 0; i2 < this.k; i2++)
      this.ad[i2] = (char)this.z[i2]; 
    this.y = new String(this.ad);
    this.s = (short)this.z[41];
    if (this.z[40] == 34 || this.z[40] == 66)
      throw new IllegalAccessError(); 
    this.i = a(51) + 40;
    this.j = i2 = a(47) + 40;
    this.p = this.j - this.i;
    this.o = d("SL=");
    this.n = d("RL=");
    i2 = this.j;
    int i3;
    for (i3 = i2 + 2; i3 < this.k; i3++) {
      if (this.y.substring(i2, i3).equals("F=")) {
        i2 = i3;
        while (i3 < this.k && this.ad[i3] != '.' && this.ad[i3] != ',')
          i3++; 
        this.v = this.y.substring(i2, i3);
        break;
      } 
      i2++;
    } 
    i2 = this.i + 8;
    int i5 = this.i;
    int i6 = this.j;
    this.ae = true;
    boolean bool = false;
    int i10;
    if ((i10 = this.p) < 1) {
      i5 = this.i;
      i6 = this.k;
      if ((i10 = this.k - i5) > 0) {
        if (i5 + 48 < this.k)
          i3 = this.i; 
        this.o = i10;
        bool = true;
      } 
      if (i10 < 0)
        i10 = 0; 
    } else {
      bool = true;
    } 
    int i7 = i6;
    if (this.v.equals("KERNELVERS")) {
      this.m = 14;
      return a(0, "NONE", "");
    } 
    int i9 = 0;
    int i8 = 681;
    if (this.v.equals("SEND")) {
      this.m = 1;
      if (!bool)
        i9 = this.p; 
      if (i9 < this.o)
        i9 = this.o; 
      if (i9 < this.n) {
        bool = true;
        i9 = this.n;
      } 
      i8 += i9;
    } else if (this.v.equals("RECEIVE")) {
      this.m = 2;
      if (!bool)
        i9 = this.p; 
      if (i9 < this.o)
        i9 = this.o; 
      if (i9 < this.n) {
        bool = true;
        i9 = this.n;
      } 
      i8 += i9;
    } else if (this.v.equals("UNDO")) {
      this.m = 4;
    } else if (this.v.equals("EOC")) {
      this.m = 5;
    } else if (this.v.equals("REGISTER")) {
      this.m = 6;
    } else if (this.v.equals("DEREGISTER")) {
      this.m = 7;
    } else if (this.v.equals("VERSION")) {
      this.m = 8;
      if (this.n == 0)
        this.n = 80; 
      if (!bool)
        i9 = this.p; 
      if (i9 < this.n)
        i9 = this.n; 
      this.o = 0;
      i8 += i9;
    } else if (this.v.equals("LOGON")) {
      this.m = 9;
    } else if (this.v.equals("LOGOFF")) {
      this.m = 10;
    } else if (this.v.equals("SET")) {
      this.m = 11;
    } else if (this.v.equals("GET")) {
      this.m = 12;
    } else if (this.v.equals("SYNCPOINT")) {
      this.m = 13;
    } 
    this.ab = new byte[i8];
    for (i3 = 0; i3 < 600; i3++)
      this.ab[i3] = 0; 
    for (i3 += i10; i3 < i8; i3++)
      this.ab[i3] = 32; 
    if (i10 > 0)
      for (i2 = 600; i5 < i6 && i2 < i8; i2++)
        this.ab[i2] = this.ac[i5++];  
    a(i8 - 73, this.o);
    a(i8 - 65, this.n);
    this.ab[0] = 1;
    this.ab[1] = 2;
    this.ab[2] = (byte)this.m;
    this.ab[505] = 1;
    this.ab[506] = 1;
    a(68, "SC=");
    a(100, "SN=");
    a(132, "SV=");
    a(164, ",UID=");
    a(196, ",PW=");
    a(228, "TK=");
    a(308, ",W=");
    a(324, "ENV=");
    a(340, "UD=");
    a(376, "MID=");
    a(408, "MTYP=");
    a(424, "PTIME=");
    a(432, "NPW=");
    a(464, "AERR=");
    a(472, "CUID=");
    a(508, "UOWTIME=");
    a(516, "UOWID=");
    a(532, "USTATUS=");
    if (b("OP="))
      if (c("MSG")) {
        this.ab[3] = 1;
      } else if (c("HOLD")) {
        this.ab[3] = 2;
      } else if (c("IMMED")) {
        this.ab[3] = 3;
      } else if (c("QUIESCE")) {
        this.ab[3] = 4;
      } else if (c("EOC")) {
        this.ab[3] = 5;
      } else if (c("CANCEL")) {
        this.ab[3] = 6;
      } else if (c("LAST")) {
        this.ab[3] = 7;
      } else if (c("NEXT")) {
        this.ab[3] = 8;
      } else if (c("PREVIEW")) {
        this.ab[3] = 9;
      } else if (c("COMMIT")) {
        this.ab[3] = 10;
      } else if (c("BACKOUT")) {
        this.ab[3] = 11;
      } else if (c("SYNC")) {
        this.ab[3] = 12;
      } else if (c("ATTACH")) {
        this.ab[3] = 13;
      } else if (c("DELETE")) {
        this.ab[3] = 14;
      } else if (c("EOCCANCEL")) {
        this.ab[3] = 15;
      } else if (c("QUERY")) {
        this.ab[3] = 16;
      } else if (c("SETUSTATUS")) {
        this.ab[3] = 17;
      } else if (c("ANY")) {
        this.ab[3] = 18;
      }  
    if (b("CST="))
      if (c("NEW")) {
        this.ab[504] = 1;
      } else if (c("OLD")) {
        this.ab[504] = 2;
      } else if (c("NONE")) {
        this.ab[504] = 3;
      }  
    if (b("STORE="))
      if (c("OFF")) {
        this.ab[505] = 1;
      } else if (c("BROKER")) {
        this.ab[505] = 2;
      } else if (c("ON")) {
        this.ab[505] = 3;
      }  
    if (b("MSTAT="))
      if (c("OFF")) {
        this.ab[506] = 1;
      } else if (c("STORED")) {
        this.ab[506] = 2;
      } else if (c("DELIVERY_ATTEMP")) {
        this.ab[506] = 3;
      } else if (c("DELIVERED")) {
        this.ab[506] = 4;
      } else if (c("PROCESSED")) {
        this.ab[506] = 5;
      } else if (c("DEAD")) {
        this.ab[506] = 6;
      }  
    if (b("UOWST="))
      if (c("RECEIVED")) {
        this.ab[507] = 1;
      } else if (c("ACCEPTED")) {
        this.ab[507] = 2;
      } else if (c("DELIVERED")) {
        this.ab[507] = 3;
      } else if (c("BACKEDOUT")) {
        this.ab[507] = 4;
      } else if (c("PROCESSED")) {
        this.ab[507] = 5;
      } else if (c("CANCELLED")) {
        this.ab[507] = 6;
      } else if (c("TIMEOUT")) {
        this.ab[507] = 7;
      } else if (c("DISCARDED")) {
        this.ab[507] = 8;
      } else if (c("RECV_FIRST")) {
        this.ab[507] = 9;
      } else if (c("RECV_MIDDLE")) {
        this.ab[507] = 10;
      } else if (c("RECV_LAST")) {
        this.ab[507] = 11;
      } else if (c("RECV_ONLY")) {
        this.ab[507] = 12;
      } else if (c("RECV_NONE")) {
        this.ab[507] = 13;
      }  
    this.ai = a(59) + 40;
    if (this.ai > 40 && this.ai < this.k)
      do {
      
      } while (a()); 
    if (b("ADCNT=")) {
      i2 = i8 - 63;
      while (i2 < i8) {
        byte b1 = (byte)this.y.charAt(this.ah);
        if (b1 == 46 || b1 == 44)
          break; 
        this.ab[i2] = b1;
        i2++;
        this.ah++;
      } 
    } 
    this.ab[i2] = 46;
    if (!a(292, "CID=")) {
      this.ab[292] = 78;
      this.ab[293] = 79;
      this.ab[294] = 78;
      this.ab[295] = 69;
    } 
    i2 = 36;
    int i4 = g.length();
    for (i3 = 0; i3 < i4; i3++) {
      this.ab[i2] = (byte)g.charAt(i3);
      i2++;
    } 
    this.q = BrokerAgentNative.callBroker(this.ab);
    if (this.q > 0 && bool) {
      if (this.p > 0) {
        i3 = this.i;
      } else {
        i3 = this.j;
      } 
      this.k = i3 + this.q;
      this.z = new byte[this.k + 1];
      for (i2 = 0; i2 < i3; i2++)
        this.z[i2] = (byte)this.y.charAt(i2); 
      for (i4 = 600; i2 < this.k; i4++) {
        this.z[i2] = this.ab[i4];
        i2++;
      } 
    } 
    i10 = 0;
    this.u = 2;
    i2 = 292;
    while (i2 < 308 && this.ab[i2] != 0 && this.ab[i2] != 32) {
      this.ad[i10] = (char)this.ab[i2];
      i2++;
      i10++;
    } 
    i5 = i10;
    i6 = i10 + 56;
    i6 = this.q + 600;
    i2 = 0;
    while (i2 < 16) {
      this.ad[i5] = "EC=00000000,TXT=                                        ,RETL=00000000".charAt(i2);
      i2++;
      i5++;
    } 
    i5 = i10 + 3;
    for (i3 = 316; i3 < 324; i3++) {
      this.ad[i5] = (char)this.ab[i3];
      i5++;
    } 
    i5 = i10 + 16;
    for (i3 = 0; i3 < 56; i3++) {
      this.ad[i5] = (char)this.ab[i6++];
      i5++;
    } 
    if (!bool && this.p > 0)
      System.arraycopy(this.ab, 600, this.z, this.i, i8 - 681); 
    return a(this.q, new String(this.ad, 0, i10), new String(this.ad, i10, 56));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\ah.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */