package com.softwareag.entirex.aci;

public class o extends n {
  private static int a = 1;
  
  static Class b;
  
  static Class c;
  
  o(b paramb1, m paramm, b paramb2) { super(paramb1, paramm, "Worker-" + a++, paramb2); }
  
  public final void run() {
    aq aq = null;
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool = false;
    int i = 0;
    int j = 0;
    while (this.q < this.r && !this.ac.t()) {
      Exception exception;
      if (this.e)
        synchronized (System.out) {
          System.out.println(this.ab.i() + "/" + Thread.currentThread().getName() + " Start of " + Thread.currentThread().getName());
        }  
      this.ac.h("Running");
      Broker broker = b();
      this;
      BrokerService brokerService = new BrokerService(broker, this.ab.d("entirex.server.serveraddress"));
      this;
      String str = this.ab.d("entirex.server.environment");
      if (str != null && str.length() > 0)
        brokerService.setEnvironment(str); 
      this;
      if (this.ab.c("entirex.server.usecodepage"))
        try {
          brokerService.useCodePage(true);
        } catch (BrokerException brokerException) {
          System.out.println(brokerException);
        }  
      this;
      brokerService.setDefaultWaittime(this.ab.d("entirex.server.waitserver"));
      brokerService.setMaxReceiveLen(4000);
      brokerService.setAdjustReceiveLen(true);
      try {
        synchronized ((b == null) ? (b = class$("com.softwareag.entirex.aci.n")) : b) {
          this.ac.x();
          this.ac.s();
        } 
        this;
        String str1 = this.ab.d("entirex.server.codepage");
        if (str1 != null && str1.length() > 0)
          brokerService.setCharacterEncoding(str1); 
        a(broker);
        bool1 = true;
        this.ab.a(brokerService);
        brokerService.register();
        this.p = 3;
        a(broker, brokerService, false);
        bool2 = true;
        boolean bool3 = true;
        while (bool3) {
          try {
            this.p = 3;
            BrokerMessage brokerMessage = brokerService.receive();
            this.p = 4;
            this.ab.z = brokerMessage.getConversation();
            if (this.ab.z != null) {
              this.ab.a(brokerMessage);
              continue;
            } 
            this.ab.b(brokerMessage);
          } catch (BrokerException brokerException) {
            j = brokerException.getErrorClass();
            i = brokerException.getErrorCode();
            if (brokerException.getErrorClass() == 74 && brokerException.getErrorCode() == 74) {
              synchronized ((b == null) ? (b = class$("com.softwareag.entirex.aci.n")) : b) {
                if (this.ac.w() > this.ac.l())
                  bool3 = false; 
              } 
            } else if (brokerException.getErrorClass() == 10 && brokerException.getErrorCode() == 50) {
              bool3 = false;
            } else if (brokerException.getErrorClass() == 10 && brokerException.getErrorCode() == 51) {
              bool3 = false;
            } else if ((brokerException.getErrorClass() == 20 && (brokerException.getErrorCode() == 380 || brokerException.getErrorCode() == 381)) || brokerException.getErrorClass() == 22 || brokerException.getErrorClass() == 1003 || brokerException.getErrorClass() == 1009 || brokerException.getErrorClass() == 1010 || brokerException.getErrorClass() == 1011) {
              String str2 = bl.a(brokerException.getErrorClass()) + bl.a(brokerException.getErrorCode());
              if (!brokerService.replyError(str2, brokerException.toString())) {
                q q = brokerService.getBroker().a();
                synchronized (q) {
                  q.c(q.g(), q.av);
                } 
              } 
            } else {
              if (brokerException.getErrorClass() == 13 && brokerException.getErrorCode() == 120)
                throw brokerException; 
              if (brokerException.getErrorClass() == 13 && brokerException.getErrorCode() == 313)
                throw brokerException; 
              brokerException.printStackTrace();
              throw brokerException;
            } 
            this.ab.a(brokerException, true);
          } 
        } 
      } catch (aq aq1) {
        this.ad = aq1.a();
        j = aq1.getErrorClass();
        i = aq1.getErrorCode();
        aq = aq1;
        synchronized (System.out) {
          System.out.println();
          System.out.println(this.ab.i() + "/" + Thread.currentThread().getName() + " ServerException in server:");
          System.out.println(aq1);
        } 
        this.ab.a(aq1, true);
      } catch (BrokerException brokerException) {
        j = brokerException.getErrorClass();
        i = brokerException.getErrorCode();
        exception = brokerException;
        synchronized (System.out) {
          System.out.println();
          System.out.println(this.ab.i() + "/" + Thread.currentThread().getName() + " Broker Exception in server:");
          System.out.println(brokerException);
        } 
        this.ab.a(brokerException, true);
      } catch (Exception exception1) {
        j = 0;
        i = 0;
        exception = exception1;
        synchronized (System.out) {
          System.out.println();
          System.out.println(this.ab.i() + "/" + Thread.currentThread().getName() + " Exception in server: ");
          System.out.println(exception1);
        } 
        this.ab.a(exception1, true);
      } finally {
        synchronized ((c == null) ? (c = class$("com.softwareag.entirex.aci.b")) : c) {
          this.ac.y();
        } 
        if (this.e)
          synchronized (System.out) {
            System.out.println();
            this;
            System.out.println(this.ab.i() + "/" + Thread.currentThread().getName() + " Terminating " + this.ab.d("entirex.server.name"));
          }  
        this.f = a(j, i);
        if (!this.f)
          this.g = b(j, i); 
        try {
          this.ab.a();
        } catch (BrokerException brokerException) {
          brokerException.printStackTrace();
        } 
        try {
          switch (j) {
            case 2:
            case 10:
              break;
            case 21:
              if (i == 18 && this.e)
                synchronized (System.out) {
                  System.out.println("Maximum number of servers reached, consider to increase NUM-SERVERS in the Broker Attribute File");
                }  
            default:
              if (exception != null && !(exception instanceof BrokerException))
                exception.printStackTrace(); 
              if (bool2) {
                if (j != 13 || (i != 313 && i != 315))
                  brokerService.deregister(); 
                bool2 = false;
                if (this.e)
                  synchronized (System.out) {
                    System.out.println(this.ab.i() + "/" + Thread.currentThread().getName() + " deregister done.");
                  }  
                bool = true;
              } 
              if (bool1) {
                if (j != 13 || (i != 313 && i != 315))
                  broker.logoff(); 
                this.ac.v().remove(this);
                bool1 = false;
                if (this.e)
                  synchronized (System.out) {
                    System.out.println(this.ab.i() + "/" + Thread.currentThread().getName() + " logoff done, remaining servers:" + this.ac.w());
                  }  
              } 
              break;
          } 
          a(broker, brokerService, false, bool);
        } catch (Throwable throwable) {
          throwable.printStackTrace();
        } 
      } 
      if (!c())
        break; 
    } 
    synchronized ((b == null) ? (b = class$("com.softwareag.entirex.aci.n")) : b) {
      this.ac.u().remove(this);
    } 
    if (this.g)
      d(); 
  }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\o.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */