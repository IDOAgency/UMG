package com.softwareag.entirex.aci;

import java.io.IOException;

final class af {
  static final short a = 126;
  
  static final short b = 126;
  
  static final short c = 127;
  
  static final short d = 128;
  
  static final short e = 129;
  
  static final short f = 129;
  
  static final short g = 800;
  
  static final short h = 800;
  
  static final short i = 801;
  
  static final short j = 802;
  
  static final short k = 802;
  
  static final short l = 900;
  
  static final short m = 900;
  
  static final short n = 901;
  
  static final short o = 903;
  
  static final short p = 904;
  
  static final short q = 904;
  
  static void a(ad paramad, short paramShort) throws IOException {
    paramad.b(20);
    paramad.b(1161970502);
    paramad.b(0);
    paramad.c(1);
    paramad.c(2);
    paramad.c(paramShort);
    paramad.c(0);
  }
  
  static void a(short paramShort) throws IOException {
    String str = b(paramShort);
    if (paramShort >= 126 && paramShort <= 129)
      throw new ae("0326", new String[] { str }); 
    if (paramShort >= 800 && paramShort <= 802)
      throw new ae("0327", new String[] { str }); 
    if (paramShort >= 900 && paramShort <= 904)
      throw new ae("0328", new String[] { str }); 
    throw new ae("0323", new String[] { str });
  }
  
  static String b(short paramShort) {
    switch (paramShort) {
      case 126:
        return "Error during Receive request";
      case 127:
        return "Receive Task stopped";
      case 128:
        return "Work queue full or alloc XWQE failed";
      case 129:
        return "Not enough space for Reply buffer";
      case 900:
        return "Shutdown in process";
      case 901:
        return "Communication to Broker failed";
      case 903:
        return "Error during processing";
      case 904:
        return "Illegal request";
      case 800:
        return "Content-length < 1";
      case 801:
        return "IOException";
      case 802:
        return "General Exception";
    } 
    return Integer.toString(paramShort);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\af.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */