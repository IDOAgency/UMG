package com.softwareag.entirex.aci;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

class b7 extends WindowAdapter {
  private final Tester a;
  
  b7(Tester paramTester) { this.a = paramTester; }
  
  public void windowClosing(WindowEvent paramWindowEvent) { System.exit(0); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\b7.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */