package com.softwareag.entirex.aci;

import java.io.PrintWriter;
import java.util.Hashtable;

public final class Broker {
  private q a;
  
  Hashtable b = new Hashtable();
  
  String c;
  
  String d;
  
  String e;
  
  byte[] f;
  
  String g;
  
  private BrokerSecurity h = null;
  
  public static final int ENCRYPTION_LEVEL_NONE = 0;
  
  public static final int ENCRYPTION_LEVEL_BROKER = 1;
  
  public static final int ENCRYPTION_LEVEL_TARGET = 2;
  
  private String[] i = { "BEST_COMPRESSION", "BEST_SPEED", "DEFAULT_COMPRESSION", "DEFLATED", "NO_COMPRESSION" };
  
  private int[] j = { 9, 1, -1, 8, 0 };
  
  public static String getVersion() { return Dump.d.getVersionString(); }
  
  public String getConnInfo() { return this.a.aa(); }
  
  q a() { return this.a; }
  
  public String getBrokerID() { return this.c; }
  
  public String toString() { return getBrokerID(); }
  
  public String getUserID() { return this.d; }
  
  public byte[] getSecurityToken() { return this.f; }
  
  public void setSecurityToken(byte[] paramArrayOfByte) { this.f = paramArrayOfByte; }
  
  public String getToken() { return this.g; }
  
  public void setSecurity(BrokerSecurity paramBrokerSecurity, boolean paramBoolean) { setSecurity(paramBrokerSecurity, 0, paramBoolean); }
  
  public void setSecurity(BrokerSecurity paramBrokerSecurity, int paramInt) { setSecurity(paramBrokerSecurity, paramInt, (paramInt != 0)); }
  
  public void setSecurity(BrokerSecurity paramBrokerSecurity, int paramInt, boolean paramBoolean) { a(paramBrokerSecurity, paramInt, (paramInt != 0), paramBoolean); }
  
  private void a(BrokerSecurity paramBrokerSecurity, int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    if (paramInt != 0 && paramInt != 1 && paramInt != 2)
      throw new IllegalArgumentException("Illegal Value for Encryption Level: " + paramInt); 
    synchronized (this.a) {
      this.h = paramBrokerSecurity;
      try {
        this.a.a(paramBrokerSecurity, paramInt, paramBoolean1, paramBoolean2);
      } catch (BrokerException brokerException) {
        throw new IllegalStateException(brokerException.toString());
      } 
    } 
  }
  
  public void useEntireXSecurity() { useEntireXSecurity(0, false); }
  
  public void useEntireXSecurity(int paramInt) { useEntireXSecurity(paramInt, false); }
  
  public void useEntireXSecurity(boolean paramBoolean) { useEntireXSecurity(0, paramBoolean); }
  
  public void useEntireXSecurity(int paramInt, boolean paramBoolean) {
    synchronized (this.a) {
      if (this.h == null || !(this.h instanceof EntireXSecurity))
        this.h = new EntireXSecurity(); 
      setSecurity(this.h, paramInt, paramBoolean);
    } 
  }
  
  public Broker(String paramString1, String paramString2) { this(paramString1, paramString2, null); }
  
  public Broker(String paramString1, String paramString2, String paramString3) {
    if (paramString1 == null || paramString1.length() == 0 || paramString2 == null || paramString2.length() == 0)
      throw new IllegalArgumentException("Wrong argument to Broker constructor"); 
    String str = null;
    int k = paramString1.toLowerCase().indexOf("compresslevel=");
    int m = "compresslevel=".length();
    if (k >= 0) {
      int n = paramString1.toLowerCase().indexOf("&", k);
      int i1 = k + m;
      int i2 = (n > k) ? n : paramString1.length();
      str = paramString1.substring(i1, i2);
      int i3 = (n > k) ? k : (k - 1);
      int i4 = (n > k) ? (i2 + 1) : i2;
      paramString1 = paramString1.substring(0, i3).concat(paramString1.substring(i4, paramString1.length()));
    } 
    this.c = paramString1;
    this.d = paramString2;
    this.g = paramString3;
    Dump.a(null);
    this.a = new q(this);
    setCompressionLevel(str);
  }
  
  String b() { return this.a.z(); }
  
  public void logon() { logon(null); }
  
  public void logon(String paramString) throws BrokerException { logon(paramString, null); }
  
  public void logon(String paramString1, String paramString2) {
    synchronized (this.a) {
      this.e = paramString1;
      this.f = null;
      this.a.u();
      this.a.b(paramString1, paramString2);
      this.f = this.a.f();
    } 
  }
  
  public void autoLogon(String paramString) throws BrokerException {
    synchronized (this.a) {
      this.e = paramString;
      this.f = null;
      this.a.u();
      this.a.i(paramString);
      this.f = this.a.f();
    } 
  }
  
  public void logoff() {
    synchronized (this.a) {
      this.a.u();
      this.a.w();
      this.f = null;
    } 
  }
  
  public static void setTrace(int paramInt) { Dump.setTrace(paramInt); }
  
  public static void setTrace(int paramInt, PrintWriter paramPrintWriter) { Dump.a(paramInt, paramPrintWriter); }
  
  public static int getTrace() { return Dump.b(); }
  
  public void reconnect(String paramString) throws BrokerException { reconnect(paramString, null); }
  
  public void reconnect(String paramString1, String paramString2) {
    if (paramString1 == null || paramString1.length() == 0)
      throw new IllegalArgumentException("Wrong argument to reconnect"); 
    synchronized (this.a) {
      this.d = paramString1;
      this.g = paramString2;
      this.a.a(paramString1, paramString2);
    } 
  }
  
  public void disconnect() {
    synchronized (this.a) {
      this.a.ab();
    } 
  }
  
  public String getUniqueID() {
    String str = this.a.ac();
    if (this.a.k(str))
      throw new IllegalStateException(); 
    return str;
  }
  
  public int getCompressionLevel() { return this.a.ad(); }
  
  public void setCompressionLevel(int paramInt) {
    if (paramInt >= -1 && paramInt <= 9) {
      if (paramInt == -1)
        paramInt = 6; 
      this.a.e(paramInt);
    } else {
      throw new IllegalArgumentException("Unknown compression level " + paramInt);
    } 
  }
  
  public void setCompressionLevel(String paramString) throws BrokerException {
    if (paramString != null)
      if (paramString.toUpperCase().startsWith("Y")) {
        this.a.e(6);
      } else if (paramString.toUpperCase().startsWith("N")) {
        this.a.e(0);
      } else {
        try {
          int k = Integer.parseInt(paramString);
          setCompressionLevel(k);
        } catch (NumberFormatException numberFormatException) {
          boolean bool = false;
          for (byte b1 = 0; b1 < this.i.length; b1++) {
            if (paramString.equalsIgnoreCase(this.i[b1])) {
              setCompressionLevel(this.j[b1]);
              bool = true;
              break;
            } 
          } 
          if (!bool)
            throw new IllegalArgumentException("Unknown compression level " + paramString); 
        } 
      }  
  }
  
  public boolean isJMSenabled() {
    boolean bool = false;
    if (this.a != null)
      try {
        bool = (this.a.v() >= 7);
      } catch (BrokerException brokerException) {} 
    return bool;
  }
  
  boolean c() {
    boolean bool = false;
    if (this.a != null)
      try {
        bool = (this.a.v() >= 8);
      } catch (BrokerException brokerException) {} 
    return bool;
  }
  
  void a(boolean paramBoolean) {
    if (this.a != null)
      this.a.d(paramBoolean); 
  }
  
  boolean d() {
    boolean bool = false;
    if (this.a != null)
      try {
        bool = (this.a.v() >= 8);
      } catch (BrokerException brokerException) {} 
    return bool;
  }
  
  public int getCISVersion() {
    byte b1;
    boolean bool;
    try {
      bool = this.a.v();
    } catch (BrokerException brokerException) {
      bool = false;
    } 
    if (bool <= 3) {
      b1 = 1;
    } else if (bool >= 4 && bool <= 6) {
      b1 = 2;
    } else if (bool == 7) {
      b1 = 3;
    } else {
      b1 = 4;
    } 
    return b1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\Broker.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */