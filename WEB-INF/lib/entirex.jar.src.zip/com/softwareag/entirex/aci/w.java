package com.softwareag.entirex.aci;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Hashtable;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Stack;
import java.util.StringTokenizer;

final class w {
  private static final String a = "ssl://";
  
  private static final String b = "32";
  
  public static final String c = "poolsize";
  
  private static final String d = "pooltimeout";
  
  private static final String e = "300";
  
  private static final int f = 10;
  
  private static boolean g = false;
  
  private static int h = 10;
  
  private String i;
  
  private int j = 0;
  
  private int k = 0;
  
  private Stack l;
  
  private y m;
  
  private boolean n;
  
  private boolean o;
  
  private String p;
  
  private int q;
  
  private Properties r;
  
  private long s;
  
  private static Hashtable t = new Hashtable();
  
  private int u = 0;
  
  private int v = 0;
  
  static Class w;
  
  static w a(String paramString) {
    w w1 = (w)t.get(paramString);
    if (w1 != null)
      return w1; 
    w1 = new w(paramString);
    t.put(paramString, w1);
    return w1;
  }
  
  private w(String paramString) {
    this.i = paramString;
    this.p = paramString;
    boolean bool = false;
    if (this.p.toLowerCase().startsWith("ssl://")) {
      bool = true;
      this.p = this.p.substring("ssl://".length());
      this.q = 1958;
    } else {
      this.q = 1971;
    } 
    try {
      int i1 = this.p.indexOf('?');
      if (i1 != -1) {
        str = this.p.substring(i1 + 1, this.p.length());
        this.p = this.p.substring(0, i1);
      } else {
        str = null;
      } 
      i1 = this.p.indexOf(':');
      if (i1 != -1) {
        this.q = Integer.parseInt(this.p.substring(i1 + 1, this.p.length()));
        if (i1 == 0) {
          this.p = "localhost";
        } else {
          this.p = this.p.substring(0, i1);
        } 
      } else if (this.p.length() == 0) {
        this.p = "localhost";
      } 
    } catch (NumberFormatException numberFormatException) {
      throw new IllegalArgumentException("Wrong argument \"" + paramString + "\" to Broker constructor");
    } 
    this.r = new Properties();
    if (str != null) {
      StringTokenizer stringTokenizer = new StringTokenizer(str, "=", true);
      try {
        while (stringTokenizer.hasMoreTokens()) {
          String str1 = stringTokenizer.nextToken("=").toLowerCase();
          stringTokenizer.nextToken();
          String str2 = stringTokenizer.nextToken("&");
          this.r.put(str1, str2);
          stringTokenizer.nextToken();
        } 
      } catch (NoSuchElementException noSuchElementException) {}
    } 
    try {
      this.j = Integer.parseInt(this.r.getProperty("poolsize", "32"));
    } catch (NumberFormatException numberFormatException) {
      this.j = Integer.parseInt("32");
    } 
    try {
      this.s = (1000 * Integer.parseInt(this.r.getProperty("pooltimeout", "300")));
      if (this.s <= 0L)
        throw new NumberFormatException(); 
    } catch (NumberFormatException numberFormatException) {
      this.s = (1000 * Integer.parseInt("300"));
    } 
    this.n = (this.j > 0);
    this.o = this.n;
    if (this.n) {
      this.l = new Stack();
    } else {
      this.j = 0;
    } 
    if (bool) {
      this.m = new x(this.p, this.q, this.r);
    } else {
      this.m = new z(this.p, this.q, this.r);
    } 
    if (Dump.c)
      Dump.log("BrokerId " + paramString + " resolved to " + toString() + (bool ? " using SSL " : " ") + (this.n ? ("(poolsize=" + this.j + ",timeout=" + (this.s / 1000L) + "s)") : "(no socketpool)")); 
    if (this.n)
      try {
        com/softwareag/entirex/aci/aa com/softwareag/entirex/aci/aa = new com/softwareag/entirex/aci/aa(this);
        com/softwareag/entirex/aci/aa.setDaemon(true);
        com/softwareag/entirex/aci/aa.setPriority(3);
        com/softwareag/entirex/aci/aa.a(paramString);
        com/softwareag/entirex/aci/aa.start();
      } catch (SecurityException securityException) {
        this.o = false;
        if (Dump.c)
          Dump.log("Cleanup thread disabled due to " + securityException); 
      }  
  }
  
  public String toString() { return this.p + ':' + this.q; }
  
  public int a() { return this.q; }
  
  public String b() { return this.p; }
  
  public boolean c() { return this.n; }
  
  public ServerSocket d() throws IOException { return this.m.c(); }
  
  public ai e() throws IOException {
    if (!this.n) {
      if (Dump.c)
        Dump.log("Allocating new socket for " + toString()); 
      return g();
    } 
    synchronized (this) {
      try {
        i();
        long l1;
        for (l1 = 0L; this.k >= this.j && l1 < h; l1 += System.currentTimeMillis() - l2) {
          this.u++;
          long l2 = System.currentTimeMillis();
          wait(h);
        } 
        if (this.k >= this.j) {
          if (Dump.c)
            Dump.log("SocketPool.getSocket: no free socket available after " + l1 + "ms"); 
          throw new ae("0333", new String[] { this.i, Integer.toString(this.j) });
        } 
      } catch (InterruptedException interruptedException) {
        if (Dump.c)
          Dump.log("SocketPool.getSocket: interrupted: " + interruptedException.getMessage()); 
      } 
      if (!this.o)
        synchronized (this) {
          h();
        }  
      ai ai = null;
      synchronized (this.l) {
        if (this.l.empty()) {
          if (Dump.c)
            Dump.log("Allocating new socket for " + toString() + " (" + this.k + ")"); 
          ai = g();
        } else {
          ai = (ai)this.l.pop();
        } 
      } 
      this.k++;
      return ai;
    } 
  }
  
  private ai g() throws IOException {
    Socket socket = this.m.b();
    ai ai = new ai(socket);
    try {
      socket.setTcpNoDelay(true);
      if (Dump.c)
        Dump.log("TcpNodelay enabled"); 
    } catch (Exception exception) {
      if (Dump.c)
        Dump.log("setTcpNodelay failed: " + exception.toString()); 
    } 
    this.v++;
    return ai;
  }
  
  public void a(ai paramai) { a(paramai, false); }
  
  public void b(ai paramai) { a(paramai, true); }
  
  private void a(ai paramai, boolean paramBoolean) {
    if (paramBoolean && paramai != null)
      paramai.c(); 
    if (!this.n)
      return; 
    synchronized (this) {
      this.k--;
      if (!paramBoolean) {
        paramai.d = System.currentTimeMillis();
        synchronized (this.l) {
          this.l.push(paramai);
        } 
      } 
      if (!this.o)
        h(); 
      notify();
    } 
  }
  
  String f() { return " Poolsize=" + this.j + ",Waits=" + this.u + ",MaxSockets=" + this.v; }
  
  private void h() {
    long l1 = System.currentTimeMillis();
    byte b1 = 0;
    synchronized (this.l) {
      while (b1 < this.l.size()) {
        ai ai = (ai)this.l.elementAt(b1);
        if (l1 > ai.d + this.s) {
          if (Dump.c)
            Dump.log("CleanupPool: " + ai.toString() + " [" + b1 + "] will be removed"); 
          ai.c();
          this.l.removeElementAt(b1);
          continue;
        } 
        b1++;
      } 
    } 
  }
  
  private void i() {
    synchronized ((w == null) ? (w = class$("com.softwareag.entirex.aci.w")) : w) {
      if (g)
        return; 
      String str = null;
      try {
        str = System.getProperty("entirex.timeout", "0");
        int i1 = Integer.parseInt(str);
        if (i1 != 0 && i1 < 10)
          throw new NumberFormatException(); 
        h = i1 * 1000;
        g = true;
      } catch (NumberFormatException numberFormatException) {
        throw new ae("0317", new String[] { str });
      } catch (SecurityException securityException) {
        h = 10;
        g = true;
      } 
    } 
  }
  
  static long a(w paramw) { return paramw.s; }
  
  static void b(w paramw) { paramw.h(); }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
  
  public class com/softwareag/entirex/aci/aa extends Thread {
    private String a;
    
    private final w b;
    
    public com/softwareag/entirex/aci/aa(w this$0) { this.b = this$0; }
    
    public void a(String param1String) { this.a = param1String; }
    
    public void run() {
      long l = w.a(this.b) / 2L;
      if (Dump.c)
        Dump.log("CleanupPool for \"" + this.a + "\": started, timeout = " + w.a(this.b) + " ms"); 
      while (true) {
        synchronized (this) {
          try {
            wait(l);
            w.b(this.b);
          } catch (InterruptedException interruptedException) {}
        } 
      } 
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\w.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */