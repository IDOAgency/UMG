package com.softwareag.entirex.aci;

import java.io.EOFException;
import java.io.InterruptedIOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

public class l extends Thread {
  public static final int a = 0;
  
  public static final int b = 1;
  
  public static final int c = 2;
  
  int d = 0;
  
  b e = null;
  
  boolean f = true;
  
  ServerSocket g = null;
  
  public l(b paramb) { this.e = paramb; }
  
  public void a() {
    this.f = false;
    if (this.g != null)
      try {
        this.g.close();
      } catch (Exception exception) {} 
  }
  
  public void run() {
    try {
      Thread.sleep(100L);
    } catch (Exception exception) {}
    setName("MonitorDispatcher");
    Dump.log("Started.");
    String str1 = this.e.n();
    String str2 = this.e.o();
    Object object = null;
    Dump.log("Argus TCP/IP control port: " + str1);
    Dump.log("Argus TCP/IP timeout: " + str2 + " seconds");
    Socket socket = null;
    do {
      try {
        this.g = new ServerSocket(Integer.parseInt(str1));
        this.g.setSoTimeout(Integer.parseInt(str2) * 1000);
        this.d = 1;
        socket = this.g.accept();
        Dump.log("accept local=" + socket.getLocalAddress() + ", remote=" + socket.getInetAddress());
        if (this.e.p() || socket.getInetAddress().equals(socket.getLocalAddress())) {
          d6 d6 = new d6(socket, this.e);
          d6.start();
        } else {
          Dump.log("Remote access not supported!");
          if (socket != null)
            try {
              socket.close();
            } catch (Exception exception) {} 
          if (this.g != null)
            try {
              this.g.close();
            } catch (Exception exception) {} 
        } 
      } catch (InterruptedIOException interruptedIOException) {
        if (this.g != null)
          try {
            this.g.close();
          } catch (Exception exception) {} 
      } catch (EOFException eOFException) {
        if (this.g != null)
          try {
            this.g.close();
          } catch (Exception exception) {} 
        Dump.log("disconnect: " + eOFException);
      } catch (BindException bindException) {
        if (this.g != null)
          try {
            this.g.close();
          } catch (Exception exception) {} 
        System.out.println("port in use: " + bindException);
        Dump.log("port in use: " + bindException);
        this.d = 2;
        this.f = false;
      } catch (SocketException socketException) {
        if (this.g != null)
          try {
            this.g.close();
          } catch (Exception exception) {} 
        Dump.log("shutdown: " + socketException);
        if (this.g != null)
          try {
            this.g.close();
          } catch (Exception exception) {} 
      } catch (Exception exception) {
        System.out.println("exception: " + exception);
        exception.printStackTrace();
        if (this.g != null)
          try {
            this.g.close();
          } catch (Exception exception1) {} 
      } finally {
        if (this.g != null)
          try {
            this.g.close();
          } catch (Exception exception) {} 
      } 
      try {
        Thread.sleep(1000L);
      } catch (Exception exception) {}
    } while (this.f);
    Dump.log("Stopped.");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\l.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */