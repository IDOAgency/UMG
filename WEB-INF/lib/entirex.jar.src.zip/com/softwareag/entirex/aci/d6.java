package com.softwareag.entirex.aci;

import com.softwareag.entirex.argus.base.Protocol;
import java.net.Socket;

public class d6 extends Thread {
  Socket a = null;
  
  b b = null;
  
  boolean c = true;
  
  Protocol d = null;
  
  public d6(Socket paramSocket, b paramb) {
    this.a = paramSocket;
    this.b = paramb;
  }
  
  public void a() {
    this.c = false;
    if (this.d != null)
      this.d.close(); 
  }
  
  public void run() {
    setName("Monitor-" + this.a.getPort());
    Dump.log("Started.");
    Object object = null;
    while (this.c) {
      try {
        this.d = new Protocol(null, this.a);
        while (this.c) {
          int i = this.d.b();
          switch (i) {
            case 1:
              this.d.a(-1);
            case 2:
              this.d.b(this.b.r());
            case 3:
              this.d.c(-1);
            case 4:
              this.d.b(this.b.q());
            case 5:
              this.d.c(this.b.getServerEnhancedInfo());
            case 6:
              this.d.a(this.b.getTableNames());
            case 7:
              this.d.a(this.b.getTable(this.d.a()));
          } 
        } 
      } catch (Exception exception) {
        Dump.log("Exception: " + exception);
        if (this.a != null)
          try {
            this.a.close();
          } catch (Exception exception1) {} 
        a();
      } 
    } 
    Dump.log("Stopped.");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\d6.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */