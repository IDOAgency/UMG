package com.softwareag.entirex.aci;

import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class BrokerException extends Exception {
  private int a = 0;
  
  private int b = 0;
  
  private String c = null;
  
  private String d;
  
  private static ResourceBundle e = null;
  
  private static final String f = "0013";
  
  BrokerException(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    super(paramString3);
    if (e == null)
      a(); 
    if (e == null) {
      this.d = "Broker Error " + paramString1 + ' ' + paramString2 + ": " + paramString3;
    } else {
      this.d = MessageFormat.format(e.getString("0000"), new String[] { paramString1, paramString2, paramString3 });
    } 
    try {
      this.a = Integer.parseInt(paramString1);
      this.b = Integer.parseInt(paramString2);
    } catch (NumberFormatException numberFormatException) {}
    if (Dump.c)
      Dump.log(this.d); 
    if (paramString4 != null) {
      StringBuffer stringBuffer = new StringBuffer("  Last BrokerCall was = ");
      stringBuffer.append(paramString4);
      stringBuffer.append("\n  Result of BrokerCall was =");
      stringBuffer.append(paramString5);
      this.c = stringBuffer.toString();
    } 
  }
  
  static void a(String paramString, String[] paramArrayOfString) throws BrokerException {
    String str = null;
    if (e == null)
      a(); 
    if (e == null) {
      str = "Resource BrokerErrors could not be loaded for error code " + paramString;
    } else {
      String[] arrayOfString = null;
      if (paramArrayOfString != null) {
        arrayOfString = new String[paramArrayOfString.length];
        for (byte b1 = 0; b1 < paramArrayOfString.length; b1++) {
          if (paramArrayOfString[b1] == null) {
            arrayOfString[b1] = "<null>";
          } else {
            arrayOfString[b1] = paramArrayOfString[b1];
          } 
        } 
      } 
      try {
        str = MessageFormat.format(e.getString(paramString), arrayOfString);
      } catch (MissingResourceException missingResourceException) {
        str = "Error " + paramString + " not defined in Resource BrokerErrors";
      } catch (NullPointerException nullPointerException) {
        str = "Error " + paramString;
      } 
    } 
    throw new BrokerException("0013", paramString, str, null, null);
  }
  
  public int getErrorClass() { return this.a; }
  
  public int getErrorCode() { return this.b; }
  
  public String getErrorInfo() { return this.c; }
  
  public String toString() { return this.d; }
  
  private static void a() {
    if (e == null)
      try {
        e = ResourceBundle.getBundle("com.softwareag.entirex.aci.BrokerErrors");
      } catch (MissingResourceException missingResourceException) {} 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\BrokerException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */