package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.k;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Properties;

public class Platform {
  private static final byte a = 32;
  
  private static final byte b = 64;
  
  private static final byte c = -64;
  
  private static final byte d = -5;
  
  public static void main(String[] paramArrayOfString) {
    EntireXVersion.main(paramArrayOfString);
    System.out.println();
    System.out.println("Java version=" + System.getProperty("java.version"));
    System.out.println("OS name=" + System.getProperty("os.name"));
    System.out.println("OS version=" + System.getProperty("os.version"));
    System.out.println("OS architecture=" + System.getProperty("os.arch"));
    byte[] arrayOfByte = { 1 };
    InputStreamReader inputStreamReader = new InputStreamReader(new ByteArrayInputStream(arrayOfByte));
    String str = inputStreamReader.getEncoding();
    System.out.println("Default encoding=" + str);
    Locale locale = Locale.getDefault();
    a();
    System.out.println("File encoding=" + System.getProperty("file.encoding"));
    System.out.println("Locale String=" + locale.getLanguage() + '_' + locale.getISO3Country());
    Properties properties = System.getProperties();
    System.out.println();
    Enumeration enumeration = properties.propertyNames();
    int i = properties.size();
    String[] arrayOfString = new String[i];
    byte b1 = 0;
    while (enumeration.hasMoreElements()) {
      String str1 = (String)enumeration.nextElement();
      str1 = str1 + " = " + properties.getProperty(str1);
      arrayOfString[b1++] = str1;
    } 
    k.a(arrayOfString);
    for (b1 = 0; b1 < i; b1++)
      System.out.println(arrayOfString[b1]); 
  }
  
  private static void a() {
    byte[] arrayOfByte = " {".getBytes();
    if (arrayOfByte[0] == 32) {
      System.out.println("Running on an ASCII machine.");
    } else if (arrayOfByte[0] == 64) {
      if (arrayOfByte[1] == -64) {
        System.out.println("Running on an EBCDIC IBM machine.");
      } else if (arrayOfByte[1] == -5) {
        System.out.println("Running on an EBCDIC SNI machine.");
      } else {
        System.out.println("Unknown character set, value for left brace=" + arrayOfByte[1]);
      } 
    } else {
      System.out.println("Unknown character set, value for blank=" + arrayOfByte[0]);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\Platform.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */