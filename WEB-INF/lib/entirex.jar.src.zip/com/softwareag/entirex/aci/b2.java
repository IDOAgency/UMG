package com.softwareag.entirex.aci;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class b2 implements ActionListener {
  private final Tester a;
  
  b2(Tester paramTester) { this.a = paramTester; }
  
  public void actionPerformed(ActionEvent paramActionEvent) { System.exit(0); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\b2.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */