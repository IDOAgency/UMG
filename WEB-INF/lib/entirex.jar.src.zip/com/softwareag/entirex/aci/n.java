package com.softwareag.entirex.aci;

import com.softwareag.entirex.cis.CommandService;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Enumeration;

class n extends Thread {
  protected static final int a = 2;
  
  protected static final int b = 3;
  
  protected static final int c = 7;
  
  protected static final int d = 10;
  
  protected boolean e = false;
  
  boolean f = false;
  
  protected boolean g = false;
  
  protected static final int h = 0;
  
  protected static final int i = 1;
  
  protected static final int j = 2;
  
  protected static final int k = 3;
  
  protected static final int l = 4;
  
  protected static final int m = 5;
  
  protected static final int n = 6;
  
  protected static final int o = 7;
  
  protected int p = 0;
  
  protected int q = 0;
  
  protected int r;
  
  private int s;
  
  private int t;
  
  private String u;
  
  private boolean v;
  
  private String w;
  
  private String x;
  
  private String y;
  
  private String z;
  
  private String aa;
  
  protected b ab;
  
  protected b ac;
  
  protected int ad;
  
  private static long ae = 60000L;
  
  int a() { return this.p; }
  
  n(b paramb1, m paramm, String paramString, b paramb2) {
    setName(paramString);
    this.ab = paramb1;
    this.ac = paramb2;
    if (paramm != null)
      paramb2.u().put(this, paramm); 
    this.w = paramb2.d("entirex.server.brokerid");
    this.x = paramb2.d("entirex.server.serveraddress");
    this.y = paramb2.d("entirex.server.userid");
    this.z = paramb2.d("entirex.server.password");
    this.aa = paramb2.d("entirex.server.security");
    this.t = paramb2.b("entirex.server.encryptionlevel");
    this.v = paramb2.c("entirex.server.encryption");
    this.s = paramb2.c();
    this.r = paramb2.z();
    this.u = paramb2.d("entirex.server.compresslevel");
    this.e = paramb2.d();
  }
  
  protected Broker b() {
    String str = this.w;
    if (str.indexOf('?') != -1 && str.toLowerCase().indexOf("poolsize=") != -1)
      return new Broker(str, this.y); 
    if (str.indexOf('?') == -1) {
      str = str + "?poolsize=" + this.s;
    } else {
      str = this.w;
    } 
    return new Broker(str, this.y);
  }
  
  protected void a(Broker paramBroker) throws BrokerException {
    if (this.aa.equals("") || Dump.c(this.aa)) {
      paramBroker.logon();
    } else if (this.aa.equalsIgnoreCase("auto")) {
      paramBroker.useEntireXSecurity(this.t, true);
      paramBroker.logon(this.z);
    } else {
      try {
        BrokerSecurity brokerSecurity;
        if (Dump.b(this.aa)) {
          brokerSecurity = new EntireXSecurity();
        } else {
          brokerSecurity = (BrokerSecurity)Class.forName(this.aa).newInstance();
        } 
        if (this.t != 0) {
          paramBroker.setSecurity(brokerSecurity, this.t);
        } else {
          paramBroker.setSecurity(brokerSecurity, this.v);
        } 
        paramBroker.logon(this.z);
      } catch (BrokerException brokerException) {
        throw brokerException;
      } catch (Exception exception) {
        System.out.println(exception);
        this;
        System.out.println("Illegal value for " + "entirex.server.security" + " = " + this.aa);
        System.exit(1);
      } 
    } 
    this.p = 2;
    this.ac.v().put(this, paramBroker.getUniqueID());
    paramBroker.setCompressionLevel(this.u);
  }
  
  protected final void a(Broker paramBroker, BrokerService paramBrokerService, boolean paramBoolean) {
    try {
      if (this.q > 0) {
        if (this.e)
          synchronized (System.out) {
            System.out.println("Reset number of restarts (was " + this.q + ", now 0) " + Thread.currentThread().getName());
          }  
        this.q = 0;
      } 
      this;
      String str = this.ab.d("entirex.server.serverlog");
      if (str != null && str.length() > 0) {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(str, true));
        this;
        bufferedWriter.write((paramBoolean ? " attach " : " ") + this.ab.d("entirex.server.name") + " started: PU=" + paramBroker.getUniqueID() + " BID=" + a(paramBroker.getBrokerID()) + " SC=" + paramBrokerService.getServerClass() + " SN=" + paramBrokerService.getServerName() + " SV=" + paramBrokerService.getServiceName() + " at " + this.ab.i() + System.getProperty("line.separator"));
        bufferedWriter.close();
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  protected final void a(Broker paramBroker, BrokerService paramBrokerService, boolean paramBoolean1, boolean paramBoolean2) {
    if (!this.f)
      try {
        this;
        String str = this.ab.d("entirex.server.serverlog");
        if (str != null && str.length() > 0) {
          BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(str, true));
          this;
          bufferedWriter.write((paramBoolean1 ? " attach " : " ") + this.ab.d("entirex.server.name") + (paramBoolean2 ? " with deregister" : "") + " stopped: PU=" + paramBroker.getUniqueID() + " BID=" + a(paramBroker.getBrokerID()) + " SC=" + paramBrokerService.getServerClass() + " SN=" + paramBrokerService.getServerName() + " SV=" + paramBrokerService.getServiceName() + " at " + this.ab.i() + System.getProperty("line.separator"));
          bufferedWriter.close();
        } 
      } catch (Exception exception) {
        exception.printStackTrace();
      }  
  }
  
  private String a(String paramString) {
    String str = null;
    if (paramString != null) {
      int i1 = paramString.indexOf("?");
      str = (i1 > -1) ? paramString.substring(0, i1) : paramString;
    } 
    return str;
  }
  
  protected boolean c() {
    boolean bool;
    if (this.f && !this.ac.t()) {
      this.q++;
      System.out.println(this.ab.i() + "/" + Thread.currentThread().getName() + " Waiting for next attempt (" + this.q + " of " + this.r + ") to start.");
      this.f = false;
      try {
        this.ac.aa();
      } catch (BrokerException brokerException) {
        if (brokerException.getErrorClass() == 250 && brokerException.getErrorCode() == 130) {
          Dump.log("During retry: " + brokerException);
        } else {
          brokerException.printStackTrace();
        } 
      } 
      this;
      String str = this.ac.d("entirex.server.brokerid");
      if (this.w.equals(str)) {
        synchronized (this) {
          this.ac.h("Retry");
          try {
            wait(ae);
          } catch (InterruptedException interruptedException) {}
        } 
      } else {
        this.w = str;
      } 
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  protected boolean a(int paramInt1, int paramInt2) { return (((paramInt1 == 13 && paramInt2 >= 300 && paramInt2 <= 313) || (paramInt2 >= 315 && paramInt2 <= 400) || (paramInt2 >= 402 && paramInt2 <= 405) || (paramInt1 == 215 && paramInt2 == 148)) && this.ad <= 1); }
  
  protected boolean b(int paramInt1, int paramInt2) {
    boolean bool = ((paramInt1 == 13 && paramInt2 == 120) || (paramInt1 == 20 && paramInt2 == 422) || this.ad == 3);
    if (bool) {
      m m1 = (m)this.ac.u().get(this);
      m1.g = bool;
      this.ac.h("Error");
    } 
    return bool;
  }
  
  protected void d() {
    Enumeration enumeration = this.ac.v().elements();
    CommandService commandService = new CommandService(this.w, this.y, this.z);
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      commandService.shutdownServer(str);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\n.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */