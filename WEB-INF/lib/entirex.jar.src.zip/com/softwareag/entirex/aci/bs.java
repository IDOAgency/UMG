package com.softwareag.entirex.aci;

import java.util.Properties;

public interface bs extends Cloneable {
  Properties y() throws be;
  
  void a(Properties paramProperties);
  
  byte[] aj();
  
  byte[] v();
  
  void c(byte[] paramArrayOfByte);
  
  byte[] z();
  
  void f(byte[] paramArrayOfByte);
  
  String d();
  
  void a(String paramString) throws be;
  
  String e();
  
  void b(String paramString) throws be;
  
  String f();
  
  void c(String paramString) throws be;
  
  String am();
  
  void f(String paramString) throws be;
  
  int g();
  
  void a(int paramInt) throws be;
  
  String h();
  
  void d(String paramString) throws be;
  
  boolean i() throws be;
  
  void a(boolean paramBoolean) throws BrokerException;
  
  int j();
  
  void b(int paramInt) throws be;
  
  void b(boolean paramBoolean) throws BrokerException;
  
  long k();
  
  void a(long paramLong);
  
  Object clone() throws CloneNotSupportedException;
  
  void k(int paramInt) throws be;
  
  void l(int paramInt) throws be;
  
  byte[] x();
  
  void t();
  
  void a(String paramString1, String paramString2);
  
  void e(String paramString) throws be;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\bs.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */