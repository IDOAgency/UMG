package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.s;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

public class BrokerService {
  private Broker a = null;
  
  private q b = null;
  
  private byte[] c = null;
  
  private byte[] d = null;
  
  private byte[] e = null;
  
  private String f;
  
  private String g = "60S";
  
  public static final String DEFAULT_WAITTIME = "60S";
  
  private int h = 7168;
  
  private boolean i = false;
  
  private boolean j;
  
  private boolean k = false;
  
  private static final s l = s.a();
  
  private StringBuffer m = new StringBuffer(98);
  
  private String n = null;
  
  protected s o = s.a();
  
  public Broker getBroker() { return this.a; }
  
  public final String toString() { return ((this.d == null) ? null : new String(this.d)) + '/' + ((this.c == null) ? null : new String(this.c)) + '/' + ((this.e == null) ? null : new String(this.e)); }
  
  final byte[] a() { return this.c; }
  
  public final String getServerName() { return new String(this.c); }
  
  final byte[] b() { return this.d; }
  
  public final String getServerClass() { return new String(this.d); }
  
  final byte[] c() { return this.e; }
  
  public final String getServiceName() { return new String(this.e); }
  
  public final String getEnvironment() { return this.f; }
  
  public final void setEnvironment(String paramString) { this.f = paramString; }
  
  public final String getDefaultWaittime() { return this.g; }
  
  public final void setDefaultWaittime(String paramString) { this.g = paramString; }
  
  public final int getMaxReceiveLen() { return this.h; }
  
  public final void setMaxReceiveLen(int paramInt) { this.h = paramInt; }
  
  public final void setAdjustReceiveLen(boolean paramBoolean) { this.i = paramBoolean; }
  
  final boolean d() { return this.i; }
  
  public final boolean isGeneric() { return this.j; }
  
  public final void useCodePage(boolean paramBoolean) { this.a.a().b(paramBoolean); }
  
  public final boolean useCodePage() { return this.a.a().t(); }
  
  final void a(Broker paramBroker) {
    this.a = paramBroker;
    if (paramBroker == null) {
      this.b = null;
    } else {
      this.b = paramBroker.a();
    } 
  }
  
  final void a(String paramString) {
    if (paramString == null) {
      this.d = null;
      this.c = null;
      this.e = null;
      return;
    } 
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, "/");
    try {
      this.d = stringTokenizer.nextToken().getBytes();
      this.c = stringTokenizer.nextToken().getBytes();
      this.e = stringTokenizer.nextToken().getBytes();
    } catch (NoSuchElementException noSuchElementException) {
      throw new IllegalArgumentException("BrokerService constructor: invalid server Address \"" + paramString + "\"");
    } 
    this.j = (this.d[0] == l.af || this.c[0] == l.af || this.e[0] == l.af);
  }
  
  BrokerService() {}
  
  public BrokerService(Broker paramBroker, String paramString) {
    if (paramBroker == null)
      throw new IllegalArgumentException("BrokerService constructor: no Broker specified"); 
    if (paramString == null)
      throw new IllegalArgumentException("BrokerService constructor: no server Address specified"); 
    a(paramString);
    a(paramBroker);
  }
  
  public BrokerService(Broker paramBroker, String paramString1, String paramString2, String paramString3) {
    if (paramBroker == null)
      throw new IllegalArgumentException("BrokerService constructor: no Broker specified"); 
    if (paramString1 == null || paramString2 == null || paramString3 == null)
      throw new IllegalArgumentException("BrokerService constructor: invalid server Address specified"); 
    this.d = paramString1.getBytes();
    this.c = paramString2.getBytes();
    this.e = paramString3.getBytes();
    this.j = (paramString1.equals("*") || paramString2.equals("*") || paramString3.equals("*"));
    a(paramBroker);
  }
  
  public final void register() { a(null); }
  
  public final void registerAttach() {
    this.k = true;
    a(q.a1);
  }
  
  final void a(byte[] paramArrayOfByte) throws BrokerException {
    if (this.j)
      BrokerException.a("0100", null); 
    this.a.b.put(toString(), this);
    synchronized (this.b) {
      this.b.u();
      this.b.a(this);
      this.b.d(paramArrayOfByte);
    } 
  }
  
  public final void deregister() {
    if (this.k) {
      b(q.at);
    } else {
      b(q.au);
    } 
  }
  
  public final void deregisterImmediate() { b(q.at); }
  
  private void b(byte[] paramArrayOfByte) throws BrokerException {
    if (!this.j)
      this.a.b.remove(toString()); 
    synchronized (this.b) {
      this.b.u();
      this.b.a(this);
      this.b.e(paramArrayOfByte);
    } 
  }
  
  public final void send(BrokerMessage paramBrokerMessage) throws BrokerException {
    if (this.j)
      BrokerException.a("0101", null); 
    if (this.k)
      BrokerException.a("0117", null); 
    if (paramBrokerMessage == null)
      throw new IllegalArgumentException("send: no message"); 
    synchronized (this.b) {
      this.b.u();
      this.b.a(this);
      this.b.a(paramBrokerMessage.getMessage());
      this.b.b(this.f);
      this.b.a("NONE", true, null);
    } 
  }
  
  public final BrokerMessage sendReceive(BrokerMessage paramBrokerMessage) throws BrokerException { return sendReceive(paramBrokerMessage, this.g); }
  
  public final BrokerMessage sendReceive(BrokerMessage paramBrokerMessage, String paramString) throws BrokerException {
    if (this.j)
      BrokerException.a("0102", null); 
    if (this.k)
      BrokerException.a("0117", null); 
    if (paramBrokerMessage == null)
      throw new IllegalArgumentException("send: no message"); 
    synchronized (this.b) {
      this.b.u();
      this.b.a(this);
      this.b.h(paramString);
      this.b.a(paramBrokerMessage.getMessage());
      this.b.b(this.f);
      this.b.a(this.h);
      this.b.a(this.i);
      this.b.a("NONE", false, null);
      BrokerMessage brokerMessage = new BrokerMessage();
      brokerMessage.setMessage(this.b.a());
      if (this.i)
        this.h = Math.max(this.h, this.b.b()); 
      return brokerMessage;
    } 
  }
  
  public final BrokerMessage receive() throws BrokerException { return a(this.g, "NEW", q.ar); }
  
  public final BrokerMessage receive(String paramString) throws BrokerException { return a(paramString, "NEW", q.ar); }
  
  public final BrokerMessage receiveOld() throws BrokerException { return a(this.g, "OLD", q.ar); }
  
  public final BrokerMessage receiveAny() throws BrokerException { return a(this.g, "ANY", q.ar); }
  
  BrokerMessage a(String paramString1, String paramString2, byte[] paramArrayOfByte) throws BrokerException {
    if (this.k)
      BrokerException.a("0117", null); 
    synchronized (this.b) {
      BrokerService brokerService;
      this.b.u();
      this.b.a(this);
      this.b.h(paramString1);
      this.b.b(this.f);
      this.b.a(this.h);
      this.b.a(this.i);
      this.b.b(paramString2, paramArrayOfByte);
      if (this.i)
        this.h = Math.max(this.h, this.b.b()); 
      String str1 = this.b.g();
      BrokerMessage brokerMessage = new BrokerMessage();
      brokerMessage.setMessage(this.b.a());
      brokerMessage.a(this.b.k());
      if (this.j) {
        String str = this.b.c() + "/" + this.b.d() + "/" + this.b.e();
        brokerService = (BrokerService)this.a.b.get(str);
        if (brokerService == null)
          BrokerException.a("0103", null); 
      } else {
        brokerService = this;
      } 
      brokerMessage.a(brokerService);
      String str2 = this.b.n();
      String str3 = this.b.l();
      if (str2 == null || str2.equals("RECV_NONE")) {
        if (str3 == null || str3.equals("NONE")) {
          brokerMessage.b(str1);
        } else {
          if (str3 != null && str3.equals("OLD") && paramString2.equals("NEW"))
            BrokerException.a("0104", null); 
          Conversation conversation = new Conversation(brokerService, str1, this.b);
          if (conversation.getBrokerService() != brokerService)
            BrokerException.a("0105", null); 
          brokerMessage.a(conversation);
        } 
      } else {
        UnitofWorkTopic unitofWorkTopic = this.b.ae() ? new UnitofWorkTopic((BrokerTopic)brokerService, str1) : new UnitofWork(brokerService, str1);
        unitofWorkTopic.b(this.b.o());
        unitofWorkTopic.a(str2);
        unitofWorkTopic.setUserStatus(this.b.p());
        unitofWorkTopic.m = this.b.i();
        brokerMessage.a(unitofWorkTopic);
        unitofWorkTopic.d = false;
      } 
      return brokerMessage;
    } 
  }
  
  public final boolean replyError(String paramString1, String paramString2) throws BrokerException {
    boolean bool = false;
    if (this.j)
      BrokerException.a("0101", null); 
    if (this.k)
      BrokerException.a("0117", null); 
    if (paramString1 == null)
      throw new IllegalArgumentException("replyError: error code missing"); 
    if (getBroker().d()) {
      synchronized (this.b) {
        this.b.a(this);
        this.b.a((paramString1 + ":" + paramString2).getBytes());
        this.b.b(this.f);
        this.b.y();
      } 
      bool = true;
    } 
    return bool;
  }
  
  public final void endallConversations() {
    if (this.k)
      BrokerException.a("0117", null); 
    synchronized (this.b) {
      this.b.u();
      this.b.a(this);
      this.b.c("ANY", null);
    } 
  }
  
  public final void cancelallConversations() {
    if (this.k)
      BrokerException.a("0117", null); 
    synchronized (this.b) {
      this.b.u();
      this.b.a(this);
      this.b.c("ANY", q.av);
    } 
  }
  
  public final BrokerAttachInfo receiveAttachInfo() throws BrokerException {
    synchronized (this.b) {
      this.b.u();
      this.b.a(this);
      this.b.h(this.g);
      this.b.a(200);
      this.b.a(false);
      int i1 = this.b.ad();
      this.b.e(0);
      this.b.b("NEW", null);
      this.b.e(i1);
      byte[] arrayOfByte = this.b.a();
      BrokerAttachInfo brokerAttachInfo = new BrokerAttachInfo();
      brokerAttachInfo.missingServers = q.a(arrayOfByte, 4);
      brokerAttachInfo.replicates = q.a(arrayOfByte, 8);
      brokerAttachInfo.pendingConversations = q.a(arrayOfByte, 12);
      brokerAttachInfo.activeConversations = q.a(arrayOfByte, 16);
      this.m.setLength(0);
      this.m.append((new String(arrayOfByte, 20, 32)).trim());
      this.m.append('/');
      this.m.append((new String(arrayOfByte, 52, 32)).trim());
      this.m.append('/');
      this.m.append((new String(arrayOfByte, 84, 32)).trim());
      brokerAttachInfo.serverAddress = this.m.toString();
      return brokerAttachInfo;
    } 
  }
  
  public final void setLogicalService(String paramString) {
    BrokerService brokerService = LocationTransparencyService.lookupBrokerService(paramString);
    a(brokerService.getBroker());
    a(brokerService.toString());
  }
  
  public final void setLogicalService(String paramString1, String paramString2) throws BrokerException {
    BrokerService brokerService = LocationTransparencyService.lookupBrokerService(paramString1, paramString2);
    a(brokerService.getBroker());
    a(brokerService.toString());
  }
  
  public final void setLogicalBroker(String paramString) {
    Broker broker = LocationTransparencyService.lookupBroker(paramString);
    a(broker);
  }
  
  public final void setLogicalBroker(String paramString1, String paramString2) throws BrokerException {
    Broker broker = LocationTransparencyService.lookupBroker(paramString1, paramString2);
    a(broker);
  }
  
  protected final void a(String paramString1, String paramString2, String paramString3) throws BrokerException {
    Broker broker = LocationTransparencyService.lookupBroker(paramString1, paramString3);
    a(broker);
    a(paramString2);
  }
  
  public void setCharacterEncoding(String paramString) {
    this.n = paramString;
    if (this.n != null) {
      try {
        if (paramString.equalsIgnoreCase("LOCAL")) {
          byte[] arrayOfByte = { 1 };
          InputStreamReader inputStreamReader = new InputStreamReader(new ByteArrayInputStream(arrayOfByte));
          paramString = inputStreamReader.getEncoding();
        } 
        useCodePage(true);
        this.o = s.a(paramString);
        this.a.a().a(paramString);
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        BrokerException.a("0121", new String[] { paramString });
      } 
    } else {
      this.o = s.a();
      this.a.a().a(null);
    } 
  }
  
  public String getCharacterEncoding() { return this.n; }
  
  public s getEncodingConstants() { return this.o; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\BrokerService.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */