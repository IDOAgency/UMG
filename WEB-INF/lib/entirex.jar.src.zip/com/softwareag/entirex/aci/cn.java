package com.softwareag.entirex.aci;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.Vector;

final class cn {
  private static final boolean a = (System.getProperty("entirex.tester.verbose", "").length() > 0);
  
  private int b;
  
  private int c;
  
  private Field d;
  
  private cn e;
  
  private int[] f;
  
  private boolean g = false;
  
  private boolean h = false;
  
  private Class i;
  
  private Tester2 j;
  
  private String k = "*";
  
  private static Vector l = new Vector();
  
  static Class m;
  
  static Class n;
  
  static Class o;
  
  static Class p;
  
  static Class q;
  
  private Object a(Object paramObject) throws Exception {
    Method method;
    switch (this.b) {
      case 1:
        return Array.get(this.j.r(), this.c);
      case 3:
        return this.d.get(paramObject);
      case 4:
        method = b(paramObject.getClass(), "get" + this.d.getName());
        return method.invoke(paramObject, new Object[0]);
      case 2:
        return this.j.q();
    } 
    throw new Exception("TesterAccessor.getter: invalid type " + this.b);
  }
  
  private void a(Object paramObject1, Object paramObject2) throws Exception {
    Method method;
    switch (this.b) {
      case 1:
        Array.set(this.j.r(), this.c, paramObject2);
        return;
      case 3:
        if (a)
          System.out.println("setter: field: " + this.d + " instance: " + paramObject1.getClass() + " value: " + paramObject2.getClass()); 
        this.d.set(paramObject1, paramObject2);
        return;
      case 4:
        method = b(paramObject1.getClass(), "set" + this.d.getName());
        method.invoke(paramObject1, new Object[] { paramObject2 });
        return;
    } 
    throw new Exception("TesterAccessor.setter: invalid type " + this.b);
  }
  
  cn(Tester2.com/softwareag/entirex/aci/b8 paramcom/softwareag/entirex/aci/b8, Tester2 paramTester2, boolean paramBoolean) throws Exception {
    StringTokenizer stringTokenizer = new StringTokenizer(paramcom/softwareag/entirex/aci/b8.a, ".");
    this.j = paramTester2;
    this.b = paramcom/softwareag/entirex/aci/b8.f;
    String str = stringTokenizer.nextToken();
    this.k = str;
    if (a)
      System.out.print("Accessor: " + paramcom/softwareag/entirex/aci/b8.a + " Name=" + str + " Type=" + this.b + " NextTokens=" + stringTokenizer.countTokens()); 
    switch (this.b) {
      case 5:
        i1 = str.indexOf(' ');
        if (paramBoolean) {
          this.c = Integer.parseInt(str.substring(0, i1)) - 1;
          this.b = 1;
        } else {
          this.d = a(paramTester2.s().getClass(), str.substring(i1 + 1));
          this.b = 3;
        } 
        this.i = paramTester2.a(this.c);
        break;
      case 1:
        this.c = Integer.parseInt(str) - 1;
        this.i = paramTester2.a(this.c);
        break;
      case 3:
      case 4:
        this.d = a(paramTester2.s().getClass(), str);
        this.i = this.d.getType();
        break;
      case 2:
        this.i = paramTester2.p();
        break;
      default:
        throw new Exception("TesterAccessor: invalid type " + this.b);
    } 
    if (a)
      System.out.println(" Class=" + this.i + " Field=" + this.d); 
    a(stringTokenizer);
  }
  
  private cn(StringTokenizer paramStringTokenizer, cn paramcn, String paramString) throws Exception {
    this.k = paramString;
    this.j = paramcn.j;
    if (a)
      System.out.print("Accessor: Name=" + paramString + " NextTokens=" + paramStringTokenizer.countTokens()); 
    this.b = 3;
    this.d = a(paramcn.i, paramString);
    this.i = this.d.getType();
    if (a)
      System.out.println(" Type=" + this.i + " Field=" + this.d); 
    a(paramStringTokenizer);
  }
  
  private void a(StringTokenizer paramStringTokenizer, String paramString) throws Exception {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, "[],");
    int i1 = stringTokenizer.countTokens();
    this.f = new int[i1];
    for (byte b1 = 0; b1 < i1; b1++) {
      this.i = this.i.getComponentType();
      String str = stringTokenizer.nextToken();
      if (str.equals("V")) {
        this.h = true;
        this.f[b1] = 1;
      } else {
        this.g = true;
        this.f[b1] = Integer.parseInt(str);
      } 
    } 
    if (paramStringTokenizer.hasMoreElements())
      this.e = new cn(paramStringTokenizer, this, paramStringTokenizer.nextToken()); 
  }
  
  private void a(StringTokenizer paramStringTokenizer) throws Exception {
    if (!paramStringTokenizer.hasMoreElements())
      return; 
    String str = paramStringTokenizer.nextToken();
    if (a)
      System.out.println("processList: Name = " + str); 
    if (str.charAt(0) == '[') {
      a(paramStringTokenizer, str);
    } else {
      this.e = new cn(paramStringTokenizer, this, str);
    } 
  }
  
  private static boolean a(cn paramcn) { return (paramcn == null) ? false : ((paramcn.h || a(paramcn.e))); }
  
  private static boolean a(Object paramObject, int[] paramArrayOfInt) {
    for (byte b1 = 0; b1 < paramArrayOfInt.length; b1++) {
      if (paramObject == null)
        return true; 
      if (paramArrayOfInt[b1] != Array.getLength(paramObject))
        return true; 
      if (Array.getLength(paramObject) > 0) {
        paramObject = Array.get(paramObject, 0);
      } else {
        paramObject = null;
      } 
    } 
    return false;
  }
  
  private void a(Object paramObject, int paramInt) throws Exception {
    if (this.e != null) {
      Object object = Array.get(paramObject, paramInt);
      if (object == null) {
        Constructor[] arrayOfConstructor = this.i.getDeclaredConstructors();
        object = arrayOfConstructor[0].newInstance(new Object[] { this.j.s() });
        Array.set(paramObject, paramInt, object);
      } 
      this.e.c(object);
    } else {
      Array.set(paramObject, paramInt, c());
    } 
  }
  
  private void b(Object paramObject) throws Exception {
    Object object = a(paramObject);
    if (object == null) {
      Constructor[] arrayOfConstructor = this.i.getDeclaredConstructors();
      object = arrayOfConstructor[0].newInstance(new Object[] { this.j.s() });
      a(paramObject, object);
    } 
    this.e.c(object);
  }
  
  private Object c() throws Exception {
    if (this.i == ((m == null) ? (m = class$("java.lang.String")) : m))
      return this.j.g(); 
    if (this.i == ((n == null) ? (n = class$("java.lang.StringBuffer")) : n))
      return new StringBuffer(this.j.g()); 
    if (this.i == char.class) {
      String str = this.j.g();
      return (str.length() > 0) ? new Character(str.charAt(0)) : new Character(' ');
    } 
    if (this.i == int.class)
      return new Integer(this.j.j()); 
    if (this.i == short.class)
      return new Short(this.j.k()); 
    if (this.i == byte.class)
      return new Byte(this.j.l()); 
    if (this.i == boolean.class)
      return new Boolean(this.j.f()); 
    if (this.i == ((o == null) ? (o = class$("java.math.BigDecimal")) : o))
      return this.j.i(); 
    if (this.i == ((p == null) ? (p = class$("java.util.Date")) : p))
      return this.j.o(); 
    if (this.i == ((q == null) ? (q = class$("[B")) : q))
      return this.j.h(); 
    if (this.i == float.class)
      return new Float(this.j.m()); 
    if (this.i == double.class)
      return new Double(this.j.n()); 
    throw new Exception("getSimpleObject failed: " + this.i);
  }
  
  void a() throws Exception { c(this.j.s()); }
  
  private void c(Object paramObject) throws Exception {
    if (this.g || this.h) {
      this.j.b();
      if (this.h)
        if (a(this.e)) {
          this.f[this.f.length - 1] = 1;
        } else {
          this.f[this.f.length - 1] = this.j.a();
        }  
      Object object = a(paramObject);
      if (object == null) {
        object = Array.newInstance(this.i, this.f);
        a(paramObject, object);
        l.addElement(object);
      } else if (this.h && a(object, this.f) && !l.contains(object)) {
        object = Array.newInstance(this.i, this.f);
        a(paramObject, object);
        l.addElement(object);
      } 
      if (this.f.length == 3) {
        if (this.h)
          this.f[2] = Array.getLength(Array.get(Array.get(object, 0), 0)); 
        for (byte b1 = 0; b1 < this.f[0]; b1++) {
          Object object1 = Array.get(object, b1);
          for (byte b2 = 0; b2 < this.f[1]; b2++) {
            Object object2 = Array.get(object1, b2);
            for (byte b3 = 0; b3 < this.f[2]; b3++)
              a(object2, b3); 
          } 
        } 
      } else if (this.f.length == 2) {
        if (this.h)
          this.f[1] = Array.getLength(Array.get(object, 0)); 
        for (byte b1 = 0; b1 < this.f[0]; b1++) {
          Object object1 = Array.get(object, b1);
          for (byte b2 = 0; b2 < this.f[1]; b2++)
            a(object1, b2); 
        } 
      } else {
        if (this.h)
          this.f[0] = Array.getLength(object); 
        for (byte b1 = 0; b1 < this.f[0]; b1++)
          a(object, b1); 
      } 
      this.j.c();
    } else if (this.e != null) {
      b(paramObject);
    } else {
      Object object = c();
      a(paramObject, object);
    } 
  }
  
  private void a(Class paramClass, Object paramObject) throws Exception {
    if (this.e != null) {
      this.e.d(paramObject);
    } else if (paramClass == ((q == null) ? (q = class$("[B")) : q)) {
      this.j.a((byte[])paramObject);
    } else if (paramClass == ((p == null) ? (p = class$("java.util.Date")) : p)) {
      this.j.a((Date)paramObject);
    } else {
      this.j.a(paramObject.toString());
    } 
  }
  
  void b() throws Exception {
    l.setSize(0);
    d(this.j.s());
  }
  
  private void d(Object paramObject) throws Exception {
    Object object = a(paramObject);
    if (this.g || this.h) {
      this.j.d();
      if (this.f.length == 3) {
        for (byte b1 = 0; b1 < Array.getLength(object); b1++) {
          Object object1 = Array.get(object, b1);
          for (byte b2 = 0; b2 < Array.getLength(object1); b2++) {
            Object object2 = Array.get(object1, b2);
            for (byte b3 = 0; b3 < Array.getLength(object2); b3++)
              a(this.i, Array.get(object2, b3)); 
          } 
        } 
      } else if (this.f.length == 2) {
        for (byte b1 = 0; b1 < Array.getLength(object); b1++) {
          Object object1 = Array.get(object, b1);
          for (byte b2 = 0; b2 < Array.getLength(object1); b2++)
            a(this.i, Array.get(object1, b2)); 
        } 
      } else {
        for (byte b1 = 0; b1 < Array.getLength(object); b1++)
          a(this.i, Array.get(object, b1)); 
      } 
      this.j.e();
    } else {
      a(this.i, object);
    } 
  }
  
  private Field a(Class paramClass, String paramString) throws Exception {
    Field[] arrayOfField = paramClass.getDeclaredFields();
    for (byte b1 = 0; b1 < arrayOfField.length; b1++) {
      Field field = arrayOfField[b1];
      if (paramString.equalsIgnoreCase(field.getName())) {
        this.j.a(field);
        return field;
      } 
    } 
    throw new NoSuchFieldException("Field " + paramString + " in class " + paramClass.getName() + " not found");
  }
  
  private Method b(Class paramClass, String paramString) throws Exception {
    Method[] arrayOfMethod = paramClass.getMethods();
    for (byte b1 = 0; b1 < arrayOfMethod.length; b1++) {
      Method method = arrayOfMethod[b1];
      if (paramString.equalsIgnoreCase(method.getName())) {
        this.j.a(method);
        return method;
      } 
    } 
    throw new NoSuchMethodException("Method " + paramString + " in class " + paramClass.getName() + " not found");
  }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\cn.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */