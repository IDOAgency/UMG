package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.ac;
import com.softwareag.entirex.base.bm;
import com.softwareag.entirex.base.s;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

public final class Marshal extends bm {
  private s a = s.a();
  
  private String b = null;
  
  private int c = 0;
  
  private int d;
  
  private byte[] e;
  
  private String f;
  
  private Calendar g = Calendar.getInstance();
  
  private char[] h = new char[0];
  
  private String i = " ";
  
  private static final int j = 4;
  
  private static final int k = 6;
  
  private static final int l = 11;
  
  public Marshal() { this(0); }
  
  public Marshal(int paramInt) {
    this.c = paramInt;
    try {
      this.f = System.getProperty("entirex.marshal.date", "");
    } catch (SecurityException securityException) {
      this.f = null;
    } 
  }
  
  public Marshal(int paramInt, String paramString) throws BrokerException {
    this.c = paramInt;
    a(paramString);
    try {
      this.f = System.getProperty("entirex.marshal.date", "");
    } catch (SecurityException securityException) {
      this.f = null;
    } 
  }
  
  public Marshal(int paramInt, s params) {
    this.c = paramInt;
    this.a = params;
    this.b = params.b();
    try {
      this.f = System.getProperty("entirex.marshal.date", "");
    } catch (SecurityException securityException) {
      this.f = null;
    } 
  }
  
  protected void a(s params) {
    this.a = params;
    this.b = this.a.b();
  }
  
  protected void a(String paramString) throws BrokerException {
    this.b = paramString;
    try {
      this.a = s.a(this.b);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      BrokerException.a("0121", new String[] { this.b });
    } 
  }
  
  protected void a(int paramInt) { this.c = paramInt; }
  
  protected void b(int paramInt) { this.d = paramInt; }
  
  protected int a() { return this.d; }
  
  public final void setBuffer(byte[] paramArrayOfByte, int paramInt) {
    this.e = paramArrayOfByte;
    this.d = paramInt;
  }
  
  protected byte[] b() { return this.e; }
  
  void a(String paramString, int paramInt) { a(paramString, 0, paramInt); }
  
  void a(String paramString, int paramInt1, int paramInt2) {
    if (paramString == null)
      throw new IllegalArgumentException("appendNumber: wrong parameter, value=" + paramString); 
    if (paramInt2 <= 0)
      return; 
    int m = paramString.length();
    a(this.a.j, paramInt2 - m + paramInt1);
    for (int n = paramInt1; n < m; n++)
      a(this.a.t[paramString.charAt(n) - '0']); 
  }
  
  void b(String paramString) throws BrokerException {
    if (paramString == null)
      throw new IllegalArgumentException("appendNumber: wrong parameter " + paramString); 
    int m = paramString.length();
    for (byte b1 = 0; b1 < m; b1++)
      a(this.a.t[paramString.charAt(b1) - '0']); 
  }
  
  void c(int paramInt) { a(this.a.j, paramInt); }
  
  void b(String paramString, int paramInt) { a(false, paramString, paramInt); }
  
  private void a(boolean paramBoolean, String paramString, int paramInt) throws BrokerException {
    if (paramString == null) {
      if (paramBoolean) {
        e(0);
      } else {
        d(paramInt);
      } 
      return;
    } 
    if (paramString.length() > paramInt)
      paramString = paramString.substring(0, paramInt); 
    if (d(paramString)) {
      if (paramBoolean) {
        paramInt = paramString.length();
        e(paramInt);
        d(paramInt);
      } else {
        d(paramInt);
      } 
    } else {
      byte[] arrayOfByte;
      for (arrayOfByte = h(paramString); arrayOfByte.length > paramInt; arrayOfByte = h(paramString))
        paramString = paramString.substring(0, paramString.length() - 1); 
      if (paramBoolean)
        e(arrayOfByte.length); 
      b(arrayOfByte);
      if (!paramBoolean && paramInt > arrayOfByte.length)
        d(paramInt - arrayOfByte.length); 
    } 
  }
  
  void c(String paramString) throws BrokerException {
    if (paramString == null)
      return; 
    if (d(paramString)) {
      d(paramString.length());
    } else {
      b(h(paramString));
    } 
  }
  
  void a(byte[] paramArrayOfByte) { b(paramArrayOfByte); }
  
  void d(int paramInt) { a(this.a.g, paramInt); }
  
  void e(int paramInt) {
    b(ac.a(paramInt, this.a));
    a(this.a.e);
  }
  
  private boolean d(String paramString) {
    int m = paramString.length();
    for (byte b1 = 0; b1 < m; b1++) {
      if (paramString.charAt(b1) != ' ')
        return false; 
    } 
    return true;
  }
  
  public void addDataA(String paramString, int paramInt) { b(paramString, paramInt); }
  
  public void addDataAV(String paramString) throws BrokerException {
    if (paramString == null) {
      e(0);
      return;
    } 
    byte[] arrayOfByte = h(paramString);
    e(arrayOfByte.length);
    b(arrayOfByte);
  }
  
  public void addDataAV(String paramString, int paramInt) { a(true, paramString, paramInt); }
  
  public void addDataB(byte[] paramArrayOfByte, int paramInt) {
    if (this.c < 2000) {
      if (paramArrayOfByte == null) {
        c(2 * paramInt);
        return;
      } 
      for (byte b1 = 0; b1 < paramInt; b1++) {
        if (b1 < paramArrayOfByte.length) {
          a(this.a.u[paramArrayOfByte[b1] >> 4 & 0xF]);
          a(this.a.u[paramArrayOfByte[b1] & 0xF]);
        } else {
          c(2);
        } 
      } 
    } else {
      byte[] arrayOfByte = new byte[paramInt];
      if (paramArrayOfByte != null)
        if (paramArrayOfByte.length == paramInt) {
          arrayOfByte = paramArrayOfByte;
        } else if (paramArrayOfByte.length < paramInt) {
          System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, paramArrayOfByte.length);
        } else {
          System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, arrayOfByte.length);
        }  
      c(arrayOfByte);
    } 
  }
  
  private void c(byte[] paramArrayOfByte) {
    if (paramArrayOfByte == null) {
      e(0);
    } else {
      e(j.a(paramArrayOfByte.length));
      c(j.a(paramArrayOfByte));
    } 
  }
  
  public void addDataBV(byte[] paramArrayOfByte) {
    if (this.c < 2000) {
      if (paramArrayOfByte == null) {
        e(0);
        return;
      } 
      e(paramArrayOfByte.length * 2);
      addDataB(paramArrayOfByte, paramArrayOfByte.length);
    } else {
      c(paramArrayOfByte);
    } 
  }
  
  public void addDataBV(byte[] paramArrayOfByte, int paramInt) {
    if (this.c < 2000) {
      if (paramArrayOfByte == null || paramInt <= 0) {
        e(0);
        return;
      } 
      if (paramArrayOfByte.length < paramInt) {
        e(paramArrayOfByte.length * 2);
        addDataB(paramArrayOfByte, paramArrayOfByte.length);
      } else {
        e(paramInt * 2);
        addDataB(paramArrayOfByte, paramInt);
      } 
    } else if (paramArrayOfByte != null && paramArrayOfByte.length > paramInt) {
      byte[] arrayOfByte = new byte[paramInt];
      System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, paramInt);
      c(arrayOfByte);
    } else {
      c(paramArrayOfByte);
    } 
  }
  
  public void addDataN(BigDecimal paramBigDecimal, int paramInt1, int paramInt2) throws BrokerException {
    if (paramBigDecimal == null || paramBigDecimal.signum() == 0) {
      a(this.a.i);
      a(this.a.j, paramInt1 + paramInt2);
      return;
    } 
    String str = paramBigDecimal.setScale(paramInt2, 4).toString();
    int m = 0;
    if (str.charAt(0) == '-') {
      a(this.a.h);
      m = 1;
    } else {
      a(this.a.i);
    } 
    int n = str.indexOf('.');
    if (n == -1) {
      if (str.length() - m > paramInt1)
        BrokerException.a("0209", new String[] { str, Integer.toString(paramInt1), Integer.toString(paramInt2) }); 
      a(str, m, paramInt1);
      c(paramInt2);
    } else {
      if (n - m > paramInt1)
        BrokerException.a("0209", new String[] { str, Integer.toString(paramInt1), Integer.toString(paramInt2) }); 
      a(str.substring(m, n), paramInt1);
      int i1 = str.length() - n - 1;
      if (i1 == paramInt2) {
        c(str.substring(n + 1));
      } else if (i1 > paramInt2) {
        c(str.substring(n + 1, n + 1 + paramInt2));
      } else {
        c(str.substring(n + 1));
        c(paramInt2 - i1);
      } 
    } 
  }
  
  public void addDataD(String paramString, int paramInt) {
    if (paramInt <= 8) {
      paramInt = 8;
    } else {
      paramInt = 15;
    } 
    b(paramString, paramInt);
  }
  
  public void addDataD(Date paramDate, int paramInt) {
    if (paramDate == null) {
      if (this.f == null) {
        this.g.setTime(new Date());
        addDataD(this.g, paramInt);
      } else if (this.f.equalsIgnoreCase("null")) {
        if (paramInt == 8) {
          a("00000101", 8);
        } else {
          a("000001010000000", 15);
        } 
      } else if (this.f.length() == 8) {
        if (paramInt == 8) {
          a(this.f, 8);
        } else {
          a(this.f + "0000000", 15);
        } 
      } else if (this.f.length() == 15) {
        if (paramInt == 8) {
          a(this.f.substring(0, 8), 8);
        } else {
          a(this.f, 15);
        } 
      } else {
        this.g.setTime(new Date());
        addDataD(this.g, paramInt);
      } 
    } else {
      this.g.clear();
      this.g.setTime(paramDate);
      addDataD(this.g, paramInt);
    } 
  }
  
  public void addDataD(Calendar paramCalendar, int paramInt) {
    if (paramCalendar == null) {
      paramCalendar = Calendar.getInstance();
      paramCalendar.setTime(new Date());
    } 
    int m = paramCalendar.get(1);
    if (m > 9999)
      m = 9999; 
    a(Integer.toString(m), 4);
    a(Integer.toString(paramCalendar.get(2) + 1), 2);
    a(Integer.toString(paramCalendar.get(5)), 2);
    if (paramInt == 15) {
      a(Integer.toString(paramCalendar.get(11)), 2);
      a(Integer.toString(paramCalendar.get(12)), 2);
      a(Integer.toString(paramCalendar.get(13)), 2);
      a(Integer.toString(paramCalendar.get(14) / 100), 1);
    } 
  }
  
  public void addDataI(String paramString, int paramInt) {
    if (paramString == null || paramString.length() == 0) {
      a(this.a.i);
      c(paramInt - 1);
    } else if (paramString.charAt(0) == '-') {
      a(this.a.h);
      a(paramString, 1, paramInt - 1);
    } else if (paramString.charAt(0) == '+') {
      a(this.a.i);
      a(paramString, 1, paramInt - 1);
    } else {
      a(this.a.i);
      a(paramString, paramInt - 1);
    } 
  }
  
  public void addDataF(String paramString, int paramInt) {
    if (paramString == null || paramString.length() == 0 || paramString.equals("0") || paramString.equals("+0") || paramString.equals("-0")) {
      if (paramInt == 6) {
        b(this.a.aa);
      } else if (paramInt == 15) {
        b(this.a.ab);
      } else {
        throw new IllegalArgumentException("addDataF: illegal length " + paramInt);
      } 
    } else {
      int i1;
      if (paramString.charAt(0) == '-') {
        a(this.a.h);
        paramString = paramString.substring(1);
      } else {
        a(this.a.i);
      } 
      int m = paramString.indexOf('.');
      if (m > 0) {
        b(paramString.substring(0, 1));
      } else if (m == -1) {
        b(paramString.substring(0, 1));
      } else {
        c(1);
      } 
      a(this.a.c);
      int n = paramString.indexOf('E', 1);
      if (m > 0)
        c(paramString.substring(1, m)); 
      if (n == -1) {
        if (paramString.length() <= paramInt + 2) {
          if (m > -1) {
            b(paramString.substring(m + 1));
          } else {
            b(paramString.substring(1));
          } 
          if (m > 0) {
            c(paramInt - paramString.length() - 2);
          } else {
            c(paramInt - paramString.length() - 2 - 1);
          } 
        } else {
          if (m > -1) {
            b(paramString.substring(m + 1, paramInt + 2));
          } else {
            b(paramString.substring(1, paramInt + 1));
          } 
          this.d = this.d - paramString.length() + paramInt + 2;
        } 
      } else if (n <= paramInt + 2) {
        if (m > -1) {
          b(paramString.substring(m + 1, n));
        } else {
          b(paramString.substring(1, n));
        } 
        if (m > 0) {
          c(paramInt - n - 2);
        } else {
          c(paramInt - n - 2 - 1);
        } 
      } else {
        if (m > -1) {
          b(paramString.substring(m + 1, paramInt + 2));
        } else {
          b(paramString.substring(1, paramInt + 1));
        } 
        this.d = this.d - n + paramInt + 2;
      } 
      a(this.a.v);
      if (n == -1) {
        i1 = 0;
      } else if (paramString.charAt(n + 1) == '-') {
        i1 = -Integer.parseInt(paramString.substring(n + 2));
      } else if (paramString.charAt(n + 1) == '+') {
        i1 = Integer.parseInt(paramString.substring(n + 2));
      } else {
        i1 = Integer.parseInt(paramString.substring(n + 1));
      } 
      if (m > 0) {
        i1 = i1 + m - 1;
      } else if (m == -1) {
        i1 = (n == -1) ? (paramString.length() - 1) : (i1 + n - 1);
      } 
      if (i1 < 0) {
        a(this.a.h);
        i1 = -i1;
      } else {
        a(this.a.i);
      } 
      if (i1 > 99)
        BrokerException.a("0212", new String[] { paramString, Integer.toString(i1) }); 
      a(Integer.toString(i1), 2);
    } 
  }
  
  int c() {
    int m = 0;
    byte b1 = 0;
    for (int n = this.d; n < this.e.length; n++) {
      if (this.e[n] == this.a.e) {
        m = n - this.d;
        break;
      } 
      b1 = b1 * 10 + this.e[n] - this.a.j;
    } 
    this.d += m + 1;
    return b1;
  }
  
  private String f(int paramInt) {
    if (paramInt == this.i.length())
      return this.i; 
    if (paramInt <= this.h.length) {
      this.i = new String(this.h, 0, paramInt);
      return this.i;
    } 
    this.h = new char[paramInt];
    for (byte b1 = 0; b1 < paramInt; b1++)
      this.h[b1] = ' '; 
    this.i = new String(this.h);
    return this.i;
  }
  
  private byte f() { return this.e[this.d++]; }
  
  private String g(int paramInt) {
    String str = null;
    try {
      boolean bool = true;
      for (int m = this.d; m < this.d + paramInt; m++) {
        if (this.e[m] != this.a.g)
          bool = false; 
      } 
      if (bool) {
        str = f(paramInt);
      } else if (this.b == null) {
        str = new String(this.e, this.d, paramInt);
      } else {
        try {
          str = new String(this.e, this.d, paramInt, this.b);
        } catch (UnsupportedEncodingException unsupportedEncodingException) {
          BrokerException.a("0121", new String[] { this.b });
          str = null;
        } 
      } 
      this.d += paramInt;
    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
      BrokerException.a("0202", new String[] { "" + this.e.length });
    } 
    return str;
  }
  
  private int g() {
    byte b1 = 0;
    if (this.d + 2 > this.e.length) {
      BrokerException.a("0202", new String[] { "" + this.e.length });
    } else {
      if (this.e[this.d] >= this.a.j && this.e[this.d] <= this.a.s) {
        b1 = this.e[this.d++] - this.a.j;
      } else {
        b1 = this.e[this.d++] - this.a.u[10] + 10;
      } 
      if (this.e[this.d] >= this.a.j && this.e[this.d] <= this.a.s) {
        b1 = (b1 << 4) + this.e[this.d++] - this.a.j;
      } else {
        b1 = (b1 << 4) + this.e[this.d++] - this.a.u[10] + 10;
      } 
    } 
    return b1;
  }
  
  private int h(int paramInt) throws BrokerException {
    int m = 0;
    if (this.d + paramInt > this.e.length) {
      BrokerException.a("0202", new String[] { "" + this.e.length });
    } else if (this.e[this.d] == this.a.i || this.e[this.d] == this.a.h) {
      m = ac.b(this.e, this.d, paramInt, this.a);
      this.d += paramInt;
    } else {
      this.d += paramInt;
      throw new BrokerException("1001", "0010", "Invalid value buffer: '" + new String(this.e, this.d - paramInt, paramInt) + "'", null, null);
    } 
    return m;
  }
  
  private int i(int paramInt) throws BrokerException {
    int m = 0;
    if (this.d + paramInt > this.e.length) {
      BrokerException.a("0202", new String[] { "" + this.e.length });
    } else {
      m = ac.a(this.e, this.d, paramInt, this.a);
      this.d += paramInt;
    } 
    return m;
  }
  
  public void skipData(int paramInt) { this.d += paramInt; }
  
  public String getDataLString() throws BrokerException { return g(1); }
  
  public boolean getDataL() throws BrokerException { return (f() == this.a.z); }
  
  public String getDataA(int paramInt) { return g(paramInt); }
  
  public String getDataAV() throws BrokerException { return getDataA(c()); }
  
  private byte[] h() {
    int m = c();
    byte[] arrayOfByte = j.a(this.e, this.d, m);
    this.d += m;
    return arrayOfByte;
  }
  
  public byte[] getDataB(int paramInt) throws BrokerException {
    if (this.c < 2000) {
      byte[] arrayOfByte = new byte[paramInt];
      for (byte b1 = 0; b1 < paramInt; b1++) {
        int m = g();
        if (m > 127) {
          arrayOfByte[b1] = (byte)(m - 256);
        } else {
          arrayOfByte[b1] = (byte)m;
        } 
      } 
      return arrayOfByte;
    } 
    return h();
  }
  
  public byte[] getDataBV() { return (this.c < 2000) ? getDataB(c() / 2) : h(); }
  
  public String getDataNString(int paramInt1, int paramInt2) throws BrokerException {
    byte b1 = f();
    String str1 = "";
    if (b1 == this.a.h)
      str1 = "-"; 
    String str2 = e(g(paramInt1));
    String str3 = g(paramInt2);
    return (paramInt2 == 0) ? (str1 + str2) : (str1 + str2 + '.' + str3);
  }
  
  public BigDecimal getDataN(int paramInt1, int paramInt2) throws BrokerException { return new BigDecimal(getDataNString(paramInt1, paramInt2)); }
  
  public String getDataDString(int paramInt) {
    if (paramInt <= 8) {
      paramInt = 8;
    } else {
      paramInt = 15;
    } 
    return g(paramInt);
  }
  
  public Date getDataD(int paramInt) throws BrokerException {
    Calendar calendar = getDataDCalendar(paramInt);
    return (calendar != null) ? calendar.getTime() : null;
  }
  
  public Calendar getDataDCalendar(int paramInt) throws BrokerException {
    Calendar calendar = Calendar.getInstance();
    calendar.clear();
    int m = i(4);
    int n = i(2) - 1;
    int i1 = i(2);
    int i2 = 0;
    int i3 = 0;
    int i4 = 0;
    int i5 = 0;
    if (paramInt == 15) {
      i2 = i(2);
      i3 = i(2);
      i4 = i(2);
      i5 = i(1);
    } 
    if (m == 0) {
      if (this.f == null || this.f.length() < 4) {
        calendar.set(1, 0, 1);
      } else if (this.f.equals("null")) {
        calendar = null;
      } else {
        m = Integer.parseInt(this.f.substring(0, 4));
        n = Integer.parseInt(this.f.substring(4, 6));
        i1 = Integer.parseInt(this.f.substring(6, 8));
        if (paramInt == 15) {
          if (this.f.length() == 15) {
            i2 = Integer.parseInt(this.f.substring(8, 10));
            i3 = Integer.parseInt(this.f.substring(10, 12));
            i4 = Integer.parseInt(this.f.substring(12, 14));
            i5 = Integer.parseInt(this.f.substring(14, 15));
          } 
          calendar.set(m, n, i1, i2, i3, i4);
          calendar.set(14, i5 * 100);
        } else {
          calendar.set(m, n, i1);
        } 
      } 
    } else if (paramInt == 15) {
      calendar.set(m, n, i1, i2, i3, i4);
      calendar.set(14, i5 * 100);
    } else {
      calendar.set(m, n, i1);
    } 
    return calendar;
  }
  
  public Date getDataT() throws BrokerException { return getDataD(15); }
  
  public String getDataI1String() throws BrokerException { return e(g(4)); }
  
  public byte getDataI1() { return (byte)h(4); }
  
  public String getDataI2String() throws BrokerException { return e(g(6)); }
  
  public short getDataI2() throws BrokerException { return (short)h(6); }
  
  public String getDataI4String() throws BrokerException { return e(g(11)); }
  
  public int getDataI4() { return h(11); }
  
  public String getDataF4String() throws BrokerException { return g(f(e(g(13)))); }
  
  public float getDataF4() throws BrokerException {
    Float float = new Float(getDataF4String());
    return float.floatValue();
  }
  
  public String getDataF8String() throws BrokerException { return g(f(e(g(22)))); }
  
  public double getDataF8() throws BrokerException {
    Double double = new Double(getDataF8String());
    return double.doubleValue();
  }
  
  public int getArrayIndex() {
    int m = c();
    if (m < 0)
      BrokerException.a("0206", new String[] { "Illegal array index (" + m + ")" }); 
    return m;
  }
  
  public void addArrayIndex(int paramInt) {
    if (paramInt < 0)
      BrokerException.a("0206", new String[] { "Illegal array index (" + paramInt + ")" }); 
    e(paramInt);
  }
  
  private String e(String paramString) {
    String str1;
    String str2 = "";
    byte b1 = 0;
    boolean bool = true;
    if (paramString != null && paramString.length() > 0) {
      while (true) {
        if (bool && paramString.charAt(b1) == '+') {
          b1++;
        } else if (bool && paramString.charAt(b1) == '-') {
          str2 = "-";
          b1++;
        } 
        bool = false;
        if (b1 < paramString.length() && paramString.charAt(b1) == '0') {
          if (++b1 < paramString.length() && paramString.charAt(b1) == '.') {
            b1--;
            break;
          } 
          if (b1 == paramString.length()) {
            str2 = "";
            b1--;
            break;
          } 
          if (b1 >= paramString.length())
            break; 
          continue;
        } 
        break;
      } 
      str1 = str2 + paramString.substring(b1);
    } else {
      str1 = "";
    } 
    return str1;
  }
  
  private String f(String paramString) {
    String str;
    int m = -1;
    int n = -1;
    if (paramString != null && paramString.length() > 0) {
      int i1 = paramString.length();
      m = paramString.indexOf(".") + 2;
      n = paramString.indexOf("E") - 1;
      if (n == -2)
        n = i1 - 1; 
      if (m > 1 && m < i1) {
        for (int i2 = n; i2 >= m; i2--) {
          if (paramString.charAt(i2) != '0') {
            m = i2 + 1;
            break;
          } 
        } 
        str = paramString.substring(0, m);
        if (n < i1 && (paramString.charAt(i1 - 4) != 'E' || paramString.charAt(i1 - 2) != '0' || paramString.charAt(i1 - 1) != '0'))
          str = str + paramString.substring(n + 1); 
      } else {
        str = paramString;
      } 
    } else {
      str = "";
    } 
    return str;
  }
  
  private String g(String paramString) {
    String str;
    byte b1 = 0;
    if (paramString != null && paramString.length() > 0) {
      for (byte b2 = 0; b2 < paramString.length(); b2++) {
        if (paramString.charAt(b2) == 'E' && b2 + 1 < paramString.length() && paramString.charAt(b2 + 1) == '+') {
          b1 = b2 + 1;
          break;
        } 
      } 
      if (b1 > 0) {
        str = paramString.substring(0, b1) + "0" + paramString.substring(b1 + 1);
      } else {
        str = paramString;
      } 
    } else {
      str = "";
    } 
    return str;
  }
  
  private byte[] h(String paramString) throws BrokerException {
    byte[] arrayOfByte;
    if (this.b == null) {
      arrayOfByte = paramString.getBytes();
    } else {
      try {
        arrayOfByte = paramString.getBytes(this.b);
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        BrokerException.a("0121", new String[] { this.b });
        arrayOfByte = null;
      } 
    } 
    return arrayOfByte;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\Marshal.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */