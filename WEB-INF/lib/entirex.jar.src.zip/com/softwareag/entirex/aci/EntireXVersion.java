package com.softwareag.entirex.aci;

public final class EntireXVersion {
  private static final String a = "09 Sep 2004";
  
  private static final String b = "7.2.1.0 Build: 2004-09-14 12:44";
  
  private static final String c = "exx721.xml";
  
  private static final String d = "7.2.1";
  
  private static String e = null;
  
  private static String f = null;
  
  public EntireXVersion(String paramString) { f = paramString; }
  
  public static String getDate() { return "09 Sep 2004"; }
  
  public static String getVersion() { return "7.2.1.0 Build: 2004-09-14 12:44"; }
  
  public static String getYear() { return "09 Sep 2004".substring("09 Sep 2004".length() - 4, "09 Sep 2004".length()); }
  
  public static String getLicProdVersion() { return "7.2.1"; }
  
  public static String getInternalVersion() {
    if (e == null) {
      StringBuffer stringBuffer = new StringBuffer();
      for (byte b1 = 0; b1 < "7.2.1.0 Build: 2004-09-14 12:44".length(); b1++) {
        if (Character.isDigit("7.2.1.0 Build: 2004-09-14 12:44".charAt(b1)))
          stringBuffer.append("7.2.1.0 Build: 2004-09-14 12:44".charAt(b1)); 
      } 
      if (stringBuffer.length() == 4)
        stringBuffer.append('0'); 
      if (stringBuffer.length() != 5) {
        e = "00000";
      } else {
        e = stringBuffer.toString();
      } 
    } 
    return e;
  }
  
  public String getVersionString() { return "EntireX " + f + ", Version: " + "7.2.1.0 Build: 2004-09-14 12:44" + ", Date: " + "09 Sep 2004"; }
  
  public String getComponentName() { return f; }
  
  public static String getLicenseFileName() { return "exx721.xml"; }
  
  public static void main(String[] paramArrayOfString) { System.out.println((new EntireXVersion("Java Package")).getVersionString()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\EntireXVersion.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */