package com.softwareag.entirex.aci;

import java.io.IOException;
import java.io.OutputStream;

class ad {
  private static final int a = 512;
  
  private OutputStream b;
  
  private byte[] c;
  
  private int d = 0;
  
  ad(OutputStream paramOutputStream, int paramInt) {
    this.b = paramOutputStream;
    if (paramInt < 512)
      paramInt = 512; 
    this.c = new byte[paramInt];
  }
  
  void a(int paramInt) {
    if (paramInt > this.c.length)
      this.c = new byte[paramInt]; 
  }
  
  void a(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
    if (this.d + paramInt2 <= this.c.length) {
      System.arraycopy(paramArrayOfByte, paramInt1, this.c, this.d, paramInt2);
      this.d += paramInt2;
    } else {
      throw new IOException("BrokerOutputStream: Buffer overflow");
    } 
  }
  
  void b(int paramInt) {
    q.a(this.c, this.d, paramInt);
    this.d += 4;
  }
  
  void c(int paramInt) {
    q.a(this.c, this.d, (short)paramInt);
    this.d += 2;
  }
  
  void a() throws IOException {
    if (this.d > 0) {
      this.b.write(this.c, 0, this.d);
      this.d = 0;
      this.b.flush();
    } 
  }
  
  void b() throws IOException {
    a();
    this.b.close();
    this.c = null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\ad.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */