package com.softwareag.entirex.aci;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

final class ai {
  private Socket a;
  
  private DataInputStream b;
  
  private ad c = null;
  
  long d;
  
  public String toString() { return (this.a == null) ? "Socket entry invalid" : this.a.toString(); }
  
  Socket a() { return this.a; }
  
  DataInputStream b() { return this.b; }
  
  ad a(int paramInt) throws IOException {
    if (this.c == null) {
      this.c = new ad(this.a.getOutputStream(), paramInt);
    } else {
      this.c.a(paramInt);
    } 
    return this.c;
  }
  
  ai(Socket paramSocket) throws IOException {
    this.a = paramSocket;
    this.b = new DataInputStream(new BufferedInputStream(this.a.getInputStream(), 4096));
    this.d = System.currentTimeMillis();
  }
  
  void c() {
    try {
      if (this.b != null)
        this.b.close(); 
    } catch (IOException iOException) {}
    try {
      if (this.c != null)
        this.c.b(); 
    } catch (IOException iOException) {}
    try {
      if (this.a != null)
        this.a.close(); 
    } catch (IOException iOException) {}
    this.b = null;
    this.c = null;
    this.a = null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\ai.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */