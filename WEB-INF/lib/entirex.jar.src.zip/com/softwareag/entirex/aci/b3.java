package com.softwareag.entirex.aci;

import java.awt.TextArea;

class com/softwareag/entirex/aci/b3 extends TextArea {
  private final Tester a;
  
  public com/softwareag/entirex/aci/b3(Tester paramTester, int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
    this.a = paramTester;
    setEditable(false);
  }
  
  public boolean isFocusTraversable() { return false; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\b3.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */