package com.softwareag.entirex.aci;

public class be extends Exception {
  private int a = 0;
  
  private int b = 0;
  
  private int c = 0;
  
  private String d;
  
  private String e;
  
  private String f;
  
  private String g;
  
  private String h;
  
  private String i = "";
  
  private String j = "";
  
  private String k = "0000";
  
  private String l = "0000";
  
  public be(int paramInt, String paramString) { this(paramInt, 0, paramString); }
  
  public be(int paramInt1, int paramInt2, String paramString) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.j = paramString;
  }
  
  public String toString() { return getClass().getName() + ": RPC protocol error " + this.a + ": " + this.i + this.j; }
  
  public int a() { return this.a; }
  
  public int b() { return this.b; }
  
  public int c() { return this.c; }
  
  public String d() { return this.d; }
  
  public String e() { return this.e; }
  
  public String f() { return this.f; }
  
  public String g() { return this.g; }
  
  public String h() { return this.h; }
  
  public String i() { return this.i; }
  
  public String j() { return this.j; }
  
  public String k() { return this.k; }
  
  public String l() { return this.l; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\be.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */