package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.ac;
import com.softwareag.entirex.base.s;
import java.util.Properties;

class by extends bw {
  private static final int a = 32;
  
  private static final int b = 8;
  
  private static final int c = 40;
  
  private static final int d = 8;
  
  private static final int e = 69;
  
  private static final int f = 4;
  
  private static final int g = 12;
  
  private static final int h = 5;
  
  private static final int i = 4;
  
  private static final int j = 8;
  
  private static final int k = 48;
  
  private static final int l = 16;
  
  private static final int m = 67;
  
  private static final int n = 2;
  
  private static final int o = 77;
  
  private static final int p = 6;
  
  private static final int q = 83;
  
  private static final int r = 6;
  
  private static final int s = 89;
  
  private static final int t = 6;
  
  private static final int u = 75;
  
  private static final int v = 1;
  
  private static final int w = 73;
  
  private static final int x = 1;
  
  private static final int y = 64;
  
  private static final int z = 2;
  
  private static final int aa = 66;
  
  private static final int ab = 1;
  
  public by(byte[] paramArrayOfByte) throws be { super(paramArrayOfByte); }
  
  public by(byte[] paramArrayOfByte, s params) throws be { super(paramArrayOfByte, params); }
  
  public by(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, Properties paramProperties, ao paramao, s params) {
    super(paramArrayOfByte1, paramArrayOfByte2, paramProperties, paramao, params);
    Boolean bool = (Boolean)paramProperties.get("ServerLogon");
    boolean bool1 = (bool == null) ? ao.p() : bool.booleanValue();
    try {
      a(bool1);
    } catch (Exception exception) {}
  }
  
  protected int a() { return 1130; }
  
  protected int l() { return 32; }
  
  protected int an() { return 8; }
  
  protected int ao() { return 40; }
  
  protected int ap() { return 8; }
  
  protected int n() { return 69; }
  
  protected int o() { return 4; }
  
  protected int p() { return 12; }
  
  protected int q() { return 5; }
  
  protected int aq() { return 4; }
  
  protected int ar() { return 8; }
  
  protected int as() { return 48; }
  
  protected int at() { return 16; }
  
  protected int au() { return 67; }
  
  protected int m() { return 2; }
  
  protected int av() { return 77; }
  
  protected int aw() { return 6; }
  
  protected int ax() { return 83; }
  
  protected int ay() { return 6; }
  
  protected int az() { return 89; }
  
  protected int a0() { return 6; }
  
  protected int a1() { return 75; }
  
  protected int a2() { return 1; }
  
  protected int a3() { return 73; }
  
  protected int a4() { return 1; }
  
  protected String r() {
    String str;
    if (super.g > 0) {
      byte b3;
      byte b2;
      byte b1;
      try {
        b1 = ac.a(u(), 17, 4, super.o);
      } catch (NumberFormatException numberFormatException) {
        b1 = 0;
      } 
      String str1 = new String(u(), 21, 1);
      String str2 = new String(u(), 22, 8);
      try {
        b2 = ac.a(u(), 30, 2, super.o);
      } catch (NumberFormatException numberFormatException) {
        b2 = 0;
      } 
      String str3 = new String(u(), 96, 1);
      String str4 = new String(u(), 97, 1);
      String str5 = new String(u(), 100, 88);
      try {
        b3 = ac.a(u(), 98, 2, super.o);
      } catch (NumberFormatException numberFormatException) {
        b3 = 0;
      } 
      str = "User error: " + super.g + "(Line " + b1 + ", Status " + str1 + ", Program " + str2 + ", Level " + b2 + ", Code " + str3 + ", Object type " + str4 + ", Text " + str5 + ", Length " + b3 + ")";
    } else if (super.e != null) {
      str = (String)super.e.get("ET");
    } else {
      str = (String)null;
    } 
    return str;
  }
  
  public int j() { return super.d; }
  
  public void b(int paramInt) {
    super.d = paramInt;
    String str = " ";
    if (paramInt > 0)
      str = Integer.toString(paramInt); 
    a(str, 0, u(), a3(), a4());
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\by.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */