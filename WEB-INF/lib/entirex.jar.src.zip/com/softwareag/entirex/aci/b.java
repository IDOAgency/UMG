package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.k;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.reflect.Constructor;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;

public abstract class b implements c {
  private String a = h.ac;
  
  private String b = "entirex.server.properties";
  
  private h c = null;
  
  private final Date d = new Date();
  
  private Properties e = null;
  
  private int f = 0;
  
  private int g = Integer.parseInt("15");
  
  private int h = 0;
  
  private String i;
  
  static final String j = "Error";
  
  static final String k = "Init";
  
  static final String l = "Retry";
  
  static final String m = "Running";
  
  static final String n = "Shutdown";
  
  private int o;
  
  private int p;
  
  private int q = 0;
  
  protected boolean r;
  
  private m s = null;
  
  private Hashtable t = new Hashtable();
  
  private Hashtable u = new Hashtable();
  
  private l v = null;
  
  protected int w = 0;
  
  private Object[] x;
  
  private boolean y = false;
  
  Conversation z = null;
  
  private Constructor aa = null;
  
  static Class ab;
  
  public b(Properties paramProperties) { this.e = paramProperties; }
  
  public b() {}
  
  int c() { return this.h; }
  
  boolean d() { return this.r; }
  
  protected final void a(String[] paramArrayOfString) {
    this.i = "Init";
    if (this.c == null)
      this.c = new h(new Properties()); 
    this.c.a();
    this.c.parse(paramArrayOfString);
    this.b = this.c.b();
    this.e = this.c.getProperties();
    boolean bool = this.c.getBoolean("-help");
    if (bool) {
      this.c.usage("");
      return;
    } 
    ah();
    synchronized (System.out) {
      String str = "";
      if (!this.a.equals(d("entirex.server.name")))
        str = ", " + this.a; 
      System.out.println(i() + " Start of " + d("entirex.server.name") + str);
    } 
    ad();
    if (!n().equalsIgnoreCase("0")) {
      Dump.log("Start ServerMonitorDispatcher (port:" + n() + ").");
      this.v = new l(this);
      this.v.start();
      this;
      while (this.v.d == 0) {
        try {
          Thread.currentThread().sleep(100L);
        } catch (Exception exception) {}
        Dump.log("ServerMonitorDispatcher is initializing.");
      } 
      this;
      if (this.v.d == 1) {
        Dump.log("ServerMonitorDispatcher is listening.");
      } else {
        Dump.log("ServerMonitorDispatcher is down.");
        return;
      } 
    } else {
      Dump.log("Do not start ServerMonitorDispatcher (port:" + n() + ").");
    } 
    ac();
    if (this.p < 0) {
      System.out.print("Server: warning, configuration of minservers corrected, was :" + this.p);
      this.p = c("entirex.server.fixedservers") ? Integer.parseInt("1") : 0;
      this.e.put("entirex.server.minservers", (new Integer(this.p)).toString());
      System.out.println(" is now " + this.p);
    } 
    if (this.o < this.p) {
      System.out.print("Server: warning, configuration of maxservers corrected, was :" + this.o);
      this.o = (this.p == 0) ? 1 : this.p;
      this.e.put("entirex.server.maxservers", (new Integer(this.o)).toString());
      System.out.println(" is now " + this.o);
    } 
    try {
      aa();
    } catch (BrokerException brokerException) {
      brokerException.printStackTrace();
      return;
    } 
    this.h = this.o;
    if (!c("entirex.server.fixedservers"))
      this.h++; 
    this.g = b("entirex.server.restartcycles");
    if (!c("entirex.server.fixedservers")) {
      this.s = new m(this, this.s, this);
    } else {
      this.s = null;
    } 
    boolean bool1 = false;
    Vector vector = new Vector();
    for (byte b1 = 0; b1 < this.p; b1++) {
      b b2 = e();
      o o1 = new o(b2, this.s, this);
      o1.start();
      vector.addElement(o1);
      if (!b1)
        for (int i1 = 0; i1 < Math.max(50, this.g) && !bool1 && !this.i.equals("Shutdown"); i1 = this.g) {
          int i2 = o1.a();
          switch (i2) {
            case 0:
              synchronized (this) {
                try {
                  wait(100L);
                } catch (InterruptedException interruptedException) {}
              } 
              i1++;
              continue;
            case 2:
            case 3:
              bool1 = true;
              this.i = "Running";
              i1 = 0;
              continue;
            case 7:
              synchronized (this) {
                try {
                  wait(60000L);
                } catch (InterruptedException interruptedException) {}
              } 
              this.i = "Retry";
              i1++;
              continue;
          } 
        }  
      if (!bool1 || this.i.equals("Shutdown"))
        break; 
      s();
    } 
    if (this.s != null && (bool1 || this.p == 0) && !this.i.equals("Shutdown")) {
      this.s.start();
      this.i = "Running";
      try {
        this.s.join();
      } catch (InterruptedException interruptedException) {
        Dump.log("Thread interrupted: " + interruptedException);
      } 
    } else {
      Enumeration enumeration1 = this.u.keys();
      while (enumeration1.hasMoreElements()) {
        o o1 = (o)enumeration1.nextElement();
        try {
          o1.join();
        } catch (InterruptedException interruptedException) {
          Dump.log("Thread interrupted: " + interruptedException);
        } 
      } 
      Enumeration enumeration2 = vector.elements();
      while (enumeration2.hasMoreElements()) {
        Object object = enumeration2.nextElement();
        try {
          ((o)object).join();
        } catch (InterruptedException interruptedException) {
          Dump.log("Thread interrupted: " + interruptedException);
        } 
      } 
    } 
    this.i = "Shutdown";
    if (this.v != null)
      this.v.a(); 
  }
  
  b e() {
    if (this.aa == null)
      try {
        this.aa = getClass().getConstructor(new Class[] { (ab == null) ? (ab = class$("java.util.Properties")) : ab });
        this.x = new Object[] { this.e };
      } catch (NoSuchMethodException noSuchMethodException) {
        try {
          this.aa = getClass().getConstructor(null);
          this.x = null;
        } catch (NoSuchMethodException noSuchMethodException1) {
          System.err.println("Something wrong with class " + getClass().getName() + ": " + noSuchMethodException1.toString());
          return null;
        } 
      }  
    try {
      b b1 = (b)this.aa.newInstance(this.x);
      b1.e = this.e;
      b1.h = this.h;
      b1.r = this.r;
      b1.o = this.o;
      b1.p = this.p;
      b1.g = this.g;
      return b1;
    } catch (Exception exception) {
      exception.printStackTrace(System.err);
      return null;
    } 
  }
  
  protected void b(boolean paramBoolean) { this.y = paramBoolean; }
  
  protected void a(BrokerMessage paramBrokerMessage) throws BrokerException {
    f();
    this.y = false;
    do {
      byte[] arrayOfByte = b(paramBrokerMessage.getMessage());
      if (arrayOfByte == null)
        break; 
      paramBrokerMessage.setMessage(arrayOfByte);
      this.z.send(paramBrokerMessage);
      if (this.y)
        break; 
      paramBrokerMessage = this.z.receive();
    } while (paramBrokerMessage != null);
    this.z.end();
    g();
  }
  
  protected void f() {}
  
  protected byte[] b(byte[] paramArrayOfByte) { return paramArrayOfByte; }
  
  protected void g() {}
  
  protected void h() { b(true); }
  
  protected abstract void b(BrokerMessage paramBrokerMessage) throws BrokerException;
  
  protected void a(Exception paramException, boolean paramBoolean) {}
  
  private void ad() {
    if (this.b != null) {
      File file = new File(this.b);
      System.out.println("Using property file " + file.getAbsolutePath());
    } 
    if (this.r) {
      System.out.println("Using the following properties: ");
      Enumeration enumeration = this.e.propertyNames();
      for (byte b1 = 0; enumeration.hasMoreElements(); b1++)
        enumeration.nextElement(); 
      String[] arrayOfString = new String[b1];
      enumeration = this.e.propertyNames();
      byte b2 = 0;
      while (enumeration.hasMoreElements())
        arrayOfString[b2++] = (String)enumeration.nextElement(); 
      k.a(arrayOfString);
      for (byte b3 = 0; b3 < arrayOfString.length; b3++) {
        String str = arrayOfString[b3];
        if (str.equals("entirex.server.password") || str.endsWith("password")) {
          System.out.println(str + ": ********");
        } else {
          System.out.println(str + ": " + this.e.getProperty(str));
        } 
      } 
      System.out.println();
    } 
  }
  
  public final int b(String paramString) {
    try {
      return Integer.parseInt(this.e.getProperty(paramString));
    } catch (Exception exception) {
      return 0;
    } 
  }
  
  public final boolean c(String paramString) { return Dump.b(this.e.getProperty(paramString)); }
  
  public final String d(String paramString) {
    String str = this.e.getProperty(paramString);
    return (str == null) ? "" : str.trim();
  }
  
  protected abstract void b();
  
  protected abstract void a(BrokerService paramBrokerService) throws BrokerException;
  
  protected abstract void a();
  
  String i() { return (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")).format(new Date()); }
  
  void e(String paramString) { this.e.put("entirex.server.security", paramString); }
  
  protected String j() { return this.a; }
  
  protected void f(String paramString) { this.a = paramString; }
  
  public int k() { return this.o; }
  
  int l() { return this.p; }
  
  protected String m() { return this.b; }
  
  protected void g(String paramString) { this.b = paramString; }
  
  String n() { return d("entirex.server.monitorport"); }
  
  String o() { return "10"; }
  
  boolean p() { return c("entirex.server.monitorremote"); }
  
  public String[][] q() {
    String str1 = "-";
    String str2 = "-";
    try {
      str1 = InetAddress.getLocalHost().getHostName().toLowerCase();
      str2 = InetAddress.getLocalHost().getHostAddress().toLowerCase();
    } catch (UnknownHostException unknownHostException) {}
    return new String[][] { { "state", ag() }, { "started", (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z")).format(this.d) }, { "worker", Integer.toString(ae()) }, { "high", (this.q == -1) ? " " : Integer.toString(this.q) }, { "name", str1 }, { "address", str2 } };
  }
  
  public String[][] getServerEnhancedInfo() { return new String[][] { 
        { "Server Type", "Java Server" }, { "Server Version", EntireXVersion.getVersion() }, { "Broker ID", d("entirex.server.brokerid") }, { "Class/Server/Service", d("entirex.server.serveraddress") }, { "Logical Set Name", d("entirex.server.logicalsetname") }, { "Logical Broker ID", d("entirex.server.logicalbrokerid") }, { "Logical Service", d("entirex.server.logicalservice") }, { "User ID", d("entirex.server.userid") }, { "Timeout", d("entirex.timeout") }, { "Codepage", Dump.d() }, 
        { "Encryption Level", d("entirex.server.encryptionlevel") }, { "Compression Level", d("entirex.server.compresslevel") }, { "EntireX Security", d("entirex.server.security") }, { "Retry Cycles", d("entirex.server.restartcycles") }, { "Trace Level", d("entirex.trace") }, { "Trace File/Location", d("entirex.server.logfile") }, { "Configuration", m() }, { "Active Workers", Integer.toString(ae()) }, { "Busy Workers", Integer.toString(af()) }, { "Worker High Watermark", Integer.toString(this.q) }, 
        { "Min Workers", Integer.toString(this.p) }, { "Max Workers", Integer.toString(this.o) }, { "Fixed Servers", c("entirex.server.fixedservers") ? "yes" : "no" } }; }
  
  public String[] getTableNames() { return new String[0]; }
  
  public String[][] getTable(int paramInt) { return new String[0][0]; }
  
  int r() {
    this.i = "Shutdown";
    if (this.s == null) {
      Enumeration enumeration = this.t.keys();
      while (enumeration.hasMoreElements()) {
        o o1 = (o)enumeration.nextElement();
        o1.d();
      } 
    } else {
      this.s.d();
    } 
    return 0;
  }
  
  private int ae() { return this.w; }
  
  private int af() {
    byte b1 = 0;
    Enumeration enumeration = this.t.keys();
    while (enumeration.hasMoreElements()) {
      o o1 = (o)enumeration.nextElement();
      if (o1.a() == 4)
        b1++; 
    } 
    return b1;
  }
  
  private String ag() { return this.i; }
  
  void s() {
    if (ae() >= this.q)
      this.q = ae(); 
  }
  
  boolean t() { return this.i.equals("Shutdown"); }
  
  private void ah() {
    b();
    Properties properties = System.getProperties();
    String str1 = this.e.getProperty("entirex.location.transparency.config");
    if (str1 != null && str1.length() > 0 && !properties.containsKey("entirex.location.transparency.config"))
      properties.put("entirex.location.transparency.config", str1); 
    String str2 = this.e.getProperty("entirex.location.transparency.ini");
    if (str2 != null && str2.length() > 0 && !properties.containsKey("entirex.location.transparency.ini"))
      properties.put("entirex.location.transparency.ini", str2); 
    String str3 = d("entirex.server.logfile");
    PrintWriter printWriter = null;
    if (!str3.equals(""))
      try {
        FileOutputStream fileOutputStream = new FileOutputStream(str3);
        printWriter = new PrintWriter(fileOutputStream, true);
        PrintStream printStream = new PrintStream(fileOutputStream);
        System.setErr(printStream);
        System.setOut(printStream);
      } catch (IOException iOException) {} 
    this.r = c("entirex.server.verbose");
    this.p = b("entirex.server.minservers");
    this.o = b("entirex.server.maxservers");
    Dump.a(d("entirex.trace"), printWriter);
    properties.put("entirex.trace", d("entirex.trace"));
    properties.put("entirex.timeout", d("entirex.timeout"));
    String str4 = d("entirex.server.serveraddress");
    String str5 = this.c.getString("-class");
    String str6 = this.c.getString("-service");
    if (str4 != null && str4.indexOf("/") < 0) {
      str4 = ((str5 == null) ? "RPC" : str5) + "/" + str4;
      str4 = str4 + "/" + ((str6 == null) ? "CALLNAT" : str6);
      this.e.put("entirex.server.serveraddress", str4);
    } 
    if (str5 != null && str6 == null)
      if (str5.indexOf("/") < 0) {
        this.e.put("entirex.server.serveraddress", "RPC/" + str5 + "/CALLNAT");
      } else {
        this.e.put("entirex.server.serveraddress", str5);
      }  
  }
  
  void h(String paramString) { this.i = paramString; }
  
  protected void a(h paramh) { this.c = paramh; }
  
  Hashtable u() { return this.t; }
  
  Hashtable v() { return this.u; }
  
  int w() { return this.w; }
  
  void x() { this.w++; }
  
  void y() { this.w--; }
  
  int z() { return this.g; }
  
  boolean aa() {
    null = false;
    String str1 = d("entirex.server.brokerid");
    String str2 = d("entirex.server.logicalservice");
    String str3 = d("entirex.server.logicalsetname");
    String str4 = d("entirex.server.logicalbrokerid");
    if (str2 != null && str2.length() > 0) {
      BrokerService brokerService = LocationTransparencyService.lookupBrokerService(str2, str3);
      this.e.put("entirex.server.brokerid", brokerService.getBroker().getBrokerID());
      this.e.put("entirex.server.serveraddress", brokerService.getServerClass() + "/" + brokerService.getServerName() + "/" + brokerService.getServiceName());
    } else if (str4 != null && str4.length() > 0) {
      Broker broker = LocationTransparencyService.lookupBroker(str4, str3);
      this.e.put("entirex.server.brokerid", broker.getBrokerID());
    } 
    return !str1.equals(d("entirex.server.brokerid"));
  }
  
  protected Properties ab() { return this.e; }
  
  protected void ac() {}
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\b.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */