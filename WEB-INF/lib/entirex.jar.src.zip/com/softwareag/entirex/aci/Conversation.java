package com.softwareag.entirex.aci;

public class Conversation extends BrokerCommunication {
  private boolean a = false;
  
  private boolean b = false;
  
  public Conversation(BrokerService paramBrokerService) {
    super(paramBrokerService);
    this.g = false;
  }
  
  public Conversation(BrokerService paramBrokerService, ConversationState paramConversationState) throws IllegalArgumentException {
    super(paramBrokerService, paramConversationState);
    this.g = false;
  }
  
  Conversation(BrokerService paramBrokerService, String paramString, q paramq) throws BrokerException {
    super(paramBrokerService, paramString);
    this.g = false;
  }
  
  public void ignoreEOC(boolean paramBoolean) {
    this.b = paramBoolean;
    this.a = true;
  }
  
  public void send(BrokerMessage paramBrokerMessage) throws BrokerException { a(paramBrokerMessage, null, true, null); }
  
  public BrokerMessage sendReceive(BrokerMessage paramBrokerMessage, String paramString) throws BrokerException { return a(paramBrokerMessage, paramString, false, null); }
  
  public BrokerMessage sendReceive(BrokerMessage paramBrokerMessage) throws BrokerException { return a(paramBrokerMessage, super.b.getDefaultWaittime(), false, null); }
  
  public void end() throws BrokerException { a(null); }
  
  public void cancel() throws BrokerException { a(q.av); }
  
  private BrokerMessage a(String paramString, boolean paramBoolean) throws BrokerException {
    try {
      return a(paramString, paramBoolean ? q.ay : null);
    } catch (BrokerException brokerException) {
      if (brokerException.getErrorClass() == 3 && (brokerException.getErrorCode() == 5 || this.a)) {
        if (this.b && brokerException.getErrorCode() != 3 && brokerException.getErrorCode() != 73)
          end(); 
        return null;
      } 
      throw brokerException;
    } 
  }
  
  public BrokerMessage receive(String paramString) throws BrokerException { return a(paramString, false); }
  
  public BrokerMessage receive() throws BrokerException { return receive(super.b.getDefaultWaittime()); }
  
  public BrokerMessage receiveLast() throws BrokerException { return a("NO", q.aw); }
  
  public BrokerMessage receivePreview(String paramString) throws BrokerException { return a(paramString, true); }
  
  public BrokerMessage receivePreview() throws BrokerException { return receivePreview(super.b.getDefaultWaittime()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\Conversation.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */