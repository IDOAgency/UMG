package com.softwareag.entirex.aci;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

final class x extends y {
  private y a = null;
  
  private final String b;
  
  private final int c;
  
  private final Properties d;
  
  private static Class e = null;
  
  private static String f;
  
  private static final String g = "entirex.ssltransport";
  
  private static final String h = "com.softwareag.entirex.aci.d4";
  
  private static final String i = "com.softwareag.entirex.aci.d0";
  
  private static final String j = "com.softwareag.entirex.aci.d3";
  
  static Class k;
  
  static Class l;
  
  static Class m;
  
  public x(String paramString, int paramInt, Properties paramProperties) {
    super(paramString, paramInt, paramProperties);
    this.b = paramString;
    this.c = paramInt;
    this.d = paramProperties;
  }
  
  public void a() throws IOException {
    if (this.a != null)
      return; 
    try {
      Class clazz = d();
      if (!((k == null) ? (k = class$("com.softwareag.entirex.aci.d2")) : k).isAssignableFrom(clazz))
        throw new ae("0408", new String[] { f }); 
      Constructor constructor = clazz.getConstructor(new Class[] { (l == null) ? (l = class$("java.lang.String")) : l, int.class, (m == null) ? (m = class$("java.util.Properties")) : m });
      this.a = (y)constructor.newInstance(new Object[] { this.b, new Integer(this.c), this.d });
    } catch (InvocationTargetException invocationTargetException) {
      Throwable throwable = invocationTargetException.getTargetException();
      if (Dump.c)
        Dump.log("Loading SSL Transport failed: " + throwable.toString()); 
      throw new ae("0404", new String[] { throwable.toString() });
    } catch (NoClassDefFoundError noClassDefFoundError) {
      if (Dump.c)
        Dump.log("Loading SSL Transport failed: " + noClassDefFoundError.toString()); 
      throw new ae("0405", new String[] { noClassDefFoundError.toString() });
    } catch (ClassNotFoundException classNotFoundException) {
      if (Dump.c)
        Dump.log("Loading SSL Transport failed: " + classNotFoundException.toString()); 
      throw new ae("0406", new String[] { f });
    } catch (ae ae) {
      if (Dump.c)
        Dump.log("Loading SSL Transport failed: " + ae.toString()); 
      throw ae;
    } catch (Exception exception) {
      if (Dump.c)
        Dump.log("Loading SSL Transport failed: " + exception.toString()); 
      throw new ae("0407", new String[] { exception.toString() });
    } 
  }
  
  public Socket b() throws IOException {
    if (this.a == null)
      a(); 
    return this.a.b();
  }
  
  public ServerSocket c() throws IOException {
    if (this.a == null)
      a(); 
    return this.a.c();
  }
  
  private static Class d() throws NoClassDefFoundError, ClassNotFoundException {
    if (e == null) {
      if (System.getProperty("java.version").startsWith("1.4.")) {
        f = System.getProperty("entirex.ssltransport", "com.softwareag.entirex.aci.d3");
      } else {
        f = System.getProperty("entirex.ssltransport", "com.softwareag.entirex.aci.d4");
      } 
      if (Dump.c)
        Dump.log("Loading SSL Transport " + f + " ..."); 
      if ((f + " ").equals("com.softwareag.entirex.aci.JSSESunTransport ")) {
        f = "com.softwareag.entirex.aci.d4";
      } else if ((f + " ").equals("com.softwareag.entirex.aci.JSSESSLTransport ")) {
        f = "com.softwareag.entirex.aci.d3";
      } 
      if ((f + " ").equals("com.softwareag.entirex.aci.JSSEIbmTransport "))
        f = "com.softwareag.entirex.aci.d0"; 
      e = Class.forName(f);
    } 
    return e;
  }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\x.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */