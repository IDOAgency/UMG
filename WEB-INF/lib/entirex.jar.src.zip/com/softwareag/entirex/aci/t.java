package com.softwareag.entirex.aci;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InterruptedIOException;

abstract class t {
  public static final int a = 1161970502;
  
  private static final int b = 20;
  
  private static final String c = "http://";
  
  private static final String d = "https://";
  
  private static final String e = "tcpip://";
  
  private int f;
  
  private static final int g = 1556207074;
  
  private static final int h = 1556206976;
  
  private static final int i = 1556206848;
  
  private byte[] j;
  
  private byte[] k;
  
  private byte[] l;
  
  private int m;
  
  private int n;
  
  private byte[] o;
  
  private boolean p = true;
  
  final int a() { return this.f; }
  
  final byte[] b() { return this.l; }
  
  final int c() { return this.m; }
  
  final int d() { return this.n; }
  
  final byte[] e() {
    byte[] arrayOfByte = this.o;
    this.o = null;
    return arrayOfByte;
  }
  
  final void a(byte[] paramArrayOfByte) { this.o = paramArrayOfByte; }
  
  void a(boolean paramBoolean) { this.p = paramBoolean; }
  
  static final t a(String paramString) {
    String str = paramString.toLowerCase();
    return (str.startsWith("http://") || str.startsWith("https://")) ? new u(paramString) : (str.startsWith("tcpip://") ? new v(paramString.substring("tcpip://".length())) : new v(paramString));
  }
  
  int a(DataInputStream paramDataInputStream) throws IOException {
    int i1 = 0;
    i1 = paramDataInputStream.readInt();
    if (i1 < 20)
      if (i1 == 0) {
        int i2 = paramDataInputStream.readInt();
        int i3 = paramDataInputStream.readInt();
        int i4 = paramDataInputStream.readInt();
        short s = paramDataInputStream.readShort();
        if (i2 != 1161970502)
          throw new ae("0319", null); 
        af.a(s);
      } else {
        throw new ae("0310", new String[] { Integer.toString(i1) });
      }  
    if (paramDataInputStream.readInt() != 1161970502)
      throw new ae("0319", null); 
    return i1;
  }
  
  final void a(int paramInt1, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt2) throws BrokerException {
    if (this.j == null) {
      this.j = new byte[20];
      this.k = new byte[28];
      this.l = new byte[2048];
    } 
    try {
      if (Dump.c)
        Dump.dumpBytes("Sending Transport Header ", paramArrayOfByte1, paramArrayOfByte1.length, 3); 
      int i1 = paramArrayOfByte1.length + ((this.o == null) ? 0 : this.o.length) + paramInt2;
      ad ad = c(i1);
      ad.a(paramArrayOfByte1, 0, paramArrayOfByte1.length);
      if (this.o != null) {
        if (this.p && Dump.c)
          Dump.dumpBytes("Sending Data ", this.o, this.o.length, 2); 
        ad.a(this.o, 0, this.o.length);
        this.o = null;
      } 
      if (Dump.c)
        Dump.dumpBytes("Sending Message Header ", paramArrayOfByte2, paramInt2, 3); 
      ad.a(paramArrayOfByte2, 0, paramInt2);
      h();
      DataInputStream dataInputStream = b(paramInt1);
      int i2 = a(dataInputStream);
      if (Dump.c) {
        q.a(this.j, 0, i2);
        q.a(this.j, 4, 1161970502);
      } 
      dataInputStream.readFully(this.j, 8, 12);
      if (Dump.c)
        Dump.dumpBytes("Received Transport Header ", this.j, 20, 3); 
      if (i2 == 20) {
        af.a(q.b(this.j, 16));
      } else if (i2 < 44) {
        throw new ae("0310", new String[] { Integer.toString(i2) });
      } 
      a(i2);
      dataInputStream.readFully(this.k, 0, 24);
      byte b1 = this.k[3];
      if (b1 > 24)
        dataInputStream.readFully(this.k, 24, b1 - 24); 
      int i3 = q.a(this.k, 8);
      int i4 = q.a(this.k, 4);
      int i5 = q.a(this.k, 16);
      int i6 = q.a(this.k, 20);
      int i7 = 0;
      if (i3 > 0)
        i7 = i4 - i3; 
      int i8 = 0;
      if (i5 > 0)
        i8 = i6 - i5; 
      this.n = i6 - b1 - i7 - i8;
      this.m = this.n + i8;
      int i9 = q.a(this.k, 12);
      if (i9 != 1556207074 && i9 != 1556206976 && i9 != 1556206848)
        throw new ae("0303", new String[0]); 
      switch (i9) {
        case 1556206976:
          this.f = 2;
          break;
        case 1556206848:
          this.f = 1;
          break;
        default:
          this.f = 0;
          break;
      } 
      if (this.n <= 0)
        throw new ae("0304", new String[] { Integer.toString(this.n) }); 
      if (i6 != i2 - 20)
        throw new ae("0305", new String[] { Integer.toString(i6), Integer.toString(i2 - 20) }); 
      if (i7 > 0) {
        this.o = new byte[i7];
        dataInputStream.readFully(this.o, 0, i7);
        if (this.p && Dump.c)
          Dump.dumpBytes("Received Data ", this.o, i7, 2); 
      } 
      this.p = true;
      dataInputStream.readFully(this.l, 0, this.m);
      if (Dump.c) {
        byte[] arrayOfByte = new byte[b1 + this.m];
        System.arraycopy(this.k, 0, arrayOfByte, 0, b1);
        System.arraycopy(this.l, 0, arrayOfByte, b1, this.m);
        Dump.dumpBytes("Received Message Header ", arrayOfByte, arrayOfByte.length, 3);
      } 
      g();
      i();
    } catch (ae ae) {
      k();
      BrokerException.a(ae.b(), ae.a());
    } catch (InterruptedIOException interruptedIOException) {
      k();
      Thread.currentThread().interrupt();
      BrokerException.a("0316", new String[] { interruptedIOException.toString() });
    } catch (IOException iOException) {
      k();
      BrokerException.a("0313", new String[] { toString(), iOException.toString() });
    } catch (RuntimeException runtimeException) {
      if (Dump.b() == 0)
        Dump.setTrace(1); 
      Dump.log(runtimeException.toString() + " thrown");
      k();
      throw runtimeException;
    } catch (Error error) {
      if (Dump.b() == 0)
        Dump.setTrace(1); 
      Dump.log(error.toString() + " thrown");
      k();
      throw error;
    } 
  }
  
  final void a(t paramt) throws IOException {
    DataInputStream dataInputStream = b(0);
    int i1 = a(dataInputStream);
    a(i1);
    ad ad = paramt.c(i1);
    ad.b(i1);
    ad.b(1161970502);
    i1 -= 8;
    byte[] arrayOfByte = new byte[i1];
    dataInputStream.readFully(arrayOfByte, 0, i1);
    ad.a(arrayOfByte, 0, i1);
    paramt.h();
    g();
    paramt.i();
    i();
  }
  
  String f() { return "Connection status unknown."; }
  
  protected void a(int paramInt) throws ae {}
  
  protected abstract DataInputStream b(int paramInt) throws IOException;
  
  protected abstract void g();
  
  protected abstract ad c(int paramInt) throws IOException;
  
  protected abstract void h();
  
  protected abstract void i();
  
  protected abstract void j();
  
  protected abstract void k();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\t.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */