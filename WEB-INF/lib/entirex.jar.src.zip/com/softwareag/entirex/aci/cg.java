package com.softwareag.entirex.aci;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class cg implements ActionListener {
  private final Tester2 a;
  
  cg(Tester2 paramTester2) { this.a = paramTester2; }
  
  public void actionPerformed(ActionEvent paramActionEvent) { Tester2.a(this.a, false); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\cg.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */