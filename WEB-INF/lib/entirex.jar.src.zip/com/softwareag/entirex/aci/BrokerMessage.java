package com.softwareag.entirex.aci;

public class BrokerMessage {
  private String a;
  
  private byte[] b = null;
  
  private BrokerService c;
  
  private Conversation d;
  
  private UnitofWork e;
  
  private String f;
  
  public String toString() { return (this.b == null) ? null : new String(this.b); }
  
  public String getClientUID() { return this.a; }
  
  void a(String paramString) { this.a = paramString; }
  
  public byte[] getMessage() { return this.b; }
  
  public void setMessage(byte[] paramArrayOfByte) { this.b = paramArrayOfByte; }
  
  public void setMessage(String paramString) { this.b = (paramString == null) ? null : paramString.getBytes(); }
  
  void a(BrokerService paramBrokerService) { this.c = paramBrokerService; }
  
  public BrokerService getService() { return this.c; }
  
  void a(Conversation paramConversation) { this.d = paramConversation; }
  
  public Conversation getConversation() { return this.d; }
  
  void a(UnitofWork paramUnitofWork) { this.e = paramUnitofWork; }
  
  public UnitofWork getUnitofWork() { return this.e; }
  
  void b(String paramString) { this.f = paramString; }
  
  public BrokerMessage() {}
  
  public BrokerMessage(byte[] paramArrayOfByte) { this.b = paramArrayOfByte; }
  
  public BrokerMessage(String paramString) { this((paramString == null) ? null : paramString.getBytes()); }
  
  public void reply(BrokerMessage paramBrokerMessage) throws BrokerException {
    if (paramBrokerMessage == null)
      throw new IllegalArgumentException("reply: no message"); 
    if (this.e != null)
      throw new IllegalArgumentException("reply: cannot reply to UnitofWork"); 
    if (this.d != null) {
      this.d.send(paramBrokerMessage);
      this.d = null;
    } else {
      if (((this.f == null) ? 1 : 0) | ((this.c == null) ? 1 : 0))
        throw new IllegalArgumentException("reply: not valid"); 
      q q = this.c.getBroker().a();
      synchronized (q) {
        q.u();
        q.a(paramBrokerMessage.getMessage());
        q.b(this.c.getEnvironment());
        q.a(this.f, true, null);
        this.f = null;
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\BrokerMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */