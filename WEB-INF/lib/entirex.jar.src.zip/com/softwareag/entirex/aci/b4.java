package com.softwareag.entirex.aci;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class b4 implements ActionListener {
  private final Tester a;
  
  b4(Tester paramTester) { this.a = paramTester; }
  
  public void actionPerformed(ActionEvent paramActionEvent) { Tester.a(this.a); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\b4.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */