package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.Command;
import com.softwareag.entirex.trace.Trace;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Hashtable;
import java.util.Properties;

public class RPCServer extends b {
  private static final String a = "entirex.rpcserver.packagename.";
  
  private BrokerMessage b = new BrokerMessage();
  
  private Method c;
  
  private Broker d;
  
  private com/softwareag/entirex/aci/es e;
  
  private boolean f = Trace.on(1, this);
  
  private ServerImplementation g;
  
  private boolean h;
  
  Conversation i = null;
  
  private static final Hashtable j = new Hashtable();
  
  private static final Hashtable k = new Hashtable();
  
  private final Hashtable l = new Hashtable();
  
  static Class m;
  
  static Class n;
  
  static Class o;
  
  public static void main(String[] paramArrayOfString) {
    RPCServer rPCServer = new RPCServer();
    rPCServer.a(new com/softwareag/entirex/aci/g(rPCServer));
    rPCServer.a(paramArrayOfString);
  }
  
  protected void a(BrokerService paramBrokerService) throws BrokerException {
    this.d = paramBrokerService.getBroker();
    this.e = new com/softwareag/entirex/aci/es(this, this.d, paramBrokerService.toString());
    this.e.setDefaultWaittime(paramBrokerService.getDefaultWaittime());
    this.e.setAdjustReceiveLen(paramBrokerService.d());
    this.e.setMaxReceiveLen(paramBrokerService.getMaxReceiveLen());
    this.e.setEnvironment(paramBrokerService.getEnvironment());
    this.e.useCodePage(paramBrokerService.useCodePage());
    this.e.setCharacterEncoding(paramBrokerService.getCharacterEncoding());
  }
  
  void a(boolean paramBoolean) {
    this.h = true;
    if (this.g != null) {
      if (this.r)
        System.out.println("closeConversation (" + paramBoolean + ") for " + this.g.getClass()); 
      this.g.closeConversation(paramBoolean);
      this.g = null;
    } 
  }
  
  protected final void a(BrokerMessage paramBrokerMessage) throws BrokerException {
    if (this.f)
      Trace.enterMethod(Trace.M4, 2, 19, 53); 
    this.g = null;
    this.i = paramBrokerMessage.getConversation();
    byte[] arrayOfByte = paramBrokerMessage.getMessage();
    this.h = false;
    try {
      while (!this.h) {
        arrayOfByte = a(arrayOfByte, true);
        this.b.setMessage(arrayOfByte);
        this.i.send(this.b);
        if (this.h) {
          this.i.end();
          continue;
        } 
        arrayOfByte = null;
        while (!this.h && arrayOfByte == null) {
          try {
            paramBrokerMessage = this.i.receive();
            if (paramBrokerMessage == null) {
              a(false);
              continue;
            } 
            arrayOfByte = paramBrokerMessage.getMessage();
          } catch (BrokerException brokerException) {
            if (brokerException.getErrorClass() == 74 && brokerException.getErrorCode() == 74)
              continue; 
            a(false);
            throw brokerException;
          } 
        } 
      } 
    } catch (et et) {
      arrayOfByte = et.a();
      this.b.setMessage(arrayOfByte);
      this.i.send(this.b);
      this.i.end();
      a(false);
    } 
    if (this.f)
      Trace.leaveMethod(Trace.M4, 2, 19, 53); 
  }
  
  protected final void b(BrokerMessage paramBrokerMessage) throws BrokerException {
    if (this.f)
      Trace.enterMethod(Trace.M4, 2, 19, 54); 
    byte[] arrayOfByte = paramBrokerMessage.getMessage();
    try {
      arrayOfByte = a(arrayOfByte, false);
    } catch (et et) {
      arrayOfByte = et.a();
    } finally {
      this.g = null;
    } 
    this.b.setMessage(arrayOfByte);
    paramBrokerMessage.reply(this.b);
    if (this.f)
      Trace.leaveMethod(Trace.M4, 2, 19, 54); 
  }
  
  public static final String a(String paramString, boolean paramBoolean) {
    if (paramString == null)
      return ""; 
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    byte b1 = -1;
    for (byte b2 = 0; b2 < i1; b2++) {
      char c1 = arrayOfChar[b2];
      arrayOfChar[b2] = Character.toLowerCase(c1);
      if (c1 == '-') {
        arrayOfChar[b2] = '_';
      } else if (c1 == '#') {
        arrayOfChar[b2] = '_';
      } else if (c1 == '.') {
        b1 = b2;
      } 
    } 
    if (paramBoolean && i1 > b1 + 1)
      arrayOfChar[b1 + 1] = Character.toUpperCase(arrayOfChar[b1 + 1]); 
    return new String(arrayOfChar);
  }
  
  private byte[] a(byte[] paramArrayOfByte, boolean paramBoolean) throws BrokerException, et {
    if (this.f) {
      Trace.enterMethod(Trace.M4, 2, 19, 55);
      Trace.parameter(Trace.MP4, 2, 19, 55, "isConversation", paramBoolean);
      Trace.parameter(Trace.MP4, 2, 19, 55, "message", paramArrayOfByte);
    } 
    if (this.i != null)
      this.e.setConversation(this.i); 
    this.e.a(paramArrayOfByte, paramBoolean);
    byte[] arrayOfByte = this.e.a(paramArrayOfByte, paramBoolean, this);
    if (arrayOfByte == null) {
      if (this.f) {
        Trace.parameter(Trace.MP4, 2, 19, 55, "message", paramArrayOfByte);
        Trace.leaveMethod(Trace.MP4, 2, 19, 55);
      } 
      return paramArrayOfByte;
    } 
    if (this.f) {
      Trace.parameter(Trace.MP4, 2, 19, 55, "reply", arrayOfByte);
      Trace.leaveMethod(Trace.M4, 2, 19, 55);
    } 
    return arrayOfByte;
  }
  
  private String i(String paramString) {
    paramString = paramString.toLowerCase();
    String str = d("entirex.rpcserver.packagename." + paramString);
    if (str.length() > 0)
      paramString = str + '.' + paramString; 
    return a(paramString, true) + "Stub";
  }
  
  private RPCService a(byte[] paramArrayOfByte, boolean paramBoolean, String paramString1, String paramString2) throws et, ClassNotFoundException, NoClassDefFoundError {
    if (this.f)
      Trace.enterMethod(Trace.M4, 2, 19, 56); 
    String str = paramString1;
    boolean bool = true;
    try {
      Class clazz = (Class)j.get(paramString1);
      if (clazz == null) {
        str = i(paramString1);
        if (this.r)
          System.out.println("Creating new class " + str); 
        clazz = Class.forName(str);
        j.put(paramString1, clazz);
      } else {
        str = clazz.getName();
      } 
      this.c = null;
      Hashtable hashtable = (Hashtable)k.get(clazz);
      if (hashtable == null) {
        hashtable = new Hashtable();
        k.put(clazz, hashtable);
      } else {
        this.c = (Method)hashtable.get(paramString2);
      } 
      if (this.c == null) {
        bool = true;
        if (this.r)
          System.out.println("Creating new method " + paramString2); 
        this.c = clazz.getMethod(paramString2, null);
        hashtable.put(paramString2, this.c);
      } 
      RPCService rPCService = (RPCService)this.l.get(clazz);
      if (rPCService == null) {
        bool = false;
        if (this.r)
          System.out.println("Creating constructor for class " + str); 
        Constructor constructor = clazz.getConstructor(new Class[] { (m == null) ? (m = class$("com.softwareag.entirex.aci.Broker")) : m, (n == null) ? (n = class$("java.lang.String")) : n });
        if (this.r)
          System.out.println("Creating new instance for class " + str); 
        rPCService = (RPCService)constructor.newInstance(new Object[] { this.d, d("entirex.server.serveraddress") });
        rPCService.setDefaultWaittime(this.e.getDefaultWaittime());
        rPCService.setAdjustReceiveLen(this.e.d());
        rPCService.setMaxReceiveLen(this.e.getMaxReceiveLen());
        rPCService.setEnvironment(this.e.getEnvironment());
        rPCService.useCodePage(this.e.useCodePage());
        rPCService.setCharacterEncoding(this.e.getCharacterEncoding());
        this.l.put(clazz, rPCService);
      } 
      Object object = rPCService.getServer();
      if (((o == null) ? (o = class$("com.softwareag.entirex.aci.ServerImplementation")) : o).isInstance(object)) {
        this.g = (ServerImplementation)object;
      } else {
        this.g = null;
      } 
      if (this.f)
        Trace.leaveMethod(Trace.M4, 2, 19, 56); 
      return rPCService;
    } catch (NoClassDefFoundError noClassDefFoundError) {
      if (paramBoolean)
        throw noClassDefFoundError; 
      this.e.a(paramArrayOfByte, "Class " + str + " not found (" + noClassDefFoundError + ")");
    } catch (ClassNotFoundException classNotFoundException) {
      if (paramBoolean)
        throw classNotFoundException; 
      this.e.a(paramArrayOfByte, "Class " + str + " not found (" + classNotFoundException + ")");
    } catch (NoSuchMethodException noSuchMethodException) {
      String str1;
      if (paramBoolean)
        return null; 
      if (bool) {
        str1 = "Method " + paramString2 + " not found in class " + str + " (" + noSuchMethodException + ")";
      } else {
        str1 = "Constructor for class " + str + " not found (" + noSuchMethodException + ")";
      } 
      this.e.a(paramArrayOfByte, str1);
    } catch (ClassCastException classCastException) {
      if (paramBoolean)
        return null; 
      this.e.a(paramArrayOfByte, "Class " + str + " has the wrong superclass (" + classCastException + ")");
    } catch (InvocationTargetException invocationTargetException) {
      System.err.print(invocationTargetException.toString());
      Throwable throwable = invocationTargetException.getTargetException();
      System.err.println(": " + throwable.toString());
      throwable.printStackTrace(System.err);
      this.e.b(paramArrayOfByte, throwable.toString());
    } catch (Exception exception) {
      synchronized (System.err) {
        System.err.println("Exception in library " + paramString1 + ", program " + paramString2);
        exception.printStackTrace();
      } 
      this.e.b(paramArrayOfByte, exception.toString());
    } 
    if (this.f)
      Trace.leaveMethod(Trace.M4, 2, 19, 56); 
    return null;
  }
  
  byte[] a(byte[] paramArrayOfByte) throws BrokerException, et {
    if (this.f)
      Trace.enterMethod(Trace.M4, 2, 19, 57); 
    try {
      RPCService rPCService = a(paramArrayOfByte, false, this.e.getLibraryName(), a(this.e.j(), false));
      if (this.i != null) {
        rPCService.setConversation(this.i);
        rPCService.a5 = this.e.a5;
      } 
      rPCService.b(paramArrayOfByte);
      this.c.invoke(rPCService, null);
      if (this.f)
        Trace.leaveMethod(Trace.M4, 2, 19, 57); 
      return rPCService.l();
    } catch (NoClassDefFoundError noClassDefFoundError) {
    
    } catch (ClassNotFoundException classNotFoundException) {
    
    } catch (InvocationTargetException invocationTargetException) {
      System.err.print(invocationTargetException.toString());
      Throwable throwable = invocationTargetException.getTargetException();
      System.err.println(": " + throwable.toString());
      throwable.printStackTrace(System.err);
      this.e.c(paramArrayOfByte, throwable.toString());
    } catch (IllegalAccessException illegalAccessException) {
      this.e.b(paramArrayOfByte, illegalAccessException.toString());
    } 
    if (this.f)
      Trace.leaveMethod(Trace.M4, 2, 19, 57); 
    return null;
  }
  
  int a(String paramString) {
    if (this.f)
      Trace.enterMethod(Trace.M4, 2, 19, 58); 
    int i1 = 0;
    if (paramString.equals("")) {
      i1 = 1140;
    } else {
      try {
        RPCService rPCService = a(null, true, paramString, "getServerRPCVersion");
        i1 = ((Integer)this.c.invoke(rPCService, null)).intValue();
      } catch (NoClassDefFoundError noClassDefFoundError) {
        i1 = 0;
      } catch (ClassNotFoundException classNotFoundException) {
        i1 = 0;
      } catch (Exception exception) {
        i1 = 1140;
      } 
    } 
    if (this.f)
      Trace.leaveMethod(Trace.M4, 2, 19, 58); 
    return i1;
  }
  
  public String[][] getServerEnhancedInfo() {
    String[][] arrayOfString = super.getServerEnhancedInfo();
    if (arrayOfString[0][0].equals("Server Type"))
      arrayOfString[0][1] = "EntireX RPC Java Server"; 
    return arrayOfString;
  }
  
  protected void a() {}
  
  protected void b() {}
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
  
  private class com/softwareag/entirex/aci/g extends h {
    private final RPCServer a;
    
    com/softwareag/entirex/aci/g(RPCServer this$0) {
      super(new Properties());
      this.a = this$0;
    }
    
    protected void init() {
      super.init();
      add(new Command("-server", "-s", "entirex.server.serveraddress", 1, 2, "RPC/SRV1/CALLNAT", "the server address as 'RPC/<server address>/CALLNAT' or <server address> with class and service,"));
    }
    
    public void a() {
      super.a();
      Properties properties = c();
      properties.put("entirex.server.name", (new EntireXVersion("Java RPC Server")).getVersionString());
      this.a.f((new EntireXVersion("Java RPC Server")).getVersionString());
    }
  }
  
  private class com/softwareag/entirex/aci/es extends RPCService {
    private final RPCServer a;
    
    com/softwareag/entirex/aci/es(RPCServer this$0, Broker param1Broker, String param1String) {
      super(param1Broker, param1String, null);
      this.a = this$0;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\RPCServer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */