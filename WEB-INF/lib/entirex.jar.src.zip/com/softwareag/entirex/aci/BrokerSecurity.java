package com.softwareag.entirex.aci;

public interface BrokerSecurity {
  void prepareLogon(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);
  
  byte[] getPassword();
  
  byte[] getNewpassword();
  
  byte[] getSecurityToken();
  
  void encryptData(byte[] paramArrayOfByte);
  
  void decryptData(byte[] paramArrayOfByte);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\BrokerSecurity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */