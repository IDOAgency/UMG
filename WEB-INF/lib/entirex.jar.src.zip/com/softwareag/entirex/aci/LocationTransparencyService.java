package com.softwareag.entirex.aci;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.Name;
import javax.naming.NameNotFoundException;
import javax.naming.NameParser;
import javax.naming.NamingException;

public class LocationTransparencyService {
  private static Context a = null;
  
  private static NameParser b = null;
  
  private static boolean c = false;
  
  private static final String d = "sag-key=200,sag-key=LocTrans,sag-key=EntireX,sag-key=Software AG";
  
  public static BrokerService lookupBrokerService(String paramString) throws BrokerException { return lookupBrokerService(paramString, "DefaultSet"); }
  
  public static BrokerService lookupBrokerService(String paramString1, String paramString2) throws BrokerException {
    if (!c)
      a(); 
    if (!c)
      throw new BrokerException("0250", "0208", "Error in configuration.", null, null); 
    try {
      if (paramString2 == null || paramString2.length() == 0)
        paramString2 = "DefaultSet"; 
      Name name = b.parse("sag-key=200,sag-key=LocTrans,sag-key=EntireX,sag-key=Software AG");
      name.add("sag-key=" + b(paramString2));
      name.add("sag-key=" + b("LogService=" + paramString1));
      return (BrokerService)a.lookup(name);
    } catch (NameNotFoundException nameNotFoundException) {
      throw new BrokerException("0250", "0208", "Error in configuration: Logical Service '" + paramString1 + "' in set '" + paramString2 + "' not found.", null, null);
    } catch (NamingException namingException) {
      if (namingException.getRootCause() instanceof BrokerException)
        throw (BrokerException)namingException.getRootCause(); 
      throw new BrokerException("0250", "0208", "Error in configuration: " + namingException, null, null);
    } catch (ClassCastException classCastException) {
      throw new BrokerException("0250", "0208", "Error in configuration, ExxObjectFactory missing: " + classCastException, null, null);
    } 
  }
  
  public static Broker lookupBroker(String paramString) throws BrokerException { return lookupBroker(paramString, "DefaultSet"); }
  
  public static Broker lookupBroker(String paramString1, String paramString2) throws BrokerException {
    if (!c)
      a(); 
    try {
      if (paramString2 == null || paramString2.length() == 0)
        paramString2 = "DefaultSet"; 
      Name name = b.parse("sag-key=200,sag-key=LocTrans,sag-key=EntireX,sag-key=Software AG");
      name.add("sag-key=" + b(paramString2));
      name.add("sag-key=" + b("LogBrokerId=" + paramString1));
      return (Broker)a.lookup(name);
    } catch (NameNotFoundException nameNotFoundException) {
      throw new BrokerException("0250", "0208", "Error in configuration: Logical Broker '" + paramString1 + "' in set '" + paramString2 + "' not found.", null, null);
    } catch (NamingException namingException) {
      if (namingException.getRootCause() instanceof BrokerException)
        throw (BrokerException)namingException.getRootCause(); 
      throw new BrokerException("0250", "0208", "Error in configuration: " + namingException, null, null);
    } catch (ClassCastException classCastException) {
      throw new BrokerException("0250", "0208", "Error in configuration, ExxObjectFactory missing: " + classCastException, null, null);
    } 
  }
  
  private static void a() {
    try {
      a = b();
      b = a.getNameParser("");
      c = true;
    } catch (Exception exception) {
      if (exception instanceof BrokerException)
        throw (BrokerException)exception; 
      throw new BrokerException("0250", "0208", "Error in configuration: " + exception, null, null);
    } 
  }
  
  public static void init(String paramString) throws BrokerException {
    try {
      a = a(paramString);
      b = a.getNameParser("");
      c = true;
    } catch (Exception exception) {
      if (exception instanceof BrokerException)
        throw (BrokerException)exception; 
      throw new BrokerException("0250", "0208", "Error in configuration: " + exception, null, null);
    } 
  }
  
  public static void init(Properties paramProperties) throws BrokerException {
    try {
      a = a(paramProperties);
      b = a.getNameParser("");
      c = true;
    } catch (Exception exception) {
      throw new BrokerException("0250", "0208", "Error in configuration: " + exception, null, null);
    } 
  }
  
  private static Context a(String paramString) {
    try {
      if (paramString == null) {
        InitialContext initialContext1 = new InitialContext();
        if (Dump.c)
          Dump.log("Created initial context using JNDI.properties"); 
        return initialContext1;
      } 
      Properties properties = new Properties();
      File file = new File(paramString);
      properties.load(new FileInputStream(file));
      InitialContext initialContext = new InitialContext(properties);
      if (Dump.c)
        Dump.log("Created initial context using " + file.getAbsolutePath() + " " + initialContext.getNameInNamespace()); 
      return initialContext;
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  private static Context a(Properties paramProperties) {
    try {
      InitialContext initialContext = new InitialContext(paramProperties);
      if (Dump.c)
        Dump.log("Created initial context using " + initialContext.getNameInNamespace()); 
      return initialContext;
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  private static Context b() throws BrokerException {
    Properties properties = new Properties();
    properties.put("java.naming.factory.object", "com.softwareag.entirex.aci.ExxObjectFactory");
    try {
      String str1 = System.getProperty("entirex.location.transparency.config");
      String str2 = null;
      String str3 = null;
      File file = null;
      if (str1 != null) {
        str1 = c(str1);
        if (str1.toLowerCase().startsWith("ldap://")) {
          properties.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
          StringTokenizer stringTokenizer = new StringTokenizer(str1, "?&");
          if (stringTokenizer.countTokens() >= 1) {
            properties.put("java.naming.provider.url", stringTokenizer.nextToken());
            while (stringTokenizer.hasMoreTokens()) {
              String str = stringTokenizer.nextToken();
              if (str.toLowerCase().startsWith("authdn=")) {
                str2 = str.substring(7);
                continue;
              } 
              if (str.toLowerCase().startsWith("authpass=")) {
                str3 = str.substring(9);
                continue;
              } 
              int i = str.indexOf("=");
              properties.put(str.substring(0, i), str.substring(i + 1));
            } 
          } 
        } 
      } else {
        String str7;
        String str4 = System.getProperty("os.name").startsWith("Windows") ? "C:\\Program Files\\Software AG\\EntireX\\etc\\XDS.ini" : "use 'entirex.location.transparency.ini' to set LDAP configuration file";
        String str5 = System.getProperty("os.name").startsWith("Windows") ? "C:\\Program Files\\Software AG\\EntireX" : "use 'entirex.home' to set EntireX installation folder";
        String str6 = System.getProperty("entirex.location.transparency.ini", str4);
        file = new File(str6);
        if (!file.exists()) {
          String str = System.getProperty("entirex.home", str5);
          file = new File(str + File.separator + "etc" + File.separator + "xds.ini");
          if (!file.exists())
            file = new File(str + File.separator + "etc" + File.separator + "XDS.ini"); 
        } 
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file.getAbsolutePath()));
        boolean bool1 = false;
        String str8 = "";
        String str9 = "localhost";
        String str10 = "389";
        boolean bool2 = false;
        do {
          str7 = bufferedReader.readLine();
          if (str7 == null)
            continue; 
          if (str7.equalsIgnoreCase("[Location Transparency]")) {
            bool1 = true;
          } else if (str7.startsWith("[")) {
            bool1 = false;
          } 
          if (!bool1)
            continue; 
          if (str7.toLowerCase().startsWith("dirservice=ldapdir"))
            properties.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory"); 
          if (str7.toLowerCase().startsWith("dirservice=flatdir"))
            throw new Exception("FlatDir not supported"); 
          if (str7.toLowerCase().startsWith("basedn="))
            str8 = str7.substring(7); 
          if (str7.toLowerCase().startsWith("host="))
            str9 = str7.substring(5); 
          if (str7.toLowerCase().startsWith("port="))
            str10 = str7.substring(5); 
          if (str7.toLowerCase().startsWith("authdn="))
            str2 = str7.substring(7); 
          if (!str7.toLowerCase().startsWith("authpass="))
            continue; 
          str3 = str7.substring(9);
        } while (str7 != null);
        properties.put("java.naming.provider.url", "ldap://" + str9 + ":" + str10 + "/" + str8);
        bufferedReader.close();
      } 
      if (str2 != null)
        properties.put("java.naming.security.principal", str2); 
      if (str3 != null)
        properties.put("java.naming.security.credentials", str3); 
      if (Dump.c) {
        String str = null;
        Dump.log("Configuring JNDI using the following properties: ");
        Enumeration enumeration = properties.propertyNames();
        while (enumeration.hasMoreElements()) {
          str = (String)enumeration.nextElement();
          if (str.equals("java.naming.security.credentials")) {
            Dump.log(str + "=********");
            continue;
          } 
          Dump.log(str + "=" + properties.getProperty(str));
        } 
      } 
      InitialContext initialContext = new InitialContext(properties);
      if (Dump.c)
        if (str1 != null) {
          Dump.log("Created initial context using " + str1 + " " + initialContext.getNameInNamespace());
        } else {
          Dump.log("Created initial context using " + file.getAbsolutePath() + " " + initialContext.getNameInNamespace());
        }  
      return initialContext;
    } catch (Throwable throwable) {
      throw new BrokerException("0250", "0208", "Error in configuration: " + throwable, null, null);
    } 
  }
  
  private static String b(String paramString) {
    StringBuffer stringBuffer = new StringBuffer(paramString);
    for (byte b1 = 0; b1 < stringBuffer.length(); b1++) {
      if (stringBuffer.charAt(b1) == ',')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '+')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '"')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '<')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '>')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == ';')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '\\' && !a(stringBuffer, b1))
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '=')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '#')
        stringBuffer.insert(b1++, '\\'); 
    } 
    return new String(stringBuffer);
  }
  
  private static boolean a(StringBuffer paramStringBuffer, int paramInt) { return (paramInt < paramStringBuffer.length() - 2 && paramStringBuffer.charAt(paramInt) == '\\' && a(paramStringBuffer.charAt(paramInt + 1)) && a(paramStringBuffer.charAt(paramInt + 2))); }
  
  private static boolean a(char paramChar) { return (Character.isDigit(paramChar) || (Character.isLetter(paramChar) && ((paramChar >= 'A' && paramChar <= 'F') || (paramChar >= 'a' && paramChar <= 'f')))); }
  
  private static String c(String paramString) {
    int i = 0;
    int j = 0;
    for (String str = ""; 0 <= i && i < paramString.length(); str = str + paramString.substring(j)) {
      i = paramString.indexOf("\\&", j);
      if (i > 0) {
        str = str + paramString.substring(j, i);
        j = i + 1;
        continue;
      } 
    } 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\LocationTransparencyService.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */