package com.softwareag.entirex.aci;

import java.applet.Applet;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class Dump {
  private static final char[] a = { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'A', 'B', 'C', 'D', 'E', 'F' };
  
  private static int b = 0;
  
  static boolean c = false;
  
  static final EntireXVersion d = new EntireXVersion("Java Runtime");
  
  private static PrintWriter e = new PrintWriter(System.out, true);
  
  private static boolean f = false;
  
  private static boolean g = true;
  
  private static String h;
  
  private static boolean i = false;
  
  private static boolean j = false;
  
  private static boolean k = true;
  
  public static boolean a() { return c; }
  
  static void a(String paramString) { a(paramString, null); }
  
  static void a(String paramString, PrintWriter paramPrintWriter) {
    if (paramString == null || paramString.length() == 0 || paramString.equalsIgnoreCase("none")) {
      paramString = "0";
    } else if (paramString.equalsIgnoreCase("standard")) {
      paramString = "1";
    } else if (paramString.equalsIgnoreCase("advanced")) {
      paramString = "2";
    } else if (paramString.equalsIgnoreCase("support")) {
      paramString = "3";
    } 
    a(Integer.parseInt(paramString), paramPrintWriter);
  }
  
  public static void setTrace(int paramInt) { a(paramInt, null); }
  
  public static void a(int paramInt, PrintWriter paramPrintWriter) {
    b = paramInt;
    c = (b > 0);
    if (paramPrintWriter != null)
      e = paramPrintWriter; 
  }
  
  public static void setTrace(int paramInt, PrintWriter paramPrintWriter, boolean paramBoolean) {
    g = paramBoolean;
    a(paramInt, paramPrintWriter);
  }
  
  public static int b() { return b; }
  
  static boolean c() { return f; }
  
  static String d() { return h; }
  
  static boolean e() { return i; }
  
  static boolean f() { return k; }
  
  static boolean b(String paramString) { return (paramString == null) ? false : ((paramString.toLowerCase().startsWith("y") || paramString.toLowerCase().equals("true"))); }
  
  static boolean c(String paramString) { return (paramString == null) ? false : ((paramString.toLowerCase().startsWith("n") || paramString.toLowerCase().equals("false"))); }
  
  static void a(Applet paramApplet) {
    if (j)
      return; 
    j = true;
    if (paramApplet != null)
      try {
        String str = paramApplet.getParameter("entirex.trace");
        if (str == null || str.length() == 0 || str.equalsIgnoreCase("none")) {
          str = "0";
        } else if (str.equalsIgnoreCase("standard")) {
          str = "1";
        } else if (str.equalsIgnoreCase("advanced")) {
          str = "2";
        } else if (str.equalsIgnoreCase("support")) {
          str = "3";
        } 
        setTrace(Integer.parseInt(str));
      } catch (NumberFormatException numberFormatException) {} 
    byte[] arrayOfByte = { 1 };
    InputStreamReader inputStreamReader = new InputStreamReader(new ByteArrayInputStream(arrayOfByte));
    h = null;
    if (paramApplet != null) {
      h = paramApplet.getParameter("entirex.cp");
    } else if (!f) {
      try {
        if (c(System.getProperty("entirex.kernelv.cache")))
          k = false; 
        h = System.getProperty("entirex.cp");
      } catch (SecurityException securityException) {}
    } 
    if (h == null || h.length() == 0) {
      h = inputStreamReader.getEncoding();
    } else if (h.equals("LOCAL")) {
      h = inputStreamReader.getEncoding();
      i = true;
    } else {
      i = true;
    } 
  }
  
  public static void dumpBytes(String paramString, byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    if (b < paramInt2)
      return; 
    synchronized (e) {
      byte b1 = 16;
      int m = 0;
      int n = paramInt1;
      byte[] arrayOfByte1 = new byte[b1];
      byte[] arrayOfByte2 = new byte[b1];
      boolean bool = false;
      e.println();
      e.println(g() + paramString + paramInt1 + " bytes:");
      StringBuffer stringBuffer = new StringBuffer();
      if (n > 0)
        arrayOfByte2[0] = (byte)(paramArrayOfByte[0] ^ 0xFFFFFFFF); 
      while (n > 0) {
        int i1;
        if (n > b1) {
          i1 = b1;
        } else {
          i1 = n;
        } 
        System.arraycopy(paramArrayOfByte, m, arrayOfByte1, 0, i1);
        n -= i1;
        m += i1;
        if (a(arrayOfByte1, arrayOfByte2)) {
          if (!bool) {
            bool = true;
            e("              -same as above-");
          } 
          continue;
        } 
        bool = false;
        System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, b1);
        stringBuffer.setLength(0);
        a(m - i1, stringBuffer);
        stringBuffer.append("   ");
        for (byte b2 = 0; b2 < arrayOfByte1.length; b2++) {
          if (b2 % 4 == 0)
            stringBuffer.append(' '); 
          if (b2 % 8 == 0)
            stringBuffer.append(' '); 
          if (b2 < i1) {
            a(arrayOfByte1[b2], stringBuffer);
          } else {
            stringBuffer.append("  ");
            arrayOfByte1[b2] = 32;
          } 
        } 
        stringBuffer.append("  |");
        a(arrayOfByte1, stringBuffer);
        stringBuffer.append('|');
        b(stringBuffer);
      } 
    } 
  }
  
  private static void b(StringBuffer paramStringBuffer) { e(paramStringBuffer.toString()); }
  
  private static void e(String paramString) { e.println(paramString); }
  
  private static void a(char paramChar, StringBuffer paramStringBuffer) {
    char c1 = paramChar >> '\004' & 0xF;
    paramStringBuffer.append(a[c1]);
    c1 = paramChar & 0xF;
    paramStringBuffer.append(a[c1]);
  }
  
  private static void a(byte paramByte, StringBuffer paramStringBuffer) {
    byte b1 = paramByte >> 4 & 0xF;
    paramStringBuffer.append(a[b1]);
    b1 = paramByte & 0xF;
    paramStringBuffer.append(a[b1]);
  }
  
  private static void a(int paramInt, StringBuffer paramStringBuffer) {
    for (byte b1 = 32; b1 > 0; b1 -= 4) {
      int m = paramInt >> b1 - 4 & 0xF;
      paramStringBuffer.append(a[m]);
    } 
  }
  
  static void a(byte[] paramArrayOfByte, StringBuffer paramStringBuffer) {
    int n = paramStringBuffer.length();
    String str = new String(paramArrayOfByte);
    paramStringBuffer.append(str);
    for (int m = n; m < paramStringBuffer.length(); m++) {
      char c1 = paramStringBuffer.charAt(m);
      if (Character.isWhitespace(c1) && !Character.isSpaceChar(c1)) {
        paramStringBuffer.setCharAt(m, '.');
      } else if (Character.isISOControl(c1)) {
        paramStringBuffer.setCharAt(m, '.');
      } 
    } 
  }
  
  private static boolean a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2) {
    if (paramArrayOfByte1.length != paramArrayOfByte2.length)
      return false; 
    for (byte b1 = 0; b1 < paramArrayOfByte1.length; b1++) {
      if (paramArrayOfByte1[b1] != paramArrayOfByte2[b1])
        return false; 
    } 
    return true;
  }
  
  private static String g() {
    if (g) {
      g = false;
      e.println(g() + "Trace started:");
      e.println(g() + d.getVersionString());
      e.println(g() + "Java version=" + System.getProperty("java.version"));
      e.println(g() + "Java vendor=" + System.getProperty("java.vendor"));
      e.println(g() + "Java class version=" + System.getProperty("java.class.version"));
      e.println(g() + "OS name=" + System.getProperty("os.name"));
      e.println(g() + "OS version=" + System.getProperty("os.version"));
      e.println(g() + "OS architecture=" + System.getProperty("os.arch"));
      e.println(g() + "Default encoding=" + h);
      Locale locale = Locale.getDefault();
      e.println(g() + "Country=" + locale.getCountry() + " Language=" + locale.getLanguage());
      try {
        e.println(g() + "Language code=" + System.getProperty("user.language"));
        e.println(g() + "Country code=" + System.getProperty("user.region"));
        e.println(g() + "Timezone=" + System.getProperty("user.timezone"));
        e.println(g() + "File encoding=" + System.getProperty("file.encoding"));
      } catch (SecurityException securityException) {}
    } 
    return (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")).format(new Date()) + '/' + Thread.currentThread().getName() + " ";
  }
  
  public static void log(String paramString) {
    if (b > 0)
      synchronized (e) {
        e.println(g() + paramString);
      }  
  }
  
  public static void logNoNewline(String paramString) {
    if (b > 0)
      synchronized (e) {
        e.print(g() + paramString);
      }  
  }
  
  public static void logNoPrefixNoNewline(String paramString) {
    if (b > 0)
      synchronized (e) {
        e.print(paramString);
      }  
  }
  
  public static void logNoPrefix(String paramString) {
    if (b > 0)
      synchronized (e) {
        e.println(paramString);
      }  
  }
  
  static void a(StringBuffer paramStringBuffer) {
    if (b > 0)
      synchronized (e) {
        e.println(g() + paramStringBuffer.toString());
      }  
  }
  
  static void d(String paramString) {
    if (b == -100)
      synchronized (e) {
        e.println(g() + paramString);
      }  
  }
  
  static  {
    try {
      String str = System.getProperty("entirex.trace", "0");
      a(str);
    } catch (SecurityException securityException) {
      f = true;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\Dump.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */