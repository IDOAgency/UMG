package com.softwareag.entirex.aci;

import java.awt.TextArea;

class com/softwareag/entirex/aci/ce {
  private TextArea a;
  
  private final Tester2 b;
  
  com/softwareag/entirex/aci/ce(Tester2 paramTester2, int paramInt1, int paramInt2) {
    if ((this.b = paramTester2).e(paramTester2))
      this.a = new Tester2.com/softwareag/entirex/aci/cf(paramTester2, paramInt1, paramInt2); 
  }
  
  TextArea a() { return this.a; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\ce.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */