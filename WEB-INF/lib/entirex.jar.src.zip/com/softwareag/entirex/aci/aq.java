package com.softwareag.entirex.aci;

public class aq extends BrokerException {
  private Throwable a;
  
  private int b;
  
  public static final int c = 0;
  
  public static final int d = 1;
  
  public static final int e = 2;
  
  public static final int f = 3;
  
  public aq(String paramString1, String paramString2, String paramString3, int paramInt) {
    super(paramString1, paramString2, paramString3, null, null);
    this.b = paramInt;
  }
  
  public aq(String paramString1, String paramString2, String paramString3, int paramInt, Throwable paramThrowable) {
    super(paramString1, paramString2, paramString3, null, null);
    this.b = paramInt;
    this.a = paramThrowable;
  }
  
  public int a() { return this.b; }
  
  public void a(int paramInt) { this.b = paramInt; }
  
  public Throwable b() { return this.a; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\aq.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */