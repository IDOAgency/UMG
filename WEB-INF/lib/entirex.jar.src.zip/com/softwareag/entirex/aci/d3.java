package com.softwareag.entirex.aci;

import com.sun.net.ssl.internal.ssl.Provider;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.Security;
import java.util.Properties;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

final class d3 extends d1 {
  private SSLContext a = null;
  
  public d3(String paramString, int paramInt, Properties paramProperties) throws GeneralSecurityException, IOException { super(paramString, paramInt, paramProperties); }
  
  protected SSLSocketFactory a(KeyStore paramKeyStore1, char[] paramArrayOfChar, KeyStore paramKeyStore2) throws ae { return c(paramKeyStore1, paramArrayOfChar, paramKeyStore2).getSocketFactory(); }
  
  protected SSLServerSocketFactory b(KeyStore paramKeyStore1, char[] paramArrayOfChar, KeyStore paramKeyStore2) throws ae { return c(paramKeyStore1, paramArrayOfChar, paramKeyStore2).getServerSocketFactory(); }
  
  private SSLContext c(KeyStore paramKeyStore1, char[] paramArrayOfChar, KeyStore paramKeyStore2) throws ae {
    if (this.a != null)
      return this.a; 
    KeyManager[] arrayOfKeyManager = null;
    TrustManager[] arrayOfTrustManager = null;
    try {
      if (paramKeyStore1 != null) {
        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        keyManagerFactory.init(paramKeyStore1, paramArrayOfChar);
        arrayOfKeyManager = keyManagerFactory.getKeyManagers();
      } 
      if (paramKeyStore2 != null) {
        TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        trustManagerFactory.init(paramKeyStore2);
        arrayOfTrustManager = trustManagerFactory.getTrustManagers();
      } 
      this.a = SSLContext.getInstance("TLS");
      this.a.init(arrayOfKeyManager, arrayOfTrustManager, null);
      if (Dump.c) {
        Dump.log("SSLContext Protocol = " + this.a.getProtocol());
        Dump.log("SSLContext Provider = " + this.a.getProvider());
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new ae("0400", new String[] { illegalArgumentException.getMessage() });
    } catch (GeneralSecurityException generalSecurityException) {
      throw new ae("0400", new String[] { generalSecurityException.getMessage() });
    } 
    return this.a;
  }
  
  static  {
    Security.addProvider(new Provider());
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\d3.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */