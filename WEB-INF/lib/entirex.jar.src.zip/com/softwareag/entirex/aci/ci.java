package com.softwareag.entirex.aci;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;

class ci implements ActionListener {
  private final Tester2 a;
  
  ci(Tester2 paramTester2) { this.a = paramTester2; }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    Tester2.a(this.a).setText("");
    Enumeration enumeration = Tester2.b(this.a).elements();
    while (enumeration.hasMoreElements()) {
      Tester2.com/softwareag/entirex/aci/b9 com/softwareag/entirex/aci/b9 = (Tester2.com/softwareag/entirex/aci/b9)enumeration.nextElement();
      com/softwareag/entirex/aci/b9.a("");
    } 
    Tester2.c(this.a);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\ci.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */