package com.softwareag.entirex.aci;

public class EntireXSecurity implements BrokerSecurity {
  public void prepareLogon(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3) { throw new IllegalAccessError(); }
  
  public byte[] prepareAutoLogon(byte[] paramArrayOfByte) { throw new IllegalAccessError(); }
  
  public byte[] getPassword() { throw new IllegalAccessError(); }
  
  public byte[] getNewpassword() { throw new IllegalAccessError(); }
  
  public byte[] getSecurityToken() { throw new IllegalAccessError(); }
  
  public void encryptData(byte[] paramArrayOfByte) { throw new IllegalAccessError(); }
  
  public void decryptData(byte[] paramArrayOfByte) { throw new IllegalAccessError(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\EntireXSecurity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */