package com.softwareag.entirex.aci;

import java.awt.TextArea;

class com/softwareag/entirex/aci/cf extends TextArea {
  private final Tester2 a;
  
  public com/softwareag/entirex/aci/cf(Tester2 paramTester2, int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
    this.a = paramTester2;
    setEditable(false);
  }
  
  public boolean isFocusTraversable() { return false; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\cf.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */