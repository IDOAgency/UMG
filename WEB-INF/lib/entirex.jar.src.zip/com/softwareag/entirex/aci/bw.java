package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.s;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Properties;

abstract class bw extends br {
  private static final int a = 0;
  
  private static final int b = 192;
  
  private static final int c = 192;
  
  protected int d = 0;
  
  private com/softwareag/entirex/aci/bx e = new com/softwareag/entirex/aci/bx(this, null);
  
  private boolean f = false;
  
  private long g(String paramString) { return (paramString.trim().length() == 0) ? 0L : Long.parseLong(paramString); }
  
  private int h(String paramString) { return (paramString.trim().length() == 0) ? 0 : Integer.parseInt(paramString); }
  
  public bw(byte[] paramArrayOfByte) throws be { this(paramArrayOfByte, s.a()); }
  
  public bw(byte[] paramArrayOfByte, s params) throws be {
    super(paramArrayOfByte, params);
    this.e = new com/softwareag/entirex/aci/bx(this, params.b(), null);
    Dump.dumpBytes("RPCMessage" + a() + ": RPC Header:", u(), u().length, 4);
    this.j = a(u(), au());
    if (params.b() == null) {
      this.l = new String(u(), ao(), ap());
      this.h = new String(u(), l(), an());
      this.n = new String(u(), as(), at());
      this.m = (new String(u(), a1(), a2())).equals("Y");
      this.d = h(new String(u(), a3(), 1));
      this.i = g(new String(u(), aq(), ar()));
      super.f = h(new String(u(), n(), o()));
      this.g = h(new String(u(), p(), q()));
    } else {
      try {
        this.l = new String(u(), ao(), ap(), params.b());
        this.h = new String(u(), l(), an(), params.b());
        this.n = new String(u(), as(), at(), params.b());
        this.m = (new String(u(), a1(), a2(), params.b())).equals("Y");
        this.d = h(new String(u(), a3(), 1, params.b()));
        this.i = g(new String(u(), aq(), ar(), params.b()));
        super.f = h(new String(u(), n(), o(), params.b()));
        this.g = h(new String(u(), p(), q(), params.b()));
      } catch (UnsupportedEncodingException unsupportedEncodingException) {}
    } 
    h(paramArrayOfByte);
    if (super.f != 0 || this.g != 0)
      throw new be(super.f, this.g, r()); 
    if (this.j == 7) {
      long l2;
      long l1;
      try {
        if (params.b() == null) {
          l1 = Long.parseLong(new String(u(), av(), aw()));
          l2 = Long.parseLong(new String(u(), az(), a0()));
        } else {
          l1 = Long.parseLong(new String(u(), av(), aw(), params.b()));
          l2 = Long.parseLong(new String(u(), az(), a0(), params.b()));
        } 
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        l1 = 0L;
        l2 = 0L;
      } catch (NumberFormatException numberFormatException) {
        l1 = 0L;
        l2 = 0L;
      } 
      if (l2 > 0L) {
        byte[] arrayOfByte = new byte[(int)l2];
        System.arraycopy(paramArrayOfByte, (int)l1, arrayOfByte, 0, (int)l2);
        d(arrayOfByte);
        Dump.dumpBytes(getClass().getName() + ": StringBuffer:", x(), x().length, 4);
        super.e = y();
        this.h = (String)super.e.get("LB");
      } 
    } else {
      f(0);
      for (int i = ad(); i < paramArrayOfByte.length; i++) {
        if (paramArrayOfByte[i] == params.c) {
          f(i - ad() + 1);
          break;
        } 
      } 
      if (ae() > 0) {
        byte[] arrayOfByte = new byte[ae()];
        System.arraycopy(paramArrayOfByte, ad(), arrayOfByte, 0, ae());
        b(arrayOfByte);
        Dump.dumpBytes("RPCMessage" + a() + ": FormatBuffer:", v(), v().length, 4);
      } else {
        Dump.log("RPCMessage" + a() + ": FormatBuffer: length <= 0.");
      } 
      i(ad() + ae());
      j(paramArrayOfByte.length - ah());
      if (ai() > 0) {
        byte[] arrayOfByte = new byte[ai()];
        System.arraycopy(paramArrayOfByte, ah(), arrayOfByte, 0, ai());
        e(arrayOfByte);
        Dump.dumpBytes("RPCMessage" + a() + ": ValueBuffer:", z(), z().length, 4);
      } else {
        Dump.log("RPCMessage" + a() + ": ValueBuffer: length <= 0.");
      } 
    } 
  }
  
  public bw(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, Properties paramProperties, ao paramao, s params) {
    super(paramao, params);
    this.e = new com/softwareag/entirex/aci/bx(this, params.b(), null);
    super.e = paramProperties;
    this.d = ao.n();
    this.h = (String)paramProperties.get("LB");
    this.l = (String)paramProperties.get("PM");
    this.n = (String)paramProperties.get("UID");
    Integer integer1 = (Integer)paramProperties.get("PacketType");
    this.j = (integer1 == null) ? ao.m() : integer1.intValue();
    Integer integer2 = (Integer)paramProperties.get("NumberParameter");
    this.i = (integer2 == null) ? ao.h() : integer2.intValue();
    super.e.remove("PacketType");
    Integer integer3 = (Integer)paramProperties.get("RPCError");
    super.f = (integer3 == null) ? 0 : integer3.intValue();
    paramProperties.remove("RPCError");
    Integer integer4 = (Integer)paramProperties.get("UserError");
    this.g = (integer4 == null) ? 0 : integer4.intValue();
    paramProperties.remove("UserError");
    this.f = ao.o();
    c(0);
    d(b());
    if (this.d != 1 || !this.f)
      b(paramArrayOfByte1); 
    e(ab() + ac());
    e(paramArrayOfByte2);
    i(ad() + ae());
    boolean bool = false;
    byte[] arrayOfByte1 = new byte[b()];
    for (byte b1 = 0; b1 < b(); b1++)
      arrayOfByte1[b1] = params.g; 
    a(arrayOfByte1);
    a(Integer.toString(a()), 0, arrayOfByte1, 0, 4);
    a(ak(), arrayOfByte1, n(), o());
    a(al(), arrayOfByte1, p(), q());
    String str1 = (String)paramProperties.get("NaturalErrorLine");
    if (str1 != null) {
      a(str1, 0, arrayOfByte1, p() + q(), 4);
      paramProperties.remove("NaturalErrorLine");
    } else {
      a(0L, arrayOfByte1, p() + q(), 4);
    } 
    String str2 = (String)paramProperties.get("NaturalErrorProgram");
    if (str2 != null) {
      a(str2, 0, arrayOfByte1, 22, 8);
      paramProperties.remove("NaturalErrorProgram");
    } 
    a(0L, arrayOfByte1, 30, 2);
    a(m(g()), 0, arrayOfByte1, au(), m());
    if (this.j != 7)
      a(d(), 0, arrayOfByte1, l(), an()); 
    a(e(), 0, arrayOfByte1, ao(), ap());
    a(f(), 0, arrayOfByte1, as(), at());
    a(k(), arrayOfByte1, aq(), ar());
    a("000000", 0, u(), ax(), ay());
    a("000000", 0, u(), av(), aw());
    a("000000", 0, u(), az(), a0());
    b(this.d);
    if (this.j == 7) {
      String str3 = null;
      String str4 = null;
      StringBuffer stringBuffer = new StringBuffer();
      Enumeration enumeration = paramProperties.propertyNames();
      while (enumeration.hasMoreElements()) {
        str3 = (String)enumeration.nextElement();
        if (str3.equals("MV") || str3.equals("ST") || str3.equals("SV") || str3.equals("SP") || str3.equals("LB") || str3.equals("SEC") || str3.equals("FB")) {
          str4 = paramProperties.getProperty(str3);
          stringBuffer.append(str3);
          stringBuffer.append("=");
          stringBuffer.append(Integer.toString(str4.length()));
          stringBuffer.append(",");
          stringBuffer.append(str4);
        } 
      } 
      if (params.b() == null) {
        d(stringBuffer.toString().getBytes());
      } else {
        try {
          d(stringBuffer.toString().getBytes(params.b()));
        } catch (UnsupportedEncodingException unsupportedEncodingException) {
          d(stringBuffer.toString().getBytes());
        } 
      } 
      g(ab() + ac() + ae() + ai());
      a(af(), arrayOfByte1, av(), aw());
      a(ag(), arrayOfByte1, az(), a0());
    } else if (ak() != 0 || al() != 0) {
      StringBuffer stringBuffer = a5();
      if (stringBuffer != null && stringBuffer.length() > 0) {
        if (params.b() == null) {
          d(stringBuffer.toString().getBytes());
        } else {
          try {
            d(stringBuffer.toString().getBytes(params.b()));
          } catch (UnsupportedEncodingException unsupportedEncodingException) {
            d(stringBuffer.toString().getBytes());
          } 
        } 
        g(ab() + ac() + ae() + ai());
      } else {
        h(0);
      } 
    } else {
      h(0);
    } 
    a(arrayOfByte1);
    byte[] arrayOfByte2 = new byte[b() + ag() + ae() + ai()];
    if (w())
      System.arraycopy(v(), 0, arrayOfByte2, ad(), ae()); 
    if (aa())
      System.arraycopy(z(), 0, arrayOfByte2, ah(), ai()); 
    if (ag() > 0)
      System.arraycopy(x(), 0, arrayOfByte2, af(), ag()); 
    System.arraycopy(u(), 0, arrayOfByte2, ab(), ac());
    g(arrayOfByte2);
  }
  
  protected int b() { return 192; }
  
  protected int c() { return 0; }
  
  protected int ad() { return 192; }
  
  protected abstract int l();
  
  protected abstract int an();
  
  protected abstract int ao();
  
  protected abstract int ap();
  
  protected abstract int as();
  
  protected abstract int at();
  
  protected abstract int au();
  
  protected abstract int m();
  
  protected abstract int av();
  
  protected abstract int aw();
  
  protected abstract int az();
  
  protected abstract int a0();
  
  protected abstract int ax();
  
  protected abstract int ay();
  
  protected abstract int a1();
  
  protected abstract int a2();
  
  protected abstract int a3();
  
  protected abstract int a4();
  
  protected abstract int aq();
  
  protected abstract int ar();
  
  protected abstract int a();
  
  public String d() { return (this.h != null) ? this.h : ""; }
  
  public void a(String paramString) throws be {
    if (paramString.length() > an())
      throw new be(7, "library name longer than " + an() + " characters"); 
    this.h = paramString;
    a(this.h, 0, u(), l(), an());
  }
  
  public String e() { return (this.l != null) ? this.l : ""; }
  
  public void b(String paramString) throws be {
    if (paramString.length() > ap())
      throw new be(7, "program name longer than " + ap() + " characters"); 
    this.l = paramString;
    a(this.l, 0, u(), ao(), ap());
  }
  
  public String f() { return (this.n != null) ? this.n : ""; }
  
  public void c(String paramString) throws be {
    if (paramString.length() > at())
      throw new be(7, "user id longer than " + at() + " characters"); 
    this.n = paramString;
    a(this.n, 0, u(), as(), at());
  }
  
  public int g() { return this.j; }
  
  public void a(int paramInt) {
    this.j = paramInt;
    a(m(paramInt), 0, u(), au(), m());
  }
  
  public String h() { throw new be(7, "language code does not exist in this protocol version"); }
  
  public void d(String paramString) throws be { throw new be(7, "language code does not exist in this protocol version"); }
  
  public boolean i() throws be { return this.m; }
  
  public void a(boolean paramBoolean) throws BrokerException {
    if (this.m != paramBoolean) {
      this.m = paramBoolean;
      String str = null;
      if (this.m) {
        str = "Y";
        a(aj().length, u(), ax(), ay());
        if (this.o.b() == null) {
          g(a(aj(), bu.a(d(), f(), am()).getBytes()));
        } else {
          try {
            g(a(aj(), bu.a(d(), f(), am()).getBytes(this.o.b())));
          } catch (UnsupportedEncodingException unsupportedEncodingException) {
            g(a(aj(), bu.a(d(), f(), am()).getBytes()));
          } 
        } 
      } else {
        str = " ";
        String str1 = "0";
        if (this.o.b() == null) {
          str1 = new String(u(), ax(), ay());
        } else {
          try {
            str1 = new String(u(), ax(), ay(), this.o.b());
          } catch (UnsupportedEncodingException unsupportedEncodingException) {}
        } 
        int i = Integer.valueOf(str1).intValue();
        byte b1 = (aj()[i] == 85) ? 9 : 58;
        g(a(aj(), i, b1));
        a("000000", 0, u(), ax(), ay());
      } 
      a(str, 0, u(), a1(), a2());
    } 
  }
  
  public void b(boolean paramBoolean) throws BrokerException { this.f = paramBoolean; }
  
  public long k() { return this.i; }
  
  public void a(long paramLong) {
    this.i = paramLong;
    a(this.i, u(), aq(), ar());
  }
  
  private int a(byte[] paramArrayOfByte, int paramInt) {
    byte b1 = 0;
    return a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bx.a(this.e)) ? 5 : (a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bx.b(this.e)) ? 2 : (a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bx.c(this.e)) ? 1 : (a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bx.d(this.e)) ? 3 : (a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bx.e(this.e)) ? 4 : (a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bx.f(this.e)) ? 7 : (a(paramArrayOfByte, paramInt, com/softwareag/entirex/aci/bx.g(this.e)) ? 6 : b1))))));
  }
  
  private byte[] m(int paramInt) {
    byte[] arrayOfByte = null;
    switch (paramInt) {
      case 4:
        arrayOfByte = com/softwareag/entirex/aci/bx.e(this.e);
        break;
      case 3:
        arrayOfByte = com/softwareag/entirex/aci/bx.d(this.e);
        break;
      case 7:
        arrayOfByte = com/softwareag/entirex/aci/bx.f(this.e);
        break;
      case 6:
        arrayOfByte = com/softwareag/entirex/aci/bx.g(this.e);
        break;
      case 2:
        arrayOfByte = com/softwareag/entirex/aci/bx.b(this.e);
        break;
      case 5:
        arrayOfByte = com/softwareag/entirex/aci/bx.a(this.e);
        break;
      case 1:
        arrayOfByte = com/softwareag/entirex/aci/bx.c(this.e);
        break;
    } 
    return arrayOfByte;
  }
  
  protected void h(byte[] paramArrayOfByte) throws be {}
  
  protected void s() {
    if (ag() > 0) {
      a(af(), u(), av(), aw());
      a(ag(), u(), az(), a0());
    } 
  }
  
  protected StringBuffer a5() { return null; }
  
  public void t() {
    StringBuffer stringBuffer = a5();
    if (stringBuffer != null && stringBuffer.length() > 0) {
      byte[] arrayOfByte;
      int i = ag();
      if (this.o.b() == null) {
        arrayOfByte = stringBuffer.toString().getBytes();
      } else {
        try {
          arrayOfByte = stringBuffer.toString().getBytes(this.o.b());
        } catch (UnsupportedEncodingException unsupportedEncodingException) {
          arrayOfByte = stringBuffer.toString().getBytes();
        } 
      } 
      d(arrayOfByte);
      g(ab() + ac() + ae() + ai());
      if (aj() != null && ag() > 0) {
        byte[] arrayOfByte1 = new byte[aj().length + arrayOfByte.length - i];
        System.arraycopy(aj(), 0, arrayOfByte1, 0, af());
        System.arraycopy(x(), 0, arrayOfByte1, af(), ag());
        System.arraycopy(aj(), af() + i, arrayOfByte1, af() + ag(), aj().length - af() - i);
        g(arrayOfByte1);
        e(af() + ag());
        i(ad() + ae());
        s();
      } 
    } else {
      h(0);
    } 
  }
  
  public void a(String paramString1, String paramString2) {
    if (paramString1 != null) {
      a(paramString1, 0, u(), p() + q(), 4);
    } else {
      a(0L, u(), p() + q(), 4);
    } 
    if (paramString2 != null)
      a(paramString2, 0, u(), 22, 8); 
    a(0L, u(), 30, 2);
  }
  
  public void e(String paramString) throws be {
    if (paramString != null)
      a(paramString, 0, u(), 100, 92); 
  }
  
  class com/softwareag/entirex/aci/ev {}
  
  private class com/softwareag/entirex/aci/bx {
    private byte[] a;
    
    private byte[] b;
    
    private byte[] c;
    
    private byte[] d;
    
    private byte[] e;
    
    private byte[] f;
    
    private byte[] g;
    
    private final bw h;
    
    private com/softwareag/entirex/aci/bx(bw this$0) {
      this.h = this$0;
      this.a = "OC".getBytes();
      this.b = "  ".getBytes();
      this.c = "CE".getBytes();
      this.d = "CB".getBytes();
      this.e = "CO".getBytes();
      this.f = "IN".getBytes();
      this.g = "NC".getBytes();
    }
    
    private com/softwareag/entirex/aci/bx(bw this$0, String param1String) {
      this.h = this$0;
      try {
        this.a = "OC".getBytes(param1String);
        this.b = "  ".getBytes(param1String);
        this.c = "CE".getBytes(param1String);
        this.d = "CB".getBytes(param1String);
        this.e = "CO".getBytes(param1String);
        this.f = "IN".getBytes(param1String);
        this.g = "NC".getBytes(param1String);
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        this.a = "OC".getBytes();
        this.b = "  ".getBytes();
        this.c = "CE".getBytes();
        this.d = "CB".getBytes();
        this.e = "CO".getBytes();
        this.f = "IN".getBytes();
        this.g = "NC".getBytes();
      } catch (NullPointerException nullPointerException) {
        this.a = "OC".getBytes();
        this.b = "  ".getBytes();
        this.c = "CE".getBytes();
        this.d = "CB".getBytes();
        this.e = "CO".getBytes();
        this.f = "IN".getBytes();
        this.g = "NC".getBytes();
      } 
    }
    
    com/softwareag/entirex/aci/bx(bw this$0, bw.com/softwareag/entirex/aci/ev param1com/softwareag/entirex/aci/ev) { this(this$0); }
    
    com/softwareag/entirex/aci/bx(bw this$0, String param1String, bw.com/softwareag/entirex/aci/ev param1com/softwareag/entirex/aci/ev) { this(this$0, param1String); }
    
    static byte[] a(com/softwareag/entirex/aci/bx param1com/softwareag/entirex/aci/bx) { return param1com/softwareag/entirex/aci/bx.g; }
    
    static byte[] b(com/softwareag/entirex/aci/bx param1com/softwareag/entirex/aci/bx) { return param1com/softwareag/entirex/aci/bx.b; }
    
    static byte[] c(com/softwareag/entirex/aci/bx param1com/softwareag/entirex/aci/bx) { return param1com/softwareag/entirex/aci/bx.a; }
    
    static byte[] d(com/softwareag/entirex/aci/bx param1com/softwareag/entirex/aci/bx) { return param1com/softwareag/entirex/aci/bx.c; }
    
    static byte[] e(com/softwareag/entirex/aci/bx param1com/softwareag/entirex/aci/bx) { return param1com/softwareag/entirex/aci/bx.d; }
    
    static byte[] f(com/softwareag/entirex/aci/bx param1com/softwareag/entirex/aci/bx) { return param1com/softwareag/entirex/aci/bx.f; }
    
    static byte[] g(com/softwareag/entirex/aci/bx param1com/softwareag/entirex/aci/bx) { return param1com/softwareag/entirex/aci/bx.e; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\bw.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */