package com.softwareag.entirex.aci;

public class UnitofWorkTopic extends UnitofWork {
  public UnitofWorkTopic(BrokerTopic paramBrokerTopic) {
    super(paramBrokerTopic);
    paramBrokerTopic.getBroker().a(true);
    this.g = true;
  }
  
  public UnitofWorkTopic(BrokerTopic paramBrokerTopic, ConversationState paramConversationState) throws IllegalArgumentException {
    super(paramBrokerTopic, paramConversationState);
    paramBrokerTopic.getBroker().a(true);
    this.g = true;
  }
  
  UnitofWorkTopic(BrokerTopic paramBrokerTopic, String paramString) throws BrokerException {
    super(paramBrokerTopic, paramString);
    paramBrokerTopic.getBroker().a(true);
    this.g = true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\UnitofWorkTopic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */