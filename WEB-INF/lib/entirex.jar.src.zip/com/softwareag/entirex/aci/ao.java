package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.ac;
import com.softwareag.entirex.base.s;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

public class ao implements Cloneable {
  private static final int a = 1;
  
  private static final int b = 7;
  
  public static final int c = 1;
  
  public static final int d = 2;
  
  public static final int e = 3;
  
  public static final int f = 4;
  
  public static final int g = 5;
  
  public static final int h = 6;
  
  public static final int i = 7;
  
  private static long j = 0L;
  
  private static String k = null;
  
  private static String l = null;
  
  private static String m = null;
  
  private static String n = null;
  
  private static int o = 5;
  
  private static int p = 0;
  
  private static boolean q = false;
  
  private static boolean r = false;
  
  private static String s = null;
  
  private bs t = null;
  
  private int u = 0;
  
  private s v = s.a();
  
  private static final s w = s.a();
  
  private static final byte[] x = new byte[0];
  
  private static final String y = " " + System.getProperty("os.name") + " " + System.getProperty("os.version") + " " + System.getProperty("os.arch") + ".";
  
  private static String z = "EntireX Java Server " + EntireXVersion.getVersion() + y;
  
  private static String aa = null;
  
  private static final int ab = 50;
  
  public ao(byte[] paramArrayOfByte) throws be { this(paramArrayOfByte, w); }
  
  public ao(byte[] paramArrayOfByte, s params) throws be {
    if (paramArrayOfByte != null) {
      String str = null;
      try {
        str = new String(paramArrayOfByte, 0, 4);
        this.u = ac.a(paramArrayOfByte, 0, 4, params);
      } catch (NumberFormatException numberFormatException) {
        throw new be(8, "Unknown version " + str + ", not an integer");
      } 
      switch (this.u) {
        case 2000:
          this.t = new bq(paramArrayOfByte, params);
          return;
        case 1140:
          this.t = new bv(paramArrayOfByte, params);
          return;
        case 1130:
          this.t = new by(paramArrayOfByte, params);
          return;
        case 1120:
          this.t = new bz(paramArrayOfByte, params);
          return;
        case 1110:
          this.t = new b0(paramArrayOfByte, params);
          return;
      } 
      this.t = null;
      throw new be(8, "Unknown version " + this.u);
    } 
    throw new be(8, "Unknown version: no message object");
  }
  
  public ao(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, Properties paramProperties, int paramInt) throws be { this(paramArrayOfByte1, paramArrayOfByte2, paramProperties, paramInt, s.a()); }
  
  public ao(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, Properties paramProperties, int paramInt, s params) throws be {
    if (paramInt == 0)
      paramInt = 2000; 
    this.v = params;
    if (paramArrayOfByte1 == null)
      paramArrayOfByte1 = ac(); 
    a(paramInt, paramArrayOfByte1, paramArrayOfByte2, paramProperties, params);
  }
  
  public ao(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, Properties paramProperties) throws be { this(paramArrayOfByte1, paramArrayOfByte2, paramProperties, 2000, s.a()); }
  
  public Properties a() {
    try {
      return (this.t != null) ? this.t.y() : null;
    } catch (be be) {
      return null;
    } 
  }
  
  private void a(Properties paramProperties) {
    if (this.t != null)
      this.t.a(paramProperties); 
  }
  
  public byte[] b() { return (this.t != null) ? this.t.v() : null; }
  
  public void a(byte[] paramArrayOfByte) throws be {
    if (this.t != null)
      this.t.c(paramArrayOfByte); 
  }
  
  public byte[] c() { return (this.t != null) ? this.t.z() : null; }
  
  public void b(byte[] paramArrayOfByte) throws be {
    if (this.t != null)
      this.t.f(paramArrayOfByte); 
  }
  
  private byte[] ae() { return (this.t != null) ? this.t.x() : null; }
  
  private void af() {
    if (this.t != null)
      this.t.t(); 
  }
  
  private void a(String paramString1, String paramString2) {
    if (this.t != null)
      this.t.a(paramString1, paramString2); 
  }
  
  private void n(String paramString) {
    if (this.t != null)
      this.t.e(paramString); 
  }
  
  public byte[] d() { return (this.t != null) ? this.t.aj() : null; }
  
  public int e() { return this.u; }
  
  public void a(int paramInt) throws be {
    if (this.u != paramInt) {
      byte[] arrayOfByte1 = null;
      byte[] arrayOfByte2 = null;
      Properties properties = null;
      if (this.t != null) {
        arrayOfByte1 = this.t.v();
        arrayOfByte2 = this.t.z();
        properties = this.t.y();
      } 
      a(paramInt, arrayOfByte1, arrayOfByte2, properties, s.a());
    } 
  }
  
  private void a(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, Properties paramProperties, s params) throws be {
    switch (paramInt) {
      case 2000:
        this.t = new bq(paramArrayOfByte1, paramArrayOfByte2, paramProperties, this, params);
        break;
      case 1140:
        this.t = new bv(paramArrayOfByte1, paramArrayOfByte2, paramProperties, this, params);
        break;
      case 1130:
        this.t = new by(paramArrayOfByte1, paramArrayOfByte2, paramProperties, this, params);
        break;
      case 1120:
        this.t = new bz(paramArrayOfByte1, paramArrayOfByte2, paramProperties, this, params);
        break;
      case 1110:
        this.t = new b0(paramArrayOfByte1, paramArrayOfByte2, paramProperties, this, params);
        break;
      default:
        this.t = null;
        throw new be(8, "Unknown version " + paramInt);
    } 
    this.u = paramInt;
  }
  
  public static ao a(String paramString) { return a(paramString, w); }
  
  public static ao a(String paramString, s params) {
    Properties properties = new Properties();
    if (paramString != null)
      properties.put("LB", paramString); 
    properties.put("PacketType", new Integer(7));
    try {
      return new ao(null, x, properties, 1110, params);
    } catch (be be) {
      return (ao)null;
    } 
  }
  
  public static String c(byte[] paramArrayOfByte) throws be { return a(paramArrayOfByte, w); }
  
  public static String a(byte[] paramArrayOfByte, s params) throws be {
    ao ao1 = new ao(paramArrayOfByte, params);
    String str = null;
    if (ao1.v() == 7) {
      str = (String)ao1.a().get("LB");
    } else {
      throw new be(11, "Invalid packet type " + ao1.v());
    } 
    return str;
  }
  
  public static ao b(int paramInt) throws be { return a(paramInt, "EntireX Java"); }
  
  public static ao a(int paramInt, s params) throws be { return a(paramInt, "EntireX Java", params); }
  
  public static ao a(int paramInt, String paramString) throws be { return a(paramInt, paramString, w); }
  
  public static ao a(int paramInt, String paramString, s params) throws be {
    switch (paramInt) {
      case 1110:
      case 1120:
      case 1130:
        return a(11, 0, "Invalid packet type", 1110, params);
      case 1140:
      case 2000:
        break;
      default:
        throw new be(8, "Unknown version " + paramInt);
    } 
    String str1 = EntireXVersion.getInternalVersion();
    String str2 = System.getProperty("os.name") + " " + System.getProperty("os.version") + " (" + System.getProperty("os.arch") + ")";
    Properties properties = new Properties();
    properties.put("MV", Integer.toString(paramInt));
    properties.put("ST", (paramString == null) ? "EntireX Java" : paramString);
    properties.put("SV", str1);
    properties.put("SP", str2);
    properties.put("PacketType", new Integer(7));
    return new ao(null, x, properties, 1110, params);
  }
  
  public static int d(byte[] paramArrayOfByte) throws BrokerException { return b(paramArrayOfByte, w); }
  
  public static int b(byte[] paramArrayOfByte, s params) throws BrokerException {
    int i1 = 0;
    try {
      ao ao1 = new ao(paramArrayOfByte, params);
      if (ao1.v() == 7) {
        Properties properties;
        String str = (String)ao1.a().get("MV");
        try {
          i1 = (str != null) ? Integer.parseInt(str) : 0;
        } catch (NumberFormatException numberFormatException) {
          throw new BrokerException("1001", "0008", "Unknown version " + str, null, null);
        } 
        switch (i1) {
          case 1110:
          case 1120:
          case 1130:
          case 1140:
          case 2000:
            properties = ao1.a();
            aa = properties.get("ST") + " " + properties.get("SP") + " Version " + properties.get("SV");
            return i1;
          case 0:
            return 1130;
        } 
        throw new BrokerException("1001", "0008", "Unknown version " + str, null, null);
      } 
      throw new BrokerException("1001", "0011", "Invalid packet type in response", null, null);
    } catch (be be) {
      if (be.a() == 11) {
        i1 = 1130;
      } else if (be.a() == 12) {
        i1 = 1130;
      } else {
        throw new BrokerException("1001", bl.a(be.a()), be.i() + be.j(), null, null);
      } 
    } catch (BrokerException brokerException) {
      if (brokerException.getErrorClass() == 1001 && brokerException.getErrorCode() == 11) {
        i1 = 1130;
      } else if (brokerException.getErrorClass() == 1001 && brokerException.getErrorCode() == 12) {
        i1 = 1130;
      } else {
        throw brokerException;
      } 
    } 
    return i1;
  }
  
  public static String f() { return aa; }
  
  public static String g() { return z; }
  
  public static void b(String paramString) { z = paramString + y; }
  
  public ao a(int paramInt1, int paramInt2, String paramString) {
    ao ao1;
    try {
      ao1 = (ao)clone();
      ao1.t.k(paramInt1);
      ao1.t.l(paramInt2);
      ao1.a().put("ET", paramString);
      ao1.a().put("PT", z);
      ao1.af();
      ao1.a(ad());
      ao1.b(x);
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      ao1 = a(paramInt1, paramInt2, paramString, 1110, this.v);
    } 
    return ao1;
  }
  
  public static ao a(int paramInt1, int paramInt2, String paramString, int paramInt3) { return a(paramInt1, paramInt2, paramString, paramInt3, w); }
  
  public static ao a(int paramInt1, int paramInt2, String paramString, int paramInt3, s params) {
    ao ao1;
    switch (paramInt3) {
      case 1110:
      case 1120:
      case 1130:
      case 1140:
      case 2000:
        break;
      default:
        paramInt3 = 1110;
        break;
    } 
    Properties properties = new Properties();
    properties.put("RPCError", new Integer(paramInt1));
    properties.put("UserError", new Integer(paramInt2));
    properties.put("ET", paramString);
    properties.put("PT", z);
    try {
      ao1 = new ao(ad(), x, properties, paramInt3, params);
    } catch (be be) {
      ao1 = (ao)null;
      System.out.println("Can not create error message " + be);
    } 
    return ao1;
  }
  
  public ao a(String paramString1, String paramString2, String paramString3) {
    ao ao1;
    try {
      ao1 = (ao)clone();
      ao1.t.k(7);
      ao1.t.l(998);
      while (paramString1.length() < 4)
        paramString1 = "0" + paramString1; 
      while (paramString2.length() < 4)
        paramString2 = "0" + paramString2; 
      ao1.a().put("EC", paramString1 + paramString2);
      ao1.a().put("ET", paramString3);
      ao1.a().put("PT", z);
      ao1.a(ad());
      ao1.b(x);
      ao1.af();
      String str = paramString1 + paramString2 + " " + paramString3;
      if (str.length() > 86)
        str = str.substring(0, 86); 
      int i1 = str.length();
      if (i1 > 9) {
        str = "Y " + (i1 + 2) + i1 + str;
      } else if (i1 > 7) {
        str = "Y " + (i1 + 2) + "0" + i1 + str;
      } else {
        str = "Y 0" + (i1 + 2) + "0" + i1 + str;
      } 
      ao1.n(str);
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      ao1 = a(paramString1, paramString2, paramString3, e(), this.v);
    } 
    return ao1;
  }
  
  public static ao a(String paramString1, String paramString2, String paramString3, int paramInt) { return a(paramString1, paramString2, paramString3, paramInt, w); }
  
  public static ao a(String paramString1, String paramString2, String paramString3, int paramInt, s params) {
    ao ao1;
    switch (paramInt) {
      case 1110:
      case 1120:
      case 1130:
      case 1140:
      case 2000:
        break;
      default:
        paramInt = 1110;
        break;
    } 
    while (paramString1.length() < 4)
      paramString1 = "0" + paramString1; 
    while (paramString2.length() < 4)
      paramString2 = "0" + paramString2; 
    Properties properties = new Properties();
    properties.put("RPCError", new Integer(7));
    properties.put("UserError", new Integer(0));
    properties.put("NaturalErrorLine", paramString1);
    properties.put("NaturalErrorProgram", paramString2);
    properties.put("ET", paramString3);
    properties.put("EC", paramString1 + paramString2);
    properties.put("PT", z);
    try {
      ao1 = new ao(ad(), x, properties, paramInt, params);
    } catch (be be) {
      ao1 = (ao)null;
      System.out.println("Can not create error message " + be);
    } 
    return ao1;
  }
  
  public static long h() { return j; }
  
  public static void a(long paramLong) { j = paramLong; }
  
  public static String i() { return k; }
  
  public static void c(String paramString) { k = paramString; }
  
  public static String j() { return l; }
  
  public static void d(String paramString) { l = paramString; }
  
  public static String k() { return m; }
  
  public static void e(String paramString) { m = paramString; }
  
  public static String l() { return n; }
  
  public static void f(String paramString) { n = paramString; }
  
  public static int m() { return o; }
  
  public static void c(int paramInt) throws be { o = paramInt; }
  
  public static int n() { return p; }
  
  public static void d(int paramInt) throws be { p = paramInt; }
  
  public static boolean o() { return q; }
  
  public static void a(boolean paramBoolean) { q = paramBoolean; }
  
  public static boolean p() { return r; }
  
  public static void b(boolean paramBoolean) { r = paramBoolean; }
  
  public static String q() { return s; }
  
  public static void g(String paramString) { s = paramString; }
  
  public String r() { return (this.t != null) ? this.t.d().trim() : null; }
  
  public void h(String paramString) {
    if (this.t != null)
      this.t.a(paramString); 
  }
  
  public String s() { return (this.t != null) ? this.t.e().trim() : null; }
  
  public void i(String paramString) {
    if (this.t != null)
      this.t.b(paramString); 
  }
  
  public String t() { return (this.t != null) ? this.t.f().trim() : null; }
  
  public void j(String paramString) {
    if (this.t != null)
      this.t.c(paramString); 
  }
  
  public String u() { return (this.t != null) ? this.t.am() : null; }
  
  public void k(String paramString) {
    if (this.t != null)
      this.t.f(paramString); 
  }
  
  public int v() { return (this.t != null) ? this.t.g() : 0; }
  
  public void e(int paramInt) throws be {
    if (this.t != null)
      if (paramInt >= 1 && paramInt <= 7) {
        this.t.a(paramInt);
      } else {
        throw new be(11, "Invalid packet type");
      }  
  }
  
  public String w() { return (this.t != null) ? this.t.h() : null; }
  
  public void l(String paramString) {
    if (this.t != null)
      this.t.d(paramString); 
  }
  
  public boolean x() { return (this.t != null) ? this.t.i() : 0; }
  
  public void c(boolean paramBoolean) {
    if (this.t != null)
      this.t.a(paramBoolean); 
  }
  
  public int y() { return (this.t != null) ? this.t.j() : 0; }
  
  public void f(int paramInt) throws be {
    if (this.t != null)
      this.t.b(paramInt); 
  }
  
  public long z() { return (this.t != null) ? this.t.k() : 0L; }
  
  public void b(long paramLong) {
    if (this.t != null)
      this.t.a(paramLong); 
  }
  
  public static ao aa() { return a(w); }
  
  public static ao a(s params) {
    Properties properties = new Properties();
    properties.put("PacketType", new Integer(6));
    try {
      return new ao(null, "PING                                                ".getBytes(), properties, 1110, params);
    } catch (be be) {
      return (ao)null;
    } 
  }
  
  public String ab() { return b(w); }
  
  public String b(s params) throws be {
    String str;
    if (v() == 6) {
      if (e() >= 2000) {
        str = (String)a().get("CO");
        if (str == null)
          str = ""; 
      } else if (params == null || params.b() == null) {
        str = new String(c());
      } else {
        try {
          str = new String(c(), params.b());
        } catch (UnsupportedEncodingException unsupportedEncodingException) {
          str = new String(c());
        } 
      } 
    } else {
      throw new be(11, "Invalid packet type " + v());
    } 
    return str.toUpperCase();
  }
  
  public ao m(String paramString) { return b(paramString, w); }
  
  public ao b(String paramString, s params) {
    Properties properties = new Properties();
    properties.put("PacketType", new Integer(6));
    try {
      String str = b(params);
      if (str.length() == 50)
        paramString = paramString.substring(0, 50); 
      if (e() >= 2000) {
        properties.put("PI", paramString);
        return new ao(ac(), x, properties, e(), params);
      } 
      return new ao(ac(), paramString.getBytes(), properties, e(), params);
    } catch (be be) {
      return (ao)null;
    } 
  }
  
  public static String e(byte[] paramArrayOfByte) throws be { return c(paramArrayOfByte, w); }
  
  public static String c(byte[] paramArrayOfByte, s params) throws be {
    String str;
    try {
      ao ao1 = new ao(paramArrayOfByte, params);
      if (ao1.v() == 6) {
        try {
          str = new String(ao1.c(), params.b());
        } catch (Exception exception) {
          str = new String(ao1.c());
        } 
        if (str.charAt(0) == '.')
          str = str.substring(1); 
      } else {
        throw new BrokerException("1001", "0011", "Invalid packet type in response", null, null);
      } 
    } catch (be be) {
      throw new BrokerException("1001", bl.a(be.a()), be.i() + be.j(), null, null);
    } 
    return str;
  }
  
  public ao f(byte[] paramArrayOfByte) {
    ao ao1;
    try {
      ao1 = (ao)clone();
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      try {
        ao1 = new ao(d(), this.v);
      } catch (be be) {
        ao1 = a(7, 0, "Could not create response: " + be.toString(), 1110);
      } 
    } 
    Properties properties = ao1.a();
    properties.remove("UID");
    properties.remove("NS");
    properties.put("PT", z);
    ao1.a(properties);
    ao1.af();
    if (ao1.y() == 1)
      ao1.a(ad()); 
    ao1.b(paramArrayOfByte);
    return ao1;
  }
  
  public byte[] ac() { return new byte[] { this.v.c }; }
  
  public static byte[] ad() { return new byte[0]; }
  
  protected Object clone() throws CloneNotSupportedException {
    ao ao1 = (ao)super.clone();
    ao1.t = (bs)this.t.clone();
    return ao1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\ao.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */