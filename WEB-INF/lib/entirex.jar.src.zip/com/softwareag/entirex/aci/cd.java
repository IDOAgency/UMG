package com.softwareag.entirex.aci;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class cd implements ActionListener {
  private final Tester2 a;
  
  cd(Tester2 paramTester2) { this.a = paramTester2; }
  
  public void actionPerformed(ActionEvent paramActionEvent) { System.exit(0); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\cd.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */