package com.softwareag.entirex.aci;

class com/softwareag/entirex/aci/b8 extends Tester2.com/softwareag/entirex/aci/b9 {
  String a;
  
  boolean b;
  
  boolean c;
  
  cn d;
  
  String e;
  
  int f;
  
  private final Tester2 g;
  
  private com/softwareag/entirex/aci/b8(Tester2 paramTester2, String paramString1, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, String paramString2) {
    super(paramTester2, "", paramInt1, paramBoolean1);
    this.g = paramTester2;
    this.e = paramString1;
    this.c = paramBoolean2;
    this.b = paramBoolean1;
    this.f = paramInt2;
    this.a = paramString2;
    if (Tester2.e(paramTester2))
      b().setEditable(paramBoolean1); 
  }
  
  com/softwareag/entirex/aci/b8(Tester2 paramTester2, String paramString1, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, String paramString2, cc paramcc) { this(paramTester2, paramString1, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramString2); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\b8.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */