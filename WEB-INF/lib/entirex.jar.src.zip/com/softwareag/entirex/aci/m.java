package com.softwareag.entirex.aci;

class m extends n {
  static Class a;
  
  m(b paramb1, m paramm, b paramb2) { super(paramb1, paramm, "Attach", paramb2); }
  
  public final void run() {
    BrokerException brokerException = null;
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool = false;
    int i = 0;
    int j = 0;
    while (!this.g && this.q < this.r) {
      Broker broker = b();
      this;
      BrokerService brokerService = new BrokerService(broker, this.ab.d("entirex.server.serveraddress"));
      try {
        a(broker);
        bool1 = true;
        brokerService.registerAttach();
        a(broker, brokerService, true);
        bool2 = true;
        this;
        brokerService.setDefaultWaittime(this.ab.d("entirex.server.waitattach"));
        brokerService.setMaxReceiveLen(500);
        if (this.e) {
          System.out.println();
          this;
          System.out.println("Starting Attach Server for " + this.ab.d("entirex.server.name") + " for " + broker + "@" + brokerService);
          System.out.println();
        } 
        boolean bool3 = true;
        while (bool3) {
          try {
            BrokerAttachInfo brokerAttachInfo = brokerService.receiveAttachInfo();
            if (this.e)
              synchronized (System.out) {
                System.out.println();
                System.out.println("Starting a new server replicate");
                System.out.println("    number of running replicates = " + brokerAttachInfo.replicates);
                System.out.println("    number of missing servers = " + brokerAttachInfo.missingServers);
                System.out.println("    number of active servers = " + this.ac.w());
              }  
            int k = brokerAttachInfo.missingServers;
            if (k < 1 || k > 100) {
              if (Dump.c)
                Dump.log("Value of missing servers (" + k + ") does not seem reasonable, use 1 instead"); 
              k = 1;
            } 
            synchronized ((a == null) ? (a = class$("com.softwareag.entirex.aci.b")) : a) {
              int i1 = this.ac.w();
              int i2 = this.ac.k();
              if (i1 >= i2) {
                k = 0;
              } else if (i1 + k > i2) {
                k = i2 - i1;
              } 
              if (k > 0) {
                if (this.e)
                  synchronized (System.out) {
                    System.out.println("Starting " + k + " server(s)");
                  }  
                for (byte b = 0; b < k; b++) {
                  b b1 = this.ab.e();
                  o o = new o(b1, this, this.ac);
                  o.start();
                } 
              } else if (this.e) {
                synchronized (System.out) {
                  System.out.println("Maximum of servers reached");
                } 
              } 
            } 
          } catch (BrokerException brokerException1) {
            j = brokerException1.getErrorClass();
            i = brokerException1.getErrorCode();
            if (brokerException1.getErrorClass() != 74 || brokerException1.getErrorCode() != 74)
              if (brokerException1.getErrorClass() == 10 && brokerException1.getErrorCode() == 50) {
                bool3 = false;
              } else if (brokerException1.getErrorClass() == 10 && brokerException1.getErrorCode() == 51) {
                bool3 = false;
              } else {
                throw brokerException1;
              }  
            if (this.g)
              bool3 = false; 
            this.ab.a(brokerException1, false);
          } 
        } 
      } catch (BrokerException brokerException1) {
        j = brokerException1.getErrorClass();
        i = brokerException1.getErrorCode();
        brokerException = brokerException1;
        synchronized (System.out) {
          System.out.println(brokerException1);
        } 
        this.ab.a(brokerException1, false);
      } finally {
        if (this.e)
          synchronized (System.out) {
            System.out.println();
            this;
            System.out.println("Terminating " + this.ab.d("entirex.server.name") + " " + Thread.currentThread().getName());
          }  
        this.f = a(j, i);
        try {
          switch (j) {
            case 2:
            case 10:
              break;
            case 21:
              if (i == 18 && this.e)
                synchronized (System.out) {
                  System.out.println("Maximum number of servers reached, consider to increase NUM-SERVERS in the Broker Attribute File");
                }  
            default:
              if (brokerException != null && !(brokerException instanceof BrokerException))
                brokerException.printStackTrace(); 
              if (bool2) {
                if (j != 13 || (i != 313 && i != 315))
                  brokerService.deregister(); 
                bool2 = false;
                if (this.e)
                  synchronized (System.out) {
                    System.out.print(" deregister done ");
                  }  
                bool = true;
              } 
              if (bool1) {
                if (j != 13 || (i != 313 && i != 315))
                  broker.logoff(); 
                this.ac.v().remove(this);
                bool1 = false;
                if (this.e)
                  synchronized (System.out) {
                    System.out.println(Thread.currentThread().getName() + " logoff done, remaining servers:" + this.ac.w());
                  }  
              } 
              break;
          } 
          a(broker, brokerService, true, bool);
        } catch (Throwable throwable) {
          throwable.printStackTrace();
        } 
      } 
      if (!c() || this.g)
        break; 
    } 
  }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\m.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */