package com.softwareag.entirex.aci;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

final class v extends t {
  private static final int a = 10;
  
  private static boolean b = false;
  
  private static int c;
  
  private boolean d = false;
  
  private int e = 0;
  
  private ai f;
  
  private Socket g;
  
  private final w h;
  
  private final String i;
  
  private final int j;
  
  private final boolean k;
  
  static Class l;
  
  public v(String paramString) {
    this.h = w.a(paramString);
    this.g = null;
    this.f = null;
    this.i = this.h.b();
    this.j = this.h.a();
    this.k = this.h.c();
  }
  
  public v(Socket paramSocket) throws IOException {
    this.h = null;
    this.g = paramSocket;
    this.f = new ai(paramSocket);
    this.i = paramSocket.getInetAddress().getHostName();
    this.j = paramSocket.getPort();
    this.k = false;
  }
  
  private void p() throws ae {
    synchronized ((l == null) ? (l = class$("com.softwareag.entirex.aci.v")) : l) {
      if (b)
        return; 
      String str = null;
      try {
        str = System.getProperty("entirex.timeout", "0");
        int m = Integer.parseInt(str);
        if (m != 0 && m < 10)
          throw new NumberFormatException(); 
        c = m * 1000;
        b = true;
      } catch (NumberFormatException numberFormatException) {
        throw new ae("0317", new String[] { str });
      } catch (SecurityException securityException) {
        c = 0;
        b = true;
      } 
    } 
  }
  
  public String toString() { return this.i + ':' + this.j; }
  
  public int l() { return this.j; }
  
  public String m() { return this.i; }
  
  public ServerSocket n() throws IOException { return this.h.d(); }
  
  String f() {
    StringBuffer stringBuffer = new StringBuffer();
    if (this.g != null)
      stringBuffer.append("Connected to " + this.g.getInetAddress() + " on port " + this.g.getPort()); 
    if (this.h != null)
      stringBuffer.append(this.h.f()); 
    return (stringBuffer.length() == 0) ? "No connection info available" : stringBuffer.toString();
  }
  
  private void q() throws ae {
    if (this.d)
      return; 
    p();
    try {
      if (this.f == null) {
        this.f = this.h.e();
        this.g = this.f.a();
      } 
      this.d = true;
    } catch (UnknownHostException unknownHostException) {
      throw new ae("0314", new String[] { this.i, unknownHostException.toString() });
    } catch (NoRouteToHostException noRouteToHostException) {
      throw new ae("0318", new String[] { this.i, Integer.toString(this.j), noRouteToHostException.toString() });
    } catch (ConnectException connectException) {
      throw new ae("0315", new String[] { this.i, Integer.toString(this.j), connectException.toString() });
    } catch (ae ae) {
      throw ae;
    } catch (IOException iOException) {
      throw new ae("0311", new String[] { this.i + ':' + Integer.toString(this.j), iOException.toString() });
    } catch (SecurityException securityException) {
      throw new ae("0312", new String[] { this.i, Integer.toString(this.j), securityException.toString() });
    } 
  }
  
  protected ad c(int paramInt) throws IOException {
    q();
    return this.f.a(paramInt);
  }
  
  protected void h() throws ae { this.f.a(0).a(); }
  
  protected DataInputStream b(int paramInt) throws IOException {
    q();
    if (c != 0 && this.e != c + paramInt) {
      this.e = c + paramInt;
      this.g.setSoTimeout(this.e);
    } 
    if (Dump.c && this.e != 0)
      Dump.log("Will receive data, timeout=" + this.e + " milliseconds"); 
    return this.f.b();
  }
  
  protected void g() throws ae {}
  
  protected void i() throws ae {
    if (!this.d)
      return; 
    if (!this.k)
      return; 
    this.d = false;
    this.h.a(this.f);
    this.g = null;
    this.f = null;
  }
  
  protected void j() throws ae {
    if (!this.d)
      return; 
    if (!this.k)
      k(); 
    this.d = false;
  }
  
  protected void k() throws ae {
    this.d = false;
    if (this.f != null)
      if (this.h == null) {
        this.f.c();
      } else {
        this.h.b(this.f);
      }  
    this.f = null;
    this.g = null;
  }
  
  static int o() { return 10; }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\v.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */