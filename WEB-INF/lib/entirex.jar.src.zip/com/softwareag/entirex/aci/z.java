package com.softwareag.entirex.aci;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

final class z extends y {
  final String a;
  
  final int b;
  
  public z(String paramString, int paramInt, Properties paramProperties) {
    super(paramString, paramInt, paramProperties);
    this.a = paramString;
    this.b = paramInt;
  }
  
  public Socket b() throws IOException { return new Socket(this.a, this.b); }
  
  public ServerSocket c() throws IOException { return new ServerSocket(this.b); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\z.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */