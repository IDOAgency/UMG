package com.softwareag.entirex.aci;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TunnelServlet extends HttpServlet {
  private static final String a = (new EntireXVersion("Broker TunnelServlet")).getVersionString();
  
  private static final String b = "application/octet-stream";
  
  private static final String c = "log";
  
  private static final String d = "broker";
  
  private static final String e = "logicalbrokerid";
  
  private static final String f = "logicalsetname";
  
  private static final String g = "locationtransparencyconfig";
  
  private static final String h = "locationtransparencyini";
  
  private static final String i = "entirex.location.transparency.config";
  
  private static final String j = "entirex.location.transparency.ini";
  
  private String k = "localhost";
  
  private String l = null;
  
  private String m = null;
  
  private boolean n = false;
  
  private boolean o = false;
  
  public void init(ServletConfig paramServletConfig) throws ServletException {
    super.init(paramServletConfig);
    a(null);
  }
  
  public String getServletInfo() { return a; }
  
  public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
    a(paramHttpServletRequest);
    if (paramHttpServletRequest.getContentLength() < 1) {
      a(paramHttpServletResponse);
      return;
    } 
    if (paramHttpServletRequest.getContentType() == null || !paramHttpServletRequest.getContentType().equalsIgnoreCase("application/octet-stream")) {
      a(paramHttpServletResponse, "content type application/octet-stream expected");
      return;
    } 
    if (this.n) {
      log(a);
      log("Remote Broker = " + this.k);
      log("Remote address/host = " + paramHttpServletRequest.getRemoteAddr() + "/" + paramHttpServletRequest.getRemoteHost());
      log("User agent = " + paramHttpServletRequest.getHeader("User-Agent"));
      log("Response character encoding = " + paramHttpServletResponse.getCharacterEncoding());
    } 
    paramHttpServletResponse.setContentType("application/octet-stream");
    paramHttpServletResponse.setHeader("Remote-Broker", this.k);
    paramHttpServletResponse.setHeader("TunnelServlet-Version", a);
    int i1 = paramHttpServletRequest.getContentLength();
    d7 d7 = new d7(paramHttpServletRequest, paramHttpServletResponse, i1);
    try {
      if (i1 > 0) {
        t t = t.a(this.k);
        d7.a(t);
        t.a(d7);
      } else {
        a(d7, paramHttpServletResponse, "nothing to do content length is <1", (short)800);
      } 
    } catch (ae ae) {
      if (this.n)
        log(ae.getMessage()); 
      a(d7, paramHttpServletResponse, ae.getMessage(), (short)801);
    } catch (IOException iOException) {
      if (this.n)
        log(iOException.toString()); 
      a(d7, paramHttpServletResponse, iOException.toString(), (short)801);
    } catch (Exception exception) {
      if (this.n)
        log(exception.toString()); 
      a(d7, paramHttpServletResponse, exception.toString(), (short)802);
    } 
  }
  
  public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException { doGet(paramHttpServletRequest, paramHttpServletResponse); }
  
  private void a(HttpServletResponse paramHttpServletResponse) throws IOException, ServletException {
    if (this.n) {
      log("responding HTML Info Page");
      log("Remote Broker = " + this.k + (this.o ? " (logical broker used)" : ""));
      log("Response character encoding = " + paramHttpServletResponse.getCharacterEncoding());
      log("Logging enabled = " + (this.n ? "Yes" : "No"));
      log("Use logical broker = " + this.o);
      log("Logical broker ID = " + this.l);
      log("Logical set name = " + this.m);
      log("Location transparency configuration = " + System.getProperty("entirex.location.transparency.config"));
      log("Location transparency configuration file = " + System.getProperty("entirex.location.transparency.ini"));
    } 
    paramHttpServletResponse.setContentType("text/html");
    PrintWriter printWriter = paramHttpServletResponse.getWriter();
    printWriter.println("<html>");
    printWriter.println("<head>");
    printWriter.println("<title>" + a + " Info Page</title>");
    printWriter.println("</head>");
    printWriter.println("<body>");
    printWriter.println("<h1>" + a + "</h1>");
    printWriter.println("<br>" + (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")).format(new Date()) + "<br>");
    printWriter.println("<table>");
    printWriter.println("<tr><th>Parameter</th><th>Value</th></tr>");
    String[][] arrayOfString = { { "broker", this.k + (this.o ? " (logical broker used)" : "") }, { "log", this.n ? "Yes" : "No" }, { "logicalbrokerid", this.l }, { "logicalsetname", this.m }, { "locationtransparencyconfig", System.getProperty("entirex.location.transparency.config") }, { "locationtransparencyini", System.getProperty("entirex.location.transparency.ini") } };
    for (byte b1 = 0; b1 < arrayOfString.length; b1++)
      printWriter.println("<tr><td>" + arrayOfString[b1][0] + ":</td><td>" + arrayOfString[b1][1] + "</td></tr>"); 
    printWriter.println("</table>");
    printWriter.println("</body>");
    printWriter.println("</html>");
  }
  
  private void a(HttpServletResponse paramHttpServletResponse, String paramString) throws IOException, ServletException {
    if (this.n)
      log("responding HTML: " + paramString); 
    paramHttpServletResponse.setContentType("text/html");
    PrintWriter printWriter = paramHttpServletResponse.getWriter();
    printWriter.println("<html>");
    printWriter.println("<head>");
    printWriter.println("<title>" + a + "</title>");
    printWriter.println("</head>");
    printWriter.println("<body>");
    printWriter.println("<h1>" + a + ": " + paramString + "</h1>");
    printWriter.println("</body>");
    printWriter.println("</html>");
  }
  
  private void a(d7 paramd7, HttpServletResponse paramHttpServletResponse, String paramString, short paramShort) throws IOException {
    if (this.n)
      log("responding Error: " + paramString); 
    paramHttpServletResponse.setHeader("TunnelServlet-Error", paramString);
    ad ad = paramd7.c(0);
    af.a(ad, paramShort);
    paramd7.h();
    paramd7.k();
  }
  
  private void a(HttpServletRequest paramHttpServletRequest) {
    String str1 = null;
    String str2 = null;
    if (paramHttpServletRequest == null) {
      String str = getInitParameter("broker");
      if (str != null && str.length() > 0)
        this.k = str; 
      str = getInitParameter("log");
      if (str != null)
        this.n = Dump.b(str); 
      str = getInitParameter("logicalbrokerid");
      if (str != null && str.length() > 0)
        str1 = str; 
      str = getInitParameter("logicalsetname");
      if (str != null && str.length() > 0)
        str2 = str; 
      str = getInitParameter("locationtransparencyconfig");
      if (str != null && str.length() > 0 && !System.getProperties().containsKey("entirex.location.transparency.config"))
        System.getProperties().put("entirex.location.transparency.config", str); 
      str = getInitParameter("locationtransparencyini");
      if (str != null && str.length() > 0 && !System.getProperties().containsKey("entirex.location.transparency.ini")) {
        if (str.startsWith("/") && getServletContext().getRealPath("/") != null)
          str = getServletContext().getRealPath("/") + str.substring(1); 
        System.getProperties().put("entirex.location.transparency.ini", str);
      } 
    } else {
      String str = paramHttpServletRequest.getParameter("broker");
      if (str != null)
        this.k = str; 
      str = paramHttpServletRequest.getParameter("log");
      if (str != null)
        this.n = Dump.b(str); 
      str = paramHttpServletRequest.getParameter("logicalbrokerid");
      if (str != null && str.length() > 0)
        str1 = str; 
      str = paramHttpServletRequest.getParameter("logicalsetname");
      if (str != null && str.length() > 0)
        str2 = str; 
      str = paramHttpServletRequest.getParameter("locationtransparencyconfig");
      if (str != null && str.length() > 0 && !System.getProperties().containsKey("entirex.location.transparency.config"))
        System.getProperties().put("entirex.location.transparency.config", str); 
      str = paramHttpServletRequest.getParameter("locationtransparencyini");
      if (str != null && str.length() > 0 && !System.getProperties().containsKey("entirex.location.transparency.ini")) {
        if (str.startsWith("/") && getServletContext().getRealPath("/") != null)
          str = getServletContext().getRealPath("/") + str.substring(1); 
        System.getProperties().put("entirex.location.transparency.ini", str);
      } 
    } 
    try {
      if (str1 != null) {
        Broker broker = LocationTransparencyService.lookupBroker(str1, str2);
        this.k = broker.getBrokerID();
        this.o = true;
        this.l = str1;
        this.m = str2;
      } 
    } catch (BrokerException brokerException) {
      log("Location transparency configuration error: ", brokerException);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\TunnelServlet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */