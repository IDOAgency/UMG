package com.softwareag.entirex.aci;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

final class d7 extends t {
  private ad a;
  
  private DataInputStream b;
  
  private int c;
  
  private boolean d = false;
  
  private HttpServletRequest e;
  
  private HttpServletResponse f;
  
  d7(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, int paramInt) {
    this.e = paramHttpServletRequest;
    this.f = paramHttpServletResponse;
    this.c = paramInt;
  }
  
  public String toString() { return getClass().getName(); }
  
  protected void a(int paramInt) throws ae {
    if (this.c != paramInt)
      throw new ae("0320", new String[] { "wrong Content-Length= (" + Integer.toString(this.c) + " instead of " + Integer.toString(paramInt) }); 
  }
  
  protected DataInputStream b(int paramInt) throws IOException {
    this.b = new DataInputStream(new BufferedInputStream(this.e.getInputStream(), 4096));
    return this.b;
  }
  
  protected ad c(int paramInt) throws IOException {
    if (paramInt != 0)
      this.f.setIntHeader("Content-Length", paramInt); 
    this.a = new ad(this.f.getOutputStream(), paramInt);
    return this.a;
  }
  
  protected void h() throws IOException {
    this.a.a();
    this.a.b();
    this.a = null;
  }
  
  protected void g() throws IOException {
    this.b.close();
    this.b = null;
  }
  
  protected void i() throws IOException { k(); }
  
  protected void j() throws IOException { k(); }
  
  protected void k() throws IOException {
    try {
      if (this.b != null)
        this.b.close(); 
      if (this.a != null)
        this.a.b(); 
    } catch (IOException iOException) {}
    this.b = null;
    this.a = null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\d7.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */