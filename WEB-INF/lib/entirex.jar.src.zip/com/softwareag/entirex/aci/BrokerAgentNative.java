package com.softwareag.entirex.aci;

final class BrokerAgentNative {
  static native int callBroker(byte[] paramArrayOfByte);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\BrokerAgentNative.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */