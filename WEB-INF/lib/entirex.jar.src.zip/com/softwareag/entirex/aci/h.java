package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.Command;
import com.softwareag.entirex.base.CommandLine;
import com.softwareag.entirex.base.i;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class h extends CommandLine {
  private static final String a = "no";
  
  private static final String b = "";
  
  private static final String c = "DefaultSet";
  
  private static final String d = "";
  
  private static final String e = "";
  
  private static final String f = "localhost";
  
  private static final String g = "ACLASS/ASERVER/ASERVICE";
  
  private static final String h = "JavaServer";
  
  private static final String i = "";
  
  private static final String j = "yes";
  
  private static final String k = "600S";
  
  private static final String l = "300S";
  
  private static final String m = "";
  
  private static final String n = Integer.toString(0);
  
  private static final String o = Integer.toString(0);
  
  static final String p = "15";
  
  private static final String q = "32";
  
  static final String r = "1";
  
  private static final String s = "no";
  
  private static final String t = "no";
  
  private static final String u = "";
  
  private static final String v = "";
  
  private static final String w = "0";
  
  private static final String x = "0";
  
  static final String y = "";
  
  private static final String z = "0";
  
  private static final String aa = "no";
  
  static final String ab = "entirex.server.properties";
  
  static final String ac = (new EntireXVersion("Java Server")).getVersionString();
  
  protected void init() {
    super.init();
    add(new Command("-broker", "-b", "entirex.server.brokerid", 1, 0, "localhost", "the ID of the broker,"));
    add(new Command("-class", null, null, 1, 1, null, "the class as in '<class>/<server>/<service>',"));
    add(new Command("-server", "-s", "entirex.server.serveraddress", 1, 2, "ACLASS/ASERVER/ASERVICE", "the server address as 'RPC/<server address>/CALLNAT' or <server address> with class and service,"));
    add(new Command("-service", null, null, 1, 3, null, "the service as in '<class>/<server>/<service>',"));
    add(new Command("-logicalsetname", null, "entirex.server.logicalsetname", 1, -1, "DefaultSet", "the set name for logical names,"));
    add(new Command("-logicalbrokerid", null, "entirex.server.logicalbrokerid", 1, -1, "", "the logical name for the broker,"));
    add(new Command("-logicalservice", null, "entirex.server.logicalservice", 1, -1, "", "the logical name for the service,"));
    add(new Command("-user", null, "entirex.server.userid", 1, -1, "JavaServer", "the user ID for the broker,"));
    add(new Command("-password", null, "entirex.server.password", 1, -1, "", "the password for the broker,"));
    add(new Command("-compresslevel", null, "entirex.server.compresslevel", 1, -1, o, "the compression level, values 0 .. 9,"));
    add(new Command("-security", null, "entirex.server.security", 1, -1, "", "the security setting, values no, yes, auto, <name of BrokerSecurity object>,"));
    add(new Command("-encryption", null, "entirex.server.encryptionlevel", 2, -1, n, "the encryption level, values 0,1,2,"));
    add(new Command("-propertyfile", "-p", "entirex.server.properties", 1, -1, "entirex.server.properties", "the file name of the property file (default is 'entirex.server.properties'),"));
    add(new Command("-serverlog", null, "entirex.server.serverlog", 1, -1, "", "the file name of the startup / shutdown log (only for Windows Services),"));
    add(new Command("-restartcycles", null, "entirex.server.restartcycles", 2, -1, "15", "the number of restart attempts if the broker is not available,"));
    add(new Command("-smhport", null, "entirex.server.monitorport", 2, -1, "0", "the port number for monitoring by SMH,"));
    add(new Command("-trace", null, "entirex.trace", 1, -1, "0", "the trace level, values 0,1,2."));
    add(new Command("-verbose", null, "entirex.server.verbose", 3, -1, "no", "if set, more information in trace,"));
    add(new Command("-codepage", null, "entirex.server.codepage", 1, -1, "", "the code page the server uses for the messages"));
    add(new Command("-logfile", null, "entirex.server.logfile", 1, -1, "", "the file the server uses for trace output"));
  }
  
  public h(Properties paramProperties) { super(paramProperties, true); }
  
  public void a() {
    Properties properties = c();
    properties.put("entirex.server.encryption", "");
    properties.put("entirex.server.usecodepage", "no");
    properties.put("entirex.server.waitattach", "600S");
    properties.put("entirex.server.waitserver", "300S");
    properties.put("entirex.server.maxservers", "32");
    properties.put("entirex.server.minservers", "1");
    properties.put("entirex.server.name", ac);
    properties.put("entirex.server.fixedservers", "no");
    properties.put("entirex.server.environment", "");
    properties.put("entirex.server.passwordencrypt", "yes");
    properties.put("entirex.timeout", "0");
    properties.put("entirex.server.monitorremote", "no");
    properties.put("entirex.location.transparency.ini", "");
    properties.put("entirex.location.transparency.config", "");
    importSystemProperties();
  }
  
  final String b() {
    String str = getProperties().getProperty("entirex.server.properties");
    try {
      FileInputStream fileInputStream = new FileInputStream(str);
      Properties properties = new Properties();
      properties.load(fileInputStream);
      fileInputStream.close();
      String str1 = properties.getProperty("entirex.server.passwordencrypt");
      boolean bool = (str1 == null || Dump.b(str1)) ? 1 : 0;
      if (bool && Dump.b(getProperties().getProperty("entirex.server.passwordencrypt")))
        i.a(str, properties); 
      a(properties);
    } catch (IOException iOException) {
      if (!str.equals("entirex.server.properties")) {
        System.err.println("Property file " + str + " not found");
        str = null;
      } 
    } 
    importPluginProperties();
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\h.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */