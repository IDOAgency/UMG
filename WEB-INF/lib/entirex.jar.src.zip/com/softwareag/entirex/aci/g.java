package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.Command;
import java.util.Properties;

class com/softwareag/entirex/aci/g extends h {
  private final RPCServer a;
  
  com/softwareag/entirex/aci/g(RPCServer paramRPCServer) {
    super(new Properties());
    this.a = paramRPCServer;
  }
  
  protected void init() {
    super.init();
    add(new Command("-server", "-s", "entirex.server.serveraddress", 1, 2, "RPC/SRV1/CALLNAT", "the server address as 'RPC/<server address>/CALLNAT' or <server address> with class and service,"));
  }
  
  public void a() {
    super.a();
    Properties properties = c();
    properties.put("entirex.server.name", (new EntireXVersion("Java RPC Server")).getVersionString());
    this.a.f((new EntireXVersion("Java RPC Server")).getVersionString());
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\g.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */