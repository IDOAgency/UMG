package com.softwareag.entirex.aci;

import java.io.IOException;

final class ae extends IOException {
  private String[] a;
  
  private String b;
  
  ae(String paramString, String[] paramArrayOfString) {
    this.b = paramString;
    this.a = paramArrayOfString;
  }
  
  String[] a() { return this.a; }
  
  String b() { return this.b; }
  
  public String getMessage() {
    try {
      BrokerException.a(this.b, this.a);
    } catch (BrokerException brokerException) {
      return brokerException.getMessage();
    } 
    return null;
  }
  
  public String toString() {
    try {
      BrokerException.a(this.b, this.a);
    } catch (BrokerException brokerException) {
      return brokerException.toString();
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\ae.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */