package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.s;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

abstract class br implements bs {
  private byte[] a = null;
  
  private byte[] b = null;
  
  private byte[] c = null;
  
  private byte[] d = null;
  
  protected Properties e = null;
  
  protected int f = 0;
  
  protected int g = 0;
  
  protected String h = null;
  
  protected long i = 0L;
  
  protected int j = 0;
  
  protected String k = null;
  
  protected String l = null;
  
  protected boolean m = false;
  
  protected String n = null;
  
  protected s o = s.a();
  
  private int p = c();
  
  private int q = b();
  
  private int r = ad();
  
  private int s = 0;
  
  private int t = 0;
  
  private int u = 0;
  
  private int v = 0;
  
  private int w = 0;
  
  public br(ao paramao, s params) {
    this.h = ao.i();
    this.i = ao.h();
    this.j = ao.m();
    this.k = ao.l();
    this.l = ao.j();
    this.n = ao.k();
    this.o = params;
  }
  
  public br(byte[] paramArrayOfByte, s params) throws be {
    this.o = params;
    g(paramArrayOfByte);
    if (paramArrayOfByte.length < b())
      throw new be(7, 0, "incorrect buffer length " + paramArrayOfByte.length); 
  }
  
  public byte[] u() { return this.d; }
  
  public void a(byte[] paramArrayOfByte) { this.d = paramArrayOfByte; }
  
  public byte[] v() { return this.a; }
  
  protected void b(byte[] paramArrayOfByte) {
    this.a = paramArrayOfByte;
    if (this.a != null) {
      this.s = this.a.length;
    } else {
      this.s = 0;
    } 
  }
  
  public void c(byte[] paramArrayOfByte) {
    byte[] arrayOfByte;
    switch (g()) {
      case 1:
      case 2:
      case 5:
        if (paramArrayOfByte == null) {
          paramArrayOfByte = new byte[1];
          paramArrayOfByte[0] = this.o.c;
        } 
        arrayOfByte = new byte[this.d.length + paramArrayOfByte.length - this.s];
        System.arraycopy(this.d, 0, arrayOfByte, 0, this.r);
        System.arraycopy(paramArrayOfByte, 0, arrayOfByte, this.r, paramArrayOfByte.length);
        System.arraycopy(this.d, this.r + this.s, arrayOfByte, this.r + paramArrayOfByte.length, this.d.length - this.r - this.s);
        g(arrayOfByte);
        b(paramArrayOfByte);
        i(this.r + paramArrayOfByte.length);
        s();
        break;
    } 
  }
  
  public boolean w() { return (this.a != null); }
  
  public byte[] x() { return this.b; }
  
  public void d(byte[] paramArrayOfByte) {
    this.b = paramArrayOfByte;
    this.u = paramArrayOfByte.length;
  }
  
  protected abstract int m();
  
  public void a(Properties paramProperties) { this.e = paramProperties; }
  
  public Properties y() throws be {
    if (this.e == null) {
      String str1 = null;
      String str2 = null;
      byte b1 = 0;
      byte b2 = 0;
      this.e = new Properties();
      if (this.b != null) {
        byte b3 = 0;
        byte b4 = 0;
        while (b3 < this.b.length) {
          if (this.b[b3] == this.o.d)
            try {
              str1 = new String(this.b, b4, b3 - b4);
              b1 = 0;
              b2 = 0;
              for (byte b5 = b3 + 1; b5 < this.b.length; b5++) {
                if (this.b[b5] == this.o.e) {
                  b2 = b5 - b3 - 1;
                  break;
                } 
                b1 = b1 * 10 + this.b[b5] - this.o.j;
              } 
              b4 = b3 + b1 + b2 + 2;
              str2 = new String(this.b, b3 + b2 + 2, b1);
              this.e.put(str1, str2);
              b3 = b4;
            } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
              throw new be(26, str2);
            }  
          b3++;
        } 
      } 
    } 
    return this.e;
  }
  
  protected abstract int n();
  
  protected abstract int o();
  
  protected abstract int p();
  
  protected abstract int q();
  
  public byte[] z() { return this.c; }
  
  protected void e(byte[] paramArrayOfByte) {
    this.c = paramArrayOfByte;
    if (paramArrayOfByte != null) {
      this.w = paramArrayOfByte.length;
    } else {
      this.w = 0;
    } 
  }
  
  public void f(byte[] paramArrayOfByte) {
    byte[] arrayOfByte;
    switch (g()) {
      case 1:
      case 2:
      case 5:
        if (paramArrayOfByte == null)
          paramArrayOfByte = new byte[0]; 
        arrayOfByte = new byte[this.d.length + paramArrayOfByte.length - this.w];
        System.arraycopy(this.d, 0, arrayOfByte, 0, this.v);
        System.arraycopy(paramArrayOfByte, 0, arrayOfByte, this.v, paramArrayOfByte.length);
        System.arraycopy(this.d, this.v + this.w, arrayOfByte, this.v + paramArrayOfByte.length, this.d.length - this.v - this.w);
        g(arrayOfByte);
        e(paramArrayOfByte);
        s();
        break;
    } 
  }
  
  public boolean aa() { return (this.c != null); }
  
  protected abstract int a();
  
  protected abstract int b();
  
  protected abstract int c();
  
  protected int ab() { return this.p; }
  
  protected void c(int paramInt) { this.p = paramInt; }
  
  protected int ac() { return this.q; }
  
  protected void d(int paramInt) { this.q = paramInt; }
  
  protected int ad() { return this.r; }
  
  protected void e(int paramInt) { this.r = paramInt; }
  
  protected int ae() { return this.s; }
  
  protected void f(int paramInt) { this.s = paramInt; }
  
  protected int af() { return this.t; }
  
  protected void g(int paramInt) { this.t = paramInt; }
  
  protected int ag() { return this.u; }
  
  protected void h(int paramInt) { this.u = paramInt; }
  
  protected int ah() { return this.v; }
  
  protected void i(int paramInt) { this.v = paramInt; }
  
  protected int ai() { return this.w; }
  
  protected void j(int paramInt) { this.w = paramInt; }
  
  public byte[] aj() { return this.d; }
  
  public void g(byte[] paramArrayOfByte) { this.d = paramArrayOfByte; }
  
  public int ak() { return this.f; }
  
  public void k(int paramInt) {
    this.f = paramInt;
    a(paramInt, aj(), n(), o());
  }
  
  public int al() { return this.g; }
  
  public void l(int paramInt) {
    this.g = paramInt;
    a(paramInt, aj(), p(), q());
  }
  
  public String am() { return this.k; }
  
  public void f(String paramString) { this.k = paramString; }
  
  protected void a(String paramString, int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3) {
    if (paramString != null && paramArrayOfByte != null)
      try {
        if (paramString.length() - paramInt1 > paramInt3) {
          if (this.o == null || this.o.b() == null) {
            System.arraycopy(paramString.substring(paramInt1, paramInt1 + paramInt3).getBytes(), 0, paramArrayOfByte, paramInt2, paramInt3);
          } else {
            System.arraycopy(paramString.substring(paramInt1, paramInt1 + paramInt3).getBytes(this.o.b()), 0, paramArrayOfByte, paramInt2, paramInt3);
          } 
        } else {
          if (this.o == null || this.o.b() == null) {
            System.arraycopy(paramString.getBytes(), paramInt1, paramArrayOfByte, paramInt2, paramString.length() - paramInt1);
          } else {
            System.arraycopy(paramString.getBytes(this.o.b()), paramInt1, paramArrayOfByte, paramInt2, paramString.length() - paramInt1);
          } 
          for (int i1 = paramInt2 + paramString.length() - paramInt1; i1 < paramInt2 + paramInt3; i1++)
            paramArrayOfByte[i1] = this.o.g; 
        } 
      } catch (UnsupportedEncodingException unsupportedEncodingException) {} 
  }
  
  protected void a(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, int paramInt3) {
    if (paramArrayOfByte1 != null && paramArrayOfByte2 != null)
      if (paramArrayOfByte1.length - paramInt1 > paramInt3) {
        System.arraycopy(paramArrayOfByte1, 0, paramArrayOfByte2, paramInt2, paramInt3);
      } else {
        System.arraycopy(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2, paramArrayOfByte1.length - paramInt1);
        for (int i1 = paramInt2 + paramArrayOfByte1.length - paramInt1; i1 < paramInt2 + paramInt3; i1++)
          paramArrayOfByte2[i1] = this.o.g; 
      }  
  }
  
  protected void a(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    if (paramArrayOfByte != null) {
      String str = Long.toString(paramLong);
      try {
        if (str.length() > paramInt2) {
          if (this.o == null || this.o.b() == null) {
            System.arraycopy(str.substring(str.length() - paramInt2).getBytes(), 0, paramArrayOfByte, paramInt1, paramInt2);
          } else {
            System.arraycopy(str.substring(str.length() - paramInt2).getBytes(this.o.b()), 0, paramArrayOfByte, paramInt1, paramInt2);
          } 
        } else {
          if (this.o == null || this.o.b() == null) {
            System.arraycopy(str.getBytes(), 0, paramArrayOfByte, paramInt1 + paramInt2 - str.length(), str.length());
          } else {
            System.arraycopy(str.getBytes(this.o.b()), 0, paramArrayOfByte, paramInt1 + paramInt2 - str.length(), str.length());
          } 
          for (int i1 = paramInt1; i1 < paramInt1 + paramInt2 - str.length(); i1++)
            paramArrayOfByte[i1] = this.o.j; 
        } 
      } catch (UnsupportedEncodingException unsupportedEncodingException) {}
    } 
  }
  
  protected boolean a(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2) {
    boolean bool = true;
    if (paramInt + m() <= paramArrayOfByte1.length) {
      for (int i1 = 0; i1 < m() && bool == true; i1++)
        bool = (paramArrayOfByte1[paramInt + i1] == paramArrayOfByte2[i1]); 
    } else {
      bool = false;
    } 
    return bool;
  }
  
  protected byte[] a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2) {
    byte[] arrayOfByte = new byte[paramArrayOfByte1.length + paramArrayOfByte2.length];
    System.arraycopy(paramArrayOfByte1, 0, arrayOfByte, 0, paramArrayOfByte1.length);
    System.arraycopy(paramArrayOfByte2, 0, arrayOfByte, paramArrayOfByte1.length, paramArrayOfByte2.length);
    return arrayOfByte;
  }
  
  protected byte[] a(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    byte[] arrayOfByte = new byte[paramArrayOfByte.length - paramInt2];
    System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, paramInt1);
    System.arraycopy(paramArrayOfByte, paramInt1 + paramInt2, arrayOfByte, paramInt1, paramArrayOfByte.length - paramInt1 - paramInt2);
    return arrayOfByte;
  }
  
  protected abstract String r();
  
  protected abstract void s();
  
  public Object clone() throws CloneNotSupportedException {
    br br1 = (br)super.clone();
    if (this.e != null) {
      br1.e = (Properties)this.e.clone();
    } else {
      br1.e = new Properties();
    } 
    if (this.a != null)
      br1.a = (byte[])this.a.clone(); 
    if (this.b != null)
      br1.b = (byte[])this.b.clone(); 
    if (this.c != null)
      br1.c = (byte[])this.c.clone(); 
    if (this.d != null)
      br1.d = (byte[])this.d.clone(); 
    return br1;
  }
  
  public abstract void e(String paramString);
  
  public abstract void a(String paramString1, String paramString2);
  
  public abstract void t();
  
  public abstract void a(long paramLong);
  
  public abstract long k();
  
  public abstract void b(boolean paramBoolean);
  
  public abstract void b(int paramInt);
  
  public abstract int j();
  
  public abstract void a(boolean paramBoolean);
  
  public abstract boolean i();
  
  public abstract void d(String paramString);
  
  public abstract String h();
  
  public abstract void a(int paramInt);
  
  public abstract int g();
  
  public abstract void c(String paramString);
  
  public abstract String f();
  
  public abstract void b(String paramString);
  
  public abstract String e();
  
  public abstract void a(String paramString);
  
  public abstract String d();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\br.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */