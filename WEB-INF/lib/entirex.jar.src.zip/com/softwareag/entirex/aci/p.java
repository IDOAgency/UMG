package com.softwareag.entirex.aci;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.text.SimpleDateFormat;
import java.util.Date;

public final class p implements Runnable {
  private static final String a = (new EntireXVersion("BrokerAgent")).getVersionString();
  
  private static final int b = 13;
  
  private static final int c = 708920131;
  
  static final int d = 30000;
  
  private static ThreadGroup g = new ThreadGroup("BrokerAgent Worker Threads");
  
  private static String h;
  
  private static boolean i;
  
  private String j;
  
  private DataInputStream k;
  
  private t l;
  
  private t m;
  
  private ah n;
  
  private boolean o = false;
  
  public static void a(boolean paramBoolean, String paramString1, String paramString2, String paramString3) {
    e = paramBoolean;
    try {
      i = false;
      if (paramString2.endsWith("/2")) {
        i = true;
        paramString2 = paramString2.substring(0, paramString2.length() - 2);
      } else if (paramString2.endsWith("/3")) {
        i = true;
        System.out.println("API version 3 not supported, will use API version 2 instead");
        paramString2 = paramString2.substring(0, paramString2.length() - 2);
      } else {
        int i4 = paramString2.indexOf(':');
        if (i4 == -1) {
          for (i4 = 0; i4 < paramString2.length(); i4++) {
            if (Character.isDigit(paramString2.charAt(i4))) {
              i = true;
              break;
            } 
          } 
        } else if (paramString2.endsWith("::NET") || paramString2.endsWith("::net")) {
          i = true;
        } 
      } 
      char c1 = '';
      int i1 = (new Integer(System.getProperty("entirex.brokeragent.restartcycles", "15"))).intValue();
      Broker broker = new Broker(paramString2, System.getProperty("user.name", "BrokerAgentUser"));
      byte b1 = 0;
      while (b1 < i1) {
        try {
          broker.b();
          break;
        } catch (BrokerException brokerException) {
          System.out.println(Thread.currentThread().getName() + " Waiting for next attempt (" + ++b1 + " of " + i1 + ") to start.");
          try {
            Thread.sleep(c1);
          } catch (InterruptedException interruptedException) {}
        } 
      } 
      if (b1 == i1) {
        System.out.println("BrokerAgent: Broker '" + paramString2 + "' not active. Check configuration.");
        return;
      } 
      if (paramString3 != null && paramString3.length() > 0)
        synchronized (g) {
          Thread thread = new Thread(new ag(paramString3));
          thread.start();
        }  
      h = paramString2;
      try {
        int i4 = paramString1.indexOf("?");
        if (i4 >= 0) {
          int i5 = Integer.parseInt(paramString1.substring(0, i4));
        } else {
          int i5 = Integer.parseInt(paramString1);
        } 
        paramString1 = ":" + paramString1;
      } catch (NumberFormatException numberFormatException) {}
      int i2 = paramString1.toLowerCase().indexOf("poolsize");
      if (i2 < 0) {
        int i4 = paramString1.indexOf("?");
        String str = (i4 >= 0) ? "&" : "?";
        paramString1 = paramString1 + str + "poolsize=0";
      } 
      v v = new v(paramString1);
      ServerSocket serverSocket = v.n();
      serverSocket.setSoTimeout(30000);
      System.out.println(a + ", running on port " + serverSocket.getLocalPort());
      int i3 = Integer.parseInt(System.getProperty("entirex.timeout", "0"));
      if (i3 != 0 && i3 < v.o()) {
        System.getProperties().put("entirex.timeout", Integer.toString(v.o()));
        System.out.println("entirex.timeout was to small, set to minmal value of " + v.o() + " seconds.");
      } 
      if (i)
        ah.a(h); 
      do {
        try {
          Socket socket = serverSocket.accept();
          v v1 = new v(socket);
          InetAddress inetAddress = socket.getInetAddress();
          String str = inetAddress.getHostName() + '[' + socket.getPort() + ']';
          synchronized (g) {
            Thread thread = new Thread(g, new p(v1, false), str);
            System.out.println();
            System.out.println("New Client Connection accepted from " + str);
            thread.start();
          } 
        } catch (InterruptedIOException interruptedIOException) {}
      } while (!f);
      serverSocket.close();
      System.out.println("...BrokerAgent stopped serving, waiting for threads to finish...");
    } catch (ae ae) {
      System.out.println("BrokerAgent Error: " + ae.getMessage());
    } catch (IOException iOException) {
      System.out.println("BrokerAgent Error: " + iOException.toString());
    } 
  }
  
  p(t paramt, boolean paramBoolean) throws IOException {
    this.l = paramt;
    this.o = paramBoolean;
    if (!i && !paramBoolean)
      this.m = t.a(h); 
  }
  
  public final void run() {
    this.j = Thread.currentThread().getName();
    boolean bool = true;
    if (i)
      this.n = new ah(); 
    try {
      this.k = this.l.b(0);
      while (true) {
        try {
          i1 = this.k.readInt();
        } catch (SocketException socketException) {
          System.out.println("...Client " + this.j + " has probably terminated normally...");
          return;
        } catch (EOFException eOFException) {
          System.out.println("...Client " + this.j + " has probably terminated normally...");
          return;
        } 
        if (i1 < 13)
          throw new IOException("Length of Request (" + i1 + ") does not have minimum length"); 
        int i2 = this.k.readInt();
        if (i2 != 1161970502 && i2 != 708920131) {
          System.out.println("...Client " + this.j + " : illegal Request Type 0x" + Integer.toHexString(i2) + ", length 0x" + Integer.toHexString(i1) + ", no response send.");
          return;
        } 
        byte[] arrayOfByte = new byte[i1 - 4];
        q.a(arrayOfByte, 0, i2);
        this.k.readFully(arrayOfByte, 4, i1 - 8);
        if (e)
          a(arrayOfByte, "Received from"); 
        switch (i2) {
          case 1161970502:
            if (f) {
              a((short)900, true, "terminated due to shutdown request...");
              return;
            } 
            if (i) {
              arrayOfByte = this.n.a(arrayOfByte);
              break;
            } 
            if (this.o) {
              a((short)904, bool, ": request illegal on port for commands");
              return;
            } 
            try {
              arrayOfByte = a(arrayOfByte);
            } catch (ae ae) {
              a((short)901, true, "terminated due to EntireX Broker problem: " + ae.getMessage());
              return;
            } catch (IOException iOException) {
              a((short)901, true, "terminated due to EntireX Broker problem: " + iOException.toString());
            } 
            break;
          case 708920131:
            bool = false;
            arrayOfByte = b(arrayOfByte);
            break;
          default:
            a((short)904, bool, ": illegal Request Type " + i2);
            return;
        } 
        if (e)
          a(arrayOfByte, "Reply from Broker for"); 
        int i1 = arrayOfByte.length + 4;
        ad ad = this.l.c(i1);
        ad.b(i1);
        ad.a(arrayOfByte, 0, arrayOfByte.length);
        this.l.h();
      } 
    } catch (IllegalAccessError illegalAccessError) {
      a((short)904, bool, ": illegal Request Type");
    } catch (ae ae) {
      a((short)903, bool, "terminated abnormally...\n...Reason: " + ae.getMessage());
    } catch (InterruptedIOException interruptedIOException) {
      a((short)903, bool, "terminated abnormally...\n...Reason: " + interruptedIOException.toString());
    } catch (IOException iOException) {
      a((short)903, bool, "terminated abnormally...\n...Reason: " + iOException.toString());
    } finally {
      this.l.k();
    } 
  }
  
  private final void a(byte[] paramArrayOfByte, String paramString) {
    synchronized (System.out) {
      a(paramString + " Client " + this.j, paramArrayOfByte);
      System.out.println();
      System.out.println();
    } 
  }
  
  private byte[] a(byte[] paramArrayOfByte) throws IOException {
    int i1 = paramArrayOfByte.length + 4;
    ad ad = this.m.c(i1);
    ad.b(i1);
    ad.a(paramArrayOfByte, 0, i1 - 4);
    this.m.h();
    DataInputStream dataInputStream = this.m.b(0);
    i1 = this.m.a(dataInputStream);
    this.m.a(i1);
    byte[] arrayOfByte = new byte[i1 - 4];
    dataInputStream.readFully(arrayOfByte, 4, i1 - 8);
    q.a(arrayOfByte, 0, 1161970502);
    this.m.i();
    return arrayOfByte;
  }
  
  private void a(short paramShort, boolean paramBoolean, String paramString) {
    System.out.println("...Client " + this.j + " " + paramString);
    a(this.l, paramShort, paramBoolean);
  }
  
  private static void a(t paramt, short paramShort, boolean paramBoolean) {
    try {
      ad ad = paramt.c(0);
      if (paramBoolean) {
        af.a(ad, paramShort);
      } else {
        byte[] arrayOfByte;
        if (paramShort == 900) {
          arrayOfByte = a("BrokerAgent request rejected due to shutdown");
        } else {
          arrayOfByte = a("BrokerAgent request rejected due to error " + paramShort);
        } 
        ad.b(arrayOfByte.length + 4);
        ad.a(arrayOfByte, 0, arrayOfByte.length);
      } 
      paramt.h();
      paramt.k();
    } catch (ae ae) {
      System.out.println("...writeBackError (might be ignored): " + ae.getMessage());
    } catch (IOException iOException) {
      System.out.println("...writeBackError (might be ignored): " + iOException.toString());
    } 
  }
  
  private static byte[] a(String paramString) throws IOException {
    try {
      return paramString.getBytes("utf-8");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      System.out.println(unsupportedEncodingException.getMessage() + " - using default encoding");
      return paramString.getBytes();
    } catch (IllegalArgumentException illegalArgumentException) {
      System.out.println(illegalArgumentException.getMessage() + " - using default encoding");
      return paramString.getBytes();
    } 
  }
  
  private byte[] b(byte[] paramArrayOfByte) throws IOException {
    String str = new String(paramArrayOfByte, 4, 5, "ASCII");
    if (str.equals("*ON**")) {
      e = true;
      System.out.println("TraceOn is set");
      return a("BrokerAgent reported: Trace is ON");
    } 
    if (str.equals("*OFF*")) {
      e = false;
      System.out.println("TraceOff is set");
      return a("BrokerAgent reported: Trace is OFF");
    } 
    if (str.equals("*IDLE") || str.equals("*KILL")) {
      f = true;
      ag.a(true);
      System.out.println("Shutdown requested: No new clients will be served");
      synchronized (g) {
        int i1 = g.activeCount();
        if (!this.o)
          i1--; 
        if (i1 == 0)
          return a("BrokerAgent terminated as requested"); 
        if (i1 == 1)
          return a("BrokerAgent will terminate after last client leaves..."); 
        return a("BrokerAgent will terminate after " + i1 + " clients leave...");
      } 
    } 
    if (str.equals("*MESS")) {
      System.out.println("Message received:'");
      System.out.println(new String(paramArrayOfByte, 9, paramArrayOfByte.length - 9, "ASCII") + "'");
      return a("BrokerAgent received message");
    } 
    if (str.equals("*STAT")) {
      StringBuffer stringBuffer = new StringBuffer("BrokerAgent reported: ");
      synchronized (g) {
        int i1 = g.activeCount();
        if (!this.o)
          i1--; 
        String str1 = null;
        if (i1 > 1) {
          str1 = i1 + " Clients are pending";
        } else if (i1 == 1) {
          str1 = "1 Client is pending";
        } else {
          str1 = "BrokerAgent is idle";
        } 
        stringBuffer.append(str1);
        System.out.print("Report sent: " + str1);
        Thread[] arrayOfThread = new Thread[i1];
        int i2 = g.enumerate(arrayOfThread);
        for (i1 = 0; i1 < i2; i1++)
          System.out.println("Active Client: " + arrayOfThread[i1].getName()); 
      } 
      return a(stringBuffer.toString());
    } 
    System.out.println("BrokerAgent reported: Unknown command");
    return a("BrokerAgent reported: Unknown command");
  }
  
  private static void a(String paramString, byte[] paramArrayOfByte) {
    if (paramArrayOfByte != null) {
      byte b1 = 0;
      byte b2 = 0;
      int i1 = paramArrayOfByte.length;
      System.out.println(" ");
      char[] arrayOfChar1 = new char[16];
      char[] arrayOfChar2 = new char[36];
      byte b3;
      for (b3 = 0; b3 < 16; b3++) {
        arrayOfChar1[b3] = ' ';
        arrayOfChar2[b3] = ' ';
      } 
      while (b3 < 36)
        arrayOfChar2[b3++] = ' '; 
      System.out.println(a());
      System.out.println("Dump of '" + paramString + "' (length = " + i1 + "):");
      System.out.println("Addr.| in Hex.                             | in Text");
      System.out.println();
      System.out.println("-----+-------------------------------------+-----------------");
      for (b3 = 0; b3 < i1; b3++) {
        byte b4 = paramArrayOfByte[b3];
        if (b4 < 0)
          b4 += 256; 
        if (paramArrayOfByte[b3] >= 32 && paramArrayOfByte[b3] <= 126) {
          arrayOfChar1[b1++] = (char)paramArrayOfByte[b3];
        } else {
          arrayOfChar1[b1++] = '.';
        } 
        byte b6 = b4 / 16;
        byte b5 = b4 % 16;
        if (b6 < 10) {
          arrayOfChar2[b2++] = (char)(b6 + 48);
        } else {
          arrayOfChar2[b2++] = (char)(b6 - 10 + 65);
        } 
        if (b5 < 10) {
          arrayOfChar2[b2++] = (char)(b5 + 48);
        } else {
          arrayOfChar2[b2++] = (char)(b5 - 10 + 65);
        } 
        if (b2 == 8 || b2 == 17 || b2 == 26)
          b2++; 
        if (b2 > 34) {
          System.out.println(a(b3 - 15) + " | " + new String(arrayOfChar2) + "| " + new String(arrayOfChar1));
          for (b2 = 0; b2 < 16; b2++) {
            arrayOfChar1[b2] = ' ';
            arrayOfChar2[b2] = ' ';
          } 
          while (b2 < 36)
            arrayOfChar2[b2++] = ' '; 
          b2 = b1 = 0;
        } 
      } 
      if (b2 > 0)
        System.out.println(a(b3 - 15) + " | " + new String(arrayOfChar2) + "| " + new String(arrayOfChar1)); 
      System.out.println("-----+-------------------------------------+-----------------");
      System.out.println();
      System.out.println("End of '" + paramString + "'");
    } 
  }
  
  private static String a(int paramInt) {
    char[] arrayOfChar = { '0', '0', '0', '0' };
    for (byte b1 = 3; b1 >= 0 && paramInt > 0; b1--) {
      int i1 = paramInt % 16;
      if (i1 < 10) {
        arrayOfChar[b1] = (char)(arrayOfChar[b1] + (char)i1);
      } else {
        arrayOfChar[b1] = (char)(65 + i1 - 10);
      } 
      paramInt /= 16;
    } 
    return new String(arrayOfChar);
  }
  
  private static String a() {
    Date date = new Date();
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    return simpleDateFormat.format(date);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\p.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */