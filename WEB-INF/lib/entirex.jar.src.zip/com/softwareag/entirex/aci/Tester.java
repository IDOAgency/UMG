package com.softwareag.entirex.aci;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.ScrollPane;
import java.awt.TextArea;
import java.awt.TextField;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

public abstract class Tester extends Applet {
  private static final int a = 70;
  
  private static final String b = "0123456789ABCDEF";
  
  private Panel c = new Panel();
  
  private Label d = new Label("Server:", 1);
  
  private Label e = new Label("Broker:", 1);
  
  private Label f = new Label("User:", 1);
  
  private Label g = new Label("Passwd:", 1);
  
  private TextField h = new TextField("HostName", 10);
  
  private TextField i = new TextField("", 2);
  
  private TextField j = new TextField("", 2);
  
  private TextField k = new TextField("RPC/Server/CALLNAT", 16);
  
  private Button l = new Button("   Call   ");
  
  private Button m = new Button("   Exit   ");
  
  private Panel n = new Panel();
  
  private Label o = new Label("Messages:");
  
  private TextArea p = null;
  
  private Panel q = new Panel();
  
  private int r = 0;
  
  private Vector s = new Vector();
  
  private int t;
  
  private boolean u = false;
  
  private StringBuffer v = new StringBuffer();
  
  private String w;
  
  private DateFormat x;
  
  private SimpleDateFormat y = (SimpleDateFormat)(this.x = DateFormat.getDateInstance(1)).getDateTimeInstance(1, 1);
  
  private boolean z = true;
  
  private String a() { return this.z ? "user" : System.getProperty("user.name", "user"); }
  
  protected abstract void setFields();
  
  protected abstract String getDefBroker();
  
  protected abstract String getDefServer();
  
  public abstract String getProgramName();
  
  protected abstract void setService(Broker paramBroker, String paramString);
  
  protected abstract void callService();
  
  protected final void initFromMain() {
    Frame frame = new Frame();
    frame.addWindowListener(new b7(this));
    frame.setTitle("EntireX Java RPC Tester for " + getProgramName());
    frame.setLocation(200, 200);
    frame.add(this, "Center");
    this.z = false;
    init();
    frame.pack();
    frame.show();
  }
  
  public void init() {
    setBackground(Color.lightGray);
    setForeground(Color.black);
    setLayout(new BorderLayout(50, 10));
    this.h.setText(getDefBroker());
    this.k.setText(getDefServer());
    this.i.setText(a());
    this.c.setLayout(new FlowLayout(1, 2, 2));
    this.c.add(this.e);
    this.c.add(this.h);
    this.c.add(this.f);
    this.c.add(this.i);
    this.c.add(this.g);
    this.c.add(this.j);
    this.j.setEchoChar('*');
    this.c.add(this.d);
    this.c.add(this.k);
    this.c.add(this.l);
    if (!this.z) {
      this.c.add(this.m);
      this.m.addActionListener(new b2(this));
    } 
    add(this.c, "North");
    this.q.setLayout(new GridLayout(this.r, 1));
    ScrollPane scrollPane = new ScrollPane(0);
    this.p = new com/softwareag/entirex/aci/b3(this, 10, 70);
    this.n.setLayout(new BorderLayout(20, 20));
    this.n.add(this.o, "West");
    this.n.add(this.p, "East");
    this.p.append("Array elements must be separated by a semicolon\n");
    add(this.n, "Center");
    setFields();
    scrollPane.add(this.q);
    Dimension dimension = scrollPane.getSize();
    dimension.height *= 3;
    scrollPane.setSize(dimension);
    add(scrollPane, "South");
    resize(getSize());
    this.l.addActionListener(new b4(this));
  }
  
  protected final void addField(String paramString, boolean paramBoolean) {
    TextField textField = paramBoolean ? new TextField(70) : new com/softwareag/entirex/aci/b5(this, "?", 70);
    Label label = new Label(paramString);
    Panel panel = new Panel();
    panel.setLayout(new BorderLayout(20, 20));
    panel.add(label, "West");
    panel.add(textField, "East");
    this.q.add(panel);
    this.r++;
    this.s.addElement(textField);
    textField.addActionListener(new b6(this));
  }
  
  private String a(int paramInt) {
    if (this.u) {
      this.t--;
      int i1 = this.w.indexOf(';');
      if (i1 == -1)
        return this.w; 
      String str = this.w.substring(0, i1);
      this.w = this.w.substring(i1 + 1);
      return str;
    } 
    TextField textField = (TextField)this.s.elementAt(paramInt);
    return textField.getText();
  }
  
  protected final void startGetArray() {
    this.u = true;
    TextField textField = (TextField)this.s.elementAt(this.t);
    this.w = textField.getText();
  }
  
  protected final void stopGetArray() {
    this.u = false;
    this.t++;
  }
  
  protected final void startAddArray() {
    this.u = true;
    this.v.setLength(0);
  }
  
  protected final void stopAddArray() {
    TextField textField = (TextField)this.s.elementAt(this.t++);
    textField.setText(this.v.toString());
    this.u = false;
  }
  
  private void a(int paramInt, String paramString) {
    if (this.u) {
      if (this.v.length() > 0)
        this.v.append(';'); 
      this.v.append(paramString.trim());
    } else {
      TextField textField = (TextField)this.s.elementAt(paramInt);
      textField.setText(paramString);
    } 
  }
  
  protected final void resetIndex() { this.t = 0; }
  
  private void b() {
    this.l.setEnabled(false);
    if (this.h.getText() == null || this.h.getText().length() == 0) {
      this.p.append("\nBroker ID is empty. Fill in valid broker ID.\n");
    } else if (this.i.getText() == null || this.i.getText().length() == 0) {
      this.p.append("\nUser ID is empty. Fill in valid user ID.\n");
    } else {
      try {
        Broker broker = new Broker(this.h.getText(), this.i.getText());
        try {
          broker.logon();
        } catch (BrokerException brokerException) {
          if (brokerException.getErrorClass() == 20 && brokerException.getErrorCode() == 379) {
            broker.setSecurity(new EntireXSecurity(), 0);
            broker.logon(this.j.getText());
          } else {
            throw brokerException;
          } 
        } 
        setService(broker, this.k.getText());
        this.t = 0;
        callService();
        broker.logoff();
        broker.disconnect();
      } catch (BrokerException brokerException) {
        this.p.append("\n" + brokerException.toString() + "\n");
      } catch (Exception exception) {
        this.p.append("\n" + exception.toString() + "\n");
        exception.printStackTrace();
      } 
    } 
    this.l.setEnabled(true);
  }
  
  protected final void skipData() { this.t++; }
  
  protected final boolean getDataL() { return a(this.t++).equals("X"); }
  
  protected final String getDataAV() { return getDataA(); }
  
  protected final String getDataA() { return a(this.t++); }
  
  protected final byte[] getDataBV() { return getDataB(); }
  
  protected int hexValue(char paramChar) {
    char c1 = Character.MIN_VALUE;
    if (paramChar >= '0' && paramChar <= '9') {
      c1 = paramChar - '0';
    } else if (paramChar >= 'A' && paramChar <= 'F') {
      c1 = paramChar - 'A' + '\n';
    } else if (paramChar >= 'a' && paramChar <= 'f') {
      c1 = paramChar - 'a' + '\n';
    } 
    return c1;
  }
  
  protected final byte[] getDataB() {
    byte[] arrayOfByte = null;
    String str = a(this.t++);
    if (str.startsWith("\"") && str.endsWith("\"")) {
      arrayOfByte = str.substring(1, str.length() - 1).getBytes();
    } else {
      arrayOfByte = new byte[str.length() / 2];
      for (byte b1 = 0; b1 < str.length() - 1; b1 += 2)
        arrayOfByte[b1 / 2] = (byte)((hexValue(str.charAt(b1)) << 4) + hexValue(str.charAt(b1 + 1))); 
    } 
    return arrayOfByte;
  }
  
  protected final BigDecimal getDataN() {
    BigDecimal bigDecimal;
    try {
      String str = a(this.t++);
      if (str == null || str.length() < 1)
        str = "0.0"; 
      bigDecimal = new BigDecimal(str);
    } catch (NumberFormatException numberFormatException) {
      bigDecimal = new BigDecimal(0.0D);
      if (!this.u)
        a(this.t - 1, bigDecimal.toString()); 
    } 
    return bigDecimal;
  }
  
  protected final int getDataI4() {
    int i1 = 0;
    try {
      i1 = Integer.parseInt(a(this.t++));
    } catch (NumberFormatException numberFormatException) {
      if (!this.u)
        a(this.t - 1, "0"); 
    } 
    return i1;
  }
  
  protected final short getDataI2() {
    short s1 = 0;
    try {
      s1 = Short.parseShort(a(this.t++));
    } catch (NumberFormatException numberFormatException) {
      if (!this.u)
        a(this.t - 1, "0"); 
    } 
    return s1;
  }
  
  protected final byte getDataI1() {
    byte b1 = 0;
    try {
      b1 = Byte.parseByte(a(this.t++));
    } catch (NumberFormatException numberFormatException) {
      if (!this.u)
        a(this.t - 1, "0"); 
    } 
    return b1;
  }
  
  protected final float getDataF4() {
    Float float;
    try {
      float = new Float(a(this.t++));
    } catch (NumberFormatException numberFormatException) {
      float = new Float(0.0D);
      if (!this.u)
        a(this.t - 1, "0.0"); 
    } 
    return float.floatValue();
  }
  
  protected final double getDataF8() {
    Double double;
    try {
      double = new Double(a(this.t++));
    } catch (NumberFormatException numberFormatException) {
      double = new Double(0.0D);
      if (!this.u)
        a(this.t - 1, "0.0"); 
    } 
    return double.doubleValue();
  }
  
  protected final Date getDataD() { return getDataD(15); }
  
  protected final Date getDataD(int paramInt) {
    Date date;
    try {
      if (paramInt < 15) {
        date = this.x.parse(a(this.t++));
      } else {
        date = this.y.parse(a(this.t++));
      } 
    } catch (ParseException parseException) {
      String str = System.getProperty("entirex.marshal.date", "");
      date = (str == null || str.length() < 4) ? new Date() : null;
      if (!this.u)
        a(this.t - 1, this.y.format(date)); 
    } 
    return date;
  }
  
  protected final void addDataAV(String paramString) { addDataA(paramString); }
  
  protected final void addDataA(String paramString) {
    a(this.t, paramString);
    if (!this.u)
      this.t++; 
  }
  
  protected final void addDataBV(byte[] paramArrayOfByte) { addDataB(paramArrayOfByte); }
  
  protected final void addDataB(byte[] paramArrayOfByte) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b1 = 0; b1 < paramArrayOfByte.length; b1++) {
      byte b2 = paramArrayOfByte[b1] >> 4 & 0xF;
      stringBuffer.append("0123456789ABCDEF".charAt(b2));
      b2 = paramArrayOfByte[b1] & 0xF;
      stringBuffer.append("0123456789ABCDEF".charAt(b2));
    } 
    a(this.t, stringBuffer.toString());
    if (!this.u)
      this.t++; 
  }
  
  protected final void addDataI(String paramString) {
    a(this.t, paramString);
    if (!this.u)
      this.t++; 
  }
  
  protected final void addDataF(String paramString) {
    a(this.t, paramString);
    if (!this.u)
      this.t++; 
  }
  
  protected final void addDataN(BigDecimal paramBigDecimal) {
    a(this.t, paramBigDecimal.toString());
    if (!this.u)
      this.t++; 
  }
  
  protected final void addDataD(Date paramDate) { addDataD(paramDate, 15); }
  
  protected final void addDataD(Date paramDate, int paramInt) {
    if (paramInt < 15) {
      a(this.t, this.x.format(paramDate));
    } else {
      String str = this.y.format(paramDate);
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(paramDate);
      int i1 = calendar.get(14);
      if (i1 > 0) {
        String str1 = this.y.toPattern();
        int i2 = str1.indexOf("ss");
        int i3 = str1.indexOf("S");
        if (i2 > -1 && i3 == -1) {
          SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str1.substring(0, i2 + 2) + ".S" + str1.substring(i2 + 2));
          str = simpleDateFormat.format(calendar.getTime());
        } 
      } 
      a(this.t, str);
    } 
    if (!this.u)
      this.t++; 
  }
  
  static void a(Tester paramTester) { paramTester.b(); }
  
  private class com/softwareag/entirex/aci/b5 extends TextField {
    private final Tester a;
    
    public com/softwareag/entirex/aci/b5(Tester this$0, String param1String, int param1Int) {
      super(param1String, param1Int);
      this.a = this$0;
      setEditable(false);
    }
    
    public boolean isFocusTraversable() { return false; }
  }
  
  private class com/softwareag/entirex/aci/b3 extends TextArea {
    private final Tester a;
    
    public com/softwareag/entirex/aci/b3(Tester this$0, int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = this$0;
      setEditable(false);
    }
    
    public boolean isFocusTraversable() { return false; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\Tester.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */