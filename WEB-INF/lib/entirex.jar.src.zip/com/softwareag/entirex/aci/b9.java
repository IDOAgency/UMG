package com.softwareag.entirex.aci;

import java.awt.TextField;

class com/softwareag/entirex/aci/b9 {
  private String a;
  
  private TextField b;
  
  private final Tester2 c;
  
  com/softwareag/entirex/aci/b9(Tester2 paramTester2, String paramString, int paramInt) { this(paramTester2, paramString, paramInt, true); }
  
  com/softwareag/entirex/aci/b9(Tester2 paramTester2, String paramString, int paramInt, boolean paramBoolean) {
    if ((this.c = paramTester2).e(paramTester2)) {
      if (paramBoolean) {
        this.b = new TextField(paramString, paramInt);
      } else {
        this.b = new Tester2.com/softwareag/entirex/aci/ca(paramTester2, paramString, paramInt);
      } 
    } else {
      this.a = paramString;
    } 
  }
  
  String a() { return Tester2.e(this.c) ? this.b.getText() : this.a; }
  
  void a(String paramString) {
    if (Tester2.e(this.c)) {
      this.b.setText(paramString);
    } else {
      this.a = paramString;
    } 
  }
  
  TextField b() { return this.b; }
  
  void a(boolean paramBoolean) { this.b.setEnabled(paramBoolean); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\b9.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */