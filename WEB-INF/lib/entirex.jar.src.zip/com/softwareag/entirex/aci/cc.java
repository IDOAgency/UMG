package com.softwareag.entirex.aci;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

class cc extends WindowAdapter {
  private final Tester2 a;
  
  cc(Tester2 paramTester2) { this.a = paramTester2; }
  
  public void windowClosing(WindowEvent paramWindowEvent) { System.exit(0); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\cc.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */