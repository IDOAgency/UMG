package com.softwareag.entirex.aci;

class com/softwareag/entirex/aci/b1 {
  private boolean a;
  
  private StringBuffer b;
  
  private StringBuffer c;
  
  private final bn d;
  
  private com/softwareag/entirex/aci/b1(bn parambn) {
    this.d = parambn;
    this.a = false;
    this.b = new StringBuffer();
    this.c = new StringBuffer();
  }
  
  static boolean a(com/softwareag/entirex/aci/b1 paramcom/softwareag/entirex/aci/b1) { return paramcom/softwareag/entirex/aci/b1.a; }
  
  static StringBuffer b(com/softwareag/entirex/aci/b1 paramcom/softwareag/entirex/aci/b1) { return paramcom/softwareag/entirex/aci/b1.b; }
  
  static StringBuffer c(com/softwareag/entirex/aci/b1 paramcom/softwareag/entirex/aci/b1) { return paramcom/softwareag/entirex/aci/b1.c; }
  
  com/softwareag/entirex/aci/b1(bn parambn, bn.com/softwareag/entirex/aci/ew paramcom/softwareag/entirex/aci/ew) { this(parambn); }
  
  static boolean a(com/softwareag/entirex/aci/b1 paramcom/softwareag/entirex/aci/b1, boolean paramBoolean) { return paramcom/softwareag/entirex/aci/b1.a = paramBoolean; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\b1.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */