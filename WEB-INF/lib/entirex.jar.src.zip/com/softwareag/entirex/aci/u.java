package com.softwareag.entirex.aci;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

final class u extends t {
  private URLConnection a;
  
  private ad b;
  
  private DataInputStream c;
  
  private String d;
  
  private String e;
  
  private int f;
  
  private boolean g = false;
  
  private boolean h = true;
  
  u(String paramString) {
    this.d = paramString;
    int i = paramString.indexOf('?');
    if (i == -1) {
      this.e = paramString;
    } else {
      this.e = paramString.substring(0, i);
      if (paramString.indexOf("checkheaders=no") != -1)
        this.h = false; 
    } 
  }
  
  public String toString() { return this.e; }
  
  String f() { return "Connection status to " + this.e + "  unknown."; }
  
  private void l() throws ae {
    if (this.g)
      return; 
    try {
      this.a = (new URL(this.d)).openConnection();
      if (Dump.c)
        Dump.log("URLConnection to " + this.d + " via " + this.a.getClass().getName()); 
      this.a.setDoOutput(true);
      this.a.setDoInput(true);
      this.a.setAllowUserInteraction(false);
      this.a.setUseCaches(false);
      this.a.setRequestProperty("Content-Type", "application/octet-stream");
      this.a.setRequestProperty("User-Agent", "EntireX/" + EntireXVersion.getVersion());
      this.g = true;
    } catch (MalformedURLException malformedURLException) {
      if (this.e.toLowerCase().startsWith("https") && malformedURLException.getMessage().indexOf("https") != -1)
        throw new ae("0325", new String[] { malformedURLException.toString() }); 
      throw new ae("0311", new String[] { this.e, malformedURLException.toString() });
    } catch (IOException iOException) {
      throw new ae("0311", new String[] { this.e, iOException.toString() });
    } 
  }
  
  protected void a(int paramInt) throws ae {
    if (this.h && this.f != paramInt)
      throw new ae("0320", new String[] { "wrong Content-Length= (" + Integer.toString(this.f) + " instead of " + Integer.toString(paramInt) }); 
  }
  
  protected DataInputStream b(int paramInt) throws IOException {
    l();
    String str1 = this.a.getHeaderField("Content-Type");
    String str2 = this.a.getHeaderField("TunnelServlet-Error");
    if (Dump.c) {
      Dump.log("Received reply from HTTP server.");
      Dump.log("HTTP Headers:");
      Dump.log("   Response = " + this.a.getHeaderField(0));
      for (byte b1 = 1;; b1++) {
        String str = this.a.getHeaderField(b1);
        if (str == null)
          break; 
        Dump.log("   " + this.a.getHeaderFieldKey(b1) + " = " + str);
      } 
      if (str1 != null && !str1.equals("application/octet-stream"))
        try {
          BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.a.getInputStream()));
          for (String str = bufferedReader.readLine(); str != null; str = bufferedReader.readLine())
            Dump.log(str); 
        } catch (IOException iOException) {} 
    } 
    if (str2 != null)
      throw new ae("0320", new String[] { str2 }); 
    if (this.h) {
      int i = m();
      if (i != 200)
        throw new ae("0324", new String[] { n() }); 
      if (str1 == null || !str1.equals("application/octet-stream"))
        throw new ae("0320", new String[] { "wrong Content-Type " + str1 }); 
      this.f = this.a.getContentLength();
      if (this.f <= 0)
        throw new ae("0320", new String[] { "wrong Content-Length = " + Integer.toString(this.f) }); 
    } 
    if (Dump.c)
      Dump.log("Will receive data ..."); 
    this.c = new DataInputStream(new BufferedInputStream(this.a.getInputStream(), 4096));
    return this.c;
  }
  
  protected ad c(int paramInt) throws IOException {
    l();
    this.b = new ad(this.a.getOutputStream(), paramInt);
    return this.b;
  }
  
  protected void h() throws ae {
    this.b.a();
    this.b.b();
    this.b = null;
  }
  
  protected void g() throws ae {
    this.c.close();
    this.c = null;
  }
  
  protected void j() throws ae { k(); }
  
  protected void i() throws ae { k(); }
  
  protected void k() throws ae {
    if (!this.g)
      return; 
    this.g = false;
    try {
      if (this.c != null)
        this.c.close(); 
      if (this.b != null)
        this.b.b(); 
    } catch (IOException iOException) {}
    this.c = null;
    this.b = null;
    this.a = null;
  }
  
  private int m() {
    String str = this.a.getHeaderField(0);
    int i = -1;
    try {
      byte b1;
      for (b1 = 0; str.charAt(b1) == ' '; b1++);
      while (str.charAt(b1) != ' ')
        b1++; 
      while (str.charAt(b1) == ' ')
        b1++; 
      return Integer.parseInt(str.substring(b1, b1 + 3));
    } catch (Exception exception) {
      if (Dump.c)
        Dump.log(exception.toString()); 
      return i;
    } 
  }
  
  private String n() {
    String str = this.a.getHeaderField(0);
    byte b1 = 0;
    if (str != null) {
      while (str.charAt(b1) == ' ')
        b1++; 
      while (str.charAt(b1) != ' ')
        b1++; 
      while (str.charAt(b1) == ' ')
        b1++; 
      return str.substring(b1);
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\ac\\u.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */