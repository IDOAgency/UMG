package com.softwareag.entirex.aci;

interface d2 {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\d2.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */