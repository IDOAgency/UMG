package com.softwareag.entirex.aci;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.ScrollPane;
import java.awt.TextArea;
import java.awt.TextField;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public abstract class Tester2 {
  private static final int a = 70;
  
  private static final int b = 100;
  
  private static final boolean c = (System.getProperty("entirex.tester.extended", "").length() > 0);
  
  public static final int d = 0;
  
  public static final int e = 1;
  
  public static final int f = 2;
  
  public static final int g = 3;
  
  public static final int h = 4;
  
  public static final int i = 5;
  
  private static final String j = "0123456789ABCDEF";
  
  private Panel k;
  
  private Panel l;
  
  private Label m;
  
  private Label n;
  
  private Label o;
  
  private Label p;
  
  private Label q;
  
  private com/softwareag/entirex/aci/b9 r;
  
  private com/softwareag/entirex/aci/b9 s;
  
  private com/softwareag/entirex/aci/b9 t;
  
  private com/softwareag/entirex/aci/b9 u;
  
  private com/softwareag/entirex/aci/b9 v;
  
  private Button w;
  
  private Button x;
  
  private Button y;
  
  private Button z;
  
  private Button aa;
  
  private Button ab;
  
  private Button ac;
  
  private Panel ad;
  
  private Label ae;
  
  private TextArea af = null;
  
  private Panel ag;
  
  private int ah = 0;
  
  private Vector ai = new Vector();
  
  private boolean aj = false;
  
  private StringBuffer ak = new StringBuffer();
  
  private String al;
  
  private String am;
  
  private String an = "localhost";
  
  private String ao = "RPC/SRV1/CALLNAT";
  
  private boolean ap = true;
  
  private boolean aq = false;
  
  private int ar = -1;
  
  private String[] as;
  
  private com/softwareag/entirex/aci/b8 at;
  
  private int au = 0;
  
  private Broker av = null;
  
  private Conversation aw = null;
  
  private int ax;
  
  private Method ay;
  
  private Class az;
  
  private Class[] a0;
  
  private Object[] a1;
  
  private Object resultValue;
  
  private RPCService a2;
  
  private Class a3;
  
  private static final DateFormat a4;
  
  private static final SimpleDateFormat a5 = (SimpleDateFormat)(a4 = DateFormat.getDateInstance(1)).getDateTimeInstance(1, 1);
  
  private int a6 = 0;
  
  private Method a7;
  
  private Object[] a8;
  
  static Class a9;
  
  private String t() { return System.getProperty("user.name", "user"); }
  
  protected abstract void setFields();
  
  protected final void test(String[] paramArrayOfString, Class paramClass, String paramString) {
    this.as = paramArrayOfString;
    if (paramArrayOfString.length >= 1)
      if (paramArrayOfString[0].equals("-batch")) {
        this.aq = true;
        this.ap = false;
        this.ar = 1;
      } else if (paramArrayOfString[0].equals("-both")) {
        this.aq = true;
        this.ap = true;
        this.ar = 1;
      } else {
        this.ar = 0;
      }  
    this.am = paramString;
    this.a3 = paramClass;
    Properties properties = System.getProperties();
    properties.put("entirex.timeout", "20");
    System.setProperties(properties);
    if (this.ap) {
      Frame frame = new Frame();
      frame.addWindowListener(new cc(this));
      frame.setTitle("EntireX Java RPC Tester for " + paramString);
      frame.setLocation(120, 150);
      u();
      frame.add(this.k, "Center");
      frame.pack();
      frame.show();
    } else if (this.aq && u()) {
      b(false);
    } 
  }
  
  private boolean u() {
    ScrollPane scrollPane = null;
    this.r = new com/softwareag/entirex/aci/b9(this, "", 10);
    this.s = new com/softwareag/entirex/aci/b9(this, "", 2);
    this.t = new com/softwareag/entirex/aci/b9(this, "", 2);
    this.u = new com/softwareag/entirex/aci/b9(this, "", 16);
    this.v = new com/softwareag/entirex/aci/b9(this, "0", 1);
    if (this.ap) {
      this.k = new Panel();
      this.l = new Panel();
      this.m = new Label("Server:", 1);
      this.n = new Label("Broker:", 1);
      this.o = new Label("User:", 1);
      this.p = new Label("Passwd:", 1);
      this.q = new Label("Trace:", 1);
      this.w = new Button(" Call ");
      this.x = new Button(" Exit ");
      this.y = new Button(" Reset ");
      this.z = new Button(" Ping ");
      this.aa = new Button(" Open C ");
      this.ab = new Button(" Commit C ");
      this.ac = new Button(" Abort C ");
      this.ad = new Panel();
      this.ae = new Label("Messages:");
      this.ag = new Panel();
      scrollPane = new ScrollPane(0);
      if (c) {
        this.ax = 100;
      } else {
        this.ax = 70;
      } 
      this.k.setBackground(Color.lightGray);
      this.k.setForeground(Color.black);
      this.k.setLayout(new BorderLayout(50, 10));
      this.l.setLayout(new FlowLayout(1, 2, 2));
      this.l.add(this.n);
      this.l.add(this.r.b());
      this.l.add(this.o);
      this.l.add(this.s.b());
      this.l.add(this.p);
      this.l.add(this.t.b());
      this.t.b().setEchoChar('*');
      this.l.add(this.m);
      this.l.add(this.u.b());
      if (c) {
        this.l.add(this.q);
        this.l.add(this.v.b());
      } 
      this.l.add(this.w);
      this.l.add(this.z);
      this.l.add(this.y);
      if (c) {
        this.l.add(this.aa);
        this.l.add(this.ab);
        this.ab.setEnabled(false);
        this.l.add(this.ac);
        this.ac.setEnabled(false);
      } 
      this.l.add(this.x);
      this.x.addActionListener(new cd(this));
      this.k.add(this.l, "North");
      this.ag.setLayout(new GridLayout(this.ah, 1));
      this.af = (new com/softwareag/entirex/aci/ce(this, 10, this.ax)).a();
      this.ad.setLayout(new BorderLayout(20, 20));
      this.ad.add(this.ae, "West");
      this.ad.add(this.af, "East");
      b(Broker.getVersion() + "\n");
      b("\nArray elements must be separated by a semicolon\n");
      this.k.add(this.ad, "Center");
    } 
    setFields();
    if (this.ap) {
      scrollPane.add(this.ag);
      Dimension dimension = scrollPane.getSize();
      dimension.height *= 3;
      scrollPane.setSize(dimension);
      this.k.add(scrollPane, "South");
      this.k.setSize(this.k.getSize());
      this.w.addActionListener(new cg(this));
      this.z.addActionListener(new ch(this));
      this.y.addActionListener(new ci(this));
      if (c) {
        this.aa.addActionListener(new cj(this));
        this.ab.addActionListener(new ck(this));
        this.ac.addActionListener(new cl(this));
      } 
    } 
    if (!af()) {
      if (this.ap) {
        this.z.setEnabled(false);
        this.w.setEnabled(false);
        this.aa.setEnabled(false);
      } 
      b("\nGenerated Java Wrapper Class \"" + this.a3.getName() + "\" needs to be public for Java 1.1\n");
      return false;
    } 
    try {
      Constructor constructor = this.a3.getDeclaredConstructor(new Class[0]);
      a(constructor);
      this.a2 = (RPCService)constructor.newInstance(new Object[0]);
      Field field = this.a3.getField("DEFAULT_BROKERID");
      a(field);
      this.an = (String)field.get(null);
      field = this.a3.getField("DEFAULT_SERVER");
      a(field);
      this.ao = (String)field.get(null);
    } catch (Exception exception) {
      b("\n" + exception.toString() + "\n");
      exception.printStackTrace(System.err);
    } 
    this.r.a(this.an);
    this.u.a(this.ao);
    this.s.a(t());
    return true;
  }
  
  protected final void addField(String paramString1, boolean paramBoolean1, boolean paramBoolean2, int paramInt, String paramString2) {
    com/softwareag/entirex/aci/b8 com/softwareag/entirex/aci/b81 = new com/softwareag/entirex/aci/b8(this, paramString1, this.ax, paramBoolean1, paramBoolean2, paramInt, paramString2, null);
    if (this.ap) {
      Label label = new Label(paramString1);
      Panel panel = new Panel();
      panel.setLayout(new BorderLayout(20, 20));
      panel.add(label, "West");
      panel.add(com/softwareag/entirex/aci/b81.b(), "East");
      this.ag.add(panel);
    } 
    this.ah++;
    this.ai.addElement(com/softwareag/entirex/aci/b81);
    if (paramBoolean1 && this.ar >= 0 && this.ar < this.as.length)
      com/softwareag/entirex/aci/b81.a(this.as[this.ar++]); 
    if (this.ap && paramBoolean1)
      com/softwareag/entirex/aci/b81.b().addActionListener(new cb(this)); 
  }
  
  private void b(String paramString) {
    if (this.ap)
      this.af.append(paramString); 
    if (this.aq)
      System.out.print(paramString); 
  }
  
  private void v() {
    String str = this.v.a();
    int i1 = 0;
    try {
      i1 = Integer.parseInt(str);
      if (i1 > 3) {
        i1 = 3;
      } else if (i1 < 0) {
        i1 = 0;
      } 
    } catch (NumberFormatException numberFormatException) {}
    this.v.a(Integer.toString(i1));
    if (i1 != this.au) {
      this.au = i1;
      if (this.au == 0) {
        Broker.setTrace(i1);
      } else {
        Broker.setTrace(i1, new PrintWriter(new com/softwareag/entirex/aci/cm(this, null), true));
      } 
    } 
  }
  
  private void w() {
    x();
    if (!z())
      return; 
    this.aw = new Conversation(this.a2);
    this.a2.setConversation(this.aw);
    if (this.ap) {
      this.aa.setEnabled(false);
      this.ab.setEnabled(true);
      this.ac.setEnabled(true);
      this.r.a(false);
      this.u.a(false);
    } 
  }
  
  private void a(boolean paramBoolean) {
    if (this.ap) {
      this.aa.setEnabled(true);
      this.ab.setEnabled(false);
      this.ac.setEnabled(false);
      this.r.a(true);
      this.u.a(true);
    } 
    try {
      if (paramBoolean) {
        this.a2.closeConversationCommit();
      } else {
        this.a2.closeConversation();
      } 
      this.av.logoff();
    } catch (BrokerException brokerException) {
      b("\n" + brokerException.toString() + "\n");
      System.err.println(brokerException);
    } 
    this.aw = null;
  }
  
  private void x() {
    String str = this.u.a();
    if (str.trim().length() > 0 && str.indexOf('/') == -1)
      this.u.a("RPC/" + str + "/CALLNAT"); 
  }
  
  private void y() {
    BrokerMessage brokerMessage = this.a2.sendReceive(new BrokerMessage(ao.aa().d()));
    b("\nServer: ");
    b(ao.e(brokerMessage.getMessage()));
    b("\n");
  }
  
  private boolean z() {
    try {
      if (this.r.a() == null || this.r.a().trim().length() == 0) {
        b("\nBroker ID is empty. Fill in valid Broker ID.\n");
      } else if (this.u.a() == null || this.u.a().trim().length() == 0 || a(this.u.a(), '/') != 2) {
        b("\nServer address is incorrect. Fill in valid server address.\n");
      } else if (this.s.a() == null || this.s.a().trim().length() == 0) {
        b("\nUser ID is empty. Fill in valid User ID.\n");
      } else {
        if (this.av == null) {
          this.av = new Broker(this.r.a(), this.s.a());
          this.av.useEntireXSecurity(true);
          this.a2.setBroker(this.av);
          this.a2.setServerAddress(this.u.a());
          this.a2.setRPCUserId(this.s.a());
          this.a2.setRPCPassword(this.t.a());
          Constructor constructor = this.a3.getDeclaredConstructor(new Class[] { (a9 == null) ? (a9 = class$("com.softwareag.entirex.aci.Broker")) : a9 });
          a(constructor);
          RPCService rPCService = (RPCService)constructor.newInstance(new Object[] { this.av });
          this.a2.setLibraryName(rPCService.getLibraryName());
          return true;
        } 
        if (!this.r.a().equals(this.av.getBrokerID())) {
          this.av = new Broker(this.r.a(), this.s.a());
          this.av.useEntireXSecurity(true);
          this.a2.setBroker(this.av);
        } else if (!this.s.a().equals(this.av.getUserID())) {
          this.av.reconnect(this.s.a());
        } 
        if (!this.u.a().equals(this.a2.toString()))
          this.a2.setServerAddress(this.u.a()); 
        this.a2.setRPCUserId(this.s.a());
        this.a2.setRPCPassword(this.t.a());
        return true;
      } 
    } catch (BrokerException brokerException) {
      b("\n" + brokerException.toString() + "\n");
      System.err.println(brokerException);
    } catch (Exception exception) {
      b("\n" + exception.toString() + "\n");
      exception.printStackTrace(System.err);
    } 
    return false;
  }
  
  private void b(boolean paramBoolean) {
    x();
    if (!z())
      return; 
    if (this.ap) {
      this.z.setEnabled(false);
      this.w.setEnabled(false);
      this.y.setEnabled(false);
    } 
    v();
    try {
      if (paramBoolean) {
        String str = this.av.b();
        b("\nBroker: ");
        b(str);
        b("\n");
      } 
      if (this.aw == null || this.aw.d)
        this.av.logon(this.t.a()); 
      ab();
      try {
        if (this.ap) {
          if (paramBoolean) {
            y();
          } else {
            ac();
          } 
        } else if (this.aq) {
          ac();
        } 
      } catch (BrokerException brokerException) {
        if (brokerException.getErrorClass() == 1014 && brokerException.getErrorCode() == 6975 && this.a2 != null) {
          this.a2.setNaturalLogon(true);
          if (paramBoolean) {
            y();
          } else {
            ac();
          } 
        } else {
          throw brokerException;
        } 
      } 
      if (this.aw == null)
        this.av.logoff(); 
    } catch (IllegalArgumentException illegalArgumentException) {
      b("\n" + illegalArgumentException.toString() + "\n");
      illegalArgumentException.printStackTrace(System.err);
    } catch (BrokerException brokerException) {
      b("\n" + brokerException.toString() + "\n");
      System.err.println(brokerException.toString());
    } catch (InvocationTargetException invocationTargetException) {
      Throwable throwable = invocationTargetException.getTargetException();
      if (throwable != null) {
        b("\n" + throwable.toString() + "\n");
        if (!(throwable instanceof BrokerException)) {
          throwable.printStackTrace(System.err);
        } else {
          System.err.println(throwable);
        } 
      } else {
        b("\n" + invocationTargetException.toString() + "\n");
        invocationTargetException.printStackTrace(System.err);
      } 
    } catch (Exception exception) {
      b("\n" + exception.toString() + "\n");
      exception.printStackTrace(System.err);
    } 
    if (this.ap) {
      this.z.setEnabled(true);
      this.w.setEnabled(true);
      this.y.setEnabled(true);
    } 
  }
  
  private String aa() {
    if (this.aj) {
      int i1 = this.al.indexOf(';');
      if (i1 == -1)
        return this.al; 
      String str = this.al.substring(0, i1);
      this.al = this.al.substring(i1 + 1);
      return str;
    } 
    return this.at.a();
  }
  
  int a() {
    StringTokenizer stringTokenizer = new StringTokenizer(this.al, ";");
    return stringTokenizer.countTokens();
  }
  
  void b() {
    this.a6++;
    if (this.a6 > 1)
      return; 
    this.aj = true;
    this.al = this.at.a();
  }
  
  void c() {
    this.a6--;
    if (this.a6 >= 1)
      return; 
    this.aj = false;
  }
  
  void d() {
    this.a6++;
    if (this.a6 > 1)
      return; 
    this.aj = true;
    this.ak.setLength(0);
  }
  
  void e() {
    this.a6--;
    if (this.a6 >= 1)
      return; 
    this.at.a(this.ak.toString());
    this.aj = false;
  }
  
  private void c(String paramString) {
    if (this.aj) {
      if (this.ak.length() > 0)
        this.ak.append(';'); 
      this.ak.append(paramString.trim());
    } else {
      this.at.a(paramString);
    } 
  }
  
  private void ab() { this.a6 = 0; }
  
  private int a(String paramString, char paramChar) {
    byte b1 = 0;
    for (byte b2 = 0; b2 < paramString.length(); b2++) {
      if (paramString.charAt(b2) == paramChar)
        b1++; 
    } 
    return b1;
  }
  
  boolean f() {
    String str = aa();
    return (str.equalsIgnoreCase("true") || str.equals("X"));
  }
  
  String g() { return aa(); }
  
  private static int a(char paramChar) {
    char c1 = Character.MIN_VALUE;
    if (paramChar >= '0' && paramChar <= '9') {
      c1 = paramChar - '0';
    } else if (paramChar >= 'A' && paramChar <= 'F') {
      c1 = paramChar - 'A' + '\n';
    } else if (paramChar >= 'a' && paramChar <= 'f') {
      c1 = paramChar - 'a' + '\n';
    } 
    return c1;
  }
  
  byte[] h() {
    byte[] arrayOfByte = null;
    String str = aa();
    if (str.startsWith("\"") && str.endsWith("\"")) {
      arrayOfByte = str.substring(1, str.length() - 1).getBytes();
    } else {
      arrayOfByte = new byte[str.length() / 2];
      for (byte b1 = 0; b1 < str.length() - 1; b1 += 2)
        arrayOfByte[b1 / 2] = (byte)((a(str.charAt(b1)) << 4) + a(str.charAt(b1 + 1))); 
    } 
    return arrayOfByte;
  }
  
  BigDecimal i() {
    BigDecimal bigDecimal;
    try {
      String str = aa();
      if (str == null || str.length() < 1)
        str = "0.0"; 
      bigDecimal = new BigDecimal(str);
    } catch (NumberFormatException numberFormatException) {
      bigDecimal = new BigDecimal(0.0D);
      if (!this.aj)
        c(bigDecimal.toString()); 
    } 
    return bigDecimal;
  }
  
  int j() {
    int i1 = 0;
    try {
      i1 = Integer.parseInt(aa());
    } catch (NumberFormatException numberFormatException) {
      if (!this.aj)
        c("0"); 
    } 
    return i1;
  }
  
  short k() {
    short s1 = 0;
    try {
      s1 = Short.parseShort(aa());
    } catch (NumberFormatException numberFormatException) {
      if (!this.aj)
        c("0"); 
    } 
    return s1;
  }
  
  byte l() {
    byte b1 = 0;
    try {
      b1 = Byte.parseByte(aa());
    } catch (NumberFormatException numberFormatException) {
      if (!this.aj)
        c("0"); 
    } 
    return b1;
  }
  
  float m() {
    Float float;
    try {
      float = new Float(aa());
    } catch (NumberFormatException numberFormatException) {
      float = new Float(0.0D);
      if (!this.aj)
        c("0.0"); 
    } 
    return float.floatValue();
  }
  
  double n() {
    Double double;
    try {
      double = new Double(aa());
    } catch (NumberFormatException numberFormatException) {
      double = new Double(0.0D);
      if (!this.aj)
        c("0.0"); 
    } 
    return double.doubleValue();
  }
  
  Date o() {
    boolean bool = (this.at.e.indexOf("(T") >= 0) ? 1 : 0;
    try {
      return bool ? a5.parse(aa()) : a4.parse(aa());
    } catch (ParseException parseException) {
      String str = System.getProperty("entirex.marshal.date", "");
      Date date = (str == null || str.length() < 4) ? new Date() : null;
      if (!this.aj)
        if (bool) {
          c(a5.format(date));
        } else {
          c(a4.format(date));
        }  
      return date;
    } 
  }
  
  void a(String paramString) { c(paramString); }
  
  void a(byte[] paramArrayOfByte) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b1 = 0; b1 < paramArrayOfByte.length; b1++) {
      byte b2 = paramArrayOfByte[b1] >> 4 & 0xF;
      stringBuffer.append("0123456789ABCDEF".charAt(b2));
      b2 = paramArrayOfByte[b1] & 0xF;
      stringBuffer.append("0123456789ABCDEF".charAt(b2));
    } 
    c(stringBuffer.toString());
  }
  
  void a(Date paramDate) {
    if (this.at.e.indexOf("(T") >= 0) {
      String str = a5.format(paramDate);
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(paramDate);
      int i1 = calendar.get(14);
      if (i1 > 0) {
        String str1 = a5.toPattern();
        int i2 = str1.indexOf("ss");
        int i3 = str1.indexOf("S");
        if (i2 > -1 && i3 == -1) {
          SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str1.substring(0, i2 + 2) + ".S" + str1.substring(i2 + 2));
          str = simpleDateFormat.format(calendar.getTime());
        } 
      } 
      c(str);
    } else {
      c(a4.format(paramDate));
    } 
  }
  
  Class a(int paramInt) { return this.a0[paramInt]; }
  
  Class p() { return this.az; }
  
  Object q() { return this.resultValue; }
  
  Object[] r() { return this.a1; }
  
  RPCService s() { return this.a2; }
  
  private void ac() {
    Method[] arrayOfMethod = this.a2.getClass().getDeclaredMethods();
    for (byte b1 = 0; b1 < arrayOfMethod.length; b1++) {
      Method method = arrayOfMethod[b1];
      if (method.getName().equals(this.am)) {
        this.ay = method;
        a(this.ay);
        this.az = method.getReturnType();
        this.a0 = method.getParameterTypes();
        this.a1 = new Object[this.a0.length];
        break;
      } 
    } 
    if (this.ay == null)
      throw new NoSuchMethodException("Method " + this.am + " in class " + this.a2.getClass().getName() + " not found"); 
    ad();
    ab();
    try {
      this.resultValue = this.ay.invoke(this.a2, this.a1);
    } catch (InvocationTargetException invocationTargetException) {
      Throwable throwable = invocationTargetException.getTargetException();
      if (throwable instanceof BrokerException)
        throw (BrokerException)throwable; 
      throw invocationTargetException;
    } 
    ae();
  }
  
  private void ad() {
    if (this.aq)
      System.out.println("\nInput values:\n-------------"); 
    for (byte b1 = 0; b1 < this.ai.size(); b1++) {
      this.at = (com/softwareag/entirex/aci/b8)this.ai.elementAt(b1);
      if (!this.at.b) {
        this.at.d = null;
      } else {
        this.at.d = new cn(this.at, this, true);
        this.at.d.a();
        this.at.d = null;
        if (this.aq)
          System.out.println(this.at.e + " : " + this.at.a()); 
      } 
    } 
  }
  
  private void ae() {
    if (this.aq)
      System.out.println("\nOutput values:\n--------------"); 
    for (byte b1 = 0; b1 < this.ai.size(); b1++) {
      this.at = (com/softwareag/entirex/aci/b8)this.ai.elementAt(b1);
      if (!this.at.c) {
        this.at.d = null;
      } else {
        this.at.d = new cn(this.at, this, false);
        this.at.d.b();
        this.at.d = null;
        if (this.aq)
          System.out.println(this.at.e + " : " + this.at.a()); 
      } 
    } 
  }
  
  void a(Object paramObject) throws Exception {
    if (this.a7 != null)
      this.a7.invoke(paramObject, this.a8); 
  }
  
  private boolean af() {
    if (Modifier.isPublic(this.a3.getModifiers()) || this.a7 != null)
      return true; 
    try {
      Class clazz = Class.forName("java.lang.reflect.AccessibleObject");
      this.a7 = clazz.getDeclaredMethod("setAccessible", new Class[] { boolean.class });
      this.a8 = new Object[] { new Boolean(true) };
      return true;
    } catch (ClassNotFoundException classNotFoundException) {
      System.err.println(classNotFoundException);
      return false;
    } catch (NoSuchMethodException noSuchMethodException) {
      System.err.println(noSuchMethodException);
      return false;
    } 
  }
  
  static void a(Tester2 paramTester2, boolean paramBoolean) { paramTester2.b(paramBoolean); }
  
  static TextArea a(Tester2 paramTester2) { return paramTester2.af; }
  
  static Vector b(Tester2 paramTester2) { return paramTester2.ai; }
  
  static void c(Tester2 paramTester2) { paramTester2.x(); }
  
  static void d(Tester2 paramTester2) { paramTester2.w(); }
  
  static void b(Tester2 paramTester2, boolean paramBoolean) { paramTester2.a(paramBoolean); }
  
  static boolean e(Tester2 paramTester2) { return paramTester2.ap; }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
  
  static void a(Tester2 paramTester2, String paramString) { paramTester2.b(paramString); }
  
  private class com/softwareag/entirex/aci/b9 {
    private String a;
    
    private TextField b;
    
    private final Tester2 c;
    
    com/softwareag/entirex/aci/b9(Tester2 this$0, String param1String, int param1Int) { this(this$0, param1String, param1Int, true); }
    
    com/softwareag/entirex/aci/b9(Tester2 this$0, String param1String, int param1Int, boolean param1Boolean) {
      if ((this.c = this$0).e(this$0)) {
        if (param1Boolean) {
          this.b = new TextField(param1String, param1Int);
        } else {
          this.b = new Tester2.com/softwareag/entirex/aci/ca(this$0, param1String, param1Int);
        } 
      } else {
        this.a = param1String;
      } 
    }
    
    String a() { return Tester2.e(this.c) ? this.b.getText() : this.a; }
    
    void a(String param1String) {
      if (Tester2.e(this.c)) {
        this.b.setText(param1String);
      } else {
        this.a = param1String;
      } 
    }
    
    TextField b() { return this.b; }
    
    void a(boolean param1Boolean) { this.b.setEnabled(param1Boolean); }
  }
  
  private class com/softwareag/entirex/aci/ca extends TextField {
    private final Tester2 a;
    
    public com/softwareag/entirex/aci/ca(Tester2 this$0, String param1String, int param1Int) {
      super(param1String, param1Int);
      this.a = this$0;
    }
    
    public boolean isFocusTraversable() { return false; }
  }
  
  private class com/softwareag/entirex/aci/ce {
    private TextArea a;
    
    private final Tester2 b;
    
    com/softwareag/entirex/aci/ce(Tester2 this$0, int param1Int1, int param1Int2) {
      if ((this.b = this$0).e(this$0))
        this.a = new Tester2.com/softwareag/entirex/aci/cf(this$0, param1Int1, param1Int2); 
    }
    
    TextArea a() { return this.a; }
  }
  
  private class com/softwareag/entirex/aci/cf extends TextArea {
    private final Tester2 a;
    
    public com/softwareag/entirex/aci/cf(Tester2 this$0, int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = this$0;
      setEditable(false);
    }
    
    public boolean isFocusTraversable() { return false; }
  }
  
  private class com/softwareag/entirex/aci/cm extends Writer {
    private final Tester2 a;
    
    private com/softwareag/entirex/aci/cm(Tester2 this$0) { this.a = this$0; }
    
    public void close() {}
    
    public void flush() {}
    
    public void write(char[] param1ArrayOfChar, int param1Int1, int param1Int2) throws IOException { Tester2.a(this.a, new String(param1ArrayOfChar, param1Int1, param1Int2)); }
    
    com/softwareag/entirex/aci/cm(Tester2 this$0, cc param1cc) { this(this$0); }
  }
  
  class com/softwareag/entirex/aci/b8 extends com/softwareag/entirex/aci/b9 {
    String a;
    
    boolean b;
    
    boolean c;
    
    cn d;
    
    String e;
    
    int f;
    
    private final Tester2 g;
    
    private com/softwareag/entirex/aci/b8(Tester2 this$0, String param1String1, int param1Int1, boolean param1Boolean1, boolean param1Boolean2, int param1Int2, String param1String2) {
      super(this$0, "", param1Int1, param1Boolean1);
      this.g = this$0;
      this.e = param1String1;
      this.c = param1Boolean2;
      this.b = param1Boolean1;
      this.f = param1Int2;
      this.a = param1String2;
      if (Tester2.e(this$0))
        b().setEditable(param1Boolean1); 
    }
    
    com/softwareag/entirex/aci/b8(Tester2 this$0, String param1String1, int param1Int1, boolean param1Boolean1, boolean param1Boolean2, int param1Int2, String param1String2, cc param1cc) { this(this$0, param1String1, param1Int1, param1Boolean1, param1Boolean2, param1Int2, param1String2); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\Tester2.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */