package com.softwareag.entirex.aci;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

abstract class y {
  public y(String paramString, int paramInt, Properties paramProperties) {}
  
  public abstract Socket b() throws IOException;
  
  public abstract ServerSocket c() throws IOException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\y.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */