package com.softwareag.entirex.aci;

import java.lang.reflect.Constructor;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NameNotFoundException;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.spi.DirObjectFactory;

public class ExxObjectFactory implements DirObjectFactory {
  private static final String a = "ExxObjectFactoryUser";
  
  private static final String b = "0250";
  
  static Class c;
  
  static Class d;
  
  public Object getObjectInstance(Object paramObject, Name paramName, Context paramContext, Hashtable paramHashtable, Attributes paramAttributes) throws Exception {
    Broker broker1 = null;
    Broker broker2 = null;
    BrokerException brokerException = null;
    if (Dump.c)
      Dump.log("ExxObjectFactory creates object for " + paramName + " in namespace '" + paramContext.getNameInNamespace() + "'"); 
    if (paramName.get(0).startsWith("sag-key=LogBrokerId=") || paramName.get(0).startsWith("sag-key=LogBrokerId\\=")) {
      Attribute attribute = paramAttributes.get("sag-value");
      if (attribute != null) {
        NamingEnumeration namingEnumeration = attribute.getAll();
        while (namingEnumeration.hasMore() && broker1 == null) {
          String str = ((String)namingEnumeration.next()).trim();
          if (Dump.c)
            Dump.log("ExxObjectFactory retrieves KERNELVERSION of " + str); 
          try {
            broker2 = new Broker(str, "ExxObjectFactoryUser");
            broker2.b();
            broker1 = broker2;
          } catch (BrokerException brokerException1) {
            if ((brokerException1.getErrorClass() == 0 && brokerException1.getErrorCode() == 0) || (brokerException1.getErrorClass() == 20 && brokerException1.getErrorCode() == 182) || (brokerException1.getErrorClass() == 79 && brokerException1.getErrorCode() == 204)) {
              broker1 = broker2;
              continue;
            } 
            if ((brokerException1.getErrorClass() == 13 && brokerException1.getErrorCode() >= 300 && brokerException1.getErrorCode() < 400) || (brokerException1.getErrorClass() == 13 && brokerException1.getErrorCode() >= 400 && brokerException1.getErrorCode() < 405))
              continue; 
            System.out.println("Error in ExxObjectFactory:" + paramName);
            throw brokerException1;
          } 
        } 
        if (broker1 == null)
          throw new BrokerException("0250", "0202", "no running broker found for '" + paramName.get(0) + "'", null, null); 
      } else {
        throw new BrokerException("0250", "0201", "no broker id found for '" + paramName.get(0) + "'", null, null);
      } 
      if (Dump.c)
        if (broker1 == null) {
          Dump.log("ExxObjectFactory (Broker): no broker found for " + paramName.get(0).substring(20));
        } else {
          Dump.log("ExxObjectFactory (Broker) uses broker with id " + ((Broker)broker1).getBrokerID());
        }  
      return broker1;
    } 
    if (paramName.get(0).startsWith("sag-key=LogService=") || paramName.get(0).startsWith("sag-key=LogService\\=") || paramName.get(0).startsWith("sag-key=Wrapper=")) {
      Object object;
      NameParser nameParser = paramContext.getNameParser("");
      Name name = nameParser.parse(paramName.get(0));
      String str1 = paramName.get(0).startsWith("sag-key=LogService") ? null : name.get(name.size() - 1).substring(16);
      String str2 = null;
      String str3 = null;
      String str4 = (str1 == null) ? "BrokerService" : "wrapped service";
      Attribute attribute = paramAttributes.get("sag-value");
      if (attribute != null) {
        NamingException namingException;
        NamingEnumeration namingEnumeration = attribute.getAll();
        while (namingEnumeration.hasMore() && broker1 == null) {
          String str = (String)namingEnumeration.next();
          if (str.startsWith("Service=")) {
            if (str2 == null || str2.length() == 0) {
              str2 = str.substring(8).replace(':', '/').trim();
              if (Dump.c)
                Dump.log("ExxObjectFactory (" + str4 + ") found service '" + str2 + "'"); 
              if (broker2 != null) {
                if (str1 == null) {
                  BrokerService brokerService = new BrokerService(broker2, str2);
                  continue;
                } 
                Class clazz = Class.forName(str1);
                if (Dump.c)
                  Dump.log("ExxObjectFactory (" + str4 + "): Creating constructor for class " + str1); 
                Constructor constructor = clazz.getConstructor(new Class[] { (c == null) ? (c = class$("com.softwareag.entirex.aci.Broker")) : c, (d == null) ? (d = class$("java.lang.String")) : d });
                if (Dump.c)
                  Dump.log("ExxObjectFactory (" + str4 + "): Creating new instance for class " + str1); 
                object = constructor.newInstance(new Object[] { broker2, str2 });
              } 
              continue;
            } 
            if (!str2.equals(str.substring(8).replace(':', '/').trim())) {
              if (Dump.c)
                Dump.log("ExxObjectFactory (" + str4 + ") found different service '" + str2 + "', '" + str.substring(8).replace(':', '/') + "'"); 
              throw new BrokerException("0250", "0204", "real service not unique for '" + paramName.get(0) + "'", null, null);
            } 
            if (Dump.c)
              Dump.log("ExxObjectFactory (" + str4 + ") found service (twice) '" + str2 + "'"); 
            if (broker2 != null) {
              if (str1 == null) {
                BrokerService brokerService = new BrokerService(broker2, str2);
                continue;
              } 
              Class clazz = Class.forName(str1);
              if (Dump.c)
                Dump.log("ExxObjectFactory (" + str4 + "): Creating constructor for class " + str1); 
              Constructor constructor = clazz.getConstructor(new Class[] { (c == null) ? (c = class$("com.softwareag.entirex.aci.Broker")) : c, (d == null) ? (d = class$("java.lang.String")) : d });
              if (Dump.c)
                Dump.log("ExxObjectFactory (" + str4 + "): Creating new instance for class " + str1); 
              object = constructor.newInstance(new Object[] { broker2, str2 });
            } 
            continue;
          } 
          if (str.startsWith("Broker=")) {
            str3 = str.substring(7).trim();
            if (Dump.c)
              Dump.log("ExxObjectFactory (" + str4 + ") found broker '" + str3 + "'"); 
            Name name1 = name.getPrefix(name.size() - 1).add("sag-key=" + a("LogBrokerId=" + str3));
            Object object1 = null;
            try {
              object1 = paramContext.lookup(name1);
            } catch (NameNotFoundException nameNotFoundException) {
              throw new BrokerException("0250", "0203", "could not resolve logical broker for '" + paramName.get(0) + "'", null, null);
            } catch (NamingException namingException1) {
              if (namingException1.getRootCause() instanceof BrokerException) {
                brokerException = (BrokerException)namingException1.getRootCause();
              } else {
                namingException = namingException1;
              } 
            } 
            if (object1 instanceof Broker) {
              broker2 = (Broker)object1;
              if (str2 != null && str2.length() > 0) {
                if (str1 == null) {
                  BrokerService brokerService = new BrokerService(broker2, str2);
                  continue;
                } 
                Class clazz = Class.forName(str1);
                if (Dump.c)
                  Dump.log("ExxObjectFactory (" + str4 + "): Creating constructor for class " + str1); 
                Constructor constructor = clazz.getConstructor(new Class[] { (c == null) ? (c = class$("com.softwareag.entirex.aci.Broker")) : c, (d == null) ? (d = class$("java.lang.String")) : d });
                if (Dump.c)
                  Dump.log("ExxObjectFactory (" + str4 + "): Creating new instance for class " + str1); 
                object = constructor.newInstance(new Object[] { broker2, str2 });
              } 
            } 
            continue;
          } 
          throw new BrokerException("0250", "0207", "description of logical service corrupt (" + str + ") for '" + paramName.get(0) + "'", null, null);
        } 
        if (str2 == null)
          throw new BrokerException("0250", "0205", "no real service found for " + paramName.get(0), null, null); 
        if (str3 == null)
          throw new BrokerException("0250", "0206", "no logical broker found for " + paramName.get(0), null, null); 
        if (broker2 == null) {
          if (namingException == null)
            throw new BrokerException("0250", "0203", "could not resolve logical broker for '" + paramName.get(0) + "'", null, null); 
          throw namingException;
        } 
      } else {
        throw new BrokerException("0250", "0205", "no real service found for " + paramName.get(0), null, null);
      } 
      if (Dump.c)
        if (object == null) {
          if (broker2 == null) {
            Dump.log("ExxObjectFactory (" + str4 + "): no broker found for " + paramName.get(0).substring(19));
          } else {
            Dump.log("ExxObjectFactory (" + str4 + "): no broker found for " + paramName.get(0).substring(19));
          } 
        } else {
          Dump.log("ExxObjectFactory (" + str4 + ") uses broker service with " + ((BrokerService)object).getServerClass() + "/" + ((BrokerService)object).getServerName() + "/" + ((BrokerService)object).getServiceName());
          Dump.log("ExxObjectFactory (" + str4 + ") uses broker with id " + ((BrokerService)object).getBroker().getBrokerID());
        }  
      return object;
    } 
    return (Object)null;
  }
  
  public Object getObjectInstance(Object paramObject, Name paramName, Context paramContext, Hashtable paramHashtable) throws Exception { return (Object)null; }
  
  private String a(String paramString) {
    StringBuffer stringBuffer = new StringBuffer(paramString);
    for (byte b1 = 0; b1 < stringBuffer.length(); b1++) {
      if (stringBuffer.charAt(b1) == ',')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '+')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '"')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '<')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '>')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == ';')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '\\' && !a(stringBuffer, b1))
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '=')
        stringBuffer.insert(b1++, '\\'); 
      if (stringBuffer.charAt(b1) == '#')
        stringBuffer.insert(b1++, '\\'); 
    } 
    return new String(stringBuffer);
  }
  
  private boolean a(StringBuffer paramStringBuffer, int paramInt) { return (paramInt < paramStringBuffer.length() - 2 && paramStringBuffer.charAt(paramInt) == '\\' && a(paramStringBuffer.charAt(paramInt + 1)) && a(paramStringBuffer.charAt(paramInt + 2))); }
  
  private boolean a(char paramChar) { return (Character.isDigit(paramChar) || (Character.isLetter(paramChar) && ((paramChar >= 'A' && paramChar <= 'F') || (paramChar >= 'a' && paramChar <= 'f')))); }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\ExxObjectFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */