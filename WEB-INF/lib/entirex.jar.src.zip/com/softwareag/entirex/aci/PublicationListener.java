package com.softwareag.entirex.aci;

public class PublicationListener extends Thread {
  private Broker a = null;
  
  private String b = null;
  
  private String c = "10S";
  
  private BrokerMessage d = null;
  
  private Publication e = null;
  
  private boolean f;
  
  private MessageListener g;
  
  private BrokerException h;
  
  public PublicationListener(Broker paramBroker, String paramString1, String paramString2, MessageListener paramMessageListener) {
    if (paramBroker == null)
      throw new IllegalArgumentException("Argument broker is null."); 
    if (paramString1 == null)
      throw new IllegalArgumentException("Argument topicName is null."); 
    if (paramString2 != null)
      this.c = paramString2; 
    this.a = paramBroker;
    this.b = paramString1;
    this.f = true;
    this.g = paramMessageListener;
  }
  
  public void run() {
    while (this.f) {
      try {
        if (this.e == null)
          this.e = new Publication(this.a, this.b); 
        this.d = this.e.receive(this.c);
        if (this.g != null)
          this.g.onMessage(this.d); 
        this;
        this;
        if (this.e.getPublicationStatus().equals("RECV_LAST") || this.e.getPublicationStatus().equals("RECV_ONLY")) {
          this.e.commit();
          this.e = new Publication(this.a, this.b);
        } 
      } catch (BrokerException brokerException) {
        this.f = false;
        this.h = brokerException;
      } 
    } 
  }
  
  public void stopListener() { this.f = false; }
  
  public BrokerException getLastException() { return this.h; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\PublicationListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */