package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.s;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

public class bn {
  private s a = s.a();
  
  private byte[] b;
  
  private String c;
  
  private Vector d = new Vector();
  
  private Vector e = new Vector();
  
  private StringBuffer f = null;
  
  private static final Hashtable g = new Hashtable();
  
  public bn() {}
  
  public bn(s params) {}
  
  public void a(s params) { this.a = params; }
  
  private void g() {
    byte b1 = 0;
    byte b2 = 0;
    com/softwareag/entirex/aci/b1 com/softwareag/entirex/aci/b1 = null;
    this.f = new StringBuffer();
    this.e.removeAllElements();
    for (byte b3 = 0; b3 < this.d.size(); b3++) {
      if ((com/softwareag/entirex/aci/b1 = (com/softwareag/entirex/aci/b1)this.d.elementAt(b3)).a(com/softwareag/entirex/aci/b1) == true) {
        if (a(com/softwareag/entirex/aci/b1.b(com/softwareag/entirex/aci/b1))) {
          this.e.addElement(com/softwareag/entirex/aci/b1.c(com/softwareag/entirex/aci/b1));
          b1++;
        } else {
          this.e.removeElementAt(--b1);
        } 
      } else {
        b2++;
        this.f.append(com/softwareag/entirex/aci/b1.b(com/softwareag/entirex/aci/b1).toString());
        for (byte b4 = 0; b4 < b1; b4++)
          this.f.append(this.e.elementAt(b4)); 
        this.f.append(com/softwareag/entirex/aci/b1.c(com/softwareag/entirex/aci/b1).toString());
      } 
    } 
    this.c = String.valueOf(b2);
    this.f.append(".");
  }
  
  private void h() {
    byte b1 = 0;
    byte b2 = 0;
    this.d.removeAllElements();
    while (b1 < this.b.length - 1) {
      com/softwareag/entirex/aci/b1 com/softwareag/entirex/aci/b1 = new com/softwareag/entirex/aci/b1(this, null);
      for (b1 = b1; b1 < this.b.length && this.b[b1] != this.a.c && this.b[b1] != this.a.e; b1++)
        com/softwareag/entirex/aci/b1.b(com/softwareag/entirex/aci/b1).append(new String(this.b, b1, 1)); 
      if (this.b[b1] == this.a.e)
        com/softwareag/entirex/aci/b1.b(com/softwareag/entirex/aci/b1).append(new String(this.b, b1++, 1)); 
      for (b1 = b1; b1 < this.b.length && this.b[b1] != this.a.c && this.b[b1] != this.a.e && a(this.b[b1]); b1++)
        com/softwareag/entirex/aci/b1.b(com/softwareag/entirex/aci/b1).append(new String(this.b, b1, 1)); 
      if (b1 < this.b.length && this.b[b1] == this.a.e)
        com/softwareag/entirex/aci/b1.c(com/softwareag/entirex/aci/b1).append(new String(this.b, b1++, 1)); 
      for (b2 = 0; b2 < 3; b2++) {
        for (b1 = b1; b1 < this.b.length && this.b[b1] != this.a.c && this.b[b1] != this.a.e && a(this.b[b1]); b1++)
          com/softwareag/entirex/aci/b1.c(com/softwareag/entirex/aci/b1).append(new String(this.b, b1, 1)); 
        if (b1 < this.b.length && this.b[b1] == this.a.e)
          com/softwareag/entirex/aci/b1.c(com/softwareag/entirex/aci/b1).append(new String(this.b, b1++, 1)); 
      } 
      com/softwareag/entirex/aci/b1.a(com/softwareag/entirex/aci/b1, b(com/softwareag/entirex/aci/b1.b(com/softwareag/entirex/aci/b1)));
      this.d.addElement(com/softwareag/entirex/aci/b1);
    } 
  }
  
  private boolean a(StringBuffer paramStringBuffer) {
    StringTokenizer stringTokenizer = new StringTokenizer(new String(paramStringBuffer), ",");
    stringTokenizer.nextToken();
    return stringTokenizer.nextToken().equals("1");
  }
  
  private boolean a(byte paramByte) { return (paramByte >= this.a.j && paramByte <= this.a.s); }
  
  private boolean b(StringBuffer paramStringBuffer) { return (paramStringBuffer.charAt(1) == 'G'); }
  
  void a() {
    this.b = new byte[1];
    this.b[0] = this.a.c;
    this.c = "0";
  }
  
  public void a(byte[] paramArrayOfByte, String paramString) {
    this.b = paramArrayOfByte;
    this.c = paramString;
  }
  
  public byte[] b() { return this.b; }
  
  int c() { return (this.b == null) ? 0 : this.b.length; }
  
  public String d() { return this.c; }
  
  byte[] e() {
    h();
    g();
    if (this.a == null || this.a.b() == null)
      return (new String(this.f)).getBytes(); 
    try {
      return (new String(this.f)).getBytes(this.a.b());
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      return null;
    } 
  }
  
  public void a(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    if (paramBoolean2 && paramInt < 1140) {
      synchronized (g) {
        byte[] arrayOfByte = (byte[])g.get(this.b);
        if (arrayOfByte == null) {
          arrayOfByte = e();
          g.put(this.b, arrayOfByte);
        } 
        this.b = arrayOfByte;
      } 
    } else if (!paramBoolean1 && paramInt == 1110) {
      int i = this.b.length;
      byte[] arrayOfByte = new byte[i];
      for (byte b1 = 0; b1 < i; b1++)
        arrayOfByte[b1] = (this.b[b1] == this.a.x) ? this.a.x : this.b[b1]; 
      this.b = arrayOfByte;
    } 
  }
  
  public long f() {
    long l = 0L;
    int i = this.b.length;
    boolean bool = false;
    for (byte b1 = 0; b1 < i; b1++) {
      if (this.b[b1] == this.a.ad) {
        bool = true;
      } else if (!bool && (this.b[b1] == this.a.w || this.b[b1] == this.a.ac || this.b[b1] == this.a.x)) {
        l++;
      } else if (this.b[b1] == this.a.ae) {
        bool = false;
      } 
    } 
    return l;
  }
  
  class com/softwareag/entirex/aci/ew {}
  
  private class com/softwareag/entirex/aci/b1 {
    private boolean a;
    
    private StringBuffer b;
    
    private StringBuffer c;
    
    private final bn d;
    
    private com/softwareag/entirex/aci/b1(bn this$0) {
      this.d = this$0;
      this.a = false;
      this.b = new StringBuffer();
      this.c = new StringBuffer();
    }
    
    static boolean a(com/softwareag/entirex/aci/b1 param1com/softwareag/entirex/aci/b1) { return param1com/softwareag/entirex/aci/b1.a; }
    
    static StringBuffer b(com/softwareag/entirex/aci/b1 param1com/softwareag/entirex/aci/b1) { return param1com/softwareag/entirex/aci/b1.b; }
    
    static StringBuffer c(com/softwareag/entirex/aci/b1 param1com/softwareag/entirex/aci/b1) { return param1com/softwareag/entirex/aci/b1.c; }
    
    com/softwareag/entirex/aci/b1(bn this$0, bn.com/softwareag/entirex/aci/ew param1com/softwareag/entirex/aci/ew) { this(this$0); }
    
    static boolean a(com/softwareag/entirex/aci/b1 param1com/softwareag/entirex/aci/b1, boolean param1Boolean) { return param1com/softwareag/entirex/aci/b1.a = param1Boolean; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\bn.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */