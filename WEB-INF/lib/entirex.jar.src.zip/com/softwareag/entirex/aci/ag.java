package com.softwareag.entirex.aci;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

class ag implements Runnable {
  private String a;
  
  private static boolean b = false;
  
  private static ThreadGroup c = new ThreadGroup("BrokerAgent Control Threads");
  
  ag(String paramString) {
    if (paramString != null && paramString.length() > 0) {
      try {
        int j = paramString.indexOf("?");
        if (j >= 0) {
          Integer.parseInt(paramString.substring(0, j));
        } else {
          Integer.parseInt(paramString);
        } 
        paramString = ":" + paramString;
      } catch (NumberFormatException numberFormatException) {}
      int i = paramString.toLowerCase().indexOf("poolsize");
      if (i < 0) {
        int j = paramString.indexOf("?");
        String str = (j >= 0) ? "&" : "?";
        paramString = paramString + str + "poolsize=0";
      } 
    } 
    this.a = paramString;
  }
  
  public void run() {
    try {
      v v = new v(this.a);
      ServerSocket serverSocket = v.n();
      serverSocket.setSoTimeout(30000);
      System.out.println("EntireX BrokerAgent Control, Commands accepted on port " + serverSocket.getLocalPort());
      do {
        try {
          Socket socket = serverSocket.accept();
          v v1 = new v(socket);
          InetAddress inetAddress = socket.getInetAddress();
          String str = inetAddress.getHostName() + '[' + socket.getPort() + ']';
          synchronized (c) {
            Thread thread = new Thread(c, new p(v1, true), str);
            System.out.println();
            System.out.println("Command Connection accepted from " + str);
            thread.start();
          } 
        } catch (InterruptedIOException interruptedIOException) {}
      } while (!b);
      serverSocket.close();
      System.out.println("...BrokerAgentControl stopped serving commands.");
    } catch (IOException iOException) {
      System.out.println("BrokerAgent Error: " + iOException.toString());
    } 
  }
  
  static void a(boolean paramBoolean) { b = paramBoolean; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\ag.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */