package com.softwareag.entirex.aci;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

public final class ConversationState implements Serializable {
  static final long serialVersionUID = -6736846114269261741L;
  
  private static final boolean a = true;
  
  private String b;
  
  private String c;
  
  private long d;
  
  public static ConversationState restoreFromTicket(String paramString) throws IllegalArgumentException {
    ConversationState conversationState = new ConversationState();
    conversationState.b = paramString;
    conversationState.b();
    return conversationState;
  }
  
  private ConversationState() {}
  
  ConversationState(String paramString) throws IllegalArgumentException {
    if (paramString == null || paramString.length() != 16)
      throw new IllegalArgumentException("ConversationState: illegal ConvID \"" + paramString + '"'); 
    this.c = paramString;
    this.b = paramString;
  }
  
  String a() { return this.c; }
  
  private void b() {
    if (this.b == null || this.b.length() != 16)
      throw new IllegalArgumentException("ConversationState.restoreTicket: \"" + this.b + "\" is not a ticket"); 
    this.c = this.b;
  }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
    paramObjectInputStream.defaultReadObject();
    b();
  }
  
  public String toString() { return this.b; }
  
  public String getTicket() { return this.b; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\ConversationState.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */