package com.softwareag.entirex.aci;

public class BrokerTopic extends BrokerService {
  private static final String a = "BrokerTopic constructor: ";
  
  public BrokerTopic(Broker paramBroker, String paramString) {
    if (paramBroker == null)
      throw new IllegalArgumentException("BrokerTopic constructor: no Broker specified"); 
    if (!paramBroker.c())
      throw new IllegalStateException("BrokerTopic constructor: Broker does not support Publish & Subscribe"); 
    if (paramString == null)
      throw new IllegalArgumentException("BrokerTopic constructor: invalid topic name specified"); 
    a("JMS/" + paramString + "/TOPIC");
    a(paramBroker);
    paramBroker.a(true);
  }
  
  public final void subscribe(boolean paramBoolean) throws BrokerException {
    byte[] arrayOfByte = paramBoolean ? q.a9 : null;
    a(arrayOfByte);
  }
  
  public final void unsubscribe() throws BrokerException { deregister(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\BrokerTopic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */