package com.softwareag.entirex.aci;

public class Publication {
  public static final String MSG_ONLY = "RECV_ONLY";
  
  public static final String MSG_LAST = "RECV_LAST";
  
  public static final String MSG_FIRST = "RECV_FIRST";
  
  public static final String MSG_MIDDLE = "RECV_MIDDLE";
  
  private Broker a;
  
  private byte[] b;
  
  private String c;
  
  private boolean d;
  
  private q e;
  
  private String f;
  
  private String g;
  
  private String h;
  
  private int i = 7168;
  
  public Publication(Broker paramBroker, String paramString) {
    if (paramBroker == null)
      throw new IllegalArgumentException("Argument 'broker' is null."); 
    this.a = paramBroker;
    this.e = paramBroker.a();
    this.b = paramString.getBytes();
    this.d = true;
  }
  
  public void publish(BrokerMessage paramBrokerMessage) throws BrokerException {
    if (paramBrokerMessage == null)
      throw new IllegalArgumentException("publish: message is null."); 
    synchronized (this.e) {
      this.e.u();
      if (this.d)
        this.c = "NEW"; 
      this.e.c(this.b);
      this.e.a(paramBrokerMessage.getMessage());
      if (this.f != null)
        this.e.b(this.f.getBytes()); 
      this.e.f(this.h);
      this.e.a(this.c, null);
      String str = this.e.h();
      if (this.d) {
        this.c = str;
        this.d = false;
      } else if (!str.equals(this.c)) {
        BrokerException.a("0113", new String[] { this.c, str });
      } 
      this.g = this.e.n();
      this.h = this.e.p();
    } 
  }
  
  public BrokerMessage receive() throws BrokerException { return receive("NO"); }
  
  public BrokerMessage receive(String paramString) throws BrokerException {
    BrokerMessage brokerMessage = null;
    synchronized (this.e) {
      this.e.u();
      if (this.d)
        this.c = "NEW"; 
      this.e.c(this.b);
      this.e.h(paramString);
      if (this.f != null)
        this.e.b(this.f.getBytes()); 
      this.e.f(this.h);
      this.e.a(getReceiveLength());
      this.e.a(true);
      this.e.j(this.c);
      brokerMessage = new BrokerMessage(this.e.a());
      String str = this.e.h();
      if (this.d) {
        this.c = str;
        this.d = false;
      } else if (!str.equals(this.c)) {
        BrokerException.a("0113", new String[] { this.c, str });
      } 
      this.g = this.e.n();
      this.i = this.e.b();
      byte[] arrayOfByte = this.e.j();
      if (arrayOfByte != null)
        this.f = new String(this.e.j()); 
      this.h = this.e.p();
    } 
    return brokerMessage;
  }
  
  public void subscribe(boolean paramBoolean) throws BrokerException {
    synchronized (this.e) {
      this.e.u();
      this.e.c(this.b);
      this.e.c(paramBoolean);
    } 
  }
  
  public void unsubscribe() throws BrokerException {
    synchronized (this.e) {
      this.e.u();
      this.e.c(this.b);
      this.e.x();
    } 
  }
  
  public void commit() throws BrokerException {
    synchronized (this.e) {
      this.e.u();
      this.e.f(this.h);
      this.e.a(this.c, q.az, null);
      this.g = this.e.n();
      this.h = this.e.p();
    } 
  }
  
  public void backout() throws BrokerException {
    synchronized (this.e) {
      this.e.u();
      this.e.f(this.h);
      this.e.a(this.c, q.a0, null);
      this.g = this.e.n();
      this.h = this.e.p();
    } 
  }
  
  public String last() throws BrokerException {
    synchronized (this.e) {
      this.e.u();
      this.e.f(this.h);
      this.e.a(this.c, q.aw, null);
      this.g = this.e.n();
      this.h = this.e.p();
    } 
    return this.g;
  }
  
  public String getPublicationStatus() throws BrokerException { return this.g; }
  
  public String query() throws BrokerException {
    synchronized (this.e) {
      this.e.u();
      this.e.f(this.h);
      this.e.a(this.c, q.a3, null);
      this.g = this.e.n();
      this.h = this.e.p();
    } 
    return this.g;
  }
  
  public void setUserStatus(String paramString) throws BrokerException {
    synchronized (this.e) {
      this.e.u();
      this.e.f(paramString);
      this.e.a(this.c, q.a8, paramString);
      this.g = this.e.n();
      paramString = this.e.p();
    } 
  }
  
  public int getReceiveLength() { return this.i; }
  
  public void setReceiveLength(int paramInt) { this.i = paramInt; }
  
  public String getPublicationId() throws BrokerException { return this.c; }
  
  public void setPublicationId(String paramString) throws BrokerException {
    this.c = paramString;
    this.d = false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\Publication.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */