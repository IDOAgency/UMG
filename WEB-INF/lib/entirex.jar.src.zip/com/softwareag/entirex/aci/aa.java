package com.softwareag.entirex.aci;

public class com/softwareag/entirex/aci/aa extends Thread {
  private String a;
  
  private final w b;
  
  public com/softwareag/entirex/aci/aa(w paramw) { this.b = paramw; }
  
  public void a(String paramString) { this.a = paramString; }
  
  public void run() {
    long l = w.a(this.b) / 2L;
    if (Dump.c)
      Dump.log("CleanupPool for \"" + this.a + "\": started, timeout = " + w.a(this.b) + " ms"); 
    while (true) {
      synchronized (this) {
        try {
          wait(l);
          w.b(this.b);
        } catch (InterruptedException interruptedException) {}
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\aa.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */