package com.softwareag.entirex.aci;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UnitofWork extends BrokerCommunication {
  public UnitofWork(BrokerService paramBrokerService) {
    super(paramBrokerService);
    this.g = true;
  }
  
  public UnitofWork(BrokerService paramBrokerService, ConversationState paramConversationState) throws IllegalArgumentException {
    super(paramBrokerService, paramConversationState);
    this.g = true;
  }
  
  UnitofWork(BrokerService paramBrokerService, String paramString) throws BrokerException {
    super(paramBrokerService, paramString);
    this.g = true;
  }
  
  public void setDataPersistence(boolean paramBoolean) {
    if (paramBoolean) {
      this.h = "BROKER";
    } else {
      this.h = "OFF";
    } 
  }
  
  public void setStatusPersistence(boolean paramBoolean) {
    if (paramBoolean) {
      if (this.k == 0 || this.k == 255)
        this.k = 1; 
    } else {
      this.k = 255;
    } 
  }
  
  public void setStatusPersistence(int paramInt) {
    if (paramInt < 1 || paramInt > 254)
      throw new IllegalArgumentException("setStatusPersistence: argument not between 1 and 254"); 
    this.k = paramInt;
  }
  
  public void setStatusPersistence(String paramString) { this.l = paramString; }
  
  public String getStatus() { return this.i; }
  
  void a(String paramString) { this.i = paramString; }
  
  public void setLifetime(String paramString) { this.j = paramString; }
  
  public String getLifetime() { return this.j; }
  
  public String getUnitofWorkID() { return this.n; }
  
  void b(String paramString) { this.n = paramString; }
  
  public void setUserStatus(String paramString) {
    if (paramString != null && paramString.length() > 32)
      throw new IllegalArgumentException("setUserStatus: argument exceeds 32 chars"); 
    this.o = paramString;
  }
  
  public String getUserStatus() { return this.o; }
  
  public int getAttemptedDeliveryCount() { return this.m; }
  
  public void send(BrokerMessage paramBrokerMessage) throws BrokerException {
    a(paramBrokerMessage, null, true, q.a2);
    this.p = true;
  }
  
  public void sendCommit(BrokerMessage paramBrokerMessage) throws BrokerException {
    a(paramBrokerMessage, null, true, q.az);
    this.p = false;
  }
  
  public void backout() throws BrokerException {
    c(q.a0);
    this.p = false;
  }
  
  public void cancel() throws BrokerException { c(q.av); }
  
  public void commit() throws BrokerException {
    c(q.az);
    this.p = false;
  }
  
  public void commitBoth() throws BrokerException {
    c(q.a5);
    this.p = false;
  }
  
  public void delete() throws BrokerException { BrokerCommunication.a(getUnitofWorkID(), getBrokerService().getBroker()); }
  
  public static void delete(String paramString, Broker paramBroker) throws BrokerException { BrokerCommunication.a(paramString, paramBroker); }
  
  public void commitEndConversation() throws BrokerException {
    c(q.a6);
    this.p = false;
  }
  
  public void commitCancelConversation() throws BrokerException {
    c(q.a7);
    this.p = false;
  }
  
  public static UnitofWork queryLast(BrokerService paramBrokerService) throws BrokerException {
    if (paramBrokerService.isGeneric())
      throw new IllegalArgumentException("queryLast: generic Service not possible"); 
    return BrokerCommunication.a(true, null, paramBrokerService);
  }
  
  public static UnitofWork queryLast(Broker paramBroker) throws BrokerException { return BrokerCommunication.a(true, null, paramBroker); }
  
  public UnitofWork query() throws BrokerException { return BrokerCommunication.a(false, getUnitofWorkID(), getBrokerService()); }
  
  public static UnitofWork query(String paramString, BrokerService paramBrokerService) throws BrokerException {
    if (paramBrokerService.isGeneric())
      throw new IllegalArgumentException("query: generic Service not possible"); 
    return BrokerCommunication.a(false, paramString, paramBrokerService);
  }
  
  public static UnitofWork query(String paramString, Broker paramBroker) throws BrokerException { return BrokerCommunication.a(false, paramString, paramBroker); }
  
  public void updateUserStatus() throws BrokerException { c(q.a8); }
  
  public BrokerMessage receive(String paramString) throws BrokerException { return a(paramString, null); }
  
  public BrokerMessage receive() throws BrokerException { return a(this.b.getDefaultWaittime(), null); }
  
  public static BrokerMessage receiveOld(BrokerService paramBrokerService, String paramString) throws BrokerException {
    if (paramBrokerService == null)
      throw new IllegalArgumentException("receiveOld: no BrokerService specified"); 
    return paramBrokerService.a(paramString, "OLD", q.a2);
  }
  
  public static BrokerMessage receiveOld(BrokerService paramBrokerService) throws BrokerException {
    if (paramBrokerService == null)
      throw new IllegalArgumentException("receiveOld: no BrokerService specified"); 
    return paramBrokerService.a(paramBrokerService.getDefaultWaittime(), "OLD", q.a2);
  }
  
  public static BrokerMessage receiveAny(BrokerService paramBrokerService, String paramString) throws BrokerException {
    if (paramBrokerService == null)
      throw new IllegalArgumentException("receiveAny: no BrokerService specified"); 
    return paramBrokerService.a(paramString, "ANY", q.a2);
  }
  
  public static BrokerMessage receiveAny(BrokerService paramBrokerService) throws BrokerException {
    if (paramBrokerService == null)
      throw new IllegalArgumentException("receiveAny: no BrokerService specified"); 
    return paramBrokerService.a(paramBrokerService.getDefaultWaittime(), "ANY", q.a2);
  }
  
  public void endConversation() throws BrokerException { a(null); }
  
  public Date getCommitTimestamp() {
    String str = getCommitTimestampString();
    Date date = (Date)null;
    if (str != null) {
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSSz");
      try {
        date = simpleDateFormat.parse(str);
      } catch (ParseException parseException) {}
    } 
    return date;
  }
  
  public String getCommitTimestampString() {
    String str = this.b.getBroker().a().r();
    if (str != null)
      str = str + "-0000"; 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\UnitofWork.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */