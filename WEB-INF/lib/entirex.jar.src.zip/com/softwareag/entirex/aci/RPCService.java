package com.softwareag.entirex.aci;

import com.softwareag.entirex.base.ac;
import com.softwareag.entirex.base.r;
import com.softwareag.entirex.trace.Trace;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Hashtable;

public abstract class RPCService extends BrokerService {
  private static final int a = 2000;
  
  private static final int b = 0;
  
  private static final int c = 4;
  
  private static final int d = 12;
  
  private static final int e = 5;
  
  private static final int f = 32;
  
  private static final int g = 8;
  
  private static final int h = 40;
  
  private static final int i = 8;
  
  private static final int j = 48;
  
  private static final int k = 16;
  
  private static final int l = 67;
  
  private static final int m = 2;
  
  private static final int n = 69;
  
  private static final int o = 4;
  
  private static final int p = 73;
  
  private static final int q = 83;
  
  private static final int r = 77;
  
  private static final int s = 192;
  
  private static final int t = 92;
  
  private static final int u = 80;
  
  private static final int v = 2;
  
  private static final int w = 9;
  
  private static final int x = 19;
  
  private static final int y = 29;
  
  private static final int z = 39;
  
  private static final int aa = 49;
  
  private static final int ab = 59;
  
  private static final int ac = 69;
  
  private static final int ad = 4;
  
  private static final int ae = 73;
  
  private static final int af = 4;
  
  private static final int ag = 82;
  
  private static final String ah = "0000";
  
  private static final String ai = "0007";
  
  private static final String aj = "0008";
  
  private static final String ak = "0009";
  
  private static final String al = "0010";
  
  private static final String am = "0011";
  
  private static final String an = "0016";
  
  private static final String ao = "0018";
  
  private static final String ap = "0028";
  
  private static final String aq = "0036";
  
  private static final String ar = "0037";
  
  private static final String as = "00000";
  
  private static final String at = "00082";
  
  private static final String au = "00954";
  
  private static final String av = "  ";
  
  private static final String aw = "CC";
  
  private static final String ax = "NC";
  
  private static final String ay = "OC";
  
  private static final String az = "CB";
  
  private static final String a0 = "CE";
  
  private static final String a1 = "CO";
  
  private static final String a2 = "IN";
  
  bl a3 = new bl();
  
  private static final boolean a4 = Trace.on(2, "RPCService");
  
  String a5 = null;
  
  private boolean a6 = false;
  
  private static final String a7 = EntireXVersion.getVersion() + " " + System.getProperty("os.name") + " " + System.getProperty("os.version") + " " + System.getProperty("os.arch") + ".";
  
  private static final String a8 = "EntireX Java RPC Server " + a7;
  
  private static final String a9 = "EntireX Java RPC Client " + a7;
  
  protected final Marshal marshal = new Marshal();
  
  private final Marshal ba = new Marshal();
  
  final bn bb = new bn();
  
  private final StringBuffer bc = new StringBuffer();
  
  private final Hashtable bd = new Hashtable();
  
  private String be = null;
  
  private String bf = null;
  
  private q bg = null;
  
  private String bh = null;
  
  private String bi;
  
  private String bj;
  
  private boolean bk = false;
  
  private char bl = ':';
  
  protected boolean compression;
  
  private boolean bm;
  
  private int bn = 0;
  
  private int bo = 0;
  
  private int bp = -1;
  
  private byte[] bq;
  
  private int br;
  
  private int bs;
  
  private boolean bt;
  
  private static final int bu = 31647;
  
  private BrokerMessage bv = new BrokerMessage();
  
  private Conversation bw;
  
  private int bx;
  
  private Conversation by = null;
  
  private String bz;
  
  private int b0;
  
  private static String b1 = null;
  
  private static final String[] b2 = { "LB", "PM", "ET", "CO" };
  
  public bl getController() { return this.a3; }
  
  public final void setRPCUserId(String paramString) { this.be = paramString; }
  
  public final String getRPCUserId() { return this.be; }
  
  public final void setRPCPassword(String paramString) { this.bf = paramString; }
  
  public final String getRPCPassword() { return this.bf; }
  
  public final void setBroker(Broker paramBroker) throws BrokerException {
    if (this.by != null)
      BrokerException.a("0216", null); 
    a(paramBroker);
    if (paramBroker == null) {
      this.bg = null;
      this.be = null;
      this.bf = null;
      this.a3.a(null);
    } else {
      this.bg = paramBroker.a();
      this.be = paramBroker.d;
      this.bf = paramBroker.e;
      this.a3.a(this);
    } 
    this.bp = -1;
  }
  
  public final void setServerAddress(String paramString) {
    if (this.by != null)
      BrokerException.a("0216", null); 
    this.bh = paramString;
    try {
      a(paramString);
    } catch (IllegalArgumentException illegalArgumentException) {
      this.bh = null;
    } 
    Broker broker = getBroker();
    if (broker != null && paramString != null) {
      this.a3.a(this);
    } else {
      this.a3.a(null);
    } 
    this.bp = -1;
  }
  
  protected RPCService(Broker paramBroker, String paramString1, String paramString2, boolean paramBoolean) {
    this(paramBroker, paramString1, paramString2);
    this.compression = paramBoolean;
    this.bm = paramBoolean;
  }
  
  protected RPCService(BrokerService paramBrokerService, String paramString, boolean paramBoolean) {
    this(paramBrokerService.getBroker(), paramBrokerService.getServerClass() + "/" + paramBrokerService.getServerName() + "/" + paramBrokerService.getServiceName(), paramString);
    this.compression = paramBoolean;
    this.bm = paramBoolean;
  }
  
  protected RPCService(Broker paramBroker, String paramString1, String paramString2) {
    super(paramBroker, paramString1);
    this.bg = paramBroker.a();
    this.be = paramBroker.d;
    this.bf = paramBroker.e;
    this.bh = paramString1;
    setAdjustReceiveLen(true);
    this.bi = paramString2;
    this.a3.a(this);
  }
  
  protected RPCService() {
    setAdjustReceiveLen(true);
    this.a3.a(null);
  }
  
  public final void setLibraryName(String paramString) { this.bi = paramString; }
  
  public final String getLibraryName() { return this.bi; }
  
  final String j() { return this.bj; }
  
  public final void setNaturalLogon(boolean paramBoolean) { setNaturalLogon(paramBoolean, ':'); }
  
  protected void setNaturalLogon(boolean paramBoolean, char paramChar) {
    this.bl = paramChar;
    this.bk = paramBoolean;
  }
  
  public final boolean getNaturalLogon() { return this.bk; }
  
  public final void setCompression(boolean paramBoolean) {
    this.compression = paramBoolean;
    this.bm = paramBoolean;
  }
  
  public final boolean getCompression() { return this.compression; }
  
  protected final void setCompression2() {
    this.compression = true;
    this.bm = true;
  }
  
  private final int e() { return this.bn; }
  
  private final void a(int paramInt) { this.bn = paramInt; }
  
  protected final int getVersion() { return this.bo; }
  
  public int findRpcVersion(int paramInt) throws BrokerException {
    switch (paramInt) {
      case 1120:
        if (this.bk)
          paramInt = 1130; 
        break;
      case 1110:
        if (this.bk) {
          paramInt = 1130;
          break;
        } 
        if (this.compression)
          paramInt = 1120; 
        break;
    } 
    this.bo = this.a3.a(paramInt, this.bn, this.bp, 2000, this.bi, this);
    return this.bo;
  }
  
  protected int getReceiveLen() { return this.br; }
  
  private void a(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, int paramInt, boolean paramBoolean) throws BrokerException {
    if (a4) {
      Trace.enterMethod(Trace.M4, 2, 20, 59);
      Trace.parameter(Trace.MP4, 2, 20, 59, "libName", paramString1);
      Trace.parameter(Trace.MP4, 2, 20, 59, "progName", paramString2);
      Trace.parameter(Trace.MP4, 2, 20, 59, "userId", paramString3);
      Trace.parameter(Trace.MP4, 2, 20, 59, "callType", paramString4);
      Trace.parameter(Trace.MP4, 2, 20, 59, "compression", paramString5);
      Trace.parameter(Trace.MP4, 2, 20, 59, "natLogon", paramString6);
      Trace.parameter(Trace.MP4, 2, 20, 59, "formatLen", paramInt);
      Trace.parameter(Trace.MP4, 2, 20, 59, "isClient", paramBoolean);
      Trace.checkpoint(Trace.CP3, 2, 20, 59, "rpcVersion", this.bo);
    } 
    this.a6 = paramBoolean;
    this.marshal.d();
    this.bc.setLength(0);
    if (getVersion() < 2000) {
      if (a4)
        Trace.checkpoint(Trace.CP3, 2, 20, 59, "before RPC 2000"); 
      this.marshal.b(Integer.toString(this.bo));
      if (paramInt > 0) {
        this.marshal.a(this.bb.d(), 8);
      } else {
        this.marshal.c(8);
      } 
      this.marshal.c(9);
      this.marshal.d(9);
      this.marshal.c(2);
      this.marshal.b(paramString1, 8);
      this.marshal.b(paramString2, 8);
      this.marshal.b(paramString3, 16);
      this.marshal.d(3);
      this.marshal.b(paramString4, 2);
      this.marshal.c(4);
      this.marshal.b(paramString5, 1);
      this.marshal.b(paramString6, 3);
      this.marshal.c(18);
      this.marshal.d(97);
    } else {
      if (a4)
        Trace.checkpoint(Trace.CP3, 2, 20, 59, "since RPC 2000"); 
      this.marshal.a(2000);
      if (paramBoolean) {
        if (paramString4.equalsIgnoreCase("NC") || paramString4.equalsIgnoreCase("OC")) {
          a(this.bc, "LB", paramString1);
          a(this.bc, "UID", paramString3);
        } else if (paramString1 != null) {
          a(this.bc, "LB", paramString1);
        } 
        if (paramString4.equalsIgnoreCase("NC") || paramString4.equalsIgnoreCase("  ") || paramString4.equalsIgnoreCase("CC")) {
          a(this.bc, "PM", paramString2);
        } else if (paramString2 != null) {
          a(this.bc, "PM", paramString2);
        } 
        a(this.bc, "PT", a9);
      } else {
        a(this.bc, "PT", a8);
        if (paramString1 != null)
          a(this.bc, "LB", paramString1); 
        if (paramString2 != null)
          a(this.bc, "PM", paramString2); 
      } 
      if (this.bk) {
        if (a4)
          Trace.checkpoint(Trace.CP3, 2, 20, 59, "RPC 2000 && natLogon"); 
        a(this.bc, "NS", bu.a(this.bi, paramString3, this.bf));
      } 
      int i1 = this.bc.length();
      if (a4)
        Trace.checkpoint(Trace.CP3, 2, 20, 59, "SB(" + i1 + ")=" + this.bc.toString()); 
      this.marshal.b("2000");
      this.marshal.c("*RPC*");
      if (paramString4.equalsIgnoreCase("CB") || paramString4.equalsIgnoreCase("CE") || paramString4.equalsIgnoreCase("CO")) {
        this.marshal.a(String.valueOf(92), 10);
        this.marshal.a(String.valueOf(i1), 10);
        this.marshal.c(10);
        this.marshal.c(10);
        this.marshal.c(10);
        this.marshal.c(10);
      } else {
        this.marshal.a(String.valueOf(92), 10);
        this.marshal.a(String.valueOf(i1), 10);
        this.marshal.a(String.valueOf(92 + i1), 10);
        this.marshal.a(String.valueOf(paramInt), 10);
        this.marshal.a(String.valueOf(92 + i1 + paramInt), 10);
        this.marshal.c(10);
      } 
      this.marshal.c(4);
      this.marshal.c(4);
      this.marshal.d(3);
      this.marshal.b(paramString4, 2);
      if (paramInt > 0) {
        this.marshal.a(this.bb.d(), 10);
      } else {
        this.marshal.c(10);
      } 
      this.marshal.c(this.bc.toString());
    } 
    if (a4) {
      Trace.parameter(Trace.MB4, 2, 20, 59, "Header + StringBuffer", this.marshal.e());
      Trace.leaveMethod(Trace.M4, 2, 20, 59);
    } 
  }
  
  protected final void buildHeader(byte[] paramArrayOfByte, String paramString1, int paramInt1, int paramInt2, int paramInt3, String paramString2, boolean paramBoolean) throws BrokerException { buildHeader(paramArrayOfByte, paramString1, paramInt2, paramInt3, paramString2, paramBoolean, 1110, false, false); }
  
  protected final void buildHeader(byte[] paramArrayOfByte, String paramString1, int paramInt1, int paramInt2, String paramString2, boolean paramBoolean1, int paramInt3, boolean paramBoolean2, boolean paramBoolean3, int paramInt4) throws BrokerException {
    a(paramInt4);
    buildHeader(paramArrayOfByte, paramString1, paramInt1, paramInt2, paramString2, paramBoolean1, paramInt3, paramBoolean2, paramBoolean3);
  }
  
  protected final void buildHeader(byte[] paramArrayOfByte, String paramString1, int paramInt1, int paramInt2, String paramString2, boolean paramBoolean1, int paramInt3, boolean paramBoolean2, boolean paramBoolean3) throws BrokerException {
    if (a4)
      Trace.enterMethod(Trace.M4, 2, 20, 60); 
    this.a6 = paramBoolean1;
    if (paramBoolean1 && (this.bg == null || this.bh == null))
      BrokerException.a("0215", null); 
    this.bt = paramBoolean3;
    this.bj = paramString2;
    if (paramBoolean1)
      try {
        findRpcVersion(paramInt3);
      } catch (BrokerException brokerException) {
        if (brokerException.getErrorClass() == 1001 && brokerException.getErrorCode() == 16)
          throw new BrokerException("1001", "0016", "Callee not found. Library: " + this.bi + ", Program: " + paramString2 + ", " + brokerException.getMessage(), null, null); 
        throw brokerException;
      }  
    if (paramBoolean1)
      if (this.bo >= 1140) {
        this.compression = true;
        this.bm = true;
      } else if (this.bg.em) {
        this.bm = true;
      }  
    String str1 = " ";
    if (this.compression)
      if (this.bm) {
        str1 = "2";
      } else {
        str1 = "1";
      }  
    String str2 = "NC";
    if (this.by != null) {
      if (a4)
        Trace.checkpoint(Trace.CP3, 2, 20, 60, "Conversation: " + this.by.toString()); 
      if (this.by.d || (!paramBoolean1 && this.a5.equals("OC"))) {
        if (a4)
          Trace.checkpoint(Trace.CP3, 2, 20, 60, "Conversation is new"); 
        str2 = "OC";
      } else {
        if (a4)
          Trace.checkpoint(Trace.CP3, 2, 20, 60, "Conversation is not new"); 
        if (this.bo >= 2000) {
          str2 = "CC";
        } else {
          str2 = "  ";
        } 
      } 
    } 
    String str3 = null;
    if (this.bk)
      str3 = " Y "; 
    int i1 = 0;
    if (paramBoolean1 || !this.compression || this.bm) {
      this.bb.a(paramArrayOfByte, paramString1);
      this.bb.a(this.bo, this.compression, paramBoolean2);
      i1 = this.bb.c();
    } 
    a(this.bi, paramString2, this.be, str2, str1, str3, i1, paramBoolean1);
    if (i1 > 0)
      this.marshal.a(this.bb.b()); 
    if (paramBoolean1)
      if (this.compression && !this.bm) {
        this.br = 192 + paramInt1 + paramInt2;
        this.bs = 192;
      } else {
        this.br = 192 + i1 + paramInt1 + paramInt2;
        this.bs = 192 + i1;
      }  
    if (a4)
      Trace.leaveMethod(Trace.M4, 2, 20, 60); 
  }
  
  protected final void callServer() { a(false, false); }
  
  protected final void callServerRetry() { a(false, true); }
  
  private BrokerMessage a(Conversation paramConversation, BrokerMessage paramBrokerMessage, boolean paramBoolean) throws BrokerException {
    BrokerMessage brokerMessage = null;
    if (a4) {
      Trace.enterMethod(Trace.M4, 2, 20, 61);
      Trace.parameter(Trace.MB4, 2, 20, 61, "send", paramBrokerMessage.getMessage());
    } 
    if (!paramBoolean) {
      if (paramConversation == null) {
        brokerMessage = sendReceive(paramBrokerMessage);
        if (a4) {
          Trace.parameter(Trace.MB4, 2, 20, 61, "receive", brokerMessage.getMessage());
          Trace.leaveMethod(Trace.M4, 2, 20, 61);
        } 
        return brokerMessage;
      } 
      brokerMessage = paramConversation.sendReceive(paramBrokerMessage);
      if (a4) {
        Trace.parameter(Trace.MB4, 2, 20, 61, "receive", brokerMessage.getMessage());
        Trace.checkpoint(Trace.CP4, 2, 20, 61, "conversational");
        Trace.leaveMethod(Trace.M4, 2, 20, 61);
      } 
      return brokerMessage;
    } 
    try {
      return a(paramConversation, paramBrokerMessage, false);
    } catch (BrokerException brokerException) {
      if (onRetry(this.bj, brokerException))
        return a(paramConversation, paramBrokerMessage, false); 
      throw brokerException;
    } 
  }
  
  protected int getSendLen() { return this.bx; }
  
  private void a(boolean paramBoolean1, boolean paramBoolean2) throws BrokerException {
    BrokerMessage brokerMessage;
    if (a4) {
      Trace.enterMethod(Trace.M4, 2, 20, 62);
      Trace.parameter(Trace.MP4, 2, 20, 62, "inquireCall", paramBoolean1);
      Trace.parameter(Trace.MP4, 2, 20, 62, "retry", paramBoolean2);
    } 
    String str = "";
    if (this.bk && this.bo >= 1130 && this.bo < 2000) {
      str = bu.a(this.bi, this.be, this.bf);
      this.marshal.a(c(str));
    } 
    byte[] arrayOfByte = this.marshal.e();
    this.marshal.d();
    this.bx = arrayOfByte.length;
    if (this.bk && this.bo >= 1130 && this.bo < 2000) {
      this.marshal.a(Integer.toString((this.bx - str.length()) % 1000000), 6);
      this.marshal.a(arrayOfByte, 83);
    } 
    if (this.bo >= 2000) {
      int i1 = arrayOfByte.length - this.bb.c() + this.bc.length() + 92;
      if (i1 < 0)
        i1 = 0; 
      if (a4) {
        Trace.checkpoint(Trace.CP3, 2, 20, 62, "Header length", "92 Bytes.");
        Trace.checkpoint(Trace.CP3, 2, 20, 62, "String Buffer length", this.bc.length() + " Bytes.");
        Trace.checkpoint(Trace.CP3, 2, 20, 62, "Format Buffer length", this.bb.c() + " Bytes.");
        Trace.checkpoint(Trace.CP3, 2, 20, 62, "Value Buffer length", i1 + " Bytes.");
        Trace.checkpoint(Trace.CP3, 2, 20, 62, "Send  Buffer length", arrayOfByte.length + " Bytes.");
      } 
      if (i1 < 0)
        i1 = 0; 
      this.marshal.d();
      this.marshal.a(Integer.toString(i1), 10);
      this.marshal.a(arrayOfByte, 59);
    } 
    this.bv.setMessage(arrayOfByte);
    arrayOfByte = null;
    if (this.bt) {
      if (this.br < this.bx)
        this.br = this.bx + this.bx / 10; 
    } else if (!this.compression) {
      this.br = this.bx;
    } 
    if (this.br > getMaxReceiveLen())
      setMaxReceiveLen(this.br); 
    if (paramBoolean1)
      this.bo = 1140; 
    if (this.by != null && !paramBoolean1) {
      brokerMessage = a(this.by, this.bv, paramBoolean2);
    } else if (this.bt && this.bg.v() < 5 && !paramBoolean1) {
      this.bw = new Conversation(this);
      brokerMessage = a(this.bw, this.bv, paramBoolean2);
      this.bw.end();
    } else {
      brokerMessage = a(null, this.bv, paramBoolean2);
    } 
    this.bv.setMessage((byte[])null);
    if (brokerMessage == null)
      BrokerException.a("0201", null); 
    this.bq = brokerMessage.getMessage();
    if (this.bo >= 2000) {
      this.bs = ac.a(this.bq, 49, 10, super.o);
      if (a4)
        Trace.checkpoint(Trace.CP3, 2, 20, 62, "receiveIndex: " + this.bs); 
    } 
    this.marshal.setBuffer(this.bq, this.bs);
    if ((this.bq.length < 192 && this.bo < 2000) || (this.bq.length < 92 && this.bo >= 2000))
      BrokerException.a("0202", new String[] { Integer.toString(this.bq.length) }); 
    this.a3.a(this.bq, this.bi, this.bj, super.o);
    if (a4) {
      Trace.parameter(Trace.MP4, 2, 20, 62, "index", this.marshal.a());
      Trace.leaveMethod(Trace.M4, 2, 20, 62);
    } 
  }
  
  public final void setConversation(Conversation paramConversation) {
    if (paramConversation == null)
      throw new IllegalArgumentException("setConversation: no Conversation object"); 
    paramConversation.a(this);
    this.by = paramConversation;
  }
  
  protected final Conversation k() { return this.by; }
  
  private void b(String paramString) {
    if (this.by == null)
      throw new BrokerException("1001", "0036", "Conversation already closed", null, null); 
    if (this.by.d) {
      this.by = null;
    } else {
      this.bb.a((byte[])null, "");
      findRpcVersion(1110);
      a(null, null, null, paramString, " ", null, 0, this.a6);
      try {
        a(false, false);
        this.by.end();
        this.by = null;
      } catch (BrokerException brokerException) {
        this.by = null;
        throw brokerException;
      } 
    } 
  }
  
  public final void closeConversation() { b("CB"); }
  
  public final void closeConversationCommit() { b("CE"); }
  
  final void a(byte[] paramArrayOfByte, boolean paramBoolean) throws et {
    char c1;
    if (a4) {
      Trace.enterMethod(Trace.M4, 2, 20, 63);
      Trace.parameter(Trace.MB4, 2, 20, 63, "message", paramArrayOfByte);
      Trace.parameter(Trace.MP4, 2, 20, 63, "isConversation", paramBoolean);
    } 
    this.bo = this.a3.b(paramArrayOfByte, super.o);
    if (a4)
      Trace.checkpoint(Trace.CP3, 2, 20, 63, "rpcVersion", this.bo); 
    if (this.bo == 0)
      a(paramArrayOfByte, "0008", "00000", "incorrect RPC version '" + ((paramArrayOfByte.length < 4) ? new String(paramArrayOfByte) : new String(paramArrayOfByte, 0, 4)) + "'"); 
    int i1 = paramArrayOfByte.length;
    if (this.bo < 2000) {
      if (i1 < 192) {
        byte[] arrayOfByte = new byte[192];
        a(arrayOfByte, "0007", "00000", "incorrect buffer length " + i1);
      } 
    } else if (i1 < 92) {
      byte[] arrayOfByte = new byte[92];
      a(arrayOfByte, "0007", "00000", "incorrect buffer length " + i1);
    } 
    if (this.bo < 2000) {
      c1 = (new String(paramArrayOfByte, 73, 1)).charAt(0);
      switch (c1) {
        case ' ':
        case '1':
        case '2':
          break;
        default:
          a(paramArrayOfByte, "0009", "00000", "incorrect compression " + c1);
          break;
      } 
    } else {
      c1 = '2';
    } 
    if (a4)
      Trace.checkpoint(Trace.CP3, 2, 20, 63, "compr: " + c1); 
    boolean bool = false;
    if (this.bo < 2000) {
      char c2 = 'À';
      bool = (i1 == c2);
      if (bool) {
        this.b0 = 0;
      } else {
        do {
        
        } while (c2 < i1 && paramArrayOfByte[c2++] != super.o.c);
        if (c2 == i1 && paramArrayOfByte[c2 - '\001'] != super.o.c)
          a(paramArrayOfByte, "0009", "00000", "incorrect format buffer"); 
        this.b0 = c2;
      } 
    } else {
      int i2 = ac.a(paramArrayOfByte, 49, 10, super.o);
      int i3 = ac.a(paramArrayOfByte, 59, 10, super.o);
      if (i2 + i3 > i1)
        a(paramArrayOfByte, "0010", "00000", "invalid value buffer, length is " + (i1 - i2) + ", expected " + i3 + " bytes"); 
      int i4 = ac.a(paramArrayOfByte, 29, 10, super.o);
      int i5 = ac.a(paramArrayOfByte, 39, 10, super.o);
      if (i4 + i5 > i1)
        a(paramArrayOfByte, "0009", "00000", "invalid format buffer"); 
      bool = (i3 == 0 && i5 == 0);
      if (a4) {
        Trace.checkpoint(Trace.CP3, 2, 20, 63, "iVBLength", i3);
        Trace.checkpoint(Trace.CP3, 2, 20, 63, "iVBOffset", i2);
        Trace.checkpoint(Trace.CP3, 2, 20, 63, "iFBLength", i5);
        Trace.checkpoint(Trace.CP3, 2, 20, 63, "iVBOffset", i2);
        Trace.checkpoint(Trace.CP3, 2, 20, 63, "headerOnly", bool);
        Trace.checkpoint(Trace.CP3, 2, 20, 63, "msglen", i1);
      } 
      if (bool) {
        this.b0 = 0;
      } else {
        this.b0 = i2;
        byte[] arrayOfByte = new byte[i5];
        System.arraycopy(paramArrayOfByte, i4, arrayOfByte, 0, i5);
      } 
    } 
    if (a4)
      Trace.checkpoint(Trace.CP3, 2, 20, 63, "valueIndex", this.b0); 
    if (this.bo < 2000) {
      this.bz = (new String(paramArrayOfByte, 67, 2)).toUpperCase();
    } else {
      this.bz = (new String(paramArrayOfByte, 80, 2)).toUpperCase();
    } 
    this.a5 = this.bz;
    if (a4)
      Trace.checkpoint(Trace.CP3, 2, 20, 63, "callType", this.bz); 
    if (this.bo < 2000) {
      this.bj = (new String(paramArrayOfByte, 40, 8)).trim();
      this.bi = (new String(paramArrayOfByte, 32, 8)).trim();
      if (this.bi.length() == 0 && (this.bz.equals("NC") || this.bz.equals("OC")))
        a(paramArrayOfByte, "0007", "00000", "no library name found"); 
    } else {
      d(paramArrayOfByte);
      try {
        this.bj = new String((byte[])this.bd.get("PM"));
      } catch (NullPointerException nullPointerException) {
        if (this.bz.equals("NC") || this.bz.equals("  ") || this.bz.equals("CC"))
          a(paramArrayOfByte, "0007", "00000", "no program name found"); 
        this.bj = "";
      } 
      try {
        this.bi = new String((byte[])this.bd.get("LB"));
      } catch (NullPointerException nullPointerException) {
        if (this.bz.equals("NC") || this.bz.equals("OC"))
          a(paramArrayOfByte, "0028", "00000", "no library name found"); 
        this.bi = "";
      } 
    } 
    if (a4) {
      Trace.checkpoint(Trace.CP3, 2, 20, 63, "progName", this.bj);
      Trace.checkpoint(Trace.CP3, 2, 20, 63, "libraryName", this.bi);
    } 
    if (this.bz.equals("NC")) {
      if (bool)
        a(paramArrayOfByte, "0007", "00000", "no format/value buffer"); 
      if (paramBoolean && this.bo < 1140)
        a(paramArrayOfByte, "0037", "00000", "nonconversational call during conversation"); 
    } else if (this.bz.equals("  ") || this.bz.equals("CC")) {
      if (bool)
        a(paramArrayOfByte, "0007", "00000", "no format/value buffer"); 
      if (!paramBoolean)
        a(paramArrayOfByte, "0036", "00000", "conversational call but no conversation"); 
    } else if (this.bz.equals("OC")) {
      if (!paramBoolean)
        a(paramArrayOfByte, "0011", "00000", "open conversation call but no conversation"); 
    } else if (this.bz.equals("CB") || this.bz.equals("CE")) {
      if (!bool)
        a(paramArrayOfByte, "0007", "00000", "close conversation with format/value buffer"); 
      if (!paramBoolean)
        a(paramArrayOfByte, "0036", "00000", "close conversation call but no conversation"); 
    } else if (this.bz.equals("CO")) {
      if (this.bo < 2000) {
        String str = null;
        if (this.b0 + 4 <= i1) {
          str = new String(paramArrayOfByte, this.b0, 4);
          if (str.equals("PING")) {
            if (a4)
              Trace.leaveMethod(Trace.M4, 2, 20, 63); 
            return;
          } 
        } 
        if (this.b0 + 9 <= i1) {
          str = new String(paramArrayOfByte, this.b0, 9);
          if (str.equals("TERMINATE")) {
            if (a4)
              Trace.leaveMethod(Trace.M4, 2, 20, 63); 
            return;
          } 
        } 
      } else {
        String str = new String((byte[])this.bd.get("CO"));
        if (a4)
          Trace.checkpoint(Trace.CP3, 2, 20, 63, "sInternalCommand", str); 
        if (str.equals("PING")) {
          if (a4)
            Trace.leaveMethod(Trace.M4, 2, 20, 63); 
          return;
        } 
      } 
      a(paramArrayOfByte, "0011", "00000", "invalid internal command");
    } else {
      if (this.bz.equals("IN")) {
        if (a4)
          Trace.leaveMethod(Trace.M4, 2, 20, 63); 
        return;
      } 
      a(paramArrayOfByte, "0011", "00000", "invalid calltype " + this.bz);
    } 
    if (a4)
      Trace.leaveMethod(Trace.M4, 2, 20, 63); 
  }
  
  final byte[] a(byte[] paramArrayOfByte, boolean paramBoolean, RPCServer paramRPCServer) throws et, BrokerException {
    if (a4)
      Trace.enterMethod(Trace.M4, 2, 20, 64); 
    if (this.bz.equals("NC")) {
      if (paramBoolean)
        paramRPCServer.a(false); 
      if (a4)
        Trace.leaveMethod(Trace.M4, 2, 20, 64); 
      return paramRPCServer.a(paramArrayOfByte);
    } 
    if (this.bz.equals("  ") || this.bz.equals("CC")) {
      if (a4)
        Trace.leaveMethod(Trace.M4, 2, 20, 64); 
      return paramRPCServer.a(paramArrayOfByte);
    } 
    if (this.bz.equals("OC")) {
      if (this.b0 == 0) {
        if (a4)
          Trace.leaveMethod(Trace.M4, 2, 20, 64); 
        return null;
      } 
      if (a4)
        Trace.leaveMethod(Trace.M4, 2, 20, 64); 
      return paramRPCServer.a(paramArrayOfByte);
    } 
    if (this.bz.equals("CB") || this.bz.equals("CE")) {
      paramRPCServer.a(this.bz.equals("CE"));
      if (a4)
        Trace.leaveMethod(Trace.M4, 2, 20, 64); 
      if (this.bo < 2000)
        return null; 
      this.marshal.d();
      this.bc.setLength(0);
      a(this.bc, "PT", a8);
      int i1 = this.bc.length();
      this.marshal.b("2000");
      this.marshal.c("*RPC*");
      this.marshal.a(String.valueOf(92), 10);
      this.marshal.a(String.valueOf(i1), 10);
      this.marshal.c(10);
      this.marshal.c(10);
      this.marshal.c(10);
      this.marshal.c(10);
      this.marshal.c(4);
      this.marshal.c(4);
      this.marshal.c(3);
      this.marshal.b(this.bz, 2);
      this.marshal.c(10);
      this.marshal.c(this.bc.toString());
      return this.marshal.e();
    } 
    if (this.bz.equals("CO")) {
      if (this.bo < 2000) {
        String str = null;
        if (this.b0 + 4 <= paramArrayOfByte.length) {
          str = new String(paramArrayOfByte, this.b0, 4);
          if (str.equals("PING")) {
            if (a4) {
              Trace.checkpoint(Trace.CP3, 2, 20, 64, "PING (before RPC 2000)");
              Trace.checkpoint(Trace.CP3, 2, 20, 64, "PING sServerIdentity", a8);
              Trace.checkpoint(Trace.CP3, 2, 20, 64, "PING message.length", paramArrayOfByte.length);
              Trace.checkpoint(Trace.CP3, 2, 20, 64, "PING valueIndex", this.b0);
              Trace.checkpoint(Trace.CB3, 2, 20, 64, "PING message", paramArrayOfByte);
            } 
            byte[] arrayOfByte = c(a8);
            int i1 = arrayOfByte.length;
            if (i1 > paramArrayOfByte.length - this.b0 - 1)
              i1 = paramArrayOfByte.length - this.b0 - 1; 
            if (i1 == 49) {
              System.arraycopy(arrayOfByte, 0, paramArrayOfByte, this.b0, i1);
            } else {
              byte[] arrayOfByte1 = new byte[this.b0 + arrayOfByte.length];
              System.arraycopy(paramArrayOfByte, 0, arrayOfByte1, 0, this.b0);
              System.arraycopy(arrayOfByte, 0, arrayOfByte1, this.b0, arrayOfByte.length);
              paramArrayOfByte = arrayOfByte1;
            } 
            if (a4)
              Trace.leaveMethod(Trace.M4, 2, 20, 64); 
            return paramArrayOfByte;
          } 
        } 
        if (this.b0 + 9 <= paramArrayOfByte.length) {
          str = new String(paramArrayOfByte, this.b0, 9);
          if (str.equals("TERMINATE")) {
            System.arraycopy(c("ignored  "), 0, paramArrayOfByte, this.b0, 9);
            if (a4)
              Trace.leaveMethod(Trace.M4, 2, 20, 64); 
            return paramArrayOfByte;
          } 
        } 
      } else {
        if (a4)
          Trace.checkpoint(Trace.CP3, 2, 20, 64, "PING (since RPC 2000)"); 
        String str = new String((byte[])this.bd.get("CO"));
        if (a4)
          Trace.checkpoint(Trace.CP3, 2, 20, 64, "sInternalCommand", str); 
        if (str.equals("PING")) {
          this.marshal.d();
          this.bc.setLength(0);
          a(this.bc, "PI", a8);
          a(this.bc, "PT", a8);
          int i1 = this.bc.length();
          if (a4)
            Trace.checkpoint(Trace.CP3, 2, 20, 64, "SB(" + i1 + "): " + this.bc); 
          this.marshal.b("2000");
          this.marshal.c("*RPC*");
          this.marshal.a(String.valueOf(92), 10);
          this.marshal.a(String.valueOf(i1), 10);
          this.marshal.c(10);
          this.marshal.c(10);
          this.marshal.c(10);
          this.marshal.c(10);
          this.marshal.c(4);
          this.marshal.c(4);
          this.marshal.c(3);
          this.marshal.b("CO", 2);
          this.marshal.c(10);
          this.marshal.c(this.bc.toString());
          if (a4)
            Trace.leaveMethod(Trace.M4, 2, 20, 64); 
          return this.marshal.e();
        } 
      } 
    } else if (this.bz.equals("IN")) {
      this.bo = 1140;
      if (a4)
        Trace.leaveMethod(Trace.M4, 2, 20, 64); 
      return a(paramRPCServer, paramArrayOfByte);
    } 
    if (a4)
      Trace.leaveMethod(Trace.M4, 2, 20, 64); 
    return null;
  }
  
  final void b(byte[] paramArrayOfByte) {
    if (a4)
      Trace.enterMethod(Trace.M4, 2, 20, 65); 
    int i1 = paramArrayOfByte.length;
    this.bo = this.a3.b(paramArrayOfByte, super.o);
    if (this.bo < 2000) {
      char c1 = (new String(paramArrayOfByte, 73, 1)).charAt(0);
      switch (c1) {
        case ' ':
          this.compression = false;
          this.bm = false;
          break;
        case '1':
          this.compression = true;
          this.bm = false;
          break;
        case '2':
          this.compression = true;
          this.bm = true;
          break;
      } 
    } else {
      this.compression = true;
      this.bm = true;
    } 
    this.bq = paramArrayOfByte;
    if (this.bo < 2000) {
      char c1 = 'À';
      boolean bool = (i1 == c1) ? 1 : 0;
      if (!bool)
        do {
        
        } while (c1 < i1 && paramArrayOfByte[c1++] != super.o.c); 
      this.bs = c1;
    } else {
      this.bs = ac.a(paramArrayOfByte, 49, 10, super.o);
      if (a4)
        Trace.checkpoint(Trace.CP3, 2, 20, 65, "receiveIndex", this.bs); 
    } 
    this.marshal.setBuffer(this.bq, this.bs);
    this.marshal.a(this.bo);
    if (a4)
      Trace.leaveMethod(Trace.M4, 2, 20, 65); 
  }
  
  final byte[] l() {
    if (a4)
      Trace.enterMethod(Trace.M4, 2, 20, 66); 
    byte[] arrayOfByte = this.marshal.e();
    if (this.bo >= 2000) {
      int i1 = arrayOfByte.length - this.bb.c() + this.bc.length() + 92;
      if (a4)
        Trace.checkpoint(Trace.CP3, 2, 20, 66, "Value Buffer", i1); 
      this.marshal.d();
      this.marshal.a(Integer.toString(i1), 10);
      this.marshal.a(arrayOfByte, 59);
    } 
    if (a4)
      Trace.leaveMethod(Trace.M4, 2, 20, 66); 
    return arrayOfByte;
  }
  
  final void a(byte[] paramArrayOfByte, String paramString) throws et { a(paramArrayOfByte, (this.bo < 2000) ? "0000" : "0016", (this.bo < 2000) ? "00082" : "00000", paramString); }
  
  final void b(byte[] paramArrayOfByte, String paramString) throws et { a(paramArrayOfByte, "0007", "00000", paramString); }
  
  final void c(byte[] paramArrayOfByte, String paramString) throws et { a(paramArrayOfByte, (this.bo < 2000) ? "0000" : "0018", (this.bo < 2000) ? "00954" : "00000", paramString); }
  
  private byte[] a(RPCServer paramRPCServer, byte[] paramArrayOfByte) throws BrokerException, et {
    if (a4) {
      Trace.enterMethod(Trace.M4, 2, 20, 67);
      Trace.parameter(Trace.MB4, 2, 20, 67, "message", paramArrayOfByte);
    } 
    String str1 = RPCServer.a(c(paramArrayOfByte), true);
    String str2;
    String str3 = (str2 = "EntireX Java").valueOf(paramRPCServer.a(str1));
    if (str3.equals("0"))
      if (str1.length() > 0) {
        a(paramArrayOfByte, "0016", "00000", "Class " + str1 + "Stub not found");
      } else {
        a(paramArrayOfByte, "0016", "00000", "Library unknown");
      }  
    String str4 = EntireXVersion.getInternalVersion();
    String str5 = System.getProperty("os.name") + " " + System.getProperty("os.version") + " (" + System.getProperty("os.arch") + ")";
    b1 = "MV=" + str3.length() + "," + str3 + "ST=" + str2.length() + "," + str2 + "SV=" + str4.length() + "," + str4 + "SP=" + str5.length() + "," + str5;
    byte[] arrayOfByte = b(paramArrayOfByte, "0000", "00000", b1);
    if (a4) {
      Trace.parameter(Trace.MB4, 2, 20, 67, "reply", arrayOfByte);
      Trace.leaveMethod(Trace.M4, 2, 20, 67);
    } 
    return arrayOfByte;
  }
  
  private String c(byte[] paramArrayOfByte) throws BrokerException, et {
    String str = "";
    byte[][] arrayOfByte = { c("LB") };
    r r1 = new r(paramArrayOfByte, 193, paramArrayOfByte.length - 193, arrayOfByte, super.o);
    while (r1.a()) {
      int i1 = r1.c();
      int i2 = r1.e();
      if (i1 == 0) {
        str = r1.a(i2);
        break;
      } 
      r1.b(i2);
    } 
    return str;
  }
  
  private void a(byte[] paramArrayOfByte, String paramString1, String paramString2, String paramString3) throws et {
    String str = "RPC Server: " + paramString3;
    System.err.println(str);
    throw new et(b(paramArrayOfByte, paramString1, paramString2, "ET=" + str.length() + ',' + str));
  }
  
  private byte[] b(byte[] paramArrayOfByte, String paramString1, String paramString2, String paramString3) {
    if (a4) {
      Trace.enterMethod(Trace.M4, 2, 20, 68);
      Trace.parameter(Trace.MP4, 2, 20, 68, "rpcResponseCode", paramString1);
      Trace.parameter(Trace.MP4, 2, 20, 68, "userResponseCode", paramString2);
      Trace.parameter(Trace.MP4, 2, 20, 68, "text", paramString3);
    } 
    byte[] arrayOfByte = null;
    if (this.bo < 1140) {
      arrayOfByte = new byte[192];
      int i5 = 192;
      if (i5 > paramArrayOfByte.length)
        i5 = paramArrayOfByte.length; 
      System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, i5);
    } else if (this.bo < 2000) {
      arrayOfByte = new byte[192 + paramString3.length()];
      System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, 192);
      System.arraycopy(c(paramString3), 0, arrayOfByte, 192, paramString3.length());
      this.ba.d();
      this.ba.a(Integer.toString(192), 6);
      this.ba.d(6);
      this.ba.a(Integer.toString(paramString3.length()), 6);
      this.ba.a(arrayOfByte, 77);
    } else {
      if (a4)
        Trace.checkpoint(Trace.CP3, 2, 20, 68, "since RPC Version 2000"); 
      StringBuffer stringBuffer = new StringBuffer(new String(paramArrayOfByte));
      stringBuffer.insert(92, paramString3);
      stringBuffer.setLength(92 + paramString3.length());
      arrayOfByte = c(stringBuffer.toString());
      this.ba.d();
      this.ba.a(Integer.toString(paramString3.length()), 10);
      this.ba.a(arrayOfByte, 19);
      this.ba.d();
      this.ba.a(Integer.toString(92), 10);
      this.ba.a(arrayOfByte, 9);
      this.ba.d();
      this.ba.a(Integer.toString(0), 10);
      byte[] arrayOfByte1 = this.ba.e();
      System.arraycopy(arrayOfByte1, 0, arrayOfByte, 29, arrayOfByte1.length);
      System.arraycopy(arrayOfByte1, 0, arrayOfByte, 39, arrayOfByte1.length);
      System.arraycopy(arrayOfByte1, 0, arrayOfByte, 49, arrayOfByte1.length);
      System.arraycopy(arrayOfByte1, 0, arrayOfByte, 59, arrayOfByte1.length);
      System.arraycopy(arrayOfByte1, 0, arrayOfByte, 82, arrayOfByte1.length);
    } 
    byte b3 = (this.bo < 2000) ? 69 : 69;
    int i1 = (this.bo < 2000) ? 4 : 4;
    System.arraycopy(c(paramString1), 0, arrayOfByte, b3, i1);
    b3 = (this.bo < 2000) ? 12 : 73;
    i1 = (this.bo < 2000) ? 5 : 4;
    this.ba.d();
    this.ba.a(Integer.toString(0), i1);
    this.ba.a(arrayOfByte, b3);
    int i2 = paramString2.length();
    int i3 = (i2 < i1) ? (b3 + i1 - i2) : b3;
    int i4 = (i2 > i1) ? (i2 - i1) : 0;
    System.arraycopy(c(paramString2.substring(i4)), 0, arrayOfByte, i3, i2 - i4);
    if (a4)
      Trace.leaveMethod(Trace.M4, 2, 20, 68); 
    return arrayOfByte;
  }
  
  private void a(StringBuffer paramStringBuffer, String paramString1, String paramString2) {
    if (paramString1 != null) {
      paramStringBuffer.append(paramString1);
      paramStringBuffer.append('=');
      if (paramString2 == null) {
        paramStringBuffer.append("0,");
      } else {
        paramStringBuffer.append(paramString2.length());
        paramStringBuffer.append(',');
        paramStringBuffer.append(paramString2);
      } 
    } 
  }
  
  private void d(byte[] paramArrayOfByte) {
    if (a4)
      Trace.enterMethod(Trace.M4, 2, 20, 69); 
    int i1 = ac.a(paramArrayOfByte, 9, 10, super.o);
    int i2 = ac.a(paramArrayOfByte, 19, 10, super.o);
    if (a4) {
      Trace.checkpoint(Trace.CP3, 2, 20, 69, "iStartOfSB", i1);
      Trace.checkpoint(Trace.CP3, 2, 20, 69, "iLengthOfSB", i2);
    } 
    r r1 = new r(paramArrayOfByte, i1, i2, b2, super.o);
    int i3 = -1;
    int i4 = 0;
    byte[] arrayOfByte = null;
    while (r1.a()) {
      i3 = r1.c();
      i4 = r1.e();
      arrayOfByte = r1.b(i4);
      if (i3 != -1)
        this.bd.put(b2[i3], arrayOfByte); 
    } 
    if (a4) {
      Enumeration enumeration = this.bd.keys();
      while (enumeration.hasMoreElements()) {
        String str = (String)enumeration.nextElement();
        Trace.checkpoint(Trace.CP3, 2, 20, 69, str + " " + new String((byte[])this.bd.get(str)), Trace.CP3);
      } 
      Trace.leaveMethod(Trace.M4, 2, 20, 69);
    } 
  }
  
  protected void onEnter(String paramString) {}
  
  protected void onLeave(String paramString, int paramInt1, int paramInt2) throws BrokerException {}
  
  protected void onException(String paramString, BrokerException paramBrokerException) throws BrokerException {}
  
  protected boolean onRetry(String paramString, BrokerException paramBrokerException) throws BrokerException { return false; }
  
  public String ping() {
    BrokerMessage brokerMessage = sendReceive(new BrokerMessage(ao.a(super.o).d()));
    return ao.c(brokerMessage.getMessage(), super.o);
  }
  
  public void setCharacterEncoding(String paramString) {
    super.setCharacterEncoding(paramString);
    this.marshal.a(super.o);
    this.ba.a(super.o);
    this.bb.a(super.o);
  }
  
  private byte[] c(String paramString) {
    byte[] arrayOfByte;
    if (getCharacterEncoding() == null) {
      arrayOfByte = paramString.getBytes();
    } else {
      try {
        arrayOfByte = paramString.getBytes(getCharacterEncoding());
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        arrayOfByte = paramString.getBytes();
      } 
    } 
    return arrayOfByte;
  }
  
  public Object getServer() { return null; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\RPCService.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */