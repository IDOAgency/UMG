package com.softwareag.entirex.aci;

import java.io.IOException;
import java.io.Writer;

class com/softwareag/entirex/aci/cm extends Writer {
  private final Tester2 a;
  
  private com/softwareag/entirex/aci/cm(Tester2 paramTester2) { this.a = paramTester2; }
  
  public void close() throws IOException {}
  
  public void flush() throws IOException {}
  
  public void write(char[] paramArrayOfChar, int paramInt1, int paramInt2) throws IOException { Tester2.a(this.a, new String(paramArrayOfChar, paramInt1, paramInt2)); }
  
  com/softwareag/entirex/aci/cm(Tester2 paramTester2, cc paramcc) { this(paramTester2); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\entirex.jar!\com\softwareag\entirex\aci\cm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */