/*     */ package javax.activation;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimeType
/*     */   implements Externalizable
/*     */ {
/*     */   private String primaryType;
/*     */   private String subType;
/*     */   private MimeTypeParameterList parameters;
/*     */   private static final String TSPECIALS = "()<>@,;:/[]?=\\\"";
/*     */   
/*     */   public MimeType() {
/*  43 */     this.primaryType = "application";
/*  44 */     this.subType = "*";
/*  45 */     this.parameters = new MimeTypeParameterList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public MimeType(String paramString) throws MimeTypeParseException { parse(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeType(String paramString1, String paramString2) throws MimeTypeParseException {
/*  66 */     if (isValidToken(paramString1)) {
/*  67 */       this.primaryType = paramString1.toLowerCase();
/*     */     } else {
/*  69 */       throw new MimeTypeParseException("Primary type is invalid.");
/*     */     } 
/*     */ 
/*     */     
/*  73 */     if (isValidToken(paramString2)) {
/*  74 */       this.subType = paramString2.toLowerCase();
/*     */     } else {
/*  76 */       throw new MimeTypeParseException("Sub type is invalid.");
/*     */     } 
/*     */     
/*  79 */     this.parameters = new MimeTypeParameterList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parse(String paramString) throws MimeTypeParseException {
/*  86 */     int i = paramString.indexOf('/');
/*  87 */     int j = paramString.indexOf(';');
/*  88 */     if (i < 0 && j < 0)
/*     */     {
/*     */       
/*  91 */       throw new MimeTypeParseException("Unable to find a sub type."); } 
/*  92 */     if (i < 0 && j >= 0)
/*     */     {
/*     */       
/*  95 */       throw new MimeTypeParseException("Unable to find a sub type."); } 
/*  96 */     if (i >= 0 && j < 0) {
/*     */       
/*  98 */       this.primaryType = paramString.substring(0, i).trim().toLowerCase();
/*  99 */       this.subType = paramString.substring(i + 1).trim().toLowerCase();
/* 100 */       this.parameters = new MimeTypeParameterList();
/* 101 */     } else if (i < j) {
/*     */       
/* 103 */       this.primaryType = paramString.substring(0, i).trim().toLowerCase();
/* 104 */       this.subType = paramString.substring(i + 1, 
/* 105 */           j).trim().toLowerCase();
/* 106 */       this.parameters = new MimeTypeParameterList(paramString.substring(j));
/*     */     }
/*     */     else {
/*     */       
/* 110 */       throw new MimeTypeParseException("Unable to find a sub type.");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     if (!isValidToken(this.primaryType)) {
/* 117 */       throw new MimeTypeParseException("Primary type is invalid.");
/*     */     }
/*     */     
/* 120 */     if (!isValidToken(this.subType)) {
/* 121 */       throw new MimeTypeParseException("Sub type is invalid.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public String getPrimaryType() { return this.primaryType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrimaryType(String paramString) throws MimeTypeParseException {
/* 140 */     if (!isValidToken(this.primaryType))
/* 141 */       throw new MimeTypeParseException("Primary type is invalid."); 
/* 142 */     this.primaryType = paramString.toLowerCase();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   public String getSubType() { return this.subType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubType(String paramString) throws MimeTypeParseException {
/* 161 */     if (!isValidToken(this.subType))
/* 162 */       throw new MimeTypeParseException("Sub type is invalid."); 
/* 163 */     this.subType = paramString.toLowerCase();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   public MimeTypeParameterList getParameters() { return this.parameters; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 183 */   public String getParameter(String paramString) { return this.parameters.get(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public void setParameter(String paramString1, String paramString2) throws MimeTypeParseException { this.parameters.set(paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   public void removeParameter(String paramString) throws MimeTypeParseException { this.parameters.remove(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   public String toString() { return String.valueOf(getBaseType()) + this.parameters.toString(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 220 */   public String getBaseType() { return String.valueOf(this.primaryType) + "/" + this.subType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(MimeType paramMimeType) {
/* 231 */     if (!this.primaryType.equals(paramMimeType.getPrimaryType()) || (
/* 232 */       !this.subType.equals("*") && 
/* 233 */       !paramMimeType.getSubType().equals("*") && 
/* 234 */       !this.subType.equals(paramMimeType.getSubType()))) {
/*     */       return false;
/*     */     }
/*     */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 245 */   public boolean match(String paramString) throws MimeTypeParseException { return match(new MimeType(paramString)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeExternal(ObjectOutput paramObjectOutput) throws IOException {
/* 258 */     paramObjectOutput.writeUTF(toString());
/* 259 */     paramObjectOutput.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput paramObjectInput) throws IOException, ClassNotFoundException {
/*     */     try {
/* 276 */       parse(paramObjectInput.readUTF()); return;
/* 277 */     } catch (MimeTypeParseException mimeTypeParseException) {
/* 278 */       throw new IOException(mimeTypeParseException.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 288 */   private static boolean isTokenChar(char paramChar) { return !(paramChar <= ' ' || paramChar >= '' || "()<>@,;:/[]?=\\\"".indexOf(paramChar) >= 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isValidToken(String paramString) throws MimeTypeParseException {
/* 295 */     int i = paramString.length();
/* 296 */     if (i > 0) {
/* 297 */       for (byte b = 0; b < i; b++) {
/* 298 */         char c = paramString.charAt(b);
/* 299 */         if (!isTokenChar(c)) {
/* 300 */           return false;
/*     */         }
/*     */       } 
/* 303 */       return true;
/*     */     } 
/* 305 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\activation\MimeType.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */