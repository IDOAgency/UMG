package javax.activation;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.io.OutputStream;

class ObjectDataContentHandler implements DataContentHandler {
  private DataFlavor[] transferFlavors;
  
  private Object obj;
  
  private String mimeType;
  
  private DataContentHandler dch;
  
  public ObjectDataContentHandler(DataContentHandler paramDataContentHandler, Object paramObject, String paramString) {
    this.obj = paramObject;
    this.mimeType = paramString;
    this.dch = paramDataContentHandler;
  }
  
  public DataContentHandler getDCH() { return this.dch; }
  
  public DataFlavor[] getTransferDataFlavors() {
    if (this.transferFlavors == null)
      if (this.dch != null) {
        this.transferFlavors = this.dch.getTransferDataFlavors();
      } else {
        this.transferFlavors = new DataFlavor[1];
        this.transferFlavors[0] = new ActivationDataFlavor(this.obj.getClass(), 
            this.mimeType, this.mimeType);
      }  
    return this.transferFlavors;
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource) throws UnsupportedFlavorException, IOException {
    if (this.dch != null)
      return this.dch.getTransferData(paramDataFlavor, paramDataSource); 
    if (paramDataFlavor.equals(this.transferFlavors[0]))
      return this.obj; 
    throw new UnsupportedFlavorException(paramDataFlavor);
  }
  
  public Object getContent(DataSource paramDataSource) { return this.obj; }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream) throws IOException {
    if (this.dch != null) {
      this.dch.writeTo(paramObject, paramString, paramOutputStream);
      return;
    } 
    throw new UnsupportedDataTypeException(
        "no object DCH for MIME type " + this.mimeType);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\activation\ObjectDataContentHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */