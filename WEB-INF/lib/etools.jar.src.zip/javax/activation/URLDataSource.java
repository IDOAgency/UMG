/*     */ package javax.activation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class URLDataSource
/*     */   implements DataSource
/*     */ {
/*     */   private URL url;
/*     */   private URLConnection url_conn;
/*     */   
/*  52 */   public URLDataSource(URL paramURL) { this.url = paramURL; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  67 */     String str = null;
/*     */     
/*     */     try {
/*  70 */       if (this.url_conn == null)
/*  71 */         this.url_conn = this.url.openConnection(); 
/*  72 */     } catch (IOException iOException) {}
/*     */     
/*  74 */     if (this.url_conn != null) {
/*  75 */       str = this.url_conn.getContentType();
/*     */     }
/*  77 */     if (str == null) {
/*  78 */       str = "application/octet-stream";
/*     */     }
/*  80 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public String getName() { return this.url.getFile(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public InputStream getInputStream() throws IOException { return this.url.openStream(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/* 113 */     this.url_conn = this.url.openConnection();
/*     */     
/* 115 */     if (this.url_conn != null) {
/* 116 */       return this.url_conn.getOutputStream();
/*     */     }
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public URL getURL() { return this.url; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\activation\URLDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */