/*     */ package javax.activation;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimeTypeParameterList
/*     */ {
/*     */   private Hashtable parameters;
/*     */   private static final String TSPECIALS = "()<>@,;:/[]?=\\\"";
/*     */   
/*  46 */   public MimeTypeParameterList() { this.parameters = new Hashtable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeTypeParameterList(String paramString) throws MimeTypeParseException {
/*  56 */     this.parameters = new Hashtable();
/*     */ 
/*     */     
/*  59 */     parse(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parse(String paramString) throws MimeTypeParseException {
/*  68 */     if (paramString == null) {
/*     */       return;
/*     */     }
/*  71 */     int i = paramString.length();
/*  72 */     if (i <= 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  77 */     int j = skipWhiteSpace(paramString, 0); char c;
/*  78 */     for (; j < i && (c = paramString.charAt(j)) == ';'; 
/*  79 */       j = skipWhiteSpace(paramString, j)) {
/*     */       String str2;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  85 */       j++;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  90 */       j = skipWhiteSpace(paramString, j);
/*     */       
/*  92 */       if (j >= i) {
/*  93 */         throw new MimeTypeParseException(
/*  94 */             "Couldn't find parameter name");
/*     */       }
/*     */       
/*  97 */       int k = j;
/*  98 */       while (j < i && isTokenChar(paramString.charAt(j))) {
/*  99 */         j++;
/*     */       }
/* 101 */       String str1 = paramString.substring(k, j).toLowerCase();
/*     */ 
/*     */       
/* 104 */       j = skipWhiteSpace(paramString, j);
/*     */       
/* 106 */       if (j >= i || paramString.charAt(j) != '=') {
/* 107 */         throw new MimeTypeParseException(
/* 108 */             "Couldn't find the '=' that separates a parameter name from its value.");
/*     */       }
/*     */ 
/*     */       
/* 112 */       j++;
/* 113 */       j = skipWhiteSpace(paramString, j);
/*     */       
/* 115 */       if (j >= i) {
/* 116 */         throw new MimeTypeParseException(
/* 117 */             "Couldn't find a value for parameter named " + str1);
/*     */       }
/*     */       
/* 120 */       c = paramString.charAt(j);
/* 121 */       if (c == '"') {
/*     */         
/* 123 */         j++;
/* 124 */         if (j >= i) {
/* 125 */           throw new MimeTypeParseException(
/* 126 */               "Encountered unterminated quoted parameter value.");
/*     */         }
/* 128 */         k = j;
/*     */ 
/*     */         
/* 131 */         while (j < i) {
/* 132 */           c = paramString.charAt(j);
/* 133 */           if (c != '"') {
/*     */             
/* 135 */             if (c == '\\')
/*     */             {
/*     */ 
/*     */               
/* 139 */               j++;
/*     */             }
/* 141 */             j++; continue;
/*     */           }  break;
/* 143 */         }  if (c != '"') {
/* 144 */           throw new MimeTypeParseException(
/* 145 */               "Encountered unterminated quoted parameter value.");
/*     */         }
/* 147 */         str2 = unquote(paramString.substring(k, j));
/*     */         
/* 149 */         j++;
/* 150 */       } else if (isTokenChar(c)) {
/*     */ 
/*     */         
/* 153 */         k = j;
/* 154 */         while (j < i && isTokenChar(paramString.charAt(j)))
/* 155 */           j++; 
/* 156 */         str2 = paramString.substring(k, j);
/*     */       } else {
/*     */         
/* 159 */         throw new MimeTypeParseException(
/* 160 */             "Unexpected character encountered at index " + j);
/*     */       } 
/*     */ 
/*     */       
/* 164 */       this.parameters.put(str1, str2);
/*     */     } 
/* 166 */     if (j < i) {
/* 167 */       throw new MimeTypeParseException(
/* 168 */           "More characters encountered in input than expected.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   public int size() { return this.parameters.size(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 187 */   public boolean isEmpty() { return this.parameters.isEmpty(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   public String get(String paramString) { return (String)this.parameters.get(paramString.trim().toLowerCase()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 209 */   public void set(String paramString1, String paramString2) { this.parameters.put(paramString1.trim().toLowerCase(), paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 218 */   public void remove(String paramString) throws MimeTypeParseException { this.parameters.remove(paramString.trim().toLowerCase()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 227 */   public Enumeration getNames() { return this.parameters.keys(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 234 */     StringBuffer stringBuffer = new StringBuffer();
/* 235 */     stringBuffer.ensureCapacity(this.parameters.size() * 16);
/*     */ 
/*     */     
/* 238 */     Enumeration enumeration = this.parameters.keys();
/* 239 */     while (enumeration.hasMoreElements()) {
/* 240 */       String str = (String)enumeration.nextElement();
/* 241 */       stringBuffer.append("; ");
/* 242 */       stringBuffer.append(str);
/* 243 */       stringBuffer.append('=');
/* 244 */       stringBuffer.append(quote((String)this.parameters.get(str)));
/*     */     } 
/*     */     
/* 247 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 256 */   private static boolean isTokenChar(char paramChar) { return !(paramChar <= ' ' || paramChar >= '' || "()<>@,;:/[]?=\\\"".indexOf(paramChar) >= 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int skipWhiteSpace(String paramString, int paramInt) {
/* 264 */     int i = paramString.length();
/* 265 */     while (paramInt < i && Character.isWhitespace(paramString.charAt(paramInt)))
/* 266 */       paramInt++; 
/* 267 */     return paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String quote(String paramString) {
/* 274 */     boolean bool = false;
/*     */ 
/*     */     
/* 277 */     int i = paramString.length();
/* 278 */     for (byte b = 0; b < i && !bool; b++) {
/* 279 */       bool = isTokenChar(paramString.charAt(b)) ? 0 : 1;
/*     */     }
/*     */     
/* 282 */     if (bool) {
/* 283 */       StringBuffer stringBuffer = new StringBuffer();
/* 284 */       stringBuffer.ensureCapacity((int)(i * 1.5D));
/*     */ 
/*     */       
/* 287 */       stringBuffer.append('"');
/*     */ 
/*     */       
/* 290 */       for (byte b1 = 0; b1 < i; b1++) {
/* 291 */         char c = paramString.charAt(b1);
/* 292 */         if (c == '\\' || c == '"')
/* 293 */           stringBuffer.append('\\'); 
/* 294 */         stringBuffer.append(c);
/*     */       } 
/*     */ 
/*     */       
/* 298 */       stringBuffer.append('"');
/*     */       
/* 300 */       return stringBuffer.toString();
/*     */     } 
/* 302 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String unquote(String paramString) {
/* 311 */     int i = paramString.length();
/* 312 */     StringBuffer stringBuffer = new StringBuffer();
/* 313 */     stringBuffer.ensureCapacity(i);
/*     */     
/* 315 */     boolean bool = false;
/* 316 */     for (byte b = 0; b < i; b++) {
/* 317 */       char c = paramString.charAt(b);
/* 318 */       if (!bool && c != '\\') {
/* 319 */         stringBuffer.append(c);
/* 320 */       } else if (bool) {
/* 321 */         stringBuffer.append(c);
/* 322 */         bool = false;
/*     */       } else {
/* 324 */         bool = true;
/*     */       } 
/*     */     } 
/*     */     
/* 328 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\activation\MimeTypeParameterList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */