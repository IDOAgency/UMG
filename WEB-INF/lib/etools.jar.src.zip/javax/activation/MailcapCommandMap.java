package javax.activation;

import com.sun.activation.registries.MailcapFile;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class MailcapCommandMap extends CommandMap {
  private static MailcapFile defDB = null;
  
  private MailcapFile[] DB = new MailcapFile[5];
  
  private static final int PROG = 0;
  
  private static final int HOME = 1;
  
  private static final int SYS = 2;
  
  private static final int JAR = 3;
  
  private static final int DEF = 4;
  
  private static boolean debug;
  
  static Class class$javax$activation$MailcapCommandMap;
  
  static  {
    try {
      debug = Boolean.getBoolean("javax.activation.debug");
      return;
    } catch (Throwable throwable) {
      return;
    } 
  }
  
  public MailcapCommandMap() {
    if (debug)
      System.out.println("MailcapCommandMap: load HOME"); 
    try {
      String str = System.getProperty("user.home");
      if (str != null) {
        String str1 = String.valueOf(str) + File.separator + ".mailcap";
        this.DB[1] = loadFile(str1);
      } 
    } catch (SecurityException securityException) {}
    if (debug)
      System.out.println("MailcapCommandMap: load SYS"); 
    try {
      String str = String.valueOf(System.getProperty("java.home")) + 
        File.separator + "lib" + File.separator + "mailcap";
      this.DB[2] = loadFile(str);
    } catch (SecurityException securityException) {}
    if (debug)
      System.out.println("MailcapCommandMap: load JAR"); 
    this.DB[3] = loadResource("/META-INF/mailcap");
    if (debug)
      System.out.println("MailcapCommandMap: load DEF"); 
    synchronized ((class$javax$activation$MailcapCommandMap != null) ? class$javax$activation$MailcapCommandMap : (class$javax$activation$MailcapCommandMap = CommandMap.class$("javax.activation.MailcapCommandMap"))) {
      if (defDB == null)
        defDB = loadResource("/META-INF/mailcap.default"); 
    } 
    this.DB[4] = defDB;
  }
  
  private MailcapFile loadResource(String paramString) {
    try {
      InputStream inputStream = getClass().getResourceAsStream(paramString);
      if (inputStream != null)
        return new MailcapFile(inputStream); 
    } catch (IOException iOException) {}
    return null;
  }
  
  private MailcapFile loadFile(String paramString) {
    MailcapFile mailcapFile = null;
    try {
      mailcapFile = new MailcapFile(paramString);
    } catch (IOException iOException) {}
    return mailcapFile;
  }
  
  public MailcapCommandMap(String paramString) throws IOException {
    this();
    if (debug)
      System.out.println("MailcapCommandMap: load PROG from " + paramString); 
    if (this.DB[false] == null)
      this.DB[0] = new MailcapFile(paramString); 
  }
  
  public MailcapCommandMap(InputStream paramInputStream) {
    this();
    if (debug)
      System.out.println("MailcapCommandMap: load PROG"); 
    if (this.DB[false] == null)
      try {
        this.DB[0] = new MailcapFile(paramInputStream);
        return;
      } catch (IOException iOException) {
        return;
      }  
  }
  
  public CommandInfo[] getPreferredCommands(String paramString) {
    Vector vector = new Vector();
    for (byte b = 0; b < this.DB.length; b++) {
      if (this.DB[b] != null) {
        Hashtable hashtable = this.DB[b].getMailcapList(paramString);
        if (hashtable != null)
          appendPrefCmdsToVector(hashtable, vector); 
      } 
    } 
    CommandInfo[] arrayOfCommandInfo = new CommandInfo[vector.size()];
    vector.copyInto(arrayOfCommandInfo);
    return arrayOfCommandInfo;
  }
  
  private void appendPrefCmdsToVector(Hashtable paramHashtable, Vector paramVector) {
    Enumeration enumeration = paramHashtable.keys();
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      if (!checkForVerb(paramVector, str)) {
        Vector vector = (Vector)paramHashtable.get(str);
        String str1 = (String)vector.firstElement();
        paramVector.addElement(new CommandInfo(str, str1));
      } 
    } 
  }
  
  private boolean checkForVerb(Vector paramVector, String paramString) {
    Enumeration enumeration = paramVector.elements();
    while (enumeration.hasMoreElements()) {
      String str = (
        (CommandInfo)enumeration.nextElement()).getCommandName();
      if (str.equals(paramString))
        return true; 
    } 
    return false;
  }
  
  public CommandInfo[] getAllCommands(String paramString) {
    Vector vector = new Vector();
    for (byte b = 0; b < this.DB.length; b++) {
      if (this.DB[b] != null) {
        Hashtable hashtable = this.DB[b].getMailcapList(paramString);
        if (hashtable != null)
          appendCmdsToVector(hashtable, vector); 
      } 
    } 
    CommandInfo[] arrayOfCommandInfo = new CommandInfo[vector.size()];
    vector.copyInto(arrayOfCommandInfo);
    return arrayOfCommandInfo;
  }
  
  private void appendCmdsToVector(Hashtable paramHashtable, Vector paramVector) {
    Enumeration enumeration = paramHashtable.keys();
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      Vector vector = (Vector)paramHashtable.get(str);
      Enumeration enumeration1 = vector.elements();
      while (enumeration1.hasMoreElements()) {
        String str1 = (String)enumeration1.nextElement();
        paramVector.insertElementAt(new CommandInfo(str, str1), 0);
      } 
    } 
  }
  
  public CommandInfo getCommand(String paramString1, String paramString2) {
    for (byte b = 0; b < this.DB.length; b++) {
      if (this.DB[b] != null) {
        Hashtable hashtable = this.DB[b].getMailcapList(paramString1);
        if (hashtable != null) {
          Vector vector = (Vector)hashtable.get(paramString2);
          if (vector != null) {
            String str = (String)vector.firstElement();
            if (str != null)
              return new CommandInfo(paramString2, str); 
          } 
        } 
      } 
    } 
    return null;
  }
  
  public void addMailcap(String paramString) throws IOException {
    if (debug)
      System.out.println("MailcapCommandMap: add to PROG"); 
    if (this.DB[false] == null)
      this.DB[0] = new MailcapFile(); 
    this.DB[0].appendToMailcap(paramString);
  }
  
  public DataContentHandler createDataContentHandler(String paramString) {
    if (debug)
      System.out.println(
          "MailcapCommandMap: createDataContentHandler for " + paramString); 
    for (byte b = 0; b < this.DB.length; b++) {
      if (this.DB[b] != null) {
        if (debug)
          System.out.println("  search DB #" + b); 
        Hashtable hashtable = this.DB[b].getMailcapList(paramString);
        if (hashtable != null) {
          Vector vector = (Vector)hashtable.get("content-handler");
          if (vector != null) {
            if (debug)
              System.out.println("    got content-handler"); 
            try {
              if (debug)
                System.out.println("      class " + 
                    (String)vector.firstElement()); 
              return (DataContentHandler)Class.forName(
                  (String)vector.firstElement()).newInstance();
            } catch (IllegalAccessException illegalAccessException) {
            
            } catch (ClassNotFoundException classNotFoundException) {
            
            } catch (InstantiationException instantiationException) {}
          } 
        } 
      } 
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\activation\MailcapCommandMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */