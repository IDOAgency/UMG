/*     */ package javax.activation;
/*     */ 
/*     */ import com.sun.activation.registries.MailcapFile;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MailcapCommandMap
/*     */   extends CommandMap
/*     */ {
/* 108 */   private static MailcapFile defDB = null;
/* 109 */   private MailcapFile[] DB = new MailcapFile[5];
/*     */   private static final int PROG = 0;
/*     */   private static final int HOME = 1;
/*     */   private static final int SYS = 2;
/*     */   private static final int JAR = 3;
/*     */   private static final int DEF = 4;
/*     */   private static boolean debug;
/*     */   static Class class$javax$activation$MailcapCommandMap;
/*     */   
/*     */   static  {
/*     */     try {
/* 120 */       debug = Boolean.getBoolean("javax.activation.debug"); return;
/* 121 */     } catch (Throwable throwable) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapCommandMap() {
/* 132 */     if (debug)
/* 133 */       System.out.println("MailcapCommandMap: load HOME"); 
/*     */     try {
/* 135 */       String str = System.getProperty("user.home");
/*     */       
/* 137 */       if (str != null) {
/* 138 */         String str1 = String.valueOf(str) + File.separator + ".mailcap";
/* 139 */         this.DB[1] = loadFile(str1);
/*     */       } 
/* 141 */     } catch (SecurityException securityException) {}
/*     */     
/* 143 */     if (debug) {
/* 144 */       System.out.println("MailcapCommandMap: load SYS");
/*     */     }
/*     */     try {
/* 147 */       String str = String.valueOf(System.getProperty("java.home")) + 
/* 148 */         File.separator + "lib" + File.separator + "mailcap";
/* 149 */       this.DB[2] = loadFile(str);
/* 150 */     } catch (SecurityException securityException) {}
/*     */     
/* 152 */     if (debug) {
/* 153 */       System.out.println("MailcapCommandMap: load JAR");
/*     */     }
/* 155 */     this.DB[3] = loadResource("/META-INF/mailcap");
/*     */     
/* 157 */     if (debug)
/* 158 */       System.out.println("MailcapCommandMap: load DEF"); 
/* 159 */     synchronized ((class$javax$activation$MailcapCommandMap != null) ? class$javax$activation$MailcapCommandMap : (class$javax$activation$MailcapCommandMap = CommandMap.class$("javax.activation.MailcapCommandMap"))) {
/*     */       
/* 161 */       if (defDB == null) {
/* 162 */         defDB = loadResource("/META-INF/mailcap.default");
/*     */       }
/*     */     } 
/* 165 */     this.DB[4] = defDB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MailcapFile loadResource(String paramString) {
/*     */     try {
/* 173 */       InputStream inputStream = getClass().getResourceAsStream(paramString);
/* 174 */       if (inputStream != null)
/* 175 */         return new MailcapFile(inputStream); 
/* 176 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 179 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MailcapFile loadFile(String paramString) {
/* 186 */     MailcapFile mailcapFile = null;
/*     */     
/*     */     try {
/* 189 */       mailcapFile = new MailcapFile(paramString);
/* 190 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 193 */     return mailcapFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapCommandMap(String paramString) throws IOException {
/* 203 */     this();
/*     */     
/* 205 */     if (debug)
/* 206 */       System.out.println("MailcapCommandMap: load PROG from " + paramString); 
/* 207 */     if (this.DB[false] == null) {
/* 208 */       this.DB[0] = new MailcapFile(paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapCommandMap(InputStream paramInputStream) {
/* 220 */     this();
/*     */     
/* 222 */     if (debug)
/* 223 */       System.out.println("MailcapCommandMap: load PROG"); 
/* 224 */     if (this.DB[false] == null) {
/*     */       try {
/* 226 */         this.DB[0] = new MailcapFile(paramInputStream); return;
/* 227 */       } catch (IOException iOException) {
/*     */         return;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandInfo[] getPreferredCommands(String paramString) {
/* 247 */     Vector vector = new Vector();
/*     */     
/* 249 */     for (byte b = 0; b < this.DB.length; b++) {
/* 250 */       if (this.DB[b] != null) {
/*     */         
/* 252 */         Hashtable hashtable = this.DB[b].getMailcapList(paramString);
/* 253 */         if (hashtable != null)
/* 254 */           appendPrefCmdsToVector(hashtable, vector); 
/*     */       } 
/*     */     } 
/* 257 */     CommandInfo[] arrayOfCommandInfo = new CommandInfo[vector.size()];
/* 258 */     vector.copyInto(arrayOfCommandInfo);
/*     */     
/* 260 */     return arrayOfCommandInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendPrefCmdsToVector(Hashtable paramHashtable, Vector paramVector) {
/* 267 */     Enumeration enumeration = paramHashtable.keys();
/*     */     
/* 269 */     while (enumeration.hasMoreElements()) {
/* 270 */       String str = (String)enumeration.nextElement();
/* 271 */       if (!checkForVerb(paramVector, str)) {
/* 272 */         Vector vector = (Vector)paramHashtable.get(str);
/* 273 */         String str1 = (String)vector.firstElement();
/* 274 */         paramVector.addElement(new CommandInfo(str, str1));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkForVerb(Vector paramVector, String paramString) {
/* 284 */     Enumeration enumeration = paramVector.elements();
/* 285 */     while (enumeration.hasMoreElements()) {
/* 286 */       String str = (
/* 287 */         (CommandInfo)enumeration.nextElement()).getCommandName();
/* 288 */       if (str.equals(paramString))
/* 289 */         return true; 
/*     */     } 
/* 291 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandInfo[] getAllCommands(String paramString) {
/* 302 */     Vector vector = new Vector();
/*     */     
/* 304 */     for (byte b = 0; b < this.DB.length; b++) {
/* 305 */       if (this.DB[b] != null) {
/*     */         
/* 307 */         Hashtable hashtable = this.DB[b].getMailcapList(paramString);
/* 308 */         if (hashtable != null)
/* 309 */           appendCmdsToVector(hashtable, vector); 
/*     */       } 
/*     */     } 
/* 312 */     CommandInfo[] arrayOfCommandInfo = new CommandInfo[vector.size()];
/* 313 */     vector.copyInto(arrayOfCommandInfo);
/*     */     
/* 315 */     return arrayOfCommandInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendCmdsToVector(Hashtable paramHashtable, Vector paramVector) {
/* 322 */     Enumeration enumeration = paramHashtable.keys();
/*     */     
/* 324 */     while (enumeration.hasMoreElements()) {
/* 325 */       String str = (String)enumeration.nextElement();
/* 326 */       Vector vector = (Vector)paramHashtable.get(str);
/* 327 */       Enumeration enumeration1 = vector.elements();
/*     */       
/* 329 */       while (enumeration1.hasMoreElements()) {
/* 330 */         String str1 = (String)enumeration1.nextElement();
/*     */         
/* 332 */         paramVector.insertElementAt(new CommandInfo(str, str1), 0);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandInfo getCommand(String paramString1, String paramString2) {
/* 346 */     for (byte b = 0; b < this.DB.length; b++) {
/* 347 */       if (this.DB[b] != null) {
/*     */         
/* 349 */         Hashtable hashtable = this.DB[b].getMailcapList(paramString1);
/* 350 */         if (hashtable != null) {
/*     */           
/* 352 */           Vector vector = (Vector)hashtable.get(paramString2);
/* 353 */           if (vector != null) {
/* 354 */             String str = (String)vector.firstElement();
/*     */             
/* 356 */             if (str != null)
/* 357 */               return new CommandInfo(paramString2, str); 
/*     */           } 
/*     */         } 
/*     */       } 
/* 361 */     }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMailcap(String paramString) throws IOException {
/* 375 */     if (debug)
/* 376 */       System.out.println("MailcapCommandMap: add to PROG"); 
/* 377 */     if (this.DB[false] == null) {
/* 378 */       this.DB[0] = new MailcapFile();
/*     */     }
/* 380 */     this.DB[0].appendToMailcap(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataContentHandler createDataContentHandler(String paramString) {
/* 391 */     if (debug)
/* 392 */       System.out.println(
/* 393 */           "MailcapCommandMap: createDataContentHandler for " + paramString); 
/* 394 */     for (byte b = 0; b < this.DB.length; b++) {
/* 395 */       if (this.DB[b] != null) {
/*     */         
/* 397 */         if (debug)
/* 398 */           System.out.println("  search DB #" + b); 
/* 399 */         Hashtable hashtable = this.DB[b].getMailcapList(paramString);
/* 400 */         if (hashtable != null) {
/* 401 */           Vector vector = (Vector)hashtable.get("content-handler");
/* 402 */           if (vector != null) {
/* 403 */             if (debug)
/* 404 */               System.out.println("    got content-handler"); 
/*     */             
/* 406 */             try { if (debug)
/* 407 */                 System.out.println("      class " + 
/* 408 */                     (String)vector.firstElement()); 
/* 409 */               return (DataContentHandler)Class.forName(
/* 410 */                   (String)vector.firstElement()).newInstance(); }
/* 411 */             catch (IllegalAccessException illegalAccessException) {  }
/* 412 */             catch (ClassNotFoundException classNotFoundException) {  }
/* 413 */             catch (InstantiationException instantiationException) {}
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 418 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\activation\MailcapCommandMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */