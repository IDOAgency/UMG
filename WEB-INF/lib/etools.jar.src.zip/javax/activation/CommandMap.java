/*    */ package javax.activation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CommandMap
/*    */ {
/* 34 */   private static CommandMap defaultCommandMap = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static CommandMap getDefaultCommandMap() {
/* 54 */     if (defaultCommandMap == null) {
/* 55 */       defaultCommandMap = new MailcapCommandMap();
/*    */     }
/* 57 */     return defaultCommandMap;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setDefaultCommandMap(CommandMap paramCommandMap) {
/* 69 */     SecurityManager securityManager = System.getSecurityManager();
/* 70 */     if (securityManager != null)
/*    */       
/*    */       try {
/* 73 */         securityManager.checkSetFactory();
/* 74 */       } catch (SecurityException securityException) {
/*    */ 
/*    */ 
/*    */         
/* 78 */         if (CommandMap.class.getClassLoader() != 
/* 79 */           paramCommandMap.getClass().getClassLoader()) {
/* 80 */           throw securityException;
/*    */         }
/*    */       }  
/* 83 */     defaultCommandMap = paramCommandMap;
/*    */   }
/*    */   
/*    */   public abstract CommandInfo[] getPreferredCommands(String paramString);
/*    */   
/*    */   public abstract CommandInfo[] getAllCommands(String paramString);
/*    */   
/*    */   public abstract CommandInfo getCommand(String paramString1, String paramString2);
/*    */   
/*    */   public abstract DataContentHandler createDataContentHandler(String paramString);
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\activation\CommandMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */