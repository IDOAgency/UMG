package javax.activation;

public abstract class CommandMap {
  private static CommandMap defaultCommandMap = null;
  
  public static CommandMap getDefaultCommandMap() {
    if (defaultCommandMap == null)
      defaultCommandMap = new MailcapCommandMap(); 
    return defaultCommandMap;
  }
  
  public static void setDefaultCommandMap(CommandMap paramCommandMap) {
    SecurityManager securityManager = System.getSecurityManager();
    if (securityManager != null)
      try {
        securityManager.checkSetFactory();
      } catch (SecurityException securityException) {
        if (CommandMap.class.getClassLoader() != 
          paramCommandMap.getClass().getClassLoader())
          throw securityException; 
      }  
    defaultCommandMap = paramCommandMap;
  }
  
  public abstract CommandInfo[] getPreferredCommands(String paramString);
  
  public abstract CommandInfo[] getAllCommands(String paramString);
  
  public abstract CommandInfo getCommand(String paramString1, String paramString2);
  
  public abstract DataContentHandler createDataContentHandler(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\activation\CommandMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */