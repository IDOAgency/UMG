package javax.activation;

import java.io.IOException;

public interface CommandObject {
  void setCommandContext(String paramString, DataHandler paramDataHandler) throws IOException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\activation\CommandObject.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */