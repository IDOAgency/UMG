package javax.activation;

import java.awt.datatransfer.DataFlavor;

public class ActivationDataFlavor extends DataFlavor {
  private String mimeType;
  
  private MimeType mimeObject;
  
  private String humanPresentableName;
  
  private Class representationClass;
  
  static Class class$(String paramString) { try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    }  }
  
  public ActivationDataFlavor(Class paramClass, String paramString1, String paramString2) {
    super(paramString1, paramString2);
    this.mimeType = paramString1;
    this.humanPresentableName = paramString2;
    this.representationClass = paramClass;
  }
  
  public ActivationDataFlavor(Class paramClass, String paramString) {
    super(paramClass, paramString);
    this.mimeType = super.getMimeType();
    this.representationClass = paramClass;
    this.humanPresentableName = paramString;
  }
  
  public ActivationDataFlavor(String paramString1, String paramString2) {
    super(paramString1, paramString2);
    this.mimeType = paramString1;
    this.representationClass = (DataFlavor.class$java$io$InputStream != null) ? DataFlavor.class$java$io$InputStream : (DataFlavor.class$java$io$InputStream = class$("java.io.InputStream"));
    this.humanPresentableName = paramString2;
  }
  
  public String getMimeType() { return this.mimeType; }
  
  public Class getRepresentationClass() { return this.representationClass; }
  
  public String getHumanPresentableName() { return this.humanPresentableName; }
  
  public void setHumanPresentableName(String paramString) { this.humanPresentableName = paramString; }
  
  public boolean equals(DataFlavor paramDataFlavor) { return !(!isMimeTypeEqual(paramDataFlavor) || 
      paramDataFlavor.getRepresentationClass() != this.representationClass); }
  
  public boolean isMimeTypeEqual(String paramString) {
    MimeType mimeType1 = null;
    try {
      if (this.mimeObject == null)
        this.mimeObject = new MimeType(this.mimeType); 
      mimeType1 = new MimeType(paramString);
    } catch (MimeTypeParseException mimeTypeParseException) {}
    return this.mimeObject.match(mimeType1);
  }
  
  protected String normalizeMimeTypeParameter(String paramString1, String paramString2) { return String.valueOf(paramString1) + "=" + paramString2; }
  
  protected String normalizeMimeType(String paramString) { return paramString; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\activation\ActivationDataFlavor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */