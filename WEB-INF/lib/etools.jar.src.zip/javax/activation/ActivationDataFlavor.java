/*     */ package javax.activation;
/*     */ 
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActivationDataFlavor
/*     */   extends DataFlavor
/*     */ {
/*     */   private String mimeType;
/*     */   private MimeType mimeObject;
/*     */   private String humanPresentableName;
/*     */   private Class representationClass;
/*     */   
/*     */   static Class class$(String paramString) { 
/*  37 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(classNotFoundException.getMessage()); }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActivationDataFlavor(Class paramClass, String paramString1, String paramString2) {
/*  75 */     super(paramString1, paramString2);
/*     */ 
/*     */     
/*  78 */     this.mimeType = paramString1;
/*  79 */     this.humanPresentableName = paramString2;
/*  80 */     this.representationClass = paramClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActivationDataFlavor(Class paramClass, String paramString) {
/* 102 */     super(paramClass, paramString);
/* 103 */     this.mimeType = super.getMimeType();
/* 104 */     this.representationClass = paramClass;
/* 105 */     this.humanPresentableName = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActivationDataFlavor(String paramString1, String paramString2) {
/* 124 */     super(paramString1, paramString2);
/* 125 */     this.mimeType = paramString1;
/* 126 */     this.representationClass = (DataFlavor.class$java$io$InputStream != null) ? DataFlavor.class$java$io$InputStream : (DataFlavor.class$java$io$InputStream = class$("java.io.InputStream"));
/* 127 */     this.humanPresentableName = paramString2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public String getMimeType() { return this.mimeType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public Class getRepresentationClass() { return this.representationClass; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public String getHumanPresentableName() { return this.humanPresentableName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public void setHumanPresentableName(String paramString) { this.humanPresentableName = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   public boolean equals(DataFlavor paramDataFlavor) { return !(!isMimeTypeEqual(paramDataFlavor) || 
/* 176 */       paramDataFlavor.getRepresentationClass() != this.representationClass); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMimeTypeEqual(String paramString) {
/* 192 */     MimeType mimeType1 = null;
/*     */     try {
/* 194 */       if (this.mimeObject == null)
/* 195 */         this.mimeObject = new MimeType(this.mimeType); 
/* 196 */       mimeType1 = new MimeType(paramString);
/* 197 */     } catch (MimeTypeParseException mimeTypeParseException) {}
/*     */     
/* 199 */     return this.mimeObject.match(mimeType1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 217 */   protected String normalizeMimeTypeParameter(String paramString1, String paramString2) { return String.valueOf(paramString1) + "=" + paramString2; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   protected String normalizeMimeType(String paramString) { return paramString; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\activation\ActivationDataFlavor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */