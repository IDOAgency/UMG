/*    */ package javax.activation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MimeTypeParseException
/*    */   extends Exception
/*    */ {
/*    */   public MimeTypeParseException() {}
/*    */   
/* 41 */   public MimeTypeParseException(String paramString) { super(paramString); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\activation\MimeTypeParseException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */