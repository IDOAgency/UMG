/*     */ package javax.activation;
/*     */ 
/*     */ import com.sun.activation.registries.MimeTypeFile;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimetypesFileTypeMap
/*     */   extends FileTypeMap
/*     */ {
/*  66 */   private static MimeTypeFile defDB = null;
/*  67 */   private MimeTypeFile[] DB = new MimeTypeFile[5];
/*     */   
/*     */   private static final int PROG = 0;
/*     */   private static final int HOME = 1;
/*     */   private static final int SYS = 2;
/*     */   private static final int JAR = 3;
/*     */   private static final int DEF = 4;
/*  74 */   private static String defaultType = "application/octet-stream";
/*     */   
/*     */   static Class class$javax$activation$MimetypesFileTypeMap;
/*     */ 
/*     */   
/*     */   public MimetypesFileTypeMap() {
/*     */     try {
/*  81 */       String str = System.getProperty("user.home");
/*     */       
/*  83 */       if (str != null) {
/*  84 */         String str1 = String.valueOf(str) + File.separator + ".mime.types";
/*  85 */         this.DB[1] = loadFile(str1);
/*     */       } 
/*  87 */     } catch (SecurityException securityException) {}
/*     */ 
/*     */     
/*     */     try {
/*  91 */       String str = String.valueOf(System.getProperty("java.home")) + 
/*  92 */         File.separator + "lib" + File.separator + "mime.types";
/*  93 */       this.DB[2] = loadFile(str);
/*  94 */     } catch (SecurityException securityException) {}
/*     */ 
/*     */     
/*  97 */     this.DB[3] = loadResource("/META-INF/mime.types");
/*     */     
/*  99 */     synchronized ((class$javax$activation$MimetypesFileTypeMap != null) ? class$javax$activation$MimetypesFileTypeMap : (class$javax$activation$MimetypesFileTypeMap = FileTypeMap.class$("javax.activation.MimetypesFileTypeMap"))) {
/*     */       
/* 101 */       if (defDB == null) {
/* 102 */         defDB = loadResource("/META-INF/mimetypes.default");
/*     */       }
/*     */     } 
/* 105 */     this.DB[4] = defDB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MimeTypeFile loadResource(String paramString) {
/*     */     try {
/* 113 */       InputStream inputStream = getClass().getResourceAsStream(paramString);
/* 114 */       if (inputStream != null)
/* 115 */         return new MimeTypeFile(inputStream); 
/* 116 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MimeTypeFile loadFile(String paramString) {
/* 126 */     MimeTypeFile mimeTypeFile = null;
/*     */     
/*     */     try {
/* 129 */       mimeTypeFile = new MimeTypeFile(paramString);
/* 130 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 133 */     return mimeTypeFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimetypesFileTypeMap(String paramString) throws IOException {
/* 143 */     this();
/* 144 */     this.DB[0] = new MimeTypeFile(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimetypesFileTypeMap(InputStream paramInputStream) {
/* 154 */     this();
/*     */     try {
/* 156 */       this.DB[0] = new MimeTypeFile(paramInputStream); return;
/* 157 */     } catch (IOException iOException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMimeTypes(String paramString) throws IOException {
/* 169 */     if (this.DB[false] == null) {
/* 170 */       this.DB[0] = new MimeTypeFile();
/*     */     }
/* 172 */     this.DB[0].appendToRegistry(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 184 */   public String getContentType(File paramFile) { return getContentType(paramFile.getName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType(String paramString) {
/* 197 */     int i = paramString.lastIndexOf(".");
/*     */     
/* 199 */     if (i < 0) {
/* 200 */       return defaultType;
/*     */     }
/* 202 */     String str = paramString.substring(i + 1);
/* 203 */     if (str.length() == 0) {
/* 204 */       return defaultType;
/*     */     }
/* 206 */     for (byte b = 0; b < this.DB.length; b++) {
/* 207 */       if (this.DB[b] != null) {
/*     */         
/* 209 */         String str1 = this.DB[b].getMIMETypeString(str);
/* 210 */         if (str1 != null)
/* 211 */           return str1; 
/*     */       } 
/* 213 */     }  return defaultType;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\activation\MimetypesFileTypeMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */