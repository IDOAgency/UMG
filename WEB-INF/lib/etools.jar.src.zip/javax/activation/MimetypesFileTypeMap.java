package javax.activation;

import com.sun.activation.registries.MimeTypeFile;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class MimetypesFileTypeMap extends FileTypeMap {
  private static MimeTypeFile defDB = null;
  
  private MimeTypeFile[] DB = new MimeTypeFile[5];
  
  private static final int PROG = 0;
  
  private static final int HOME = 1;
  
  private static final int SYS = 2;
  
  private static final int JAR = 3;
  
  private static final int DEF = 4;
  
  private static String defaultType = "application/octet-stream";
  
  static Class class$javax$activation$MimetypesFileTypeMap;
  
  public MimetypesFileTypeMap() {
    try {
      String str = System.getProperty("user.home");
      if (str != null) {
        String str1 = String.valueOf(str) + File.separator + ".mime.types";
        this.DB[1] = loadFile(str1);
      } 
    } catch (SecurityException securityException) {}
    try {
      String str = String.valueOf(System.getProperty("java.home")) + 
        File.separator + "lib" + File.separator + "mime.types";
      this.DB[2] = loadFile(str);
    } catch (SecurityException securityException) {}
    this.DB[3] = loadResource("/META-INF/mime.types");
    synchronized ((class$javax$activation$MimetypesFileTypeMap != null) ? class$javax$activation$MimetypesFileTypeMap : (class$javax$activation$MimetypesFileTypeMap = FileTypeMap.class$("javax.activation.MimetypesFileTypeMap"))) {
      if (defDB == null)
        defDB = loadResource("/META-INF/mimetypes.default"); 
    } 
    this.DB[4] = defDB;
  }
  
  private MimeTypeFile loadResource(String paramString) {
    try {
      InputStream inputStream = getClass().getResourceAsStream(paramString);
      if (inputStream != null)
        return new MimeTypeFile(inputStream); 
    } catch (IOException iOException) {}
    return null;
  }
  
  private MimeTypeFile loadFile(String paramString) {
    MimeTypeFile mimeTypeFile = null;
    try {
      mimeTypeFile = new MimeTypeFile(paramString);
    } catch (IOException iOException) {}
    return mimeTypeFile;
  }
  
  public MimetypesFileTypeMap(String paramString) throws IOException {
    this();
    this.DB[0] = new MimeTypeFile(paramString);
  }
  
  public MimetypesFileTypeMap(InputStream paramInputStream) {
    this();
    try {
      this.DB[0] = new MimeTypeFile(paramInputStream);
      return;
    } catch (IOException iOException) {
      return;
    } 
  }
  
  public void addMimeTypes(String paramString) throws IOException {
    if (this.DB[false] == null)
      this.DB[0] = new MimeTypeFile(); 
    this.DB[0].appendToRegistry(paramString);
  }
  
  public String getContentType(File paramFile) { return getContentType(paramFile.getName()); }
  
  public String getContentType(String paramString) {
    int i = paramString.lastIndexOf(".");
    if (i < 0)
      return defaultType; 
    String str = paramString.substring(i + 1);
    if (str.length() == 0)
      return defaultType; 
    for (byte b = 0; b < this.DB.length; b++) {
      if (this.DB[b] != null) {
        String str1 = this.DB[b].getMIMETypeString(str);
        if (str1 != null)
          return str1; 
      } 
    } 
    return defaultType;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\activation\MimetypesFileTypeMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */