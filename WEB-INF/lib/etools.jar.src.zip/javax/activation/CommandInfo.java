/*     */ package javax.activation;
/*     */ 
/*     */ import java.beans.Beans;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommandInfo
/*     */ {
/*     */   private String verb;
/*     */   private String className;
/*     */   
/*     */   public CommandInfo(String paramString1, String paramString2) {
/*  50 */     this.verb = paramString1;
/*  51 */     this.className = paramString2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public String getCommandName() { return this.verb; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public String getCommandClass() { return this.className; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getCommandObject(DataHandler paramDataHandler, ClassLoader paramClassLoader) throws IOException, ClassNotFoundException {
/* 109 */     Object object = null;
/*     */ 
/*     */     
/* 112 */     object = Beans.instantiate(paramClassLoader, this.className);
/*     */ 
/*     */     
/* 115 */     if (object != null) {
/* 116 */       if (object instanceof CommandObject) {
/* 117 */         ((CommandObject)object).setCommandContext(this.verb, paramDataHandler);
/* 118 */       } else if (object instanceof Externalizable && 
/* 119 */         paramDataHandler != null) {
/* 120 */         InputStream inputStream = paramDataHandler.getInputStream();
/* 121 */         if (inputStream != null) {
/* 122 */           ((Externalizable)object).readExternal(
/* 123 */               new ObjectInputStream(inputStream));
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 129 */     return object;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\activation\CommandInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */