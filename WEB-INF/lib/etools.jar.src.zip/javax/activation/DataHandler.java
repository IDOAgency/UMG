/*     */ package javax.activation;
/*     */ 
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.datatransfer.Transferable;
/*     */ import java.awt.datatransfer.UnsupportedFlavorException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PipedInputStream;
/*     */ import java.io.PipedOutputStream;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataHandler
/*     */   implements Transferable
/*     */ {
/*     */   private DataSource dataSource;
/*     */   private DataSource objDataSource;
/*     */   private Object object;
/*     */   private String objectMimeType;
/*     */   private CommandMap currentCommandMap;
/*  86 */   private static final DataFlavor[] emptyFlavors = new DataFlavor[0];
/*     */   
/*     */   private DataFlavor[] transferFlavors;
/*     */   
/*     */   private DataContentHandler dataContentHandler;
/*     */   
/*     */   private DataContentHandler factoryDCH;
/*     */   
/*  94 */   private static DataContentHandlerFactory factory = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private DataContentHandlerFactory oldFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   private String shortType;
/*     */ 
/*     */ 
/*     */   
/*     */   public DataHandler(DataSource paramDataSource) {
/*     */     this.transferFlavors = emptyFlavors;
/* 108 */     this.dataSource = paramDataSource;
/* 109 */     this.oldFactory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataHandler(Object paramObject, String paramString) {
/*     */     this.transferFlavors = emptyFlavors;
/* 122 */     this.object = paramObject;
/* 123 */     this.objectMimeType = paramString;
/* 124 */     this.oldFactory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataHandler(URL paramURL) {
/*     */     this.transferFlavors = emptyFlavors;
/* 135 */     this.dataSource = new URLDataSource(paramURL);
/* 136 */     this.oldFactory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CommandMap getCommandMap() {
/* 143 */     if (this.currentCommandMap != null) {
/* 144 */       return this.currentCommandMap;
/*     */     }
/* 146 */     return CommandMap.getDefaultCommandMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSource getDataSource() {
/* 164 */     if (this.dataSource == null) {
/*     */       
/* 166 */       if (this.objDataSource == null)
/* 167 */         this.objDataSource = new DataHandlerDataSource(this); 
/* 168 */       return this.objDataSource;
/*     */     } 
/* 170 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 182 */     if (this.dataSource != null) {
/* 183 */       return this.dataSource.getName();
/*     */     }
/* 185 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 196 */     if (this.dataSource != null) {
/* 197 */       return this.dataSource.getContentType();
/*     */     }
/* 199 */     return this.objectMimeType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 227 */     InputStream inputStream = null;
/*     */     
/* 229 */     if (this.dataSource != null) {
/* 230 */       inputStream = this.dataSource.getInputStream();
/*     */     } else {
/* 232 */       DataContentHandler dataContentHandler1 = getDataContentHandler();
/*     */       
/* 234 */       if (dataContentHandler1 == null) {
/* 235 */         throw new UnsupportedDataTypeException(
/* 236 */             "no DCH for MIME type " + getBaseType());
/*     */       }
/* 238 */       if (dataContentHandler1 instanceof ObjectDataContentHandler && (
/* 239 */         (ObjectDataContentHandler)dataContentHandler1).getDCH() == null) {
/* 240 */         throw new UnsupportedDataTypeException(
/* 241 */             "no object DCH for MIME type " + getBaseType());
/*     */       }
/*     */       
/* 244 */       DataContentHandler dataContentHandler2 = dataContentHandler1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 252 */       PipedOutputStream pipedOutputStream = new PipedOutputStream();
/* 253 */       PipedInputStream pipedInputStream = new PipedInputStream(pipedOutputStream);
/* 254 */       (new Thread(
/* 255 */           new Runnable(dataContentHandler2, pipedOutputStream, this) { private final PipedOutputStream val$pos; public void run() {
/*     */               
/* 257 */               try { this.val$fdch
/* 258 */                   .writeTo(this.this$0.object, this.this$0.objectMimeType, this.val$pos); }
/* 259 */               catch (IOException iOException) {  }
/*     */               finally
/*     */               { try {
/* 262 */                   this.val$pos
/* 263 */                     .close();
/* 264 */                 } catch (IOException iOException) {} }
/*     */             
/*     */             }
/*     */             private final DataHandler this$0; private final DataContentHandler val$fdch; }
/* 268 */           "DataHandler.getInputStream")).start();
/* 269 */       inputStream = pipedInputStream;
/*     */     } 
/*     */     
/* 272 */     return inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(OutputStream paramOutputStream) throws IOException {
/* 292 */     if (this.dataSource != null) {
/* 293 */       InputStream inputStream = null;
/* 294 */       byte[] arrayOfByte = new byte[8192];
/*     */ 
/*     */       
/* 297 */       inputStream = this.dataSource.getInputStream();
/*     */       int i;
/* 299 */       while ((i = inputStream.read(arrayOfByte)) > 0) {
/* 300 */         paramOutputStream.write(arrayOfByte, 0, i);
/*     */       }
/* 302 */       inputStream.close(); return;
/*     */     } 
/* 304 */     DataContentHandler dataContentHandler1 = getDataContentHandler();
/* 305 */     dataContentHandler1.writeTo(this.object, this.objectMimeType, paramOutputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/* 322 */     if (this.dataSource != null) {
/* 323 */       return this.dataSource.getOutputStream();
/*     */     }
/* 325 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataFlavor[] getTransferDataFlavors() {
/* 353 */     if (factory != this.oldFactory) {
/* 354 */       this.transferFlavors = emptyFlavors;
/*     */     }
/*     */     
/* 357 */     if (this.transferFlavors == emptyFlavors)
/* 358 */       this.transferFlavors = getDataContentHandler().getTransferDataFlavors(); 
/* 359 */     return this.transferFlavors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDataFlavorSupported(DataFlavor paramDataFlavor) {
/* 375 */     DataFlavor[] arrayOfDataFlavor = getTransferDataFlavors();
/*     */     
/* 377 */     for (byte b = 0; b < arrayOfDataFlavor.length; b++) {
/* 378 */       if (arrayOfDataFlavor[b].equals(paramDataFlavor))
/* 379 */         return true; 
/*     */     } 
/* 381 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 419 */   public Object getTransferData(DataFlavor paramDataFlavor) throws UnsupportedFlavorException, IOException { return getDataContentHandler().getTransferData(paramDataFlavor, this.dataSource); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCommandMap(CommandMap paramCommandMap) {
/* 435 */     if (paramCommandMap != this.currentCommandMap || paramCommandMap == null) {
/*     */       
/* 437 */       this.transferFlavors = emptyFlavors;
/* 438 */       this.dataContentHandler = null;
/*     */       
/* 440 */       this.currentCommandMap = paramCommandMap;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 458 */   public CommandInfo[] getPreferredCommands() { return getCommandMap().getPreferredCommands(getBaseType()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 474 */   public CommandInfo[] getAllCommands() { return getCommandMap().getAllCommands(getBaseType()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 490 */   public CommandInfo getCommand(String paramString) { return getCommandMap().getCommand(getBaseType(), paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 511 */   public Object getContent() throws IOException { return getDataContentHandler().getContent(getDataSource()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getBean(CommandInfo paramCommandInfo) {
/* 527 */     Object object1 = null;
/*     */ 
/*     */ 
/*     */     
/* 531 */     try { object1 = paramCommandInfo.getCommandObject(this, getClass().getClassLoader()); }
/* 532 */     catch (IOException iOException) {  }
/* 533 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */     
/* 535 */     return object1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DataContentHandler getDataContentHandler() {
/* 558 */     if (factory != this.oldFactory) {
/* 559 */       this.oldFactory = factory;
/* 560 */       this.factoryDCH = null;
/* 561 */       this.dataContentHandler = null;
/* 562 */       this.transferFlavors = emptyFlavors;
/*     */     } 
/*     */     
/* 565 */     if (this.dataContentHandler != null) {
/* 566 */       return this.dataContentHandler;
/*     */     }
/* 568 */     String str = getBaseType();
/*     */     
/* 570 */     if (this.factoryDCH == null && factory != null) {
/* 571 */       this.factoryDCH = factory.createDataContentHandler(str);
/*     */     }
/* 573 */     if (this.factoryDCH != null) {
/* 574 */       this.dataContentHandler = this.factoryDCH;
/*     */     }
/* 576 */     if (this.dataContentHandler == null) {
/* 577 */       this.dataContentHandler = 
/* 578 */         getCommandMap().createDataContentHandler(str);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 583 */     if (this.dataSource != null) {
/* 584 */       this.dataContentHandler = new DataSourceDataContentHandler(
/* 585 */           this.dataContentHandler, 
/* 586 */           this.dataSource);
/*     */     } else {
/* 588 */       this.dataContentHandler = new ObjectDataContentHandler(
/* 589 */           this.dataContentHandler, 
/* 590 */           this.object, 
/* 591 */           this.objectMimeType);
/* 592 */     }  return this.dataContentHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getBaseType() {
/* 600 */     if (this.shortType == null) {
/* 601 */       String str = getContentType();
/*     */       try {
/* 603 */         MimeType mimeType = new MimeType(str);
/* 604 */         this.shortType = mimeType.getBaseType();
/* 605 */       } catch (MimeTypeParseException mimeTypeParseException) {
/* 606 */         this.shortType = str;
/*     */       } 
/*     */     } 
/* 609 */     return this.shortType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDataContentHandlerFactory(DataContentHandlerFactory paramDataContentHandlerFactory) {
/* 627 */     if (factory != null) {
/* 628 */       throw new Error("DataContentHandlerFactory already defined");
/*     */     }
/* 630 */     SecurityManager securityManager = System.getSecurityManager();
/* 631 */     if (securityManager != null)
/*     */       
/*     */       try {
/* 634 */         securityManager.checkSetFactory();
/* 635 */       } catch (SecurityException securityException) {
/*     */ 
/*     */ 
/*     */         
/* 639 */         if (DataHandler.class.getClassLoader() != 
/* 640 */           paramDataContentHandlerFactory.getClass().getClassLoader()) {
/* 641 */           throw securityException;
/*     */         }
/*     */       }  
/* 644 */     factory = paramDataContentHandlerFactory;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\activation\DataHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */