package javax.activation;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.net.URL;

public class DataHandler implements Transferable {
  private DataSource dataSource;
  
  private DataSource objDataSource;
  
  private Object object;
  
  private String objectMimeType;
  
  private CommandMap currentCommandMap;
  
  private static final DataFlavor[] emptyFlavors = new DataFlavor[0];
  
  private DataFlavor[] transferFlavors;
  
  private DataContentHandler dataContentHandler;
  
  private DataContentHandler factoryDCH;
  
  private static DataContentHandlerFactory factory = null;
  
  private DataContentHandlerFactory oldFactory;
  
  private String shortType;
  
  public DataHandler(DataSource paramDataSource) {
    this.transferFlavors = emptyFlavors;
    this.dataSource = paramDataSource;
    this.oldFactory = factory;
  }
  
  public DataHandler(Object paramObject, String paramString) {
    this.transferFlavors = emptyFlavors;
    this.object = paramObject;
    this.objectMimeType = paramString;
    this.oldFactory = factory;
  }
  
  public DataHandler(URL paramURL) {
    this.transferFlavors = emptyFlavors;
    this.dataSource = new URLDataSource(paramURL);
    this.oldFactory = factory;
  }
  
  private CommandMap getCommandMap() {
    if (this.currentCommandMap != null)
      return this.currentCommandMap; 
    return CommandMap.getDefaultCommandMap();
  }
  
  public DataSource getDataSource() {
    if (this.dataSource == null) {
      if (this.objDataSource == null)
        this.objDataSource = new DataHandlerDataSource(this); 
      return this.objDataSource;
    } 
    return this.dataSource;
  }
  
  public String getName() {
    if (this.dataSource != null)
      return this.dataSource.getName(); 
    return null;
  }
  
  public String getContentType() {
    if (this.dataSource != null)
      return this.dataSource.getContentType(); 
    return this.objectMimeType;
  }
  
  public InputStream getInputStream() throws IOException {
    InputStream inputStream = null;
    if (this.dataSource != null) {
      inputStream = this.dataSource.getInputStream();
    } else {
      DataContentHandler dataContentHandler1 = getDataContentHandler();
      if (dataContentHandler1 == null)
        throw new UnsupportedDataTypeException(
            "no DCH for MIME type " + getBaseType()); 
      if (dataContentHandler1 instanceof ObjectDataContentHandler && (
        (ObjectDataContentHandler)dataContentHandler1).getDCH() == null)
        throw new UnsupportedDataTypeException(
            "no object DCH for MIME type " + getBaseType()); 
      DataContentHandler dataContentHandler2 = dataContentHandler1;
      PipedOutputStream pipedOutputStream = new PipedOutputStream();
      PipedInputStream pipedInputStream = new PipedInputStream(pipedOutputStream);
      (new Thread(
          new Runnable(dataContentHandler2, pipedOutputStream, this) {
            private final PipedOutputStream val$pos;
            
            private final DataHandler this$0;
            
            private final DataContentHandler val$fdch;
            
            public void run() {
              try {
                this.val$fdch
                  .writeTo(this.this$0.object, this.this$0.objectMimeType, this.val$pos);
              } catch (IOException iOException) {
              
              } finally {
                try {
                  this.val$pos
                    .close();
                } catch (IOException iOException) {}
              } 
            }
          }"DataHandler.getInputStream")).start();
      inputStream = pipedInputStream;
    } 
    return inputStream;
  }
  
  public void writeTo(OutputStream paramOutputStream) throws IOException {
    if (this.dataSource != null) {
      InputStream inputStream = null;
      byte[] arrayOfByte = new byte[8192];
      inputStream = this.dataSource.getInputStream();
      int i;
      while ((i = inputStream.read(arrayOfByte)) > 0)
        paramOutputStream.write(arrayOfByte, 0, i); 
      inputStream.close();
      return;
    } 
    DataContentHandler dataContentHandler1 = getDataContentHandler();
    dataContentHandler1.writeTo(this.object, this.objectMimeType, paramOutputStream);
  }
  
  public OutputStream getOutputStream() throws IOException {
    if (this.dataSource != null)
      return this.dataSource.getOutputStream(); 
    return null;
  }
  
  public DataFlavor[] getTransferDataFlavors() {
    if (factory != this.oldFactory)
      this.transferFlavors = emptyFlavors; 
    if (this.transferFlavors == emptyFlavors)
      this.transferFlavors = getDataContentHandler().getTransferDataFlavors(); 
    return this.transferFlavors;
  }
  
  public boolean isDataFlavorSupported(DataFlavor paramDataFlavor) {
    DataFlavor[] arrayOfDataFlavor = getTransferDataFlavors();
    for (byte b = 0; b < arrayOfDataFlavor.length; b++) {
      if (arrayOfDataFlavor[b].equals(paramDataFlavor))
        return true; 
    } 
    return false;
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor) throws UnsupportedFlavorException, IOException { return getDataContentHandler().getTransferData(paramDataFlavor, this.dataSource); }
  
  public void setCommandMap(CommandMap paramCommandMap) {
    if (paramCommandMap != this.currentCommandMap || paramCommandMap == null) {
      this.transferFlavors = emptyFlavors;
      this.dataContentHandler = null;
      this.currentCommandMap = paramCommandMap;
    } 
  }
  
  public CommandInfo[] getPreferredCommands() { return getCommandMap().getPreferredCommands(getBaseType()); }
  
  public CommandInfo[] getAllCommands() { return getCommandMap().getAllCommands(getBaseType()); }
  
  public CommandInfo getCommand(String paramString) { return getCommandMap().getCommand(getBaseType(), paramString); }
  
  public Object getContent() throws IOException { return getDataContentHandler().getContent(getDataSource()); }
  
  public Object getBean(CommandInfo paramCommandInfo) {
    Object object1 = null;
    try {
      object1 = paramCommandInfo.getCommandObject(this, getClass().getClassLoader());
    } catch (IOException iOException) {
    
    } catch (ClassNotFoundException classNotFoundException) {}
    return object1;
  }
  
  private DataContentHandler getDataContentHandler() {
    if (factory != this.oldFactory) {
      this.oldFactory = factory;
      this.factoryDCH = null;
      this.dataContentHandler = null;
      this.transferFlavors = emptyFlavors;
    } 
    if (this.dataContentHandler != null)
      return this.dataContentHandler; 
    String str = getBaseType();
    if (this.factoryDCH == null && factory != null)
      this.factoryDCH = factory.createDataContentHandler(str); 
    if (this.factoryDCH != null)
      this.dataContentHandler = this.factoryDCH; 
    if (this.dataContentHandler == null)
      this.dataContentHandler = 
        getCommandMap().createDataContentHandler(str); 
    if (this.dataSource != null) {
      this.dataContentHandler = new DataSourceDataContentHandler(
          this.dataContentHandler, 
          this.dataSource);
    } else {
      this.dataContentHandler = new ObjectDataContentHandler(
          this.dataContentHandler, 
          this.object, 
          this.objectMimeType);
    } 
    return this.dataContentHandler;
  }
  
  private String getBaseType() {
    if (this.shortType == null) {
      String str = getContentType();
      try {
        MimeType mimeType = new MimeType(str);
        this.shortType = mimeType.getBaseType();
      } catch (MimeTypeParseException mimeTypeParseException) {
        this.shortType = str;
      } 
    } 
    return this.shortType;
  }
  
  public static void setDataContentHandlerFactory(DataContentHandlerFactory paramDataContentHandlerFactory) {
    if (factory != null)
      throw new Error("DataContentHandlerFactory already defined"); 
    SecurityManager securityManager = System.getSecurityManager();
    if (securityManager != null)
      try {
        securityManager.checkSetFactory();
      } catch (SecurityException securityException) {
        if (DataHandler.class.getClassLoader() != 
          paramDataContentHandlerFactory.getClass().getClassLoader())
          throw securityException; 
      }  
    factory = paramDataContentHandlerFactory;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\activation\DataHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */