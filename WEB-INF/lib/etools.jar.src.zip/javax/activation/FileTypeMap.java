/*     */ package javax.activation;
/*     */ 
/*     */ import java.io.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FileTypeMap
/*     */ {
/*  44 */   private static FileTypeMap defaultMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDefaultFileTypeMap(FileTypeMap paramFileTypeMap) {
/*  80 */     SecurityManager securityManager = System.getSecurityManager();
/*  81 */     if (securityManager != null)
/*     */       
/*     */       try {
/*  84 */         securityManager.checkSetFactory();
/*  85 */       } catch (SecurityException securityException) {
/*     */ 
/*     */ 
/*     */         
/*  89 */         if (FileTypeMap.class.getClassLoader() != 
/*  90 */           paramFileTypeMap.getClass().getClassLoader()) {
/*  91 */           throw securityException;
/*     */         }
/*     */       }  
/*  94 */     defaultMap = paramFileTypeMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FileTypeMap getDefaultFileTypeMap() {
/* 108 */     if (defaultMap == null)
/* 109 */       defaultMap = new MimetypesFileTypeMap(); 
/* 110 */     return defaultMap;
/*     */   }
/*     */   
/*     */   public abstract String getContentType(File paramFile);
/*     */   
/*     */   public abstract String getContentType(String paramString);
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\activation\FileTypeMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */