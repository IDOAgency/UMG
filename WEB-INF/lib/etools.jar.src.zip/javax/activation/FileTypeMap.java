package javax.activation;

import java.io.File;

public abstract class FileTypeMap {
  private static FileTypeMap defaultMap = null;
  
  public static void setDefaultFileTypeMap(FileTypeMap paramFileTypeMap) {
    SecurityManager securityManager = System.getSecurityManager();
    if (securityManager != null)
      try {
        securityManager.checkSetFactory();
      } catch (SecurityException securityException) {
        if (FileTypeMap.class.getClassLoader() != 
          paramFileTypeMap.getClass().getClassLoader())
          throw securityException; 
      }  
    defaultMap = paramFileTypeMap;
  }
  
  public static FileTypeMap getDefaultFileTypeMap() {
    if (defaultMap == null)
      defaultMap = new MimetypesFileTypeMap(); 
    return defaultMap;
  }
  
  public abstract String getContentType(File paramFile);
  
  public abstract String getContentType(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\activation\FileTypeMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */