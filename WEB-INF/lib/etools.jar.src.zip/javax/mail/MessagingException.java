/*     */ package javax.mail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessagingException
/*     */   extends Exception
/*     */ {
/*     */   private Exception next;
/*     */   
/*     */   public MessagingException() {}
/*     */   
/*  39 */   public MessagingException(String paramString) { super(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessagingException(String paramString, Exception paramException) {
/*  52 */     super(paramString);
/*  53 */     this.next = paramException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public Exception getNextException() { return this.next; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setNextException(Exception paramException) {
/*  77 */     Exception exception = this;
/*  78 */     while (exception instanceof MessagingException && 
/*  79 */       ((MessagingException)exception).next != null) {
/*  80 */       exception = ((MessagingException)exception).next;
/*     */     }
/*     */ 
/*     */     
/*  84 */     if (exception instanceof MessagingException) {
/*  85 */       ((MessagingException)exception).next = paramException;
/*  86 */       return true;
/*     */     } 
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/*  96 */     if (this.next == null) {
/*  97 */       return super.getMessage();
/*     */     }
/*  99 */     return String.valueOf(super.getMessage()) + 
/* 100 */       ";\n  nested exception is: \n\t" + 
/* 101 */       this.next.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\MessagingException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */