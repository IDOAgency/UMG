package javax.mail;

public class MessagingException extends Exception {
  private Exception next;
  
  public MessagingException() {}
  
  public MessagingException(String paramString) { super(paramString); }
  
  public MessagingException(String paramString, Exception paramException) {
    super(paramString);
    this.next = paramException;
  }
  
  public Exception getNextException() { return this.next; }
  
  public boolean setNextException(Exception paramException) {
    Exception exception = this;
    while (exception instanceof MessagingException && 
      ((MessagingException)exception).next != null)
      exception = ((MessagingException)exception).next; 
    if (exception instanceof MessagingException) {
      ((MessagingException)exception).next = paramException;
      return true;
    } 
    return false;
  }
  
  public String getMessage() {
    if (this.next == null)
      return super.getMessage(); 
    return String.valueOf(super.getMessage()) + 
      ";\n  nested exception is: \n\t" + 
      this.next.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\MessagingException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */