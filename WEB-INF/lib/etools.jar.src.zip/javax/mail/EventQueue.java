/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import javax.mail.event.MailEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EventQueue
/*     */   implements Runnable
/*     */ {
/*     */   private QueueElement head;
/*     */   private QueueElement tail;
/*     */   private Thread qThread;
/*     */   
/*     */   class QueueElement
/*     */   {
/*     */     private final EventQueue this$0;
/*     */     QueueElement next;
/*     */     QueueElement prev;
/*     */     MailEvent event;
/*     */     Vector vector;
/*     */     
/*     */     QueueElement(EventQueue this$0, MailEvent param1MailEvent, Vector param1Vector) {
/*  30 */       this.this$0 = this$0; this.this$0 = this$0;
/*  31 */       this.event = param1MailEvent;
/*  32 */       this.vector = param1Vector;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EventQueue() {
/*  41 */     this.qThread = new Thread(this);
/*  42 */     this.qThread.setDaemon(true);
/*  43 */     this.qThread.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enqueue(MailEvent paramMailEvent, Vector paramVector) {
/*  50 */     QueueElement queueElement = new QueueElement(this, paramMailEvent, paramVector);
/*     */     
/*  52 */     if (this.head == null) {
/*  53 */       this.head = queueElement;
/*  54 */       this.tail = queueElement;
/*     */     } else {
/*  56 */       queueElement.next = this.head;
/*  57 */       this.head.prev = queueElement;
/*  58 */       this.head = queueElement;
/*     */     } 
/*  60 */     notify();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private QueueElement dequeue() throws InterruptedException {
/*  73 */     while (this.tail == null)
/*  74 */       wait(); 
/*  75 */     QueueElement queueElement = this.tail;
/*  76 */     this.tail = queueElement.prev;
/*  77 */     if (this.tail == null) {
/*  78 */       this.head = null;
/*     */     } else {
/*  80 */       this.tail.next = null;
/*     */     } 
/*  82 */     queueElement.prev = queueElement.next = null;
/*  83 */     return queueElement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/*     */       QueueElement queueElement;
/*  93 */       while ((queueElement = dequeue()) != null) {
/*  94 */         MailEvent mailEvent = queueElement.event;
/*  95 */         Vector vector = queueElement.vector;
/*     */         
/*  97 */         for (byte b = 0; b < vector.size(); b++) {
/*  98 */           mailEvent.dispatch(vector.elementAt(b));
/*     */         }
/* 100 */         queueElement = null; mailEvent = null; vector = null;
/*     */       }  return;
/* 102 */     } catch (InterruptedException interruptedException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void stop() {
/* 111 */     if (this.qThread != null) {
/* 112 */       this.qThread.interrupt();
/* 113 */       this.qThread = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\EventQueue.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */