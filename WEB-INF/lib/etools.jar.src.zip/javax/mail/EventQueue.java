package javax.mail;

import java.util.Vector;
import javax.mail.event.MailEvent;

class EventQueue implements Runnable {
  private QueueElement head;
  
  private QueueElement tail;
  
  private Thread qThread;
  
  class QueueElement {
    private final EventQueue this$0;
    
    QueueElement next;
    
    QueueElement prev;
    
    MailEvent event;
    
    Vector vector;
    
    QueueElement(EventQueue this$0, MailEvent param1MailEvent, Vector param1Vector) {
      this.this$0 = this$0;
      this.this$0 = this$0;
      this.event = param1MailEvent;
      this.vector = param1Vector;
    }
  }
  
  public EventQueue() {
    this.qThread = new Thread(this);
    this.qThread.setDaemon(true);
    this.qThread.start();
  }
  
  public void enqueue(MailEvent paramMailEvent, Vector paramVector) {
    QueueElement queueElement = new QueueElement(this, paramMailEvent, paramVector);
    if (this.head == null) {
      this.head = queueElement;
      this.tail = queueElement;
    } else {
      queueElement.next = this.head;
      this.head.prev = queueElement;
      this.head = queueElement;
    } 
    notify();
  }
  
  private QueueElement dequeue() throws InterruptedException {
    while (this.tail == null)
      wait(); 
    QueueElement queueElement = this.tail;
    this.tail = queueElement.prev;
    if (this.tail == null) {
      this.head = null;
    } else {
      this.tail.next = null;
    } 
    queueElement.prev = queueElement.next = null;
    return queueElement;
  }
  
  public void run() {
    try {
      QueueElement queueElement;
      while ((queueElement = dequeue()) != null) {
        MailEvent mailEvent = queueElement.event;
        Vector vector = queueElement.vector;
        for (byte b = 0; b < vector.size(); b++)
          mailEvent.dispatch(vector.elementAt(b)); 
        queueElement = null;
        mailEvent = null;
        vector = null;
      } 
      return;
    } catch (InterruptedException interruptedException) {
      return;
    } 
  }
  
  void stop() {
    if (this.qThread != null) {
      this.qThread.interrupt();
      this.qThread = null;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\EventQueue.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */