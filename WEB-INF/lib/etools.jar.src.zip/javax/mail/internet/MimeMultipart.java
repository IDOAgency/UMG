/*     */ package javax.mail.internet;
/*     */ 
/*     */ import com.sun.mail.util.LineInputStream;
/*     */ import com.sun.mail.util.LineOutputStream;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.BodyPart;
/*     */ import javax.mail.MessageAware;
/*     */ import javax.mail.MessageContext;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Multipart;
/*     */ import javax.mail.MultipartDataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimeMultipart
/*     */   extends Multipart
/*     */ {
/*     */   protected DataSource ds;
/*     */   protected boolean parsed = true;
/*     */   
/*  55 */   public MimeMultipart() { this("mixed"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeMultipart(String paramString) {
/*  68 */     ContentType contentType = new ContentType("multipart", paramString, null);
/*  69 */     contentType.setParameter("boundary", UniqueValue.getUniqueValue());
/*  70 */     this.contentType = contentType.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeMultipart(DataSource paramDataSource) throws MessagingException {
/*  93 */     if (paramDataSource instanceof MessageAware) {
/*  94 */       MessageContext messageContext = ((MessageAware)paramDataSource).getMessageContext();
/*  95 */       setParent(messageContext.getPart());
/*     */     } 
/*     */     
/*  98 */     if (paramDataSource instanceof MultipartDataSource) {
/*     */       
/* 100 */       setMultipartDataSource((MultipartDataSource)paramDataSource);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 106 */     this.parsed = false;
/* 107 */     this.ds = paramDataSource;
/* 108 */     this.contentType = paramDataSource.getContentType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubType(String paramString) {
/* 120 */     ContentType contentType = new ContentType(this.contentType);
/* 121 */     contentType.setSubType(paramString);
/* 122 */     this.contentType = contentType.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCount() throws MessagingException {
/* 131 */     parse();
/* 132 */     return super.getCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BodyPart getBodyPart(int paramInt) throws MessagingException {
/* 144 */     parse();
/* 145 */     return super.getBodyPart(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BodyPart getBodyPart(String paramString) throws MessagingException {
/* 157 */     parse();
/*     */     
/* 159 */     int i = getCount();
/* 160 */     for (byte b = 0; b < i; b++) {
/* 161 */       MimeBodyPart mimeBodyPart = (MimeBodyPart)getBodyPart(b);
/* 162 */       if (mimeBodyPart.getContentID().equals(paramString))
/* 163 */         return mimeBodyPart; 
/*     */     } 
/* 165 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateHeaders() {
/* 186 */     for (byte b = 0; b < this.parts.size(); b++) {
/* 187 */       ((MimeBodyPart)this.parts.elementAt(b)).updateHeaders();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(OutputStream paramOutputStream) throws IOException, MessagingException {
/* 196 */     parse();
/*     */     
/* 198 */     String str = "--" + (
/* 199 */       new ContentType(this.contentType)).getParameter("boundary");
/* 200 */     LineOutputStream lineOutputStream = new LineOutputStream(paramOutputStream);
/*     */     
/* 202 */     for (byte b = 0; b < this.parts.size(); b++) {
/* 203 */       lineOutputStream.writeln(str);
/* 204 */       ((MimeBodyPart)this.parts.elementAt(b)).writeTo(paramOutputStream);
/* 205 */       lineOutputStream.writeln();
/*     */     } 
/*     */ 
/*     */     
/* 209 */     lineOutputStream.writeln(String.valueOf(str) + "--");
/*     */   }
/*     */   
/*     */   private void parse() {
/* 213 */     if (this.parsed) {
/*     */       return;
/*     */     }
/* 216 */     InputStream inputStream = null;
/*     */     
/*     */     try {
/* 219 */       inputStream = this.ds.getInputStream();
/* 220 */       if (!(inputStream instanceof java.io.ByteArrayInputStream) && 
/* 221 */         !(inputStream instanceof BufferedInputStream))
/* 222 */         inputStream = new BufferedInputStream(inputStream); 
/* 223 */     } catch (Exception exception) {
/* 224 */       throw new MessagingException("No inputstream from datasource");
/*     */     } 
/*     */     
/* 227 */     ContentType contentType = new ContentType(this.contentType);
/* 228 */     String str = "--" + contentType.getParameter("boundary");
/* 229 */     int i = str.length();
/* 230 */     byte[] arrayOfByte = new byte[i];
/* 231 */     str.getBytes(0, i, arrayOfByte, 0);
/*     */ 
/*     */     
/*     */     try {
/* 235 */       LineInputStream lineInputStream = new LineInputStream(inputStream); String str1; do {
/*     */       
/* 237 */       } while ((str1 = lineInputStream.readLine()) != null && 
/* 238 */         !str1.trim().equals(str));
/*     */ 
/*     */       
/* 241 */       if (str1 == null) {
/* 242 */         throw new MessagingException("Missing start boundary");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 248 */       boolean bool = false;
/* 249 */       while (!bool) {
/*     */ 
/*     */ 
/*     */         
/* 253 */         InternetHeaders internetHeaders = new InternetHeaders(inputStream);
/*     */         
/* 255 */         if (!inputStream.markSupported()) {
/* 256 */           throw new MessagingException("Stream doesn't support mark");
/*     */         }
/* 258 */         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */         
/* 260 */         boolean bool1 = true;
/*     */         
/* 262 */         int j = -1, k = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         while (true) {
/* 268 */           if (bool1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 274 */             inputStream.mark(i + 4 + 1000);
/*     */             byte b;
/* 276 */             for (b = 0; b < i && 
/* 277 */               inputStream.read() == arrayOfByte[b]; b++);
/*     */             
/* 279 */             if (b == i) {
/*     */               
/* 281 */               int n = inputStream.read();
/* 282 */               if (n == 45 && 
/* 283 */                 inputStream.read() == 45) {
/* 284 */                 bool = true;
/* 285 */                 n = inputStream.read();
/*     */               } 
/*     */ 
/*     */               
/* 289 */               while (n == 32 || n == 9) {
/* 290 */                 n = inputStream.read();
/*     */               }
/* 292 */               if (n != 10) {
/*     */                 
/* 294 */                 if (n == 13) {
/* 295 */                   inputStream.mark(1);
/* 296 */                   if (inputStream.read() != 10)
/* 297 */                     inputStream.reset();  break;
/*     */                 } 
/*     */               } else {
/*     */                 break;
/*     */               } 
/* 302 */             }  inputStream.reset();
/*     */ 
/*     */ 
/*     */             
/* 306 */             if (j != -1) {
/* 307 */               byteArrayOutputStream.write(j);
/* 308 */               if (k != -1)
/* 309 */                 byteArrayOutputStream.write(k); 
/* 310 */               j = k = -1;
/*     */             } 
/*     */           } 
/*     */           
/*     */           int m;
/* 315 */           if ((m = inputStream.read()) < 0) {
/* 316 */             bool = true;
/*     */ 
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */ 
/*     */           
/* 324 */           if (m == 13 || m == 10) {
/* 325 */             bool1 = true;
/* 326 */             j = m;
/* 327 */             if (m == 13) {
/* 328 */               inputStream.mark(1);
/* 329 */               if ((m = inputStream.read()) == 10) {
/* 330 */                 k = m; continue;
/*     */               } 
/* 332 */               inputStream.reset();
/*     */             }  continue;
/*     */           } 
/* 335 */           bool1 = false;
/* 336 */           byteArrayOutputStream.write(m);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 343 */         MimeBodyPart mimeBodyPart = 
/* 344 */           new MimeBodyPart(internetHeaders, byteArrayOutputStream.toByteArray());
/* 345 */         addBodyPart(mimeBodyPart);
/*     */       } 
/* 347 */     } catch (IOException iOException) {
/* 348 */       throw new MessagingException("IO Error", iOException);
/*     */     } 
/*     */     
/* 351 */     this.parsed = true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\MimeMultipart.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */