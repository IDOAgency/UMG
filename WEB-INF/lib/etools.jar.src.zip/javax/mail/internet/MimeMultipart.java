package javax.mail.internet;

import com.sun.mail.util.LineInputStream;
import com.sun.mail.util.LineOutputStream;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.MessageAware;
import javax.mail.MessageContext;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.MultipartDataSource;

public class MimeMultipart extends Multipart {
  protected DataSource ds;
  
  protected boolean parsed = true;
  
  public MimeMultipart() { this("mixed"); }
  
  public MimeMultipart(String paramString) {
    ContentType contentType = new ContentType("multipart", paramString, null);
    contentType.setParameter("boundary", UniqueValue.getUniqueValue());
    this.contentType = contentType.toString();
  }
  
  public MimeMultipart(DataSource paramDataSource) throws MessagingException {
    if (paramDataSource instanceof MessageAware) {
      MessageContext messageContext = ((MessageAware)paramDataSource).getMessageContext();
      setParent(messageContext.getPart());
    } 
    if (paramDataSource instanceof MultipartDataSource) {
      setMultipartDataSource((MultipartDataSource)paramDataSource);
      return;
    } 
    this.parsed = false;
    this.ds = paramDataSource;
    this.contentType = paramDataSource.getContentType();
  }
  
  public void setSubType(String paramString) {
    ContentType contentType = new ContentType(this.contentType);
    contentType.setSubType(paramString);
    this.contentType = contentType.toString();
  }
  
  public int getCount() throws MessagingException {
    parse();
    return super.getCount();
  }
  
  public BodyPart getBodyPart(int paramInt) throws MessagingException {
    parse();
    return super.getBodyPart(paramInt);
  }
  
  public BodyPart getBodyPart(String paramString) throws MessagingException {
    parse();
    int i = getCount();
    for (byte b = 0; b < i; b++) {
      MimeBodyPart mimeBodyPart = (MimeBodyPart)getBodyPart(b);
      if (mimeBodyPart.getContentID().equals(paramString))
        return mimeBodyPart; 
    } 
    return null;
  }
  
  protected void updateHeaders() {
    for (byte b = 0; b < this.parts.size(); b++)
      ((MimeBodyPart)this.parts.elementAt(b)).updateHeaders(); 
  }
  
  public void writeTo(OutputStream paramOutputStream) throws IOException, MessagingException {
    parse();
    String str = "--" + (
      new ContentType(this.contentType)).getParameter("boundary");
    LineOutputStream lineOutputStream = new LineOutputStream(paramOutputStream);
    for (byte b = 0; b < this.parts.size(); b++) {
      lineOutputStream.writeln(str);
      ((MimeBodyPart)this.parts.elementAt(b)).writeTo(paramOutputStream);
      lineOutputStream.writeln();
    } 
    lineOutputStream.writeln(String.valueOf(str) + "--");
  }
  
  private void parse() {
    if (this.parsed)
      return; 
    InputStream inputStream = null;
    try {
      inputStream = this.ds.getInputStream();
      if (!(inputStream instanceof java.io.ByteArrayInputStream) && 
        !(inputStream instanceof BufferedInputStream))
        inputStream = new BufferedInputStream(inputStream); 
    } catch (Exception exception) {
      throw new MessagingException("No inputstream from datasource");
    } 
    ContentType contentType = new ContentType(this.contentType);
    String str = "--" + contentType.getParameter("boundary");
    int i = str.length();
    byte[] arrayOfByte = new byte[i];
    str.getBytes(0, i, arrayOfByte, 0);
    try {
      LineInputStream lineInputStream = new LineInputStream(inputStream);
      String str1;
      do {
      
      } while ((str1 = lineInputStream.readLine()) != null && 
        !str1.trim().equals(str));
      if (str1 == null)
        throw new MessagingException("Missing start boundary"); 
      boolean bool = false;
      while (!bool) {
        InternetHeaders internetHeaders = new InternetHeaders(inputStream);
        if (!inputStream.markSupported())
          throw new MessagingException("Stream doesn't support mark"); 
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        boolean bool1 = true;
        int j = -1, k = -1;
        while (true) {
          if (bool1) {
            inputStream.mark(i + 4 + 1000);
            byte b;
            for (b = 0; b < i && 
              inputStream.read() == arrayOfByte[b]; b++);
            if (b == i) {
              int n = inputStream.read();
              if (n == 45 && 
                inputStream.read() == 45) {
                bool = true;
                n = inputStream.read();
              } 
              while (n == 32 || n == 9)
                n = inputStream.read(); 
              if (n != 10) {
                if (n == 13) {
                  inputStream.mark(1);
                  if (inputStream.read() != 10)
                    inputStream.reset(); 
                  break;
                } 
              } else {
                break;
              } 
            } 
            inputStream.reset();
            if (j != -1) {
              byteArrayOutputStream.write(j);
              if (k != -1)
                byteArrayOutputStream.write(k); 
              j = k = -1;
            } 
          } 
          int m;
          if ((m = inputStream.read()) < 0) {
            bool = true;
            break;
          } 
          if (m == 13 || m == 10) {
            bool1 = true;
            j = m;
            if (m == 13) {
              inputStream.mark(1);
              if ((m = inputStream.read()) == 10) {
                k = m;
                continue;
              } 
              inputStream.reset();
            } 
            continue;
          } 
          bool1 = false;
          byteArrayOutputStream.write(m);
        } 
        MimeBodyPart mimeBodyPart = 
          new MimeBodyPart(internetHeaders, byteArrayOutputStream.toByteArray());
        addBodyPart(mimeBodyPart);
      } 
    } catch (IOException iOException) {
      throw new MessagingException("IO Error", iOException);
    } 
    this.parsed = true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\MimeMultipart.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */