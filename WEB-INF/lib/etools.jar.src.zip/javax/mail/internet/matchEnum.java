package javax.mail.internet;

import java.util.Enumeration;
import java.util.Vector;
import javax.mail.Header;

class matchEnum implements Enumeration {
  private Enumeration e;
  
  private String[] names;
  
  private boolean match;
  
  private boolean want_line;
  
  private hdr next_header;
  
  matchEnum(Vector paramVector, String[] paramArrayOfString, boolean paramBoolean1, boolean paramBoolean2) {
    this.e = paramVector.elements();
    this.names = paramArrayOfString;
    this.match = paramBoolean1;
    this.want_line = paramBoolean2;
    this.next_header = null;
  }
  
  public boolean hasMoreElements() {
    if (this.next_header == null)
      this.next_header = nextMatch(); 
    return !(this.next_header == null);
  }
  
  public Object nextElement() {
    if (this.next_header != null) {
      hdr hdr1 = this.next_header;
      this.next_header = null;
      if (this.want_line)
        return hdr1.line; 
      return new Header(hdr1.getName(), 
          hdr1.getValue());
    } 
    return null;
  }
  
  private hdr nextMatch() {
    label21: while (this.e.hasMoreElements()) {
      hdr hdr1 = (hdr)this.e.nextElement();
      if (hdr1.line != null) {
        if (this.names == null)
          return this.match ? null : hdr1; 
        for (byte b = 0; b < this.names.length; b++) {
          if (this.names[b].equalsIgnoreCase(hdr1.name)) {
            if (this.match)
              return hdr1; 
            continue label21;
          } 
        } 
        if (!this.match)
          return hdr1; 
      } 
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\matchEnum.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */