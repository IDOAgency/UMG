/*    */ package javax.mail.internet;
/*    */ 
/*    */ import javax.mail.MessagingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParseException
/*    */   extends MessagingException
/*    */ {
/*    */   public ParseException() {}
/*    */   
/* 32 */   public ParseException(String paramString) { super(paramString); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\ParseException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */