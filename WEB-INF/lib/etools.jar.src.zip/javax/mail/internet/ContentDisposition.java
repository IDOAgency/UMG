package javax.mail.internet;

class ContentDisposition {
  private String disposition;
  
  private ParameterList list;
  
  public ContentDisposition() {}
  
  public ContentDisposition(String paramString, ParameterList paramParameterList) {
    this.disposition = paramString;
    this.list = paramParameterList;
  }
  
  public ContentDisposition(String paramString) throws ParseException {
    HeaderTokenizer headerTokenizer = new HeaderTokenizer(paramString, "()<>@,;:\\\"\t []/?=");
    HeaderTokenizer.Token token = headerTokenizer.next();
    if (token.getType() != -1)
      throw new ParseException(); 
    this.disposition = token.getValue();
    String str = headerTokenizer.getRemainder();
    if (str != null)
      this.list = new ParameterList(str); 
  }
  
  public String getDisposition() { return this.disposition; }
  
  public String getParameter(String paramString) {
    if (this.list == null)
      return null; 
    return this.list.get(paramString);
  }
  
  public ParameterList getParameterList() { return this.list; }
  
  public void setDisposition(String paramString) throws ParseException { this.disposition = paramString; }
  
  public void setParameter(String paramString1, String paramString2) {
    if (this.list == null)
      this.list = new ParameterList(); 
    this.list.set(paramString1, paramString2);
  }
  
  public void setParameterList(ParameterList paramParameterList) { this.list = paramParameterList; }
  
  public String toString() {
    if (this.disposition == null)
      return null; 
    if (this.list == null)
      return this.disposition; 
    StringBuffer stringBuffer = new StringBuffer(this.disposition);
    stringBuffer.append(this.list.toString());
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\ContentDisposition.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */