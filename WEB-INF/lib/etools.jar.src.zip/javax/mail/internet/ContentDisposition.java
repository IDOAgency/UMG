/*     */ package javax.mail.internet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ContentDisposition
/*     */ {
/*     */   private String disposition;
/*     */   private ParameterList list;
/*     */   
/*     */   public ContentDisposition() {}
/*     */   
/*     */   public ContentDisposition(String paramString, ParameterList paramParameterList) {
/*  39 */     this.disposition = paramString;
/*  40 */     this.list = paramParameterList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentDisposition(String paramString) throws ParseException {
/*  52 */     HeaderTokenizer headerTokenizer = new HeaderTokenizer(paramString, "()<>@,;:\\\"\t []/?=");
/*     */ 
/*     */ 
/*     */     
/*  56 */     HeaderTokenizer.Token token = headerTokenizer.next();
/*  57 */     if (token.getType() != -1)
/*  58 */       throw new ParseException(); 
/*  59 */     this.disposition = token.getValue();
/*     */ 
/*     */     
/*  62 */     String str = headerTokenizer.getRemainder();
/*  63 */     if (str != null) {
/*  64 */       this.list = new ParameterList(str);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public String getDisposition() { return this.disposition; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParameter(String paramString) {
/*  81 */     if (this.list == null) {
/*  82 */       return null;
/*     */     }
/*  84 */     return this.list.get(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public ParameterList getParameterList() { return this.list; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public void setDisposition(String paramString) throws ParseException { this.disposition = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(String paramString1, String paramString2) {
/* 113 */     if (this.list == null) {
/* 114 */       this.list = new ParameterList();
/*     */     }
/* 116 */     this.list.set(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public void setParameterList(ParameterList paramParameterList) { this.list = paramParameterList; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 135 */     if (this.disposition == null) {
/* 136 */       return null;
/*     */     }
/* 138 */     if (this.list == null) {
/* 139 */       return this.disposition;
/*     */     }
/* 141 */     StringBuffer stringBuffer = new StringBuffer(this.disposition);
/* 142 */     stringBuffer.append(this.list.toString());
/* 143 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\ContentDisposition.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */