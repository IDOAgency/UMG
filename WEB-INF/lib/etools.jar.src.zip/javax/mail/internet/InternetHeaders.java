package javax.mail.internet;

import com.sun.mail.util.LineInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.NoSuchElementException;
import java.util.Vector;
import javax.mail.MessagingException;

public class InternetHeaders {
  private Vector headers;
  
  public InternetHeaders() {
    this.headers = new Vector();
    this.headers.addElement(new hdr("Return-Path", null));
    this.headers.addElement(new hdr("Received", null));
    this.headers.addElement(new hdr("Message-Id", null));
    this.headers.addElement(new hdr("Resent-Date", null));
    this.headers.addElement(new hdr("Date", null));
    this.headers.addElement(new hdr("Resent-From", null));
    this.headers.addElement(new hdr("From", null));
    this.headers.addElement(new hdr("Reply-To", null));
    this.headers.addElement(new hdr("To", null));
    this.headers.addElement(new hdr("Subject", null));
    this.headers.addElement(new hdr("Cc", null));
    this.headers.addElement(new hdr("In-Reply-To", null));
    this.headers.addElement(new hdr("Resent-Message-Id", null));
    this.headers.addElement(new hdr("Errors-To", null));
    this.headers.addElement(new hdr("Mime-Version", null));
    this.headers.addElement(new hdr("Content-Type", null));
    this.headers.addElement(new hdr("Content-Transfer-Encoding", null));
    this.headers.addElement(new hdr("Content-MD5", null));
    this.headers.addElement(new hdr(":", null));
    this.headers.addElement(new hdr("Content-Length", null));
    this.headers.addElement(new hdr("Status", null));
  }
  
  public InternetHeaders(InputStream paramInputStream) throws MessagingException {
    this.headers = new Vector();
    load(paramInputStream);
  }
  
  public void load(InputStream paramInputStream) throws MessagingException {
    LineInputStream lineInputStream = new LineInputStream(paramInputStream);
    try {
      String str;
      while ((str = lineInputStream.readLine()) != null && 
        str.length() != 0)
        addHeaderLine(str); 
      return;
    } catch (IOException iOException) {
      throw new MessagingException("Error in input stream", iOException);
    } 
  }
  
  public String[] getHeader(String paramString) {
    Enumeration enumeration = this.headers.elements();
    Vector vector = new Vector();
    while (enumeration.hasMoreElements()) {
      hdr hdr = (hdr)enumeration.nextElement();
      if (paramString.equalsIgnoreCase(hdr.name) && hdr.line != null)
        vector.addElement(hdr.getValue()); 
    } 
    if (vector.size() == 0)
      return null; 
    String[] arrayOfString = new String[vector.size()];
    vector.copyInto(arrayOfString);
    return arrayOfString;
  }
  
  public String getHeader(String paramString1, String paramString2) {
    String[] arrayOfString = getHeader(paramString1);
    if (arrayOfString == null)
      return null; 
    if (arrayOfString.length == 1 || paramString2 == null)
      return arrayOfString[0]; 
    StringBuffer stringBuffer = new StringBuffer(arrayOfString[0]);
    for (byte b = 1; b < arrayOfString.length; b++) {
      stringBuffer.append(paramString2);
      stringBuffer.append(arrayOfString[b]);
    } 
    return stringBuffer.toString();
  }
  
  public void setHeader(String paramString1, String paramString2) {
    boolean bool = false;
    for (byte b = 0; b < this.headers.size(); b++) {
      hdr hdr = (hdr)this.headers.elementAt(b);
      if (paramString1.equalsIgnoreCase(hdr.name))
        if (!bool) {
          int i;
          if (hdr.line != null && (i = hdr.line.indexOf(':')) >= 0) {
            hdr.line = String.valueOf(hdr.line.substring(0, i + 1)) + " " + paramString2;
          } else {
            hdr.line = String.valueOf(paramString1) + ": " + paramString2;
          } 
          bool = true;
        } else {
          this.headers.removeElementAt(b);
          b--;
        }  
    } 
    if (!bool)
      addHeader(paramString1, paramString2); 
  }
  
  public void addHeader(String paramString1, String paramString2) {
    int i = this.headers.size();
    for (int j = i - 1; j >= 0; j--) {
      hdr hdr = (hdr)this.headers.elementAt(j);
      if (paramString1.equalsIgnoreCase(hdr.name)) {
        this.headers.insertElementAt(new hdr(paramString1, paramString2), j + 1);
        return;
      } 
      if (hdr.name.equals(":"))
        i = j; 
    } 
    this.headers.insertElementAt(new hdr(paramString1, paramString2), i);
  }
  
  public void removeHeader(String paramString) {
    for (byte b = 0; b < this.headers.size(); b++) {
      hdr hdr = (hdr)this.headers.elementAt(b);
      if (paramString.equalsIgnoreCase(hdr.name))
        hdr.line = null; 
    } 
  }
  
  public Enumeration getAllHeaders() { return new matchEnum(this.headers, null, false, false); }
  
  public Enumeration getMatchingHeaders(String[] paramArrayOfString) { return new matchEnum(this.headers, paramArrayOfString, true, false); }
  
  public Enumeration getNonMatchingHeaders(String[] paramArrayOfString) { return new matchEnum(this.headers, paramArrayOfString, false, false); }
  
  public void addHeaderLine(String paramString) {
    try {
      char c = paramString.charAt(0);
      if (c == ' ' || c == '\t') {
        hdr hdr = (hdr)this.headers.lastElement();
        hdr.line = String.valueOf(hdr.line) + "\r\n" + paramString;
        return;
      } 
      this.headers.addElement(new hdr(paramString));
      return;
    } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
      return;
    } catch (NoSuchElementException noSuchElementException) {
      return;
    } 
  }
  
  public Enumeration getAllHeaderLines() { return getNonMatchingHeaderLines(null); }
  
  public Enumeration getMatchingHeaderLines(String[] paramArrayOfString) { return new matchEnum(this.headers, paramArrayOfString, true, true); }
  
  public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString) { return new matchEnum(this.headers, paramArrayOfString, false, true); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\InternetHeaders.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */