/*     */ package javax.mail.internet;
/*     */ 
/*     */ import com.sun.mail.util.LineInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Vector;
/*     */ import javax.mail.MessagingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InternetHeaders
/*     */ {
/*     */   private Vector headers;
/*     */   
/*     */   public InternetHeaders() {
/*  43 */     this.headers = new Vector();
/*  44 */     this.headers.addElement(new hdr("Return-Path", null));
/*  45 */     this.headers.addElement(new hdr("Received", null));
/*  46 */     this.headers.addElement(new hdr("Message-Id", null));
/*  47 */     this.headers.addElement(new hdr("Resent-Date", null));
/*  48 */     this.headers.addElement(new hdr("Date", null));
/*  49 */     this.headers.addElement(new hdr("Resent-From", null));
/*  50 */     this.headers.addElement(new hdr("From", null));
/*  51 */     this.headers.addElement(new hdr("Reply-To", null));
/*  52 */     this.headers.addElement(new hdr("To", null));
/*  53 */     this.headers.addElement(new hdr("Subject", null));
/*  54 */     this.headers.addElement(new hdr("Cc", null));
/*  55 */     this.headers.addElement(new hdr("In-Reply-To", null));
/*  56 */     this.headers.addElement(new hdr("Resent-Message-Id", null));
/*  57 */     this.headers.addElement(new hdr("Errors-To", null));
/*  58 */     this.headers.addElement(new hdr("Mime-Version", null));
/*  59 */     this.headers.addElement(new hdr("Content-Type", null));
/*  60 */     this.headers.addElement(new hdr("Content-Transfer-Encoding", null));
/*  61 */     this.headers.addElement(new hdr("Content-MD5", null));
/*  62 */     this.headers.addElement(new hdr(":", null));
/*  63 */     this.headers.addElement(new hdr("Content-Length", null));
/*  64 */     this.headers.addElement(new hdr("Status", null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InternetHeaders(InputStream paramInputStream) throws MessagingException {
/*  79 */     this.headers = new Vector();
/*  80 */     load(paramInputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void load(InputStream paramInputStream) throws MessagingException {
/*  98 */     LineInputStream lineInputStream = new LineInputStream(paramInputStream);
/*     */     try {
/*     */       String str;
/* 101 */       while ((str = lineInputStream.readLine()) != null && 
/* 102 */         str.length() != 0)
/*     */       {
/*     */ 
/*     */         
/* 106 */         addHeaderLine(str); } 
/*     */       return;
/* 108 */     } catch (IOException iOException) {
/* 109 */       throw new MessagingException("Error in input stream", iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getHeader(String paramString) {
/* 120 */     Enumeration enumeration = this.headers.elements();
/*     */     
/* 122 */     Vector vector = new Vector();
/*     */     
/* 124 */     while (enumeration.hasMoreElements()) {
/* 125 */       hdr hdr = (hdr)enumeration.nextElement();
/* 126 */       if (paramString.equalsIgnoreCase(hdr.name) && hdr.line != null) {
/* 127 */         vector.addElement(hdr.getValue());
/*     */       }
/*     */     } 
/* 130 */     if (vector.size() == 0) {
/* 131 */       return null;
/*     */     }
/* 133 */     String[] arrayOfString = new String[vector.size()];
/* 134 */     vector.copyInto(arrayOfString);
/* 135 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHeader(String paramString1, String paramString2) {
/* 150 */     String[] arrayOfString = getHeader(paramString1);
/*     */     
/* 152 */     if (arrayOfString == null) {
/* 153 */       return null;
/*     */     }
/* 155 */     if (arrayOfString.length == 1 || paramString2 == null) {
/* 156 */       return arrayOfString[0];
/*     */     }
/* 158 */     StringBuffer stringBuffer = new StringBuffer(arrayOfString[0]);
/* 159 */     for (byte b = 1; b < arrayOfString.length; b++) {
/* 160 */       stringBuffer.append(paramString2);
/* 161 */       stringBuffer.append(arrayOfString[b]);
/*     */     } 
/* 163 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeader(String paramString1, String paramString2) {
/* 177 */     boolean bool = false;
/*     */     
/* 179 */     for (byte b = 0; b < this.headers.size(); b++) {
/* 180 */       hdr hdr = (hdr)this.headers.elementAt(b);
/* 181 */       if (paramString1.equalsIgnoreCase(hdr.name)) {
/* 182 */         if (!bool) {
/*     */           int i;
/* 184 */           if (hdr.line != null && (i = hdr.line.indexOf(':')) >= 0) {
/* 185 */             hdr.line = String.valueOf(hdr.line.substring(0, i + 1)) + " " + paramString2;
/*     */           } else {
/* 187 */             hdr.line = String.valueOf(paramString1) + ": " + paramString2;
/*     */           } 
/* 189 */           bool = true;
/*     */         } else {
/* 191 */           this.headers.removeElementAt(b);
/* 192 */           b--;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 197 */     if (!bool) {
/* 198 */       addHeader(paramString1, paramString2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addHeader(String paramString1, String paramString2) {
/* 211 */     int i = this.headers.size();
/* 212 */     for (int j = i - 1; j >= 0; j--) {
/* 213 */       hdr hdr = (hdr)this.headers.elementAt(j);
/* 214 */       if (paramString1.equalsIgnoreCase(hdr.name)) {
/* 215 */         this.headers.insertElementAt(new hdr(paramString1, paramString2), j + 1);
/*     */         
/*     */         return;
/*     */       } 
/* 219 */       if (hdr.name.equals(":"))
/* 220 */         i = j; 
/*     */     } 
/* 222 */     this.headers.insertElementAt(new hdr(paramString1, paramString2), i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeHeader(String paramString) {
/* 230 */     for (byte b = 0; b < this.headers.size(); b++) {
/* 231 */       hdr hdr = (hdr)this.headers.elementAt(b);
/* 232 */       if (paramString.equalsIgnoreCase(hdr.name)) {
/* 233 */         hdr.line = null;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 245 */   public Enumeration getAllHeaders() { return new matchEnum(this.headers, null, false, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 253 */   public Enumeration getMatchingHeaders(String[] paramArrayOfString) { return new matchEnum(this.headers, paramArrayOfString, true, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 261 */   public Enumeration getNonMatchingHeaders(String[] paramArrayOfString) { return new matchEnum(this.headers, paramArrayOfString, false, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addHeaderLine(String paramString) {
/*     */     try {
/* 275 */       char c = paramString.charAt(0);
/* 276 */       if (c == ' ' || c == '\t') {
/* 277 */         hdr hdr = (hdr)this.headers.lastElement();
/* 278 */         hdr.line = String.valueOf(hdr.line) + "\r\n" + paramString; return;
/*     */       } 
/* 280 */       this.headers.addElement(new hdr(paramString)); return;
/* 281 */     } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
/*     */       
/*     */       return;
/* 284 */     } catch (NoSuchElementException noSuchElementException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 293 */   public Enumeration getAllHeaderLines() { return getNonMatchingHeaderLines(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   public Enumeration getMatchingHeaderLines(String[] paramArrayOfString) { return new matchEnum(this.headers, paramArrayOfString, true, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 307 */   public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString) { return new matchEnum(this.headers, paramArrayOfString, false, true); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\InternetHeaders.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */