/*     */ package javax.mail.internet;
/*     */ 
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import javax.mail.Address;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NewsAddress
/*     */   extends Address
/*     */ {
/*     */   protected String newsgroup;
/*     */   protected String host;
/*     */   
/*     */   public NewsAddress() {}
/*     */   
/*  36 */   public NewsAddress(String paramString) { this(paramString, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NewsAddress(String paramString1, String paramString2) {
/*  46 */     this.newsgroup = paramString1;
/*  47 */     this.host = paramString2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public String getType() { return "news"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public void setNewsgroup(String paramString) { this.newsgroup = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public String getNewsgroup() { return this.newsgroup; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public void setHost(String paramString) { this.host = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public String getHost() { return this.host; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public String toString() { return this.newsgroup; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 107 */     if (!(paramObject instanceof NewsAddress)) {
/* 108 */       return false;
/*     */     }
/* 110 */     NewsAddress newsAddress = (NewsAddress)paramObject;
/* 111 */     return !(!this.newsgroup.equals(newsAddress.newsgroup) || ((
/* 112 */       this.host != null || newsAddress.host != null) && (
/* 113 */       this.host == null || newsAddress.host == null || !this.host.equalsIgnoreCase(newsAddress.host))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 120 */     int i = 0;
/* 121 */     if (this.newsgroup != null)
/* 122 */       i += this.newsgroup.hashCode(); 
/* 123 */     if (this.host != null)
/* 124 */       i += this.host.toLowerCase().hashCode(); 
/* 125 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(Address[] paramArrayOfAddress) {
/* 141 */     if (paramArrayOfAddress == null || paramArrayOfAddress.length == 0) {
/* 142 */       return null;
/*     */     }
/* 144 */     StringBuffer stringBuffer = 
/* 145 */       new StringBuffer(((NewsAddress)paramArrayOfAddress[0]).toString());
/* 146 */     for (byte b = 1; b < paramArrayOfAddress.length; b++) {
/* 147 */       stringBuffer.append(",").append(((NewsAddress)paramArrayOfAddress[b]).toString());
/*     */     }
/* 149 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NewsAddress[] parse(String paramString) throws AddressException {
/* 163 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ",");
/* 164 */     Vector vector = new Vector();
/* 165 */     while (stringTokenizer.hasMoreTokens()) {
/* 166 */       String str = stringTokenizer.nextToken();
/* 167 */       vector.addElement(new NewsAddress(str));
/*     */     } 
/* 169 */     int i = vector.size();
/* 170 */     NewsAddress[] arrayOfNewsAddress = new NewsAddress[i];
/* 171 */     if (i > 0)
/* 172 */       vector.copyInto(arrayOfNewsAddress); 
/* 173 */     return arrayOfNewsAddress;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\NewsAddress.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */