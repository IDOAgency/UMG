package javax.mail.internet;

import java.util.StringTokenizer;
import java.util.Vector;
import javax.mail.Address;

public class NewsAddress extends Address {
  protected String newsgroup;
  
  protected String host;
  
  public NewsAddress() {}
  
  public NewsAddress(String paramString) { this(paramString, null); }
  
  public NewsAddress(String paramString1, String paramString2) {
    this.newsgroup = paramString1;
    this.host = paramString2;
  }
  
  public String getType() { return "news"; }
  
  public void setNewsgroup(String paramString) { this.newsgroup = paramString; }
  
  public String getNewsgroup() { return this.newsgroup; }
  
  public void setHost(String paramString) { this.host = paramString; }
  
  public String getHost() { return this.host; }
  
  public String toString() { return this.newsgroup; }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof NewsAddress))
      return false; 
    NewsAddress newsAddress = (NewsAddress)paramObject;
    return !(!this.newsgroup.equals(newsAddress.newsgroup) || ((
      this.host != null || newsAddress.host != null) && (
      this.host == null || newsAddress.host == null || !this.host.equalsIgnoreCase(newsAddress.host))));
  }
  
  public int hashCode() {
    int i = 0;
    if (this.newsgroup != null)
      i += this.newsgroup.hashCode(); 
    if (this.host != null)
      i += this.host.toLowerCase().hashCode(); 
    return i;
  }
  
  public static String toString(Address[] paramArrayOfAddress) {
    if (paramArrayOfAddress == null || paramArrayOfAddress.length == 0)
      return null; 
    StringBuffer stringBuffer = 
      new StringBuffer(((NewsAddress)paramArrayOfAddress[0]).toString());
    for (byte b = 1; b < paramArrayOfAddress.length; b++)
      stringBuffer.append(",").append(((NewsAddress)paramArrayOfAddress[b]).toString()); 
    return stringBuffer.toString();
  }
  
  public static NewsAddress[] parse(String paramString) throws AddressException {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, ",");
    Vector vector = new Vector();
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken();
      vector.addElement(new NewsAddress(str));
    } 
    int i = vector.size();
    NewsAddress[] arrayOfNewsAddress = new NewsAddress[i];
    if (i > 0)
      vector.copyInto(arrayOfNewsAddress); 
    return arrayOfNewsAddress;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\NewsAddress.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */