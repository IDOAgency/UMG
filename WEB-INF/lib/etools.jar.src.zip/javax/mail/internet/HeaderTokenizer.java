/*     */ package javax.mail.internet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HeaderTokenizer
/*     */ {
/*     */   private String string;
/*     */   private boolean skipComments;
/*     */   private String delimiters;
/*     */   private int currentPos;
/*     */   private int maxPos;
/*     */   private int nextPos;
/*     */   private int peekPos;
/*     */   public static final String RFC822 = "()<>@,;:\\\"\t []";
/*     */   public static final String MIME = "()<>@,;:\\\"\t []/?=";
/*     */   
/*     */   public static class Token
/*     */   {
/*     */     private int type;
/*     */     private String value;
/*     */     public static final int ATOM = -1;
/*     */     public static final int QUOTEDSTRING = -2;
/*     */     public static final int COMMENT = -3;
/*     */     public static final int EOF = -4;
/*     */     
/*     */     public Token(int param1Int, String param1String) {
/*  64 */       this.type = param1Int;
/*  65 */       this.value = param1String;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     public int getType() { return this.type; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     public String getValue() { return this.value; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   private static final Token EOFToken = new Token(-4, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HeaderTokenizer(String paramString1, String paramString2, boolean paramBoolean) {
/* 135 */     this.string = (paramString1 == null) ? "" : paramString1;
/* 136 */     this.skipComments = paramBoolean;
/* 137 */     this.delimiters = paramString2;
/* 138 */     this.currentPos = this.nextPos = this.peekPos = 0;
/* 139 */     this.maxPos = this.string.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public HeaderTokenizer(String paramString1, String paramString2) { this(paramString1, paramString2, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   public HeaderTokenizer(String paramString) { this(paramString, "()<>@,;:\\\"\t []"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token next() throws ParseException {
/* 173 */     this.currentPos = this.nextPos;
/* 174 */     Token token = getNext();
/* 175 */     this.nextPos = this.peekPos = this.currentPos;
/* 176 */     return token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token peek() throws ParseException {
/* 191 */     this.currentPos = this.peekPos;
/* 192 */     Token token = getNext();
/* 193 */     this.peekPos = this.currentPos;
/* 194 */     return token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 204 */   public String getRemainder() { return this.string.substring(this.nextPos); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Token getNext() throws ParseException {
/* 214 */     if (this.currentPos >= this.maxPos) {
/* 215 */       return EOFToken;
/*     */     }
/*     */     
/* 218 */     if (skipWhiteSpace() == -4) {
/* 219 */       return EOFToken;
/*     */     }
/*     */ 
/*     */     
/* 223 */     boolean bool = false;
/*     */     
/* 225 */     char c = this.string.charAt(this.currentPos);
/*     */ 
/*     */ 
/*     */     
/* 229 */     while (c == '(') {
/*     */ 
/*     */       
/* 232 */       int j = ++this.currentPos; byte b = 1;
/* 233 */       for (; b && this.currentPos < this.maxPos; 
/* 234 */         this.currentPos++) {
/* 235 */         c = this.string.charAt(this.currentPos);
/* 236 */         if (c == '\\') {
/* 237 */           this.currentPos++;
/* 238 */           bool = true;
/* 239 */         } else if (c == '\r') {
/* 240 */           bool = true;
/* 241 */         } else if (c == '(') {
/* 242 */           b++;
/* 243 */         } else if (c == ')') {
/* 244 */           b--;
/*     */         } 
/* 246 */       }  if (b != 0) {
/* 247 */         throw new ParseException("Unbalanced comments");
/*     */       }
/* 249 */       if (!this.skipComments) {
/*     */         String str;
/*     */ 
/*     */         
/* 253 */         if (bool) {
/* 254 */           str = filterToken(this.string, j, this.currentPos - 1);
/*     */         } else {
/* 256 */           str = this.string.substring(j, this.currentPos - 1);
/*     */         } 
/* 258 */         return new Token(-3, str);
/*     */       } 
/*     */ 
/*     */       
/* 262 */       if (skipWhiteSpace() == -4)
/* 263 */         return EOFToken; 
/* 264 */       c = this.string.charAt(this.currentPos);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 269 */     if (c == '"') {
/* 270 */       for (int j = ++this.currentPos; this.currentPos < this.maxPos; this.currentPos++) {
/* 271 */         c = this.string.charAt(this.currentPos);
/* 272 */         if (c == '\\') {
/* 273 */           this.currentPos++;
/* 274 */           bool = true;
/* 275 */         } else if (c == '\r') {
/* 276 */           bool = true;
/* 277 */         } else if (c == '"') {
/* 278 */           String str; this.currentPos++;
/*     */ 
/*     */           
/* 281 */           if (bool) {
/* 282 */             str = filterToken(this.string, j, this.currentPos - 1);
/*     */           } else {
/* 284 */             str = this.string.substring(j, this.currentPos - 1);
/*     */           } 
/* 286 */           return new Token(-2, str);
/*     */         } 
/*     */       } 
/* 289 */       throw new ParseException("Unbalanced quoted string");
/*     */     } 
/*     */ 
/*     */     
/* 293 */     if (c < ' ' || c >= '' || this.delimiters.indexOf(c) >= 0) {
/* 294 */       this.currentPos++;
/* 295 */       char[] arrayOfChar = new char[1];
/* 296 */       arrayOfChar[0] = c;
/* 297 */       return new Token(c, new String(arrayOfChar));
/*     */     } 
/*     */     
/*     */     int i;
/* 301 */     for (i = this.currentPos; this.currentPos < this.maxPos; this.currentPos++) {
/* 302 */       c = this.string.charAt(this.currentPos);
/*     */ 
/*     */       
/* 305 */       if (c < ' ' || c >= '' || c == '(' || c == ' ' || 
/* 306 */         c == '"' || this.delimiters.indexOf(c) >= 0)
/*     */         break; 
/*     */     } 
/* 309 */     return new Token(-1, this.string.substring(i, this.currentPos));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int skipWhiteSpace() {
/* 315 */     for (; this.currentPos < this.maxPos; this.currentPos++) {
/* 316 */       char c; if ((c = this.string.charAt(this.currentPos)) != ' ' && 
/* 317 */         c != '\t' && c != '\r' && c != '\n')
/* 318 */         return this.currentPos; 
/* 319 */     }  return -4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String filterToken(String paramString, int paramInt1, int paramInt2) {
/* 326 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 328 */     boolean bool1 = false;
/* 329 */     boolean bool2 = false;
/*     */     
/* 331 */     for (int i = paramInt1; i < paramInt2; i++) {
/* 332 */       char c = paramString.charAt(i);
/* 333 */       if (c == '\n' && bool2) {
/*     */ 
/*     */         
/* 336 */         bool2 = false;
/*     */       }
/*     */       else {
/*     */         
/* 340 */         bool2 = false;
/* 341 */         if (!bool1) {
/*     */           
/* 343 */           if (c == '\\') {
/* 344 */             bool1 = true;
/* 345 */           } else if (c == '\r') {
/* 346 */             bool2 = true;
/*     */           } else {
/* 348 */             stringBuffer.append(c);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 353 */           stringBuffer.append(c);
/* 354 */           bool1 = false;
/*     */         } 
/*     */       } 
/* 357 */     }  return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\HeaderTokenizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */