package javax.mail.internet;

class hdr {
  String name;
  
  String line;
  
  hdr(String paramString) {
    int i = paramString.indexOf(':');
    if (i < 0) {
      this.name = paramString.trim();
    } else {
      this.name = paramString.substring(0, i).trim();
    } 
    this.line = paramString;
  }
  
  hdr(String paramString1, String paramString2) {
    this.name = paramString1;
    if (paramString2 != null) {
      this.line = String.valueOf(paramString1) + ": " + paramString2;
      return;
    } 
    this.line = null;
  }
  
  String getName() { return this.name; }
  
  String getValue() {
    int i = this.line.indexOf(':');
    if (i < 0)
      return this.line; 
    int j;
    for (j = i + 1; j < this.line.length(); j++) {
      char c = this.line.charAt(j);
      if (c != ' ' && c != '\t' && c != '\r' && c != '\n')
        break; 
    } 
    return this.line.substring(j);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\hdr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */