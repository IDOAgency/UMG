/*     */ package javax.mail.internet;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.UnknownServiceException;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.MessageAware;
/*     */ import javax.mail.MessageContext;
/*     */ import javax.mail.MessagingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimePartDataSource
/*     */   implements DataSource, MessageAware
/*     */ {
/*     */   private MimePart part;
/*     */   private MessageContext context;
/*     */   
/*  32 */   public MimePartDataSource(MimePart paramMimePart) { this.part = paramMimePart; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/*     */     try {
/*     */       InputStream inputStream;
/*  55 */       if (this.part instanceof MimeBodyPart) {
/*  56 */         inputStream = ((MimeBodyPart)this.part).getContentStream();
/*  57 */       } else if (this.part instanceof MimeMessage) {
/*  58 */         inputStream = ((MimeMessage)this.part).getContentStream();
/*     */       } else {
/*  60 */         throw new MessagingException("Unknown part");
/*     */       } 
/*  62 */       String str = this.part.getEncoding();
/*  63 */       if (str != null) {
/*  64 */         return MimeUtility.decode(inputStream, str);
/*     */       }
/*  66 */       return inputStream;
/*  67 */     } catch (MessagingException messagingException) {
/*  68 */       throw new IOException(messagingException.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public OutputStream getOutputStream() throws IOException { throw new UnknownServiceException(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*     */     try {
/*  89 */       return this.part.getContentType();
/*  90 */     } catch (MessagingException messagingException) {
/*  91 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public String getName() { return ""; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageContext getMessageContext() {
/* 109 */     if (this.context == null)
/* 110 */       this.context = new MessageContext(this.part); 
/* 111 */     return this.context;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\MimePartDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */