package javax.mail.internet;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownServiceException;
import javax.activation.DataSource;
import javax.mail.MessageAware;
import javax.mail.MessageContext;
import javax.mail.MessagingException;

public class MimePartDataSource implements DataSource, MessageAware {
  private MimePart part;
  
  private MessageContext context;
  
  public MimePartDataSource(MimePart paramMimePart) { this.part = paramMimePart; }
  
  public InputStream getInputStream() throws IOException {
    try {
      InputStream inputStream;
      if (this.part instanceof MimeBodyPart) {
        inputStream = ((MimeBodyPart)this.part).getContentStream();
      } else if (this.part instanceof MimeMessage) {
        inputStream = ((MimeMessage)this.part).getContentStream();
      } else {
        throw new MessagingException("Unknown part");
      } 
      String str = this.part.getEncoding();
      if (str != null)
        return MimeUtility.decode(inputStream, str); 
      return inputStream;
    } catch (MessagingException messagingException) {
      throw new IOException(messagingException.getMessage());
    } 
  }
  
  public OutputStream getOutputStream() throws IOException { throw new UnknownServiceException(); }
  
  public String getContentType() {
    try {
      return this.part.getContentType();
    } catch (MessagingException messagingException) {
      return null;
    } 
  }
  
  public String getName() { return ""; }
  
  public MessageContext getMessageContext() {
    if (this.context == null)
      this.context = new MessageContext(this.part); 
    return this.context;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\MimePartDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */