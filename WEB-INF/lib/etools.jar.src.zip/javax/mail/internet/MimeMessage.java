package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.LineOutputStream;
import com.sun.mail.util.MailDateFormat;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;
import javax.activation.DataHandler;
import javax.mail.Address;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;

public class MimeMessage extends Message implements MimePart {
  protected DataHandler dh;
  
  protected byte[] content;
  
  protected InternetHeaders headers;
  
  protected Flags flags;
  
  private boolean modified = false;
  
  private static MailDateFormat mailDateFormat = new MailDateFormat();
  
  public MimeMessage(Session paramSession) {
    super(paramSession);
    this.modified = true;
    this.headers = new InternetHeaders();
    this.flags = new Flags();
  }
  
  public MimeMessage(Session paramSession, InputStream paramInputStream) throws MessagingException {
    super(paramSession);
    this.flags = new Flags();
    parse(paramInputStream);
  }
  
  protected MimeMessage(Folder paramFolder, int paramInt) {
    super(paramFolder, paramInt);
    this.flags = new Flags();
  }
  
  protected MimeMessage(Folder paramFolder, InputStream paramInputStream, int paramInt) throws MessagingException {
    this(paramFolder, paramInt);
    parse(paramInputStream);
  }
  
  protected MimeMessage(Folder paramFolder, InternetHeaders paramInternetHeaders, byte[] paramArrayOfByte, int paramInt) throws MessagingException {
    this(paramFolder, paramInt);
    this.headers = paramInternetHeaders;
    this.content = paramArrayOfByte;
  }
  
  private void parse(InputStream paramInputStream) throws MessagingException {
    if (!(paramInputStream instanceof ByteArrayInputStream) && 
      !(paramInputStream instanceof BufferedInputStream))
      paramInputStream = new BufferedInputStream(paramInputStream); 
    this.headers = new InternetHeaders(paramInputStream);
    try {
      this.content = ASCIIUtility.getBytes(paramInputStream);
    } catch (IOException iOException) {
      throw new MessagingException("IOException", iOException);
    } 
    this.modified = false;
  }
  
  public Address[] getFrom() throws MessagingException {
    Address[] arrayOfAddress = getAddressHeader("From");
    if (arrayOfAddress == null)
      arrayOfAddress = getAddressHeader("Sender"); 
    return arrayOfAddress;
  }
  
  public void setFrom(Address paramAddress) throws MessagingException {
    if (paramAddress == null) {
      removeHeader("From");
      return;
    } 
    setHeader("From", paramAddress.toString());
  }
  
  public void setFrom() throws MessagingException {
    InternetAddress internetAddress = InternetAddress.getLocalAddress(this.session);
    if (internetAddress != null) {
      setFrom(internetAddress);
      return;
    } 
    throw new MessagingException("No From address");
  }
  
  public void addFrom(Address[] paramArrayOfAddress) throws MessagingException { addAddressHeader("From", paramArrayOfAddress); }
  
  public static class RecipientType extends Message.RecipientType {
    public static final RecipientType NEWSGROUPS = new RecipientType("Newsgroups");
    
    protected RecipientType(String param1String) throws MessagingException { super(param1String); }
  }
  
  public Address[] getRecipients(Message.RecipientType paramRecipientType) throws MessagingException {
    if (paramRecipientType == RecipientType.NEWSGROUPS) {
      String str = getHeader("Newsgroups", ",");
      return (str == null) ? null : NewsAddress.parse(str);
    } 
    return getAddressHeader(getHeaderName(paramRecipientType));
  }
  
  public Address[] getAllRecipients() throws MessagingException {
    Address[] arrayOfAddress1 = super.getAllRecipients();
    Address[] arrayOfAddress2 = getRecipients(RecipientType.NEWSGROUPS);
    if (arrayOfAddress2 == null)
      return arrayOfAddress1; 
    int i = (
      (arrayOfAddress1 != null) ? arrayOfAddress1.length : 0) + (
      (arrayOfAddress2 != null) ? arrayOfAddress2.length : 0);
    Address[] arrayOfAddress3 = new Address[i];
    int j = 0;
    if (arrayOfAddress1 != null) {
      System.arraycopy(arrayOfAddress1, 0, arrayOfAddress3, j, arrayOfAddress1.length);
      j += arrayOfAddress1.length;
    } 
    if (arrayOfAddress2 != null) {
      System.arraycopy(arrayOfAddress2, 0, arrayOfAddress3, j, arrayOfAddress2.length);
      j += arrayOfAddress2.length;
    } 
    return arrayOfAddress3;
  }
  
  public void setRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress) throws MessagingException {
    if (paramRecipientType == RecipientType.NEWSGROUPS) {
      if (paramArrayOfAddress == null || paramArrayOfAddress.length == 0) {
        removeHeader("Newsgroups");
        return;
      } 
      setHeader("Newsgroups", NewsAddress.toString(paramArrayOfAddress));
      return;
    } 
    setAddressHeader(getHeaderName(paramRecipientType), paramArrayOfAddress);
  }
  
  public void addRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress) throws MessagingException {
    if (paramRecipientType == RecipientType.NEWSGROUPS) {
      String str = NewsAddress.toString(paramArrayOfAddress);
      if (str != null) {
        addHeader("Newsgroups", str);
        return;
      } 
    } else {
      addAddressHeader(getHeaderName(paramRecipientType), paramArrayOfAddress);
    } 
  }
  
  public Address[] getReplyTo() throws MessagingException {
    Address[] arrayOfAddress = getAddressHeader("Reply-To");
    if (arrayOfAddress == null)
      arrayOfAddress = getFrom(); 
    return arrayOfAddress;
  }
  
  public void setReplyTo(Address[] paramArrayOfAddress) throws MessagingException { setAddressHeader("Reply-To", paramArrayOfAddress); }
  
  private Address[] getAddressHeader(String paramString) throws MessagingException {
    String str = getHeader(paramString, ",");
    return (str == null) ? null : InternetAddress.parse(str);
  }
  
  private void setAddressHeader(String paramString, Address[] paramArrayOfAddress) throws MessagingException {
    String str = InternetAddress.toString(paramArrayOfAddress);
    if (str == null) {
      removeHeader(paramString);
      return;
    } 
    setHeader(paramString, str);
  }
  
  private void addAddressHeader(String paramString, Address[] paramArrayOfAddress) throws MessagingException {
    String str = InternetAddress.toString(paramArrayOfAddress);
    if (str == null)
      return; 
    addHeader(paramString, str);
  }
  
  public String getSubject() throws MessagingException {
    String str = getHeader("Subject", null);
    if (str == null)
      return null; 
    try {
      return MimeUtility.decodeText(str);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      return str;
    } 
  }
  
  public void setSubject(String paramString) throws MessagingException { setSubject(paramString, null); }
  
  public void setSubject(String paramString1, String paramString2) throws MessagingException {
    if (paramString1 == null)
      removeHeader("Subject"); 
    try {
      setHeader("Subject", 
          MimeUtility.encodeText(paramString1, paramString2, null));
      return;
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw new MessagingException("Encoding error", unsupportedEncodingException);
    } 
  }
  
  public Date getSentDate() throws MessagingException {
    String str = getHeader("Date", null);
    if (str != null)
      try {
        synchronized (mailDateFormat) {
          return mailDateFormat.parse(str);
        } 
      } catch (ParseException parseException) {
        return null;
      }  
    return null;
  }
  
  public void setSentDate(Date paramDate) throws MessagingException {
    if (paramDate == null) {
      removeHeader("Date");
      return;
    } 
    synchronized (mailDateFormat) {
      setHeader("Date", mailDateFormat.format(paramDate));
      return;
    } 
  }
  
  public Date getReceivedDate() throws MessagingException { return null; }
  
  public int getSize() throws MessagingException {
    if (this.content != null)
      return this.content.length; 
    return -1;
  }
  
  public int getLineCount() throws MessagingException { return -1; }
  
  public String getContentType() throws MessagingException {
    String str = getHeader("Content-Type", null);
    if (str == null)
      return "text/plain"; 
    return str;
  }
  
  public boolean isMimeType(String paramString) throws MessagingException { return MimeBodyPart.isMimeType(this, paramString); }
  
  public String getDisposition() throws MessagingException { return MimeBodyPart.getDisposition(this); }
  
  public void setDisposition(String paramString) throws MessagingException { MimeBodyPart.setDisposition(this, paramString); }
  
  public String getEncoding() throws MessagingException { return getHeader("Content-Transfer-Encoding", null); }
  
  public String getContentID() throws MessagingException { return getHeader("Content-Id", null); }
  
  public void setContentID(String paramString) throws MessagingException {
    if (paramString == null) {
      removeHeader("Content-ID");
      return;
    } 
    setHeader("Content-ID", paramString);
  }
  
  public String getContentMD5() throws MessagingException { return getHeader("Content-MD5", null); }
  
  public void setContentMD5(String paramString) throws MessagingException { setHeader("Content-MD5", paramString); }
  
  public String getDescription() throws MessagingException { return MimeBodyPart.getDescription(this); }
  
  public void setDescription(String paramString) throws MessagingException { setDescription(paramString, null); }
  
  public void setDescription(String paramString1, String paramString2) throws MessagingException { MimeBodyPart.setDescription(this, paramString1, paramString2); }
  
  public String[] getContentLanguage() throws MessagingException { return MimeBodyPart.getContentLanguage(this); }
  
  public void setContentLanguage(String[] paramArrayOfString) throws MessagingException { MimeBodyPart.setContentLanguage(this, paramArrayOfString); }
  
  public String getMessageID() throws MessagingException { return getHeader("Message-ID", null); }
  
  public String getFileName() throws MessagingException { return MimeBodyPart.getFileName(this); }
  
  public void setFileName(String paramString) throws MessagingException { MimeBodyPart.setFileName(this, paramString); }
  
  private String getHeaderName(Message.RecipientType paramRecipientType) throws MessagingException {
    String str;
    if (paramRecipientType == Message.RecipientType.TO) {
      str = "To";
    } else if (paramRecipientType == Message.RecipientType.CC) {
      str = "Cc";
    } else if (paramRecipientType == Message.RecipientType.BCC) {
      str = "Bcc";
    } else if (paramRecipientType == RecipientType.NEWSGROUPS) {
      str = "Newsgroups";
    } else {
      throw new MessagingException("Invalid Recipient Type");
    } 
    return str;
  }
  
  public InputStream getInputStream() throws IOException, MessagingException { return getDataHandler().getInputStream(); }
  
  protected InputStream getContentStream() throws IOException, MessagingException {
    if (this.content != null)
      return new ByteArrayInputStream(this.content); 
    throw new MessagingException("No content");
  }
  
  public DataHandler getDataHandler() throws MessagingException {
    if (this.dh == null)
      this.dh = new DataHandler(new MimePartDataSource(this)); 
    return this.dh;
  }
  
  public Object getContent() throws IOException, MessagingException { return getDataHandler().getContent(); }
  
  public void setDataHandler(DataHandler paramDataHandler) throws MessagingException {
    this.dh = paramDataHandler;
    MimeBodyPart.invalidateContentHeaders(this);
  }
  
  public void setContent(Object paramObject, String paramString) throws MessagingException { setDataHandler(new DataHandler(paramObject, paramString)); }
  
  public void setText(String paramString) throws MessagingException { setText(paramString, null); }
  
  public void setText(String paramString1, String paramString2) throws MessagingException { MimeBodyPart.setText(this, paramString1, paramString2); }
  
  public void setContent(Multipart paramMultipart) throws MessagingException {
    setDataHandler(new DataHandler(paramMultipart, paramMultipart.getContentType()));
    paramMultipart.setParent(this);
  }
  
  public Message reply(boolean paramBoolean) throws MessagingException {
    MimeMessage mimeMessage = new MimeMessage(this.session);
    String str1 = getHeader("Subject", null);
    if (str1 != null) {
      if (!str1.regionMatches(true, 0, "Re: ", 0, 4))
        str1 = "Re: " + str1; 
      mimeMessage.setHeader("Subject", str1);
    } 
    Address[] arrayOfAddress = getReplyTo();
    mimeMessage.setRecipients(Message.RecipientType.TO, arrayOfAddress);
    if (paramBoolean) {
      Vector vector = new Vector();
      InternetAddress internetAddress = InternetAddress.getLocalAddress(this.session);
      vector.addElement(internetAddress);
      String str = this.session.getProperty("mail.alternates");
      if (str != null)
        eliminateDuplicates(vector, 
            InternetAddress.parse(str, false)); 
      eliminateDuplicates(vector, arrayOfAddress);
      arrayOfAddress = getRecipients(Message.RecipientType.TO);
      arrayOfAddress = eliminateDuplicates(vector, arrayOfAddress);
      if (arrayOfAddress != null && arrayOfAddress.length > 0)
        mimeMessage.addRecipients(Message.RecipientType.TO, arrayOfAddress); 
      arrayOfAddress = getRecipients(Message.RecipientType.CC);
      arrayOfAddress = eliminateDuplicates(vector, arrayOfAddress);
      if (arrayOfAddress != null && arrayOfAddress.length > 0)
        mimeMessage.setRecipients(Message.RecipientType.CC, arrayOfAddress); 
      arrayOfAddress = getRecipients(RecipientType.NEWSGROUPS);
      if (arrayOfAddress != null && arrayOfAddress.length > 0)
        mimeMessage.setRecipients(RecipientType.NEWSGROUPS, arrayOfAddress); 
    } 
    String str2 = getHeader("Message-Id", null);
    if (str2 != null)
      mimeMessage.setHeader("In-Reply-To", str2); 
    try {
      setFlags(answeredFlag, true);
    } catch (MessagingException messagingException) {}
    return mimeMessage;
  }
  
  private static final Flags answeredFlag = new Flags(Flags.Flag.ANSWERED);
  
  private Address[] eliminateDuplicates(Vector paramVector, Address[] paramArrayOfAddress) {
    if (paramArrayOfAddress == null)
      return null; 
    int i = 0;
    for (byte b = 0; b < paramArrayOfAddress.length; b++) {
      boolean bool = false;
      for (byte b1 = 0; b1 < paramVector.size(); b1++) {
        if (((InternetAddress)paramVector.elementAt(b1)).equals(paramArrayOfAddress[b])) {
          bool = true;
          i++;
          paramArrayOfAddress[b] = null;
          break;
        } 
      } 
      if (!bool)
        paramVector.addElement(paramArrayOfAddress[b]); 
    } 
    if (i != 0) {
      Address[] arrayOfAddress;
      if (paramArrayOfAddress instanceof InternetAddress[]) {
        arrayOfAddress = new InternetAddress[paramArrayOfAddress.length - i];
      } else {
        arrayOfAddress = new Address[paramArrayOfAddress.length - i];
      } 
      for (byte b1 = 0, b2 = 0; b1 < paramArrayOfAddress.length; b1++) {
        if (paramArrayOfAddress[b1] != null)
          arrayOfAddress[b2++] = paramArrayOfAddress[b1]; 
      } 
      paramArrayOfAddress = arrayOfAddress;
    } 
    return paramArrayOfAddress;
  }
  
  public void writeTo(OutputStream paramOutputStream) throws IOException, MessagingException { writeTo(paramOutputStream, null); }
  
  public void writeTo(OutputStream paramOutputStream, String[] paramArrayOfString) throws IOException, MessagingException {
    if (this.modified || this.content == null) {
      MimeBodyPart.writeTo(this, paramOutputStream, paramArrayOfString);
      return;
    } 
    Enumeration enumeration = getNonMatchingHeaderLines(paramArrayOfString);
    LineOutputStream lineOutputStream = new LineOutputStream(paramOutputStream);
    while (enumeration.hasMoreElements())
      lineOutputStream.writeln((String)enumeration.nextElement()); 
    lineOutputStream.writeln();
    paramOutputStream.write(this.content);
    paramOutputStream.flush();
  }
  
  public String[] getHeader(String paramString) throws MessagingException { return this.headers.getHeader(paramString); }
  
  public String getHeader(String paramString1, String paramString2) throws MessagingException { return this.headers.getHeader(paramString1, paramString2); }
  
  public void setHeader(String paramString1, String paramString2) throws MessagingException { this.headers.setHeader(paramString1, paramString2); }
  
  public void addHeader(String paramString1, String paramString2) throws MessagingException { this.headers.addHeader(paramString1, paramString2); }
  
  public void removeHeader(String paramString) throws MessagingException { this.headers.removeHeader(paramString); }
  
  public Enumeration getAllHeaders() throws MessagingException { return this.headers.getAllHeaders(); }
  
  public Enumeration getMatchingHeaders(String[] paramArrayOfString) throws MessagingException { return this.headers.getMatchingHeaders(paramArrayOfString); }
  
  public Enumeration getNonMatchingHeaders(String[] paramArrayOfString) throws MessagingException { return this.headers.getNonMatchingHeaders(paramArrayOfString); }
  
  public void addHeaderLine(String paramString) throws MessagingException { this.headers.addHeaderLine(paramString); }
  
  public Enumeration getAllHeaderLines() throws MessagingException { return this.headers.getAllHeaderLines(); }
  
  public Enumeration getMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException { return this.headers.getMatchingHeaderLines(paramArrayOfString); }
  
  public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException { return this.headers.getNonMatchingHeaderLines(paramArrayOfString); }
  
  public Flags getFlags() throws MessagingException { return (Flags)this.flags.clone(); }
  
  public boolean isSet(Flags.Flag paramFlag) throws MessagingException { return this.flags.contains(paramFlag); }
  
  public void setFlags(Flags paramFlags, boolean paramBoolean) throws MessagingException {
    if (paramBoolean) {
      this.flags.add(paramFlags);
      return;
    } 
    this.flags.remove(paramFlags);
  }
  
  public void saveChanges() throws MessagingException {
    this.modified = true;
    updateHeaders();
  }
  
  protected void updateHeaders() throws MessagingException {
    MimeBodyPart.updateHeaders(this);
    setHeader("Mime-Version", "1.0");
    setHeader("Message-ID", 
        "<" + UniqueValue.getUniqueValue(this.session) + ">");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\MimeMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */