/*      */ package javax.mail.internet;
/*      */ 
/*      */ import com.sun.mail.util.ASCIIUtility;
/*      */ import com.sun.mail.util.LineOutputStream;
/*      */ import com.sun.mail.util.MailDateFormat;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.text.ParseException;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Vector;
/*      */ import javax.activation.DataHandler;
/*      */ import javax.mail.Address;
/*      */ import javax.mail.Flags;
/*      */ import javax.mail.Folder;
/*      */ import javax.mail.Message;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.Multipart;
/*      */ import javax.mail.Session;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MimeMessage
/*      */   extends Message
/*      */   implements MimePart
/*      */ {
/*      */   protected DataHandler dh;
/*      */   protected byte[] content;
/*      */   protected InternetHeaders headers;
/*      */   protected Flags flags;
/*      */   private boolean modified = false;
/*   82 */   private static MailDateFormat mailDateFormat = new MailDateFormat();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MimeMessage(Session paramSession) {
/*   91 */     super(paramSession);
/*   92 */     this.modified = true;
/*   93 */     this.headers = new InternetHeaders();
/*   94 */     this.flags = new Flags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MimeMessage(Session paramSession, InputStream paramInputStream) throws MessagingException {
/*  109 */     super(paramSession);
/*  110 */     this.flags = new Flags();
/*  111 */     parse(paramInputStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MimeMessage(Folder paramFolder, int paramInt) {
/*  121 */     super(paramFolder, paramInt);
/*  122 */     this.flags = new Flags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MimeMessage(Folder paramFolder, InputStream paramInputStream, int paramInt) throws MessagingException {
/*  140 */     this(paramFolder, paramInt);
/*  141 */     parse(paramInputStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MimeMessage(Folder paramFolder, InternetHeaders paramInternetHeaders, byte[] paramArrayOfByte, int paramInt) throws MessagingException {
/*  157 */     this(paramFolder, paramInt);
/*  158 */     this.headers = paramInternetHeaders;
/*  159 */     this.content = paramArrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void parse(InputStream paramInputStream) throws MessagingException {
/*  165 */     if (!(paramInputStream instanceof ByteArrayInputStream) && 
/*  166 */       !(paramInputStream instanceof BufferedInputStream)) {
/*  167 */       paramInputStream = new BufferedInputStream(paramInputStream);
/*      */     }
/*  169 */     this.headers = new InternetHeaders(paramInputStream);
/*      */     
/*      */     try {
/*  172 */       this.content = ASCIIUtility.getBytes(paramInputStream);
/*  173 */     } catch (IOException iOException) {
/*  174 */       throw new MessagingException("IOException", iOException);
/*      */     } 
/*      */     
/*  177 */     this.modified = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Address[] getFrom() throws MessagingException {
/*  194 */     Address[] arrayOfAddress = getAddressHeader("From");
/*  195 */     if (arrayOfAddress == null) {
/*  196 */       arrayOfAddress = getAddressHeader("Sender");
/*      */     }
/*  198 */     return arrayOfAddress;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFrom(Address paramAddress) throws MessagingException {
/*  215 */     if (paramAddress == null) {
/*  216 */       removeHeader("From"); return;
/*      */     } 
/*  218 */     setHeader("From", paramAddress.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFrom() throws MessagingException {
/*  233 */     InternetAddress internetAddress = InternetAddress.getLocalAddress(this.session);
/*  234 */     if (internetAddress != null) {
/*  235 */       setFrom(internetAddress); return;
/*      */     } 
/*  237 */     throw new MessagingException("No From address");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  253 */   public void addFrom(Address[] paramArrayOfAddress) throws MessagingException { addAddressHeader("From", paramArrayOfAddress); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class RecipientType
/*      */     extends Message.RecipientType
/*      */   {
/*  268 */     public static final RecipientType NEWSGROUPS = new RecipientType("Newsgroups");
/*      */     
/*  270 */     protected RecipientType(String param1String) throws MessagingException { super(param1String); }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Address[] getRecipients(Message.RecipientType paramRecipientType) throws MessagingException {
/*  304 */     if (paramRecipientType == RecipientType.NEWSGROUPS) {
/*  305 */       String str = getHeader("Newsgroups", ",");
/*  306 */       return (str == null) ? null : NewsAddress.parse(str);
/*      */     } 
/*  308 */     return getAddressHeader(getHeaderName(paramRecipientType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Address[] getAllRecipients() throws MessagingException {
/*  323 */     Address[] arrayOfAddress1 = super.getAllRecipients();
/*  324 */     Address[] arrayOfAddress2 = getRecipients(RecipientType.NEWSGROUPS);
/*      */     
/*  326 */     if (arrayOfAddress2 == null) {
/*  327 */       return arrayOfAddress1;
/*      */     }
/*  329 */     int i = (
/*  330 */       (arrayOfAddress1 != null) ? arrayOfAddress1.length : 0) + (
/*  331 */       (arrayOfAddress2 != null) ? arrayOfAddress2.length : 0);
/*  332 */     Address[] arrayOfAddress3 = new Address[i];
/*  333 */     int j = 0;
/*  334 */     if (arrayOfAddress1 != null) {
/*  335 */       System.arraycopy(arrayOfAddress1, 0, arrayOfAddress3, j, arrayOfAddress1.length);
/*  336 */       j += arrayOfAddress1.length;
/*      */     } 
/*  338 */     if (arrayOfAddress2 != null) {
/*  339 */       System.arraycopy(arrayOfAddress2, 0, arrayOfAddress3, j, arrayOfAddress2.length);
/*  340 */       j += arrayOfAddress2.length;
/*      */     } 
/*  342 */     return arrayOfAddress3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress) throws MessagingException {
/*  362 */     if (paramRecipientType == RecipientType.NEWSGROUPS) {
/*  363 */       if (paramArrayOfAddress == null || paramArrayOfAddress.length == 0) {
/*  364 */         removeHeader("Newsgroups"); return;
/*      */       } 
/*  366 */       setHeader("Newsgroups", NewsAddress.toString(paramArrayOfAddress)); return;
/*      */     } 
/*  368 */     setAddressHeader(getHeaderName(paramRecipientType), paramArrayOfAddress);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress) throws MessagingException {
/*  385 */     if (paramRecipientType == RecipientType.NEWSGROUPS)
/*  386 */     { String str = NewsAddress.toString(paramArrayOfAddress);
/*  387 */       if (str != null) {
/*  388 */         addHeader("Newsgroups", str); return;
/*      */       }  }
/*  390 */     else { addAddressHeader(getHeaderName(paramRecipientType), paramArrayOfAddress); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Address[] getReplyTo() throws MessagingException {
/*  405 */     Address[] arrayOfAddress = getAddressHeader("Reply-To");
/*  406 */     if (arrayOfAddress == null)
/*  407 */       arrayOfAddress = getFrom(); 
/*  408 */     return arrayOfAddress;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  423 */   public void setReplyTo(Address[] paramArrayOfAddress) throws MessagingException { setAddressHeader("Reply-To", paramArrayOfAddress); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Address[] getAddressHeader(String paramString) throws MessagingException {
/*  429 */     String str = getHeader(paramString, ",");
/*  430 */     return (str == null) ? null : InternetAddress.parse(str);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void setAddressHeader(String paramString, Address[] paramArrayOfAddress) throws MessagingException {
/*  436 */     String str = InternetAddress.toString(paramArrayOfAddress);
/*  437 */     if (str == null) {
/*  438 */       removeHeader(paramString); return;
/*      */     } 
/*  440 */     setHeader(paramString, str);
/*      */   }
/*      */ 
/*      */   
/*      */   private void addAddressHeader(String paramString, Address[] paramArrayOfAddress) throws MessagingException {
/*  445 */     String str = InternetAddress.toString(paramArrayOfAddress);
/*  446 */     if (str == null)
/*      */       return; 
/*  448 */     addHeader(paramString, str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSubject() throws MessagingException {
/*  467 */     String str = getHeader("Subject", null);
/*      */     
/*  469 */     if (str == null) {
/*  470 */       return null;
/*      */     }
/*      */     try {
/*  473 */       return MimeUtility.decodeText(str);
/*  474 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*  475 */       return str;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  504 */   public void setSubject(String paramString) throws MessagingException { setSubject(paramString, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubject(String paramString1, String paramString2) throws MessagingException {
/*  533 */     if (paramString1 == null) {
/*  534 */       removeHeader("Subject");
/*      */     }
/*      */     try {
/*  537 */       setHeader("Subject", 
/*  538 */           MimeUtility.encodeText(paramString1, paramString2, null)); return;
/*  539 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*  540 */       throw new MessagingException("Encoding error", unsupportedEncodingException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getSentDate() throws MessagingException {
/*  556 */     String str = getHeader("Date", null);
/*  557 */     if (str != null) {
/*      */       try {
/*  559 */         synchronized (mailDateFormat) {
/*  560 */           return mailDateFormat.parse(str);
/*      */         } 
/*  562 */       } catch (ParseException parseException) {
/*  563 */         return null;
/*      */       } 
/*      */     }
/*      */     
/*  567 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSentDate(Date paramDate) throws MessagingException {
/*  583 */     if (paramDate == null) {
/*  584 */       removeHeader("Date"); return;
/*      */     } 
/*  586 */     synchronized (mailDateFormat) {
/*  587 */       setHeader("Date", mailDateFormat.format(paramDate));
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  606 */   public Date getReceivedDate() throws MessagingException { return null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSize() throws MessagingException {
/*  624 */     if (this.content != null) {
/*  625 */       return this.content.length;
/*      */     }
/*  627 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  644 */   public int getLineCount() throws MessagingException { return -1; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContentType() throws MessagingException {
/*  661 */     String str = getHeader("Content-Type", null);
/*  662 */     if (str == null)
/*  663 */       return "text/plain"; 
/*  664 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  682 */   public boolean isMimeType(String paramString) throws MessagingException { return MimeBodyPart.isMimeType(this, paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  700 */   public String getDisposition() throws MessagingException { return MimeBodyPart.getDisposition(this); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  715 */   public void setDisposition(String paramString) throws MessagingException { MimeBodyPart.setDisposition(this, paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  730 */   public String getEncoding() throws MessagingException { return getHeader("Content-Transfer-Encoding", null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  745 */   public String getContentID() throws MessagingException { return getHeader("Content-Id", null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContentID(String paramString) throws MessagingException {
/*  760 */     if (paramString == null) {
/*  761 */       removeHeader("Content-ID"); return;
/*      */     } 
/*  763 */     setHeader("Content-ID", paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  778 */   public String getContentMD5() throws MessagingException { return getHeader("Content-MD5", null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  791 */   public void setContentMD5(String paramString) throws MessagingException { setHeader("Content-MD5", paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  811 */   public String getDescription() throws MessagingException { return MimeBodyPart.getDescription(this); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  840 */   public void setDescription(String paramString) throws MessagingException { setDescription(paramString, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  871 */   public void setDescription(String paramString1, String paramString2) throws MessagingException { MimeBodyPart.setDescription(this, paramString1, paramString2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  887 */   public String[] getContentLanguage() throws MessagingException { return MimeBodyPart.getContentLanguage(this); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  903 */   public void setContentLanguage(String[] paramArrayOfString) throws MessagingException { MimeBodyPart.setContentLanguage(this, paramArrayOfString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  921 */   public String getMessageID() throws MessagingException { return getHeader("Message-ID", null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  937 */   public String getFileName() throws MessagingException { return MimeBodyPart.getFileName(this); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  953 */   public void setFileName(String paramString) throws MessagingException { MimeBodyPart.setFileName(this, paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getHeaderName(Message.RecipientType paramRecipientType) throws MessagingException {
/*      */     String str;
/*  960 */     if (paramRecipientType == Message.RecipientType.TO) {
/*  961 */       str = "To";
/*  962 */     } else if (paramRecipientType == Message.RecipientType.CC) {
/*  963 */       str = "Cc";
/*  964 */     } else if (paramRecipientType == Message.RecipientType.BCC) {
/*  965 */       str = "Bcc";
/*  966 */     } else if (paramRecipientType == RecipientType.NEWSGROUPS) {
/*  967 */       str = "Newsgroups";
/*      */     } else {
/*  969 */       throw new MessagingException("Invalid Recipient Type");
/*  970 */     }  return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  991 */   public InputStream getInputStream() throws IOException, MessagingException { return getDataHandler().getInputStream(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputStream getContentStream() throws IOException, MessagingException {
/* 1006 */     if (this.content != null) {
/* 1007 */       return new ByteArrayInputStream(this.content);
/*      */     }
/* 1009 */     throw new MessagingException("No content");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DataHandler getDataHandler() throws MessagingException {
/* 1042 */     if (this.dh == null)
/* 1043 */       this.dh = new DataHandler(new MimePartDataSource(this)); 
/* 1044 */     return this.dh;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1068 */   public Object getContent() throws IOException, MessagingException { return getDataHandler().getContent(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDataHandler(DataHandler paramDataHandler) throws MessagingException {
/* 1084 */     this.dh = paramDataHandler;
/* 1085 */     MimeBodyPart.invalidateContentHeaders(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1109 */   public void setContent(Object paramObject, String paramString) throws MessagingException { setDataHandler(new DataHandler(paramObject, paramString)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1130 */   public void setText(String paramString) throws MessagingException { setText(paramString, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1142 */   public void setText(String paramString1, String paramString2) throws MessagingException { MimeBodyPart.setText(this, paramString1, paramString2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContent(Multipart paramMultipart) throws MessagingException {
/* 1157 */     setDataHandler(new DataHandler(paramMultipart, paramMultipart.getContentType()));
/* 1158 */     paramMultipart.setParent(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Message reply(boolean paramBoolean) throws MessagingException {
/* 1185 */     MimeMessage mimeMessage = new MimeMessage(this.session);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1193 */     String str1 = getHeader("Subject", null);
/* 1194 */     if (str1 != null) {
/* 1195 */       if (!str1.regionMatches(true, 0, "Re: ", 0, 4))
/* 1196 */         str1 = "Re: " + str1; 
/* 1197 */       mimeMessage.setHeader("Subject", str1);
/*      */     } 
/* 1199 */     Address[] arrayOfAddress = getReplyTo();
/* 1200 */     mimeMessage.setRecipients(Message.RecipientType.TO, arrayOfAddress);
/* 1201 */     if (paramBoolean) {
/* 1202 */       Vector vector = new Vector();
/*      */       
/* 1204 */       InternetAddress internetAddress = InternetAddress.getLocalAddress(this.session);
/* 1205 */       vector.addElement(internetAddress);
/*      */       
/* 1207 */       String str = this.session.getProperty("mail.alternates");
/* 1208 */       if (str != null) {
/* 1209 */         eliminateDuplicates(vector, 
/* 1210 */             InternetAddress.parse(str, false));
/*      */       }
/* 1212 */       eliminateDuplicates(vector, arrayOfAddress);
/* 1213 */       arrayOfAddress = getRecipients(Message.RecipientType.TO);
/* 1214 */       arrayOfAddress = eliminateDuplicates(vector, arrayOfAddress);
/* 1215 */       if (arrayOfAddress != null && arrayOfAddress.length > 0)
/* 1216 */         mimeMessage.addRecipients(Message.RecipientType.TO, arrayOfAddress); 
/* 1217 */       arrayOfAddress = getRecipients(Message.RecipientType.CC);
/* 1218 */       arrayOfAddress = eliminateDuplicates(vector, arrayOfAddress);
/* 1219 */       if (arrayOfAddress != null && arrayOfAddress.length > 0) {
/* 1220 */         mimeMessage.setRecipients(Message.RecipientType.CC, arrayOfAddress);
/*      */       }
/* 1222 */       arrayOfAddress = getRecipients(RecipientType.NEWSGROUPS);
/* 1223 */       if (arrayOfAddress != null && arrayOfAddress.length > 0)
/* 1224 */         mimeMessage.setRecipients(RecipientType.NEWSGROUPS, arrayOfAddress); 
/*      */     } 
/* 1226 */     String str2 = getHeader("Message-Id", null);
/* 1227 */     if (str2 != null)
/* 1228 */       mimeMessage.setHeader("In-Reply-To", str2); 
/*      */     try {
/* 1230 */       setFlags(answeredFlag, true);
/* 1231 */     } catch (MessagingException messagingException) {}
/*      */ 
/*      */     
/* 1234 */     return mimeMessage;
/*      */   }
/*      */ 
/*      */   
/* 1238 */   private static final Flags answeredFlag = new Flags(Flags.Flag.ANSWERED);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Address[] eliminateDuplicates(Vector paramVector, Address[] paramArrayOfAddress) {
/* 1246 */     if (paramArrayOfAddress == null)
/* 1247 */       return null; 
/* 1248 */     int i = 0;
/* 1249 */     for (byte b = 0; b < paramArrayOfAddress.length; b++) {
/* 1250 */       boolean bool = false;
/*      */       
/* 1252 */       for (byte b1 = 0; b1 < paramVector.size(); b1++) {
/* 1253 */         if (((InternetAddress)paramVector.elementAt(b1)).equals(paramArrayOfAddress[b])) {
/*      */           
/* 1255 */           bool = true;
/* 1256 */           i++;
/* 1257 */           paramArrayOfAddress[b] = null;
/*      */           break;
/*      */         } 
/*      */       } 
/* 1261 */       if (!bool) {
/* 1262 */         paramVector.addElement(paramArrayOfAddress[b]);
/*      */       }
/*      */     } 
/* 1265 */     if (i != 0) {
/*      */       Address[] arrayOfAddress;
/*      */ 
/*      */       
/* 1269 */       if (paramArrayOfAddress instanceof InternetAddress[]) {
/* 1270 */         arrayOfAddress = new InternetAddress[paramArrayOfAddress.length - i];
/*      */       } else {
/* 1272 */         arrayOfAddress = new Address[paramArrayOfAddress.length - i];
/* 1273 */       }  for (byte b1 = 0, b2 = 0; b1 < paramArrayOfAddress.length; b1++) {
/* 1274 */         if (paramArrayOfAddress[b1] != null)
/* 1275 */           arrayOfAddress[b2++] = paramArrayOfAddress[b1]; 
/* 1276 */       }  paramArrayOfAddress = arrayOfAddress;
/*      */     } 
/* 1278 */     return paramArrayOfAddress;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1292 */   public void writeTo(OutputStream paramOutputStream) throws IOException, MessagingException { writeTo(paramOutputStream, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeTo(OutputStream paramOutputStream, String[] paramArrayOfString) throws IOException, MessagingException {
/* 1307 */     if (this.modified || this.content == null) {
/* 1308 */       MimeBodyPart.writeTo(this, paramOutputStream, paramArrayOfString);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1314 */     Enumeration enumeration = getNonMatchingHeaderLines(paramArrayOfString);
/* 1315 */     LineOutputStream lineOutputStream = new LineOutputStream(paramOutputStream);
/* 1316 */     while (enumeration.hasMoreElements()) {
/* 1317 */       lineOutputStream.writeln((String)enumeration.nextElement());
/*      */     }
/*      */     
/* 1320 */     lineOutputStream.writeln();
/*      */ 
/*      */     
/* 1323 */     paramOutputStream.write(this.content);
/* 1324 */     paramOutputStream.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1342 */   public String[] getHeader(String paramString) throws MessagingException { return this.headers.getHeader(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1358 */   public String getHeader(String paramString1, String paramString2) throws MessagingException { return this.headers.getHeader(paramString1, paramString2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1379 */   public void setHeader(String paramString1, String paramString2) throws MessagingException { this.headers.setHeader(paramString1, paramString2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1399 */   public void addHeader(String paramString1, String paramString2) throws MessagingException { this.headers.addHeader(paramString1, paramString2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1412 */   public void removeHeader(String paramString) throws MessagingException { this.headers.removeHeader(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1431 */   public Enumeration getAllHeaders() throws MessagingException { return this.headers.getAllHeaders(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1443 */   public Enumeration getMatchingHeaders(String[] paramArrayOfString) throws MessagingException { return this.headers.getMatchingHeaders(paramArrayOfString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1455 */   public Enumeration getNonMatchingHeaders(String[] paramArrayOfString) throws MessagingException { return this.headers.getNonMatchingHeaders(paramArrayOfString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1468 */   public void addHeaderLine(String paramString) throws MessagingException { this.headers.addHeaderLine(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1479 */   public Enumeration getAllHeaderLines() throws MessagingException { return this.headers.getAllHeaderLines(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1491 */   public Enumeration getMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException { return this.headers.getMatchingHeaderLines(paramArrayOfString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1503 */   public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException { return this.headers.getNonMatchingHeaderLines(paramArrayOfString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1519 */   public Flags getFlags() throws MessagingException { return (Flags)this.flags.clone(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1542 */   public boolean isSet(Flags.Flag paramFlag) throws MessagingException { return this.flags.contains(paramFlag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFlags(Flags paramFlags, boolean paramBoolean) throws MessagingException {
/* 1558 */     if (paramBoolean) {
/* 1559 */       this.flags.add(paramFlags); return;
/*      */     } 
/* 1561 */     this.flags.remove(paramFlags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void saveChanges() throws MessagingException {
/* 1585 */     this.modified = true;
/* 1586 */     updateHeaders();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateHeaders() throws MessagingException {
/* 1605 */     MimeBodyPart.updateHeaders(this);
/* 1606 */     setHeader("Mime-Version", "1.0");
/* 1607 */     setHeader("Message-ID", 
/* 1608 */         "<" + UniqueValue.getUniqueValue(this.session) + ">");
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\MimeMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */