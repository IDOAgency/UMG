/*     */ package javax.mail.internet;
/*     */ 
/*     */ import com.sun.mail.util.ASCIIUtility;
/*     */ import com.sun.mail.util.LineOutputStream;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.mail.BodyPart;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Multipart;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimeBodyPart
/*     */   extends BodyPart
/*     */   implements MimePart
/*     */ {
/*     */   protected DataHandler dh;
/*     */   protected byte[] content;
/*     */   protected InternetHeaders headers;
/*     */   
/*  66 */   public MimeBodyPart() { this.headers = new InternetHeaders(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeBodyPart(InputStream paramInputStream) throws MessagingException {
/*  85 */     if (!(paramInputStream instanceof ByteArrayInputStream) && 
/*  86 */       !(paramInputStream instanceof BufferedInputStream)) {
/*  87 */       paramInputStream = new BufferedInputStream(paramInputStream);
/*     */     }
/*  89 */     this.headers = new InternetHeaders(paramInputStream);
/*     */     
/*     */     try {
/*  92 */       this.content = ASCIIUtility.getBytes(paramInputStream); return;
/*  93 */     } catch (IOException iOException) {
/*  94 */       throw new MessagingException("Error reading input stream", iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeBodyPart(InternetHeaders paramInternetHeaders, byte[] paramArrayOfByte) throws MessagingException {
/* 111 */     this.headers = paramInternetHeaders;
/* 112 */     this.content = paramArrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public int getSize() throws MessagingException { return -1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public int getLineCount() throws MessagingException { return -1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() throws MessagingException {
/* 156 */     String str = getHeader("Content-Type", null);
/* 157 */     if (str == null) {
/* 158 */       str = "text/plain";
/*     */     }
/* 160 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   public boolean isMimeType(String paramString) throws MessagingException { return isMimeType(this, paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   public String getDisposition() throws MessagingException { return getDisposition(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 209 */   public void setDisposition(String paramString) throws MessagingException { setDisposition(this, paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 223 */   public String getEncoding() throws MessagingException { return getHeader("Content-Transfer-Encoding", null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 235 */   public String getContentID() throws MessagingException { return getHeader("Content-Id", null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 247 */   public String getContentMD5() throws MessagingException { return getHeader("Content-MD5", null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 259 */   public void setContentMD5(String paramString) throws MessagingException { setHeader("Content-MD5", paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 272 */   public String[] getContentLanguage() throws MessagingException { return getContentLanguage(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 283 */   public void setContentLanguage(String[] paramArrayOfString) throws MessagingException { setContentLanguage(this, paramArrayOfString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 302 */   public String getDescription() throws MessagingException { return getDescription(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 331 */   public void setDescription(String paramString) throws MessagingException { setDescription(paramString, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 362 */   public void setDescription(String paramString1, String paramString2) throws MessagingException { setDescription(this, paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 377 */   public String getFileName() throws MessagingException { return getFileName(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 392 */   public void setFileName(String paramString) throws MessagingException { setFileName(this, paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 412 */   public InputStream getInputStream() throws IOException, MessagingException { return getDataHandler().getInputStream(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputStream getContentStream() throws IOException, MessagingException {
/* 425 */     if (this.content != null) {
/* 426 */       return new ByteArrayInputStream(this.content);
/*     */     }
/* 428 */     throw new MessagingException("No content");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataHandler getDataHandler() throws MessagingException {
/* 439 */     if (this.dh == null)
/* 440 */       this.dh = new DataHandler(new MimePartDataSource(this)); 
/* 441 */     return this.dh;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 463 */   public Object getContent() throws IOException, MessagingException { return getDataHandler().getContent(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataHandler(DataHandler paramDataHandler) throws MessagingException {
/* 478 */     this.dh = paramDataHandler;
/* 479 */     invalidateContentHeaders(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContent(Object paramObject, String paramString) throws MessagingException {
/* 502 */     if (paramObject instanceof Multipart) {
/* 503 */       setContent((Multipart)paramObject); return;
/*     */     } 
/* 505 */     setDataHandler(new DataHandler(paramObject, paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 526 */   public void setText(String paramString) throws MessagingException { setText(paramString, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 538 */   public void setText(String paramString1, String paramString2) throws MessagingException { setText(this, paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContent(Multipart paramMultipart) throws MessagingException {
/* 552 */     setDataHandler(new DataHandler(paramMultipart, paramMultipart.getContentType()));
/* 553 */     paramMultipart.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 567 */   public void writeTo(OutputStream paramOutputStream) throws IOException, MessagingException { writeTo(this, paramOutputStream, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 580 */   public String[] getHeader(String paramString) throws MessagingException { return this.headers.getHeader(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 596 */   public String getHeader(String paramString1, String paramString2) throws MessagingException { return this.headers.getHeader(paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 612 */   public void setHeader(String paramString1, String paramString2) throws MessagingException { this.headers.setHeader(paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 627 */   public void addHeader(String paramString1, String paramString2) throws MessagingException { this.headers.addHeader(paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 634 */   public void removeHeader(String paramString) throws MessagingException { this.headers.removeHeader(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 642 */   public Enumeration getAllHeaders() throws MessagingException { return this.headers.getAllHeaders(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 651 */   public Enumeration getMatchingHeaders(String[] paramArrayOfString) throws MessagingException { return this.headers.getMatchingHeaders(paramArrayOfString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 660 */   public Enumeration getNonMatchingHeaders(String[] paramArrayOfString) throws MessagingException { return this.headers.getNonMatchingHeaders(paramArrayOfString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 667 */   public void addHeaderLine(String paramString) throws MessagingException { this.headers.addHeaderLine(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 676 */   public Enumeration getAllHeaderLines() throws MessagingException { return this.headers.getAllHeaderLines(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 686 */   public Enumeration getMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException { return this.headers.getMatchingHeaderLines(paramArrayOfString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 696 */   public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException { return this.headers.getNonMatchingHeaderLines(paramArrayOfString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 722 */   protected void updateHeaders() { updateHeaders(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isMimeType(MimePart paramMimePart, String paramString) throws MessagingException {
/*     */     try {
/* 734 */       ContentType contentType = new ContentType(paramMimePart.getContentType());
/* 735 */       return contentType.match(paramString);
/* 736 */     } catch (ParseException parseException) {
/* 737 */       return paramMimePart.getContentType().equalsIgnoreCase(paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void setText(MimePart paramMimePart, String paramString1, String paramString2) throws MessagingException {
/* 743 */     if (paramString2 == null)
/* 744 */       if (MimeUtility.checkAscii(paramString1) != 1) {
/* 745 */         paramString2 = MimeUtility.getDefaultMIMECharset();
/*     */       } else {
/* 747 */         paramString2 = "us-ascii";
/*     */       }  
/* 749 */     paramMimePart.setContent(paramString1, "text/plain; charset=" + 
/* 750 */         MimeUtility.quote(paramString2, "()<>@,;:\\\"\t []/?="));
/*     */   }
/*     */   
/*     */   static String getDisposition(MimePart paramMimePart) throws MessagingException {
/* 754 */     String str = paramMimePart.getHeader("Content-Disposition", null);
/*     */     
/* 756 */     if (str == null) {
/* 757 */       return null;
/*     */     }
/* 759 */     ContentDisposition contentDisposition = new ContentDisposition(str);
/* 760 */     return contentDisposition.getDisposition();
/*     */   }
/*     */ 
/*     */   
/*     */   static void setDisposition(MimePart paramMimePart, String paramString) throws MessagingException {
/* 765 */     if (paramString == null) {
/* 766 */       paramMimePart.removeHeader("Content-Disposition"); return;
/*     */     } 
/* 768 */     String str = paramMimePart.getHeader("Content-Disposition", null);
/* 769 */     if (str != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 775 */       ContentDisposition contentDisposition = new ContentDisposition(str);
/* 776 */       contentDisposition.setDisposition(paramString);
/* 777 */       paramString = contentDisposition.toString();
/*     */     } 
/* 779 */     paramMimePart.setHeader("Content-Disposition", paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static String getDescription(MimePart paramMimePart) throws MessagingException {
/* 785 */     String str = paramMimePart.getHeader("Content-Description", null);
/*     */     
/* 787 */     if (str == null) {
/* 788 */       return null;
/*     */     }
/*     */     try {
/* 791 */       return MimeUtility.decodeText(str);
/* 792 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 793 */       return str;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void setDescription(MimePart paramMimePart, String paramString1, String paramString2) throws MessagingException {
/* 800 */     if (paramString1 == null) {
/* 801 */       paramMimePart.removeHeader("Content-Description");
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/* 806 */       paramMimePart.setHeader("Content-Description", 
/* 807 */           MimeUtility.encodeText(paramString1, paramString2, null)); return;
/* 808 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 809 */       throw new MessagingException("Encoding error", unsupportedEncodingException);
/*     */     } 
/*     */   }
/*     */   
/*     */   static String getFileName(MimePart paramMimePart) throws MessagingException {
/* 814 */     String str1 = null;
/* 815 */     String str2 = paramMimePart.getHeader("Content-Disposition", null);
/*     */     
/* 817 */     if (str2 != null) {
/*     */       
/* 819 */       ContentDisposition contentDisposition = new ContentDisposition(str2);
/* 820 */       str1 = contentDisposition.getParameter("filename");
/*     */     } 
/* 822 */     if (str1 == null) {
/*     */       
/* 824 */       str2 = paramMimePart.getHeader("Content-Type", null);
/* 825 */       if (str2 != null) {
/* 826 */         ContentType contentType = new ContentType(str2);
/* 827 */         str1 = contentType.getParameter("name");
/*     */       } 
/*     */     } 
/* 830 */     return str1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void setFileName(MimePart paramMimePart, String paramString) throws MessagingException {
/* 836 */     String str = paramMimePart.getHeader("Content-Disposition", null);
/* 837 */     ContentDisposition contentDisposition = 
/* 838 */       new ContentDisposition((str == null) ? "attachment" : str);
/* 839 */     contentDisposition.setParameter("filename", paramString);
/* 840 */     paramMimePart.setHeader("Content-Disposition", contentDisposition.toString());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 848 */     str = paramMimePart.getHeader("Content-Type", null);
/* 849 */     if (str != null) {
/* 850 */       ContentType contentType = new ContentType(str);
/* 851 */       contentType.setParameter("name", paramString);
/* 852 */       paramMimePart.setHeader("Content-Type", contentType.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static String[] getContentLanguage(MimePart paramMimePart) throws MessagingException {
/* 858 */     String str = paramMimePart.getHeader("Content-Language", null);
/*     */     
/* 860 */     if (str == null) {
/* 861 */       return null;
/*     */     }
/*     */     
/* 864 */     HeaderTokenizer headerTokenizer = new HeaderTokenizer(str, "()<>@,;:\\\"\t []/?=");
/* 865 */     Vector vector = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 871 */       HeaderTokenizer.Token token = headerTokenizer.next();
/* 872 */       int i = token.getType();
/* 873 */       if (i == -4)
/*     */         break; 
/* 875 */       if (i == -1) {
/* 876 */         vector.addElement(token.getValue());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 881 */     if (vector.size() == 0) {
/* 882 */       return null;
/*     */     }
/* 884 */     String[] arrayOfString = new String[vector.size()];
/* 885 */     vector.copyInto(arrayOfString);
/* 886 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */   
/*     */   static void setContentLanguage(MimePart paramMimePart, String[] paramArrayOfString) throws MessagingException {
/* 891 */     StringBuffer stringBuffer = new StringBuffer(paramArrayOfString[0]);
/* 892 */     for (byte b = 1; b < paramArrayOfString.length; b++)
/* 893 */       stringBuffer.append(',').append(paramArrayOfString[b]); 
/* 894 */     paramMimePart.setHeader("Content-Language", stringBuffer.toString());
/*     */   }
/*     */   
/*     */   static void updateHeaders(MimePart paramMimePart) throws MessagingException {
/* 898 */     DataHandler dataHandler = paramMimePart.getDataHandler();
/* 899 */     if (dataHandler == null) {
/*     */       return;
/*     */     }
/*     */     try {
/* 903 */       String str = dataHandler.getContentType();
/* 904 */       boolean bool = false;
/*     */       
/* 906 */       ContentType contentType = new ContentType(str);
/* 907 */       if (contentType.match("multipart/*")) {
/*     */         
/* 909 */         bool = true;
/* 910 */         Object object = dataHandler.getContent();
/* 911 */         ((MimeMultipart)object).updateHeaders();
/*     */       }
/* 913 */       else if (contentType.match("message/rfc822")) {
/* 914 */         bool = true;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 920 */       if (paramMimePart.getHeader("Content-Type") == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 927 */         String str1 = paramMimePart.getHeader("Content-Disposition", null);
/* 928 */         if (str1 != null) {
/*     */           
/* 930 */           ContentDisposition contentDisposition = new ContentDisposition(str1);
/* 931 */           String str2 = contentDisposition.getParameter("filename");
/* 932 */           if (str2 != null) {
/* 933 */             contentType.setParameter("name", str2);
/* 934 */             str = contentType.toString();
/*     */           } 
/*     */         } 
/*     */         
/* 938 */         paramMimePart.setHeader("Content-Type", str);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 943 */       if (!bool && 
/* 944 */         paramMimePart.getHeader("Content-Transfer-Encoding") == null)
/* 945 */       { paramMimePart.setHeader("Content-Transfer-Encoding", 
/* 946 */             MimeUtility.getEncoding(dataHandler.getDataSource())); return; } 
/* 947 */     } catch (IOException iOException) {
/* 948 */       throw new MessagingException("IOException updating headers", iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void invalidateContentHeaders(MimePart paramMimePart) throws MessagingException {
/* 954 */     paramMimePart.removeHeader("Content-Type");
/* 955 */     paramMimePart.removeHeader("Content-Transfer-Encoding");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void writeTo(MimePart paramMimePart, OutputStream paramOutputStream, String[] paramArrayOfString) throws IOException, MessagingException {
/* 962 */     LineOutputStream lineOutputStream = null;
/* 963 */     if (paramOutputStream instanceof LineOutputStream) {
/* 964 */       lineOutputStream = (LineOutputStream)paramOutputStream;
/*     */     } else {
/* 966 */       lineOutputStream = new LineOutputStream(paramOutputStream);
/*     */     } 
/*     */ 
/*     */     
/* 970 */     Enumeration enumeration = paramMimePart.getNonMatchingHeaderLines(paramArrayOfString);
/* 971 */     while (enumeration.hasMoreElements()) {
/* 972 */       lineOutputStream.writeln((String)enumeration.nextElement());
/*     */     }
/*     */     
/* 975 */     lineOutputStream.writeln();
/*     */ 
/*     */ 
/*     */     
/* 979 */     paramOutputStream = MimeUtility.encode(paramOutputStream, paramMimePart.getEncoding());
/* 980 */     paramMimePart.getDataHandler().writeTo(paramOutputStream);
/* 981 */     paramOutputStream.flush();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\MimeBodyPart.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */