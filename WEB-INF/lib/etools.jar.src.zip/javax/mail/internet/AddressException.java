/*    */ package javax.mail.internet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddressException
/*    */   extends ParseException
/*    */ {
/*    */   protected String ref;
/* 29 */   protected int pos = -1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AddressException() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   public AddressException(String paramString) { super(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AddressException(String paramString1, String paramString2) {
/* 54 */     super(paramString1);
/* 55 */     this.ref = paramString2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AddressException(String paramString1, String paramString2, int paramInt) {
/* 64 */     super(paramString1);
/* 65 */     this.ref = paramString2;
/* 66 */     this.pos = paramInt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 74 */   public String getRef() { return this.ref; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 82 */   public int getPos() { return this.pos; }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 86 */     String str = super.toString();
/* 87 */     if (this.ref == null)
/* 88 */       return str; 
/* 89 */     str = String.valueOf(str) + " in string ``" + this.ref + "''";
/* 90 */     if (this.pos < 0)
/* 91 */       return str; 
/* 92 */     return String.valueOf(str) + " at position " + this.pos;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\AddressException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */