package javax.mail.internet;

public class AddressException extends ParseException {
  protected String ref;
  
  protected int pos = -1;
  
  public AddressException() {}
  
  public AddressException(String paramString) { super(paramString); }
  
  public AddressException(String paramString1, String paramString2) {
    super(paramString1);
    this.ref = paramString2;
  }
  
  public AddressException(String paramString1, String paramString2, int paramInt) {
    super(paramString1);
    this.ref = paramString2;
    this.pos = paramInt;
  }
  
  public String getRef() { return this.ref; }
  
  public int getPos() { return this.pos; }
  
  public String toString() {
    String str = super.toString();
    if (this.ref == null)
      return str; 
    str = String.valueOf(str) + " in string ``" + this.ref + "''";
    if (this.pos < 0)
      return str; 
    return String.valueOf(str) + " at position " + this.pos;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\AddressException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */