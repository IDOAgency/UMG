package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.BASE64DecoderStream;
import com.sun.mail.util.BASE64EncoderStream;
import com.sun.mail.util.BEncoderStream;
import com.sun.mail.util.LineInputStream;
import com.sun.mail.util.QDecoderStream;
import com.sun.mail.util.QEncoderStream;
import com.sun.mail.util.QPDecoderStream;
import com.sun.mail.util.QPEncoderStream;
import com.sun.mail.util.UUDecoderStream;
import com.sun.mail.util.UUEncoderStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import javax.activation.DataSource;
import javax.mail.MessagingException;

public class MimeUtility {
  public static final int ALL = -1;
  
  private static String defaultJavaCharset;
  
  private static String defaultMIMECharset;
  
  private static Hashtable mime2java;
  
  private static Hashtable java2mime;
  
  static final int ALL_ASCII = 1;
  
  static final int MOSTLY_ASCII = 2;
  
  static final int MOSTLY_NONASCII = 3;
  
  public static String getEncoding(DataSource paramDataSource) {
    ContentType contentType = null;
    InputStream inputStream = null;
    String str = null;
    try {
      contentType = new ContentType(paramDataSource.getContentType());
      inputStream = paramDataSource.getInputStream();
    } catch (Exception exception) {
      return "base64";
    } 
    if (contentType.match("text/*")) {
      int i = checkAscii(inputStream, -1, false);
      switch (i) {
        case 1:
          str = "7bit";
          break;
        case 2:
          str = "quoted-printable";
          break;
        default:
          str = "base64";
          break;
      } 
    } else if (checkAscii(inputStream, -1, true) == 1) {
      str = "7bit";
    } else {
      str = "base64";
    } 
    try {
      inputStream.close();
    } catch (IOException iOException) {}
    return str;
  }
  
  public static InputStream decode(InputStream paramInputStream, String paramString) throws MessagingException {
    if (paramString.equalsIgnoreCase("base64"))
      return new BASE64DecoderStream(paramInputStream); 
    if (paramString.equalsIgnoreCase("quoted-printable"))
      return new QPDecoderStream(paramInputStream); 
    if (paramString.equalsIgnoreCase("uuencode") || 
      paramString.equalsIgnoreCase("x-uuencode"))
      return new UUDecoderStream(paramInputStream); 
    if (paramString.equalsIgnoreCase("binary") || 
      paramString.equalsIgnoreCase("7bit") || 
      paramString.equalsIgnoreCase("8bit"))
      return paramInputStream; 
    throw new MessagingException("Unknown encoding: " + paramString);
  }
  
  public static OutputStream encode(OutputStream paramOutputStream, String paramString) throws MessagingException {
    if (paramString == null)
      return paramOutputStream; 
    if (paramString.equalsIgnoreCase("base64"))
      return new BASE64EncoderStream(paramOutputStream); 
    if (paramString.equalsIgnoreCase("quoted-printable"))
      return new QPEncoderStream(paramOutputStream); 
    if (paramString.equalsIgnoreCase("uuencode") || 
      paramString.equalsIgnoreCase("x-uuencode"))
      return new UUEncoderStream(paramOutputStream); 
    if (paramString.equalsIgnoreCase("binary") || 
      paramString.equalsIgnoreCase("7bit") || 
      paramString.equalsIgnoreCase("8bit"))
      return paramOutputStream; 
    throw new MessagingException("Unknown encoding: " + paramString);
  }
  
  public static String encodeText(String paramString) throws UnsupportedEncodingException { return encodeText(paramString, null, null); }
  
  public static String encodeText(String paramString1, String paramString2, String paramString3) throws UnsupportedEncodingException { return encodeWord(paramString1, paramString2, paramString3, false); }
  
  public static String decodeText(String paramString) throws UnsupportedEncodingException {
    String str = " \t\n\r";
    if (paramString.indexOf("=?") == -1)
      return paramString; 
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, str, true);
    StringBuffer stringBuffer1 = new StringBuffer();
    StringBuffer stringBuffer2 = new StringBuffer();
    boolean bool = false;
    while (stringTokenizer.hasMoreTokens()) {
      String str2, str1 = stringTokenizer.nextToken();
      char c;
      if ((c = str1.charAt(0)) == ' ' || c == '\t' || 
        c == '\r' || c == '\n') {
        stringBuffer2.append(c);
        continue;
      } 
      try {
        str2 = decodeWord(str1);
        if (!bool && stringBuffer2.length() > 0)
          stringBuffer1.append(stringBuffer2); 
        bool = true;
      } catch (ParseException parseException) {
        str2 = str1;
        if (stringBuffer2.length() > 0)
          stringBuffer1.append(stringBuffer2); 
        bool = false;
      } 
      stringBuffer1.append(str2);
      stringBuffer2.setLength(0);
    } 
    return stringBuffer1.toString();
  }
  
  public static String encodeWord(String paramString) throws UnsupportedEncodingException { return encodeWord(paramString, null, null); }
  
  public static String encodeWord(String paramString1, String paramString2, String paramString3) throws UnsupportedEncodingException { return encodeWord(paramString1, paramString2, paramString3, true); }
  
  private static String encodeWord(String paramString1, String paramString2, String paramString3, boolean paramBoolean) throws UnsupportedEncodingException {
    boolean bool;
    String str;
    if (checkAscii(paramString1) == 1)
      return paramString1; 
    if (paramString2 == null) {
      str = getDefaultJavaCharset();
      paramString2 = getDefaultMIMECharset();
    } else {
      str = javaCharset(paramString2);
    } 
    if (paramString3 == null) {
      byte[] arrayOfByte = paramString1.getBytes(str);
      if (checkAscii(arrayOfByte) == 2) {
        paramString3 = "Q";
      } else {
        paramString3 = "B";
      } 
    } 
    if (paramString3.equalsIgnoreCase("B")) {
      bool = true;
    } else if (paramString3.equalsIgnoreCase("Q")) {
      bool = false;
    } else {
      throw new UnsupportedEncodingException(
          "Unknown transfer encoding: " + paramString3);
    } 
    StringBuffer stringBuffer = new StringBuffer();
    doEncode(paramString1, bool, str, 
        
        68 - paramString2.length(), 
        "=?" + paramString2 + "?" + paramString3 + "?", 
        true, paramBoolean, stringBuffer);
    return stringBuffer.toString();
  }
  
  private static void doEncode(String paramString1, boolean paramBoolean1, String paramString2, int paramInt, String paramString3, boolean paramBoolean2, boolean paramBoolean3, StringBuffer paramStringBuffer) throws UnsupportedEncodingException {
    QEncoderStream qEncoderStream;
    int i;
    byte[] arrayOfByte1 = paramString1.getBytes(paramString2);
    if (paramBoolean1) {
      i = BEncoderStream.encodedLength(arrayOfByte1);
    } else {
      i = QEncoderStream.encodedLength(arrayOfByte1, paramBoolean3);
    } 
    int j;
    if (i > paramInt && (j = paramString1.length()) > 1) {
      doEncode(paramString1.substring(0, j / 2), paramBoolean1, paramString2, 
          paramInt, paramString3, paramBoolean2, paramBoolean3, paramStringBuffer);
      doEncode(paramString1.substring(j / 2, j), paramBoolean1, paramString2, 
          paramInt, paramString3, false, paramBoolean3, paramStringBuffer);
      return;
    } 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    if (paramBoolean1) {
      qEncoderStream = new BEncoderStream(byteArrayOutputStream);
    } else {
      qEncoderStream = new QEncoderStream(byteArrayOutputStream, paramBoolean3);
    } 
    try {
      qEncoderStream.write(arrayOfByte1);
      qEncoderStream.close();
    } catch (IOException iOException) {}
    byte[] arrayOfByte2 = byteArrayOutputStream.toByteArray();
    if (!paramBoolean2)
      paramStringBuffer.append("\r\n "); 
    paramStringBuffer.append(paramString3);
    for (byte b = 0; b < arrayOfByte2.length; b++)
      paramStringBuffer.append((char)arrayOfByte2[b]); 
    paramStringBuffer.append("?=");
  }
  
  public static String decodeWord(String paramString) throws UnsupportedEncodingException {
    if (!paramString.startsWith("=?"))
      throw new ParseException(); 
    int i = 2;
    int j;
    if ((j = paramString.indexOf('?', i)) == -1)
      throw new ParseException(); 
    String str1 = javaCharset(paramString.substring(i, j));
    i = j + 1;
    if ((j = paramString.indexOf('?', i)) == -1)
      throw new ParseException(); 
    String str2 = paramString.substring(i, j);
    i = j + 1;
    if ((j = paramString.indexOf("?=", i)) == -1)
      throw new ParseException(); 
    String str3 = paramString.substring(i, j);
    try {
      QDecoderStream qDecoderStream;
      ByteArrayInputStream byteArrayInputStream = 
        new ByteArrayInputStream(ASCIIUtility.getBytes(str3));
      if (str2.equalsIgnoreCase("B")) {
        qDecoderStream = new BASE64DecoderStream(byteArrayInputStream);
      } else if (str2.equalsIgnoreCase("Q")) {
        qDecoderStream = new QDecoderStream(byteArrayInputStream);
      } else {
        throw new UnsupportedEncodingException(
            "unknown encoding: " + str2);
      } 
      int k = byteArrayInputStream.available();
      byte[] arrayOfByte = new byte[k];
      k = qDecoderStream.read(arrayOfByte, 0, k);
      return new String(arrayOfByte, 0, k, str1);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw unsupportedEncodingException;
    } catch (IOException iOException) {
      throw new ParseException();
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new UnsupportedEncodingException();
    } 
  }
  
  public static String quote(String paramString1, String paramString2) {
    int i = paramString1.length();
    boolean bool = false;
    for (byte b = 0; b < i; b++) {
      char c = paramString1.charAt(b);
      if (c == '"' || c == '\\' || c == '\r' || c == '\n') {
        StringBuffer stringBuffer = new StringBuffer(i + 3);
        stringBuffer.append('"');
        for (byte b1 = 0; b1 < i; b1++) {
          char c1 = paramString1.charAt(b1);
          if (c1 == '"' || c1 == '\\' || 
            c1 == '\r' || c1 == '\n')
            stringBuffer.append('\\'); 
          stringBuffer.append(c1);
        } 
        stringBuffer.append('"');
        return stringBuffer.toString();
      } 
      if (c < ' ' || c >= '' || paramString2.indexOf(c) >= 0)
        bool = true; 
    } 
    if (bool) {
      StringBuffer stringBuffer = new StringBuffer(i + 2);
      stringBuffer.append('"').append(paramString1).append('"');
      return stringBuffer.toString();
    } 
    return paramString1;
  }
  
  public static String javaCharset(String paramString) throws UnsupportedEncodingException {
    if (mime2java == null || paramString == null)
      return paramString; 
    String str = (String)mime2java.get(paramString.toLowerCase());
    return (str == null) ? paramString : str;
  }
  
  public static String mimeCharset(String paramString) throws UnsupportedEncodingException {
    if (java2mime == null || paramString == null)
      return paramString; 
    String str = (String)java2mime.get(paramString.toLowerCase());
    return (str == null) ? paramString : str;
  }
  
  public static String getDefaultJavaCharset() {
    if (defaultJavaCharset == null)
      try {
        defaultJavaCharset = System.getProperty("file.encoding", 
            "8859_1");
      } catch (SecurityException securityException) {
        InputStreamReader inputStreamReader = 
          new InputStreamReader(new $NullInputStream());
        defaultJavaCharset = inputStreamReader.getEncoding();
        if (defaultJavaCharset == null)
          defaultJavaCharset = "8859_1"; 
      }  
    return defaultJavaCharset;
  }
  
  static String getDefaultMIMECharset() {
    if (defaultMIMECharset == null)
      defaultMIMECharset = mimeCharset(getDefaultJavaCharset()); 
    return defaultMIMECharset;
  }
  
  static  {
    InputStream inputStream = 
      MimeUtility.class.getResourceAsStream(
        "/META-INF/javamail.charset.map");
    if (inputStream != null) {
      LineInputStream lineInputStream = new LineInputStream(inputStream);
      java2mime = new Hashtable(20);
      loadMappings((LineInputStream)lineInputStream, java2mime);
      mime2java = new Hashtable(10);
      loadMappings((LineInputStream)lineInputStream, mime2java);
    } 
  }
  
  private static void loadMappings(LineInputStream paramLineInputStream, Hashtable paramHashtable) {
    while (true) {
      String str;
      try {
        str = paramLineInputStream.readLine();
      } catch (IOException iOException) {
        return;
      } 
      if (str != null)
        if (!str.startsWith("--") || !str.endsWith("--")) {
          if (str.trim().length() == 0 || str.startsWith("#"))
            continue; 
          StringTokenizer stringTokenizer = new StringTokenizer(str, " \t");
          try {
            String str1 = stringTokenizer.nextToken();
            String str2 = stringTokenizer.nextToken();
            paramHashtable.put(str1.toLowerCase(), str2);
            continue;
          } catch (NoSuchElementException noSuchElementException) {
            continue;
          } 
        }  
      break;
    } 
  }
  
  static int checkAscii(String paramString) {
    int i = paramString.length();
    for (byte b = 0; b < i; b++) {
      if (paramString.charAt(b) > '')
        return 3; 
    } 
    return 1;
  }
  
  static int checkAscii(byte[] paramArrayOfByte) {
    byte b1 = 0, b2 = 0;
    for (byte b3 = 0; b3 < paramArrayOfByte.length; b3++) {
      if ((paramArrayOfByte[b3] & 0xFF) > Byte.MAX_VALUE) {
        b2++;
      } else {
        b1++;
      } 
    } 
    if (b2 == 0)
      return 1; 
    if (b1 > b2)
      return 2; 
    return 3;
  }
  
  static int checkAscii(InputStream paramInputStream, int paramInt, boolean paramBoolean) {
    byte b1 = 0, b2 = 0;
    char c = 'က';
    byte b3 = 0;
    boolean bool = false;
    byte[] arrayOfByte = null;
    if (paramInt != 0) {
      c = (paramInt == -1) ? 4096 : Math.min(paramInt, 4096);
      arrayOfByte = new byte[c];
    } 
    while (paramInt != 0) {
      try {
        int i;
        if ((i = paramInputStream.read(arrayOfByte, 0, c)) != -1) {
          for (byte b = 0; b < i; b++) {
            byte b4 = arrayOfByte[b] & 0xFF;
            if (b4 == 13 || b4 == 10) {
              b3 = 0;
            } else {
              b3++;
              if (b3 > 'Ϧ')
                bool = true; 
            } 
            if (b4 > Byte.MAX_VALUE) {
              if (paramBoolean)
                return 3; 
              b2++;
            } else {
              b1++;
            } 
          } 
          if (paramInt != -1)
            paramInt -= i; 
          continue;
        } 
        break;
      } catch (IOException iOException) {
        break;
      } 
    } 
    if (paramInt == 0 && paramBoolean)
      return 3; 
    if (b2 == 0) {
      if (bool)
        return 2; 
      return 1;
    } 
    if (b1 > b2)
      return 2; 
    return 3;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\MimeUtility.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */