/*     */ package javax.mail.internet;
/*     */ 
/*     */ import com.sun.mail.util.ASCIIUtility;
/*     */ import com.sun.mail.util.BASE64DecoderStream;
/*     */ import com.sun.mail.util.BASE64EncoderStream;
/*     */ import com.sun.mail.util.BEncoderStream;
/*     */ import com.sun.mail.util.LineInputStream;
/*     */ import com.sun.mail.util.QDecoderStream;
/*     */ import com.sun.mail.util.QEncoderStream;
/*     */ import com.sun.mail.util.QPDecoderStream;
/*     */ import com.sun.mail.util.QPEncoderStream;
/*     */ import com.sun.mail.util.UUDecoderStream;
/*     */ import com.sun.mail.util.UUEncoderStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Hashtable;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.MessagingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimeUtility
/*     */ {
/*     */   public static final int ALL = -1;
/*     */   private static String defaultJavaCharset;
/*     */   private static String defaultMIMECharset;
/*     */   private static Hashtable mime2java;
/*     */   private static Hashtable java2mime;
/*     */   static final int ALL_ASCII = 1;
/*     */   static final int MOSTLY_ASCII = 2;
/*     */   static final int MOSTLY_NONASCII = 3;
/*     */   
/*     */   public static String getEncoding(DataSource paramDataSource) {
/*  93 */     ContentType contentType = null;
/*  94 */     InputStream inputStream = null;
/*  95 */     String str = null;
/*     */     
/*     */     try {
/*  98 */       contentType = new ContentType(paramDataSource.getContentType());
/*  99 */       inputStream = paramDataSource.getInputStream();
/* 100 */     } catch (Exception exception) {
/* 101 */       return "base64";
/*     */     } 
/*     */     
/* 104 */     if (contentType.match("text/*")) {
/*     */       
/* 106 */       int i = checkAscii(inputStream, -1, false);
/* 107 */       switch (i) {
/*     */         case 1:
/* 109 */           str = "7bit";
/*     */           break;
/*     */         case 2:
/* 112 */           str = "quoted-printable";
/*     */           break;
/*     */         default:
/* 115 */           str = "base64";
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/* 121 */     } else if (checkAscii(inputStream, -1, true) == 1) {
/* 122 */       str = "7bit";
/*     */     } else {
/* 124 */       str = "base64";
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 129 */       inputStream.close();
/* 130 */     } catch (IOException iOException) {}
/*     */     
/* 132 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InputStream decode(InputStream paramInputStream, String paramString) throws MessagingException {
/* 148 */     if (paramString.equalsIgnoreCase("base64"))
/* 149 */       return new BASE64DecoderStream(paramInputStream); 
/* 150 */     if (paramString.equalsIgnoreCase("quoted-printable"))
/* 151 */       return new QPDecoderStream(paramInputStream); 
/* 152 */     if (paramString.equalsIgnoreCase("uuencode") || 
/* 153 */       paramString.equalsIgnoreCase("x-uuencode"))
/* 154 */       return new UUDecoderStream(paramInputStream); 
/* 155 */     if (paramString.equalsIgnoreCase("binary") || 
/* 156 */       paramString.equalsIgnoreCase("7bit") || 
/* 157 */       paramString.equalsIgnoreCase("8bit")) {
/* 158 */       return paramInputStream;
/*     */     }
/* 160 */     throw new MessagingException("Unknown encoding: " + paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OutputStream encode(OutputStream paramOutputStream, String paramString) throws MessagingException {
/* 176 */     if (paramString == null)
/* 177 */       return paramOutputStream; 
/* 178 */     if (paramString.equalsIgnoreCase("base64"))
/* 179 */       return new BASE64EncoderStream(paramOutputStream); 
/* 180 */     if (paramString.equalsIgnoreCase("quoted-printable"))
/* 181 */       return new QPEncoderStream(paramOutputStream); 
/* 182 */     if (paramString.equalsIgnoreCase("uuencode") || 
/* 183 */       paramString.equalsIgnoreCase("x-uuencode"))
/* 184 */       return new UUEncoderStream(paramOutputStream); 
/* 185 */     if (paramString.equalsIgnoreCase("binary") || 
/* 186 */       paramString.equalsIgnoreCase("7bit") || 
/* 187 */       paramString.equalsIgnoreCase("8bit")) {
/* 188 */       return paramOutputStream;
/*     */     }
/* 190 */     throw new MessagingException("Unknown encoding: " + paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public static String encodeText(String paramString) throws UnsupportedEncodingException { return encodeText(paramString, null, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 262 */   public static String encodeText(String paramString1, String paramString2, String paramString3) throws UnsupportedEncodingException { return encodeWord(paramString1, paramString2, paramString3, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decodeText(String paramString) throws UnsupportedEncodingException {
/* 304 */     String str = " \t\n\r";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 316 */     if (paramString.indexOf("=?") == -1) {
/* 317 */       return paramString;
/*     */     }
/*     */ 
/*     */     
/* 321 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, str, true);
/* 322 */     StringBuffer stringBuffer1 = new StringBuffer();
/* 323 */     StringBuffer stringBuffer2 = new StringBuffer();
/* 324 */     boolean bool = false;
/*     */     
/* 326 */     while (stringTokenizer.hasMoreTokens()) {
/*     */       
/* 328 */       String str2, str1 = stringTokenizer.nextToken();
/*     */       char c;
/* 330 */       if ((c = str1.charAt(0)) == ' ' || c == '\t' || 
/* 331 */         c == '\r' || c == '\n') {
/* 332 */         stringBuffer2.append(c);
/*     */         
/*     */         continue;
/*     */       } 
/*     */       try {
/* 337 */         str2 = decodeWord(str1);
/*     */         
/* 339 */         if (!bool && stringBuffer2.length() > 0)
/*     */         {
/*     */ 
/*     */           
/* 343 */           stringBuffer1.append(stringBuffer2);
/*     */         }
/* 345 */         bool = true;
/* 346 */       } catch (ParseException parseException) {
/*     */         
/* 348 */         str2 = str1;
/*     */         
/* 350 */         if (stringBuffer2.length() > 0)
/* 351 */           stringBuffer1.append(stringBuffer2); 
/* 352 */         bool = false;
/*     */       } 
/* 354 */       stringBuffer1.append(str2);
/* 355 */       stringBuffer2.setLength(0);
/*     */     } 
/*     */     
/* 358 */     return stringBuffer1.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 384 */   public static String encodeWord(String paramString) throws UnsupportedEncodingException { return encodeWord(paramString, null, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 412 */   public static String encodeWord(String paramString1, String paramString2, String paramString3) throws UnsupportedEncodingException { return encodeWord(paramString1, paramString2, paramString3, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String encodeWord(String paramString1, String paramString2, String paramString3, boolean paramBoolean) throws UnsupportedEncodingException {
/*     */     boolean bool;
/*     */     String str;
/* 428 */     if (checkAscii(paramString1) == 1) {
/* 429 */       return paramString1;
/*     */     }
/*     */ 
/*     */     
/* 433 */     if (paramString2 == null) {
/* 434 */       str = getDefaultJavaCharset();
/* 435 */       paramString2 = getDefaultMIMECharset();
/*     */     } else {
/* 437 */       str = javaCharset(paramString2);
/*     */     } 
/*     */     
/* 440 */     if (paramString3 == null) {
/* 441 */       byte[] arrayOfByte = paramString1.getBytes(str);
/* 442 */       if (checkAscii(arrayOfByte) == 2) {
/* 443 */         paramString3 = "Q";
/*     */       } else {
/* 445 */         paramString3 = "B";
/*     */       } 
/*     */     } 
/*     */     
/* 449 */     if (paramString3.equalsIgnoreCase("B")) {
/* 450 */       bool = true;
/* 451 */     } else if (paramString3.equalsIgnoreCase("Q")) {
/* 452 */       bool = false;
/*     */     } else {
/* 454 */       throw new UnsupportedEncodingException(
/* 455 */           "Unknown transfer encoding: " + paramString3);
/*     */     } 
/* 457 */     StringBuffer stringBuffer = new StringBuffer();
/* 458 */     doEncode(paramString1, bool, str, 
/*     */ 
/*     */ 
/*     */         
/* 462 */         68 - paramString2.length(), 
/* 463 */         "=?" + paramString2 + "?" + paramString3 + "?", 
/* 464 */         true, paramBoolean, stringBuffer);
/*     */     
/* 466 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void doEncode(String paramString1, boolean paramBoolean1, String paramString2, int paramInt, String paramString3, boolean paramBoolean2, boolean paramBoolean3, StringBuffer paramStringBuffer) throws UnsupportedEncodingException {
/*     */     QEncoderStream qEncoderStream;
/*     */     int i;
/* 476 */     byte[] arrayOfByte1 = paramString1.getBytes(paramString2);
/*     */     
/* 478 */     if (paramBoolean1) {
/* 479 */       i = BEncoderStream.encodedLength(arrayOfByte1);
/*     */     } else {
/* 481 */       i = QEncoderStream.encodedLength(arrayOfByte1, paramBoolean3);
/*     */     } 
/*     */     int j;
/* 484 */     if (i > paramInt && (j = paramString1.length()) > 1) {
/*     */ 
/*     */       
/* 487 */       doEncode(paramString1.substring(0, j / 2), paramBoolean1, paramString2, 
/* 488 */           paramInt, paramString3, paramBoolean2, paramBoolean3, paramStringBuffer);
/* 489 */       doEncode(paramString1.substring(j / 2, j), paramBoolean1, paramString2, 
/* 490 */           paramInt, paramString3, false, paramBoolean3, paramStringBuffer);
/*     */       return;
/*     */     } 
/* 493 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/* 495 */     if (paramBoolean1) {
/* 496 */       qEncoderStream = new BEncoderStream(byteArrayOutputStream);
/*     */     } else {
/* 498 */       qEncoderStream = new QEncoderStream(byteArrayOutputStream, paramBoolean3);
/*     */     } 
/*     */     try {
/* 501 */       qEncoderStream.write(arrayOfByte1);
/* 502 */       qEncoderStream.close();
/* 503 */     } catch (IOException iOException) {}
/*     */     
/* 505 */     byte[] arrayOfByte2 = byteArrayOutputStream.toByteArray();
/*     */ 
/*     */     
/* 508 */     if (!paramBoolean2) {
/* 509 */       paramStringBuffer.append("\r\n ");
/*     */     }
/* 511 */     paramStringBuffer.append(paramString3);
/* 512 */     for (byte b = 0; b < arrayOfByte2.length; b++)
/* 513 */       paramStringBuffer.append((char)arrayOfByte2[b]); 
/* 514 */     paramStringBuffer.append("?=");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decodeWord(String paramString) throws UnsupportedEncodingException {
/* 534 */     if (!paramString.startsWith("=?")) {
/* 535 */       throw new ParseException();
/*     */     }
/*     */     
/* 538 */     int i = 2; int j;
/* 539 */     if ((j = paramString.indexOf('?', i)) == -1)
/* 540 */       throw new ParseException(); 
/* 541 */     String str1 = javaCharset(paramString.substring(i, j));
/*     */ 
/*     */     
/* 544 */     i = j + 1;
/* 545 */     if ((j = paramString.indexOf('?', i)) == -1)
/* 546 */       throw new ParseException(); 
/* 547 */     String str2 = paramString.substring(i, j);
/*     */ 
/*     */     
/* 550 */     i = j + 1;
/* 551 */     if ((j = paramString.indexOf("?=", i)) == -1)
/* 552 */       throw new ParseException(); 
/* 553 */     String str3 = paramString.substring(i, j);
/*     */     
/*     */     try {
/*     */       QDecoderStream qDecoderStream;
/* 557 */       ByteArrayInputStream byteArrayInputStream = 
/* 558 */         new ByteArrayInputStream(ASCIIUtility.getBytes(str3));
/*     */ 
/*     */ 
/*     */       
/* 562 */       if (str2.equalsIgnoreCase("B")) {
/* 563 */         qDecoderStream = new BASE64DecoderStream(byteArrayInputStream);
/* 564 */       } else if (str2.equalsIgnoreCase("Q")) {
/* 565 */         qDecoderStream = new QDecoderStream(byteArrayInputStream);
/*     */       } else {
/* 567 */         throw new UnsupportedEncodingException(
/* 568 */             "unknown encoding: " + str2);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 575 */       int k = byteArrayInputStream.available();
/* 576 */       byte[] arrayOfByte = new byte[k];
/*     */       
/* 578 */       k = qDecoderStream.read(arrayOfByte, 0, k);
/*     */ 
/*     */ 
/*     */       
/* 582 */       return new String(arrayOfByte, 0, k, str1);
/* 583 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */ 
/*     */       
/* 586 */       throw unsupportedEncodingException;
/* 587 */     } catch (IOException iOException) {
/*     */       
/* 589 */       throw new ParseException();
/* 590 */     } catch (IllegalArgumentException illegalArgumentException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 598 */       throw new UnsupportedEncodingException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String quote(String paramString1, String paramString2) {
/* 619 */     int i = paramString1.length();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 625 */     boolean bool = false;
/* 626 */     for (byte b = 0; b < i; b++) {
/* 627 */       char c = paramString1.charAt(b);
/* 628 */       if (c == '"' || c == '\\' || c == '\r' || c == '\n') {
/*     */         
/* 630 */         StringBuffer stringBuffer = new StringBuffer(i + 3);
/* 631 */         stringBuffer.append('"');
/* 632 */         for (byte b1 = 0; b1 < i; b1++) {
/* 633 */           char c1 = paramString1.charAt(b1);
/* 634 */           if (c1 == '"' || c1 == '\\' || 
/* 635 */             c1 == '\r' || c1 == '\n')
/*     */           {
/* 637 */             stringBuffer.append('\\'); } 
/* 638 */           stringBuffer.append(c1);
/*     */         } 
/* 640 */         stringBuffer.append('"');
/* 641 */         return stringBuffer.toString();
/* 642 */       }  if (c < ' ' || c >= '' || paramString2.indexOf(c) >= 0)
/*     */       {
/* 644 */         bool = true;
/*     */       }
/*     */     } 
/* 647 */     if (bool) {
/* 648 */       StringBuffer stringBuffer = new StringBuffer(i + 2);
/* 649 */       stringBuffer.append('"').append(paramString1).append('"');
/* 650 */       return stringBuffer.toString();
/*     */     } 
/* 652 */     return paramString1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String javaCharset(String paramString) throws UnsupportedEncodingException {
/* 663 */     if (mime2java == null || paramString == null)
/*     */     {
/* 665 */       return paramString;
/*     */     }
/* 667 */     String str = (String)mime2java.get(paramString.toLowerCase());
/* 668 */     return (str == null) ? paramString : str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String mimeCharset(String paramString) throws UnsupportedEncodingException {
/* 685 */     if (java2mime == null || paramString == null)
/*     */     {
/* 687 */       return paramString;
/*     */     }
/* 689 */     String str = (String)java2mime.get(paramString.toLowerCase());
/* 690 */     return (str == null) ? paramString : str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDefaultJavaCharset() {
/* 705 */     if (defaultJavaCharset == null) {
/*     */       try {
/* 707 */         defaultJavaCharset = System.getProperty("file.encoding", 
/* 708 */             "8859_1");
/* 709 */       } catch (SecurityException securityException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 716 */         InputStreamReader inputStreamReader = 
/* 717 */           new InputStreamReader(new $NullInputStream());
/* 718 */         defaultJavaCharset = inputStreamReader.getEncoding();
/* 719 */         if (defaultJavaCharset == null) {
/* 720 */           defaultJavaCharset = "8859_1";
/*     */         }
/*     */       } 
/*     */     }
/* 724 */     return defaultJavaCharset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getDefaultMIMECharset() {
/* 731 */     if (defaultMIMECharset == null)
/* 732 */       defaultMIMECharset = mimeCharset(getDefaultJavaCharset()); 
/* 733 */     return defaultMIMECharset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static  {
/* 742 */     InputStream inputStream = 
/* 743 */       MimeUtility.class.getResourceAsStream(
/* 744 */         "/META-INF/javamail.charset.map");
/*     */     
/* 746 */     if (inputStream != null) {
/* 747 */       LineInputStream lineInputStream = new LineInputStream(inputStream);
/*     */ 
/*     */       
/* 750 */       java2mime = new Hashtable(20);
/* 751 */       loadMappings((LineInputStream)lineInputStream, java2mime);
/*     */ 
/*     */       
/* 754 */       mime2java = new Hashtable(10);
/* 755 */       loadMappings((LineInputStream)lineInputStream, mime2java);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadMappings(LineInputStream paramLineInputStream, Hashtable paramHashtable) {
/*     */     while (true) {
/*     */       String str;
/*     */       try {
/* 764 */         str = paramLineInputStream.readLine();
/* 765 */       } catch (IOException iOException) {
/*     */         return;
/*     */       } 
/*     */       
/* 769 */       if (str != null)
/*     */       {
/* 771 */         if (!str.startsWith("--") || !str.endsWith("--")) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 776 */           if (str.trim().length() == 0 || str.startsWith("#")) {
/*     */             continue;
/*     */           }
/*     */ 
/*     */           
/* 781 */           StringTokenizer stringTokenizer = new StringTokenizer(str, " \t");
/*     */           try {
/* 783 */             String str1 = stringTokenizer.nextToken();
/* 784 */             String str2 = stringTokenizer.nextToken();
/* 785 */             paramHashtable.put(str1.toLowerCase(), str2); continue;
/* 786 */           } catch (NoSuchElementException noSuchElementException) {
/*     */             continue;
/*     */           } 
/*     */         } 
/*     */       }
/*     */       break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int checkAscii(String paramString) {
/* 802 */     int i = paramString.length();
/*     */     
/* 804 */     for (byte b = 0; b < i; b++) {
/* 805 */       if (paramString.charAt(b) > '') {
/* 806 */         return 3;
/*     */       }
/*     */     } 
/* 809 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int checkAscii(byte[] paramArrayOfByte) {
/* 821 */     byte b1 = 0, b2 = 0;
/*     */     
/* 823 */     for (byte b3 = 0; b3 < paramArrayOfByte.length; b3++) {
/*     */ 
/*     */ 
/*     */       
/* 827 */       if ((paramArrayOfByte[b3] & 0xFF) > Byte.MAX_VALUE) {
/* 828 */         b2++;
/*     */       } else {
/* 830 */         b1++;
/*     */       } 
/*     */     } 
/* 833 */     if (b2 == 0)
/* 834 */       return 1; 
/* 835 */     if (b1 > b2) {
/* 836 */       return 2;
/*     */     }
/* 838 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int checkAscii(InputStream paramInputStream, int paramInt, boolean paramBoolean) {
/* 863 */     byte b1 = 0, b2 = 0;
/*     */     
/* 865 */     char c = 'က';
/* 866 */     byte b3 = 0;
/* 867 */     boolean bool = false;
/* 868 */     byte[] arrayOfByte = null;
/* 869 */     if (paramInt != 0) {
/* 870 */       c = (paramInt == -1) ? 4096 : Math.min(paramInt, 4096);
/* 871 */       arrayOfByte = new byte[c];
/*     */     } 
/* 873 */     while (paramInt != 0) {
/*     */       
/* 875 */       try { int i; if ((i = paramInputStream.read(arrayOfByte, 0, c)) != -1)
/*     */         
/* 877 */         { for (byte b = 0; b < i; b++) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 882 */             byte b4 = arrayOfByte[b] & 0xFF;
/* 883 */             if (b4 == 13 || b4 == 10) {
/* 884 */               b3 = 0;
/*     */             } else {
/* 886 */               b3++;
/* 887 */               if (b3 > 'Ϧ')
/* 888 */                 bool = true; 
/*     */             } 
/* 890 */             if (b4 > Byte.MAX_VALUE) {
/* 891 */               if (paramBoolean) {
/* 892 */                 return 3;
/*     */               }
/* 894 */               b2++;
/*     */             } else {
/* 896 */               b1++;
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 901 */           if (paramInt != -1)
/* 902 */             paramInt -= i;  continue; }  break; }
/*     */       catch (IOException iOException) { break; }
/*     */     
/* 905 */     }  if (paramInt == 0 && paramBoolean)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 912 */       return 3;
/*     */     }
/* 914 */     if (b2 == 0) {
/*     */       
/* 916 */       if (bool) {
/* 917 */         return 2;
/*     */       }
/* 919 */       return 1;
/*     */     } 
/* 921 */     if (b1 > b2)
/* 922 */       return 2; 
/* 923 */     return 3;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\MimeUtility.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */