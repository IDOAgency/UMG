/*     */ package javax.mail.internet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentType
/*     */ {
/*     */   private String primaryType;
/*     */   private String subType;
/*     */   private ParameterList list;
/*     */   
/*     */   public ContentType() {}
/*     */   
/*     */   public ContentType(String paramString1, String paramString2, ParameterList paramParameterList) {
/*  43 */     this.primaryType = paramString1;
/*  44 */     this.subType = paramString2;
/*  45 */     this.list = paramParameterList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentType(String paramString) throws ParseException {
/*  57 */     HeaderTokenizer headerTokenizer = new HeaderTokenizer(paramString, "()<>@,;:\\\"\t []/?=");
/*     */ 
/*     */ 
/*     */     
/*  61 */     HeaderTokenizer.Token token = headerTokenizer.next();
/*  62 */     if (token.getType() != -1)
/*  63 */       throw new ParseException(); 
/*  64 */     this.primaryType = token.getValue();
/*     */ 
/*     */     
/*  67 */     token = headerTokenizer.next();
/*  68 */     if ((char)token.getType() != '/') {
/*  69 */       throw new ParseException();
/*     */     }
/*     */     
/*  72 */     token = headerTokenizer.next();
/*  73 */     if (token.getType() != -1)
/*  74 */       throw new ParseException(); 
/*  75 */     this.subType = token.getValue();
/*     */ 
/*     */     
/*  78 */     String str = headerTokenizer.getRemainder();
/*  79 */     if (str != null) {
/*  80 */       this.list = new ParameterList(str);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public String getPrimaryType() { return this.primaryType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public String getSubType() { return this.subType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public String getBaseType() { return String.valueOf(this.primaryType) + '/' + this.subType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParameter(String paramString) {
/* 116 */     if (this.list == null) {
/* 117 */       return null;
/*     */     }
/* 119 */     return this.list.get(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public ParameterList getParameterList() { return this.list; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public void setPrimaryType(String paramString) throws ParseException { this.primaryType = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public void setSubType(String paramString) throws ParseException { this.subType = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(String paramString1, String paramString2) {
/* 156 */     if (this.list == null) {
/* 157 */       this.list = new ParameterList();
/*     */     }
/* 159 */     this.list.set(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 167 */   public void setParameterList(ParameterList paramParameterList) { this.list = paramParameterList; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 178 */     if (this.primaryType == null || this.subType == null) {
/* 179 */       return null;
/*     */     }
/* 181 */     StringBuffer stringBuffer = new StringBuffer();
/* 182 */     stringBuffer.append(this.primaryType).append('/').append(this.subType);
/* 183 */     if (this.list != null) {
/* 184 */       stringBuffer.append(this.list.toString());
/*     */     }
/* 186 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(ContentType paramContentType) {
/* 209 */     if (!this.primaryType.equalsIgnoreCase(paramContentType.getPrimaryType())) {
/* 210 */       return false;
/*     */     }
/* 212 */     String str = paramContentType.getSubType();
/*     */ 
/*     */     
/* 215 */     if (this.subType.charAt(0) == '*' || str.charAt(0) == '*') {
/* 216 */       return true;
/*     */     }
/*     */     
/* 219 */     if (!this.subType.equalsIgnoreCase(str)) {
/* 220 */       return false;
/*     */     }
/* 222 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(String paramString) {
/*     */     try {
/* 243 */       return match(new ContentType(paramString));
/* 244 */     } catch (ParseException parseException) {
/* 245 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\ContentType.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */