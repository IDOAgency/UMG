/*    */ package javax.mail.internet;
/*    */ 
/*    */ import javax.mail.Session;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UniqueValue
/*    */ {
/* 38 */   public static String getUniqueValue() { return getUniqueValue(null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getUniqueValue(Session paramSession) {
/* 57 */     String str = null;
/*    */     
/* 59 */     InternetAddress internetAddress = InternetAddress.getLocalAddress(paramSession);
/* 60 */     if (internetAddress != null) {
/* 61 */       str = internetAddress.getAddress();
/*    */     } else {
/* 63 */       str = "javamailuser@localhost";
/*    */     } 
/*    */     
/* 66 */     StringBuffer stringBuffer = new StringBuffer();
/*    */ 
/*    */     
/* 69 */     stringBuffer.append(stringBuffer.hashCode()).append('.')
/* 70 */       .append(System.currentTimeMillis()).append('.')
/* 71 */       .append("JavaMail.")
/* 72 */       .append(str);
/* 73 */     return stringBuffer.toString();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\UniqueValue.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */