package javax.mail.internet;

import javax.mail.Session;

class UniqueValue {
  public static String getUniqueValue() { return getUniqueValue(null); }
  
  public static String getUniqueValue(Session paramSession) {
    String str = null;
    InternetAddress internetAddress = InternetAddress.getLocalAddress(paramSession);
    if (internetAddress != null) {
      str = internetAddress.getAddress();
    } else {
      str = "javamailuser@localhost";
    } 
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(stringBuffer.hashCode()).append('.')
      .append(System.currentTimeMillis()).append('.')
      .append("JavaMail.")
      .append(str);
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\UniqueValue.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */