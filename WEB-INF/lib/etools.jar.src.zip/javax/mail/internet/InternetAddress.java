package javax.mail.internet;

import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.mail.Address;
import javax.mail.Session;

public class InternetAddress extends Address {
  protected String address;
  
  protected String personal;
  
  protected String encodedPersonal;
  
  public InternetAddress() {}
  
  public InternetAddress(String paramString) throws AddressException {
    InternetAddress[] arrayOfInternetAddress = parse(paramString, true);
    if (arrayOfInternetAddress.length != 1)
      throw new AddressException("Illegal address", paramString); 
    this.address = (arrayOfInternetAddress[0]).address;
    this.personal = (arrayOfInternetAddress[0]).personal;
    this.encodedPersonal = (arrayOfInternetAddress[0]).encodedPersonal;
  }
  
  private InternetAddress(String paramString, boolean paramBoolean) throws AddressException {
    this(paramString);
    if (paramBoolean)
      checkAddress(this.address, true, true); 
  }
  
  public InternetAddress(String paramString1, String paramString2) throws UnsupportedEncodingException { this(paramString1, paramString2, null); }
  
  public InternetAddress(String paramString1, String paramString2, String paramString3) throws UnsupportedEncodingException {
    this.address = paramString1;
    setPersonal(paramString2, paramString3);
  }
  
  public String getType() { return "rfc822"; }
  
  public void setAddress(String paramString) throws AddressException { this.address = paramString; }
  
  public void setPersonal(String paramString1, String paramString2) throws UnsupportedEncodingException {
    this.personal = paramString1;
    if (paramString1 != null) {
      this.encodedPersonal = MimeUtility.encodeWord(paramString1, paramString2, null);
      return;
    } 
    this.encodedPersonal = null;
  }
  
  public void setPersonal(String paramString) throws AddressException {
    this.personal = paramString;
    if (paramString != null) {
      this.encodedPersonal = MimeUtility.encodeWord(paramString);
      return;
    } 
    this.encodedPersonal = null;
  }
  
  public String getAddress() { return this.address; }
  
  public String getPersonal() {
    if (this.personal != null)
      return this.personal; 
    if (this.encodedPersonal != null)
      try {
        this.personal = MimeUtility.decodeText(this.encodedPersonal);
        return this.personal;
      } catch (Exception exception) {
        return this.encodedPersonal;
      }  
    return null;
  }
  
  public String toString() {
    if (this.encodedPersonal == null && this.personal != null)
      try {
        this.encodedPersonal = MimeUtility.encodeWord(this.personal);
      } catch (UnsupportedEncodingException unsupportedEncodingException) {} 
    if (this.encodedPersonal != null)
      return String.valueOf(quotePhrase(this.encodedPersonal)) + " <" + this.address + ">"; 
    if (isGroup() || isSimple())
      return this.address; 
    return "<" + this.address + ">";
  }
  
  private static final String rfc822phrase = "()<>@,;:\\\"\t []".replace(' ', false).replace('\t', false);
  
  private static final String specialsNoDotNoAt = "()<>,;:\\\"[]";
  
  private static final String specialsNoDot = "()<>,;:\\\"[]@";
  
  private static String quotePhrase(String paramString) {
    int i = paramString.length();
    boolean bool = false;
    for (byte b = 0; b < i; b++) {
      char c = paramString.charAt(b);
      if (c == '"' || c == '\\') {
        StringBuffer stringBuffer = new StringBuffer(i + 3);
        stringBuffer.append('"');
        for (byte b1 = 0; b1 < i; b1++) {
          char c1 = paramString.charAt(b1);
          if (c1 == '"' || c1 == '\\')
            stringBuffer.append('\\'); 
          stringBuffer.append(c1);
        } 
        stringBuffer.append('"');
        return stringBuffer.toString();
      } 
      if ((c < ' ' && c != '\r' && c != '\n' && c != '\t') || 
        c >= '' || rfc822phrase.indexOf(c) >= 0)
        bool = true; 
    } 
    if (bool) {
      StringBuffer stringBuffer = new StringBuffer(i + 2);
      stringBuffer.append('"').append(paramString).append('"');
      return stringBuffer.toString();
    } 
    return paramString;
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof InternetAddress))
      return false; 
    String str = ((InternetAddress)paramObject).getAddress();
    if (str == this.address)
      return true; 
    if (this.address != null && this.address.equalsIgnoreCase(str))
      return true; 
    return false;
  }
  
  public int hashCode() {
    if (this.address == null)
      return 0; 
    return this.address.toLowerCase().hashCode();
  }
  
  public static String toString(Address[] paramArrayOfAddress) { return toString(paramArrayOfAddress, 0); }
  
  public static String toString(Address[] paramArrayOfAddress, int paramInt) {
    if (paramArrayOfAddress == null || paramArrayOfAddress.length == 0)
      return null; 
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramArrayOfAddress.length; b++) {
      if (b) {
        stringBuffer.append(", ");
        paramInt += 2;
      } 
      String str = paramArrayOfAddress[b].toString();
      int i = lengthOfFirstSegment(str);
      if (paramInt + i > 76) {
        stringBuffer.append("\r\n ");
        paramInt = 1;
      } 
      stringBuffer.append(str);
      paramInt = lengthOfLastSegment(str, paramInt);
    } 
    return stringBuffer.toString();
  }
  
  private static int lengthOfFirstSegment(String paramString) {
    int i;
    if ((i = paramString.indexOf("\r\n")) != -1)
      return i; 
    return paramString.length();
  }
  
  private static int lengthOfLastSegment(String paramString, int paramInt) {
    int i;
    if ((i = paramString.lastIndexOf("\r\n")) != -1)
      return paramString.length() - i - 2; 
    return paramString.length() + paramInt;
  }
  
  public static InternetAddress getLocalAddress(Session paramSession) {
    String str1 = null, str2 = null, str3 = null;
    try {
      if (paramSession == null) {
        str1 = System.getProperty("user.name");
        str2 = InetAddress.getLocalHost().getHostName();
      } else {
        str3 = paramSession.getProperty("mail.from");
        if (str3 == null) {
          str1 = paramSession.getProperty("mail.user");
          if (str1 == null)
            str1 = paramSession.getProperty("user.name"); 
          if (str1 == null)
            str1 = System.getProperty("user.name"); 
          str2 = paramSession.getProperty("mail.host");
          if (str2 == null) {
            InetAddress inetAddress = InetAddress.getLocalHost();
            if (inetAddress != null)
              str2 = inetAddress.getHostName(); 
          } 
        } 
      } 
      if (str3 == null && str1 != null && str2 != null)
        str3 = String.valueOf(str1) + "@" + str2; 
      if (str3 != null)
        return new InternetAddress(str3); 
    } catch (SecurityException securityException) {
    
    } catch (AddressException addressException) {
    
    } catch (UnknownHostException unknownHostException) {}
    return null;
  }
  
  public static InternetAddress[] parse(String paramString) throws AddressException { return parse(paramString, true); }
  
  public static InternetAddress[] parse(String paramString, boolean paramBoolean) throws AddressException {
    byte b4 = -1, b5 = -1;
    int i = paramString.length();
    boolean bool1 = false;
    boolean bool = false;
    boolean bool2 = false;
    Vector vector = new Vector();
    byte b1, b2, b3;
    for (b1 = b2 = -1, b3 = 0; b3 < i; b3++) {
      InternetAddress internetAddress;
      byte b;
      char c = paramString.charAt(b3);
      switch (c) {
        case '(':
          bool2 = true;
          if (b1 >= 0 && b2 == -1)
            b2 = b3; 
          if (b4 == -1)
            b4 = b3 + 1; 
          b3++;
          for (b = 1; b3 < i && !b; 
            b3++) {
            c = paramString.charAt(b3);
            switch (c) {
              case '\\':
                b3++;
                break;
              case '(':
                b++;
                break;
              case ')':
                b--;
                break;
            } 
          } 
          if (b > 0)
            throw new AddressException("Missing ')'", paramString, b3); 
          b3--;
          if (b5 == -1)
            b5 = b3; 
          break;
        case ')':
          throw new AddressException("Missing '('", paramString, b3);
        case '<':
          bool2 = true;
          if (bool)
            throw new AddressException("Extra route-addr", paramString, b3); 
          if (!bool1) {
            b4 = b1;
            b5 = b3;
            b1 = b3 + 1;
          } 
          while (++b3 < i) {
            c = paramString.charAt(b3);
            switch (c) {
              case '\\':
                b3++;
              default:
                b3++;
                continue;
              case '>':
                break;
            } 
            break;
          } 
          if (b3 >= i)
            throw new AddressException("Missing '>'", paramString, b3); 
          bool = true;
          b2 = b3;
          break;
        case '>':
          throw new AddressException("Missing '<'", paramString, b3);
        case '"':
          bool2 = true;
          if (b1 == -1)
            b1 = b3; 
          while (++b3 < i) {
            c = paramString.charAt(b3);
            switch (c) {
              case '\\':
                b3++;
              default:
                b3++;
                continue;
              case '"':
                break;
            } 
            break;
          } 
          if (b3 >= i)
            throw new AddressException("Missing '\"'", paramString, b3); 
          break;
        case '[':
          bool2 = true;
          while (++b3 < i) {
            c = paramString.charAt(b3);
            switch (c) {
              case '\\':
                b3++;
                b3++;
                break;
              case ']':
                break;
            } 
          } 
          if (b3 >= i)
            throw new AddressException("Missing ']'", paramString, b3); 
          break;
        case ',':
          if (b1 == -1) {
            bool = false;
            bool2 = false;
            b1 = b2 = -1;
            break;
          } 
          if (!bool1) {
            if (b2 == -1)
              b2 = b3; 
            String str = paramString.substring(b1, b2).trim();
            if (bool2 || paramBoolean) {
              checkAddress(str, bool, paramBoolean);
              InternetAddress internetAddress1 = new InternetAddress();
              internetAddress1.setAddress(str);
              if (b4 >= 0) {
                String str1 = 
                  paramString.substring(b4, b5).trim();
                if (str1.startsWith("\"") && 
                  str1.endsWith("\""))
                  str1 = str1.substring(1, 
                      str1.length() - 1); 
                internetAddress1.encodedPersonal = str1;
                b4 = b5 = -1;
              } 
              vector.addElement(internetAddress1);
            } else {
              StringTokenizer stringTokenizer = new StringTokenizer(str);
              while (stringTokenizer.hasMoreTokens()) {
                String str1 = stringTokenizer.nextToken();
                checkAddress(str1, false, paramBoolean);
                InternetAddress internetAddress1 = new InternetAddress();
                internetAddress1.setAddress(str1);
                vector.addElement(internetAddress1);
              } 
            } 
            bool = false;
            bool2 = false;
            b1 = b2 = -1;
          } 
          break;
        case ':':
          bool2 = true;
          if (bool1)
            throw new AddressException("Nested group", paramString, b3); 
          bool1 = true;
          break;
        case ';':
          if (!bool1)
            throw new AddressException(
                "Illegal semicolon, not in group", paramString, b3); 
          bool1 = false;
          internetAddress = new InternetAddress();
          b2 = b3 + 1;
          internetAddress.setAddress(paramString.substring(b1, b2).trim());
          vector.addElement(internetAddress);
          bool = false;
          b1 = b2 = -1;
          break;
        default:
          if (b1 == -1)
            b1 = b3; 
          break;
        case '\t':
        case '\n':
        case '\r':
        case ' ':
          break;
      } 
    } 
    if (b1 >= 0) {
      if (b2 == -1)
        b2 = b3; 
      String str = paramString.substring(b1, b2).trim();
      if (bool2 || paramBoolean) {
        checkAddress(str, bool, paramBoolean);
        InternetAddress internetAddress = new InternetAddress();
        internetAddress.setAddress(str);
        if (b4 >= 0) {
          String str1 = 
            paramString.substring(b4, b5).trim();
          if (str1.startsWith("\"") && str1.endsWith("\""))
            str1 = str1.substring(1, str1.length() - 1); 
          internetAddress.encodedPersonal = str1;
        } 
        vector.addElement(internetAddress);
      } else {
        StringTokenizer stringTokenizer = new StringTokenizer(str);
        while (stringTokenizer.hasMoreTokens()) {
          String str1 = stringTokenizer.nextToken();
          checkAddress(str1, false, paramBoolean);
          InternetAddress internetAddress = new InternetAddress();
          internetAddress.setAddress(str1);
          vector.addElement(internetAddress);
        } 
      } 
    } 
    InternetAddress[] arrayOfInternetAddress = new InternetAddress[vector.size()];
    vector.copyInto(arrayOfInternetAddress);
    return arrayOfInternetAddress;
  }
  
  private static void checkAddress(String paramString, boolean paramBoolean1, boolean paramBoolean2) throws AddressException {
    String str2, str1;
    int j = 0;
    if (paramString.indexOf('"') >= 0)
      return; 
    if (!paramBoolean2 || paramBoolean1) {
      int k;
      for (j = 0; (k = indexOfAny(paramString, ",:", j)) >= 0; 
        j = k + 1) {
        if (paramString.charAt(j) != '@')
          throw new AddressException("Illegal route-addr", paramString); 
        if (paramString.charAt(k) == ':') {
          j = k + 1;
          break;
        } 
      } 
    } 
    int i;
    if ((i = paramString.indexOf('@', j)) >= 0) {
      if (i == j)
        throw new AddressException("Missing local name", paramString); 
      if (i == paramString.length() - 1)
        throw new AddressException("Missing domain", paramString); 
      str1 = paramString.substring(j, i);
      str2 = paramString.substring(i + 1);
    } else {
      str1 = paramString;
      str2 = null;
    } 
    if (indexOfAny(paramString, " \t\n\r") >= 0)
      throw new AddressException("Illegal whitespace in address", paramString); 
    if (indexOfAny(str1, "()<>,;:\\\"[]@") >= 0)
      throw new AddressException("Illegal character in local name", paramString); 
    if (str2 != null && str2.indexOf('[') < 0 && 
      indexOfAny(str2, "()<>,;:\\\"[]@") >= 0)
      throw new AddressException("Illegal character in domain", paramString); 
  }
  
  private boolean isSimple() { return !(indexOfAny(this.address, "()<>,;:\\\"[]") >= 0); }
  
  private boolean isGroup() { return !(!this.address.endsWith(";") || this.address.indexOf(':') <= 0); }
  
  private static int indexOfAny(String paramString1, String paramString2) { return indexOfAny(paramString1, paramString2, 0); }
  
  private static int indexOfAny(String paramString1, String paramString2, int paramInt) {
    try {
      int i = paramString1.length();
      for (int j = paramInt; j < i; j++) {
        if (paramString2.indexOf(paramString1.charAt(j)) >= 0)
          return j; 
      } 
      return -1;
    } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
      return -1;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\InternetAddress.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */