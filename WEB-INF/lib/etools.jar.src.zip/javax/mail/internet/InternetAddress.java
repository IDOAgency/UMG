/*     */ package javax.mail.internet;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import javax.mail.Address;
/*     */ import javax.mail.Session;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InternetAddress
/*     */   extends Address
/*     */ {
/*     */   protected String address;
/*     */   protected String personal;
/*     */   protected String encodedPersonal;
/*     */   
/*     */   public InternetAddress() {}
/*     */   
/*     */   public InternetAddress(String paramString) throws AddressException {
/*  57 */     InternetAddress[] arrayOfInternetAddress = parse(paramString, true);
/*     */     
/*  59 */     if (arrayOfInternetAddress.length != 1) {
/*  60 */       throw new AddressException("Illegal address", paramString);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     this.address = (arrayOfInternetAddress[0]).address;
/*  69 */     this.personal = (arrayOfInternetAddress[0]).personal;
/*  70 */     this.encodedPersonal = (arrayOfInternetAddress[0]).encodedPersonal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InternetAddress(String paramString, boolean paramBoolean) throws AddressException {
/*  85 */     this(paramString);
/*  86 */     if (paramBoolean) {
/*  87 */       checkAddress(this.address, true, true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public InternetAddress(String paramString1, String paramString2) throws UnsupportedEncodingException { this(paramString1, paramString2, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InternetAddress(String paramString1, String paramString2, String paramString3) throws UnsupportedEncodingException {
/* 112 */     this.address = paramString1;
/* 113 */     setPersonal(paramString2, paramString3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public String getType() { return "rfc822"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public void setAddress(String paramString) throws AddressException { this.address = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersonal(String paramString1, String paramString2) throws UnsupportedEncodingException {
/* 148 */     this.personal = paramString1;
/* 149 */     if (paramString1 != null) {
/* 150 */       this.encodedPersonal = MimeUtility.encodeWord(paramString1, paramString2, null); return;
/*     */     } 
/* 152 */     this.encodedPersonal = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersonal(String paramString) throws AddressException {
/* 168 */     this.personal = paramString;
/* 169 */     if (paramString != null) {
/* 170 */       this.encodedPersonal = MimeUtility.encodeWord(paramString); return;
/*     */     } 
/* 172 */     this.encodedPersonal = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public String getAddress() { return this.address; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPersonal() {
/* 191 */     if (this.personal != null) {
/* 192 */       return this.personal;
/*     */     }
/* 194 */     if (this.encodedPersonal != null) {
/*     */       try {
/* 196 */         this.personal = MimeUtility.decodeText(this.encodedPersonal);
/* 197 */         return this.personal;
/* 198 */       } catch (Exception exception) {
/*     */ 
/*     */ 
/*     */         
/* 202 */         return this.encodedPersonal;
/*     */       } 
/*     */     }
/*     */     
/* 206 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 217 */     if (this.encodedPersonal == null && this.personal != null) {
/*     */       try {
/* 219 */         this.encodedPersonal = MimeUtility.encodeWord(this.personal);
/* 220 */       } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */     }
/* 222 */     if (this.encodedPersonal != null)
/* 223 */       return String.valueOf(quotePhrase(this.encodedPersonal)) + " <" + this.address + ">"; 
/* 224 */     if (isGroup() || isSimple()) {
/* 225 */       return this.address;
/*     */     }
/* 227 */     return "<" + this.address + ">";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 247 */   private static final String rfc822phrase = "()<>@,;:\\\"\t []".replace(' ', false).replace('\t', false); private static final String specialsNoDotNoAt = "()<>,;:\\\"[]"; private static final String specialsNoDot = "()<>,;:\\\"[]@";
/*     */   
/*     */   private static String quotePhrase(String paramString) {
/* 250 */     int i = paramString.length();
/* 251 */     boolean bool = false;
/*     */     
/* 253 */     for (byte b = 0; b < i; b++) {
/* 254 */       char c = paramString.charAt(b);
/* 255 */       if (c == '"' || c == '\\') {
/*     */         
/* 257 */         StringBuffer stringBuffer = new StringBuffer(i + 3);
/* 258 */         stringBuffer.append('"');
/* 259 */         for (byte b1 = 0; b1 < i; b1++) {
/* 260 */           char c1 = paramString.charAt(b1);
/* 261 */           if (c1 == '"' || c1 == '\\')
/*     */           {
/* 263 */             stringBuffer.append('\\'); } 
/* 264 */           stringBuffer.append(c1);
/*     */         } 
/* 266 */         stringBuffer.append('"');
/* 267 */         return stringBuffer.toString();
/* 268 */       }  if ((c < ' ' && c != '\r' && c != '\n' && c != '\t') || 
/* 269 */         c >= '' || rfc822phrase.indexOf(c) >= 0)
/*     */       {
/* 271 */         bool = true;
/*     */       }
/*     */     } 
/* 274 */     if (bool) {
/* 275 */       StringBuffer stringBuffer = new StringBuffer(i + 2);
/* 276 */       stringBuffer.append('"').append(paramString).append('"');
/* 277 */       return stringBuffer.toString();
/*     */     } 
/* 279 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 286 */     if (!(paramObject instanceof InternetAddress)) {
/* 287 */       return false;
/*     */     }
/* 289 */     String str = ((InternetAddress)paramObject).getAddress();
/* 290 */     if (str == this.address)
/* 291 */       return true; 
/* 292 */     if (this.address != null && this.address.equalsIgnoreCase(str)) {
/* 293 */       return true;
/*     */     }
/* 295 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 302 */     if (this.address == null) {
/* 303 */       return 0;
/*     */     }
/* 305 */     return this.address.toLowerCase().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 321 */   public static String toString(Address[] paramArrayOfAddress) { return toString(paramArrayOfAddress, 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(Address[] paramArrayOfAddress, int paramInt) {
/* 345 */     if (paramArrayOfAddress == null || paramArrayOfAddress.length == 0) {
/* 346 */       return null;
/*     */     }
/* 348 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 350 */     for (byte b = 0; b < paramArrayOfAddress.length; b++) {
/* 351 */       if (b) {
/* 352 */         stringBuffer.append(", ");
/* 353 */         paramInt += 2;
/*     */       } 
/*     */       
/* 356 */       String str = paramArrayOfAddress[b].toString();
/* 357 */       int i = lengthOfFirstSegment(str);
/* 358 */       if (paramInt + i > 76) {
/* 359 */         stringBuffer.append("\r\n ");
/* 360 */         paramInt = 1;
/*     */       } 
/* 362 */       stringBuffer.append(str);
/* 363 */       paramInt = lengthOfLastSegment(str, paramInt);
/*     */     } 
/*     */     
/* 366 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int lengthOfFirstSegment(String paramString) {
/*     */     int i;
/* 374 */     if ((i = paramString.indexOf("\r\n")) != -1) {
/* 375 */       return i;
/*     */     }
/* 377 */     return paramString.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int lengthOfLastSegment(String paramString, int paramInt) {
/*     */     int i;
/* 387 */     if ((i = paramString.lastIndexOf("\r\n")) != -1) {
/* 388 */       return paramString.length() - i - 2;
/*     */     }
/* 390 */     return paramString.length() + paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InternetAddress getLocalAddress(Session paramSession) {
/* 407 */     String str1 = null, str2 = null, str3 = null;
/*     */     
/* 409 */     try { if (paramSession == null) {
/* 410 */         str1 = System.getProperty("user.name");
/* 411 */         str2 = InetAddress.getLocalHost().getHostName();
/*     */       } else {
/* 413 */         str3 = paramSession.getProperty("mail.from");
/* 414 */         if (str3 == null) {
/* 415 */           str1 = paramSession.getProperty("mail.user");
/* 416 */           if (str1 == null)
/* 417 */             str1 = paramSession.getProperty("user.name"); 
/* 418 */           if (str1 == null)
/* 419 */             str1 = System.getProperty("user.name"); 
/* 420 */           str2 = paramSession.getProperty("mail.host");
/* 421 */           if (str2 == null) {
/* 422 */             InetAddress inetAddress = InetAddress.getLocalHost();
/* 423 */             if (inetAddress != null) {
/* 424 */               str2 = inetAddress.getHostName();
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 429 */       if (str3 == null && str1 != null && str2 != null) {
/* 430 */         str3 = String.valueOf(str1) + "@" + str2;
/*     */       }
/* 432 */       if (str3 != null)
/* 433 */         return new InternetAddress(str3);  }
/* 434 */     catch (SecurityException securityException) {  }
/* 435 */     catch (AddressException addressException) {  }
/* 436 */     catch (UnknownHostException unknownHostException) {}
/* 437 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 450 */   public static InternetAddress[] parse(String paramString) throws AddressException { return parse(paramString, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InternetAddress[] parse(String paramString, boolean paramBoolean) throws AddressException {
/* 474 */     byte b4 = -1, b5 = -1;
/* 475 */     int i = paramString.length();
/* 476 */     boolean bool1 = false;
/* 477 */     boolean bool = false;
/* 478 */     boolean bool2 = false;
/*     */     
/* 480 */     Vector vector = new Vector();
/*     */     
/*     */     byte b1, b2, b3;
/* 483 */     for (b1 = b2 = -1, b3 = 0; b3 < i; b3++)
/* 484 */     { InternetAddress internetAddress; byte b; char c = paramString.charAt(b3);
/*     */       
/* 486 */       switch (c)
/*     */       
/*     */       { 
/*     */         case '(':
/* 490 */           bool2 = true;
/* 491 */           if (b1 >= 0 && b2 == -1)
/* 492 */             b2 = b3; 
/* 493 */           if (b4 == -1)
/* 494 */             b4 = b3 + 1; 
/* 495 */           b3++; for (b = 1; b3 < i && !b; 
/* 496 */             b3++) {
/* 497 */             c = paramString.charAt(b3);
/* 498 */             switch (c) {
/*     */               case '\\':
/* 500 */                 b3++;
/*     */                 break;
/*     */               case '(':
/* 503 */                 b++;
/*     */                 break;
/*     */               case ')':
/* 506 */                 b--;
/*     */                 break;
/*     */             } 
/*     */ 
/*     */           
/*     */           } 
/* 512 */           if (b > 0)
/* 513 */             throw new AddressException("Missing ')'", paramString, b3); 
/* 514 */           b3--;
/* 515 */           if (b5 == -1) {
/* 516 */             b5 = b3;
/*     */           }
/*     */           break;
/*     */         case ')':
/* 520 */           throw new AddressException("Missing '('", paramString, b3);
/*     */         
/*     */         case '<':
/* 523 */           bool2 = true;
/* 524 */           if (bool)
/* 525 */             throw new AddressException("Extra route-addr", paramString, b3); 
/* 526 */           if (!bool1) {
/* 527 */             b4 = b1;
/* 528 */             b5 = b3;
/* 529 */             b1 = b3 + 1;
/*     */           } 
/*     */ 
/*     */           
/* 533 */           while (++b3 < i) {
/* 534 */             c = paramString.charAt(b3);
/* 535 */             switch (c) {
/*     */               case '\\':
/* 537 */                 b3++;
/*     */               default:
/*     */                 b3++; continue;
/*     */               case '>':
/*     */                 break;
/*     */             } 
/*     */             break;
/*     */           } 
/* 545 */           if (b3 >= i)
/* 546 */             throw new AddressException("Missing '>'", paramString, b3); 
/* 547 */           bool = true;
/* 548 */           b2 = b3;
/*     */           break;
/*     */         case '>':
/* 551 */           throw new AddressException("Missing '<'", paramString, b3);
/*     */         
/*     */         case '"':
/* 554 */           bool2 = true;
/* 555 */           if (b1 == -1) {
/* 556 */             b1 = b3;
/*     */           }
/* 558 */           while (++b3 < i) {
/* 559 */             c = paramString.charAt(b3);
/* 560 */             switch (c) {
/*     */               case '\\':
/* 562 */                 b3++;
/*     */               default:
/*     */                 b3++; continue;
/*     */               case '"':
/*     */                 break;
/*     */             } 
/*     */             break;
/*     */           } 
/* 570 */           if (b3 >= i) {
/* 571 */             throw new AddressException("Missing '\"'", paramString, b3);
/*     */           }
/*     */           break;
/*     */         case '[':
/* 575 */           bool2 = true;
/*     */           
/* 577 */           while (++b3 < i) {
/* 578 */             c = paramString.charAt(b3);
/* 579 */             switch (c) {
/*     */               case '\\':
/* 581 */                 b3++;
/*     */                 b3++;
/*     */                 break;
/*     */               
/*     */               case ']':
/*     */                 break;
/*     */             } 
/*     */           } 
/* 589 */           if (b3 >= i) {
/* 590 */             throw new AddressException("Missing ']'", paramString, b3);
/*     */           }
/*     */           break;
/*     */         case ',':
/* 594 */           if (b1 == -1) {
/* 595 */             bool = false;
/* 596 */             bool2 = false;
/* 597 */             b1 = b2 = -1;
/*     */             break;
/*     */           } 
/* 600 */           if (!bool1) {
/*     */ 
/*     */             
/* 603 */             if (b2 == -1)
/* 604 */               b2 = b3; 
/* 605 */             String str = paramString.substring(b1, b2).trim();
/* 606 */             if (bool2 || paramBoolean) {
/* 607 */               checkAddress(str, bool, paramBoolean);
/* 608 */               InternetAddress internetAddress1 = new InternetAddress();
/* 609 */               internetAddress1.setAddress(str);
/* 610 */               if (b4 >= 0) {
/* 611 */                 String str1 = 
/* 612 */                   paramString.substring(b4, b5).trim();
/* 613 */                 if (str1.startsWith("\"") && 
/* 614 */                   str1.endsWith("\"")) {
/* 615 */                   str1 = str1.substring(1, 
/* 616 */                       str1.length() - 1);
/*     */                 }
/* 618 */                 internetAddress1.encodedPersonal = str1;
/* 619 */                 b4 = b5 = -1;
/*     */               } 
/* 621 */               vector.addElement(internetAddress1);
/*     */             } else {
/*     */               
/* 624 */               StringTokenizer stringTokenizer = new StringTokenizer(str);
/* 625 */               while (stringTokenizer.hasMoreTokens()) {
/* 626 */                 String str1 = stringTokenizer.nextToken();
/* 627 */                 checkAddress(str1, false, paramBoolean);
/* 628 */                 InternetAddress internetAddress1 = new InternetAddress();
/* 629 */                 internetAddress1.setAddress(str1);
/* 630 */                 vector.addElement(internetAddress1);
/*     */               } 
/*     */             } 
/*     */             
/* 634 */             bool = false;
/* 635 */             bool2 = false;
/* 636 */             b1 = b2 = -1;
/*     */           } 
/*     */           break;
/*     */         case ':':
/* 640 */           bool2 = true;
/* 641 */           if (bool1)
/* 642 */             throw new AddressException("Nested group", paramString, b3); 
/* 643 */           bool1 = true;
/*     */           break;
/*     */         
/*     */         case ';':
/* 647 */           if (!bool1)
/* 648 */             throw new AddressException(
/* 649 */                 "Illegal semicolon, not in group", paramString, b3); 
/* 650 */           bool1 = false;
/* 651 */           internetAddress = new InternetAddress();
/* 652 */           b2 = b3 + 1;
/* 653 */           internetAddress.setAddress(paramString.substring(b1, b2).trim());
/* 654 */           vector.addElement(internetAddress);
/*     */           
/* 656 */           bool = false;
/* 657 */           b1 = b2 = -1;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 668 */           if (b1 == -1)
/* 669 */             b1 = b3;  break;
/*     */         case '\t':
/*     */         case '\n':
/*     */         case '\r':
/*     */         case ' ':
/* 674 */           break; }  }  if (b1 >= 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 680 */       if (b2 == -1)
/* 681 */         b2 = b3; 
/* 682 */       String str = paramString.substring(b1, b2).trim();
/* 683 */       if (bool2 || paramBoolean) {
/* 684 */         checkAddress(str, bool, paramBoolean);
/* 685 */         InternetAddress internetAddress = new InternetAddress();
/* 686 */         internetAddress.setAddress(str);
/* 687 */         if (b4 >= 0) {
/* 688 */           String str1 = 
/* 689 */             paramString.substring(b4, b5).trim();
/* 690 */           if (str1.startsWith("\"") && str1.endsWith("\"")) {
/* 691 */             str1 = str1.substring(1, str1.length() - 1);
/*     */           }
/* 693 */           internetAddress.encodedPersonal = str1;
/*     */         } 
/* 695 */         vector.addElement(internetAddress);
/*     */       } else {
/*     */         
/* 698 */         StringTokenizer stringTokenizer = new StringTokenizer(str);
/* 699 */         while (stringTokenizer.hasMoreTokens()) {
/* 700 */           String str1 = stringTokenizer.nextToken();
/* 701 */           checkAddress(str1, false, paramBoolean);
/* 702 */           InternetAddress internetAddress = new InternetAddress();
/* 703 */           internetAddress.setAddress(str1);
/* 704 */           vector.addElement(internetAddress);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 709 */     InternetAddress[] arrayOfInternetAddress = new InternetAddress[vector.size()];
/* 710 */     vector.copyInto(arrayOfInternetAddress);
/* 711 */     return arrayOfInternetAddress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkAddress(String paramString, boolean paramBoolean1, boolean paramBoolean2) throws AddressException {
/*     */     String str2, str1;
/* 727 */     int j = 0;
/* 728 */     if (paramString.indexOf('"') >= 0)
/*     */       return; 
/* 730 */     if (!paramBoolean2 || paramBoolean1) {
/*     */       int k;
/*     */ 
/*     */ 
/*     */       
/* 735 */       for (j = 0; (k = indexOfAny(paramString, ",:", j)) >= 0; 
/* 736 */         j = k + 1) {
/* 737 */         if (paramString.charAt(j) != '@')
/* 738 */           throw new AddressException("Illegal route-addr", paramString); 
/* 739 */         if (paramString.charAt(k) == ':') {
/*     */           
/* 741 */           j = k + 1;
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*     */     int i;
/*     */     
/* 752 */     if ((i = paramString.indexOf('@', j)) >= 0) {
/* 753 */       if (i == j)
/* 754 */         throw new AddressException("Missing local name", paramString); 
/* 755 */       if (i == paramString.length() - 1)
/* 756 */         throw new AddressException("Missing domain", paramString); 
/* 757 */       str1 = paramString.substring(j, i);
/* 758 */       str2 = paramString.substring(i + 1);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 764 */       str1 = paramString;
/* 765 */       str2 = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 776 */     if (indexOfAny(paramString, " \t\n\r") >= 0) {
/* 777 */       throw new AddressException("Illegal whitespace in address", paramString);
/*     */     }
/* 779 */     if (indexOfAny(str1, "()<>,;:\\\"[]@") >= 0) {
/* 780 */       throw new AddressException("Illegal character in local name", paramString);
/*     */     }
/* 782 */     if (str2 != null && str2.indexOf('[') < 0 && 
/* 783 */       indexOfAny(str2, "()<>,;:\\\"[]@") >= 0) {
/* 784 */       throw new AddressException("Illegal character in domain", paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 793 */   private boolean isSimple() { return !(indexOfAny(this.address, "()<>,;:\\\"[]") >= 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 801 */   private boolean isGroup() { return !(!this.address.endsWith(";") || this.address.indexOf(':') <= 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 811 */   private static int indexOfAny(String paramString1, String paramString2) { return indexOfAny(paramString1, paramString2, 0); }
/*     */ 
/*     */   
/*     */   private static int indexOfAny(String paramString1, String paramString2, int paramInt) {
/*     */     try {
/* 816 */       int i = paramString1.length();
/* 817 */       for (int j = paramInt; j < i; j++) {
/* 818 */         if (paramString2.indexOf(paramString1.charAt(j)) >= 0)
/* 819 */           return j; 
/*     */       } 
/* 821 */       return -1;
/* 822 */     } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
/* 823 */       return -1;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\InternetAddress.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */