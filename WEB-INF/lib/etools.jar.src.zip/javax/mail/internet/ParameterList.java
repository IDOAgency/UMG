/*     */ package javax.mail.internet;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterList
/*     */ {
/*  22 */   private Hashtable list = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterList() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterList(String paramString) throws ParseException {
/*  41 */     HeaderTokenizer headerTokenizer = new HeaderTokenizer(paramString, "()<>@,;:\\\"\t []/?=");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/*  47 */       HeaderTokenizer.Token token = headerTokenizer.next();
/*  48 */       int i = token.getType();
/*     */       
/*  50 */       if (i == -4) {
/*     */         return;
/*     */       }
/*  53 */       if ((char)i == ';') {
/*     */         
/*  55 */         token = headerTokenizer.next();
/*     */         
/*  57 */         if (token.getType() != -1)
/*  58 */           throw new ParseException(); 
/*  59 */         String str = token.getValue().toLowerCase();
/*     */ 
/*     */         
/*  62 */         token = headerTokenizer.next();
/*  63 */         if ((char)token.getType() != '=') {
/*  64 */           throw new ParseException();
/*     */         }
/*     */         
/*  67 */         token = headerTokenizer.next();
/*  68 */         i = token.getType();
/*     */         
/*  70 */         if (i != -1 && 
/*  71 */           i != -2) {
/*  72 */           throw new ParseException();
/*     */         }
/*  74 */         this.list.put(str, token.getValue()); continue;
/*     */       }  break;
/*  76 */     }  throw new ParseException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public int size() { return this.list.size(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public String get(String paramString) { return (String)this.list.get(paramString.trim().toLowerCase()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public void set(String paramString1, String paramString2) { this.list.put(paramString1.trim().toLowerCase(), paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public void remove(String paramString) throws ParseException { this.list.remove(paramString.trim().toLowerCase()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public Enumeration getNames() { return this.list.keys(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 140 */     StringBuffer stringBuffer = new StringBuffer();
/* 141 */     Enumeration enumeration = this.list.keys();
/*     */     
/* 143 */     while (enumeration.hasMoreElements()) {
/* 144 */       String str1 = (String)enumeration.nextElement();
/* 145 */       String str2 = quote((String)this.list.get(str1));
/* 146 */       stringBuffer.append("; ").append(str1).append('=').append(str2);
/*     */     } 
/*     */     
/* 149 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 154 */   private String quote(String paramString) { return MimeUtility.quote(paramString, "()<>@,;:\\\"\t []/?="); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\ParameterList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */