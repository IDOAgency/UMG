package javax.mail.internet;

import java.util.Enumeration;
import java.util.Hashtable;

public class ParameterList {
  private Hashtable list = new Hashtable();
  
  public ParameterList() {}
  
  public ParameterList(String paramString) throws ParseException {
    HeaderTokenizer headerTokenizer = new HeaderTokenizer(paramString, "()<>@,;:\\\"\t []/?=");
    while (true) {
      HeaderTokenizer.Token token = headerTokenizer.next();
      int i = token.getType();
      if (i == -4)
        return; 
      if ((char)i == ';') {
        token = headerTokenizer.next();
        if (token.getType() != -1)
          throw new ParseException(); 
        String str = token.getValue().toLowerCase();
        token = headerTokenizer.next();
        if ((char)token.getType() != '=')
          throw new ParseException(); 
        token = headerTokenizer.next();
        i = token.getType();
        if (i != -1 && 
          i != -2)
          throw new ParseException(); 
        this.list.put(str, token.getValue());
        continue;
      } 
      break;
    } 
    throw new ParseException();
  }
  
  public int size() { return this.list.size(); }
  
  public String get(String paramString) { return (String)this.list.get(paramString.trim().toLowerCase()); }
  
  public void set(String paramString1, String paramString2) { this.list.put(paramString1.trim().toLowerCase(), paramString2); }
  
  public void remove(String paramString) throws ParseException { this.list.remove(paramString.trim().toLowerCase()); }
  
  public Enumeration getNames() { return this.list.keys(); }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    Enumeration enumeration = this.list.keys();
    while (enumeration.hasMoreElements()) {
      String str1 = (String)enumeration.nextElement();
      String str2 = quote((String)this.list.get(str1));
      stringBuffer.append("; ").append(str1).append('=').append(str2);
    } 
    return stringBuffer.toString();
  }
  
  private String quote(String paramString) { return MimeUtility.quote(paramString, "()<>@,;:\\\"\t []/?="); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\internet\ParameterList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */