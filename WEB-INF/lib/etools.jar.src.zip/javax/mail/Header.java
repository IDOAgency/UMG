package javax.mail;

public class Header {
  private String name;
  
  private String value;
  
  public Header(String paramString1, String paramString2) {
    this.name = paramString1;
    this.value = paramString2;
  }
  
  public String getName() { return this.name; }
  
  public String getValue() { return this.value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\Header.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */