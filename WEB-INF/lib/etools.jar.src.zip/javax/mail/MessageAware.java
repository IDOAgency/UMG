package javax.mail;

public interface MessageAware {
  MessageContext getMessageContext();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\MessageAware.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */