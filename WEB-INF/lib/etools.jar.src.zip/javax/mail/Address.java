package javax.mail;

public abstract class Address {
  public abstract String getType();
  
  public abstract String toString();
  
  public abstract boolean equals(Object paramObject);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\Address.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */