/*     */ package javax.mail;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.UnknownHostException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class URLName
/*     */ {
/*     */   protected String fullURL;
/*     */   private String protocol;
/*     */   private String username;
/*     */   private String password;
/*     */   private String host;
/*     */   private InetAddress hostAddress;
/*     */   private boolean hostAddressKnown;
/*     */   private int port;
/*     */   private String file;
/*     */   private String ref;
/*     */   private int hashCode;
/*     */   
/*     */   public URLName(String paramString1, String paramString2, int paramInt, String paramString3, String paramString4, String paramString5) {
/*  57 */     this.hostAddressKnown = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     this.port = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     this.protocol = paramString1;
/*  97 */     this.host = paramString2;
/*  98 */     this.port = paramInt;
/*     */     int i;
/* 100 */     if (paramString3 != null && (i = paramString3.indexOf('#')) != -1) {
/* 101 */       this.file = paramString3.substring(0, i);
/* 102 */       this.ref = paramString3.substring(i + 1);
/*     */     } else {
/* 104 */       this.file = paramString3;
/* 105 */       this.ref = null;
/*     */     } 
/* 107 */     this.username = paramString4;
/* 108 */     this.password = paramString5;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public URLName(URL paramURL) { this(paramURL.toString()); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URLName(String paramString) {
/*     */     this.hostAddressKnown = false;
/*     */     this.port = -1;
/* 123 */     parseString(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 130 */     if (this.fullURL == null) {
/*     */       
/* 132 */       StringBuffer stringBuffer = new StringBuffer();
/* 133 */       if (this.protocol != null) {
/* 134 */         stringBuffer.append(this.protocol);
/* 135 */         stringBuffer.append(":");
/*     */       } 
/*     */       
/* 138 */       if (this.username != null || this.host != null) {
/*     */         
/* 140 */         stringBuffer.append("//");
/*     */ 
/*     */ 
/*     */         
/* 144 */         if (this.username != null) {
/* 145 */           stringBuffer.append(this.username);
/*     */           
/* 147 */           if (this.password != null) {
/* 148 */             stringBuffer.append(":");
/* 149 */             stringBuffer.append(this.password);
/*     */           } 
/*     */           
/* 152 */           stringBuffer.append("@");
/*     */         } 
/*     */ 
/*     */         
/* 156 */         if (this.host != null) {
/* 157 */           stringBuffer.append(this.host);
/*     */         }
/*     */ 
/*     */         
/* 161 */         if (this.port != -1) {
/* 162 */           stringBuffer.append(":");
/* 163 */           stringBuffer.append(Integer.toString(this.port));
/*     */         } 
/* 165 */         if (this.file != null) {
/* 166 */           stringBuffer.append("/");
/*     */         }
/*     */       } 
/*     */       
/* 170 */       if (this.file != null) {
/* 171 */         stringBuffer.append(this.file);
/*     */       }
/*     */ 
/*     */       
/* 175 */       if (this.ref != null) {
/* 176 */         stringBuffer.append("#");
/* 177 */         stringBuffer.append(this.ref);
/*     */       } 
/*     */ 
/*     */       
/* 181 */       this.fullURL = stringBuffer.toString();
/*     */     } 
/*     */     
/* 184 */     return this.fullURL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseString(String paramString) {
/* 193 */     this.protocol = this.file = this.ref = this.host = this.username = this.password = null;
/* 194 */     this.port = -1;
/*     */     
/* 196 */     int i = paramString.length();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 201 */     int j = paramString.indexOf(':');
/* 202 */     if (j != -1) {
/* 203 */       this.protocol = paramString.substring(0, j);
/*     */     }
/*     */     
/* 206 */     if (paramString.regionMatches(j + 1, "//", 0, 2)) {
/*     */       
/* 208 */       String str = null;
/* 209 */       int m = paramString.indexOf('/', j + 3);
/* 210 */       if (m != -1)
/* 211 */       { str = paramString.substring(j + 3, m);
/* 212 */         if (m + 1 < i) {
/* 213 */           this.file = paramString.substring(m + 1);
/*     */         } else {
/* 215 */           this.file = "";
/*     */         }  }
/* 217 */       else { str = paramString.substring(j + 3); }
/*     */ 
/*     */       
/* 220 */       int n = str.indexOf('@');
/* 221 */       if (n != -1) {
/* 222 */         String str1 = str.substring(0, n);
/* 223 */         str = str.substring(n + 1);
/*     */ 
/*     */         
/* 226 */         int i2 = str1.indexOf(':');
/* 227 */         if (i2 != -1) {
/* 228 */           this.username = str1.substring(0, i2);
/* 229 */           this.password = str1.substring(i2 + 1);
/*     */         } else {
/* 231 */           this.username = str1;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 236 */       int i1 = str.indexOf(':');
/* 237 */       if (i1 != -1) {
/* 238 */         String str1 = str.substring(i1 + 1);
/* 239 */         if (str1.length() > 0) {
/*     */           try {
/* 241 */             this.port = Integer.parseInt(str1);
/* 242 */           } catch (NumberFormatException numberFormatException) {
/* 243 */             this.port = -1;
/*     */           } 
/*     */         }
/*     */         
/* 247 */         this.host = str.substring(0, i1);
/*     */       } else {
/* 249 */         this.host = str;
/*     */       }
/*     */     
/* 252 */     } else if (j + 1 < i) {
/* 253 */       this.file = paramString.substring(j + 1);
/*     */     } 
/*     */     
/*     */     int k;
/*     */     
/* 258 */     if (this.file != null && (k = this.file.indexOf('#')) != -1) {
/* 259 */       this.ref = this.file.substring(k + 1);
/* 260 */       this.file = this.file.substring(0, k);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 269 */   public int getPort() { return this.port; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 277 */   public String getProtocol() { return this.protocol; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 285 */   public String getFile() { return this.file; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 293 */   public String getRef() { return this.ref; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 301 */   public String getHost() { return this.host; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 309 */   public String getUsername() { return this.username; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 317 */   public String getPassword() { return this.password; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 324 */   public URL getURL() throws MalformedURLException { return new URL(getProtocol(), getHost(), getPort(), getFile()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 338 */     if (!(paramObject instanceof URLName))
/* 339 */       return false; 
/* 340 */     URLName uRLName = (URLName)paramObject;
/*     */ 
/*     */     
/* 343 */     if (uRLName.protocol == null || !uRLName.protocol.equals(this.protocol)) {
/* 344 */       return false;
/*     */     }
/*     */     
/* 347 */     InetAddress inetAddress1 = getHostAddress(), inetAddress2 = uRLName.getHostAddress();
/*     */     
/* 349 */     if (inetAddress1 != null && inetAddress2 != null) {
/* 350 */       if (!inetAddress1.equals(inetAddress2)) {
/* 351 */         return false;
/*     */       }
/* 353 */     } else if (this.host != null && uRLName.host != null) {
/* 354 */       if (!this.host.equalsIgnoreCase(uRLName.host)) {
/* 355 */         return false;
/*     */       }
/* 357 */     } else if (this.host != uRLName.host) {
/* 358 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 363 */     if (this.username != uRLName.username && (
/* 364 */       this.username == null || !this.username.equals(uRLName.username))) {
/* 365 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 371 */     String str1 = (this.file == null) ? "" : this.file;
/* 372 */     String str2 = (uRLName.file == null) ? "" : uRLName.file;
/*     */     
/* 374 */     if (!str1.equals(str2)) {
/* 375 */       return false;
/*     */     }
/*     */     
/* 378 */     if (this.port != uRLName.port) {
/* 379 */       return false;
/*     */     }
/*     */     
/* 382 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 389 */     if (this.hashCode != 0)
/* 390 */       return this.hashCode; 
/* 391 */     if (this.protocol != null)
/* 392 */       this.hashCode += this.protocol.hashCode(); 
/* 393 */     InetAddress inetAddress = getHostAddress();
/* 394 */     if (inetAddress != null) {
/* 395 */       this.hashCode += inetAddress.hashCode();
/* 396 */     } else if (this.host != null) {
/* 397 */       this.hashCode += this.host.toLowerCase().hashCode();
/* 398 */     }  if (this.username != null)
/* 399 */       this.hashCode += this.username.hashCode(); 
/* 400 */     if (this.file != null)
/* 401 */       this.hashCode += this.file.hashCode(); 
/* 402 */     this.hashCode += this.port;
/* 403 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InetAddress getHostAddress() {
/* 412 */     if (this.hostAddressKnown)
/* 413 */       return this.hostAddress; 
/* 414 */     if (this.host == null)
/* 415 */       return null; 
/*     */     try {
/* 417 */       this.hostAddress = InetAddress.getByName(this.host);
/* 418 */     } catch (UnknownHostException unknownHostException) {
/* 419 */       this.hostAddress = null;
/*     */     } 
/* 421 */     this.hostAddressKnown = true;
/* 422 */     return this.hostAddress;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\URLName.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */