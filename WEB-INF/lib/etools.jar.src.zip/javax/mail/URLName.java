package javax.mail;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;

public class URLName {
  protected String fullURL;
  
  private String protocol;
  
  private String username;
  
  private String password;
  
  private String host;
  
  private InetAddress hostAddress;
  
  private boolean hostAddressKnown;
  
  private int port;
  
  private String file;
  
  private String ref;
  
  private int hashCode;
  
  public URLName(String paramString1, String paramString2, int paramInt, String paramString3, String paramString4, String paramString5) {
    this.hostAddressKnown = false;
    this.port = -1;
    this.protocol = paramString1;
    this.host = paramString2;
    this.port = paramInt;
    int i;
    if (paramString3 != null && (i = paramString3.indexOf('#')) != -1) {
      this.file = paramString3.substring(0, i);
      this.ref = paramString3.substring(i + 1);
    } else {
      this.file = paramString3;
      this.ref = null;
    } 
    this.username = paramString4;
    this.password = paramString5;
  }
  
  public URLName(URL paramURL) { this(paramURL.toString()); }
  
  public URLName(String paramString) {
    this.hostAddressKnown = false;
    this.port = -1;
    parseString(paramString);
  }
  
  public String toString() {
    if (this.fullURL == null) {
      StringBuffer stringBuffer = new StringBuffer();
      if (this.protocol != null) {
        stringBuffer.append(this.protocol);
        stringBuffer.append(":");
      } 
      if (this.username != null || this.host != null) {
        stringBuffer.append("//");
        if (this.username != null) {
          stringBuffer.append(this.username);
          if (this.password != null) {
            stringBuffer.append(":");
            stringBuffer.append(this.password);
          } 
          stringBuffer.append("@");
        } 
        if (this.host != null)
          stringBuffer.append(this.host); 
        if (this.port != -1) {
          stringBuffer.append(":");
          stringBuffer.append(Integer.toString(this.port));
        } 
        if (this.file != null)
          stringBuffer.append("/"); 
      } 
      if (this.file != null)
        stringBuffer.append(this.file); 
      if (this.ref != null) {
        stringBuffer.append("#");
        stringBuffer.append(this.ref);
      } 
      this.fullURL = stringBuffer.toString();
    } 
    return this.fullURL;
  }
  
  protected void parseString(String paramString) {
    this.protocol = this.file = this.ref = this.host = this.username = this.password = null;
    this.port = -1;
    int i = paramString.length();
    int j = paramString.indexOf(':');
    if (j != -1)
      this.protocol = paramString.substring(0, j); 
    if (paramString.regionMatches(j + 1, "//", 0, 2)) {
      String str = null;
      int m = paramString.indexOf('/', j + 3);
      if (m != -1) {
        str = paramString.substring(j + 3, m);
        if (m + 1 < i) {
          this.file = paramString.substring(m + 1);
        } else {
          this.file = "";
        } 
      } else {
        str = paramString.substring(j + 3);
      } 
      int n = str.indexOf('@');
      if (n != -1) {
        String str1 = str.substring(0, n);
        str = str.substring(n + 1);
        int i2 = str1.indexOf(':');
        if (i2 != -1) {
          this.username = str1.substring(0, i2);
          this.password = str1.substring(i2 + 1);
        } else {
          this.username = str1;
        } 
      } 
      int i1 = str.indexOf(':');
      if (i1 != -1) {
        String str1 = str.substring(i1 + 1);
        if (str1.length() > 0)
          try {
            this.port = Integer.parseInt(str1);
          } catch (NumberFormatException numberFormatException) {
            this.port = -1;
          }  
        this.host = str.substring(0, i1);
      } else {
        this.host = str;
      } 
    } else if (j + 1 < i) {
      this.file = paramString.substring(j + 1);
    } 
    int k;
    if (this.file != null && (k = this.file.indexOf('#')) != -1) {
      this.ref = this.file.substring(k + 1);
      this.file = this.file.substring(0, k);
    } 
  }
  
  public int getPort() { return this.port; }
  
  public String getProtocol() { return this.protocol; }
  
  public String getFile() { return this.file; }
  
  public String getRef() { return this.ref; }
  
  public String getHost() { return this.host; }
  
  public String getUsername() { return this.username; }
  
  public String getPassword() { return this.password; }
  
  public URL getURL() throws MalformedURLException { return new URL(getProtocol(), getHost(), getPort(), getFile()); }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof URLName))
      return false; 
    URLName uRLName = (URLName)paramObject;
    if (uRLName.protocol == null || !uRLName.protocol.equals(this.protocol))
      return false; 
    InetAddress inetAddress1 = getHostAddress(), inetAddress2 = uRLName.getHostAddress();
    if (inetAddress1 != null && inetAddress2 != null) {
      if (!inetAddress1.equals(inetAddress2))
        return false; 
    } else if (this.host != null && uRLName.host != null) {
      if (!this.host.equalsIgnoreCase(uRLName.host))
        return false; 
    } else if (this.host != uRLName.host) {
      return false;
    } 
    if (this.username != uRLName.username && (
      this.username == null || !this.username.equals(uRLName.username)))
      return false; 
    String str1 = (this.file == null) ? "" : this.file;
    String str2 = (uRLName.file == null) ? "" : uRLName.file;
    if (!str1.equals(str2))
      return false; 
    if (this.port != uRLName.port)
      return false; 
    return true;
  }
  
  public int hashCode() {
    if (this.hashCode != 0)
      return this.hashCode; 
    if (this.protocol != null)
      this.hashCode += this.protocol.hashCode(); 
    InetAddress inetAddress = getHostAddress();
    if (inetAddress != null) {
      this.hashCode += inetAddress.hashCode();
    } else if (this.host != null) {
      this.hashCode += this.host.toLowerCase().hashCode();
    } 
    if (this.username != null)
      this.hashCode += this.username.hashCode(); 
    if (this.file != null)
      this.hashCode += this.file.hashCode(); 
    this.hashCode += this.port;
    return this.hashCode;
  }
  
  private InetAddress getHostAddress() {
    if (this.hostAddressKnown)
      return this.hostAddress; 
    if (this.host == null)
      return null; 
    try {
      this.hostAddress = InetAddress.getByName(this.host);
    } catch (UnknownHostException unknownHostException) {
      this.hostAddress = null;
    } 
    this.hostAddressKnown = true;
    return this.hostAddress;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\URLName.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */