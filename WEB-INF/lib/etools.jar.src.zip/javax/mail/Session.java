package javax.mail;

import com.sun.mail.util.LineInputStream;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.net.InetAddress;
import java.util.Hashtable;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public final class Session {
  private Properties props;
  
  private Authenticator authenticator;
  
  private Hashtable authTable;
  
  private boolean debug;
  
  private Vector providers;
  
  private Hashtable providersByProtocol;
  
  private Hashtable providersByClassName;
  
  private Properties addressMap;
  
  private static Session defaultSession = null;
  
  private Session(Properties paramProperties, Authenticator paramAuthenticator) {
    this.authTable = new Hashtable();
    this.debug = false;
    this.providers = new Vector();
    this.providersByProtocol = new Hashtable();
    this.providersByClassName = new Hashtable();
    this.addressMap = new Properties();
    this.props = paramProperties;
    this.authenticator = paramAuthenticator;
    if (Boolean.valueOf(paramProperties.getProperty("mail.debug")).booleanValue())
      this.debug = true; 
    if (paramAuthenticator != null) {
      clazz = paramAuthenticator.getClass();
    } else {
      clazz = getClass();
    } 
    loadProviders(clazz);
    loadAddressMap(clazz);
  }
  
  public static Session getInstance(Properties paramProperties, Authenticator paramAuthenticator) { return new Session(paramProperties, paramAuthenticator); }
  
  public static Session getDefaultInstance(Properties paramProperties, Authenticator paramAuthenticator) {
    if (defaultSession == null) {
      defaultSession = new Session(paramProperties, paramAuthenticator);
    } else if (defaultSession.authenticator != paramAuthenticator) {
      if (defaultSession.authenticator == null || 
        paramAuthenticator == null || 
        defaultSession.authenticator.getClass().getClassLoader() != 
        paramAuthenticator.getClass().getClassLoader())
        throw new SecurityException("Access to default session denied"); 
    } 
    return defaultSession;
  }
  
  public void setDebug(boolean paramBoolean) { this.debug = paramBoolean; }
  
  public boolean getDebug() { return this.debug; }
  
  public Provider[] getProviders() {
    Provider[] arrayOfProvider = new Provider[this.providers.size()];
    this.providers.copyInto(arrayOfProvider);
    return arrayOfProvider;
  }
  
  public Provider getProvider(String paramString) throws NoSuchProviderException {
    if (paramString == null || paramString.length() <= 0)
      throw new NoSuchProviderException("Invalid protocol: null"); 
    Provider provider = null;
    String str = this.props.getProperty("mail." + paramString + ".class");
    if (str != null) {
      if (this.debug)
        System.out.println("DEBUG: mail." + paramString + 
            ".class property exists and points to " + 
            str); 
      provider = (Provider)this.providersByClassName.get(str);
    } 
    if (provider != null)
      return provider; 
    provider = (Provider)this.providersByProtocol.get(paramString);
    if (provider == null)
      throw new NoSuchProviderException("No provider for " + paramString); 
    if (this.debug)
      System.out.println("\nDEBUG: getProvider() returning " + 
          provider.toString()); 
    return provider;
  }
  
  public void setProvider(Provider paramProvider) throws NoSuchProviderException {
    if (paramProvider == null)
      throw new NoSuchProviderException("Can't set null provider"); 
    this.providersByProtocol.put(paramProvider.getProtocol(), paramProvider);
    this.props.put("mail." + paramProvider.getProtocol() + ".class", 
        paramProvider.getClassName());
  }
  
  public Store getStore() throws NoSuchProviderException { return getStore(getProperty("mail.store.protocol")); }
  
  public Store getStore(String paramString) throws NoSuchProviderException { return getStore(new URLName(paramString, null, -1, null, null, null)); }
  
  public Store getStore(URLName paramURLName) throws NoSuchProviderException {
    String str = paramURLName.getProtocol();
    Provider provider = getProvider(str);
    return getStore(provider, paramURLName);
  }
  
  public Store getStore(Provider paramProvider) throws NoSuchProviderException { return getStore(paramProvider, null); }
  
  private Store getStore(Provider paramProvider, URLName paramURLName) throws NoSuchProviderException {
    if (paramProvider == null || paramProvider.getType() != Provider.Type.STORE)
      throw new NoSuchProviderException("invalid provider"); 
    try {
      return (Store)getService(paramProvider, paramURLName);
    } catch (ClassCastException classCastException) {
      throw new NoSuchProviderException("incorrect class");
    } 
  }
  
  public Folder getFolder(URLName paramURLName) throws MessagingException {
    Store store = getStore(paramURLName);
    store.connect();
    return store.getFolder(paramURLName);
  }
  
  public Transport getTransport() throws NoSuchProviderException { return getTransport(getProperty("mail.transport.protocol")); }
  
  public Transport getTransport(String paramString) throws NoSuchProviderException { return getTransport(new URLName(paramString, null, -1, null, null, null)); }
  
  public Transport getTransport(URLName paramURLName) throws NoSuchProviderException {
    String str = paramURLName.getProtocol();
    Provider provider = getProvider(str);
    return getTransport(provider, paramURLName);
  }
  
  public Transport getTransport(Provider paramProvider) throws NoSuchProviderException { return getTransport(paramProvider, null); }
  
  public Transport getTransport(Address paramAddress) throws NoSuchProviderException {
    String str = (String)this.addressMap.get(paramAddress.getType());
    if (str == null)
      throw new NoSuchProviderException("No provider for Address type: " + 
          paramAddress.getType()); 
    return getTransport(str);
  }
  
  private Transport getTransport(Provider paramProvider, URLName paramURLName) throws NoSuchProviderException {
    if (paramProvider == null || paramProvider.getType() != Provider.Type.TRANSPORT)
      throw new NoSuchProviderException("invalid provider"); 
    try {
      return (Transport)getService(paramProvider, paramURLName);
    } catch (ClassCastException classCastException) {
      throw new NoSuchProviderException("incorrect class");
    } 
  }
  
  private Object getService(Provider paramProvider, URLName paramURLName) throws NoSuchProviderException {
    if (paramProvider == null)
      throw new NoSuchProviderException("null"); 
    if (paramURLName == null)
      paramURLName = new URLName(paramProvider.getProtocol(), null, -1, 
          null, null, null); 
    Object object = null;
    try {
      Class clazz = Class.forName(paramProvider.getClassName());
      Class[] arrayOfClass = { Session.class, URLName.class };
      Constructor constructor = clazz.getConstructor(arrayOfClass);
      Object[] arrayOfObject = { this, paramURLName };
      object = constructor.newInstance(arrayOfObject);
    } catch (Exception exception) {
      if (this.debug)
        exception.printStackTrace(); 
      throw new NoSuchProviderException(paramProvider.getProtocol());
    } 
    return object;
  }
  
  public void setPasswordAuthentication(URLName paramURLName, PasswordAuthentication paramPasswordAuthentication) {
    if (paramPasswordAuthentication == null) {
      this.authTable.remove(paramURLName);
      return;
    } 
    this.authTable.put(paramURLName, paramPasswordAuthentication);
  }
  
  public PasswordAuthentication getPasswordAuthentication(URLName paramURLName) { return (PasswordAuthentication)this.authTable.get(paramURLName); }
  
  public PasswordAuthentication requestPasswordAuthentication(InetAddress paramInetAddress, int paramInt, String paramString1, String paramString2, String paramString3) {
    if (this.authenticator != null)
      return this.authenticator.requestPasswordAuthentication(
          paramInetAddress, paramInt, paramString1, paramString2, paramString3); 
    return null;
  }
  
  public Properties getProperties() { return this.props; }
  
  public String getProperty(String paramString) { return this.props.getProperty(paramString); }
  
  private void loadProviders(Class paramClass) {
    BufferedInputStream bufferedInputStream = null;
    try {
      String str = String.valueOf(System.getProperty("java.home")) + 
        File.separator + "lib" + 
        File.separator + "javamail.providers";
      bufferedInputStream = 
        new BufferedInputStream(new FileInputStream(str));
      if (bufferedInputStream != null) {
        loadProvidersFromStream(bufferedInputStream);
        bufferedInputStream.close();
        pr("DEBUG: loaded providers in <java.home>/lib");
      } else if (this.debug) {
        pr("DEBUG: not loading system providers in <java.home>/lib");
      } 
    } catch (FileNotFoundException fileNotFoundException) {
      if (this.debug)
        pr("DEBUG: not loading system providers in <java.home>/lib"); 
    } catch (IOException iOException) {
      if (this.debug)
        pr("DEBUG: " + iOException.getMessage()); 
    } catch (SecurityException securityException) {
      if (this.debug)
        pr("DEBUG: not loading system providers in <java.home>/lib"); 
    } 
    InputStream inputStream1 = null;
    String str1 = "/META-INF/javamail.providers";
    inputStream1 = paramClass.getResourceAsStream(str1);
    if (inputStream1 != null) {
      try {
        loadProvidersFromStream(inputStream1);
        inputStream1.close();
        if (this.debug)
          pr("DEBUG:successfully loaded optional custom providers: " + 
              str1); 
      } catch (IOException iOException) {
        if (this.debug)
          pr("DEBUG: " + iOException.getMessage()); 
      } 
    } else if (this.debug) {
      pr("DEBUG: not loading optional custom providers file: " + 
          str1);
    } 
    InputStream inputStream2 = null;
    String str2 = "/META-INF/javamail.default.providers";
    inputStream2 = paramClass.getResourceAsStream(str2);
    if (inputStream2 != null) {
      try {
        loadProvidersFromStream(inputStream2);
        inputStream2.close();
        if (this.debug)
          pr("DEBUG: successfully loaded default providers"); 
      } catch (IOException iOException) {
        if (this.debug)
          pr("DEBUG: " + iOException.getMessage()); 
      } 
    } else if (this.debug) {
      pr("DEBUG: can't load default providers file" + str2);
    } 
    if (this.debug) {
      System.out.println("\nDEBUG: Tables of loaded providers");
      pr("DEBUG: Providers Listed By Class Name: " + 
          this.providersByClassName.toString());
      pr("DEBUG: Providers Listed By Protocol: " + 
          this.providersByProtocol.toString());
    } 
  }
  
  private void loadProvidersFromStream(InputStream paramInputStream) throws IOException {
    if (paramInputStream != null) {
      LineInputStream lineInputStream = new LineInputStream(paramInputStream);
      String str;
      while ((str = lineInputStream.readLine()) != null) {
        if (!str.startsWith("#")) {
          Provider.Type type = null;
          String str1 = null, str2 = null;
          String str3 = null, str4 = null;
          StringTokenizer stringTokenizer = new StringTokenizer(str, ";");
          while (stringTokenizer.hasMoreTokens()) {
            String str5 = stringTokenizer.nextToken().trim();
            int i = str5.indexOf("=");
            if (str5.startsWith("protocol=")) {
              str1 = str5.substring(i + 1);
              continue;
            } 
            if (str5.startsWith("type=")) {
              String str6 = str5.substring(i + 1);
              if (str6.equalsIgnoreCase("store")) {
                type = Provider.Type.STORE;
                continue;
              } 
              if (str6.equalsIgnoreCase("transport"))
                type = Provider.Type.TRANSPORT; 
              continue;
            } 
            if (str5.startsWith("class=")) {
              str2 = str5.substring(i + 1);
              continue;
            } 
            if (str5.startsWith("vendor=")) {
              str3 = str5.substring(i + 1);
              continue;
            } 
            if (str5.startsWith("version="))
              str4 = str5.substring(i + 1); 
          } 
          if (type == null || str1 == null || str2 == null || 
            str1.length() <= 0 || str2.length() <= 0) {
            if (this.debug)
              System.out.println("DEBUG: Bad provider entry: " + 
                  str); 
            continue;
          } 
          Provider provider = new Provider(type, str1, str2, 
              str3, str4);
          this.providers.addElement(provider);
          this.providersByClassName.put(str2, provider);
          if (!this.providersByProtocol.containsKey(str1))
            this.providersByProtocol.put(str1, provider); 
        } 
      } 
    } 
  }
  
  private void loadAddressMap(Class paramClass) {
    InputStream inputStream1 = null;
    String str1 = "/META-INF/javamail.default.address.map";
    inputStream1 = paramClass.getResourceAsStream(str1);
    if (inputStream1 != null)
      try {
        this.addressMap.load(inputStream1);
        inputStream1.close();
      } catch (IOException iOException) {
      
      } catch (SecurityException securityException) {} 
    InputStream inputStream2 = null;
    String str2 = "/META-INF/javamail.address.map";
    inputStream2 = paramClass.getResourceAsStream(str2);
    if (inputStream2 != null)
      try {
        this.addressMap.load(inputStream2);
        inputStream2.close();
      } catch (IOException iOException) {} 
    BufferedInputStream bufferedInputStream = null;
    try {
      String str = String.valueOf(System.getProperty("java.home")) + 
        File.separator + "lib" + 
        File.separator + "javamail.address.map";
      bufferedInputStream = 
        new BufferedInputStream(new FileInputStream(str));
    } catch (FileNotFoundException fileNotFoundException) {
    
    } catch (SecurityException securityException) {}
    if (bufferedInputStream != null)
      try {
        this.addressMap.load(bufferedInputStream);
        bufferedInputStream.close();
        return;
      } catch (IOException iOException) {
        return;
      }  
  }
  
  private static void pr(String paramString) { System.out.println(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\Session.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */