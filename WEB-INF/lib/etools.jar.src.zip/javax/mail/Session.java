/*     */ package javax.mail;
/*     */ 
/*     */ import com.sun.mail.util.LineInputStream;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Session
/*     */ {
/*     */   private Properties props;
/*     */   private Authenticator authenticator;
/*     */   private Hashtable authTable;
/*     */   private boolean debug;
/*     */   private Vector providers;
/*     */   private Hashtable providersByProtocol;
/*     */   private Hashtable providersByClassName;
/*     */   private Properties addressMap;
/*  47 */   private static Session defaultSession = null; private Session(Properties paramProperties, Authenticator paramAuthenticator) { this.authTable = new Hashtable(); this.debug = false; this.providers = new Vector();
/*     */     this.providersByProtocol = new Hashtable();
/*     */     this.providersByClassName = new Hashtable();
/*     */     this.addressMap = new Properties();
/*  51 */     this.props = paramProperties;
/*  52 */     this.authenticator = paramAuthenticator;
/*     */     
/*  54 */     if (Boolean.valueOf(paramProperties.getProperty("mail.debug")).booleanValue()) {
/*  55 */       this.debug = true;
/*     */     }
/*     */ 
/*     */     
/*  59 */     if (paramAuthenticator != null) {
/*  60 */       clazz = paramAuthenticator.getClass();
/*     */     } else {
/*  62 */       clazz = getClass();
/*     */     } 
/*  64 */     loadProviders(clazz);
/*  65 */     loadAddressMap(clazz); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public static Session getInstance(Properties paramProperties, Authenticator paramAuthenticator) { return new Session(paramProperties, paramAuthenticator); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Session getDefaultInstance(Properties paramProperties, Authenticator paramAuthenticator) {
/* 128 */     if (defaultSession == null) {
/* 129 */       defaultSession = new Session(paramProperties, paramAuthenticator);
/*     */     
/*     */     }
/* 132 */     else if (defaultSession.authenticator != paramAuthenticator) {
/*     */       
/* 134 */       if (defaultSession.authenticator == null || 
/* 135 */         paramAuthenticator == null || 
/* 136 */         defaultSession.authenticator.getClass().getClassLoader() != 
/* 137 */         paramAuthenticator.getClass().getClassLoader())
/*     */       {
/*     */ 
/*     */         
/* 141 */         throw new SecurityException("Access to default session denied");
/*     */       }
/*     */     } 
/* 144 */     return defaultSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public void setDebug(boolean paramBoolean) { this.debug = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public boolean getDebug() { return this.debug; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Provider[] getProviders() {
/* 185 */     Provider[] arrayOfProvider = new Provider[this.providers.size()];
/* 186 */     this.providers.copyInto(arrayOfProvider);
/* 187 */     return arrayOfProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Provider getProvider(String paramString) throws NoSuchProviderException {
/* 207 */     if (paramString == null || paramString.length() <= 0) {
/* 208 */       throw new NoSuchProviderException("Invalid protocol: null");
/*     */     }
/*     */     
/* 211 */     Provider provider = null;
/*     */ 
/*     */     
/* 214 */     String str = this.props.getProperty("mail." + paramString + ".class");
/* 215 */     if (str != null) {
/* 216 */       if (this.debug) {
/* 217 */         System.out.println("DEBUG: mail." + paramString + 
/* 218 */             ".class property exists and points to " + 
/* 219 */             str);
/*     */       }
/* 221 */       provider = (Provider)this.providersByClassName.get(str);
/*     */     } 
/*     */     
/* 224 */     if (provider != null) {
/* 225 */       return provider;
/*     */     }
/*     */     
/* 228 */     provider = (Provider)this.providersByProtocol.get(paramString);
/*     */ 
/*     */     
/* 231 */     if (provider == null) {
/* 232 */       throw new NoSuchProviderException("No provider for " + paramString);
/*     */     }
/* 234 */     if (this.debug) {
/* 235 */       System.out.println("\nDEBUG: getProvider() returning " + 
/* 236 */           provider.toString());
/*     */     }
/* 238 */     return provider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProvider(Provider paramProvider) throws NoSuchProviderException {
/* 252 */     if (paramProvider == null) {
/* 253 */       throw new NoSuchProviderException("Can't set null provider");
/*     */     }
/* 255 */     this.providersByProtocol.put(paramProvider.getProtocol(), paramProvider);
/* 256 */     this.props.put("mail." + paramProvider.getProtocol() + ".class", 
/* 257 */         paramProvider.getClassName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 272 */   public Store getStore() throws NoSuchProviderException { return getStore(getProperty("mail.store.protocol")); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 286 */   public Store getStore(String paramString) throws NoSuchProviderException { return getStore(new URLName(paramString, null, -1, null, null, null)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Store getStore(URLName paramURLName) throws NoSuchProviderException {
/* 305 */     String str = paramURLName.getProtocol();
/* 306 */     Provider provider = getProvider(str);
/* 307 */     return getStore(provider, paramURLName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 320 */   public Store getStore(Provider paramProvider) throws NoSuchProviderException { return getStore(paramProvider, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Store getStore(Provider paramProvider, URLName paramURLName) throws NoSuchProviderException {
/* 340 */     if (paramProvider == null || paramProvider.getType() != Provider.Type.STORE) {
/* 341 */       throw new NoSuchProviderException("invalid provider");
/*     */     }
/*     */     
/*     */     try {
/* 345 */       return (Store)getService(paramProvider, paramURLName);
/* 346 */     } catch (ClassCastException classCastException) {
/* 347 */       throw new NoSuchProviderException("incorrect class");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Folder getFolder(URLName paramURLName) throws MessagingException {
/* 378 */     Store store = getStore(paramURLName);
/* 379 */     store.connect();
/* 380 */     return store.getFolder(paramURLName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 393 */   public Transport getTransport() throws NoSuchProviderException { return getTransport(getProperty("mail.transport.protocol")); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 406 */   public Transport getTransport(String paramString) throws NoSuchProviderException { return getTransport(new URLName(paramString, null, -1, null, null, null)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Transport getTransport(URLName paramURLName) throws NoSuchProviderException {
/* 424 */     String str = paramURLName.getProtocol();
/* 425 */     Provider provider = getProvider(str);
/* 426 */     return getTransport(provider, paramURLName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 440 */   public Transport getTransport(Provider paramProvider) throws NoSuchProviderException { return getTransport(paramProvider, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Transport getTransport(Address paramAddress) throws NoSuchProviderException {
/* 456 */     String str = (String)this.addressMap.get(paramAddress.getType());
/* 457 */     if (str == null) {
/* 458 */       throw new NoSuchProviderException("No provider for Address type: " + 
/* 459 */           paramAddress.getType());
/*     */     }
/* 461 */     return getTransport(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Transport getTransport(Provider paramProvider, URLName paramURLName) throws NoSuchProviderException {
/* 478 */     if (paramProvider == null || paramProvider.getType() != Provider.Type.TRANSPORT) {
/* 479 */       throw new NoSuchProviderException("invalid provider");
/*     */     }
/*     */     
/*     */     try {
/* 483 */       return (Transport)getService(paramProvider, paramURLName);
/* 484 */     } catch (ClassCastException classCastException) {
/* 485 */       throw new NoSuchProviderException("incorrect class");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object getService(Provider paramProvider, URLName paramURLName) throws NoSuchProviderException {
/* 503 */     if (paramProvider == null) {
/* 504 */       throw new NoSuchProviderException("null");
/*     */     }
/*     */ 
/*     */     
/* 508 */     if (paramURLName == null) {
/* 509 */       paramURLName = new URLName(paramProvider.getProtocol(), null, -1, 
/* 510 */           null, null, null);
/*     */     }
/*     */     
/* 513 */     Object object = null;
/*     */     
/*     */     try {
/* 516 */       Class clazz = Class.forName(paramProvider.getClassName());
/* 517 */       Class[] arrayOfClass = { Session.class, URLName.class };
/* 518 */       Constructor constructor = clazz.getConstructor(arrayOfClass);
/*     */       
/* 520 */       Object[] arrayOfObject = { this, paramURLName };
/* 521 */       object = constructor.newInstance(arrayOfObject);
/*     */     }
/* 523 */     catch (Exception exception) {
/* 524 */       if (this.debug) exception.printStackTrace(); 
/* 525 */       throw new NoSuchProviderException(paramProvider.getProtocol());
/*     */     } 
/*     */     
/* 528 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPasswordAuthentication(URLName paramURLName, PasswordAuthentication paramPasswordAuthentication) {
/* 543 */     if (paramPasswordAuthentication == null) {
/* 544 */       this.authTable.remove(paramURLName); return;
/*     */     } 
/* 546 */     this.authTable.put(paramURLName, paramPasswordAuthentication);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 556 */   public PasswordAuthentication getPasswordAuthentication(URLName paramURLName) { return (PasswordAuthentication)this.authTable.get(paramURLName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PasswordAuthentication requestPasswordAuthentication(InetAddress paramInetAddress, int paramInt, String paramString1, String paramString2, String paramString3) {
/* 582 */     if (this.authenticator != null) {
/* 583 */       return this.authenticator.requestPasswordAuthentication(
/* 584 */           paramInetAddress, paramInt, paramString1, paramString2, paramString3);
/*     */     }
/* 586 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 595 */   public Properties getProperties() { return this.props; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 604 */   public String getProperty(String paramString) { return this.props.getProperty(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadProviders(Class paramClass) {
/* 610 */     BufferedInputStream bufferedInputStream = null;
/*     */     try {
/* 612 */       String str = String.valueOf(System.getProperty("java.home")) + 
/* 613 */         File.separator + "lib" + 
/* 614 */         File.separator + "javamail.providers";
/* 615 */       bufferedInputStream = 
/* 616 */         new BufferedInputStream(new FileInputStream(str));
/* 617 */       if (bufferedInputStream != null) {
/* 618 */         loadProvidersFromStream(bufferedInputStream);
/* 619 */         bufferedInputStream.close();
/* 620 */         pr("DEBUG: loaded providers in <java.home>/lib");
/*     */       }
/* 622 */       else if (this.debug) {
/* 623 */         pr("DEBUG: not loading system providers in <java.home>/lib");
/*     */       } 
/* 625 */     } catch (FileNotFoundException fileNotFoundException) {
/* 626 */       if (this.debug)
/* 627 */         pr("DEBUG: not loading system providers in <java.home>/lib"); 
/* 628 */     } catch (IOException iOException) {
/* 629 */       if (this.debug)
/* 630 */         pr("DEBUG: " + iOException.getMessage()); 
/* 631 */     } catch (SecurityException securityException) {
/* 632 */       if (this.debug) {
/* 633 */         pr("DEBUG: not loading system providers in <java.home>/lib");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 639 */     InputStream inputStream1 = null;
/* 640 */     String str1 = "/META-INF/javamail.providers";
/* 641 */     inputStream1 = paramClass.getResourceAsStream(str1);
/* 642 */     if (inputStream1 != null) {
/*     */       try {
/* 644 */         loadProvidersFromStream(inputStream1);
/* 645 */         inputStream1.close();
/* 646 */         if (this.debug)
/* 647 */           pr("DEBUG:successfully loaded optional custom providers: " + 
/* 648 */               str1); 
/* 649 */       } catch (IOException iOException) {
/* 650 */         if (this.debug) {
/* 651 */           pr("DEBUG: " + iOException.getMessage());
/*     */         }
/*     */       } 
/* 654 */     } else if (this.debug) {
/* 655 */       pr("DEBUG: not loading optional custom providers file: " + 
/* 656 */           str1);
/*     */     } 
/*     */ 
/*     */     
/* 660 */     InputStream inputStream2 = null;
/* 661 */     String str2 = "/META-INF/javamail.default.providers";
/* 662 */     inputStream2 = paramClass.getResourceAsStream(str2);
/* 663 */     if (inputStream2 != null) {
/*     */       try {
/* 665 */         loadProvidersFromStream(inputStream2);
/* 666 */         inputStream2.close();
/* 667 */         if (this.debug)
/* 668 */           pr("DEBUG: successfully loaded default providers"); 
/* 669 */       } catch (IOException iOException) {
/* 670 */         if (this.debug) {
/* 671 */           pr("DEBUG: " + iOException.getMessage());
/*     */         }
/*     */       } 
/* 674 */     } else if (this.debug) {
/* 675 */       pr("DEBUG: can't load default providers file" + str2);
/*     */     } 
/*     */ 
/*     */     
/* 679 */     if (this.debug) {
/* 680 */       System.out.println("\nDEBUG: Tables of loaded providers");
/*     */ 
/*     */ 
/*     */       
/* 684 */       pr("DEBUG: Providers Listed By Class Name: " + 
/* 685 */           this.providersByClassName.toString());
/*     */ 
/*     */ 
/*     */       
/* 689 */       pr("DEBUG: Providers Listed By Protocol: " + 
/* 690 */           this.providersByProtocol.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadProvidersFromStream(InputStream paramInputStream) throws IOException {
/* 696 */     if (paramInputStream != null) {
/* 697 */       LineInputStream lineInputStream = new LineInputStream(paramInputStream);
/*     */       
/*     */       String str;
/*     */       
/* 701 */       while ((str = lineInputStream.readLine()) != null) {
/*     */         
/* 703 */         if (!str.startsWith("#")) {
/*     */           
/* 705 */           Provider.Type type = null;
/* 706 */           String str1 = null, str2 = null;
/* 707 */           String str3 = null, str4 = null;
/*     */ 
/*     */           
/* 710 */           StringTokenizer stringTokenizer = new StringTokenizer(str, ";");
/* 711 */           while (stringTokenizer.hasMoreTokens()) {
/* 712 */             String str5 = stringTokenizer.nextToken().trim();
/*     */ 
/*     */             
/* 715 */             int i = str5.indexOf("=");
/* 716 */             if (str5.startsWith("protocol=")) {
/* 717 */               str1 = str5.substring(i + 1); continue;
/* 718 */             }  if (str5.startsWith("type=")) {
/* 719 */               String str6 = str5.substring(i + 1);
/* 720 */               if (str6.equalsIgnoreCase("store")) {
/* 721 */                 type = Provider.Type.STORE; continue;
/* 722 */               }  if (str6.equalsIgnoreCase("transport"))
/* 723 */                 type = Provider.Type.TRANSPORT;  continue;
/*     */             } 
/* 725 */             if (str5.startsWith("class=")) {
/* 726 */               str2 = str5.substring(i + 1); continue;
/* 727 */             }  if (str5.startsWith("vendor=")) {
/* 728 */               str3 = str5.substring(i + 1); continue;
/* 729 */             }  if (str5.startsWith("version=")) {
/* 730 */               str4 = str5.substring(i + 1);
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 735 */           if (type == null || str1 == null || str2 == null || 
/* 736 */             str1.length() <= 0 || str2.length() <= 0) {
/*     */             
/* 738 */             if (this.debug)
/* 739 */               System.out.println("DEBUG: Bad provider entry: " + 
/* 740 */                   str); 
/*     */             continue;
/*     */           } 
/* 743 */           Provider provider = new Provider(type, str1, str2, 
/* 744 */               str3, str4);
/*     */ 
/*     */           
/* 747 */           this.providers.addElement(provider);
/* 748 */           this.providersByClassName.put(str2, provider);
/* 749 */           if (!this.providersByProtocol.containsKey(str1)) {
/* 750 */             this.providersByProtocol.put(str1, provider);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadAddressMap(Class paramClass) {
/* 762 */     InputStream inputStream1 = null;
/* 763 */     String str1 = "/META-INF/javamail.default.address.map";
/* 764 */     inputStream1 = paramClass.getResourceAsStream(str1);
/* 765 */     if (inputStream1 != null) {
/*     */       
/* 767 */       try { this.addressMap.load(inputStream1);
/* 768 */         inputStream1.close(); }
/* 769 */       catch (IOException iOException) {  }
/* 770 */       catch (SecurityException securityException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 776 */     InputStream inputStream2 = null;
/* 777 */     String str2 = "/META-INF/javamail.address.map";
/* 778 */     inputStream2 = paramClass.getResourceAsStream(str2);
/*     */     
/* 780 */     if (inputStream2 != null) {
/*     */       try {
/* 782 */         this.addressMap.load(inputStream2);
/* 783 */         inputStream2.close();
/* 784 */       } catch (IOException iOException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 790 */     BufferedInputStream bufferedInputStream = null;
/*     */     try {
/* 792 */       String str = String.valueOf(System.getProperty("java.home")) + 
/* 793 */         File.separator + "lib" + 
/* 794 */         File.separator + "javamail.address.map";
/* 795 */       bufferedInputStream = 
/* 796 */         new BufferedInputStream(new FileInputStream(str));
/* 797 */     } catch (FileNotFoundException fileNotFoundException) {
/*     */     
/* 799 */     } catch (SecurityException securityException) {}
/*     */ 
/*     */     
/* 802 */     if (bufferedInputStream != null)
/*     */       try {
/* 804 */         this.addressMap.load(bufferedInputStream);
/* 805 */         bufferedInputStream.close(); return;
/* 806 */       } catch (IOException iOException) {
/*     */         return;
/*     */       }  
/*     */   }
/*     */   
/* 811 */   private static void pr(String paramString) { System.out.println(paramString); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\Session.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */