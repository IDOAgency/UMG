package javax.mail;

public interface UIDFolder {
  public static final long LASTUID = -1L;
  
  long getUIDValidity() throws MessagingException;
  
  Message getMessageByUID(long paramLong) throws MessagingException;
  
  Message[] getMessagesByUID(long paramLong1, long paramLong2) throws MessagingException;
  
  Message[] getMessagesByUID(long[] paramArrayOfLong) throws MessagingException;
  
  long getUID(Message paramMessage) throws MessagingException;
  
  public static class FetchProfileItem extends FetchProfile.Item {
    protected FetchProfileItem(String param1String) { super(param1String); }
    
    public static final FetchProfileItem UID = new FetchProfileItem("UID");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\UIDFolder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */