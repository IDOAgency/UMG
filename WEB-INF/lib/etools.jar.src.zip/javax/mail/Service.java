/*     */ package javax.mail;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Vector;
/*     */ import javax.mail.event.ConnectionEvent;
/*     */ import javax.mail.event.ConnectionListener;
/*     */ import javax.mail.event.MailEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Service
/*     */ {
/*     */   protected Session session;
/*     */   protected URLName url;
/*     */   protected boolean debug;
/*     */   private boolean connected;
/*     */   private Vector connectionListeners;
/*     */   private EventQueue q;
/*     */   
/*     */   protected Service(Session paramSession, URLName paramURLName) {
/*  43 */     this.debug = false;
/*     */     
/*  45 */     this.connected = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     this.session = paramSession;
/*  56 */     this.url = paramURLName;
/*  57 */     this.debug = paramSession.getDebug();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public void connect() throws MessagingException { connect(null, null, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public void connect(String paramString1, String paramString2, String paramString3) throws MessagingException { connect(paramString1, -1, paramString2, paramString3); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect(String paramString1, int paramInt, String paramString2, String paramString3) throws MessagingException {
/* 148 */     if (isConnected()) {
/* 149 */       throw new MessagingException("already connected");
/*     */     }
/*     */     
/* 152 */     boolean bool = false;
/* 153 */     boolean bool1 = false;
/* 154 */     String str1 = null;
/* 155 */     String str2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     if (this.url != null) {
/* 161 */       str1 = this.url.getProtocol();
/* 162 */       if (paramString1 == null)
/* 163 */         paramString1 = this.url.getHost(); 
/* 164 */       if (paramInt == -1) {
/* 165 */         paramInt = this.url.getPort();
/*     */       }
/* 167 */       if (paramString2 == null) {
/* 168 */         paramString2 = this.url.getUsername();
/* 169 */         if (paramString3 == null) {
/* 170 */           paramString3 = this.url.getPassword();
/*     */         }
/* 172 */       } else if (paramString3 == null && paramString2.equals(this.url.getUsername())) {
/*     */         
/* 174 */         paramString3 = this.url.getPassword();
/*     */       } 
/*     */       
/* 177 */       str2 = this.url.getFile();
/*     */     } 
/*     */ 
/*     */     
/* 181 */     if (str1 != null) {
/* 182 */       if (paramString1 == null)
/* 183 */         paramString1 = this.session.getProperty("mail." + str1 + ".host"); 
/* 184 */       if (paramString2 == null) {
/* 185 */         paramString2 = this.session.getProperty("mail." + str1 + ".user");
/*     */       }
/*     */     } 
/*     */     
/* 189 */     if (paramString1 == null) {
/* 190 */       paramString1 = this.session.getProperty("mail.host");
/*     */     }
/* 192 */     if (paramString2 == null) {
/* 193 */       paramString2 = this.session.getProperty("mail.user");
/*     */     }
/*     */     
/* 196 */     if (paramString2 == null) {
/*     */       try {
/* 198 */         paramString2 = System.getProperty("user.name");
/* 199 */       } catch (SecurityException securityException) {
/* 200 */         if (this.debug) {
/* 201 */           securityException.printStackTrace();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 206 */     if (paramString3 == null && this.url != null) {
/* 207 */       PasswordAuthentication passwordAuthentication = this.session.getPasswordAuthentication(getURLName());
/* 208 */       if (passwordAuthentication != null) {
/* 209 */         if (paramString2 == null) {
/* 210 */           paramString2 = passwordAuthentication.getUserName();
/* 211 */           paramString3 = passwordAuthentication.getPassword();
/* 212 */         } else if (paramString2.equals(passwordAuthentication.getUserName())) {
/* 213 */           paramString3 = passwordAuthentication.getPassword();
/*     */         } 
/*     */       } else {
/* 216 */         bool1 = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 221 */     bool = protocolConnect(paramString1, paramInt, paramString2, paramString3);
/*     */ 
/*     */     
/* 224 */     if (!bool) {
/*     */       InetAddress inetAddress;
/*     */       try {
/* 227 */         inetAddress = InetAddress.getByName(paramString1);
/* 228 */       } catch (UnknownHostException unknownHostException) {
/* 229 */         inetAddress = null;
/*     */       } 
/* 231 */       PasswordAuthentication passwordAuthentication = this.session.requestPasswordAuthentication(
/* 232 */           inetAddress, paramInt, 
/* 233 */           str1, 
/* 234 */           null, paramString2);
/* 235 */       if (passwordAuthentication != null) {
/* 236 */         paramString2 = passwordAuthentication.getUserName();
/* 237 */         paramString3 = passwordAuthentication.getPassword();
/*     */ 
/*     */         
/* 240 */         bool = protocolConnect(paramString1, paramInt, paramString2, paramString3);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 245 */     if (!bool) {
/* 246 */       throw new AuthenticationFailedException();
/*     */     }
/* 248 */     setURLName(new URLName(str1, paramString1, paramInt, str2, paramString2, paramString3));
/*     */     
/* 250 */     if (bool1) {
/* 251 */       this.session.setPasswordAuthentication(getURLName(), 
/* 252 */           new PasswordAuthentication(paramString2, paramString3));
/*     */     }
/*     */     
/* 255 */     setConnected(true);
/*     */ 
/*     */     
/* 258 */     notifyConnectionListeners(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 291 */   protected boolean protocolConnect(String paramString1, int paramInt, String paramString2, String paramString3) throws MessagingException { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 307 */   public boolean isConnected() { return this.connected; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 324 */   protected void setConnected(boolean paramBoolean) { this.connected = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws MessagingException {
/* 346 */     setConnected(false);
/* 347 */     notifyConnectionListeners(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URLName getURLName() {
/* 365 */     if (this.url != null && (this.url.getPassword() != null || this.url.getFile() != null)) {
/* 366 */       return new URLName(this.url.getProtocol(), this.url.getHost(), 
/* 367 */           this.url.getPort(), null, 
/* 368 */           this.url.getUsername(), null);
/*     */     }
/* 370 */     return this.url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 391 */   protected void setURLName(URLName paramURLName) { this.url = paramURLName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addConnectionListener(ConnectionListener paramConnectionListener) {
/* 404 */     if (this.connectionListeners == null)
/* 405 */       this.connectionListeners = new Vector(); 
/* 406 */     this.connectionListeners.addElement(paramConnectionListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeConnectionListener(ConnectionListener paramConnectionListener) {
/* 419 */     if (this.connectionListeners != null) {
/* 420 */       this.connectionListeners.removeElement(paramConnectionListener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyConnectionListeners(int paramInt) {
/* 434 */     if (this.connectionListeners != null) {
/* 435 */       ConnectionEvent connectionEvent = new ConnectionEvent(this, paramInt);
/* 436 */       queueEvent(connectionEvent, this.connectionListeners);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 449 */     if (paramInt == 3) {
/* 450 */       terminateQueue();
/*     */     }
/*     */   }
/*     */   
/*     */   private void terminateQueue() throws MessagingException {
/* 455 */     if (this.q != null) {
/* 456 */       Vector vector = new Vector();
/* 457 */       vector.setSize(1);
/*     */       
/* 459 */       this.q.enqueue(
/* 460 */           new MailEvent(new Object())
/*     */           {
/*     */             public void dispatch(Object param1Object) {
/* 463 */               Thread.currentThread().interrupt();
/*     */             }
/*     */           }, 
/* 466 */           vector);
/*     */ 
/*     */       
/* 469 */       this.q = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 478 */     URLName uRLName = getURLName();
/* 479 */     if (uRLName != null) {
/* 480 */       return uRLName.toString();
/*     */     }
/* 482 */     return super.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void queueEvent(MailEvent paramMailEvent, Vector paramVector) {
/* 494 */     if (this.q == null) {
/* 495 */       this.q = new EventQueue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 505 */     Vector vector = (Vector)paramVector.clone();
/* 506 */     this.q.enqueue(paramMailEvent, vector);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finalize() throws MessagingException {
/* 513 */     super.finalize();
/* 514 */     terminateQueue();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\Service.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */