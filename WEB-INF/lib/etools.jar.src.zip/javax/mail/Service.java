package javax.mail;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Vector;
import javax.mail.event.ConnectionEvent;
import javax.mail.event.ConnectionListener;
import javax.mail.event.MailEvent;

public abstract class Service {
  protected Session session;
  
  protected URLName url;
  
  protected boolean debug;
  
  private boolean connected;
  
  private Vector connectionListeners;
  
  private EventQueue q;
  
  protected Service(Session paramSession, URLName paramURLName) {
    this.debug = false;
    this.connected = false;
    this.session = paramSession;
    this.url = paramURLName;
    this.debug = paramSession.getDebug();
  }
  
  public void connect() throws MessagingException { connect(null, null, null); }
  
  public void connect(String paramString1, String paramString2, String paramString3) throws MessagingException { connect(paramString1, -1, paramString2, paramString3); }
  
  public void connect(String paramString1, int paramInt, String paramString2, String paramString3) throws MessagingException {
    if (isConnected())
      throw new MessagingException("already connected"); 
    boolean bool = false;
    boolean bool1 = false;
    String str1 = null;
    String str2 = null;
    if (this.url != null) {
      str1 = this.url.getProtocol();
      if (paramString1 == null)
        paramString1 = this.url.getHost(); 
      if (paramInt == -1)
        paramInt = this.url.getPort(); 
      if (paramString2 == null) {
        paramString2 = this.url.getUsername();
        if (paramString3 == null)
          paramString3 = this.url.getPassword(); 
      } else if (paramString3 == null && paramString2.equals(this.url.getUsername())) {
        paramString3 = this.url.getPassword();
      } 
      str2 = this.url.getFile();
    } 
    if (str1 != null) {
      if (paramString1 == null)
        paramString1 = this.session.getProperty("mail." + str1 + ".host"); 
      if (paramString2 == null)
        paramString2 = this.session.getProperty("mail." + str1 + ".user"); 
    } 
    if (paramString1 == null)
      paramString1 = this.session.getProperty("mail.host"); 
    if (paramString2 == null)
      paramString2 = this.session.getProperty("mail.user"); 
    if (paramString2 == null)
      try {
        paramString2 = System.getProperty("user.name");
      } catch (SecurityException securityException) {
        if (this.debug)
          securityException.printStackTrace(); 
      }  
    if (paramString3 == null && this.url != null) {
      PasswordAuthentication passwordAuthentication = this.session.getPasswordAuthentication(getURLName());
      if (passwordAuthentication != null) {
        if (paramString2 == null) {
          paramString2 = passwordAuthentication.getUserName();
          paramString3 = passwordAuthentication.getPassword();
        } else if (paramString2.equals(passwordAuthentication.getUserName())) {
          paramString3 = passwordAuthentication.getPassword();
        } 
      } else {
        bool1 = true;
      } 
    } 
    bool = protocolConnect(paramString1, paramInt, paramString2, paramString3);
    if (!bool) {
      InetAddress inetAddress;
      try {
        inetAddress = InetAddress.getByName(paramString1);
      } catch (UnknownHostException unknownHostException) {
        inetAddress = null;
      } 
      PasswordAuthentication passwordAuthentication = this.session.requestPasswordAuthentication(
          inetAddress, paramInt, 
          str1, 
          null, paramString2);
      if (passwordAuthentication != null) {
        paramString2 = passwordAuthentication.getUserName();
        paramString3 = passwordAuthentication.getPassword();
        bool = protocolConnect(paramString1, paramInt, paramString2, paramString3);
      } 
    } 
    if (!bool)
      throw new AuthenticationFailedException(); 
    setURLName(new URLName(str1, paramString1, paramInt, str2, paramString2, paramString3));
    if (bool1)
      this.session.setPasswordAuthentication(getURLName(), 
          new PasswordAuthentication(paramString2, paramString3)); 
    setConnected(true);
    notifyConnectionListeners(1);
  }
  
  protected boolean protocolConnect(String paramString1, int paramInt, String paramString2, String paramString3) throws MessagingException { return false; }
  
  public boolean isConnected() { return this.connected; }
  
  protected void setConnected(boolean paramBoolean) { this.connected = paramBoolean; }
  
  public void close() throws MessagingException {
    setConnected(false);
    notifyConnectionListeners(3);
  }
  
  public URLName getURLName() {
    if (this.url != null && (this.url.getPassword() != null || this.url.getFile() != null))
      return new URLName(this.url.getProtocol(), this.url.getHost(), 
          this.url.getPort(), null, 
          this.url.getUsername(), null); 
    return this.url;
  }
  
  protected void setURLName(URLName paramURLName) { this.url = paramURLName; }
  
  public void addConnectionListener(ConnectionListener paramConnectionListener) {
    if (this.connectionListeners == null)
      this.connectionListeners = new Vector(); 
    this.connectionListeners.addElement(paramConnectionListener);
  }
  
  public void removeConnectionListener(ConnectionListener paramConnectionListener) {
    if (this.connectionListeners != null)
      this.connectionListeners.removeElement(paramConnectionListener); 
  }
  
  protected void notifyConnectionListeners(int paramInt) {
    if (this.connectionListeners != null) {
      ConnectionEvent connectionEvent = new ConnectionEvent(this, paramInt);
      queueEvent(connectionEvent, this.connectionListeners);
    } 
    if (paramInt == 3)
      terminateQueue(); 
  }
  
  private void terminateQueue() throws MessagingException {
    if (this.q != null) {
      Vector vector = new Vector();
      vector.setSize(1);
      this.q.enqueue(
          new MailEvent(new Object()) {
            public void dispatch(Object param1Object) { Thread.currentThread().interrupt(); }
          },  vector);
      this.q = null;
    } 
  }
  
  public String toString() {
    URLName uRLName = getURLName();
    if (uRLName != null)
      return uRLName.toString(); 
    return super.toString();
  }
  
  protected void queueEvent(MailEvent paramMailEvent, Vector paramVector) {
    if (this.q == null)
      this.q = new EventQueue(); 
    Vector vector = (Vector)paramVector.clone();
    this.q.enqueue(paramMailEvent, vector);
  }
  
  protected void finalize() throws MessagingException {
    super.finalize();
    terminateQueue();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\Service.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */