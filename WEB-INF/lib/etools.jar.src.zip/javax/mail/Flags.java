/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Flags
/*     */   implements Cloneable
/*     */ {
/*     */   private int system_flags;
/*     */   private Hashtable user_flags;
/*     */   private static final int ANSWERED_BIT = 1;
/*     */   private static final int DELETED_BIT = 2;
/*     */   private static final int DRAFT_BIT = 4;
/*     */   private static final int FLAGGED_BIT = 8;
/*     */   private static final int RECENT_BIT = 16;
/*     */   private static final int SEEN_BIT = 32;
/*     */   private static final int USER_BIT = -2147483648;
/*     */   
/*     */   public static final class Flag
/*     */   {
/*  79 */     public static final Flag ANSWERED = new Flag(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     public static final Flag DELETED = new Flag(2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     public static final Flag DRAFT = new Flag(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     public static final Flag FLAGGED = new Flag(8);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     public static final Flag RECENT = new Flag(16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     public static final Flag SEEN = new Flag(32);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     public static final Flag USER = new Flag(Integer.MIN_VALUE);
/*     */     
/*     */     private int bit;
/*     */ 
/*     */     
/* 134 */     private Flag(int param1Int) { this.bit = param1Int; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flags() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flags(Flags paramFlags) {
/* 150 */     this.system_flags = paramFlags.system_flags;
/* 151 */     if (paramFlags.user_flags != null) {
/* 152 */       this.user_flags = (Hashtable)paramFlags.user_flags.clone();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public Flags(Flag paramFlag) { this.system_flags |= paramFlag.bit; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flags(String paramString) {
/* 170 */     this.user_flags = new Hashtable(1);
/* 171 */     this.user_flags.put(paramString, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public void add(Flag paramFlag) { this.system_flags |= paramFlag.bit; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(String paramString) {
/* 189 */     if (this.user_flags == null)
/* 190 */       this.user_flags = new Hashtable(1); 
/* 191 */     this.user_flags.put(paramString.toLowerCase(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Flags paramFlags) {
/* 201 */     this.system_flags |= paramFlags.system_flags;
/*     */     
/* 203 */     if (paramFlags.user_flags != null) {
/* 204 */       if (this.user_flags == null) {
/* 205 */         this.user_flags = new Hashtable(1);
/*     */       }
/* 207 */       Enumeration enumeration = paramFlags.user_flags.keys();
/*     */       
/* 209 */       while (enumeration.hasMoreElements()) {
/* 210 */         String str = (String)enumeration.nextElement();
/* 211 */         this.user_flags.put(str, paramFlags.user_flags.get(str));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 222 */   public void remove(Flag paramFlag) { this.system_flags &= (paramFlag.bit ^ 0xFFFFFFFF); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(String paramString) {
/* 231 */     if (this.user_flags != null) {
/* 232 */       this.user_flags.remove(paramString.toLowerCase());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(Flags paramFlags) {
/* 242 */     this.system_flags &= (paramFlags.system_flags ^ 0xFFFFFFFF);
/*     */     
/* 244 */     if (paramFlags.user_flags != null) {
/* 245 */       if (this.user_flags == null) {
/*     */         return;
/*     */       }
/* 248 */       Enumeration enumeration = paramFlags.user_flags.keys();
/* 249 */       while (enumeration.hasMoreElements()) {
/* 250 */         this.user_flags.remove(enumeration.nextElement());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 260 */   public boolean contains(Flag paramFlag) { return !((this.system_flags & paramFlag.bit) == 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(String paramString) {
/* 269 */     if (this.user_flags == null) {
/* 270 */       return false;
/*     */     }
/* 272 */     return this.user_flags.containsKey(paramString.toLowerCase());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Flags paramFlags) {
/* 284 */     if ((paramFlags.system_flags & this.system_flags) != paramFlags.system_flags) {
/* 285 */       return false;
/*     */     }
/*     */     
/* 288 */     if (paramFlags.user_flags != null) {
/* 289 */       if (this.user_flags == null)
/* 290 */         return false; 
/* 291 */       Enumeration enumeration = paramFlags.user_flags.keys();
/*     */       
/* 293 */       while (enumeration.hasMoreElements()) {
/* 294 */         if (!this.user_flags.containsKey(enumeration.nextElement())) {
/* 295 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 300 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 309 */     if (!(paramObject instanceof Flags)) {
/* 310 */       return false;
/*     */     }
/* 312 */     Flags flags = (Flags)paramObject;
/*     */ 
/*     */     
/* 315 */     if (flags.system_flags != this.system_flags) {
/* 316 */       return false;
/*     */     }
/*     */     
/* 319 */     if (flags.user_flags == null && this.user_flags == null)
/* 320 */       return true; 
/* 321 */     if (flags.user_flags != null && this.user_flags != null && 
/* 322 */       flags.user_flags.size() == this.user_flags.size()) {
/* 323 */       Enumeration enumeration = flags.user_flags.keys();
/*     */       
/* 325 */       while (enumeration.hasMoreElements()) {
/* 326 */         if (!this.user_flags.containsKey(enumeration.nextElement()))
/* 327 */           return false; 
/*     */       } 
/* 329 */       return true;
/*     */     } 
/*     */     
/* 332 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 341 */     int i = this.system_flags;
/* 342 */     if (this.user_flags != null) {
/* 343 */       Enumeration enumeration = this.user_flags.keys();
/* 344 */       while (enumeration.hasMoreElements())
/* 345 */         i += ((String)enumeration.nextElement()).hashCode(); 
/*     */     } 
/* 347 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flag[] getSystemFlags() {
/* 357 */     Vector vector = new Vector();
/* 358 */     if ((this.system_flags & true) != 0)
/* 359 */       vector.addElement(Flag.ANSWERED); 
/* 360 */     if ((this.system_flags & 0x2) != 0)
/* 361 */       vector.addElement(Flag.DELETED); 
/* 362 */     if ((this.system_flags & 0x4) != 0)
/* 363 */       vector.addElement(Flag.DRAFT); 
/* 364 */     if ((this.system_flags & 0x8) != 0)
/* 365 */       vector.addElement(Flag.FLAGGED); 
/* 366 */     if ((this.system_flags & 0x10) != 0)
/* 367 */       vector.addElement(Flag.RECENT); 
/* 368 */     if ((this.system_flags & 0x20) != 0)
/* 369 */       vector.addElement(Flag.SEEN); 
/* 370 */     if ((this.system_flags & 0x80000000) != 0) {
/* 371 */       vector.addElement(Flag.USER);
/*     */     }
/* 373 */     Flag[] arrayOfFlag = new Flag[vector.size()];
/* 374 */     vector.copyInto(arrayOfFlag);
/* 375 */     return arrayOfFlag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getUserFlags() {
/* 385 */     Vector vector = new Vector();
/* 386 */     if (this.user_flags != null) {
/* 387 */       Enumeration enumeration = this.user_flags.elements();
/*     */       
/* 389 */       while (enumeration.hasMoreElements()) {
/* 390 */         vector.addElement(enumeration.nextElement());
/*     */       }
/*     */     } 
/* 393 */     String[] arrayOfString = new String[vector.size()];
/* 394 */     vector.copyInto(arrayOfString);
/* 395 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 402 */   public Object clone() { return new Flags(this); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\Flags.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */