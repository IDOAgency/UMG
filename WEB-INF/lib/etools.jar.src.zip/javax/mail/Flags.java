package javax.mail;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class Flags implements Cloneable {
  private int system_flags;
  
  private Hashtable user_flags;
  
  private static final int ANSWERED_BIT = 1;
  
  private static final int DELETED_BIT = 2;
  
  private static final int DRAFT_BIT = 4;
  
  private static final int FLAGGED_BIT = 8;
  
  private static final int RECENT_BIT = 16;
  
  private static final int SEEN_BIT = 32;
  
  private static final int USER_BIT = -2147483648;
  
  public static final class Flag {
    public static final Flag ANSWERED = new Flag(1);
    
    public static final Flag DELETED = new Flag(2);
    
    public static final Flag DRAFT = new Flag(4);
    
    public static final Flag FLAGGED = new Flag(8);
    
    public static final Flag RECENT = new Flag(16);
    
    public static final Flag SEEN = new Flag(32);
    
    public static final Flag USER = new Flag(Integer.MIN_VALUE);
    
    private int bit;
    
    private Flag(int param1Int) { this.bit = param1Int; }
  }
  
  public Flags() {}
  
  public Flags(Flags paramFlags) {
    this.system_flags = paramFlags.system_flags;
    if (paramFlags.user_flags != null)
      this.user_flags = (Hashtable)paramFlags.user_flags.clone(); 
  }
  
  public Flags(Flag paramFlag) { this.system_flags |= paramFlag.bit; }
  
  public Flags(String paramString) {
    this.user_flags = new Hashtable(1);
    this.user_flags.put(paramString, paramString);
  }
  
  public void add(Flag paramFlag) { this.system_flags |= paramFlag.bit; }
  
  public void add(String paramString) {
    if (this.user_flags == null)
      this.user_flags = new Hashtable(1); 
    this.user_flags.put(paramString.toLowerCase(), paramString);
  }
  
  public void add(Flags paramFlags) {
    this.system_flags |= paramFlags.system_flags;
    if (paramFlags.user_flags != null) {
      if (this.user_flags == null)
        this.user_flags = new Hashtable(1); 
      Enumeration enumeration = paramFlags.user_flags.keys();
      while (enumeration.hasMoreElements()) {
        String str = (String)enumeration.nextElement();
        this.user_flags.put(str, paramFlags.user_flags.get(str));
      } 
    } 
  }
  
  public void remove(Flag paramFlag) { this.system_flags &= (paramFlag.bit ^ 0xFFFFFFFF); }
  
  public void remove(String paramString) {
    if (this.user_flags != null)
      this.user_flags.remove(paramString.toLowerCase()); 
  }
  
  public void remove(Flags paramFlags) {
    this.system_flags &= (paramFlags.system_flags ^ 0xFFFFFFFF);
    if (paramFlags.user_flags != null) {
      if (this.user_flags == null)
        return; 
      Enumeration enumeration = paramFlags.user_flags.keys();
      while (enumeration.hasMoreElements())
        this.user_flags.remove(enumeration.nextElement()); 
    } 
  }
  
  public boolean contains(Flag paramFlag) { return !((this.system_flags & paramFlag.bit) == 0); }
  
  public boolean contains(String paramString) {
    if (this.user_flags == null)
      return false; 
    return this.user_flags.containsKey(paramString.toLowerCase());
  }
  
  public boolean contains(Flags paramFlags) {
    if ((paramFlags.system_flags & this.system_flags) != paramFlags.system_flags)
      return false; 
    if (paramFlags.user_flags != null) {
      if (this.user_flags == null)
        return false; 
      Enumeration enumeration = paramFlags.user_flags.keys();
      while (enumeration.hasMoreElements()) {
        if (!this.user_flags.containsKey(enumeration.nextElement()))
          return false; 
      } 
    } 
    return true;
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof Flags))
      return false; 
    Flags flags = (Flags)paramObject;
    if (flags.system_flags != this.system_flags)
      return false; 
    if (flags.user_flags == null && this.user_flags == null)
      return true; 
    if (flags.user_flags != null && this.user_flags != null && 
      flags.user_flags.size() == this.user_flags.size()) {
      Enumeration enumeration = flags.user_flags.keys();
      while (enumeration.hasMoreElements()) {
        if (!this.user_flags.containsKey(enumeration.nextElement()))
          return false; 
      } 
      return true;
    } 
    return false;
  }
  
  public int hashCode() {
    int i = this.system_flags;
    if (this.user_flags != null) {
      Enumeration enumeration = this.user_flags.keys();
      while (enumeration.hasMoreElements())
        i += ((String)enumeration.nextElement()).hashCode(); 
    } 
    return i;
  }
  
  public Flag[] getSystemFlags() {
    Vector vector = new Vector();
    if ((this.system_flags & true) != 0)
      vector.addElement(Flag.ANSWERED); 
    if ((this.system_flags & 0x2) != 0)
      vector.addElement(Flag.DELETED); 
    if ((this.system_flags & 0x4) != 0)
      vector.addElement(Flag.DRAFT); 
    if ((this.system_flags & 0x8) != 0)
      vector.addElement(Flag.FLAGGED); 
    if ((this.system_flags & 0x10) != 0)
      vector.addElement(Flag.RECENT); 
    if ((this.system_flags & 0x20) != 0)
      vector.addElement(Flag.SEEN); 
    if ((this.system_flags & 0x80000000) != 0)
      vector.addElement(Flag.USER); 
    Flag[] arrayOfFlag = new Flag[vector.size()];
    vector.copyInto(arrayOfFlag);
    return arrayOfFlag;
  }
  
  public String[] getUserFlags() {
    Vector vector = new Vector();
    if (this.user_flags != null) {
      Enumeration enumeration = this.user_flags.elements();
      while (enumeration.hasMoreElements())
        vector.addElement(enumeration.nextElement()); 
    } 
    String[] arrayOfString = new String[vector.size()];
    vector.copyInto(arrayOfString);
    return arrayOfString;
  }
  
  public Object clone() { return new Flags(this); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\Flags.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */