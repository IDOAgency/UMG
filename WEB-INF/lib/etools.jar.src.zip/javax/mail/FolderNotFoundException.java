/*    */ package javax.mail;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FolderNotFoundException
/*    */   extends MessagingException
/*    */ {
/*    */   private Folder folder;
/*    */   
/*    */   public FolderNotFoundException() {}
/*    */   
/*    */   public FolderNotFoundException(String paramString, Folder paramFolder) {
/* 35 */     super(paramString);
/* 36 */     this.folder = paramFolder;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public Folder getFolder() { return this.folder; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\FolderNotFoundException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */