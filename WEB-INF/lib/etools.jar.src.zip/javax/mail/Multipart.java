/*     */ package javax.mail;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Multipart
/*     */ {
/*  40 */   protected Vector parts = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   protected String contentType = "multipart/mixed";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Part parent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setMultipartDataSource(MultipartDataSource paramMultipartDataSource) throws MessagingException {
/*  77 */     this.contentType = paramMultipartDataSource.getContentType();
/*     */     
/*  79 */     int i = paramMultipartDataSource.getCount();
/*  80 */     for (byte b = 0; b < i; b++) {
/*  81 */       addBodyPart(paramMultipartDataSource.getBodyPart(b));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public String getContentType() { return this.contentType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCount() throws MessagingException {
/* 104 */     if (this.parts == null) {
/* 105 */       return 0;
/*     */     }
/* 107 */     return this.parts.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BodyPart getBodyPart(int paramInt) throws MessagingException {
/* 120 */     if (this.parts == null) {
/* 121 */       throw new IndexOutOfBoundsException("No such BodyPart");
/*     */     }
/* 123 */     return (BodyPart)this.parts.elementAt(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeBodyPart(BodyPart paramBodyPart) throws MessagingException {
/* 138 */     if (this.parts == null) {
/* 139 */       throw new MessagingException("No such body part");
/*     */     }
/* 141 */     boolean bool = this.parts.removeElement(paramBodyPart);
/* 142 */     paramBodyPart.setParent(null);
/* 143 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeBodyPart(int paramInt) throws MessagingException {
/* 159 */     if (this.parts == null) {
/* 160 */       throw new IndexOutOfBoundsException("No such BodyPart");
/*     */     }
/* 162 */     BodyPart bodyPart = (BodyPart)this.parts.elementAt(paramInt);
/* 163 */     this.parts.removeElementAt(paramInt);
/* 164 */     bodyPart.setParent(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBodyPart(BodyPart paramBodyPart) throws MessagingException {
/* 179 */     if (this.parts == null) {
/* 180 */       this.parts = new Vector();
/*     */     }
/* 182 */     this.parts.addElement(paramBodyPart);
/* 183 */     paramBodyPart.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBodyPart(BodyPart paramBodyPart, int paramInt) throws MessagingException {
/* 202 */     if (this.parts == null) {
/* 203 */       this.parts = new Vector();
/*     */     }
/* 205 */     this.parts.insertElementAt(paramBodyPart, paramInt);
/* 206 */     paramBodyPart.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void writeTo(OutputStream paramOutputStream) throws IOException, MessagingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 227 */   public Part getParent() { return this.parent; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 240 */   public void setParent(Part paramPart) { this.parent = paramPart; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\Multipart.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */