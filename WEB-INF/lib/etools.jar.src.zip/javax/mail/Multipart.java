package javax.mail;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Vector;

public abstract class Multipart {
  protected Vector parts = new Vector();
  
  protected String contentType = "multipart/mixed";
  
  protected Part parent;
  
  protected void setMultipartDataSource(MultipartDataSource paramMultipartDataSource) throws MessagingException {
    this.contentType = paramMultipartDataSource.getContentType();
    int i = paramMultipartDataSource.getCount();
    for (byte b = 0; b < i; b++)
      addBodyPart(paramMultipartDataSource.getBodyPart(b)); 
  }
  
  public String getContentType() { return this.contentType; }
  
  public int getCount() throws MessagingException {
    if (this.parts == null)
      return 0; 
    return this.parts.size();
  }
  
  public BodyPart getBodyPart(int paramInt) throws MessagingException {
    if (this.parts == null)
      throw new IndexOutOfBoundsException("No such BodyPart"); 
    return (BodyPart)this.parts.elementAt(paramInt);
  }
  
  public boolean removeBodyPart(BodyPart paramBodyPart) throws MessagingException {
    if (this.parts == null)
      throw new MessagingException("No such body part"); 
    boolean bool = this.parts.removeElement(paramBodyPart);
    paramBodyPart.setParent(null);
    return bool;
  }
  
  public void removeBodyPart(int paramInt) throws MessagingException {
    if (this.parts == null)
      throw new IndexOutOfBoundsException("No such BodyPart"); 
    BodyPart bodyPart = (BodyPart)this.parts.elementAt(paramInt);
    this.parts.removeElementAt(paramInt);
    bodyPart.setParent(null);
  }
  
  public void addBodyPart(BodyPart paramBodyPart) throws MessagingException {
    if (this.parts == null)
      this.parts = new Vector(); 
    this.parts.addElement(paramBodyPart);
    paramBodyPart.setParent(this);
  }
  
  public void addBodyPart(BodyPart paramBodyPart, int paramInt) throws MessagingException {
    if (this.parts == null)
      this.parts = new Vector(); 
    this.parts.insertElementAt(paramBodyPart, paramInt);
    paramBodyPart.setParent(this);
  }
  
  public abstract void writeTo(OutputStream paramOutputStream) throws IOException, MessagingException;
  
  public Part getParent() { return this.parent; }
  
  public void setParent(Part paramPart) { this.parent = paramPart; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\Multipart.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */