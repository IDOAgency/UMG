package javax.mail.event;

import java.util.EventListener;

public interface FolderListener extends EventListener {
  void folderCreated(FolderEvent paramFolderEvent);
  
  void folderDeleted(FolderEvent paramFolderEvent);
  
  void folderRenamed(FolderEvent paramFolderEvent);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\FolderListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */