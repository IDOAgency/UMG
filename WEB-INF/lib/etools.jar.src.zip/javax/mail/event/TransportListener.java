package javax.mail.event;

import java.util.EventListener;

public interface TransportListener extends EventListener {
  void messageDelivered(TransportEvent paramTransportEvent);
  
  void messageNotDelivered(TransportEvent paramTransportEvent);
  
  void messagePartiallyDelivered(TransportEvent paramTransportEvent);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\TransportListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */