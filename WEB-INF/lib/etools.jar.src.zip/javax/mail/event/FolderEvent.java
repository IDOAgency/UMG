package javax.mail.event;

import javax.mail.Folder;

public class FolderEvent extends MailEvent {
  public static final int CREATED = 1;
  
  public static final int DELETED = 2;
  
  public static final int RENAMED = 3;
  
  protected int type;
  
  protected Folder folder;
  
  protected Folder newFolder;
  
  public FolderEvent(Object paramObject, Folder paramFolder, int paramInt) { this(paramObject, paramFolder, paramFolder, paramInt); }
  
  public FolderEvent(Object paramObject, Folder paramFolder1, Folder paramFolder2, int paramInt) {
    super(paramObject);
    this.folder = paramFolder1;
    this.newFolder = paramFolder2;
    this.type = paramInt;
  }
  
  public int getType() { return this.type; }
  
  public Folder getFolder() { return this.folder; }
  
  public Folder getNewFolder() { return this.newFolder; }
  
  public void dispatch(Object paramObject) {
    if (this.type == 1) {
      ((FolderListener)paramObject).folderCreated(this);
      return;
    } 
    if (this.type == 2) {
      ((FolderListener)paramObject).folderDeleted(this);
      return;
    } 
    if (this.type == 3)
      ((FolderListener)paramObject).folderRenamed(this); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\FolderEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */