/*     */ package javax.mail.event;
/*     */ 
/*     */ import javax.mail.Folder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FolderEvent
/*     */   extends MailEvent
/*     */ {
/*     */   public static final int CREATED = 1;
/*     */   public static final int DELETED = 2;
/*     */   public static final int RENAMED = 3;
/*     */   protected int type;
/*     */   protected Folder folder;
/*     */   protected Folder newFolder;
/*     */   
/*  57 */   public FolderEvent(Object paramObject, Folder paramFolder, int paramInt) { this(paramObject, paramFolder, paramFolder, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FolderEvent(Object paramObject, Folder paramFolder1, Folder paramFolder2, int paramInt) {
/*  71 */     super(paramObject);
/*  72 */     this.folder = paramFolder1;
/*  73 */     this.newFolder = paramFolder2;
/*  74 */     this.type = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public int getType() { return this.type; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public Folder getFolder() { return this.folder; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public Folder getNewFolder() { return this.newFolder; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispatch(Object paramObject) {
/* 115 */     if (this.type == 1) {
/* 116 */       ((FolderListener)paramObject).folderCreated(this); return;
/* 117 */     }  if (this.type == 2) {
/* 118 */       ((FolderListener)paramObject).folderDeleted(this); return;
/* 119 */     }  if (this.type == 3)
/* 120 */       ((FolderListener)paramObject).folderRenamed(this); 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\event\FolderEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */