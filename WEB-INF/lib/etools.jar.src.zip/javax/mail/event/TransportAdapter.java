package javax.mail.event;

public abstract class TransportAdapter implements TransportListener {
  public void messageDelivered(TransportEvent paramTransportEvent) {}
  
  public void messageNotDelivered(TransportEvent paramTransportEvent) {}
  
  public void messagePartiallyDelivered(TransportEvent paramTransportEvent) {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\TransportAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */