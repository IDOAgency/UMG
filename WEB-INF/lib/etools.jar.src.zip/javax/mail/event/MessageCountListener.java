package javax.mail.event;

import java.util.EventListener;

public interface MessageCountListener extends EventListener {
  void messagesAdded(MessageCountEvent paramMessageCountEvent);
  
  void messagesRemoved(MessageCountEvent paramMessageCountEvent);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\event\MessageCountListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */