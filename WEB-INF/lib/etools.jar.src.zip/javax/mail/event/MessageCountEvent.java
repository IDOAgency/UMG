package javax.mail.event;

import javax.mail.Folder;
import javax.mail.Message;

public class MessageCountEvent extends MailEvent {
  public static final int ADDED = 1;
  
  public static final int REMOVED = 2;
  
  protected int type;
  
  protected boolean removed;
  
  protected Message[] msgs;
  
  public MessageCountEvent(Folder paramFolder, int paramInt, boolean paramBoolean, Message[] paramArrayOfMessage) {
    super(paramFolder);
    this.type = paramInt;
    this.removed = paramBoolean;
    this.msgs = paramArrayOfMessage;
  }
  
  public int getType() { return this.type; }
  
  public boolean isRemoved() { return this.removed; }
  
  public Message[] getMessages() { return this.msgs; }
  
  public void dispatch(Object paramObject) {
    if (this.type == 1) {
      ((MessageCountListener)paramObject).messagesAdded(this);
      return;
    } 
    ((MessageCountListener)paramObject).messagesRemoved(this);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\MessageCountEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */