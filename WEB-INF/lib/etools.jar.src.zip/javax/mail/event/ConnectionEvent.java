package javax.mail.event;

public class ConnectionEvent extends MailEvent {
  public static final int OPENED = 1;
  
  public static final int DISCONNECTED = 2;
  
  public static final int CLOSED = 3;
  
  protected int type;
  
  public ConnectionEvent(Object paramObject, int paramInt) {
    super(paramObject);
    this.type = paramInt;
  }
  
  public int getType() { return this.type; }
  
  public void dispatch(Object paramObject) {
    if (this.type == 1) {
      ((ConnectionListener)paramObject).opened(this);
      return;
    } 
    if (this.type == 2) {
      ((ConnectionListener)paramObject).disconnected(this);
      return;
    } 
    if (this.type == 3)
      ((ConnectionListener)paramObject).closed(this); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\event\ConnectionEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */