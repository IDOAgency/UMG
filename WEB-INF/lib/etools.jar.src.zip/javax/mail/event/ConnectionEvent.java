/*    */ package javax.mail.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectionEvent
/*    */   extends MailEvent
/*    */ {
/*    */   public static final int OPENED = 1;
/*    */   public static final int DISCONNECTED = 2;
/*    */   public static final int CLOSED = 3;
/*    */   protected int type;
/*    */   
/*    */   public ConnectionEvent(Object paramObject, int paramInt) {
/* 40 */     super(paramObject);
/* 41 */     this.type = paramInt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 49 */   public int getType() { return this.type; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void dispatch(Object paramObject) {
/* 56 */     if (this.type == 1) {
/* 57 */       ((ConnectionListener)paramObject).opened(this); return;
/* 58 */     }  if (this.type == 2) {
/* 59 */       ((ConnectionListener)paramObject).disconnected(this); return;
/* 60 */     }  if (this.type == 3)
/* 61 */       ((ConnectionListener)paramObject).closed(this); 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\ConnectionEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */