package javax.mail.event;

public abstract class FolderAdapter implements FolderListener {
  public void folderCreated(FolderEvent paramFolderEvent) {}
  
  public void folderRenamed(FolderEvent paramFolderEvent) {}
  
  public void folderDeleted(FolderEvent paramFolderEvent) {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\FolderAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */