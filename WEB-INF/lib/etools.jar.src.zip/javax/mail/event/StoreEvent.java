/*    */ package javax.mail.event;
/*    */ 
/*    */ import javax.mail.Store;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StoreEvent
/*    */   extends MailEvent
/*    */ {
/*    */   public static final int ALERT = 1;
/*    */   public static final int NOTICE = 2;
/*    */   protected int type;
/*    */   protected String message;
/*    */   
/*    */   public StoreEvent(Store paramStore, int paramInt, String paramString) {
/* 53 */     super(paramStore);
/* 54 */     this.type = paramInt;
/* 55 */     this.message = paramString;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 66 */   public int getMessageType() { return this.type; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 75 */   public String getMessage() { return this.message; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 82 */   public void dispatch(Object paramObject) { ((StoreListener)paramObject).notification(this); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\StoreEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */