package javax.mail.event;

public abstract class MessageCountAdapter implements MessageCountListener {
  public void messagesAdded(MessageCountEvent paramMessageCountEvent) {}
  
  public void messagesRemoved(MessageCountEvent paramMessageCountEvent) {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\MessageCountAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */