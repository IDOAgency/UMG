package javax.mail.event;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.Transport;

public class TransportEvent extends MailEvent {
  public static final int MESSAGE_DELIVERED = 1;
  
  public static final int MESSAGE_NOT_DELIVERED = 2;
  
  public static final int MESSAGE_PARTIALLY_DELIVERED = 3;
  
  protected int type;
  
  protected Address[] validSent;
  
  protected Address[] validUnsent;
  
  protected Address[] invalid;
  
  protected Message msg;
  
  public TransportEvent(Transport paramTransport, int paramInt, Address[] paramArrayOfAddress1, Address[] paramArrayOfAddress2, Address[] paramArrayOfAddress3, Message paramMessage) {
    super(paramTransport);
    this.type = paramInt;
    this.validSent = paramArrayOfAddress1;
    this.validUnsent = paramArrayOfAddress2;
    this.invalid = paramArrayOfAddress3;
    this.msg = paramMessage;
  }
  
  public int getType() { return this.type; }
  
  public Address[] getValidSentAddresses() { return this.validSent; }
  
  public Address[] getValidUnsentAddresses() { return this.validUnsent; }
  
  public Address[] getInvalidAddresses() { return this.invalid; }
  
  public void dispatch(Object paramObject) {
    if (this.type == 1) {
      ((TransportListener)paramObject).messageDelivered(this);
      return;
    } 
    if (this.type == 2) {
      ((TransportListener)paramObject).messageNotDelivered(this);
      return;
    } 
    ((TransportListener)paramObject).messagePartiallyDelivered(this);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\event\TransportEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */