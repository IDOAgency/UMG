/*     */ package javax.mail.event;
/*     */ 
/*     */ import javax.mail.Address;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.Transport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransportEvent
/*     */   extends MailEvent
/*     */ {
/*     */   public static final int MESSAGE_DELIVERED = 1;
/*     */   public static final int MESSAGE_NOT_DELIVERED = 2;
/*     */   public static final int MESSAGE_PARTIALLY_DELIVERED = 3;
/*     */   protected int type;
/*     */   protected Address[] validSent;
/*     */   protected Address[] validUnsent;
/*     */   protected Address[] invalid;
/*     */   protected Message msg;
/*     */   
/*     */   public TransportEvent(Transport paramTransport, int paramInt, Address[] paramArrayOfAddress1, Address[] paramArrayOfAddress2, Address[] paramArrayOfAddress3, Message paramMessage) {
/*  68 */     super(paramTransport);
/*  69 */     this.type = paramInt;
/*  70 */     this.validSent = paramArrayOfAddress1;
/*  71 */     this.validUnsent = paramArrayOfAddress2;
/*  72 */     this.invalid = paramArrayOfAddress3;
/*  73 */     this.msg = paramMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public int getType() { return this.type; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public Address[] getValidSentAddresses() { return this.validSent; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public Address[] getValidUnsentAddresses() { return this.validUnsent; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public Address[] getInvalidAddresses() { return this.invalid; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispatch(Object paramObject) {
/* 114 */     if (this.type == 1) {
/* 115 */       ((TransportListener)paramObject).messageDelivered(this); return;
/* 116 */     }  if (this.type == 2) {
/* 117 */       ((TransportListener)paramObject).messageNotDelivered(this); return;
/*     */     } 
/* 119 */     ((TransportListener)paramObject).messagePartiallyDelivered(this);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\TransportEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */