package javax.mail.event;

public abstract class ConnectionAdapter implements ConnectionListener {
  public void opened(ConnectionEvent paramConnectionEvent) {}
  
  public void disconnected(ConnectionEvent paramConnectionEvent) {}
  
  public void closed(ConnectionEvent paramConnectionEvent) {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\ConnectionAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */