package javax.mail.event;

import java.util.EventListener;

public interface StoreListener extends EventListener {
  void notification(StoreEvent paramStoreEvent);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\StoreListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */