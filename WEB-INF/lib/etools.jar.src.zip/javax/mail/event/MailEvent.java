/*    */ package javax.mail.event;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MailEvent
/*    */   extends EventObject
/*    */ {
/* 20 */   public MailEvent(Object paramObject) { super(paramObject); }
/*    */   
/*    */   public abstract void dispatch(Object paramObject);
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\MailEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */