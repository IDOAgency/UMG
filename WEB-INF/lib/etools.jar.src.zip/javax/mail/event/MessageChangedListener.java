package javax.mail.event;

import java.util.EventListener;

public interface MessageChangedListener extends EventListener {
  void messageChanged(MessageChangedEvent paramMessageChangedEvent);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\event\MessageChangedListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */