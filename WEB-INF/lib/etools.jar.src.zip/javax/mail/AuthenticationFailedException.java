/*    */ package javax.mail;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationFailedException
/*    */   extends MessagingException
/*    */ {
/*    */   public AuthenticationFailedException() {}
/*    */   
/* 32 */   public AuthenticationFailedException(String paramString) { super(paramString); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\AuthenticationFailedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */