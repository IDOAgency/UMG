/*      */ package javax.mail;
/*      */ 
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ import javax.mail.event.ConnectionEvent;
/*      */ import javax.mail.event.ConnectionListener;
/*      */ import javax.mail.event.FolderEvent;
/*      */ import javax.mail.event.FolderListener;
/*      */ import javax.mail.event.MailEvent;
/*      */ import javax.mail.event.MessageChangedEvent;
/*      */ import javax.mail.event.MessageChangedListener;
/*      */ import javax.mail.event.MessageCountEvent;
/*      */ import javax.mail.event.MessageCountListener;
/*      */ import javax.mail.search.SearchTerm;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Folder
/*      */ {
/*      */   protected Store store;
/*      */   protected int mode;
/*      */   public static final int HOLDS_MESSAGES = 1;
/*      */   public static final int HOLDS_FOLDERS = 2;
/*      */   public static final int READ_ONLY = 1;
/*      */   public static final int READ_WRITE = 2;
/*      */   private Vector connectionListeners;
/*      */   private Vector folderListeners;
/*      */   private Vector messageCountListeners;
/*      */   private Vector messageChangedListeners;
/*      */   private EventQueue q;
/*      */   
/*      */   protected Folder(Store paramStore) {
/*   85 */     this.mode = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   93 */     this.store = paramStore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract String getName();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract String getFullName();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URLName getURLName() throws MessagingException {
/*  126 */     URLName uRLName = getStore().getURLName();
/*  127 */     String str = getFullName();
/*  128 */     StringBuffer stringBuffer = new StringBuffer();
/*  129 */     char c = getSeparator();
/*      */     
/*  131 */     if (str != null) {
/*      */ 
/*      */       
/*  134 */       StringTokenizer stringTokenizer = new StringTokenizer(
/*  135 */           str, (new Character(c)).toString(), true);
/*      */       
/*  137 */       while (stringTokenizer.hasMoreTokens()) {
/*  138 */         String str1 = stringTokenizer.nextToken();
/*  139 */         if (str1.charAt(0) == c) {
/*  140 */           stringBuffer.append("/");
/*      */           
/*      */           continue;
/*      */         } 
/*  144 */         stringBuffer.append(str1);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  152 */     return new URLName(uRLName.getProtocol(), uRLName.getHost(), 
/*  153 */         uRLName.getPort(), stringBuffer.toString(), 
/*  154 */         uRLName.getUsername(), 
/*  155 */         null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  164 */   public Store getStore() { return this.store; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract Folder getParent() throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean exists() throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract Folder[] list(String paramString) throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  252 */   public Folder[] listSubscribed(String paramString) throws MessagingException { return list(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  270 */   public Folder[] list() throws MessagingException { return list("%"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  288 */   public Folder[] listSubscribed() throws MessagingException { return listSubscribed("%"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract char getSeparator() throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getType() throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean create(int paramInt) throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  353 */   public boolean isSubscribed() throws MessagingException { return true; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  374 */   public void setSubscribed(boolean paramBoolean) throws MessagingException { throw new MethodNotSupportedException(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean hasNewMessages() throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract Folder getFolder(String paramString) throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean delete(boolean paramBoolean) throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean renameTo(Folder paramFolder) throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void open(int paramInt) throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void close(boolean paramBoolean) throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean isOpen() throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMode() throws MessagingException {
/*  581 */     if (!isOpen())
/*  582 */       throw new IllegalStateException("Folder not open"); 
/*  583 */     return this.mode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract Flags getPermanentFlags();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getMessageCount() throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNewMessageCount() throws MessagingException {
/*  649 */     if (!isOpen()) {
/*  650 */       return -1;
/*      */     }
/*  652 */     byte b1 = 0;
/*  653 */     int i = getMessageCount();
/*  654 */     for (byte b2 = 1; b2 <= i; b2++) {
/*      */       try {
/*  656 */         if (getMessage(b2).isSet(Flags.Flag.RECENT))
/*  657 */           b1++; 
/*  658 */       } catch (MessageRemovedException messageRemovedException) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  663 */     return b1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUnreadMessageCount() throws MessagingException {
/*  695 */     if (!isOpen()) {
/*  696 */       return -1;
/*      */     }
/*  698 */     byte b1 = 0;
/*  699 */     int i = getMessageCount();
/*  700 */     for (byte b2 = 1; b2 <= i; b2++) {
/*      */       try {
/*  702 */         if (!getMessage(b2).isSet(Flags.Flag.SEEN))
/*  703 */           b1++; 
/*  704 */       } catch (MessageRemovedException messageRemovedException) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  709 */     return b1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract Message getMessage(int paramInt) throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Message[] getMessages(int paramInt1, int paramInt2) throws MessagingException {
/*  773 */     Message[] arrayOfMessage = new Message[paramInt2 - paramInt1 + 1];
/*  774 */     for (int i = paramInt1; i <= paramInt2; i++)
/*  775 */       arrayOfMessage[i - paramInt1] = getMessage(i); 
/*  776 */     return arrayOfMessage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Message[] getMessages(int[] paramArrayOfInt) throws MessagingException {
/*  803 */     int i = paramArrayOfInt.length;
/*  804 */     Message[] arrayOfMessage = new Message[i];
/*  805 */     for (byte b = 0; b < i; b++)
/*  806 */       arrayOfMessage[b] = getMessage(paramArrayOfInt[b]); 
/*  807 */     return arrayOfMessage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Message[] getMessages() throws MessagingException {
/*  833 */     int i = getMessageCount();
/*  834 */     Message[] arrayOfMessage = new Message[i];
/*  835 */     for (byte b = 1; b <= i; b++)
/*  836 */       arrayOfMessage[b - true] = getMessage(b); 
/*  837 */     return arrayOfMessage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void appendMessages(Message[] paramArrayOfMessage) throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fetch(Message[] paramArrayOfMessage, FetchProfile paramFetchProfile) throws MessagingException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFlags(Message[] paramArrayOfMessage, Flags paramFlags, boolean paramBoolean) throws MessagingException {
/*  931 */     for (byte b = 0; b < paramArrayOfMessage.length; b++) {
/*      */       try {
/*  933 */         paramArrayOfMessage[b].setFlags(paramFlags, paramBoolean);
/*  934 */       } catch (MessageRemovedException messageRemovedException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFlags(int paramInt1, int paramInt2, Flags paramFlags, boolean paramBoolean) throws MessagingException {
/*  974 */     for (int i = paramInt1; i <= paramInt2; i++) {
/*      */       try {
/*  976 */         Message message = getMessage(i);
/*  977 */         message.setFlags(paramFlags, paramBoolean);
/*  978 */       } catch (MessageRemovedException messageRemovedException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFlags(int[] paramArrayOfInt, Flags paramFlags, boolean paramBoolean) throws MessagingException {
/* 1016 */     for (byte b = 0; b < paramArrayOfInt.length; b++) {
/*      */       try {
/* 1018 */         Message message = getMessage(paramArrayOfInt[b]);
/* 1019 */         message.setFlags(paramFlags, paramBoolean);
/* 1020 */       } catch (MessageRemovedException messageRemovedException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyMessages(Message[] paramArrayOfMessage, Folder paramFolder) throws MessagingException {
/* 1054 */     if (!paramFolder.exists()) {
/* 1055 */       throw new FolderNotFoundException(
/* 1056 */           String.valueOf(paramFolder.getFullName()) + " does not exist", 
/* 1057 */           paramFolder);
/*      */     }
/* 1059 */     paramFolder.appendMessages(paramArrayOfMessage);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract Message[] expunge() throws MessagingException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1116 */   public Message[] search(SearchTerm paramSearchTerm) throws MessagingException { return search(paramSearchTerm, getMessages()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Message[] search(SearchTerm paramSearchTerm, Message[] paramArrayOfMessage) throws MessagingException {
/* 1150 */     Vector vector = new Vector();
/*      */ 
/*      */     
/* 1153 */     for (byte b = 0; b < paramArrayOfMessage.length; b++) {
/*      */       try {
/* 1155 */         if (paramArrayOfMessage[b].match(paramSearchTerm))
/* 1156 */           vector.addElement(paramArrayOfMessage[b]); 
/* 1157 */       } catch (MessageRemovedException messageRemovedException) {}
/*      */     } 
/*      */     
/* 1160 */     Message[] arrayOfMessage = new Message[vector.size()];
/* 1161 */     vector.copyInto(arrayOfMessage);
/* 1162 */     return arrayOfMessage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addConnectionListener(ConnectionListener paramConnectionListener) {
/* 1179 */     if (this.connectionListeners == null)
/* 1180 */       this.connectionListeners = new Vector(); 
/* 1181 */     this.connectionListeners.addElement(paramConnectionListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeConnectionListener(ConnectionListener paramConnectionListener) {
/* 1195 */     if (this.connectionListeners != null) {
/* 1196 */       this.connectionListeners.removeElement(paramConnectionListener);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyConnectionListeners(int paramInt) throws MessagingException {
/* 1210 */     if (this.connectionListeners != null) {
/* 1211 */       ConnectionEvent connectionEvent = new ConnectionEvent(this, paramInt);
/* 1212 */       queueEvent(connectionEvent, this.connectionListeners);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1225 */     if (paramInt == 3) {
/* 1226 */       terminateQueue();
/*      */     }
/*      */   }
/*      */   
/*      */   private void terminateQueue() {
/* 1231 */     if (this.q != null) {
/* 1232 */       Vector vector = new Vector();
/* 1233 */       vector.setSize(1);
/*      */       
/* 1235 */       this.q.enqueue(
/* 1236 */           new MailEvent(new Object())
/*      */           {
/*      */             public void dispatch(Object param1Object) {
/* 1239 */               Thread.currentThread().interrupt();
/*      */             }
/*      */           }, 
/* 1242 */           vector);
/*      */ 
/*      */       
/* 1245 */       this.q = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addFolderListener(FolderListener paramFolderListener) {
/* 1262 */     if (this.folderListeners == null)
/* 1263 */       this.folderListeners = new Vector(); 
/* 1264 */     this.folderListeners.addElement(paramFolderListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeFolderListener(FolderListener paramFolderListener) {
/* 1277 */     if (this.folderListeners != null) {
/* 1278 */       this.folderListeners.removeElement(paramFolderListener);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyFolderListeners(int paramInt) throws MessagingException {
/* 1297 */     if (this.folderListeners != null) {
/* 1298 */       FolderEvent folderEvent = new FolderEvent(this, this, paramInt);
/* 1299 */       queueEvent(folderEvent, this.folderListeners);
/*      */     } 
/* 1301 */     this.store.notifyFolderListeners(paramInt, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyFolderRenamedListeners(Folder paramFolder) {
/* 1322 */     if (this.folderListeners != null) {
/* 1323 */       FolderEvent folderEvent = new FolderEvent(this, this, paramFolder, 
/* 1324 */           3);
/* 1325 */       queueEvent(folderEvent, this.folderListeners);
/*      */     } 
/* 1327 */     this.store.notifyFolderRenamedListeners(this, paramFolder);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMessageCountListener(MessageCountListener paramMessageCountListener) {
/* 1343 */     if (this.messageCountListeners == null)
/* 1344 */       this.messageCountListeners = new Vector(); 
/* 1345 */     this.messageCountListeners.addElement(paramMessageCountListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeMessageCountListener(MessageCountListener paramMessageCountListener) {
/* 1359 */     if (this.messageCountListeners != null) {
/* 1360 */       this.messageCountListeners.removeElement(paramMessageCountListener);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyMessageAddedListeners(Message[] paramArrayOfMessage) throws MessagingException {
/* 1376 */     if (this.messageCountListeners == null) {
/*      */       return;
/*      */     }
/* 1379 */     MessageCountEvent messageCountEvent = new MessageCountEvent(
/* 1380 */         this, 
/* 1381 */         1, 
/* 1382 */         false, 
/* 1383 */         paramArrayOfMessage);
/*      */     
/* 1385 */     queueEvent(messageCountEvent, this.messageCountListeners);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyMessageRemovedListeners(boolean paramBoolean, Message[] paramArrayOfMessage) {
/* 1402 */     if (this.messageCountListeners == null) {
/*      */       return;
/*      */     }
/* 1405 */     MessageCountEvent messageCountEvent = new MessageCountEvent(
/* 1406 */         this, 
/* 1407 */         2, 
/* 1408 */         paramBoolean, 
/* 1409 */         paramArrayOfMessage);
/* 1410 */     queueEvent(messageCountEvent, this.messageCountListeners);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMessageChangedListener(MessageChangedListener paramMessageChangedListener) {
/* 1427 */     if (this.messageChangedListeners == null)
/* 1428 */       this.messageChangedListeners = new Vector(); 
/* 1429 */     this.messageChangedListeners.addElement(paramMessageChangedListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeMessageChangedListener(MessageChangedListener paramMessageChangedListener) {
/* 1443 */     if (this.messageChangedListeners != null) {
/* 1444 */       this.messageChangedListeners.removeElement(paramMessageChangedListener);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyMessageChangedListeners(int paramInt, Message paramMessage) {
/* 1458 */     if (this.messageChangedListeners == null) {
/*      */       return;
/*      */     }
/* 1461 */     MessageChangedEvent messageChangedEvent = new MessageChangedEvent(this, paramInt, paramMessage);
/* 1462 */     queueEvent(messageChangedEvent, this.messageChangedListeners);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void queueEvent(MailEvent paramMailEvent, Vector paramVector) {
/* 1474 */     if (this.q == null) {
/* 1475 */       this.q = new EventQueue();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1485 */     Vector vector = (Vector)paramVector.clone();
/* 1486 */     this.q.enqueue(paramMailEvent, vector);
/*      */   }
/*      */   
/*      */   protected void finalize() {
/* 1490 */     super.finalize();
/* 1491 */     terminateQueue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1501 */     String str = getFullName();
/* 1502 */     if (str != null) {
/* 1503 */       return str;
/*      */     }
/* 1505 */     return super.toString();
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\Folder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */