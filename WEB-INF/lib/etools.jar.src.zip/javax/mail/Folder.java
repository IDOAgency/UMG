package javax.mail;

import java.util.StringTokenizer;
import java.util.Vector;
import javax.mail.event.ConnectionEvent;
import javax.mail.event.ConnectionListener;
import javax.mail.event.FolderEvent;
import javax.mail.event.FolderListener;
import javax.mail.event.MailEvent;
import javax.mail.event.MessageChangedEvent;
import javax.mail.event.MessageChangedListener;
import javax.mail.event.MessageCountEvent;
import javax.mail.event.MessageCountListener;
import javax.mail.search.SearchTerm;

public abstract class Folder {
  protected Store store;
  
  protected int mode;
  
  public static final int HOLDS_MESSAGES = 1;
  
  public static final int HOLDS_FOLDERS = 2;
  
  public static final int READ_ONLY = 1;
  
  public static final int READ_WRITE = 2;
  
  private Vector connectionListeners;
  
  private Vector folderListeners;
  
  private Vector messageCountListeners;
  
  private Vector messageChangedListeners;
  
  private EventQueue q;
  
  protected Folder(Store paramStore) {
    this.mode = -1;
    this.store = paramStore;
  }
  
  public abstract String getName();
  
  public abstract String getFullName();
  
  public URLName getURLName() throws MessagingException {
    URLName uRLName = getStore().getURLName();
    String str = getFullName();
    StringBuffer stringBuffer = new StringBuffer();
    char c = getSeparator();
    if (str != null) {
      StringTokenizer stringTokenizer = new StringTokenizer(
          str, (new Character(c)).toString(), true);
      while (stringTokenizer.hasMoreTokens()) {
        String str1 = stringTokenizer.nextToken();
        if (str1.charAt(0) == c) {
          stringBuffer.append("/");
          continue;
        } 
        stringBuffer.append(str1);
      } 
    } 
    return new URLName(uRLName.getProtocol(), uRLName.getHost(), 
        uRLName.getPort(), stringBuffer.toString(), 
        uRLName.getUsername(), 
        null);
  }
  
  public Store getStore() { return this.store; }
  
  public abstract Folder getParent() throws MessagingException;
  
  public abstract boolean exists() throws MessagingException;
  
  public abstract Folder[] list(String paramString) throws MessagingException;
  
  public Folder[] listSubscribed(String paramString) throws MessagingException { return list(paramString); }
  
  public Folder[] list() throws MessagingException { return list("%"); }
  
  public Folder[] listSubscribed() throws MessagingException { return listSubscribed("%"); }
  
  public abstract char getSeparator() throws MessagingException;
  
  public abstract int getType() throws MessagingException;
  
  public abstract boolean create(int paramInt) throws MessagingException;
  
  public boolean isSubscribed() throws MessagingException { return true; }
  
  public void setSubscribed(boolean paramBoolean) throws MessagingException { throw new MethodNotSupportedException(); }
  
  public abstract boolean hasNewMessages() throws MessagingException;
  
  public abstract Folder getFolder(String paramString) throws MessagingException;
  
  public abstract boolean delete(boolean paramBoolean) throws MessagingException;
  
  public abstract boolean renameTo(Folder paramFolder) throws MessagingException;
  
  public abstract void open(int paramInt) throws MessagingException;
  
  public abstract void close(boolean paramBoolean) throws MessagingException;
  
  public abstract boolean isOpen() throws MessagingException;
  
  public int getMode() throws MessagingException {
    if (!isOpen())
      throw new IllegalStateException("Folder not open"); 
    return this.mode;
  }
  
  public abstract Flags getPermanentFlags();
  
  public abstract int getMessageCount() throws MessagingException;
  
  public int getNewMessageCount() throws MessagingException {
    if (!isOpen())
      return -1; 
    byte b1 = 0;
    int i = getMessageCount();
    for (byte b2 = 1; b2 <= i; b2++) {
      try {
        if (getMessage(b2).isSet(Flags.Flag.RECENT))
          b1++; 
      } catch (MessageRemovedException messageRemovedException) {}
    } 
    return b1;
  }
  
  public int getUnreadMessageCount() throws MessagingException {
    if (!isOpen())
      return -1; 
    byte b1 = 0;
    int i = getMessageCount();
    for (byte b2 = 1; b2 <= i; b2++) {
      try {
        if (!getMessage(b2).isSet(Flags.Flag.SEEN))
          b1++; 
      } catch (MessageRemovedException messageRemovedException) {}
    } 
    return b1;
  }
  
  public abstract Message getMessage(int paramInt) throws MessagingException;
  
  public Message[] getMessages(int paramInt1, int paramInt2) throws MessagingException {
    Message[] arrayOfMessage = new Message[paramInt2 - paramInt1 + 1];
    for (int i = paramInt1; i <= paramInt2; i++)
      arrayOfMessage[i - paramInt1] = getMessage(i); 
    return arrayOfMessage;
  }
  
  public Message[] getMessages(int[] paramArrayOfInt) throws MessagingException {
    int i = paramArrayOfInt.length;
    Message[] arrayOfMessage = new Message[i];
    for (byte b = 0; b < i; b++)
      arrayOfMessage[b] = getMessage(paramArrayOfInt[b]); 
    return arrayOfMessage;
  }
  
  public Message[] getMessages() throws MessagingException {
    int i = getMessageCount();
    Message[] arrayOfMessage = new Message[i];
    for (byte b = 1; b <= i; b++)
      arrayOfMessage[b - true] = getMessage(b); 
    return arrayOfMessage;
  }
  
  public abstract void appendMessages(Message[] paramArrayOfMessage) throws MessagingException;
  
  public void fetch(Message[] paramArrayOfMessage, FetchProfile paramFetchProfile) throws MessagingException {}
  
  public void setFlags(Message[] paramArrayOfMessage, Flags paramFlags, boolean paramBoolean) throws MessagingException {
    for (byte b = 0; b < paramArrayOfMessage.length; b++) {
      try {
        paramArrayOfMessage[b].setFlags(paramFlags, paramBoolean);
      } catch (MessageRemovedException messageRemovedException) {}
    } 
  }
  
  public void setFlags(int paramInt1, int paramInt2, Flags paramFlags, boolean paramBoolean) throws MessagingException {
    for (int i = paramInt1; i <= paramInt2; i++) {
      try {
        Message message = getMessage(i);
        message.setFlags(paramFlags, paramBoolean);
      } catch (MessageRemovedException messageRemovedException) {}
    } 
  }
  
  public void setFlags(int[] paramArrayOfInt, Flags paramFlags, boolean paramBoolean) throws MessagingException {
    for (byte b = 0; b < paramArrayOfInt.length; b++) {
      try {
        Message message = getMessage(paramArrayOfInt[b]);
        message.setFlags(paramFlags, paramBoolean);
      } catch (MessageRemovedException messageRemovedException) {}
    } 
  }
  
  public void copyMessages(Message[] paramArrayOfMessage, Folder paramFolder) throws MessagingException {
    if (!paramFolder.exists())
      throw new FolderNotFoundException(
          String.valueOf(paramFolder.getFullName()) + " does not exist", 
          paramFolder); 
    paramFolder.appendMessages(paramArrayOfMessage);
  }
  
  public abstract Message[] expunge() throws MessagingException;
  
  public Message[] search(SearchTerm paramSearchTerm) throws MessagingException { return search(paramSearchTerm, getMessages()); }
  
  public Message[] search(SearchTerm paramSearchTerm, Message[] paramArrayOfMessage) throws MessagingException {
    Vector vector = new Vector();
    for (byte b = 0; b < paramArrayOfMessage.length; b++) {
      try {
        if (paramArrayOfMessage[b].match(paramSearchTerm))
          vector.addElement(paramArrayOfMessage[b]); 
      } catch (MessageRemovedException messageRemovedException) {}
    } 
    Message[] arrayOfMessage = new Message[vector.size()];
    vector.copyInto(arrayOfMessage);
    return arrayOfMessage;
  }
  
  public void addConnectionListener(ConnectionListener paramConnectionListener) {
    if (this.connectionListeners == null)
      this.connectionListeners = new Vector(); 
    this.connectionListeners.addElement(paramConnectionListener);
  }
  
  public void removeConnectionListener(ConnectionListener paramConnectionListener) {
    if (this.connectionListeners != null)
      this.connectionListeners.removeElement(paramConnectionListener); 
  }
  
  protected void notifyConnectionListeners(int paramInt) throws MessagingException {
    if (this.connectionListeners != null) {
      ConnectionEvent connectionEvent = new ConnectionEvent(this, paramInt);
      queueEvent(connectionEvent, this.connectionListeners);
    } 
    if (paramInt == 3)
      terminateQueue(); 
  }
  
  private void terminateQueue() {
    if (this.q != null) {
      Vector vector = new Vector();
      vector.setSize(1);
      this.q.enqueue(
          new MailEvent(new Object()) {
            public void dispatch(Object param1Object) { Thread.currentThread().interrupt(); }
          },  vector);
      this.q = null;
    } 
  }
  
  public void addFolderListener(FolderListener paramFolderListener) {
    if (this.folderListeners == null)
      this.folderListeners = new Vector(); 
    this.folderListeners.addElement(paramFolderListener);
  }
  
  public void removeFolderListener(FolderListener paramFolderListener) {
    if (this.folderListeners != null)
      this.folderListeners.removeElement(paramFolderListener); 
  }
  
  protected void notifyFolderListeners(int paramInt) throws MessagingException {
    if (this.folderListeners != null) {
      FolderEvent folderEvent = new FolderEvent(this, this, paramInt);
      queueEvent(folderEvent, this.folderListeners);
    } 
    this.store.notifyFolderListeners(paramInt, this);
  }
  
  protected void notifyFolderRenamedListeners(Folder paramFolder) {
    if (this.folderListeners != null) {
      FolderEvent folderEvent = new FolderEvent(this, this, paramFolder, 
          3);
      queueEvent(folderEvent, this.folderListeners);
    } 
    this.store.notifyFolderRenamedListeners(this, paramFolder);
  }
  
  public void addMessageCountListener(MessageCountListener paramMessageCountListener) {
    if (this.messageCountListeners == null)
      this.messageCountListeners = new Vector(); 
    this.messageCountListeners.addElement(paramMessageCountListener);
  }
  
  public void removeMessageCountListener(MessageCountListener paramMessageCountListener) {
    if (this.messageCountListeners != null)
      this.messageCountListeners.removeElement(paramMessageCountListener); 
  }
  
  protected void notifyMessageAddedListeners(Message[] paramArrayOfMessage) throws MessagingException {
    if (this.messageCountListeners == null)
      return; 
    MessageCountEvent messageCountEvent = new MessageCountEvent(
        this, 
        1, 
        false, 
        paramArrayOfMessage);
    queueEvent(messageCountEvent, this.messageCountListeners);
  }
  
  protected void notifyMessageRemovedListeners(boolean paramBoolean, Message[] paramArrayOfMessage) {
    if (this.messageCountListeners == null)
      return; 
    MessageCountEvent messageCountEvent = new MessageCountEvent(
        this, 
        2, 
        paramBoolean, 
        paramArrayOfMessage);
    queueEvent(messageCountEvent, this.messageCountListeners);
  }
  
  public void addMessageChangedListener(MessageChangedListener paramMessageChangedListener) {
    if (this.messageChangedListeners == null)
      this.messageChangedListeners = new Vector(); 
    this.messageChangedListeners.addElement(paramMessageChangedListener);
  }
  
  public void removeMessageChangedListener(MessageChangedListener paramMessageChangedListener) {
    if (this.messageChangedListeners != null)
      this.messageChangedListeners.removeElement(paramMessageChangedListener); 
  }
  
  protected void notifyMessageChangedListeners(int paramInt, Message paramMessage) {
    if (this.messageChangedListeners == null)
      return; 
    MessageChangedEvent messageChangedEvent = new MessageChangedEvent(this, paramInt, paramMessage);
    queueEvent(messageChangedEvent, this.messageChangedListeners);
  }
  
  private void queueEvent(MailEvent paramMailEvent, Vector paramVector) {
    if (this.q == null)
      this.q = new EventQueue(); 
    Vector vector = (Vector)paramVector.clone();
    this.q.enqueue(paramMailEvent, vector);
  }
  
  protected void finalize() {
    super.finalize();
    terminateQueue();
  }
  
  public String toString() {
    String str = getFullName();
    if (str != null)
      return str; 
    return super.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\Folder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */