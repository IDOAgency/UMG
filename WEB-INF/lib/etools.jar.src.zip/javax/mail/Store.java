/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import javax.mail.event.FolderEvent;
/*     */ import javax.mail.event.FolderListener;
/*     */ import javax.mail.event.StoreEvent;
/*     */ import javax.mail.event.StoreListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Store
/*     */   extends Service
/*     */ {
/*     */   private Vector storeListeners;
/*     */   private Vector folderListeners;
/*     */   
/*  41 */   protected Store(Session paramSession, URLName paramURLName) { super(paramSession, paramURLName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Folder getDefaultFolder() throws MessagingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Folder getFolder(String paramString) throws MessagingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Folder getFolder(URLName paramURLName) throws MessagingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addStoreListener(StoreListener paramStoreListener) {
/* 106 */     if (this.storeListeners == null)
/* 107 */       this.storeListeners = new Vector(); 
/* 108 */     this.storeListeners.addElement(paramStoreListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeStoreListener(StoreListener paramStoreListener) {
/* 121 */     if (this.storeListeners != null) {
/* 122 */       this.storeListeners.removeElement(paramStoreListener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyStoreListeners(int paramInt, String paramString) {
/* 136 */     if (this.storeListeners == null) {
/*     */       return;
/*     */     }
/* 139 */     StoreEvent storeEvent = new StoreEvent(this, paramInt, paramString);
/* 140 */     queueEvent(storeEvent, this.storeListeners);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFolderListener(FolderListener paramFolderListener) {
/* 159 */     if (this.folderListeners == null)
/* 160 */       this.folderListeners = new Vector(); 
/* 161 */     this.folderListeners.addElement(paramFolderListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeFolderListener(FolderListener paramFolderListener) {
/* 174 */     if (this.folderListeners != null) {
/* 175 */       this.folderListeners.removeElement(paramFolderListener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyFolderListeners(int paramInt, Folder paramFolder) {
/* 193 */     if (this.folderListeners == null) {
/*     */       return;
/*     */     }
/* 196 */     FolderEvent folderEvent = new FolderEvent(this, paramFolder, paramInt);
/* 197 */     queueEvent(folderEvent, this.folderListeners);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyFolderRenamedListeners(Folder paramFolder1, Folder paramFolder2) {
/* 216 */     if (this.folderListeners == null) {
/*     */       return;
/*     */     }
/* 219 */     FolderEvent folderEvent = new FolderEvent(this, paramFolder1, paramFolder2, 3);
/* 220 */     queueEvent(folderEvent, this.folderListeners);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\Store.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */