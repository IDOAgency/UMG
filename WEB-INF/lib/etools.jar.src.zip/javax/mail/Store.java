package javax.mail;

import java.util.Vector;
import javax.mail.event.FolderEvent;
import javax.mail.event.FolderListener;
import javax.mail.event.StoreEvent;
import javax.mail.event.StoreListener;

public abstract class Store extends Service {
  private Vector storeListeners;
  
  private Vector folderListeners;
  
  protected Store(Session paramSession, URLName paramURLName) { super(paramSession, paramURLName); }
  
  public abstract Folder getDefaultFolder() throws MessagingException;
  
  public abstract Folder getFolder(String paramString) throws MessagingException;
  
  public abstract Folder getFolder(URLName paramURLName) throws MessagingException;
  
  public void addStoreListener(StoreListener paramStoreListener) {
    if (this.storeListeners == null)
      this.storeListeners = new Vector(); 
    this.storeListeners.addElement(paramStoreListener);
  }
  
  public void removeStoreListener(StoreListener paramStoreListener) {
    if (this.storeListeners != null)
      this.storeListeners.removeElement(paramStoreListener); 
  }
  
  protected void notifyStoreListeners(int paramInt, String paramString) {
    if (this.storeListeners == null)
      return; 
    StoreEvent storeEvent = new StoreEvent(this, paramInt, paramString);
    queueEvent(storeEvent, this.storeListeners);
  }
  
  public void addFolderListener(FolderListener paramFolderListener) {
    if (this.folderListeners == null)
      this.folderListeners = new Vector(); 
    this.folderListeners.addElement(paramFolderListener);
  }
  
  public void removeFolderListener(FolderListener paramFolderListener) {
    if (this.folderListeners != null)
      this.folderListeners.removeElement(paramFolderListener); 
  }
  
  protected void notifyFolderListeners(int paramInt, Folder paramFolder) {
    if (this.folderListeners == null)
      return; 
    FolderEvent folderEvent = new FolderEvent(this, paramFolder, paramInt);
    queueEvent(folderEvent, this.folderListeners);
  }
  
  protected void notifyFolderRenamedListeners(Folder paramFolder1, Folder paramFolder2) {
    if (this.folderListeners == null)
      return; 
    FolderEvent folderEvent = new FolderEvent(this, paramFolder1, paramFolder2, 3);
    queueEvent(folderEvent, this.folderListeners);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\Store.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */