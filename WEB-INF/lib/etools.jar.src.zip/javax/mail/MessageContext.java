package javax.mail;

public class MessageContext {
  private Part part;
  
  public MessageContext(Part paramPart) { this.part = paramPart; }
  
  public Part getPart() { return this.part; }
  
  public Message getMessage() {
    try {
      return getMessage(this.part);
    } catch (MessagingException messagingException) {
      return null;
    } 
  }
  
  private static Message getMessage(Part paramPart) throws MessagingException {
    while (paramPart != null) {
      if (paramPart instanceof Message)
        return (Message)paramPart; 
      BodyPart bodyPart = (BodyPart)paramPart;
      Multipart multipart = bodyPart.getParent();
      paramPart = multipart.getParent();
    } 
    return null;
  }
  
  public Session getSession() {
    Message message = getMessage();
    return (message != null) ? message.session : null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\MessageContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */