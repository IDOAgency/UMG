/*    */ package javax.mail;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageContext
/*    */ {
/*    */   private Part part;
/*    */   
/* 31 */   public MessageContext(Part paramPart) { this.part = paramPart; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   public Part getPart() { return this.part; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Message getMessage() {
/*    */     try {
/* 52 */       return getMessage(this.part);
/* 53 */     } catch (MessagingException messagingException) {
/* 54 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static Message getMessage(Part paramPart) throws MessagingException {
/* 68 */     while (paramPart != null) {
/* 69 */       if (paramPart instanceof Message)
/* 70 */         return (Message)paramPart; 
/* 71 */       BodyPart bodyPart = (BodyPart)paramPart;
/* 72 */       Multipart multipart = bodyPart.getParent();
/* 73 */       paramPart = multipart.getParent();
/*    */     } 
/* 75 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Session getSession() {
/* 84 */     Message message = getMessage();
/* 85 */     return (message != null) ? message.session : null;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\MessageContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */