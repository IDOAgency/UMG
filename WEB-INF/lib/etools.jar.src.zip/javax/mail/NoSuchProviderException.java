package javax.mail;

public class NoSuchProviderException extends MessagingException {
  public NoSuchProviderException() {}
  
  public NoSuchProviderException(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\NoSuchProviderException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */