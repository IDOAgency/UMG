/*    */ package javax.mail;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StoreClosedException
/*    */   extends MessagingException
/*    */ {
/*    */   private Store store;
/*    */   
/* 33 */   public StoreClosedException(Store paramStore) { this(paramStore, null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StoreClosedException(Store paramStore, String paramString) {
/* 42 */     super(paramString);
/* 43 */     this.store = paramStore;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   public Store getStore() { return this.store; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\StoreClosedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */