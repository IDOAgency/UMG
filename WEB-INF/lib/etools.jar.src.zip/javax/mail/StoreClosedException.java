package javax.mail;

public class StoreClosedException extends MessagingException {
  private Store store;
  
  public StoreClosedException(Store paramStore) { this(paramStore, null); }
  
  public StoreClosedException(Store paramStore, String paramString) {
    super(paramString);
    this.store = paramStore;
  }
  
  public Store getStore() { return this.store; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\StoreClosedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */