package javax.mail;

public class SendFailedException extends MessagingException {
  protected Address[] invalid;
  
  protected Address[] validSent;
  
  protected Address[] validUnsent;
  
  public SendFailedException() {}
  
  public SendFailedException(String paramString) { super(paramString); }
  
  public SendFailedException(String paramString, Exception paramException) { super(paramString, paramException); }
  
  public SendFailedException(String paramString, Exception paramException, Address[] paramArrayOfAddress1, Address[] paramArrayOfAddress2, Address[] paramArrayOfAddress3) {
    super(paramString, paramException);
    this.validSent = paramArrayOfAddress1;
    this.validUnsent = paramArrayOfAddress2;
    this.invalid = paramArrayOfAddress3;
  }
  
  public Address[] getValidSentAddresses() { return this.validSent; }
  
  public Address[] getValidUnsentAddresses() { return this.validUnsent; }
  
  public Address[] getInvalidAddresses() { return this.invalid; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\SendFailedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */