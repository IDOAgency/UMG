/*     */ package javax.mail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SendFailedException
/*     */   extends MessagingException
/*     */ {
/*     */   protected Address[] invalid;
/*     */   protected Address[] validSent;
/*     */   protected Address[] validUnsent;
/*     */   
/*     */   public SendFailedException() {}
/*     */   
/*  42 */   public SendFailedException(String paramString) { super(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public SendFailedException(String paramString, Exception paramException) { super(paramString, paramException); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SendFailedException(String paramString, Exception paramException, Address[] paramArrayOfAddress1, Address[] paramArrayOfAddress2, Address[] paramArrayOfAddress3) {
/*  73 */     super(paramString, paramException);
/*  74 */     this.validSent = paramArrayOfAddress1;
/*  75 */     this.validUnsent = paramArrayOfAddress2;
/*  76 */     this.invalid = paramArrayOfAddress3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public Address[] getValidSentAddresses() { return this.validSent; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public Address[] getValidUnsentAddresses() { return this.validUnsent; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public Address[] getInvalidAddresses() { return this.invalid; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\SendFailedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */