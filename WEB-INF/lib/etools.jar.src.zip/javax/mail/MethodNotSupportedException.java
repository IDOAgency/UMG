package javax.mail;

public class MethodNotSupportedException extends MessagingException {
  public MethodNotSupportedException() {}
  
  public MethodNotSupportedException(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\MethodNotSupportedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */