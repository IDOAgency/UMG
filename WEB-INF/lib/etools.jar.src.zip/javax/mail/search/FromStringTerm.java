package javax.mail.search;

import javax.mail.Address;
import javax.mail.Message;

public final class FromStringTerm extends AddressStringTerm {
  public FromStringTerm(String paramString) { super(paramString); }
  
  public boolean match(Message paramMessage) {
    Address[] arrayOfAddress;
    try {
      arrayOfAddress = paramMessage.getFrom();
    } catch (Exception exception) {
      return false;
    } 
    if (arrayOfAddress == null)
      return false; 
    for (byte b = 0; b < arrayOfAddress.length; b++) {
      if (match(arrayOfAddress[b]))
        return true; 
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\FromStringTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */