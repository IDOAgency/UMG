/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Address;
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FromStringTerm
/*    */   extends AddressStringTerm
/*    */ {
/* 32 */   public FromStringTerm(String paramString) { super(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(Message paramMessage) {
/*    */     Address[] arrayOfAddress;
/*    */     try {
/* 47 */       arrayOfAddress = paramMessage.getFrom();
/* 48 */     } catch (Exception exception) {
/* 49 */       return false;
/*    */     } 
/*    */     
/* 52 */     if (arrayOfAddress == null) {
/* 53 */       return false;
/*    */     }
/* 55 */     for (byte b = 0; b < arrayOfAddress.length; b++) {
/* 56 */       if (match(arrayOfAddress[b]))
/* 57 */         return true; 
/* 58 */     }  return false;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\FromStringTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */