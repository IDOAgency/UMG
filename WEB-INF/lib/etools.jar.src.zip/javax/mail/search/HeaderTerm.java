package javax.mail.search;

import javax.mail.Message;

public final class HeaderTerm extends StringTerm {
  protected String headerName;
  
  public HeaderTerm(String paramString1, String paramString2) {
    super(paramString2);
    this.headerName = paramString1;
  }
  
  public String getHeaderName() { return this.headerName; }
  
  public boolean match(Message paramMessage) {
    String[] arrayOfString;
    try {
      arrayOfString = paramMessage.getHeader(this.headerName);
    } catch (Exception exception) {
      return false;
    } 
    if (arrayOfString == null)
      return false; 
    for (byte b = 0; b < arrayOfString.length; b++) {
      if (match(arrayOfString[b]))
        return true; 
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\HeaderTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */