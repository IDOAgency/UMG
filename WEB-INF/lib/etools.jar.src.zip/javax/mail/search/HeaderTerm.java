/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HeaderTerm
/*    */   extends StringTerm
/*    */ {
/*    */   protected String headerName;
/*    */   
/*    */   public HeaderTerm(String paramString1, String paramString2) {
/* 29 */     super(paramString2);
/* 30 */     this.headerName = paramString1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 37 */   public String getHeaderName() { return this.headerName; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(Message paramMessage) {
/*    */     String[] arrayOfString;
/*    */     try {
/* 50 */       arrayOfString = paramMessage.getHeader(this.headerName);
/* 51 */     } catch (Exception exception) {
/* 52 */       return false;
/*    */     } 
/*    */     
/* 55 */     if (arrayOfString == null) {
/* 56 */       return false;
/*    */     }
/* 58 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 59 */       if (match(arrayOfString[b]))
/* 60 */         return true; 
/* 61 */     }  return false;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\HeaderTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */