package javax.mail.search;

import java.util.Date;
import javax.mail.Message;

public final class ReceivedDateTerm extends DateTerm {
  public ReceivedDateTerm(int paramInt, Date paramDate) { super(paramInt, paramDate); }
  
  public boolean match(Message paramMessage) {
    Date date;
    try {
      date = paramMessage.getReceivedDate();
    } catch (Exception exception) {
      return false;
    } 
    if (date == null)
      return false; 
    return match(date);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\ReceivedDateTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */