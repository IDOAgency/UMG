package javax.mail.search;

import javax.mail.Message;

public final class AndTerm extends SearchTerm {
  protected SearchTerm[] terms;
  
  public AndTerm(SearchTerm paramSearchTerm1, SearchTerm paramSearchTerm2) {
    this.terms = new SearchTerm[2];
    this.terms[0] = paramSearchTerm1;
    this.terms[1] = paramSearchTerm2;
  }
  
  public AndTerm(SearchTerm[] paramArrayOfSearchTerm) {
    this.terms = new SearchTerm[paramArrayOfSearchTerm.length];
    for (byte b = 0; b < paramArrayOfSearchTerm.length; b++)
      this.terms[b] = paramArrayOfSearchTerm[b]; 
  }
  
  public SearchTerm[] getTerms() { return (SearchTerm[])this.terms.clone(); }
  
  public boolean match(Message paramMessage) {
    for (byte b = 0; b < this.terms.length; b++) {
      if (!this.terms[b].match(paramMessage))
        return false; 
    } 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\AndTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */