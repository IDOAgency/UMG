/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AndTerm
/*    */   extends SearchTerm
/*    */ {
/*    */   protected SearchTerm[] terms;
/*    */   
/*    */   public AndTerm(SearchTerm paramSearchTerm1, SearchTerm paramSearchTerm2) {
/* 34 */     this.terms = new SearchTerm[2];
/* 35 */     this.terms[0] = paramSearchTerm1;
/* 36 */     this.terms[1] = paramSearchTerm2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AndTerm(SearchTerm[] paramArrayOfSearchTerm) {
/* 45 */     this.terms = new SearchTerm[paramArrayOfSearchTerm.length];
/* 46 */     for (byte b = 0; b < paramArrayOfSearchTerm.length; b++) {
/* 47 */       this.terms[b] = paramArrayOfSearchTerm[b];
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   public SearchTerm[] getTerms() { return (SearchTerm[])this.terms.clone(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(Message paramMessage) {
/* 68 */     for (byte b = 0; b < this.terms.length; b++) {
/* 69 */       if (!this.terms[b].match(paramMessage))
/* 70 */         return false; 
/* 71 */     }  return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\AndTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */