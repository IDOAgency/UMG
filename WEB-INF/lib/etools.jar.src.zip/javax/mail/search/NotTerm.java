package javax.mail.search;

import javax.mail.Message;

public final class NotTerm extends SearchTerm {
  protected SearchTerm term;
  
  public NotTerm(SearchTerm paramSearchTerm) { this.term = paramSearchTerm; }
  
  public SearchTerm getTerm() { return this.term; }
  
  public boolean match(Message paramMessage) { return !this.term.match(paramMessage); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\NotTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */