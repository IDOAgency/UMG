/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NotTerm
/*    */   extends SearchTerm
/*    */ {
/*    */   protected SearchTerm term;
/*    */   
/* 22 */   public NotTerm(SearchTerm paramSearchTerm) { this.term = paramSearchTerm; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   public SearchTerm getTerm() { return this.term; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   public boolean match(Message paramMessage) { return !this.term.match(paramMessage); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\NotTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */