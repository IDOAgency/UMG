/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Address;
/*    */ import javax.mail.internet.InternetAddress;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AddressStringTerm
/*    */   extends StringTerm
/*    */ {
/* 33 */   protected AddressStringTerm(String paramString) { super(paramString, true); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean match(Address paramAddress) {
/* 49 */     if (paramAddress instanceof InternetAddress) {
/* 50 */       InternetAddress internetAddress = (InternetAddress)paramAddress;
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 55 */       String str1 = internetAddress.getAddress();
/* 56 */       String str2 = internetAddress.getPersonal();
/* 57 */       return match((str2 == null) ? str1 : (
/* 58 */           String.valueOf(str2) + " <" + str1 + ">"));
/*    */     } 
/* 60 */     return match(paramAddress.toString());
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\AddressStringTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */