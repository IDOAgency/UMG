package javax.mail.search;

import javax.mail.Address;
import javax.mail.internet.InternetAddress;

public abstract class AddressStringTerm extends StringTerm {
  protected AddressStringTerm(String paramString) { super(paramString, true); }
  
  protected boolean match(Address paramAddress) {
    if (paramAddress instanceof InternetAddress) {
      InternetAddress internetAddress = (InternetAddress)paramAddress;
      String str1 = internetAddress.getAddress();
      String str2 = internetAddress.getPersonal();
      return match((str2 == null) ? str1 : (
          String.valueOf(str2) + " <" + str1 + ">"));
    } 
    return match(paramAddress.toString());
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\AddressStringTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */