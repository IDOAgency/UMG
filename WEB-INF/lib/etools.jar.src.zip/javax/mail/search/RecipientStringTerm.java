/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Address;
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RecipientStringTerm
/*    */   extends AddressStringTerm
/*    */ {
/*    */   private Message.RecipientType type;
/*    */   
/*    */   public RecipientStringTerm(Message.RecipientType paramRecipientType, String paramString) {
/* 38 */     super(paramString);
/* 39 */     this.type = paramRecipientType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   public Message.RecipientType getRecipientType() { return this.type; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(Message paramMessage) {
/*    */     Address[] arrayOfAddress;
/*    */     try {
/* 61 */       arrayOfAddress = paramMessage.getRecipients(this.type);
/* 62 */     } catch (Exception exception) {
/* 63 */       return false;
/*    */     } 
/*    */     
/* 66 */     if (arrayOfAddress == null) {
/* 67 */       return false;
/*    */     }
/* 69 */     for (byte b = 0; b < arrayOfAddress.length; b++) {
/* 70 */       if (match(arrayOfAddress[b]))
/* 71 */         return true; 
/* 72 */     }  return false;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\RecipientStringTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */