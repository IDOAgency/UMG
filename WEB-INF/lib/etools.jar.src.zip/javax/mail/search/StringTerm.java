package javax.mail.search;

public abstract class StringTerm extends SearchTerm {
  protected String pattern;
  
  protected boolean ignoreCase;
  
  protected StringTerm(String paramString) {
    this.pattern = paramString;
    this.ignoreCase = true;
  }
  
  protected StringTerm(String paramString, boolean paramBoolean) {
    this.pattern = paramString;
    this.ignoreCase = paramBoolean;
  }
  
  public String getPattern() { return this.pattern; }
  
  public boolean getIgnoreCase() { return this.ignoreCase; }
  
  protected boolean match(String paramString) {
    int i = paramString.length() - this.pattern.length();
    for (byte b = 0; b <= i; b++) {
      if (paramString.regionMatches(this.ignoreCase, b, 
          this.pattern, 0, this.pattern.length()))
        return true; 
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\StringTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */