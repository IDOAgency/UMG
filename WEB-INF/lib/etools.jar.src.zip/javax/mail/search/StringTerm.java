/*    */ package javax.mail.search;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class StringTerm
/*    */   extends SearchTerm
/*    */ {
/*    */   protected String pattern;
/*    */   protected boolean ignoreCase;
/*    */   
/*    */   protected StringTerm(String paramString) {
/* 23 */     this.pattern = paramString;
/* 24 */     this.ignoreCase = true;
/*    */   }
/*    */   
/*    */   protected StringTerm(String paramString, boolean paramBoolean) {
/* 28 */     this.pattern = paramString;
/* 29 */     this.ignoreCase = paramBoolean;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   public String getPattern() { return this.pattern; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   public boolean getIgnoreCase() { return this.ignoreCase; }
/*    */ 
/*    */   
/*    */   protected boolean match(String paramString) {
/* 47 */     int i = paramString.length() - this.pattern.length();
/* 48 */     for (byte b = 0; b <= i; b++) {
/* 49 */       if (paramString.regionMatches(this.ignoreCase, b, 
/* 50 */           this.pattern, 0, this.pattern.length()))
/* 51 */         return true; 
/*    */     } 
/* 53 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\StringTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */