package javax.mail.search;

public abstract class IntegerComparisonTerm extends ComparisonTerm {
  protected int number;
  
  protected IntegerComparisonTerm(int paramInt1, int paramInt2) {
    this.comparison = paramInt1;
    this.number = paramInt2;
  }
  
  public int getNumber() { return this.number; }
  
  public int getComparison() { return this.comparison; }
  
  protected boolean match(int paramInt) {
    switch (this.comparison) {
      case 1:
        return !(paramInt > this.number);
      case 2:
        return !(paramInt >= this.number);
      case 3:
        return !(paramInt != this.number);
      case 4:
        return !(paramInt == this.number);
      case 5:
        return !(paramInt <= this.number);
      case 6:
        return !(paramInt < this.number);
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\IntegerComparisonTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */