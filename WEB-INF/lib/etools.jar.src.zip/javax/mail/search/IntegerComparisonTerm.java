/*    */ package javax.mail.search;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class IntegerComparisonTerm
/*    */   extends ComparisonTerm
/*    */ {
/*    */   protected int number;
/*    */   
/*    */   protected IntegerComparisonTerm(int paramInt1, int paramInt2) {
/* 20 */     this.comparison = paramInt1;
/* 21 */     this.number = paramInt2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 28 */   public int getNumber() { return this.number; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   public int getComparison() { return this.comparison; }
/*    */ 
/*    */   
/*    */   protected boolean match(int paramInt) {
/* 39 */     switch (this.comparison) {
/*    */       case 1:
/* 41 */         return !(paramInt > this.number);
/*    */       case 2:
/* 43 */         return !(paramInt >= this.number);
/*    */       case 3:
/* 45 */         return !(paramInt != this.number);
/*    */       case 4:
/* 47 */         return !(paramInt == this.number);
/*    */       case 5:
/* 49 */         return !(paramInt <= this.number);
/*    */       case 6:
/* 51 */         return !(paramInt < this.number);
/*    */     } 
/* 53 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\IntegerComparisonTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */