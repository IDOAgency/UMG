package javax.mail.search;

import javax.mail.MessagingException;

public class SearchException extends MessagingException {
  public SearchException() {}
  
  public SearchException(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\SearchException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */