/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SubjectTerm
/*    */   extends StringTerm
/*    */ {
/* 28 */   public SubjectTerm(String paramString) { super(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(Message paramMessage) {
/*    */     String str;
/*    */     try {
/* 42 */       str = paramMessage.getSubject();
/* 43 */     } catch (Exception exception) {
/* 44 */       return false;
/*    */     } 
/*    */     
/* 47 */     if (str == null) {
/* 48 */       return false;
/*    */     }
/* 50 */     return match(str);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\SubjectTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */