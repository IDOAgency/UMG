package javax.mail.search;

import javax.mail.Message;

public final class MessageIDTerm extends StringTerm {
  public MessageIDTerm(String paramString) { super(paramString); }
  
  public boolean match(Message paramMessage) {
    String[] arrayOfString;
    try {
      arrayOfString = paramMessage.getHeader("Message-ID");
    } catch (Exception exception) {
      return false;
    } 
    if (arrayOfString == null)
      return false; 
    for (byte b = 0; b < arrayOfString.length; b++) {
      if (match(arrayOfString[b]))
        return true; 
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\MessageIDTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */