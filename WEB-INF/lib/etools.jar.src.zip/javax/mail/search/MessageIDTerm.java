/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MessageIDTerm
/*    */   extends StringTerm
/*    */ {
/* 32 */   public MessageIDTerm(String paramString) { super(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(Message paramMessage) {
/*    */     String[] arrayOfString;
/*    */     try {
/* 46 */       arrayOfString = paramMessage.getHeader("Message-ID");
/* 47 */     } catch (Exception exception) {
/* 48 */       return false;
/*    */     } 
/*    */     
/* 51 */     if (arrayOfString == null) {
/* 52 */       return false;
/*    */     }
/* 54 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 55 */       if (match(arrayOfString[b]))
/* 56 */         return true; 
/* 57 */     }  return false;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\MessageIDTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */