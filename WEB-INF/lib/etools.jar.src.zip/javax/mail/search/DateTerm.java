/*    */ package javax.mail.search;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DateTerm
/*    */   extends ComparisonTerm
/*    */ {
/*    */   protected Date date;
/*    */   
/*    */   protected DateTerm(int paramInt, Date paramDate) {
/* 27 */     this.comparison = paramInt;
/* 28 */     this.date = paramDate;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   public Date getDate() { return new Date(this.date.getTime()); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   public int getComparison() { return this.comparison; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean match(Date paramDate) {
/* 52 */     switch (this.comparison) {
/*    */       case 1:
/* 54 */         return !(!paramDate.before(this.date) && !paramDate.equals(this.date));
/*    */       case 2:
/* 56 */         return paramDate.before(this.date);
/*    */       case 3:
/* 58 */         return paramDate.equals(this.date);
/*    */       case 4:
/* 60 */         return !paramDate.equals(this.date);
/*    */       case 5:
/* 62 */         return paramDate.after(this.date);
/*    */       case 6:
/* 64 */         return !(!paramDate.after(this.date) && !paramDate.equals(this.date));
/*    */     } 
/* 66 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\DateTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */