package javax.mail.search;

import java.util.Date;

public abstract class DateTerm extends ComparisonTerm {
  protected Date date;
  
  protected DateTerm(int paramInt, Date paramDate) {
    this.comparison = paramInt;
    this.date = paramDate;
  }
  
  public Date getDate() { return new Date(this.date.getTime()); }
  
  public int getComparison() { return this.comparison; }
  
  protected boolean match(Date paramDate) {
    switch (this.comparison) {
      case 1:
        return !(!paramDate.before(this.date) && !paramDate.equals(this.date));
      case 2:
        return paramDate.before(this.date);
      case 3:
        return paramDate.equals(this.date);
      case 4:
        return !paramDate.equals(this.date);
      case 5:
        return paramDate.after(this.date);
      case 6:
        return !(!paramDate.after(this.date) && !paramDate.equals(this.date));
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\DateTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */