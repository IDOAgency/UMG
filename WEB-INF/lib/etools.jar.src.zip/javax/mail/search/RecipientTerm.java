/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Address;
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RecipientTerm
/*    */   extends AddressTerm
/*    */ {
/*    */   protected Message.RecipientType type;
/*    */   
/*    */   public RecipientTerm(Message.RecipientType paramRecipientType, Address paramAddress) {
/* 33 */     super(paramAddress);
/* 34 */     this.type = paramRecipientType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public Message.RecipientType getRecipientType() { return this.type; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(Message paramMessage) {
/*    */     Address[] arrayOfAddress;
/*    */     try {
/* 55 */       arrayOfAddress = paramMessage.getRecipients(this.type);
/* 56 */     } catch (Exception exception) {
/* 57 */       return false;
/*    */     } 
/*    */     
/* 60 */     if (arrayOfAddress == null) {
/* 61 */       return false;
/*    */     }
/* 63 */     for (byte b = 0; b < arrayOfAddress.length; b++) {
/* 64 */       if (match(arrayOfAddress[b]))
/* 65 */         return true; 
/* 66 */     }  return false;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\RecipientTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */