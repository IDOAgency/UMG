package javax.mail.search;

import java.util.Date;
import javax.mail.Message;

public final class SentDateTerm extends DateTerm {
  public SentDateTerm(int paramInt, Date paramDate) { super(paramInt, paramDate); }
  
  public boolean match(Message paramMessage) {
    Date date;
    try {
      date = paramMessage.getSentDate();
    } catch (Exception exception) {
      return false;
    } 
    if (date == null)
      return false; 
    return match(date);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\SentDateTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */