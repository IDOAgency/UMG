/*    */ package javax.mail.search;
/*    */ 
/*    */ import java.util.Date;
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SentDateTerm
/*    */   extends DateTerm
/*    */ {
/* 28 */   public SentDateTerm(int paramInt, Date paramDate) { super(paramInt, paramDate); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(Message paramMessage) {
/*    */     Date date;
/*    */     try {
/* 42 */       date = paramMessage.getSentDate();
/* 43 */     } catch (Exception exception) {
/* 44 */       return false;
/*    */     } 
/*    */     
/* 47 */     if (date == null) {
/* 48 */       return false;
/*    */     }
/* 50 */     return match(date);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\SentDateTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */