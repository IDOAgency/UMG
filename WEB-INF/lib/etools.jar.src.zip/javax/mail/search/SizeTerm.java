package javax.mail.search;

import javax.mail.Message;

public final class SizeTerm extends IntegerComparisonTerm {
  public SizeTerm(int paramInt1, int paramInt2) { super(paramInt1, paramInt2); }
  
  public boolean match(Message paramMessage) {
    int i;
    try {
      i = paramMessage.getSize();
    } catch (Exception exception) {
      return false;
    } 
    if (i == -1)
      return false; 
    return match(i);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\SizeTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */