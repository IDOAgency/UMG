/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SizeTerm
/*    */   extends IntegerComparisonTerm
/*    */ {
/* 27 */   public SizeTerm(int paramInt1, int paramInt2) { super(paramInt1, paramInt2); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(Message paramMessage) {
/*    */     int i;
/*    */     try {
/* 40 */       i = paramMessage.getSize();
/* 41 */     } catch (Exception exception) {
/* 42 */       return false;
/*    */     } 
/*    */     
/* 45 */     if (i == -1) {
/* 46 */       return false;
/*    */     }
/* 48 */     return match(i);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\SizeTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */