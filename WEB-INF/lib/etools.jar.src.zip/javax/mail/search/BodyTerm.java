package javax.mail.search;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;

public final class BodyTerm extends StringTerm {
  public BodyTerm(String paramString) { super(paramString); }
  
  public boolean match(Message paramMessage) {
    Object object = null;
    String str = null;
    Message message = paramMessage;
    try {
      str = message.getContentType();
    } catch (Exception exception) {
      return false;
    } 
    if (str.regionMatches(true, 0, "text/", 0, 5)) {
      try {
        object = message.getContent();
      } catch (Exception exception) {}
    } else if (str.regionMatches(true, 0, "multipart/mixed", 0, 15)) {
      try {
        BodyPart bodyPart = ((Multipart)message.getContent()).getBodyPart(0);
        str = bodyPart.getContentType();
        if (str.regionMatches(true, 0, "text/", 0, 5))
          object = bodyPart.getContent(); 
      } catch (Exception exception) {}
    } 
    if (object == null || !(object instanceof String))
      return false; 
    return match((String)object);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\BodyTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */