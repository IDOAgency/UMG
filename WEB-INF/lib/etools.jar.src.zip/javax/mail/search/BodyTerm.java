/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.BodyPart;
/*    */ import javax.mail.Message;
/*    */ import javax.mail.Multipart;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BodyTerm
/*    */   extends StringTerm
/*    */ {
/* 32 */   public BodyTerm(String paramString) { super(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(Message paramMessage) {
/* 42 */     Object object = null;
/* 43 */     String str = null;
/* 44 */     Message message = paramMessage;
/*    */     
/*    */     try {
/* 47 */       str = message.getContentType();
/* 48 */     } catch (Exception exception) {
/* 49 */       return false;
/*    */     } 
/*    */     
/* 52 */     if (str.regionMatches(true, 0, "text/", 0, 5)) {
/*    */       
/*    */       try {
/* 55 */         object = message.getContent();
/* 56 */       } catch (Exception exception) {}
/* 57 */     } else if (str.regionMatches(true, 0, "multipart/mixed", 0, 15)) {
/*    */       
/*    */       try {
/* 60 */         BodyPart bodyPart = ((Multipart)message.getContent()).getBodyPart(0);
/* 61 */         str = bodyPart.getContentType();
/* 62 */         if (str.regionMatches(true, 0, "text/", 0, 5))
/* 63 */           object = bodyPart.getContent(); 
/* 64 */       } catch (Exception exception) {}
/*    */     } 
/*    */     
/* 67 */     if (object == null || !(object instanceof String)) {
/* 68 */       return false;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 77 */     return match((String)object);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\BodyTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */