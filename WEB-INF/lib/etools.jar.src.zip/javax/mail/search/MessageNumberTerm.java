/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MessageNumberTerm
/*    */   extends IntegerComparisonTerm
/*    */ {
/* 26 */   public MessageNumberTerm(int paramInt) { super(3, paramInt); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(Message paramMessage) {
/*    */     int i;
/*    */     try {
/* 39 */       i = paramMessage.getMessageNumber();
/* 40 */     } catch (Exception exception) {
/* 41 */       return false;
/*    */     } 
/*    */     
/* 44 */     return match(i);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\MessageNumberTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */