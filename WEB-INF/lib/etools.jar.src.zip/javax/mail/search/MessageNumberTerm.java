package javax.mail.search;

import javax.mail.Message;

public final class MessageNumberTerm extends IntegerComparisonTerm {
  public MessageNumberTerm(int paramInt) { super(3, paramInt); }
  
  public boolean match(Message paramMessage) {
    int i;
    try {
      i = paramMessage.getMessageNumber();
    } catch (Exception exception) {
      return false;
    } 
    return match(i);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\MessageNumberTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */