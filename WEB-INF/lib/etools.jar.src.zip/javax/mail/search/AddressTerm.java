/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Address;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AddressTerm
/*    */   extends SearchTerm
/*    */ {
/*    */   protected Address address;
/*    */   
/* 23 */   protected AddressTerm(Address paramAddress) { this.address = paramAddress; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 30 */   public Address getAddress() { return this.address; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 37 */   protected boolean match(Address paramAddress) { return paramAddress.equals(this.address); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\AddressTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */