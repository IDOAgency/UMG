package javax.mail.search;

import javax.mail.Flags;
import javax.mail.Message;

public final class FlagTerm extends SearchTerm {
  protected boolean set;
  
  protected Flags flags;
  
  public FlagTerm(Flags paramFlags, boolean paramBoolean) {
    this.flags = paramFlags;
    this.set = paramBoolean;
  }
  
  public Flags getFlags() { return (Flags)this.flags.clone(); }
  
  public boolean getTestSet() { return this.set; }
  
  public boolean match(Message paramMessage) {
    try {
      Flags flags1 = paramMessage.getFlags();
      if (this.set) {
        if (flags1.contains(this.flags))
          return true; 
        return false;
      } 
      Flags.Flag[] arrayOfFlag = this.flags.getSystemFlags();
      for (byte b1 = 0; b1 < arrayOfFlag.length; b1++) {
        if (flags1.contains(arrayOfFlag[b1]))
          return false; 
      } 
      String[] arrayOfString = this.flags.getUserFlags();
      for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
        if (flags1.contains(arrayOfString[b2]))
          return false; 
      } 
      return true;
    } catch (Exception exception) {
      return false;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\search\FlagTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */