/*     */ package javax.mail.search;
/*     */ 
/*     */ import javax.mail.Flags;
/*     */ import javax.mail.Message;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FlagTerm
/*     */   extends SearchTerm
/*     */ {
/*     */   protected boolean set;
/*     */   protected Flags flags;
/*     */   
/*     */   public FlagTerm(Flags paramFlags, boolean paramBoolean) {
/*  40 */     this.flags = paramFlags;
/*  41 */     this.set = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   public Flags getFlags() { return (Flags)this.flags.clone(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public boolean getTestSet() { return this.set; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(Message paramMessage) {
/*     */     try {
/*  67 */       Flags flags1 = paramMessage.getFlags();
/*  68 */       if (this.set) {
/*  69 */         if (flags1.contains(this.flags)) {
/*  70 */           return true;
/*     */         }
/*  72 */         return false;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  79 */       Flags.Flag[] arrayOfFlag = this.flags.getSystemFlags();
/*     */ 
/*     */       
/*  82 */       for (byte b1 = 0; b1 < arrayOfFlag.length; b1++) {
/*  83 */         if (flags1.contains(arrayOfFlag[b1]))
/*     */         {
/*  85 */           return false;
/*     */         }
/*     */       } 
/*  88 */       String[] arrayOfString = this.flags.getUserFlags();
/*     */ 
/*     */       
/*  91 */       for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
/*  92 */         if (flags1.contains(arrayOfString[b2]))
/*     */         {
/*  94 */           return false;
/*     */         }
/*     */       } 
/*  97 */       return true;
/*     */     }
/*  99 */     catch (Exception exception) {
/* 100 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\FlagTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */