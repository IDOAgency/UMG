/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Address;
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FromTerm
/*    */   extends AddressTerm
/*    */ {
/* 26 */   public FromTerm(Address paramAddress) { super(paramAddress); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(Message paramMessage) {
/*    */     Address[] arrayOfAddress;
/*    */     try {
/* 39 */       arrayOfAddress = paramMessage.getFrom();
/* 40 */     } catch (Exception exception) {
/* 41 */       return false;
/*    */     } 
/*    */     
/* 44 */     if (arrayOfAddress == null) {
/* 45 */       return false;
/*    */     }
/* 47 */     for (byte b = 0; b < arrayOfAddress.length; b++) {
/* 48 */       if (match(arrayOfAddress[b]))
/* 49 */         return true; 
/* 50 */     }  return false;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\FromTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */