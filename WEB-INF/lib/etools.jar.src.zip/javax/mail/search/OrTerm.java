/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OrTerm
/*    */   extends SearchTerm
/*    */ {
/*    */   protected SearchTerm[] terms;
/*    */   
/*    */   public OrTerm(SearchTerm paramSearchTerm1, SearchTerm paramSearchTerm2) {
/* 33 */     this.terms = new SearchTerm[2];
/* 34 */     this.terms[0] = paramSearchTerm1;
/* 35 */     this.terms[1] = paramSearchTerm2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public OrTerm(SearchTerm[] paramArrayOfSearchTerm) {
/* 45 */     this.terms = new SearchTerm[paramArrayOfSearchTerm.length];
/* 46 */     for (byte b = 0; b < paramArrayOfSearchTerm.length; b++) {
/* 47 */       this.terms[b] = paramArrayOfSearchTerm[b];
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   public SearchTerm[] getTerms() { return (SearchTerm[])this.terms.clone(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(Message paramMessage) {
/* 69 */     for (byte b = 0; b < this.terms.length; b++) {
/* 70 */       if (this.terms[b].match(paramMessage))
/* 71 */         return true; 
/* 72 */     }  return false;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\search\OrTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */