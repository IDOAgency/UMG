/*     */ package javax.mail;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Authenticator
/*     */ {
/*     */   private InetAddress requestingSite;
/*     */   private int requestingPort;
/*     */   private String requestingProtocol;
/*     */   private String requestingPrompt;
/*     */   private String requestingUserName;
/*     */   
/*     */   private void reset() {
/*  61 */     this.requestingSite = null;
/*  62 */     this.requestingPort = -1;
/*  63 */     this.requestingProtocol = null;
/*  64 */     this.requestingPrompt = null;
/*  65 */     this.requestingUserName = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final PasswordAuthentication requestPasswordAuthentication(InetAddress paramInetAddress, int paramInt, String paramString1, String paramString2, String paramString3) {
/*  85 */     reset();
/*  86 */     this.requestingSite = paramInetAddress;
/*  87 */     this.requestingPort = paramInt;
/*  88 */     this.requestingProtocol = paramString1;
/*  89 */     this.requestingPrompt = paramString2;
/*  90 */     this.requestingUserName = paramString3;
/*  91 */     return getPasswordAuthentication();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   protected final InetAddress getRequestingSite() { return this.requestingSite; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   protected final int getRequestingPort() { return this.requestingPort; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   protected final String getRequestingProtocol() { return this.requestingProtocol; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   protected final String getRequestingPrompt() { return this.requestingPrompt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   protected final String getDefaultUserName() { return this.requestingUserName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   protected PasswordAuthentication getPasswordAuthentication() { return null; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\Authenticator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */