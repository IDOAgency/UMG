/*    */ package javax.mail;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FolderClosedException
/*    */   extends MessagingException
/*    */ {
/*    */   private Folder folder;
/*    */   
/* 33 */   public FolderClosedException(Folder paramFolder) { this(paramFolder, null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FolderClosedException(Folder paramFolder, String paramString) {
/* 42 */     super(paramString);
/* 43 */     this.folder = paramFolder;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   public Folder getFolder() { return this.folder; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\FolderClosedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */