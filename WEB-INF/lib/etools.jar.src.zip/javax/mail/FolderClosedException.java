package javax.mail;

public class FolderClosedException extends MessagingException {
  private Folder folder;
  
  public FolderClosedException(Folder paramFolder) { this(paramFolder, null); }
  
  public FolderClosedException(Folder paramFolder, String paramString) {
    super(paramString);
    this.folder = paramFolder;
  }
  
  public Folder getFolder() { return this.folder; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\FolderClosedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */