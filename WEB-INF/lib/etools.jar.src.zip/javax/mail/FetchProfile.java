/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FetchProfile
/*     */ {
/*     */   public static class Item
/*     */   {
/*  83 */     public static final Item ENVELOPE = new Item("ENVELOPE");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     public static final Item CONTENT_INFO = new Item("CONTENT_INFO");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     public static final Item FLAGS = new Item("FLAGS");
/*     */ 
/*     */ 
/*     */     
/*     */     private String name;
/*     */ 
/*     */ 
/*     */     
/* 108 */     protected Item(String param1String) { this.name = param1String; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   private Vector specials = null;
/* 117 */   private Vector headers = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Item paramItem) {
/* 130 */     if (this.specials == null)
/* 131 */       this.specials = new Vector(); 
/* 132 */     this.specials.addElement(paramItem);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(String paramString) {
/* 142 */     if (this.headers == null)
/* 143 */       this.headers = new Vector(); 
/* 144 */     this.headers.addElement(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   public boolean contains(Item paramItem) { return !(this.specials == null || !this.specials.contains(paramItem)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   public boolean contains(String paramString) { return !(this.headers == null || !this.headers.contains(paramString)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Item[] getItems() {
/* 167 */     if (this.specials == null) {
/* 168 */       return new Item[0];
/*     */     }
/* 170 */     Item[] arrayOfItem = new Item[this.specials.size()];
/* 171 */     this.specials.copyInto(arrayOfItem);
/* 172 */     return arrayOfItem;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getHeaderNames() {
/* 181 */     if (this.headers == null) {
/* 182 */       return new String[0];
/*     */     }
/* 184 */     String[] arrayOfString = new String[this.headers.size()];
/* 185 */     this.headers.copyInto(arrayOfString);
/* 186 */     return arrayOfString;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\FetchProfile.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */