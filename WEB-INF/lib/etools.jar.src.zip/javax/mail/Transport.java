/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.mail.event.TransportEvent;
/*     */ import javax.mail.event.TransportListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Transport
/*     */   extends Service
/*     */ {
/*     */   private Vector transportListeners;
/*     */   
/*  43 */   public Transport(Session paramSession, URLName paramURLName) { super(paramSession, paramURLName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void send(Message paramMessage) throws MessagingException {
/*  72 */     paramMessage.saveChanges();
/*  73 */     send0(paramMessage, paramMessage.getAllRecipients());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void send(Message paramMessage, Address[] paramArrayOfAddress) throws MessagingException {
/*  87 */     paramMessage.saveChanges();
/*  88 */     send0(paramMessage, paramArrayOfAddress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void send0(Message paramMessage, Address[] paramArrayOfAddress) throws MessagingException {
/*  95 */     if (paramArrayOfAddress == null || paramArrayOfAddress.length == 0) {
/*  96 */       throw new SendFailedException("No recipient addresses");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     Hashtable hashtable = new Hashtable();
/*     */ 
/*     */     
/* 105 */     Vector vector1 = new Vector();
/* 106 */     Vector vector2 = new Vector();
/* 107 */     Vector vector3 = new Vector();
/*     */     
/* 109 */     for (byte b = 0; b < paramArrayOfAddress.length; b++) {
/*     */       
/* 111 */       if (hashtable.containsKey(paramArrayOfAddress[b].getType())) {
/* 112 */         Vector vector = (Vector)hashtable.get(paramArrayOfAddress[b].getType());
/* 113 */         vector.addElement(paramArrayOfAddress[b]);
/*     */       } else {
/*     */         
/* 116 */         Vector vector = new Vector();
/* 117 */         vector.addElement(paramArrayOfAddress[b]);
/* 118 */         hashtable.put(paramArrayOfAddress[b].getType(), vector);
/*     */       } 
/*     */     } 
/*     */     
/* 122 */     int i = hashtable.size();
/* 123 */     if (i == 0) {
/* 124 */       throw new SendFailedException("No recipient addresses");
/*     */     }
/* 126 */     Session session = (paramMessage.session != null) ? paramMessage.session : 
/* 127 */       Session.getDefaultInstance(System.getProperties(), null);
/*     */ 
/*     */     
/* 130 */     MessagingException messagingException = null;
/* 131 */     boolean bool = false;
/*     */     
/* 133 */     Enumeration enumeration = hashtable.elements();
/* 134 */     while (enumeration.hasMoreElements()) {
/* 135 */       Vector vector = (Vector)enumeration.nextElement();
/* 136 */       Address[] arrayOfAddress = new Address[vector.size()];
/* 137 */       vector.copyInto(arrayOfAddress);
/*     */       
/*     */       Transport transport;
/* 140 */       if ((transport = session.getTransport(arrayOfAddress[false])) == null) {
/*     */ 
/*     */         
/* 143 */         for (byte b1 = 0; b1 < arrayOfAddress.length; b1++)
/* 144 */           vector1.addElement(arrayOfAddress[b1]); 
/*     */         continue;
/*     */       } 
/*     */       try {
/* 148 */         transport.connect();
/* 149 */         transport.sendMessage(paramMessage, arrayOfAddress);
/* 150 */       } catch (SendFailedException sendFailedException) {
/* 151 */         bool = true;
/*     */         
/* 153 */         if (messagingException == null) {
/* 154 */           messagingException = sendFailedException;
/*     */         } else {
/* 156 */           messagingException.setNextException(sendFailedException);
/*     */         } 
/*     */         
/* 159 */         Address[] arrayOfAddress1 = sendFailedException.getInvalidAddresses();
/* 160 */         if (arrayOfAddress1 != null) {
/* 161 */           for (byte b1 = 0; b1 < arrayOfAddress1.length; b1++) {
/* 162 */             vector1.addElement(arrayOfAddress1[b1]);
/*     */           }
/*     */         }
/* 165 */         arrayOfAddress1 = sendFailedException.getValidSentAddresses();
/* 166 */         if (arrayOfAddress1 != null) {
/* 167 */           for (byte b1 = 0; b1 < arrayOfAddress1.length; b1++) {
/* 168 */             vector2.addElement(arrayOfAddress1[b1]);
/*     */           }
/*     */         }
/* 171 */         Address[] arrayOfAddress2 = sendFailedException.getValidUnsentAddresses();
/* 172 */         if (arrayOfAddress2 != null)
/* 173 */           for (byte b1 = 0; b1 < arrayOfAddress2.length; b1++)
/* 174 */             vector3.addElement(arrayOfAddress2[b1]);  
/* 175 */       } catch (MessagingException messagingException1) {
/* 176 */         bool = true;
/*     */         
/* 178 */         if (messagingException == null) {
/* 179 */           messagingException = messagingException1; continue;
/*     */         } 
/* 181 */         messagingException.setNextException(messagingException1);
/*     */       } finally {
/* 183 */         transport.close();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 188 */     if (bool || vector1.size() != 0 || vector3.size() != 0) {
/* 189 */       Address[] arrayOfAddress1 = null, arrayOfAddress2 = null, arrayOfAddress3 = null;
/*     */ 
/*     */       
/* 192 */       if (vector2.size() > 0) {
/* 193 */         arrayOfAddress1 = new Address[vector2.size()];
/* 194 */         vector2.copyInto(arrayOfAddress1);
/*     */       } 
/* 196 */       if (vector3.size() > 0) {
/* 197 */         arrayOfAddress2 = new Address[vector3.size()];
/* 198 */         vector3.copyInto(arrayOfAddress2);
/*     */       } 
/* 200 */       if (vector1.size() > 0) {
/* 201 */         arrayOfAddress3 = new Address[vector1.size()];
/* 202 */         vector1.copyInto(arrayOfAddress3);
/*     */       } 
/* 204 */       throw new SendFailedException("Sending failed", messagingException, 
/* 205 */           arrayOfAddress1, arrayOfAddress2, arrayOfAddress3);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void sendMessage(Message paramMessage, Address[] paramArrayOfAddress) throws MessagingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTransportListener(TransportListener paramTransportListener) {
/* 240 */     if (this.transportListeners == null)
/* 241 */       this.transportListeners = new Vector(); 
/* 242 */     this.transportListeners.addElement(paramTransportListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeTransportListener(TransportListener paramTransportListener) {
/* 255 */     if (this.transportListeners != null) {
/* 256 */       this.transportListeners.removeElement(paramTransportListener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyTransportListeners(int paramInt, Address[] paramArrayOfAddress1, Address[] paramArrayOfAddress2, Address[] paramArrayOfAddress3, Message paramMessage) {
/* 272 */     if (this.transportListeners == null) {
/*     */       return;
/*     */     }
/* 275 */     TransportEvent transportEvent = new TransportEvent(this, paramInt, paramArrayOfAddress1, 
/* 276 */         paramArrayOfAddress2, paramArrayOfAddress3, paramMessage);
/* 277 */     queueEvent(transportEvent, this.transportListeners);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\Transport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */