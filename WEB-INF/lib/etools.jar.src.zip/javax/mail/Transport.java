package javax.mail;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.mail.event.TransportEvent;
import javax.mail.event.TransportListener;

public abstract class Transport extends Service {
  private Vector transportListeners;
  
  public Transport(Session paramSession, URLName paramURLName) { super(paramSession, paramURLName); }
  
  public static void send(Message paramMessage) throws MessagingException {
    paramMessage.saveChanges();
    send0(paramMessage, paramMessage.getAllRecipients());
  }
  
  public static void send(Message paramMessage, Address[] paramArrayOfAddress) throws MessagingException {
    paramMessage.saveChanges();
    send0(paramMessage, paramArrayOfAddress);
  }
  
  private static void send0(Message paramMessage, Address[] paramArrayOfAddress) throws MessagingException {
    if (paramArrayOfAddress == null || paramArrayOfAddress.length == 0)
      throw new SendFailedException("No recipient addresses"); 
    Hashtable hashtable = new Hashtable();
    Vector vector1 = new Vector();
    Vector vector2 = new Vector();
    Vector vector3 = new Vector();
    for (byte b = 0; b < paramArrayOfAddress.length; b++) {
      if (hashtable.containsKey(paramArrayOfAddress[b].getType())) {
        Vector vector = (Vector)hashtable.get(paramArrayOfAddress[b].getType());
        vector.addElement(paramArrayOfAddress[b]);
      } else {
        Vector vector = new Vector();
        vector.addElement(paramArrayOfAddress[b]);
        hashtable.put(paramArrayOfAddress[b].getType(), vector);
      } 
    } 
    int i = hashtable.size();
    if (i == 0)
      throw new SendFailedException("No recipient addresses"); 
    Session session = (paramMessage.session != null) ? paramMessage.session : 
      Session.getDefaultInstance(System.getProperties(), null);
    MessagingException messagingException = null;
    boolean bool = false;
    Enumeration enumeration = hashtable.elements();
    while (enumeration.hasMoreElements()) {
      Vector vector = (Vector)enumeration.nextElement();
      Address[] arrayOfAddress = new Address[vector.size()];
      vector.copyInto(arrayOfAddress);
      Transport transport;
      if ((transport = session.getTransport(arrayOfAddress[false])) == null) {
        for (byte b1 = 0; b1 < arrayOfAddress.length; b1++)
          vector1.addElement(arrayOfAddress[b1]); 
        continue;
      } 
      try {
        transport.connect();
        transport.sendMessage(paramMessage, arrayOfAddress);
      } catch (SendFailedException sendFailedException) {
        bool = true;
        if (messagingException == null) {
          messagingException = sendFailedException;
        } else {
          messagingException.setNextException(sendFailedException);
        } 
        Address[] arrayOfAddress1 = sendFailedException.getInvalidAddresses();
        if (arrayOfAddress1 != null)
          for (byte b1 = 0; b1 < arrayOfAddress1.length; b1++)
            vector1.addElement(arrayOfAddress1[b1]);  
        arrayOfAddress1 = sendFailedException.getValidSentAddresses();
        if (arrayOfAddress1 != null)
          for (byte b1 = 0; b1 < arrayOfAddress1.length; b1++)
            vector2.addElement(arrayOfAddress1[b1]);  
        Address[] arrayOfAddress2 = sendFailedException.getValidUnsentAddresses();
        if (arrayOfAddress2 != null)
          for (byte b1 = 0; b1 < arrayOfAddress2.length; b1++)
            vector3.addElement(arrayOfAddress2[b1]);  
      } catch (MessagingException messagingException1) {
        bool = true;
        if (messagingException == null) {
          messagingException = messagingException1;
          continue;
        } 
        messagingException.setNextException(messagingException1);
      } finally {
        transport.close();
      } 
    } 
    if (bool || vector1.size() != 0 || vector3.size() != 0) {
      Address[] arrayOfAddress1 = null, arrayOfAddress2 = null, arrayOfAddress3 = null;
      if (vector2.size() > 0) {
        arrayOfAddress1 = new Address[vector2.size()];
        vector2.copyInto(arrayOfAddress1);
      } 
      if (vector3.size() > 0) {
        arrayOfAddress2 = new Address[vector3.size()];
        vector3.copyInto(arrayOfAddress2);
      } 
      if (vector1.size() > 0) {
        arrayOfAddress3 = new Address[vector1.size()];
        vector1.copyInto(arrayOfAddress3);
      } 
      throw new SendFailedException("Sending failed", messagingException, 
          arrayOfAddress1, arrayOfAddress2, arrayOfAddress3);
    } 
  }
  
  public abstract void sendMessage(Message paramMessage, Address[] paramArrayOfAddress) throws MessagingException;
  
  public void addTransportListener(TransportListener paramTransportListener) {
    if (this.transportListeners == null)
      this.transportListeners = new Vector(); 
    this.transportListeners.addElement(paramTransportListener);
  }
  
  public void removeTransportListener(TransportListener paramTransportListener) {
    if (this.transportListeners != null)
      this.transportListeners.removeElement(paramTransportListener); 
  }
  
  protected void notifyTransportListeners(int paramInt, Address[] paramArrayOfAddress1, Address[] paramArrayOfAddress2, Address[] paramArrayOfAddress3, Message paramMessage) {
    if (this.transportListeners == null)
      return; 
    TransportEvent transportEvent = new TransportEvent(this, paramInt, paramArrayOfAddress1, 
        paramArrayOfAddress2, paramArrayOfAddress3, paramMessage);
    queueEvent(transportEvent, this.transportListeners);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\Transport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */