package javax.mail;

import javax.activation.DataSource;

public interface MultipartDataSource extends DataSource {
  int getCount();
  
  BodyPart getBodyPart(int paramInt) throws MessagingException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\MultipartDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */