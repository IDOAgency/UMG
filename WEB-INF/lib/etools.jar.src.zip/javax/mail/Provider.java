package javax.mail;

public class Provider {
  private Type type;
  
  private String protocol;
  
  private String className;
  
  private String vendor;
  
  private String version;
  
  public static class Type {
    public static final Type STORE = new Type("Store");
    
    public static final Type TRANSPORT = new Type("Transport");
    
    private String type;
    
    private Type(String param1String) { this.type = param1String; }
  }
  
  Provider(Type paramType, String paramString1, String paramString2, String paramString3, String paramString4) {
    this.type = paramType;
    this.protocol = paramString1;
    this.className = paramString2;
    this.vendor = paramString3;
    this.version = paramString4;
  }
  
  public Type getType() { return this.type; }
  
  public String getProtocol() { return this.protocol; }
  
  public String getClassName() { return this.className; }
  
  public String getVendor() { return this.vendor; }
  
  public String getVersion() { return this.version; }
  
  public String toString() {
    null = "javax.mail.Provider[";
    if (this.type == Type.STORE) {
      null = String.valueOf(null) + "STORE,";
    } else if (this.type == Type.TRANSPORT) {
      null = String.valueOf(null) + "TRANSPORT,";
    } 
    null = String.valueOf(null) + this.protocol + "," + this.className;
    if (this.vendor != null)
      null = String.valueOf(null) + "," + this.vendor; 
    if (this.version != null)
      null = String.valueOf(null) + "," + this.version; 
    return String.valueOf(null) + "]";
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\Provider.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */