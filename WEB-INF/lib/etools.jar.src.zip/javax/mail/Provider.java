/*     */ package javax.mail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Provider
/*     */ {
/*     */   private Type type;
/*     */   private String protocol;
/*     */   private String className;
/*     */   private String vendor;
/*     */   private String version;
/*     */   
/*     */   public static class Type
/*     */   {
/*  27 */     public static final Type STORE = new Type("Store");
/*  28 */     public static final Type TRANSPORT = new Type("Transport");
/*     */     
/*     */     private String type;
/*     */ 
/*     */     
/*  33 */     private Type(String param1String) { this.type = param1String; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Provider(Type paramType, String paramString1, String paramString2, String paramString3, String paramString4) {
/*  51 */     this.type = paramType;
/*  52 */     this.protocol = paramString1;
/*  53 */     this.className = paramString2;
/*  54 */     this.vendor = paramString3;
/*  55 */     this.version = paramString4;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  60 */   public Type getType() { return this.type; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public String getProtocol() { return this.protocol; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public String getClassName() { return this.className; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public String getVendor() { return this.vendor; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public String getVersion() { return this.version; }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  85 */     null = "javax.mail.Provider[";
/*  86 */     if (this.type == Type.STORE) {
/*  87 */       null = String.valueOf(null) + "STORE,";
/*  88 */     } else if (this.type == Type.TRANSPORT) {
/*  89 */       null = String.valueOf(null) + "TRANSPORT,";
/*     */     } 
/*     */     
/*  92 */     null = String.valueOf(null) + this.protocol + "," + this.className;
/*     */     
/*  94 */     if (this.vendor != null) {
/*  95 */       null = String.valueOf(null) + "," + this.vendor;
/*     */     }
/*  97 */     if (this.version != null) {
/*  98 */       null = String.valueOf(null) + "," + this.version;
/*     */     }
/* 100 */     return String.valueOf(null) + "]";
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\javax\mail\Provider.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */