package javax.mail;

public final class PasswordAuthentication {
  private String userName;
  
  private String password;
  
  public PasswordAuthentication(String paramString1, String paramString2) {
    this.userName = paramString1;
    this.password = paramString2;
  }
  
  public String getUserName() { return this.userName; }
  
  public String getPassword() { return this.password; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\javax\mail\PasswordAuthentication.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */