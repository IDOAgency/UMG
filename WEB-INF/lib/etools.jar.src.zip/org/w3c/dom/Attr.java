package org.w3c.dom;

public interface Attr extends Node {
  String getName();
  
  boolean getSpecified();
  
  String getValue();
  
  void setValue(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\w3c\dom\Attr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */