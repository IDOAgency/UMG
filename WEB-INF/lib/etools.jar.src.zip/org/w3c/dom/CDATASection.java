package org.w3c.dom;

public interface CDATASection extends Text {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\w3c\dom\CDATASection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */