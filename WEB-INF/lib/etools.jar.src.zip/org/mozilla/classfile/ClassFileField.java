package org.mozilla.classfile;

import java.io.DataOutputStream;
import java.io.IOException;

class ClassFileField {
  private short itsNameIndex;
  
  private short itsTypeIndex;
  
  private short itsFlags;
  
  private short[] itsAttr;
  
  ClassFileField(short paramShort1, short paramShort2, short paramShort3) {
    this.itsNameIndex = paramShort1;
    this.itsTypeIndex = paramShort2;
    this.itsFlags = paramShort3;
  }
  
  ClassFileField(short paramShort1, short paramShort2, short paramShort3, short[] paramArrayOfShort) {
    this.itsNameIndex = paramShort1;
    this.itsTypeIndex = paramShort2;
    this.itsFlags = paramShort3;
    this.itsAttr = paramArrayOfShort;
  }
  
  void write(DataOutputStream paramDataOutputStream) throws IOException {
    paramDataOutputStream.writeShort(this.itsFlags);
    paramDataOutputStream.writeShort(this.itsNameIndex);
    paramDataOutputStream.writeShort(this.itsTypeIndex);
    if (this.itsAttr == null) {
      paramDataOutputStream.writeShort(0);
    } else {
      paramDataOutputStream.writeShort(1);
      paramDataOutputStream.writeShort(this.itsAttr[0]);
      paramDataOutputStream.writeShort(this.itsAttr[1]);
      paramDataOutputStream.writeShort(this.itsAttr[2]);
      paramDataOutputStream.writeShort(this.itsAttr[3]);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\classfile\ClassFileField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */