/*      */ package org.mozilla.classfile;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.util.Hashtable;
/*      */ import org.mozilla.javascript.WrappedException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class ConstantPool
/*      */ {
/* 1219 */   private int itsTopIndex = 1;
/* 1220 */   private byte[] itsPool = new byte[256];
/* 1221 */   private int itsTop = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void write(DataOutputStream paramDataOutputStream) throws IOException {
/* 1240 */     paramDataOutputStream.writeShort((short)this.itsTopIndex);
/* 1241 */     paramDataOutputStream.write(this.itsPool, 0, this.itsTop);
/*      */   }
/*      */ 
/*      */   
/*      */   short addConstant(int paramInt) {
/* 1246 */     ensure(5);
/* 1247 */     this.itsPool[this.itsTop++] = 3;
/* 1248 */     this.itsPool[this.itsTop++] = (byte)(paramInt >> 24);
/* 1249 */     this.itsPool[this.itsTop++] = (byte)(paramInt >> 16);
/* 1250 */     this.itsPool[this.itsTop++] = (byte)(paramInt >> 8);
/* 1251 */     this.itsPool[this.itsTop++] = (byte)paramInt;
/* 1252 */     return (short)this.itsTopIndex++;
/*      */   }
/*      */ 
/*      */   
/*      */   short addConstant(long paramLong) {
/* 1257 */     ensure(9);
/* 1258 */     this.itsPool[this.itsTop++] = 5;
/* 1259 */     this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 56);
/* 1260 */     this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 48);
/* 1261 */     this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 40);
/* 1262 */     this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 32);
/* 1263 */     this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 24);
/* 1264 */     this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 16);
/* 1265 */     this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 8);
/* 1266 */     this.itsPool[this.itsTop++] = (byte)(int)paramLong;
/* 1267 */     short s = (short)this.itsTopIndex;
/* 1268 */     this.itsTopIndex += 2;
/* 1269 */     return s;
/*      */   }
/*      */ 
/*      */   
/*      */   short addConstant(float paramFloat) {
/* 1274 */     ensure(5);
/* 1275 */     this.itsPool[this.itsTop++] = 4;
/* 1276 */     int i = Float.floatToIntBits(paramFloat);
/* 1277 */     this.itsPool[this.itsTop++] = (byte)(i >> 24);
/* 1278 */     this.itsPool[this.itsTop++] = (byte)(i >> 16);
/* 1279 */     this.itsPool[this.itsTop++] = (byte)(i >> 8);
/* 1280 */     this.itsPool[this.itsTop++] = (byte)i;
/* 1281 */     return (short)this.itsTopIndex++;
/*      */   }
/*      */ 
/*      */   
/*      */   short addConstant(double paramDouble) {
/* 1286 */     ensure(9);
/* 1287 */     this.itsPool[this.itsTop++] = 6;
/* 1288 */     long l = Double.doubleToLongBits(paramDouble);
/* 1289 */     this.itsPool[this.itsTop++] = (byte)(int)(l >> 56);
/* 1290 */     this.itsPool[this.itsTop++] = (byte)(int)(l >> 48);
/* 1291 */     this.itsPool[this.itsTop++] = (byte)(int)(l >> 40);
/* 1292 */     this.itsPool[this.itsTop++] = (byte)(int)(l >> 32);
/* 1293 */     this.itsPool[this.itsTop++] = (byte)(int)(l >> 24);
/* 1294 */     this.itsPool[this.itsTop++] = (byte)(int)(l >> 16);
/* 1295 */     this.itsPool[this.itsTop++] = (byte)(int)(l >> 8);
/* 1296 */     this.itsPool[this.itsTop++] = (byte)(int)l;
/* 1297 */     short s = (short)this.itsTopIndex;
/* 1298 */     this.itsTopIndex += 2;
/* 1299 */     return s;
/*      */   }
/*      */ 
/*      */   
/*      */   short addConstant(String paramString) {
/* 1304 */     Utf8StringIndexPair utf8StringIndexPair = (Utf8StringIndexPair)this.itsUtf8Hash.get(paramString);
/* 1305 */     if (utf8StringIndexPair == null) {
/* 1306 */       addUtf8(paramString);
/* 1307 */       utf8StringIndexPair = (Utf8StringIndexPair)this.itsUtf8Hash.get(paramString);
/*      */     } 
/* 1309 */     if (utf8StringIndexPair.itsStringIndex == -1) {
/* 1310 */       utf8StringIndexPair.itsStringIndex = (short)this.itsTopIndex++;
/* 1311 */       ensure(3);
/* 1312 */       this.itsPool[this.itsTop++] = 8;
/* 1313 */       this.itsPool[this.itsTop++] = (byte)(utf8StringIndexPair.itsUtf8Index >> 8);
/* 1314 */       this.itsPool[this.itsTop++] = (byte)utf8StringIndexPair.itsUtf8Index;
/*      */     } 
/* 1316 */     return utf8StringIndexPair.itsStringIndex;
/*      */   }
/*      */ 
/*      */   
/*      */   short addUtf8(String paramString) {
/* 1321 */     Utf8StringIndexPair utf8StringIndexPair = (Utf8StringIndexPair)this.itsUtf8Hash.get(paramString);
/* 1322 */     if (utf8StringIndexPair == null) {
/* 1323 */       utf8StringIndexPair = new Utf8StringIndexPair((short)this.itsTopIndex++, (short)-1);
/* 1324 */       this.itsUtf8Hash.put(paramString, utf8StringIndexPair);
/*      */       
/*      */       try {
/* 1327 */         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 1328 */         DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
/* 1329 */         dataOutputStream.writeUTF(paramString);
/* 1330 */         byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
/* 1331 */         ensure(1 + arrayOfByte.length);
/* 1332 */         this.itsPool[this.itsTop++] = 1;
/* 1333 */         System.arraycopy(arrayOfByte, 0, this.itsPool, this.itsTop, arrayOfByte.length);
/* 1334 */         this.itsTop += arrayOfByte.length;
/*      */       }
/* 1336 */       catch (IOException iOException) {
/* 1337 */         throw WrappedException.wrapException(iOException);
/*      */       } 
/*      */     } 
/* 1340 */     return utf8StringIndexPair.itsUtf8Index;
/*      */   }
/*      */ 
/*      */   
/*      */   short addNameAndType(short paramShort1, short paramShort2) {
/* 1345 */     ensure(5);
/* 1346 */     this.itsPool[this.itsTop++] = 12;
/* 1347 */     this.itsPool[this.itsTop++] = (byte)(paramShort1 >> 8);
/* 1348 */     this.itsPool[this.itsTop++] = (byte)paramShort1;
/* 1349 */     this.itsPool[this.itsTop++] = (byte)(paramShort2 >> 8);
/* 1350 */     this.itsPool[this.itsTop++] = (byte)paramShort2;
/* 1351 */     return (short)this.itsTopIndex++;
/*      */   }
/*      */ 
/*      */   
/*      */   short addClass(short paramShort) {
/* 1356 */     Short short1 = new Short(paramShort);
/* 1357 */     Short short2 = (Short)this.itsClassHash.get(short1);
/* 1358 */     if (short2 == null) {
/* 1359 */       ensure(3);
/* 1360 */       this.itsPool[this.itsTop++] = 7;
/* 1361 */       this.itsPool[this.itsTop++] = (byte)(paramShort >> 8);
/* 1362 */       this.itsPool[this.itsTop++] = (byte)paramShort;
/* 1363 */       short2 = new Short((short)this.itsTopIndex++);
/* 1364 */       this.itsClassHash.put(short1, short2);
/*      */     } 
/* 1366 */     return short2.shortValue();
/*      */   }
/*      */ 
/*      */   
/*      */   short addClass(String paramString) {
/* 1371 */     short s = 
/* 1372 */       addUtf8(ClassFileWriter.fullyQualifiedForm(paramString));
/* 1373 */     return addClass(s);
/*      */   }
/*      */ 
/*      */   
/*      */   short addFieldRef(String paramString1, String paramString2, String paramString3) {
/* 1378 */     String str = String.valueOf(paramString1) + " " + paramString2 + " " + paramString3;
/* 1379 */     Short short = (Short)this.itsFieldRefHash.get(str);
/* 1380 */     if (short == null) {
/* 1381 */       short s1 = addUtf8(paramString2);
/* 1382 */       short s2 = addUtf8(paramString3);
/* 1383 */       short s3 = addNameAndType(s1, s2);
/* 1384 */       short s4 = addClass(paramString1);
/* 1385 */       ensure(5);
/* 1386 */       this.itsPool[this.itsTop++] = 9;
/* 1387 */       this.itsPool[this.itsTop++] = (byte)(s4 >> 8);
/* 1388 */       this.itsPool[this.itsTop++] = (byte)s4;
/* 1389 */       this.itsPool[this.itsTop++] = (byte)(s3 >> 8);
/* 1390 */       this.itsPool[this.itsTop++] = (byte)s3;
/* 1391 */       short = new Short((short)this.itsTopIndex++);
/* 1392 */       this.itsFieldRefHash.put(str, short);
/*      */     } 
/* 1394 */     return short.shortValue();
/*      */   }
/*      */ 
/*      */   
/*      */   short addMethodRef(String paramString1, String paramString2, String paramString3) {
/* 1399 */     String str = String.valueOf(paramString1) + " " + paramString2 + " " + paramString3;
/* 1400 */     Short short = (Short)this.itsMethodRefHash.get(str);
/* 1401 */     if (short == null) {
/* 1402 */       short s1 = addUtf8(paramString2);
/* 1403 */       short s2 = addUtf8(paramString3);
/* 1404 */       short s3 = addNameAndType(s1, s2);
/* 1405 */       short s4 = addClass(paramString1);
/* 1406 */       ensure(5);
/* 1407 */       this.itsPool[this.itsTop++] = 10;
/* 1408 */       this.itsPool[this.itsTop++] = (byte)(s4 >> 8);
/* 1409 */       this.itsPool[this.itsTop++] = (byte)s4;
/* 1410 */       this.itsPool[this.itsTop++] = (byte)(s3 >> 8);
/* 1411 */       this.itsPool[this.itsTop++] = (byte)s3;
/* 1412 */       short = new Short((short)this.itsTopIndex++);
/* 1413 */       this.itsMethodRefHash.put(str, short);
/*      */     } 
/* 1415 */     return short.shortValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   short addInterfaceMethodRef(String paramString1, String paramString2, String paramString3) {
/* 1421 */     short s1 = addUtf8(paramString2);
/* 1422 */     short s2 = addUtf8(paramString3);
/* 1423 */     short s3 = addNameAndType(s1, s2);
/* 1424 */     short s4 = addClass(paramString1);
/* 1425 */     ensure(5);
/* 1426 */     this.itsPool[this.itsTop++] = 11;
/* 1427 */     this.itsPool[this.itsTop++] = (byte)(s4 >> 8);
/* 1428 */     this.itsPool[this.itsTop++] = (byte)s4;
/* 1429 */     this.itsPool[this.itsTop++] = (byte)(s3 >> 8);
/* 1430 */     this.itsPool[this.itsTop++] = (byte)s3;
/* 1431 */     return (short)this.itsTopIndex++;
/*      */   }
/*      */ 
/*      */   
/*      */   void ensure(int paramInt) {
/* 1436 */     while (this.itsTop + paramInt >= this.itsPool.length) {
/* 1437 */       byte[] arrayOfByte = this.itsPool;
/* 1438 */       this.itsPool = new byte[this.itsPool.length * 2];
/* 1439 */       System.arraycopy(arrayOfByte, 0, this.itsPool, 0, this.itsTop);
/*      */     } 
/*      */   }
/*      */   
/* 1443 */   private Hashtable itsUtf8Hash = new Hashtable();
/* 1444 */   private Hashtable itsFieldRefHash = new Hashtable();
/* 1445 */   private Hashtable itsMethodRefHash = new Hashtable();
/* 1446 */   private Hashtable itsClassHash = new Hashtable();
/*      */   private static final int ConstantPoolSize = 256;
/*      */   private static final byte CONSTANT_Class = 7;
/*      */   private static final byte CONSTANT_Fieldref = 9;
/*      */   private static final byte CONSTANT_Methodref = 10;
/*      */   private static final byte CONSTANT_InterfaceMethodref = 11;
/*      */   private static final byte CONSTANT_String = 8;
/*      */   private static final byte CONSTANT_Integer = 3;
/*      */   private static final byte CONSTANT_Float = 4;
/*      */   private static final byte CONSTANT_Long = 5;
/*      */   private static final byte CONSTANT_Double = 6;
/*      */   private static final byte CONSTANT_NameAndType = 12;
/*      */   private static final byte CONSTANT_Utf8 = 1;
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\classfile\ConstantPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */