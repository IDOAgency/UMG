package org.mozilla.classfile;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Hashtable;
import org.mozilla.javascript.WrappedException;

class ConstantPool {
  private int itsTopIndex = 1;
  
  private byte[] itsPool = new byte[256];
  
  private int itsTop = 0;
  
  void write(DataOutputStream paramDataOutputStream) throws IOException {
    paramDataOutputStream.writeShort((short)this.itsTopIndex);
    paramDataOutputStream.write(this.itsPool, 0, this.itsTop);
  }
  
  short addConstant(int paramInt) {
    ensure(5);
    this.itsPool[this.itsTop++] = 3;
    this.itsPool[this.itsTop++] = (byte)(paramInt >> 24);
    this.itsPool[this.itsTop++] = (byte)(paramInt >> 16);
    this.itsPool[this.itsTop++] = (byte)(paramInt >> 8);
    this.itsPool[this.itsTop++] = (byte)paramInt;
    return (short)this.itsTopIndex++;
  }
  
  short addConstant(long paramLong) {
    ensure(9);
    this.itsPool[this.itsTop++] = 5;
    this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 56);
    this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 48);
    this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 40);
    this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 32);
    this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 24);
    this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 16);
    this.itsPool[this.itsTop++] = (byte)(int)(paramLong >> 8);
    this.itsPool[this.itsTop++] = (byte)(int)paramLong;
    short s = (short)this.itsTopIndex;
    this.itsTopIndex += 2;
    return s;
  }
  
  short addConstant(float paramFloat) {
    ensure(5);
    this.itsPool[this.itsTop++] = 4;
    int i = Float.floatToIntBits(paramFloat);
    this.itsPool[this.itsTop++] = (byte)(i >> 24);
    this.itsPool[this.itsTop++] = (byte)(i >> 16);
    this.itsPool[this.itsTop++] = (byte)(i >> 8);
    this.itsPool[this.itsTop++] = (byte)i;
    return (short)this.itsTopIndex++;
  }
  
  short addConstant(double paramDouble) {
    ensure(9);
    this.itsPool[this.itsTop++] = 6;
    long l = Double.doubleToLongBits(paramDouble);
    this.itsPool[this.itsTop++] = (byte)(int)(l >> 56);
    this.itsPool[this.itsTop++] = (byte)(int)(l >> 48);
    this.itsPool[this.itsTop++] = (byte)(int)(l >> 40);
    this.itsPool[this.itsTop++] = (byte)(int)(l >> 32);
    this.itsPool[this.itsTop++] = (byte)(int)(l >> 24);
    this.itsPool[this.itsTop++] = (byte)(int)(l >> 16);
    this.itsPool[this.itsTop++] = (byte)(int)(l >> 8);
    this.itsPool[this.itsTop++] = (byte)(int)l;
    short s = (short)this.itsTopIndex;
    this.itsTopIndex += 2;
    return s;
  }
  
  short addConstant(String paramString) {
    Utf8StringIndexPair utf8StringIndexPair = (Utf8StringIndexPair)this.itsUtf8Hash.get(paramString);
    if (utf8StringIndexPair == null) {
      addUtf8(paramString);
      utf8StringIndexPair = (Utf8StringIndexPair)this.itsUtf8Hash.get(paramString);
    } 
    if (utf8StringIndexPair.itsStringIndex == -1) {
      utf8StringIndexPair.itsStringIndex = (short)this.itsTopIndex++;
      ensure(3);
      this.itsPool[this.itsTop++] = 8;
      this.itsPool[this.itsTop++] = (byte)(utf8StringIndexPair.itsUtf8Index >> 8);
      this.itsPool[this.itsTop++] = (byte)utf8StringIndexPair.itsUtf8Index;
    } 
    return utf8StringIndexPair.itsStringIndex;
  }
  
  short addUtf8(String paramString) {
    Utf8StringIndexPair utf8StringIndexPair = (Utf8StringIndexPair)this.itsUtf8Hash.get(paramString);
    if (utf8StringIndexPair == null) {
      utf8StringIndexPair = new Utf8StringIndexPair((short)this.itsTopIndex++, (short)-1);
      this.itsUtf8Hash.put(paramString, utf8StringIndexPair);
      try {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
        dataOutputStream.writeUTF(paramString);
        byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
        ensure(1 + arrayOfByte.length);
        this.itsPool[this.itsTop++] = 1;
        System.arraycopy(arrayOfByte, 0, this.itsPool, this.itsTop, arrayOfByte.length);
        this.itsTop += arrayOfByte.length;
      } catch (IOException iOException) {
        throw WrappedException.wrapException(iOException);
      } 
    } 
    return utf8StringIndexPair.itsUtf8Index;
  }
  
  short addNameAndType(short paramShort1, short paramShort2) {
    ensure(5);
    this.itsPool[this.itsTop++] = 12;
    this.itsPool[this.itsTop++] = (byte)(paramShort1 >> 8);
    this.itsPool[this.itsTop++] = (byte)paramShort1;
    this.itsPool[this.itsTop++] = (byte)(paramShort2 >> 8);
    this.itsPool[this.itsTop++] = (byte)paramShort2;
    return (short)this.itsTopIndex++;
  }
  
  short addClass(short paramShort) {
    Short short1 = new Short(paramShort);
    Short short2 = (Short)this.itsClassHash.get(short1);
    if (short2 == null) {
      ensure(3);
      this.itsPool[this.itsTop++] = 7;
      this.itsPool[this.itsTop++] = (byte)(paramShort >> 8);
      this.itsPool[this.itsTop++] = (byte)paramShort;
      short2 = new Short((short)this.itsTopIndex++);
      this.itsClassHash.put(short1, short2);
    } 
    return short2.shortValue();
  }
  
  short addClass(String paramString) {
    short s = 
      addUtf8(ClassFileWriter.fullyQualifiedForm(paramString));
    return addClass(s);
  }
  
  short addFieldRef(String paramString1, String paramString2, String paramString3) {
    String str = String.valueOf(paramString1) + " " + paramString2 + " " + paramString3;
    Short short = (Short)this.itsFieldRefHash.get(str);
    if (short == null) {
      short s1 = addUtf8(paramString2);
      short s2 = addUtf8(paramString3);
      short s3 = addNameAndType(s1, s2);
      short s4 = addClass(paramString1);
      ensure(5);
      this.itsPool[this.itsTop++] = 9;
      this.itsPool[this.itsTop++] = (byte)(s4 >> 8);
      this.itsPool[this.itsTop++] = (byte)s4;
      this.itsPool[this.itsTop++] = (byte)(s3 >> 8);
      this.itsPool[this.itsTop++] = (byte)s3;
      short = new Short((short)this.itsTopIndex++);
      this.itsFieldRefHash.put(str, short);
    } 
    return short.shortValue();
  }
  
  short addMethodRef(String paramString1, String paramString2, String paramString3) {
    String str = String.valueOf(paramString1) + " " + paramString2 + " " + paramString3;
    Short short = (Short)this.itsMethodRefHash.get(str);
    if (short == null) {
      short s1 = addUtf8(paramString2);
      short s2 = addUtf8(paramString3);
      short s3 = addNameAndType(s1, s2);
      short s4 = addClass(paramString1);
      ensure(5);
      this.itsPool[this.itsTop++] = 10;
      this.itsPool[this.itsTop++] = (byte)(s4 >> 8);
      this.itsPool[this.itsTop++] = (byte)s4;
      this.itsPool[this.itsTop++] = (byte)(s3 >> 8);
      this.itsPool[this.itsTop++] = (byte)s3;
      short = new Short((short)this.itsTopIndex++);
      this.itsMethodRefHash.put(str, short);
    } 
    return short.shortValue();
  }
  
  short addInterfaceMethodRef(String paramString1, String paramString2, String paramString3) {
    short s1 = addUtf8(paramString2);
    short s2 = addUtf8(paramString3);
    short s3 = addNameAndType(s1, s2);
    short s4 = addClass(paramString1);
    ensure(5);
    this.itsPool[this.itsTop++] = 11;
    this.itsPool[this.itsTop++] = (byte)(s4 >> 8);
    this.itsPool[this.itsTop++] = (byte)s4;
    this.itsPool[this.itsTop++] = (byte)(s3 >> 8);
    this.itsPool[this.itsTop++] = (byte)s3;
    return (short)this.itsTopIndex++;
  }
  
  void ensure(int paramInt) {
    while (this.itsTop + paramInt >= this.itsPool.length) {
      byte[] arrayOfByte = this.itsPool;
      this.itsPool = new byte[this.itsPool.length * 2];
      System.arraycopy(arrayOfByte, 0, this.itsPool, 0, this.itsTop);
    } 
  }
  
  private Hashtable itsUtf8Hash = new Hashtable();
  
  private Hashtable itsFieldRefHash = new Hashtable();
  
  private Hashtable itsMethodRefHash = new Hashtable();
  
  private Hashtable itsClassHash = new Hashtable();
  
  private static final int ConstantPoolSize = 256;
  
  private static final byte CONSTANT_Class = 7;
  
  private static final byte CONSTANT_Fieldref = 9;
  
  private static final byte CONSTANT_Methodref = 10;
  
  private static final byte CONSTANT_InterfaceMethodref = 11;
  
  private static final byte CONSTANT_String = 8;
  
  private static final byte CONSTANT_Integer = 3;
  
  private static final byte CONSTANT_Float = 4;
  
  private static final byte CONSTANT_Long = 5;
  
  private static final byte CONSTANT_Double = 6;
  
  private static final byte CONSTANT_NameAndType = 12;
  
  private static final byte CONSTANT_Utf8 = 1;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\classfile\ConstantPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */