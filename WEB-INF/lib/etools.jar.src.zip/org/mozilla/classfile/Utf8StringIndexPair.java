package org.mozilla.classfile;

class Utf8StringIndexPair {
  short itsUtf8Index;
  
  short itsStringIndex;
  
  Utf8StringIndexPair(short paramShort1, short paramShort2) {
    this.itsUtf8Index = paramShort1;
    this.itsStringIndex = paramShort2;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\classfile\Utf8StringIndexPair.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */