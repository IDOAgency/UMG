package org.mozilla.classfile;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Vector;
import org.mozilla.javascript.LabelTable;
import org.mozilla.javascript.LocalVariable;
import org.mozilla.javascript.VariableTable;

public class ClassFileWriter extends LabelTable {
  public static final short ACC_PUBLIC = 1;
  
  public static final short ACC_PRIVATE = 2;
  
  public static final short ACC_PROTECTED = 4;
  
  public static final short ACC_STATIC = 8;
  
  public static final short ACC_FINAL = 16;
  
  public static final short ACC_SYNCHRONIZED = 32;
  
  public static final short ACC_VOLATILE = 64;
  
  public static final short ACC_TRANSIENT = 128;
  
  public static final short ACC_NATIVE = 256;
  
  public static final short ACC_ABSTRACT = 1024;
  
  private static final int LineNumberTableSize = 16;
  
  private static final int ExceptionTableSize = 4;
  
  private static final long FileHeaderConstant = -3819410108756852691L;
  
  private static final boolean DEBUG = false;
  
  private static final boolean DEBUGSTACK = false;
  
  private static final boolean DEBUGLABELS = false;
  
  private static final boolean DEBUGCODE = false;
  
  private static final int CodeBufferSize = 128;
  
  private ExceptionTableEntry[] itsExceptionTable;
  
  private int itsExceptionTableTop;
  
  private int[] itsLineNumberTable;
  
  private int itsLineNumberTableTop;
  
  private byte[] itsCodeBuffer;
  
  private int itsCodeBufferTop;
  
  private ConstantPool itsConstantPool;
  
  private short itsSourceFileAttributeIndex;
  
  private ClassFileMethod itsCurrentMethod;
  
  private short itsStackTop;
  
  private short itsMaxStack;
  
  private short itsMaxLocals;
  
  private Vector itsMethods;
  
  private Vector itsFields;
  
  private Vector itsInterfaces;
  
  private short itsFlags;
  
  private short itsThisClassIndex;
  
  private short itsSuperClassIndex;
  
  private short itsSourceFileNameIndex;
  
  public ClassFileWriter(String paramString1, String paramString2, String paramString3) {
    this.itsMethods = new Vector();
    this.itsFields = new Vector();
    this.itsInterfaces = new Vector();
    this.itsConstantPool = new ConstantPool();
    this.itsThisClassIndex = this.itsConstantPool.addClass(paramString1);
    this.itsSuperClassIndex = this.itsConstantPool.addClass(paramString2);
    if (paramString3 != null)
      this.itsSourceFileNameIndex = this.itsConstantPool.addUtf8(paramString3); 
    this.itsFlags = 1;
  }
  
  public void addInterface(String paramString) {
    short s = this.itsConstantPool.addClass(paramString);
    this.itsInterfaces.addElement(new Short(s));
  }
  
  public void setFlags(short paramShort) { this.itsFlags = paramShort; }
  
  public static String fullyQualifiedForm(String paramString) { return paramString.replace('.', '/'); }
  
  public void addField(String paramString1, String paramString2, short paramShort) {
    short s1 = this.itsConstantPool.addUtf8(paramString1);
    short s2 = this.itsConstantPool.addUtf8(paramString2);
    this.itsFields.addElement(new ClassFileField(s1, s2, paramShort));
  }
  
  public void addField(String paramString1, String paramString2, short paramShort, int paramInt) {
    short s1 = this.itsConstantPool.addUtf8(paramString1);
    short s2 = this.itsConstantPool.addUtf8(paramString2);
    short[] arrayOfShort = new short[4];
    arrayOfShort[0] = this.itsConstantPool.addUtf8("ConstantValue");
    arrayOfShort[1] = 0;
    arrayOfShort[2] = 2;
    arrayOfShort[3] = this.itsConstantPool.addConstant(paramInt);
    this.itsFields.addElement(new ClassFileField(s1, s2, paramShort, arrayOfShort));
  }
  
  public void addField(String paramString1, String paramString2, short paramShort, long paramLong) {
    short s1 = this.itsConstantPool.addUtf8(paramString1);
    short s2 = this.itsConstantPool.addUtf8(paramString2);
    short[] arrayOfShort = new short[4];
    arrayOfShort[0] = this.itsConstantPool.addUtf8("ConstantValue");
    arrayOfShort[1] = 0;
    arrayOfShort[2] = 2;
    arrayOfShort[3] = this.itsConstantPool.addConstant(paramLong);
    this.itsFields.addElement(new ClassFileField(s1, s2, paramShort, arrayOfShort));
  }
  
  public void addField(String paramString1, String paramString2, short paramShort, double paramDouble) {
    short s1 = this.itsConstantPool.addUtf8(paramString1);
    short s2 = this.itsConstantPool.addUtf8(paramString2);
    short[] arrayOfShort = new short[4];
    arrayOfShort[0] = this.itsConstantPool.addUtf8("ConstantValue");
    arrayOfShort[1] = 0;
    arrayOfShort[2] = 2;
    arrayOfShort[3] = this.itsConstantPool.addConstant(paramDouble);
    this.itsFields.addElement(new ClassFileField(s1, s2, paramShort, arrayOfShort));
  }
  
  public void startMethod(String paramString1, String paramString2, short paramShort) {
    short s1 = this.itsConstantPool.addUtf8(paramString1);
    short s2 = this.itsConstantPool.addUtf8(paramString2);
    this.itsCurrentMethod = new ClassFileMethod(s1, s2, paramShort);
    this.itsMethods.addElement(this.itsCurrentMethod);
  }
  
  public void stopMethod(short paramShort, VariableTable paramVariableTable) {
    for (byte b1 = 0; b1 < this.itsLabelTableTop; b1++)
      this.itsLabelTable[b1].fixGotos(this.itsCodeBuffer); 
    this.itsMaxLocals = paramShort;
    int i = 0;
    if (this.itsLineNumberTable != null)
      i = 8 + this.itsLineNumberTableTop * 4; 
    int j = 0;
    if (paramVariableTable != null)
      j = 8 + paramVariableTable.size() * 10; 
    int k = 14 + this.itsCodeBufferTop + 2 + this.itsExceptionTableTop * 8 + 2 + i + j;
    byte[] arrayOfByte = new byte[k];
    int m = 0;
    short s = this.itsConstantPool.addUtf8("Code");
    arrayOfByte[m++] = (byte)(s >> 8);
    arrayOfByte[m++] = (byte)s;
    k -= 6;
    arrayOfByte[m++] = (byte)(k >> 24);
    arrayOfByte[m++] = (byte)(k >> 16);
    arrayOfByte[m++] = (byte)(k >> 8);
    arrayOfByte[m++] = (byte)k;
    arrayOfByte[m++] = (byte)(this.itsMaxStack >> 8);
    arrayOfByte[m++] = (byte)this.itsMaxStack;
    arrayOfByte[m++] = (byte)(this.itsMaxLocals >> 8);
    arrayOfByte[m++] = (byte)this.itsMaxLocals;
    arrayOfByte[m++] = (byte)(this.itsCodeBufferTop >> 24);
    arrayOfByte[m++] = (byte)(this.itsCodeBufferTop >> 16);
    arrayOfByte[m++] = (byte)(this.itsCodeBufferTop >> 8);
    arrayOfByte[m++] = (byte)this.itsCodeBufferTop;
    System.arraycopy(this.itsCodeBuffer, 0, arrayOfByte, m, this.itsCodeBufferTop);
    m += this.itsCodeBufferTop;
    if (this.itsExceptionTableTop > 0) {
      arrayOfByte[m++] = (byte)(this.itsExceptionTableTop >> 8);
      arrayOfByte[m++] = (byte)this.itsExceptionTableTop;
      for (byte b = 0; b < this.itsExceptionTableTop; b++) {
        short s1 = this.itsExceptionTable[b].getStartPC(this.itsLabelTable);
        arrayOfByte[m++] = (byte)(s1 >> 8);
        arrayOfByte[m++] = (byte)s1;
        short s2 = this.itsExceptionTable[b].getEndPC(this.itsLabelTable);
        arrayOfByte[m++] = (byte)(s2 >> 8);
        arrayOfByte[m++] = (byte)s2;
        short s3 = this.itsExceptionTable[b].getHandlerPC(this.itsLabelTable);
        arrayOfByte[m++] = (byte)(s3 >> 8);
        arrayOfByte[m++] = (byte)s3;
        short s4 = this.itsExceptionTable[b].getCatchType();
        arrayOfByte[m++] = (byte)(s4 >> 8);
        arrayOfByte[m++] = (byte)s4;
      } 
    } else {
      arrayOfByte[m++] = 0;
      arrayOfByte[m++] = 0;
    } 
    byte b2 = 0;
    if (this.itsLineNumberTable != null)
      b2++; 
    if (paramVariableTable != null)
      b2++; 
    arrayOfByte[m++] = 0;
    arrayOfByte[m++] = (byte)b2;
    if (this.itsLineNumberTable != null) {
      short s1 = this.itsConstantPool.addUtf8("LineNumberTable");
      arrayOfByte[m++] = (byte)(s1 >> 8);
      arrayOfByte[m++] = (byte)s1;
      int n = 2 + this.itsLineNumberTableTop * 4;
      arrayOfByte[m++] = (byte)(n >> 24);
      arrayOfByte[m++] = (byte)(n >> 16);
      arrayOfByte[m++] = (byte)(n >> 8);
      arrayOfByte[m++] = (byte)n;
      arrayOfByte[m++] = (byte)(this.itsLineNumberTableTop >> 8);
      arrayOfByte[m++] = (byte)this.itsLineNumberTableTop;
      for (byte b = 0; b < this.itsLineNumberTableTop; b++) {
        arrayOfByte[m++] = (byte)(this.itsLineNumberTable[b] >> 24);
        arrayOfByte[m++] = (byte)(this.itsLineNumberTable[b] >> 16);
        arrayOfByte[m++] = (byte)(this.itsLineNumberTable[b] >> 8);
        arrayOfByte[m++] = (byte)this.itsLineNumberTable[b];
      } 
    } 
    if (paramVariableTable != null) {
      short s1 = this.itsConstantPool.addUtf8("LocalVariableTable");
      arrayOfByte[m++] = (byte)(s1 >> 8);
      arrayOfByte[m++] = (byte)s1;
      int n = paramVariableTable.size();
      int i1 = 2 + n * 10;
      arrayOfByte[m++] = (byte)(i1 >> 24);
      arrayOfByte[m++] = (byte)(i1 >> 16);
      arrayOfByte[m++] = (byte)(i1 >> 8);
      arrayOfByte[m++] = (byte)i1;
      arrayOfByte[m++] = (byte)(n >> 8);
      arrayOfByte[m++] = (byte)n;
      for (byte b = 0; b < n; b++) {
        LocalVariable localVariable = paramVariableTable.get(b);
        int i2 = localVariable.getStartPC();
        arrayOfByte[m++] = (byte)(i2 >> 8);
        arrayOfByte[m++] = (byte)i2;
        int i3 = this.itsCodeBufferTop - i2;
        arrayOfByte[m++] = (byte)(i3 >> 8);
        arrayOfByte[m++] = (byte)i3;
        short s2 = this.itsConstantPool.addUtf8(localVariable.getName());
        arrayOfByte[m++] = (byte)(s2 >> 8);
        arrayOfByte[m++] = (byte)s2;
        short s3 = this.itsConstantPool.addUtf8(localVariable.isNumber() ? "D" : "Ljava/lang/Object;");
        arrayOfByte[m++] = (byte)(s3 >> 8);
        arrayOfByte[m++] = (byte)s3;
        short s4 = localVariable.getJRegister();
        arrayOfByte[m++] = (byte)(s4 >> 8);
        arrayOfByte[m++] = (byte)s4;
      } 
    } 
    this.itsCurrentMethod.setCodeAttribute(arrayOfByte);
    this.itsExceptionTable = null;
    this.itsExceptionTableTop = 0;
    this.itsLabelTableTop = 0;
    this.itsLineNumberTable = null;
    this.itsCodeBufferTop = 0;
    this.itsCurrentMethod = null;
    this.itsMaxStack = 0;
    this.itsStackTop = 0;
  }
  
  public void add(byte paramByte) {
    addToCodeBuffer(paramByte);
    this.itsStackTop = (short)(this.itsStackTop + ByteCode.stackChange[paramByte & 0xFF]);
    if (this.itsStackTop > this.itsMaxStack)
      this.itsMaxStack = this.itsStackTop; 
  }
  
  public void add(byte paramByte, int paramInt) {
    int i;
    this.itsStackTop = (short)(this.itsStackTop + ByteCode.stackChange[paramByte & 0xFF]);
    if (this.itsStackTop > this.itsMaxStack)
      this.itsMaxStack = this.itsStackTop; 
    switch (paramByte) {
      case -103:
      case -102:
      case -101:
      case -100:
      case -99:
      case -98:
      case -97:
      case -96:
      case -95:
      case -94:
      case -93:
      case -92:
      case -91:
      case -90:
      case -89:
      case -88:
      case -58:
      case -57:
        i = this.itsCodeBufferTop;
        addToCodeBuffer(paramByte);
        if ((paramInt & 0x80000000) != Integer.MIN_VALUE) {
          int j = acquireLabel();
          int k = j & 0x7FFFFFFF;
          this.itsLabelTable[k].setPC((short)(i + paramInt));
          addToCodeBuffer((byte)(paramInt >> 8));
          addToCodeBuffer((byte)paramInt);
        } else {
          int j = paramInt & 0x7FFFFFFF;
          short s = this.itsLabelTable[j].getPC();
          if (s != -1) {
            short s1 = (short)(s - i);
            addToCodeBuffer((byte)(s1 >> 8));
            addToCodeBuffer((byte)s1);
          } else {
            this.itsLabelTable[j].addFixup(i + 1);
            addToCodeBuffer((byte)0);
            addToCodeBuffer((byte)0);
          } 
        } 
        return;
      case 16:
        addToCodeBuffer(paramByte);
        addToCodeBuffer((byte)paramInt);
        return;
      case 17:
        addToCodeBuffer(paramByte);
        addToCodeBuffer((byte)(paramInt >> 8));
        addToCodeBuffer((byte)paramInt);
        return;
      case -68:
        addToCodeBuffer(paramByte);
        addToCodeBuffer((byte)paramInt);
        return;
      case -76:
      case -75:
        addToCodeBuffer(paramByte);
        addToCodeBuffer((byte)(paramInt >> 8));
        addToCodeBuffer((byte)paramInt);
        return;
      case 18:
      case 19:
      case 20:
        if (paramInt >= 256 || paramByte == 19 || paramByte == 20) {
          if (paramByte == 18) {
            addToCodeBuffer((byte)19);
          } else {
            addToCodeBuffer(paramByte);
          } 
          addToCodeBuffer((byte)(paramInt >> 8));
          addToCodeBuffer((byte)paramInt);
        } else {
          addToCodeBuffer(paramByte);
          addToCodeBuffer((byte)paramInt);
        } 
        return;
      case -87:
      case 21:
      case 22:
      case 23:
      case 24:
      case 25:
      case 54:
      case 55:
      case 56:
      case 57:
      case 58:
        if (paramInt >= 256) {
          addToCodeBuffer((byte)-60);
          addToCodeBuffer(paramByte);
          addToCodeBuffer((byte)(paramInt >> 8));
          addToCodeBuffer((byte)paramInt);
        } else {
          addToCodeBuffer(paramByte);
          addToCodeBuffer((byte)paramInt);
        } 
        return;
    } 
    throw new RuntimeException("Unexpected opcode for 1 operand");
  }
  
  public void addLoadConstant(int paramInt) { add((byte)18, this.itsConstantPool.addConstant(paramInt)); }
  
  public void addLoadConstant(long paramLong) { add((byte)20, this.itsConstantPool.addConstant(paramLong)); }
  
  public void addLoadConstant(float paramFloat) { add((byte)18, this.itsConstantPool.addConstant(paramFloat)); }
  
  public void addLoadConstant(double paramDouble) { add((byte)20, this.itsConstantPool.addConstant(paramDouble)); }
  
  public void addLoadConstant(String paramString) { add((byte)18, this.itsConstantPool.addConstant(paramString)); }
  
  public void add(byte paramByte, int paramInt1, int paramInt2) {
    this.itsStackTop = (short)(this.itsStackTop + ByteCode.stackChange[paramByte & 0xFF]);
    if (this.itsStackTop > this.itsMaxStack)
      this.itsMaxStack = this.itsStackTop; 
    if (paramByte == -124) {
      if (paramInt1 > 255 || paramInt2 < -128 || paramInt2 > 127) {
        addToCodeBuffer((byte)-60);
        addToCodeBuffer((byte)-124);
        addToCodeBuffer((byte)(paramInt1 >> 8));
        addToCodeBuffer((byte)paramInt1);
        addToCodeBuffer((byte)(paramInt2 >> 8));
        addToCodeBuffer((byte)paramInt2);
      } else {
        addToCodeBuffer((byte)-60);
        addToCodeBuffer((byte)-124);
        addToCodeBuffer((byte)paramInt1);
        addToCodeBuffer((byte)paramInt2);
      } 
    } else if (paramByte == -59) {
      addToCodeBuffer((byte)-59);
      addToCodeBuffer((byte)(paramInt1 >> 8));
      addToCodeBuffer((byte)paramInt1);
      addToCodeBuffer((byte)paramInt2);
    } else {
      throw new RuntimeException("Unexpected opcode for 2 operands");
    } 
  }
  
  public void add(byte paramByte, String paramString) {
    short s;
    this.itsStackTop = (short)(this.itsStackTop + ByteCode.stackChange[paramByte & 0xFF]);
    switch (paramByte) {
      case -69:
      case -67:
      case -64:
      case -63:
        s = this.itsConstantPool.addClass(paramString);
        addToCodeBuffer(paramByte);
        addToCodeBuffer((byte)(s >> 8));
        addToCodeBuffer((byte)s);
        break;
      default:
        throw new RuntimeException("bad opcode for class reference");
    } 
    if (this.itsStackTop > this.itsMaxStack)
      this.itsMaxStack = this.itsStackTop; 
  }
  
  public void add(byte paramByte, String paramString1, String paramString2, String paramString3) {
    this.itsStackTop = (short)(this.itsStackTop + ByteCode.stackChange[paramByte & 0xFF]);
    char c = paramString3.charAt(0);
    short s = (c == 'J' || c == 'D') ? 2 : 1;
    switch (paramByte) {
      case -78:
      case -76:
        this.itsStackTop = (short)(this.itsStackTop + s);
        break;
      case -77:
      case -75:
        this.itsStackTop = (short)(this.itsStackTop - s);
        break;
      default:
        throw new RuntimeException("bad opcode for field reference");
    } 
    short s1 = this.itsConstantPool.addFieldRef(paramString1, paramString2, paramString3);
    addToCodeBuffer(paramByte);
    addToCodeBuffer((byte)(s1 >> 8));
    addToCodeBuffer((byte)s1);
    if (this.itsStackTop > this.itsMaxStack)
      this.itsMaxStack = this.itsStackTop; 
  }
  
  public void add(byte paramByte, String paramString1, String paramString2, String paramString3, String paramString4) {
    short s;
    char c;
    int i = sizeOfParameters(paramString3);
    this.itsStackTop = (short)(this.itsStackTop - (i & 0xFFFF));
    this.itsStackTop = (short)(this.itsStackTop + ByteCode.stackChange[paramByte & 0xFF]);
    if (this.itsStackTop > this.itsMaxStack)
      this.itsMaxStack = this.itsStackTop; 
    switch (paramByte) {
      case -74:
      case -73:
      case -72:
      case -71:
        c = paramString4.charAt(0);
        if (c != 'V')
          if (c == 'J' || c == 'D') {
            this.itsStackTop = (short)(this.itsStackTop + 2);
          } else {
            this.itsStackTop = (short)(this.itsStackTop + 1);
          }  
        addToCodeBuffer(paramByte);
        if (paramByte == -71) {
          short s1 = this.itsConstantPool.addInterfaceMethodRef(paramString1, paramString2, String.valueOf(paramString3) + paramString4);
          addToCodeBuffer((byte)(s1 >> 8));
          addToCodeBuffer((byte)s1);
          addToCodeBuffer((byte)((i >> 16) + 1));
          addToCodeBuffer((byte)0);
          break;
        } 
        s = this.itsConstantPool.addMethodRef(paramString1, paramString2, String.valueOf(paramString3) + paramString4);
        addToCodeBuffer((byte)(s >> 8));
        addToCodeBuffer((byte)s);
        break;
      default:
        throw new RuntimeException("bad opcode for method reference");
    } 
    if (this.itsStackTop > this.itsMaxStack)
      this.itsMaxStack = this.itsStackTop; 
  }
  
  public int markLabel(int paramInt) { return markLabel(paramInt, (short)this.itsCodeBufferTop); }
  
  public int markLabel(int paramInt, short paramShort) {
    this.itsStackTop = paramShort;
    return markLabel(paramInt, (short)this.itsCodeBufferTop);
  }
  
  public int markHandler(int paramInt) {
    this.itsStackTop = 1;
    return markLabel(paramInt);
  }
  
  public int getCurrentCodeOffset() { return this.itsCodeBufferTop; }
  
  public short getStackTop() { return this.itsStackTop; }
  
  public void adjustStackTop(int paramInt) {
    this.itsStackTop = (short)(this.itsStackTop + paramInt);
    if (this.itsStackTop > this.itsMaxStack)
      this.itsMaxStack = this.itsStackTop; 
  }
  
  public void addToCodeBuffer(byte paramByte) {
    if (this.itsCodeBuffer == null) {
      this.itsCodeBuffer = new byte[128];
      this.itsCodeBuffer[0] = paramByte;
      this.itsCodeBufferTop = 1;
    } else {
      if (this.itsCodeBufferTop == this.itsCodeBuffer.length) {
        byte[] arrayOfByte = this.itsCodeBuffer;
        this.itsCodeBuffer = new byte[this.itsCodeBufferTop * 2];
        System.arraycopy(arrayOfByte, 0, this.itsCodeBuffer, 0, this.itsCodeBufferTop);
      } 
      this.itsCodeBuffer[this.itsCodeBufferTop++] = paramByte;
    } 
  }
  
  public void addExceptionHandler(int paramInt1, int paramInt2, int paramInt3, String paramString) {
    if ((paramInt1 & 0x80000000) != Integer.MIN_VALUE)
      throw new RuntimeException("Bad startLabel"); 
    if ((paramInt2 & 0x80000000) != Integer.MIN_VALUE)
      throw new RuntimeException("Bad endLabel"); 
    if ((paramInt3 & 0x80000000) != Integer.MIN_VALUE)
      throw new RuntimeException("Bad handlerLabel"); 
    ExceptionTableEntry exceptionTableEntry = new ExceptionTableEntry(paramInt1, paramInt2, paramInt3, (paramString == null) ? 0 : this.itsConstantPool.addClass(paramString));
    if (this.itsExceptionTable == null) {
      this.itsExceptionTable = new ExceptionTableEntry[4];
      this.itsExceptionTable[0] = exceptionTableEntry;
      this.itsExceptionTableTop = 1;
    } else {
      if (this.itsExceptionTableTop == this.itsExceptionTable.length) {
        ExceptionTableEntry[] arrayOfExceptionTableEntry = this.itsExceptionTable;
        this.itsExceptionTable = new ExceptionTableEntry[this.itsExceptionTableTop * 2];
        System.arraycopy(arrayOfExceptionTableEntry, 0, this.itsExceptionTable, 0, this.itsExceptionTableTop);
      } 
      this.itsExceptionTable[this.itsExceptionTableTop++] = exceptionTableEntry;
    } 
  }
  
  public void addLineNumberEntry(short paramShort) {
    if (this.itsLineNumberTable == null) {
      this.itsLineNumberTable = new int[16];
      this.itsLineNumberTable[0] = (this.itsCodeBufferTop << 16) + paramShort;
      this.itsLineNumberTableTop = 1;
    } else {
      if (this.itsLineNumberTableTop == this.itsLineNumberTable.length) {
        int[] arrayOfInt = this.itsLineNumberTable;
        this.itsLineNumberTable = new int[this.itsLineNumberTableTop * 2];
        System.arraycopy(arrayOfInt, 0, this.itsLineNumberTable, 0, this.itsLineNumberTableTop);
      } 
      this.itsLineNumberTable[this.itsLineNumberTableTop++] = (this.itsCodeBufferTop << 16) + paramShort;
    } 
  }
  
  public void write(OutputStream paramOutputStream) throws IOException {
    DataOutputStream dataOutputStream = new DataOutputStream(paramOutputStream);
    short s = 0;
    if (this.itsSourceFileNameIndex != 0)
      s = this.itsConstantPool.addUtf8("SourceFile"); 
    dataOutputStream.writeLong(-3819410108756852691L);
    this.itsConstantPool.write(dataOutputStream);
    dataOutputStream.writeShort(this.itsFlags);
    dataOutputStream.writeShort(this.itsThisClassIndex);
    dataOutputStream.writeShort(this.itsSuperClassIndex);
    dataOutputStream.writeShort(this.itsInterfaces.size());
    for (byte b1 = 0; b1 < this.itsInterfaces.size(); b1++)
      dataOutputStream.writeShort(((Short)this.itsInterfaces.elementAt(b1)).shortValue()); 
    dataOutputStream.writeShort(this.itsFields.size());
    for (byte b2 = 0; b2 < this.itsFields.size(); b2++)
      ((ClassFileField)this.itsFields.elementAt(b2)).write(dataOutputStream); 
    dataOutputStream.writeShort(this.itsMethods.size());
    for (byte b3 = 0; b3 < this.itsMethods.size(); b3++)
      ((ClassFileMethod)this.itsMethods.elementAt(b3)).write(dataOutputStream); 
    if (this.itsSourceFileNameIndex != 0) {
      dataOutputStream.writeShort(1);
      dataOutputStream.writeShort(s);
      dataOutputStream.writeInt(2);
      dataOutputStream.writeShort(this.itsSourceFileNameIndex);
    } else {
      dataOutputStream.writeShort(0);
    } 
  }
  
  private int sizeOfParameters(String paramString) {
    byte b1 = 1;
    byte b2 = 0;
    byte b3 = 0;
    while (paramString.charAt(b1) != ')') {
      switch (paramString.charAt(b1)) {
        case 'D':
        case 'J':
          b2++;
        case 'B':
        case 'C':
        case 'F':
        case 'I':
        case 'S':
        case 'Z':
          b2++;
          b3++;
          b1++;
          continue;
        case '[':
          for (; paramString.charAt(b1) == '['; b1++);
          if (paramString.charAt(b1) != 'L') {
            b2++;
            b3++;
            b1++;
            continue;
          } 
        case 'L':
          b2++;
          b3++;
          do {
          
          } while (paramString.charAt(b1++) != ';');
          continue;
      } 
      throw new RuntimeException("Bad signature character");
    } 
    return b3 << 16 | b2;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\classfile\ClassFileWriter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */