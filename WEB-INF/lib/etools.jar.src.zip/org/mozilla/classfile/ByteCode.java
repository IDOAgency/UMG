/*      */ package org.mozilla.classfile;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ByteCode
/*      */ {
/*      */   public static final byte NOP = 0;
/*      */   public static final byte ACONST_NULL = 1;
/*      */   public static final byte ICONST_M1 = 2;
/*      */   public static final byte ICONST_0 = 3;
/*      */   public static final byte ICONST_1 = 4;
/*      */   public static final byte ICONST_2 = 5;
/*      */   public static final byte ICONST_3 = 6;
/*      */   public static final byte ICONST_4 = 7;
/*      */   public static final byte ICONST_5 = 8;
/*      */   public static final byte LCONST_0 = 9;
/*      */   public static final byte LCONST_1 = 10;
/*      */   public static final byte FCONST_0 = 11;
/*      */   public static final byte FCONST_1 = 12;
/*      */   public static final byte FCONST_2 = 13;
/*      */   public static final byte DCONST_0 = 14;
/*      */   public static final byte DCONST_1 = 15;
/*      */   public static final byte BIPUSH = 16;
/*      */   public static final byte SIPUSH = 17;
/*      */   public static final byte LDC = 18;
/*      */   public static final byte LDC_W = 19;
/*      */   public static final byte LDC2_W = 20;
/*      */   public static final byte ILOAD = 21;
/*      */   public static final byte LLOAD = 22;
/*      */   public static final byte FLOAD = 23;
/*      */   public static final byte DLOAD = 24;
/*      */   public static final byte ALOAD = 25;
/*      */   public static final byte ILOAD_0 = 26;
/*      */   public static final byte ILOAD_1 = 27;
/*      */   public static final byte ILOAD_2 = 28;
/*      */   public static final byte ILOAD_3 = 29;
/*      */   public static final byte LLOAD_0 = 30;
/*      */   public static final byte LLOAD_1 = 31;
/*      */   public static final byte LLOAD_2 = 32;
/*      */   public static final byte LLOAD_3 = 33;
/*      */   public static final byte FLOAD_0 = 34;
/*      */   public static final byte FLOAD_1 = 35;
/*      */   public static final byte FLOAD_2 = 36;
/*      */   public static final byte FLOAD_3 = 37;
/*      */   public static final byte DLOAD_0 = 38;
/*      */   public static final byte DLOAD_1 = 39;
/*      */   public static final byte DLOAD_2 = 40;
/*      */   public static final byte DLOAD_3 = 41;
/*      */   public static final byte ALOAD_0 = 42;
/*      */   public static final byte ALOAD_1 = 43;
/*      */   public static final byte ALOAD_2 = 44;
/*      */   public static final byte ALOAD_3 = 45;
/*      */   public static final byte IALOAD = 46;
/*      */   public static final byte LALOAD = 47;
/*      */   public static final byte FALOAD = 48;
/*      */   public static final byte DALOAD = 49;
/*      */   public static final byte AALOAD = 50;
/*      */   public static final byte BALOAD = 51;
/*      */   public static final byte CALOAD = 52;
/*      */   public static final byte SALOAD = 53;
/*      */   public static final byte ISTORE = 54;
/*      */   public static final byte LSTORE = 55;
/*      */   public static final byte FSTORE = 56;
/*      */   public static final byte DSTORE = 57;
/*      */   public static final byte ASTORE = 58;
/*      */   public static final byte ISTORE_0 = 59;
/*      */   public static final byte ISTORE_1 = 60;
/*      */   public static final byte ISTORE_2 = 61;
/*      */   public static final byte ISTORE_3 = 62;
/*      */   public static final byte LSTORE_0 = 63;
/*      */   public static final byte LSTORE_1 = 64;
/*      */   public static final byte LSTORE_2 = 65;
/*      */   public static final byte LSTORE_3 = 66;
/*      */   public static final byte FSTORE_0 = 67;
/*      */   public static final byte FSTORE_1 = 68;
/*      */   public static final byte FSTORE_2 = 69;
/*      */   public static final byte FSTORE_3 = 70;
/*      */   public static final byte DSTORE_0 = 71;
/*      */   public static final byte DSTORE_1 = 72;
/*      */   public static final byte DSTORE_2 = 73;
/*      */   public static final byte DSTORE_3 = 74;
/*      */   public static final byte ASTORE_0 = 75;
/*      */   public static final byte ASTORE_1 = 76;
/*      */   public static final byte ASTORE_2 = 77;
/*      */   public static final byte ASTORE_3 = 78;
/*      */   public static final byte IASTORE = 79;
/*      */   public static final byte LASTORE = 80;
/*      */   public static final byte FASTORE = 81;
/*      */   public static final byte DASTORE = 82;
/*      */   public static final byte AASTORE = 83;
/*      */   public static final byte BASTORE = 84;
/*      */   public static final byte CASTORE = 85;
/*      */   public static final byte SASTORE = 86;
/*      */   public static final byte POP = 87;
/*      */   public static final byte POP2 = 88;
/*      */   public static final byte DUP = 89;
/*      */   public static final byte DUP_X1 = 90;
/*      */   public static final byte DUP_X2 = 91;
/*      */   public static final byte DUP2 = 92;
/*      */   public static final byte DUP2_X1 = 93;
/*      */   public static final byte DUP2_X2 = 94;
/*      */   public static final byte SWAP = 95;
/*      */   public static final byte IADD = 96;
/*      */   public static final byte LADD = 97;
/*      */   public static final byte FADD = 98;
/*      */   public static final byte DADD = 99;
/*      */   public static final byte ISUB = 100;
/*      */   public static final byte LSUB = 101;
/*      */   public static final byte FSUB = 102;
/*      */   public static final byte DSUB = 103;
/*      */   public static final byte IMUL = 104;
/*      */   public static final byte LMUL = 105;
/*      */   public static final byte FMUL = 106;
/*      */   public static final byte DMUL = 107;
/*      */   public static final byte IDIV = 108;
/*      */   public static final byte LDIV = 109;
/*      */   public static final byte FDIV = 110;
/*      */   public static final byte DDIV = 111;
/*      */   public static final byte IREM = 112;
/*      */   public static final byte LREM = 113;
/*      */   public static final byte FREM = 114;
/*      */   public static final byte DREM = 115;
/*      */   public static final byte INEG = 116;
/*      */   public static final byte LNEG = 117;
/*      */   public static final byte FNEG = 118;
/*      */   public static final byte DNEG = 119;
/*      */   public static final byte ISHL = 120;
/*      */   public static final byte LSHL = 121;
/*      */   public static final byte ISHR = 122;
/*      */   public static final byte LSHR = 123;
/*      */   public static final byte IUSHR = 124;
/*      */   public static final byte LUSHR = 125;
/*      */   public static final byte IAND = 126;
/*      */   public static final byte LAND = 127;
/*      */   public static final byte IOR = -128;
/*      */   public static final byte LOR = -127;
/*      */   public static final byte IXOR = -126;
/*      */   public static final byte LXOR = -125;
/*      */   public static final byte IINC = -124;
/*      */   public static final byte I2L = -123;
/*      */   public static final byte I2F = -122;
/*      */   public static final byte I2D = -121;
/*      */   public static final byte L2I = -120;
/*      */   public static final byte L2F = -119;
/*      */   public static final byte L2D = -118;
/*      */   public static final byte F2I = -117;
/*      */   public static final byte F2L = -116;
/*      */   public static final byte F2D = -115;
/*      */   public static final byte D2I = -114;
/*      */   public static final byte D2L = -113;
/*      */   public static final byte D2F = -112;
/*      */   public static final byte I2B = -111;
/*      */   public static final byte I2C = -110;
/*      */   public static final byte I2S = -109;
/*      */   public static final byte LCMP = -108;
/*      */   public static final byte FCMPL = -107;
/*      */   public static final byte FCMPG = -106;
/*      */   public static final byte DCMPL = -105;
/*      */   public static final byte DCMPG = -104;
/*      */   public static final byte IFEQ = -103;
/*      */   public static final byte IFNE = -102;
/*      */   public static final byte IFLT = -101;
/*      */   public static final byte IFGE = -100;
/*      */   public static final byte IFGT = -99;
/*      */   public static final byte IFLE = -98;
/*      */   public static final byte IF_ICMPEQ = -97;
/*      */   public static final byte IF_ICMPNE = -96;
/*      */   public static final byte IF_ICMPLT = -95;
/*      */   public static final byte IF_ICMPGE = -94;
/*      */   public static final byte IF_ICMPGT = -93;
/*      */   public static final byte IF_ICMPLE = -92;
/*      */   public static final byte IF_ACMPEQ = -91;
/*      */   public static final byte IF_ACMPNE = -90;
/*      */   public static final byte GOTO = -89;
/*      */   public static final byte JSR = -88;
/*      */   public static final byte RET = -87;
/*      */   public static final byte TABLESWITCH = -86;
/*      */   public static final byte LOOKUPSWITCH = -85;
/*      */   public static final byte IRETURN = -84;
/*      */   public static final byte LRETURN = -83;
/*      */   public static final byte FRETURN = -82;
/*      */   public static final byte DRETURN = -81;
/*      */   public static final byte ARETURN = -80;
/*      */   public static final byte RETURN = -79;
/*      */   public static final byte GETSTATIC = -78;
/*      */   public static final byte PUTSTATIC = -77;
/*      */   public static final byte GETFIELD = -76;
/*      */   public static final byte PUTFIELD = -75;
/*      */   public static final byte INVOKEVIRTUAL = -74;
/*      */   public static final byte INVOKESPECIAL = -73;
/*      */   public static final byte INVOKESTATIC = -72;
/*      */   public static final byte INVOKEINTERFACE = -71;
/*      */   public static final byte XXXUNUSEDXXX = -70;
/*      */   public static final byte NEW = -69;
/*      */   public static final byte NEWARRAY = -68;
/*      */   public static final byte ANEWARRAY = -67;
/*      */   public static final byte ARRAYLENGTH = -66;
/*      */   public static final byte ATHROW = -65;
/*      */   public static final byte CHECKCAST = -64;
/*      */   public static final byte INSTANCEOF = -63;
/*      */   public static final byte MONITORENTER = -62;
/*      */   public static final byte MONITOREXIT = -61;
/*      */   public static final byte WIDE = -60;
/*      */   public static final byte MULTIANEWARRAY = -59;
/*      */   public static final byte IFNULL = -58;
/*      */   public static final byte IFNONNULL = -57;
/*      */   public static final byte GOTO_W = -56;
/*      */   public static final byte JSR_W = -55;
/*      */   public static final byte BREAKPOINT = -54;
/*      */   public static final byte LDC_QUICK = -53;
/*      */   public static final byte LDC_W_QUICK = -52;
/*      */   public static final byte LDC2_W_QUICK = -51;
/*      */   public static final byte GETFIELD_QUICK = -50;
/*      */   public static final byte PUTFIELD_QUICK = -49;
/*      */   public static final byte GETFIELD2_QUICK = -48;
/*      */   public static final byte PUTFIELD2_QUICK = -47;
/*      */   public static final byte GETSTATIC_QUICK = -46;
/*      */   public static final byte PUTSTATIC_QUICK = -45;
/*      */   public static final byte GETSTATIC2_QUICK = -44;
/*      */   public static final byte PUTSTATIC2_QUICK = -43;
/*      */   public static final byte INVOKEVIRTUAL_QUICK = -42;
/*      */   public static final byte INVOKENONVIRTUAL_QUICK = -41;
/*      */   public static final byte INVOKESUPER_QUICK = -40;
/*      */   public static final byte INVOKESTATIC_QUICK = -39;
/*      */   public static final byte INVOKEINTERFACE_QUICK = -38;
/*      */   public static final byte INVOKEVIRTUALOBJECT_QUICK = -37;
/*      */   public static final byte NEW_QUICK = -35;
/*      */   public static final byte ANEWARRAY_QUICK = -34;
/*      */   public static final byte MULTIANEWARRAY_QUICK = -33;
/*      */   public static final byte CHECKCAST_QUICK = -32;
/*      */   public static final byte INSTANCEOF_QUICK = -31;
/*      */   public static final byte INVOKEVIRTUAL_QUICK_W = -30;
/*      */   public static final byte GETFIELD_QUICK_W = -29;
/*      */   public static final byte PUTFIELD_QUICK_W = -28;
/*      */   public static final byte IMPDEP1 = -2;
/*      */   public static final byte IMPDEP2 = -1;
/*      */   public static final byte T_BOOLEAN = 4;
/*      */   public static final byte T_CHAR = 5;
/*      */   public static final byte T_FLOAT = 6;
/*      */   public static final byte T_DOUBLE = 7;
/*      */   public static final byte T_BYTE = 8;
/*      */   public static final byte T_SHORT = 9;
/*      */   public static final byte T_INT = 10;
/*      */   public static final byte T_LONG = 11;
/*      */   static final byte[] extra = { 
/*      */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*  317 */       0, 0, 0, 0, 0, 0, 1, 
/*  318 */       2, 
/*  319 */       1, 
/*  320 */       2, 
/*  321 */       2, 
/*  322 */       1, 
/*  323 */       1, 
/*  324 */       1, 
/*  325 */       1, 
/*  326 */       1, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  355 */       1, 
/*  356 */       1, 
/*  357 */       1, 
/*  358 */       1, 
/*  359 */       1, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  433 */       2, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  454 */       2, 
/*  455 */       2, 
/*  456 */       2, 
/*  457 */       2, 
/*  458 */       2, 
/*  459 */       2, 
/*  460 */       2, 
/*  461 */       2, 
/*  462 */       2, 
/*  463 */       2, 
/*  464 */       2, 
/*  465 */       2, 
/*  466 */       2, 
/*  467 */       2, 
/*  468 */       2, 
/*  469 */       2, 
/*  470 */       1, 
/*  471 */       -1, 
/*  472 */       -1, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  479 */       2, 
/*  480 */       2, 
/*  481 */       2, 
/*  482 */       2, 
/*  483 */       2, 
/*  484 */       2, 
/*  485 */       2, 
/*  486 */       2, 
/*      */       
/*  488 */       2, 
/*  489 */       1, 
/*  490 */       2, 
/*      */ 
/*      */       
/*  493 */       2, 
/*  494 */       2, 
/*      */ 
/*      */ 
/*      */       
/*  498 */       3, 
/*  499 */       2, 
/*  500 */       2, 
/*  501 */       4, 
/*  502 */       4, 
/*      */       
/*  504 */       1, 
/*  505 */       2, 
/*  506 */       2, 
/*  507 */       2, 
/*  508 */       2, 
/*  509 */       2, 
/*  510 */       2, 
/*  511 */       2, 
/*  512 */       2, 
/*  513 */       2, 
/*  514 */       2, 
/*  515 */       2, 
/*  516 */       2, 
/*  517 */       2, 
/*  518 */       2, 
/*  519 */       2, 
/*  520 */       2, 
/*      */       
/*  522 */       2, 
/*  523 */       2, 
/*  524 */       3, 
/*  525 */       2, 
/*  526 */       2, 
/*      */       
/*  528 */       2, 
/*  529 */       2 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte[] opcodeCount = { 
/*      */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*  579 */       0, 0, 0, 0, 0, 0, 1, 
/*  580 */       1, 
/*  581 */       1, 
/*  582 */       1, 
/*  583 */       1, 
/*  584 */       1, 
/*  585 */       1, 
/*  586 */       1, 
/*  587 */       1, 
/*  588 */       1, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  617 */       1, 
/*  618 */       1, 
/*  619 */       1, 
/*  620 */       1, 
/*  621 */       1, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  695 */       2, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  716 */       1, 
/*  717 */       1, 
/*  718 */       1, 
/*  719 */       1, 
/*  720 */       1, 
/*  721 */       1, 
/*  722 */       1, 
/*  723 */       1, 
/*  724 */       1, 
/*  725 */       1, 
/*  726 */       1, 
/*  727 */       1, 
/*  728 */       1, 
/*  729 */       1, 
/*  730 */       1, 
/*  731 */       1, 
/*  732 */       1, 
/*  733 */       -1, 
/*  734 */       -1, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  741 */       1, 
/*  742 */       1, 
/*  743 */       1, 
/*  744 */       1, 
/*  745 */       1, 
/*  746 */       1, 
/*  747 */       1, 
/*  748 */       1, 
/*      */       
/*  750 */       1, 
/*  751 */       1, 
/*  752 */       1, 
/*      */ 
/*      */       
/*  755 */       1, 
/*  756 */       1, 
/*      */ 
/*      */ 
/*      */       
/*  760 */       2, 
/*  761 */       1, 
/*  762 */       1, 
/*  763 */       1, 
/*  764 */       1, 
/*      */       
/*  766 */       -1, 
/*  767 */       -1, 
/*  768 */       -1, 
/*  769 */       -1, 
/*  770 */       -1, 
/*  771 */       -1, 
/*  772 */       -1, 
/*  773 */       -1, 
/*  774 */       -1, 
/*  775 */       -1, 
/*  776 */       -1, 
/*  777 */       -1, 
/*  778 */       -1, 
/*  779 */       -1, 
/*  780 */       -1, 
/*  781 */       -1, 
/*  782 */       -1, 
/*  783 */       -1, 
/*  784 */       -1, 
/*  785 */       -1, 
/*  786 */       -1, 
/*  787 */       -1, 
/*  788 */       -1, 
/*  789 */       -1, 
/*  790 */       -1, 
/*  791 */       -1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte[] stackChange = { 
/*  826 */       0, 1, 
/*  827 */       1, 
/*  828 */       1, 
/*  829 */       1, 
/*  830 */       1, 
/*  831 */       1, 
/*  832 */       1, 
/*  833 */       1, 
/*  834 */       2, 
/*  835 */       2, 
/*  836 */       1, 
/*  837 */       1, 
/*  838 */       1, 
/*  839 */       2, 
/*  840 */       2, 
/*  841 */       1, 
/*  842 */       1, 
/*  843 */       1, 
/*  844 */       1, 
/*  845 */       2, 
/*  846 */       1, 
/*  847 */       2, 
/*  848 */       1, 
/*  849 */       2, 
/*  850 */       1, 
/*  851 */       1, 
/*  852 */       1, 
/*  853 */       1, 
/*  854 */       1, 
/*  855 */       2, 
/*  856 */       2, 
/*  857 */       2, 
/*  858 */       2, 
/*  859 */       1, 
/*  860 */       1, 
/*  861 */       1, 
/*  862 */       1, 
/*  863 */       2, 
/*  864 */       2, 
/*  865 */       2, 
/*  866 */       2, 
/*  867 */       1, 
/*  868 */       1, 
/*  869 */       1, 
/*  870 */       1, 
/*  871 */       -1, 
/*      */       
/*  873 */       -1, 
/*      */       
/*  875 */       -1, 
/*  876 */       -1, 
/*  877 */       -1, 
/*  878 */       -1, 
/*  879 */       -1, 
/*  880 */       -2, 
/*  881 */       -1, 
/*  882 */       -2, 
/*  883 */       -1, 
/*  884 */       -1, 
/*  885 */       -1, 
/*  886 */       -1, 
/*  887 */       -1, 
/*  888 */       -2, 
/*  889 */       -2, 
/*  890 */       -2, 
/*  891 */       -2, 
/*  892 */       -1, 
/*  893 */       -1, 
/*  894 */       -1, 
/*  895 */       -1, 
/*  896 */       -2, 
/*  897 */       -2, 
/*  898 */       -2, 
/*  899 */       -2, 
/*  900 */       -1, 
/*  901 */       -1, 
/*  902 */       -1, 
/*  903 */       -1, 
/*  904 */       -3, 
/*  905 */       -4, 
/*  906 */       -3, 
/*  907 */       -4, 
/*  908 */       -3, 
/*  909 */       -3, 
/*  910 */       -3, 
/*  911 */       -3, 
/*  912 */       -1, 
/*  913 */       -2, 
/*  914 */       1, 
/*  915 */       1, 
/*  916 */       1, 
/*  917 */       2, 
/*  918 */       2, 
/*  919 */       2, 
/*      */       
/*  921 */       -1, 
/*  922 */       -2, 
/*  923 */       -1, 
/*  924 */       -2, 
/*  925 */       -1, 
/*  926 */       -2, 
/*  927 */       -1, 
/*  928 */       -2, 
/*  929 */       -1, 
/*  930 */       -2, 
/*  931 */       -1, 
/*  932 */       -2, 
/*  933 */       -1, 
/*  934 */       -2, 
/*  935 */       -1, 
/*  936 */       -2, 
/*  937 */       -1, 
/*  938 */       -2, 
/*  939 */       -1, 
/*  940 */       -2, 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  945 */       -1, 
/*  946 */       -1, 
/*  947 */       -1, 
/*  948 */       -1, 
/*  949 */       -1, 
/*  950 */       -1, 
/*  951 */       -1, 
/*  952 */       -2, 
/*  953 */       -1, 
/*  954 */       -2, 
/*  955 */       -1, 
/*  956 */       -2, 
/*      */       
/*  958 */       1, 
/*      */       
/*  960 */       1, 
/*  961 */       -1, 
/*  962 */       -1, 
/*      */ 
/*      */       
/*  965 */       1, 
/*  966 */       1, 
/*  967 */       -1, 
/*      */       
/*  969 */       -1, 
/*      */ 
/*      */ 
/*      */       
/*  973 */       -3, 
/*  974 */       -1, 
/*  975 */       -1, 
/*  976 */       -3, 
/*  977 */       -3, 
/*  978 */       -1, 
/*  979 */       -1, 
/*  980 */       -1, 
/*  981 */       -1, 
/*  982 */       -1, 
/*  983 */       -1, 
/*  984 */       -2, 
/*  985 */       -2, 
/*  986 */       -2, 
/*  987 */       -2, 
/*  988 */       -2, 
/*  989 */       -2, 
/*  990 */       -2, 
/*  991 */       -2, 
/*      */       
/*  993 */       1, 
/*      */       
/*  995 */       -1, 
/*  996 */       -1, 
/*  997 */       -1, 
/*  998 */       -2, 
/*  999 */       -1, 
/* 1000 */       -2, 
/* 1001 */       -1,
/*      */ 
/*      */ 
/*      */       
/* 1005 */       -1, 
/* 1006 */       -1, 
/* 1007 */       -1, 
/* 1008 */       -1, 
/*      */       
/* 1010 */       -1, 
/*      */       
/* 1012 */       1, 
/*      */ 
/*      */ 
/*      */       
/* 1016 */       -1, 
/*      */ 
/*      */       
/* 1019 */       -1, 
/* 1020 */       -1, 
/*      */       
/* 1022 */       1, 
/* 1023 */       -1, 
/* 1024 */       -1, 
/*      */       
/* 1026 */       1, 
/*      */       
/* 1028 */       1, 
/* 1029 */       1, 
/* 1030 */       2, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1046 */       1, 
/* 1047 */       1, 
/* 1048 */       1, 
/* 1049 */       -1 };
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\classfile\ByteCode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */