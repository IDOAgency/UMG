package org.mozilla.classfile;

import org.mozilla.javascript.Label;

class ExceptionTableEntry {
  private int itsStartLabel;
  
  private int itsEndLabel;
  
  private int itsHandlerLabel;
  
  private short itsCatchType;
  
  ExceptionTableEntry(int paramInt1, int paramInt2, int paramInt3, short paramShort) {
    this.itsStartLabel = paramInt1;
    this.itsEndLabel = paramInt2;
    this.itsHandlerLabel = paramInt3;
    this.itsCatchType = paramShort;
  }
  
  short getStartPC(Label[] paramArrayOfLabel) {
    short s = paramArrayOfLabel[this.itsStartLabel & 0x7FFFFFFF].getPC();
    if (s == -1)
      throw new RuntimeException("start label not defined"); 
    return s;
  }
  
  short getEndPC(Label[] paramArrayOfLabel) {
    short s = paramArrayOfLabel[this.itsEndLabel & 0x7FFFFFFF].getPC();
    if (s == -1)
      throw new RuntimeException("end label not defined"); 
    return s;
  }
  
  short getHandlerPC(Label[] paramArrayOfLabel) {
    short s = paramArrayOfLabel[this.itsHandlerLabel & 0x7FFFFFFF].getPC();
    if (s == -1)
      throw new RuntimeException("handler label not defined"); 
    return s;
  }
  
  short getCatchType() { return this.itsCatchType; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\classfile\ExceptionTableEntry.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */