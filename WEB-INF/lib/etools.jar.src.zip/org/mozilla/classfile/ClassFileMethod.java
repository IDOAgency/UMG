package org.mozilla.classfile;

import java.io.DataOutputStream;
import java.io.IOException;

class ClassFileMethod {
  private short itsNameIndex;
  
  private short itsTypeIndex;
  
  private short itsFlags;
  
  private byte[] itsCodeAttribute;
  
  ClassFileMethod(short paramShort1, short paramShort2, short paramShort3) {
    this.itsNameIndex = paramShort1;
    this.itsTypeIndex = paramShort2;
    this.itsFlags = paramShort3;
  }
  
  void setCodeAttribute(byte[] paramArrayOfByte) { this.itsCodeAttribute = paramArrayOfByte; }
  
  void write(DataOutputStream paramDataOutputStream) throws IOException {
    paramDataOutputStream.writeShort(this.itsFlags);
    paramDataOutputStream.writeShort(this.itsNameIndex);
    paramDataOutputStream.writeShort(this.itsTypeIndex);
    paramDataOutputStream.writeShort(1);
    paramDataOutputStream.write(this.itsCodeAttribute, 0, this.itsCodeAttribute.length);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\classfile\ClassFileMethod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */