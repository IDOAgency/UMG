/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InterpreterData
/*    */ {
/*    */   static final int INITIAL_MAX_ICODE_LENGTH = 1024;
/*    */   static final int INITIAL_STRINGTABLE_SIZE = 64;
/*    */   static final int INITIAL_NUMBERTABLE_SIZE = 64;
/*    */   VariableTable itsVariableTable;
/*    */   String itsName;
/*    */   String itsSource;
/*    */   String itsSourceFile;
/*    */   boolean itsNeedsActivation;
/*    */   boolean itsFromEvalCode;
/*    */   boolean itsUseDynamicScope;
/*    */   byte itsFunctionType;
/*    */   String[] itsStringTable;
/*    */   int itsStringTableIndex;
/*    */   Number[] itsNumberTable;
/*    */   int itsNumberTableIndex;
/*    */   InterpretedFunction[] itsNestedFunctions;
/*    */   Object[] itsRegExpLiterals;
/*    */   byte[] itsICode;
/*    */   int itsICodeTop;
/*    */   int itsMaxLocals;
/*    */   int itsMaxArgs;
/*    */   int itsMaxStack;
/*    */   int itsMaxTryDepth;
/*    */   Object securityDomain;
/*    */   Context itsCX;
/*    */   Scriptable itsScope;
/*    */   Scriptable itsThisObj;
/*    */   Object[] itsInArgs;
/*    */   
/*    */   InterpreterData(int paramInt1, int paramInt2, int paramInt3, Object paramObject, boolean paramBoolean) {
/* 50 */     this.itsICodeTop = (paramInt1 == 0) ? 
/* 51 */       1024 : (
/* 52 */       paramInt1 * 2);
/* 53 */     this.itsICode = new byte[this.itsICodeTop];
/*    */     
/* 55 */     this.itsStringTable = new String[(paramInt2 == 0) ? 
/* 56 */         64 : (
/* 57 */         paramInt2 * 2)];
/*    */     
/* 59 */     this.itsNumberTable = new Number[(paramInt3 == 0) ? 
/* 60 */         64 : (
/* 61 */         paramInt3 * 2)];
/*    */     
/* 63 */     this.itsUseDynamicScope = paramBoolean;
/* 64 */     if (paramObject == null && Context.isSecurityDomainRequired())
/* 65 */       throw new SecurityException("Required security context missing"); 
/* 66 */     this.securityDomain = paramObject;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\InterpreterData.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */