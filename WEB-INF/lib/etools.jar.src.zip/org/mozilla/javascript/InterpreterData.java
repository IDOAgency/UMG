package org.mozilla.javascript;

class InterpreterData {
  static final int INITIAL_MAX_ICODE_LENGTH = 1024;
  
  static final int INITIAL_STRINGTABLE_SIZE = 64;
  
  static final int INITIAL_NUMBERTABLE_SIZE = 64;
  
  VariableTable itsVariableTable;
  
  String itsName;
  
  String itsSource;
  
  String itsSourceFile;
  
  boolean itsNeedsActivation;
  
  boolean itsFromEvalCode;
  
  boolean itsUseDynamicScope;
  
  byte itsFunctionType;
  
  String[] itsStringTable;
  
  int itsStringTableIndex;
  
  Number[] itsNumberTable;
  
  int itsNumberTableIndex;
  
  InterpretedFunction[] itsNestedFunctions;
  
  Object[] itsRegExpLiterals;
  
  byte[] itsICode;
  
  int itsICodeTop;
  
  int itsMaxLocals;
  
  int itsMaxArgs;
  
  int itsMaxStack;
  
  int itsMaxTryDepth;
  
  Object securityDomain;
  
  Context itsCX;
  
  Scriptable itsScope;
  
  Scriptable itsThisObj;
  
  Object[] itsInArgs;
  
  InterpreterData(int paramInt1, int paramInt2, int paramInt3, Object paramObject, boolean paramBoolean) {
    this.itsICodeTop = (paramInt1 == 0) ? 
      1024 : (
      paramInt1 * 2);
    this.itsICode = new byte[this.itsICodeTop];
    this.itsStringTable = new String[(paramInt2 == 0) ? 
        64 : (
        paramInt2 * 2)];
    this.itsNumberTable = new Number[(paramInt3 == 0) ? 
        64 : (
        paramInt3 * 2)];
    this.itsUseDynamicScope = paramBoolean;
    if (paramObject == null && Context.isSecurityDomainRequired())
      throw new SecurityException("Required security context missing"); 
    this.securityDomain = paramObject;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\InterpreterData.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */