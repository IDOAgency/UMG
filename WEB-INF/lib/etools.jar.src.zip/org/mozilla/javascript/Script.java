package org.mozilla.javascript;

public interface Script {
  Object exec(Context paramContext, Scriptable paramScriptable) throws JavaScriptException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Script.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */