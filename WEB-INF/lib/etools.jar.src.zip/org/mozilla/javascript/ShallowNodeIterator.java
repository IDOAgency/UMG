/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShallowNodeIterator
/*    */   implements Enumeration
/*    */ {
/*    */   private Node current;
/*    */   
/* 50 */   public ShallowNodeIterator(Node paramNode) { this.current = paramNode; }
/*    */ 
/*    */ 
/*    */   
/* 54 */   public boolean hasMoreElements() { return !(this.current == null); }
/*    */ 
/*    */ 
/*    */   
/* 58 */   public Object nextElement() { return nextNode(); }
/*    */ 
/*    */   
/*    */   public Node nextNode() {
/* 62 */     Node node = this.current;
/* 63 */     this.current = this.current.next;
/* 64 */     return node;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\ShallowNodeIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */