/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariableTable
/*     */ {
/*  45 */   public int size() { return this.itsVariables.size(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public int getParameterCount() { return this.varStart; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public LocalVariable createLocalVariable(String paramString, boolean paramBoolean) { return new LocalVariable(paramString, paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public LocalVariable get(int paramInt) { return (LocalVariable)this.itsVariables.elementAt(paramInt); }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalVariable get(String paramString) {
/*  65 */     Integer integer = (Integer)this.itsVariableNames.get(paramString);
/*  66 */     if (integer != null) {
/*  67 */       return (LocalVariable)this.itsVariables.elementAt(integer.intValue());
/*     */     }
/*  69 */     return null;
/*     */   }
/*     */   
/*     */   public int getOrdinal(String paramString) {
/*  73 */     Integer integer = (Integer)this.itsVariableNames.get(paramString);
/*  74 */     if (integer != null) {
/*  75 */       return integer.intValue();
/*     */     }
/*  77 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  82 */   public String getName(int paramInt) { return ((LocalVariable)this.itsVariables.elementAt(paramInt)).getName(); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void establishIndices() {
/*  87 */     for (byte b = 0; b < this.itsVariables.size(); b++) {
/*  88 */       LocalVariable localVariable = (LocalVariable)this.itsVariables.elementAt(b);
/*  89 */       localVariable.setIndex(b);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addParameter(String paramString) {
/*  95 */     Integer integer = (Integer)this.itsVariableNames.get(paramString);
/*  96 */     if (integer != null) {
/*  97 */       LocalVariable localVariable1 = 
/*  98 */         (LocalVariable)this.itsVariables.elementAt(integer.intValue());
/*  99 */       if (localVariable1.isParameter()) {
/* 100 */         Object[] arrayOfObject = { paramString };
/* 101 */         String str = Context.getMessage("msg.dup.parms", arrayOfObject);
/* 102 */         Context.reportWarning(str, null, 0, null, 0);
/*     */       } else {
/*     */         
/* 105 */         this.itsVariables.removeElementAt(integer.intValue());
/*     */       } 
/*     */     } 
/* 108 */     int i = this.varStart++;
/* 109 */     LocalVariable localVariable = createLocalVariable(paramString, true);
/* 110 */     this.itsVariables.insertElementAt(localVariable, i);
/* 111 */     this.itsVariableNames.put(paramString, new Integer(i));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addLocal(String paramString) {
/* 116 */     Integer integer = (Integer)this.itsVariableNames.get(paramString);
/* 117 */     if (integer != null) {
/* 118 */       LocalVariable localVariable1 = 
/* 119 */         (LocalVariable)this.itsVariables.elementAt(integer.intValue());
/* 120 */       if (!localVariable1.isParameter()) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 127 */     int i = this.itsVariables.size();
/* 128 */     LocalVariable localVariable = createLocalVariable(paramString, false);
/* 129 */     this.itsVariables.addElement(localVariable);
/* 130 */     this.itsVariableNames.put(paramString, new Integer(i));
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeLocal(String paramString) {
/* 135 */     Integer integer = (Integer)this.itsVariableNames.get(paramString);
/* 136 */     if (integer != null) {
/* 137 */       this.itsVariables.removeElementAt(integer.intValue());
/* 138 */       this.itsVariableNames.remove(paramString);
/* 139 */       Hashtable hashtable = new Hashtable(11);
/* 140 */       Enumeration enumeration = this.itsVariableNames.keys();
/* 141 */       while (enumeration.hasMoreElements()) {
/* 142 */         Object object = enumeration.nextElement();
/* 143 */         Integer integer1 = (Integer)this.itsVariableNames.get(object);
/* 144 */         int i = integer1.intValue();
/* 145 */         if (i > integer.intValue())
/* 146 */           integer1 = new Integer(i - 1); 
/* 147 */         hashtable.put(object, integer1);
/*     */       } 
/* 149 */       this.itsVariableNames = hashtable;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 154 */   protected Vector itsVariables = new Vector();
/*     */ 
/*     */   
/* 157 */   protected Hashtable itsVariableNames = new Hashtable(11);
/*     */   protected int varStart;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\VariableTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */