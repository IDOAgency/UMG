package org.mozilla.javascript;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class VariableTable {
  public int size() { return this.itsVariables.size(); }
  
  public int getParameterCount() { return this.varStart; }
  
  public LocalVariable createLocalVariable(String paramString, boolean paramBoolean) { return new LocalVariable(paramString, paramBoolean); }
  
  public LocalVariable get(int paramInt) { return (LocalVariable)this.itsVariables.elementAt(paramInt); }
  
  public LocalVariable get(String paramString) {
    Integer integer = (Integer)this.itsVariableNames.get(paramString);
    if (integer != null)
      return (LocalVariable)this.itsVariables.elementAt(integer.intValue()); 
    return null;
  }
  
  public int getOrdinal(String paramString) {
    Integer integer = (Integer)this.itsVariableNames.get(paramString);
    if (integer != null)
      return integer.intValue(); 
    return -1;
  }
  
  public String getName(int paramInt) { return ((LocalVariable)this.itsVariables.elementAt(paramInt)).getName(); }
  
  public void establishIndices() {
    for (byte b = 0; b < this.itsVariables.size(); b++) {
      LocalVariable localVariable = (LocalVariable)this.itsVariables.elementAt(b);
      localVariable.setIndex(b);
    } 
  }
  
  public void addParameter(String paramString) {
    Integer integer = (Integer)this.itsVariableNames.get(paramString);
    if (integer != null) {
      LocalVariable localVariable1 = 
        (LocalVariable)this.itsVariables.elementAt(integer.intValue());
      if (localVariable1.isParameter()) {
        Object[] arrayOfObject = { paramString };
        String str = Context.getMessage("msg.dup.parms", arrayOfObject);
        Context.reportWarning(str, null, 0, null, 0);
      } else {
        this.itsVariables.removeElementAt(integer.intValue());
      } 
    } 
    int i = this.varStart++;
    LocalVariable localVariable = createLocalVariable(paramString, true);
    this.itsVariables.insertElementAt(localVariable, i);
    this.itsVariableNames.put(paramString, new Integer(i));
  }
  
  public void addLocal(String paramString) {
    Integer integer = (Integer)this.itsVariableNames.get(paramString);
    if (integer != null) {
      LocalVariable localVariable1 = 
        (LocalVariable)this.itsVariables.elementAt(integer.intValue());
      if (!localVariable1.isParameter())
        return; 
    } 
    int i = this.itsVariables.size();
    LocalVariable localVariable = createLocalVariable(paramString, false);
    this.itsVariables.addElement(localVariable);
    this.itsVariableNames.put(paramString, new Integer(i));
  }
  
  public void removeLocal(String paramString) {
    Integer integer = (Integer)this.itsVariableNames.get(paramString);
    if (integer != null) {
      this.itsVariables.removeElementAt(integer.intValue());
      this.itsVariableNames.remove(paramString);
      Hashtable hashtable = new Hashtable(11);
      Enumeration enumeration = this.itsVariableNames.keys();
      while (enumeration.hasMoreElements()) {
        Object object = enumeration.nextElement();
        Integer integer1 = (Integer)this.itsVariableNames.get(object);
        int i = integer1.intValue();
        if (i > integer.intValue())
          integer1 = new Integer(i - 1); 
        hashtable.put(object, integer1);
      } 
      this.itsVariableNames = hashtable;
    } 
  }
  
  protected Vector itsVariables = new Vector();
  
  protected Hashtable itsVariableNames = new Hashtable(11);
  
  protected int varStart;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\VariableTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */