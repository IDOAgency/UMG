package org.mozilla.javascript;

public interface ErrorReporter {
  void error(String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2);
  
  EvaluatorException runtimeError(String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2);
  
  void warning(String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\ErrorReporter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */