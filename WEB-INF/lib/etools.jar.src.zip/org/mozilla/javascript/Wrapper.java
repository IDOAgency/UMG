package org.mozilla.javascript;

public interface Wrapper {
  Object unwrap();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Wrapper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */