package org.mozilla.javascript;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

class FieldAndMethods extends NativeJavaMethod {
  private Field field;
  
  private Object javaObject;
  
  private String name;
  
  FieldAndMethods(Method[] paramArrayOfMethod, Field paramField, String paramString) {
    super(paramArrayOfMethod);
    this.field = paramField;
    this.name = paramString;
  }
  
  void setJavaObject(Object paramObject) { this.javaObject = paramObject; }
  
  String getName() {
    if (this.field == null)
      return this.name; 
    return this.field.getName();
  }
  
  Field getField() { return this.field; }
  
  public Object getDefaultValue(Class paramClass) {
    Class clazz;
    if (paramClass == ScriptRuntime.FunctionClass)
      return this; 
    try {
      object = this.field.get(this.javaObject);
      clazz = this.field.getType();
    } catch (IllegalAccessException illegalAccessException) {
      Object[] arrayOfObject = { getName() };
      throw Context.reportRuntimeError(
          Context.getMessage("msg.java.internal.private", arrayOfObject));
    } 
    Object object = NativeJavaObject.wrap(this, object, clazz);
    if (object instanceof Scriptable)
      object = ((Scriptable)object).getDefaultValue(paramClass); 
    return object;
  }
  
  public Object clone() {
    FieldAndMethods fieldAndMethods = new FieldAndMethods(this.methods, this.field, this.name);
    fieldAndMethods.javaObject = this.javaObject;
    return fieldAndMethods;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\FieldAndMethods.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */