package org.mozilla.javascript;

public class NativeFunction extends ScriptableObject implements Function {
  private static final int OFFSET = 4;
  
  private static final int SETBACK = 2;
  
  private static final boolean printSource = false;
  
  protected String[] names;
  
  protected short argCount;
  
  protected short version;
  
  protected String source;
  
  public NativeFunction[] nestedFunctions;
  
  public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) {
    paramFunctionObject.setPrototype(paramScriptable2);
    String[] arrayOfString = { "" };
    ((NativeFunction)paramScriptable2).names = arrayOfString;
  }
  
  public String getClassName() { return "Function"; }
  
  public boolean has(String paramString, Scriptable paramScriptable) { return !(!paramString.equals("prototype") && !paramString.equals("arguments") && 
      !super.has(paramString, paramScriptable)); }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    Object object = super.get(paramString, paramScriptable);
    if (object != Scriptable.NOT_FOUND)
      return object; 
    if (paramString.equals("prototype")) {
      NativeObject nativeObject = new NativeObject();
      byte b = 
        7;
      nativeObject.defineProperty("constructor", this, 7);
      put(paramString, this, nativeObject);
      Scriptable scriptable = ScriptableObject.getObjectPrototype(this);
      if (scriptable != nativeObject)
        nativeObject.setPrototype(scriptable); 
      return nativeObject;
    } 
    if (paramString.equals("arguments")) {
      NativeCall nativeCall = getActivation(Context.getContext());
      return (nativeCall == null) ? 
        null : 
        nativeCall.get("arguments", nativeCall);
    } 
    return Scriptable.NOT_FOUND;
  }
  
  public boolean hasInstance(Scriptable paramScriptable) {
    FlattenedObject flattenedObject = new FlattenedObject(this);
    Object object = flattenedObject.getProperty("prototype");
    if (object instanceof FlattenedObject) {
      object = ((FlattenedObject)object).getObject();
      if (object != Undefined.instance)
        return ScriptRuntime.jsDelegatesTo(paramScriptable, 
            (Scriptable)object); 
    } 
    Object[] arrayOfObject = { this.names[0] };
    String str = ScriptRuntime.getMessage("msg.instanceof.bad.prototype", 
        arrayOfObject);
    throw NativeGlobal.constructError(Context.getContext(), "TypeError", 
        str, paramScriptable);
  }
  
  public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException { return Undefined.instance; }
  
  protected Scriptable getClassPrototype() {
    Object object = get("prototype", this);
    if (object == null || 
      !(object instanceof Scriptable) || 
      object == Undefined.instance)
      object = ScriptableObject.getClassPrototype(this, "Object"); 
    return (Scriptable)object;
  }
  
  public Scriptable construct(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject) throws JavaScriptException {
    NativeObject nativeObject = new NativeObject();
    nativeObject.setPrototype(getClassPrototype());
    nativeObject.setParentScope(getParentScope());
    Object object = call(paramContext, paramScriptable, nativeObject, paramArrayOfObject);
    if (object != null && object != Undefined.instance && 
      object instanceof Scriptable)
      return (Scriptable)object; 
    return nativeObject;
  }
  
  private boolean nextIs(int paramInt1, int paramInt2) {
    if (paramInt1 + 1 < this.source.length())
      return !(this.source.charAt(paramInt1 + 1) != paramInt2); 
    return false;
  }
  
  public String decompile(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    if (this.source == null)
      return "function " + jsGet_name() + 
        "() {\n\t[native code]\n}\n"; 
    StringBuffer stringBuffer = new StringBuffer();
    char c = Character.MIN_VALUE;
    if (this.source.length() > 0) {
      if (paramBoolean1) {
        if (!paramBoolean2)
          stringBuffer.append('\n'); 
        for (byte b = 0; b < paramInt; b++)
          stringBuffer.append(' '); 
      } 
      if (this.source.charAt(0) == 'm')
        if (this.source.length() > 1 && (
          this.source.charAt(1) == ',' || 
          this.source.charAt(1) == ']'))
          if (!paramBoolean2) {
            stringBuffer.append("function ");
            if (nextIs(c, 93) && 
              this.version != 120 && 
              this.names != null && 
              this.names[0].equals("anonymous"))
              stringBuffer.append("anonymous"); 
            c++;
          } else {
            while (c < this.source.length()) {
              if (this.source.charAt(c) == '\001')
                if (c <= Character.MIN_VALUE || 
                  this.source.charAt(c - 1) != ',')
                  break;  
              c++;
            } 
            c++;
          }   
    } 
    while (c < this.source.length()) {
      double d;
      char c2;
      long l;
      char c1;
      switch (this.source.charAt(c)) {
        case ',':
        case '8':
          c++;
          c1 = c + this.source.charAt(c);
          stringBuffer.append(this.source.substring(c + '\001', c1 + '\001'));
          c = c1;
          break;
        case '-':
          c++;
          l = 0L;
          switch (this.source.charAt(c)) {
            case 'S':
              c++;
              stringBuffer.append(this.source.charAt(c));
              break;
            case 'J':
              c++;
              l |= this.source.charAt(c++) << 48;
              l |= this.source.charAt(c++) << 32;
              l |= this.source.charAt(c++) << 16;
              l |= this.source.charAt(c);
              stringBuffer.append(l);
              break;
            case 'D':
              c++;
              l |= this.source.charAt(c++) << 48;
              l |= this.source.charAt(c++) << 32;
              l |= this.source.charAt(c++) << 16;
              l |= this.source.charAt(c);
              d = Double.longBitsToDouble(l);
              stringBuffer.append(ScriptRuntime.numberToString(d, 10));
              break;
          } 
          break;
        case '.':
          c++;
          c1 = c + this.source.charAt(c);
          stringBuffer.append('"');
          stringBuffer.append(
              ScriptRuntime.escapeString(this.source.substring(c + '\001', c1 + '\001')));
          stringBuffer.append('"');
          c = c1;
          break;
        case 'l':
          c++;
          switch (this.source.charAt(c)) {
            case '4':
              stringBuffer.append("true");
              break;
            case '3':
              stringBuffer.append("false");
              break;
            case '1':
              stringBuffer.append("null");
              break;
            case '2':
              stringBuffer.append("this");
              break;
            case ' ':
              stringBuffer.append("typeof");
              break;
            case '':
              stringBuffer.append("void");
              break;
            case 'J':
              stringBuffer.append("undefined");
              break;
          } 
          break;
        case 'm':
          c++;
          c2 = this.source.charAt(c);
          if (this.nestedFunctions == null || 
            c2 > this.nestedFunctions.length) {
            String str;
            if (this.names != null && this.names.length > 0 && 
              this.names[0].length() > 0) {
              Object[] arrayOfObject = { new Integer(this.source.charAt(c)), 
                  this.names[0] };
              str = 
                Context.getMessage("msg.no.function.ref.found.in", arrayOfObject);
            } else {
              Object[] arrayOfObject = { new Integer(this.source.charAt(c)) };
              str = 
                Context.getMessage("msg.no.function.ref.found", arrayOfObject);
            } 
            throw Context.reportRuntimeError(str);
          } 
          stringBuffer.append(this.nestedFunctions[c2].decompile(paramInt, 
                false, 
                false));
          break;
        case '_':
          stringBuffer.append(", ");
          break;
        case '[':
          if (nextIs(c, 1))
            paramInt += 4; 
          stringBuffer.append("{");
          break;
        case '\\':
          if (!paramBoolean2 || !paramBoolean1 || c + '\001' != this.source.length()) {
            if (nextIs(c, 1))
              paramInt -= 4; 
            if (nextIs(c, 117) || 
              nextIs(c, 113)) {
              paramInt -= 4;
              stringBuffer.append("} ");
              break;
            } 
            stringBuffer.append('}');
          } 
          break;
        case ']':
          stringBuffer.append('(');
          break;
        case '^':
          if (nextIs(c, 91)) {
            stringBuffer.append(") ");
            break;
          } 
          stringBuffer.append(')');
          break;
        case 'Y':
          stringBuffer.append('[');
          break;
        case 'Z':
          stringBuffer.append(']');
          break;
        case '\001':
          stringBuffer.append('\n');
          if (c + '\001' < this.source.length()) {
            c2 = Character.MIN_VALUE;
            if (nextIs(c, 115) || 
              nextIs(c, 116)) {
              c2 = '\002';
            } else if (nextIs(c, 92)) {
              c2 = '\004';
            } else if (nextIs(c, 44)) {
              char c3 = this.source.charAt(c + '\002');
              if (this.source.charAt(c + c3 + '\003') == 'b')
                c2 = '\004'; 
            } 
            for (; c2 < paramInt; c2++)
              stringBuffer.append(' '); 
          } 
          break;
        case 'k':
          stringBuffer.append('.');
          break;
        case '\036':
          stringBuffer.append("new ");
          break;
        case '\037':
          stringBuffer.append("delete ");
          break;
        case 'p':
          stringBuffer.append("if ");
          break;
        case 'q':
          stringBuffer.append("else ");
          break;
        case 'w':
          stringBuffer.append("for ");
          break;
        case '?':
          stringBuffer.append(" in ");
          break;
        case '{':
          stringBuffer.append("with ");
          break;
        case 'u':
          stringBuffer.append("while ");
          break;
        case 'v':
          stringBuffer.append("do ");
          break;
        case 'K':
          stringBuffer.append("try ");
          break;
        case '|':
          stringBuffer.append("catch ");
          break;
        case '}':
          stringBuffer.append("finally ");
          break;
        case '>':
          stringBuffer.append("throw ");
          break;
        case 'r':
          stringBuffer.append("switch ");
          break;
        case 'x':
          if (nextIs(c, 44)) {
            stringBuffer.append("break ");
            break;
          } 
          stringBuffer.append("break");
          break;
        case 'y':
          if (nextIs(c, 44)) {
            stringBuffer.append("continue ");
            break;
          } 
          stringBuffer.append("continue");
          break;
        case 's':
          stringBuffer.append("case ");
          break;
        case 't':
          stringBuffer.append("default");
          break;
        case '\005':
          if (nextIs(c, 88)) {
            stringBuffer.append("return");
            break;
          } 
          stringBuffer.append("return ");
          break;
        case 'z':
          stringBuffer.append("var ");
          break;
        case 'X':
          if (nextIs(c, 1)) {
            stringBuffer.append(";");
            break;
          } 
          stringBuffer.append("; ");
          break;
        case '`':
          c++;
          switch (this.source.charAt(c)) {
            case '':
              stringBuffer.append(" = ");
              break;
            case '\027':
              stringBuffer.append(" += ");
              break;
            case '\030':
              stringBuffer.append(" -= ");
              break;
            case '\031':
              stringBuffer.append(" *= ");
              break;
            case '\032':
              stringBuffer.append(" /= ");
              break;
            case '\033':
              stringBuffer.append(" %= ");
              break;
            case '\013':
              stringBuffer.append(" |= ");
              break;
            case '\f':
              stringBuffer.append(" ^= ");
              break;
            case '\r':
              stringBuffer.append(" &= ");
              break;
            case '\024':
              stringBuffer.append(" <<= ");
              break;
            case '\025':
              stringBuffer.append(" >>= ");
              break;
            case '\026':
              stringBuffer.append(" >>>= ");
              break;
          } 
          break;
        case 'a':
          stringBuffer.append(" ? ");
          break;
        case '':
          stringBuffer.append(':');
          break;
        case 'b':
          if (nextIs(c, 1)) {
            stringBuffer.append(":");
            break;
          } 
          stringBuffer.append(" : ");
          break;
        case 'c':
          stringBuffer.append(" || ");
          break;
        case 'd':
          stringBuffer.append(" && ");
          break;
        case '\013':
          stringBuffer.append(" | ");
          break;
        case '\f':
          stringBuffer.append(" ^ ");
          break;
        case '\r':
          stringBuffer.append(" & ");
          break;
        case 'e':
          c++;
          switch (this.source.charAt(c)) {
            case '5':
              stringBuffer.append((this.version == 120) ? " == " : 
                  " === ");
              break;
            case '6':
              stringBuffer.append((this.version == 120) ? " != " : 
                  " !== ");
              break;
            case '\016':
              stringBuffer.append(" == ");
              break;
            case '\017':
              stringBuffer.append(" != ");
              break;
          } 
          break;
        case 'f':
          c++;
          switch (this.source.charAt(c)) {
            case '\021':
              stringBuffer.append(" <= ");
              break;
            case '\020':
              stringBuffer.append(" < ");
              break;
            case '\023':
              stringBuffer.append(" >= ");
              break;
            case '\022':
              stringBuffer.append(" > ");
              break;
            case '@':
              stringBuffer.append(" instanceof ");
              break;
          } 
          break;
        case 'g':
          c++;
          switch (this.source.charAt(c)) {
            case '\024':
              stringBuffer.append(" << ");
              break;
            case '\025':
              stringBuffer.append(" >> ");
              break;
            case '\026':
              stringBuffer.append(" >>> ");
              break;
          } 
          break;
        case 'h':
          c++;
          switch (this.source.charAt(c)) {
            case ' ':
              stringBuffer.append("typeof ");
              break;
            case '':
              stringBuffer.append("void ");
              break;
            case '':
              stringBuffer.append('!');
              break;
            case '\034':
              stringBuffer.append('~');
              break;
            case '\027':
              stringBuffer.append('+');
              break;
            case '\030':
              stringBuffer.append('-');
              break;
          } 
          break;
        case 'i':
          stringBuffer.append("++");
          break;
        case 'j':
          stringBuffer.append("--");
          break;
        case '\027':
          stringBuffer.append(" + ");
          break;
        case '\030':
          stringBuffer.append(" - ");
          break;
        case '\031':
          stringBuffer.append(" * ");
          break;
        case '\032':
          stringBuffer.append(" / ");
          break;
        case '\033':
          stringBuffer.append(" % ");
          break;
        default:
          throw new RuntimeException("Unknown token " + 
              this.source.charAt(c));
      } 
      c++;
    } 
    if (paramBoolean1 && !paramBoolean2)
      stringBuffer.append('\n'); 
    return stringBuffer.toString();
  }
  
  public static Object jsFunction_toString(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException {
    Object object = paramScriptable.getDefaultValue(ScriptRuntime.FunctionClass);
    if (!(object instanceof NativeFunction)) {
      Object[] arrayOfObject = { "toString" };
      String str = Context.getMessage("msg.incompat.call", arrayOfObject);
      throw NativeGlobal.constructError(paramContext, "TypeError", str, paramFunction);
    } 
    if (object instanceof NativeJavaMethod)
      return "\nfunction " + ((NativeFunction)object).jsGet_name() + 
        "() {/*\n" + object.toString() + "*/}\n"; 
    int i = 0;
    if (paramArrayOfObject.length > 0)
      i = (int)ScriptRuntime.toNumber(paramArrayOfObject[0]); 
    return ((NativeFunction)object).decompile(i, true, false);
  }
  
  public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
    int i = paramArrayOfObject.length;
    StringBuffer stringBuffer = new StringBuffer();
    byte b;
    for (b = 0; b < i - 1; b++) {
      if (b)
        stringBuffer.append(","); 
      stringBuffer.append(ScriptRuntime.toString(paramArrayOfObject[b]));
    } 
    String str1 = (i == 0) ? "" : ScriptRuntime.toString(paramArrayOfObject[b]);
    String str2 = "function (" + stringBuffer.toString() + ") {" + 
      str1 + "}";
    int[] arrayOfInt = new int[1];
    String str3 = Context.getSourcePositionFromStack(arrayOfInt);
    if (str3 == null) {
      str3 = "<eval'ed string>";
      arrayOfInt[0] = 1;
    } 
    Object object = paramContext.getSecurityDomainForStackDepth(4);
    Scriptable scriptable1 = paramContext.ctorScope;
    if (scriptable1 == null)
      scriptable1 = paramFunction; 
    Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable1);
    int j = paramContext.getOptimizationLevel();
    paramContext.setOptimizationLevel(-1);
    NativeFunction nativeFunction = (NativeFunction)paramContext.compileFunction(
        scriptable2, str2, 
        str3, arrayOfInt[0], 
        object);
    paramContext.setOptimizationLevel(j);
    if (nativeFunction.names == null)
      nativeFunction.names = new String[1]; 
    nativeFunction.names[0] = "anonymous";
    nativeFunction.setPrototype(ScriptableObject.getFunctionPrototype(scriptable2));
    nativeFunction.setParentScope(scriptable2);
    return nativeFunction;
  }
  
  public static Object jsFunction_apply(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException {
    Object[] arrayOfObject;
    if (paramArrayOfObject.length != 2)
      return jsFunction_call(paramContext, paramScriptable, paramArrayOfObject, paramFunction); 
    Object object = paramScriptable.getDefaultValue(ScriptRuntime.FunctionClass);
    Scriptable scriptable = (paramArrayOfObject[false] == null) ? 
      ScriptableObject.getTopLevelScope(paramScriptable) : 
      ScriptRuntime.toObject(paramFunction, paramArrayOfObject[0]);
    if (paramArrayOfObject.length > 1) {
      if (paramArrayOfObject[1] instanceof NativeArray || 
        paramArrayOfObject[1] instanceof Arguments) {
        arrayOfObject = paramContext.getElements((Scriptable)paramArrayOfObject[1]);
      } else {
        throw NativeGlobal.constructError(
            paramContext, "TypeError", 
            ScriptRuntime.getMessage("msg.arg.isnt.array", null), 
            paramScriptable);
      } 
    } else {
      arrayOfObject = new Object[0];
    } 
    return ScriptRuntime.call(paramContext, object, scriptable, arrayOfObject, scriptable);
  }
  
  public static Object jsFunction_call(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException {
    Object object = paramScriptable.getDefaultValue(ScriptRuntime.FunctionClass);
    if (paramArrayOfObject.length == 0) {
      Scriptable scriptable1 = ScriptRuntime.toObject(paramFunction, object);
      Scriptable scriptable2 = scriptable1.getParentScope();
      return ScriptRuntime.call(paramContext, object, scriptable2, ScriptRuntime.emptyArgs, 
          scriptable2);
    } 
    Scriptable scriptable = (paramArrayOfObject[false] == null) ? 
      ScriptableObject.getTopLevelScope(paramScriptable) : 
      ScriptRuntime.toObject(paramFunction, paramArrayOfObject[0]);
    Object[] arrayOfObject = new Object[paramArrayOfObject.length - 1];
    System.arraycopy(paramArrayOfObject, 1, arrayOfObject, 0, arrayOfObject.length);
    return ScriptRuntime.call(paramContext, object, scriptable, arrayOfObject, scriptable);
  }
  
  public int jsGet_length() {
    Context context = Context.getContext();
    if (context != null && context.getLanguageVersion() != 120)
      return this.argCount; 
    NativeCall nativeCall = getActivation(context);
    if (nativeCall == null)
      return this.argCount; 
    return nativeCall.getOriginalArguments().length;
  }
  
  public int jsGet_arity() { return this.argCount; }
  
  public String jsGet_name() {
    if (this.names == null)
      return ""; 
    if (this.names[0].equals("anonymous")) {
      Context context = Context.getCurrentContext();
      if (context != null && context.getLanguageVersion() == 120)
        return ""; 
    } 
    return this.names[0];
  }
  
  private NativeCall getActivation(Context paramContext) {
    NativeCall nativeCall = paramContext.currentActivation;
    while (nativeCall != null) {
      if (nativeCall.getFunctionObject() == this)
        return nativeCall; 
      nativeCall = nativeCall.caller;
    } 
    return null;
  }
  
  public int debug_level = -1;
  
  public String debug_srcName;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeFunction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */