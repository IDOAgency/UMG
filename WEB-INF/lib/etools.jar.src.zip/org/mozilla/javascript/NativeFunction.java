/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NativeFunction
/*      */   extends ScriptableObject
/*      */   implements Function
/*      */ {
/*      */   private static final int OFFSET = 4;
/*      */   private static final int SETBACK = 2;
/*      */   private static final boolean printSource = false;
/*      */   protected String[] names;
/*      */   protected short argCount;
/*      */   protected short version;
/*      */   protected String source;
/*      */   public NativeFunction[] nestedFunctions;
/*      */   
/*      */   public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) {
/*   55 */     paramFunctionObject.setPrototype(paramScriptable2);
/*      */     
/*   57 */     String[] arrayOfString = { "" };
/*   58 */     ((NativeFunction)paramScriptable2).names = arrayOfString;
/*      */   }
/*      */ 
/*      */   
/*   62 */   public String getClassName() { return "Function"; }
/*      */ 
/*      */ 
/*      */   
/*   66 */   public boolean has(String paramString, Scriptable paramScriptable) { return !(!paramString.equals("prototype") && !paramString.equals("arguments") && 
/*   67 */       !super.has(paramString, paramScriptable)); }
/*      */ 
/*      */   
/*      */   public Object get(String paramString, Scriptable paramScriptable) {
/*   71 */     Object object = super.get(paramString, paramScriptable);
/*   72 */     if (object != Scriptable.NOT_FOUND)
/*   73 */       return object; 
/*   74 */     if (paramString.equals("prototype")) {
/*   75 */       NativeObject nativeObject = new NativeObject();
/*   76 */       byte b = 
/*   77 */         7;
/*      */       
/*   79 */       nativeObject.defineProperty("constructor", this, 7);
/*      */ 
/*      */ 
/*      */       
/*   83 */       put(paramString, this, nativeObject);
/*   84 */       Scriptable scriptable = ScriptableObject.getObjectPrototype(this);
/*   85 */       if (scriptable != nativeObject)
/*   86 */         nativeObject.setPrototype(scriptable); 
/*   87 */       return nativeObject;
/*      */     } 
/*   89 */     if (paramString.equals("arguments")) {
/*      */ 
/*      */ 
/*      */       
/*   93 */       NativeCall nativeCall = getActivation(Context.getContext());
/*   94 */       return (nativeCall == null) ? 
/*   95 */         null : 
/*   96 */         nativeCall.get("arguments", nativeCall);
/*      */     } 
/*   98 */     return Scriptable.NOT_FOUND;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasInstance(Scriptable paramScriptable) {
/*  118 */     FlattenedObject flattenedObject = new FlattenedObject(this);
/*  119 */     Object object = flattenedObject.getProperty("prototype");
/*  120 */     if (object instanceof FlattenedObject) {
/*  121 */       object = ((FlattenedObject)object).getObject();
/*  122 */       if (object != Undefined.instance)
/*  123 */         return ScriptRuntime.jsDelegatesTo(paramScriptable, 
/*  124 */             (Scriptable)object); 
/*      */     } 
/*  126 */     Object[] arrayOfObject = { this.names[0] };
/*  127 */     String str = ScriptRuntime.getMessage("msg.instanceof.bad.prototype", 
/*  128 */         arrayOfObject);
/*  129 */     throw NativeGlobal.constructError(Context.getContext(), "TypeError", 
/*  130 */         str, paramScriptable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  140 */   public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException { return Undefined.instance; }
/*      */ 
/*      */   
/*      */   protected Scriptable getClassPrototype() {
/*  144 */     Object object = get("prototype", this);
/*  145 */     if (object == null || 
/*  146 */       !(object instanceof Scriptable) || 
/*  147 */       object == Undefined.instance)
/*  148 */       object = ScriptableObject.getClassPrototype(this, "Object"); 
/*  149 */     return (Scriptable)object;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Scriptable construct(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject) throws JavaScriptException {
/*  155 */     NativeObject nativeObject = new NativeObject();
/*      */     
/*  157 */     nativeObject.setPrototype(getClassPrototype());
/*  158 */     nativeObject.setParentScope(getParentScope());
/*      */     
/*  160 */     Object object = call(paramContext, paramScriptable, nativeObject, paramArrayOfObject);
/*  161 */     if (object != null && object != Undefined.instance && 
/*  162 */       object instanceof Scriptable)
/*      */     {
/*  164 */       return (Scriptable)object;
/*      */     }
/*  166 */     return nativeObject;
/*      */   }
/*      */   
/*      */   private boolean nextIs(int paramInt1, int paramInt2) {
/*  170 */     if (paramInt1 + 1 < this.source.length())
/*  171 */       return !(this.source.charAt(paramInt1 + 1) != paramInt2); 
/*  172 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String decompile(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
/*  210 */     if (this.source == null) {
/*  211 */       return "function " + jsGet_name() + 
/*  212 */         "() {\n\t[native code]\n}\n";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  237 */     StringBuffer stringBuffer = new StringBuffer();
/*      */     
/*  239 */     char c = Character.MIN_VALUE;
/*      */     
/*  241 */     if (this.source.length() > 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  253 */       if (paramBoolean1) {
/*      */         
/*  255 */         if (!paramBoolean2)
/*  256 */           stringBuffer.append('\n'); 
/*  257 */         for (byte b = 0; b < paramInt; b++) {
/*  258 */           stringBuffer.append(' ');
/*      */         }
/*      */       } 
/*  261 */       if (this.source.charAt(0) == 'm')
/*      */       {
/*      */         
/*  264 */         if (this.source.length() > 1 && (
/*  265 */           this.source.charAt(1) == ',' || 
/*  266 */           this.source.charAt(1) == ']'))
/*      */         {
/*  268 */           if (!paramBoolean2) {
/*  269 */             stringBuffer.append("function ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  280 */             if (nextIs(c, 93) && 
/*  281 */               this.version != 120 && 
/*  282 */               this.names != null && 
/*  283 */               this.names[0].equals("anonymous"))
/*  284 */               stringBuffer.append("anonymous"); 
/*  285 */             c++;
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  290 */             while (c < this.source.length()) {
/*  291 */               if (this.source.charAt(c) == '\001')
/*      */               {
/*      */                 
/*  294 */                 if (c <= Character.MIN_VALUE || 
/*  295 */                   this.source.charAt(c - 1) != ',')
/*      */                   break;  } 
/*  297 */               c++;
/*      */             } 
/*      */             
/*  300 */             c++;
/*      */           } 
/*      */         }
/*      */       }
/*      */     } 
/*  305 */     while (c < this.source.length()) {
/*      */       char c2; double d; long l; char c1;
/*  307 */       switch (this.source.charAt(c)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case ',':
/*      */         case '8':
/*  317 */           c++;
/*  318 */           c1 = c + this.source.charAt(c);
/*  319 */           stringBuffer.append(this.source.substring(c + '\001', c1 + '\001'));
/*  320 */           c = c1;
/*      */           break;
/*      */         
/*      */         case '-':
/*  324 */           c++;
/*  325 */           l = 0L;
/*  326 */           switch (this.source.charAt(c)) {
/*      */             case 'S':
/*  328 */               c++;
/*  329 */               stringBuffer.append(this.source.charAt(c));
/*      */               break;
/*      */             
/*      */             case 'J':
/*  333 */               c++;
/*  334 */               l |= this.source.charAt(c++) << 48;
/*  335 */               l |= this.source.charAt(c++) << 32;
/*  336 */               l |= this.source.charAt(c++) << 16;
/*  337 */               l |= this.source.charAt(c);
/*      */               
/*  339 */               stringBuffer.append(l);
/*      */               break;
/*      */             case 'D':
/*  342 */               c++;
/*      */               
/*  344 */               l |= this.source.charAt(c++) << 48;
/*  345 */               l |= this.source.charAt(c++) << 32;
/*  346 */               l |= this.source.charAt(c++) << 16;
/*  347 */               l |= this.source.charAt(c);
/*      */               
/*  349 */               d = Double.longBitsToDouble(l);
/*  350 */               stringBuffer.append(ScriptRuntime.numberToString(d, 10));
/*      */               break;
/*      */           } 
/*      */           
/*      */           break;
/*      */         case '.':
/*  356 */           c++;
/*  357 */           c1 = c + this.source.charAt(c);
/*  358 */           stringBuffer.append('"');
/*  359 */           stringBuffer.append(
/*  360 */               ScriptRuntime.escapeString(this.source.substring(c + '\001', c1 + '\001')));
/*  361 */           stringBuffer.append('"');
/*  362 */           c = c1;
/*      */           break;
/*      */         
/*      */         case 'l':
/*  366 */           c++;
/*  367 */           switch (this.source.charAt(c)) {
/*      */             case '4':
/*  369 */               stringBuffer.append("true");
/*      */               break;
/*      */             
/*      */             case '3':
/*  373 */               stringBuffer.append("false");
/*      */               break;
/*      */             
/*      */             case '1':
/*  377 */               stringBuffer.append("null");
/*      */               break;
/*      */             
/*      */             case '2':
/*  381 */               stringBuffer.append("this");
/*      */               break;
/*      */             
/*      */             case ' ':
/*  385 */               stringBuffer.append("typeof");
/*      */               break;
/*      */             
/*      */             case '':
/*  389 */               stringBuffer.append("void");
/*      */               break;
/*      */             
/*      */             case 'J':
/*  393 */               stringBuffer.append("undefined");
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 'm':
/*  404 */           c++;
/*  405 */           c2 = this.source.charAt(c);
/*  406 */           if (this.nestedFunctions == null || 
/*  407 */             c2 > this.nestedFunctions.length) {
/*      */             String str;
/*      */             
/*  410 */             if (this.names != null && this.names.length > 0 && 
/*  411 */               this.names[0].length() > 0) {
/*      */               
/*  413 */               Object[] arrayOfObject = { new Integer(this.source.charAt(c)), 
/*  414 */                   this.names[0] };
/*  415 */               str = 
/*  416 */                 Context.getMessage("msg.no.function.ref.found.in", arrayOfObject);
/*      */             } else {
/*  418 */               Object[] arrayOfObject = {
/*  419 */                   new Integer(this.source.charAt(c)) };
/*  420 */               str = 
/*  421 */                 Context.getMessage("msg.no.function.ref.found", arrayOfObject);
/*      */             } 
/*  423 */             throw Context.reportRuntimeError(str);
/*      */           } 
/*  425 */           stringBuffer.append(this.nestedFunctions[c2].decompile(paramInt, 
/*  426 */                 false, 
/*  427 */                 false));
/*      */           break;
/*      */         
/*      */         case '_':
/*  431 */           stringBuffer.append(", ");
/*      */           break;
/*      */         
/*      */         case '[':
/*  435 */           if (nextIs(c, 1))
/*  436 */             paramInt += 4; 
/*  437 */           stringBuffer.append("{");
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case '\\':
/*  445 */           if (!paramBoolean2 || !paramBoolean1 || c + '\001' != this.source.length()) {
/*      */ 
/*      */             
/*  448 */             if (nextIs(c, 1))
/*  449 */               paramInt -= 4; 
/*  450 */             if (nextIs(c, 117) || 
/*  451 */               nextIs(c, 113)) {
/*  452 */               paramInt -= 4;
/*  453 */               stringBuffer.append("} ");
/*      */               break;
/*      */             } 
/*  456 */             stringBuffer.append('}');
/*      */           } 
/*      */           break;
/*      */         case ']':
/*  460 */           stringBuffer.append('(');
/*      */           break;
/*      */         
/*      */         case '^':
/*  464 */           if (nextIs(c, 91)) {
/*  465 */             stringBuffer.append(") "); break;
/*      */           } 
/*  467 */           stringBuffer.append(')');
/*      */           break;
/*      */         
/*      */         case 'Y':
/*  471 */           stringBuffer.append('[');
/*      */           break;
/*      */         
/*      */         case 'Z':
/*  475 */           stringBuffer.append(']');
/*      */           break;
/*      */         
/*      */         case '\001':
/*  479 */           stringBuffer.append('\n');
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  485 */           if (c + '\001' < this.source.length()) {
/*  486 */             c2 = Character.MIN_VALUE;
/*  487 */             if (nextIs(c, 115) || 
/*  488 */               nextIs(c, 116)) {
/*  489 */               c2 = '\002';
/*  490 */             } else if (nextIs(c, 92)) {
/*  491 */               c2 = '\004';
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*  497 */             else if (nextIs(c, 44)) {
/*  498 */               char c3 = this.source.charAt(c + '\002');
/*  499 */               if (this.source.charAt(c + c3 + '\003') == 'b') {
/*  500 */                 c2 = '\004';
/*      */               }
/*      */             } 
/*  503 */             for (; c2 < paramInt; c2++) {
/*  504 */               stringBuffer.append(' ');
/*      */             }
/*      */           } 
/*      */           break;
/*      */         case 'k':
/*  509 */           stringBuffer.append('.');
/*      */           break;
/*      */         
/*      */         case '\036':
/*  513 */           stringBuffer.append("new ");
/*      */           break;
/*      */         
/*      */         case '\037':
/*  517 */           stringBuffer.append("delete ");
/*      */           break;
/*      */         
/*      */         case 'p':
/*  521 */           stringBuffer.append("if ");
/*      */           break;
/*      */         
/*      */         case 'q':
/*  525 */           stringBuffer.append("else ");
/*      */           break;
/*      */         
/*      */         case 'w':
/*  529 */           stringBuffer.append("for ");
/*      */           break;
/*      */         
/*      */         case '?':
/*  533 */           stringBuffer.append(" in ");
/*      */           break;
/*      */         
/*      */         case '{':
/*  537 */           stringBuffer.append("with ");
/*      */           break;
/*      */         
/*      */         case 'u':
/*  541 */           stringBuffer.append("while ");
/*      */           break;
/*      */         
/*      */         case 'v':
/*  545 */           stringBuffer.append("do ");
/*      */           break;
/*      */         
/*      */         case 'K':
/*  549 */           stringBuffer.append("try ");
/*      */           break;
/*      */         
/*      */         case '|':
/*  553 */           stringBuffer.append("catch ");
/*      */           break;
/*      */         
/*      */         case '}':
/*  557 */           stringBuffer.append("finally ");
/*      */           break;
/*      */         
/*      */         case '>':
/*  561 */           stringBuffer.append("throw ");
/*      */           break;
/*      */         
/*      */         case 'r':
/*  565 */           stringBuffer.append("switch ");
/*      */           break;
/*      */         
/*      */         case 'x':
/*  569 */           if (nextIs(c, 44)) {
/*  570 */             stringBuffer.append("break "); break;
/*      */           } 
/*  572 */           stringBuffer.append("break");
/*      */           break;
/*      */         
/*      */         case 'y':
/*  576 */           if (nextIs(c, 44)) {
/*  577 */             stringBuffer.append("continue "); break;
/*      */           } 
/*  579 */           stringBuffer.append("continue");
/*      */           break;
/*      */         
/*      */         case 's':
/*  583 */           stringBuffer.append("case ");
/*      */           break;
/*      */         
/*      */         case 't':
/*  587 */           stringBuffer.append("default");
/*      */           break;
/*      */         
/*      */         case '\005':
/*  591 */           if (nextIs(c, 88)) {
/*  592 */             stringBuffer.append("return"); break;
/*      */           } 
/*  594 */           stringBuffer.append("return ");
/*      */           break;
/*      */         
/*      */         case 'z':
/*  598 */           stringBuffer.append("var ");
/*      */           break;
/*      */         
/*      */         case 'X':
/*  602 */           if (nextIs(c, 1)) {
/*      */             
/*  604 */             stringBuffer.append(";");
/*      */             break;
/*      */           } 
/*  607 */           stringBuffer.append("; ");
/*      */           break;
/*      */         
/*      */         case '`':
/*  611 */           c++;
/*  612 */           switch (this.source.charAt(c)) {
/*      */             case '':
/*  614 */               stringBuffer.append(" = ");
/*      */               break;
/*      */             
/*      */             case '\027':
/*  618 */               stringBuffer.append(" += ");
/*      */               break;
/*      */             
/*      */             case '\030':
/*  622 */               stringBuffer.append(" -= ");
/*      */               break;
/*      */             
/*      */             case '\031':
/*  626 */               stringBuffer.append(" *= ");
/*      */               break;
/*      */             
/*      */             case '\032':
/*  630 */               stringBuffer.append(" /= ");
/*      */               break;
/*      */             
/*      */             case '\033':
/*  634 */               stringBuffer.append(" %= ");
/*      */               break;
/*      */             
/*      */             case '\013':
/*  638 */               stringBuffer.append(" |= ");
/*      */               break;
/*      */             
/*      */             case '\f':
/*  642 */               stringBuffer.append(" ^= ");
/*      */               break;
/*      */             
/*      */             case '\r':
/*  646 */               stringBuffer.append(" &= ");
/*      */               break;
/*      */             
/*      */             case '\024':
/*  650 */               stringBuffer.append(" <<= ");
/*      */               break;
/*      */             
/*      */             case '\025':
/*  654 */               stringBuffer.append(" >>= ");
/*      */               break;
/*      */             
/*      */             case '\026':
/*  658 */               stringBuffer.append(" >>>= ");
/*      */               break;
/*      */           } 
/*      */           
/*      */           break;
/*      */         case 'a':
/*  664 */           stringBuffer.append(" ? ");
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case '':
/*  672 */           stringBuffer.append(':');
/*      */           break;
/*      */         
/*      */         case 'b':
/*  676 */           if (nextIs(c, 1)) {
/*      */             
/*  678 */             stringBuffer.append(":");
/*      */             break;
/*      */           } 
/*  681 */           stringBuffer.append(" : ");
/*      */           break;
/*      */         
/*      */         case 'c':
/*  685 */           stringBuffer.append(" || ");
/*      */           break;
/*      */         
/*      */         case 'd':
/*  689 */           stringBuffer.append(" && ");
/*      */           break;
/*      */         
/*      */         case '\013':
/*  693 */           stringBuffer.append(" | ");
/*      */           break;
/*      */         
/*      */         case '\f':
/*  697 */           stringBuffer.append(" ^ ");
/*      */           break;
/*      */         
/*      */         case '\r':
/*  701 */           stringBuffer.append(" & ");
/*      */           break;
/*      */         
/*      */         case 'e':
/*  705 */           c++;
/*  706 */           switch (this.source.charAt(c)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case '5':
/*  715 */               stringBuffer.append((this.version == 120) ? " == " : 
/*  716 */                   " === ");
/*      */               break;
/*      */             
/*      */             case '6':
/*  720 */               stringBuffer.append((this.version == 120) ? " != " : 
/*  721 */                   " !== ");
/*      */               break;
/*      */             
/*      */             case '\016':
/*  725 */               stringBuffer.append(" == ");
/*      */               break;
/*      */             
/*      */             case '\017':
/*  729 */               stringBuffer.append(" != ");
/*      */               break;
/*      */           } 
/*      */           
/*      */           break;
/*      */         case 'f':
/*  735 */           c++;
/*  736 */           switch (this.source.charAt(c)) {
/*      */             case '\021':
/*  738 */               stringBuffer.append(" <= ");
/*      */               break;
/*      */             
/*      */             case '\020':
/*  742 */               stringBuffer.append(" < ");
/*      */               break;
/*      */             
/*      */             case '\023':
/*  746 */               stringBuffer.append(" >= ");
/*      */               break;
/*      */             
/*      */             case '\022':
/*  750 */               stringBuffer.append(" > ");
/*      */               break;
/*      */             
/*      */             case '@':
/*  754 */               stringBuffer.append(" instanceof ");
/*      */               break;
/*      */           } 
/*      */           
/*      */           break;
/*      */         case 'g':
/*  760 */           c++;
/*  761 */           switch (this.source.charAt(c)) {
/*      */             case '\024':
/*  763 */               stringBuffer.append(" << ");
/*      */               break;
/*      */             
/*      */             case '\025':
/*  767 */               stringBuffer.append(" >> ");
/*      */               break;
/*      */             
/*      */             case '\026':
/*  771 */               stringBuffer.append(" >>> ");
/*      */               break;
/*      */           } 
/*      */           
/*      */           break;
/*      */         case 'h':
/*  777 */           c++;
/*  778 */           switch (this.source.charAt(c)) {
/*      */             case ' ':
/*  780 */               stringBuffer.append("typeof ");
/*      */               break;
/*      */             
/*      */             case '':
/*  784 */               stringBuffer.append("void ");
/*      */               break;
/*      */             
/*      */             case '':
/*  788 */               stringBuffer.append('!');
/*      */               break;
/*      */             
/*      */             case '\034':
/*  792 */               stringBuffer.append('~');
/*      */               break;
/*      */             
/*      */             case '\027':
/*  796 */               stringBuffer.append('+');
/*      */               break;
/*      */             
/*      */             case '\030':
/*  800 */               stringBuffer.append('-');
/*      */               break;
/*      */           } 
/*      */           
/*      */           break;
/*      */         case 'i':
/*  806 */           stringBuffer.append("++");
/*      */           break;
/*      */         
/*      */         case 'j':
/*  810 */           stringBuffer.append("--");
/*      */           break;
/*      */         
/*      */         case '\027':
/*  814 */           stringBuffer.append(" + ");
/*      */           break;
/*      */         
/*      */         case '\030':
/*  818 */           stringBuffer.append(" - ");
/*      */           break;
/*      */         
/*      */         case '\031':
/*  822 */           stringBuffer.append(" * ");
/*      */           break;
/*      */         
/*      */         case '\032':
/*  826 */           stringBuffer.append(" / ");
/*      */           break;
/*      */         
/*      */         case '\033':
/*  830 */           stringBuffer.append(" % ");
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  835 */           throw new RuntimeException("Unknown token " + 
/*  836 */               this.source.charAt(c));
/*      */       } 
/*  838 */       c++;
/*      */     } 
/*      */ 
/*      */     
/*  842 */     if (paramBoolean1 && !paramBoolean2) {
/*  843 */       stringBuffer.append('\n');
/*      */     }
/*  845 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object jsFunction_toString(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException {
/*  851 */     Object object = paramScriptable.getDefaultValue(ScriptRuntime.FunctionClass);
/*  852 */     if (!(object instanceof NativeFunction)) {
/*  853 */       Object[] arrayOfObject = { "toString" };
/*  854 */       String str = Context.getMessage("msg.incompat.call", arrayOfObject);
/*  855 */       throw NativeGlobal.constructError(paramContext, "TypeError", str, paramFunction);
/*      */     } 
/*  857 */     if (object instanceof NativeJavaMethod) {
/*  858 */       return "\nfunction " + ((NativeFunction)object).jsGet_name() + 
/*  859 */         "() {/*\n" + object.toString() + "*/}\n";
/*      */     }
/*      */     
/*  862 */     int i = 0;
/*  863 */     if (paramArrayOfObject.length > 0) {
/*  864 */       i = (int)ScriptRuntime.toNumber(paramArrayOfObject[0]);
/*      */     }
/*  866 */     return ((NativeFunction)object).decompile(i, true, false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
/*  872 */     int i = paramArrayOfObject.length;
/*  873 */     StringBuffer stringBuffer = new StringBuffer();
/*      */ 
/*      */     
/*      */     byte b;
/*      */     
/*  878 */     for (b = 0; b < i - 1; b++) {
/*  879 */       if (b)
/*  880 */         stringBuffer.append(","); 
/*  881 */       stringBuffer.append(ScriptRuntime.toString(paramArrayOfObject[b]));
/*      */     } 
/*  883 */     String str1 = (i == 0) ? "" : ScriptRuntime.toString(paramArrayOfObject[b]);
/*      */     
/*  885 */     String str2 = "function (" + stringBuffer.toString() + ") {" + 
/*  886 */       str1 + "}";
/*  887 */     int[] arrayOfInt = new int[1];
/*  888 */     String str3 = Context.getSourcePositionFromStack(arrayOfInt);
/*  889 */     if (str3 == null) {
/*  890 */       str3 = "<eval'ed string>";
/*  891 */       arrayOfInt[0] = 1;
/*      */     } 
/*  893 */     Object object = paramContext.getSecurityDomainForStackDepth(4);
/*  894 */     Scriptable scriptable1 = paramContext.ctorScope;
/*  895 */     if (scriptable1 == null)
/*  896 */       scriptable1 = paramFunction; 
/*  897 */     Scriptable scriptable2 = ScriptableObject.getTopLevelScope(scriptable1);
/*      */ 
/*      */ 
/*      */     
/*  901 */     int j = paramContext.getOptimizationLevel();
/*  902 */     paramContext.setOptimizationLevel(-1);
/*  903 */     NativeFunction nativeFunction = (NativeFunction)paramContext.compileFunction(
/*  904 */         scriptable2, str2, 
/*  905 */         str3, arrayOfInt[0], 
/*  906 */         object);
/*  907 */     paramContext.setOptimizationLevel(j);
/*      */     
/*  909 */     if (nativeFunction.names == null)
/*  910 */       nativeFunction.names = new String[1]; 
/*  911 */     nativeFunction.names[0] = "anonymous";
/*  912 */     nativeFunction.setPrototype(ScriptableObject.getFunctionPrototype(scriptable2));
/*  913 */     nativeFunction.setParentScope(scriptable2);
/*      */     
/*  915 */     return nativeFunction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object jsFunction_apply(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException {
/*      */     Object[] arrayOfObject;
/*  927 */     if (paramArrayOfObject.length != 2)
/*  928 */       return jsFunction_call(paramContext, paramScriptable, paramArrayOfObject, paramFunction); 
/*  929 */     Object object = paramScriptable.getDefaultValue(ScriptRuntime.FunctionClass);
/*  930 */     Scriptable scriptable = (paramArrayOfObject[false] == null) ? 
/*  931 */       ScriptableObject.getTopLevelScope(paramScriptable) : 
/*  932 */       ScriptRuntime.toObject(paramFunction, paramArrayOfObject[0]);
/*      */     
/*  934 */     if (paramArrayOfObject.length > 1) {
/*  935 */       if (paramArrayOfObject[1] instanceof NativeArray || 
/*  936 */         paramArrayOfObject[1] instanceof Arguments) {
/*  937 */         arrayOfObject = paramContext.getElements((Scriptable)paramArrayOfObject[1]);
/*      */       } else {
/*  939 */         throw NativeGlobal.constructError(
/*  940 */             paramContext, "TypeError", 
/*  941 */             ScriptRuntime.getMessage("msg.arg.isnt.array", null), 
/*  942 */             paramScriptable);
/*      */       } 
/*      */     } else {
/*  945 */       arrayOfObject = new Object[0];
/*  946 */     }  return ScriptRuntime.call(paramContext, object, scriptable, arrayOfObject, scriptable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object jsFunction_call(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException {
/*  958 */     Object object = paramScriptable.getDefaultValue(ScriptRuntime.FunctionClass);
/*  959 */     if (paramArrayOfObject.length == 0) {
/*  960 */       Scriptable scriptable1 = ScriptRuntime.toObject(paramFunction, object);
/*  961 */       Scriptable scriptable2 = scriptable1.getParentScope();
/*  962 */       return ScriptRuntime.call(paramContext, object, scriptable2, ScriptRuntime.emptyArgs, 
/*  963 */           scriptable2);
/*      */     } 
/*  965 */     Scriptable scriptable = (paramArrayOfObject[false] == null) ? 
/*  966 */       ScriptableObject.getTopLevelScope(paramScriptable) : 
/*  967 */       ScriptRuntime.toObject(paramFunction, paramArrayOfObject[0]);
/*      */     
/*  969 */     Object[] arrayOfObject = new Object[paramArrayOfObject.length - 1];
/*  970 */     System.arraycopy(paramArrayOfObject, 1, arrayOfObject, 0, arrayOfObject.length);
/*  971 */     return ScriptRuntime.call(paramContext, object, scriptable, arrayOfObject, scriptable);
/*      */   }
/*      */ 
/*      */   
/*      */   public int jsGet_length() {
/*  976 */     Context context = Context.getContext();
/*  977 */     if (context != null && context.getLanguageVersion() != 120)
/*  978 */       return this.argCount; 
/*  979 */     NativeCall nativeCall = getActivation(context);
/*  980 */     if (nativeCall == null)
/*  981 */       return this.argCount; 
/*  982 */     return nativeCall.getOriginalArguments().length;
/*      */   }
/*      */ 
/*      */   
/*  986 */   public int jsGet_arity() { return this.argCount; }
/*      */ 
/*      */   
/*      */   public String jsGet_name() {
/*  990 */     if (this.names == null)
/*  991 */       return ""; 
/*  992 */     if (this.names[0].equals("anonymous")) {
/*  993 */       Context context = Context.getCurrentContext();
/*  994 */       if (context != null && context.getLanguageVersion() == 120)
/*  995 */         return ""; 
/*      */     } 
/*  997 */     return this.names[0];
/*      */   }
/*      */   
/*      */   private NativeCall getActivation(Context paramContext) {
/* 1001 */     NativeCall nativeCall = paramContext.currentActivation;
/* 1002 */     while (nativeCall != null) {
/* 1003 */       if (nativeCall.getFunctionObject() == this)
/* 1004 */         return nativeCall; 
/* 1005 */       nativeCall = nativeCall.caller;
/*      */     } 
/* 1007 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1038 */   public int debug_level = -1;
/*      */   public String debug_srcName;
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeFunction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */