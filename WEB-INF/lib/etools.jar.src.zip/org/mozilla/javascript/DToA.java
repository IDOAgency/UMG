package org.mozilla.javascript;

import java.math.BigInteger;

class DToA {
  static final int DTOBASESTR_BUFFER_SIZE = 1078;
  
  static final int DTOSTR_STANDARD = 0;
  
  static final int DTOSTR_STANDARD_EXPONENTIAL = 1;
  
  static final int DTOSTR_FIXED = 2;
  
  static final int DTOSTR_EXPONENTIAL = 3;
  
  static final int DTOSTR_PRECISION = 4;
  
  static final int Frac_mask = 1048575;
  
  static final int Exp_shift = 20;
  
  static final int Exp_msk1 = 1048576;
  
  static final int Bias = 1023;
  
  static final int P = 53;
  
  static final int Exp_shift1 = 20;
  
  static final int Exp_mask = 2146435072;
  
  static final int Bndry_mask = 1048575;
  
  static final int Log2P = 1;
  
  static final int Sign_bit = -2147483648;
  
  static final int Exp_11 = 1072693248;
  
  static final int Ten_pmax = 22;
  
  static final int Quick_max = 14;
  
  static final int Bletch = 16;
  
  static final int Frac_mask1 = 1048575;
  
  static final int Int_max = 14;
  
  static final int n_bigtens = 5;
  
  static char BASEDIGIT(int paramInt) { return (char)((paramInt >= 10) ? (87 + paramInt) : (48 + paramInt)); }
  
  static final double[] tens = { 
      1.0D, 10.0D, 100.0D, 1000.0D, 10000.0D, 100000.0D, 1000000.0D, 1.0E7D, 1.0E8D, 1.0E9D, 
      1.0E10D, 1.0E11D, 1.0E12D, 1.0E13D, 1.0E14D, 1.0E15D, 1.0E16D, 1.0E17D, 1.0E18D, 1.0E19D, 
      1.0E20D, 1.0E21D, 1.0E22D };
  
  static final double[] bigtens = { 1.0E16D, 1.0E32D, 1.0E64D, 1.0E128D, 1.0E256D };
  
  static int lo0bits(int paramInt) {
    int i = paramInt;
    if ((i & 0x7) != 0) {
      if ((i & true) != 0)
        return 0; 
      if ((i & 0x2) != 0)
        return 1; 
      return 2;
    } 
    byte b = 0;
    if ((i & 0xFFFF) == 0) {
      b = 16;
      i >>>= 16;
    } 
    if ((i & 0xFF) == 0) {
      b += 8;
      i >>>= 8;
    } 
    if ((i & 0xF) == 0) {
      b += 4;
      i >>>= 4;
    } 
    if ((i & 0x3) == 0) {
      b += 2;
      i >>>= 2;
    } 
    if ((i & true) == 0) {
      b++;
      i >>>= 1;
      if ((i & true) == 0)
        return 32; 
    } 
    return b;
  }
  
  static int hi0bits(int paramInt) {
    byte b = 0;
    if ((paramInt & 0xFFFF0000) == 0) {
      b = 16;
      paramInt <<= 16;
    } 
    if ((paramInt & 0xFF000000) == 0) {
      b += 8;
      paramInt <<= 8;
    } 
    if ((paramInt & 0xF0000000) == 0) {
      b += 4;
      paramInt <<= 4;
    } 
    if ((paramInt & 0xC0000000) == 0) {
      b += 2;
      paramInt <<= 2;
    } 
    if ((paramInt & 0x80000000) == 0) {
      b++;
      if ((paramInt & 0x40000000) == 0)
        return 32; 
    } 
    return b;
  }
  
  static void stuffBits(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    paramArrayOfByte[paramInt1] = (byte)(paramInt2 >> 24);
    paramArrayOfByte[paramInt1 + 1] = (byte)(paramInt2 >> 16);
    paramArrayOfByte[paramInt1 + 2] = (byte)(paramInt2 >> 8);
    paramArrayOfByte[paramInt1 + 3] = (byte)paramInt2;
  }
  
  static BigInteger d2b(double paramDouble, int[] paramArrayOfInt1, int[] paramArrayOfInt2) {
    int i;
    boolean bool;
    byte[] arrayOfByte;
    long l = Double.doubleToLongBits(paramDouble);
    int n = (int)(l >>> 32);
    int i1 = (int)l;
    int k = n & 0xFFFFF;
    n &= Integer.MAX_VALUE;
    int m;
    if ((m = n >>> 20) != 0)
      k |= 0x100000; 
    int j;
    if ((j = i1) != 0) {
      arrayOfByte = new byte[8];
      i = lo0bits(j);
      j >>>= i;
      if (i != 0) {
        stuffBits(arrayOfByte, 4, j | k << 32 - i);
        k >>= i;
      } else {
        stuffBits(arrayOfByte, 4, j);
      } 
      stuffBits(arrayOfByte, 0, k);
      bool = (k != 0) ? true : true;
    } else {
      arrayOfByte = new byte[4];
      i = lo0bits(k);
      k >>>= i;
      stuffBits(arrayOfByte, 0, k);
      i += 32;
      bool = true;
    } 
    if (m != 0) {
      paramArrayOfInt1[0] = m - 1023 - 52 + i;
      paramArrayOfInt2[0] = 53 - i;
    } else {
      paramArrayOfInt1[0] = m - 1023 - 52 + 1 + i;
      paramArrayOfInt2[0] = 32 * bool - hi0bits(k);
    } 
    return new BigInteger(arrayOfByte);
  }
  
  public static String JS_dtobasestr(int paramInt, double paramDouble) {
    char[] arrayOfChar = new char[1078];
    int i = 0;
    if (paramDouble < 0.0D) {
      arrayOfChar[i++] = '-';
      paramDouble = -paramDouble;
    } 
    if (Double.isNaN(paramDouble))
      return "NaN"; 
    if (Double.isInfinite(paramDouble))
      return "Infinity"; 
    byte b = i;
    double d1 = (int)paramDouble;
    BigInteger bigInteger = BigInteger.valueOf((int)d1);
    String str = bigInteger.toString(paramInt);
    str.getChars(0, str.length(), arrayOfChar, i);
    i += str.length();
    double d2 = paramDouble - d1;
    if (d2 != 0.0D) {
      arrayOfChar[i++] = '.';
      long l = Double.doubleToLongBits(paramDouble);
      int j = (int)(l >> 32);
      int k = (int)l;
      int[] arrayOfInt1 = new int[1];
      int[] arrayOfInt2 = new int[1];
      bigInteger = d2b(d2, arrayOfInt1, arrayOfInt2);
      int m = -(j >>> 20 & 0x7FF);
      if (m == 0)
        m = -1; 
      m += 1076;
      BigInteger bigInteger1 = BigInteger.valueOf(1L);
      BigInteger bigInteger2 = bigInteger1;
      if (k == 0 && (j & 0xFFFFF) == 0 && (
        j & 0x7FE00000) != 0) {
        m++;
        bigInteger2 = BigInteger.valueOf(2L);
      } 
      bigInteger = bigInteger.shiftLeft(arrayOfInt1[0] + m);
      BigInteger bigInteger3 = BigInteger.valueOf(1L);
      bigInteger3 = bigInteger3.shiftLeft(m);
      BigInteger bigInteger4 = BigInteger.valueOf(paramInt);
      boolean bool = false;
      do {
        bigInteger = bigInteger.multiply(bigInteger4);
        BigInteger[] arrayOfBigInteger = bigInteger.divideAndRemainder(bigInteger3);
        bigInteger = arrayOfBigInteger[1];
        char c = (char)arrayOfBigInteger[0].intValue();
        if (bigInteger1 == bigInteger2) {
          bigInteger1 = bigInteger2 = bigInteger1.multiply(bigInteger4);
        } else {
          bigInteger1 = bigInteger1.multiply(bigInteger4);
          bigInteger2 = bigInteger2.multiply(bigInteger4);
        } 
        int n = bigInteger.compareTo(bigInteger1);
        BigInteger bigInteger5 = bigInteger3.subtract(bigInteger2);
        int i1 = (bigInteger5.signum() <= 0) ? 1 : bigInteger.compareTo(bigInteger5);
        if (!i1 && (k & true) == 0) {
          if (n > 0)
            c++; 
          bool = true;
        } else if (n < 0 || (n == 0 && (k & true) == 0)) {
          if (i1) {
            bigInteger = bigInteger.shiftLeft(1);
            i1 = bigInteger.compareTo(bigInteger3);
            if (i1 > 0)
              c++; 
          } 
          bool = true;
        } else if (i1 > 0) {
          c++;
          bool = true;
        } 
        arrayOfChar[i++] = BASEDIGIT(c);
      } while (!bool);
    } 
    return new String(arrayOfChar, 0, i);
  }
  
  static int word0(double paramDouble) {
    long l = Double.doubleToLongBits(paramDouble);
    return (int)(l >> 32);
  }
  
  static double setWord0(double paramDouble, int paramInt) {
    long l = Double.doubleToLongBits(paramDouble);
    l = paramInt << 32 | l & 0xFFFFFFFFL;
    return Double.longBitsToDouble(l);
  }
  
  static int word1(double paramDouble) {
    long l = Double.doubleToLongBits(paramDouble);
    return (int)l;
  }
  
  static BigInteger pow5mult(BigInteger paramBigInteger, int paramInt) { return paramBigInteger.multiply(BigInteger.valueOf(5L).pow(paramInt)); }
  
  static boolean roundOff(StringBuffer paramStringBuffer) {
    char c;
    while ((c = paramStringBuffer.charAt(paramStringBuffer.length() - 1)) == '9') {
      paramStringBuffer.setLength(paramStringBuffer.length() - 1);
      if (paramStringBuffer.length() == 0)
        return true; 
    } 
    paramStringBuffer.append((char)(c + '\001'));
    return false;
  }
  
  static int JS_dtoa(double paramDouble, int paramInt1, boolean paramBoolean, int paramInt2, boolean[] paramArrayOfBoolean, StringBuffer paramStringBuffer) {
    boolean bool2;
    double d1;
    char c;
    int i6, i5, j, i, arrayOfInt1[] = new int[1];
    int[] arrayOfInt2 = new int[1];
    if ((word0(paramDouble) & 0x80000000) != 0) {
      paramArrayOfBoolean[0] = true;
      paramDouble = setWord0(paramDouble, word0(paramDouble) & 0x7FFFFFFF);
    } else {
      paramArrayOfBoolean[0] = false;
    } 
    if ((word0(paramDouble) & 0x7FF00000) == 2146435072) {
      paramStringBuffer.append((word1(paramDouble) == 0 && (word0(paramDouble) & 0xFFFFF) == 0) ? "Infinity" : "NaN");
      return 9999;
    } 
    if (paramDouble == 0.0D) {
      paramStringBuffer.setLength(0);
      paramStringBuffer.append('0');
      return 1;
    } 
    BigInteger bigInteger1 = d2b(paramDouble, arrayOfInt1, arrayOfInt2);
    int k;
    if ((k = word0(paramDouble) >>> 20 & 0x7FF) != 0) {
      d1 = setWord0(paramDouble, word0(paramDouble) & 0xFFFFF | 0x3FF00000);
      k -= 1023;
      bool2 = false;
    } else {
      k = arrayOfInt2[0] + arrayOfInt1[0] + 1074;
      long l = ((k > 32) ? (word0(paramDouble) << 64 - k | word1(paramDouble) >>> k - 32) : (word1(paramDouble) << 32 - k));
      d1 = setWord0(l, word0(l) - 32505856);
      k -= 1075;
      bool2 = true;
    } 
    double d2 = (d1 - 1.5D) * 0.289529654602168D + 0.1760912590558D + k * 0.301029995663981D;
    int i2 = (int)d2;
    if (d2 < 0.0D && d2 != i2)
      i2--; 
    boolean bool3 = true;
    if (i2 >= 0 && i2 <= 22) {
      if (paramDouble < tens[i2])
        i2--; 
      bool3 = false;
    } 
    int i1 = arrayOfInt2[0] - k - 1;
    if (i1 >= 0) {
      i = 0;
      i5 = i1;
    } else {
      i = -i1;
      i5 = 0;
    } 
    if (i2 >= 0) {
      j = 0;
      i6 = i2;
      i5 += i2;
    } else {
      i -= i2;
      j = -i2;
      i6 = 0;
    } 
    if (paramInt1 < 0 || paramInt1 > 9)
      paramInt1 = 0; 
    boolean bool4 = true;
    if (paramInt1 > 5) {
      paramInt1 -= 4;
      bool4 = false;
    } 
    boolean bool5 = true;
    int n = 0, m = n;
    switch (paramInt1) {
      case 0:
      case 1:
        m = n = -1;
        k = 18;
        paramInt2 = 0;
        break;
      case 2:
        bool5 = false;
      case 4:
        if (paramInt2 <= 0)
          paramInt2 = 1; 
        m = n = k = paramInt2;
        break;
      case 3:
        bool5 = false;
      case 5:
        k = paramInt2 + i2 + 1;
        m = k;
        n = k - 1;
        if (k <= 0)
          k = 1; 
        break;
    } 
    boolean bool6 = false;
    if (m >= 0 && m <= 14 && bool4) {
      k = 0;
      d1 = paramDouble;
      int i8 = i2;
      int i7 = m;
      byte b2 = 2;
      if (i2 > 0) {
        d2 = tens[i2 & 0xF];
        i1 = i2 >> 4;
        if ((i1 & 0x10) != 0) {
          i1 &= 0xF;
          paramDouble /= bigtens[4];
          b2++;
        } 
        for (; i1 != 0; i1 >>= 1, k++) {
          if ((i1 & true) != 0) {
            b2++;
            d2 *= bigtens[k];
          } 
        } 
        paramDouble /= d2;
      } else {
        int i9;
        if ((i9 = -i2) != 0) {
          paramDouble *= tens[i9 & 0xF];
          for (i1 = i9 >> 4; i1 != 0; i1 >>= 1, k++) {
            if ((i1 & true) != 0) {
              b2++;
              paramDouble *= bigtens[k];
            } 
          } 
        } 
      } 
      if (bool3 && paramDouble < 1.0D && m > 0)
        if (n <= 0) {
          bool6 = true;
        } else {
          m = n;
          i2--;
          paramDouble *= 10.0D;
          b2++;
        }  
      double d = b2 * paramDouble + 7.0D;
      d = setWord0(d, word0(d) - 54525952);
      if (m == 0) {
        Object object1 = null, object2 = object1;
        paramDouble -= 5.0D;
        if (paramDouble > d) {
          paramStringBuffer.append('1');
          i2++;
          return i2 + 1;
        } 
        if (paramDouble < -d) {
          paramStringBuffer.setLength(0);
          paramStringBuffer.append('0');
          return 1;
        } 
        bool6 = true;
      } 
      if (!bool6) {
        bool6 = true;
        if (bool5) {
          d = 0.5D / tens[m - 1] - d;
          k = 0;
          while (true) {
            long l = (long)paramDouble;
            paramDouble -= l;
            paramStringBuffer.append((char)(int)(48L + l));
            if (paramDouble < d)
              return i2 + 1; 
            if (1.0D - paramDouble < d) {
              char c1;
              while (true) {
                c1 = paramStringBuffer.charAt(paramStringBuffer.length() - 1);
                paramStringBuffer.setLength(paramStringBuffer.length() - 1);
                if (c1 == '9') {
                  if (paramStringBuffer.length() == 0) {
                    i2++;
                    c1 = '0';
                    break;
                  } 
                  continue;
                } 
                break;
              } 
              paramStringBuffer.append((char)(c1 + '\001'));
              return i2 + 1;
            } 
            if (++k < m) {
              d *= 10.0D;
              paramDouble *= 10.0D;
              continue;
            } 
            break;
          } 
        } else {
          d *= tens[m - 1];
          for (k = 1;; k++, paramDouble *= 10.0D) {
            long l = (long)paramDouble;
            paramDouble -= l;
            paramStringBuffer.append((char)(int)(48L + l));
            if (k == m) {
              if (paramDouble > 0.5D + d) {
                char c1;
                while (true) {
                  c1 = paramStringBuffer.charAt(paramStringBuffer.length() - 1);
                  paramStringBuffer.setLength(paramStringBuffer.length() - 1);
                  if (c1 == '9') {
                    if (paramStringBuffer.length() == 0) {
                      i2++;
                      c1 = '0';
                      break;
                    } 
                    continue;
                  } 
                  break;
                } 
                paramStringBuffer.append((char)(c1 + '\001'));
                return i2 + 1;
              } 
              if (paramDouble < 0.5D - d) {
                while (paramStringBuffer.charAt(paramStringBuffer.length() - 1) == '0')
                  paramStringBuffer.setLength(paramStringBuffer.length() - 1); 
                return i2 + 1;
              } 
              break;
            } 
          } 
        } 
      } 
      if (bool6) {
        paramStringBuffer.setLength(0);
        paramDouble = d1;
        i2 = i8;
        m = i7;
      } 
    } 
    if (arrayOfInt1[0] >= 0 && i2 <= 14) {
      d2 = tens[i2];
      if (paramInt2 < 0 && m <= 0) {
        Object object1 = null, object2 = object1;
        if (m < 0 || paramDouble < 5.0D * d2 || (!paramBoolean && paramDouble == 5.0D * d2)) {
          paramStringBuffer.setLength(0);
          paramStringBuffer.append('0');
          return 1;
        } 
        paramStringBuffer.append('1');
        i2++;
        return i2 + 1;
      } 
      for (k = 1;; k++) {
        long l = (long)(paramDouble / d2);
        paramDouble -= l * d2;
        paramStringBuffer.append((char)(int)(48L + l));
        if (k == m) {
          paramDouble += paramDouble;
          if (paramDouble > d2 || (paramDouble == d2 && ((l & 0x1L) != 0L || paramBoolean))) {
            char c1;
            while (true) {
              c1 = paramStringBuffer.charAt(paramStringBuffer.length() - 1);
              paramStringBuffer.setLength(paramStringBuffer.length() - 1);
              if (c1 == '9') {
                if (paramStringBuffer.length() == 0) {
                  i2++;
                  c1 = '0';
                  break;
                } 
                continue;
              } 
              break;
            } 
            paramStringBuffer.append((char)(c1 + '\001'));
          } 
          break;
        } 
        paramDouble *= 10.0D;
        if (paramDouble == 0.0D)
          break; 
      } 
      return i2 + 1;
    } 
    int i3 = i;
    int i4 = j;
    BigInteger bigInteger2 = null, bigInteger3 = bigInteger2;
    if (bool5) {
      if (paramInt1 < 2) {
        k = bool2 ? (arrayOfInt1[0] + 1075) : (54 - arrayOfInt2[0]);
      } else {
        i1 = m - 1;
        if (i4 >= i1) {
          i4 -= i1;
        } else {
          i6 += i1 -= i4;
          j += i1;
          i4 = 0;
        } 
        if ((k = m) < 0) {
          i3 -= k;
          k = 0;
        } 
      } 
      i += k;
      i5 += k;
      bigInteger3 = BigInteger.valueOf(1L);
    } 
    if (i3 > 0 && i5 > 0) {
      k = (i3 < i5) ? i3 : i5;
      i -= k;
      i3 -= k;
      i5 -= k;
    } 
    if (j > 0)
      if (bool5) {
        if (i4 > 0) {
          bigInteger3 = pow5mult(bigInteger3, i4);
          BigInteger bigInteger = bigInteger3.multiply(bigInteger1);
          bigInteger1 = bigInteger;
        } 
        if ((i1 = j - i4) != 0)
          bigInteger1 = pow5mult(bigInteger1, i1); 
      } else {
        bigInteger1 = pow5mult(bigInteger1, j);
      }  
    BigInteger bigInteger4 = BigInteger.valueOf(1L);
    if (i6 > 0)
      bigInteger4 = pow5mult(bigInteger4, i6); 
    boolean bool1 = false;
    if (paramInt1 < 2 && 
      word1(paramDouble) == 0 && (word0(paramDouble) & 0xFFFFF) == 0 && (
      word0(paramDouble) & 0x7FE00000) != 0) {
      i++;
      i5++;
      bool1 = true;
    } 
    byte[] arrayOfByte = bigInteger4.toByteArray();
    byte b = 0;
    for (byte b1 = 0; b1 < 4; b1++) {
      b <<= 8;
      if (b1 < arrayOfByte.length)
        b |= arrayOfByte[b1] & 0xFF; 
    } 
    if ((k = ((i6 != 0) ? (32 - hi0bits(b)) : 1) + i5 & 0x1F) != 0)
      k = 32 - k; 
    if (k > 4) {
      k -= 4;
      i += k;
      i3 += k;
      i5 += k;
    } else if (k < 4) {
      k += 28;
      i += k;
      i3 += k;
      i5 += k;
    } 
    if (i > 0)
      bigInteger1 = bigInteger1.shiftLeft(i); 
    if (i5 > 0)
      bigInteger4 = bigInteger4.shiftLeft(i5); 
    if (bool3 && 
      bigInteger1.compareTo(bigInteger4) < 0) {
      i2--;
      bigInteger1 = bigInteger1.multiply(BigInteger.valueOf(10L));
      if (bool5)
        bigInteger3 = bigInteger3.multiply(BigInteger.valueOf(10L)); 
      m = n;
    } 
    if (m <= 0 && paramInt1 > 2) {
      if (m < 0 || (
        k = bigInteger1.compareTo(bigInteger4 = bigInteger4.multiply(BigInteger.valueOf(5L)))) < 0 || (
        k == 0 && !paramBoolean)) {
        paramStringBuffer.setLength(0);
        paramStringBuffer.append('0');
        return 1;
      } 
      paramStringBuffer.append('1');
      i2++;
      return i2 + 1;
    } 
    if (bool5) {
      if (i3 > 0)
        bigInteger3 = bigInteger3.shiftLeft(i3); 
      bigInteger2 = bigInteger3;
      if (bool1) {
        bigInteger3 = bigInteger2;
        bigInteger3 = bigInteger3.shiftLeft(1);
      } 
      k = 1;
      while (true) {
        BigInteger[] arrayOfBigInteger = bigInteger1.divideAndRemainder(bigInteger4);
        bigInteger1 = arrayOfBigInteger[1];
        c = (char)(arrayOfBigInteger[0].intValue() + 48);
        i1 = bigInteger1.compareTo(bigInteger2);
        BigInteger bigInteger = bigInteger4.subtract(bigInteger3);
        int i7 = (bigInteger.signum() <= 0) ? 1 : bigInteger1.compareTo(bigInteger);
        if (!i7 && paramInt1 == 0 && (word1(paramDouble) & true) == 0) {
          if (c == '9') {
            paramStringBuffer.append('9');
            if (roundOff(paramStringBuffer)) {
              i2++;
              paramStringBuffer.append('1');
            } 
            return i2 + 1;
          } 
          if (i1 > 0)
            c = (char)(c + '\001'); 
          paramStringBuffer.append(c);
          return i2 + 1;
        } 
        if (i1 < 0 || (
          i1 == 0 && 
          paramInt1 == 0 && (
          word1(paramDouble) & true) == 0)) {
          if (i7) {
            bigInteger1 = bigInteger1.shiftLeft(1);
            i7 = bigInteger1.compareTo(bigInteger4);
            c = (char)(c + '\001');
            if ((i7 > 0 || (i7 == 0 && ((c & true) == '\001' || paramBoolean))) && c == '9') {
              paramStringBuffer.append('9');
              if (roundOff(paramStringBuffer)) {
                i2++;
                paramStringBuffer.append('1');
              } 
              return i2 + 1;
            } 
          } 
          paramStringBuffer.append(c);
          return i2 + 1;
        } 
        if (i7 > 0) {
          if (c == '9') {
            paramStringBuffer.append('9');
            if (roundOff(paramStringBuffer)) {
              i2++;
              paramStringBuffer.append('1');
            } 
            return i2 + 1;
          } 
          paramStringBuffer.append((char)(c + '\001'));
          return i2 + 1;
        } 
        paramStringBuffer.append(c);
        if (k != m) {
          bigInteger1 = bigInteger1.multiply(BigInteger.valueOf(10L));
          if (bigInteger2 == bigInteger3) {
            bigInteger2 = bigInteger3 = bigInteger3.multiply(BigInteger.valueOf(10L));
          } else {
            bigInteger2 = bigInteger2.multiply(BigInteger.valueOf(10L));
            bigInteger3 = bigInteger3.multiply(BigInteger.valueOf(10L));
          } 
          k++;
        } 
        break;
      } 
    } else {
      k = 1;
      while (true) {
        BigInteger[] arrayOfBigInteger = bigInteger1.divideAndRemainder(bigInteger4);
        bigInteger1 = arrayOfBigInteger[1];
        c = (char)(arrayOfBigInteger[0].intValue() + 48);
        paramStringBuffer.append(c);
        if (k < m) {
          bigInteger1 = bigInteger1.multiply(BigInteger.valueOf(10L));
          k++;
        } 
        break;
      } 
    } 
    bigInteger1 = bigInteger1.shiftLeft(1);
    i1 = bigInteger1.compareTo(bigInteger4);
    if (i1 > 0 || (i1 == 0 && ((c & true) == '\001' || paramBoolean))) {
      if (roundOff(paramStringBuffer)) {
        i2++;
        paramStringBuffer.append('1');
        return i2 + 1;
      } 
    } else {
      while (paramStringBuffer.charAt(paramStringBuffer.length() - 1) == '0')
        paramStringBuffer.setLength(paramStringBuffer.length() - 1); 
    } 
    return i2 + 1;
  }
  
  private static final int[] dtoaModes = { 0, 0, 3, 
      2, 
      2 };
  
  static void JS_dtostr(StringBuffer paramStringBuffer, int paramInt1, int paramInt2, double paramDouble) {
    boolean[] arrayOfBoolean = new boolean[1];
    if (paramInt1 == 2 && (paramDouble >= 1.0E21D || paramDouble <= -1.0E21D))
      paramInt1 = 0; 
    int i = JS_dtoa(paramDouble, dtoaModes[paramInt1], !(paramInt1 < 2), paramInt2, arrayOfBoolean, paramStringBuffer);
    int j = paramStringBuffer.length();
    if (i != 9999) {
      boolean bool = false;
      int k = 0;
      switch (paramInt1) {
        case 0:
          if (i < -5 || i > 21) {
            bool = true;
            break;
          } 
          k = i;
          break;
        case 2:
          if (paramInt2 >= 0) {
            k = i + paramInt2;
            break;
          } 
          k = i;
          break;
        case 3:
          k = paramInt2;
        case 1:
          bool = true;
          break;
        case 4:
          k = paramInt2;
          if (i < -5 || i > paramInt2)
            bool = true; 
          break;
      } 
      if (j < k) {
        int m = k;
        j = k;
        do {
          paramStringBuffer.append('0');
        } while (paramStringBuffer.length() != m);
      } 
      if (bool) {
        if (j != 1)
          paramStringBuffer.insert(1, '.'); 
        paramStringBuffer.append('e');
        if (i - 1 >= 0)
          paramStringBuffer.append('+'); 
        paramStringBuffer.append(i - 1);
      } else if (i != j) {
        if (i > 0) {
          paramStringBuffer.insert(i, '.');
        } else {
          for (byte b = 0; b < 1 - i; b++)
            paramStringBuffer.insert(0, '0'); 
          paramStringBuffer.insert(1, '.');
        } 
      } 
    } 
    if (arrayOfBoolean[0] && (
      word0(paramDouble) != Integer.MIN_VALUE || word1(paramDouble) != 0) && ((
      word0(paramDouble) & 0x7FF00000) != 2146435072 || (
      word1(paramDouble) == 0 && (word0(paramDouble) & 0xFFFFF) == 0)))
      paramStringBuffer.insert(0, '-'); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\DToA.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */