/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class DToA
/*      */ {
/*      */   static final int DTOBASESTR_BUFFER_SIZE = 1078;
/*      */   static final int DTOSTR_STANDARD = 0;
/*      */   static final int DTOSTR_STANDARD_EXPONENTIAL = 1;
/*      */   static final int DTOSTR_FIXED = 2;
/*      */   static final int DTOSTR_EXPONENTIAL = 3;
/*      */   static final int DTOSTR_PRECISION = 4;
/*      */   static final int Frac_mask = 1048575;
/*      */   static final int Exp_shift = 20;
/*      */   static final int Exp_msk1 = 1048576;
/*      */   static final int Bias = 1023;
/*      */   static final int P = 53;
/*      */   static final int Exp_shift1 = 20;
/*      */   static final int Exp_mask = 2146435072;
/*      */   static final int Bndry_mask = 1048575;
/*      */   static final int Log2P = 1;
/*      */   static final int Sign_bit = -2147483648;
/*      */   static final int Exp_11 = 1072693248;
/*      */   static final int Ten_pmax = 22;
/*      */   static final int Quick_max = 14;
/*      */   static final int Bletch = 16;
/*      */   static final int Frac_mask1 = 1048575;
/*      */   static final int Int_max = 14;
/*      */   static final int n_bigtens = 5;
/*      */   
/*   51 */   static char BASEDIGIT(int paramInt) { return (char)((paramInt >= 10) ? (87 + paramInt) : (48 + paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final double[] tens = { 
/*   84 */       1.0D, 10.0D, 100.0D, 1000.0D, 10000.0D, 100000.0D, 1000000.0D, 1.0E7D, 1.0E8D, 1.0E9D, 
/*   85 */       1.0E10D, 1.0E11D, 1.0E12D, 1.0E13D, 1.0E14D, 1.0E15D, 1.0E16D, 1.0E17D, 1.0E18D, 1.0E19D, 
/*   86 */       1.0E20D, 1.0E21D, 1.0E22D };
/*      */ 
/*      */   
/*   89 */   static final double[] bigtens = { 1.0E16D, 1.0E32D, 1.0E64D, 1.0E128D, 1.0E256D };
/*      */ 
/*      */ 
/*      */   
/*      */   static int lo0bits(int paramInt) {
/*   94 */     int i = paramInt;
/*      */     
/*   96 */     if ((i & 0x7) != 0) {
/*   97 */       if ((i & true) != 0)
/*   98 */         return 0; 
/*   99 */       if ((i & 0x2) != 0) {
/*  100 */         return 1;
/*      */       }
/*  102 */       return 2;
/*      */     } 
/*  104 */     byte b = 0;
/*  105 */     if ((i & 0xFFFF) == 0) {
/*  106 */       b = 16;
/*  107 */       i >>>= 16;
/*      */     } 
/*  109 */     if ((i & 0xFF) == 0) {
/*  110 */       b += 8;
/*  111 */       i >>>= 8;
/*      */     } 
/*  113 */     if ((i & 0xF) == 0) {
/*  114 */       b += 4;
/*  115 */       i >>>= 4;
/*      */     } 
/*  117 */     if ((i & 0x3) == 0) {
/*  118 */       b += 2;
/*  119 */       i >>>= 2;
/*      */     } 
/*  121 */     if ((i & true) == 0) {
/*  122 */       b++;
/*  123 */       i >>>= 1;
/*  124 */       if ((i & true) == 0)
/*  125 */         return 32; 
/*      */     } 
/*  127 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static int hi0bits(int paramInt) {
/*  133 */     byte b = 0;
/*      */     
/*  135 */     if ((paramInt & 0xFFFF0000) == 0) {
/*  136 */       b = 16;
/*  137 */       paramInt <<= 16;
/*      */     } 
/*  139 */     if ((paramInt & 0xFF000000) == 0) {
/*  140 */       b += 8;
/*  141 */       paramInt <<= 8;
/*      */     } 
/*  143 */     if ((paramInt & 0xF0000000) == 0) {
/*  144 */       b += 4;
/*  145 */       paramInt <<= 4;
/*      */     } 
/*  147 */     if ((paramInt & 0xC0000000) == 0) {
/*  148 */       b += 2;
/*  149 */       paramInt <<= 2;
/*      */     } 
/*  151 */     if ((paramInt & 0x80000000) == 0) {
/*  152 */       b++;
/*  153 */       if ((paramInt & 0x40000000) == 0)
/*  154 */         return 32; 
/*      */     } 
/*  156 */     return b;
/*      */   }
/*      */ 
/*      */   
/*      */   static void stuffBits(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
/*  161 */     paramArrayOfByte[paramInt1] = (byte)(paramInt2 >> 24);
/*  162 */     paramArrayOfByte[paramInt1 + 1] = (byte)(paramInt2 >> 16);
/*  163 */     paramArrayOfByte[paramInt1 + 2] = (byte)(paramInt2 >> 8);
/*  164 */     paramArrayOfByte[paramInt1 + 3] = (byte)paramInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static BigInteger d2b(double paramDouble, int[] paramArrayOfInt1, int[] paramArrayOfInt2) {
/*      */     int i;
/*      */     boolean bool;
/*      */     byte[] arrayOfByte;
/*  174 */     long l = Double.doubleToLongBits(paramDouble);
/*  175 */     int n = (int)(l >>> 32);
/*  176 */     int i1 = (int)l;
/*      */     
/*  178 */     int k = n & 0xFFFFF;
/*  179 */     n &= Integer.MAX_VALUE;
/*      */     int m;
/*  181 */     if ((m = n >>> 20) != 0)
/*  182 */       k |= 0x100000; 
/*      */     int j;
/*  184 */     if ((j = i1) != 0) {
/*  185 */       arrayOfByte = new byte[8];
/*  186 */       i = lo0bits(j);
/*  187 */       j >>>= i;
/*  188 */       if (i != 0) {
/*  189 */         stuffBits(arrayOfByte, 4, j | k << 32 - i);
/*  190 */         k >>= i;
/*      */       } else {
/*      */         
/*  193 */         stuffBits(arrayOfByte, 4, j);
/*  194 */       }  stuffBits(arrayOfByte, 0, k);
/*  195 */       bool = (k != 0) ? true : true;
/*      */     }
/*      */     else {
/*      */       
/*  199 */       arrayOfByte = new byte[4];
/*  200 */       i = lo0bits(k);
/*  201 */       k >>>= i;
/*  202 */       stuffBits(arrayOfByte, 0, k);
/*  203 */       i += 32;
/*  204 */       bool = true;
/*      */     } 
/*  206 */     if (m != 0) {
/*  207 */       paramArrayOfInt1[0] = m - 1023 - 52 + i;
/*  208 */       paramArrayOfInt2[0] = 53 - i;
/*      */     } else {
/*      */       
/*  211 */       paramArrayOfInt1[0] = m - 1023 - 52 + 1 + i;
/*  212 */       paramArrayOfInt2[0] = 32 * bool - hi0bits(k);
/*      */     } 
/*  214 */     return new BigInteger(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String JS_dtobasestr(int paramInt, double paramDouble) {
/*  230 */     char[] arrayOfChar = new char[1078];
/*      */     
/*  232 */     int i = 0;
/*  233 */     if (paramDouble < 0.0D) {
/*  234 */       arrayOfChar[i++] = '-';
/*  235 */       paramDouble = -paramDouble;
/*      */     } 
/*      */ 
/*      */     
/*  239 */     if (Double.isNaN(paramDouble)) {
/*  240 */       return "NaN";
/*      */     }
/*  242 */     if (Double.isInfinite(paramDouble)) {
/*  243 */       return "Infinity";
/*      */     }
/*      */     
/*  246 */     byte b = i;
/*  247 */     double d1 = (int)paramDouble;
/*  248 */     BigInteger bigInteger = BigInteger.valueOf((int)d1);
/*  249 */     String str = bigInteger.toString(paramInt);
/*  250 */     str.getChars(0, str.length(), arrayOfChar, i);
/*  251 */     i += str.length();
/*      */     
/*  253 */     double d2 = paramDouble - d1;
/*  254 */     if (d2 != 0.0D) {
/*      */       
/*  256 */       arrayOfChar[i++] = '.';
/*      */       
/*  258 */       long l = Double.doubleToLongBits(paramDouble);
/*  259 */       int j = (int)(l >> 32);
/*  260 */       int k = (int)l;
/*      */       
/*  262 */       int[] arrayOfInt1 = new int[1];
/*  263 */       int[] arrayOfInt2 = new int[1];
/*      */       
/*  265 */       bigInteger = d2b(d2, arrayOfInt1, arrayOfInt2);
/*      */ 
/*      */ 
/*      */       
/*  269 */       int m = -(j >>> 20 & 0x7FF);
/*  270 */       if (m == 0)
/*  271 */         m = -1; 
/*  272 */       m += 1076;
/*      */ 
/*      */       
/*  275 */       BigInteger bigInteger1 = BigInteger.valueOf(1L);
/*  276 */       BigInteger bigInteger2 = bigInteger1;
/*  277 */       if (k == 0 && (j & 0xFFFFF) == 0 && (
/*  278 */         j & 0x7FE00000) != 0) {
/*      */ 
/*      */         
/*  281 */         m++;
/*  282 */         bigInteger2 = BigInteger.valueOf(2L);
/*      */       } 
/*      */       
/*  285 */       bigInteger = bigInteger.shiftLeft(arrayOfInt1[0] + m);
/*  286 */       BigInteger bigInteger3 = BigInteger.valueOf(1L);
/*  287 */       bigInteger3 = bigInteger3.shiftLeft(m);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  293 */       BigInteger bigInteger4 = BigInteger.valueOf(paramInt);
/*      */       
/*  295 */       boolean bool = false;
/*      */       do {
/*  297 */         bigInteger = bigInteger.multiply(bigInteger4);
/*  298 */         BigInteger[] arrayOfBigInteger = bigInteger.divideAndRemainder(bigInteger3);
/*  299 */         bigInteger = arrayOfBigInteger[1];
/*  300 */         char c = (char)arrayOfBigInteger[0].intValue();
/*  301 */         if (bigInteger1 == bigInteger2) {
/*  302 */           bigInteger1 = bigInteger2 = bigInteger1.multiply(bigInteger4);
/*      */         } else {
/*  304 */           bigInteger1 = bigInteger1.multiply(bigInteger4);
/*  305 */           bigInteger2 = bigInteger2.multiply(bigInteger4);
/*      */         } 
/*      */ 
/*      */         
/*  309 */         int n = bigInteger.compareTo(bigInteger1);
/*      */         
/*  311 */         BigInteger bigInteger5 = bigInteger3.subtract(bigInteger2);
/*  312 */         int i1 = (bigInteger5.signum() <= 0) ? 1 : bigInteger.compareTo(bigInteger5);
/*      */         
/*  314 */         if (!i1 && (k & true) == 0) {
/*  315 */           if (n > 0)
/*  316 */             c++; 
/*  317 */           bool = true;
/*      */         }
/*  319 */         else if (n < 0 || (n == 0 && (k & true) == 0)) {
/*  320 */           if (i1) {
/*      */ 
/*      */             
/*  323 */             bigInteger = bigInteger.shiftLeft(1);
/*  324 */             i1 = bigInteger.compareTo(bigInteger3);
/*  325 */             if (i1 > 0)
/*      */             {
/*  327 */               c++; } 
/*      */           } 
/*  329 */           bool = true;
/*  330 */         } else if (i1 > 0) {
/*  331 */           c++;
/*  332 */           bool = true;
/*      */         } 
/*      */         
/*  335 */         arrayOfChar[i++] = BASEDIGIT(c);
/*  336 */       } while (!bool);
/*      */     } 
/*      */     
/*  339 */     return new String(arrayOfChar, 0, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int word0(double paramDouble) {
/*  378 */     long l = Double.doubleToLongBits(paramDouble);
/*  379 */     return (int)(l >> 32);
/*      */   }
/*      */ 
/*      */   
/*      */   static double setWord0(double paramDouble, int paramInt) {
/*  384 */     long l = Double.doubleToLongBits(paramDouble);
/*  385 */     l = paramInt << 32 | l & 0xFFFFFFFFL;
/*  386 */     return Double.longBitsToDouble(l);
/*      */   }
/*      */ 
/*      */   
/*      */   static int word1(double paramDouble) {
/*  391 */     long l = Double.doubleToLongBits(paramDouble);
/*  392 */     return (int)l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  399 */   static BigInteger pow5mult(BigInteger paramBigInteger, int paramInt) { return paramBigInteger.multiply(BigInteger.valueOf(5L).pow(paramInt)); }
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean roundOff(StringBuffer paramStringBuffer) {
/*      */     char c;
/*  405 */     while ((c = paramStringBuffer.charAt(paramStringBuffer.length() - 1)) == '9') {
/*  406 */       paramStringBuffer.setLength(paramStringBuffer.length() - 1);
/*  407 */       if (paramStringBuffer.length() == 0) {
/*  408 */         return true;
/*      */       }
/*      */     } 
/*  411 */     paramStringBuffer.append((char)(c + '\001'));
/*  412 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int JS_dtoa(double paramDouble, int paramInt1, boolean paramBoolean, int paramInt2, boolean[] paramArrayOfBoolean, StringBuffer paramStringBuffer) {
/*      */     boolean bool2;
/*      */     double d1;
/*      */     char c;
/*  466 */     int i6, i5, j, i, arrayOfInt1[] = new int[1];
/*  467 */     int[] arrayOfInt2 = new int[1];
/*      */ 
/*      */ 
/*      */     
/*  471 */     if ((word0(paramDouble) & 0x80000000) != 0) {
/*      */       
/*  473 */       paramArrayOfBoolean[0] = true;
/*      */       
/*  475 */       paramDouble = setWord0(paramDouble, word0(paramDouble) & 0x7FFFFFFF);
/*      */     } else {
/*      */       
/*  478 */       paramArrayOfBoolean[0] = false;
/*      */     } 
/*  480 */     if ((word0(paramDouble) & 0x7FF00000) == 2146435072) {
/*      */       
/*  482 */       paramStringBuffer.append((word1(paramDouble) == 0 && (word0(paramDouble) & 0xFFFFF) == 0) ? "Infinity" : "NaN");
/*  483 */       return 9999;
/*      */     } 
/*  485 */     if (paramDouble == 0.0D) {
/*      */       
/*  487 */       paramStringBuffer.setLength(0);
/*  488 */       paramStringBuffer.append('0');
/*  489 */       return 1;
/*      */     } 
/*      */     
/*  492 */     BigInteger bigInteger1 = d2b(paramDouble, arrayOfInt1, arrayOfInt2); int k;
/*  493 */     if ((k = word0(paramDouble) >>> 20 & 0x7FF) != 0) {
/*  494 */       d1 = setWord0(paramDouble, word0(paramDouble) & 0xFFFFF | 0x3FF00000);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  516 */       k -= 1023;
/*  517 */       bool2 = false;
/*      */     }
/*      */     else {
/*      */       
/*  521 */       k = arrayOfInt2[0] + arrayOfInt1[0] + 1074;
/*  522 */       long l = ((k > 32) ? (word0(paramDouble) << 64 - k | word1(paramDouble) >>> k - 32) : (word1(paramDouble) << 32 - k));
/*      */ 
/*      */       
/*  525 */       d1 = setWord0(l, word0(l) - 32505856);
/*  526 */       k -= 1075;
/*  527 */       bool2 = true;
/*      */     } 
/*      */     
/*  530 */     double d2 = (d1 - 1.5D) * 0.289529654602168D + 0.1760912590558D + k * 0.301029995663981D;
/*  531 */     int i2 = (int)d2;
/*  532 */     if (d2 < 0.0D && d2 != i2)
/*  533 */       i2--; 
/*  534 */     boolean bool3 = true;
/*  535 */     if (i2 >= 0 && i2 <= 22) {
/*  536 */       if (paramDouble < tens[i2])
/*  537 */         i2--; 
/*  538 */       bool3 = false;
/*      */     } 
/*      */ 
/*      */     
/*  542 */     int i1 = arrayOfInt2[0] - k - 1;
/*      */     
/*  544 */     if (i1 >= 0) {
/*  545 */       i = 0;
/*  546 */       i5 = i1;
/*      */     } else {
/*      */       
/*  549 */       i = -i1;
/*  550 */       i5 = 0;
/*      */     } 
/*  552 */     if (i2 >= 0) {
/*  553 */       j = 0;
/*  554 */       i6 = i2;
/*  555 */       i5 += i2;
/*      */     } else {
/*      */       
/*  558 */       i -= i2;
/*  559 */       j = -i2;
/*  560 */       i6 = 0;
/*      */     } 
/*      */ 
/*      */     
/*  564 */     if (paramInt1 < 0 || paramInt1 > 9)
/*  565 */       paramInt1 = 0; 
/*  566 */     boolean bool4 = true;
/*  567 */     if (paramInt1 > 5) {
/*  568 */       paramInt1 -= 4;
/*  569 */       bool4 = false;
/*      */     } 
/*  571 */     boolean bool5 = true;
/*  572 */     int n = 0, m = n;
/*  573 */     switch (paramInt1) {
/*      */       case 0:
/*      */       case 1:
/*  576 */         m = n = -1;
/*  577 */         k = 18;
/*  578 */         paramInt2 = 0;
/*      */         break;
/*      */       case 2:
/*  581 */         bool5 = false;
/*      */       
/*      */       case 4:
/*  584 */         if (paramInt2 <= 0)
/*  585 */           paramInt2 = 1; 
/*  586 */         m = n = k = paramInt2;
/*      */         break;
/*      */       case 3:
/*  589 */         bool5 = false;
/*      */       
/*      */       case 5:
/*  592 */         k = paramInt2 + i2 + 1;
/*  593 */         m = k;
/*  594 */         n = k - 1;
/*  595 */         if (k <= 0) {
/*  596 */           k = 1;
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  602 */     boolean bool6 = false;
/*  603 */     if (m >= 0 && m <= 14 && bool4) {
/*      */ 
/*      */ 
/*      */       
/*  607 */       k = 0;
/*  608 */       d1 = paramDouble;
/*  609 */       int i8 = i2;
/*  610 */       int i7 = m;
/*  611 */       byte b2 = 2;
/*      */       
/*  613 */       if (i2 > 0) {
/*  614 */         d2 = tens[i2 & 0xF];
/*  615 */         i1 = i2 >> 4;
/*  616 */         if ((i1 & 0x10) != 0) {
/*      */           
/*  618 */           i1 &= 0xF;
/*  619 */           paramDouble /= bigtens[4];
/*  620 */           b2++;
/*      */         } 
/*  622 */         for (; i1 != 0; i1 >>= 1, k++) {
/*  623 */           if ((i1 & true) != 0) {
/*  624 */             b2++;
/*  625 */             d2 *= bigtens[k];
/*      */           } 
/*  627 */         }  paramDouble /= d2;
/*      */       } else {
/*  629 */         int i9; if ((i9 = -i2) != 0) {
/*  630 */           paramDouble *= tens[i9 & 0xF];
/*  631 */           for (i1 = i9 >> 4; i1 != 0; i1 >>= 1, k++) {
/*  632 */             if ((i1 & true) != 0) {
/*  633 */               b2++;
/*  634 */               paramDouble *= bigtens[k];
/*      */             } 
/*      */           } 
/*      */         } 
/*  638 */       }  if (bool3 && paramDouble < 1.0D && m > 0) {
/*  639 */         if (n <= 0) {
/*  640 */           bool6 = true;
/*      */         } else {
/*  642 */           m = n;
/*  643 */           i2--;
/*  644 */           paramDouble *= 10.0D;
/*  645 */           b2++;
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  651 */       double d = b2 * paramDouble + 7.0D;
/*  652 */       d = setWord0(d, word0(d) - 54525952);
/*  653 */       if (m == 0) {
/*  654 */         Object object1 = null, object2 = object1;
/*  655 */         paramDouble -= 5.0D;
/*  656 */         if (paramDouble > d) {
/*  657 */           paramStringBuffer.append('1');
/*  658 */           i2++;
/*  659 */           return i2 + 1;
/*      */         } 
/*  661 */         if (paramDouble < -d) {
/*  662 */           paramStringBuffer.setLength(0);
/*  663 */           paramStringBuffer.append('0');
/*  664 */           return 1;
/*      */         } 
/*  666 */         bool6 = true;
/*      */       } 
/*  668 */       if (!bool6) {
/*  669 */         bool6 = true;
/*  670 */         if (bool5) {
/*      */ 
/*      */ 
/*      */           
/*  674 */           d = 0.5D / tens[m - 1] - d;
/*  675 */           k = 0; while (true) {
/*  676 */             long l = (long)paramDouble;
/*  677 */             paramDouble -= l;
/*  678 */             paramStringBuffer.append((char)(int)(48L + l));
/*  679 */             if (paramDouble < d) {
/*  680 */               return i2 + 1;
/*      */             }
/*  682 */             if (1.0D - paramDouble < d) {
/*      */               char c1;
/*      */               
/*      */               while (true) {
/*  686 */                 c1 = paramStringBuffer.charAt(paramStringBuffer.length() - 1);
/*  687 */                 paramStringBuffer.setLength(paramStringBuffer.length() - 1);
/*  688 */                 if (c1 == '9') {
/*  689 */                   if (paramStringBuffer.length() == 0) {
/*  690 */                     i2++;
/*  691 */                     c1 = '0'; break;
/*      */                   }  continue;
/*      */                 }  break;
/*      */               } 
/*  695 */               paramStringBuffer.append((char)(c1 + '\001'));
/*  696 */               return i2 + 1;
/*      */             } 
/*  698 */             if (++k < m) {
/*      */               
/*  700 */               d *= 10.0D;
/*  701 */               paramDouble *= 10.0D; continue;
/*      */             } 
/*      */             break;
/*      */           } 
/*      */         } else {
/*  706 */           d *= tens[m - 1];
/*  707 */           for (k = 1;; k++, paramDouble *= 10.0D) {
/*  708 */             long l = (long)paramDouble;
/*  709 */             paramDouble -= l;
/*  710 */             paramStringBuffer.append((char)(int)(48L + l));
/*  711 */             if (k == m) {
/*  712 */               if (paramDouble > 0.5D + d) {
/*      */                 char c1;
/*      */                 
/*      */                 while (true) {
/*  716 */                   c1 = paramStringBuffer.charAt(paramStringBuffer.length() - 1);
/*  717 */                   paramStringBuffer.setLength(paramStringBuffer.length() - 1);
/*  718 */                   if (c1 == '9') {
/*  719 */                     if (paramStringBuffer.length() == 0) {
/*  720 */                       i2++;
/*  721 */                       c1 = '0'; break;
/*      */                     }  continue;
/*      */                   }  break;
/*      */                 } 
/*  725 */                 paramStringBuffer.append((char)(c1 + '\001'));
/*  726 */                 return i2 + 1;
/*      */               } 
/*      */               
/*  729 */               if (paramDouble < 0.5D - d) {
/*  730 */                 while (paramStringBuffer.charAt(paramStringBuffer.length() - 1) == '0') {
/*  731 */                   paramStringBuffer.setLength(paramStringBuffer.length() - 1);
/*      */                 }
/*      */                 
/*  734 */                 return i2 + 1;
/*      */               } 
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  741 */       if (bool6) {
/*  742 */         paramStringBuffer.setLength(0);
/*  743 */         paramDouble = d1;
/*  744 */         i2 = i8;
/*  745 */         m = i7;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  751 */     if (arrayOfInt1[0] >= 0 && i2 <= 14) {
/*      */       
/*  753 */       d2 = tens[i2];
/*  754 */       if (paramInt2 < 0 && m <= 0) {
/*  755 */         Object object1 = null, object2 = object1;
/*  756 */         if (m < 0 || paramDouble < 5.0D * d2 || (!paramBoolean && paramDouble == 5.0D * d2)) {
/*  757 */           paramStringBuffer.setLength(0);
/*  758 */           paramStringBuffer.append('0');
/*  759 */           return 1;
/*      */         } 
/*  761 */         paramStringBuffer.append('1');
/*  762 */         i2++;
/*  763 */         return i2 + 1;
/*      */       } 
/*  765 */       for (k = 1;; k++) {
/*  766 */         long l = (long)(paramDouble / d2);
/*  767 */         paramDouble -= l * d2;
/*  768 */         paramStringBuffer.append((char)(int)(48L + l));
/*  769 */         if (k == m) {
/*  770 */           paramDouble += paramDouble;
/*  771 */           if (paramDouble > d2 || (paramDouble == d2 && ((l & 0x1L) != 0L || paramBoolean))) {
/*      */             char c1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             while (true) {
/*  782 */               c1 = paramStringBuffer.charAt(paramStringBuffer.length() - 1);
/*  783 */               paramStringBuffer.setLength(paramStringBuffer.length() - 1);
/*  784 */               if (c1 == '9') {
/*  785 */                 if (paramStringBuffer.length() == 0) {
/*  786 */                   i2++;
/*  787 */                   c1 = '0'; break;
/*      */                 }  continue;
/*      */               }  break;
/*      */             } 
/*  791 */             paramStringBuffer.append((char)(c1 + '\001'));
/*      */           } 
/*      */           break;
/*      */         } 
/*  795 */         paramDouble *= 10.0D;
/*  796 */         if (paramDouble == 0.0D)
/*      */           break; 
/*      */       } 
/*  799 */       return i2 + 1;
/*      */     } 
/*      */     
/*  802 */     int i3 = i;
/*  803 */     int i4 = j;
/*  804 */     BigInteger bigInteger2 = null, bigInteger3 = bigInteger2;
/*  805 */     if (bool5) {
/*  806 */       if (paramInt1 < 2) {
/*  807 */         k = bool2 ? (arrayOfInt1[0] + 1075) : (54 - arrayOfInt2[0]);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  812 */         i1 = m - 1;
/*  813 */         if (i4 >= i1) {
/*  814 */           i4 -= i1;
/*      */         } else {
/*  816 */           i6 += i1 -= i4;
/*  817 */           j += i1;
/*  818 */           i4 = 0;
/*      */         } 
/*  820 */         if ((k = m) < 0) {
/*  821 */           i3 -= k;
/*  822 */           k = 0;
/*      */         } 
/*      */       } 
/*      */       
/*  826 */       i += k;
/*  827 */       i5 += k;
/*  828 */       bigInteger3 = BigInteger.valueOf(1L);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  834 */     if (i3 > 0 && i5 > 0) {
/*  835 */       k = (i3 < i5) ? i3 : i5;
/*  836 */       i -= k;
/*  837 */       i3 -= k;
/*  838 */       i5 -= k;
/*      */     } 
/*      */ 
/*      */     
/*  842 */     if (j > 0) {
/*  843 */       if (bool5) {
/*  844 */         if (i4 > 0) {
/*  845 */           bigInteger3 = pow5mult(bigInteger3, i4);
/*  846 */           BigInteger bigInteger = bigInteger3.multiply(bigInteger1);
/*  847 */           bigInteger1 = bigInteger;
/*      */         } 
/*  849 */         if ((i1 = j - i4) != 0) {
/*  850 */           bigInteger1 = pow5mult(bigInteger1, i1);
/*      */         }
/*      */       } else {
/*  853 */         bigInteger1 = pow5mult(bigInteger1, j);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  858 */     BigInteger bigInteger4 = BigInteger.valueOf(1L);
/*  859 */     if (i6 > 0) {
/*  860 */       bigInteger4 = pow5mult(bigInteger4, i6);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  865 */     boolean bool1 = false;
/*  866 */     if (paramInt1 < 2 && 
/*  867 */       word1(paramDouble) == 0 && (word0(paramDouble) & 0xFFFFF) == 0 && (
/*  868 */       word0(paramDouble) & 0x7FE00000) != 0) {
/*      */ 
/*      */ 
/*      */       
/*  872 */       i++;
/*  873 */       i5++;
/*  874 */       bool1 = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  885 */     byte[] arrayOfByte = bigInteger4.toByteArray();
/*  886 */     byte b = 0;
/*  887 */     for (byte b1 = 0; b1 < 4; b1++) {
/*  888 */       b <<= 8;
/*  889 */       if (b1 < arrayOfByte.length)
/*  890 */         b |= arrayOfByte[b1] & 0xFF; 
/*      */     } 
/*  892 */     if ((k = ((i6 != 0) ? (32 - hi0bits(b)) : 1) + i5 & 0x1F) != 0) {
/*  893 */       k = 32 - k;
/*      */     }
/*  895 */     if (k > 4) {
/*  896 */       k -= 4;
/*  897 */       i += k;
/*  898 */       i3 += k;
/*  899 */       i5 += k;
/*      */     }
/*  901 */     else if (k < 4) {
/*  902 */       k += 28;
/*  903 */       i += k;
/*  904 */       i3 += k;
/*  905 */       i5 += k;
/*      */     } 
/*      */     
/*  908 */     if (i > 0)
/*  909 */       bigInteger1 = bigInteger1.shiftLeft(i); 
/*  910 */     if (i5 > 0) {
/*  911 */       bigInteger4 = bigInteger4.shiftLeft(i5);
/*      */     }
/*      */     
/*  914 */     if (bool3 && 
/*  915 */       bigInteger1.compareTo(bigInteger4) < 0) {
/*  916 */       i2--;
/*  917 */       bigInteger1 = bigInteger1.multiply(BigInteger.valueOf(10L));
/*  918 */       if (bool5)
/*  919 */         bigInteger3 = bigInteger3.multiply(BigInteger.valueOf(10L)); 
/*  920 */       m = n;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  925 */     if (m <= 0 && paramInt1 > 2) {
/*      */ 
/*      */       
/*  928 */       if (m < 0 || (
/*  929 */         k = bigInteger1.compareTo(bigInteger4 = bigInteger4.multiply(BigInteger.valueOf(5L)))) < 0 || (
/*  930 */         k == 0 && !paramBoolean)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  936 */         paramStringBuffer.setLength(0);
/*  937 */         paramStringBuffer.append('0');
/*  938 */         return 1;
/*      */       } 
/*      */ 
/*      */       
/*  942 */       paramStringBuffer.append('1');
/*  943 */       i2++;
/*  944 */       return i2 + 1;
/*      */     } 
/*  946 */     if (bool5) {
/*  947 */       if (i3 > 0) {
/*  948 */         bigInteger3 = bigInteger3.shiftLeft(i3);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  954 */       bigInteger2 = bigInteger3;
/*  955 */       if (bool1) {
/*  956 */         bigInteger3 = bigInteger2;
/*  957 */         bigInteger3 = bigInteger3.shiftLeft(1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  962 */       k = 1; while (true) {
/*  963 */         BigInteger[] arrayOfBigInteger = bigInteger1.divideAndRemainder(bigInteger4);
/*  964 */         bigInteger1 = arrayOfBigInteger[1];
/*  965 */         c = (char)(arrayOfBigInteger[0].intValue() + 48);
/*      */ 
/*      */ 
/*      */         
/*  969 */         i1 = bigInteger1.compareTo(bigInteger2);
/*      */         
/*  971 */         BigInteger bigInteger = bigInteger4.subtract(bigInteger3);
/*  972 */         int i7 = (bigInteger.signum() <= 0) ? 1 : bigInteger1.compareTo(bigInteger);
/*      */         
/*  974 */         if (!i7 && paramInt1 == 0 && (word1(paramDouble) & true) == 0) {
/*  975 */           if (c == '9') {
/*  976 */             paramStringBuffer.append('9');
/*  977 */             if (roundOff(paramStringBuffer)) {
/*  978 */               i2++;
/*  979 */               paramStringBuffer.append('1');
/*      */             } 
/*  981 */             return i2 + 1;
/*      */           } 
/*      */           
/*  984 */           if (i1 > 0)
/*  985 */             c = (char)(c + '\001'); 
/*  986 */           paramStringBuffer.append(c);
/*  987 */           return i2 + 1;
/*      */         } 
/*  989 */         if (i1 < 0 || (
/*  990 */           i1 == 0 && 
/*  991 */           paramInt1 == 0 && (
/*  992 */           word1(paramDouble) & true) == 0)) {
/*      */           
/*  994 */           if (i7) {
/*      */ 
/*      */             
/*  997 */             bigInteger1 = bigInteger1.shiftLeft(1);
/*  998 */             i7 = bigInteger1.compareTo(bigInteger4);
/*      */             
/* 1000 */             c = (char)(c + '\001'); if ((i7 > 0 || (i7 == 0 && ((c & true) == '\001' || paramBoolean))) && c == '9') {
/* 1001 */               paramStringBuffer.append('9');
/* 1002 */               if (roundOff(paramStringBuffer)) {
/* 1003 */                 i2++;
/* 1004 */                 paramStringBuffer.append('1');
/*      */               } 
/* 1006 */               return i2 + 1;
/*      */             } 
/*      */           } 
/*      */           
/* 1010 */           paramStringBuffer.append(c);
/* 1011 */           return i2 + 1;
/*      */         } 
/* 1013 */         if (i7 > 0) {
/* 1014 */           if (c == '9') {
/*      */ 
/*      */ 
/*      */             
/* 1018 */             paramStringBuffer.append('9');
/* 1019 */             if (roundOff(paramStringBuffer)) {
/* 1020 */               i2++;
/* 1021 */               paramStringBuffer.append('1');
/*      */             } 
/* 1023 */             return i2 + 1;
/*      */           } 
/* 1025 */           paramStringBuffer.append((char)(c + '\001'));
/* 1026 */           return i2 + 1;
/*      */         } 
/* 1028 */         paramStringBuffer.append(c);
/* 1029 */         if (k != m) {
/*      */           
/* 1031 */           bigInteger1 = bigInteger1.multiply(BigInteger.valueOf(10L));
/* 1032 */           if (bigInteger2 == bigInteger3) {
/* 1033 */             bigInteger2 = bigInteger3 = bigInteger3.multiply(BigInteger.valueOf(10L));
/*      */           } else {
/* 1035 */             bigInteger2 = bigInteger2.multiply(BigInteger.valueOf(10L));
/* 1036 */             bigInteger3 = bigInteger3.multiply(BigInteger.valueOf(10L));
/*      */           }  k++;
/*      */         }  break;
/*      */       } 
/*      */     } else {
/* 1041 */       k = 1;
/*      */       while (true) {
/* 1043 */         BigInteger[] arrayOfBigInteger = bigInteger1.divideAndRemainder(bigInteger4);
/* 1044 */         bigInteger1 = arrayOfBigInteger[1];
/* 1045 */         c = (char)(arrayOfBigInteger[0].intValue() + 48);
/* 1046 */         paramStringBuffer.append(c);
/* 1047 */         if (k < m) {
/*      */           
/* 1049 */           bigInteger1 = bigInteger1.multiply(BigInteger.valueOf(10L)); k++;
/*      */         } 
/*      */         break;
/*      */       } 
/*      */     } 
/* 1054 */     bigInteger1 = bigInteger1.shiftLeft(1);
/* 1055 */     i1 = bigInteger1.compareTo(bigInteger4);
/* 1056 */     if (i1 > 0 || (i1 == 0 && ((c & true) == '\001' || paramBoolean))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1065 */       if (roundOff(paramStringBuffer)) {
/* 1066 */         i2++;
/* 1067 */         paramStringBuffer.append('1');
/* 1068 */         return i2 + 1;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1073 */       while (paramStringBuffer.charAt(paramStringBuffer.length() - 1) == '0') {
/* 1074 */         paramStringBuffer.setLength(paramStringBuffer.length() - 1);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1088 */     return i2 + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1095 */   private static final int[] dtoaModes = { 0, 0, 3, 
/* 1096 */       2, 
/* 1097 */       2 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void JS_dtostr(StringBuffer paramStringBuffer, int paramInt1, int paramInt2, double paramDouble) {
/* 1103 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1109 */     if (paramInt1 == 2 && (paramDouble >= 1.0E21D || paramDouble <= -1.0E21D)) {
/* 1110 */       paramInt1 = 0;
/*      */     }
/* 1112 */     int i = JS_dtoa(paramDouble, dtoaModes[paramInt1], !(paramInt1 < 2), paramInt2, arrayOfBoolean, paramStringBuffer);
/* 1113 */     int j = paramStringBuffer.length();
/*      */ 
/*      */     
/* 1116 */     if (i != 9999) {
/* 1117 */       boolean bool = false;
/* 1118 */       int k = 0;
/*      */ 
/*      */ 
/*      */       
/* 1122 */       switch (paramInt1) {
/*      */         case 0:
/* 1124 */           if (i < -5 || i > 21) {
/* 1125 */             bool = true; break;
/*      */           } 
/* 1127 */           k = i;
/*      */           break;
/*      */         
/*      */         case 2:
/* 1131 */           if (paramInt2 >= 0) {
/* 1132 */             k = i + paramInt2; break;
/*      */           } 
/* 1134 */           k = i;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/* 1139 */           k = paramInt2;
/*      */         
/*      */         case 1:
/* 1142 */           bool = true;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 4:
/* 1147 */           k = paramInt2;
/* 1148 */           if (i < -5 || i > paramInt2) {
/* 1149 */             bool = true;
/*      */           }
/*      */           break;
/*      */       } 
/*      */       
/* 1154 */       if (j < k) {
/* 1155 */         int m = k;
/* 1156 */         j = k;
/*      */         do {
/* 1158 */           paramStringBuffer.append('0');
/* 1159 */         } while (paramStringBuffer.length() != m);
/*      */       } 
/*      */       
/* 1162 */       if (bool) {
/*      */         
/* 1164 */         if (j != 1) {
/* 1165 */           paramStringBuffer.insert(1, '.');
/*      */         }
/* 1167 */         paramStringBuffer.append('e');
/* 1168 */         if (i - 1 >= 0)
/* 1169 */           paramStringBuffer.append('+'); 
/* 1170 */         paramStringBuffer.append(i - 1);
/*      */       }
/* 1172 */       else if (i != j) {
/*      */ 
/*      */         
/* 1175 */         if (i > 0) {
/*      */           
/* 1177 */           paramStringBuffer.insert(i, '.');
/*      */         } else {
/*      */           
/* 1180 */           for (byte b = 0; b < 1 - i; b++)
/* 1181 */             paramStringBuffer.insert(0, '0'); 
/* 1182 */           paramStringBuffer.insert(1, '.');
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1188 */     if (arrayOfBoolean[0] && (
/* 1189 */       word0(paramDouble) != Integer.MIN_VALUE || word1(paramDouble) != 0) && ((
/* 1190 */       word0(paramDouble) & 0x7FF00000) != 2146435072 || (
/* 1191 */       word1(paramDouble) == 0 && (word0(paramDouble) & 0xFFFFF) == 0)))
/* 1192 */       paramStringBuffer.insert(0, '-'); 
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\DToA.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */