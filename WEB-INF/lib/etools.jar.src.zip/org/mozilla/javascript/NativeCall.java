/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NativeCall
/*     */   extends ScriptableObject
/*     */ {
/*     */   NativeCall caller;
/*     */   NativeFunction funObj;
/*     */   Scriptable thisObj;
/*     */   Object[] originalArgs;
/*     */   public int debugPC;
/*     */   
/*     */   NativeCall(Context paramContext, Scriptable paramScriptable1, NativeFunction paramNativeFunction, Scriptable paramScriptable2, Object[] paramArrayOfObject) {
/*  51 */     this(paramContext, paramScriptable1, paramNativeFunction, paramScriptable2);
/*  52 */     this.originalArgs = paramArrayOfObject;
/*     */ 
/*     */     
/*  55 */     String[] arrayOfString = paramNativeFunction.names;
/*  56 */     if (arrayOfString != null) {
/*  57 */       for (byte b = 0; b < paramNativeFunction.argCount; b++) {
/*  58 */         Object object = (b < paramArrayOfObject.length) ? paramArrayOfObject[b] : 
/*  59 */           Undefined.instance;
/*  60 */         put(arrayOfString[b + true], this, object);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  65 */     put("arguments", this, new Arguments(this));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   NativeCall(Context paramContext, Scriptable paramScriptable1, NativeFunction paramNativeFunction, Scriptable paramScriptable2) {
/*  71 */     this.funObj = paramNativeFunction;
/*  72 */     this.thisObj = paramScriptable2;
/*     */     
/*  74 */     setParentScope(paramScriptable1);
/*     */ 
/*     */ 
/*     */     
/*  78 */     this.caller = paramContext.currentActivation;
/*  79 */     paramContext.currentActivation = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeCall() {}
/*     */ 
/*     */   
/*  87 */   public String getClassName() { return "Call"; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
/*  93 */     if (!paramBoolean) {
/*  94 */       Object[] arrayOfObject = { "Call" };
/*  95 */       throw Context.reportRuntimeError(
/*  96 */           Context.getMessage("msg.only.from.new", arrayOfObject));
/*     */     } 
/*  98 */     ScriptRuntime.checkDeprecated(paramContext, "Call");
/*  99 */     NativeCall nativeCall = new NativeCall();
/* 100 */     nativeCall.setPrototype(ScriptableObject.getObjectPrototype(paramFunction));
/* 101 */     return nativeCall;
/*     */   }
/*     */   
/*     */   NativeCall getActivation(NativeFunction paramNativeFunction) {
/* 105 */     NativeCall nativeCall = this;
/*     */     do {
/* 107 */       if (nativeCall.funObj == paramNativeFunction)
/* 108 */         return nativeCall; 
/* 109 */       nativeCall = nativeCall.caller;
/* 110 */     } while (nativeCall != null);
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */   
/* 115 */   public NativeFunction getFunctionObject() { return this.funObj; }
/*     */ 
/*     */ 
/*     */   
/* 119 */   public Object[] getOriginalArguments() { return this.originalArgs; }
/*     */ 
/*     */ 
/*     */   
/* 123 */   public NativeCall getCaller() { return this.caller; }
/*     */ 
/*     */ 
/*     */   
/* 127 */   public Scriptable getThisObj() { return this.thisObj; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeCall.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */