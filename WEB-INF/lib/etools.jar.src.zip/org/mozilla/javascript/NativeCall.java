package org.mozilla.javascript;

public final class NativeCall extends ScriptableObject {
  NativeCall caller;
  
  NativeFunction funObj;
  
  Scriptable thisObj;
  
  Object[] originalArgs;
  
  public int debugPC;
  
  NativeCall(Context paramContext, Scriptable paramScriptable1, NativeFunction paramNativeFunction, Scriptable paramScriptable2, Object[] paramArrayOfObject) {
    this(paramContext, paramScriptable1, paramNativeFunction, paramScriptable2);
    this.originalArgs = paramArrayOfObject;
    String[] arrayOfString = paramNativeFunction.names;
    if (arrayOfString != null)
      for (byte b = 0; b < paramNativeFunction.argCount; b++) {
        Object object = (b < paramArrayOfObject.length) ? paramArrayOfObject[b] : 
          Undefined.instance;
        put(arrayOfString[b + true], this, object);
      }  
    put("arguments", this, new Arguments(this));
  }
  
  NativeCall(Context paramContext, Scriptable paramScriptable1, NativeFunction paramNativeFunction, Scriptable paramScriptable2) {
    this.funObj = paramNativeFunction;
    this.thisObj = paramScriptable2;
    setParentScope(paramScriptable1);
    this.caller = paramContext.currentActivation;
    paramContext.currentActivation = this;
  }
  
  public NativeCall() {}
  
  public String getClassName() { return "Call"; }
  
  public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
    if (!paramBoolean) {
      Object[] arrayOfObject = { "Call" };
      throw Context.reportRuntimeError(
          Context.getMessage("msg.only.from.new", arrayOfObject));
    } 
    ScriptRuntime.checkDeprecated(paramContext, "Call");
    NativeCall nativeCall = new NativeCall();
    nativeCall.setPrototype(ScriptableObject.getObjectPrototype(paramFunction));
    return nativeCall;
  }
  
  NativeCall getActivation(NativeFunction paramNativeFunction) {
    NativeCall nativeCall = this;
    do {
      if (nativeCall.funObj == paramNativeFunction)
        return nativeCall; 
      nativeCall = nativeCall.caller;
    } while (nativeCall != null);
    return null;
  }
  
  public NativeFunction getFunctionObject() { return this.funObj; }
  
  public Object[] getOriginalArguments() { return this.originalArgs; }
  
  public NativeCall getCaller() { return this.caller; }
  
  public Scriptable getThisObj() { return this.thisObj; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeCall.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */