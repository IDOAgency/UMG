package org.mozilla.javascript;

public interface ClassNameHelper {
  String getGeneratingDirectory();
  
  String getTargetClassFileName();
  
  String getTargetClassFileName(String paramString);
  
  String getTargetPackage();
  
  void setTargetClassFileName(String paramString);
  
  void setTargetExtends(Class paramClass);
  
  void setTargetImplements(Class[] paramArrayOfClass);
  
  void setTargetPackage(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\ClassNameHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */