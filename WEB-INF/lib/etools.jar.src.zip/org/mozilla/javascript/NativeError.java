package org.mozilla.javascript;

public class NativeError extends ScriptableObject {
  public String getClassName() { return "Error"; }
  
  public String toString() { return String.valueOf(getName()) + ": " + getMessage(); }
  
  public String jsFunction_toString() { return toString(); }
  
  public String getName() {
    return ScriptRuntime.toString(
        ScriptRuntime.getProp(this, "name", this));
  }
  
  public String getMessage() {
    return ScriptRuntime.toString(
        ScriptRuntime.getProp(this, "message", this));
  }
  
  public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) throws PropertyException {
    ((ScriptableObject)paramScriptable2).defineProperty("message", "", 
        0);
    ((ScriptableObject)paramScriptable2).defineProperty("name", "Error", 
        0);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeError.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */