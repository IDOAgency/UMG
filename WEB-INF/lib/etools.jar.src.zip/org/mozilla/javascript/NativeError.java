/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeError
/*    */   extends ScriptableObject
/*    */ {
/* 51 */   public String getClassName() { return "Error"; }
/*    */ 
/*    */ 
/*    */   
/* 55 */   public String toString() { return String.valueOf(getName()) + ": " + getMessage(); }
/*    */ 
/*    */ 
/*    */   
/* 59 */   public String jsFunction_toString() { return toString(); }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 63 */     return ScriptRuntime.toString(
/* 64 */         ScriptRuntime.getProp(this, "name", this));
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 68 */     return ScriptRuntime.toString(
/* 69 */         ScriptRuntime.getProp(this, "message", this));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) throws PropertyException {
/* 76 */     ((ScriptableObject)paramScriptable2).defineProperty("message", "", 
/* 77 */         0);
/* 78 */     ((ScriptableObject)paramScriptable2).defineProperty("name", "Error", 
/* 79 */         0);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeError.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */