package org.mozilla.javascript;

public interface DeepErrorReporterHook extends ErrorReporter {
  ErrorReporter getErrorReporter();
  
  ErrorReporter setErrorReporter(ErrorReporter paramErrorReporter);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\DeepErrorReporterHook.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */