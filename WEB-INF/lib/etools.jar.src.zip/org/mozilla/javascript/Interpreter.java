/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Interpreter
/*      */   extends LabelTable
/*      */ {
/*      */   public static final boolean printICode = false;
/*      */   boolean itsInFunctionFlag;
/*      */   Vector itsFunctionList;
/*      */   InterpreterData itsData;
/*      */   
/*   51 */   public IRFactory createIRFactory(TokenStream paramTokenStream, ClassNameHelper paramClassNameHelper, Scriptable paramScriptable) { return new IRFactory(paramTokenStream, paramScriptable); }
/*      */ 
/*      */ 
/*      */   
/*   55 */   public Node transform(Node paramNode, TokenStream paramTokenStream, Scriptable paramScriptable) { return (new NodeTransformer()).transform(paramNode, null, paramTokenStream, paramScriptable); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object compile(Context paramContext, Scriptable paramScriptable, Node paramNode, Object paramObject, SecuritySupport paramSecuritySupport, ClassNameHelper paramClassNameHelper) throws IOException {
/*   64 */     this.version = paramContext.getLanguageVersion();
/*   65 */     this.itsData = new InterpreterData(0, 0, 0, paramObject, 
/*   66 */         paramContext.hasCompileFunctionsWithDynamicScope());
/*   67 */     if (paramNode instanceof FunctionNode) {
/*   68 */       FunctionNode functionNode = (FunctionNode)paramNode;
/*   69 */       InterpretedFunction interpretedFunction = 
/*   70 */         generateFunctionICode(paramContext, paramScriptable, functionNode, paramObject);
/*   71 */       interpretedFunction.itsData.itsFunctionType = functionNode.getFunctionType();
/*   72 */       createFunctionObject(interpretedFunction, paramScriptable);
/*   73 */       return interpretedFunction;
/*      */     } 
/*   75 */     return generateScriptICode(paramContext, paramScriptable, paramNode, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateICodeFromTree(Node paramNode, VariableTable paramVariableTable, boolean paramBoolean, Object paramObject) {
/*   83 */     int i = 0;
/*   84 */     this.itsData.itsVariableTable = paramVariableTable;
/*   85 */     this.itsData.itsNeedsActivation = paramBoolean;
/*   86 */     i = generateICode(paramNode, i);
/*   87 */     this.itsData.itsICodeTop = i;
/*   88 */     if (this.itsEpilogLabel != -1)
/*   89 */       markLabel(this.itsEpilogLabel, i); 
/*   90 */     for (byte b = 0; b < this.itsLabelTableTop; b++) {
/*   91 */       this.itsLabelTable[b].fixGotos(this.itsData.itsICode);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object[] generateRegExpLiterals(Context paramContext, Scriptable paramScriptable, Vector paramVector) {
/*   98 */     Object[] arrayOfObject = new Object[paramVector.size()];
/*   99 */     RegExpProxy regExpProxy = paramContext.getRegExpProxy();
/*  100 */     for (byte b = 0; b < paramVector.size(); b++) {
/*  101 */       Node node1 = (Node)paramVector.elementAt(b);
/*  102 */       Node node2 = node1.getFirstChild();
/*  103 */       Node node3 = node1.getLastChild();
/*  104 */       arrayOfObject[b] = regExpProxy.newRegExp(paramContext, paramScriptable, node2.getString(), 
/*  105 */           (node2 != node3) ? node3.getString() : null, false);
/*  106 */       node1.putProp(12, new Integer(b));
/*      */     } 
/*  108 */     return arrayOfObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InterpretedScript generateScriptICode(Context paramContext, Scriptable paramScriptable, Node paramNode, Object paramObject) {
/*  116 */     this.itsSourceFile = (String)paramNode.getProp(16);
/*  117 */     this.itsFunctionList = (Vector)paramNode.getProp(5);
/*  118 */     if (this.itsFunctionList != null)
/*  119 */       generateNestedFunctions(paramScriptable, paramContext, paramObject); 
/*  120 */     Object[] arrayOfObject = null;
/*  121 */     Vector vector = (Vector)paramNode.getProp(12);
/*  122 */     if (vector != null) {
/*  123 */       arrayOfObject = generateRegExpLiterals(paramContext, paramScriptable, vector);
/*      */     }
/*  125 */     VariableTable variableTable = (VariableTable)paramNode.getProp(10);
/*  126 */     generateICodeFromTree(paramNode, variableTable, false, paramObject);
/*  127 */     this.itsData.itsNestedFunctions = this.itsNestedFunctions;
/*  128 */     this.itsData.itsRegExpLiterals = arrayOfObject;
/*      */ 
/*      */     
/*  131 */     return new InterpretedScript(this.itsData, paramContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateNestedFunctions(Scriptable paramScriptable, Context paramContext, Object paramObject) {
/*  138 */     this.itsNestedFunctions = new InterpretedFunction[this.itsFunctionList.size()];
/*  139 */     for (short s = 0; s < this.itsFunctionList.size(); s = (short)(s + 1)) {
/*  140 */       FunctionNode functionNode = (FunctionNode)this.itsFunctionList.elementAt(s);
/*  141 */       Interpreter interpreter = new Interpreter();
/*  142 */       interpreter.itsSourceFile = this.itsSourceFile;
/*  143 */       interpreter.itsData = new InterpreterData(0, 0, 0, paramObject, 
/*  144 */           paramContext.hasCompileFunctionsWithDynamicScope());
/*  145 */       interpreter.itsData.itsFunctionType = functionNode.getFunctionType();
/*  146 */       interpreter.itsInFunctionFlag = true;
/*  147 */       this.itsNestedFunctions[s] = interpreter.generateFunctionICode(paramContext, paramScriptable, functionNode, 
/*  148 */           paramObject);
/*  149 */       functionNode.putProp(5, new Short(s));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InterpretedFunction generateFunctionICode(Context paramContext, Scriptable paramScriptable, FunctionNode paramFunctionNode, Object paramObject) {
/*  157 */     this.itsFunctionList = (Vector)paramFunctionNode.getProp(5);
/*  158 */     if (this.itsFunctionList != null)
/*  159 */       generateNestedFunctions(paramScriptable, paramContext, paramObject); 
/*  160 */     Object[] arrayOfObject = null;
/*  161 */     Vector vector = (Vector)paramFunctionNode.getProp(12);
/*  162 */     if (vector != null) {
/*  163 */       arrayOfObject = generateRegExpLiterals(paramContext, paramScriptable, vector);
/*      */     }
/*  165 */     VariableTable variableTable = paramFunctionNode.getVariableTable();
/*  166 */     generateICodeFromTree(paramFunctionNode.getLastChild(), 
/*  167 */         variableTable, paramFunctionNode.requiresActivation(), 
/*  168 */         paramObject);
/*      */     
/*  170 */     this.itsData.itsName = paramFunctionNode.getFunctionName();
/*  171 */     this.itsData.itsSource = (String)paramFunctionNode.getProp(17);
/*  172 */     this.itsData.itsNestedFunctions = this.itsNestedFunctions;
/*  173 */     this.itsData.itsRegExpLiterals = arrayOfObject;
/*      */ 
/*      */     
/*  176 */     return new InterpretedFunction(this.itsData, paramContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  183 */   int itsTryDepth = 0;
/*  184 */   int itsStackDepth = 0;
/*  185 */   int itsEpilogLabel = -1;
/*      */   String itsSourceFile;
/*  187 */   int itsLineNumber = 0;
/*  188 */   InterpretedFunction[] itsNestedFunctions = null;
/*      */   static PrintWriter out;
/*      */   
/*      */   private int updateLineNumber(Node paramNode, int paramInt) {
/*  192 */     Object object = paramNode.getDatum();
/*  193 */     if (object == null || !(object instanceof Number))
/*  194 */       return paramInt; 
/*  195 */     short s = ((Number)object).shortValue();
/*  196 */     if (s != this.itsLineNumber) {
/*  197 */       this.itsLineNumber = s;
/*  198 */       paramInt = addByte((byte)-110, paramInt);
/*  199 */       paramInt = addByte((byte)(s >> 8), paramInt);
/*  200 */       paramInt = addByte((byte)(s & 0xFF), paramInt);
/*      */     } 
/*      */     
/*  203 */     return paramInt;
/*      */   }
/*      */ 
/*      */   
/*      */   private void badTree(Node paramNode) {
/*      */     try {
/*  209 */       out = new PrintWriter(new FileOutputStream("icode.txt", true));
/*  210 */       out.println("Un-handled node : " + paramNode.toString());
/*  211 */       out.close();
/*      */     }
/*  213 */     catch (IOException iOException) {}
/*  214 */     throw new RuntimeException("Un-handled node : " + 
/*  215 */         paramNode.toString()); } private int generateICode(Node paramNode, int paramInt) { Node node10, node9, node8; int i4; Node node7; Vector vector; Short short; int i2; String str4; int i3; Object object1; int j; Object object2; Node node3, node4; int n; Node node6; String str1, str2;
/*      */     Number number;
/*      */     String str3;
/*      */     int m, k;
/*      */     Node node5;
/*  220 */     int i1, i = paramNode.getType();
/*  221 */     Node node1 = paramNode.getFirstChild();
/*  222 */     Node node2 = node1;
/*  223 */     switch (i) {
/*      */       
/*      */       case 109:
/*  226 */         paramInt = addByte((byte)55, paramInt);
/*  227 */         node6 = (Node)paramNode.getProp(5);
/*  228 */         short = (Short)node6.getProp(5);
/*  229 */         paramInt = addByte((byte)(short.shortValue() >> 8), paramInt);
/*  230 */         paramInt = addByte((byte)(short.shortValue() & 0xFF), paramInt);
/*  231 */         this.itsStackDepth++;
/*  232 */         if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  233 */           this.itsData.itsMaxStack = this.itsStackDepth;
/*      */         }
/*      */         break;
/*      */       
/*      */       case 145:
/*  238 */         paramInt = updateLineNumber(paramNode, paramInt);
/*  239 */         while (node1 != null) {
/*  240 */           if (node1.getType() != 109)
/*  241 */             paramInt = generateICode(node1, paramInt); 
/*  242 */           node1 = node1.getNextSibling();
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 115:
/*  247 */         paramInt = updateLineNumber(paramNode, paramInt);
/*  248 */         node1 = node1.getNextSibling();
/*  249 */         while (node1 != null) {
/*  250 */           paramInt = generateICode(node1, paramInt);
/*  251 */           node1 = node1.getNextSibling();
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 116:
/*      */       case 123:
/*      */       case 127:
/*      */       case 131:
/*      */       case 132:
/*      */       case 135:
/*      */       case 137:
/*  262 */         paramInt = updateLineNumber(paramNode, paramInt);
/*  263 */         while (node1 != null) {
/*  264 */           paramInt = generateICode(node1, paramInt);
/*  265 */           node1 = node1.getNextSibling();
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 95:
/*  270 */         paramInt = generateICode(node1, paramInt);
/*  271 */         paramInt = addByte((byte)57, paramInt);
/*  272 */         this.itsStackDepth--;
/*  273 */         node1 = node1.getNextSibling();
/*  274 */         paramInt = generateICode(node1, paramInt);
/*      */         break;
/*      */       
/*      */       case 114:
/*  278 */         paramInt = updateLineNumber(paramNode, paramInt);
/*  279 */         paramInt = generateICode(node1, paramInt);
/*  280 */         i1 = this.itsData.itsMaxLocals++;
/*  281 */         paramInt = addByte((byte)69, paramInt);
/*  282 */         paramInt = addByte((byte)i1, paramInt);
/*  283 */         paramInt = addByte((byte)57, paramInt);
/*  284 */         this.itsStackDepth--;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  291 */         vector = (Vector)paramNode.getProp(13);
/*  292 */         for (i4 = 0; i4 < vector.size(); i4++) {
/*  293 */           Node node11 = (Node)vector.elementAt(i4);
/*  294 */           Node node12 = node11.getFirstChild();
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  299 */           paramInt = generateICode(node12, paramInt);
/*  300 */           paramInt = addByte((byte)70, paramInt);
/*  301 */           this.itsStackDepth++;
/*  302 */           if (this.itsStackDepth > this.itsData.itsMaxStack)
/*  303 */             this.itsData.itsMaxStack = this.itsStackDepth; 
/*  304 */           paramInt = addByte((byte)i1, paramInt);
/*  305 */           paramInt = addByte((byte)53, paramInt);
/*  306 */           Node node13 = new Node(136);
/*  307 */           node11.addChildAfter(node13, node12);
/*  308 */           Node node14 = new Node(7);
/*  309 */           node14.putProp(1, node13);
/*  310 */           paramInt = addGoto(node14, 7, 
/*  311 */               paramInt);
/*  312 */           this.itsStackDepth--;
/*      */         } 
/*      */         
/*  315 */         node8 = (Node)paramNode.getProp(14);
/*  316 */         if (node8 != null) {
/*  317 */           Node node11 = new Node(136);
/*  318 */           node8.getFirstChild().addChildToFront(node11);
/*  319 */           Node node12 = new Node(6);
/*  320 */           node12.putProp(1, node11);
/*  321 */           paramInt = addGoto(node12, 6, 
/*  322 */               paramInt);
/*      */         } 
/*      */         
/*  325 */         node9 = (Node)paramNode.getProp(2);
/*  326 */         node10 = new Node(6);
/*  327 */         node10.putProp(1, node9);
/*  328 */         paramInt = addGoto(node10, 6, 
/*  329 */             paramInt);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 136:
/*  334 */         object2 = paramNode.getProp(20);
/*  335 */         if (object2 == null) {
/*  336 */           int i5 = markLabel(acquireLabel(), paramInt);
/*  337 */           paramNode.putProp(20, new Integer(i5));
/*      */         } else {
/*      */           
/*  340 */           int i5 = ((Integer)object2).intValue();
/*  341 */           markLabel(i5, paramInt);
/*      */         } 
/*      */ 
/*      */         
/*  345 */         if (paramNode.getProp(21) != null) {
/*  346 */           this.itsStackDepth = 1;
/*  347 */           if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  348 */             this.itsData.itsMaxStack = this.itsStackDepth;
/*      */           }
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 101:
/*      */       case 102:
/*  355 */         paramInt = generateICode(node1, paramInt);
/*  356 */         node1 = node1.getNextSibling();
/*  357 */         paramInt = generateICode(node1, paramInt);
/*  358 */         n = paramNode.getInt();
/*  359 */         if (this.version == 120)
/*  360 */           if (n == 14) {
/*  361 */             n = 53;
/*  362 */           } else if (n == 15) {
/*  363 */             n = 54;
/*      */           }  
/*  365 */         paramInt = addByte((byte)n, paramInt);
/*  366 */         this.itsStackDepth--;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 30:
/*      */       case 43:
/*  372 */         if (this.itsSourceFile != null && (this.itsData.itsSourceFile == null || !this.itsSourceFile.equals(this.itsData.itsSourceFile)))
/*  373 */           this.itsData.itsSourceFile = this.itsSourceFile; 
/*  374 */         paramInt = addByte((byte)-109, paramInt);
/*      */         
/*  376 */         n = 0;
/*  377 */         i3 = -1;
/*  378 */         while (node1 != null) {
/*  379 */           paramInt = generateICode(node1, paramInt);
/*  380 */           if (i3 == -1)
/*  381 */             if (node1.getType() == 44) {
/*  382 */               i3 = (short)(this.itsData.itsStringTableIndex - 1);
/*  383 */             } else if (node1.getType() == 39) {
/*  384 */               i3 = (short)(this.itsData.itsStringTableIndex - 1);
/*      */             }  
/*  386 */           node1 = node1.getNextSibling();
/*  387 */           n++;
/*      */         } 
/*  389 */         if (paramNode.getProp(30) != null) {
/*      */           
/*  391 */           paramInt = addByte((byte)67, paramInt);
/*  392 */           paramInt = addByte((byte)(this.itsLineNumber >> 8), paramInt);
/*  393 */           paramInt = addByte((byte)(this.itsLineNumber & 0xFF), paramInt);
/*  394 */           paramInt = addString(this.itsSourceFile, paramInt);
/*      */         } else {
/*      */           
/*  397 */           paramInt = addByte((byte)i, paramInt);
/*  398 */           paramInt = addByte((byte)(i3 >> 8), paramInt);
/*  399 */           paramInt = addByte((byte)(i3 & 0xFF), paramInt);
/*      */         } 
/*      */         
/*  402 */         this.itsStackDepth -= n - 1;
/*      */         
/*  404 */         if (i == 30) {
/*  405 */           n--;
/*      */         } else {
/*  407 */           n -= 2;
/*  408 */         }  paramInt = addByte((byte)(n >> 8), paramInt);
/*  409 */         paramInt = addByte((byte)(n & 0xFF), paramInt);
/*  410 */         if (n > this.itsData.itsMaxArgs) {
/*  411 */           this.itsData.itsMaxArgs = n;
/*      */         }
/*  413 */         paramInt = addByte((byte)-109, paramInt);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 69:
/*      */       case 143:
/*  419 */         paramInt = generateICode(node1, paramInt);
/*  420 */         paramInt = addByte((byte)69, paramInt);
/*  421 */         paramInt = addLocalRef(paramNode, paramInt);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 144:
/*  426 */         if (paramNode.getProp(true) != null) {
/*  427 */           paramInt = addByte((byte)66, paramInt);
/*      */         } else {
/*  429 */           paramInt = addByte((byte)70, paramInt);
/*  430 */           this.itsStackDepth++;
/*  431 */           if (this.itsStackDepth > this.itsData.itsMaxStack)
/*  432 */             this.itsData.itsMaxStack = this.itsStackDepth; 
/*      */         } 
/*  434 */         node5 = (Node)paramNode.getProp(7);
/*  435 */         paramInt = addLocalRef(node5, paramInt);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 70:
/*  440 */         paramInt = addByte((byte)70, paramInt);
/*  441 */         node5 = (Node)paramNode.getProp(6);
/*  442 */         paramInt = addLocalRef(node5, paramInt);
/*  443 */         this.itsStackDepth++;
/*  444 */         if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  445 */           this.itsData.itsMaxStack = this.itsStackDepth;
/*      */         }
/*      */         break;
/*      */       
/*      */       case 7:
/*      */       case 8:
/*  451 */         paramInt = generateICode(node1, paramInt);
/*  452 */         this.itsStackDepth--;
/*      */       
/*      */       case 6:
/*  455 */         paramInt = addGoto(paramNode, (byte)i, paramInt);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 142:
/*  468 */         node5 = (Node)paramNode.getProp(1);
/*  469 */         node5.putProp(21, paramNode);
/*  470 */         paramInt = addGoto(paramNode, 65, 
/*  471 */             paramInt);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 100:
/*  476 */         paramInt = generateICode(node1, paramInt);
/*  477 */         paramInt = addByte((byte)9, paramInt);
/*  478 */         this.itsStackDepth++;
/*  479 */         if (this.itsStackDepth > this.itsData.itsMaxStack)
/*  480 */           this.itsData.itsMaxStack = this.itsStackDepth; 
/*  481 */         m = acquireLabel();
/*  482 */         paramInt = addGoto(m, 8, 
/*  483 */             paramInt);
/*  484 */         paramInt = addByte((byte)57, paramInt);
/*  485 */         this.itsStackDepth--;
/*  486 */         node1 = node1.getNextSibling();
/*  487 */         paramInt = generateICode(node1, paramInt);
/*  488 */         markLabel(m, paramInt);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 99:
/*  493 */         paramInt = generateICode(node1, paramInt);
/*  494 */         paramInt = addByte((byte)9, paramInt);
/*  495 */         this.itsStackDepth++;
/*  496 */         if (this.itsStackDepth > this.itsData.itsMaxStack)
/*  497 */           this.itsData.itsMaxStack = this.itsStackDepth; 
/*  498 */         m = acquireLabel();
/*  499 */         paramInt = addGoto(m, 7, 
/*  500 */             paramInt);
/*  501 */         paramInt = addByte((byte)57, paramInt);
/*  502 */         this.itsStackDepth--;
/*  503 */         node1 = node1.getNextSibling();
/*  504 */         paramInt = generateICode(node1, paramInt);
/*  505 */         markLabel(m, paramInt);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 39:
/*  510 */         paramInt = generateICode(node1, paramInt);
/*  511 */         str3 = (String)paramNode.getProp(19);
/*  512 */         if (str3 != null) {
/*  513 */           if (str3.equals("__proto__")) {
/*  514 */             paramInt = addByte((byte)81, paramInt); break;
/*      */           } 
/*  516 */           if (str3.equals("__parent__")) {
/*  517 */             paramInt = addByte((byte)86, paramInt); break;
/*      */           } 
/*  519 */           badTree(paramNode);
/*      */           break;
/*      */         } 
/*  522 */         node1 = node1.getNextSibling();
/*  523 */         paramInt = generateICode(node1, paramInt);
/*  524 */         paramInt = addByte((byte)39, paramInt);
/*  525 */         this.itsStackDepth--;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 20:
/*      */       case 21:
/*      */       case 22:
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 31:
/*      */       case 41:
/*  543 */         paramInt = generateICode(node1, paramInt);
/*  544 */         node1 = node1.getNextSibling();
/*  545 */         paramInt = generateICode(node1, paramInt);
/*  546 */         paramInt = addByte((byte)i, paramInt);
/*  547 */         this.itsStackDepth--;
/*      */         break;
/*      */       
/*      */       case 141:
/*  551 */         paramInt = generateICode(node1, paramInt);
/*  552 */         object1 = paramNode.getProp(18);
/*  553 */         if (object1 == ScriptRuntime.NumberClass) {
/*  554 */           paramInt = addByte((byte)58, paramInt); break;
/*      */         } 
/*  556 */         badTree(paramNode);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 104:
/*  561 */         paramInt = generateICode(node1, paramInt);
/*  562 */         switch (paramNode.getInt()) {
/*      */           case 131:
/*  564 */             paramInt = addByte((byte)57, paramInt);
/*  565 */             paramInt = addByte((byte)74, paramInt);
/*      */             break;
/*      */           case 128:
/*  568 */             k = acquireLabel();
/*  569 */             i3 = acquireLabel();
/*  570 */             paramInt = addGoto(k, 7, 
/*  571 */                 paramInt);
/*  572 */             paramInt = addByte((byte)52, paramInt);
/*  573 */             paramInt = addGoto(i3, 6, 
/*  574 */                 paramInt);
/*  575 */             markLabel(k, paramInt);
/*  576 */             paramInt = addByte((byte)51, paramInt);
/*  577 */             markLabel(i3, paramInt);
/*      */             break;
/*      */           
/*      */           case 28:
/*  581 */             paramInt = addByte((byte)28, paramInt);
/*      */             break;
/*      */           case 32:
/*  584 */             paramInt = addByte((byte)32, paramInt);
/*      */             break;
/*      */           case 24:
/*  587 */             paramInt = addByte((byte)29, paramInt);
/*      */             break;
/*      */           case 23:
/*  590 */             paramInt = addByte((byte)58, paramInt);
/*      */             break;
/*      */         } 
/*  593 */         badTree(paramNode);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 40:
/*  599 */         paramInt = generateICode(node1, paramInt);
/*  600 */         node1 = node1.getNextSibling();
/*  601 */         paramInt = generateICode(node1, paramInt);
/*  602 */         str2 = (String)paramNode.getProp(19);
/*  603 */         if (str2 != null) {
/*  604 */           if (str2.equals("__proto__")) {
/*  605 */             paramInt = addByte((byte)83, paramInt); break;
/*      */           } 
/*  607 */           if (str2.equals("__parent__")) {
/*  608 */             paramInt = addByte((byte)84, paramInt); break;
/*      */           } 
/*  610 */           badTree(paramNode);
/*      */           break;
/*      */         } 
/*  613 */         node1 = node1.getNextSibling();
/*  614 */         paramInt = generateICode(node1, paramInt);
/*  615 */         paramInt = addByte((byte)40, paramInt);
/*  616 */         this.itsStackDepth -= 2;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 42:
/*  622 */         paramInt = generateICode(node1, paramInt);
/*  623 */         node1 = node1.getNextSibling();
/*  624 */         paramInt = generateICode(node1, paramInt);
/*  625 */         node1 = node1.getNextSibling();
/*  626 */         paramInt = generateICode(node1, paramInt);
/*  627 */         paramInt = addByte((byte)i, paramInt);
/*  628 */         this.itsStackDepth -= 2;
/*      */         break;
/*      */       
/*      */       case 10:
/*  632 */         paramInt = generateICode(node1, paramInt);
/*  633 */         node1 = node1.getNextSibling();
/*  634 */         paramInt = generateICode(node1, paramInt);
/*  635 */         paramInt = addByte((byte)10, paramInt);
/*  636 */         paramInt = addString(node2.getString(), paramInt);
/*  637 */         this.itsStackDepth--;
/*      */         break;
/*      */       
/*      */       case 32:
/*  641 */         str2 = paramNode.getString();
/*  642 */         i3 = -1;
/*      */ 
/*      */         
/*  645 */         if (this.itsInFunctionFlag && !this.itsData.itsNeedsActivation)
/*  646 */           i3 = this.itsData.itsVariableTable.getOrdinal(str2); 
/*  647 */         if (i3 == -1) {
/*  648 */           paramInt = addByte((byte)78, paramInt);
/*  649 */           paramInt = addString(str2, paramInt);
/*      */         } else {
/*      */           
/*  652 */           paramInt = addByte((byte)72, paramInt);
/*  653 */           paramInt = addByte((byte)i3, paramInt);
/*  654 */           paramInt = addByte((byte)32, paramInt);
/*      */         } 
/*  656 */         this.itsStackDepth++;
/*  657 */         if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  658 */           this.itsData.itsMaxStack = this.itsStackDepth;
/*      */         }
/*      */         break;
/*      */       
/*      */       case 140:
/*  663 */         paramInt = generateICode(node1, paramInt);
/*  664 */         paramInt = addByte((byte)82, paramInt);
/*      */         break;
/*      */       
/*      */       case 44:
/*      */       case 46:
/*      */       case 61:
/*      */       case 71:
/*  671 */         paramInt = addByte((byte)i, paramInt);
/*  672 */         paramInt = addString(paramNode.getString(), paramInt);
/*  673 */         this.itsStackDepth++;
/*  674 */         if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  675 */           this.itsData.itsMaxStack = this.itsStackDepth;
/*      */         }
/*      */         break;
/*      */       case 105:
/*      */       case 106:
/*  680 */         j = node1.getType();
/*  681 */         switch (j) {
/*      */           case 72:
/*  683 */             str4 = node1.getString();
/*  684 */             if (this.itsData.itsNeedsActivation) {
/*  685 */               paramInt = addByte((byte)85, paramInt);
/*  686 */               paramInt = addByte((byte)46, paramInt);
/*  687 */               paramInt = addString(str4, paramInt);
/*  688 */               this.itsStackDepth += 2;
/*  689 */               if (this.itsStackDepth > this.itsData.itsMaxStack)
/*  690 */                 this.itsData.itsMaxStack = this.itsStackDepth; 
/*  691 */               paramInt = addByte((byte)(
/*  692 */                   (i == 105) ? 
/*  693 */                   34 : 
/*  694 */                   37), 
/*  695 */                   paramInt);
/*  696 */               this.itsStackDepth--;
/*      */               break;
/*      */             } 
/*  699 */             paramInt = addByte((byte)(
/*  700 */                 (i == 105) ? 
/*  701 */                 59 : 
/*  702 */                 60), 
/*  703 */                 paramInt);
/*  704 */             i4 = this.itsData.itsVariableTable
/*  705 */               .getOrdinal(str4);
/*  706 */             paramInt = addByte((byte)i4, paramInt);
/*  707 */             this.itsStackDepth++;
/*  708 */             if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  709 */               this.itsData.itsMaxStack = this.itsStackDepth;
/*      */             }
/*      */             break;
/*      */           
/*      */           case 39:
/*      */           case 41:
/*  715 */             node7 = node1.getFirstChild();
/*  716 */             paramInt = generateICode(node7, 
/*  717 */                 paramInt);
/*  718 */             node7 = node7.getNextSibling();
/*  719 */             paramInt = generateICode(node7, 
/*  720 */                 paramInt);
/*  721 */             if (j == 39) {
/*  722 */               paramInt = addByte((byte)(
/*  723 */                   (i == 105) ? 
/*  724 */                   34 : 
/*  725 */                   37), 
/*  726 */                   paramInt);
/*      */             } else {
/*  728 */               paramInt = addByte((byte)(
/*  729 */                   (i == 105) ? 
/*  730 */                   35 : 
/*  731 */                   38), 
/*  732 */                   paramInt);
/*  733 */             }  this.itsStackDepth--;
/*      */             break;
/*      */         } 
/*      */         
/*  737 */         paramInt = addByte((byte)(
/*  738 */             (i == 105) ? 
/*  739 */             33 : 
/*  740 */             36), 
/*  741 */             paramInt);
/*  742 */         paramInt = addString(node1.getString(), 
/*  743 */             paramInt);
/*  744 */         this.itsStackDepth++;
/*  745 */         if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  746 */           this.itsData.itsMaxStack = this.itsStackDepth;
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 45:
/*  754 */         number = (Number)paramNode.getDatum();
/*  755 */         if (number.doubleValue() == 0.0D) {
/*  756 */           paramInt = addByte((byte)47, paramInt);
/*      */         }
/*  758 */         else if (number.doubleValue() == 1.0D) {
/*  759 */           paramInt = addByte((byte)48, paramInt);
/*      */         } else {
/*  761 */           paramInt = addByte((byte)45, paramInt);
/*  762 */           paramInt = addNumber(number, paramInt);
/*      */         } 
/*      */         
/*  765 */         this.itsStackDepth++;
/*  766 */         if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  767 */           this.itsData.itsMaxStack = this.itsStackDepth;
/*      */         }
/*      */         break;
/*      */       case 2:
/*      */       case 57:
/*  772 */         paramInt = updateLineNumber(paramNode, paramInt);
/*      */       case 3:
/*  774 */         paramInt = generateICode(node1, paramInt);
/*  775 */         paramInt = addByte((byte)i, paramInt);
/*  776 */         this.itsStackDepth--;
/*      */         break;
/*      */       
/*      */       case 68:
/*  780 */         paramInt = generateICode(node1, paramInt);
/*  781 */         paramInt = addByte((byte)i, paramInt);
/*      */         break;
/*      */       
/*      */       case 77:
/*  785 */         paramInt = addByte((byte)i, paramInt);
/*  786 */         this.itsStackDepth++;
/*  787 */         if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  788 */           this.itsData.itsMaxStack = this.itsStackDepth;
/*      */         }
/*      */         break;
/*      */       case 4:
/*  792 */         paramInt = addByte((byte)i, paramInt);
/*      */         break;
/*      */       
/*      */       case 75:
/*  796 */         this.itsTryDepth++;
/*  797 */         if (this.itsTryDepth > this.itsData.itsMaxTryDepth)
/*  798 */           this.itsData.itsMaxTryDepth = this.itsTryDepth; 
/*  799 */         node4 = (Node)paramNode.getProp(1);
/*  800 */         node7 = (Node)paramNode.getProp(21);
/*  801 */         if (node4 == null) {
/*  802 */           paramInt = addByte((byte)75, paramInt);
/*  803 */           paramInt = addByte((byte)0, paramInt);
/*  804 */           paramInt = addByte((byte)0, paramInt);
/*      */         } else {
/*      */           
/*  807 */           paramInt = 
/*  808 */             addGoto(paramNode, 75, paramInt);
/*  809 */         }  i4 = 0;
/*  810 */         if (node7 != null) {
/*  811 */           i4 = acquireLabel();
/*  812 */           int i5 = i4 & 0x7FFFFFFF;
/*  813 */           this.itsLabelTable[i5].addFixup(paramInt);
/*      */         } 
/*  815 */         paramInt = addByte((byte)0, paramInt);
/*  816 */         paramInt = addByte((byte)0, paramInt);
/*      */         
/*  818 */         node8 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  824 */         while (node1 != null) {
/*  825 */           if (node8 == node4) {
/*  826 */             this.itsStackDepth = 1;
/*  827 */             if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  828 */               this.itsData.itsMaxStack = this.itsStackDepth;
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  836 */           if (node1.getNextSibling() == node4)
/*  837 */             paramInt = addByte((byte)76, 
/*  838 */                 paramInt); 
/*  839 */           paramInt = generateICode(node1, paramInt);
/*  840 */           node8 = node1;
/*  841 */           node1 = node1.getNextSibling();
/*      */         } 
/*  843 */         this.itsStackDepth = 0;
/*  844 */         if (node7 != null) {
/*      */           
/*  846 */           int i5 = acquireLabel();
/*  847 */           paramInt = 
/*  848 */             addGoto(i5, 6, paramInt);
/*      */           
/*  850 */           markLabel(i4, paramInt);
/*  851 */           this.itsStackDepth = 1;
/*  852 */           if (this.itsStackDepth > this.itsData.itsMaxStack)
/*  853 */             this.itsData.itsMaxStack = this.itsStackDepth; 
/*  854 */           int i6 = this.itsData.itsMaxLocals++;
/*  855 */           paramInt = addByte((byte)69, paramInt);
/*  856 */           paramInt = addByte((byte)i6, paramInt);
/*  857 */           paramInt = addByte((byte)57, paramInt);
/*  858 */           Integer integer = 
/*  859 */             (Integer)node7.getProp(20);
/*  860 */           paramInt = addGoto(integer.intValue(), 
/*  861 */               65, paramInt);
/*  862 */           paramInt = addByte((byte)70, paramInt);
/*  863 */           paramInt = addByte((byte)i6, paramInt);
/*  864 */           paramInt = addByte((byte)87, paramInt);
/*  865 */           this.itsStackDepth = 0;
/*  866 */           markLabel(i5, paramInt);
/*      */         } 
/*  868 */         this.itsTryDepth--;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 62:
/*  873 */         paramInt = updateLineNumber(paramNode, paramInt);
/*  874 */         paramInt = generateICode(node1, paramInt);
/*  875 */         paramInt = addByte((byte)62, paramInt);
/*  876 */         this.itsStackDepth--;
/*      */         break;
/*      */       
/*      */       case 5:
/*  880 */         paramInt = updateLineNumber(paramNode, paramInt);
/*  881 */         if (node1 != null) {
/*  882 */           paramInt = generateICode(node1, paramInt);
/*      */         } else {
/*  884 */           paramInt = addByte((byte)74, paramInt);
/*  885 */           this.itsStackDepth++;
/*  886 */           if (this.itsStackDepth > this.itsData.itsMaxStack)
/*  887 */             this.itsData.itsMaxStack = this.itsStackDepth; 
/*      */         } 
/*  889 */         paramInt = addGoto(paramNode, 5, paramInt);
/*  890 */         this.itsStackDepth--;
/*      */         break;
/*      */       
/*      */       case 72:
/*  894 */         str1 = paramNode.getString();
/*  895 */         if (this.itsData.itsNeedsActivation) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  900 */           paramInt = addByte((byte)85, paramInt);
/*  901 */           paramInt = addByte((byte)46, paramInt);
/*  902 */           paramInt = addString(str1, paramInt);
/*  903 */           this.itsStackDepth += 2;
/*  904 */           if (this.itsStackDepth > this.itsData.itsMaxStack)
/*  905 */             this.itsData.itsMaxStack = this.itsStackDepth; 
/*  906 */           paramInt = addByte((byte)39, paramInt);
/*  907 */           this.itsStackDepth--;
/*      */           break;
/*      */         } 
/*  910 */         i2 = this.itsData.itsVariableTable.getOrdinal(str1);
/*  911 */         paramInt = addByte((byte)72, paramInt);
/*  912 */         paramInt = addByte((byte)i2, paramInt);
/*  913 */         this.itsStackDepth++;
/*  914 */         if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  915 */           this.itsData.itsMaxStack = this.itsStackDepth;
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 73:
/*  921 */         if (this.itsData.itsNeedsActivation) {
/*  922 */           node1.setType(61);
/*  923 */           paramNode.setType(10);
/*  924 */           paramInt = generateICode(paramNode, paramInt);
/*      */           break;
/*      */         } 
/*  927 */         str1 = node1.getString();
/*  928 */         node1 = node1.getNextSibling();
/*  929 */         paramInt = generateICode(node1, paramInt);
/*  930 */         i2 = this.itsData.itsVariableTable.getOrdinal(str1);
/*  931 */         paramInt = addByte((byte)73, paramInt);
/*  932 */         paramInt = addByte((byte)i2, paramInt);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 108:
/*  938 */         paramInt = addByte((byte)paramNode.getInt(), paramInt);
/*  939 */         this.itsStackDepth++;
/*  940 */         if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  941 */           this.itsData.itsMaxStack = this.itsStackDepth;
/*      */         }
/*      */         break;
/*      */       case 79:
/*  945 */         paramInt = generateICode(node1, paramInt);
/*  946 */         paramInt = addByte((byte)79, paramInt);
/*  947 */         paramInt = addLocalRef(paramNode, paramInt);
/*  948 */         this.itsStackDepth--;
/*      */         break;
/*      */       
/*      */       case 80:
/*  952 */         paramInt = addByte((byte)80, paramInt);
/*  953 */         node3 = (Node)paramNode.getProp(4);
/*  954 */         paramInt = addLocalRef(node3, paramInt);
/*  955 */         this.itsStackDepth++;
/*  956 */         if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  957 */           this.itsData.itsMaxStack = this.itsStackDepth;
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 56:
/*  966 */         node3 = (Node)paramNode.getProp(12);
/*  967 */         i2 = ((Integer)node3.getProp(
/*  968 */             12)).intValue();
/*  969 */         paramInt = addByte((byte)56, paramInt);
/*  970 */         paramInt = addByte((byte)(i2 >> 8), paramInt);
/*  971 */         paramInt = addByte((byte)(i2 & 0xFF), paramInt);
/*  972 */         this.itsStackDepth++;
/*  973 */         if (this.itsStackDepth > this.itsData.itsMaxStack) {
/*  974 */           this.itsData.itsMaxStack = this.itsStackDepth;
/*      */         }
/*      */         break;
/*      */       
/*      */       default:
/*  979 */         badTree(paramNode); break;
/*      */       case 138:
/*      */         break;
/*  982 */     }  return paramInt; }
/*      */ 
/*      */ 
/*      */   
/*      */   private int addLocalRef(Node paramNode, int paramInt) {
/*      */     int i;
/*  988 */     Integer integer = (Integer)paramNode.getProp(7);
/*  989 */     if (integer == null) {
/*  990 */       i = this.itsData.itsMaxLocals++;
/*  991 */       paramNode.putProp(7, new Integer(i));
/*      */     } else {
/*      */       
/*  994 */       i = integer.intValue();
/*  995 */     }  paramInt = addByte((byte)i, paramInt);
/*  996 */     if (i >= this.itsData.itsMaxLocals)
/*  997 */       this.itsData.itsMaxLocals = i + 1; 
/*  998 */     return paramInt;
/*      */   }
/*      */ 
/*      */   
/*      */   private int addGoto(Node paramNode, int paramInt1, int paramInt2) {
/*      */     int i;
/* 1004 */     if (paramNode.getType() == 5) {
/* 1005 */       if (this.itsEpilogLabel == -1)
/* 1006 */         this.itsEpilogLabel = acquireLabel(); 
/* 1007 */       i = this.itsEpilogLabel;
/*      */     } else {
/*      */       
/* 1010 */       Node node = (Node)paramNode.getProp(1);
/* 1011 */       Object object = node.getProp(20);
/* 1012 */       if (object == null) {
/* 1013 */         i = acquireLabel();
/* 1014 */         node.putProp(20, new Integer(i));
/*      */       } else {
/*      */         
/* 1017 */         i = ((Integer)object).intValue();
/*      */       } 
/* 1019 */     }  return addGoto(i, (byte)paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int addGoto(int paramInt1, int paramInt2, int paramInt3) {
/* 1025 */     int i = paramInt3;
/* 1026 */     paramInt3 = addByte((byte)paramInt2, paramInt3);
/* 1027 */     int j = paramInt1 & 0x7FFFFFFF;
/* 1028 */     short s = this.itsLabelTable[j].getPC();
/* 1029 */     if (s != -1) {
/* 1030 */       short s1 = (short)(s - i);
/* 1031 */       paramInt3 = addByte((byte)(s1 >> 8), paramInt3);
/* 1032 */       paramInt3 = addByte((byte)s1, paramInt3);
/*      */     } else {
/*      */       
/* 1035 */       this.itsLabelTable[j].addFixup(i + 1);
/* 1036 */       paramInt3 = addByte((byte)0, paramInt3);
/* 1037 */       paramInt3 = addByte((byte)0, paramInt3);
/*      */     } 
/* 1039 */     return paramInt3;
/*      */   }
/*      */   
/*      */   private final int addByte(byte paramByte, int paramInt) {
/* 1043 */     if (this.itsData.itsICode.length == paramInt) {
/* 1044 */       byte[] arrayOfByte = new byte[paramInt * 2];
/* 1045 */       System.arraycopy(this.itsData.itsICode, 0, arrayOfByte, 0, paramInt);
/* 1046 */       this.itsData.itsICode = arrayOfByte;
/*      */     } 
/* 1048 */     this.itsData.itsICode[paramInt++] = paramByte;
/* 1049 */     return paramInt;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int addString(String paramString, int paramInt) {
/* 1054 */     paramInt = addByte((byte)(this.itsData.itsStringTableIndex >> 8), paramInt);
/* 1055 */     paramInt = addByte((byte)(this.itsData.itsStringTableIndex & 0xFF), paramInt);
/* 1056 */     if (this.itsData.itsStringTable.length == this.itsData.itsStringTableIndex) {
/* 1057 */       String[] arrayOfString = new String[this.itsData.itsStringTableIndex * 2];
/* 1058 */       System.arraycopy(this.itsData.itsStringTable, 0, arrayOfString, 0, this.itsData.itsStringTableIndex);
/* 1059 */       this.itsData.itsStringTable = arrayOfString;
/*      */     } 
/* 1061 */     this.itsData.itsStringTable[this.itsData.itsStringTableIndex++] = paramString;
/* 1062 */     return paramInt;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int addNumber(Number paramNumber, int paramInt) {
/* 1067 */     paramInt = addByte((byte)(this.itsData.itsNumberTableIndex >> 8), paramInt);
/* 1068 */     paramInt = addByte((byte)(this.itsData.itsNumberTableIndex & 0xFF), paramInt);
/* 1069 */     if (this.itsData.itsNumberTable.length == this.itsData.itsNumberTableIndex) {
/* 1070 */       Number[] arrayOfNumber = new Number[this.itsData.itsNumberTableIndex * 2];
/* 1071 */       System.arraycopy(this.itsData.itsNumberTable, 0, arrayOfNumber, 0, this.itsData.itsNumberTableIndex);
/* 1072 */       this.itsData.itsNumberTable = arrayOfNumber;
/*      */     } 
/* 1074 */     this.itsData.itsNumberTable[this.itsData.itsNumberTableIndex++] = paramNumber;
/* 1075 */     return paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getString(String[] paramArrayOfString, byte[] paramArrayOfByte, int paramInt) {
/* 1081 */     byte b = (paramArrayOfByte[paramInt] << 8) + (paramArrayOfByte[paramInt + 1] & 0xFF);
/* 1082 */     return paramArrayOfString[b];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Number getNumber(Number[] paramArrayOfNumber, byte[] paramArrayOfByte, int paramInt) {
/* 1088 */     byte b = (paramArrayOfByte[paramInt] << 8) + (paramArrayOfByte[paramInt + 1] & 0xFF);
/* 1089 */     return paramArrayOfNumber[b];
/*      */   }
/*      */ 
/*      */   
/*      */   private static int getTarget(byte[] paramArrayOfByte, int paramInt) {
/* 1094 */     byte b = (paramArrayOfByte[paramInt] << 8) + (paramArrayOfByte[paramInt + 1] & 0xFF);
/* 1095 */     return paramInt - 1 + b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void dumpICode(InterpreterData paramInterpreterData) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1288 */   private static final Byte zero = new Byte((byte)0);
/* 1289 */   private static final Byte one = new Byte((byte)1);
/*      */   
/*      */   private int version;
/*      */   
/*      */   private static void createFunctionObject(InterpretedFunction paramInterpretedFunction, Scriptable paramScriptable) {
/* 1294 */     paramInterpretedFunction.setPrototype(ScriptableObject.getClassPrototype(paramScriptable, "Function"));
/* 1295 */     paramInterpretedFunction.setParentScope(paramScriptable);
/* 1296 */     InterpreterData interpreterData = paramInterpretedFunction.itsData;
/* 1297 */     if (interpreterData.itsName.length() == 0)
/*      */       return; 
/* 1299 */     if ((interpreterData.itsFunctionType == 1 && 
/* 1300 */       paramInterpretedFunction.itsClosure == null) || (
/* 1301 */       interpreterData.itsFunctionType == 3 && 
/* 1302 */       paramInterpretedFunction.itsClosure != null))
/*      */     {
/* 1304 */       ScriptRuntime.setProp(paramScriptable, paramInterpretedFunction.itsData.itsName, paramInterpretedFunction, paramScriptable);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object interpret(InterpreterData paramInterpreterData) throws JavaScriptException {
/* 1312 */     Object[] arrayOfObject1 = new Object[paramInterpreterData.itsMaxStack];
/* 1313 */     byte b = -1;
/* 1314 */     byte[] arrayOfByte = paramInterpreterData.itsICode;
/* 1315 */     int i = 0;
/* 1316 */     int j = paramInterpreterData.itsICodeTop;
/*      */     
/* 1318 */     Object[] arrayOfObject2 = null;
/* 1319 */     if (paramInterpreterData.itsMaxLocals > 0) {
/* 1320 */       arrayOfObject2 = new Object[paramInterpreterData.itsMaxLocals];
/*      */     }
/* 1322 */     Object[] arrayOfObject3 = null;
/* 1323 */     Scriptable scriptable1 = Undefined.instance;
/* 1324 */     int k = paramInterpreterData.itsVariableTable.size();
/* 1325 */     if (k > 0) {
/* 1326 */       arrayOfObject3 = new Object[k];
/* 1327 */       for (k = 0; k < paramInterpreterData.itsVariableTable.getParameterCount(); k++) {
/* 1328 */         if (k >= paramInterpreterData.itsInArgs.length) {
/* 1329 */           arrayOfObject3[k] = scriptable1;
/*      */         } else {
/* 1331 */           arrayOfObject3[k] = paramInterpreterData.itsInArgs[k];
/*      */         } 
/* 1333 */       }  for (; k < arrayOfObject3.length; k++) {
/* 1334 */         arrayOfObject3[k] = scriptable1;
/*      */       }
/*      */     } 
/* 1337 */     Context context = paramInterpreterData.itsCX;
/* 1338 */     Scriptable scriptable2 = paramInterpreterData.itsScope;
/*      */     
/* 1340 */     if (paramInterpreterData.itsNestedFunctions != null) {
/* 1341 */       for (k = 0; k < paramInterpreterData.itsNestedFunctions.length; k++) {
/* 1342 */         createFunctionObject(paramInterpreterData.itsNestedFunctions[k], scriptable2);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1351 */     String str = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1359 */     int[] arrayOfInt1 = null;
/* 1360 */     int[] arrayOfInt2 = null;
/* 1361 */     Scriptable[] arrayOfScriptable = null;
/* 1362 */     byte b1 = 0;
/*      */     
/* 1364 */     if (paramInterpreterData.itsMaxTryDepth > 0) {
/* 1365 */       arrayOfInt1 = new int[paramInterpreterData.itsMaxTryDepth];
/* 1366 */       arrayOfInt2 = new int[paramInterpreterData.itsMaxTryDepth];
/* 1367 */       arrayOfScriptable = new Scriptable[paramInterpreterData.itsMaxTryDepth];
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1375 */     Object object1 = context.interpreterSecurityDomain;
/* 1376 */     context.interpreterSecurityDomain = paramInterpreterData.securityDomain;
/* 1377 */     Object object2 = scriptable1;
/*      */     
/* 1379 */     Scriptable scriptable3 = paramInterpreterData.itsThisObj;
/*      */     
/* 1381 */     while (i < j) {
/*      */       try {
/* 1383 */         Scriptable scriptable; int n; long l; int m; Object[] arrayOfObject; byte b3, b2; Object object5, object4, object3; switch (arrayOfByte[i] & 0xFF) {
/*      */           case 76:
/* 1385 */             b1--;
/*      */             break;
/*      */           case 75:
/* 1388 */             k = getTarget(arrayOfByte, i + true);
/* 1389 */             if (k == i) k = 0; 
/* 1390 */             arrayOfInt1[b1] = k;
/* 1391 */             k = getTarget(arrayOfByte, i + 3);
/* 1392 */             if (k == i + 2) k = 0; 
/* 1393 */             arrayOfInt2[b1] = k;
/* 1394 */             arrayOfScriptable[b1++] = scriptable2;
/* 1395 */             i += true;
/*      */             break;
/*      */           case 19:
/* 1398 */             object5 = arrayOfObject1[b--];
/* 1399 */             object3 = arrayOfObject1[b];
/* 1400 */             arrayOfObject1[b] = ScriptRuntime.cmp_LEB(object5, object3);
/*      */             break;
/*      */           case 17:
/* 1403 */             object5 = arrayOfObject1[b--];
/* 1404 */             object3 = arrayOfObject1[b];
/* 1405 */             arrayOfObject1[b] = ScriptRuntime.cmp_LEB(object3, object5);
/*      */             break;
/*      */           case 18:
/* 1408 */             object5 = arrayOfObject1[b--];
/* 1409 */             object3 = arrayOfObject1[b];
/* 1410 */             arrayOfObject1[b] = ScriptRuntime.cmp_LTB(object5, object3);
/*      */             break;
/*      */           case 16:
/* 1413 */             object5 = arrayOfObject1[b--];
/* 1414 */             object3 = arrayOfObject1[b];
/* 1415 */             arrayOfObject1[b] = ScriptRuntime.cmp_LTB(object3, object5);
/*      */             break;
/*      */           case 63:
/* 1418 */             object5 = arrayOfObject1[b--];
/* 1419 */             object3 = arrayOfObject1[b];
/* 1420 */             arrayOfObject1[b] = 
/* 1421 */               new Boolean(ScriptRuntime.in(object3, object5));
/*      */             break;
/*      */           case 64:
/* 1424 */             object5 = arrayOfObject1[b--];
/* 1425 */             object3 = arrayOfObject1[b];
/* 1426 */             arrayOfObject1[b] = new Boolean(
/* 1427 */                 ScriptRuntime.instanceOf(scriptable2, object3, object5));
/*      */             break;
/*      */           case 14:
/* 1430 */             object5 = arrayOfObject1[b--];
/* 1431 */             object3 = arrayOfObject1[b];
/* 1432 */             arrayOfObject1[b] = ScriptRuntime.eqB(object3, object5);
/*      */             break;
/*      */           case 15:
/* 1435 */             object5 = arrayOfObject1[b--];
/* 1436 */             object3 = arrayOfObject1[b];
/* 1437 */             arrayOfObject1[b] = ScriptRuntime.neB(object3, object5);
/*      */             break;
/*      */           case 53:
/* 1440 */             object5 = arrayOfObject1[b--];
/* 1441 */             object3 = arrayOfObject1[b];
/* 1442 */             arrayOfObject1[b] = ScriptRuntime.seqB(object3, object5);
/*      */             break;
/*      */           case 54:
/* 1445 */             object5 = arrayOfObject1[b--];
/* 1446 */             object3 = arrayOfObject1[b];
/* 1447 */             arrayOfObject1[b] = ScriptRuntime.sneB(object3, object5);
/*      */             break;
/*      */           case 8:
/* 1450 */             if (!ScriptRuntime.toBoolean(arrayOfObject1[b--])) {
/* 1451 */               i = getTarget(arrayOfByte, i + true);
/*      */               continue;
/*      */             } 
/* 1454 */             i += 2;
/*      */             break;
/*      */           case 7:
/* 1457 */             if (ScriptRuntime.toBoolean(arrayOfObject1[b--])) {
/* 1458 */               i = getTarget(arrayOfByte, i + 1);
/*      */               continue;
/*      */             } 
/* 1461 */             i += 2;
/*      */             break;
/*      */           case 6:
/* 1464 */             i = getTarget(arrayOfByte, i + 1);
/*      */             continue;
/*      */           case 65:
/* 1467 */             arrayOfObject1[++b] = new Integer(i + 3);
/* 1468 */             i = getTarget(arrayOfByte, i + 1);
/*      */             continue;
/*      */           case 66:
/* 1471 */             b3 = arrayOfByte[++i] & 0xFF;
/* 1472 */             i = ((Integer)arrayOfObject2[b3]).intValue();
/*      */             continue;
/*      */           case 57:
/* 1475 */             b--;
/*      */             break;
/*      */           case 9:
/* 1478 */             arrayOfObject1[b + 1] = arrayOfObject1[b];
/* 1479 */             b++;
/*      */             break;
/*      */           case 2:
/* 1482 */             object2 = arrayOfObject1[b--];
/*      */             break;
/*      */           case 5:
/* 1485 */             object2 = arrayOfObject1[b--];
/* 1486 */             i = getTarget(arrayOfByte, i + 1);
/*      */             break;
/*      */           case 28:
/* 1489 */             n = ScriptRuntime.toInt32(arrayOfObject1[b]);
/* 1490 */             arrayOfObject1[b] = new Double((n ^ 0xFFFFFFFF));
/*      */             break;
/*      */           case 13:
/* 1493 */             n = ScriptRuntime.toInt32(arrayOfObject1[b--]);
/* 1494 */             m = ScriptRuntime.toInt32(arrayOfObject1[b]);
/* 1495 */             arrayOfObject1[b] = new Double((m & n));
/*      */             break;
/*      */           case 11:
/* 1498 */             n = ScriptRuntime.toInt32(arrayOfObject1[b--]);
/* 1499 */             m = ScriptRuntime.toInt32(arrayOfObject1[b]);
/* 1500 */             arrayOfObject1[b] = new Double((m | n));
/*      */             break;
/*      */           case 12:
/* 1503 */             n = ScriptRuntime.toInt32(arrayOfObject1[b--]);
/* 1504 */             m = ScriptRuntime.toInt32(arrayOfObject1[b]);
/* 1505 */             arrayOfObject1[b] = new Double((m ^ n));
/*      */             break;
/*      */           case 20:
/* 1508 */             n = ScriptRuntime.toInt32(arrayOfObject1[b--]);
/* 1509 */             m = ScriptRuntime.toInt32(arrayOfObject1[b]);
/* 1510 */             arrayOfObject1[b] = new Double((m << n));
/*      */             break;
/*      */           case 21:
/* 1513 */             n = ScriptRuntime.toInt32(arrayOfObject1[b--]);
/* 1514 */             m = ScriptRuntime.toInt32(arrayOfObject1[b]);
/* 1515 */             arrayOfObject1[b] = new Double((m >> n));
/*      */             break;
/*      */           case 22:
/* 1518 */             n = ScriptRuntime.toInt32(arrayOfObject1[b--]) & 0x1F;
/* 1519 */             l = ScriptRuntime.toUint32(arrayOfObject1[b]);
/* 1520 */             arrayOfObject1[b] = new Double((l >>> n));
/*      */             break;
/*      */           case 23:
/* 1523 */             object5 = arrayOfObject1[b--];
/* 1524 */             object3 = arrayOfObject1[b];
/* 1525 */             arrayOfObject1[b] = ScriptRuntime.add(object3, object5);
/*      */             break;
/*      */           case 24:
/* 1528 */             object5 = arrayOfObject1[b--];
/* 1529 */             object3 = arrayOfObject1[b];
/* 1530 */             arrayOfObject1[b] = new Double(ScriptRuntime.toNumber(object3) - 
/* 1531 */                 ScriptRuntime.toNumber(object5));
/*      */             break;
/*      */           case 29:
/* 1534 */             object5 = arrayOfObject1[b];
/* 1535 */             arrayOfObject1[b] = new Double(-ScriptRuntime.toNumber(object5));
/*      */             break;
/*      */           case 58:
/* 1538 */             object5 = arrayOfObject1[b];
/* 1539 */             arrayOfObject1[b] = new Double(ScriptRuntime.toNumber(object5));
/*      */             break;
/*      */           case 25:
/* 1542 */             object5 = arrayOfObject1[b--];
/* 1543 */             object3 = arrayOfObject1[b];
/* 1544 */             arrayOfObject1[b] = new Double(ScriptRuntime.toNumber(object3) * 
/* 1545 */                 ScriptRuntime.toNumber(object5));
/*      */             break;
/*      */           case 26:
/* 1548 */             object5 = arrayOfObject1[b--];
/* 1549 */             object3 = arrayOfObject1[b];
/*      */             
/* 1551 */             arrayOfObject1[b] = new Double(ScriptRuntime.toNumber(object3) / 
/* 1552 */                 ScriptRuntime.toNumber(object5));
/*      */             break;
/*      */           case 27:
/* 1555 */             object5 = arrayOfObject1[b--];
/* 1556 */             object3 = arrayOfObject1[b];
/* 1557 */             arrayOfObject1[b] = new Double(ScriptRuntime.toNumber(object3) % 
/* 1558 */                 ScriptRuntime.toNumber(object5));
/*      */             break;
/*      */           case 61:
/* 1561 */             arrayOfObject1[++b] = 
/* 1562 */               ScriptRuntime.bind(scriptable2, 
/* 1563 */                 getString(paramInterpreterData.itsStringTable, 
/* 1564 */                   arrayOfByte, i + 1));
/* 1565 */             i += 2;
/*      */             break;
/*      */           case 71:
/* 1568 */             arrayOfObject1[++b] = 
/* 1569 */               ScriptRuntime.getBase(scriptable2, 
/* 1570 */                 getString(paramInterpreterData.itsStringTable, 
/* 1571 */                   arrayOfByte, i + 1));
/* 1572 */             i += 2;
/*      */             break;
/*      */           case 10:
/* 1575 */             object5 = arrayOfObject1[b--];
/* 1576 */             object3 = arrayOfObject1[b];
/*      */             
/* 1578 */             arrayOfObject1[b] = 
/* 1579 */               ScriptRuntime.setName((Scriptable)object3, object5, scriptable2, 
/* 1580 */                 getString(paramInterpreterData.itsStringTable, 
/* 1581 */                   arrayOfByte, i + 1));
/* 1582 */             i += 2;
/*      */             break;
/*      */           case 31:
/* 1585 */             object5 = arrayOfObject1[b--];
/* 1586 */             object3 = arrayOfObject1[b];
/* 1587 */             arrayOfObject1[b] = 
/* 1588 */               ScriptRuntime.delete(object3, object5);
/*      */             break;
/*      */           case 39:
/* 1591 */             str = (String)arrayOfObject1[b--];
/* 1592 */             object3 = arrayOfObject1[b];
/* 1593 */             arrayOfObject1[b] = 
/* 1594 */               ScriptRuntime.getProp(object3, str, scriptable2);
/*      */             break;
/*      */           case 40:
/* 1597 */             object5 = arrayOfObject1[b--];
/* 1598 */             str = (String)arrayOfObject1[b--];
/* 1599 */             object3 = arrayOfObject1[b];
/* 1600 */             arrayOfObject1[b] = 
/* 1601 */               ScriptRuntime.setProp(object3, str, object5, scriptable2);
/*      */             break;
/*      */           case 41:
/* 1604 */             object4 = arrayOfObject1[b--];
/* 1605 */             object3 = arrayOfObject1[b];
/* 1606 */             arrayOfObject1[b] = 
/* 1607 */               ScriptRuntime.getElem(object3, object4, scriptable2);
/*      */             break;
/*      */           case 42:
/* 1610 */             object5 = arrayOfObject1[b--];
/* 1611 */             object4 = arrayOfObject1[b--];
/* 1612 */             object3 = arrayOfObject1[b];
/* 1613 */             arrayOfObject1[b] = 
/* 1614 */               ScriptRuntime.setElem(object3, object4, object5, scriptable2);
/*      */             break;
/*      */           case 34:
/* 1617 */             str = (String)arrayOfObject1[b--];
/* 1618 */             object3 = arrayOfObject1[b];
/* 1619 */             arrayOfObject1[b] = 
/* 1620 */               ScriptRuntime.postIncrement(object3, str, scriptable2);
/*      */             break;
/*      */           case 37:
/* 1623 */             str = (String)arrayOfObject1[b--];
/* 1624 */             object3 = arrayOfObject1[b];
/* 1625 */             arrayOfObject1[b] = 
/* 1626 */               ScriptRuntime.postDecrement(object3, str, scriptable2);
/*      */             break;
/*      */           case 35:
/* 1629 */             object5 = arrayOfObject1[b--];
/* 1630 */             object3 = arrayOfObject1[b];
/* 1631 */             arrayOfObject1[b] = 
/* 1632 */               ScriptRuntime.postIncrementElem(object3, object5, scriptable2);
/*      */             break;
/*      */           case 38:
/* 1635 */             object5 = arrayOfObject1[b--];
/* 1636 */             object3 = arrayOfObject1[b];
/* 1637 */             arrayOfObject1[b] = 
/* 1638 */               ScriptRuntime.postDecrementElem(object3, object5, scriptable2);
/*      */             break;
/*      */           case 68:
/* 1641 */             object3 = arrayOfObject1[b];
/* 1642 */             arrayOfObject1[b] = ScriptRuntime.getThis((Scriptable)object3);
/*      */             break;
/*      */           case 69:
/* 1645 */             object3 = arrayOfObject1[b];
/* 1646 */             b3 = arrayOfByte[++i] & 0xFF;
/* 1647 */             arrayOfObject2[b3] = object3;
/*      */             break;
/*      */           case 70:
/* 1650 */             b3 = arrayOfByte[++i] & 0xFF;
/* 1651 */             arrayOfObject1[++b] = arrayOfObject2[b3];
/*      */             break;
/*      */           case 67:
/* 1654 */             k = arrayOfByte[i + 1] << 8 | arrayOfByte[i + 2] & 0xFF;
/* 1655 */             str = getString(paramInterpreterData.itsStringTable, arrayOfByte, i + 3);
/* 1656 */             b2 = arrayOfByte[i + 5] << 8 | arrayOfByte[i + 6] & 0xFF;
/* 1657 */             arrayOfObject = new Object[b2];
/* 1658 */             for (k = b2 - 1; k >= 0; k--)
/* 1659 */               arrayOfObject[k] = arrayOfObject1[b--]; 
/* 1660 */             object5 = arrayOfObject1[b--];
/* 1661 */             object3 = arrayOfObject1[b];
/* 1662 */             arrayOfObject1[b] = ScriptRuntime.callSpecial(
/* 1663 */                 context, object3, object5, arrayOfObject, 
/* 1664 */                 scriptable3, scriptable2, str, k);
/* 1665 */             i += 6;
/*      */             break;
/*      */           case 43:
/* 1668 */             b2 = arrayOfByte[i + 3] << 8 | arrayOfByte[i + 4] & 0xFF;
/* 1669 */             arrayOfObject = new Object[b2];
/* 1670 */             for (k = b2 - 1; k >= 0; k--)
/* 1671 */               arrayOfObject[k] = arrayOfObject1[b--]; 
/* 1672 */             object5 = arrayOfObject1[b--];
/* 1673 */             object3 = arrayOfObject1[b];
/* 1674 */             if (object3 == scriptable1) {
/* 1675 */               object3 = getString(paramInterpreterData.itsStringTable, arrayOfByte, 
/* 1676 */                   i + 1);
/*      */             }
/* 1678 */             scriptable = scriptable2;
/* 1679 */             if (paramInterpreterData.itsNeedsActivation) {
/* 1680 */               scriptable = ScriptableObject.getTopLevelScope(scriptable2);
/*      */             }
/* 1682 */             arrayOfObject1[b] = ScriptRuntime.call(context, object3, object5, 
/* 1683 */                 arrayOfObject, 
/* 1684 */                 scriptable);
/* 1685 */             i += 4;
/*      */             break;
/*      */           case 30:
/* 1688 */             b2 = arrayOfByte[i + 3] << 8 | arrayOfByte[i + 4] & 0xFF;
/* 1689 */             arrayOfObject = new Object[b2];
/* 1690 */             for (k = b2 - 1; k >= 0; k--)
/* 1691 */               arrayOfObject[k] = arrayOfObject1[b--]; 
/* 1692 */             object3 = arrayOfObject1[b];
/* 1693 */             if (object3 == scriptable1) {
/* 1694 */               object3 = getString(paramInterpreterData.itsStringTable, arrayOfByte, 
/* 1695 */                   i + 1);
/*      */             }
/* 1697 */             arrayOfObject1[b] = ScriptRuntime.newObject(context, object3, 
/* 1698 */                 arrayOfObject, 
/* 1699 */                 scriptable2);
/* 1700 */             i += 4;
/*      */             break;
/*      */           case 32:
/* 1703 */             object3 = arrayOfObject1[b];
/* 1704 */             arrayOfObject1[b] = ScriptRuntime.typeof(object3);
/*      */             break;
/*      */           case 78:
/* 1707 */             str = getString(paramInterpreterData.itsStringTable, arrayOfByte, i + 1);
/* 1708 */             arrayOfObject1[++b] = 
/* 1709 */               ScriptRuntime.typeofName(scriptable2, str);
/* 1710 */             i += 2;
/*      */             break;
/*      */           case 46:
/* 1713 */             arrayOfObject1[++b] = getString(paramInterpreterData.itsStringTable, 
/* 1714 */                 arrayOfByte, i + 1);
/* 1715 */             i += 2;
/*      */             break;
/*      */           case 45:
/* 1718 */             arrayOfObject1[++b] = getNumber(paramInterpreterData.itsNumberTable, 
/* 1719 */                 arrayOfByte, i + 1);
/* 1720 */             i += 2;
/*      */             break;
/*      */           case 44:
/* 1723 */             arrayOfObject1[++b] = ScriptRuntime.name(scriptable2, 
/* 1724 */                 getString(paramInterpreterData.itsStringTable, 
/* 1725 */                   arrayOfByte, i + 1));
/* 1726 */             i += 2;
/*      */             break;
/*      */           case 33:
/* 1729 */             arrayOfObject1[++b] = ScriptRuntime.postIncrement(scriptable2, 
/* 1730 */                 getString(paramInterpreterData.itsStringTable, 
/* 1731 */                   arrayOfByte, i + 1));
/* 1732 */             i += 2;
/*      */             break;
/*      */           case 36:
/* 1735 */             arrayOfObject1[++b] = ScriptRuntime.postDecrement(scriptable2, 
/* 1736 */                 getString(paramInterpreterData.itsStringTable, 
/* 1737 */                   arrayOfByte, i + 1));
/* 1738 */             i += 2;
/*      */             break;
/*      */           case 73:
/* 1741 */             object3 = arrayOfObject1[b];
/* 1742 */             b3 = arrayOfByte[++i] & 0xFF;
/* 1743 */             arrayOfObject3[b3] = object3;
/*      */             break;
/*      */           case 72:
/* 1746 */             b3 = arrayOfByte[++i] & 0xFF;
/* 1747 */             arrayOfObject1[++b] = arrayOfObject3[b3];
/*      */             break;
/*      */           case 59:
/* 1750 */             b3 = arrayOfByte[++i] & 0xFF;
/* 1751 */             arrayOfObject1[++b] = arrayOfObject3[b3];
/* 1752 */             arrayOfObject3[b3] = ScriptRuntime.postIncrement(arrayOfObject3[b3]);
/*      */             break;
/*      */           case 60:
/* 1755 */             b3 = arrayOfByte[++i] & 0xFF;
/* 1756 */             arrayOfObject1[++b] = arrayOfObject3[b3];
/* 1757 */             arrayOfObject3[b3] = ScriptRuntime.postDecrement(arrayOfObject3[b3]);
/*      */             break;
/*      */           case 47:
/* 1760 */             arrayOfObject1[++b] = zero;
/*      */             break;
/*      */           case 48:
/* 1763 */             arrayOfObject1[++b] = one;
/*      */             break;
/*      */           case 49:
/* 1766 */             arrayOfObject1[++b] = null;
/*      */             break;
/*      */           case 50:
/* 1769 */             arrayOfObject1[++b] = scriptable3;
/*      */             break;
/*      */           case 51:
/* 1772 */             arrayOfObject1[++b] = Boolean.FALSE;
/*      */             break;
/*      */           case 52:
/* 1775 */             arrayOfObject1[++b] = Boolean.TRUE;
/*      */             break;
/*      */           case 74:
/* 1778 */             arrayOfObject1[++b] = Undefined.instance;
/*      */             break;
/*      */           case 62:
/* 1781 */             context.interpreterSecurityDomain = null;
/* 1782 */             throw new JavaScriptException(arrayOfObject1[b--]);
/*      */           case 87:
/* 1784 */             context.interpreterSecurityDomain = null;
/* 1785 */             object3 = arrayOfObject1[b--];
/* 1786 */             if (object3 instanceof JavaScriptException) {
/* 1787 */               throw (JavaScriptException)object3;
/*      */             }
/* 1789 */             throw (RuntimeException)object3;
/*      */           case 3:
/* 1791 */             object3 = arrayOfObject1[b--];
/* 1792 */             scriptable2 = ScriptRuntime.enterWith(object3, scriptable2);
/*      */             break;
/*      */           case 4:
/* 1795 */             scriptable2 = ScriptRuntime.leaveWith(scriptable2);
/*      */             break;
/*      */           case 77:
/* 1798 */             arrayOfObject1[++b] = ScriptRuntime.newScope();
/*      */             break;
/*      */           case 79:
/* 1801 */             b3 = arrayOfByte[++i] & 0xFF;
/* 1802 */             object3 = arrayOfObject1[b--];
/* 1803 */             arrayOfObject2[b3] = ScriptRuntime.initEnum(object3, scriptable2);
/*      */             break;
/*      */           case 80:
/* 1806 */             b3 = arrayOfByte[++i] & 0xFF;
/* 1807 */             arrayOfObject1[++b] = 
/* 1808 */               ScriptRuntime.nextEnum((Enumeration)arrayOfObject2[b3]);
/*      */             break;
/*      */           case 81:
/* 1811 */             object3 = arrayOfObject1[b];
/* 1812 */             arrayOfObject1[b] = ScriptRuntime.getProto(object3, scriptable2);
/*      */             break;
/*      */           case 82:
/* 1815 */             object3 = arrayOfObject1[b];
/* 1816 */             arrayOfObject1[b] = ScriptRuntime.getParent(object3);
/*      */             break;
/*      */           case 86:
/* 1819 */             object3 = arrayOfObject1[b];
/* 1820 */             arrayOfObject1[b] = ScriptRuntime.getParent(object3, scriptable2);
/*      */             break;
/*      */           case 83:
/* 1823 */             object5 = arrayOfObject1[b--];
/* 1824 */             object3 = arrayOfObject1[b];
/* 1825 */             arrayOfObject1[b] = 
/* 1826 */               ScriptRuntime.setProto(object3, object5, scriptable2);
/*      */             break;
/*      */           case 84:
/* 1829 */             object5 = arrayOfObject1[b--];
/* 1830 */             object3 = arrayOfObject1[b];
/* 1831 */             arrayOfObject1[b] = 
/* 1832 */               ScriptRuntime.setParent(object3, object5, scriptable2);
/*      */             break;
/*      */           case 85:
/* 1835 */             arrayOfObject1[++b] = scriptable2;
/*      */             break;
/*      */           case 55:
/* 1838 */             k = arrayOfByte[i + 1] << 8 | arrayOfByte[i + 2] & 0xFF;
/* 1839 */             arrayOfObject1[++b] = 
/* 1840 */               new InterpretedFunction(
/* 1841 */                 paramInterpreterData.itsNestedFunctions[k], 
/* 1842 */                 scriptable2, context);
/* 1843 */             createFunctionObject(
/* 1844 */                 (InterpretedFunction)arrayOfObject1[b], scriptable2);
/* 1845 */             i += 2;
/*      */             break;
/*      */           case 56:
/* 1848 */             k = arrayOfByte[i + 1] << 8 | arrayOfByte[i + 2] & 0xFF;
/* 1849 */             arrayOfObject1[++b] = paramInterpreterData.itsRegExpLiterals[k];
/* 1850 */             i += 2;
/*      */             break;
/*      */           case 146:
/* 1853 */             k = arrayOfByte[i + 1] << 8 | arrayOfByte[i + 2] & 0xFF;
/* 1854 */             context.interpreterLine = k;
/* 1855 */             i += 2;
/*      */             break;
/*      */           case 147:
/* 1858 */             context.interpreterSourceFile = paramInterpreterData.itsSourceFile;
/*      */             break;
/*      */           default:
/* 1861 */             dumpICode(paramInterpreterData);
/* 1862 */             throw new RuntimeException("Unknown icode : " + (
/* 1863 */                 arrayOfByte[i] & 0xFF) + " @ pc : " + i);
/*      */         } 
/* 1865 */         i++;
/*      */       }
/* 1867 */       catch (EcmaError ecmaError) {
/*      */ 
/*      */         
/* 1870 */         b = 0;
/* 1871 */         context.interpreterSecurityDomain = null;
/* 1872 */         if (b1 > 0) {
/* 1873 */           i = arrayOfInt1[--b1];
/* 1874 */           scriptable2 = arrayOfScriptable[b1];
/* 1875 */           if (i == 0) {
/* 1876 */             i = arrayOfInt2[b1];
/* 1877 */             if (i == 0)
/* 1878 */               throw ecmaError; 
/* 1879 */             arrayOfObject1[0] = ecmaError.getErrorObject();
/*      */           } else {
/*      */             
/* 1882 */             arrayOfObject1[0] = ecmaError.getErrorObject();
/*      */           } 
/*      */         } else {
/* 1885 */           throw ecmaError;
/*      */         } 
/*      */         
/* 1888 */         context.interpreterSecurityDomain = paramInterpreterData.securityDomain;
/*      */       }
/* 1890 */       catch (JavaScriptException javaScriptException) {
/* 1891 */         b = 0;
/* 1892 */         context.interpreterSecurityDomain = null;
/* 1893 */         if (b1 > 0) {
/* 1894 */           i = arrayOfInt1[--b1];
/* 1895 */           scriptable2 = arrayOfScriptable[b1];
/* 1896 */           if (i == 0) {
/* 1897 */             i = arrayOfInt2[b1];
/* 1898 */             if (i == 0)
/* 1899 */               throw javaScriptException; 
/* 1900 */             arrayOfObject1[0] = javaScriptException;
/*      */           } else {
/*      */             
/* 1903 */             arrayOfObject1[0] = ScriptRuntime.unwrapJavaScriptException(javaScriptException);
/*      */           } 
/*      */         } else {
/* 1906 */           throw javaScriptException;
/*      */         } 
/*      */         
/* 1909 */         context.interpreterSecurityDomain = paramInterpreterData.securityDomain;
/*      */       }
/* 1911 */       catch (RuntimeException runtimeException) {
/* 1912 */         context.interpreterSecurityDomain = null;
/* 1913 */         if (b1 > 0) {
/* 1914 */           b = 0;
/* 1915 */           arrayOfObject1[0] = runtimeException;
/* 1916 */           i = arrayOfInt2[--b1];
/* 1917 */           scriptable2 = arrayOfScriptable[b1];
/* 1918 */           if (i == 0) throw runtimeException;
/*      */         
/*      */         } else {
/* 1921 */           throw runtimeException;
/*      */         } 
/*      */         
/* 1924 */         context.interpreterSecurityDomain = paramInterpreterData.securityDomain;
/*      */       } 
/*      */     } 
/* 1927 */     context.interpreterSecurityDomain = object1;
/* 1928 */     return object2;
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Interpreter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */