package org.mozilla.javascript;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Vector;

public class Interpreter extends LabelTable {
  public static final boolean printICode = false;
  
  boolean itsInFunctionFlag;
  
  Vector itsFunctionList;
  
  InterpreterData itsData;
  
  public IRFactory createIRFactory(TokenStream paramTokenStream, ClassNameHelper paramClassNameHelper, Scriptable paramScriptable) { return new IRFactory(paramTokenStream, paramScriptable); }
  
  public Node transform(Node paramNode, TokenStream paramTokenStream, Scriptable paramScriptable) { return (new NodeTransformer()).transform(paramNode, null, paramTokenStream, paramScriptable); }
  
  public Object compile(Context paramContext, Scriptable paramScriptable, Node paramNode, Object paramObject, SecuritySupport paramSecuritySupport, ClassNameHelper paramClassNameHelper) throws IOException {
    this.version = paramContext.getLanguageVersion();
    this.itsData = new InterpreterData(0, 0, 0, paramObject, 
        paramContext.hasCompileFunctionsWithDynamicScope());
    if (paramNode instanceof FunctionNode) {
      FunctionNode functionNode = (FunctionNode)paramNode;
      InterpretedFunction interpretedFunction = 
        generateFunctionICode(paramContext, paramScriptable, functionNode, paramObject);
      interpretedFunction.itsData.itsFunctionType = functionNode.getFunctionType();
      createFunctionObject(interpretedFunction, paramScriptable);
      return interpretedFunction;
    } 
    return generateScriptICode(paramContext, paramScriptable, paramNode, paramObject);
  }
  
  private void generateICodeFromTree(Node paramNode, VariableTable paramVariableTable, boolean paramBoolean, Object paramObject) {
    int i = 0;
    this.itsData.itsVariableTable = paramVariableTable;
    this.itsData.itsNeedsActivation = paramBoolean;
    i = generateICode(paramNode, i);
    this.itsData.itsICodeTop = i;
    if (this.itsEpilogLabel != -1)
      markLabel(this.itsEpilogLabel, i); 
    for (byte b = 0; b < this.itsLabelTableTop; b++)
      this.itsLabelTable[b].fixGotos(this.itsData.itsICode); 
  }
  
  private Object[] generateRegExpLiterals(Context paramContext, Scriptable paramScriptable, Vector paramVector) {
    Object[] arrayOfObject = new Object[paramVector.size()];
    RegExpProxy regExpProxy = paramContext.getRegExpProxy();
    for (byte b = 0; b < paramVector.size(); b++) {
      Node node1 = (Node)paramVector.elementAt(b);
      Node node2 = node1.getFirstChild();
      Node node3 = node1.getLastChild();
      arrayOfObject[b] = regExpProxy.newRegExp(paramContext, paramScriptable, node2.getString(), 
          (node2 != node3) ? node3.getString() : null, false);
      node1.putProp(12, new Integer(b));
    } 
    return arrayOfObject;
  }
  
  private InterpretedScript generateScriptICode(Context paramContext, Scriptable paramScriptable, Node paramNode, Object paramObject) {
    this.itsSourceFile = (String)paramNode.getProp(16);
    this.itsFunctionList = (Vector)paramNode.getProp(5);
    if (this.itsFunctionList != null)
      generateNestedFunctions(paramScriptable, paramContext, paramObject); 
    Object[] arrayOfObject = null;
    Vector vector = (Vector)paramNode.getProp(12);
    if (vector != null)
      arrayOfObject = generateRegExpLiterals(paramContext, paramScriptable, vector); 
    VariableTable variableTable = (VariableTable)paramNode.getProp(10);
    generateICodeFromTree(paramNode, variableTable, false, paramObject);
    this.itsData.itsNestedFunctions = this.itsNestedFunctions;
    this.itsData.itsRegExpLiterals = arrayOfObject;
    return new InterpretedScript(this.itsData, paramContext);
  }
  
  private void generateNestedFunctions(Scriptable paramScriptable, Context paramContext, Object paramObject) {
    this.itsNestedFunctions = new InterpretedFunction[this.itsFunctionList.size()];
    for (short s = 0; s < this.itsFunctionList.size(); s = (short)(s + 1)) {
      FunctionNode functionNode = (FunctionNode)this.itsFunctionList.elementAt(s);
      Interpreter interpreter = new Interpreter();
      interpreter.itsSourceFile = this.itsSourceFile;
      interpreter.itsData = new InterpreterData(0, 0, 0, paramObject, 
          paramContext.hasCompileFunctionsWithDynamicScope());
      interpreter.itsData.itsFunctionType = functionNode.getFunctionType();
      interpreter.itsInFunctionFlag = true;
      this.itsNestedFunctions[s] = interpreter.generateFunctionICode(paramContext, paramScriptable, functionNode, 
          paramObject);
      functionNode.putProp(5, new Short(s));
    } 
  }
  
  private InterpretedFunction generateFunctionICode(Context paramContext, Scriptable paramScriptable, FunctionNode paramFunctionNode, Object paramObject) {
    this.itsFunctionList = (Vector)paramFunctionNode.getProp(5);
    if (this.itsFunctionList != null)
      generateNestedFunctions(paramScriptable, paramContext, paramObject); 
    Object[] arrayOfObject = null;
    Vector vector = (Vector)paramFunctionNode.getProp(12);
    if (vector != null)
      arrayOfObject = generateRegExpLiterals(paramContext, paramScriptable, vector); 
    VariableTable variableTable = paramFunctionNode.getVariableTable();
    generateICodeFromTree(paramFunctionNode.getLastChild(), 
        variableTable, paramFunctionNode.requiresActivation(), 
        paramObject);
    this.itsData.itsName = paramFunctionNode.getFunctionName();
    this.itsData.itsSource = (String)paramFunctionNode.getProp(17);
    this.itsData.itsNestedFunctions = this.itsNestedFunctions;
    this.itsData.itsRegExpLiterals = arrayOfObject;
    return new InterpretedFunction(this.itsData, paramContext);
  }
  
  int itsTryDepth = 0;
  
  int itsStackDepth = 0;
  
  int itsEpilogLabel = -1;
  
  String itsSourceFile;
  
  int itsLineNumber = 0;
  
  InterpretedFunction[] itsNestedFunctions = null;
  
  static PrintWriter out;
  
  private int updateLineNumber(Node paramNode, int paramInt) {
    Object object = paramNode.getDatum();
    if (object == null || !(object instanceof Number))
      return paramInt; 
    short s = ((Number)object).shortValue();
    if (s != this.itsLineNumber) {
      this.itsLineNumber = s;
      paramInt = addByte((byte)-110, paramInt);
      paramInt = addByte((byte)(s >> 8), paramInt);
      paramInt = addByte((byte)(s & 0xFF), paramInt);
    } 
    return paramInt;
  }
  
  private void badTree(Node paramNode) {
    try {
      out = new PrintWriter(new FileOutputStream("icode.txt", true));
      out.println("Un-handled node : " + paramNode.toString());
      out.close();
    } catch (IOException iOException) {}
    throw new RuntimeException("Un-handled node : " + 
        paramNode.toString());
  }
  
  private int generateICode(Node paramNode, int paramInt) {
    Node node10, node9, node8;
    int i4;
    Vector vector;
    String str4;
    int i3;
    Node node7;
    Short short;
    int i2;
    String str2;
    int i1, m;
    Node node4;
    String str1;
    Number number;
    int n;
    Node node6;
    Object object2;
    String str3;
    Node node5;
    int k, j;
    Node node3;
    Object object1;
    int i = paramNode.getType();
    Node node1 = paramNode.getFirstChild();
    Node node2 = node1;
    switch (i) {
      case 109:
        paramInt = addByte((byte)55, paramInt);
        node6 = (Node)paramNode.getProp(5);
        short = (Short)node6.getProp(5);
        paramInt = addByte((byte)(short.shortValue() >> 8), paramInt);
        paramInt = addByte((byte)(short.shortValue() & 0xFF), paramInt);
        this.itsStackDepth++;
        if (this.itsStackDepth > this.itsData.itsMaxStack)
          this.itsData.itsMaxStack = this.itsStackDepth; 
        break;
      case 145:
        paramInt = updateLineNumber(paramNode, paramInt);
        while (node1 != null) {
          if (node1.getType() != 109)
            paramInt = generateICode(node1, paramInt); 
          node1 = node1.getNextSibling();
        } 
        break;
      case 115:
        paramInt = updateLineNumber(paramNode, paramInt);
        node1 = node1.getNextSibling();
        while (node1 != null) {
          paramInt = generateICode(node1, paramInt);
          node1 = node1.getNextSibling();
        } 
        break;
      case 116:
      case 123:
      case 127:
      case 131:
      case 132:
      case 135:
      case 137:
        paramInt = updateLineNumber(paramNode, paramInt);
        while (node1 != null) {
          paramInt = generateICode(node1, paramInt);
          node1 = node1.getNextSibling();
        } 
        break;
      case 95:
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)57, paramInt);
        this.itsStackDepth--;
        node1 = node1.getNextSibling();
        paramInt = generateICode(node1, paramInt);
        break;
      case 114:
        paramInt = updateLineNumber(paramNode, paramInt);
        paramInt = generateICode(node1, paramInt);
        i1 = this.itsData.itsMaxLocals++;
        paramInt = addByte((byte)69, paramInt);
        paramInt = addByte((byte)i1, paramInt);
        paramInt = addByte((byte)57, paramInt);
        this.itsStackDepth--;
        vector = (Vector)paramNode.getProp(13);
        for (i4 = 0; i4 < vector.size(); i4++) {
          Node node11 = (Node)vector.elementAt(i4);
          Node node12 = node11.getFirstChild();
          paramInt = generateICode(node12, paramInt);
          paramInt = addByte((byte)70, paramInt);
          this.itsStackDepth++;
          if (this.itsStackDepth > this.itsData.itsMaxStack)
            this.itsData.itsMaxStack = this.itsStackDepth; 
          paramInt = addByte((byte)i1, paramInt);
          paramInt = addByte((byte)53, paramInt);
          Node node13 = new Node(136);
          node11.addChildAfter(node13, node12);
          Node node14 = new Node(7);
          node14.putProp(1, node13);
          paramInt = addGoto(node14, 7, 
              paramInt);
          this.itsStackDepth--;
        } 
        node8 = (Node)paramNode.getProp(14);
        if (node8 != null) {
          Node node11 = new Node(136);
          node8.getFirstChild().addChildToFront(node11);
          Node node12 = new Node(6);
          node12.putProp(1, node11);
          paramInt = addGoto(node12, 6, 
              paramInt);
        } 
        node9 = (Node)paramNode.getProp(2);
        node10 = new Node(6);
        node10.putProp(1, node9);
        paramInt = addGoto(node10, 6, 
            paramInt);
        break;
      case 136:
        object2 = paramNode.getProp(20);
        if (object2 == null) {
          int i5 = markLabel(acquireLabel(), paramInt);
          paramNode.putProp(20, new Integer(i5));
        } else {
          int i5 = ((Integer)object2).intValue();
          markLabel(i5, paramInt);
        } 
        if (paramNode.getProp(21) != null) {
          this.itsStackDepth = 1;
          if (this.itsStackDepth > this.itsData.itsMaxStack)
            this.itsData.itsMaxStack = this.itsStackDepth; 
        } 
        break;
      case 101:
      case 102:
        paramInt = generateICode(node1, paramInt);
        node1 = node1.getNextSibling();
        paramInt = generateICode(node1, paramInt);
        n = paramNode.getInt();
        if (this.version == 120)
          if (n == 14) {
            n = 53;
          } else if (n == 15) {
            n = 54;
          }  
        paramInt = addByte((byte)n, paramInt);
        this.itsStackDepth--;
        break;
      case 30:
      case 43:
        if (this.itsSourceFile != null && (this.itsData.itsSourceFile == null || !this.itsSourceFile.equals(this.itsData.itsSourceFile)))
          this.itsData.itsSourceFile = this.itsSourceFile; 
        paramInt = addByte((byte)-109, paramInt);
        n = 0;
        i3 = -1;
        while (node1 != null) {
          paramInt = generateICode(node1, paramInt);
          if (i3 == -1)
            if (node1.getType() == 44) {
              i3 = (short)(this.itsData.itsStringTableIndex - 1);
            } else if (node1.getType() == 39) {
              i3 = (short)(this.itsData.itsStringTableIndex - 1);
            }  
          node1 = node1.getNextSibling();
          n++;
        } 
        if (paramNode.getProp(30) != null) {
          paramInt = addByte((byte)67, paramInt);
          paramInt = addByte((byte)(this.itsLineNumber >> 8), paramInt);
          paramInt = addByte((byte)(this.itsLineNumber & 0xFF), paramInt);
          paramInt = addString(this.itsSourceFile, paramInt);
        } else {
          paramInt = addByte((byte)i, paramInt);
          paramInt = addByte((byte)(i3 >> 8), paramInt);
          paramInt = addByte((byte)(i3 & 0xFF), paramInt);
        } 
        this.itsStackDepth -= n - 1;
        if (i == 30) {
          n--;
        } else {
          n -= 2;
        } 
        paramInt = addByte((byte)(n >> 8), paramInt);
        paramInt = addByte((byte)(n & 0xFF), paramInt);
        if (n > this.itsData.itsMaxArgs)
          this.itsData.itsMaxArgs = n; 
        paramInt = addByte((byte)-109, paramInt);
        break;
      case 69:
      case 143:
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)69, paramInt);
        paramInt = addLocalRef(paramNode, paramInt);
        break;
      case 144:
        if (paramNode.getProp(true) != null) {
          paramInt = addByte((byte)66, paramInt);
        } else {
          paramInt = addByte((byte)70, paramInt);
          this.itsStackDepth++;
          if (this.itsStackDepth > this.itsData.itsMaxStack)
            this.itsData.itsMaxStack = this.itsStackDepth; 
        } 
        node5 = (Node)paramNode.getProp(7);
        paramInt = addLocalRef(node5, paramInt);
        break;
      case 70:
        paramInt = addByte((byte)70, paramInt);
        node5 = (Node)paramNode.getProp(6);
        paramInt = addLocalRef(node5, paramInt);
        this.itsStackDepth++;
        if (this.itsStackDepth > this.itsData.itsMaxStack)
          this.itsData.itsMaxStack = this.itsStackDepth; 
        break;
      case 7:
      case 8:
        paramInt = generateICode(node1, paramInt);
        this.itsStackDepth--;
      case 6:
        paramInt = addGoto(paramNode, (byte)i, paramInt);
        break;
      case 142:
        node5 = (Node)paramNode.getProp(1);
        node5.putProp(21, paramNode);
        paramInt = addGoto(paramNode, 65, 
            paramInt);
        break;
      case 100:
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)9, paramInt);
        this.itsStackDepth++;
        if (this.itsStackDepth > this.itsData.itsMaxStack)
          this.itsData.itsMaxStack = this.itsStackDepth; 
        m = acquireLabel();
        paramInt = addGoto(m, 8, 
            paramInt);
        paramInt = addByte((byte)57, paramInt);
        this.itsStackDepth--;
        node1 = node1.getNextSibling();
        paramInt = generateICode(node1, paramInt);
        markLabel(m, paramInt);
        break;
      case 99:
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)9, paramInt);
        this.itsStackDepth++;
        if (this.itsStackDepth > this.itsData.itsMaxStack)
          this.itsData.itsMaxStack = this.itsStackDepth; 
        m = acquireLabel();
        paramInt = addGoto(m, 7, 
            paramInt);
        paramInt = addByte((byte)57, paramInt);
        this.itsStackDepth--;
        node1 = node1.getNextSibling();
        paramInt = generateICode(node1, paramInt);
        markLabel(m, paramInt);
        break;
      case 39:
        paramInt = generateICode(node1, paramInt);
        str3 = (String)paramNode.getProp(19);
        if (str3 != null) {
          if (str3.equals("__proto__")) {
            paramInt = addByte((byte)81, paramInt);
            break;
          } 
          if (str3.equals("__parent__")) {
            paramInt = addByte((byte)86, paramInt);
            break;
          } 
          badTree(paramNode);
          break;
        } 
        node1 = node1.getNextSibling();
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)39, paramInt);
        this.itsStackDepth--;
        break;
      case 11:
      case 12:
      case 13:
      case 20:
      case 21:
      case 22:
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 31:
      case 41:
        paramInt = generateICode(node1, paramInt);
        node1 = node1.getNextSibling();
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)i, paramInt);
        this.itsStackDepth--;
        break;
      case 141:
        paramInt = generateICode(node1, paramInt);
        object1 = paramNode.getProp(18);
        if (object1 == ScriptRuntime.NumberClass) {
          paramInt = addByte((byte)58, paramInt);
          break;
        } 
        badTree(paramNode);
        break;
      case 104:
        paramInt = generateICode(node1, paramInt);
        switch (paramNode.getInt()) {
          case 131:
            paramInt = addByte((byte)57, paramInt);
            paramInt = addByte((byte)74, paramInt);
            break;
          case 128:
            k = acquireLabel();
            i3 = acquireLabel();
            paramInt = addGoto(k, 7, 
                paramInt);
            paramInt = addByte((byte)52, paramInt);
            paramInt = addGoto(i3, 6, 
                paramInt);
            markLabel(k, paramInt);
            paramInt = addByte((byte)51, paramInt);
            markLabel(i3, paramInt);
            break;
          case 28:
            paramInt = addByte((byte)28, paramInt);
            break;
          case 32:
            paramInt = addByte((byte)32, paramInt);
            break;
          case 24:
            paramInt = addByte((byte)29, paramInt);
            break;
          case 23:
            paramInt = addByte((byte)58, paramInt);
            break;
        } 
        badTree(paramNode);
        break;
      case 40:
        paramInt = generateICode(node1, paramInt);
        node1 = node1.getNextSibling();
        paramInt = generateICode(node1, paramInt);
        str2 = (String)paramNode.getProp(19);
        if (str2 != null) {
          if (str2.equals("__proto__")) {
            paramInt = addByte((byte)83, paramInt);
            break;
          } 
          if (str2.equals("__parent__")) {
            paramInt = addByte((byte)84, paramInt);
            break;
          } 
          badTree(paramNode);
          break;
        } 
        node1 = node1.getNextSibling();
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)40, paramInt);
        this.itsStackDepth -= 2;
        break;
      case 42:
        paramInt = generateICode(node1, paramInt);
        node1 = node1.getNextSibling();
        paramInt = generateICode(node1, paramInt);
        node1 = node1.getNextSibling();
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)i, paramInt);
        this.itsStackDepth -= 2;
        break;
      case 10:
        paramInt = generateICode(node1, paramInt);
        node1 = node1.getNextSibling();
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)10, paramInt);
        paramInt = addString(node2.getString(), paramInt);
        this.itsStackDepth--;
        break;
      case 32:
        str2 = paramNode.getString();
        i3 = -1;
        if (this.itsInFunctionFlag && !this.itsData.itsNeedsActivation)
          i3 = this.itsData.itsVariableTable.getOrdinal(str2); 
        if (i3 == -1) {
          paramInt = addByte((byte)78, paramInt);
          paramInt = addString(str2, paramInt);
        } else {
          paramInt = addByte((byte)72, paramInt);
          paramInt = addByte((byte)i3, paramInt);
          paramInt = addByte((byte)32, paramInt);
        } 
        this.itsStackDepth++;
        if (this.itsStackDepth > this.itsData.itsMaxStack)
          this.itsData.itsMaxStack = this.itsStackDepth; 
        break;
      case 140:
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)82, paramInt);
        break;
      case 44:
      case 46:
      case 61:
      case 71:
        paramInt = addByte((byte)i, paramInt);
        paramInt = addString(paramNode.getString(), paramInt);
        this.itsStackDepth++;
        if (this.itsStackDepth > this.itsData.itsMaxStack)
          this.itsData.itsMaxStack = this.itsStackDepth; 
        break;
      case 105:
      case 106:
        j = node1.getType();
        switch (j) {
          case 72:
            str4 = node1.getString();
            if (this.itsData.itsNeedsActivation) {
              paramInt = addByte((byte)85, paramInt);
              paramInt = addByte((byte)46, paramInt);
              paramInt = addString(str4, paramInt);
              this.itsStackDepth += 2;
              if (this.itsStackDepth > this.itsData.itsMaxStack)
                this.itsData.itsMaxStack = this.itsStackDepth; 
              paramInt = addByte((byte)(
                  (i == 105) ? 
                  34 : 
                  37), 
                  paramInt);
              this.itsStackDepth--;
              break;
            } 
            paramInt = addByte((byte)(
                (i == 105) ? 
                59 : 
                60), 
                paramInt);
            i4 = this.itsData.itsVariableTable
              .getOrdinal(str4);
            paramInt = addByte((byte)i4, paramInt);
            this.itsStackDepth++;
            if (this.itsStackDepth > this.itsData.itsMaxStack)
              this.itsData.itsMaxStack = this.itsStackDepth; 
            break;
          case 39:
          case 41:
            node7 = node1.getFirstChild();
            paramInt = generateICode(node7, 
                paramInt);
            node7 = node7.getNextSibling();
            paramInt = generateICode(node7, 
                paramInt);
            if (j == 39) {
              paramInt = addByte((byte)(
                  (i == 105) ? 
                  34 : 
                  37), 
                  paramInt);
            } else {
              paramInt = addByte((byte)(
                  (i == 105) ? 
                  35 : 
                  38), 
                  paramInt);
            } 
            this.itsStackDepth--;
            break;
        } 
        paramInt = addByte((byte)(
            (i == 105) ? 
            33 : 
            36), 
            paramInt);
        paramInt = addString(node1.getString(), 
            paramInt);
        this.itsStackDepth++;
        if (this.itsStackDepth > this.itsData.itsMaxStack)
          this.itsData.itsMaxStack = this.itsStackDepth; 
        break;
      case 45:
        number = (Number)paramNode.getDatum();
        if (number.doubleValue() == 0.0D) {
          paramInt = addByte((byte)47, paramInt);
        } else if (number.doubleValue() == 1.0D) {
          paramInt = addByte((byte)48, paramInt);
        } else {
          paramInt = addByte((byte)45, paramInt);
          paramInt = addNumber(number, paramInt);
        } 
        this.itsStackDepth++;
        if (this.itsStackDepth > this.itsData.itsMaxStack)
          this.itsData.itsMaxStack = this.itsStackDepth; 
        break;
      case 2:
      case 57:
        paramInt = updateLineNumber(paramNode, paramInt);
      case 3:
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)i, paramInt);
        this.itsStackDepth--;
        break;
      case 68:
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)i, paramInt);
        break;
      case 77:
        paramInt = addByte((byte)i, paramInt);
        this.itsStackDepth++;
        if (this.itsStackDepth > this.itsData.itsMaxStack)
          this.itsData.itsMaxStack = this.itsStackDepth; 
        break;
      case 4:
        paramInt = addByte((byte)i, paramInt);
        break;
      case 75:
        this.itsTryDepth++;
        if (this.itsTryDepth > this.itsData.itsMaxTryDepth)
          this.itsData.itsMaxTryDepth = this.itsTryDepth; 
        node4 = (Node)paramNode.getProp(1);
        node7 = (Node)paramNode.getProp(21);
        if (node4 == null) {
          paramInt = addByte((byte)75, paramInt);
          paramInt = addByte((byte)0, paramInt);
          paramInt = addByte((byte)0, paramInt);
        } else {
          paramInt = 
            addGoto(paramNode, 75, paramInt);
        } 
        i4 = 0;
        if (node7 != null) {
          i4 = acquireLabel();
          int i5 = i4 & 0x7FFFFFFF;
          this.itsLabelTable[i5].addFixup(paramInt);
        } 
        paramInt = addByte((byte)0, paramInt);
        paramInt = addByte((byte)0, paramInt);
        node8 = null;
        while (node1 != null) {
          if (node8 == node4) {
            this.itsStackDepth = 1;
            if (this.itsStackDepth > this.itsData.itsMaxStack)
              this.itsData.itsMaxStack = this.itsStackDepth; 
          } 
          if (node1.getNextSibling() == node4)
            paramInt = addByte((byte)76, 
                paramInt); 
          paramInt = generateICode(node1, paramInt);
          node8 = node1;
          node1 = node1.getNextSibling();
        } 
        this.itsStackDepth = 0;
        if (node7 != null) {
          int i5 = acquireLabel();
          paramInt = 
            addGoto(i5, 6, paramInt);
          markLabel(i4, paramInt);
          this.itsStackDepth = 1;
          if (this.itsStackDepth > this.itsData.itsMaxStack)
            this.itsData.itsMaxStack = this.itsStackDepth; 
          int i6 = this.itsData.itsMaxLocals++;
          paramInt = addByte((byte)69, paramInt);
          paramInt = addByte((byte)i6, paramInt);
          paramInt = addByte((byte)57, paramInt);
          Integer integer = 
            (Integer)node7.getProp(20);
          paramInt = addGoto(integer.intValue(), 
              65, paramInt);
          paramInt = addByte((byte)70, paramInt);
          paramInt = addByte((byte)i6, paramInt);
          paramInt = addByte((byte)87, paramInt);
          this.itsStackDepth = 0;
          markLabel(i5, paramInt);
        } 
        this.itsTryDepth--;
        break;
      case 62:
        paramInt = updateLineNumber(paramNode, paramInt);
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)62, paramInt);
        this.itsStackDepth--;
        break;
      case 5:
        paramInt = updateLineNumber(paramNode, paramInt);
        if (node1 != null) {
          paramInt = generateICode(node1, paramInt);
        } else {
          paramInt = addByte((byte)74, paramInt);
          this.itsStackDepth++;
          if (this.itsStackDepth > this.itsData.itsMaxStack)
            this.itsData.itsMaxStack = this.itsStackDepth; 
        } 
        paramInt = addGoto(paramNode, 5, paramInt);
        this.itsStackDepth--;
        break;
      case 72:
        str1 = paramNode.getString();
        if (this.itsData.itsNeedsActivation) {
          paramInt = addByte((byte)85, paramInt);
          paramInt = addByte((byte)46, paramInt);
          paramInt = addString(str1, paramInt);
          this.itsStackDepth += 2;
          if (this.itsStackDepth > this.itsData.itsMaxStack)
            this.itsData.itsMaxStack = this.itsStackDepth; 
          paramInt = addByte((byte)39, paramInt);
          this.itsStackDepth--;
          break;
        } 
        i2 = this.itsData.itsVariableTable.getOrdinal(str1);
        paramInt = addByte((byte)72, paramInt);
        paramInt = addByte((byte)i2, paramInt);
        this.itsStackDepth++;
        if (this.itsStackDepth > this.itsData.itsMaxStack)
          this.itsData.itsMaxStack = this.itsStackDepth; 
        break;
      case 73:
        if (this.itsData.itsNeedsActivation) {
          node1.setType(61);
          paramNode.setType(10);
          paramInt = generateICode(paramNode, paramInt);
          break;
        } 
        str1 = node1.getString();
        node1 = node1.getNextSibling();
        paramInt = generateICode(node1, paramInt);
        i2 = this.itsData.itsVariableTable.getOrdinal(str1);
        paramInt = addByte((byte)73, paramInt);
        paramInt = addByte((byte)i2, paramInt);
        break;
      case 108:
        paramInt = addByte((byte)paramNode.getInt(), paramInt);
        this.itsStackDepth++;
        if (this.itsStackDepth > this.itsData.itsMaxStack)
          this.itsData.itsMaxStack = this.itsStackDepth; 
        break;
      case 79:
        paramInt = generateICode(node1, paramInt);
        paramInt = addByte((byte)79, paramInt);
        paramInt = addLocalRef(paramNode, paramInt);
        this.itsStackDepth--;
        break;
      case 80:
        paramInt = addByte((byte)80, paramInt);
        node3 = (Node)paramNode.getProp(4);
        paramInt = addLocalRef(node3, paramInt);
        this.itsStackDepth++;
        if (this.itsStackDepth > this.itsData.itsMaxStack)
          this.itsData.itsMaxStack = this.itsStackDepth; 
        break;
      case 56:
        node3 = (Node)paramNode.getProp(12);
        i2 = ((Integer)node3.getProp(
            12)).intValue();
        paramInt = addByte((byte)56, paramInt);
        paramInt = addByte((byte)(i2 >> 8), paramInt);
        paramInt = addByte((byte)(i2 & 0xFF), paramInt);
        this.itsStackDepth++;
        if (this.itsStackDepth > this.itsData.itsMaxStack)
          this.itsData.itsMaxStack = this.itsStackDepth; 
        break;
      default:
        badTree(paramNode);
        break;
      case 138:
        break;
    } 
    return paramInt;
  }
  
  private int addLocalRef(Node paramNode, int paramInt) {
    int i;
    Integer integer = (Integer)paramNode.getProp(7);
    if (integer == null) {
      i = this.itsData.itsMaxLocals++;
      paramNode.putProp(7, new Integer(i));
    } else {
      i = integer.intValue();
    } 
    paramInt = addByte((byte)i, paramInt);
    if (i >= this.itsData.itsMaxLocals)
      this.itsData.itsMaxLocals = i + 1; 
    return paramInt;
  }
  
  private int addGoto(Node paramNode, int paramInt1, int paramInt2) {
    int i;
    if (paramNode.getType() == 5) {
      if (this.itsEpilogLabel == -1)
        this.itsEpilogLabel = acquireLabel(); 
      i = this.itsEpilogLabel;
    } else {
      Node node = (Node)paramNode.getProp(1);
      Object object = node.getProp(20);
      if (object == null) {
        i = acquireLabel();
        node.putProp(20, new Integer(i));
      } else {
        i = ((Integer)object).intValue();
      } 
    } 
    return addGoto(i, (byte)paramInt1, paramInt2);
  }
  
  private int addGoto(int paramInt1, int paramInt2, int paramInt3) {
    int i = paramInt3;
    paramInt3 = addByte((byte)paramInt2, paramInt3);
    int j = paramInt1 & 0x7FFFFFFF;
    short s = this.itsLabelTable[j].getPC();
    if (s != -1) {
      short s1 = (short)(s - i);
      paramInt3 = addByte((byte)(s1 >> 8), paramInt3);
      paramInt3 = addByte((byte)s1, paramInt3);
    } else {
      this.itsLabelTable[j].addFixup(i + 1);
      paramInt3 = addByte((byte)0, paramInt3);
      paramInt3 = addByte((byte)0, paramInt3);
    } 
    return paramInt3;
  }
  
  private final int addByte(byte paramByte, int paramInt) {
    if (this.itsData.itsICode.length == paramInt) {
      byte[] arrayOfByte = new byte[paramInt * 2];
      System.arraycopy(this.itsData.itsICode, 0, arrayOfByte, 0, paramInt);
      this.itsData.itsICode = arrayOfByte;
    } 
    this.itsData.itsICode[paramInt++] = paramByte;
    return paramInt;
  }
  
  private final int addString(String paramString, int paramInt) {
    paramInt = addByte((byte)(this.itsData.itsStringTableIndex >> 8), paramInt);
    paramInt = addByte((byte)(this.itsData.itsStringTableIndex & 0xFF), paramInt);
    if (this.itsData.itsStringTable.length == this.itsData.itsStringTableIndex) {
      String[] arrayOfString = new String[this.itsData.itsStringTableIndex * 2];
      System.arraycopy(this.itsData.itsStringTable, 0, arrayOfString, 0, this.itsData.itsStringTableIndex);
      this.itsData.itsStringTable = arrayOfString;
    } 
    this.itsData.itsStringTable[this.itsData.itsStringTableIndex++] = paramString;
    return paramInt;
  }
  
  private final int addNumber(Number paramNumber, int paramInt) {
    paramInt = addByte((byte)(this.itsData.itsNumberTableIndex >> 8), paramInt);
    paramInt = addByte((byte)(this.itsData.itsNumberTableIndex & 0xFF), paramInt);
    if (this.itsData.itsNumberTable.length == this.itsData.itsNumberTableIndex) {
      Number[] arrayOfNumber = new Number[this.itsData.itsNumberTableIndex * 2];
      System.arraycopy(this.itsData.itsNumberTable, 0, arrayOfNumber, 0, this.itsData.itsNumberTableIndex);
      this.itsData.itsNumberTable = arrayOfNumber;
    } 
    this.itsData.itsNumberTable[this.itsData.itsNumberTableIndex++] = paramNumber;
    return paramInt;
  }
  
  private static String getString(String[] paramArrayOfString, byte[] paramArrayOfByte, int paramInt) {
    byte b = (paramArrayOfByte[paramInt] << 8) + (paramArrayOfByte[paramInt + 1] & 0xFF);
    return paramArrayOfString[b];
  }
  
  private static Number getNumber(Number[] paramArrayOfNumber, byte[] paramArrayOfByte, int paramInt) {
    byte b = (paramArrayOfByte[paramInt] << 8) + (paramArrayOfByte[paramInt + 1] & 0xFF);
    return paramArrayOfNumber[b];
  }
  
  private static int getTarget(byte[] paramArrayOfByte, int paramInt) {
    byte b = (paramArrayOfByte[paramInt] << 8) + (paramArrayOfByte[paramInt + 1] & 0xFF);
    return paramInt - 1 + b;
  }
  
  private static void dumpICode(InterpreterData paramInterpreterData) {}
  
  private static final Byte zero = new Byte((byte)0);
  
  private static final Byte one = new Byte((byte)1);
  
  private int version;
  
  private static void createFunctionObject(InterpretedFunction paramInterpretedFunction, Scriptable paramScriptable) {
    paramInterpretedFunction.setPrototype(ScriptableObject.getClassPrototype(paramScriptable, "Function"));
    paramInterpretedFunction.setParentScope(paramScriptable);
    InterpreterData interpreterData = paramInterpretedFunction.itsData;
    if (interpreterData.itsName.length() == 0)
      return; 
    if ((interpreterData.itsFunctionType == 1 && 
      paramInterpretedFunction.itsClosure == null) || (
      interpreterData.itsFunctionType == 3 && 
      paramInterpretedFunction.itsClosure != null))
      ScriptRuntime.setProp(paramScriptable, paramInterpretedFunction.itsData.itsName, paramInterpretedFunction, paramScriptable); 
  }
  
  public static Object interpret(InterpreterData paramInterpreterData) throws JavaScriptException {
    Object[] arrayOfObject1 = new Object[paramInterpreterData.itsMaxStack];
    byte b = -1;
    byte[] arrayOfByte = paramInterpreterData.itsICode;
    int i = 0;
    int j = paramInterpreterData.itsICodeTop;
    Object[] arrayOfObject2 = null;
    if (paramInterpreterData.itsMaxLocals > 0)
      arrayOfObject2 = new Object[paramInterpreterData.itsMaxLocals]; 
    Object[] arrayOfObject3 = null;
    Scriptable scriptable1 = Undefined.instance;
    int k = paramInterpreterData.itsVariableTable.size();
    if (k > 0) {
      arrayOfObject3 = new Object[k];
      for (k = 0; k < paramInterpreterData.itsVariableTable.getParameterCount(); k++) {
        if (k >= paramInterpreterData.itsInArgs.length) {
          arrayOfObject3[k] = scriptable1;
        } else {
          arrayOfObject3[k] = paramInterpreterData.itsInArgs[k];
        } 
      } 
      for (; k < arrayOfObject3.length; k++)
        arrayOfObject3[k] = scriptable1; 
    } 
    Context context = paramInterpreterData.itsCX;
    Scriptable scriptable2 = paramInterpreterData.itsScope;
    if (paramInterpreterData.itsNestedFunctions != null)
      for (k = 0; k < paramInterpreterData.itsNestedFunctions.length; k++)
        createFunctionObject(paramInterpreterData.itsNestedFunctions[k], scriptable2);  
    String str = null;
    int[] arrayOfInt1 = null;
    int[] arrayOfInt2 = null;
    Scriptable[] arrayOfScriptable = null;
    byte b1 = 0;
    if (paramInterpreterData.itsMaxTryDepth > 0) {
      arrayOfInt1 = new int[paramInterpreterData.itsMaxTryDepth];
      arrayOfInt2 = new int[paramInterpreterData.itsMaxTryDepth];
      arrayOfScriptable = new Scriptable[paramInterpreterData.itsMaxTryDepth];
    } 
    Object object1 = context.interpreterSecurityDomain;
    context.interpreterSecurityDomain = paramInterpreterData.securityDomain;
    Object object2 = scriptable1;
    Scriptable scriptable3 = paramInterpreterData.itsThisObj;
    while (i < j) {
      try {
        Scriptable scriptable;
        int n;
        long l;
        int m;
        Object[] arrayOfObject;
        byte b3, b2;
        Object object5, object4, object3;
        switch (arrayOfByte[i] & 0xFF) {
          case 76:
            b1--;
            break;
          case 75:
            k = getTarget(arrayOfByte, i + true);
            if (k == i)
              k = 0; 
            arrayOfInt1[b1] = k;
            k = getTarget(arrayOfByte, i + 3);
            if (k == i + 2)
              k = 0; 
            arrayOfInt2[b1] = k;
            arrayOfScriptable[b1++] = scriptable2;
            i += true;
            break;
          case 19:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.cmp_LEB(object5, object3);
            break;
          case 17:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.cmp_LEB(object3, object5);
            break;
          case 18:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.cmp_LTB(object5, object3);
            break;
          case 16:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.cmp_LTB(object3, object5);
            break;
          case 63:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = 
              new Boolean(ScriptRuntime.in(object3, object5));
            break;
          case 64:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = new Boolean(
                ScriptRuntime.instanceOf(scriptable2, object3, object5));
            break;
          case 14:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.eqB(object3, object5);
            break;
          case 15:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.neB(object3, object5);
            break;
          case 53:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.seqB(object3, object5);
            break;
          case 54:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.sneB(object3, object5);
            break;
          case 8:
            if (!ScriptRuntime.toBoolean(arrayOfObject1[b--])) {
              i = getTarget(arrayOfByte, i + true);
              continue;
            } 
            i += 2;
            break;
          case 7:
            if (ScriptRuntime.toBoolean(arrayOfObject1[b--])) {
              i = getTarget(arrayOfByte, i + 1);
              continue;
            } 
            i += 2;
            break;
          case 6:
            i = getTarget(arrayOfByte, i + 1);
            continue;
          case 65:
            arrayOfObject1[++b] = new Integer(i + 3);
            i = getTarget(arrayOfByte, i + 1);
            continue;
          case 66:
            b3 = arrayOfByte[++i] & 0xFF;
            i = ((Integer)arrayOfObject2[b3]).intValue();
            continue;
          case 57:
            b--;
            break;
          case 9:
            arrayOfObject1[b + 1] = arrayOfObject1[b];
            b++;
            break;
          case 2:
            object2 = arrayOfObject1[b--];
            break;
          case 5:
            object2 = arrayOfObject1[b--];
            i = getTarget(arrayOfByte, i + 1);
            break;
          case 28:
            n = ScriptRuntime.toInt32(arrayOfObject1[b]);
            arrayOfObject1[b] = new Double((n ^ 0xFFFFFFFF));
            break;
          case 13:
            n = ScriptRuntime.toInt32(arrayOfObject1[b--]);
            m = ScriptRuntime.toInt32(arrayOfObject1[b]);
            arrayOfObject1[b] = new Double((m & n));
            break;
          case 11:
            n = ScriptRuntime.toInt32(arrayOfObject1[b--]);
            m = ScriptRuntime.toInt32(arrayOfObject1[b]);
            arrayOfObject1[b] = new Double((m | n));
            break;
          case 12:
            n = ScriptRuntime.toInt32(arrayOfObject1[b--]);
            m = ScriptRuntime.toInt32(arrayOfObject1[b]);
            arrayOfObject1[b] = new Double((m ^ n));
            break;
          case 20:
            n = ScriptRuntime.toInt32(arrayOfObject1[b--]);
            m = ScriptRuntime.toInt32(arrayOfObject1[b]);
            arrayOfObject1[b] = new Double((m << n));
            break;
          case 21:
            n = ScriptRuntime.toInt32(arrayOfObject1[b--]);
            m = ScriptRuntime.toInt32(arrayOfObject1[b]);
            arrayOfObject1[b] = new Double((m >> n));
            break;
          case 22:
            n = ScriptRuntime.toInt32(arrayOfObject1[b--]) & 0x1F;
            l = ScriptRuntime.toUint32(arrayOfObject1[b]);
            arrayOfObject1[b] = new Double((l >>> n));
            break;
          case 23:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.add(object3, object5);
            break;
          case 24:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = new Double(ScriptRuntime.toNumber(object3) - 
                ScriptRuntime.toNumber(object5));
            break;
          case 29:
            object5 = arrayOfObject1[b];
            arrayOfObject1[b] = new Double(-ScriptRuntime.toNumber(object5));
            break;
          case 58:
            object5 = arrayOfObject1[b];
            arrayOfObject1[b] = new Double(ScriptRuntime.toNumber(object5));
            break;
          case 25:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = new Double(ScriptRuntime.toNumber(object3) * 
                ScriptRuntime.toNumber(object5));
            break;
          case 26:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = new Double(ScriptRuntime.toNumber(object3) / 
                ScriptRuntime.toNumber(object5));
            break;
          case 27:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = new Double(ScriptRuntime.toNumber(object3) % 
                ScriptRuntime.toNumber(object5));
            break;
          case 61:
            arrayOfObject1[++b] = 
              ScriptRuntime.bind(scriptable2, 
                getString(paramInterpreterData.itsStringTable, 
                  arrayOfByte, i + 1));
            i += 2;
            break;
          case 71:
            arrayOfObject1[++b] = 
              ScriptRuntime.getBase(scriptable2, 
                getString(paramInterpreterData.itsStringTable, 
                  arrayOfByte, i + 1));
            i += 2;
            break;
          case 10:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = 
              ScriptRuntime.setName((Scriptable)object3, object5, scriptable2, 
                getString(paramInterpreterData.itsStringTable, 
                  arrayOfByte, i + 1));
            i += 2;
            break;
          case 31:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = 
              ScriptRuntime.delete(object3, object5);
            break;
          case 39:
            str = (String)arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = 
              ScriptRuntime.getProp(object3, str, scriptable2);
            break;
          case 40:
            object5 = arrayOfObject1[b--];
            str = (String)arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = 
              ScriptRuntime.setProp(object3, str, object5, scriptable2);
            break;
          case 41:
            object4 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = 
              ScriptRuntime.getElem(object3, object4, scriptable2);
            break;
          case 42:
            object5 = arrayOfObject1[b--];
            object4 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = 
              ScriptRuntime.setElem(object3, object4, object5, scriptable2);
            break;
          case 34:
            str = (String)arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = 
              ScriptRuntime.postIncrement(object3, str, scriptable2);
            break;
          case 37:
            str = (String)arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = 
              ScriptRuntime.postDecrement(object3, str, scriptable2);
            break;
          case 35:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = 
              ScriptRuntime.postIncrementElem(object3, object5, scriptable2);
            break;
          case 38:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = 
              ScriptRuntime.postDecrementElem(object3, object5, scriptable2);
            break;
          case 68:
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.getThis((Scriptable)object3);
            break;
          case 69:
            object3 = arrayOfObject1[b];
            b3 = arrayOfByte[++i] & 0xFF;
            arrayOfObject2[b3] = object3;
            break;
          case 70:
            b3 = arrayOfByte[++i] & 0xFF;
            arrayOfObject1[++b] = arrayOfObject2[b3];
            break;
          case 67:
            k = arrayOfByte[i + 1] << 8 | arrayOfByte[i + 2] & 0xFF;
            str = getString(paramInterpreterData.itsStringTable, arrayOfByte, i + 3);
            b2 = arrayOfByte[i + 5] << 8 | arrayOfByte[i + 6] & 0xFF;
            arrayOfObject = new Object[b2];
            for (k = b2 - 1; k >= 0; k--)
              arrayOfObject[k] = arrayOfObject1[b--]; 
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.callSpecial(
                context, object3, object5, arrayOfObject, 
                scriptable3, scriptable2, str, k);
            i += 6;
            break;
          case 43:
            b2 = arrayOfByte[i + 3] << 8 | arrayOfByte[i + 4] & 0xFF;
            arrayOfObject = new Object[b2];
            for (k = b2 - 1; k >= 0; k--)
              arrayOfObject[k] = arrayOfObject1[b--]; 
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            if (object3 == scriptable1)
              object3 = getString(paramInterpreterData.itsStringTable, arrayOfByte, 
                  i + 1); 
            scriptable = scriptable2;
            if (paramInterpreterData.itsNeedsActivation)
              scriptable = ScriptableObject.getTopLevelScope(scriptable2); 
            arrayOfObject1[b] = ScriptRuntime.call(context, object3, object5, 
                arrayOfObject, 
                scriptable);
            i += 4;
            break;
          case 30:
            b2 = arrayOfByte[i + 3] << 8 | arrayOfByte[i + 4] & 0xFF;
            arrayOfObject = new Object[b2];
            for (k = b2 - 1; k >= 0; k--)
              arrayOfObject[k] = arrayOfObject1[b--]; 
            object3 = arrayOfObject1[b];
            if (object3 == scriptable1)
              object3 = getString(paramInterpreterData.itsStringTable, arrayOfByte, 
                  i + 1); 
            arrayOfObject1[b] = ScriptRuntime.newObject(context, object3, 
                arrayOfObject, 
                scriptable2);
            i += 4;
            break;
          case 32:
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.typeof(object3);
            break;
          case 78:
            str = getString(paramInterpreterData.itsStringTable, arrayOfByte, i + 1);
            arrayOfObject1[++b] = 
              ScriptRuntime.typeofName(scriptable2, str);
            i += 2;
            break;
          case 46:
            arrayOfObject1[++b] = getString(paramInterpreterData.itsStringTable, 
                arrayOfByte, i + 1);
            i += 2;
            break;
          case 45:
            arrayOfObject1[++b] = getNumber(paramInterpreterData.itsNumberTable, 
                arrayOfByte, i + 1);
            i += 2;
            break;
          case 44:
            arrayOfObject1[++b] = ScriptRuntime.name(scriptable2, 
                getString(paramInterpreterData.itsStringTable, 
                  arrayOfByte, i + 1));
            i += 2;
            break;
          case 33:
            arrayOfObject1[++b] = ScriptRuntime.postIncrement(scriptable2, 
                getString(paramInterpreterData.itsStringTable, 
                  arrayOfByte, i + 1));
            i += 2;
            break;
          case 36:
            arrayOfObject1[++b] = ScriptRuntime.postDecrement(scriptable2, 
                getString(paramInterpreterData.itsStringTable, 
                  arrayOfByte, i + 1));
            i += 2;
            break;
          case 73:
            object3 = arrayOfObject1[b];
            b3 = arrayOfByte[++i] & 0xFF;
            arrayOfObject3[b3] = object3;
            break;
          case 72:
            b3 = arrayOfByte[++i] & 0xFF;
            arrayOfObject1[++b] = arrayOfObject3[b3];
            break;
          case 59:
            b3 = arrayOfByte[++i] & 0xFF;
            arrayOfObject1[++b] = arrayOfObject3[b3];
            arrayOfObject3[b3] = ScriptRuntime.postIncrement(arrayOfObject3[b3]);
            break;
          case 60:
            b3 = arrayOfByte[++i] & 0xFF;
            arrayOfObject1[++b] = arrayOfObject3[b3];
            arrayOfObject3[b3] = ScriptRuntime.postDecrement(arrayOfObject3[b3]);
            break;
          case 47:
            arrayOfObject1[++b] = zero;
            break;
          case 48:
            arrayOfObject1[++b] = one;
            break;
          case 49:
            arrayOfObject1[++b] = null;
            break;
          case 50:
            arrayOfObject1[++b] = scriptable3;
            break;
          case 51:
            arrayOfObject1[++b] = Boolean.FALSE;
            break;
          case 52:
            arrayOfObject1[++b] = Boolean.TRUE;
            break;
          case 74:
            arrayOfObject1[++b] = Undefined.instance;
            break;
          case 62:
            context.interpreterSecurityDomain = null;
            throw new JavaScriptException(arrayOfObject1[b--]);
          case 87:
            context.interpreterSecurityDomain = null;
            object3 = arrayOfObject1[b--];
            if (object3 instanceof JavaScriptException)
              throw (JavaScriptException)object3; 
            throw (RuntimeException)object3;
          case 3:
            object3 = arrayOfObject1[b--];
            scriptable2 = ScriptRuntime.enterWith(object3, scriptable2);
            break;
          case 4:
            scriptable2 = ScriptRuntime.leaveWith(scriptable2);
            break;
          case 77:
            arrayOfObject1[++b] = ScriptRuntime.newScope();
            break;
          case 79:
            b3 = arrayOfByte[++i] & 0xFF;
            object3 = arrayOfObject1[b--];
            arrayOfObject2[b3] = ScriptRuntime.initEnum(object3, scriptable2);
            break;
          case 80:
            b3 = arrayOfByte[++i] & 0xFF;
            arrayOfObject1[++b] = 
              ScriptRuntime.nextEnum((Enumeration)arrayOfObject2[b3]);
            break;
          case 81:
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.getProto(object3, scriptable2);
            break;
          case 82:
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.getParent(object3);
            break;
          case 86:
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = ScriptRuntime.getParent(object3, scriptable2);
            break;
          case 83:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = 
              ScriptRuntime.setProto(object3, object5, scriptable2);
            break;
          case 84:
            object5 = arrayOfObject1[b--];
            object3 = arrayOfObject1[b];
            arrayOfObject1[b] = 
              ScriptRuntime.setParent(object3, object5, scriptable2);
            break;
          case 85:
            arrayOfObject1[++b] = scriptable2;
            break;
          case 55:
            k = arrayOfByte[i + 1] << 8 | arrayOfByte[i + 2] & 0xFF;
            arrayOfObject1[++b] = 
              new InterpretedFunction(
                paramInterpreterData.itsNestedFunctions[k], 
                scriptable2, context);
            createFunctionObject(
                (InterpretedFunction)arrayOfObject1[b], scriptable2);
            i += 2;
            break;
          case 56:
            k = arrayOfByte[i + 1] << 8 | arrayOfByte[i + 2] & 0xFF;
            arrayOfObject1[++b] = paramInterpreterData.itsRegExpLiterals[k];
            i += 2;
            break;
          case 146:
            k = arrayOfByte[i + 1] << 8 | arrayOfByte[i + 2] & 0xFF;
            context.interpreterLine = k;
            i += 2;
            break;
          case 147:
            context.interpreterSourceFile = paramInterpreterData.itsSourceFile;
            break;
          default:
            dumpICode(paramInterpreterData);
            throw new RuntimeException("Unknown icode : " + (
                arrayOfByte[i] & 0xFF) + " @ pc : " + i);
        } 
        i++;
      } catch (EcmaError ecmaError) {
        b = 0;
        context.interpreterSecurityDomain = null;
        if (b1 > 0) {
          i = arrayOfInt1[--b1];
          scriptable2 = arrayOfScriptable[b1];
          if (i == 0) {
            i = arrayOfInt2[b1];
            if (i == 0)
              throw ecmaError; 
            arrayOfObject1[0] = ecmaError.getErrorObject();
          } else {
            arrayOfObject1[0] = ecmaError.getErrorObject();
          } 
        } else {
          throw ecmaError;
        } 
        context.interpreterSecurityDomain = paramInterpreterData.securityDomain;
      } catch (JavaScriptException javaScriptException) {
        b = 0;
        context.interpreterSecurityDomain = null;
        if (b1 > 0) {
          i = arrayOfInt1[--b1];
          scriptable2 = arrayOfScriptable[b1];
          if (i == 0) {
            i = arrayOfInt2[b1];
            if (i == 0)
              throw javaScriptException; 
            arrayOfObject1[0] = javaScriptException;
          } else {
            arrayOfObject1[0] = ScriptRuntime.unwrapJavaScriptException(javaScriptException);
          } 
        } else {
          throw javaScriptException;
        } 
        context.interpreterSecurityDomain = paramInterpreterData.securityDomain;
      } catch (RuntimeException runtimeException) {
        context.interpreterSecurityDomain = null;
        if (b1 > 0) {
          b = 0;
          arrayOfObject1[0] = runtimeException;
          i = arrayOfInt2[--b1];
          scriptable2 = arrayOfScriptable[b1];
          if (i == 0)
            throw runtimeException; 
        } else {
          throw runtimeException;
        } 
        context.interpreterSecurityDomain = paramInterpreterData.securityDomain;
      } 
    } 
    context.interpreterSecurityDomain = object1;
    return object2;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Interpreter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */