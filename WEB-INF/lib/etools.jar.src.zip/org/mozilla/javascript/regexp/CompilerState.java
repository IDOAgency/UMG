package org.mozilla.javascript.regexp;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

class CompilerState {
  Context cx;
  
  Scriptable scope;
  
  char[] source;
  
  int indexBegin;
  
  int index;
  
  int flags;
  
  int parenCount;
  
  int progLength;
  
  byte[] prog;
  
  CompilerState(String paramString, int paramInt, Context paramContext, Scriptable paramScriptable) {
    this.source = paramString.toCharArray();
    this.scope = paramScriptable;
    this.flags = paramInt;
    this.cx = paramContext;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\CompilerState.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */