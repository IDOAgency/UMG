package org.mozilla.javascript.regexp;

import java.util.Vector;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.RegExpProxy;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Undefined;

public class RegExpImpl implements RegExpProxy {
  String input;
  
  boolean multiline;
  
  Vector parens = new Vector(9);
  
  SubString lastMatch;
  
  SubString lastParen;
  
  SubString leftContext;
  
  SubString rightContext;
  
  public boolean isRegExp(Object paramObject) { return paramObject instanceof NativeRegExp; }
  
  public Object newRegExp(Context paramContext, Scriptable paramScriptable, String paramString1, String paramString2, boolean paramBoolean) { return new NativeRegExp(paramContext, paramScriptable, paramString1, paramString2, paramBoolean); }
  
  public Object executeRegExp(Object paramObject, Scriptable paramScriptable, String paramString, int[] paramArrayOfInt, boolean paramBoolean) {
    if (paramObject instanceof NativeRegExp)
      return ((NativeRegExp)paramObject).executeRegExp(paramScriptable, paramString, 
          paramArrayOfInt, paramBoolean); 
    return null;
  }
  
  public Object match(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException {
    MatchData matchData = new MatchData();
    matchData.optarg = 1;
    matchData.mode = 1;
    matchData.parent = ScriptableObject.getTopLevelScope(paramFunction);
    Object object = matchOrReplace(paramContext, paramScriptable, paramArrayOfObject, paramFunction, matchData, false);
    return (matchData.arrayobj == null) ? object : matchData.arrayobj;
  }
  
  public Object search(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException {
    MatchData matchData = new MatchData();
    matchData.optarg = 1;
    matchData.mode = 3;
    matchData.parent = ScriptableObject.getTopLevelScope(paramFunction);
    return matchOrReplace(paramContext, paramScriptable, paramArrayOfObject, paramFunction, matchData, false);
  }
  
  public Object replace(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException {
    Scriptable scriptable = (paramArrayOfObject.length < 2) ? Undefined.instance : paramArrayOfObject[1];
    String str = null;
    Function function = null;
    if (scriptable instanceof Function) {
      function = (Function)scriptable;
    } else {
      str = ScriptRuntime.toString(scriptable);
    } 
    ReplaceData replaceData = new ReplaceData();
    replaceData.optarg = 2;
    replaceData.mode = 2;
    replaceData.lambda = function;
    replaceData.repstr = (str == null) ? null : str.toCharArray();
    replaceData.dollar = (str == null) ? -1 : str.indexOf('$');
    replaceData.charArray = null;
    replaceData.length = 0;
    replaceData.index = 0;
    replaceData.leftIndex = 0;
    Object object = matchOrReplace(paramContext, paramScriptable, paramArrayOfObject, paramFunction, replaceData, true);
    if (replaceData.charArray == null) {
      if (replaceData.global || object == null || !object.equals(Boolean.TRUE))
        return replaceData.str; 
      int k = this.leftContext.length;
      int m = k + replaceData.findReplen(this);
      char[] arrayOfChar1 = new char[m];
      SubString subString1 = this.leftContext;
      System.arraycopy(subString1.charArray, subString1.index, 
          arrayOfChar1, 0, k);
      replaceData.doReplace(this, arrayOfChar1, k);
      replaceData.charArray = arrayOfChar1;
      replaceData.length = m;
    } 
    SubString subString = this.rightContext;
    int i = subString.length;
    int j = replaceData.length + i;
    char[] arrayOfChar = new char[j];
    System.arraycopy(replaceData.charArray, 0, 
        arrayOfChar, 0, replaceData.charArray.length);
    System.arraycopy(subString.charArray, subString.index, arrayOfChar, 
        replaceData.length, i);
    return new String(arrayOfChar, 0, j);
  }
  
  private static Object matchOrReplace(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction, GlobData paramGlobData, boolean paramBoolean) throws JavaScriptException {
    NativeRegExp nativeRegExp;
    String str = ScriptRuntime.toString(paramScriptable);
    paramGlobData.str = str;
    RegExpImpl regExpImpl = getRegExpImpl(paramContext);
    Scriptable scriptable = ScriptableObject.getTopLevelScope(paramFunction);
    if (paramArrayOfObject.length == 0) {
      nativeRegExp = new NativeRegExp(paramContext, scriptable, "", "", false);
    } else if (paramArrayOfObject[0] instanceof NativeRegExp) {
      nativeRegExp = (NativeRegExp)paramArrayOfObject[0];
    } else {
      String str2, str1 = ScriptRuntime.toString(paramArrayOfObject[0]);
      if (paramGlobData.optarg < paramArrayOfObject.length) {
        paramArrayOfObject[0] = str1;
        str2 = ScriptRuntime.toString(paramArrayOfObject[paramGlobData.optarg]);
      } else {
        str2 = null;
      } 
      nativeRegExp = new NativeRegExp(paramContext, scriptable, str1, str2, paramBoolean);
    } 
    paramGlobData.regexp = nativeRegExp;
    paramGlobData.global = !((nativeRegExp.getFlags() & true) == 0);
    int[] arrayOfInt = new int[1];
    Object object = null;
    if (paramGlobData.mode == 3) {
      object = nativeRegExp.executeRegExp(paramFunction, str, arrayOfInt, true);
      if (object != null && object.equals(Boolean.TRUE)) {
        object = new Integer(regExpImpl.leftContext.length);
      } else {
        object = new Integer(-1);
      } 
    } else if (paramGlobData.global) {
      nativeRegExp.setLastIndex(0);
      for (byte b = 0; arrayOfInt[0] <= str.length(); b++) {
        object = nativeRegExp.executeRegExp(paramFunction, str, arrayOfInt, true);
        if (object == null || !object.equals(Boolean.TRUE))
          break; 
        paramGlobData.doGlobal(paramFunction, b);
        if (regExpImpl.lastMatch.length == 0)
          if (arrayOfInt[0] != str.length()) {
            arrayOfInt[0] = arrayOfInt[0] + 1;
          } else {
            break;
          }  
      } 
    } else {
      object = nativeRegExp.executeRegExp(paramFunction, str, arrayOfInt, 
          !(paramGlobData.mode != 2));
    } 
    return object;
  }
  
  public int find_split(Function paramFunction, String paramString1, String paramString2, Object paramObject, int[] paramArrayOfInt1, int[] paramArrayOfInt2, boolean[] paramArrayOfBoolean, String[][] paramArrayOfString) {
    int k, i = paramArrayOfInt1[0];
    int j = paramString1.length();
    Context context = Context.getCurrentContext();
    int m = context.getLanguageVersion();
    NativeRegExp nativeRegExp = (NativeRegExp)paramObject;
    while (true) {
      int i1 = paramArrayOfInt1[0];
      paramArrayOfInt1[0] = i;
      if (nativeRegExp.executeRegExp(paramFunction, paramString1, paramArrayOfInt1, true) != Boolean.TRUE) {
        paramArrayOfInt1[0] = i1;
        paramArrayOfInt2[0] = 1;
        paramArrayOfBoolean[0] = false;
        return j;
      } 
      i = paramArrayOfInt1[0];
      paramArrayOfInt1[0] = i1;
      paramArrayOfBoolean[0] = true;
      SubString subString = this.lastMatch;
      paramArrayOfInt2[0] = subString.length;
      if (paramArrayOfInt2[0] == 0)
        if (i == paramArrayOfInt1[0]) {
          if (i == j) {
            if (m == 120) {
              paramArrayOfInt2[0] = 1;
              int i2 = i;
              break;
            } 
            byte b1 = -1;
            break;
          } 
          i++;
          continue;
        }  
      k = i - paramArrayOfInt2[0];
      break;
    } 
    int n = this.parens.size();
    paramArrayOfString[0] = new String[n];
    for (byte b = 0; b < n; b++) {
      SubString subString = getParenSubString(b);
      paramArrayOfString[0][b] = subString.toString();
    } 
    return k;
  }
  
  static RegExpImpl getRegExpImpl(Context paramContext) { return (RegExpImpl)ScriptRuntime.getRegExpProxy(paramContext); }
  
  SubString getParenSubString(int paramInt) {
    if (paramInt >= this.parens.size())
      return SubString.emptySubString; 
    return (SubString)this.parens.elementAt(paramInt);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\RegExpImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */