/*     */ package org.mozilla.javascript.regexp;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.Function;
/*     */ import org.mozilla.javascript.JavaScriptException;
/*     */ import org.mozilla.javascript.RegExpProxy;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegExpImpl
/*     */   implements RegExpProxy
/*     */ {
/*     */   String input;
/*     */   boolean multiline;
/*  46 */   Vector parens = new Vector(9);
/*     */   SubString lastMatch;
/*     */   SubString lastParen;
/*     */   
/*  50 */   public boolean isRegExp(Object paramObject) { return paramObject instanceof NativeRegExp; }
/*     */ 
/*     */   
/*     */   SubString leftContext;
/*     */   SubString rightContext;
/*     */   
/*  56 */   public Object newRegExp(Context paramContext, Scriptable paramScriptable, String paramString1, String paramString2, boolean paramBoolean) { return new NativeRegExp(paramContext, paramScriptable, paramString1, paramString2, paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object executeRegExp(Object paramObject, Scriptable paramScriptable, String paramString, int[] paramArrayOfInt, boolean paramBoolean) {
/*  62 */     if (paramObject instanceof NativeRegExp)
/*  63 */       return ((NativeRegExp)paramObject).executeRegExp(paramScriptable, paramString, 
/*  64 */           paramArrayOfInt, paramBoolean); 
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object match(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException {
/*  73 */     MatchData matchData = new MatchData();
/*  74 */     matchData.optarg = 1;
/*  75 */     matchData.mode = 1;
/*  76 */     matchData.parent = ScriptableObject.getTopLevelScope(paramFunction);
/*  77 */     Object object = matchOrReplace(paramContext, paramScriptable, paramArrayOfObject, paramFunction, matchData, false);
/*  78 */     return (matchData.arrayobj == null) ? object : matchData.arrayobj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object search(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException {
/*  85 */     MatchData matchData = new MatchData();
/*  86 */     matchData.optarg = 1;
/*  87 */     matchData.mode = 3;
/*  88 */     matchData.parent = ScriptableObject.getTopLevelScope(paramFunction);
/*  89 */     return matchOrReplace(paramContext, paramScriptable, paramArrayOfObject, paramFunction, matchData, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object replace(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException {
/*  96 */     Scriptable scriptable = (paramArrayOfObject.length < 2) ? Undefined.instance : paramArrayOfObject[1];
/*  97 */     String str = null;
/*  98 */     Function function = null;
/*  99 */     if (scriptable instanceof Function) {
/* 100 */       function = (Function)scriptable;
/*     */     } else {
/* 102 */       str = ScriptRuntime.toString(scriptable);
/*     */     } 
/*     */     
/* 105 */     ReplaceData replaceData = new ReplaceData();
/* 106 */     replaceData.optarg = 2;
/* 107 */     replaceData.mode = 2;
/* 108 */     replaceData.lambda = function;
/* 109 */     replaceData.repstr = (str == null) ? null : str.toCharArray();
/* 110 */     replaceData.dollar = (str == null) ? -1 : str.indexOf('$');
/* 111 */     replaceData.charArray = null;
/* 112 */     replaceData.length = 0;
/* 113 */     replaceData.index = 0;
/* 114 */     replaceData.leftIndex = 0;
/* 115 */     Object object = matchOrReplace(paramContext, paramScriptable, paramArrayOfObject, paramFunction, replaceData, true);
/*     */ 
/*     */     
/* 118 */     if (replaceData.charArray == null) {
/* 119 */       if (replaceData.global || object == null || !object.equals(Boolean.TRUE))
/*     */       {
/* 121 */         return replaceData.str;
/*     */       }
/* 123 */       int k = this.leftContext.length;
/* 124 */       int m = k + replaceData.findReplen(this);
/* 125 */       char[] arrayOfChar1 = new char[m];
/* 126 */       SubString subString1 = this.leftContext;
/* 127 */       System.arraycopy(subString1.charArray, subString1.index, 
/* 128 */           arrayOfChar1, 0, k);
/* 129 */       replaceData.doReplace(this, arrayOfChar1, k);
/* 130 */       replaceData.charArray = arrayOfChar1;
/* 131 */       replaceData.length = m;
/*     */     } 
/*     */     
/* 134 */     SubString subString = this.rightContext;
/* 135 */     int i = subString.length;
/* 136 */     int j = replaceData.length + i;
/* 137 */     char[] arrayOfChar = new char[j];
/* 138 */     System.arraycopy(replaceData.charArray, 0, 
/* 139 */         arrayOfChar, 0, replaceData.charArray.length);
/* 140 */     System.arraycopy(subString.charArray, subString.index, arrayOfChar, 
/* 141 */         replaceData.length, i);
/* 142 */     return new String(arrayOfChar, 0, j);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object matchOrReplace(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction, GlobData paramGlobData, boolean paramBoolean) throws JavaScriptException {
/*     */     NativeRegExp nativeRegExp;
/* 155 */     String str = ScriptRuntime.toString(paramScriptable);
/* 156 */     paramGlobData.str = str;
/* 157 */     RegExpImpl regExpImpl = getRegExpImpl(paramContext);
/* 158 */     Scriptable scriptable = ScriptableObject.getTopLevelScope(paramFunction);
/*     */     
/* 160 */     if (paramArrayOfObject.length == 0) {
/* 161 */       nativeRegExp = new NativeRegExp(paramContext, scriptable, "", "", false);
/*     */     }
/* 163 */     else if (paramArrayOfObject[0] instanceof NativeRegExp) {
/* 164 */       nativeRegExp = (NativeRegExp)paramArrayOfObject[0];
/*     */     } else {
/* 166 */       String str2, str1 = ScriptRuntime.toString(paramArrayOfObject[0]);
/*     */       
/* 168 */       if (paramGlobData.optarg < paramArrayOfObject.length) {
/* 169 */         paramArrayOfObject[0] = str1;
/* 170 */         str2 = ScriptRuntime.toString(paramArrayOfObject[paramGlobData.optarg]);
/*     */       } else {
/* 172 */         str2 = null;
/*     */       } 
/* 174 */       nativeRegExp = new NativeRegExp(paramContext, scriptable, str1, str2, paramBoolean);
/*     */     } 
/* 176 */     paramGlobData.regexp = nativeRegExp;
/*     */     
/* 178 */     paramGlobData.global = !((nativeRegExp.getFlags() & true) == 0);
/* 179 */     int[] arrayOfInt = new int[1];
/* 180 */     Object object = null;
/* 181 */     if (paramGlobData.mode == 3)
/* 182 */     { object = nativeRegExp.executeRegExp(paramFunction, str, arrayOfInt, true);
/* 183 */       if (object != null && object.equals(Boolean.TRUE))
/* 184 */       { object = new Integer(regExpImpl.leftContext.length); }
/*     */       else
/* 186 */       { object = new Integer(-1); }  }
/* 187 */     else if (paramGlobData.global)
/* 188 */     { nativeRegExp.setLastIndex(0);
/* 189 */       for (byte b = 0; arrayOfInt[0] <= str.length(); b++) {
/* 190 */         object = nativeRegExp.executeRegExp(paramFunction, str, arrayOfInt, true);
/* 191 */         if (object == null || !object.equals(Boolean.TRUE))
/*     */           break; 
/* 193 */         paramGlobData.doGlobal(paramFunction, b);
/* 194 */         if (regExpImpl.lastMatch.length == 0)
/* 195 */           if (arrayOfInt[0] != str.length())
/*     */           
/* 197 */           { arrayOfInt[0] = arrayOfInt[0] + 1; }
/*     */           else { break; }
/*     */            
/*     */       }  }
/* 201 */     else { object = nativeRegExp.executeRegExp(paramFunction, str, arrayOfInt, 
/* 202 */           !(paramGlobData.mode != 2)); }
/*     */ 
/*     */     
/* 205 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int find_split(Function paramFunction, String paramString1, String paramString2, Object paramObject, int[] paramArrayOfInt1, int[] paramArrayOfInt2, boolean[] paramArrayOfBoolean, String[][] paramArrayOfString) {
/* 214 */     int k, i = paramArrayOfInt1[0];
/* 215 */     int j = paramString1.length();
/*     */     
/* 217 */     Context context = Context.getCurrentContext();
/* 218 */     int m = context.getLanguageVersion();
/* 219 */     NativeRegExp nativeRegExp = (NativeRegExp)paramObject;
/*     */ 
/*     */     
/*     */     while (true) {
/* 223 */       int i1 = paramArrayOfInt1[0];
/* 224 */       paramArrayOfInt1[0] = i;
/* 225 */       if (nativeRegExp.executeRegExp(paramFunction, paramString1, paramArrayOfInt1, true) != Boolean.TRUE) {
/*     */ 
/*     */         
/* 228 */         paramArrayOfInt1[0] = i1;
/* 229 */         paramArrayOfInt2[0] = 1;
/* 230 */         paramArrayOfBoolean[0] = false;
/* 231 */         return j;
/*     */       } 
/* 233 */       i = paramArrayOfInt1[0];
/* 234 */       paramArrayOfInt1[0] = i1;
/* 235 */       paramArrayOfBoolean[0] = true;
/*     */       
/* 237 */       SubString subString = this.lastMatch;
/* 238 */       paramArrayOfInt2[0] = subString.length;
/* 239 */       if (paramArrayOfInt2[0] == 0)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 246 */         if (i == paramArrayOfInt1[0]) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 253 */           if (i == j) {
/* 254 */             if (m == 120) {
/* 255 */               paramArrayOfInt2[0] = 1;
/* 256 */               int i2 = i;
/*     */               break;
/*     */             } 
/* 259 */             byte b1 = -1;
/*     */             break;
/*     */           } 
/* 262 */           i++;
/*     */           
/*     */           continue;
/*     */         } 
/*     */       }
/* 267 */       k = i - paramArrayOfInt2[0];
/*     */       break;
/*     */     } 
/* 270 */     int n = this.parens.size();
/* 271 */     paramArrayOfString[0] = new String[n];
/* 272 */     for (byte b = 0; b < n; b++) {
/* 273 */       SubString subString = getParenSubString(b);
/* 274 */       paramArrayOfString[0][b] = subString.toString();
/*     */     } 
/* 276 */     return k;
/*     */   }
/*     */ 
/*     */   
/* 280 */   static RegExpImpl getRegExpImpl(Context paramContext) { return (RegExpImpl)ScriptRuntime.getRegExpProxy(paramContext); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SubString getParenSubString(int paramInt) {
/* 288 */     if (paramInt >= this.parens.size())
/* 289 */       return SubString.emptySubString; 
/* 290 */     return (SubString)this.parens.elementAt(paramInt);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\RegExpImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */