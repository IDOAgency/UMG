package org.mozilla.javascript.regexp;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

class MatchData extends GlobData {
  Scriptable arrayobj;
  
  void doGlobal(Function paramFunction, int paramInt) throws JavaScriptException {
    MatchData matchData = this;
    Context context = Context.getCurrentContext();
    RegExpImpl regExpImpl = RegExpImpl.getRegExpImpl(context);
    if (this.arrayobj == null) {
      Scriptable scriptable = ScriptableObject.getTopLevelScope(paramFunction);
      this.arrayobj = ScriptRuntime.newObject(context, scriptable, "Array", null);
    } 
    SubString subString = regExpImpl.lastMatch;
    String str = subString.toString();
    this.arrayobj.put(paramInt, this.arrayobj, str);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\MatchData.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */