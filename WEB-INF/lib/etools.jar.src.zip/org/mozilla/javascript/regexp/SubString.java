package org.mozilla.javascript.regexp;

class SubString {
  public SubString() {}
  
  public SubString(String paramString) {
    this.index = 0;
    this.charArray = paramString.toCharArray();
    this.length = paramString.length();
  }
  
  public String toString() {
    return (this.charArray == null) ? 
      "" : 
      new String(this.charArray, this.index, this.length);
  }
  
  static final SubString emptySubString = new SubString();
  
  char[] charArray;
  
  int index;
  
  int length;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\SubString.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */