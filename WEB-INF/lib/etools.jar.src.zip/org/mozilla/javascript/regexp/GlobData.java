package org.mozilla.javascript.regexp;

import org.mozilla.javascript.Function;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.Scriptable;

abstract class GlobData {
  static final int GLOB_MATCH = 1;
  
  static final int GLOB_REPLACE = 2;
  
  static final int GLOB_SEARCH = 3;
  
  byte mode;
  
  int optarg;
  
  boolean global;
  
  String str;
  
  NativeRegExp regexp;
  
  Scriptable parent;
  
  abstract void doGlobal(Function paramFunction, int paramInt) throws JavaScriptException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\GlobData.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */