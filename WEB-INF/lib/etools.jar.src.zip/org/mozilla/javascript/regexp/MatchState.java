package org.mozilla.javascript.regexp;

import org.mozilla.javascript.Scriptable;

class MatchState {
  boolean anchoring;
  
  int pcend;
  
  int cpbegin;
  
  int cpend;
  
  int start;
  
  int skipped;
  
  byte flags;
  
  int parenCount;
  
  SubString[] maybeParens;
  
  SubString[] parens;
  
  Scriptable scope;
  
  char[] input;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\MatchState.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */