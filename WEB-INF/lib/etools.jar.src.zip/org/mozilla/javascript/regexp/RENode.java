package org.mozilla.javascript.regexp;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.NativeGlobal;
import org.mozilla.javascript.ScriptRuntime;

class RENode {
  public static final int ANCHORED = 1;
  
  public static final int SINGLE = 2;
  
  public static final int NONEMPTY = 4;
  
  public static final int ISNEXT = 8;
  
  public static final int GOODNEXT = 16;
  
  public static final int ISJOIN = 32;
  
  public static final int REALLOK = 64;
  
  public static final int MINIMAL = 128;
  
  byte op;
  
  byte flags;
  
  short offset;
  
  RENode next;
  
  Object kid;
  
  int kid2;
  
  int num;
  
  char chr;
  
  short min;
  
  short max;
  
  short kidlen;
  
  short bmsize;
  
  char[] s;
  
  byte[] bitmap;
  
  RENode(CompilerState paramCompilerState, byte paramByte, Object paramObject) {
    this.op = paramByte;
    this.kid = paramObject;
  }
  
  private void calcBMSize(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) {
    char c = Character.MIN_VALUE;
    while (paramInt1 < paramInt2) {
      char c1 = paramArrayOfChar[paramInt1++];
      if (c1 == '\\')
        if (paramInt1 + 5 <= paramInt2 && paramArrayOfChar[paramInt1] == 'u' && 
          NativeRegExp.isHex(paramArrayOfChar[paramInt1 + 1]) && 
          NativeRegExp.isHex(paramArrayOfChar[paramInt1 + 2]) && 
          NativeRegExp.isHex(paramArrayOfChar[paramInt1 + 3]) && 
          NativeRegExp.isHex(paramArrayOfChar[paramInt1 + 4])) {
          int i = (((NativeRegExp.unHex(paramArrayOfChar[paramInt1]) << 4) + 
            NativeRegExp.unHex(paramArrayOfChar[paramInt1 + 1]) << 4) + 
            NativeRegExp.unHex(paramArrayOfChar[paramInt1 + 2]) << 4) + 
            NativeRegExp.unHex(paramArrayOfChar[paramInt1 + 3]);
          c1 = (char)i;
          paramInt1 += 5;
        } else {
          if (c < 'ÿ')
            c = 'ÿ'; 
          continue;
        }  
      if (paramBoolean) {
        char c2;
        if ((c2 = Character.toUpperCase(c1)) > c)
          c = c2; 
        if ((c2 = Character.toLowerCase(c2)) > c)
          c = c2; 
      } 
      if (c1 > c)
        c = c1; 
    } 
    this.bmsize = (short)((c + '\b') / 
      '\b');
  }
  
  private void matchBit(char paramChar, int paramInt) {
    char c = paramChar >> '\003';
    byte b = (byte)(paramChar & 0x7);
    b = (byte)(1 << b);
    if (paramInt != 0) {
      this.bitmap[c] = (byte)(this.bitmap[c] & (b ^ 0xFFFFFFFF));
    } else {
      this.bitmap[c] = (byte)(this.bitmap[c] | b);
    } 
  }
  
  private void checkRange(char paramChar, int paramInt) {
    matchBit(paramChar, paramInt);
    matchBit('-', paramInt);
  }
  
  void buildBitmap(MatchState paramMatchState, char[] paramArrayOfChar, boolean paramBoolean) {
    int i = ((Integer)this.kid).intValue();
    int j = this.kid2;
    byte b = 0;
    boolean bool1 = false;
    this.kid2 = 0;
    if (paramArrayOfChar[i] == '^') {
      bool1 = true;
      this.kid2 = -1;
      i++;
    } 
    calcBMSize(paramArrayOfChar, i, j, paramBoolean);
    this.bitmap = new byte[this.bmsize];
    if (bool1) {
      b = -1;
      for (byte b1 = 0; b1 < this.bmsize; b1++)
        this.bitmap[b1] = -1; 
      this.bitmap[0] = -2;
    } 
    short s1 = this.bmsize * 8;
    char c = (char)s1;
    boolean bool2 = false;
    while (i < j) {
      char c1 = paramArrayOfChar[i++];
      if (c1 == '\\') {
        int m, k;
        c1 = paramArrayOfChar[i++];
        switch (c1) {
          case 'b':
          case 'f':
          case 'n':
          case 'r':
          case 't':
          case 'v':
            c1 = NativeRegExp.getEscape(c1);
            break;
          case 'd':
            if (bool2)
              checkRange(c, b); 
            c = (char)s1;
            for (c1 = '0'; c1 <= '9'; c1 = (char)(c1 + '\001'))
              matchBit(c1, b); 
            continue;
          case 'D':
            if (bool2)
              checkRange(c, b); 
            c = (char)s1;
            for (c1 = Character.MIN_VALUE; c1 < '0'; c1 = (char)(c1 + '\001'))
              matchBit(c1, b); 
            for (c1 = ':'; c1 < s1; c1 = (char)(c1 + '\001'))
              matchBit(c1, b); 
            continue;
          case 'w':
            if (bool2)
              checkRange(c, b); 
            c = (char)s1;
            for (c1 = Character.MIN_VALUE; c1 < s1; c1 = (char)(c1 + '\001')) {
              if (NativeRegExp.isWord(c1))
                matchBit(c1, b); 
            } 
            continue;
          case 'W':
            if (bool2)
              checkRange(c, b); 
            c = (char)s1;
            for (c1 = Character.MIN_VALUE; c1 < s1; c1 = (char)(c1 + '\001')) {
              if (!NativeRegExp.isWord(c1))
                matchBit(c1, b); 
            } 
            continue;
          case 's':
            if (bool2)
              checkRange(c, b); 
            c = (char)s1;
            for (c1 = Character.MIN_VALUE; c1 < s1; c1 = (char)(c1 + '\001')) {
              if (Character.isWhitespace(c1))
                matchBit(c1, b); 
            } 
            continue;
          case 'S':
            if (bool2)
              checkRange(c, b); 
            c = (char)s1;
            for (c1 = Character.MIN_VALUE; c1 < s1; c1 = (char)(c1 + '\001')) {
              if (!Character.isWhitespace(c1))
                matchBit(c1, b); 
            } 
            continue;
          case '0':
          case '1':
          case '2':
          case '3':
          case '4':
          case '5':
          case '6':
          case '7':
            k = NativeRegExp.unDigit(c1);
            m = i - 2;
            c1 = paramArrayOfChar[i];
            if (c1 >= '0' && c1 <= '7') {
              i++;
              k = 8 * k + NativeRegExp.unDigit(c1);
              c1 = paramArrayOfChar[i];
              if (c1 >= '0' && c1 <= '7') {
                i++;
                int n = 8 * k + NativeRegExp.unDigit(c1);
                if (n <= 255) {
                  k = n;
                } else {
                  i--;
                } 
              } 
            } 
            c1 = (char)k;
            break;
          case 'x':
            m = i;
            if (i < paramArrayOfChar.length && 
              NativeRegExp.isHex(c1 = paramArrayOfChar[i++])) {
              k = NativeRegExp.unHex(c1);
              if (i < paramArrayOfChar.length && 
                NativeRegExp.isHex(c1 = paramArrayOfChar[i++])) {
                k <<= 4;
                k += NativeRegExp.unHex(c1);
              } 
            } else {
              i = m;
              k = 120;
            } 
            c1 = (char)k;
            break;
          case 'u':
            if (paramArrayOfChar.length > i + 3 && 
              NativeRegExp.isHex(paramArrayOfChar[i]) && 
              NativeRegExp.isHex(paramArrayOfChar[i + 1]) && 
              NativeRegExp.isHex(paramArrayOfChar[i + 2]) && 
              NativeRegExp.isHex(paramArrayOfChar[i + 3])) {
              k = (((NativeRegExp.unHex(paramArrayOfChar[i]) << 4) + 
                NativeRegExp.unHex(paramArrayOfChar[i + 1]) << 4) + 
                NativeRegExp.unHex(paramArrayOfChar[i + 2]) << 4) + 
                NativeRegExp.unHex(paramArrayOfChar[i + 3]);
              c1 = (char)k;
              i += 4;
            } 
            break;
          case 'c':
            c1 = paramArrayOfChar[i++];
            c1 = Character.toUpperCase(c1);
            c1 = (char)(c1 ^ 0x40);
            break;
        } 
      } 
      if (bool2) {
        if (c > c1)
          throw NativeGlobal.constructError(
              Context.getCurrentContext(), "RangeError", 
              ScriptRuntime.getMessage(
                "msg.bad.range", null), 
              paramMatchState.scope); 
        bool2 = false;
      } else {
        c = c1;
        if (i + 1 < j && paramArrayOfChar[i] == '-' && 
          paramArrayOfChar[i + 1] != ']') {
          i++;
          bool2 = true;
          continue;
        } 
      } 
      for (; c <= c1; c = (char)(c + '\001')) {
        matchBit(c, b);
        if (paramBoolean) {
          char c2 = Character.toUpperCase(c);
          matchBit(c2, b);
          c2 = Character.toLowerCase(c2);
          matchBit(c2, b);
        } 
      } 
      c = c1;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\RENode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */