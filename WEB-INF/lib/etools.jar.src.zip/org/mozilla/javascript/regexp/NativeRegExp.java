package org.mozilla.javascript.regexp;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.NativeFunction;
import org.mozilla.javascript.NativeGlobal;
import org.mozilla.javascript.PropertyException;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.TokenStream;

public class NativeRegExp extends ScriptableObject implements Function {
  public static final int GLOB = 1;
  
  public static final int FOLD = 2;
  
  public static final int MULTILINE = 4;
  
  private static final boolean debug = false;
  
  static final int JS_BITS_PER_BYTE = 8;
  
  private static final byte REOP_EMPTY = 0;
  
  private static final byte REOP_ALT = 1;
  
  private static final byte REOP_BOL = 2;
  
  private static final byte REOP_EOL = 3;
  
  private static final byte REOP_WBDRY = 4;
  
  private static final byte REOP_WNONBDRY = 5;
  
  private static final byte REOP_QUANT = 6;
  
  private static final byte REOP_STAR = 7;
  
  private static final byte REOP_PLUS = 8;
  
  private static final byte REOP_OPT = 9;
  
  private static final byte REOP_LPAREN = 10;
  
  private static final byte REOP_RPAREN = 11;
  
  private static final byte REOP_DOT = 12;
  
  private static final byte REOP_CCLASS = 13;
  
  private static final byte REOP_DIGIT = 14;
  
  private static final byte REOP_NONDIGIT = 15;
  
  private static final byte REOP_ALNUM = 16;
  
  private static final byte REOP_NONALNUM = 17;
  
  private static final byte REOP_SPACE = 18;
  
  private static final byte REOP_NONSPACE = 19;
  
  private static final byte REOP_BACKREF = 20;
  
  private static final byte REOP_FLAT = 21;
  
  private static final byte REOP_FLAT1 = 22;
  
  private static final byte REOP_JUMP = 23;
  
  private static final byte REOP_DOTSTAR = 24;
  
  private static final byte REOP_ANCHOR = 25;
  
  private static final byte REOP_EOLONLY = 26;
  
  private static final byte REOP_UCFLAT = 27;
  
  private static final byte REOP_UCFLAT1 = 28;
  
  private static final byte REOP_UCCLASS = 29;
  
  private static final byte REOP_NUCCLASS = 30;
  
  private static final byte REOP_BACKREFi = 31;
  
  private static final byte REOP_FLATi = 32;
  
  private static final byte REOP_FLAT1i = 33;
  
  private static final byte REOP_UCFLATi = 34;
  
  private static final byte REOP_UCFLAT1i = 35;
  
  private static final byte REOP_ANCHOR1 = 36;
  
  private static final byte REOP_NCCLASS = 37;
  
  private static final byte REOP_DOTSTARMIN = 38;
  
  private static final byte REOP_LPARENNON = 39;
  
  private static final byte REOP_RPARENNON = 40;
  
  private static final byte REOP_ASSERT = 41;
  
  private static final byte REOP_ASSERT_NOT = 42;
  
  private static final byte REOP_END = 43;
  
  private static final int REOP_FLATLEN_MAX = 255;
  
  private static int level;
  
  public static void init(Scriptable paramScriptable) throws PropertyException {
    NativeRegExp nativeRegExp = new NativeRegExp();
    nativeRegExp.setParentScope(paramScriptable);
    nativeRegExp.setPrototype(ScriptableObject.getObjectPrototype(paramScriptable));
    String[] arrayOfString1 = { "compile", "toString", "exec", "test" };
    nativeRegExp.defineFunctionProperties(arrayOfString1, NativeRegExp.class, 
        2);
    String[] arrayOfString2 = { "lastIndex", "source", "global", "ignoreCase", "multiline" };
    int[] arrayOfInt = { 4, 
        5, 
        5, 
        5, 
        5 };
    for (byte b = 0; b < arrayOfString2.length; b++)
      nativeRegExp.defineProperty(arrayOfString2[b], NativeRegExp.class, arrayOfInt[b]); 
    Scriptable scriptable = NativeRegExpCtor.init(paramScriptable);
    scriptable.put("prototype", scriptable, nativeRegExp);
  }
  
  public NativeRegExp(Context paramContext, Scriptable paramScriptable, String paramString1, String paramString2, boolean paramBoolean) { init(paramContext, paramScriptable, paramString1, paramString2, paramBoolean); }
  
  public void init(Context paramContext, Scriptable paramScriptable, String paramString1, String paramString2, boolean paramBoolean) {
    this.source = paramString1;
    this.flags = 0;
    if (paramString2 != null)
      for (byte b = 0; b < paramString2.length(); b++) {
        char c = paramString2.charAt(b);
        if (c == 'g') {
          this.flags = (byte)(this.flags | true);
        } else if (c == 'i') {
          this.flags = (byte)(this.flags | 0x2);
        } else if (c == 'm') {
          this.flags = (byte)(this.flags | 0x4);
        } else {
          Object[] arrayOfObject = { new Character(c) };
          throw NativeGlobal.constructError(
              paramContext, "SyntaxError", 
              ScriptRuntime.getMessage(
                "msg.invalid.re.flag", arrayOfObject), 
              paramScriptable);
        } 
      }  
    CompilerState compilerState = new CompilerState(paramString1, this.flags, paramContext, paramScriptable);
    if (paramBoolean) {
      this.ren = null;
      int i = paramString1.length();
      int j = 0;
      while (i > 0) {
        int k = i;
        if (k > 255)
          k = 255; 
        RENode rENode1 = new RENode(compilerState, (k == 1) ? 22 : 21, 
            new Integer(j));
        rENode1.flags = 4;
        if (k > 1) {
          rENode1.kid2 = j + k;
        } else {
          rENode1.flags = (byte)(rENode1.flags | 0x2);
          rENode1.chr = compilerState.source[j];
        } 
        j += k;
        i -= k;
        if (this.ren == null) {
          this.ren = rENode1;
          continue;
        } 
        setNext(compilerState, this.ren, rENode1);
      } 
    } else {
      this.ren = parseRegExp(compilerState);
    } 
    if (this.ren == null)
      return; 
    RENode rENode = new RENode(compilerState, (byte)43, null);
    setNext(compilerState, this.ren, rENode);
    this.lastIndex = 0;
    this.parenCount = compilerState.parenCount;
    this.flags = this.flags;
    paramScriptable = ScriptableObject.getTopLevelScope(paramScriptable);
    setPrototype(ScriptableObject.getClassPrototype(paramScriptable, "RegExp"));
    setParentScope(paramScriptable);
  }
  
  public String getClassName() { return "RegExp"; }
  
  public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) { return execSub(paramContext, this, paramArrayOfObject, paramScriptable1, false, this); }
  
  public Scriptable construct(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject) { return (Scriptable)call(paramContext, paramScriptable, null, paramArrayOfObject); }
  
  public static Scriptable compile(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    NativeRegExp nativeRegExp = (NativeRegExp)paramScriptable;
    String str1 = (paramArrayOfObject.length == 0) ? "" : ScriptRuntime.toString(paramArrayOfObject[0]);
    String str2 = (paramArrayOfObject.length > 1) ? ScriptRuntime.toString(paramArrayOfObject[1]) : 
      null;
    nativeRegExp.init(paramContext, paramFunction, str1, str2, false);
    return nativeRegExp;
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append('/');
    stringBuffer.append(this.source);
    stringBuffer.append('/');
    if ((this.flags & true) != 0)
      stringBuffer.append('g'); 
    if ((this.flags & 0x2) != 0)
      stringBuffer.append('i'); 
    if ((this.flags & 0x4) != 0)
      stringBuffer.append('m'); 
    return stringBuffer.toString();
  }
  
  public long getLastIndex() { return this.lastIndex & 0xFFFFFFFFL; }
  
  public void setLastIndex(int paramInt) { this.lastIndex = paramInt; }
  
  public String getSource() { return this.source; }
  
  public boolean getGlobal() { return !((this.flags & true) == 0); }
  
  public boolean getIgnoreCase() { return !((this.flags & 0x2) == 0); }
  
  public boolean getMultiline() { return !((this.flags & 0x4) == 0); }
  
  public NativeRegExp() {}
  
  private static RegExpImpl getImpl(Context paramContext) { return (RegExpImpl)ScriptRuntime.getRegExpProxy(paramContext); }
  
  private static Object execSub(Context paramContext, Scriptable paramScriptable1, Object[] paramArrayOfObject, Scriptable paramScriptable2, boolean paramBoolean, Function paramFunction) {
    boolean bool;
    String str;
    if (!(paramScriptable1 instanceof NativeRegExp)) {
      Object[] arrayOfObject = { ((NativeFunction)paramFunction).jsGet_name() };
      throw NativeGlobal.constructError(
          paramContext, "TypeError", 
          ScriptRuntime.getMessage(
            "msg.incompat.call", arrayOfObject), 
          paramScriptable2);
    } 
    NativeRegExp nativeRegExp = (NativeRegExp)paramScriptable1;
    if (paramArrayOfObject.length == 0) {
      str = (getImpl(paramContext)).input;
      if (str == null) {
        Object[] arrayOfObject = { nativeRegExp.toString() };
        throw NativeGlobal.constructError(
            paramContext, "SyntaxError", 
            
            ScriptRuntime.getMessage("msg.no.re.input.for", arrayOfObject), 
            paramScriptable1);
      } 
    } else {
      str = ScriptRuntime.toString(paramArrayOfObject[0]);
    } 
    if ((nativeRegExp.flags & true) != 0) {
      bool = nativeRegExp.lastIndex;
    } else {
      bool = false;
    } 
    int[] arrayOfInt = { bool };
    Object object = nativeRegExp.executeRegExp(paramScriptable2, str, arrayOfInt, paramBoolean);
    if ((nativeRegExp.flags & true) != 0)
      nativeRegExp.lastIndex = (object == null) ? 0 : arrayOfInt[0]; 
    return object;
  }
  
  public static Object exec(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return execSub(paramContext, paramScriptable, paramArrayOfObject, paramFunction, false, paramFunction); }
  
  public static Object test(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    Object object = execSub(paramContext, paramScriptable, paramArrayOfObject, paramFunction, true, paramFunction);
    if (object == null || !object.equals(Boolean.TRUE))
      object = Boolean.FALSE; 
    return object;
  }
  
  private static String[] reopname = null;
  
  static final String metachars = "|^${*+?().[\\";
  
  static final String closurechars = "{*+?";
  
  private String source;
  
  private int lastIndex;
  
  private int parenCount;
  
  private byte flags;
  
  private byte[] program;
  
  RENode ren;
  
  private String getPrintableString(String paramString) { return ""; }
  
  private void dumpRegExp(CompilerState paramCompilerState, RENode paramRENode) {}
  
  private void fixNext(CompilerState paramCompilerState, RENode paramRENode1, RENode paramRENode2, RENode paramRENode3) {
    boolean bool = (paramRENode2 == null || (paramRENode2.flags & 0x8) != 0) ? 0 : 1;
    RENode rENode;
    for (; (rENode = paramRENode1.next) != null && rENode != paramRENode3; paramRENode1 = rENode) {
      if (paramRENode1.op == 1) {
        RENode rENode1 = (RENode)paramRENode1.kid;
        if (rENode1.op != 23) {
          RENode rENode2;
          for (rENode2 = rENode1; rENode2.next != null; rENode2 = rENode2.next) {
            if (rENode2.op == 1)
              throw new RuntimeException("REOP_ALT not expected"); 
          } 
          rENode2.next = new RENode(paramCompilerState, (byte)23, null);
          rENode2.next.flags = (byte)(rENode2.next.flags | 0x8);
          rENode2.flags = (byte)(rENode2.flags | 0x10);
          fixNext(paramCompilerState, rENode1, paramRENode2, paramRENode3);
        } 
      } 
    } 
    if (paramRENode2 != null)
      if ((paramRENode2.flags & 0x8) == 0) {
        paramRENode2.flags = (byte)(paramRENode2.flags | 0x8);
      } else {
        paramRENode2.flags = (byte)(paramRENode2.flags | 0x20);
      }  
    paramRENode1.next = paramRENode2;
    if (bool)
      paramRENode1.flags = (byte)(paramRENode1.flags | 0x10); 
    switch (paramRENode1.op) {
      case 1:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 39:
      case 41:
      case 42:
        fixNext(paramCompilerState, (RENode)paramRENode1.kid, paramRENode2, paramRENode3);
        break;
    } 
  }
  
  private void setNext(CompilerState paramCompilerState, RENode paramRENode1, RENode paramRENode2) { fixNext(paramCompilerState, paramRENode1, paramRENode2, null); }
  
  private RENode parseRegExp(CompilerState paramCompilerState) {
    RENode rENode = parseAltern(paramCompilerState);
    if (rENode == null)
      return null; 
    char[] arrayOfChar = paramCompilerState.source;
    int i = paramCompilerState.index;
    if (i < arrayOfChar.length && arrayOfChar[i] == '|') {
      RENode rENode1 = rENode;
      rENode = new RENode(paramCompilerState, (byte)1, rENode1);
      if (rENode == null)
        return null; 
      rENode.flags = (byte)(rENode1.flags & 0x5);
      RENode rENode2 = rENode;
      do {
        paramCompilerState.index = ++i;
        if (i < arrayOfChar.length && (arrayOfChar[i] == '|' || 
          arrayOfChar[i] == ')')) {
          rENode1 = new RENode(paramCompilerState, (byte)0, null);
        } else {
          rENode1 = parseAltern(paramCompilerState);
          i = paramCompilerState.index;
        } 
        if (rENode1 == null)
          return null; 
        RENode rENode3 = new RENode(paramCompilerState, (byte)1, rENode1);
        if (rENode3 == null)
          return null; 
        rENode2.next = rENode3;
        rENode2.flags = (byte)(rENode2.flags | 0x10);
        rENode3.flags = (byte)(rENode1.flags & 0x5 | 
          
          0x8);
        rENode2 = rENode3;
      } while (i < arrayOfChar.length && arrayOfChar[i] == '|');
    } 
    return rENode;
  }
  
  private RENode parseAltern(CompilerState paramCompilerState) {
    RENode rENode1 = parseItem(paramCompilerState);
    if (rENode1 == null)
      return null; 
    RENode rENode2 = rENode1;
    byte b = 0;
    char[] arrayOfChar = paramCompilerState.source;
    int i = paramCompilerState.index;
    char c;
    while (i != arrayOfChar.length && (c = arrayOfChar[i]) != '|' && 
      c != ')') {
      RENode rENode = parseItem(paramCompilerState);
      if (rENode == null)
        return null; 
      setNext(paramCompilerState, rENode2, rENode);
      b |= rENode.flags;
      rENode2 = rENode;
      i = paramCompilerState.index;
    } 
    rENode1.flags = (byte)(rENode1.flags | b & 0x4);
    return rENode1;
  }
  
  RENode parseItem(CompilerState paramCompilerState) {
    byte b;
    RENode rENode;
    char[] arrayOfChar = paramCompilerState.source;
    int i = paramCompilerState.index;
    switch ((i < arrayOfChar.length) ? arrayOfChar[i] : 0) {
      case '^':
        paramCompilerState.index = i + 1;
        rENode = new RENode(paramCompilerState, (byte)2, null);
        rENode.flags = (byte)(rENode.flags | true);
        return rENode;
      case '$':
        paramCompilerState.index = i + 1;
        return new RENode(paramCompilerState, (
            i == paramCompilerState.indexBegin || ((
            arrayOfChar[i - 1] == '(' || 
            arrayOfChar[i - 1] == '|') && (
            i - 1 == paramCompilerState.indexBegin || 
            arrayOfChar[i - 2] != '\\'))) ? 
            26 : 
            3, 
            null);
      case '\\':
        switch ((++i < arrayOfChar.length) ? arrayOfChar[i] : 0) {
          case 'b':
            b = 4;
            paramCompilerState.index = i + 1;
            rENode = new RENode(paramCompilerState, b, null);
            rENode.flags = (byte)(rENode.flags | 0x4);
            return rENode;
          case 'B':
            b = 5;
            paramCompilerState.index = i + 1;
            rENode = new RENode(paramCompilerState, b, null);
            rENode.flags = (byte)(rENode.flags | 0x4);
            return rENode;
        } 
        return parseQuantAtom(paramCompilerState);
    } 
    return parseQuantAtom(paramCompilerState);
  }
  
  RENode parseQuantAtom(CompilerState paramCompilerState) { // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual parseAtom : (Lorg/mozilla/javascript/regexp/CompilerState;)Lorg/mozilla/javascript/regexp/RENode;
    //   5: astore_2
    //   6: aload_2
    //   7: ifnonnull -> 12
    //   10: aconst_null
    //   11: areturn
    //   12: aload_1
    //   13: getfield source : [C
    //   16: astore #8
    //   18: aload_1
    //   19: getfield index : I
    //   22: istore #9
    //   24: goto -> 574
    //   27: aload #8
    //   29: iload #9
    //   31: caload
    //   32: lookupswitch default -> 582, 42 -> 461, 43 -> 479, 63 -> 522, 123 -> 76
    //   76: iinc #9, 1
    //   79: iload #9
    //   81: aload #8
    //   83: arraylength
    //   84: if_icmpeq -> 101
    //   87: aload #8
    //   89: iload #9
    //   91: caload
    //   92: dup
    //   93: istore #4
    //   95: invokestatic isDigit : (C)Z
    //   98: ifne -> 120
    //   101: aload_0
    //   102: ldc 'msg.bad.quant'
    //   104: aload #8
    //   106: aload_1
    //   107: getfield index : I
    //   110: caload
    //   111: invokestatic valueOf : (C)Ljava/lang/String;
    //   114: aload_1
    //   115: invokespecial reportError : (Ljava/lang/String;Ljava/lang/String;Lorg/mozilla/javascript/regexp/CompilerState;)V
    //   118: aconst_null
    //   119: areturn
    //   120: iload #4
    //   122: invokestatic unDigit : (C)I
    //   125: istore #6
    //   127: goto -> 168
    //   130: bipush #10
    //   132: iload #6
    //   134: imul
    //   135: iload #4
    //   137: invokestatic unDigit : (C)I
    //   140: iadd
    //   141: istore #6
    //   143: iload #6
    //   145: bipush #16
    //   147: ishr
    //   148: ifeq -> 168
    //   151: aload_0
    //   152: ldc 'msg.overlarge.max'
    //   154: aload_0
    //   155: aload #8
    //   157: iload #9
    //   159: invokespecial tail : ([CI)Ljava/lang/String;
    //   162: aload_1
    //   163: invokespecial reportError : (Ljava/lang/String;Ljava/lang/String;Lorg/mozilla/javascript/regexp/CompilerState;)V
    //   166: aconst_null
    //   167: areturn
    //   168: iinc #9, 1
    //   171: iload #9
    //   173: aload #8
    //   175: arraylength
    //   176: if_icmpge -> 193
    //   179: aload #8
    //   181: iload #9
    //   183: caload
    //   184: dup
    //   185: istore #4
    //   187: invokestatic isDigit : (C)Z
    //   190: ifne -> 130
    //   193: aload #8
    //   195: iload #9
    //   197: caload
    //   198: bipush #44
    //   200: if_icmpne -> 340
    //   203: iinc #9, 1
    //   206: iload #9
    //   208: istore_3
    //   209: aload #8
    //   211: iload #9
    //   213: caload
    //   214: invokestatic isDigit : (C)Z
    //   217: ifeq -> 334
    //   220: aload #8
    //   222: iload #9
    //   224: caload
    //   225: invokestatic unDigit : (C)I
    //   228: istore #7
    //   230: goto -> 270
    //   233: bipush #10
    //   235: iload #7
    //   237: imul
    //   238: iload #4
    //   240: invokestatic unDigit : (C)I
    //   243: iadd
    //   244: istore #7
    //   246: iload #7
    //   248: bipush #16
    //   250: ishr
    //   251: ifeq -> 270
    //   254: aload_0
    //   255: ldc 'msg.overlarge.max'
    //   257: aload #8
    //   259: iload_3
    //   260: caload
    //   261: invokestatic valueOf : (C)Ljava/lang/String;
    //   264: aload_1
    //   265: invokespecial reportError : (Ljava/lang/String;Ljava/lang/String;Lorg/mozilla/javascript/regexp/CompilerState;)V
    //   268: aconst_null
    //   269: areturn
    //   270: aload #8
    //   272: iinc #9, 1
    //   275: iload #9
    //   277: caload
    //   278: dup
    //   279: istore #4
    //   281: invokestatic isDigit : (C)Z
    //   284: ifne -> 233
    //   287: iload #7
    //   289: ifne -> 311
    //   292: aload_0
    //   293: ldc 'msg.zero.quant'
    //   295: aload_0
    //   296: aload #8
    //   298: aload_1
    //   299: getfield index : I
    //   302: invokespecial tail : ([CI)Ljava/lang/String;
    //   305: aload_1
    //   306: invokespecial reportError : (Ljava/lang/String;Ljava/lang/String;Lorg/mozilla/javascript/regexp/CompilerState;)V
    //   309: aconst_null
    //   310: areturn
    //   311: iload #6
    //   313: iload #7
    //   315: if_icmple -> 368
    //   318: aload_0
    //   319: ldc 'msg.max.lt.min'
    //   321: aload_0
    //   322: aload #8
    //   324: iload_3
    //   325: invokespecial tail : ([CI)Ljava/lang/String;
    //   328: aload_1
    //   329: invokespecial reportError : (Ljava/lang/String;Ljava/lang/String;Lorg/mozilla/javascript/regexp/CompilerState;)V
    //   332: aconst_null
    //   333: areturn
    //   334: iconst_0
    //   335: istore #7
    //   337: goto -> 368
    //   340: iload #6
    //   342: ifne -> 364
    //   345: aload_0
    //   346: ldc 'msg.zero.quant'
    //   348: aload_0
    //   349: aload #8
    //   351: aload_1
    //   352: getfield index : I
    //   355: invokespecial tail : ([CI)Ljava/lang/String;
    //   358: aload_1
    //   359: invokespecial reportError : (Ljava/lang/String;Ljava/lang/String;Lorg/mozilla/javascript/regexp/CompilerState;)V
    //   362: aconst_null
    //   363: areturn
    //   364: iload #6
    //   366: istore #7
    //   368: aload #8
    //   370: iload #9
    //   372: caload
    //   373: bipush #125
    //   375: if_icmpeq -> 397
    //   378: aload_0
    //   379: ldc 'msg.unterm.quant'
    //   381: aload #8
    //   383: aload_1
    //   384: getfield index : I
    //   387: caload
    //   388: invokestatic valueOf : (C)Ljava/lang/String;
    //   391: aload_1
    //   392: invokespecial reportError : (Ljava/lang/String;Ljava/lang/String;Lorg/mozilla/javascript/regexp/CompilerState;)V
    //   395: aconst_null
    //   396: areturn
    //   397: iinc #9, 1
    //   400: new org/mozilla/javascript/regexp/RENode
    //   403: dup
    //   404: aload_1
    //   405: bipush #6
    //   407: aload_2
    //   408: invokespecial <init> : (Lorg/mozilla/javascript/regexp/CompilerState;BLjava/lang/Object;)V
    //   411: astore #5
    //   413: iload #6
    //   415: ifle -> 439
    //   418: aload_2
    //   419: getfield flags : B
    //   422: iconst_4
    //   423: iand
    //   424: ifeq -> 439
    //   427: aload #5
    //   429: dup
    //   430: getfield flags : B
    //   433: iconst_4
    //   434: ior
    //   435: i2b
    //   436: putfield flags : B
    //   439: aload #5
    //   441: iload #6
    //   443: i2s
    //   444: putfield min : S
    //   447: aload #5
    //   449: iload #7
    //   451: i2s
    //   452: putfield max : S
    //   455: aload #5
    //   457: astore_2
    //   458: goto -> 540
    //   461: iinc #9, 1
    //   464: new org/mozilla/javascript/regexp/RENode
    //   467: dup
    //   468: aload_1
    //   469: bipush #7
    //   471: aload_2
    //   472: invokespecial <init> : (Lorg/mozilla/javascript/regexp/CompilerState;BLjava/lang/Object;)V
    //   475: astore_2
    //   476: goto -> 540
    //   479: iinc #9, 1
    //   482: new org/mozilla/javascript/regexp/RENode
    //   485: dup
    //   486: aload_1
    //   487: bipush #8
    //   489: aload_2
    //   490: invokespecial <init> : (Lorg/mozilla/javascript/regexp/CompilerState;BLjava/lang/Object;)V
    //   493: astore #5
    //   495: aload_2
    //   496: getfield flags : B
    //   499: iconst_4
    //   500: iand
    //   501: ifeq -> 516
    //   504: aload #5
    //   506: dup
    //   507: getfield flags : B
    //   510: iconst_4
    //   511: ior
    //   512: i2b
    //   513: putfield flags : B
    //   516: aload #5
    //   518: astore_2
    //   519: goto -> 540
    //   522: iinc #9, 1
    //   525: new org/mozilla/javascript/regexp/RENode
    //   528: dup
    //   529: aload_1
    //   530: bipush #9
    //   532: aload_2
    //   533: invokespecial <init> : (Lorg/mozilla/javascript/regexp/CompilerState;BLjava/lang/Object;)V
    //   536: astore_2
    //   537: goto -> 540
    //   540: iload #9
    //   542: aload #8
    //   544: arraylength
    //   545: if_icmpge -> 574
    //   548: aload #8
    //   550: iload #9
    //   552: caload
    //   553: bipush #63
    //   555: if_icmpne -> 574
    //   558: aload_2
    //   559: dup
    //   560: getfield flags : B
    //   563: sipush #128
    //   566: ior
    //   567: i2b
    //   568: putfield flags : B
    //   571: iinc #9, 1
    //   574: iload #9
    //   576: aload #8
    //   578: arraylength
    //   579: if_icmplt -> 27
    //   582: aload_1
    //   583: iload #9
    //   585: putfield index : I
    //   588: aload_2
    //   589: areturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #805	-> 0
    //   #806	-> 6
    //   #807	-> 10
    //   #813	-> 12
    //   #814	-> 18
    //   #816	-> 24
    //   #817	-> 27
    //   #819	-> 76
    //   #820	-> 101
    //   #821	-> 104
    //   #820	-> 115
    //   #822	-> 118
    //   #824	-> 120
    //   #825	-> 127
    //   #826	-> 130
    //   #827	-> 143
    //   #828	-> 151
    //   #829	-> 162
    //   #828	-> 163
    //   #830	-> 166
    //   #825	-> 168
    //   #833	-> 193
    //   #834	-> 203
    //   #835	-> 209
    //   #836	-> 220
    //   #837	-> 230
    //   #838	-> 233
    //   #839	-> 246
    //   #840	-> 254
    //   #841	-> 257
    //   #840	-> 265
    //   #842	-> 268
    //   #837	-> 270
    //   #845	-> 287
    //   #846	-> 292
    //   #847	-> 295
    //   #846	-> 306
    //   #848	-> 309
    //   #850	-> 311
    //   #851	-> 318
    //   #852	-> 332
    //   #856	-> 334
    //   #833	-> 337
    //   #860	-> 340
    //   #861	-> 345
    //   #862	-> 348
    //   #861	-> 359
    //   #863	-> 362
    //   #865	-> 364
    //   #867	-> 368
    //   #868	-> 378
    //   #869	-> 381
    //   #868	-> 392
    //   #870	-> 395
    //   #872	-> 397
    //   #874	-> 400
    //   #875	-> 413
    //   #876	-> 427
    //   #877	-> 439
    //   #878	-> 447
    //   #879	-> 455
    //   #880	-> 458
    //   #883	-> 461
    //   #884	-> 464
    //   #885	-> 476
    //   #888	-> 479
    //   #889	-> 482
    //   #890	-> 495
    //   #891	-> 504
    //   #892	-> 516
    //   #893	-> 519
    //   #896	-> 522
    //   #897	-> 525
    //   #898	-> 537
    //   #903	-> 540
    //   #904	-> 558
    //   #905	-> 571
    //   #816	-> 574
    //   #909	-> 582
    //   #910	-> 588 }
  
  RENode parseAtom(CompilerState paramCompilerState) {
    byte b;
    char c;
    RENode rENode2;
    int i = 0;
    RENode rENode1 = null;
    boolean bool1 = false;
    boolean bool2 = false;
    char[] arrayOfChar = paramCompilerState.source;
    int k = paramCompilerState.index;
    int m = k;
    if (k == arrayOfChar.length) {
      paramCompilerState.index = k;
      return new RENode(paramCompilerState, (byte)0, null);
    } 
    switch (arrayOfChar[k]) {
      case '|':
        return new RENode(paramCompilerState, (byte)0, null);
      case '(':
        b = 43;
        if (arrayOfChar[k + 1] == '?')
          switch (arrayOfChar[k + 2]) {
            case ':':
              b = 39;
              break;
            case '=':
              b = 41;
              break;
            case '!':
              b = 42;
              break;
          }  
        if (b == 43) {
          b = 10;
          i = paramCompilerState.parenCount++;
          paramCompilerState.index = k + 1;
        } else {
          paramCompilerState.index = k + 3;
        } 
        rENode2 = parseRegExp(paramCompilerState);
        if (rENode2 == null)
          return null; 
        k = paramCompilerState.index;
        if (k >= arrayOfChar.length || arrayOfChar[k] != ')') {
          reportError("msg.unterm.paren", tail(arrayOfChar, m), paramCompilerState);
          return null;
        } 
        k++;
        rENode1 = new RENode(paramCompilerState, b, rENode2);
        rENode1.flags = (byte)(rENode2.flags & 0x5);
        rENode1.num = i;
        if (b == 10 || b == 39) {
          rENode2 = new RENode(paramCompilerState, (byte)(b + 1), null);
          setNext(paramCompilerState, rENode1, rENode2);
          rENode2.num = i;
        } 
        paramCompilerState.index = k;
        return rENode1;
      case '.':
        k++;
        b = 12;
        if (k < arrayOfChar.length && arrayOfChar[k] == '*') {
          k++;
          b = 24;
          if (k < arrayOfChar.length && arrayOfChar[k] == '?') {
            k++;
            b = 38;
          } 
        } 
        rENode1 = new RENode(paramCompilerState, b, null);
        if (rENode1.op == 12)
          rENode1.flags = 6; 
        paramCompilerState.index = k;
        return rENode1;
      case '[':
        if (++k == arrayOfChar.length) {
          reportError("msg.unterm.class", tail(arrayOfChar, m), paramCompilerState);
          return null;
        } 
        c = arrayOfChar[k];
        rENode1 = new RENode(paramCompilerState, (byte)13, new Integer(k));
        if (c == '^' && ++k == arrayOfChar.length) {
          reportError("msg.unterm.class", tail(arrayOfChar, m), paramCompilerState);
          return null;
        } 
        while (true) {
          if (++k == arrayOfChar.length) {
            reportError("msg.unterm.paren", tail(arrayOfChar, m), paramCompilerState);
            return null;
          } 
          c = arrayOfChar[k];
          if (c != ']') {
            if (c == '\\' && k + 1 != arrayOfChar.length)
              k++; 
            continue;
          } 
          break;
        } 
        rENode1.kid2 = k++;
        rENode1.flags = 6;
        paramCompilerState.index = k;
        return rENode1;
      case '\\':
        if (++k == arrayOfChar.length) {
          Context.reportError(ScriptRuntime.getMessage("msg.trail.backslash", null));
          return null;
        } 
        c = arrayOfChar[k];
        switch (c) {
          case 'f':
          case 'n':
          case 'r':
          case 't':
          case 'v':
            c = getEscape(c);
            rENode1 = new RENode(paramCompilerState, (byte)22, null);
            break;
          case 'd':
            rENode1 = new RENode(paramCompilerState, (byte)14, null);
            break;
          case 'D':
            rENode1 = new RENode(paramCompilerState, (byte)15, null);
            break;
          case 'w':
            rENode1 = new RENode(paramCompilerState, (byte)16, null);
            break;
          case 'W':
            rENode1 = new RENode(paramCompilerState, (byte)17, null);
            break;
          case 's':
            rENode1 = new RENode(paramCompilerState, (byte)18, null);
            break;
          case 'S':
            rENode1 = new RENode(paramCompilerState, (byte)19, null);
            break;
          case '0':
          case '1':
          case '2':
          case '3':
          case '4':
          case '5':
          case '6':
          case '7':
          case '8':
          case '9':
            if (paramCompilerState.cx.getLanguageVersion() != 0 && paramCompilerState.cx.getLanguageVersion() <= 140) {
              byte b1;
              switch (c) {
                case '0':
                  paramCompilerState.index = k;
                  i = doOctal(paramCompilerState);
                  k = paramCompilerState.index;
                  rENode1 = new RENode(paramCompilerState, (byte)22, null);
                  c = (char)i;
                  break;
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                  i = unDigit(c);
                  b1 = 1;
                  while (++k < arrayOfChar.length && isDigit(c = arrayOfChar[k])) {
                    i = 10 * i + unDigit(c);
                    b1++;
                  } 
                  if ((i == 8 || i == 9) && i > paramCompilerState.parenCount) {
                    m = --k;
                    bool2 = true;
                    bool1 = true;
                    break;
                  } 
                  if (b1 > 1 || i > paramCompilerState.parenCount) {
                    paramCompilerState.index = m;
                    i = doOctal(paramCompilerState);
                    k = paramCompilerState.index;
                    rENode1 = new RENode(paramCompilerState, (byte)22, null);
                    c = (char)i;
                    break;
                  } 
                  k--;
                  rENode1 = new RENode(paramCompilerState, (byte)20, null);
                  rENode1.num = i - 1;
                  rENode1.flags = 4;
                  bool1 = true;
                  break;
              } 
              break;
            } 
            if (c == '0') {
              rENode1 = new RENode(paramCompilerState, (byte)22, null);
              c = Character.MIN_VALUE;
              break;
            } 
            i = unDigit(c);
            j = 1;
            while (++k < arrayOfChar.length && isDigit(c = arrayOfChar[k])) {
              i = 10 * i + unDigit(c);
              j++;
            } 
            k--;
            rENode1 = new RENode(paramCompilerState, (byte)20, null);
            rENode1.num = i - 1;
            rENode1.flags = 4;
            bool1 = true;
            break;
          case 'x':
            m = k;
            if (++k < arrayOfChar.length && isHex(c = arrayOfChar[k])) {
              i = unHex(c);
              if (++k < arrayOfChar.length && isHex(c = arrayOfChar[k])) {
                i <<= 4;
                i += unHex(c);
              } else if (paramCompilerState.cx.getLanguageVersion() != 0 && paramCompilerState.cx.getLanguageVersion() <= 140) {
                k--;
              } else {
                k = m;
                i = 120;
              } 
            } else {
              k = m;
              i = 120;
            } 
            rENode1 = new RENode(paramCompilerState, (byte)22, null);
            c = (char)i;
            break;
          case 'c':
            c = arrayOfChar[++k];
            if ((c < 'A' || c > 'Z') && (c < 'a' || c > 'z')) {
              k -= 2;
              m = k;
              bool2 = true;
              bool1 = true;
              break;
            } 
            c = Character.toUpperCase(c);
            c = (char)(c ^ 0x40);
            rENode1 = new RENode(paramCompilerState, (byte)22, null);
            break;
          case 'u':
            if (k + 4 < arrayOfChar.length && isHex(arrayOfChar[k + 1]) && isHex(arrayOfChar[k + 2]) && isHex(arrayOfChar[k + 3]) && isHex(arrayOfChar[k + 4])) {
              i = (((unHex(arrayOfChar[k + 1]) << 4) + unHex(arrayOfChar[k + 2]) << 4) + unHex(arrayOfChar[k + 3]) << 4) + unHex(arrayOfChar[k + 4]);
              c = (char)i;
              k += 4;
              rENode1 = new RENode(paramCompilerState, (byte)22, null);
              break;
            } 
            m = k;
            bool2 = true;
            bool1 = true;
            break;
          default:
            m = k;
            bool2 = true;
            bool1 = true;
            break;
        } 
        if (rENode1 != null && !bool1) {
          rENode1.chr = c;
          rENode1.flags = 6;
        } 
        bool1 = false;
        if (!bool2) {
          k++;
        } else {
          bool2 = false;
          break;
        } 
        paramCompilerState.index = k;
        return rENode1;
    } 
    do {
    
    } while (++k != arrayOfChar.length && "|^${*+?().[\\".indexOf(arrayOfChar[k]) == -1);
    int j = k - m;
    if (k != arrayOfChar.length && j > 1 && "{*+?".indexOf(arrayOfChar[k]) != -1) {
      k--;
      j--;
    } 
    if (j > 255) {
      j = 255;
      k = m + j;
    } 
    rENode1 = new RENode(paramCompilerState, (j == 1) ? 22 : 21, new Integer(m));
    rENode1.flags = 4;
    if (j > 1) {
      rENode1.kid2 = k;
    } else {
      rENode1.flags = (byte)(rENode1.flags | 0x2);
      rENode1.chr = arrayOfChar[m];
    } 
    paramCompilerState.index = k;
    return rENode1;
  }
  
  private int doOctal(CompilerState paramCompilerState) {
    char[] arrayOfChar = paramCompilerState.source;
    int i = paramCompilerState.index;
    char c = Character.MIN_VALUE;
    char c1;
    while (++i < arrayOfChar.length && (c1 = arrayOfChar[i]) >= '0' && 
      c1 <= '7') {
      char c2 = 8 * c + c1 - '0';
      if (c2 <= 'ÿ') {
        c = c2;
        continue;
      } 
      break;
    } 
    paramCompilerState.index = --i;
    return c;
  }
  
  static char getEscape(char paramChar) {
    switch (paramChar) {
      case 'b':
        return '\b';
      case 'f':
        return '\f';
      case 'n':
        return '\n';
      case 'r':
        return '\r';
      case 't':
        return '\t';
      case 'v':
        return '\013';
    } 
    throw new RuntimeException();
  }
  
  public static boolean isDigit(char paramChar) { return !(paramChar < '0' || paramChar > '9'); }
  
  static int unDigit(char paramChar) { return paramChar - '0'; }
  
  static boolean isHex(char paramChar) { return !((paramChar < '0' || paramChar > '9') && (paramChar < 'a' || paramChar > 'f') && (
      paramChar < 'A' || paramChar > 'F')); }
  
  static int unHex(char paramChar) {
    if (paramChar >= '0' && paramChar <= '9')
      return paramChar - '0'; 
    return '\n' + Character.toLowerCase(paramChar) - 'a';
  }
  
  static boolean isWord(char paramChar) { return !(!Character.isLetter(paramChar) && !isDigit(paramChar) && paramChar != '_'); }
  
  private String tail(char[] paramArrayOfChar, int paramInt) { return new String(paramArrayOfChar, paramInt, paramArrayOfChar.length - paramInt); }
  
  private static boolean matchChar(int paramInt, char paramChar1, char paramChar2) {
    if (paramChar1 == paramChar2)
      return true; 
    if ((paramInt & 0x2) != 0) {
      paramChar1 = Character.toUpperCase(paramChar1);
      paramChar2 = Character.toUpperCase(paramChar2);
      return !(paramChar1 != paramChar2 && 
        Character.toLowerCase(paramChar1) != Character.toLowerCase(paramChar2));
    } 
    return false;
  }
  
  int greedyRecurse(GreedyState paramGreedyState, int paramInt1, int paramInt2) {
    int k = paramGreedyState.state.parenCount;
    int i = matchRENodes(paramGreedyState.state, paramGreedyState.kid, paramGreedyState.next, paramInt1);
    if (i == -1) {
      paramGreedyState.state.parenCount = k;
      if (paramInt2 != -1)
        matchRENodes(paramGreedyState.state, paramGreedyState.kid, paramGreedyState.next, paramInt2); 
      return matchRENodes(paramGreedyState.state, paramGreedyState.next, paramGreedyState.stop, paramInt1);
    } 
    if (i == paramInt1)
      return i; 
    if (paramGreedyState.maxKid == 0 || ++paramGreedyState.kidCount < paramGreedyState.maxKid) {
      int m = greedyRecurse(paramGreedyState, i, paramInt1);
      if (m != -1)
        return m; 
      paramGreedyState.kidCount--;
      paramGreedyState.state.parenCount = k;
      matchRENodes(paramGreedyState.state, paramGreedyState.kid, paramGreedyState.next, paramInt1);
    } 
    int j = matchRENodes(paramGreedyState.state, paramGreedyState.next, paramGreedyState.stop, i);
    if (j != -1)
      return j; 
    paramGreedyState.state.parenCount = k;
    if (paramInt2 != -1)
      matchRENodes(paramGreedyState.state, paramGreedyState.kid, paramGreedyState.next, paramInt2); 
    return matchRENodes(paramGreedyState.state, paramGreedyState.next, paramGreedyState.stop, paramInt1);
  }
  
  int matchGreedyKid(MatchState paramMatchState, RENode paramRENode1, RENode paramRENode2, int paramInt1, int paramInt2, int paramInt3) {
    GreedyState greedyState = new GreedyState();
    greedyState.state = paramMatchState;
    greedyState.kid = (RENode)paramRENode1.kid;
    greedyState.next = paramRENode1.next;
    greedyState.stop = paramRENode2;
    greedyState.kidCount = paramInt1;
    greedyState.maxKid = (paramRENode1.op == 6) ? paramRENode1.max : 0;
    return greedyRecurse(greedyState, paramInt2, paramInt3);
  }
  
  int matchNonGreedyKid(MatchState paramMatchState, RENode paramRENode, int paramInt1, int paramInt2, int paramInt3) {
    int j = matchRENodes(paramMatchState, paramRENode.next, null, paramInt3);
    if (j != -1)
      return paramInt3; 
    int i = matchRENodes(paramMatchState, (RENode)paramRENode.kid, paramRENode.next, paramInt3);
    if (i == -1)
      return -1; 
    if (i == paramInt3)
      return i; 
    return matchNonGreedyKid(paramMatchState, paramRENode, paramInt1, paramInt2, i);
  }
  
  int matchRENodes(MatchState paramMatchState, RENode paramRENode1, RENode paramRENode2, int paramInt) {
    char[] arrayOfChar = paramMatchState.input;
    while (paramRENode1 != paramRENode2 && paramRENode1 != null) {
      int i3, i2, i1, n;
      RegExpImpl regExpImpl;
      int k;
      Context context;
      int m, j;
      char[] arrayOfChar1;
      SubString subString2, subString1;
      int i;
      switch (paramRENode1.op) {
        case 1:
          if (paramRENode1.next.op != 1) {
            paramRENode1 = (RENode)paramRENode1.kid;
            continue;
          } 
          i = paramMatchState.parenCount;
          m = matchRENodes(paramMatchState, (RENode)paramRENode1.kid, 
              paramRENode2, paramInt);
          if (m != -1)
            return m; 
          for (i1 = i; i1 < paramMatchState.parenCount; i1++)
            (paramMatchState.parens[i1]).length = 0; 
          paramMatchState.parenCount = i;
          break;
        case 6:
          m = -1;
          for (i = 0; i < paramRENode1.min; i++) {
            i1 = matchRENodes(paramMatchState, (RENode)paramRENode1.kid, 
                paramRENode1.next, paramInt);
            if (i1 == -1)
              return -1; 
            m = paramInt;
            paramInt = i1;
          } 
          if (i != paramRENode1.max) {
            if ((paramRENode1.flags & 0x80) == 0)
              return matchGreedyKid(paramMatchState, paramRENode1, paramRENode2, i, 
                  paramInt, m); 
            paramInt = matchNonGreedyKid(paramMatchState, paramRENode1, i, 
                paramRENode1.max, paramInt);
            if (paramInt == -1)
              return -1; 
          } 
          break;
        case 8:
          m = matchRENodes(paramMatchState, (RENode)paramRENode1.kid, 
              paramRENode1.next, paramInt);
          if (m == -1)
            return -1; 
          if ((paramRENode1.flags & 0x80) == 0)
            return matchGreedyKid(paramMatchState, paramRENode1, paramRENode2, 1, 
                m, paramInt); 
          paramInt = matchNonGreedyKid(paramMatchState, paramRENode1, 1, 0, m);
          if (paramInt == -1)
            return -1; 
          break;
        case 7:
          if ((paramRENode1.flags & 0x80) == 0)
            return matchGreedyKid(paramMatchState, paramRENode1, paramRENode2, 0, paramInt, -1); 
          paramInt = matchNonGreedyKid(paramMatchState, paramRENode1, 0, 0, paramInt);
          if (paramInt == -1)
            return -1; 
          break;
        case 9:
          m = paramMatchState.parenCount;
          if ((paramRENode1.flags & 0x80) != 0) {
            i1 = matchRENodes(paramMatchState, paramRENode1.next, 
                paramRENode2, paramInt);
            if (i1 != -1)
              return i1; 
          } 
          i1 = matchRENodes(paramMatchState, (RENode)paramRENode1.kid, 
              paramRENode1.next, paramInt);
          if (i1 == -1) {
            paramMatchState.parenCount = m;
            break;
          } 
          i2 = matchRENodes(paramMatchState, paramRENode1.next, 
              paramRENode2, i1);
          if (i2 == -1) {
            paramMatchState.parenCount = m;
            break;
          } 
          return i2;
        case 39:
          paramRENode1 = (RENode)paramRENode1.kid;
          continue;
        case 10:
          i = paramRENode1.num;
          paramRENode1 = (RENode)paramRENode1.kid;
          subString2 = paramMatchState.parens[i];
          if (subString2 == null) {
            subString2 = paramMatchState.parens[i] = new SubString();
            subString2.charArray = arrayOfChar;
          } 
          subString2.index = paramInt;
          subString2.length = 0;
          if (i >= paramMatchState.parenCount)
            paramMatchState.parenCount = i + 1; 
          continue;
        case 11:
          i = paramRENode1.num;
          subString2 = paramMatchState.parens[i];
          if (subString2 == null)
            throw new RuntimeException("Paren problem"); 
          subString2.length = paramInt - subString2.index;
          break;
        case 41:
          k = matchRENodes(paramMatchState, (RENode)paramRENode1.kid, 
              paramRENode1.next, paramInt);
          if (k == -1)
            return -1; 
          break;
        case 42:
          k = matchRENodes(paramMatchState, (RENode)paramRENode1.kid, 
              paramRENode1.next, paramInt);
          if (k != -1)
            return -1; 
          break;
        case 20:
          i = paramRENode1.num;
          if (i >= paramMatchState.parens.length) {
            Context.reportError(
                ScriptRuntime.getMessage(
                  "msg.bad.backref", null));
            return -1;
          } 
          subString1 = paramMatchState.parens[i];
          if (subString1 == null)
            subString1 = paramMatchState.parens[i] = new SubString(); 
          i1 = subString1.length;
          if (arrayOfChar.length - paramInt < i1)
            return -1; 
          for (i2 = 0; i2 < i1; i2++, paramInt++) {
            if (!matchChar(paramMatchState.flags, arrayOfChar[paramInt], 
                subString1.charArray[subString1.index + i2]))
              return -1; 
          } 
          break;
        case 13:
          if (paramInt < arrayOfChar.length) {
            if (paramRENode1.bitmap == null) {
              char[] arrayOfChar2 = (paramRENode1.s != null) ? 
                paramRENode1.s : 
                this.source.toCharArray();
              paramRENode1.buildBitmap(paramMatchState, arrayOfChar2, !((paramMatchState.flags & 0x2) == 0));
            } 
            char c = arrayOfChar[paramInt];
            i1 = c >>> '\003';
            if (i1 >= paramRENode1.bmsize) {
              if (paramRENode1.kid2 == -1) {
                paramInt++;
                break;
              } 
              return -1;
            } 
            i2 = c & 0x7;
            i2 = 1 << i2;
            if ((paramRENode1.bitmap[i1] & i2) != 0) {
              paramInt++;
              break;
            } 
            return -1;
          } 
          return -1;
        case 12:
          if (paramInt < arrayOfChar.length && arrayOfChar[paramInt] != '\n') {
            paramInt++;
            break;
          } 
          return -1;
        case 38:
          for (j = paramInt; j < arrayOfChar.length; j++) {
            i1 = matchRENodes(paramMatchState, paramRENode1.next, 
                paramRENode2, j);
            if (i1 != -1)
              return i1; 
            if (arrayOfChar[j] == '\n')
              return -1; 
          } 
          return -1;
        case 24:
          for (j = paramInt; j < arrayOfChar.length && 
            arrayOfChar[j] != '\n'; j++);
          while (j >= paramInt) {
            i1 = matchRENodes(paramMatchState, paramRENode1.next, 
                paramRENode2, j);
            if (i1 != -1)
              return i1; 
            j--;
          } 
          return -1;
        case 4:
          if (!(((paramInt != 0 && isWord(arrayOfChar[paramInt - 1])) ? 0 : 1) ^ ((paramInt < arrayOfChar.length && isWord(arrayOfChar[paramInt])) ? 0 : 1)))
            return -1; 
          break;
        case 5:
          if (!(((paramInt != 0 && isWord(arrayOfChar[paramInt - 1])) ? 0 : 1) ^ ((paramInt >= arrayOfChar.length || !isWord(arrayOfChar[paramInt])) ? 0 : 1)))
            return -1; 
          break;
        case 3:
        case 26:
          if (paramInt != arrayOfChar.length) {
            Context context1 = Context.getCurrentContext();
            RegExpImpl regExpImpl1 = getImpl(context1);
            if (regExpImpl1.multiline || (
              paramMatchState.flags & 0x4) != 0) {
              if (arrayOfChar[paramInt] != '\n')
                return -1; 
              break;
            } 
            return -1;
          } 
          break;
        case 2:
          context = Context.getCurrentContext();
          regExpImpl = getImpl(context);
          if (paramInt == 0 || (
            paramInt < arrayOfChar.length && (
            regExpImpl.multiline || (
            paramMatchState.flags & 0x4) != 0) && 
            arrayOfChar[paramInt - 1] == '\n'))
            break; 
          return -1;
        case 14:
          if (paramInt < arrayOfChar.length && isDigit(arrayOfChar[paramInt])) {
            paramInt++;
            break;
          } 
          return -1;
        case 15:
          if (paramInt < arrayOfChar.length && !isDigit(arrayOfChar[paramInt])) {
            paramInt++;
            break;
          } 
          return -1;
        case 16:
          if (paramInt < arrayOfChar.length && isWord(arrayOfChar[paramInt])) {
            paramInt++;
            break;
          } 
          return -1;
        case 17:
          if (paramInt < arrayOfChar.length && !isWord(arrayOfChar[paramInt])) {
            paramInt++;
            break;
          } 
          return -1;
        case 18:
          if (paramInt < arrayOfChar.length && (
            TokenStream.isJSSpace(arrayOfChar[paramInt]) || 
            TokenStream.isJSLineTerminator(arrayOfChar[paramInt]))) {
            paramInt++;
            break;
          } 
          return -1;
        case 19:
          if (paramInt < arrayOfChar.length && 
            !TokenStream.isJSSpace(arrayOfChar[paramInt]) && 
            !TokenStream.isJSLineTerminator(arrayOfChar[paramInt])) {
            paramInt++;
            break;
          } 
          return -1;
        case 22:
          if (paramInt < arrayOfChar.length && 
            matchChar(paramMatchState.flags, paramRENode1.chr, arrayOfChar[paramInt])) {
            paramInt++;
            break;
          } 
          return -1;
        case 21:
          arrayOfChar1 = (paramRENode1.s != null) ? 
            paramRENode1.s : 
            this.source.toCharArray();
          n = ((Integer)paramRENode1.kid).intValue();
          i2 = paramRENode1.kid2 - n;
          if (arrayOfChar.length - paramInt < i2)
            return -1; 
          for (i3 = 0; i3 < i2; i3++, paramInt++) {
            if (!matchChar(paramMatchState.flags, arrayOfChar[paramInt], 
                arrayOfChar1[n + i3]))
              return -1; 
          } 
          break;
        default:
          throw new RuntimeException("Unsupported by node matcher");
        case 0:
        case 23:
        case 40:
        case 43:
          break;
      } 
      paramRENode1 = paramRENode1.next;
    } 
    return paramInt;
  }
  
  int matchRegExp(MatchState paramMatchState, RENode paramRENode, int paramInt) {
    for (int i = paramInt; i <= paramMatchState.input.length; i++) {
      paramMatchState.skipped = i - paramInt;
      paramMatchState.parenCount = 0;
      int j = matchRENodes(paramMatchState, paramRENode, null, i);
      if (j != -1)
        return j; 
    } 
    return -1;
  }
  
  Object executeRegExp(Scriptable paramScriptable, String paramString, int[] paramArrayOfInt, boolean paramBoolean) {
    Scriptable scriptable2, scriptable1;
    NativeRegExp nativeRegExp = this;
    Context context = Context.getCurrentContext();
    RegExpImpl regExpImpl = getImpl(context);
    MatchState matchState = new MatchState();
    matchState.anchoring = false;
    matchState.flags = nativeRegExp.flags;
    matchState.scope = paramScriptable;
    char[] arrayOfChar = paramString.toCharArray();
    int i = paramArrayOfInt[0];
    if (i > arrayOfChar.length)
      i = arrayOfChar.length; 
    int j = i;
    matchState.cpbegin = 0;
    matchState.cpend = arrayOfChar.length;
    matchState.start = i;
    matchState.skipped = 0;
    matchState.input = arrayOfChar;
    matchState.parenCount = 0;
    matchState.maybeParens = new SubString[nativeRegExp.parenCount];
    matchState.parens = new SubString[nativeRegExp.parenCount];
    j = matchRegExp(matchState, this.ren, j);
    if (j == -1)
      return null; 
    int k = j - matchState.cpbegin;
    paramArrayOfInt[0] = k;
    int m = k - i + matchState.skipped;
    int n = j;
    j -= m;
    if (paramBoolean) {
      scriptable1 = Boolean.TRUE;
      scriptable2 = null;
    } else {
      Scriptable scriptable = ScriptableObject.getTopLevelScope(paramScriptable);
      scriptable1 = ScriptRuntime.newObject(context, scriptable, "Array", null);
      scriptable2 = (Scriptable)scriptable1;
      String str = new String(arrayOfChar, j, m);
      scriptable2.put(0, scriptable2, str);
    } 
    if (matchState.parenCount > nativeRegExp.parenCount)
      throw new RuntimeException(); 
    if (matchState.parenCount == 0) {
      regExpImpl.parens.setSize(0);
      regExpImpl.lastParen = SubString.emptySubString;
    } else {
      SubString subString = null;
      regExpImpl.parens.setSize(matchState.parenCount);
      for (byte b = 0; b < matchState.parenCount; b++) {
        subString = matchState.parens[b];
        regExpImpl.parens.setElementAt(subString, b);
        if (!paramBoolean) {
          String str = (subString == null) ? "" : subString.toString();
          scriptable2.put(b + 1, scriptable2, str);
        } 
      } 
      regExpImpl.lastParen = subString;
    } 
    if (!paramBoolean) {
      scriptable2.put("index", scriptable2, new Integer(i + matchState.skipped));
      scriptable2.put("input", scriptable2, paramString);
    } 
    if (regExpImpl.lastMatch == null) {
      regExpImpl.lastMatch = new SubString();
      regExpImpl.leftContext = new SubString();
      regExpImpl.rightContext = new SubString();
    } 
    regExpImpl.lastMatch.charArray = arrayOfChar;
    regExpImpl.lastMatch.index = j;
    regExpImpl.lastMatch.length = m;
    regExpImpl.leftContext.charArray = arrayOfChar;
    if (context.getLanguageVersion() == 120) {
      regExpImpl.leftContext.index = i;
      regExpImpl.leftContext.length = matchState.skipped;
    } else {
      regExpImpl.leftContext.index = 0;
      regExpImpl.leftContext.length = i + matchState.skipped;
    } 
    regExpImpl.rightContext.charArray = arrayOfChar;
    regExpImpl.rightContext.index = n;
    regExpImpl.rightContext.length = matchState.cpend - n;
    return scriptable1;
  }
  
  public byte getFlags() { return this.flags; }
  
  private void reportError(String paramString1, String paramString2, CompilerState paramCompilerState) {
    Object[] arrayOfObject = { paramString2 };
    throw NativeGlobal.constructError(
        paramCompilerState.cx, "SyntaxError", 
        ScriptRuntime.getMessage(paramString1, arrayOfObject), 
        paramCompilerState.scope);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\NativeRegExp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */