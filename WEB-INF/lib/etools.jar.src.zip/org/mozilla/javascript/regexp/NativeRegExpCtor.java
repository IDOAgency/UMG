/*     */ package org.mozilla.javascript.regexp;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.FunctionObject;
/*     */ import org.mozilla.javascript.NativeFunction;
/*     */ import org.mozilla.javascript.PropertyException;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeRegExpCtor
/*     */   extends NativeFunction
/*     */ {
/*     */   public static Scriptable init(Scriptable paramScriptable) throws PropertyException {
/*  58 */     NativeRegExpCtor nativeRegExpCtor = new NativeRegExpCtor();
/*     */     
/*  60 */     String[] arrayOfString1 = { "RegExp" };
/*  61 */     nativeRegExpCtor.names = arrayOfString1;
/*     */     
/*  63 */     nativeRegExpCtor.setPrototype(ScriptableObject.getClassPrototype(paramScriptable, "Function"));
/*  64 */     nativeRegExpCtor.setParentScope(paramScriptable);
/*     */     
/*  66 */     String[] arrayOfString2 = { "multiline", "input", "lastMatch", 
/*  67 */         "lastParen", "leftContext", "rightContext" };
/*     */     
/*  69 */     String[] arrayOfString3 = { "$*", "$_", "$&", 
/*  70 */         "$+", "$`", "$'" };
/*     */     
/*  72 */     for (byte b1 = 0; b1 < arrayOfString2.length; b1++)
/*  73 */       nativeRegExpCtor.defineProperty(arrayOfString2[b1], NativeRegExpCtor.class, 
/*  74 */           2); 
/*  75 */     for (byte b2 = 0; b2 < arrayOfString3.length; b2++) {
/*  76 */       StringBuffer stringBuffer = new StringBuffer("get");
/*  77 */       stringBuffer.append(arrayOfString2[b2]);
/*  78 */       stringBuffer.setCharAt(3, Character.toUpperCase(arrayOfString2[b2].charAt(0)));
/*  79 */       Method[] arrayOfMethod1 = FunctionObject.findMethods(
/*  80 */           NativeRegExpCtor.class, 
/*  81 */           stringBuffer.toString());
/*  82 */       stringBuffer.setCharAt(0, 's');
/*  83 */       Method[] arrayOfMethod2 = FunctionObject.findMethods(
/*  84 */           NativeRegExpCtor.class, 
/*  85 */           stringBuffer.toString());
/*  86 */       Method method = (arrayOfMethod2 == null) ? null : arrayOfMethod2[0];
/*  87 */       nativeRegExpCtor.defineProperty(arrayOfString3[b2], null, arrayOfMethod1[0], method, 
/*  88 */           2);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  93 */     ScriptableObject scriptableObject = (ScriptableObject)paramScriptable;
/*  94 */     scriptableObject.defineProperty("RegExp", nativeRegExpCtor, 2);
/*     */     
/*  96 */     return nativeRegExpCtor;
/*     */   }
/*     */ 
/*     */   
/* 100 */   public String getClassName() { return "Function"; }
/*     */ 
/*     */ 
/*     */   
/*     */   private int getDollarNumber(String paramString) {
/* 105 */     if (paramString.length() != 2)
/* 106 */       return 0; 
/* 107 */     char c = paramString.charAt(1);
/* 108 */     if (c < '0' || c > '9')
/* 109 */       return 0; 
/* 110 */     return c - '0';
/*     */   }
/*     */   
/*     */   public boolean has(String paramString, Scriptable paramScriptable) {
/* 114 */     if (paramString != null && paramString.length() > 1 && paramString.charAt(0) == '$' && 
/* 115 */       getDollarNumber(paramString) != 0) {
/* 116 */       return true;
/*     */     }
/* 118 */     return super.has(paramString, paramScriptable);
/*     */   }
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/* 122 */     if (paramString.length() > 1 && paramString.charAt(0) == '$') {
/* 123 */       int i = getDollarNumber(paramString);
/* 124 */       if (i != 0) {
/* 125 */         i--;
/* 126 */         RegExpImpl regExpImpl = getImpl();
/* 127 */         return regExpImpl.getParenSubString(i).toString();
/*     */       } 
/*     */     } 
/* 130 */     return super.get(paramString, paramScriptable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) { return construct(paramContext, this.parent, paramArrayOfObject); }
/*     */ 
/*     */   
/*     */   public Scriptable construct(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject) {
/* 140 */     NativeRegExp nativeRegExp = new NativeRegExp();
/* 141 */     NativeRegExp.compile(paramContext, nativeRegExp, paramArrayOfObject, this);
/* 142 */     nativeRegExp.setPrototype(ScriptableObject.getClassPrototype(paramScriptable, "RegExp"));
/* 143 */     nativeRegExp.setParentScope(getParentScope());
/* 144 */     return nativeRegExp;
/*     */   }
/*     */ 
/*     */   
/* 148 */   public static boolean getMultiline(ScriptableObject paramScriptableObject) { return (getImpl()).multiline; }
/*     */ 
/*     */ 
/*     */   
/* 152 */   public static void setMultiline(ScriptableObject paramScriptableObject, boolean paramBoolean) { (getImpl()).multiline = paramBoolean; }
/*     */ 
/*     */   
/*     */   public static String getInput(ScriptableObject paramScriptableObject) {
/* 156 */     String str = (getImpl()).input;
/* 157 */     return (str == null) ? "" : str;
/*     */   }
/*     */ 
/*     */   
/* 161 */   public static void setInput(ScriptableObject paramScriptableObject, String paramString) { (getImpl()).input = paramString; }
/*     */ 
/*     */   
/*     */   public static String getLastMatch(ScriptableObject paramScriptableObject) {
/* 165 */     SubString subString = (getImpl()).lastMatch;
/* 166 */     return (subString == null) ? "" : subString.toString();
/*     */   }
/*     */   
/*     */   public static String getLastParen(ScriptableObject paramScriptableObject) {
/* 170 */     SubString subString = (getImpl()).lastParen;
/* 171 */     return (subString == null) ? "" : subString.toString();
/*     */   }
/*     */   
/*     */   public static String getLeftContext(ScriptableObject paramScriptableObject) {
/* 175 */     SubString subString = (getImpl()).leftContext;
/* 176 */     return (subString == null) ? "" : subString.toString();
/*     */   }
/*     */   
/*     */   public static String getRightContext(ScriptableObject paramScriptableObject) {
/* 180 */     SubString subString = (getImpl()).rightContext;
/* 181 */     return (subString == null) ? "" : subString.toString();
/*     */   }
/*     */   
/*     */   static RegExpImpl getImpl() {
/* 185 */     Context context = Context.getCurrentContext();
/* 186 */     return (RegExpImpl)ScriptRuntime.getRegExpProxy(context);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\NativeRegExpCtor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */