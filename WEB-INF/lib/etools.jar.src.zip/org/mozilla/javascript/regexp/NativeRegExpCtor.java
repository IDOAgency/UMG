package org.mozilla.javascript.regexp;

import java.lang.reflect.Method;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.FunctionObject;
import org.mozilla.javascript.NativeFunction;
import org.mozilla.javascript.PropertyException;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

public class NativeRegExpCtor extends NativeFunction {
  public static Scriptable init(Scriptable paramScriptable) throws PropertyException {
    NativeRegExpCtor nativeRegExpCtor = new NativeRegExpCtor();
    String[] arrayOfString1 = { "RegExp" };
    nativeRegExpCtor.names = arrayOfString1;
    nativeRegExpCtor.setPrototype(ScriptableObject.getClassPrototype(paramScriptable, "Function"));
    nativeRegExpCtor.setParentScope(paramScriptable);
    String[] arrayOfString2 = { "multiline", "input", "lastMatch", 
        "lastParen", "leftContext", "rightContext" };
    String[] arrayOfString3 = { "$*", "$_", "$&", 
        "$+", "$`", "$'" };
    for (byte b1 = 0; b1 < arrayOfString2.length; b1++)
      nativeRegExpCtor.defineProperty(arrayOfString2[b1], NativeRegExpCtor.class, 
          2); 
    for (byte b2 = 0; b2 < arrayOfString3.length; b2++) {
      StringBuffer stringBuffer = new StringBuffer("get");
      stringBuffer.append(arrayOfString2[b2]);
      stringBuffer.setCharAt(3, Character.toUpperCase(arrayOfString2[b2].charAt(0)));
      Method[] arrayOfMethod1 = FunctionObject.findMethods(
          NativeRegExpCtor.class, 
          stringBuffer.toString());
      stringBuffer.setCharAt(0, 's');
      Method[] arrayOfMethod2 = FunctionObject.findMethods(
          NativeRegExpCtor.class, 
          stringBuffer.toString());
      Method method = (arrayOfMethod2 == null) ? null : arrayOfMethod2[0];
      nativeRegExpCtor.defineProperty(arrayOfString3[b2], null, arrayOfMethod1[0], method, 
          2);
    } 
    ScriptableObject scriptableObject = (ScriptableObject)paramScriptable;
    scriptableObject.defineProperty("RegExp", nativeRegExpCtor, 2);
    return nativeRegExpCtor;
  }
  
  public String getClassName() { return "Function"; }
  
  private int getDollarNumber(String paramString) {
    if (paramString.length() != 2)
      return 0; 
    char c = paramString.charAt(1);
    if (c < '0' || c > '9')
      return 0; 
    return c - '0';
  }
  
  public boolean has(String paramString, Scriptable paramScriptable) {
    if (paramString != null && paramString.length() > 1 && paramString.charAt(0) == '$' && 
      getDollarNumber(paramString) != 0)
      return true; 
    return super.has(paramString, paramScriptable);
  }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    if (paramString.length() > 1 && paramString.charAt(0) == '$') {
      int i = getDollarNumber(paramString);
      if (i != 0) {
        i--;
        RegExpImpl regExpImpl = getImpl();
        return regExpImpl.getParenSubString(i).toString();
      } 
    } 
    return super.get(paramString, paramScriptable);
  }
  
  public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) { return construct(paramContext, this.parent, paramArrayOfObject); }
  
  public Scriptable construct(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject) {
    NativeRegExp nativeRegExp = new NativeRegExp();
    NativeRegExp.compile(paramContext, nativeRegExp, paramArrayOfObject, this);
    nativeRegExp.setPrototype(ScriptableObject.getClassPrototype(paramScriptable, "RegExp"));
    nativeRegExp.setParentScope(getParentScope());
    return nativeRegExp;
  }
  
  public static boolean getMultiline(ScriptableObject paramScriptableObject) { return (getImpl()).multiline; }
  
  public static void setMultiline(ScriptableObject paramScriptableObject, boolean paramBoolean) { (getImpl()).multiline = paramBoolean; }
  
  public static String getInput(ScriptableObject paramScriptableObject) {
    String str = (getImpl()).input;
    return (str == null) ? "" : str;
  }
  
  public static void setInput(ScriptableObject paramScriptableObject, String paramString) { (getImpl()).input = paramString; }
  
  public static String getLastMatch(ScriptableObject paramScriptableObject) {
    SubString subString = (getImpl()).lastMatch;
    return (subString == null) ? "" : subString.toString();
  }
  
  public static String getLastParen(ScriptableObject paramScriptableObject) {
    SubString subString = (getImpl()).lastParen;
    return (subString == null) ? "" : subString.toString();
  }
  
  public static String getLeftContext(ScriptableObject paramScriptableObject) {
    SubString subString = (getImpl()).leftContext;
    return (subString == null) ? "" : subString.toString();
  }
  
  public static String getRightContext(ScriptableObject paramScriptableObject) {
    SubString subString = (getImpl()).rightContext;
    return (subString == null) ? "" : subString.toString();
  }
  
  static RegExpImpl getImpl() {
    Context context = Context.getCurrentContext();
    return (RegExpImpl)ScriptRuntime.getRegExpProxy(context);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\NativeRegExpCtor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */