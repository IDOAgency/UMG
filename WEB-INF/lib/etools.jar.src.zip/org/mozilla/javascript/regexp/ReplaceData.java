/*     */ package org.mozilla.javascript.regexp;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.Function;
/*     */ import org.mozilla.javascript.JavaScriptException;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReplaceData
/*     */   extends GlobData
/*     */ {
/*     */   int leftIndex;
/*     */   int index;
/*     */   int length;
/*     */   char[] charArray;
/* 349 */   int dollar = -1;
/*     */   
/*     */   char[] repstr;
/*     */   
/*     */   Function lambda;
/*     */ 
/*     */   
/*     */   void doGlobal(Function paramFunction, int paramInt) throws JavaScriptException {
/*     */     char[] arrayOfChar2;
/* 358 */     ReplaceData replaceData = this;
/*     */     
/* 360 */     Context context = Context.getCurrentContext();
/* 361 */     RegExpImpl regExpImpl = RegExpImpl.getRegExpImpl(context);
/* 362 */     SubString subString = regExpImpl.leftContext;
/*     */     
/* 364 */     char[] arrayOfChar1 = subString.charArray;
/* 365 */     int i = replaceData.leftIndex;
/*     */     
/* 367 */     int j = regExpImpl.lastMatch.index - i;
/* 368 */     replaceData.leftIndex = regExpImpl.lastMatch.index + regExpImpl.lastMatch.length;
/* 369 */     int k = findReplen(regExpImpl);
/* 370 */     int m = j + k;
/*     */     
/* 372 */     if (replaceData.charArray != null) {
/* 373 */       arrayOfChar2 = new char[replaceData.length + m];
/* 374 */       System.arraycopy(replaceData.charArray, 0, arrayOfChar2, 0, replaceData.length);
/*     */     } else {
/* 376 */       arrayOfChar2 = new char[m];
/*     */     } 
/*     */     
/* 379 */     replaceData.charArray = arrayOfChar2;
/* 380 */     replaceData.length += m;
/* 381 */     int n = replaceData.index;
/* 382 */     replaceData.index += m;
/* 383 */     System.arraycopy(arrayOfChar1, i, arrayOfChar2, n, j);
/* 384 */     n += j;
/* 385 */     doReplace(regExpImpl, arrayOfChar2, n);
/*     */   }
/*     */   
/* 388 */   static SubString dollarStr = new SubString("$");
/*     */ 
/*     */ 
/*     */   
/*     */   static SubString interpretDollar(RegExpImpl paramRegExpImpl, char[] paramArrayOfChar, int paramInt1, int paramInt2, int[] paramArrayOfInt) {
/* 393 */     Context context = Context.getCurrentContext();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 400 */     if (paramArrayOfChar[paramInt1] != '$')
/* 401 */       throw new RuntimeException(); 
/* 402 */     if (context.getLanguageVersion() != 0 && 
/* 403 */       context.getLanguageVersion() <= 140 && 
/* 404 */       paramInt1 > paramInt2 && paramArrayOfChar[paramInt1 - 1] == '\\') {
/* 405 */       return null;
/*     */     }
/*     */     
/* 408 */     char c = paramArrayOfChar[paramInt1 + 1];
/* 409 */     if (NativeRegExp.isDigit(c)) {
/* 410 */       int j, i; if (context.getLanguageVersion() != 0 && 
/* 411 */         context.getLanguageVersion() <= 140) {
/* 412 */         if (c == '0') {
/* 413 */           return null;
/*     */         }
/* 415 */         j = 0;
/* 416 */         char[] arrayOfChar = paramArrayOfChar;
/* 417 */         i = paramInt1;
/* 418 */         while (++i < arrayOfChar.length && NativeRegExp.isDigit(c = arrayOfChar[i])) {
/* 419 */           int k = 10 * j + NativeRegExp.unDigit(c);
/* 420 */           if (k >= j) {
/*     */             
/* 422 */             j = k; continue;
/*     */           }  break;
/*     */         } 
/*     */       } else {
/* 426 */         j = NativeRegExp.unDigit(c);
/* 427 */         i = paramInt1 + 2;
/* 428 */         if (paramInt1 + 2 < paramArrayOfChar.length) {
/* 429 */           c = paramArrayOfChar[paramInt1 + 2];
/* 430 */           if (NativeRegExp.isDigit(c)) {
/* 431 */             j = 10 * j + NativeRegExp.unDigit(c);
/* 432 */             i++;
/*     */           } 
/*     */         } 
/* 435 */         if (j == 0) return null;
/*     */       
/*     */       } 
/* 438 */       j--;
/* 439 */       paramArrayOfInt[0] = i - paramInt1;
/* 440 */       return paramRegExpImpl.getParenSubString(j);
/*     */     } 
/*     */     
/* 443 */     paramArrayOfInt[0] = 2;
/* 444 */     switch (c) {
/*     */       case '$':
/* 446 */         return dollarStr;
/*     */       case '&':
/* 448 */         return paramRegExpImpl.lastMatch;
/*     */       case '+':
/* 450 */         return paramRegExpImpl.lastParen;
/*     */       case '`':
/* 452 */         if (context.getLanguageVersion() == 120) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 460 */           paramRegExpImpl.leftContext.index = 0;
/* 461 */           paramRegExpImpl.leftContext.length = paramRegExpImpl.lastMatch.index;
/*     */         } 
/* 463 */         return paramRegExpImpl.leftContext;
/*     */       case '\'':
/* 465 */         return paramRegExpImpl.rightContext;
/*     */     } 
/* 467 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int findReplen(RegExpImpl paramRegExpImpl) throws JavaScriptException {
/* 478 */     if (this.lambda != null) {
/*     */ 
/*     */       
/* 481 */       Context context = Context.getCurrentContext();
/* 482 */       Vector vector = paramRegExpImpl.parens;
/* 483 */       int k = vector.size();
/* 484 */       Object[] arrayOfObject = new Object[k + 3];
/* 485 */       arrayOfObject[0] = paramRegExpImpl.lastMatch.toString();
/* 486 */       for (byte b1 = 0; b1 < k; b1++) {
/* 487 */         SubString subString = (SubString)vector.elementAt(b1);
/* 488 */         arrayOfObject[b1 + 1] = subString.toString();
/*     */       } 
/* 490 */       arrayOfObject[k + 1] = new Integer(paramRegExpImpl.leftContext.length);
/* 491 */       arrayOfObject[k + 2] = this.str;
/* 492 */       Scriptable scriptable = this.lambda.getParentScope();
/* 493 */       Object object = this.lambda.call(context, scriptable, scriptable, arrayOfObject);
/*     */       
/* 495 */       this.repstr = ScriptRuntime.toString(object).toCharArray();
/* 496 */       return this.repstr.length;
/*     */     } 
/*     */     
/* 499 */     int i = this.repstr.length;
/* 500 */     if (this.dollar == -1) {
/* 501 */       return i;
/*     */     }
/* 503 */     byte b = 0;
/* 504 */     for (int j = this.dollar; j < this.repstr.length; ) {
/* 505 */       char c = this.repstr[j];
/* 506 */       if (c != '$') {
/* 507 */         j++;
/*     */         continue;
/*     */       } 
/* 510 */       int[] arrayOfInt = new int[1];
/* 511 */       SubString subString = interpretDollar(paramRegExpImpl, this.repstr, j, 
/* 512 */           b, arrayOfInt);
/* 513 */       if (subString != null) {
/* 514 */         i += subString.length - arrayOfInt[0];
/* 515 */         j += arrayOfInt[0];
/*     */         continue;
/*     */       } 
/* 518 */       j++;
/*     */     } 
/* 520 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doReplace(RegExpImpl paramRegExpImpl, char[] paramArrayOfChar, int paramInt) {
/* 529 */     int i = 0;
/* 530 */     char[] arrayOfChar = this.repstr;
/* 531 */     int j = this.dollar;
/* 532 */     byte b = i;
/* 533 */     if (j != -1)
/*     */       while (true) {
/*     */         
/* 536 */         int k = j - i;
/* 537 */         System.arraycopy(this.repstr, i, paramArrayOfChar, paramInt, 
/* 538 */             k);
/* 539 */         paramInt += k;
/* 540 */         i = j;
/* 541 */         int[] arrayOfInt = new int[1];
/* 542 */         SubString subString = interpretDollar(paramRegExpImpl, arrayOfChar, 
/* 543 */             j, b, arrayOfInt);
/* 544 */         if (subString != null) {
/* 545 */           k = subString.length;
/* 546 */           if (k > 0) {
/* 547 */             System.arraycopy(subString.charArray, subString.index, paramArrayOfChar, 
/* 548 */                 paramInt, k);
/*     */           }
/* 550 */           paramInt += k;
/* 551 */           i += arrayOfInt[0];
/* 552 */           j += arrayOfInt[0];
/*     */         } else {
/*     */           
/* 555 */           j++;
/* 556 */         }  if (j >= this.repstr.length)
/* 557 */           break;  while (this.repstr[j] != '$') {
/* 558 */           j++;
/* 559 */           if (j >= this.repstr.length)
/*     */             // Byte code: goto -> 180 
/*     */         } 
/*     */       }  
/* 563 */     if (this.repstr.length > i)
/* 564 */       System.arraycopy(this.repstr, i, paramArrayOfChar, paramInt, 
/* 565 */           this.repstr.length - i); 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\ReplaceData.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */