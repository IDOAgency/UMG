package org.mozilla.javascript.regexp;

import java.util.Vector;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;

class ReplaceData extends GlobData {
  int leftIndex;
  
  int index;
  
  int length;
  
  char[] charArray;
  
  int dollar = -1;
  
  char[] repstr;
  
  Function lambda;
  
  void doGlobal(Function paramFunction, int paramInt) throws JavaScriptException {
    char[] arrayOfChar2;
    ReplaceData replaceData = this;
    Context context = Context.getCurrentContext();
    RegExpImpl regExpImpl = RegExpImpl.getRegExpImpl(context);
    SubString subString = regExpImpl.leftContext;
    char[] arrayOfChar1 = subString.charArray;
    int i = replaceData.leftIndex;
    int j = regExpImpl.lastMatch.index - i;
    replaceData.leftIndex = regExpImpl.lastMatch.index + regExpImpl.lastMatch.length;
    int k = findReplen(regExpImpl);
    int m = j + k;
    if (replaceData.charArray != null) {
      arrayOfChar2 = new char[replaceData.length + m];
      System.arraycopy(replaceData.charArray, 0, arrayOfChar2, 0, replaceData.length);
    } else {
      arrayOfChar2 = new char[m];
    } 
    replaceData.charArray = arrayOfChar2;
    replaceData.length += m;
    int n = replaceData.index;
    replaceData.index += m;
    System.arraycopy(arrayOfChar1, i, arrayOfChar2, n, j);
    n += j;
    doReplace(regExpImpl, arrayOfChar2, n);
  }
  
  static SubString dollarStr = new SubString("$");
  
  static SubString interpretDollar(RegExpImpl paramRegExpImpl, char[] paramArrayOfChar, int paramInt1, int paramInt2, int[] paramArrayOfInt) {
    Context context = Context.getCurrentContext();
    if (paramArrayOfChar[paramInt1] != '$')
      throw new RuntimeException(); 
    if (context.getLanguageVersion() != 0 && 
      context.getLanguageVersion() <= 140 && 
      paramInt1 > paramInt2 && paramArrayOfChar[paramInt1 - 1] == '\\')
      return null; 
    char c = paramArrayOfChar[paramInt1 + 1];
    if (NativeRegExp.isDigit(c)) {
      int j, i;
      if (context.getLanguageVersion() != 0 && 
        context.getLanguageVersion() <= 140) {
        if (c == '0')
          return null; 
        j = 0;
        char[] arrayOfChar = paramArrayOfChar;
        i = paramInt1;
        while (++i < arrayOfChar.length && NativeRegExp.isDigit(c = arrayOfChar[i])) {
          int k = 10 * j + NativeRegExp.unDigit(c);
          if (k >= j) {
            j = k;
            continue;
          } 
          break;
        } 
      } else {
        j = NativeRegExp.unDigit(c);
        i = paramInt1 + 2;
        if (paramInt1 + 2 < paramArrayOfChar.length) {
          c = paramArrayOfChar[paramInt1 + 2];
          if (NativeRegExp.isDigit(c)) {
            j = 10 * j + NativeRegExp.unDigit(c);
            i++;
          } 
        } 
        if (j == 0)
          return null; 
      } 
      j--;
      paramArrayOfInt[0] = i - paramInt1;
      return paramRegExpImpl.getParenSubString(j);
    } 
    paramArrayOfInt[0] = 2;
    switch (c) {
      case '$':
        return dollarStr;
      case '&':
        return paramRegExpImpl.lastMatch;
      case '+':
        return paramRegExpImpl.lastParen;
      case '`':
        if (context.getLanguageVersion() == 120) {
          paramRegExpImpl.leftContext.index = 0;
          paramRegExpImpl.leftContext.length = paramRegExpImpl.lastMatch.index;
        } 
        return paramRegExpImpl.leftContext;
      case '\'':
        return paramRegExpImpl.rightContext;
    } 
    return null;
  }
  
  int findReplen(RegExpImpl paramRegExpImpl) throws JavaScriptException {
    if (this.lambda != null) {
      Context context = Context.getCurrentContext();
      Vector vector = paramRegExpImpl.parens;
      int k = vector.size();
      Object[] arrayOfObject = new Object[k + 3];
      arrayOfObject[0] = paramRegExpImpl.lastMatch.toString();
      for (byte b1 = 0; b1 < k; b1++) {
        SubString subString = (SubString)vector.elementAt(b1);
        arrayOfObject[b1 + 1] = subString.toString();
      } 
      arrayOfObject[k + 1] = new Integer(paramRegExpImpl.leftContext.length);
      arrayOfObject[k + 2] = this.str;
      Scriptable scriptable = this.lambda.getParentScope();
      Object object = this.lambda.call(context, scriptable, scriptable, arrayOfObject);
      this.repstr = ScriptRuntime.toString(object).toCharArray();
      return this.repstr.length;
    } 
    int i = this.repstr.length;
    if (this.dollar == -1)
      return i; 
    byte b = 0;
    for (int j = this.dollar; j < this.repstr.length; ) {
      char c = this.repstr[j];
      if (c != '$') {
        j++;
        continue;
      } 
      int[] arrayOfInt = new int[1];
      SubString subString = interpretDollar(paramRegExpImpl, this.repstr, j, 
          b, arrayOfInt);
      if (subString != null) {
        i += subString.length - arrayOfInt[0];
        j += arrayOfInt[0];
        continue;
      } 
      j++;
    } 
    return i;
  }
  
  void doReplace(RegExpImpl paramRegExpImpl, char[] paramArrayOfChar, int paramInt) {
    int i = 0;
    char[] arrayOfChar = this.repstr;
    int j = this.dollar;
    byte b = i;
    if (j != -1)
      while (true) {
        int k = j - i;
        System.arraycopy(this.repstr, i, paramArrayOfChar, paramInt, 
            k);
        paramInt += k;
        i = j;
        int[] arrayOfInt = new int[1];
        SubString subString = interpretDollar(paramRegExpImpl, arrayOfChar, 
            j, b, arrayOfInt);
        if (subString != null) {
          k = subString.length;
          if (k > 0)
            System.arraycopy(subString.charArray, subString.index, paramArrayOfChar, 
                paramInt, k); 
          paramInt += k;
          i += arrayOfInt[0];
          j += arrayOfInt[0];
        } else {
          j++;
        } 
        if (j >= this.repstr.length)
          break; 
        while (this.repstr[j] != '$') {
          j++;
          if (j >= this.repstr.length)
            // Byte code: goto -> 180 
        } 
      }  
    if (this.repstr.length > i)
      System.arraycopy(this.repstr, i, paramArrayOfChar, paramInt, 
          this.repstr.length - i); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\ReplaceData.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */