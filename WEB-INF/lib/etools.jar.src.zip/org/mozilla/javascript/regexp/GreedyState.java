package org.mozilla.javascript.regexp;

class GreedyState {
  MatchState state;
  
  RENode kid;
  
  RENode next;
  
  RENode stop;
  
  int kidCount;
  
  int maxKid;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\regexp\GreedyState.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */