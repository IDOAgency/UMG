package org.mozilla.javascript;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.lang.reflect.InvocationTargetException;
import java.text.MessageFormat;
import java.util.Hashtable;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public final class Context {
  public static String languageVersionProperty = "language version";
  
  public static String errorReporterProperty = "error reporter";
  
  public static final int VERSION_UNKNOWN = -1;
  
  public static final int VERSION_DEFAULT = 0;
  
  public static final int VERSION_1_0 = 100;
  
  public static final int VERSION_1_1 = 110;
  
  public static final int VERSION_1_2 = 120;
  
  public static final int VERSION_1_3 = 130;
  
  public static final int VERSION_1_4 = 140;
  
  public static final int VERSION_1_5 = 150;
  
  static final String defaultResource = "org.mozilla.javascript.resources.Messages";
  
  static final boolean printTrees = false;
  
  private static Class codegenClass;
  
  private static ClassNameHelper nameHelper;
  
  private static boolean requireSecurityDomain;
  
  static final boolean useJSObject = false;
  
  NativeCall currentActivation;
  
  Hashtable iterating;
  
  Object interpreterSecurityDomain;
  
  Scriptable ctorScope;
  
  int version;
  
  int errorCount;
  
  static boolean isCachingEnabled;
  
  private SecuritySupport securitySupport;
  
  private ErrorReporter errorReporter;
  
  private Thread currentThread;
  
  private static Hashtable threadContexts;
  
  private RegExpProxy regExpProxy;
  
  private Locale locale;
  
  private boolean generatingDebug;
  
  private boolean generatingSource;
  
  private boolean compileFunctionsWithDynamicScopeFlag;
  
  private int optimizationLevel;
  
  private SourceTextManager debug_stm;
  
  private DeepScriptHook debug_scriptHook;
  
  private DeepCallHook debug_callHook;
  
  private DeepExecuteHook debug_executeHook;
  
  private DeepNewObjectHook debug_newObjectHook;
  
  private DeepBytecodeHook debug_bytecodeHook;
  
  private DeepErrorReporterHook debug_errorReporterHook;
  
  private static final byte debugLevel = 0;
  
  private int enterCount;
  
  private ListenerCollection listeners;
  
  private Hashtable hashtable;
  
  int interpreterLine;
  
  String interpreterSourceFile;
  
  public Context() {
    this.generatingSource = true;
    setLanguageVersion(0);
    this.generatingDebug = true;
    this.optimizationLevel = (codegenClass != null) ? 0 : -1;
  }
  
  public Context(SecuritySupport paramSecuritySupport) {
    this();
    this.securitySupport = paramSecuritySupport;
  }
  
  public static Context enter() { return enter(null); }
  
  public static Context enter(Context paramContext) {
    Thread thread = Thread.currentThread();
    Context context = (Context)threadContexts.get(thread);
    if (context != null) {
      synchronized (context) {
        context.enterCount++;
      } 
      return context;
    } 
    if (paramContext != null)
      synchronized (paramContext) {
        if (paramContext.currentThread == null) {
          paramContext.currentThread = thread;
          threadContexts.put(thread, paramContext);
          paramContext.enterCount++;
          return paramContext;
        } 
      }  
    context = new Context();
    context.currentThread = thread;
    threadContexts.put(thread, context);
    context.enterCount = 1;
    return context;
  }
  
  public static void exit() {
    Context context = getCurrentContext();
    if (context != null)
      synchronized (context) {
        if (--context.enterCount == 0) {
          threadContexts.remove(context.currentThread);
          context.currentThread = null;
        } 
      }  
  }
  
  public static Context getCurrentContext() {
    Thread thread = Thread.currentThread();
    return (Context)threadContexts.get(thread);
  }
  
  public int getLanguageVersion() { return this.version; }
  
  public void setLanguageVersion(int paramInt) {
    if (this.listeners != null && paramInt != this.version)
      firePropertyChange(languageVersionProperty, new Integer(this.version), new Integer(paramInt)); 
    this.version = paramInt;
  }
  
  public String getImplementationVersion() { return "JavaScript-Java 1.5 release 1 2000 03 15"; }
  
  public ErrorReporter getErrorReporter() {
    if (this.debug_errorReporterHook != null)
      return this.debug_errorReporterHook; 
    if (this.errorReporter == null)
      this.errorReporter = new DefaultErrorReporter(); 
    return this.errorReporter;
  }
  
  public ErrorReporter setErrorReporter(ErrorReporter paramErrorReporter) {
    if (this.debug_errorReporterHook != null)
      return this.debug_errorReporterHook.setErrorReporter(paramErrorReporter); 
    ErrorReporter errorReporter1 = this.errorReporter;
    if (this.listeners != null && this.errorReporter != paramErrorReporter)
      firePropertyChange(errorReporterProperty, this.errorReporter, paramErrorReporter); 
    this.errorReporter = paramErrorReporter;
    return errorReporter1;
  }
  
  public Locale getLocale() {
    if (this.locale == null)
      this.locale = Locale.getDefault(); 
    return this.locale;
  }
  
  public Locale setLocale(Locale paramLocale) {
    Locale locale1 = this.locale;
    this.locale = paramLocale;
    return locale1;
  }
  
  public void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener) {
    if (this.listeners == null)
      this.listeners = new ListenerCollection(); 
    this.listeners.addListener(paramPropertyChangeListener);
  }
  
  public void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener) { this.listeners.removeListener(paramPropertyChangeListener); }
  
  protected void firePropertyChange(String paramString, Object paramObject1, Object paramObject2) {
    Class clazz = PropertyChangeListener.class;
    Object[] arrayOfObject = this.listeners.getListeners(clazz);
    for (byte b = 0; b < arrayOfObject.length; b++) {
      PropertyChangeListener propertyChangeListener = (PropertyChangeListener)arrayOfObject[b];
      propertyChangeListener.propertyChange(new PropertyChangeEvent(this, paramString, paramObject1, paramObject2));
    } 
  }
  
  public static void reportWarning(String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2) {
    Context context = getContext();
    context.getErrorReporter().warning(paramString1, paramString2, paramInt1, paramString3, paramInt2);
  }
  
  public static void reportWarning(String paramString) {
    int[] arrayOfInt = new int[1];
    String str = getSourcePositionFromStack(arrayOfInt);
    reportWarning(paramString, str, arrayOfInt[0], null, 0);
  }
  
  public static void reportError(String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2) {
    Context context = getCurrentContext();
    if (context != null) {
      context.errorCount++;
      context.getErrorReporter().error(paramString1, paramString2, paramInt1, paramString3, paramInt2);
    } else {
      throw new EvaluatorException(paramString1);
    } 
  }
  
  public static void reportError(String paramString) {
    int[] arrayOfInt = new int[1];
    String str = getSourcePositionFromStack(arrayOfInt);
    reportError(paramString, str, arrayOfInt[0], null, 0);
  }
  
  public static EvaluatorException reportRuntimeError(String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2) {
    Context context = getCurrentContext();
    if (context != null) {
      context.errorCount++;
      return context.getErrorReporter().runtimeError(paramString1, paramString2, paramInt1, paramString3, paramInt2);
    } 
    throw new EvaluatorException(paramString1);
  }
  
  public static EvaluatorException reportRuntimeError(String paramString) {
    int[] arrayOfInt = new int[1];
    String str = getSourcePositionFromStack(arrayOfInt);
    return reportRuntimeError(paramString, str, arrayOfInt[0], null, 0);
  }
  
  public Scriptable initStandardObjects(ScriptableObject paramScriptableObject) { return initStandardObjects(paramScriptableObject, false); }
  
  public ScriptableObject initStandardObjects(ScriptableObject paramScriptableObject, boolean paramBoolean) {
    String str = "org.mozilla.javascript.";
    try {
      if (paramScriptableObject == null)
        paramScriptableObject = new NativeObject(); 
      ScriptableObject.defineClass(paramScriptableObject, NativeFunction.class, paramBoolean);
      ScriptableObject.defineClass(paramScriptableObject, NativeObject.class, paramBoolean);
      Scriptable scriptable1 = ScriptableObject.getObjectPrototype(paramScriptableObject);
      Scriptable scriptable2 = ScriptableObject.getFunctionPrototype(paramScriptableObject);
      scriptable2.setPrototype(scriptable1);
      if (paramScriptableObject.getPrototype() == null)
        paramScriptableObject.setPrototype(scriptable1); 
      ScriptableObject.defineClass(paramScriptableObject, NativeError.class, paramBoolean);
      ScriptableObject.defineClass(paramScriptableObject, NativeGlobal.class, paramBoolean);
      String[] arrayOfString = { 
          "NativeArray", "Array", "NativeString", "String", "NativeBoolean", "Boolean", "NativeNumber", "Number", "NativeDate", "Date", 
          "NativeMath", "Math", "NativeCall", "Call", "NativeWith", "With", "regexp.NativeRegExp", "RegExp", "NativeScript", "Script" };
      for (boolean bool = false; bool < arrayOfString.length; bool += true) {
        try {
          if (paramBoolean) {
            Class clazz = Class.forName("org.mozilla.javascript." + arrayOfString[bool]);
            ScriptableObject.defineClass(paramScriptableObject, clazz, paramBoolean);
          } else {
            String str2 = "org.mozilla.javascript." + arrayOfString[bool];
          } 
        } catch (ClassNotFoundException classNotFoundException) {}
      } 
      String str1 = "org.mozilla.javascript.JavaAdapter";
      try {
        str1 = System.getProperty(str1, str1);
      } catch (SecurityException securityException) {}
      try {
        Class clazz1 = Class.forName(str1);
        ScriptableObject.defineClass(paramScriptableObject, clazz1, paramBoolean);
        Class clazz2 = Class.forName("org.mozilla.javascript.NativeJavaPackage");
        ScriptableObject.defineClass(paramScriptableObject, clazz2, paramBoolean);
      } catch (ClassNotFoundException classNotFoundException) {
      
      } catch (SecurityException securityException) {}
    } catch (IllegalAccessException illegalAccessException) {
      throw WrappedException.wrapException(illegalAccessException);
    } catch (InstantiationException instantiationException) {
      throw WrappedException.wrapException(instantiationException);
    } catch (InvocationTargetException invocationTargetException) {
      throw WrappedException.wrapException(invocationTargetException);
    } catch (ClassDefinitionException classDefinitionException) {
      throw WrappedException.wrapException(classDefinitionException);
    } catch (PropertyException propertyException) {
      throw WrappedException.wrapException(propertyException);
    } 
    return paramScriptableObject;
  }
  
  public static Object getUndefinedValue() { return Undefined.instance; }
  
  public Object evaluateString(Scriptable paramScriptable, String paramString1, String paramString2, int paramInt, Object paramObject) throws JavaScriptException {
    try {
      StringReader stringReader = new StringReader(paramString1);
      return evaluateReader(paramScriptable, stringReader, paramString2, paramInt, paramObject);
    } catch (IOException iOException) {
      throw new RuntimeException();
    } 
  }
  
  public Object evaluateReader(Scriptable paramScriptable, Reader paramReader, String paramString, int paramInt, Object paramObject) throws IOException, JavaScriptException {
    Script script = compileReader(paramScriptable, paramReader, paramString, paramInt, paramObject);
    if (script != null)
      return script.exec(this, paramScriptable); 
    return null;
  }
  
  public boolean stringIsCompilableUnit(String paramString) {
    StringReader stringReader = new StringReader(paramString);
    TokenStream tokenStream = new TokenStream(stringReader, null, null, 1);
    DeepErrorReporterHook deepErrorReporterHook = setErrorReporterHook(null);
    ErrorReporter errorReporter1 = setErrorReporter(new DefaultErrorReporter());
    boolean bool = false;
    try {
      IRFactory iRFactory = new IRFactory(tokenStream, null);
      Parser parser = new Parser(iRFactory);
      parser.parse(tokenStream);
    } catch (IOException iOException) {
      bool = true;
    } catch (EvaluatorException evaluatorException) {
      bool = true;
    } finally {
      setErrorReporter(errorReporter1);
      setErrorReporterHook(deepErrorReporterHook);
    } 
    if (bool && tokenStream.eof())
      return false; 
    return true;
  }
  
  public Script compileReader(Scriptable paramScriptable, Reader paramReader, String paramString, int paramInt, Object paramObject) throws IOException {
    return (Script)compile(paramScriptable, paramReader, paramString, paramInt, paramObject, false);
  }
  
  public Function compileFunction(Scriptable paramScriptable, String paramString1, String paramString2, int paramInt, Object paramObject) {
    StringReader stringReader = new StringReader(paramString1);
    try {
      return (Function)compile(paramScriptable, stringReader, paramString2, paramInt, paramObject, true);
    } catch (IOException iOException) {
      throw new RuntimeException();
    } 
  }
  
  public String decompileScript(Script paramScript, Scriptable paramScriptable, int paramInt) {
    NativeScript nativeScript = (NativeScript)paramScript;
    nativeScript.initScript(paramScriptable);
    return nativeScript.decompile(paramInt, true, false);
  }
  
  public String decompileFunction(Function paramFunction, int paramInt) {
    if (paramFunction instanceof NativeFunction)
      return ((NativeFunction)paramFunction).decompile(paramInt, true, false); 
    return "function " + paramFunction.getClassName() + "() {\n\t[native code]\n}\n";
  }
  
  public String decompileFunctionBody(Function paramFunction, int paramInt) {
    if (paramFunction instanceof NativeFunction)
      return ((NativeFunction)paramFunction).decompile(paramInt, true, true); 
    return "[native code]\n";
  }
  
  public Scriptable newObject(Scriptable paramScriptable) throws PropertyException, NotAFunctionException, JavaScriptException { return newObject(paramScriptable, "Object", null); }
  
  public Scriptable newObject(Scriptable paramScriptable, String paramString) throws PropertyException, NotAFunctionException, JavaScriptException { return newObject(paramScriptable, paramString, null); }
  
  public Scriptable newObject(Scriptable paramScriptable, String paramString, Object[] paramArrayOfObject) throws PropertyException, NotAFunctionException, JavaScriptException {
    Object object = ScriptRuntime.getTopLevelProp(paramScriptable, paramString);
    if (object == Scriptable.NOT_FOUND) {
      Object[] arrayOfObject = { paramString };
      String str = getMessage("msg.ctor.not.found", arrayOfObject);
      throw new PropertyException(str);
    } 
    if (!(object instanceof Function)) {
      Object[] arrayOfObject = { paramString };
      String str = getMessage("msg.not.ctor", arrayOfObject);
      throw new NotAFunctionException(str);
    } 
    Function function = (Function)object;
    return function.construct(this, function.getParentScope(), (paramArrayOfObject == null) ? ScriptRuntime.emptyArgs : paramArrayOfObject);
  }
  
  public Scriptable newArray(Scriptable paramScriptable, int paramInt) {
    NativeArray nativeArray = new NativeArray(paramInt);
    newArrayHelper(paramScriptable, nativeArray);
    return nativeArray;
  }
  
  public Scriptable newArray(Scriptable paramScriptable, Object[] paramArrayOfObject) {
    NativeArray nativeArray = new NativeArray(paramArrayOfObject);
    newArrayHelper(paramScriptable, nativeArray);
    return nativeArray;
  }
  
  public Object[] getElements(Scriptable paramScriptable) {
    double d = NativeArray.getLengthProperty(paramScriptable);
    if (d != d)
      return null; 
    int i = (int)d;
    Object[] arrayOfObject = new Object[i];
    for (byte b = 0; b < i; b++) {
      Object object = paramScriptable.get(b, paramScriptable);
      arrayOfObject[b] = (object == Scriptable.NOT_FOUND) ? Undefined.instance : object;
    } 
    return arrayOfObject;
  }
  
  public static boolean toBoolean(Object paramObject) { return ScriptRuntime.toBoolean(paramObject); }
  
  public static double toNumber(Object paramObject) { return ScriptRuntime.toNumber(paramObject); }
  
  public static String toString(Object paramObject) { return ScriptRuntime.toString(paramObject); }
  
  public static Scriptable toObject(Object paramObject, Scriptable paramScriptable) { return ScriptRuntime.toObject(paramScriptable, paramObject, null); }
  
  public static Scriptable toObject(Object paramObject, Scriptable paramScriptable, Class paramClass) {
    if (paramObject == null && paramClass != null)
      return null; 
    return ScriptRuntime.toObject(paramScriptable, paramObject, paramClass);
  }
  
  public boolean isGeneratingDebug() { return this.generatingDebug; }
  
  public void setGeneratingDebug(boolean paramBoolean) {
    if (paramBoolean)
      setOptimizationLevel(0); 
    this.generatingDebug = paramBoolean;
  }
  
  public boolean isGeneratingSource() { return this.generatingSource; }
  
  public void setGeneratingSource(boolean paramBoolean) { this.generatingSource = paramBoolean; }
  
  public int getOptimizationLevel() { return this.optimizationLevel; }
  
  public void setOptimizationLevel(int paramInt) {
    if (paramInt < 0) {
      paramInt = -1;
    } else if (paramInt > 9) {
      paramInt = 9;
    } 
    if (codegenClass == null)
      paramInt = -1; 
    this.optimizationLevel = paramInt;
  }
  
  public String getTargetClassFileName() {
    return (nameHelper == null) ? null : nameHelper.getTargetClassFileName();
  }
  
  public void setTargetClassFileName(String paramString) {
    if (nameHelper != null)
      nameHelper.setTargetClassFileName(paramString); 
  }
  
  public String getTargetPackage() { return (nameHelper == null) ? null : nameHelper.getTargetPackage(); }
  
  public void setTargetPackage(String paramString) {
    if (nameHelper != null)
      nameHelper.setTargetPackage(paramString); 
  }
  
  public static boolean isSecurityDomainRequired() { return requireSecurityDomain; }
  
  public Object getInterpreterSecurityDomain() { return this.interpreterSecurityDomain; }
  
  public boolean isInterpreterClass(Class paramClass) { return !(paramClass != Interpreter.class); }
  
  public void setTargetExtends(Class paramClass) {
    if (nameHelper != null)
      nameHelper.setTargetExtends(paramClass); 
  }
  
  public void setTargetImplements(Class[] paramArrayOfClass) {
    if (nameHelper != null)
      nameHelper.setTargetImplements(paramArrayOfClass); 
  }
  
  public Object getThreadLocal(Object paramObject) {
    if (this.hashtable == null)
      return null; 
    return this.hashtable.get(paramObject);
  }
  
  public void putThreadLocal(Object paramObject1, Object paramObject2) {
    if (this.hashtable == null)
      this.hashtable = new Hashtable(); 
    this.hashtable.put(paramObject1, paramObject2);
  }
  
  public boolean hasCompileFunctionsWithDynamicScope() { return this.compileFunctionsWithDynamicScopeFlag; }
  
  public void setCompileFunctionsWithDynamicScope(boolean paramBoolean) { this.compileFunctionsWithDynamicScopeFlag = paramBoolean; }
  
  public static void setCachingEnabled(boolean paramBoolean) {
    if (isCachingEnabled && !paramBoolean) {
      FunctionObject.methodsCache = null;
      JavaMembers.classTable = new Hashtable();
    } 
    isCachingEnabled = paramBoolean;
  }
  
  public SourceTextManager getSourceTextManager() { return this.debug_stm; }
  
  public SourceTextManager setSourceTextManager(SourceTextManager paramSourceTextManager) {
    SourceTextManager sourceTextManager = this.debug_stm;
    this.debug_stm = paramSourceTextManager;
    return sourceTextManager;
  }
  
  public DeepScriptHook getScriptHook() { return this.debug_scriptHook; }
  
  public DeepScriptHook setScriptHook(DeepScriptHook paramDeepScriptHook) {
    DeepScriptHook deepScriptHook = this.debug_scriptHook;
    this.debug_scriptHook = paramDeepScriptHook;
    return deepScriptHook;
  }
  
  public DeepCallHook getCallHook() { return this.debug_callHook; }
  
  public DeepCallHook setCallHook(DeepCallHook paramDeepCallHook) {
    DeepCallHook deepCallHook = this.debug_callHook;
    this.debug_callHook = paramDeepCallHook;
    return deepCallHook;
  }
  
  public DeepExecuteHook getExecuteHook() { return this.debug_executeHook; }
  
  public DeepExecuteHook setExecuteHook(DeepExecuteHook paramDeepExecuteHook) {
    DeepExecuteHook deepExecuteHook = this.debug_executeHook;
    this.debug_executeHook = paramDeepExecuteHook;
    return deepExecuteHook;
  }
  
  public DeepNewObjectHook getNewObjectHook() { return this.debug_newObjectHook; }
  
  public DeepNewObjectHook setNewObjectHook(DeepNewObjectHook paramDeepNewObjectHook) {
    DeepNewObjectHook deepNewObjectHook = this.debug_newObjectHook;
    this.debug_newObjectHook = paramDeepNewObjectHook;
    return deepNewObjectHook;
  }
  
  public DeepBytecodeHook getBytecodeHook() { return this.debug_bytecodeHook; }
  
  public DeepBytecodeHook setBytecodeHook(DeepBytecodeHook paramDeepBytecodeHook) {
    DeepBytecodeHook deepBytecodeHook = this.debug_bytecodeHook;
    this.debug_bytecodeHook = paramDeepBytecodeHook;
    return deepBytecodeHook;
  }
  
  public DeepErrorReporterHook getErrorReporterHook() { return this.debug_errorReporterHook; }
  
  public DeepErrorReporterHook setErrorReporterHook(DeepErrorReporterHook paramDeepErrorReporterHook) {
    DeepErrorReporterHook deepErrorReporterHook = this.debug_errorReporterHook;
    this.debug_errorReporterHook = paramDeepErrorReporterHook;
    return deepErrorReporterHook;
  }
  
  public int getDebugLevel() { return 0; }
  
  public int setDebugLevel(int paramInt) {
    byte b = 0;
    if (paramInt < 0) {
      paramInt = 0;
    } else if (paramInt > 9) {
      paramInt = 9;
    } 
    if (paramInt > 0)
      setOptimizationLevel(0); 
    return b;
  }
  
  static Context getContext() {
    Thread thread = Thread.currentThread();
    Context context = (Context)threadContexts.get(thread);
    if (context == null)
      throw new RuntimeException("No Context associated with current Thread"); 
    return context;
  }
  
  static String getMessage(String paramString, Object[] paramArrayOfObject) {
    String str;
    Context context = getCurrentContext();
    Locale locale1 = (context != null) ? context.getLocale() : Locale.getDefault();
    ResourceBundle resourceBundle = ResourceBundle.getBundle("org.mozilla.javascript.resources.Messages", locale1);
    try {
      str = resourceBundle.getString(paramString);
    } catch (MissingResourceException missingResourceException) {
      throw new RuntimeException("no message resource found for message property " + paramString);
    } 
    MessageFormat messageFormat = new MessageFormat(str);
    return messageFormat.format(paramArrayOfObject);
  }
  
  private Object compile(Scriptable paramScriptable, Reader paramReader, String paramString, int paramInt, Object paramObject, boolean paramBoolean) throws IOException {
    TokenStream tokenStream = new TokenStream(paramReader, paramScriptable, paramString, paramInt);
    return compile(paramScriptable, tokenStream, paramObject, paramBoolean);
  }
  
  static  {
    try {
      codegenClass = Class.forName("org.mozilla.javascript.optimizer.Codegen");
      Class clazz = Class.forName("org.mozilla.javascript.optimizer.OptClassNameHelper");
      nameHelper = (ClassNameHelper)clazz.newInstance();
    } catch (ClassNotFoundException classNotFoundException) {
      codegenClass = null;
    } catch (IllegalAccessException illegalAccessException) {
      codegenClass = null;
    } catch (InstantiationException instantiationException) {
      codegenClass = null;
    } 
    requireSecurityDomain = true;
    String str = "org.mozilla.javascript.resources.Security";
    try {
      ResourceBundle resourceBundle = ResourceBundle.getBundle("org.mozilla.javascript.resources.Security");
      String str1 = resourceBundle.getString("security.requireSecurityDomain");
      requireSecurityDomain = str1.equals("true");
    } catch (MissingResourceException missingResourceException) {
      requireSecurityDomain = true;
    } catch (SecurityException securityException) {
      requireSecurityDomain = true;
    } 
    isCachingEnabled = true;
    threadContexts = new Hashtable(11);
  }
  
  private Interpreter getCompiler() {
    if (codegenClass == null)
      return new Interpreter(); 
    try {
      return (Interpreter)codegenClass.newInstance();
    } catch (SecurityException securityException) {
    
    } catch (IllegalArgumentException illegalArgumentException) {
    
    } catch (InstantiationException instantiationException) {
    
    } catch (IllegalAccessException illegalAccessException) {}
    throw new RuntimeException("Malformed optimizer package");
  }
  
  private Object compile(Scriptable paramScriptable, TokenStream paramTokenStream, Object paramObject, boolean paramBoolean) throws IOException {
    Interpreter interpreter = (this.optimizationLevel == -1) ? new Interpreter() : getCompiler();
    this.errorCount = 0;
    IRFactory iRFactory = interpreter.createIRFactory(paramTokenStream, nameHelper, paramScriptable);
    Parser parser = new Parser(iRFactory);
    Node node = (Node)parser.parse(paramTokenStream);
    if (node == null)
      return null; 
    node = interpreter.transform(node, paramTokenStream, paramScriptable);
    if (paramBoolean) {
      Node node1 = node.getFirstChild();
      if (node1 == null)
        return null; 
      node = (Node)node1.getProp(5);
      if (node == null)
        return null; 
    } 
    Object object = interpreter.compile(this, paramScriptable, node, paramObject, this.securitySupport, nameHelper);
    return (this.errorCount == 0) ? object : null;
  }
  
  static String getSourcePositionFromStack(int[] paramArrayOfInt) {
    CharArrayWriter charArrayWriter = new CharArrayWriter();
    RuntimeException runtimeException = new RuntimeException();
    runtimeException.printStackTrace(new PrintWriter(charArrayWriter));
    String str = charArrayWriter.toString();
    byte b1 = -1;
    byte b2 = -1;
    byte b3 = -1;
    for (byte b4 = 0; b4 < str.length(); b4++) {
      char c = str.charAt(b4);
      if (c == ':') {
        b3 = b4;
      } else if (c == '(') {
        b1 = b4;
      } else if (c == ')') {
        b2 = b4;
      } else if (c == '\n' && b1 != -1 && b2 != -1 && b3 != -1) {
        String str1 = str.substring(b1 + 1, b3);
        if (str1.endsWith(".js")) {
          String str2 = str.substring(b3 + 1, b2);
          try {
            paramArrayOfInt[0] = Integer.parseInt(str2);
            return str1;
          } catch (NumberFormatException numberFormatException) {}
        } 
        b1 = b2 = b3 = -1;
      } 
    } 
    Context context = getCurrentContext();
    if (context.interpreterLine > 0 && context.interpreterSourceFile != null) {
      paramArrayOfInt[0] = context.interpreterLine;
      return context.interpreterSourceFile;
    } 
    return null;
  }
  
  RegExpProxy getRegExpProxy() {
    if (this.regExpProxy == null)
      try {
        Class clazz = Class.forName("org.mozilla.javascript.regexp.RegExpImpl");
        this.regExpProxy = (RegExpProxy)clazz.newInstance();
        return this.regExpProxy;
      } catch (ClassNotFoundException classNotFoundException) {
      
      } catch (InstantiationException instantiationException) {
      
      } catch (IllegalAccessException illegalAccessException) {} 
    return this.regExpProxy;
  }
  
  private void newArrayHelper(Scriptable paramScriptable1, Scriptable paramScriptable2) {
    paramScriptable2.setParentScope(paramScriptable1);
    Object object = ScriptRuntime.getTopLevelProp(paramScriptable1, "Array");
    if (object != null && object instanceof Scriptable) {
      Scriptable scriptable = (Scriptable)object;
      paramScriptable2.setPrototype((Scriptable)scriptable.get("prototype", scriptable));
    } 
  }
  
  final boolean isVersionECMA1() { return !(this.version != 0 && this.version < 130); }
  
  Object getSecurityDomainFromClass(Class paramClass) {
    if (paramClass == Interpreter.class)
      return this.interpreterSecurityDomain; 
    return this.securitySupport.getSecurityDomain(paramClass);
  }
  
  SecuritySupport getSecuritySupport() { return this.securitySupport; }
  
  Object getSecurityDomainForStackDepth(int paramInt) {
    Object object = null;
    if (this.securitySupport != null) {
      Class[] arrayOfClass = this.securitySupport.getClassContext();
      if (paramInt != -1) {
        int i = paramInt + 1;
        object = getSecurityDomainFromClass(arrayOfClass[i]);
      } else {
        for (byte b = 1; b < arrayOfClass.length; b++) {
          object = getSecurityDomainFromClass(arrayOfClass[b]);
          if (object != null)
            break; 
        } 
      } 
    } 
    if (object != null)
      return object; 
    if (requireSecurityDomain)
      throw new SecurityException("Required security context not found"); 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Context.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */