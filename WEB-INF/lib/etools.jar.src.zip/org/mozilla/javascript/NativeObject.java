package org.mozilla.javascript;

import java.util.Hashtable;

public class NativeObject extends ScriptableObject {
  public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) {
    Object object = paramScriptable2.get("valueOf", paramScriptable2);
    ((FunctionObject)object).setLength((short)0);
  }
  
  public String getClassName() { return "Object"; }
  
  public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) throws JavaScriptException {
    if (!paramBoolean)
      return paramFunction.construct(paramContext, paramFunction.getParentScope(), paramArrayOfObject); 
    if (paramArrayOfObject.length == 0 || paramArrayOfObject[false] == null || 
      paramArrayOfObject[false] == Undefined.instance)
      return new NativeObject(); 
    return ScriptRuntime.toObject(paramFunction.getParentScope(), paramArrayOfObject[0]);
  }
  
  public String toString() {
    Context context = Context.getContext();
    if (context != null)
      return jsFunction_toString(context, this, null, null); 
    return "[object " + getClassName() + "]";
  }
  
  public static String jsFunction_toString(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    if (paramContext.getLanguageVersion() != 120)
      return "[object " + paramScriptable.getClassName() + "]"; 
    return toSource(paramContext, paramScriptable, paramArrayOfObject, paramFunction);
  }
  
  public static String toSource(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    Scriptable scriptable = paramScriptable;
    if (paramContext.iterating == null)
      paramContext.iterating = new Hashtable(31); 
    if (paramContext.iterating.get(scriptable) == Boolean.TRUE)
      return "{}"; 
    StringBuffer stringBuffer = new StringBuffer("{");
    Object[] arrayOfObject = scriptable.getIds();
    for (byte b = 0; b < arrayOfObject.length; b++) {
      if (b)
        stringBuffer.append(", "); 
      Object object1 = arrayOfObject[b];
      String str = ScriptRuntime.toString(object1);
      Object object2 = (object1 instanceof String) ? 
        scriptable.get((String)object1, scriptable) : 
        scriptable.get(((Number)object1).intValue(), scriptable);
      if (object2 instanceof String) {
        stringBuffer.append(String.valueOf(str) + ":\"" + 
            
            ScriptRuntime.escapeString(ScriptRuntime.toString(object2)) + 
            "\"");
      } else {
        try {
          paramContext.iterating.put(scriptable, Boolean.TRUE);
          stringBuffer.append(String.valueOf(str) + ":" + ScriptRuntime.toString(object2));
        } finally {
          paramContext.iterating.remove(scriptable);
        } 
      } 
    } 
    stringBuffer.append("}");
    return stringBuffer.toString();
  }
  
  public static Object jsFunction_valueOf(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return paramScriptable; }
  
  public static Object jsFunction_hasOwnProperty(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    if (paramArrayOfObject.length != 0 && 
      paramScriptable.has(ScriptRuntime.toString(paramArrayOfObject[0]), paramScriptable))
      return Boolean.TRUE; 
    return Boolean.FALSE;
  }
  
  public static Object jsFunction_propertyIsEnumerable(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    try {
      if (paramArrayOfObject.length != 0) {
        String str = ScriptRuntime.toString(paramArrayOfObject[0]);
        if (paramScriptable.has(str, paramScriptable)) {
          int i = ((ScriptableObject)paramScriptable).getAttributes(str, paramScriptable);
          if ((i & 0x2) == 0)
            return Boolean.TRUE; 
        } 
      } 
    } catch (PropertyException propertyException) {
    
    } catch (ClassCastException classCastException) {}
    return Boolean.FALSE;
  }
  
  public static Object jsFunction_isPrototypeOf(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    if (paramArrayOfObject.length != 0 && paramArrayOfObject[0] instanceof Scriptable) {
      Scriptable scriptable = (Scriptable)paramArrayOfObject[0];
      do {
        scriptable = scriptable.getPrototype();
        if (scriptable == paramScriptable)
          return Boolean.TRUE; 
      } while (scriptable != null);
    } 
    return Boolean.FALSE;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeObject.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */