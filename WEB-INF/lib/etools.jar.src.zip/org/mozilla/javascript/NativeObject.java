/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeObject
/*     */   extends ScriptableObject
/*     */ {
/*     */   public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) {
/*  51 */     Object object = paramScriptable2.get("valueOf", paramScriptable2);
/*  52 */     ((FunctionObject)object).setLength((short)0);
/*     */   }
/*     */ 
/*     */   
/*  56 */   public String getClassName() { return "Object"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) throws JavaScriptException {
/*  63 */     if (!paramBoolean)
/*     */     {
/*  65 */       return paramFunction.construct(paramContext, paramFunction.getParentScope(), paramArrayOfObject);
/*     */     }
/*  67 */     if (paramArrayOfObject.length == 0 || paramArrayOfObject[false] == null || 
/*  68 */       paramArrayOfObject[false] == Undefined.instance)
/*     */     {
/*  70 */       return new NativeObject();
/*     */     }
/*  72 */     return ScriptRuntime.toObject(paramFunction.getParentScope(), paramArrayOfObject[0]);
/*     */   }
/*     */   
/*     */   public String toString() {
/*  76 */     Context context = Context.getContext();
/*  77 */     if (context != null) {
/*  78 */       return jsFunction_toString(context, this, null, null);
/*     */     }
/*  80 */     return "[object " + getClassName() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String jsFunction_toString(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/*  86 */     if (paramContext.getLanguageVersion() != 120) {
/*  87 */       return "[object " + paramScriptable.getClassName() + "]";
/*     */     }
/*  89 */     return toSource(paramContext, paramScriptable, paramArrayOfObject, paramFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toSource(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/*  95 */     Scriptable scriptable = paramScriptable;
/*     */     
/*  97 */     if (paramContext.iterating == null) {
/*  98 */       paramContext.iterating = new Hashtable(31);
/*     */     }
/* 100 */     if (paramContext.iterating.get(scriptable) == Boolean.TRUE) {
/* 101 */       return "{}";
/*     */     }
/* 103 */     StringBuffer stringBuffer = new StringBuffer("{");
/* 104 */     Object[] arrayOfObject = scriptable.getIds();
/*     */     
/* 106 */     for (byte b = 0; b < arrayOfObject.length; b++) {
/* 107 */       if (b) {
/* 108 */         stringBuffer.append(", ");
/*     */       }
/* 110 */       Object object1 = arrayOfObject[b];
/* 111 */       String str = ScriptRuntime.toString(object1);
/* 112 */       Object object2 = (object1 instanceof String) ? 
/* 113 */         scriptable.get((String)object1, scriptable) : 
/* 114 */         scriptable.get(((Number)object1).intValue(), scriptable);
/* 115 */       if (object2 instanceof String) {
/* 116 */         stringBuffer.append(String.valueOf(str) + ":\"" + 
/*     */             
/* 118 */             ScriptRuntime.escapeString(ScriptRuntime.toString(object2)) + 
/* 119 */             "\"");
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/*     */ 
/*     */ 
/*     */           
/* 127 */           paramContext.iterating.put(scriptable, Boolean.TRUE);
/* 128 */           stringBuffer.append(String.valueOf(str) + ":" + ScriptRuntime.toString(object2));
/*     */         } finally {
/* 130 */           paramContext.iterating.remove(scriptable);
/*     */         } 
/*     */       } 
/*     */     } 
/* 134 */     stringBuffer.append("}");
/* 135 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public static Object jsFunction_valueOf(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return paramScriptable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsFunction_hasOwnProperty(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 150 */     if (paramArrayOfObject.length != 0 && 
/* 151 */       paramScriptable.has(ScriptRuntime.toString(paramArrayOfObject[0]), paramScriptable))
/* 152 */       return Boolean.TRUE; 
/* 153 */     return Boolean.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsFunction_propertyIsEnumerable(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/*     */     try {
/* 162 */       if (paramArrayOfObject.length != 0) {
/* 163 */         String str = ScriptRuntime.toString(paramArrayOfObject[0]);
/* 164 */         if (paramScriptable.has(str, paramScriptable)) {
/* 165 */           int i = ((ScriptableObject)paramScriptable).getAttributes(str, paramScriptable);
/* 166 */           if ((i & 0x2) == 0) {
/* 167 */             return Boolean.TRUE;
/*     */           }
/*     */         } 
/*     */       } 
/* 171 */     } catch (PropertyException propertyException) {
/*     */     
/* 173 */     } catch (ClassCastException classCastException) {}
/*     */     
/* 175 */     return Boolean.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsFunction_isPrototypeOf(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 181 */     if (paramArrayOfObject.length != 0 && paramArrayOfObject[0] instanceof Scriptable) {
/* 182 */       Scriptable scriptable = (Scriptable)paramArrayOfObject[0];
/*     */       do {
/* 184 */         scriptable = scriptable.getPrototype();
/* 185 */         if (scriptable == paramScriptable)
/* 186 */           return Boolean.TRUE; 
/* 187 */       } while (scriptable != null);
/*     */     } 
/* 189 */     return Boolean.FALSE;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeObject.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */