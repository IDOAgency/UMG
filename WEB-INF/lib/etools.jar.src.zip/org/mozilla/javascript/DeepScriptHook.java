package org.mozilla.javascript;

public interface DeepScriptHook {
  void loadingScript(Context paramContext, NativeFunction paramNativeFunction);
  
  void unloadingScript(Context paramContext, NativeFunction paramNativeFunction);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\DeepScriptHook.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */