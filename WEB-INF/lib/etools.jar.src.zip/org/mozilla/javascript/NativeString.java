package org.mozilla.javascript;

public class NativeString extends ScriptableObject implements Wrapper {
  private static final String defaultValue = "";
  
  private String string;
  
  public NativeString() { this.string = ""; }
  
  public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) {
    String[] arrayOfString = { "indexOf", 
        "lastIndexOf", 
        "substring", 
        "toUpperCase", 
        "toLowerCase", 
        "toString" };
    short[] arrayOfShort = { 2, 
        2, 
        2 };
    for (byte b = 0; b < arrayOfString.length; b++) {
      Object object = paramScriptable2.get(arrayOfString[b], paramScriptable2);
      ((FunctionObject)object).setLength(arrayOfShort[b]);
    } 
  }
  
  public NativeString(String paramString) { this.string = paramString; }
  
  public String getClassName() { return "String"; }
  
  public static String jsStaticFunction_fromCharCode(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    if (paramArrayOfObject.length < 1)
      return ""; 
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramArrayOfObject.length; b++)
      stringBuffer.append(ScriptRuntime.toUint16(paramArrayOfObject[b])); 
    return stringBuffer.toString();
  }
  
  public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
    String str = (paramArrayOfObject.length >= 1) ? 
      ScriptRuntime.toString(paramArrayOfObject[0]) : 
      "";
    if (paramBoolean)
      return new NativeString(str); 
    return str;
  }
  
  public String toString() { return this.string; }
  
  public String jsFunction_toString() { return this.string; }
  
  public String jsFunction_valueOf() { return this.string; }
  
  public Object get(int paramInt, Scriptable paramScriptable) {
    if (paramInt >= 0 && paramInt < this.string.length())
      return this.string.substring(paramInt, paramInt + 1); 
    return super.get(paramInt, paramScriptable);
  }
  
  public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
    if (paramInt >= 0 && paramInt < this.string.length())
      return; 
    super.put(paramInt, paramScriptable, paramObject);
  }
  
  public static String jsFunction_charAt(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    if (paramArrayOfObject.length < 1)
      paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1); 
    String str = ScriptRuntime.toString(paramScriptable);
    double d = ScriptRuntime.toInteger(paramArrayOfObject[0]);
    if (d < 0.0D || d >= str.length())
      return ""; 
    return str.substring((int)d, (int)d + 1);
  }
  
  public static double jsFunction_charCodeAt(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    if (paramArrayOfObject.length < 1)
      paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1); 
    String str = ScriptRuntime.toString(paramScriptable);
    double d = ScriptRuntime.toInteger(paramArrayOfObject[0]);
    if (d < 0.0D || d >= str.length())
      return ScriptRuntime.NaN; 
    return str.charAt((int)d);
  }
  
  public static int jsFunction_indexOf(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    if (paramArrayOfObject.length < 2)
      paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 2); 
    String str1 = ScriptRuntime.toString(paramScriptable);
    String str2 = ScriptRuntime.toString(paramArrayOfObject[0]);
    double d = ScriptRuntime.toInteger(paramArrayOfObject[1]);
    if (d > str1.length())
      return -1; 
    if (d < 0.0D)
      d = 0.0D; 
    return str1.indexOf(str2, (int)d);
  }
  
  public static int jsFunction_lastIndexOf(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    if (paramArrayOfObject.length < 2)
      paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 2); 
    String str1 = ScriptRuntime.toString(paramScriptable);
    String str2 = ScriptRuntime.toString(paramArrayOfObject[0]);
    double d = ScriptRuntime.toNumber(paramArrayOfObject[1]);
    if (d != d || d > str1.length()) {
      d = str1.length();
    } else if (d < 0.0D) {
      d = 0.0D;
    } 
    return str1.lastIndexOf(str2, (int)d);
  }
  
  private static int find_split(Function paramFunction, String paramString1, String paramString2, Object paramObject, int[] paramArrayOfInt1, int[] paramArrayOfInt2, boolean[] paramArrayOfBoolean, String[][] paramArrayOfString) {
    int i = paramArrayOfInt1[0];
    int j = paramString1.length();
    Context context = Context.getContext();
    int k = context.getLanguageVersion();
    if (k == 120 && 
      paramObject == null && paramString2.length() == 1 && paramString2.charAt(0) == ' ') {
      if (i == 0) {
        while (i < j && Character.isWhitespace(paramString1.charAt(i)))
          i++; 
        paramArrayOfInt1[0] = i;
      } 
      if (i == j)
        return -1; 
      while (i < j && 
        !Character.isWhitespace(paramString1.charAt(i)))
        i++; 
      int m = i;
      while (m < j && Character.isWhitespace(paramString1.charAt(m)))
        m++; 
      paramArrayOfInt2[0] = m - i;
      return i;
    } 
    if (i > j)
      return -1; 
    if (paramObject != null)
      return context.getRegExpProxy().find_split(paramFunction, paramString1, 
          paramString2, paramObject, 
          paramArrayOfInt1, paramArrayOfInt2, paramArrayOfBoolean, 
          paramArrayOfString); 
    if (k != 0 && k < 130 && 
      j == 0)
      return -1; 
    if (paramString2.length() == 0) {
      if (k == 120) {
        if (i == j) {
          paramArrayOfInt2[0] = 1;
          return i;
        } 
        return i + 1;
      } 
      return (i == j) ? -1 : (i + 1);
    } 
    if (paramArrayOfInt1[0] >= j)
      return j; 
    i = paramString1.indexOf(paramString2, paramArrayOfInt1[0]);
    return (i != -1) ? i : j;
  }
  
  public static Object jsFunction_split(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    String str1 = ScriptRuntime.toString(paramScriptable);
    Scriptable scriptable1 = ScriptableObject.getTopLevelScope(paramFunction);
    Scriptable scriptable2 = ScriptRuntime.newObject(paramContext, scriptable1, "Array", null);
    if (paramArrayOfObject.length < 1) {
      scriptable2.put(0, scriptable2, str1);
      return scriptable2;
    } 
    boolean bool = (paramArrayOfObject.length <= 1 || paramArrayOfObject[true] == Undefined.instance) ? 0 : 1;
    long l = 0L;
    if (bool) {
      l = ScriptRuntime.toUint32(paramArrayOfObject[1]);
      if (l > str1.length())
        l = (1 + str1.length()); 
    } 
    String str2 = null;
    int[] arrayOfInt1 = new int[1];
    Object object = null;
    RegExpProxy regExpProxy = paramContext.getRegExpProxy();
    if (regExpProxy != null && regExpProxy.isRegExp(paramArrayOfObject[0])) {
      object = paramArrayOfObject[0];
    } else {
      str2 = ScriptRuntime.toString(paramArrayOfObject[0]);
      arrayOfInt1[0] = str2.length();
    } 
    int[] arrayOfInt2 = new int[1];
    byte b = 0;
    boolean[] arrayOfBoolean = new boolean[1];
    String[][] arrayOfString = { null };
    while (true) {
      String str;
      int i;
      if ((i = find_split(paramFunction, str1, str2, object, arrayOfInt2, 
          arrayOfInt1, arrayOfBoolean, arrayOfString)) < 0)
        break; 
      if ((bool && b >= l) || i > str1.length())
        break; 
      if (str1.length() == 0) {
        str = str1;
      } else {
        str = str1.substring(arrayOfInt2[0], i);
      } 
      scriptable2.put(b, scriptable2, str);
      b++;
      if (object != null && arrayOfBoolean[0] == true) {
        int j = arrayOfString[0].length;
        for (byte b1 = 0; b1 < j && (
          !bool || b < l); b1++) {
          scriptable2.put(b, scriptable2, arrayOfString[0][b1]);
          b++;
        } 
        arrayOfBoolean[0] = false;
      } 
      arrayOfInt2[0] = i + arrayOfInt1[0];
      if (paramContext.getLanguageVersion() < 130 && 
        paramContext.getLanguageVersion() != 0)
        if (!bool && arrayOfInt2[0] == str1.length())
          break;  
    } 
    return scriptable2;
  }
  
  public static String jsFunction_substring(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    double d2;
    if (paramArrayOfObject.length < 1)
      paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1); 
    String str = ScriptRuntime.toString(paramScriptable);
    int i = str.length();
    double d1 = ScriptRuntime.toInteger(paramArrayOfObject[0]);
    if (d1 < 0.0D) {
      d1 = 0.0D;
    } else if (d1 > i) {
      d1 = i;
    } 
    if (paramArrayOfObject.length == 1) {
      d2 = i;
    } else {
      d2 = ScriptRuntime.toInteger(paramArrayOfObject[1]);
      if (d2 < 0.0D) {
        d2 = 0.0D;
      } else if (d2 > i) {
        d2 = i;
      } 
      if (d2 < d1)
        if (paramContext.getLanguageVersion() != 120) {
          double d = d1;
          d1 = d2;
          d2 = d;
        } else {
          d2 = d1;
        }  
    } 
    return str.substring((int)d1, (int)d2);
  }
  
  public static String jsFunction_toLowerCase(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    String str = ScriptRuntime.toString(paramScriptable);
    return str.toLowerCase();
  }
  
  public static String jsFunction_toUpperCase(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    String str = ScriptRuntime.toString(paramScriptable);
    return str.toUpperCase();
  }
  
  public double jsGet_length() { return this.string.length(); }
  
  public static String jsFunction_substr(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    double d2;
    String str = ScriptRuntime.toString(paramScriptable);
    if (paramArrayOfObject.length < 1)
      return str; 
    double d1 = ScriptRuntime.toInteger(paramArrayOfObject[0]);
    int i = str.length();
    if (d1 < 0.0D) {
      d1 += i;
      if (d1 < 0.0D)
        d1 = 0.0D; 
    } else if (d1 > i) {
      d1 = i;
    } 
    if (paramArrayOfObject.length == 1) {
      d2 = i;
    } else {
      d2 = ScriptRuntime.toInteger(paramArrayOfObject[1]);
      if (d2 < 0.0D)
        d2 = 0.0D; 
      d2 += d1;
      if (d2 > i)
        d2 = i; 
    } 
    return str.substring((int)d1, (int)d2);
  }
  
  public static String jsFunction_concat(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(ScriptRuntime.toString(paramScriptable));
    for (byte b = 0; b < paramArrayOfObject.length; b++)
      stringBuffer.append(ScriptRuntime.toString(paramArrayOfObject[b])); 
    return stringBuffer.toString();
  }
  
  public static String jsFunction_slice(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    String str = ScriptRuntime.toString(paramScriptable);
    if (paramArrayOfObject.length != 0) {
      double d2, d1 = ScriptRuntime.toInteger(paramArrayOfObject[0]);
      int i = str.length();
      if (d1 < 0.0D) {
        d1 += i;
        if (d1 < 0.0D)
          d1 = 0.0D; 
      } else if (d1 > i) {
        d1 = i;
      } 
      if (paramArrayOfObject.length == 1) {
        d2 = i;
      } else {
        d2 = ScriptRuntime.toInteger(paramArrayOfObject[1]);
        if (d2 < 0.0D) {
          d2 += i;
          if (d2 < 0.0D)
            d2 = 0.0D; 
        } else if (d2 > i) {
          d2 = i;
        } 
        if (d2 < d1)
          d2 = d1; 
      } 
      return str.substring((int)d1, (int)d2);
    } 
    return str;
  }
  
  private String tagify(String paramString1, String paramString2, String paramString3) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append('<');
    stringBuffer.append(paramString1);
    if (paramString3 != null) {
      stringBuffer.append('=');
      stringBuffer.append(paramString3);
    } 
    stringBuffer.append('>');
    stringBuffer.append(this.string);
    stringBuffer.append("</");
    stringBuffer.append((paramString2 == null) ? paramString1 : paramString2);
    stringBuffer.append('>');
    return stringBuffer.toString();
  }
  
  public String jsFunction_bold() { return tagify("B", null, null); }
  
  public String jsFunction_italics() { return tagify("I", null, null); }
  
  public String jsFunction_fixed() { return tagify("TT", null, null); }
  
  public String jsFunction_strike() { return tagify("STRIKE", null, null); }
  
  public String jsFunction_small() { return tagify("SMALL", null, null); }
  
  public String jsFunction_big() { return tagify("BIG", null, null); }
  
  public String jsFunction_blink() { return tagify("BLINK", null, null); }
  
  public String jsFunction_sup() { return tagify("SUP", null, null); }
  
  public String jsFunction_sub() { return tagify("SUB", null, null); }
  
  public String jsFunction_fontsize(String paramString) { return tagify("FONT SIZE", "FONT", paramString); }
  
  public String jsFunction_fontcolor(String paramString) { return tagify("FONT COLOR", "FONT", paramString); }
  
  public String jsFunction_link(String paramString) { return tagify("A HREF", "A", paramString); }
  
  public String jsFunction_anchor(String paramString) { return tagify("A NAME", "A", paramString); }
  
  public static Object jsFunction_equals(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    String str1 = ScriptRuntime.toString(paramScriptable);
    String str2 = ScriptRuntime.toString(paramArrayOfObject[0]);
    return new Boolean(str1.equals(str2));
  }
  
  public static Object jsFunction_equalsIgnoreCase(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    String str1 = ScriptRuntime.toString(paramScriptable);
    String str2 = ScriptRuntime.toString(paramArrayOfObject[0]);
    return new Boolean(str1.equalsIgnoreCase(str2));
  }
  
  public Object unwrap() { return this.string; }
  
  public static Object jsFunction_match(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return checkReProxy(paramContext).match(paramContext, paramScriptable, paramArrayOfObject, paramFunction); }
  
  public static Object jsFunction_search(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return checkReProxy(paramContext).search(paramContext, paramScriptable, paramArrayOfObject, paramFunction); }
  
  public static Object jsFunction_replace(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return checkReProxy(paramContext).replace(paramContext, paramScriptable, paramArrayOfObject, paramFunction); }
  
  private static RegExpProxy checkReProxy(Context paramContext) {
    RegExpProxy regExpProxy = paramContext.getRegExpProxy();
    if (regExpProxy == null)
      throw Context.reportRuntimeError(Context.getMessage("msg.no.regexp", null)); 
    return regExpProxy;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeString.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */