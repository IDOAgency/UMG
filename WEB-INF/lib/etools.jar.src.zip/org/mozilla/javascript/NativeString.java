/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeString
/*     */   extends ScriptableObject
/*     */   implements Wrapper
/*     */ {
/*     */   private static final String defaultValue = "";
/*     */   private String string;
/*     */   
/*  61 */   public NativeString() { this.string = ""; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) {
/*  75 */     String[] arrayOfString = { "indexOf", 
/*  76 */         "lastIndexOf", 
/*  77 */         "substring", 
/*  78 */         "toUpperCase", 
/*  79 */         "toLowerCase", 
/*  80 */         "toString" };
/*     */ 
/*     */     
/*  83 */     short[] arrayOfShort = { 2, 
/*  84 */         2, 
/*  85 */         2 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     for (byte b = 0; b < arrayOfString.length; b++) {
/*  92 */       Object object = paramScriptable2.get(arrayOfString[b], paramScriptable2);
/*  93 */       ((FunctionObject)object).setLength(arrayOfShort[b]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  98 */   public NativeString(String paramString) { this.string = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 102 */   public String getClassName() { return "String"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String jsStaticFunction_fromCharCode(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 110 */     if (paramArrayOfObject.length < 1)
/* 111 */       return ""; 
/* 112 */     StringBuffer stringBuffer = new StringBuffer();
/* 113 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 114 */       stringBuffer.append(ScriptRuntime.toUint16(paramArrayOfObject[b]));
/*     */     }
/* 116 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
/* 122 */     String str = (paramArrayOfObject.length >= 1) ? 
/* 123 */       ScriptRuntime.toString(paramArrayOfObject[0]) : 
/* 124 */       "";
/* 125 */     if (paramBoolean)
/*     */     {
/* 127 */       return new NativeString(str);
/*     */     }
/*     */     
/* 130 */     return str;
/*     */   }
/*     */ 
/*     */   
/* 134 */   public String toString() { return this.string; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   public String jsFunction_toString() { return this.string; }
/*     */ 
/*     */ 
/*     */   
/* 143 */   public String jsFunction_valueOf() { return this.string; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(int paramInt, Scriptable paramScriptable) {
/* 150 */     if (paramInt >= 0 && paramInt < this.string.length())
/* 151 */       return this.string.substring(paramInt, paramInt + 1); 
/* 152 */     return super.get(paramInt, paramScriptable);
/*     */   }
/*     */   
/*     */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
/* 156 */     if (paramInt >= 0 && paramInt < this.string.length())
/*     */       return; 
/* 158 */     super.put(paramInt, paramScriptable, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String jsFunction_charAt(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 168 */     if (paramArrayOfObject.length < 1) {
/* 169 */       paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1);
/*     */     }
/*     */ 
/*     */     
/* 173 */     String str = ScriptRuntime.toString(paramScriptable);
/* 174 */     double d = ScriptRuntime.toInteger(paramArrayOfObject[0]);
/*     */     
/* 176 */     if (d < 0.0D || d >= str.length()) {
/* 177 */       return "";
/*     */     }
/* 179 */     return str.substring((int)d, (int)d + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static double jsFunction_charCodeAt(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 185 */     if (paramArrayOfObject.length < 1) {
/* 186 */       paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1);
/*     */     }
/* 188 */     String str = ScriptRuntime.toString(paramScriptable);
/* 189 */     double d = ScriptRuntime.toInteger(paramArrayOfObject[0]);
/*     */     
/* 191 */     if (d < 0.0D || d >= str.length()) {
/* 192 */       return ScriptRuntime.NaN;
/*     */     }
/*     */     
/* 195 */     return str.charAt((int)d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int jsFunction_indexOf(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 206 */     if (paramArrayOfObject.length < 2) {
/* 207 */       paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 2);
/*     */     }
/* 209 */     String str1 = ScriptRuntime.toString(paramScriptable);
/* 210 */     String str2 = ScriptRuntime.toString(paramArrayOfObject[0]);
/* 211 */     double d = ScriptRuntime.toInteger(paramArrayOfObject[1]);
/*     */     
/* 213 */     if (d > str1.length()) {
/* 214 */       return -1;
/*     */     }
/* 216 */     if (d < 0.0D)
/* 217 */       d = 0.0D; 
/* 218 */     return str1.indexOf(str2, (int)d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int jsFunction_lastIndexOf(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 230 */     if (paramArrayOfObject.length < 2) {
/* 231 */       paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 2);
/*     */     }
/* 233 */     String str1 = ScriptRuntime.toString(paramScriptable);
/* 234 */     String str2 = ScriptRuntime.toString(paramArrayOfObject[0]);
/* 235 */     double d = ScriptRuntime.toNumber(paramArrayOfObject[1]);
/*     */     
/* 237 */     if (d != d || d > str1.length()) {
/* 238 */       d = str1.length();
/* 239 */     } else if (d < 0.0D) {
/* 240 */       d = 0.0D;
/*     */     } 
/* 242 */     return str1.lastIndexOf(str2, (int)d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int find_split(Function paramFunction, String paramString1, String paramString2, Object paramObject, int[] paramArrayOfInt1, int[] paramArrayOfInt2, boolean[] paramArrayOfBoolean, String[][] paramArrayOfString) {
/* 262 */     int i = paramArrayOfInt1[0];
/* 263 */     int j = paramString1.length();
/* 264 */     Context context = Context.getContext();
/* 265 */     int k = context.getLanguageVersion();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 272 */     if (k == 120 && 
/* 273 */       paramObject == null && paramString2.length() == 1 && paramString2.charAt(0) == ' ') {
/*     */ 
/*     */       
/* 276 */       if (i == 0) {
/* 277 */         while (i < j && Character.isWhitespace(paramString1.charAt(i)))
/* 278 */           i++; 
/* 279 */         paramArrayOfInt1[0] = i;
/*     */       } 
/*     */ 
/*     */       
/* 283 */       if (i == j) {
/* 284 */         return -1;
/*     */       }
/*     */       
/* 287 */       while (i < j && 
/* 288 */         !Character.isWhitespace(paramString1.charAt(i))) {
/* 289 */         i++;
/*     */       }
/*     */       
/* 292 */       int m = i;
/* 293 */       while (m < j && Character.isWhitespace(paramString1.charAt(m))) {
/* 294 */         m++;
/*     */       }
/*     */       
/* 297 */       paramArrayOfInt2[0] = m - i;
/* 298 */       return i;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 311 */     if (i > j) {
/* 312 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 319 */     if (paramObject != null) {
/* 320 */       return context.getRegExpProxy().find_split(paramFunction, paramString1, 
/* 321 */           paramString2, paramObject, 
/* 322 */           paramArrayOfInt1, paramArrayOfInt2, paramArrayOfBoolean, 
/* 323 */           paramArrayOfString);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 331 */     if (k != 0 && k < 130 && 
/* 332 */       j == 0) {
/* 333 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 345 */     if (paramString2.length() == 0) {
/* 346 */       if (k == 120) {
/* 347 */         if (i == j) {
/* 348 */           paramArrayOfInt2[0] = 1;
/* 349 */           return i;
/*     */         } 
/* 351 */         return i + 1;
/*     */       } 
/* 353 */       return (i == j) ? -1 : (i + 1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 359 */     if (paramArrayOfInt1[0] >= j) {
/* 360 */       return j;
/*     */     }
/* 362 */     i = paramString1.indexOf(paramString2, paramArrayOfInt1[0]);
/*     */     
/* 364 */     return (i != -1) ? i : j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsFunction_split(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 375 */     String str1 = ScriptRuntime.toString(paramScriptable);
/*     */ 
/*     */     
/* 378 */     Scriptable scriptable1 = ScriptableObject.getTopLevelScope(paramFunction);
/* 379 */     Scriptable scriptable2 = ScriptRuntime.newObject(paramContext, scriptable1, "Array", null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 384 */     if (paramArrayOfObject.length < 1) {
/* 385 */       scriptable2.put(0, scriptable2, str1);
/* 386 */       return scriptable2;
/*     */     } 
/*     */ 
/*     */     
/* 390 */     boolean bool = (paramArrayOfObject.length <= 1 || paramArrayOfObject[true] == Undefined.instance) ? 0 : 1;
/* 391 */     long l = 0L;
/* 392 */     if (bool) {
/*     */       
/* 394 */       l = ScriptRuntime.toUint32(paramArrayOfObject[1]);
/* 395 */       if (l > str1.length()) {
/* 396 */         l = (1 + str1.length());
/*     */       }
/*     */     } 
/* 399 */     String str2 = null;
/* 400 */     int[] arrayOfInt1 = new int[1];
/* 401 */     Object object = null;
/* 402 */     RegExpProxy regExpProxy = paramContext.getRegExpProxy();
/* 403 */     if (regExpProxy != null && regExpProxy.isRegExp(paramArrayOfObject[0])) {
/* 404 */       object = paramArrayOfObject[0];
/*     */     } else {
/* 406 */       str2 = ScriptRuntime.toString(paramArrayOfObject[0]);
/* 407 */       arrayOfInt1[0] = str2.length();
/*     */     } 
/*     */ 
/*     */     
/* 411 */     int[] arrayOfInt2 = new int[1];
/*     */     
/* 413 */     byte b = 0;
/* 414 */     boolean[] arrayOfBoolean = new boolean[1];
/* 415 */     String[][] arrayOfString = { null }; while (true) {
/* 416 */       String str; int i; if ((i = find_split(paramFunction, str1, str2, object, arrayOfInt2, 
/* 417 */           arrayOfInt1, arrayOfBoolean, arrayOfString)) < 0)
/*     */         break; 
/* 419 */       if ((bool && b >= l) || i > str1.length()) {
/*     */         break;
/*     */       }
/*     */       
/* 423 */       if (str1.length() == 0) {
/* 424 */         str = str1;
/*     */       } else {
/* 426 */         str = str1.substring(arrayOfInt2[0], i);
/*     */       } 
/* 428 */       scriptable2.put(b, scriptable2, str);
/* 429 */       b++;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 435 */       if (object != null && arrayOfBoolean[0] == true) {
/* 436 */         int j = arrayOfString[0].length;
/* 437 */         for (byte b1 = 0; b1 < j && (
/* 438 */           !bool || b < l); b1++) {
/*     */           
/* 440 */           scriptable2.put(b, scriptable2, arrayOfString[0][b1]);
/* 441 */           b++;
/*     */         } 
/* 443 */         arrayOfBoolean[0] = false;
/*     */       } 
/* 445 */       arrayOfInt2[0] = i + arrayOfInt1[0];
/*     */       
/* 447 */       if (paramContext.getLanguageVersion() < 130 && 
/* 448 */         paramContext.getLanguageVersion() != 0)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 454 */         if (!bool && arrayOfInt2[0] == str1.length())
/*     */           break; 
/*     */       }
/*     */     } 
/* 458 */     return scriptable2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String jsFunction_substring(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/*     */     double d2;
/* 468 */     if (paramArrayOfObject.length < 1) {
/* 469 */       paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1);
/*     */     }
/* 471 */     String str = ScriptRuntime.toString(paramScriptable);
/* 472 */     int i = str.length();
/* 473 */     double d1 = ScriptRuntime.toInteger(paramArrayOfObject[0]);
/*     */ 
/*     */     
/* 476 */     if (d1 < 0.0D) {
/* 477 */       d1 = 0.0D;
/* 478 */     } else if (d1 > i) {
/* 479 */       d1 = i;
/*     */     } 
/* 481 */     if (paramArrayOfObject.length == 1) {
/* 482 */       d2 = i;
/*     */     } else {
/* 484 */       d2 = ScriptRuntime.toInteger(paramArrayOfObject[1]);
/* 485 */       if (d2 < 0.0D) {
/* 486 */         d2 = 0.0D;
/* 487 */       } else if (d2 > i) {
/* 488 */         d2 = i;
/*     */       } 
/*     */       
/* 491 */       if (d2 < d1) {
/* 492 */         if (paramContext.getLanguageVersion() != 120) {
/* 493 */           double d = d1;
/* 494 */           d1 = d2;
/* 495 */           d2 = d;
/*     */         } else {
/*     */           
/* 498 */           d2 = d1;
/*     */         } 
/*     */       }
/*     */     } 
/* 502 */     return str.substring((int)d1, (int)d2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String jsFunction_toLowerCase(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 512 */     String str = ScriptRuntime.toString(paramScriptable);
/* 513 */     return str.toLowerCase();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String jsFunction_toUpperCase(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 519 */     String str = ScriptRuntime.toString(paramScriptable);
/* 520 */     return str.toUpperCase();
/*     */   }
/*     */ 
/*     */   
/* 524 */   public double jsGet_length() { return this.string.length(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String jsFunction_substr(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/*     */     double d2;
/* 533 */     String str = ScriptRuntime.toString(paramScriptable);
/*     */     
/* 535 */     if (paramArrayOfObject.length < 1) {
/* 536 */       return str;
/*     */     }
/* 538 */     double d1 = ScriptRuntime.toInteger(paramArrayOfObject[0]);
/*     */     
/* 540 */     int i = str.length();
/*     */     
/* 542 */     if (d1 < 0.0D) {
/* 543 */       d1 += i;
/* 544 */       if (d1 < 0.0D)
/* 545 */         d1 = 0.0D; 
/* 546 */     } else if (d1 > i) {
/* 547 */       d1 = i;
/*     */     } 
/*     */     
/* 550 */     if (paramArrayOfObject.length == 1) {
/* 551 */       d2 = i;
/*     */     } else {
/* 553 */       d2 = ScriptRuntime.toInteger(paramArrayOfObject[1]);
/* 554 */       if (d2 < 0.0D)
/* 555 */         d2 = 0.0D; 
/* 556 */       d2 += d1;
/* 557 */       if (d2 > i) {
/* 558 */         d2 = i;
/*     */       }
/*     */     } 
/* 561 */     return str.substring((int)d1, (int)d2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String jsFunction_concat(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 570 */     StringBuffer stringBuffer = new StringBuffer();
/* 571 */     stringBuffer.append(ScriptRuntime.toString(paramScriptable));
/*     */     
/* 573 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 574 */       stringBuffer.append(ScriptRuntime.toString(paramArrayOfObject[b]));
/*     */     }
/* 576 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String jsFunction_slice(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 582 */     String str = ScriptRuntime.toString(paramScriptable);
/*     */     
/* 584 */     if (paramArrayOfObject.length != 0) {
/* 585 */       double d2, d1 = ScriptRuntime.toInteger(paramArrayOfObject[0]);
/*     */       
/* 587 */       int i = str.length();
/* 588 */       if (d1 < 0.0D) {
/* 589 */         d1 += i;
/* 590 */         if (d1 < 0.0D)
/* 591 */           d1 = 0.0D; 
/* 592 */       } else if (d1 > i) {
/* 593 */         d1 = i;
/*     */       } 
/*     */       
/* 596 */       if (paramArrayOfObject.length == 1) {
/* 597 */         d2 = i;
/*     */       } else {
/* 599 */         d2 = ScriptRuntime.toInteger(paramArrayOfObject[1]);
/* 600 */         if (d2 < 0.0D) {
/* 601 */           d2 += i;
/* 602 */           if (d2 < 0.0D)
/* 603 */             d2 = 0.0D; 
/* 604 */         } else if (d2 > i) {
/* 605 */           d2 = i;
/*     */         } 
/* 607 */         if (d2 < d1)
/* 608 */           d2 = d1; 
/*     */       } 
/* 610 */       return str.substring((int)d1, (int)d2);
/*     */     } 
/* 612 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String tagify(String paramString1, String paramString2, String paramString3) {
/* 619 */     StringBuffer stringBuffer = new StringBuffer();
/* 620 */     stringBuffer.append('<');
/* 621 */     stringBuffer.append(paramString1);
/* 622 */     if (paramString3 != null) {
/* 623 */       stringBuffer.append('=');
/* 624 */       stringBuffer.append(paramString3);
/*     */     } 
/* 626 */     stringBuffer.append('>');
/* 627 */     stringBuffer.append(this.string);
/* 628 */     stringBuffer.append("</");
/* 629 */     stringBuffer.append((paramString2 == null) ? paramString1 : paramString2);
/* 630 */     stringBuffer.append('>');
/* 631 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/* 635 */   public String jsFunction_bold() { return tagify("B", null, null); }
/*     */ 
/*     */ 
/*     */   
/* 639 */   public String jsFunction_italics() { return tagify("I", null, null); }
/*     */ 
/*     */ 
/*     */   
/* 643 */   public String jsFunction_fixed() { return tagify("TT", null, null); }
/*     */ 
/*     */ 
/*     */   
/* 647 */   public String jsFunction_strike() { return tagify("STRIKE", null, null); }
/*     */ 
/*     */ 
/*     */   
/* 651 */   public String jsFunction_small() { return tagify("SMALL", null, null); }
/*     */ 
/*     */ 
/*     */   
/* 655 */   public String jsFunction_big() { return tagify("BIG", null, null); }
/*     */ 
/*     */ 
/*     */   
/* 659 */   public String jsFunction_blink() { return tagify("BLINK", null, null); }
/*     */ 
/*     */ 
/*     */   
/* 663 */   public String jsFunction_sup() { return tagify("SUP", null, null); }
/*     */ 
/*     */ 
/*     */   
/* 667 */   public String jsFunction_sub() { return tagify("SUB", null, null); }
/*     */ 
/*     */ 
/*     */   
/* 671 */   public String jsFunction_fontsize(String paramString) { return tagify("FONT SIZE", "FONT", paramString); }
/*     */ 
/*     */ 
/*     */   
/* 675 */   public String jsFunction_fontcolor(String paramString) { return tagify("FONT COLOR", "FONT", paramString); }
/*     */ 
/*     */ 
/*     */   
/* 679 */   public String jsFunction_link(String paramString) { return tagify("A HREF", "A", paramString); }
/*     */ 
/*     */ 
/*     */   
/* 683 */   public String jsFunction_anchor(String paramString) { return tagify("A NAME", "A", paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsFunction_equals(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 689 */     String str1 = ScriptRuntime.toString(paramScriptable);
/* 690 */     String str2 = ScriptRuntime.toString(paramArrayOfObject[0]);
/* 691 */     return new Boolean(str1.equals(str2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsFunction_equalsIgnoreCase(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 700 */     String str1 = ScriptRuntime.toString(paramScriptable);
/* 701 */     String str2 = ScriptRuntime.toString(paramArrayOfObject[0]);
/* 702 */     return new Boolean(str1.equalsIgnoreCase(str2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 711 */   public Object unwrap() { return this.string; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 718 */   public static Object jsFunction_match(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return checkReProxy(paramContext).match(paramContext, paramScriptable, paramArrayOfObject, paramFunction); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 725 */   public static Object jsFunction_search(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return checkReProxy(paramContext).search(paramContext, paramScriptable, paramArrayOfObject, paramFunction); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 732 */   public static Object jsFunction_replace(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return checkReProxy(paramContext).replace(paramContext, paramScriptable, paramArrayOfObject, paramFunction); }
/*     */ 
/*     */   
/*     */   private static RegExpProxy checkReProxy(Context paramContext) {
/* 736 */     RegExpProxy regExpProxy = paramContext.getRegExpProxy();
/* 737 */     if (regExpProxy == null) {
/* 738 */       throw Context.reportRuntimeError(Context.getMessage("msg.no.regexp", null));
/*     */     }
/* 740 */     return regExpProxy;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeString.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */