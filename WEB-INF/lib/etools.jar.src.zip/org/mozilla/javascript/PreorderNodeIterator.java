package org.mozilla.javascript;

import java.util.Stack;

public class PreorderNodeIterator {
  private Node start;
  
  private Node current;
  
  private Node currentParent;
  
  private Stack stack;
  
  public PreorderNodeIterator(Node paramNode) {
    this.start = paramNode;
    this.stack = new Stack();
  }
  
  public Node currentNode() { return this.current; }
  
  public Node getCurrentParent() { return this.currentParent; }
  
  public Node nextNode() {
    if (this.current == null)
      return this.current = this.start; 
    if (this.current.first != null) {
      this.stack.push(this.current);
      this.currentParent = this.current;
      this.current = this.current.first;
    } else {
      boolean bool;
      this.current = this.current.next;
      while (true) {
        bool = this.stack.isEmpty();
        if (bool || this.current != null)
          break; 
        this.current = (Node)this.stack.pop();
        this.current = this.current.next;
      } 
      this.currentParent = bool ? null : (Node)this.stack.peek();
    } 
    return this.current;
  }
  
  public void replaceCurrent(Node paramNode) {
    this.currentParent.replaceChild(this.current, paramNode);
    this.current = paramNode;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\PreorderNodeIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */