/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.util.Stack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreorderNodeIterator
/*    */ {
/*    */   private Node start;
/*    */   private Node current;
/*    */   private Node currentParent;
/*    */   private Stack stack;
/*    */   
/*    */   public PreorderNodeIterator(Node paramNode) {
/* 49 */     this.start = paramNode;
/* 50 */     this.stack = new Stack();
/*    */   }
/*    */ 
/*    */   
/* 54 */   public Node currentNode() { return this.current; }
/*    */ 
/*    */ 
/*    */   
/* 58 */   public Node getCurrentParent() { return this.currentParent; }
/*    */ 
/*    */   
/*    */   public Node nextNode() {
/* 62 */     if (this.current == null)
/* 63 */       return this.current = this.start; 
/* 64 */     if (this.current.first != null) {
/* 65 */       this.stack.push(this.current);
/* 66 */       this.currentParent = this.current;
/* 67 */       this.current = this.current.first;
/*    */     } else {
/* 69 */       boolean bool; this.current = this.current.next;
/*    */       
/*    */       while (true) {
/* 72 */         bool = this.stack.isEmpty();
/* 73 */         if (bool || this.current != null)
/*    */           break; 
/* 75 */         this.current = (Node)this.stack.pop();
/* 76 */         this.current = this.current.next;
/*    */       } 
/* 78 */       this.currentParent = bool ? null : (Node)this.stack.peek();
/*    */     } 
/* 80 */     return this.current;
/*    */   }
/*    */   
/*    */   public void replaceCurrent(Node paramNode) {
/* 84 */     this.currentParent.replaceChild(this.current, paramNode);
/* 85 */     this.current = paramNode;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\PreorderNodeIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */