/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ScriptableObject
/*      */   implements Scriptable
/*      */ {
/*      */   public static final int EMPTY = 0;
/*      */   public static final int READONLY = 1;
/*      */   public static final int DONTENUM = 2;
/*      */   public static final int PERMANENT = 4;
/*      */   private static final int SLOT_NOT_FOUND = -1;
/*      */   protected Scriptable prototype;
/*      */   protected Scriptable parent;
/*      */   
/*  116 */   public boolean has(String paramString, Scriptable paramScriptable) { return !(getSlot(paramString, paramString.hashCode()) == -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  127 */   public boolean has(int paramInt, Scriptable paramScriptable) { return !(getSlot(null, paramInt) == -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object get(String paramString, Scriptable paramScriptable) {
/*      */     int i;
/*  142 */     if (paramString == this.lastName) {
/*  143 */       if (this.lastValue != REMOVED)
/*  144 */         return this.lastValue; 
/*  145 */       i = this.lastHash;
/*      */     } else {
/*  147 */       i = paramString.hashCode();
/*      */     } 
/*  149 */     int j = getSlot(paramString, i);
/*  150 */     if (j == -1)
/*  151 */       return Scriptable.NOT_FOUND; 
/*  152 */     Slot slot = this.slots[j];
/*  153 */     if ((slot.flags & true) != 0) {
/*  154 */       GetterSlot getterSlot = (GetterSlot)slot;
/*      */       try {
/*  156 */         if (getterSlot.delegateTo == null) {
/*      */ 
/*      */           
/*  159 */           Class clazz = getterSlot.getter.getDeclaringClass();
/*  160 */           while (!clazz.isInstance(paramScriptable)) {
/*  161 */             paramScriptable = paramScriptable.getPrototype();
/*  162 */             if (paramScriptable == null) {
/*  163 */               paramScriptable = this;
/*      */               break;
/*      */             } 
/*      */           } 
/*  167 */           return getterSlot.getter.invoke(paramScriptable, ScriptRuntime.emptyArgs);
/*      */         } 
/*  169 */         Object[] arrayOfObject = { this };
/*  170 */         return getterSlot.getter.invoke(getterSlot.delegateTo, arrayOfObject);
/*      */       }
/*  172 */       catch (InvocationTargetException invocationTargetException) {
/*  173 */         throw WrappedException.wrapException(invocationTargetException);
/*      */       }
/*  175 */       catch (IllegalAccessException illegalAccessException) {
/*  176 */         throw WrappedException.wrapException(illegalAccessException);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  181 */     this.lastValue = REMOVED;
/*  182 */     this.lastName = paramString;
/*  183 */     this.lastHash = i;
/*  184 */     this.lastValue = slot.value;
/*  185 */     return this.lastValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object get(int paramInt, Scriptable paramScriptable) {
/*  196 */     int i = getSlot(null, paramInt);
/*  197 */     if (i == -1)
/*  198 */       return Scriptable.NOT_FOUND; 
/*  199 */     return (this.slots[i]).value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
/*  218 */     int i = paramString.hashCode();
/*  219 */     int j = getSlot(paramString, i);
/*  220 */     if (j == -1) {
/*  221 */       if (paramScriptable != this) {
/*  222 */         paramScriptable.put(paramString, paramScriptable, paramObject);
/*      */         return;
/*      */       } 
/*  225 */       j = getSlotToSet(paramString, i, false);
/*      */     } 
/*  227 */     Slot slot = this.slots[j];
/*  228 */     if ((slot.attributes & true) != 0)
/*      */       return; 
/*  230 */     if ((slot.flags & 0x2) != 0) {
/*  231 */       GetterSlot getterSlot = (GetterSlot)slot;
/*      */       try {
/*  233 */         Class[] arrayOfClass = getterSlot.setter.getParameterTypes();
/*  234 */         Class clazz = arrayOfClass[arrayOfClass.length - 1];
/*  235 */         Object object = 
/*  236 */           FunctionObject.convertArg(paramScriptable, paramObject, clazz);
/*  237 */         if (getterSlot.delegateTo == null) {
/*      */ 
/*      */           
/*  240 */           Object[] arrayOfObject1 = { object };
/*  241 */           Class clazz1 = getterSlot.setter.getDeclaringClass();
/*  242 */           while (!clazz1.isInstance(paramScriptable)) {
/*  243 */             paramScriptable = paramScriptable.getPrototype();
/*  244 */             if (paramScriptable == null) {
/*  245 */               paramScriptable = this;
/*      */               break;
/*      */             } 
/*      */           } 
/*  249 */           getterSlot.setter.invoke(paramScriptable, arrayOfObject1);
/*      */           return;
/*      */         } 
/*  252 */         Object[] arrayOfObject = { this, object };
/*  253 */         getterSlot.setter.invoke(getterSlot.delegateTo, arrayOfObject);
/*      */         
/*      */         return;
/*  256 */       } catch (InvocationTargetException invocationTargetException) {
/*  257 */         throw WrappedException.wrapException(invocationTargetException);
/*      */       }
/*  259 */       catch (IllegalAccessException illegalAccessException) {
/*  260 */         throw WrappedException.wrapException(illegalAccessException);
/*      */       } 
/*      */     } 
/*  263 */     if (this == paramScriptable) {
/*  264 */       slot.value = paramObject;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  269 */       this.lastValue = (paramString == this.lastName) ? paramObject : REMOVED;
/*      */     } else {
/*  271 */       paramScriptable.put(paramString, paramScriptable, paramObject);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
/*  283 */     int i = getSlot(null, paramInt);
/*  284 */     if (i == -1) {
/*  285 */       if (paramScriptable != this) {
/*  286 */         paramScriptable.put(paramInt, paramScriptable, paramObject);
/*      */         return;
/*      */       } 
/*  289 */       i = getSlotToSet(null, paramInt, false);
/*      */     } 
/*  291 */     Slot slot = this.slots[i];
/*  292 */     if ((slot.attributes & true) != 0)
/*      */       return; 
/*  294 */     if (this == paramScriptable) {
/*  295 */       slot.value = paramObject;
/*      */     } else {
/*  297 */       paramScriptable.put(paramInt, paramScriptable, paramObject);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void delete(String paramString) {
/*  310 */     if (paramString.equals(this.lastName))
/*  311 */       this.lastValue = REMOVED; 
/*  312 */     removeSlot(paramString, paramString.hashCode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  324 */   public void delete(int paramInt) { removeSlot(null, paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAttributes(String paramString, Scriptable paramScriptable) throws PropertyException {
/*  347 */     int i = getSlot(paramString, paramString.hashCode());
/*  348 */     if (i == -1) {
/*  349 */       throw new PropertyException(
/*  350 */           Context.getMessage("msg.prop.not.found", null));
/*      */     }
/*  352 */     return (this.slots[i]).attributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAttributes(int paramInt, Scriptable paramScriptable) throws PropertyException {
/*  372 */     int i = getSlot(null, paramInt);
/*  373 */     if (i == -1) {
/*  374 */       throw new PropertyException(
/*  375 */           Context.getMessage("msg.prop.not.found", null));
/*      */     }
/*  377 */     return (this.slots[i]).attributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributes(String paramString, Scriptable paramScriptable, int paramInt) throws PropertyException {
/*  407 */     byte b = 7;
/*  408 */     paramInt &= 0x7;
/*  409 */     int i = getSlot(paramString, paramString.hashCode());
/*  410 */     if (i == -1) {
/*  411 */       throw new PropertyException(
/*  412 */           Context.getMessage("msg.prop.not.found", null));
/*      */     }
/*  414 */     (this.slots[i]).attributes = (short)paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributes(int paramInt1, Scriptable paramScriptable, int paramInt2) throws PropertyException {
/*  435 */     int i = getSlot(null, paramInt1);
/*  436 */     if (i == -1) {
/*  437 */       throw new PropertyException(
/*  438 */           Context.getMessage("msg.prop.not.found", null));
/*      */     }
/*  440 */     (this.slots[i]).attributes = (short)paramInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  447 */   public Scriptable getPrototype() { return this.prototype; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  454 */   public void setPrototype(Scriptable paramScriptable) { this.prototype = paramScriptable; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  461 */   public Scriptable getParentScope() { return this.parent; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  468 */   public void setParentScope(Scriptable paramScriptable) { this.parent = paramScriptable; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  483 */   public Object[] getIds() { return getIds(false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  498 */   public Object[] getAllIds() { return getIds(true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getDefaultValue(Class paramClass) {
/*  517 */     FlattenedObject flattenedObject = new FlattenedObject(this);
/*  518 */     Context context = null;
/*      */     try {
/*  520 */       for (byte b = 0; b < 2; b++) {
/*  521 */         Object object; if ((paramClass == ScriptRuntime.StringClass) ? (b == 0) : (b == 1))
/*  522 */         { Function function = getFunctionProperty(flattenedObject, "toString");
/*  523 */           if (function != null)
/*      */           
/*  525 */           { if (context == null)
/*  526 */               context = Context.getContext(); 
/*  527 */             object = function.call(context, function.getParentScope(), flattenedObject.getObject(), 
/*  528 */                 ScriptRuntime.emptyArgs); }
/*      */           else { continue; }
/*      */            }
/*  531 */         else { String str1; if (paramClass == null) {
/*  532 */             str1 = "undefined";
/*  533 */           } else if (paramClass == ScriptRuntime.StringClass) {
/*  534 */             str1 = "string";
/*  535 */           } else if (paramClass == ScriptRuntime.ScriptableClass) {
/*  536 */             str1 = "object";
/*  537 */           } else if (paramClass == ScriptRuntime.FunctionClass) {
/*  538 */             str1 = "function";
/*  539 */           } else if (paramClass == ScriptRuntime.BooleanClass || 
/*  540 */             paramClass == boolean.class) {
/*  541 */             str1 = "boolean";
/*  542 */           } else if (paramClass == ScriptRuntime.NumberClass || 
/*  543 */             paramClass == ScriptRuntime.ByteClass || 
/*  544 */             paramClass == byte.class || 
/*  545 */             paramClass == ScriptRuntime.ShortClass || 
/*  546 */             paramClass == short.class || 
/*  547 */             paramClass == ScriptRuntime.IntegerClass || 
/*  548 */             paramClass == int.class || 
/*  549 */             paramClass == ScriptRuntime.FloatClass || 
/*  550 */             paramClass == float.class || 
/*  551 */             paramClass == ScriptRuntime.DoubleClass || 
/*  552 */             paramClass == double.class) {
/*  553 */             str1 = "number";
/*      */           } else {
/*  555 */             Object[] arrayOfObject1 = { paramClass.toString() };
/*  556 */             throw Context.reportRuntimeError(
/*  557 */                 Context.getMessage("msg.invalid.type", arrayOfObject1));
/*      */           } 
/*  559 */           Function function = getFunctionProperty(flattenedObject, "valueOf");
/*  560 */           if (function != null)
/*      */           
/*  562 */           { Object[] arrayOfObject1 = { str1 };
/*  563 */             if (context == null)
/*  564 */               context = Context.getContext(); 
/*  565 */             object = function.call(context, function.getParentScope(), flattenedObject.getObject(), 
/*  566 */                 arrayOfObject1); } else { continue; }
/*      */            }
/*  568 */          if (object != null && (object == Undefined.instance || 
/*  569 */           !(object instanceof Scriptable) || 
/*  570 */           paramClass == Scriptable.class || 
/*  571 */           paramClass == Function.class))
/*      */         {
/*  573 */           return object;
/*      */         }
/*  575 */         if (object instanceof NativeJavaObject) {
/*      */ 
/*      */           
/*  578 */           Object object1 = ((Wrapper)object).unwrap();
/*  579 */           if (object1 instanceof String) {
/*  580 */             return object1;
/*      */           }
/*      */         } 
/*      */         continue;
/*      */       } 
/*  585 */     } catch (JavaScriptException javaScriptException) {}
/*      */ 
/*      */     
/*  588 */     String str = (paramClass == null) ? "undefined" : paramClass.toString();
/*  589 */     Object[] arrayOfObject = { str };
/*  590 */     throw NativeGlobal.constructError(
/*  591 */         Context.getContext(), "TypeError", 
/*  592 */         ScriptRuntime.getMessage("msg.default.value", arrayOfObject), 
/*  593 */         this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  610 */   public boolean hasInstance(Scriptable paramScriptable) { return ScriptRuntime.jsDelegatesTo(paramScriptable, this); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  710 */   public static void defineClass(Scriptable paramScriptable, Class paramClass) throws IllegalAccessException, InstantiationException, InvocationTargetException, ClassDefinitionException, PropertyException { defineClass(paramScriptable, paramClass, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void defineClass(Scriptable paramScriptable, Class paramClass, boolean paramBoolean) throws IllegalAccessException, InstantiationException, InvocationTargetException, ClassDefinitionException, PropertyException { // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: invokestatic getMethodList : (Ljava/lang/Class;)[Ljava/lang/reflect/Method;
/*      */     //   4: astore_3
/*      */     //   5: iconst_0
/*      */     //   6: istore #4
/*      */     //   8: goto -> 90
/*      */     //   11: aload_3
/*      */     //   12: iload #4
/*      */     //   14: aaload
/*      */     //   15: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   18: ldc 'init'
/*      */     //   20: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   23: ifeq -> 87
/*      */     //   26: aload_3
/*      */     //   27: iload #4
/*      */     //   29: aaload
/*      */     //   30: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
/*      */     //   33: astore #5
/*      */     //   35: aload #5
/*      */     //   37: arraylength
/*      */     //   38: iconst_1
/*      */     //   39: if_icmpne -> 87
/*      */     //   42: aload #5
/*      */     //   44: iconst_0
/*      */     //   45: aaload
/*      */     //   46: getstatic org/mozilla/javascript/ScriptRuntime.ScriptableClass : Ljava/lang/Class;
/*      */     //   49: if_acmpne -> 87
/*      */     //   52: aload_3
/*      */     //   53: iload #4
/*      */     //   55: aaload
/*      */     //   56: invokevirtual getModifiers : ()I
/*      */     //   59: invokestatic isStatic : (I)Z
/*      */     //   62: ifeq -> 87
/*      */     //   65: iconst_1
/*      */     //   66: anewarray java/lang/Object
/*      */     //   69: dup
/*      */     //   70: iconst_0
/*      */     //   71: aload_0
/*      */     //   72: aastore
/*      */     //   73: astore #6
/*      */     //   75: aload_3
/*      */     //   76: iload #4
/*      */     //   78: aaload
/*      */     //   79: aconst_null
/*      */     //   80: aload #6
/*      */     //   82: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   85: pop
/*      */     //   86: return
/*      */     //   87: iinc #4, 1
/*      */     //   90: iload #4
/*      */     //   92: aload_3
/*      */     //   93: arraylength
/*      */     //   94: if_icmplt -> 11
/*      */     //   97: invokestatic getExclusionList : ()Ljava/util/Hashtable;
/*      */     //   100: astore #5
/*      */     //   102: aload_1
/*      */     //   103: invokevirtual getConstructors : ()[Ljava/lang/reflect/Constructor;
/*      */     //   106: astore #6
/*      */     //   108: aconst_null
/*      */     //   109: astore #7
/*      */     //   111: iconst_0
/*      */     //   112: istore #8
/*      */     //   114: goto -> 142
/*      */     //   117: aload #6
/*      */     //   119: iload #8
/*      */     //   121: aaload
/*      */     //   122: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
/*      */     //   125: arraylength
/*      */     //   126: ifne -> 139
/*      */     //   129: aload #6
/*      */     //   131: iload #8
/*      */     //   133: aaload
/*      */     //   134: astore #7
/*      */     //   136: goto -> 150
/*      */     //   139: iinc #8, 1
/*      */     //   142: iload #8
/*      */     //   144: aload #6
/*      */     //   146: arraylength
/*      */     //   147: if_icmplt -> 117
/*      */     //   150: aload #7
/*      */     //   152: ifnonnull -> 183
/*      */     //   155: iconst_1
/*      */     //   156: anewarray java/lang/Object
/*      */     //   159: dup
/*      */     //   160: iconst_0
/*      */     //   161: aload_1
/*      */     //   162: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   165: aastore
/*      */     //   166: astore #9
/*      */     //   168: new org/mozilla/javascript/ClassDefinitionException
/*      */     //   171: dup
/*      */     //   172: ldc 'msg.zero.arg.ctor'
/*      */     //   174: aload #9
/*      */     //   176: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   179: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   182: athrow
/*      */     //   183: aload #7
/*      */     //   185: getstatic org/mozilla/javascript/ScriptRuntime.emptyArgs : [Ljava/lang/Object;
/*      */     //   188: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   191: checkcast org/mozilla/javascript/Scriptable
/*      */     //   194: astore #9
/*      */     //   196: aload #9
/*      */     //   198: aload_0
/*      */     //   199: invokestatic getObjectPrototype : (Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;
/*      */     //   202: invokeinterface setPrototype : (Lorg/mozilla/javascript/Scriptable;)V
/*      */     //   207: aload #9
/*      */     //   209: invokeinterface getClassName : ()Ljava/lang/String;
/*      */     //   214: astore #10
/*      */     //   216: ldc 'js_'
/*      */     //   218: astore #11
/*      */     //   220: ldc 'jsFunction_'
/*      */     //   222: astore #12
/*      */     //   224: ldc 'jsStaticFunction_'
/*      */     //   226: astore #13
/*      */     //   228: ldc 'jsProperty_'
/*      */     //   230: astore #14
/*      */     //   232: ldc 'jsGet_'
/*      */     //   234: astore #15
/*      */     //   236: ldc 'jsSet_'
/*      */     //   238: astore #16
/*      */     //   240: ldc 'jsConstructor'
/*      */     //   242: astore #17
/*      */     //   244: aload_1
/*      */     //   245: ldc 'jsConstructor'
/*      */     //   247: invokestatic findMethods : (Ljava/lang/Class;Ljava/lang/String;)[Ljava/lang/reflect/Method;
/*      */     //   250: astore #18
/*      */     //   252: aconst_null
/*      */     //   253: astore #19
/*      */     //   255: aload #18
/*      */     //   257: ifnull -> 308
/*      */     //   260: aload #18
/*      */     //   262: arraylength
/*      */     //   263: iconst_1
/*      */     //   264: if_icmple -> 302
/*      */     //   267: iconst_2
/*      */     //   268: anewarray java/lang/Object
/*      */     //   271: dup
/*      */     //   272: iconst_0
/*      */     //   273: aload #18
/*      */     //   275: iconst_0
/*      */     //   276: aaload
/*      */     //   277: aastore
/*      */     //   278: dup
/*      */     //   279: iconst_1
/*      */     //   280: aload #18
/*      */     //   282: iconst_1
/*      */     //   283: aaload
/*      */     //   284: aastore
/*      */     //   285: astore #20
/*      */     //   287: new org/mozilla/javascript/ClassDefinitionException
/*      */     //   290: dup
/*      */     //   291: ldc 'msg.multiple.ctors'
/*      */     //   293: aload #20
/*      */     //   295: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   298: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   301: athrow
/*      */     //   302: aload #18
/*      */     //   304: iconst_0
/*      */     //   305: aaload
/*      */     //   306: astore #19
/*      */     //   308: iconst_0
/*      */     //   309: istore #20
/*      */     //   311: iconst_0
/*      */     //   312: istore #21
/*      */     //   314: goto -> 521
/*      */     //   317: aload_3
/*      */     //   318: iload #21
/*      */     //   320: aaload
/*      */     //   321: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   324: astore #22
/*      */     //   326: aconst_null
/*      */     //   327: astore #23
/*      */     //   329: aload #22
/*      */     //   331: ldc 'js'
/*      */     //   333: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   336: ifne -> 345
/*      */     //   339: aconst_null
/*      */     //   340: astore #23
/*      */     //   342: goto -> 444
/*      */     //   345: aload #22
/*      */     //   347: ldc 'js_'
/*      */     //   349: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   352: ifeq -> 362
/*      */     //   355: ldc 'js_'
/*      */     //   357: astore #23
/*      */     //   359: goto -> 444
/*      */     //   362: aload #22
/*      */     //   364: ldc 'jsFunction_'
/*      */     //   366: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   369: ifeq -> 379
/*      */     //   372: ldc 'jsFunction_'
/*      */     //   374: astore #23
/*      */     //   376: goto -> 444
/*      */     //   379: aload #22
/*      */     //   381: ldc 'jsStaticFunction_'
/*      */     //   383: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   386: ifeq -> 396
/*      */     //   389: ldc 'jsStaticFunction_'
/*      */     //   391: astore #23
/*      */     //   393: goto -> 444
/*      */     //   396: aload #22
/*      */     //   398: ldc 'jsProperty_'
/*      */     //   400: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   403: ifeq -> 413
/*      */     //   406: ldc 'jsProperty_'
/*      */     //   408: astore #23
/*      */     //   410: goto -> 444
/*      */     //   413: aload #22
/*      */     //   415: ldc 'jsGet_'
/*      */     //   417: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   420: ifeq -> 430
/*      */     //   423: ldc 'jsGet_'
/*      */     //   425: astore #23
/*      */     //   427: goto -> 444
/*      */     //   430: aload #22
/*      */     //   432: ldc 'jsSet_'
/*      */     //   434: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   437: ifeq -> 444
/*      */     //   440: ldc 'jsSet_'
/*      */     //   442: astore #23
/*      */     //   444: aload #23
/*      */     //   446: ifnull -> 464
/*      */     //   449: iconst_1
/*      */     //   450: istore #20
/*      */     //   452: aload #22
/*      */     //   454: aload #23
/*      */     //   456: invokevirtual length : ()I
/*      */     //   459: invokevirtual substring : (I)Ljava/lang/String;
/*      */     //   462: astore #22
/*      */     //   464: aload #22
/*      */     //   466: aload #10
/*      */     //   468: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   471: ifeq -> 518
/*      */     //   474: aload #19
/*      */     //   476: ifnull -> 512
/*      */     //   479: iconst_2
/*      */     //   480: anewarray java/lang/Object
/*      */     //   483: dup
/*      */     //   484: iconst_0
/*      */     //   485: aload #19
/*      */     //   487: aastore
/*      */     //   488: dup
/*      */     //   489: iconst_1
/*      */     //   490: aload_3
/*      */     //   491: iload #21
/*      */     //   493: aaload
/*      */     //   494: aastore
/*      */     //   495: astore #24
/*      */     //   497: new org/mozilla/javascript/ClassDefinitionException
/*      */     //   500: dup
/*      */     //   501: ldc 'msg.multiple.ctors'
/*      */     //   503: aload #24
/*      */     //   505: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   508: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   511: athrow
/*      */     //   512: aload_3
/*      */     //   513: iload #21
/*      */     //   515: aaload
/*      */     //   516: astore #19
/*      */     //   518: iinc #21, 1
/*      */     //   521: iload #21
/*      */     //   523: aload_3
/*      */     //   524: arraylength
/*      */     //   525: if_icmplt -> 317
/*      */     //   528: aload #19
/*      */     //   530: ifnonnull -> 626
/*      */     //   533: aload #6
/*      */     //   535: arraylength
/*      */     //   536: iconst_1
/*      */     //   537: if_icmpne -> 549
/*      */     //   540: aload #6
/*      */     //   542: iconst_0
/*      */     //   543: aaload
/*      */     //   544: astore #19
/*      */     //   546: goto -> 593
/*      */     //   549: aload #6
/*      */     //   551: arraylength
/*      */     //   552: iconst_2
/*      */     //   553: if_icmpne -> 593
/*      */     //   556: aload #6
/*      */     //   558: iconst_0
/*      */     //   559: aaload
/*      */     //   560: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
/*      */     //   563: arraylength
/*      */     //   564: ifne -> 576
/*      */     //   567: aload #6
/*      */     //   569: iconst_1
/*      */     //   570: aaload
/*      */     //   571: astore #19
/*      */     //   573: goto -> 593
/*      */     //   576: aload #6
/*      */     //   578: iconst_1
/*      */     //   579: aaload
/*      */     //   580: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
/*      */     //   583: arraylength
/*      */     //   584: ifne -> 593
/*      */     //   587: aload #6
/*      */     //   589: iconst_0
/*      */     //   590: aaload
/*      */     //   591: astore #19
/*      */     //   593: aload #19
/*      */     //   595: ifnonnull -> 626
/*      */     //   598: iconst_1
/*      */     //   599: anewarray java/lang/Object
/*      */     //   602: dup
/*      */     //   603: iconst_0
/*      */     //   604: aload_1
/*      */     //   605: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   608: aastore
/*      */     //   609: astore #22
/*      */     //   611: new org/mozilla/javascript/ClassDefinitionException
/*      */     //   614: dup
/*      */     //   615: ldc 'msg.ctor.multiple.parms'
/*      */     //   617: aload #22
/*      */     //   619: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   622: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   625: athrow
/*      */     //   626: new org/mozilla/javascript/FunctionObject
/*      */     //   629: dup
/*      */     //   630: aload #10
/*      */     //   632: aload #19
/*      */     //   634: aload_0
/*      */     //   635: invokespecial <init> : (Ljava/lang/String;Ljava/lang/reflect/Member;Lorg/mozilla/javascript/Scriptable;)V
/*      */     //   638: astore #22
/*      */     //   640: aload #22
/*      */     //   642: invokevirtual isVarArgsMethod : ()Z
/*      */     //   645: ifeq -> 679
/*      */     //   648: iconst_1
/*      */     //   649: anewarray java/lang/Object
/*      */     //   652: dup
/*      */     //   653: iconst_0
/*      */     //   654: aload #19
/*      */     //   656: invokeinterface getName : ()Ljava/lang/String;
/*      */     //   661: aastore
/*      */     //   662: astore #23
/*      */     //   664: ldc 'msg.varargs.ctor'
/*      */     //   666: aload #23
/*      */     //   668: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   671: astore #24
/*      */     //   673: aload #24
/*      */     //   675: invokestatic reportRuntimeError : (Ljava/lang/String;)Lorg/mozilla/javascript/EvaluatorException;
/*      */     //   678: athrow
/*      */     //   679: aload #22
/*      */     //   681: aload_0
/*      */     //   682: aload #9
/*      */     //   684: invokevirtual addAsConstructor : (Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;)V
/*      */     //   687: iload #20
/*      */     //   689: ifne -> 702
/*      */     //   692: aload #5
/*      */     //   694: ifnonnull -> 702
/*      */     //   697: invokestatic getExclusionList : ()Ljava/util/Hashtable;
/*      */     //   700: astore #5
/*      */     //   702: aconst_null
/*      */     //   703: astore #23
/*      */     //   705: iconst_0
/*      */     //   706: istore #24
/*      */     //   708: goto -> 1683
/*      */     //   711: iload #20
/*      */     //   713: ifne -> 727
/*      */     //   716: aload_3
/*      */     //   717: iload #24
/*      */     //   719: aaload
/*      */     //   720: invokevirtual getDeclaringClass : ()Ljava/lang/Class;
/*      */     //   723: aload_1
/*      */     //   724: if_acmpne -> 1680
/*      */     //   727: aload_3
/*      */     //   728: iload #24
/*      */     //   730: aaload
/*      */     //   731: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   734: astore #25
/*      */     //   736: aload #25
/*      */     //   738: ldc 'finishInit'
/*      */     //   740: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   743: ifeq -> 832
/*      */     //   746: aload_3
/*      */     //   747: iload #24
/*      */     //   749: aaload
/*      */     //   750: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
/*      */     //   753: astore #26
/*      */     //   755: aload #26
/*      */     //   757: arraylength
/*      */     //   758: iconst_3
/*      */     //   759: if_icmpne -> 832
/*      */     //   762: aload #26
/*      */     //   764: iconst_0
/*      */     //   765: aaload
/*      */     //   766: getstatic org/mozilla/javascript/ScriptRuntime.ScriptableClass : Ljava/lang/Class;
/*      */     //   769: if_acmpne -> 832
/*      */     //   772: aload #26
/*      */     //   774: iconst_1
/*      */     //   775: aaload
/*      */     //   776: getstatic org/mozilla/javascript/ScriptableObject.class$org$mozilla$javascript$FunctionObject : Ljava/lang/Class;
/*      */     //   779: ifnull -> 788
/*      */     //   782: getstatic org/mozilla/javascript/ScriptableObject.class$org$mozilla$javascript$FunctionObject : Ljava/lang/Class;
/*      */     //   785: goto -> 797
/*      */     //   788: ldc 'org.mozilla.javascript.FunctionObject'
/*      */     //   790: invokestatic class$ : (Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   793: dup
/*      */     //   794: putstatic org/mozilla/javascript/ScriptableObject.class$org$mozilla$javascript$FunctionObject : Ljava/lang/Class;
/*      */     //   797: if_acmpne -> 832
/*      */     //   800: aload #26
/*      */     //   802: iconst_2
/*      */     //   803: aaload
/*      */     //   804: getstatic org/mozilla/javascript/ScriptRuntime.ScriptableClass : Ljava/lang/Class;
/*      */     //   807: if_acmpne -> 832
/*      */     //   810: aload_3
/*      */     //   811: iload #24
/*      */     //   813: aaload
/*      */     //   814: invokevirtual getModifiers : ()I
/*      */     //   817: invokestatic isStatic : (I)Z
/*      */     //   820: ifeq -> 832
/*      */     //   823: aload_3
/*      */     //   824: iload #24
/*      */     //   826: aaload
/*      */     //   827: astore #23
/*      */     //   829: goto -> 1680
/*      */     //   832: aload #25
/*      */     //   834: ldc 'jsConstructor'
/*      */     //   836: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   839: ifne -> 1680
/*      */     //   842: aconst_null
/*      */     //   843: astore #26
/*      */     //   845: iload #20
/*      */     //   847: ifeq -> 987
/*      */     //   850: aload #25
/*      */     //   852: ldc 'js_'
/*      */     //   854: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   857: ifeq -> 867
/*      */     //   860: ldc 'js_'
/*      */     //   862: astore #26
/*      */     //   864: goto -> 972
/*      */     //   867: aload #25
/*      */     //   869: ldc 'jsFunction_'
/*      */     //   871: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   874: ifeq -> 884
/*      */     //   877: ldc 'jsFunction_'
/*      */     //   879: astore #26
/*      */     //   881: goto -> 972
/*      */     //   884: aload #25
/*      */     //   886: ldc 'jsStaticFunction_'
/*      */     //   888: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   891: ifeq -> 921
/*      */     //   894: ldc 'jsStaticFunction_'
/*      */     //   896: astore #26
/*      */     //   898: aload_3
/*      */     //   899: iload #24
/*      */     //   901: aaload
/*      */     //   902: invokevirtual getModifiers : ()I
/*      */     //   905: invokestatic isStatic : (I)Z
/*      */     //   908: ifne -> 972
/*      */     //   911: new org/mozilla/javascript/ClassDefinitionException
/*      */     //   914: dup
/*      */     //   915: ldc 'jsStaticFunction must be used with static method.'
/*      */     //   917: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   920: athrow
/*      */     //   921: aload #25
/*      */     //   923: ldc 'jsProperty_'
/*      */     //   925: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   928: ifeq -> 938
/*      */     //   931: ldc 'jsProperty_'
/*      */     //   933: astore #26
/*      */     //   935: goto -> 972
/*      */     //   938: aload #25
/*      */     //   940: ldc 'jsGet_'
/*      */     //   942: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   945: ifeq -> 955
/*      */     //   948: ldc 'jsGet_'
/*      */     //   950: astore #26
/*      */     //   952: goto -> 972
/*      */     //   955: aload #25
/*      */     //   957: ldc 'jsSet_'
/*      */     //   959: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   962: ifeq -> 1680
/*      */     //   965: ldc 'jsSet_'
/*      */     //   967: astore #26
/*      */     //   969: goto -> 972
/*      */     //   972: aload #25
/*      */     //   974: aload #26
/*      */     //   976: invokevirtual length : ()I
/*      */     //   979: invokevirtual substring : (I)Ljava/lang/String;
/*      */     //   982: astore #25
/*      */     //   984: goto -> 1000
/*      */     //   987: aload #5
/*      */     //   989: aload #25
/*      */     //   991: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   994: ifnull -> 1000
/*      */     //   997: goto -> 1680
/*      */     //   1000: aload_3
/*      */     //   1001: iload #24
/*      */     //   1003: aaload
/*      */     //   1004: aload #19
/*      */     //   1006: if_acmpeq -> 1680
/*      */     //   1009: aload #26
/*      */     //   1011: ifnull -> 1024
/*      */     //   1014: aload #26
/*      */     //   1016: ldc 'jsSet_'
/*      */     //   1018: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   1021: ifne -> 1680
/*      */     //   1024: aload #26
/*      */     //   1026: ifnull -> 1204
/*      */     //   1029: aload #26
/*      */     //   1031: ldc 'jsGet_'
/*      */     //   1033: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   1036: ifeq -> 1204
/*      */     //   1039: aload #9
/*      */     //   1041: instanceof org/mozilla/javascript/ScriptableObject
/*      */     //   1044: ifne -> 1084
/*      */     //   1047: iconst_2
/*      */     //   1048: anewarray java/lang/Object
/*      */     //   1051: dup
/*      */     //   1052: iconst_0
/*      */     //   1053: aload #9
/*      */     //   1055: invokevirtual getClass : ()Ljava/lang/Class;
/*      */     //   1058: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1061: aastore
/*      */     //   1062: dup
/*      */     //   1063: iconst_1
/*      */     //   1064: aload #25
/*      */     //   1066: aastore
/*      */     //   1067: astore #27
/*      */     //   1069: new org/mozilla/javascript/PropertyException
/*      */     //   1072: dup
/*      */     //   1073: ldc 'msg.extend.scriptable'
/*      */     //   1075: aload #27
/*      */     //   1077: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1080: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   1083: athrow
/*      */     //   1084: aload_1
/*      */     //   1085: new java/lang/StringBuffer
/*      */     //   1088: dup
/*      */     //   1089: ldc 'jsSet_'
/*      */     //   1091: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   1094: aload #25
/*      */     //   1096: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1099: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1102: invokestatic findMethods : (Ljava/lang/Class;Ljava/lang/String;)[Ljava/lang/reflect/Method;
/*      */     //   1105: astore #27
/*      */     //   1107: aload #27
/*      */     //   1109: ifnull -> 1152
/*      */     //   1112: aload #27
/*      */     //   1114: arraylength
/*      */     //   1115: iconst_1
/*      */     //   1116: if_icmpeq -> 1152
/*      */     //   1119: iconst_2
/*      */     //   1120: anewarray java/lang/Object
/*      */     //   1123: dup
/*      */     //   1124: iconst_0
/*      */     //   1125: aload #25
/*      */     //   1127: aastore
/*      */     //   1128: dup
/*      */     //   1129: iconst_1
/*      */     //   1130: aload_1
/*      */     //   1131: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   1134: aastore
/*      */     //   1135: astore #28
/*      */     //   1137: new org/mozilla/javascript/PropertyException
/*      */     //   1140: dup
/*      */     //   1141: ldc 'msg.no.overload'
/*      */     //   1143: aload #28
/*      */     //   1145: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1148: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   1151: athrow
/*      */     //   1152: bipush #6
/*      */     //   1154: aload #27
/*      */     //   1156: ifnull -> 1163
/*      */     //   1159: iconst_0
/*      */     //   1160: goto -> 1164
/*      */     //   1163: iconst_1
/*      */     //   1164: ior
/*      */     //   1165: istore #28
/*      */     //   1167: aload #27
/*      */     //   1169: ifnonnull -> 1176
/*      */     //   1172: aconst_null
/*      */     //   1173: goto -> 1180
/*      */     //   1176: aload #27
/*      */     //   1178: iconst_0
/*      */     //   1179: aaload
/*      */     //   1180: astore #29
/*      */     //   1182: aload #9
/*      */     //   1184: checkcast org/mozilla/javascript/ScriptableObject
/*      */     //   1187: aload #25
/*      */     //   1189: aconst_null
/*      */     //   1190: aload_3
/*      */     //   1191: iload #24
/*      */     //   1193: aaload
/*      */     //   1194: aload #29
/*      */     //   1196: iload #28
/*      */     //   1198: invokevirtual defineProperty : (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;I)V
/*      */     //   1201: goto -> 1680
/*      */     //   1204: aload #25
/*      */     //   1206: ldc 'get'
/*      */     //   1208: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   1211: ifne -> 1224
/*      */     //   1214: aload #25
/*      */     //   1216: ldc 'set'
/*      */     //   1218: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   1221: ifeq -> 1556
/*      */     //   1224: aload #25
/*      */     //   1226: invokevirtual length : ()I
/*      */     //   1229: iconst_3
/*      */     //   1230: if_icmple -> 1556
/*      */     //   1233: iload #20
/*      */     //   1235: ifeq -> 1258
/*      */     //   1238: aload #26
/*      */     //   1240: ldc 'jsFunction_'
/*      */     //   1242: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   1245: ifne -> 1556
/*      */     //   1248: aload #26
/*      */     //   1250: ldc 'jsStaticFunction_'
/*      */     //   1252: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   1255: ifne -> 1556
/*      */     //   1258: aload #9
/*      */     //   1260: instanceof org/mozilla/javascript/ScriptableObject
/*      */     //   1263: ifne -> 1303
/*      */     //   1266: iconst_2
/*      */     //   1267: anewarray java/lang/Object
/*      */     //   1270: dup
/*      */     //   1271: iconst_0
/*      */     //   1272: aload #9
/*      */     //   1274: invokevirtual getClass : ()Ljava/lang/Class;
/*      */     //   1277: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1280: aastore
/*      */     //   1281: dup
/*      */     //   1282: iconst_1
/*      */     //   1283: aload #25
/*      */     //   1285: aastore
/*      */     //   1286: astore #27
/*      */     //   1288: new org/mozilla/javascript/PropertyException
/*      */     //   1291: dup
/*      */     //   1292: ldc 'msg.extend.scriptable'
/*      */     //   1294: aload #27
/*      */     //   1296: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1299: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   1302: athrow
/*      */     //   1303: aload #25
/*      */     //   1305: ldc 'set'
/*      */     //   1307: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   1310: ifne -> 1680
/*      */     //   1313: new java/lang/StringBuffer
/*      */     //   1316: dup
/*      */     //   1317: invokespecial <init> : ()V
/*      */     //   1320: astore #27
/*      */     //   1322: aload #25
/*      */     //   1324: iconst_3
/*      */     //   1325: invokevirtual charAt : (I)C
/*      */     //   1328: istore #28
/*      */     //   1330: aload #27
/*      */     //   1332: iload #28
/*      */     //   1334: invokestatic toLowerCase : (C)C
/*      */     //   1337: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*      */     //   1340: pop
/*      */     //   1341: aload #25
/*      */     //   1343: invokevirtual length : ()I
/*      */     //   1346: iconst_4
/*      */     //   1347: if_icmple -> 1362
/*      */     //   1350: aload #27
/*      */     //   1352: aload #25
/*      */     //   1354: iconst_4
/*      */     //   1355: invokevirtual substring : (I)Ljava/lang/String;
/*      */     //   1358: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1361: pop
/*      */     //   1362: aload #27
/*      */     //   1364: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1367: astore #29
/*      */     //   1369: aload #27
/*      */     //   1371: iconst_0
/*      */     //   1372: iload #28
/*      */     //   1374: invokevirtual setCharAt : (IC)V
/*      */     //   1377: aload #27
/*      */     //   1379: iconst_0
/*      */     //   1380: ldc 'set'
/*      */     //   1382: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1385: pop
/*      */     //   1386: aload #27
/*      */     //   1388: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1391: astore #30
/*      */     //   1393: aload_1
/*      */     //   1394: iload #20
/*      */     //   1396: ifeq -> 1419
/*      */     //   1399: new java/lang/StringBuffer
/*      */     //   1402: dup
/*      */     //   1403: ldc 'js_'
/*      */     //   1405: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   1408: aload #30
/*      */     //   1410: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1413: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1416: goto -> 1421
/*      */     //   1419: aload #30
/*      */     //   1421: invokestatic findMethods : (Ljava/lang/Class;Ljava/lang/String;)[Ljava/lang/reflect/Method;
/*      */     //   1424: astore #31
/*      */     //   1426: aload #31
/*      */     //   1428: ifnull -> 1471
/*      */     //   1431: aload #31
/*      */     //   1433: arraylength
/*      */     //   1434: iconst_1
/*      */     //   1435: if_icmpeq -> 1471
/*      */     //   1438: iconst_2
/*      */     //   1439: anewarray java/lang/Object
/*      */     //   1442: dup
/*      */     //   1443: iconst_0
/*      */     //   1444: aload #25
/*      */     //   1446: aastore
/*      */     //   1447: dup
/*      */     //   1448: iconst_1
/*      */     //   1449: aload_1
/*      */     //   1450: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   1453: aastore
/*      */     //   1454: astore #32
/*      */     //   1456: new org/mozilla/javascript/PropertyException
/*      */     //   1459: dup
/*      */     //   1460: ldc 'msg.no.overload'
/*      */     //   1462: aload #32
/*      */     //   1464: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1467: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   1470: athrow
/*      */     //   1471: aload #31
/*      */     //   1473: ifnonnull -> 1504
/*      */     //   1476: iload #20
/*      */     //   1478: ifeq -> 1504
/*      */     //   1481: aload_1
/*      */     //   1482: new java/lang/StringBuffer
/*      */     //   1485: dup
/*      */     //   1486: ldc 'jsProperty_'
/*      */     //   1488: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   1491: aload #30
/*      */     //   1493: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1496: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1499: invokestatic findMethods : (Ljava/lang/Class;Ljava/lang/String;)[Ljava/lang/reflect/Method;
/*      */     //   1502: astore #31
/*      */     //   1504: bipush #6
/*      */     //   1506: aload #31
/*      */     //   1508: ifnull -> 1515
/*      */     //   1511: iconst_0
/*      */     //   1512: goto -> 1516
/*      */     //   1515: iconst_1
/*      */     //   1516: ior
/*      */     //   1517: istore #32
/*      */     //   1519: aload #31
/*      */     //   1521: ifnonnull -> 1528
/*      */     //   1524: aconst_null
/*      */     //   1525: goto -> 1532
/*      */     //   1528: aload #31
/*      */     //   1530: iconst_0
/*      */     //   1531: aaload
/*      */     //   1532: astore #33
/*      */     //   1534: aload #9
/*      */     //   1536: checkcast org/mozilla/javascript/ScriptableObject
/*      */     //   1539: aload #29
/*      */     //   1541: aconst_null
/*      */     //   1542: aload_3
/*      */     //   1543: iload #24
/*      */     //   1545: aaload
/*      */     //   1546: aload #33
/*      */     //   1548: iload #32
/*      */     //   1550: invokevirtual defineProperty : (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;I)V
/*      */     //   1553: goto -> 1680
/*      */     //   1556: new org/mozilla/javascript/FunctionObject
/*      */     //   1559: dup
/*      */     //   1560: aload #25
/*      */     //   1562: aload_3
/*      */     //   1563: iload #24
/*      */     //   1565: aaload
/*      */     //   1566: aload #9
/*      */     //   1568: invokespecial <init> : (Ljava/lang/String;Ljava/lang/reflect/Member;Lorg/mozilla/javascript/Scriptable;)V
/*      */     //   1571: astore #27
/*      */     //   1573: aload #27
/*      */     //   1575: invokevirtual isVarArgsConstructor : ()Z
/*      */     //   1578: ifeq -> 1612
/*      */     //   1581: iconst_1
/*      */     //   1582: anewarray java/lang/Object
/*      */     //   1585: dup
/*      */     //   1586: iconst_0
/*      */     //   1587: aload #19
/*      */     //   1589: invokeinterface getName : ()Ljava/lang/String;
/*      */     //   1594: aastore
/*      */     //   1595: astore #28
/*      */     //   1597: ldc 'msg.varargs.fun'
/*      */     //   1599: aload #28
/*      */     //   1601: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1604: astore #29
/*      */     //   1606: aload #29
/*      */     //   1608: invokestatic reportRuntimeError : (Ljava/lang/String;)Lorg/mozilla/javascript/EvaluatorException;
/*      */     //   1611: athrow
/*      */     //   1612: aload #26
/*      */     //   1614: ldc 'jsStaticFunction_'
/*      */     //   1616: if_acmpne -> 1624
/*      */     //   1619: aload #22
/*      */     //   1621: goto -> 1626
/*      */     //   1624: aload #9
/*      */     //   1626: astore #28
/*      */     //   1628: aload #28
/*      */     //   1630: instanceof org/mozilla/javascript/ScriptableObject
/*      */     //   1633: ifeq -> 1652
/*      */     //   1636: aload #28
/*      */     //   1638: checkcast org/mozilla/javascript/ScriptableObject
/*      */     //   1641: aload #25
/*      */     //   1643: aload #27
/*      */     //   1645: iconst_2
/*      */     //   1646: invokevirtual defineProperty : (Ljava/lang/String;Ljava/lang/Object;I)V
/*      */     //   1649: goto -> 1665
/*      */     //   1652: aload #28
/*      */     //   1654: aload #25
/*      */     //   1656: aload #28
/*      */     //   1658: aload #27
/*      */     //   1660: invokeinterface put : (Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)V
/*      */     //   1665: iload_2
/*      */     //   1666: ifeq -> 1680
/*      */     //   1669: aload #27
/*      */     //   1671: invokevirtual sealObject : ()V
/*      */     //   1674: aload #27
/*      */     //   1676: iconst_1
/*      */     //   1677: invokevirtual addPropertyAttribute : (I)V
/*      */     //   1680: iinc #24, 1
/*      */     //   1683: iload #24
/*      */     //   1685: aload_3
/*      */     //   1686: arraylength
/*      */     //   1687: if_icmplt -> 711
/*      */     //   1690: aload #23
/*      */     //   1692: ifnull -> 1724
/*      */     //   1695: iconst_3
/*      */     //   1696: anewarray java/lang/Object
/*      */     //   1699: dup
/*      */     //   1700: iconst_0
/*      */     //   1701: aload_0
/*      */     //   1702: aastore
/*      */     //   1703: dup
/*      */     //   1704: iconst_1
/*      */     //   1705: aload #22
/*      */     //   1707: aastore
/*      */     //   1708: dup
/*      */     //   1709: iconst_2
/*      */     //   1710: aload #9
/*      */     //   1712: aastore
/*      */     //   1713: astore #25
/*      */     //   1715: aload #23
/*      */     //   1717: aconst_null
/*      */     //   1718: aload #25
/*      */     //   1720: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   1723: pop
/*      */     //   1724: iload_2
/*      */     //   1725: ifeq -> 1764
/*      */     //   1728: aload #22
/*      */     //   1730: invokevirtual sealObject : ()V
/*      */     //   1733: aload #22
/*      */     //   1735: iconst_1
/*      */     //   1736: invokevirtual addPropertyAttribute : (I)V
/*      */     //   1739: aload #9
/*      */     //   1741: instanceof org/mozilla/javascript/ScriptableObject
/*      */     //   1744: ifeq -> 1764
/*      */     //   1747: aload #9
/*      */     //   1749: checkcast org/mozilla/javascript/ScriptableObject
/*      */     //   1752: invokevirtual sealObject : ()V
/*      */     //   1755: aload #9
/*      */     //   1757: checkcast org/mozilla/javascript/ScriptableObject
/*      */     //   1760: iconst_1
/*      */     //   1761: invokevirtual addPropertyAttribute : (I)V
/*      */     //   1764: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #747	-> 0
/*      */     //   #748	-> 5
/*      */     //   #749	-> 11
/*      */     //   #751	-> 26
/*      */     //   #752	-> 35
/*      */     //   #753	-> 42
/*      */     //   #754	-> 52
/*      */     //   #756	-> 65
/*      */     //   #757	-> 75
/*      */     //   #758	-> 86
/*      */     //   #748	-> 87
/*      */     //   #764	-> 97
/*      */     //   #766	-> 102
/*      */     //   #767	-> 108
/*      */     //   #768	-> 111
/*      */     //   #769	-> 117
/*      */     //   #770	-> 129
/*      */     //   #771	-> 136
/*      */     //   #768	-> 139
/*      */     //   #774	-> 150
/*      */     //   #775	-> 155
/*      */     //   #776	-> 168
/*      */     //   #777	-> 172
/*      */     //   #776	-> 179
/*      */     //   #781	-> 183
/*      */     //   #780	-> 191
/*      */     //   #782	-> 196
/*      */     //   #783	-> 207
/*      */     //   #789	-> 216
/*      */     //   #790	-> 220
/*      */     //   #791	-> 224
/*      */     //   #792	-> 228
/*      */     //   #793	-> 232
/*      */     //   #794	-> 236
/*      */     //   #795	-> 240
/*      */     //   #797	-> 244
/*      */     //   #795	-> 245
/*      */     //   #797	-> 247
/*      */     //   #798	-> 252
/*      */     //   #799	-> 255
/*      */     //   #800	-> 260
/*      */     //   #801	-> 267
/*      */     //   #802	-> 287
/*      */     //   #803	-> 291
/*      */     //   #802	-> 298
/*      */     //   #805	-> 302
/*      */     //   #810	-> 308
/*      */     //   #811	-> 311
/*      */     //   #812	-> 317
/*      */     //   #813	-> 326
/*      */     //   #814	-> 329
/*      */     //   #815	-> 339
/*      */     //   #814	-> 342
/*      */     //   #816	-> 345
/*      */     //   #789	-> 347
/*      */     //   #816	-> 349
/*      */     //   #789	-> 355
/*      */     //   #817	-> 357
/*      */     //   #816	-> 359
/*      */     //   #818	-> 362
/*      */     //   #790	-> 364
/*      */     //   #818	-> 366
/*      */     //   #790	-> 372
/*      */     //   #819	-> 374
/*      */     //   #818	-> 376
/*      */     //   #820	-> 379
/*      */     //   #791	-> 381
/*      */     //   #820	-> 383
/*      */     //   #791	-> 389
/*      */     //   #821	-> 391
/*      */     //   #820	-> 393
/*      */     //   #822	-> 396
/*      */     //   #792	-> 398
/*      */     //   #822	-> 400
/*      */     //   #792	-> 406
/*      */     //   #823	-> 408
/*      */     //   #822	-> 410
/*      */     //   #824	-> 413
/*      */     //   #793	-> 415
/*      */     //   #824	-> 417
/*      */     //   #793	-> 423
/*      */     //   #825	-> 425
/*      */     //   #824	-> 427
/*      */     //   #826	-> 430
/*      */     //   #794	-> 432
/*      */     //   #826	-> 434
/*      */     //   #794	-> 440
/*      */     //   #827	-> 442
/*      */     //   #828	-> 444
/*      */     //   #829	-> 449
/*      */     //   #830	-> 452
/*      */     //   #832	-> 464
/*      */     //   #833	-> 474
/*      */     //   #834	-> 479
/*      */     //   #835	-> 497
/*      */     //   #836	-> 501
/*      */     //   #835	-> 508
/*      */     //   #838	-> 512
/*      */     //   #811	-> 518
/*      */     //   #842	-> 528
/*      */     //   #843	-> 533
/*      */     //   #844	-> 540
/*      */     //   #843	-> 546
/*      */     //   #845	-> 549
/*      */     //   #846	-> 556
/*      */     //   #847	-> 567
/*      */     //   #846	-> 573
/*      */     //   #848	-> 576
/*      */     //   #849	-> 587
/*      */     //   #851	-> 593
/*      */     //   #852	-> 598
/*      */     //   #853	-> 611
/*      */     //   #854	-> 615
/*      */     //   #853	-> 622
/*      */     //   #858	-> 626
/*      */     //   #859	-> 640
/*      */     //   #860	-> 648
/*      */     //   #861	-> 664
/*      */     //   #862	-> 673
/*      */     //   #864	-> 679
/*      */     //   #866	-> 687
/*      */     //   #867	-> 697
/*      */     //   #868	-> 702
/*      */     //   #869	-> 705
/*      */     //   #870	-> 711
/*      */     //   #872	-> 727
/*      */     //   #873	-> 736
/*      */     //   #874	-> 746
/*      */     //   #875	-> 755
/*      */     //   #876	-> 762
/*      */     //   #877	-> 772
/*      */     //   #878	-> 800
/*      */     //   #879	-> 810
/*      */     //   #881	-> 823
/*      */     //   #882	-> 829
/*      */     //   #885	-> 832
/*      */     //   #795	-> 834
/*      */     //   #885	-> 836
/*      */     //   #887	-> 842
/*      */     //   #888	-> 845
/*      */     //   #889	-> 850
/*      */     //   #789	-> 852
/*      */     //   #889	-> 854
/*      */     //   #789	-> 860
/*      */     //   #890	-> 862
/*      */     //   #889	-> 864
/*      */     //   #891	-> 867
/*      */     //   #790	-> 869
/*      */     //   #891	-> 871
/*      */     //   #790	-> 877
/*      */     //   #892	-> 879
/*      */     //   #891	-> 881
/*      */     //   #893	-> 884
/*      */     //   #791	-> 886
/*      */     //   #893	-> 888
/*      */     //   #791	-> 894
/*      */     //   #894	-> 896
/*      */     //   #895	-> 898
/*      */     //   #896	-> 911
/*      */     //   #897	-> 915
/*      */     //   #896	-> 917
/*      */     //   #899	-> 921
/*      */     //   #792	-> 923
/*      */     //   #899	-> 925
/*      */     //   #792	-> 931
/*      */     //   #900	-> 933
/*      */     //   #899	-> 935
/*      */     //   #901	-> 938
/*      */     //   #793	-> 940
/*      */     //   #901	-> 942
/*      */     //   #793	-> 948
/*      */     //   #902	-> 950
/*      */     //   #901	-> 952
/*      */     //   #903	-> 955
/*      */     //   #794	-> 957
/*      */     //   #903	-> 959
/*      */     //   #794	-> 965
/*      */     //   #904	-> 967
/*      */     //   #903	-> 969
/*      */     //   #908	-> 972
/*      */     //   #888	-> 984
/*      */     //   #909	-> 987
/*      */     //   #910	-> 997
/*      */     //   #911	-> 1000
/*      */     //   #914	-> 1009
/*      */     //   #794	-> 1016
/*      */     //   #914	-> 1018
/*      */     //   #916	-> 1024
/*      */     //   #793	-> 1031
/*      */     //   #916	-> 1033
/*      */     //   #917	-> 1039
/*      */     //   #918	-> 1047
/*      */     //   #919	-> 1069
/*      */     //   #920	-> 1073
/*      */     //   #919	-> 1080
/*      */     //   #923	-> 1084
/*      */     //   #794	-> 1085
/*      */     //   #924	-> 1094
/*      */     //   #922	-> 1102
/*      */     //   #925	-> 1107
/*      */     //   #926	-> 1119
/*      */     //   #927	-> 1137
/*      */     //   #928	-> 1141
/*      */     //   #927	-> 1148
/*      */     //   #930	-> 1152
/*      */     //   #932	-> 1154
/*      */     //   #933	-> 1163
/*      */     //   #931	-> 1164
/*      */     //   #930	-> 1165
/*      */     //   #934	-> 1167
/*      */     //   #935	-> 1182
/*      */     //   #936	-> 1190
/*      */     //   #937	-> 1196
/*      */     //   #935	-> 1198
/*      */     //   #938	-> 1201
/*      */     //   #940	-> 1204
/*      */     //   #941	-> 1224
/*      */     //   #942	-> 1233
/*      */     //   #790	-> 1240
/*      */     //   #942	-> 1242
/*      */     //   #943	-> 1248
/*      */     //   #791	-> 1250
/*      */     //   #943	-> 1252
/*      */     //   #945	-> 1258
/*      */     //   #946	-> 1266
/*      */     //   #947	-> 1288
/*      */     //   #948	-> 1292
/*      */     //   #947	-> 1299
/*      */     //   #950	-> 1303
/*      */     //   #952	-> 1313
/*      */     //   #953	-> 1322
/*      */     //   #954	-> 1330
/*      */     //   #955	-> 1341
/*      */     //   #956	-> 1350
/*      */     //   #957	-> 1362
/*      */     //   #958	-> 1369
/*      */     //   #959	-> 1377
/*      */     //   #960	-> 1386
/*      */     //   #962	-> 1393
/*      */     //   #963	-> 1394
/*      */     //   #789	-> 1399
/*      */     //   #963	-> 1408
/*      */     //   #964	-> 1419
/*      */     //   #961	-> 1421
/*      */     //   #965	-> 1426
/*      */     //   #966	-> 1438
/*      */     //   #967	-> 1456
/*      */     //   #968	-> 1460
/*      */     //   #967	-> 1467
/*      */     //   #970	-> 1471
/*      */     //   #972	-> 1481
/*      */     //   #792	-> 1482
/*      */     //   #973	-> 1491
/*      */     //   #971	-> 1499
/*      */     //   #974	-> 1504
/*      */     //   #976	-> 1506
/*      */     //   #977	-> 1515
/*      */     //   #975	-> 1516
/*      */     //   #974	-> 1517
/*      */     //   #978	-> 1519
/*      */     //   #979	-> 1534
/*      */     //   #980	-> 1542
/*      */     //   #981	-> 1548
/*      */     //   #979	-> 1550
/*      */     //   #982	-> 1553
/*      */     //   #984	-> 1556
/*      */     //   #985	-> 1573
/*      */     //   #986	-> 1581
/*      */     //   #987	-> 1597
/*      */     //   #988	-> 1606
/*      */     //   #990	-> 1612
/*      */     //   #791	-> 1614
/*      */     //   #990	-> 1616
/*      */     //   #991	-> 1619
/*      */     //   #992	-> 1624
/*      */     //   #990	-> 1626
/*      */     //   #993	-> 1628
/*      */     //   #994	-> 1636
/*      */     //   #993	-> 1649
/*      */     //   #996	-> 1652
/*      */     //   #998	-> 1665
/*      */     //   #999	-> 1669
/*      */     //   #1000	-> 1674
/*      */     //   #869	-> 1680
/*      */     //   #1004	-> 1690
/*      */     //   #1006	-> 1695
/*      */     //   #1007	-> 1715
/*      */     //   #1010	-> 1724
/*      */     //   #1011	-> 1728
/*      */     //   #1012	-> 1733
/*      */     //   #1013	-> 1739
/*      */     //   #1014	-> 1747
/*      */     //   #1015	-> 1755
/*      */     //   #741	-> 1764 }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineProperty(String paramString, Object paramObject, int paramInt) {
/* 1033 */     put(paramString, this, paramObject);
/*      */     try {
/* 1035 */       setAttributes(paramString, this, paramInt);
/*      */     }
/* 1037 */     catch (PropertyException propertyException) {
/* 1038 */       throw new RuntimeException("Cannot create property");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineProperty(String paramString, Class paramClass, int paramInt) throws PropertyException {
/* 1069 */     StringBuffer stringBuffer = new StringBuffer(paramString);
/* 1070 */     stringBuffer.setCharAt(0, Character.toUpperCase(paramString.charAt(0)));
/* 1071 */     String str = stringBuffer.toString();
/* 1072 */     Method[] arrayOfMethod1 = FunctionObject.findMethods(paramClass, "get" + str);
/* 1073 */     Method[] arrayOfMethod2 = FunctionObject.findMethods(paramClass, "set" + str);
/* 1074 */     if (arrayOfMethod2 == null)
/* 1075 */       paramInt |= 0x1; 
/* 1076 */     if (arrayOfMethod1.length != 1 || (arrayOfMethod2 != null && arrayOfMethod2.length != 1)) {
/* 1077 */       Object[] arrayOfObject = { paramString, paramClass.getName() };
/* 1078 */       throw new PropertyException(
/* 1079 */           Context.getMessage("msg.no.overload", arrayOfObject));
/*      */     } 
/* 1081 */     defineProperty(paramString, null, arrayOfMethod1[0], 
/* 1082 */         (arrayOfMethod2 == null) ? null : arrayOfMethod2[0], paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineProperty(String paramString, Object paramObject, Method paramMethod1, Method paramMethod2, int paramInt) throws PropertyException {
/* 1132 */     short s = 1;
/* 1133 */     if (paramObject == null && Modifier.isStatic(paramMethod1.getModifiers()))
/* 1134 */       paramObject = HAS_STATIC_ACCESSORS; 
/* 1135 */     Class[] arrayOfClass = paramMethod1.getParameterTypes();
/* 1136 */     if (arrayOfClass.length != 0) {
/* 1137 */       if (arrayOfClass.length != 1 || 
/* 1138 */         arrayOfClass[false] != ScriptableObject.class) {
/*      */         
/* 1140 */         Object[] arrayOfObject = { paramMethod1.toString() };
/* 1141 */         throw new PropertyException(
/* 1142 */             Context.getMessage("msg.bad.getter.parms", arrayOfObject));
/*      */       } 
/* 1144 */     } else if (paramObject != null) {
/* 1145 */       Object[] arrayOfObject = { paramMethod1.toString() };
/* 1146 */       throw new PropertyException(
/* 1147 */           Context.getMessage("msg.obj.getter.parms", arrayOfObject));
/*      */     } 
/* 1149 */     if (paramMethod2 != null) {
/* 1150 */       s = (short)(s | 0x2);
/* 1151 */       if ((!(paramObject != HAS_STATIC_ACCESSORS)) != 
/* 1152 */         Modifier.isStatic(paramMethod2.getModifiers()))
/*      */       {
/* 1154 */         throw new PropertyException(
/* 1155 */             Context.getMessage("msg.getter.static", null));
/*      */       }
/* 1157 */       arrayOfClass = paramMethod2.getParameterTypes();
/* 1158 */       if (arrayOfClass.length == 2) {
/* 1159 */         if (arrayOfClass[false] != ScriptableObject.class) {
/* 1160 */           throw new PropertyException(
/* 1161 */               Context.getMessage("msg.setter2.parms", null));
/*      */         }
/* 1163 */         if (paramObject == null) {
/* 1164 */           Object[] arrayOfObject = { paramMethod2.toString() };
/* 1165 */           throw new PropertyException(
/* 1166 */               Context.getMessage("msg.setter1.parms", arrayOfObject));
/*      */         } 
/* 1168 */       } else if (arrayOfClass.length == 1) {
/* 1169 */         if (paramObject != null) {
/* 1170 */           Object[] arrayOfObject = { paramMethod2.toString() };
/* 1171 */           throw new PropertyException(
/* 1172 */               Context.getMessage("msg.setter2.expected", arrayOfObject));
/*      */         } 
/*      */       } else {
/* 1175 */         throw new PropertyException(
/* 1176 */             Context.getMessage("msg.setter.parms", null));
/*      */       } 
/*      */     } 
/* 1179 */     int i = getSlotToSet(paramString, 
/* 1180 */         paramString.hashCode(), 
/* 1181 */         true);
/* 1182 */     GetterSlot getterSlot = (GetterSlot)this.slots[i];
/* 1183 */     getterSlot.delegateTo = paramObject;
/* 1184 */     getterSlot.getter = paramMethod1;
/* 1185 */     getterSlot.setter = paramMethod2;
/* 1186 */     getterSlot.value = null;
/* 1187 */     getterSlot.attributes = (short)paramInt;
/* 1188 */     getterSlot.flags = s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineFunctionProperties(String[] paramArrayOfString, Class paramClass, int paramInt) throws PropertyException {
/* 1211 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 1212 */       String str = paramArrayOfString[b];
/* 1213 */       Method[] arrayOfMethod = FunctionObject.findMethods(paramClass, str);
/* 1214 */       if (arrayOfMethod == null) {
/* 1215 */         Object[] arrayOfObject = { str, paramClass.getName() };
/* 1216 */         throw new PropertyException(
/* 1217 */             Context.getMessage("msg.method.not.found", arrayOfObject));
/*      */       } 
/* 1219 */       if (arrayOfMethod.length > 1) {
/* 1220 */         Object[] arrayOfObject = { str, paramClass.getName() };
/* 1221 */         throw new PropertyException(
/* 1222 */             Context.getMessage("msg.no.overload", arrayOfObject));
/*      */       } 
/* 1224 */       FunctionObject functionObject = new FunctionObject(str, arrayOfMethod[0], this);
/* 1225 */       defineProperty(str, functionObject, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1234 */   public static Scriptable getObjectPrototype(Scriptable paramScriptable) { return getClassPrototype(paramScriptable, "Object"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1242 */   public static Scriptable getFunctionPrototype(Scriptable paramScriptable) { return getClassPrototype(paramScriptable, "Function"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable getClassPrototype(Scriptable paramScriptable, String paramString) {
/* 1263 */     paramScriptable = getTopLevelScope(paramScriptable);
/* 1264 */     Object object1 = ScriptRuntime.getTopLevelProp(paramScriptable, paramString);
/* 1265 */     if (object1 == Scriptable.NOT_FOUND || !(object1 instanceof Scriptable))
/* 1266 */       return null; 
/* 1267 */     Scriptable scriptable = (Scriptable)object1;
/* 1268 */     if (!scriptable.has("prototype", scriptable))
/* 1269 */       return null; 
/* 1270 */     Object object2 = scriptable.get("prototype", scriptable);
/* 1271 */     if (!(object2 instanceof Scriptable))
/* 1272 */       return null; 
/* 1273 */     return (Scriptable)object2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable getTopLevelScope(Scriptable paramScriptable) {
/* 1286 */     Scriptable scriptable = paramScriptable;
/*      */     do {
/* 1288 */       paramScriptable = scriptable;
/* 1289 */       scriptable = paramScriptable.getParentScope();
/* 1290 */     } while (scriptable != null);
/* 1291 */     return paramScriptable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1303 */   public void sealObject() { this.count = -1; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1316 */   public boolean isSealed() { return !(this.count != -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void addPropertyAttribute(int paramInt) {
/* 1323 */     if (this.slots == null)
/*      */       return; 
/* 1325 */     for (byte b = 0; b < this.slots.length; b++) {
/* 1326 */       Slot slot = this.slots[b];
/* 1327 */       if (slot != null && slot != REMOVED)
/*      */       {
/* 1329 */         if ((slot.flags & 0x2) == 0 || paramInt != 1)
/*      */         {
/* 1331 */           slot.attributes = (short)(slot.attributes | paramInt);
/*      */         }
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private int getSlot(String paramString, int paramInt) {
/* 1338 */     if (this.slots == null)
/* 1339 */       return -1; 
/* 1340 */     int i = (paramInt & 0x7FFFFFFF) % this.slots.length;
/* 1341 */     int j = i;
/*      */     do {
/* 1343 */       Slot slot = this.slots[j];
/* 1344 */       if (slot == null)
/* 1345 */         return -1; 
/* 1346 */       if (slot != REMOVED && slot.intKey == paramInt && (
/* 1347 */         slot.stringKey == paramString || (paramString != null && 
/* 1348 */         paramString.equals(slot.stringKey))))
/*      */       {
/* 1350 */         return j;
/*      */       }
/* 1352 */       if (++j != this.slots.length)
/* 1353 */         continue;  j = 0;
/* 1354 */     } while (j != i);
/* 1355 */     return -1;
/*      */   }
/*      */   
/*      */   private int getSlotToSet(String paramString, int paramInt, boolean paramBoolean) {
/* 1359 */     if (this.slots == null)
/* 1360 */       this.slots = new Slot[5]; 
/* 1361 */     int i = (paramInt & 0x7FFFFFFF) % this.slots.length;
/* 1362 */     int j = i;
/*      */     do {
/* 1364 */       Slot slot = this.slots[j];
/* 1365 */       if (slot == null) {
/* 1366 */         return addSlot(paramString, paramInt, paramBoolean);
/*      */       }
/* 1368 */       if (slot != REMOVED && slot.intKey == paramInt && (
/* 1369 */         slot.stringKey == paramString || (paramString != null && 
/* 1370 */         paramString.equals(slot.stringKey))))
/*      */       {
/* 1372 */         return j;
/*      */       }
/* 1374 */       if (++j != this.slots.length)
/* 1375 */         continue;  j = 0;
/* 1376 */     } while (j != i);
/* 1377 */     throw new RuntimeException("Hashtable internal error");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int addSlot(String paramString, int paramInt, boolean paramBoolean) {
/* 1390 */     if (this.count == -1)
/* 1391 */       throw Context.reportRuntimeError(
/* 1392 */           Context.getMessage("msg.add.sealed", null)); 
/* 1393 */     int i = (paramInt & 0x7FFFFFFF) % this.slots.length;
/* 1394 */     int j = i;
/*      */     do {
/* 1396 */       Slot slot = this.slots[j];
/* 1397 */       if (slot == null || slot == REMOVED) {
/* 1398 */         this.count++;
/* 1399 */         if (4 * this.count > 3 * this.slots.length) {
/* 1400 */           grow();
/* 1401 */           return getSlotToSet(paramString, paramInt, paramBoolean);
/*      */         } 
/* 1403 */         slot = paramBoolean ? new GetterSlot() : new Slot();
/* 1404 */         slot.stringKey = paramString;
/* 1405 */         slot.intKey = paramInt;
/* 1406 */         this.slots[j] = slot;
/* 1407 */         return j;
/*      */       } 
/* 1409 */       if (slot.intKey == paramInt && (
/* 1410 */         slot.stringKey == paramString || (paramString != null && 
/* 1411 */         paramString.equals(slot.stringKey))))
/*      */       {
/* 1413 */         return j;
/*      */       }
/* 1415 */       if (++j != this.slots.length)
/* 1416 */         continue;  j = 0;
/* 1417 */     } while (j != i);
/* 1418 */     throw new RuntimeException("Hashtable internal error");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeSlot(String paramString, int paramInt) {
/* 1429 */     if (this.count == -1)
/* 1430 */       throw Context.reportRuntimeError(
/* 1431 */           Context.getMessage("msg.remove.sealed", null)); 
/* 1432 */     int i = getSlot(paramString, paramInt);
/* 1433 */     if (i == -1)
/*      */       return; 
/* 1435 */     if (((this.slots[i]).attributes & 0x4) != 0)
/*      */       return; 
/* 1437 */     this.slots[i] = REMOVED;
/* 1438 */     this.count--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void grow() {
/* 1448 */     Slot[] arrayOfSlot = new Slot[this.slots.length * 2 + 1];
/* 1449 */     for (int i = this.slots.length - 1; i >= 0; i--) {
/* 1450 */       Slot slot = this.slots[i];
/* 1451 */       if (slot != null && slot != REMOVED) {
/*      */         
/* 1453 */         int j = (slot.intKey & 0x7FFFFFFF) % arrayOfSlot.length;
/* 1454 */         while (arrayOfSlot[j] != null) {
/* 1455 */           if (++j == arrayOfSlot.length) {
/* 1456 */             j = 0;
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1463 */         arrayOfSlot[j] = slot;
/*      */       } 
/* 1465 */     }  this.slots = arrayOfSlot;
/*      */   }
/*      */   
/*      */   private Function getFunctionProperty(FlattenedObject paramFlattenedObject, String paramString) {
/* 1469 */     Object object = paramFlattenedObject.getProperty(paramString);
/* 1470 */     if (object == null || !(object instanceof FlattenedObject))
/* 1471 */       return null; 
/* 1472 */     Scriptable scriptable = ((FlattenedObject)object).getObject();
/* 1473 */     if (scriptable instanceof Function)
/* 1474 */       return (Function)scriptable; 
/* 1475 */     return null;
/*      */   }
/*      */   
/*      */   private static Hashtable getExclusionList() {
/* 1479 */     if (exclusionList != null)
/* 1480 */       return exclusionList; 
/* 1481 */     Hashtable hashtable = new Hashtable(17);
/* 1482 */     Method[] arrayOfMethod = ScriptRuntime.FunctionClass.getMethods();
/* 1483 */     for (byte b = 0; b < arrayOfMethod.length; b++) {
/* 1484 */       hashtable.put(arrayOfMethod[b].getName(), Boolean.TRUE);
/*      */     }
/* 1486 */     exclusionList = hashtable;
/* 1487 */     return hashtable;
/*      */   }
/*      */   
/*      */   private Object[] getIds(boolean paramBoolean) {
/* 1491 */     if (this.slots == null)
/* 1492 */       return ScriptRuntime.emptyArgs; 
/* 1493 */     byte b = 0;
/* 1494 */     for (int i = this.slots.length - 1; i >= 0; i--) {
/* 1495 */       Slot slot = this.slots[i];
/* 1496 */       if (slot != null && slot != REMOVED)
/*      */       {
/* 1498 */         if (paramBoolean || (slot.attributes & 0x2) == 0)
/* 1499 */           b++;  } 
/*      */     } 
/* 1501 */     Object[] arrayOfObject = new Object[b];
/* 1502 */     for (int j = this.slots.length - 1; j >= 0; j--) {
/* 1503 */       Slot slot = this.slots[j];
/* 1504 */       if (slot != null && slot != REMOVED)
/*      */       {
/* 1506 */         if (paramBoolean || (slot.attributes & 0x2) == 0)
/* 1507 */           arrayOfObject[--b] = (slot.stringKey != null) ? 
/* 1508 */             slot.stringKey : 
/* 1509 */             new Integer(slot.intKey);  } 
/*      */     } 
/* 1511 */     return arrayOfObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1525 */   private static final Object HAS_STATIC_ACCESSORS = void.class;
/* 1526 */   private static final Slot REMOVED = new Slot();
/* 1527 */   private static Hashtable exclusionList = null;
/*      */   
/*      */   private Slot[] slots;
/*      */   
/*      */   private int count;
/*      */   
/*      */   private String lastName;
/*      */   private int lastHash;
/* 1535 */   private Object lastValue = REMOVED;
/*      */   static Class class$org$mozilla$javascript$FunctionObject;
/*      */   
/*      */   public abstract String getClassName();
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\ScriptableObject.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */