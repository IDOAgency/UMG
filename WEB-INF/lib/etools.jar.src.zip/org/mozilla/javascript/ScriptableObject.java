package org.mozilla.javascript;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Hashtable;

public abstract class ScriptableObject implements Scriptable {
  public static final int EMPTY = 0;
  
  public static final int READONLY = 1;
  
  public static final int DONTENUM = 2;
  
  public static final int PERMANENT = 4;
  
  private static final int SLOT_NOT_FOUND = -1;
  
  protected Scriptable prototype;
  
  protected Scriptable parent;
  
  public boolean has(String paramString, Scriptable paramScriptable) { return !(getSlot(paramString, paramString.hashCode()) == -1); }
  
  public boolean has(int paramInt, Scriptable paramScriptable) { return !(getSlot(null, paramInt) == -1); }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    int i;
    if (paramString == this.lastName) {
      if (this.lastValue != REMOVED)
        return this.lastValue; 
      i = this.lastHash;
    } else {
      i = paramString.hashCode();
    } 
    int j = getSlot(paramString, i);
    if (j == -1)
      return Scriptable.NOT_FOUND; 
    Slot slot = this.slots[j];
    if ((slot.flags & true) != 0) {
      GetterSlot getterSlot = (GetterSlot)slot;
      try {
        if (getterSlot.delegateTo == null) {
          Class clazz = getterSlot.getter.getDeclaringClass();
          while (!clazz.isInstance(paramScriptable)) {
            paramScriptable = paramScriptable.getPrototype();
            if (paramScriptable == null) {
              paramScriptable = this;
              break;
            } 
          } 
          return getterSlot.getter.invoke(paramScriptable, ScriptRuntime.emptyArgs);
        } 
        Object[] arrayOfObject = { this };
        return getterSlot.getter.invoke(getterSlot.delegateTo, arrayOfObject);
      } catch (InvocationTargetException invocationTargetException) {
        throw WrappedException.wrapException(invocationTargetException);
      } catch (IllegalAccessException illegalAccessException) {
        throw WrappedException.wrapException(illegalAccessException);
      } 
    } 
    this.lastValue = REMOVED;
    this.lastName = paramString;
    this.lastHash = i;
    this.lastValue = slot.value;
    return this.lastValue;
  }
  
  public Object get(int paramInt, Scriptable paramScriptable) {
    int i = getSlot(null, paramInt);
    if (i == -1)
      return Scriptable.NOT_FOUND; 
    return (this.slots[i]).value;
  }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
    int i = paramString.hashCode();
    int j = getSlot(paramString, i);
    if (j == -1) {
      if (paramScriptable != this) {
        paramScriptable.put(paramString, paramScriptable, paramObject);
        return;
      } 
      j = getSlotToSet(paramString, i, false);
    } 
    Slot slot = this.slots[j];
    if ((slot.attributes & true) != 0)
      return; 
    if ((slot.flags & 0x2) != 0) {
      GetterSlot getterSlot = (GetterSlot)slot;
      try {
        Class[] arrayOfClass = getterSlot.setter.getParameterTypes();
        Class clazz = arrayOfClass[arrayOfClass.length - 1];
        Object object = 
          FunctionObject.convertArg(paramScriptable, paramObject, clazz);
        if (getterSlot.delegateTo == null) {
          Object[] arrayOfObject1 = { object };
          Class clazz1 = getterSlot.setter.getDeclaringClass();
          while (!clazz1.isInstance(paramScriptable)) {
            paramScriptable = paramScriptable.getPrototype();
            if (paramScriptable == null) {
              paramScriptable = this;
              break;
            } 
          } 
          getterSlot.setter.invoke(paramScriptable, arrayOfObject1);
          return;
        } 
        Object[] arrayOfObject = { this, object };
        getterSlot.setter.invoke(getterSlot.delegateTo, arrayOfObject);
        return;
      } catch (InvocationTargetException invocationTargetException) {
        throw WrappedException.wrapException(invocationTargetException);
      } catch (IllegalAccessException illegalAccessException) {
        throw WrappedException.wrapException(illegalAccessException);
      } 
    } 
    if (this == paramScriptable) {
      slot.value = paramObject;
      this.lastValue = (paramString == this.lastName) ? paramObject : REMOVED;
    } else {
      paramScriptable.put(paramString, paramScriptable, paramObject);
    } 
  }
  
  public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
    int i = getSlot(null, paramInt);
    if (i == -1) {
      if (paramScriptable != this) {
        paramScriptable.put(paramInt, paramScriptable, paramObject);
        return;
      } 
      i = getSlotToSet(null, paramInt, false);
    } 
    Slot slot = this.slots[i];
    if ((slot.attributes & true) != 0)
      return; 
    if (this == paramScriptable) {
      slot.value = paramObject;
    } else {
      paramScriptable.put(paramInt, paramScriptable, paramObject);
    } 
  }
  
  public void delete(String paramString) {
    if (paramString.equals(this.lastName))
      this.lastValue = REMOVED; 
    removeSlot(paramString, paramString.hashCode());
  }
  
  public void delete(int paramInt) { removeSlot(null, paramInt); }
  
  public int getAttributes(String paramString, Scriptable paramScriptable) throws PropertyException {
    int i = getSlot(paramString, paramString.hashCode());
    if (i == -1)
      throw new PropertyException(
          Context.getMessage("msg.prop.not.found", null)); 
    return (this.slots[i]).attributes;
  }
  
  public int getAttributes(int paramInt, Scriptable paramScriptable) throws PropertyException {
    int i = getSlot(null, paramInt);
    if (i == -1)
      throw new PropertyException(
          Context.getMessage("msg.prop.not.found", null)); 
    return (this.slots[i]).attributes;
  }
  
  public void setAttributes(String paramString, Scriptable paramScriptable, int paramInt) throws PropertyException {
    byte b = 7;
    paramInt &= 0x7;
    int i = getSlot(paramString, paramString.hashCode());
    if (i == -1)
      throw new PropertyException(
          Context.getMessage("msg.prop.not.found", null)); 
    (this.slots[i]).attributes = (short)paramInt;
  }
  
  public void setAttributes(int paramInt1, Scriptable paramScriptable, int paramInt2) throws PropertyException {
    int i = getSlot(null, paramInt1);
    if (i == -1)
      throw new PropertyException(
          Context.getMessage("msg.prop.not.found", null)); 
    (this.slots[i]).attributes = (short)paramInt2;
  }
  
  public Scriptable getPrototype() { return this.prototype; }
  
  public void setPrototype(Scriptable paramScriptable) { this.prototype = paramScriptable; }
  
  public Scriptable getParentScope() { return this.parent; }
  
  public void setParentScope(Scriptable paramScriptable) { this.parent = paramScriptable; }
  
  public Object[] getIds() { return getIds(false); }
  
  public Object[] getAllIds() { return getIds(true); }
  
  public Object getDefaultValue(Class paramClass) {
    FlattenedObject flattenedObject = new FlattenedObject(this);
    Context context = null;
    try {
      for (byte b = 0; b < 2; b++) {
        Object object;
        if ((paramClass == ScriptRuntime.StringClass) ? (b == 0) : (b == 1)) {
          Function function = getFunctionProperty(flattenedObject, "toString");
          if (function != null) {
            if (context == null)
              context = Context.getContext(); 
            object = function.call(context, function.getParentScope(), flattenedObject.getObject(), 
                ScriptRuntime.emptyArgs);
          } else {
            continue;
          } 
        } else {
          String str1;
          if (paramClass == null) {
            str1 = "undefined";
          } else if (paramClass == ScriptRuntime.StringClass) {
            str1 = "string";
          } else if (paramClass == ScriptRuntime.ScriptableClass) {
            str1 = "object";
          } else if (paramClass == ScriptRuntime.FunctionClass) {
            str1 = "function";
          } else if (paramClass == ScriptRuntime.BooleanClass || 
            paramClass == boolean.class) {
            str1 = "boolean";
          } else if (paramClass == ScriptRuntime.NumberClass || 
            paramClass == ScriptRuntime.ByteClass || 
            paramClass == byte.class || 
            paramClass == ScriptRuntime.ShortClass || 
            paramClass == short.class || 
            paramClass == ScriptRuntime.IntegerClass || 
            paramClass == int.class || 
            paramClass == ScriptRuntime.FloatClass || 
            paramClass == float.class || 
            paramClass == ScriptRuntime.DoubleClass || 
            paramClass == double.class) {
            str1 = "number";
          } else {
            Object[] arrayOfObject1 = { paramClass.toString() };
            throw Context.reportRuntimeError(
                Context.getMessage("msg.invalid.type", arrayOfObject1));
          } 
          Function function = getFunctionProperty(flattenedObject, "valueOf");
          if (function != null) {
            Object[] arrayOfObject1 = { str1 };
            if (context == null)
              context = Context.getContext(); 
            object = function.call(context, function.getParentScope(), flattenedObject.getObject(), 
                arrayOfObject1);
          } else {
            continue;
          } 
        } 
        if (object != null && (object == Undefined.instance || 
          !(object instanceof Scriptable) || 
          paramClass == Scriptable.class || 
          paramClass == Function.class))
          return object; 
        if (object instanceof NativeJavaObject) {
          Object object1 = ((Wrapper)object).unwrap();
          if (object1 instanceof String)
            return object1; 
        } 
        continue;
      } 
    } catch (JavaScriptException javaScriptException) {}
    String str = (paramClass == null) ? "undefined" : paramClass.toString();
    Object[] arrayOfObject = { str };
    throw NativeGlobal.constructError(
        Context.getContext(), "TypeError", 
        ScriptRuntime.getMessage("msg.default.value", arrayOfObject), 
        this);
  }
  
  public boolean hasInstance(Scriptable paramScriptable) { return ScriptRuntime.jsDelegatesTo(paramScriptable, this); }
  
  public static void defineClass(Scriptable paramScriptable, Class paramClass) throws IllegalAccessException, InstantiationException, InvocationTargetException, ClassDefinitionException, PropertyException { defineClass(paramScriptable, paramClass, false); }
  
  public static void defineClass(Scriptable paramScriptable, Class paramClass, boolean paramBoolean) throws IllegalAccessException, InstantiationException, InvocationTargetException, ClassDefinitionException, PropertyException { // Byte code:
    //   0: aload_1
    //   1: invokestatic getMethodList : (Ljava/lang/Class;)[Ljava/lang/reflect/Method;
    //   4: astore_3
    //   5: iconst_0
    //   6: istore #4
    //   8: goto -> 90
    //   11: aload_3
    //   12: iload #4
    //   14: aaload
    //   15: invokevirtual getName : ()Ljava/lang/String;
    //   18: ldc 'init'
    //   20: invokevirtual equals : (Ljava/lang/Object;)Z
    //   23: ifeq -> 87
    //   26: aload_3
    //   27: iload #4
    //   29: aaload
    //   30: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
    //   33: astore #5
    //   35: aload #5
    //   37: arraylength
    //   38: iconst_1
    //   39: if_icmpne -> 87
    //   42: aload #5
    //   44: iconst_0
    //   45: aaload
    //   46: getstatic org/mozilla/javascript/ScriptRuntime.ScriptableClass : Ljava/lang/Class;
    //   49: if_acmpne -> 87
    //   52: aload_3
    //   53: iload #4
    //   55: aaload
    //   56: invokevirtual getModifiers : ()I
    //   59: invokestatic isStatic : (I)Z
    //   62: ifeq -> 87
    //   65: iconst_1
    //   66: anewarray java/lang/Object
    //   69: dup
    //   70: iconst_0
    //   71: aload_0
    //   72: aastore
    //   73: astore #6
    //   75: aload_3
    //   76: iload #4
    //   78: aaload
    //   79: aconst_null
    //   80: aload #6
    //   82: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   85: pop
    //   86: return
    //   87: iinc #4, 1
    //   90: iload #4
    //   92: aload_3
    //   93: arraylength
    //   94: if_icmplt -> 11
    //   97: invokestatic getExclusionList : ()Ljava/util/Hashtable;
    //   100: astore #5
    //   102: aload_1
    //   103: invokevirtual getConstructors : ()[Ljava/lang/reflect/Constructor;
    //   106: astore #6
    //   108: aconst_null
    //   109: astore #7
    //   111: iconst_0
    //   112: istore #8
    //   114: goto -> 142
    //   117: aload #6
    //   119: iload #8
    //   121: aaload
    //   122: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
    //   125: arraylength
    //   126: ifne -> 139
    //   129: aload #6
    //   131: iload #8
    //   133: aaload
    //   134: astore #7
    //   136: goto -> 150
    //   139: iinc #8, 1
    //   142: iload #8
    //   144: aload #6
    //   146: arraylength
    //   147: if_icmplt -> 117
    //   150: aload #7
    //   152: ifnonnull -> 183
    //   155: iconst_1
    //   156: anewarray java/lang/Object
    //   159: dup
    //   160: iconst_0
    //   161: aload_1
    //   162: invokevirtual getName : ()Ljava/lang/String;
    //   165: aastore
    //   166: astore #9
    //   168: new org/mozilla/javascript/ClassDefinitionException
    //   171: dup
    //   172: ldc 'msg.zero.arg.ctor'
    //   174: aload #9
    //   176: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   179: invokespecial <init> : (Ljava/lang/String;)V
    //   182: athrow
    //   183: aload #7
    //   185: getstatic org/mozilla/javascript/ScriptRuntime.emptyArgs : [Ljava/lang/Object;
    //   188: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
    //   191: checkcast org/mozilla/javascript/Scriptable
    //   194: astore #9
    //   196: aload #9
    //   198: aload_0
    //   199: invokestatic getObjectPrototype : (Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;
    //   202: invokeinterface setPrototype : (Lorg/mozilla/javascript/Scriptable;)V
    //   207: aload #9
    //   209: invokeinterface getClassName : ()Ljava/lang/String;
    //   214: astore #10
    //   216: ldc 'js_'
    //   218: astore #11
    //   220: ldc 'jsFunction_'
    //   222: astore #12
    //   224: ldc 'jsStaticFunction_'
    //   226: astore #13
    //   228: ldc 'jsProperty_'
    //   230: astore #14
    //   232: ldc 'jsGet_'
    //   234: astore #15
    //   236: ldc 'jsSet_'
    //   238: astore #16
    //   240: ldc 'jsConstructor'
    //   242: astore #17
    //   244: aload_1
    //   245: ldc 'jsConstructor'
    //   247: invokestatic findMethods : (Ljava/lang/Class;Ljava/lang/String;)[Ljava/lang/reflect/Method;
    //   250: astore #18
    //   252: aconst_null
    //   253: astore #19
    //   255: aload #18
    //   257: ifnull -> 308
    //   260: aload #18
    //   262: arraylength
    //   263: iconst_1
    //   264: if_icmple -> 302
    //   267: iconst_2
    //   268: anewarray java/lang/Object
    //   271: dup
    //   272: iconst_0
    //   273: aload #18
    //   275: iconst_0
    //   276: aaload
    //   277: aastore
    //   278: dup
    //   279: iconst_1
    //   280: aload #18
    //   282: iconst_1
    //   283: aaload
    //   284: aastore
    //   285: astore #20
    //   287: new org/mozilla/javascript/ClassDefinitionException
    //   290: dup
    //   291: ldc 'msg.multiple.ctors'
    //   293: aload #20
    //   295: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   298: invokespecial <init> : (Ljava/lang/String;)V
    //   301: athrow
    //   302: aload #18
    //   304: iconst_0
    //   305: aaload
    //   306: astore #19
    //   308: iconst_0
    //   309: istore #20
    //   311: iconst_0
    //   312: istore #21
    //   314: goto -> 521
    //   317: aload_3
    //   318: iload #21
    //   320: aaload
    //   321: invokevirtual getName : ()Ljava/lang/String;
    //   324: astore #22
    //   326: aconst_null
    //   327: astore #23
    //   329: aload #22
    //   331: ldc 'js'
    //   333: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   336: ifne -> 345
    //   339: aconst_null
    //   340: astore #23
    //   342: goto -> 444
    //   345: aload #22
    //   347: ldc 'js_'
    //   349: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   352: ifeq -> 362
    //   355: ldc 'js_'
    //   357: astore #23
    //   359: goto -> 444
    //   362: aload #22
    //   364: ldc 'jsFunction_'
    //   366: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   369: ifeq -> 379
    //   372: ldc 'jsFunction_'
    //   374: astore #23
    //   376: goto -> 444
    //   379: aload #22
    //   381: ldc 'jsStaticFunction_'
    //   383: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   386: ifeq -> 396
    //   389: ldc 'jsStaticFunction_'
    //   391: astore #23
    //   393: goto -> 444
    //   396: aload #22
    //   398: ldc 'jsProperty_'
    //   400: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   403: ifeq -> 413
    //   406: ldc 'jsProperty_'
    //   408: astore #23
    //   410: goto -> 444
    //   413: aload #22
    //   415: ldc 'jsGet_'
    //   417: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   420: ifeq -> 430
    //   423: ldc 'jsGet_'
    //   425: astore #23
    //   427: goto -> 444
    //   430: aload #22
    //   432: ldc 'jsSet_'
    //   434: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   437: ifeq -> 444
    //   440: ldc 'jsSet_'
    //   442: astore #23
    //   444: aload #23
    //   446: ifnull -> 464
    //   449: iconst_1
    //   450: istore #20
    //   452: aload #22
    //   454: aload #23
    //   456: invokevirtual length : ()I
    //   459: invokevirtual substring : (I)Ljava/lang/String;
    //   462: astore #22
    //   464: aload #22
    //   466: aload #10
    //   468: invokevirtual equals : (Ljava/lang/Object;)Z
    //   471: ifeq -> 518
    //   474: aload #19
    //   476: ifnull -> 512
    //   479: iconst_2
    //   480: anewarray java/lang/Object
    //   483: dup
    //   484: iconst_0
    //   485: aload #19
    //   487: aastore
    //   488: dup
    //   489: iconst_1
    //   490: aload_3
    //   491: iload #21
    //   493: aaload
    //   494: aastore
    //   495: astore #24
    //   497: new org/mozilla/javascript/ClassDefinitionException
    //   500: dup
    //   501: ldc 'msg.multiple.ctors'
    //   503: aload #24
    //   505: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   508: invokespecial <init> : (Ljava/lang/String;)V
    //   511: athrow
    //   512: aload_3
    //   513: iload #21
    //   515: aaload
    //   516: astore #19
    //   518: iinc #21, 1
    //   521: iload #21
    //   523: aload_3
    //   524: arraylength
    //   525: if_icmplt -> 317
    //   528: aload #19
    //   530: ifnonnull -> 626
    //   533: aload #6
    //   535: arraylength
    //   536: iconst_1
    //   537: if_icmpne -> 549
    //   540: aload #6
    //   542: iconst_0
    //   543: aaload
    //   544: astore #19
    //   546: goto -> 593
    //   549: aload #6
    //   551: arraylength
    //   552: iconst_2
    //   553: if_icmpne -> 593
    //   556: aload #6
    //   558: iconst_0
    //   559: aaload
    //   560: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
    //   563: arraylength
    //   564: ifne -> 576
    //   567: aload #6
    //   569: iconst_1
    //   570: aaload
    //   571: astore #19
    //   573: goto -> 593
    //   576: aload #6
    //   578: iconst_1
    //   579: aaload
    //   580: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
    //   583: arraylength
    //   584: ifne -> 593
    //   587: aload #6
    //   589: iconst_0
    //   590: aaload
    //   591: astore #19
    //   593: aload #19
    //   595: ifnonnull -> 626
    //   598: iconst_1
    //   599: anewarray java/lang/Object
    //   602: dup
    //   603: iconst_0
    //   604: aload_1
    //   605: invokevirtual getName : ()Ljava/lang/String;
    //   608: aastore
    //   609: astore #22
    //   611: new org/mozilla/javascript/ClassDefinitionException
    //   614: dup
    //   615: ldc 'msg.ctor.multiple.parms'
    //   617: aload #22
    //   619: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   622: invokespecial <init> : (Ljava/lang/String;)V
    //   625: athrow
    //   626: new org/mozilla/javascript/FunctionObject
    //   629: dup
    //   630: aload #10
    //   632: aload #19
    //   634: aload_0
    //   635: invokespecial <init> : (Ljava/lang/String;Ljava/lang/reflect/Member;Lorg/mozilla/javascript/Scriptable;)V
    //   638: astore #22
    //   640: aload #22
    //   642: invokevirtual isVarArgsMethod : ()Z
    //   645: ifeq -> 679
    //   648: iconst_1
    //   649: anewarray java/lang/Object
    //   652: dup
    //   653: iconst_0
    //   654: aload #19
    //   656: invokeinterface getName : ()Ljava/lang/String;
    //   661: aastore
    //   662: astore #23
    //   664: ldc 'msg.varargs.ctor'
    //   666: aload #23
    //   668: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   671: astore #24
    //   673: aload #24
    //   675: invokestatic reportRuntimeError : (Ljava/lang/String;)Lorg/mozilla/javascript/EvaluatorException;
    //   678: athrow
    //   679: aload #22
    //   681: aload_0
    //   682: aload #9
    //   684: invokevirtual addAsConstructor : (Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;)V
    //   687: iload #20
    //   689: ifne -> 702
    //   692: aload #5
    //   694: ifnonnull -> 702
    //   697: invokestatic getExclusionList : ()Ljava/util/Hashtable;
    //   700: astore #5
    //   702: aconst_null
    //   703: astore #23
    //   705: iconst_0
    //   706: istore #24
    //   708: goto -> 1683
    //   711: iload #20
    //   713: ifne -> 727
    //   716: aload_3
    //   717: iload #24
    //   719: aaload
    //   720: invokevirtual getDeclaringClass : ()Ljava/lang/Class;
    //   723: aload_1
    //   724: if_acmpne -> 1680
    //   727: aload_3
    //   728: iload #24
    //   730: aaload
    //   731: invokevirtual getName : ()Ljava/lang/String;
    //   734: astore #25
    //   736: aload #25
    //   738: ldc 'finishInit'
    //   740: invokevirtual equals : (Ljava/lang/Object;)Z
    //   743: ifeq -> 832
    //   746: aload_3
    //   747: iload #24
    //   749: aaload
    //   750: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
    //   753: astore #26
    //   755: aload #26
    //   757: arraylength
    //   758: iconst_3
    //   759: if_icmpne -> 832
    //   762: aload #26
    //   764: iconst_0
    //   765: aaload
    //   766: getstatic org/mozilla/javascript/ScriptRuntime.ScriptableClass : Ljava/lang/Class;
    //   769: if_acmpne -> 832
    //   772: aload #26
    //   774: iconst_1
    //   775: aaload
    //   776: getstatic org/mozilla/javascript/ScriptableObject.class$org$mozilla$javascript$FunctionObject : Ljava/lang/Class;
    //   779: ifnull -> 788
    //   782: getstatic org/mozilla/javascript/ScriptableObject.class$org$mozilla$javascript$FunctionObject : Ljava/lang/Class;
    //   785: goto -> 797
    //   788: ldc 'org.mozilla.javascript.FunctionObject'
    //   790: invokestatic class$ : (Ljava/lang/String;)Ljava/lang/Class;
    //   793: dup
    //   794: putstatic org/mozilla/javascript/ScriptableObject.class$org$mozilla$javascript$FunctionObject : Ljava/lang/Class;
    //   797: if_acmpne -> 832
    //   800: aload #26
    //   802: iconst_2
    //   803: aaload
    //   804: getstatic org/mozilla/javascript/ScriptRuntime.ScriptableClass : Ljava/lang/Class;
    //   807: if_acmpne -> 832
    //   810: aload_3
    //   811: iload #24
    //   813: aaload
    //   814: invokevirtual getModifiers : ()I
    //   817: invokestatic isStatic : (I)Z
    //   820: ifeq -> 832
    //   823: aload_3
    //   824: iload #24
    //   826: aaload
    //   827: astore #23
    //   829: goto -> 1680
    //   832: aload #25
    //   834: ldc 'jsConstructor'
    //   836: invokevirtual equals : (Ljava/lang/Object;)Z
    //   839: ifne -> 1680
    //   842: aconst_null
    //   843: astore #26
    //   845: iload #20
    //   847: ifeq -> 987
    //   850: aload #25
    //   852: ldc 'js_'
    //   854: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   857: ifeq -> 867
    //   860: ldc 'js_'
    //   862: astore #26
    //   864: goto -> 972
    //   867: aload #25
    //   869: ldc 'jsFunction_'
    //   871: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   874: ifeq -> 884
    //   877: ldc 'jsFunction_'
    //   879: astore #26
    //   881: goto -> 972
    //   884: aload #25
    //   886: ldc 'jsStaticFunction_'
    //   888: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   891: ifeq -> 921
    //   894: ldc 'jsStaticFunction_'
    //   896: astore #26
    //   898: aload_3
    //   899: iload #24
    //   901: aaload
    //   902: invokevirtual getModifiers : ()I
    //   905: invokestatic isStatic : (I)Z
    //   908: ifne -> 972
    //   911: new org/mozilla/javascript/ClassDefinitionException
    //   914: dup
    //   915: ldc 'jsStaticFunction must be used with static method.'
    //   917: invokespecial <init> : (Ljava/lang/String;)V
    //   920: athrow
    //   921: aload #25
    //   923: ldc 'jsProperty_'
    //   925: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   928: ifeq -> 938
    //   931: ldc 'jsProperty_'
    //   933: astore #26
    //   935: goto -> 972
    //   938: aload #25
    //   940: ldc 'jsGet_'
    //   942: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   945: ifeq -> 955
    //   948: ldc 'jsGet_'
    //   950: astore #26
    //   952: goto -> 972
    //   955: aload #25
    //   957: ldc 'jsSet_'
    //   959: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   962: ifeq -> 1680
    //   965: ldc 'jsSet_'
    //   967: astore #26
    //   969: goto -> 972
    //   972: aload #25
    //   974: aload #26
    //   976: invokevirtual length : ()I
    //   979: invokevirtual substring : (I)Ljava/lang/String;
    //   982: astore #25
    //   984: goto -> 1000
    //   987: aload #5
    //   989: aload #25
    //   991: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   994: ifnull -> 1000
    //   997: goto -> 1680
    //   1000: aload_3
    //   1001: iload #24
    //   1003: aaload
    //   1004: aload #19
    //   1006: if_acmpeq -> 1680
    //   1009: aload #26
    //   1011: ifnull -> 1024
    //   1014: aload #26
    //   1016: ldc 'jsSet_'
    //   1018: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1021: ifne -> 1680
    //   1024: aload #26
    //   1026: ifnull -> 1204
    //   1029: aload #26
    //   1031: ldc 'jsGet_'
    //   1033: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1036: ifeq -> 1204
    //   1039: aload #9
    //   1041: instanceof org/mozilla/javascript/ScriptableObject
    //   1044: ifne -> 1084
    //   1047: iconst_2
    //   1048: anewarray java/lang/Object
    //   1051: dup
    //   1052: iconst_0
    //   1053: aload #9
    //   1055: invokevirtual getClass : ()Ljava/lang/Class;
    //   1058: invokevirtual toString : ()Ljava/lang/String;
    //   1061: aastore
    //   1062: dup
    //   1063: iconst_1
    //   1064: aload #25
    //   1066: aastore
    //   1067: astore #27
    //   1069: new org/mozilla/javascript/PropertyException
    //   1072: dup
    //   1073: ldc 'msg.extend.scriptable'
    //   1075: aload #27
    //   1077: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   1080: invokespecial <init> : (Ljava/lang/String;)V
    //   1083: athrow
    //   1084: aload_1
    //   1085: new java/lang/StringBuffer
    //   1088: dup
    //   1089: ldc 'jsSet_'
    //   1091: invokespecial <init> : (Ljava/lang/String;)V
    //   1094: aload #25
    //   1096: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1099: invokevirtual toString : ()Ljava/lang/String;
    //   1102: invokestatic findMethods : (Ljava/lang/Class;Ljava/lang/String;)[Ljava/lang/reflect/Method;
    //   1105: astore #27
    //   1107: aload #27
    //   1109: ifnull -> 1152
    //   1112: aload #27
    //   1114: arraylength
    //   1115: iconst_1
    //   1116: if_icmpeq -> 1152
    //   1119: iconst_2
    //   1120: anewarray java/lang/Object
    //   1123: dup
    //   1124: iconst_0
    //   1125: aload #25
    //   1127: aastore
    //   1128: dup
    //   1129: iconst_1
    //   1130: aload_1
    //   1131: invokevirtual getName : ()Ljava/lang/String;
    //   1134: aastore
    //   1135: astore #28
    //   1137: new org/mozilla/javascript/PropertyException
    //   1140: dup
    //   1141: ldc 'msg.no.overload'
    //   1143: aload #28
    //   1145: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   1148: invokespecial <init> : (Ljava/lang/String;)V
    //   1151: athrow
    //   1152: bipush #6
    //   1154: aload #27
    //   1156: ifnull -> 1163
    //   1159: iconst_0
    //   1160: goto -> 1164
    //   1163: iconst_1
    //   1164: ior
    //   1165: istore #28
    //   1167: aload #27
    //   1169: ifnonnull -> 1176
    //   1172: aconst_null
    //   1173: goto -> 1180
    //   1176: aload #27
    //   1178: iconst_0
    //   1179: aaload
    //   1180: astore #29
    //   1182: aload #9
    //   1184: checkcast org/mozilla/javascript/ScriptableObject
    //   1187: aload #25
    //   1189: aconst_null
    //   1190: aload_3
    //   1191: iload #24
    //   1193: aaload
    //   1194: aload #29
    //   1196: iload #28
    //   1198: invokevirtual defineProperty : (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;I)V
    //   1201: goto -> 1680
    //   1204: aload #25
    //   1206: ldc 'get'
    //   1208: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   1211: ifne -> 1224
    //   1214: aload #25
    //   1216: ldc 'set'
    //   1218: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   1221: ifeq -> 1556
    //   1224: aload #25
    //   1226: invokevirtual length : ()I
    //   1229: iconst_3
    //   1230: if_icmple -> 1556
    //   1233: iload #20
    //   1235: ifeq -> 1258
    //   1238: aload #26
    //   1240: ldc 'jsFunction_'
    //   1242: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1245: ifne -> 1556
    //   1248: aload #26
    //   1250: ldc 'jsStaticFunction_'
    //   1252: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1255: ifne -> 1556
    //   1258: aload #9
    //   1260: instanceof org/mozilla/javascript/ScriptableObject
    //   1263: ifne -> 1303
    //   1266: iconst_2
    //   1267: anewarray java/lang/Object
    //   1270: dup
    //   1271: iconst_0
    //   1272: aload #9
    //   1274: invokevirtual getClass : ()Ljava/lang/Class;
    //   1277: invokevirtual toString : ()Ljava/lang/String;
    //   1280: aastore
    //   1281: dup
    //   1282: iconst_1
    //   1283: aload #25
    //   1285: aastore
    //   1286: astore #27
    //   1288: new org/mozilla/javascript/PropertyException
    //   1291: dup
    //   1292: ldc 'msg.extend.scriptable'
    //   1294: aload #27
    //   1296: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   1299: invokespecial <init> : (Ljava/lang/String;)V
    //   1302: athrow
    //   1303: aload #25
    //   1305: ldc 'set'
    //   1307: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   1310: ifne -> 1680
    //   1313: new java/lang/StringBuffer
    //   1316: dup
    //   1317: invokespecial <init> : ()V
    //   1320: astore #27
    //   1322: aload #25
    //   1324: iconst_3
    //   1325: invokevirtual charAt : (I)C
    //   1328: istore #28
    //   1330: aload #27
    //   1332: iload #28
    //   1334: invokestatic toLowerCase : (C)C
    //   1337: invokevirtual append : (C)Ljava/lang/StringBuffer;
    //   1340: pop
    //   1341: aload #25
    //   1343: invokevirtual length : ()I
    //   1346: iconst_4
    //   1347: if_icmple -> 1362
    //   1350: aload #27
    //   1352: aload #25
    //   1354: iconst_4
    //   1355: invokevirtual substring : (I)Ljava/lang/String;
    //   1358: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1361: pop
    //   1362: aload #27
    //   1364: invokevirtual toString : ()Ljava/lang/String;
    //   1367: astore #29
    //   1369: aload #27
    //   1371: iconst_0
    //   1372: iload #28
    //   1374: invokevirtual setCharAt : (IC)V
    //   1377: aload #27
    //   1379: iconst_0
    //   1380: ldc 'set'
    //   1382: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuffer;
    //   1385: pop
    //   1386: aload #27
    //   1388: invokevirtual toString : ()Ljava/lang/String;
    //   1391: astore #30
    //   1393: aload_1
    //   1394: iload #20
    //   1396: ifeq -> 1419
    //   1399: new java/lang/StringBuffer
    //   1402: dup
    //   1403: ldc 'js_'
    //   1405: invokespecial <init> : (Ljava/lang/String;)V
    //   1408: aload #30
    //   1410: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1413: invokevirtual toString : ()Ljava/lang/String;
    //   1416: goto -> 1421
    //   1419: aload #30
    //   1421: invokestatic findMethods : (Ljava/lang/Class;Ljava/lang/String;)[Ljava/lang/reflect/Method;
    //   1424: astore #31
    //   1426: aload #31
    //   1428: ifnull -> 1471
    //   1431: aload #31
    //   1433: arraylength
    //   1434: iconst_1
    //   1435: if_icmpeq -> 1471
    //   1438: iconst_2
    //   1439: anewarray java/lang/Object
    //   1442: dup
    //   1443: iconst_0
    //   1444: aload #25
    //   1446: aastore
    //   1447: dup
    //   1448: iconst_1
    //   1449: aload_1
    //   1450: invokevirtual getName : ()Ljava/lang/String;
    //   1453: aastore
    //   1454: astore #32
    //   1456: new org/mozilla/javascript/PropertyException
    //   1459: dup
    //   1460: ldc 'msg.no.overload'
    //   1462: aload #32
    //   1464: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   1467: invokespecial <init> : (Ljava/lang/String;)V
    //   1470: athrow
    //   1471: aload #31
    //   1473: ifnonnull -> 1504
    //   1476: iload #20
    //   1478: ifeq -> 1504
    //   1481: aload_1
    //   1482: new java/lang/StringBuffer
    //   1485: dup
    //   1486: ldc 'jsProperty_'
    //   1488: invokespecial <init> : (Ljava/lang/String;)V
    //   1491: aload #30
    //   1493: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   1496: invokevirtual toString : ()Ljava/lang/String;
    //   1499: invokestatic findMethods : (Ljava/lang/Class;Ljava/lang/String;)[Ljava/lang/reflect/Method;
    //   1502: astore #31
    //   1504: bipush #6
    //   1506: aload #31
    //   1508: ifnull -> 1515
    //   1511: iconst_0
    //   1512: goto -> 1516
    //   1515: iconst_1
    //   1516: ior
    //   1517: istore #32
    //   1519: aload #31
    //   1521: ifnonnull -> 1528
    //   1524: aconst_null
    //   1525: goto -> 1532
    //   1528: aload #31
    //   1530: iconst_0
    //   1531: aaload
    //   1532: astore #33
    //   1534: aload #9
    //   1536: checkcast org/mozilla/javascript/ScriptableObject
    //   1539: aload #29
    //   1541: aconst_null
    //   1542: aload_3
    //   1543: iload #24
    //   1545: aaload
    //   1546: aload #33
    //   1548: iload #32
    //   1550: invokevirtual defineProperty : (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;I)V
    //   1553: goto -> 1680
    //   1556: new org/mozilla/javascript/FunctionObject
    //   1559: dup
    //   1560: aload #25
    //   1562: aload_3
    //   1563: iload #24
    //   1565: aaload
    //   1566: aload #9
    //   1568: invokespecial <init> : (Ljava/lang/String;Ljava/lang/reflect/Member;Lorg/mozilla/javascript/Scriptable;)V
    //   1571: astore #27
    //   1573: aload #27
    //   1575: invokevirtual isVarArgsConstructor : ()Z
    //   1578: ifeq -> 1612
    //   1581: iconst_1
    //   1582: anewarray java/lang/Object
    //   1585: dup
    //   1586: iconst_0
    //   1587: aload #19
    //   1589: invokeinterface getName : ()Ljava/lang/String;
    //   1594: aastore
    //   1595: astore #28
    //   1597: ldc 'msg.varargs.fun'
    //   1599: aload #28
    //   1601: invokestatic getMessage : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   1604: astore #29
    //   1606: aload #29
    //   1608: invokestatic reportRuntimeError : (Ljava/lang/String;)Lorg/mozilla/javascript/EvaluatorException;
    //   1611: athrow
    //   1612: aload #26
    //   1614: ldc 'jsStaticFunction_'
    //   1616: if_acmpne -> 1624
    //   1619: aload #22
    //   1621: goto -> 1626
    //   1624: aload #9
    //   1626: astore #28
    //   1628: aload #28
    //   1630: instanceof org/mozilla/javascript/ScriptableObject
    //   1633: ifeq -> 1652
    //   1636: aload #28
    //   1638: checkcast org/mozilla/javascript/ScriptableObject
    //   1641: aload #25
    //   1643: aload #27
    //   1645: iconst_2
    //   1646: invokevirtual defineProperty : (Ljava/lang/String;Ljava/lang/Object;I)V
    //   1649: goto -> 1665
    //   1652: aload #28
    //   1654: aload #25
    //   1656: aload #28
    //   1658: aload #27
    //   1660: invokeinterface put : (Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)V
    //   1665: iload_2
    //   1666: ifeq -> 1680
    //   1669: aload #27
    //   1671: invokevirtual sealObject : ()V
    //   1674: aload #27
    //   1676: iconst_1
    //   1677: invokevirtual addPropertyAttribute : (I)V
    //   1680: iinc #24, 1
    //   1683: iload #24
    //   1685: aload_3
    //   1686: arraylength
    //   1687: if_icmplt -> 711
    //   1690: aload #23
    //   1692: ifnull -> 1724
    //   1695: iconst_3
    //   1696: anewarray java/lang/Object
    //   1699: dup
    //   1700: iconst_0
    //   1701: aload_0
    //   1702: aastore
    //   1703: dup
    //   1704: iconst_1
    //   1705: aload #22
    //   1707: aastore
    //   1708: dup
    //   1709: iconst_2
    //   1710: aload #9
    //   1712: aastore
    //   1713: astore #25
    //   1715: aload #23
    //   1717: aconst_null
    //   1718: aload #25
    //   1720: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   1723: pop
    //   1724: iload_2
    //   1725: ifeq -> 1764
    //   1728: aload #22
    //   1730: invokevirtual sealObject : ()V
    //   1733: aload #22
    //   1735: iconst_1
    //   1736: invokevirtual addPropertyAttribute : (I)V
    //   1739: aload #9
    //   1741: instanceof org/mozilla/javascript/ScriptableObject
    //   1744: ifeq -> 1764
    //   1747: aload #9
    //   1749: checkcast org/mozilla/javascript/ScriptableObject
    //   1752: invokevirtual sealObject : ()V
    //   1755: aload #9
    //   1757: checkcast org/mozilla/javascript/ScriptableObject
    //   1760: iconst_1
    //   1761: invokevirtual addPropertyAttribute : (I)V
    //   1764: return
    // Line number table:
    //   Java source line number -> byte code offset
    //   #747	-> 0
    //   #748	-> 5
    //   #749	-> 11
    //   #751	-> 26
    //   #752	-> 35
    //   #753	-> 42
    //   #754	-> 52
    //   #756	-> 65
    //   #757	-> 75
    //   #758	-> 86
    //   #748	-> 87
    //   #764	-> 97
    //   #766	-> 102
    //   #767	-> 108
    //   #768	-> 111
    //   #769	-> 117
    //   #770	-> 129
    //   #771	-> 136
    //   #768	-> 139
    //   #774	-> 150
    //   #775	-> 155
    //   #776	-> 168
    //   #777	-> 172
    //   #776	-> 179
    //   #781	-> 183
    //   #780	-> 191
    //   #782	-> 196
    //   #783	-> 207
    //   #789	-> 216
    //   #790	-> 220
    //   #791	-> 224
    //   #792	-> 228
    //   #793	-> 232
    //   #794	-> 236
    //   #795	-> 240
    //   #797	-> 244
    //   #795	-> 245
    //   #797	-> 247
    //   #798	-> 252
    //   #799	-> 255
    //   #800	-> 260
    //   #801	-> 267
    //   #802	-> 287
    //   #803	-> 291
    //   #802	-> 298
    //   #805	-> 302
    //   #810	-> 308
    //   #811	-> 311
    //   #812	-> 317
    //   #813	-> 326
    //   #814	-> 329
    //   #815	-> 339
    //   #814	-> 342
    //   #816	-> 345
    //   #789	-> 347
    //   #816	-> 349
    //   #789	-> 355
    //   #817	-> 357
    //   #816	-> 359
    //   #818	-> 362
    //   #790	-> 364
    //   #818	-> 366
    //   #790	-> 372
    //   #819	-> 374
    //   #818	-> 376
    //   #820	-> 379
    //   #791	-> 381
    //   #820	-> 383
    //   #791	-> 389
    //   #821	-> 391
    //   #820	-> 393
    //   #822	-> 396
    //   #792	-> 398
    //   #822	-> 400
    //   #792	-> 406
    //   #823	-> 408
    //   #822	-> 410
    //   #824	-> 413
    //   #793	-> 415
    //   #824	-> 417
    //   #793	-> 423
    //   #825	-> 425
    //   #824	-> 427
    //   #826	-> 430
    //   #794	-> 432
    //   #826	-> 434
    //   #794	-> 440
    //   #827	-> 442
    //   #828	-> 444
    //   #829	-> 449
    //   #830	-> 452
    //   #832	-> 464
    //   #833	-> 474
    //   #834	-> 479
    //   #835	-> 497
    //   #836	-> 501
    //   #835	-> 508
    //   #838	-> 512
    //   #811	-> 518
    //   #842	-> 528
    //   #843	-> 533
    //   #844	-> 540
    //   #843	-> 546
    //   #845	-> 549
    //   #846	-> 556
    //   #847	-> 567
    //   #846	-> 573
    //   #848	-> 576
    //   #849	-> 587
    //   #851	-> 593
    //   #852	-> 598
    //   #853	-> 611
    //   #854	-> 615
    //   #853	-> 622
    //   #858	-> 626
    //   #859	-> 640
    //   #860	-> 648
    //   #861	-> 664
    //   #862	-> 673
    //   #864	-> 679
    //   #866	-> 687
    //   #867	-> 697
    //   #868	-> 702
    //   #869	-> 705
    //   #870	-> 711
    //   #872	-> 727
    //   #873	-> 736
    //   #874	-> 746
    //   #875	-> 755
    //   #876	-> 762
    //   #877	-> 772
    //   #878	-> 800
    //   #879	-> 810
    //   #881	-> 823
    //   #882	-> 829
    //   #885	-> 832
    //   #795	-> 834
    //   #885	-> 836
    //   #887	-> 842
    //   #888	-> 845
    //   #889	-> 850
    //   #789	-> 852
    //   #889	-> 854
    //   #789	-> 860
    //   #890	-> 862
    //   #889	-> 864
    //   #891	-> 867
    //   #790	-> 869
    //   #891	-> 871
    //   #790	-> 877
    //   #892	-> 879
    //   #891	-> 881
    //   #893	-> 884
    //   #791	-> 886
    //   #893	-> 888
    //   #791	-> 894
    //   #894	-> 896
    //   #895	-> 898
    //   #896	-> 911
    //   #897	-> 915
    //   #896	-> 917
    //   #899	-> 921
    //   #792	-> 923
    //   #899	-> 925
    //   #792	-> 931
    //   #900	-> 933
    //   #899	-> 935
    //   #901	-> 938
    //   #793	-> 940
    //   #901	-> 942
    //   #793	-> 948
    //   #902	-> 950
    //   #901	-> 952
    //   #903	-> 955
    //   #794	-> 957
    //   #903	-> 959
    //   #794	-> 965
    //   #904	-> 967
    //   #903	-> 969
    //   #908	-> 972
    //   #888	-> 984
    //   #909	-> 987
    //   #910	-> 997
    //   #911	-> 1000
    //   #914	-> 1009
    //   #794	-> 1016
    //   #914	-> 1018
    //   #916	-> 1024
    //   #793	-> 1031
    //   #916	-> 1033
    //   #917	-> 1039
    //   #918	-> 1047
    //   #919	-> 1069
    //   #920	-> 1073
    //   #919	-> 1080
    //   #923	-> 1084
    //   #794	-> 1085
    //   #924	-> 1094
    //   #922	-> 1102
    //   #925	-> 1107
    //   #926	-> 1119
    //   #927	-> 1137
    //   #928	-> 1141
    //   #927	-> 1148
    //   #930	-> 1152
    //   #932	-> 1154
    //   #933	-> 1163
    //   #931	-> 1164
    //   #930	-> 1165
    //   #934	-> 1167
    //   #935	-> 1182
    //   #936	-> 1190
    //   #937	-> 1196
    //   #935	-> 1198
    //   #938	-> 1201
    //   #940	-> 1204
    //   #941	-> 1224
    //   #942	-> 1233
    //   #790	-> 1240
    //   #942	-> 1242
    //   #943	-> 1248
    //   #791	-> 1250
    //   #943	-> 1252
    //   #945	-> 1258
    //   #946	-> 1266
    //   #947	-> 1288
    //   #948	-> 1292
    //   #947	-> 1299
    //   #950	-> 1303
    //   #952	-> 1313
    //   #953	-> 1322
    //   #954	-> 1330
    //   #955	-> 1341
    //   #956	-> 1350
    //   #957	-> 1362
    //   #958	-> 1369
    //   #959	-> 1377
    //   #960	-> 1386
    //   #962	-> 1393
    //   #963	-> 1394
    //   #789	-> 1399
    //   #963	-> 1408
    //   #964	-> 1419
    //   #961	-> 1421
    //   #965	-> 1426
    //   #966	-> 1438
    //   #967	-> 1456
    //   #968	-> 1460
    //   #967	-> 1467
    //   #970	-> 1471
    //   #972	-> 1481
    //   #792	-> 1482
    //   #973	-> 1491
    //   #971	-> 1499
    //   #974	-> 1504
    //   #976	-> 1506
    //   #977	-> 1515
    //   #975	-> 1516
    //   #974	-> 1517
    //   #978	-> 1519
    //   #979	-> 1534
    //   #980	-> 1542
    //   #981	-> 1548
    //   #979	-> 1550
    //   #982	-> 1553
    //   #984	-> 1556
    //   #985	-> 1573
    //   #986	-> 1581
    //   #987	-> 1597
    //   #988	-> 1606
    //   #990	-> 1612
    //   #791	-> 1614
    //   #990	-> 1616
    //   #991	-> 1619
    //   #992	-> 1624
    //   #990	-> 1626
    //   #993	-> 1628
    //   #994	-> 1636
    //   #993	-> 1649
    //   #996	-> 1652
    //   #998	-> 1665
    //   #999	-> 1669
    //   #1000	-> 1674
    //   #869	-> 1680
    //   #1004	-> 1690
    //   #1006	-> 1695
    //   #1007	-> 1715
    //   #1010	-> 1724
    //   #1011	-> 1728
    //   #1012	-> 1733
    //   #1013	-> 1739
    //   #1014	-> 1747
    //   #1015	-> 1755
    //   #741	-> 1764 }
  
  public void defineProperty(String paramString, Object paramObject, int paramInt) {
    put(paramString, this, paramObject);
    try {
      setAttributes(paramString, this, paramInt);
    } catch (PropertyException propertyException) {
      throw new RuntimeException("Cannot create property");
    } 
  }
  
  public void defineProperty(String paramString, Class paramClass, int paramInt) throws PropertyException {
    StringBuffer stringBuffer = new StringBuffer(paramString);
    stringBuffer.setCharAt(0, Character.toUpperCase(paramString.charAt(0)));
    String str = stringBuffer.toString();
    Method[] arrayOfMethod1 = FunctionObject.findMethods(paramClass, "get" + str);
    Method[] arrayOfMethod2 = FunctionObject.findMethods(paramClass, "set" + str);
    if (arrayOfMethod2 == null)
      paramInt |= 0x1; 
    if (arrayOfMethod1.length != 1 || (arrayOfMethod2 != null && arrayOfMethod2.length != 1)) {
      Object[] arrayOfObject = { paramString, paramClass.getName() };
      throw new PropertyException(
          Context.getMessage("msg.no.overload", arrayOfObject));
    } 
    defineProperty(paramString, null, arrayOfMethod1[0], 
        (arrayOfMethod2 == null) ? null : arrayOfMethod2[0], paramInt);
  }
  
  public void defineProperty(String paramString, Object paramObject, Method paramMethod1, Method paramMethod2, int paramInt) throws PropertyException {
    short s = 1;
    if (paramObject == null && Modifier.isStatic(paramMethod1.getModifiers()))
      paramObject = HAS_STATIC_ACCESSORS; 
    Class[] arrayOfClass = paramMethod1.getParameterTypes();
    if (arrayOfClass.length != 0) {
      if (arrayOfClass.length != 1 || 
        arrayOfClass[false] != ScriptableObject.class) {
        Object[] arrayOfObject = { paramMethod1.toString() };
        throw new PropertyException(
            Context.getMessage("msg.bad.getter.parms", arrayOfObject));
      } 
    } else if (paramObject != null) {
      Object[] arrayOfObject = { paramMethod1.toString() };
      throw new PropertyException(
          Context.getMessage("msg.obj.getter.parms", arrayOfObject));
    } 
    if (paramMethod2 != null) {
      s = (short)(s | 0x2);
      if ((!(paramObject != HAS_STATIC_ACCESSORS)) != 
        Modifier.isStatic(paramMethod2.getModifiers()))
        throw new PropertyException(
            Context.getMessage("msg.getter.static", null)); 
      arrayOfClass = paramMethod2.getParameterTypes();
      if (arrayOfClass.length == 2) {
        if (arrayOfClass[false] != ScriptableObject.class)
          throw new PropertyException(
              Context.getMessage("msg.setter2.parms", null)); 
        if (paramObject == null) {
          Object[] arrayOfObject = { paramMethod2.toString() };
          throw new PropertyException(
              Context.getMessage("msg.setter1.parms", arrayOfObject));
        } 
      } else if (arrayOfClass.length == 1) {
        if (paramObject != null) {
          Object[] arrayOfObject = { paramMethod2.toString() };
          throw new PropertyException(
              Context.getMessage("msg.setter2.expected", arrayOfObject));
        } 
      } else {
        throw new PropertyException(
            Context.getMessage("msg.setter.parms", null));
      } 
    } 
    int i = getSlotToSet(paramString, 
        paramString.hashCode(), 
        true);
    GetterSlot getterSlot = (GetterSlot)this.slots[i];
    getterSlot.delegateTo = paramObject;
    getterSlot.getter = paramMethod1;
    getterSlot.setter = paramMethod2;
    getterSlot.value = null;
    getterSlot.attributes = (short)paramInt;
    getterSlot.flags = s;
  }
  
  public void defineFunctionProperties(String[] paramArrayOfString, Class paramClass, int paramInt) throws PropertyException {
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      String str = paramArrayOfString[b];
      Method[] arrayOfMethod = FunctionObject.findMethods(paramClass, str);
      if (arrayOfMethod == null) {
        Object[] arrayOfObject = { str, paramClass.getName() };
        throw new PropertyException(
            Context.getMessage("msg.method.not.found", arrayOfObject));
      } 
      if (arrayOfMethod.length > 1) {
        Object[] arrayOfObject = { str, paramClass.getName() };
        throw new PropertyException(
            Context.getMessage("msg.no.overload", arrayOfObject));
      } 
      FunctionObject functionObject = new FunctionObject(str, arrayOfMethod[0], this);
      defineProperty(str, functionObject, paramInt);
    } 
  }
  
  public static Scriptable getObjectPrototype(Scriptable paramScriptable) { return getClassPrototype(paramScriptable, "Object"); }
  
  public static Scriptable getFunctionPrototype(Scriptable paramScriptable) { return getClassPrototype(paramScriptable, "Function"); }
  
  public static Scriptable getClassPrototype(Scriptable paramScriptable, String paramString) {
    paramScriptable = getTopLevelScope(paramScriptable);
    Object object1 = ScriptRuntime.getTopLevelProp(paramScriptable, paramString);
    if (object1 == Scriptable.NOT_FOUND || !(object1 instanceof Scriptable))
      return null; 
    Scriptable scriptable = (Scriptable)object1;
    if (!scriptable.has("prototype", scriptable))
      return null; 
    Object object2 = scriptable.get("prototype", scriptable);
    if (!(object2 instanceof Scriptable))
      return null; 
    return (Scriptable)object2;
  }
  
  public static Scriptable getTopLevelScope(Scriptable paramScriptable) {
    Scriptable scriptable = paramScriptable;
    do {
      paramScriptable = scriptable;
      scriptable = paramScriptable.getParentScope();
    } while (scriptable != null);
    return paramScriptable;
  }
  
  public void sealObject() { this.count = -1; }
  
  public boolean isSealed() { return !(this.count != -1); }
  
  void addPropertyAttribute(int paramInt) {
    if (this.slots == null)
      return; 
    for (byte b = 0; b < this.slots.length; b++) {
      Slot slot = this.slots[b];
      if (slot != null && slot != REMOVED)
        if ((slot.flags & 0x2) == 0 || paramInt != 1)
          slot.attributes = (short)(slot.attributes | paramInt);  
    } 
  }
  
  private int getSlot(String paramString, int paramInt) {
    if (this.slots == null)
      return -1; 
    int i = (paramInt & 0x7FFFFFFF) % this.slots.length;
    int j = i;
    do {
      Slot slot = this.slots[j];
      if (slot == null)
        return -1; 
      if (slot != REMOVED && slot.intKey == paramInt && (
        slot.stringKey == paramString || (paramString != null && 
        paramString.equals(slot.stringKey))))
        return j; 
      if (++j != this.slots.length)
        continue; 
      j = 0;
    } while (j != i);
    return -1;
  }
  
  private int getSlotToSet(String paramString, int paramInt, boolean paramBoolean) {
    if (this.slots == null)
      this.slots = new Slot[5]; 
    int i = (paramInt & 0x7FFFFFFF) % this.slots.length;
    int j = i;
    do {
      Slot slot = this.slots[j];
      if (slot == null)
        return addSlot(paramString, paramInt, paramBoolean); 
      if (slot != REMOVED && slot.intKey == paramInt && (
        slot.stringKey == paramString || (paramString != null && 
        paramString.equals(slot.stringKey))))
        return j; 
      if (++j != this.slots.length)
        continue; 
      j = 0;
    } while (j != i);
    throw new RuntimeException("Hashtable internal error");
  }
  
  private int addSlot(String paramString, int paramInt, boolean paramBoolean) {
    if (this.count == -1)
      throw Context.reportRuntimeError(
          Context.getMessage("msg.add.sealed", null)); 
    int i = (paramInt & 0x7FFFFFFF) % this.slots.length;
    int j = i;
    do {
      Slot slot = this.slots[j];
      if (slot == null || slot == REMOVED) {
        this.count++;
        if (4 * this.count > 3 * this.slots.length) {
          grow();
          return getSlotToSet(paramString, paramInt, paramBoolean);
        } 
        slot = paramBoolean ? new GetterSlot() : new Slot();
        slot.stringKey = paramString;
        slot.intKey = paramInt;
        this.slots[j] = slot;
        return j;
      } 
      if (slot.intKey == paramInt && (
        slot.stringKey == paramString || (paramString != null && 
        paramString.equals(slot.stringKey))))
        return j; 
      if (++j != this.slots.length)
        continue; 
      j = 0;
    } while (j != i);
    throw new RuntimeException("Hashtable internal error");
  }
  
  private void removeSlot(String paramString, int paramInt) {
    if (this.count == -1)
      throw Context.reportRuntimeError(
          Context.getMessage("msg.remove.sealed", null)); 
    int i = getSlot(paramString, paramInt);
    if (i == -1)
      return; 
    if (((this.slots[i]).attributes & 0x4) != 0)
      return; 
    this.slots[i] = REMOVED;
    this.count--;
  }
  
  private void grow() {
    Slot[] arrayOfSlot = new Slot[this.slots.length * 2 + 1];
    for (int i = this.slots.length - 1; i >= 0; i--) {
      Slot slot = this.slots[i];
      if (slot != null && slot != REMOVED) {
        int j = (slot.intKey & 0x7FFFFFFF) % arrayOfSlot.length;
        while (arrayOfSlot[j] != null) {
          if (++j == arrayOfSlot.length)
            j = 0; 
        } 
        arrayOfSlot[j] = slot;
      } 
    } 
    this.slots = arrayOfSlot;
  }
  
  private Function getFunctionProperty(FlattenedObject paramFlattenedObject, String paramString) {
    Object object = paramFlattenedObject.getProperty(paramString);
    if (object == null || !(object instanceof FlattenedObject))
      return null; 
    Scriptable scriptable = ((FlattenedObject)object).getObject();
    if (scriptable instanceof Function)
      return (Function)scriptable; 
    return null;
  }
  
  private static Hashtable getExclusionList() {
    if (exclusionList != null)
      return exclusionList; 
    Hashtable hashtable = new Hashtable(17);
    Method[] arrayOfMethod = ScriptRuntime.FunctionClass.getMethods();
    for (byte b = 0; b < arrayOfMethod.length; b++)
      hashtable.put(arrayOfMethod[b].getName(), Boolean.TRUE); 
    exclusionList = hashtable;
    return hashtable;
  }
  
  private Object[] getIds(boolean paramBoolean) {
    if (this.slots == null)
      return ScriptRuntime.emptyArgs; 
    byte b = 0;
    for (int i = this.slots.length - 1; i >= 0; i--) {
      Slot slot = this.slots[i];
      if (slot != null && slot != REMOVED)
        if (paramBoolean || (slot.attributes & 0x2) == 0)
          b++;  
    } 
    Object[] arrayOfObject = new Object[b];
    for (int j = this.slots.length - 1; j >= 0; j--) {
      Slot slot = this.slots[j];
      if (slot != null && slot != REMOVED)
        if (paramBoolean || (slot.attributes & 0x2) == 0)
          arrayOfObject[--b] = (slot.stringKey != null) ? 
            slot.stringKey : 
            new Integer(slot.intKey);  
    } 
    return arrayOfObject;
  }
  
  private static final Object HAS_STATIC_ACCESSORS = void.class;
  
  private static final Slot REMOVED = new Slot();
  
  private static Hashtable exclusionList = null;
  
  private Slot[] slots;
  
  private int count;
  
  private String lastName;
  
  private int lastHash;
  
  private Object lastValue = REMOVED;
  
  static Class class$org$mozilla$javascript$FunctionObject;
  
  public abstract String getClassName();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\ScriptableObject.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */