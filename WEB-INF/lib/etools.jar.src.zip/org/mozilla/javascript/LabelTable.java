/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LabelTable
/*    */ {
/*    */   private static final boolean DEBUGLABELS = false;
/*    */   private static final int LabelTableSize = 32;
/*    */   protected Label[] itsLabelTable;
/*    */   protected int itsLabelTableTop;
/*    */   
/*    */   public int acquireLabel() {
/* 48 */     if (this.itsLabelTable == null) {
/* 49 */       this.itsLabelTable = new Label[32];
/* 50 */       this.itsLabelTable[0] = new Label();
/* 51 */       this.itsLabelTableTop = 1;
/* 52 */       return Integer.MIN_VALUE;
/*    */     } 
/*    */     
/* 55 */     if (this.itsLabelTableTop == this.itsLabelTable.length) {
/* 56 */       Label[] arrayOfLabel = this.itsLabelTable;
/* 57 */       this.itsLabelTable = new Label[this.itsLabelTableTop * 2];
/* 58 */       System.arraycopy(arrayOfLabel, 0, this.itsLabelTable, 0, this.itsLabelTableTop);
/*    */     } 
/* 60 */     this.itsLabelTable[this.itsLabelTableTop] = new Label();
/* 61 */     int i = this.itsLabelTableTop++;
/* 62 */     return i | 0x80000000;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int markLabel(int paramInt1, int paramInt2) {
/* 72 */     paramInt1 &= Integer.MAX_VALUE;
/*    */ 
/*    */ 
/*    */     
/* 76 */     this.itsLabelTable[paramInt1].setPC((short)paramInt2);
/* 77 */     return paramInt1 | 0x80000000;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\LabelTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */