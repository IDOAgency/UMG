package org.mozilla.javascript;

public class LabelTable {
  private static final boolean DEBUGLABELS = false;
  
  private static final int LabelTableSize = 32;
  
  protected Label[] itsLabelTable;
  
  protected int itsLabelTableTop;
  
  public int acquireLabel() {
    if (this.itsLabelTable == null) {
      this.itsLabelTable = new Label[32];
      this.itsLabelTable[0] = new Label();
      this.itsLabelTableTop = 1;
      return Integer.MIN_VALUE;
    } 
    if (this.itsLabelTableTop == this.itsLabelTable.length) {
      Label[] arrayOfLabel = this.itsLabelTable;
      this.itsLabelTable = new Label[this.itsLabelTableTop * 2];
      System.arraycopy(arrayOfLabel, 0, this.itsLabelTable, 0, this.itsLabelTableTop);
    } 
    this.itsLabelTable[this.itsLabelTableTop] = new Label();
    int i = this.itsLabelTableTop++;
    return i | 0x80000000;
  }
  
  public int markLabel(int paramInt1, int paramInt2) {
    paramInt1 &= Integer.MAX_VALUE;
    this.itsLabelTable[paramInt1].setPC((short)paramInt2);
    return paramInt1 | 0x80000000;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\LabelTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */