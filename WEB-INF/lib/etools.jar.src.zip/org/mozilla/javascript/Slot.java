package org.mozilla.javascript;

class Slot {
  static final int HAS_GETTER = 1;
  
  static final int HAS_SETTER = 2;
  
  int intKey;
  
  String stringKey;
  
  Object value;
  
  short attributes;
  
  short flags;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Slot.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */