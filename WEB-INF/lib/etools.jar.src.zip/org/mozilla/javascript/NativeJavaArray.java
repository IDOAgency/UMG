package org.mozilla.javascript;

import java.lang.reflect.Array;

public class NativeJavaArray extends NativeJavaObject {
  Object array;
  
  int length;
  
  Class cls;
  
  Scriptable prototype;
  
  public String getClassName() { return "JavaArray"; }
  
  public static NativeJavaArray wrap(Scriptable paramScriptable, Object paramObject) { return new NativeJavaArray(paramScriptable, paramObject); }
  
  public Object unwrap() { return this.array; }
  
  public NativeJavaArray(Scriptable paramScriptable, Object paramObject) {
    super(paramScriptable, null, ScriptRuntime.ObjectClass);
    Class clazz = paramObject.getClass();
    if (!clazz.isArray())
      throw new RuntimeException("Array expected"); 
    this.array = paramObject;
    this.length = Array.getLength(paramObject);
    this.cls = clazz.getComponentType();
  }
  
  public boolean has(String paramString, Scriptable paramScriptable) { return !(!paramString.equals("length") && !super.has(paramString, paramScriptable)); }
  
  public boolean has(int paramInt, Scriptable paramScriptable) { return !(paramInt < 0 || paramInt >= this.length); }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    if (paramString.equals("length"))
      return new Integer(this.length); 
    Object object = super.get(paramString, paramScriptable);
    if (object == Scriptable.NOT_FOUND && 
      !ScriptRuntime.hasProp(getPrototype(), paramString)) {
      Object[] arrayOfObject = { this.array.getClass().getName(), 
          paramString };
      throw Context.reportRuntimeError(
          Context.getMessage("msg.java.member.not.found", 
            arrayOfObject));
    } 
    return object;
  }
  
  public Object get(int paramInt, Scriptable paramScriptable) {
    if (paramInt >= 0 && paramInt < this.length)
      return NativeJavaObject.wrap(this, Array.get(this.array, paramInt), this.cls); 
    return Undefined.instance;
  }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
    if (!paramString.equals("length"))
      super.put(paramString, paramScriptable, paramObject); 
  }
  
  public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
    if (paramInt >= 0 && paramInt < this.length) {
      Array.set(this.array, paramInt, NativeJavaObject.coerceType(this.cls, paramObject));
      return;
    } 
    super.put(paramInt, paramScriptable, paramObject);
  }
  
  public Object getDefaultValue(Class paramClass) {
    if (paramClass == null || paramClass == ScriptRuntime.StringClass)
      return this.array.toString(); 
    if (paramClass == ScriptRuntime.BooleanClass)
      return Boolean.TRUE; 
    if (paramClass == ScriptRuntime.NumberClass)
      return ScriptRuntime.NaNobj; 
    return this;
  }
  
  public Object[] getIds() {
    Object[] arrayOfObject = new Object[this.length];
    int i = this.length;
    while (--i >= 0)
      arrayOfObject[i] = new Integer(i); 
    return arrayOfObject;
  }
  
  public boolean hasInstance(Scriptable paramScriptable) {
    if (!(paramScriptable instanceof NativeJavaObject))
      return false; 
    Object object = ((NativeJavaObject)paramScriptable).unwrap();
    return this.cls.isInstance(object);
  }
  
  public Scriptable getPrototype() {
    if (this.prototype == null)
      this.prototype = 
        ScriptableObject.getClassPrototype(getParentScope(), 
          "Array"); 
    return this.prototype;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeJavaArray.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */