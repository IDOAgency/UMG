/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeJavaArray
/*     */   extends NativeJavaObject
/*     */ {
/*     */   Object array;
/*     */   int length;
/*     */   Class cls;
/*     */   Scriptable prototype;
/*     */   
/*  54 */   public String getClassName() { return "JavaArray"; }
/*     */ 
/*     */ 
/*     */   
/*  58 */   public static NativeJavaArray wrap(Scriptable paramScriptable, Object paramObject) { return new NativeJavaArray(paramScriptable, paramObject); }
/*     */ 
/*     */ 
/*     */   
/*  62 */   public Object unwrap() { return this.array; }
/*     */ 
/*     */   
/*     */   public NativeJavaArray(Scriptable paramScriptable, Object paramObject) {
/*  66 */     super(paramScriptable, null, ScriptRuntime.ObjectClass);
/*  67 */     Class clazz = paramObject.getClass();
/*  68 */     if (!clazz.isArray()) {
/*  69 */       throw new RuntimeException("Array expected");
/*     */     }
/*  71 */     this.array = paramObject;
/*  72 */     this.length = Array.getLength(paramObject);
/*  73 */     this.cls = clazz.getComponentType();
/*     */   }
/*     */ 
/*     */   
/*  77 */   public boolean has(String paramString, Scriptable paramScriptable) { return !(!paramString.equals("length") && !super.has(paramString, paramScriptable)); }
/*     */ 
/*     */ 
/*     */   
/*  81 */   public boolean has(int paramInt, Scriptable paramScriptable) { return !(paramInt < 0 || paramInt >= this.length); }
/*     */ 
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/*  85 */     if (paramString.equals("length"))
/*  86 */       return new Integer(this.length); 
/*  87 */     Object object = super.get(paramString, paramScriptable);
/*  88 */     if (object == Scriptable.NOT_FOUND && 
/*  89 */       !ScriptRuntime.hasProp(getPrototype(), paramString)) {
/*     */       
/*  91 */       Object[] arrayOfObject = { this.array.getClass().getName(), 
/*  92 */           paramString };
/*  93 */       throw Context.reportRuntimeError(
/*  94 */           Context.getMessage("msg.java.member.not.found", 
/*  95 */             arrayOfObject));
/*     */     } 
/*  97 */     return object;
/*     */   }
/*     */   
/*     */   public Object get(int paramInt, Scriptable paramScriptable) {
/* 101 */     if (paramInt >= 0 && paramInt < this.length)
/* 102 */       return NativeJavaObject.wrap(this, Array.get(this.array, paramInt), this.cls); 
/* 103 */     return Undefined.instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
/* 108 */     if (!paramString.equals("length"))
/* 109 */       super.put(paramString, paramScriptable, paramObject); 
/*     */   }
/*     */   
/*     */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
/* 113 */     if (paramInt >= 0 && paramInt < this.length) {
/* 114 */       Array.set(this.array, paramInt, NativeJavaObject.coerceType(this.cls, paramObject));
/*     */       return;
/*     */     } 
/* 117 */     super.put(paramInt, paramScriptable, paramObject);
/*     */   }
/*     */   
/*     */   public Object getDefaultValue(Class paramClass) {
/* 121 */     if (paramClass == null || paramClass == ScriptRuntime.StringClass)
/* 122 */       return this.array.toString(); 
/* 123 */     if (paramClass == ScriptRuntime.BooleanClass)
/* 124 */       return Boolean.TRUE; 
/* 125 */     if (paramClass == ScriptRuntime.NumberClass)
/* 126 */       return ScriptRuntime.NaNobj; 
/* 127 */     return this;
/*     */   }
/*     */   
/*     */   public Object[] getIds() {
/* 131 */     Object[] arrayOfObject = new Object[this.length];
/* 132 */     int i = this.length;
/* 133 */     while (--i >= 0)
/* 134 */       arrayOfObject[i] = new Integer(i); 
/* 135 */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   public boolean hasInstance(Scriptable paramScriptable) {
/* 139 */     if (!(paramScriptable instanceof NativeJavaObject))
/* 140 */       return false; 
/* 141 */     Object object = ((NativeJavaObject)paramScriptable).unwrap();
/* 142 */     return this.cls.isInstance(object);
/*     */   }
/*     */   
/*     */   public Scriptable getPrototype() {
/* 146 */     if (this.prototype == null) {
/* 147 */       this.prototype = 
/* 148 */         ScriptableObject.getClassPrototype(getParentScope(), 
/* 149 */           "Array");
/*     */     }
/* 151 */     return this.prototype;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeJavaArray.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */