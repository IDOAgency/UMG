/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EcmaError
/*     */   extends RuntimeException
/*     */ {
/*     */   private NativeError errorObject;
/*     */   private String sourceName;
/*     */   private int lineNumber;
/*     */   private int columnNumber;
/*     */   private String lineSource;
/*     */   
/*     */   public EcmaError(NativeError paramNativeError, String paramString1, int paramInt1, int paramInt2, String paramString2) {
/*  63 */     super("EcmaError");
/*  64 */     this.errorObject = paramNativeError;
/*  65 */     this.sourceName = paramString1;
/*  66 */     this.lineNumber = paramInt1;
/*  67 */     this.columnNumber = paramInt2;
/*  68 */     this.lineSource = paramString2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  76 */     if (this.sourceName != null && this.lineNumber > 0) {
/*  77 */       return String.valueOf(this.errorObject.toString()) + " (" + this.sourceName + 
/*  78 */         "; line " + this.lineNumber + ")";
/*     */     }
/*  80 */     return this.errorObject.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public String getName() { return this.errorObject.getName(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public String getMessage() { return this.errorObject.getMessage(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public String getSourceName() { return this.sourceName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public int getLineNumber() { return this.lineNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public Scriptable getErrorObject() { return this.errorObject; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public int getColumnNumber() { return this.columnNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public String getLineSource() { return this.lineSource; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\EcmaError.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */