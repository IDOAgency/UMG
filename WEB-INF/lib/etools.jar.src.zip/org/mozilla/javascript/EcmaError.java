package org.mozilla.javascript;

public class EcmaError extends RuntimeException {
  private NativeError errorObject;
  
  private String sourceName;
  
  private int lineNumber;
  
  private int columnNumber;
  
  private String lineSource;
  
  public EcmaError(NativeError paramNativeError, String paramString1, int paramInt1, int paramInt2, String paramString2) {
    super("EcmaError");
    this.errorObject = paramNativeError;
    this.sourceName = paramString1;
    this.lineNumber = paramInt1;
    this.columnNumber = paramInt2;
    this.lineSource = paramString2;
  }
  
  public String toString() {
    if (this.sourceName != null && this.lineNumber > 0)
      return String.valueOf(this.errorObject.toString()) + " (" + this.sourceName + 
        "; line " + this.lineNumber + ")"; 
    return this.errorObject.toString();
  }
  
  public String getName() { return this.errorObject.getName(); }
  
  public String getMessage() { return this.errorObject.getMessage(); }
  
  public String getSourceName() { return this.sourceName; }
  
  public int getLineNumber() { return this.lineNumber; }
  
  public Scriptable getErrorObject() { return this.errorObject; }
  
  public int getColumnNumber() { return this.columnNumber; }
  
  public String getLineSource() { return this.lineSource; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\EcmaError.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */