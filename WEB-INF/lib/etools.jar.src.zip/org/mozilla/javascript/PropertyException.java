package org.mozilla.javascript;

public class PropertyException extends Exception {
  public PropertyException(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\PropertyException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */