/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Node
/*     */   implements Cloneable
/*     */ {
/*     */   public static final int TARGET_PROP = 1;
/*     */   public static final int BREAK_PROP = 2;
/*     */   public static final int CONTINUE_PROP = 3;
/*     */   public static final int ENUM_PROP = 4;
/*     */   public static final int FUNCTION_PROP = 5;
/*     */   public static final int TEMP_PROP = 6;
/*     */   public static final int LOCAL_PROP = 7;
/*     */   public static final int CODEOFFSET_PROP = 8;
/*     */   public static final int FIXUPS_PROP = 9;
/*     */   public static final int VARS_PROP = 10;
/*     */   public static final int USES_PROP = 11;
/*     */   public static final int REGEXP_PROP = 12;
/*     */   public static final int CASES_PROP = 13;
/*     */   public static final int DEFAULT_PROP = 14;
/*     */   public static final int CASEARRAY_PROP = 15;
/*     */   public static final int SOURCENAME_PROP = 16;
/*     */   public static final int SOURCE_PROP = 17;
/*     */   public static final int TYPE_PROP = 18;
/*     */   public static final int SPECIAL_PROP_PROP = 19;
/*     */   public static final int LABEL_PROP = 20;
/*     */   public static final int FINALLY_PROP = 21;
/*     */   public static final int LOCALCOUNT_PROP = 22;
/*     */   public static final int TARGETBLOCK_PROP = 23;
/*     */   public static final int VARIABLE_PROP = 24;
/*     */   public static final int LASTUSE_PROP = 25;
/*     */   public static final int ISNUMBER_PROP = 26;
/*     */   public static final int DIRECTCALL_PROP = 27;
/*     */   public static final int BASE_LINENO_PROP = 28;
/*     */   public static final int END_LINENO_PROP = 29;
/*     */   public static final int SPECIALCALL_PROP = 30;
/*     */   public static final int BOTH = 0;
/*     */   public static final int LEFT = 1;
/*     */   public static final int RIGHT = 2;
/*     */   private static String[] propNames;
/*     */   protected int type;
/*     */   protected Node next;
/*     */   protected Node first;
/*     */   protected Node last;
/*     */   protected Hashtable props;
/*     */   protected Object datum;
/*     */   
/*  52 */   public Node(int paramInt) { this.type = paramInt; }
/*     */ 
/*     */   
/*     */   public Node(int paramInt, Node paramNode) {
/*  56 */     this.type = paramInt;
/*  57 */     this.first = this.last = paramNode;
/*  58 */     paramNode.next = null;
/*     */   }
/*     */   
/*     */   public Node(int paramInt, Node paramNode1, Node paramNode2) {
/*  62 */     this.type = paramInt;
/*  63 */     this.first = paramNode1;
/*  64 */     this.last = paramNode2;
/*  65 */     paramNode1.next = paramNode2;
/*  66 */     paramNode2.next = null;
/*     */   }
/*     */   
/*     */   public Node(int paramInt, Node paramNode1, Node paramNode2, Node paramNode3) {
/*  70 */     this.type = paramInt;
/*  71 */     this.first = paramNode1;
/*  72 */     this.last = paramNode3;
/*  73 */     paramNode1.next = paramNode2;
/*  74 */     paramNode2.next = paramNode3;
/*  75 */     paramNode3.next = null;
/*     */   }
/*     */   
/*     */   public Node(int paramInt, Object paramObject) {
/*  79 */     this.type = paramInt;
/*  80 */     this.datum = paramObject;
/*     */   }
/*     */   
/*     */   public Node(int paramInt, Node paramNode, Object paramObject) {
/*  84 */     this(paramInt, paramNode);
/*  85 */     this.datum = paramObject;
/*     */   }
/*     */   
/*     */   public Node(int paramInt, Node paramNode1, Node paramNode2, Object paramObject) {
/*  89 */     this(paramInt, paramNode1, paramNode2);
/*  90 */     this.datum = paramObject;
/*     */   }
/*     */ 
/*     */   
/*  94 */   public int getType() { return this.type; }
/*     */ 
/*     */ 
/*     */   
/*  98 */   public void setType(int paramInt) { this.type = paramInt; }
/*     */ 
/*     */ 
/*     */   
/* 102 */   public boolean hasChildren() { return !(this.first == null); }
/*     */ 
/*     */ 
/*     */   
/* 106 */   public Node getFirstChild() { return this.first; }
/*     */ 
/*     */ 
/*     */   
/* 110 */   public Node getLastChild() { return this.last; }
/*     */ 
/*     */ 
/*     */   
/* 114 */   public Node getNextSibling() { return this.next; }
/*     */ 
/*     */   
/*     */   public Node getChildBefore(Node paramNode) {
/* 118 */     if (paramNode == this.first)
/* 119 */       return null; 
/* 120 */     Node node = this.first;
/* 121 */     while (node.next != paramNode) {
/* 122 */       node = node.next;
/* 123 */       if (node == null)
/* 124 */         throw new RuntimeException("node is not a child"); 
/*     */     } 
/* 126 */     return node;
/*     */   }
/*     */   
/*     */   public Node getLastSibling() {
/* 130 */     Node node = this;
/* 131 */     while (node.next != null) {
/* 132 */       node = node.next;
/*     */     }
/* 134 */     return node;
/*     */   }
/*     */ 
/*     */   
/* 138 */   public ShallowNodeIterator getChildIterator() { return new ShallowNodeIterator(this.first); }
/*     */ 
/*     */ 
/*     */   
/* 142 */   public PreorderNodeIterator getPreorderIterator() { return new PreorderNodeIterator(this); }
/*     */ 
/*     */   
/*     */   public void addChildToFront(Node paramNode) {
/* 146 */     paramNode.next = this.first;
/* 147 */     this.first = paramNode;
/* 148 */     if (this.last == null) {
/* 149 */       this.last = paramNode;
/*     */     }
/*     */   }
/*     */   
/*     */   public void addChildToBack(Node paramNode) {
/* 154 */     paramNode.next = null;
/* 155 */     if (this.last == null) {
/* 156 */       this.first = this.last = paramNode;
/*     */       return;
/*     */     } 
/* 159 */     this.last.next = paramNode;
/* 160 */     this.last = paramNode;
/*     */   }
/*     */   
/*     */   public void addChildrenToFront(Node paramNode) {
/* 164 */     Node node = paramNode.getLastSibling();
/* 165 */     node.next = this.first;
/* 166 */     this.first = paramNode;
/* 167 */     if (this.last == null) {
/* 168 */       this.last = node;
/*     */     }
/*     */   }
/*     */   
/*     */   public void addChildrenToBack(Node paramNode) {
/* 173 */     if (this.last != null) {
/* 174 */       this.last.next = paramNode;
/*     */     }
/* 176 */     this.last = paramNode.getLastSibling();
/* 177 */     if (this.first == null) {
/* 178 */       this.first = paramNode;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChildBefore(Node paramNode1, Node paramNode2) {
/* 186 */     if (paramNode1.next != null)
/* 187 */       throw new RuntimeException(
/* 188 */           "newChild had siblings in addChildBefore"); 
/* 189 */     if (this.first == paramNode2) {
/* 190 */       paramNode1.next = this.first;
/* 191 */       this.first = paramNode1;
/*     */       return;
/*     */     } 
/* 194 */     Node node = getChildBefore(paramNode2);
/* 195 */     addChildAfter(paramNode1, node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChildAfter(Node paramNode1, Node paramNode2) {
/* 202 */     if (paramNode1.next != null)
/* 203 */       throw new RuntimeException(
/* 204 */           "newChild had siblings in addChildAfter"); 
/* 205 */     paramNode1.next = paramNode2.next;
/* 206 */     paramNode2.next = paramNode1;
/* 207 */     if (this.last == paramNode2)
/* 208 */       this.last = paramNode1; 
/*     */   }
/*     */   
/*     */   public void removeChild(Node paramNode) {
/* 212 */     Node node = getChildBefore(paramNode);
/* 213 */     if (node == null) {
/* 214 */       this.first = this.first.next;
/*     */     } else {
/* 216 */       node.next = paramNode.next;
/* 217 */     }  if (paramNode == this.last) this.last = node; 
/* 218 */     paramNode.next = null;
/*     */   }
/*     */   
/*     */   public void replaceChild(Node paramNode1, Node paramNode2) {
/* 222 */     paramNode2.next = paramNode1.next;
/* 223 */     if (paramNode1 == this.first) {
/* 224 */       this.first = paramNode2;
/*     */     } else {
/* 226 */       Node node = getChildBefore(paramNode1);
/* 227 */       node.next = paramNode2;
/*     */     } 
/* 229 */     if (paramNode1 == this.last)
/* 230 */       this.last = paramNode2; 
/* 231 */     paramNode1.next = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 327 */   private static final String propToString(int paramInt) { return propNames[paramInt - 1]; }
/*     */ 
/*     */   
/*     */   public Object getProp(int paramInt) {
/* 331 */     if (this.props == null)
/* 332 */       return null; 
/* 333 */     return this.props.get(new Integer(paramInt));
/*     */   }
/*     */   
/*     */   public void putProp(int paramInt, Object paramObject) {
/* 337 */     if (this.props == null)
/* 338 */       this.props = new Hashtable(2); 
/* 339 */     if (paramObject == null) {
/* 340 */       this.props.remove(new Integer(paramInt));
/*     */     } else {
/* 342 */       this.props.put(new Integer(paramInt), paramObject);
/*     */     } 
/*     */   }
/*     */   
/* 346 */   public Object getDatum() { return this.datum; }
/*     */ 
/*     */ 
/*     */   
/* 350 */   public void setDatum(Object paramObject) { this.datum = paramObject; }
/*     */ 
/*     */ 
/*     */   
/* 354 */   public int getInt() { return ((Number)this.datum).intValue(); }
/*     */ 
/*     */ 
/*     */   
/* 358 */   public double getDouble() { return ((Number)this.datum).doubleValue(); }
/*     */ 
/*     */ 
/*     */   
/* 362 */   public long getLong() { return ((Number)this.datum).longValue(); }
/*     */ 
/*     */ 
/*     */   
/* 366 */   public String getString() { return (String)this.datum; }
/*     */ 
/*     */   
/*     */   public Node cloneNode() {
/*     */     Node node;
/*     */     try {
/* 372 */       node = (Node)clone();
/* 373 */       node.next = null;
/* 374 */       node.first = null;
/* 375 */       node.last = null;
/*     */     }
/* 377 */     catch (CloneNotSupportedException cloneNotSupportedException) {
/* 378 */       throw new RuntimeException(cloneNotSupportedException.getMessage());
/*     */     } 
/* 380 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 426 */   public String toString() { return null; }
/*     */ 
/*     */ 
/*     */   
/* 430 */   public String toStringTree() { return toStringTreeHelper(0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 456 */   private String toStringTreeHelper(int paramInt) { return ""; }
/*     */ 
/*     */   
/* 459 */   public Node getFirst() { return this.first; }
/* 460 */   public Node getNext() { return this.next; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Node.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */