package org.mozilla.javascript;

import java.util.Hashtable;

public class Node implements Cloneable {
  public static final int TARGET_PROP = 1;
  
  public static final int BREAK_PROP = 2;
  
  public static final int CONTINUE_PROP = 3;
  
  public static final int ENUM_PROP = 4;
  
  public static final int FUNCTION_PROP = 5;
  
  public static final int TEMP_PROP = 6;
  
  public static final int LOCAL_PROP = 7;
  
  public static final int CODEOFFSET_PROP = 8;
  
  public static final int FIXUPS_PROP = 9;
  
  public static final int VARS_PROP = 10;
  
  public static final int USES_PROP = 11;
  
  public static final int REGEXP_PROP = 12;
  
  public static final int CASES_PROP = 13;
  
  public static final int DEFAULT_PROP = 14;
  
  public static final int CASEARRAY_PROP = 15;
  
  public static final int SOURCENAME_PROP = 16;
  
  public static final int SOURCE_PROP = 17;
  
  public static final int TYPE_PROP = 18;
  
  public static final int SPECIAL_PROP_PROP = 19;
  
  public static final int LABEL_PROP = 20;
  
  public static final int FINALLY_PROP = 21;
  
  public static final int LOCALCOUNT_PROP = 22;
  
  public static final int TARGETBLOCK_PROP = 23;
  
  public static final int VARIABLE_PROP = 24;
  
  public static final int LASTUSE_PROP = 25;
  
  public static final int ISNUMBER_PROP = 26;
  
  public static final int DIRECTCALL_PROP = 27;
  
  public static final int BASE_LINENO_PROP = 28;
  
  public static final int END_LINENO_PROP = 29;
  
  public static final int SPECIALCALL_PROP = 30;
  
  public static final int BOTH = 0;
  
  public static final int LEFT = 1;
  
  public static final int RIGHT = 2;
  
  private static String[] propNames;
  
  protected int type;
  
  protected Node next;
  
  protected Node first;
  
  protected Node last;
  
  protected Hashtable props;
  
  protected Object datum;
  
  public Node(int paramInt) { this.type = paramInt; }
  
  public Node(int paramInt, Node paramNode) {
    this.type = paramInt;
    this.first = this.last = paramNode;
    paramNode.next = null;
  }
  
  public Node(int paramInt, Node paramNode1, Node paramNode2) {
    this.type = paramInt;
    this.first = paramNode1;
    this.last = paramNode2;
    paramNode1.next = paramNode2;
    paramNode2.next = null;
  }
  
  public Node(int paramInt, Node paramNode1, Node paramNode2, Node paramNode3) {
    this.type = paramInt;
    this.first = paramNode1;
    this.last = paramNode3;
    paramNode1.next = paramNode2;
    paramNode2.next = paramNode3;
    paramNode3.next = null;
  }
  
  public Node(int paramInt, Object paramObject) {
    this.type = paramInt;
    this.datum = paramObject;
  }
  
  public Node(int paramInt, Node paramNode, Object paramObject) {
    this(paramInt, paramNode);
    this.datum = paramObject;
  }
  
  public Node(int paramInt, Node paramNode1, Node paramNode2, Object paramObject) {
    this(paramInt, paramNode1, paramNode2);
    this.datum = paramObject;
  }
  
  public int getType() { return this.type; }
  
  public void setType(int paramInt) { this.type = paramInt; }
  
  public boolean hasChildren() { return !(this.first == null); }
  
  public Node getFirstChild() { return this.first; }
  
  public Node getLastChild() { return this.last; }
  
  public Node getNextSibling() { return this.next; }
  
  public Node getChildBefore(Node paramNode) {
    if (paramNode == this.first)
      return null; 
    Node node = this.first;
    while (node.next != paramNode) {
      node = node.next;
      if (node == null)
        throw new RuntimeException("node is not a child"); 
    } 
    return node;
  }
  
  public Node getLastSibling() {
    Node node = this;
    while (node.next != null)
      node = node.next; 
    return node;
  }
  
  public ShallowNodeIterator getChildIterator() { return new ShallowNodeIterator(this.first); }
  
  public PreorderNodeIterator getPreorderIterator() { return new PreorderNodeIterator(this); }
  
  public void addChildToFront(Node paramNode) {
    paramNode.next = this.first;
    this.first = paramNode;
    if (this.last == null)
      this.last = paramNode; 
  }
  
  public void addChildToBack(Node paramNode) {
    paramNode.next = null;
    if (this.last == null) {
      this.first = this.last = paramNode;
      return;
    } 
    this.last.next = paramNode;
    this.last = paramNode;
  }
  
  public void addChildrenToFront(Node paramNode) {
    Node node = paramNode.getLastSibling();
    node.next = this.first;
    this.first = paramNode;
    if (this.last == null)
      this.last = node; 
  }
  
  public void addChildrenToBack(Node paramNode) {
    if (this.last != null)
      this.last.next = paramNode; 
    this.last = paramNode.getLastSibling();
    if (this.first == null)
      this.first = paramNode; 
  }
  
  public void addChildBefore(Node paramNode1, Node paramNode2) {
    if (paramNode1.next != null)
      throw new RuntimeException(
          "newChild had siblings in addChildBefore"); 
    if (this.first == paramNode2) {
      paramNode1.next = this.first;
      this.first = paramNode1;
      return;
    } 
    Node node = getChildBefore(paramNode2);
    addChildAfter(paramNode1, node);
  }
  
  public void addChildAfter(Node paramNode1, Node paramNode2) {
    if (paramNode1.next != null)
      throw new RuntimeException(
          "newChild had siblings in addChildAfter"); 
    paramNode1.next = paramNode2.next;
    paramNode2.next = paramNode1;
    if (this.last == paramNode2)
      this.last = paramNode1; 
  }
  
  public void removeChild(Node paramNode) {
    Node node = getChildBefore(paramNode);
    if (node == null) {
      this.first = this.first.next;
    } else {
      node.next = paramNode.next;
    } 
    if (paramNode == this.last)
      this.last = node; 
    paramNode.next = null;
  }
  
  public void replaceChild(Node paramNode1, Node paramNode2) {
    paramNode2.next = paramNode1.next;
    if (paramNode1 == this.first) {
      this.first = paramNode2;
    } else {
      Node node = getChildBefore(paramNode1);
      node.next = paramNode2;
    } 
    if (paramNode1 == this.last)
      this.last = paramNode2; 
    paramNode1.next = null;
  }
  
  private static final String propToString(int paramInt) { return propNames[paramInt - 1]; }
  
  public Object getProp(int paramInt) {
    if (this.props == null)
      return null; 
    return this.props.get(new Integer(paramInt));
  }
  
  public void putProp(int paramInt, Object paramObject) {
    if (this.props == null)
      this.props = new Hashtable(2); 
    if (paramObject == null) {
      this.props.remove(new Integer(paramInt));
    } else {
      this.props.put(new Integer(paramInt), paramObject);
    } 
  }
  
  public Object getDatum() { return this.datum; }
  
  public void setDatum(Object paramObject) { this.datum = paramObject; }
  
  public int getInt() { return ((Number)this.datum).intValue(); }
  
  public double getDouble() { return ((Number)this.datum).doubleValue(); }
  
  public long getLong() { return ((Number)this.datum).longValue(); }
  
  public String getString() { return (String)this.datum; }
  
  public Node cloneNode() {
    Node node;
    try {
      node = (Node)clone();
      node.next = null;
      node.first = null;
      node.last = null;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new RuntimeException(cloneNotSupportedException.getMessage());
    } 
    return node;
  }
  
  public String toString() { return null; }
  
  public String toStringTree() { return toStringTreeHelper(0); }
  
  private String toStringTreeHelper(int paramInt) { return ""; }
  
  public Node getFirst() { return this.first; }
  
  public Node getNext() { return this.next; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Node.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */