/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Scriptable
/*    */ {
/* 73 */   public static final Object NOT_FOUND = new Object();
/*    */   
/*    */   void delete(int paramInt);
/*    */   
/*    */   void delete(String paramString);
/*    */   
/*    */   Object get(int paramInt, Scriptable paramScriptable);
/*    */   
/*    */   Object get(String paramString, Scriptable paramScriptable);
/*    */   
/*    */   String getClassName();
/*    */   
/*    */   Object getDefaultValue(Class paramClass);
/*    */   
/*    */   Object[] getIds();
/*    */   
/*    */   Scriptable getParentScope();
/*    */   
/*    */   Scriptable getPrototype();
/*    */   
/*    */   boolean has(int paramInt, Scriptable paramScriptable);
/*    */   
/*    */   boolean has(String paramString, Scriptable paramScriptable);
/*    */   
/*    */   boolean hasInstance(Scriptable paramScriptable);
/*    */   
/*    */   void put(int paramInt, Scriptable paramScriptable, Object paramObject);
/*    */   
/*    */   void put(String paramString, Scriptable paramScriptable, Object paramObject);
/*    */   
/*    */   void setParentScope(Scriptable paramScriptable);
/*    */   
/*    */   void setPrototype(Scriptable paramScriptable);
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Scriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */