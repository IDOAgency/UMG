/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Label
/*    */ {
/*    */   private static final int FIXUPTABLE_SIZE = 8;
/*    */   private static final boolean DEBUG = true;
/* 46 */   private short itsPC = -1;
/*    */   
/*    */   private int[] itsFixupTable;
/*    */   private int itsFixupTableTop;
/*    */   
/* 51 */   public short getPC() { return this.itsPC; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void fixGotos(byte[] paramArrayOfByte) {
/* 57 */     if (this.itsPC == -1 && this.itsFixupTable != null) {
/* 58 */       throw new RuntimeException("Unlocated label");
/*    */     }
/* 60 */     if (this.itsFixupTable != null) {
/* 61 */       for (byte b = 0; b < this.itsFixupTableTop; b++) {
/* 62 */         int i = this.itsFixupTable[b];
/*    */         
/* 64 */         short s = (short)(this.itsPC - i - 1);
/* 65 */         paramArrayOfByte[i++] = (byte)(s >> 8);
/* 66 */         paramArrayOfByte[i] = (byte)s;
/*    */       } 
/*    */     }
/* 69 */     this.itsFixupTable = null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPC(short paramShort) {
/* 75 */     if (this.itsPC != -1 && this.itsPC != paramShort) {
/* 76 */       throw new RuntimeException("Duplicate label");
/*    */     }
/* 78 */     this.itsPC = paramShort;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addFixup(int paramInt) {
/* 83 */     if (this.itsFixupTable == null) {
/* 84 */       this.itsFixupTableTop = 1;
/* 85 */       this.itsFixupTable = new int[8];
/* 86 */       this.itsFixupTable[0] = paramInt;
/*    */     } else {
/*    */       
/* 89 */       if (this.itsFixupTableTop == this.itsFixupTable.length) {
/* 90 */         int i = this.itsFixupTable.length;
/* 91 */         int[] arrayOfInt = new int[i + 8];
/* 92 */         System.arraycopy(this.itsFixupTable, 0, arrayOfInt, 0, i);
/* 93 */         this.itsFixupTable = arrayOfInt;
/*    */       } 
/* 95 */       this.itsFixupTable[this.itsFixupTableTop++] = paramInt;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Label.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */