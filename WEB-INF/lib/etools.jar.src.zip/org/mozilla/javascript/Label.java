package org.mozilla.javascript;

public class Label {
  private static final int FIXUPTABLE_SIZE = 8;
  
  private static final boolean DEBUG = true;
  
  private short itsPC = -1;
  
  private int[] itsFixupTable;
  
  private int itsFixupTableTop;
  
  public short getPC() { return this.itsPC; }
  
  public void fixGotos(byte[] paramArrayOfByte) {
    if (this.itsPC == -1 && this.itsFixupTable != null)
      throw new RuntimeException("Unlocated label"); 
    if (this.itsFixupTable != null)
      for (byte b = 0; b < this.itsFixupTableTop; b++) {
        int i = this.itsFixupTable[b];
        short s = (short)(this.itsPC - i - 1);
        paramArrayOfByte[i++] = (byte)(s >> 8);
        paramArrayOfByte[i] = (byte)s;
      }  
    this.itsFixupTable = null;
  }
  
  public void setPC(short paramShort) {
    if (this.itsPC != -1 && this.itsPC != paramShort)
      throw new RuntimeException("Duplicate label"); 
    this.itsPC = paramShort;
  }
  
  public void addFixup(int paramInt) {
    if (this.itsFixupTable == null) {
      this.itsFixupTableTop = 1;
      this.itsFixupTable = new int[8];
      this.itsFixupTable[0] = paramInt;
    } else {
      if (this.itsFixupTableTop == this.itsFixupTable.length) {
        int i = this.itsFixupTable.length;
        int[] arrayOfInt = new int[i + 8];
        System.arraycopy(this.itsFixupTable, 0, arrayOfInt, 0, i);
        this.itsFixupTable = arrayOfInt;
      } 
      this.itsFixupTable[this.itsFixupTableTop++] = paramInt;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Label.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */