package org.mozilla.javascript;

final class Source {
  char functionNumber;
  
  StringBuffer buf = new StringBuffer(64);
  
  void append(char paramChar) { this.buf.append(paramChar); }
  
  void addString(int paramInt, String paramString) {
    this.buf.append((char)paramInt);
    this.buf.append((char)paramString.length());
    this.buf.append(paramString);
  }
  
  void addNumber(Number paramNumber) {
    this.buf.append('-');
    if (paramNumber instanceof Double || paramNumber instanceof Float) {
      this.buf.append('D');
      long l = Double.doubleToLongBits(paramNumber.doubleValue());
      this.buf.append((char)(int)(l >> 48 & 0xFFFFL));
      this.buf.append((char)(int)(l >> 32 & 0xFFFFL));
      this.buf.append((char)(int)(l >> 16 & 0xFFFFL));
      this.buf.append((char)(int)(l & 0xFFFFL));
    } else {
      long l = paramNumber.longValue();
      if (l <= 65535L) {
        this.buf.append('S');
        this.buf.append((char)(int)l);
      } else {
        this.buf.append('J');
        this.buf.append((char)(int)(l >> 48 & 0xFFFFL));
        this.buf.append((char)(int)(l >> 32 & 0xFFFFL));
        this.buf.append((char)(int)(l >> 16 & 0xFFFFL));
        this.buf.append((char)(int)(l & 0xFFFFL));
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Source.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */