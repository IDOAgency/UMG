package org.mozilla.javascript;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Enumeration;

public class ScriptRuntime {
  public static final Class UndefinedClass = Undefined.class;
  
  public static final Class ScriptableClass = Scriptable.class;
  
  public static final Class StringClass = String.class;
  
  public static final Class NumberClass = Number.class;
  
  public static final Class BooleanClass = Boolean.class;
  
  public static final Class ByteClass = Byte.class;
  
  public static final Class ShortClass = Short.class;
  
  public static final Class IntegerClass = Integer.class;
  
  public static final Class LongClass = Long.class;
  
  public static final Class FloatClass = Float.class;
  
  public static final Class DoubleClass = Double.class;
  
  public static final Class CharacterClass = Character.class;
  
  public static final Class ObjectClass = Object.class;
  
  public static final Class FunctionClass = Function.class;
  
  public static final Class ClassClass = Class.class;
  
  public static boolean toBoolean(Object paramObject) {
    if (paramObject == null)
      return false; 
    if (paramObject instanceof Scriptable) {
      if (Context.getContext().isVersionECMA1())
        return !(paramObject == Undefined.instance); 
      paramObject = ((Scriptable)paramObject).getDefaultValue(BooleanClass);
      if (paramObject instanceof Scriptable)
        throw errorWithClassName("msg.primitive.expected", paramObject); 
    } 
    if (paramObject instanceof String)
      return !(((String)paramObject).length() == 0); 
    if (paramObject instanceof Number) {
      double d = ((Number)paramObject).doubleValue();
      return !(d != d || d == 0.0D);
    } 
    if (paramObject instanceof Boolean)
      return ((Boolean)paramObject).booleanValue(); 
    throw errorWithClassName("msg.invalid.type", paramObject);
  }
  
  public static double toNumber(Object paramObject) {
    if (paramObject != null && paramObject instanceof Scriptable) {
      paramObject = ((Scriptable)paramObject).getDefaultValue(NumberClass);
      if (paramObject != null && paramObject instanceof Scriptable)
        throw errorWithClassName("msg.primitive.expected", paramObject); 
    } 
    if (paramObject == null)
      return 0.0D; 
    if (paramObject instanceof String)
      return toNumber((String)paramObject); 
    if (paramObject instanceof Number)
      return ((Number)paramObject).doubleValue(); 
    if (paramObject instanceof Boolean)
      return ((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D; 
    throw errorWithClassName("msg.invalid.type", paramObject);
  }
  
  public static double NaN = NaND;
  
  public static Double NaNobj = new Double(NaND);
  
  public static double negativeZero = -0.0D;
  
  private static final boolean MSJVM_BUG_WORKAROUNDS = true;
  
  private static final int NO_INDEX = 5;
  
  private static final char NO_INDEX_CHAR = '5';
  
  static double stringToNumber(String paramString, int paramInt1, int paramInt2) {
    char c1 = '9';
    char c2 = 'a';
    char c3 = 'A';
    int i = paramString.length();
    if (paramInt2 < 10)
      c1 = (char)(48 + paramInt2 - 1); 
    if (paramInt2 > 10) {
      c2 = (char)(97 + paramInt2 - 10);
      c3 = (char)(65 + paramInt2 - 10);
    } 
    double d = 0.0D;
    int j;
    for (j = paramInt1; j < i; j++) {
      char c5, c4 = paramString.charAt(j);
      if (c4 >= '0' && c4 <= c1) {
        c5 = c4 - '0';
      } else if (c4 >= 'a' && c4 < c2) {
        c5 = c4 - 'a' + '\n';
      } else if (c4 >= 'A' && c4 < c3) {
        c5 = c4 - 'A' + '\n';
      } else {
        break;
      } 
      d = d * paramInt2 + c5;
    } 
    if (paramInt1 == j)
      return NaN; 
    if (d >= 9.007199254740992E15D) {
      if (paramInt2 == 10)
        try {
          return Double.valueOf(paramString.substring(paramInt1, j)).doubleValue();
        } catch (NumberFormatException numberFormatException) {
          return NaN;
        }  
      if (paramInt2 == 2 || paramInt2 == 4 || paramInt2 == 8 || 
        paramInt2 == 16 || paramInt2 == 32) {
        int k;
        BinaryDigitReader binaryDigitReader = new BinaryDigitReader(paramInt2, paramString, paramInt1, j);
        d = 0.0D;
        do {
          k = binaryDigitReader.getNextBinaryDigit();
        } while (k == 0);
        if (k == 1) {
          d = 1.0D;
          for (byte b = 52; b != 0; b--) {
            k = binaryDigitReader.getNextBinaryDigit();
            if (k < 0)
              return d; 
            d = d * 2.0D + k;
          } 
          int m = binaryDigitReader.getNextBinaryDigit();
          if (m >= 0) {
            double d1 = 2.0D;
            int n = 0;
            int i1;
            while ((i1 = binaryDigitReader.getNextBinaryDigit()) >= 0) {
              n |= i1;
              d1 *= 2.0D;
            } 
            d += (m & (k | n));
            d *= d1;
          } 
        } 
      } 
    } 
    return d;
  }
  
  public static double toNumber(String paramString) {
    char c1;
    int i = paramString.length();
    byte b = 0;
    while (true) {
      if (b == i)
        return 0.0D; 
      c1 = paramString.charAt(b);
      if (Character.isWhitespace(c1)) {
        b++;
        continue;
      } 
      break;
    } 
    if (c1 == '0' && b + 2 < i && 
      Character.toLowerCase(paramString.charAt(b + 1)) == 'x')
      return stringToNumber(paramString, b + 2, 16); 
    if ((c1 == '+' || c1 == '-') && b + 3 < i && 
      paramString.charAt(b + 1) == '0' && 
      Character.toLowerCase(paramString.charAt(b + 2)) == 'x') {
      double d = stringToNumber(paramString, b + 3, 16);
      return (c1 == '-') ? -d : d;
    } 
    int j = i - 1;
    char c2;
    while (Character.isWhitespace(c2 = paramString.charAt(j)))
      j--; 
    if (c2 == 'y') {
      if (c1 == '+' || c1 == '-')
        b++; 
      String str1 = paramString.substring(b, j + 1);
      if (str1.equals("Infinity"))
        return (c1 == '-') ? 
          Double.NEGATIVE_INFINITY : 
          Double.POSITIVE_INFINITY; 
      return NaN;
    } 
    String str = paramString.substring(b, j + 1);
    for (int k = str.length() - 1; k >= 0; ) {
      char c = str.charAt(k);
      if ((c >= '0' && c <= '9') || c == '.' || 
        c == 'e' || c == 'E' || 
        c == '+' || c == '-') {
        k--;
        continue;
      } 
      return NaN;
    } 
    try {
      return Double.valueOf(str).doubleValue();
    } catch (NumberFormatException numberFormatException) {
      return NaN;
    } 
  }
  
  public static Object[] padArguments(Object[] paramArrayOfObject, int paramInt) {
    if (paramInt < paramArrayOfObject.length)
      return paramArrayOfObject; 
    Object[] arrayOfObject = new Object[paramInt];
    byte b;
    for (b = 0; b < paramArrayOfObject.length; b++)
      arrayOfObject[b] = paramArrayOfObject[b]; 
    for (; b < paramInt; b++)
      arrayOfObject[b] = Undefined.instance; 
    return arrayOfObject;
  }
  
  public static String escapeString(String paramString) {
    String str = "\bb\ff\nn\rr\tt\013v\"\"''";
    StringBuffer stringBuffer = new StringBuffer(paramString.length());
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if (c >= ' ' && c <= '~' && 
        c != '"') {
        stringBuffer.append(c);
      } else {
        int i;
        if ((i = str.indexOf(c)) >= 0) {
          stringBuffer.append("\\");
          stringBuffer.append(str.charAt(i + 1));
        } else if (c < 'Ā') {
          String str1 = Integer.toHexString(c);
          if (str1.length() == 1) {
            stringBuffer.append("\\x0");
            stringBuffer.append(str1);
          } else {
            stringBuffer.append("\\x");
            stringBuffer.append(str1);
          } 
        } else {
          String str1 = Integer.toHexString(c);
          stringBuffer.append("\\u");
          for (int j = str1.length(); j < 4; j++)
            stringBuffer.append("0"); 
          stringBuffer.append(str1);
        } 
      } 
    } 
    return stringBuffer.toString();
  }
  
  public static String toString(Object paramObject) {
    while (true) {
      if (paramObject == null)
        return "null"; 
      if (paramObject instanceof Scriptable) {
        paramObject = ((Scriptable)paramObject).getDefaultValue(StringClass);
        if (paramObject != Undefined.instance && paramObject instanceof Scriptable)
          throw errorWithClassName("msg.primitive.expected", paramObject); 
        continue;
      } 
      break;
    } 
    if (paramObject instanceof Number)
      return numberToString(((Number)paramObject).doubleValue(), 10); 
    return paramObject.toString();
  }
  
  public static String numberToString(double paramDouble, int paramInt) {
    if (paramDouble != paramDouble)
      return "NaN"; 
    if (paramDouble == Double.POSITIVE_INFINITY)
      return "Infinity"; 
    if (paramDouble == Double.NEGATIVE_INFINITY)
      return "-Infinity"; 
    if (paramDouble == 0.0D)
      return "0"; 
    if (paramInt < 2 || paramInt > 36) {
      Object[] arrayOfObject = { Integer.toString(paramInt) };
      throw Context.reportRuntimeError(
          getMessage("msg.bad.radix", arrayOfObject));
    } 
    if (paramInt != 10)
      return DToA.JS_dtobasestr(paramInt, paramDouble); 
    StringBuffer stringBuffer = new StringBuffer();
    DToA.JS_dtostr(stringBuffer, 0, 0, paramDouble);
    return stringBuffer.toString();
  }
  
  public static Scriptable toObject(Scriptable paramScriptable, Object paramObject) { return toObject(paramScriptable, paramObject, null); }
  
  public static Scriptable toObject(Scriptable paramScriptable, Object paramObject, Class paramClass) {
    if (paramObject == null)
      throw NativeGlobal.constructError(
          Context.getContext(), "TypeError", 
          getMessage("msg.null.to.object", null), 
          paramScriptable); 
    if (paramObject instanceof Scriptable) {
      if (paramObject == Undefined.instance)
        throw NativeGlobal.constructError(
            Context.getContext(), "TypeError", 
            getMessage("msg.undef.to.object", null), 
            paramScriptable); 
      return (Scriptable)paramObject;
    } 
    String str = (paramObject instanceof String) ? "String" : (
      (paramObject instanceof Number) ? "Number" : (
      (paramObject instanceof Boolean) ? "Boolean" : 
      null));
    if (str == null) {
      Object object = NativeJavaObject.wrap(paramScriptable, paramObject, paramClass);
      if (object instanceof Scriptable)
        return (Scriptable)object; 
      throw errorWithClassName("msg.invalid.type", paramObject);
    } 
    Object[] arrayOfObject = { paramObject };
    paramScriptable = ScriptableObject.getTopLevelScope(paramScriptable);
    return newObject(Context.getContext(), paramScriptable, 
        str, arrayOfObject);
  }
  
  public static Scriptable newObject(Context paramContext, Scriptable paramScriptable, String paramString, Object[] paramArrayOfObject) {
    JavaScriptException javaScriptException = null;
    try {
      return paramContext.newObject(paramScriptable, paramString, paramArrayOfObject);
    } catch (NotAFunctionException notAFunctionException) {
      javaScriptException = notAFunctionException;
    } catch (PropertyException propertyException2) {
      PropertyException propertyException1 = propertyException2;
    } catch (JavaScriptException javaScriptException1) {
      javaScriptException = javaScriptException1;
    } 
    throw Context.reportRuntimeError(javaScriptException.getMessage());
  }
  
  public static double toInteger(Object paramObject) {
    double d = toNumber(paramObject);
    if (d != d)
      return 0.0D; 
    if (d == 0.0D || 
      d == Double.POSITIVE_INFINITY || 
      d == Double.NEGATIVE_INFINITY)
      return d; 
    if (d > 0.0D)
      return Math.floor(d); 
    return Math.ceil(d);
  }
  
  public static double toInteger(double paramDouble) {
    if (paramDouble != paramDouble)
      return 0.0D; 
    if (paramDouble == 0.0D || 
      paramDouble == Double.POSITIVE_INFINITY || 
      paramDouble == Double.NEGATIVE_INFINITY)
      return paramDouble; 
    if (paramDouble > 0.0D)
      return Math.floor(paramDouble); 
    return Math.ceil(paramDouble);
  }
  
  public static int toInt32(Object paramObject) {
    double d1 = 4.294967296E9D;
    double d2 = 2.147483648E9D;
    if (paramObject instanceof Byte)
      return ((Number)paramObject).intValue(); 
    double d3 = toNumber(paramObject);
    if (d3 != d3 || d3 == 0.0D || 
      d3 == Double.POSITIVE_INFINITY || 
      d3 == Double.NEGATIVE_INFINITY)
      return 0; 
    d3 = Math.IEEEremainder(d3, d1);
    d3 = (d3 >= 0.0D) ? 
      d3 : (
      d3 + d1);
    if (d3 >= d2)
      return (int)(d3 - d1); 
    return (int)d3;
  }
  
  public static int toInt32(double paramDouble) {
    double d1 = 4.294967296E9D;
    double d2 = 2.147483648E9D;
    if (paramDouble != paramDouble || paramDouble == 0.0D || 
      paramDouble == Double.POSITIVE_INFINITY || 
      paramDouble == Double.NEGATIVE_INFINITY)
      return 0; 
    paramDouble = Math.IEEEremainder(paramDouble, d1);
    paramDouble = (paramDouble >= 0.0D) ? 
      paramDouble : (
      paramDouble + d1);
    if (paramDouble >= d2)
      return (int)(paramDouble - d1); 
    return (int)paramDouble;
  }
  
  public static long toUint32(double paramDouble) {
    double d = 4.294967296E9D;
    if (paramDouble != paramDouble || paramDouble == 0.0D || 
      paramDouble == Double.POSITIVE_INFINITY || 
      paramDouble == Double.NEGATIVE_INFINITY)
      return 0L; 
    if (paramDouble > 0.0D) {
      paramDouble = Math.floor(paramDouble);
    } else {
      paramDouble = Math.ceil(paramDouble);
    } 
    paramDouble = Math.IEEEremainder(paramDouble, d);
    paramDouble = (paramDouble >= 0.0D) ? 
      paramDouble : (
      paramDouble + d);
    return (long)Math.floor(paramDouble);
  }
  
  public static long toUint32(Object paramObject) { return toUint32(toNumber(paramObject)); }
  
  public static char toUint16(Object paramObject) {
    long l = 65536L;
    double d = toNumber(paramObject);
    if (d != d || d == 0.0D || 
      d == Double.POSITIVE_INFINITY || 
      d == Double.NEGATIVE_INFINITY)
      return Character.MIN_VALUE; 
    d = Math.IEEEremainder(d, l);
    d = (d >= 0.0D) ? 
      d : (
      d + l);
    return (char)(int)Math.floor(d);
  }
  
  public static Object unwrapJavaScriptException(JavaScriptException paramJavaScriptException) { return paramJavaScriptException.value; }
  
  public static Object getProp(Object paramObject, String paramString, Scriptable paramScriptable) {
    Scriptable scriptable1;
    if (paramObject instanceof Scriptable) {
      scriptable1 = (Scriptable)paramObject;
    } else {
      scriptable1 = toObject(paramScriptable, paramObject);
    } 
    if (scriptable1 == null || scriptable1 == Undefined.instance) {
      String str = (scriptable1 == null) ? "msg.null.to.object" : 
        "msg.undefined";
      throw NativeGlobal.constructError(
          Context.getContext(), "ConversionError", 
          getMessage(str, null), 
          paramScriptable);
    } 
    Scriptable scriptable2 = scriptable1;
    do {
      Object object = scriptable2.get(paramString, scriptable1);
      if (object != Scriptable.NOT_FOUND)
        return object; 
      scriptable2 = scriptable2.getPrototype();
    } while (scriptable2 != null);
    return Undefined.instance;
  }
  
  public static Object getTopLevelProp(Scriptable paramScriptable, String paramString) {
    Object object;
    Scriptable scriptable = ScriptableObject.getTopLevelScope(paramScriptable);
    do {
      object = scriptable.get(paramString, scriptable);
      if (object != Scriptable.NOT_FOUND)
        return object; 
      scriptable = scriptable.getPrototype();
    } while (scriptable != null);
    return object;
  }
  
  public static Scriptable getProto(Object paramObject, Scriptable paramScriptable) {
    Scriptable scriptable;
    if (paramObject instanceof Scriptable) {
      scriptable = (Scriptable)paramObject;
    } else {
      scriptable = toObject(paramScriptable, paramObject);
    } 
    if (scriptable == null)
      throw NativeGlobal.constructError(
          Context.getContext(), "TypeError", 
          getMessage("msg.null.to.object", null), 
          paramScriptable); 
    return scriptable.getPrototype();
  }
  
  public static Scriptable getParent(Object paramObject) {
    Scriptable scriptable;
    try {
      scriptable = (Scriptable)paramObject;
    } catch (ClassCastException classCastException) {
      return null;
    } 
    if (scriptable == null)
      return null; 
    return getThis(scriptable.getParentScope());
  }
  
  public static Scriptable getParent(Object paramObject, Scriptable paramScriptable) {
    Scriptable scriptable;
    if (paramObject instanceof Scriptable) {
      scriptable = (Scriptable)paramObject;
    } else {
      scriptable = toObject(paramScriptable, paramObject);
    } 
    if (scriptable == null)
      throw NativeGlobal.constructError(
          Context.getContext(), "TypeError", 
          getMessage("msg.null.to.object", null), 
          paramScriptable); 
    return scriptable.getParentScope();
  }
  
  public static Object setProto(Object paramObject1, Object paramObject2, Scriptable paramScriptable) {
    Scriptable scriptable1;
    if (paramObject1 instanceof Scriptable) {
      scriptable1 = (Scriptable)paramObject1;
    } else {
      scriptable1 = toObject(paramScriptable, paramObject1);
    } 
    Scriptable scriptable2 = (paramObject2 == null) ? null : toObject(paramScriptable, paramObject2);
    Scriptable scriptable3 = scriptable2;
    while (scriptable3 != null) {
      if (scriptable3 == scriptable1) {
        Object[] arrayOfObject = { "__proto__" };
        throw Context.reportRuntimeError(
            getMessage("msg.cyclic.value", arrayOfObject));
      } 
      scriptable3 = scriptable3.getPrototype();
    } 
    if (scriptable1 == null)
      throw NativeGlobal.constructError(
          Context.getContext(), "TypeError", 
          getMessage("msg.null.to.object", null), 
          paramScriptable); 
    scriptable1.setPrototype(scriptable2);
    return scriptable2;
  }
  
  public static Object setParent(Object paramObject1, Object paramObject2, Scriptable paramScriptable) {
    Scriptable scriptable1;
    if (paramObject1 instanceof Scriptable) {
      scriptable1 = (Scriptable)paramObject1;
    } else {
      scriptable1 = toObject(paramScriptable, paramObject1);
    } 
    Scriptable scriptable2 = (paramObject2 == null) ? null : toObject(paramScriptable, paramObject2);
    Scriptable scriptable3 = scriptable2;
    while (scriptable3 != null) {
      if (scriptable3 == scriptable1) {
        Object[] arrayOfObject = { "__parent__" };
        throw Context.reportRuntimeError(
            getMessage("msg.cyclic.value", arrayOfObject));
      } 
      scriptable3 = scriptable3.getParentScope();
    } 
    if (scriptable1 == null)
      throw NativeGlobal.constructError(
          Context.getContext(), "TypeError", 
          getMessage("msg.null.to.object", null), 
          paramScriptable); 
    scriptable1.setParentScope(scriptable2);
    return scriptable2;
  }
  
  public static Object setProp(Object paramObject1, String paramString, Object paramObject2, Scriptable paramScriptable) {
    Scriptable scriptable1;
    if (paramObject1 instanceof Scriptable) {
      scriptable1 = (Scriptable)paramObject1;
    } else {
      scriptable1 = toObject(paramScriptable, paramObject1);
    } 
    if (scriptable1 == null)
      throw NativeGlobal.constructError(
          Context.getContext(), "TypeError", 
          getMessage("msg.null.to.object", null), 
          paramScriptable); 
    Scriptable scriptable2 = scriptable1;
    do {
      if (scriptable2.has(paramString, scriptable1)) {
        scriptable2.put(paramString, scriptable1, paramObject2);
        return paramObject2;
      } 
      scriptable2 = scriptable2.getPrototype();
    } while (scriptable2 != null);
    scriptable1.put(paramString, scriptable1, paramObject2);
    return paramObject2;
  }
  
  private static final int MAX_VALUE_LENGTH = Integer.toString(2147483647).length();
  
  private static Method getContextClassLoaderMethod;
  
  public static Object[] emptyArgs;
  
  private static int indexFromString(String paramString) {
    int i = paramString.length();
    char c;
    if (i > 0 && (c = paramString.charAt(0)) >= '0' && c <= '9' && 
      i <= MAX_VALUE_LENGTH) {
      char c1 = c - '0';
      char c2 = Character.MIN_VALUE;
      byte b = 1;
      if (c1 != '\000')
        while (b < i && (c = paramString.charAt(b)) >= '0' && c <= '9') {
          c2 = c1;
          c1 = '\n' * c1 + c - '0';
          b++;
        }  
      if (b == i && (
        c2 < 214748364 || (
        c2 == 214748364 && 
        c < '\007')))
        return c1; 
    } 
    return 5;
  }
  
  static String getStringId(Object paramObject) {
    if (paramObject instanceof Number) {
      double d = ((Number)paramObject).doubleValue();
      int j = (int)d;
      if (j == d)
        return null; 
      return toString(paramObject);
    } 
    String str = toString(paramObject);
    int i = indexFromString(str);
    if (i != 5 || (str.length() == 1 && 
      str.charAt(0) == '5'))
      return null; 
    return str;
  }
  
  static int getIntId(Object paramObject) {
    if (paramObject instanceof Number) {
      double d = ((Number)paramObject).doubleValue();
      int j = (int)d;
      if (j == d)
        return j; 
      return 0;
    } 
    String str = toString(paramObject);
    int i = indexFromString(str);
    if (i != 5 || (str.length() == 1 && 
      str.charAt(0) == '5'))
      return i; 
    return 0;
  }
  
  public static Object getElem(Object paramObject1, Object paramObject2, Scriptable paramScriptable) {
    String str;
    int i;
    if (paramObject2 instanceof Number) {
      double d = ((Number)paramObject2).doubleValue();
      i = (int)d;
      str = (i == d) ? null : toString(paramObject2);
    } else {
      str = toString(paramObject2);
      i = indexFromString(str);
      if (i != 5) {
        str = null;
      } else if (str.length() == 1 && str.charAt(0) == '5') {
        str = null;
      } 
    } 
    Scriptable scriptable1 = (paramObject1 instanceof Scriptable) ? 
      (Scriptable)paramObject1 : 
      toObject(paramScriptable, paramObject1);
    Scriptable scriptable2 = scriptable1;
    if (str != null) {
      if (str.equals("__proto__"))
        return scriptable1.getPrototype(); 
      if (str.equals("__parent__"))
        return scriptable1.getParentScope(); 
      while (scriptable2 != null) {
        Object object = scriptable2.get(str, scriptable1);
        if (object != Scriptable.NOT_FOUND)
          return object; 
        scriptable2 = scriptable2.getPrototype();
      } 
      return Undefined.instance;
    } 
    while (scriptable2 != null) {
      Object object = scriptable2.get(i, scriptable1);
      if (object != Scriptable.NOT_FOUND)
        return object; 
      scriptable2 = scriptable2.getPrototype();
    } 
    return Undefined.instance;
  }
  
  public static Object getElem(Scriptable paramScriptable, int paramInt) {
    Scriptable scriptable = paramScriptable;
    while (scriptable != null) {
      Object object = scriptable.get(paramInt, paramScriptable);
      if (object != Scriptable.NOT_FOUND)
        return object; 
      scriptable = scriptable.getPrototype();
    } 
    return Undefined.instance;
  }
  
  public static Object setElem(Object paramObject1, Object paramObject2, Object paramObject3, Scriptable paramScriptable) {
    String str;
    int i;
    if (paramObject2 instanceof Number) {
      double d = ((Number)paramObject2).doubleValue();
      i = (int)d;
      str = (i == d) ? null : toString(paramObject2);
    } else {
      str = toString(paramObject2);
      i = indexFromString(str);
      if (i != 5) {
        str = null;
      } else if (str.length() == 1 && str.charAt(0) == '5') {
        str = null;
      } 
    } 
    Scriptable scriptable1 = (paramObject1 instanceof Scriptable) ? 
      (Scriptable)paramObject1 : 
      toObject(paramScriptable, paramObject1);
    Scriptable scriptable2 = scriptable1;
    if (str != null) {
      if (str.equals("__proto__"))
        return setProto(paramObject1, paramObject3, paramScriptable); 
      if (str.equals("__parent__"))
        return setParent(paramObject1, paramObject3, paramScriptable); 
      do {
        if (scriptable2.has(str, scriptable1)) {
          scriptable2.put(str, scriptable1, paramObject3);
          return paramObject3;
        } 
        scriptable2 = scriptable2.getPrototype();
      } while (scriptable2 != null);
      scriptable1.put(str, scriptable1, paramObject3);
      return paramObject3;
    } 
    do {
      if (scriptable2.has(i, scriptable1)) {
        scriptable2.put(i, scriptable1, paramObject3);
        return paramObject3;
      } 
      scriptable2 = scriptable2.getPrototype();
    } while (scriptable2 != null);
    scriptable1.put(i, scriptable1, paramObject3);
    return paramObject3;
  }
  
  public static Object setElem(Scriptable paramScriptable, int paramInt, Object paramObject) {
    Scriptable scriptable = paramScriptable;
    do {
      if (scriptable.has(paramInt, paramScriptable)) {
        scriptable.put(paramInt, paramScriptable, paramObject);
        return paramObject;
      } 
      scriptable = scriptable.getPrototype();
    } while (scriptable != null);
    paramScriptable.put(paramInt, paramScriptable, paramObject);
    return paramObject;
  }
  
  public static Object delete(Object paramObject1, Object paramObject2) {
    if (!(paramObject1 instanceof Scriptable))
      return Boolean.TRUE; 
    FlattenedObject flattenedObject = new FlattenedObject((Scriptable)paramObject1);
    return flattenedObject.deleteProperty(paramObject2) ? Boolean.TRUE : Boolean.FALSE;
  }
  
  public static Object name(Scriptable paramScriptable, String paramString) {
    Scriptable scriptable = paramScriptable;
    while (scriptable != null) {
      Scriptable scriptable1 = scriptable;
      do {
        Object object = scriptable1.get(paramString, scriptable);
        if (object != Scriptable.NOT_FOUND)
          return object; 
        scriptable1 = scriptable1.getPrototype();
      } while (scriptable1 != null);
      scriptable = scriptable.getParentScope();
    } 
    Object[] arrayOfObject = { paramString.toString() };
    throw NativeGlobal.constructError(
        Context.getContext(), "ReferenceError", 
        getMessage("msg.is.not.defined", arrayOfObject), 
        paramScriptable);
  }
  
  public static Scriptable bind(Scriptable paramScriptable, String paramString) {
    Scriptable scriptable = paramScriptable;
    while (scriptable != null) {
      Scriptable scriptable1 = scriptable;
      do {
        if (scriptable1.has(paramString, scriptable))
          return scriptable; 
        scriptable1 = scriptable1.getPrototype();
      } while (scriptable1 != null);
      scriptable = scriptable.getParentScope();
    } 
    return null;
  }
  
  public static Scriptable getBase(Scriptable paramScriptable, String paramString) {
    Scriptable scriptable = paramScriptable;
    while (scriptable != null) {
      Scriptable scriptable1 = scriptable;
      do {
        if (scriptable1.get(paramString, scriptable) != Scriptable.NOT_FOUND)
          return scriptable; 
        scriptable1 = scriptable1.getPrototype();
      } while (scriptable1 != null);
      scriptable = scriptable.getParentScope();
    } 
    Object[] arrayOfObject = { paramString };
    throw NativeGlobal.constructError(
        Context.getContext(), "ReferenceError", 
        getMessage("msg.is.not.defined", arrayOfObject), 
        paramScriptable);
  }
  
  public static Scriptable getThis(Scriptable paramScriptable) {
    while (paramScriptable instanceof NativeWith)
      paramScriptable = paramScriptable.getPrototype(); 
    if (paramScriptable instanceof NativeCall)
      paramScriptable = ScriptableObject.getTopLevelScope(paramScriptable); 
    return paramScriptable;
  }
  
  public static Object setName(Scriptable paramScriptable1, Object paramObject, Scriptable paramScriptable2, String paramString) {
    if (paramScriptable1 == null) {
      Scriptable scriptable = paramScriptable2;
      do {
        paramScriptable1 = scriptable;
        scriptable = paramScriptable1.getParentScope();
      } while (scriptable != null);
      paramScriptable1.put(paramString, paramScriptable1, paramObject);
      String[] arrayOfString = { paramString };
      String str = getMessage("msg.assn.create", arrayOfString);
      Context.reportWarning(str);
      return paramObject;
    } 
    return setProp(paramScriptable1, paramString, paramObject, paramScriptable2);
  }
  
  public static Enumeration initEnum(Object paramObject, Scriptable paramScriptable) {
    Scriptable scriptable = toObject(paramScriptable, paramObject);
    return new IdEnumeration(scriptable);
  }
  
  public static Object nextEnum(Enumeration paramEnumeration) {
    if (!paramEnumeration.hasMoreElements())
      return null; 
    return paramEnumeration.nextElement();
  }
  
  public static Object call(Context paramContext, Object paramObject1, Object paramObject2, Object[] paramArrayOfObject) throws JavaScriptException {
    Scriptable scriptable = null;
    if (paramObject1 instanceof Scriptable)
      scriptable = ((Scriptable)paramObject1).getParentScope(); 
    return call(paramContext, paramObject1, paramObject2, paramArrayOfObject, scriptable);
  }
  
  public static Object call(Context paramContext, Object paramObject1, Object paramObject2, Object[] paramArrayOfObject, Scriptable paramScriptable) throws JavaScriptException {
    Scriptable scriptable;
    Function function;
    try {
      function = (Function)paramObject1;
    } catch (ClassCastException classCastException) {
      scriptable = new Object[] { toString(paramObject1) };
      throw NativeGlobal.constructError(
          Context.getContext(), "TypeError", 
          getMessage("msg.isnt.function", 
            scriptable), 
          paramScriptable);
    } 
    if (paramObject2 instanceof Scriptable || paramObject2 == null) {
      scriptable = (Scriptable)paramObject2;
    } else {
      scriptable = toObject(paramScriptable, paramObject2);
    } 
    return function.call(paramContext, paramScriptable, scriptable, paramArrayOfObject);
  }
  
  private static Object callOrNewSpecial(Context paramContext, Scriptable paramScriptable, Object paramObject1, Object paramObject2, Object paramObject3, Object[] paramArrayOfObject, boolean paramBoolean, String paramString, int paramInt) throws JavaScriptException {
    if (paramObject1 instanceof FunctionObject) {
      FunctionObject functionObject = (FunctionObject)paramObject1;
      Method method = functionObject.method;
      Class clazz = method.getDeclaringClass();
      String str = method.getName();
      if (str.equals("eval") && clazz == NativeGlobal.class)
        return NativeGlobal.evalSpecial(paramContext, paramScriptable, paramObject3, paramArrayOfObject, 
            paramString, paramInt); 
      if (str.equals("With") && clazz == NativeWith.class)
        return NativeWith.newWithSpecial(paramContext, paramArrayOfObject, functionObject, paramBoolean ^ true); 
      if (str.equals("jsFunction_exec") && clazz == NativeScript.class)
        return ((NativeScript)paramObject2).exec(paramContext, ScriptableObject.getTopLevelScope(paramScriptable)); 
      if (str.equals("exec") && 
        paramContext.getRegExpProxy() != null && 
        paramContext.getRegExpProxy().isRegExp(paramObject2))
        return call(paramContext, paramObject1, paramObject2, paramArrayOfObject, paramScriptable); 
    } else if (paramObject1 instanceof NativeJavaMethod) {
      return call(paramContext, paramObject1, paramObject2, paramArrayOfObject, paramScriptable);
    } 
    if (paramBoolean)
      return call(paramContext, paramObject1, paramObject3, paramArrayOfObject, paramScriptable); 
    return newObject(paramContext, paramObject1, paramArrayOfObject, paramScriptable);
  }
  
  public static Object callSpecial(Context paramContext, Object paramObject1, Object paramObject2, Object[] paramArrayOfObject, Scriptable paramScriptable1, Scriptable paramScriptable2, String paramString, int paramInt) throws JavaScriptException {
    return callOrNewSpecial(paramContext, paramScriptable2, paramObject1, paramObject2, 
        paramScriptable1, paramArrayOfObject, true, 
        paramString, paramInt);
  }
  
  public static Scriptable newObject(Context paramContext, Object paramObject, Object[] paramArrayOfObject, Scriptable paramScriptable) throws JavaScriptException {
    try {
      Function function = (Function)paramObject;
      if (function != null)
        return function.construct(paramContext, paramScriptable, paramArrayOfObject); 
    } catch (ClassCastException classCastException) {}
    Object[] arrayOfObject = { toString(paramObject) };
    throw NativeGlobal.constructError(
        Context.getContext(), "TypeError", 
        getMessage("msg.isnt.function", arrayOfObject), 
        paramScriptable);
  }
  
  public static Scriptable newObjectSpecial(Context paramContext, Object paramObject, Object[] paramArrayOfObject, Scriptable paramScriptable) throws JavaScriptException {
    return (Scriptable)callOrNewSpecial(paramContext, paramScriptable, paramObject, null, null, paramArrayOfObject, 
        false, null, -1);
  }
  
  public static String typeof(Object paramObject) {
    if (paramObject == Undefined.instance)
      return "undefined"; 
    if (paramObject == null)
      return "object"; 
    if (paramObject instanceof Scriptable)
      return (paramObject instanceof Function) ? "function" : "object"; 
    if (paramObject instanceof String)
      return "string"; 
    if (paramObject instanceof Number)
      return "number"; 
    if (paramObject instanceof Boolean)
      return "boolean"; 
    throw errorWithClassName("msg.invalid.type", paramObject);
  }
  
  public static String typeofName(Scriptable paramScriptable, String paramString) {
    Scriptable scriptable = bind(paramScriptable, paramString);
    if (scriptable == null)
      return "undefined"; 
    return typeof(getProp(scriptable, paramString, paramScriptable));
  }
  
  public static Object add(Object paramObject1, Object paramObject2) {
    if (paramObject1 instanceof Scriptable)
      paramObject1 = ((Scriptable)paramObject1).getDefaultValue(null); 
    if (paramObject2 instanceof Scriptable)
      paramObject2 = ((Scriptable)paramObject2).getDefaultValue(null); 
    if (!(paramObject1 instanceof String) && !(paramObject2 instanceof String)) {
      if (paramObject1 instanceof Number && paramObject2 instanceof Number)
        return new Double(((Number)paramObject1).doubleValue() + (
            (Number)paramObject2).doubleValue()); 
      return new Double(toNumber(paramObject1) + toNumber(paramObject2));
    } 
    return String.valueOf(toString(paramObject1)) + toString(paramObject2);
  }
  
  public static Object postIncrement(Object paramObject) {
    if (paramObject instanceof Number) {
      paramObject = new Double(((Number)paramObject).doubleValue() + 1.0D);
    } else {
      paramObject = new Double(toNumber(paramObject) + 1.0D);
    } 
    return paramObject;
  }
  
  public static Object postIncrement(Scriptable paramScriptable, String paramString) {
    Scriptable scriptable = paramScriptable;
    while (scriptable != null) {
      Scriptable scriptable1 = scriptable;
      do {
        Object object = scriptable1.get(paramString, scriptable);
        if (object != Scriptable.NOT_FOUND) {
          Object object1 = object;
          if (object1 instanceof Number) {
            object1 = new Double((
                (Number)object1).doubleValue() + 1.0D);
            scriptable1.put(paramString, scriptable, object1);
            return object;
          } 
          object1 = new Double(toNumber(object1) + 1.0D);
          scriptable1.put(paramString, scriptable, object1);
          return new Double(toNumber(object));
        } 
        scriptable1 = scriptable1.getPrototype();
      } while (scriptable1 != null);
      scriptable = scriptable.getParentScope();
    } 
    Object[] arrayOfObject = { paramString };
    throw NativeGlobal.constructError(
        Context.getContext(), "ReferenceError", 
        getMessage("msg.is.not.defined", arrayOfObject), 
        paramScriptable);
  }
  
  public static Object postIncrement(Object paramObject, String paramString, Scriptable paramScriptable) {
    Scriptable scriptable1;
    if (paramObject instanceof Scriptable) {
      scriptable1 = (Scriptable)paramObject;
    } else {
      scriptable1 = toObject(paramScriptable, paramObject);
    } 
    if (scriptable1 == null)
      throw NativeGlobal.constructError(
          Context.getContext(), "TypeError", 
          getMessage("msg.null.to.object", null), 
          paramScriptable); 
    Scriptable scriptable2 = scriptable1;
    do {
      Object object = scriptable2.get(paramString, scriptable1);
      if (object != Scriptable.NOT_FOUND) {
        Object object1 = object;
        if (object1 instanceof Number) {
          object1 = new Double((
              (Number)object1).doubleValue() + 1.0D);
          scriptable2.put(paramString, scriptable1, object1);
          return object;
        } 
        object1 = new Double(toNumber(object1) + 1.0D);
        scriptable2.put(paramString, scriptable1, object1);
        return new Double(toNumber(object));
      } 
      scriptable2 = scriptable2.getPrototype();
    } while (scriptable2 != null);
    return Undefined.instance;
  }
  
  public static Object postIncrementElem(Object paramObject1, Object paramObject2, Scriptable paramScriptable) {
    Object object = getElem(paramObject1, paramObject2, paramScriptable);
    if (object == Undefined.instance)
      return Undefined.instance; 
    double d = toNumber(object);
    Double double = new Double(d + 1.0D);
    setElem(paramObject1, paramObject2, double, paramScriptable);
    return new Double(d);
  }
  
  public static Object postDecrementElem(Object paramObject1, Object paramObject2, Scriptable paramScriptable) {
    Object object = getElem(paramObject1, paramObject2, paramScriptable);
    if (object == Undefined.instance)
      return Undefined.instance; 
    double d = toNumber(object);
    Double double = new Double(d - 1.0D);
    setElem(paramObject1, paramObject2, double, paramScriptable);
    return new Double(d);
  }
  
  public static Object postDecrement(Object paramObject) {
    if (paramObject instanceof Number) {
      paramObject = new Double(((Number)paramObject).doubleValue() - 1.0D);
    } else {
      paramObject = new Double(toNumber(paramObject) - 1.0D);
    } 
    return paramObject;
  }
  
  public static Object postDecrement(Scriptable paramScriptable, String paramString) {
    Scriptable scriptable = paramScriptable;
    while (scriptable != null) {
      Scriptable scriptable1 = scriptable;
      do {
        Object object = scriptable1.get(paramString, scriptable);
        if (object != Scriptable.NOT_FOUND) {
          Object object1 = object;
          if (object1 instanceof Number) {
            object1 = new Double((
                (Number)object1).doubleValue() - 1.0D);
            scriptable1.put(paramString, scriptable, object1);
            return object;
          } 
          object1 = new Double(toNumber(object1) - 1.0D);
          scriptable1.put(paramString, scriptable, object1);
          return new Double(toNumber(object));
        } 
        scriptable1 = scriptable1.getPrototype();
      } while (scriptable1 != null);
      scriptable = scriptable.getParentScope();
    } 
    Object[] arrayOfObject = { paramString };
    throw NativeGlobal.constructError(
        Context.getContext(), "ReferenceError", 
        getMessage("msg.is.not.defined", arrayOfObject), 
        paramScriptable);
  }
  
  public static Object postDecrement(Object paramObject, String paramString, Scriptable paramScriptable) {
    Scriptable scriptable1;
    if (paramObject instanceof Scriptable) {
      scriptable1 = (Scriptable)paramObject;
    } else {
      scriptable1 = toObject(paramScriptable, paramObject);
    } 
    if (scriptable1 == null)
      throw NativeGlobal.constructError(
          Context.getContext(), "TypeError", 
          getMessage("msg.null.to.object", null), 
          paramScriptable); 
    Scriptable scriptable2 = scriptable1;
    do {
      Object object = scriptable2.get(paramString, scriptable1);
      if (object != Scriptable.NOT_FOUND) {
        Object object1 = object;
        if (object1 instanceof Number) {
          object1 = new Double((
              (Number)object1).doubleValue() - 1.0D);
          scriptable2.put(paramString, scriptable1, object1);
          return object;
        } 
        object1 = new Double(toNumber(object1) - 1.0D);
        scriptable2.put(paramString, scriptable1, object1);
        return new Double(toNumber(object));
      } 
      scriptable2 = scriptable2.getPrototype();
    } while (scriptable2 != null);
    return Undefined.instance;
  }
  
  public static Object toPrimitive(Object paramObject) {
    if (paramObject == null || !(paramObject instanceof Scriptable))
      return paramObject; 
    Object object = ((Scriptable)paramObject).getDefaultValue(null);
    if (object != null && object instanceof Scriptable)
      throw NativeGlobal.constructError(
          Context.getContext(), "TypeError", 
          getMessage("msg.bad.default.value", null), 
          paramObject); 
    return object;
  }
  
  private static Class getTypeOfValue(Object paramObject) {
    if (paramObject == null)
      return ScriptableClass; 
    if (paramObject == Undefined.instance)
      return UndefinedClass; 
    if (paramObject instanceof Scriptable)
      return ScriptableClass; 
    if (paramObject instanceof Number)
      return NumberClass; 
    return paramObject.getClass();
  }
  
  public static boolean eq(Object paramObject1, Object paramObject2) {
    Object object1 = paramObject1;
    Object object2 = paramObject2;
    while (true) {
      Class clazz1 = getTypeOfValue(paramObject1);
      Class clazz2 = getTypeOfValue(paramObject2);
      if (clazz1 == clazz2) {
        if (clazz1 == UndefinedClass)
          return true; 
        if (clazz1 == NumberClass)
          return !(((Number)paramObject1).doubleValue() != (
            (Number)paramObject2).doubleValue()); 
        if (clazz1 == StringClass || clazz1 == BooleanClass)
          return object1.equals(object2); 
        if (clazz1 == ScriptableClass) {
          if (paramObject1 == paramObject2)
            return true; 
          if (paramObject1 instanceof NativeJavaObject && 
            paramObject2 instanceof NativeJavaObject)
            return !(((NativeJavaObject)paramObject1).unwrap() != (
              (NativeJavaObject)paramObject2).unwrap()); 
          return false;
        } 
        throw new RuntimeException();
      } 
      if (paramObject1 == null && paramObject2 == Undefined.instance)
        return true; 
      if (paramObject1 == Undefined.instance && paramObject2 == null)
        return true; 
      if (clazz1 == NumberClass && 
        clazz2 == StringClass)
        return !(((Number)paramObject1).doubleValue() != toNumber(paramObject2)); 
      if (clazz1 == StringClass && 
        clazz2 == NumberClass)
        return !(toNumber(paramObject1) != ((Number)paramObject2).doubleValue()); 
      if (clazz1 == BooleanClass) {
        paramObject1 = new Double(toNumber(paramObject1));
        object1 = paramObject1;
        continue;
      } 
      if (clazz2 == BooleanClass) {
        paramObject2 = new Double(toNumber(paramObject2));
        object2 = paramObject2;
        continue;
      } 
      if ((clazz1 == StringClass || 
        clazz1 == NumberClass) && 
        clazz2 == ScriptableClass && paramObject2 != null) {
        paramObject2 = toPrimitive(paramObject2);
        object2 = paramObject2;
        continue;
      } 
      if (clazz1 == ScriptableClass && paramObject1 != null && (
        clazz2 == StringClass || 
        clazz2 == NumberClass)) {
        paramObject1 = toPrimitive(paramObject1);
        object1 = paramObject1;
        continue;
      } 
      break;
    } 
    return false;
  }
  
  public static Boolean eqB(Object paramObject1, Object paramObject2) {
    if (eq(paramObject1, paramObject2))
      return Boolean.TRUE; 
    return Boolean.FALSE;
  }
  
  public static Boolean neB(Object paramObject1, Object paramObject2) {
    if (eq(paramObject1, paramObject2))
      return Boolean.FALSE; 
    return Boolean.TRUE;
  }
  
  public static boolean shallowEq(Object paramObject1, Object paramObject2) {
    Class clazz = getTypeOfValue(paramObject1);
    if (clazz != getTypeOfValue(paramObject2))
      return false; 
    if (clazz == StringClass || clazz == BooleanClass)
      return paramObject1.equals(paramObject2); 
    if (clazz == NumberClass)
      return !(((Number)paramObject1).doubleValue() != (
        (Number)paramObject2).doubleValue()); 
    if (clazz == ScriptableClass) {
      if (paramObject1 == paramObject2)
        return true; 
      if (paramObject1 instanceof NativeJavaObject && paramObject2 instanceof NativeJavaObject)
        return !(((NativeJavaObject)paramObject1).unwrap() != (
          (NativeJavaObject)paramObject2).unwrap()); 
      return false;
    } 
    if (clazz == UndefinedClass)
      return true; 
    return false;
  }
  
  public static Boolean seqB(Object paramObject1, Object paramObject2) {
    if (shallowEq(paramObject1, paramObject2))
      return Boolean.TRUE; 
    return Boolean.FALSE;
  }
  
  public static Boolean sneB(Object paramObject1, Object paramObject2) {
    if (shallowEq(paramObject1, paramObject2))
      return Boolean.FALSE; 
    return Boolean.TRUE;
  }
  
  public static boolean instanceOf(Scriptable paramScriptable, Object paramObject1, Object paramObject2) {
    if (!(paramObject2 instanceof Scriptable))
      throw NativeGlobal.constructError(
          Context.getContext(), "TypeError", 
          getMessage("msg.instanceof.not.object", null), 
          paramScriptable); 
    if (!(paramObject1 instanceof Scriptable))
      return false; 
    return ((Scriptable)paramObject2).hasInstance((Scriptable)paramObject1);
  }
  
  protected static boolean jsDelegatesTo(Scriptable paramScriptable1, Scriptable paramScriptable2) {
    Scriptable scriptable = paramScriptable1.getPrototype();
    while (scriptable != null) {
      if (scriptable.equals(paramScriptable2))
        return true; 
      scriptable = scriptable.getPrototype();
    } 
    return false;
  }
  
  public static boolean in(Object paramObject1, Object paramObject2) {
    if (!(paramObject2 instanceof Scriptable))
      throw NativeGlobal.constructError(
          Context.getContext(), "TypeError", 
          getMessage("msg.instanceof.not.object", null), paramObject1); 
    FlattenedObject flattenedObject = new FlattenedObject((Scriptable)paramObject2);
    return flattenedObject.hasProperty(paramObject1);
  }
  
  public static Boolean cmp_LTB(Object paramObject1, Object paramObject2) {
    if (cmp_LT(paramObject1, paramObject2) == 1)
      return Boolean.TRUE; 
    return Boolean.FALSE;
  }
  
  public static int cmp_LT(Object paramObject1, Object paramObject2) {
    if (paramObject1 instanceof Scriptable)
      paramObject1 = ((Scriptable)paramObject1).getDefaultValue(NumberClass); 
    if (paramObject2 instanceof Scriptable)
      paramObject2 = ((Scriptable)paramObject2).getDefaultValue(NumberClass); 
    if (!(paramObject1 instanceof String) || !(paramObject2 instanceof String)) {
      double d1 = toNumber(paramObject1);
      if (d1 != d1)
        return 0; 
      double d2 = toNumber(paramObject2);
      if (d2 != d2)
        return 0; 
      return (d1 < d2) ? 1 : 0;
    } 
    return (toString(paramObject1).compareTo(toString(paramObject2)) < 0) ? 1 : 0;
  }
  
  public static Boolean cmp_LEB(Object paramObject1, Object paramObject2) {
    if (cmp_LE(paramObject1, paramObject2) == 1)
      return Boolean.TRUE; 
    return Boolean.FALSE;
  }
  
  public static int cmp_LE(Object paramObject1, Object paramObject2) {
    if (paramObject1 instanceof Scriptable)
      paramObject1 = ((Scriptable)paramObject1).getDefaultValue(NumberClass); 
    if (paramObject2 instanceof Scriptable)
      paramObject2 = ((Scriptable)paramObject2).getDefaultValue(NumberClass); 
    if (!(paramObject1 instanceof String) || !(paramObject2 instanceof String)) {
      double d1 = toNumber(paramObject1);
      if (d1 != d1)
        return 0; 
      double d2 = toNumber(paramObject2);
      if (d2 != d2)
        return 0; 
      return (d1 <= d2) ? 1 : 0;
    } 
    return (toString(paramObject1).compareTo(toString(paramObject2)) <= 0) ? 1 : 0;
  }
  
  public static void main(String paramString, String[] paramArrayOfString) throws JavaScriptException {
    Scriptable scriptable2;
    Context context = Context.enter();
    Scriptable scriptable1 = context.initStandardObjects(null);
    try {
      scriptable2 = context.newObject(scriptable1, "Array");
    } catch (PropertyException propertyException) {
      throw WrappedException.wrapException(propertyException);
    } catch (NotAFunctionException notAFunctionException) {
      throw WrappedException.wrapException(notAFunctionException);
    } catch (JavaScriptException javaScriptException) {
      throw WrappedException.wrapException(javaScriptException);
    } 
    for (byte b = 0; b < paramArrayOfString.length; b++)
      scriptable2.put(b, scriptable2, paramArrayOfString[b]); 
    scriptable1.put("arguments", scriptable1, scriptable2);
    try {
      Class clazz = loadClassName(paramString);
      Script script = (Script)clazz.newInstance();
      script.exec(context, scriptable1);
      return;
    } catch (ClassNotFoundException classNotFoundException) {
    
    } catch (InstantiationException instantiationException) {
    
    } catch (IllegalAccessException illegalAccessException) {
    
    } finally {
      Context.exit();
    } 
    throw new RuntimeException("Error creating script object");
  }
  
  public static Scriptable initScript(Context paramContext, Scriptable paramScriptable1, NativeFunction paramNativeFunction, Scriptable paramScriptable2, boolean paramBoolean) {
    String[] arrayOfString = paramNativeFunction.names;
    if (arrayOfString != null) {
      Object object;
      try {
        object = (ScriptableObject)paramScriptable1;
      } catch (ClassCastException classCastException) {
        object = null;
      } 
      Scriptable scriptable = paramScriptable1;
      if (paramBoolean) {
        scriptable = paramScriptable1;
        while (scriptable instanceof NativeWith)
          scriptable = scriptable.getParentScope(); 
      } 
      for (int i = paramNativeFunction.names.length - 1; i > 0; i--) {
        String str = paramNativeFunction.names[i];
        if (!hasProp(paramScriptable1, str))
          if (object != null && !paramBoolean) {
            object.defineProperty(str, Undefined.instance, 
                4);
          } else {
            scriptable.put(str, scriptable, Undefined.instance);
          }  
      } 
    } 
    if (paramContext.getDebugLevel() > 0);
    return paramScriptable1;
  }
  
  public static Scriptable runScript(Script paramScript) {
    Context context = Context.enter();
    Scriptable scriptable = context.initStandardObjects(new ImporterTopLevel());
    try {
      paramScript.exec(context, scriptable);
    } catch (JavaScriptException javaScriptException) {
      throw new Error(javaScriptException.toString());
    } 
    Context.exit();
    return scriptable;
  }
  
  public static void setAdapterProto(Scriptable paramScriptable, Object paramObject) {
    Scriptable scriptable1 = paramScriptable.getPrototype();
    Scriptable scriptable2 = ScriptableObject.getTopLevelScope(paramScriptable);
    Scriptable scriptable3 = Context.toObject(paramObject, scriptable2);
    paramScriptable.setPrototype(scriptable3);
    scriptable3.setPrototype(scriptable1);
  }
  
  public static Scriptable initVarObj(Context paramContext, Scriptable paramScriptable1, NativeFunction paramNativeFunction, Scriptable paramScriptable2, Object[] paramArrayOfObject) {
    NativeCall nativeCall = new NativeCall(paramContext, paramScriptable1, paramNativeFunction, paramScriptable2, paramArrayOfObject);
    String[] arrayOfString = paramNativeFunction.names;
    if (arrayOfString != null)
      for (short s = paramNativeFunction.argCount + 1; s < paramNativeFunction.names.length; s++) {
        String str = paramNativeFunction.names[s];
        nativeCall.put(str, nativeCall, Undefined.instance);
      }  
    return nativeCall;
  }
  
  public static void popActivation(Context paramContext) {
    NativeCall nativeCall = paramContext.currentActivation;
    if (nativeCall != null) {
      paramContext.currentActivation = nativeCall.caller;
      nativeCall.caller = null;
    } 
  }
  
  public static Scriptable newScope() { return new NativeObject(); }
  
  public static Scriptable enterWith(Object paramObject, Scriptable paramScriptable) { return new NativeWith(paramScriptable, toObject(paramScriptable, paramObject)); }
  
  public static Scriptable leaveWith(Scriptable paramScriptable) { return paramScriptable.getParentScope(); }
  
  public static NativeFunction initFunction(NativeFunction paramNativeFunction, Scriptable paramScriptable, String paramString, Context paramContext) {
    paramNativeFunction.setPrototype(ScriptableObject.getClassPrototype(paramScriptable, "Function"));
    paramNativeFunction.setParentScope(paramScriptable);
    if (paramString != null && paramString.length() != 0)
      setName(paramScriptable, paramNativeFunction, paramScriptable, paramString); 
    return paramNativeFunction;
  }
  
  public static NativeFunction createFunctionObject(Scriptable paramScriptable, Class paramClass, Context paramContext, boolean paramBoolean) {
    Constructor[] arrayOfConstructor = paramClass.getConstructors();
    NativeFunction nativeFunction = null;
    Object[] arrayOfObject = { paramScriptable, paramContext };
    try {
      nativeFunction = (NativeFunction)arrayOfConstructor[0].newInstance(arrayOfObject);
    } catch (InstantiationException instantiationException) {
      throw WrappedException.wrapException(instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      throw WrappedException.wrapException(illegalAccessException);
    } catch (IllegalArgumentException illegalArgumentException) {
      throw WrappedException.wrapException(illegalArgumentException);
    } catch (InvocationTargetException invocationTargetException) {
      throw WrappedException.wrapException(invocationTargetException);
    } 
    nativeFunction.setPrototype(ScriptableObject.getClassPrototype(paramScriptable, "Function"));
    nativeFunction.setParentScope(paramScriptable);
    String str = nativeFunction.jsGet_name();
    if (paramBoolean && str != null && str.length() != 0 && 
      !str.equals("anonymous"))
      setProp(paramScriptable, str, nativeFunction, paramScriptable); 
    return nativeFunction;
  }
  
  static void checkDeprecated(Context paramContext, String paramString) {
    int i = paramContext.getLanguageVersion();
    if (i >= 140 || i == 0) {
      Object[] arrayOfObject = { paramString };
      String str = getMessage("msg.deprec.ctor", 
          arrayOfObject);
      if (i == 0) {
        Context.reportWarning(str);
      } else {
        throw Context.reportRuntimeError(str);
      } 
    } 
  }
  
  public static String getMessage(String paramString, Object[] paramArrayOfObject) { return Context.getMessage(paramString, paramArrayOfObject); }
  
  public static RegExpProxy getRegExpProxy(Context paramContext) { return paramContext.getRegExpProxy(); }
  
  public static NativeCall getCurrentActivation(Context paramContext) { return paramContext.currentActivation; }
  
  public static void setCurrentActivation(Context paramContext, NativeCall paramNativeCall) { paramContext.currentActivation = paramNativeCall; }
  
  static  {
    try {
      getContextClassLoaderMethod = 
        Thread.class.getDeclaredMethod("getContextClassLoader", 
          new Class[0]);
    } catch (NoSuchMethodException noSuchMethodException) {
    
    } catch (SecurityException securityException) {}
    emptyArgs = new Object[0];
  }
  
  public static Class loadClassName(String paramString) {
    try {
      if (getContextClassLoaderMethod != null) {
        ClassLoader classLoader = (ClassLoader)getContextClassLoaderMethod.invoke(Thread.currentThread(), new Object[0]);
        if (classLoader != null)
          return classLoader.loadClass(paramString); 
      } 
    } catch (SecurityException securityException) {
    
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InvocationTargetException invocationTargetException) {
    
    } catch (ClassNotFoundException classNotFoundException) {}
    return Class.forName(paramString);
  }
  
  static boolean hasProp(Scriptable paramScriptable, String paramString) {
    Scriptable scriptable = paramScriptable;
    do {
      if (scriptable.has(paramString, paramScriptable))
        return true; 
      scriptable = scriptable.getPrototype();
    } while (scriptable != null);
    return false;
  }
  
  private static RuntimeException errorWithClassName(String paramString, Object paramObject) {
    Object[] arrayOfObject = { paramObject.getClass().getName() };
    return Context.reportRuntimeError(getMessage(paramString, arrayOfObject));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\ScriptRuntime.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */