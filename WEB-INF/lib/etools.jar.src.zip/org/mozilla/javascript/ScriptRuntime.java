/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.Enumeration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ScriptRuntime
/*      */ {
/*   69 */   public static final Class UndefinedClass = Undefined.class;
/*   70 */   public static final Class ScriptableClass = Scriptable.class;
/*   71 */   public static final Class StringClass = String.class;
/*   72 */   public static final Class NumberClass = Number.class;
/*   73 */   public static final Class BooleanClass = Boolean.class;
/*   74 */   public static final Class ByteClass = Byte.class;
/*   75 */   public static final Class ShortClass = Short.class;
/*   76 */   public static final Class IntegerClass = Integer.class;
/*   77 */   public static final Class LongClass = Long.class;
/*   78 */   public static final Class FloatClass = Float.class;
/*   79 */   public static final Class DoubleClass = Double.class;
/*   80 */   public static final Class CharacterClass = Character.class;
/*   81 */   public static final Class ObjectClass = Object.class;
/*   82 */   public static final Class FunctionClass = Function.class;
/*   83 */   public static final Class ClassClass = Class.class;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean toBoolean(Object paramObject) {
/*   91 */     if (paramObject == null)
/*   92 */       return false; 
/*   93 */     if (paramObject instanceof Scriptable) {
/*   94 */       if (Context.getContext().isVersionECMA1())
/*      */       {
/*   96 */         return !(paramObject == Undefined.instance);
/*      */       }
/*      */       
/*   99 */       paramObject = ((Scriptable)paramObject).getDefaultValue(BooleanClass);
/*  100 */       if (paramObject instanceof Scriptable) {
/*  101 */         throw errorWithClassName("msg.primitive.expected", paramObject);
/*      */       }
/*      */     } 
/*  104 */     if (paramObject instanceof String)
/*  105 */       return !(((String)paramObject).length() == 0); 
/*  106 */     if (paramObject instanceof Number) {
/*  107 */       double d = ((Number)paramObject).doubleValue();
/*  108 */       return !(d != d || d == 0.0D);
/*      */     } 
/*  110 */     if (paramObject instanceof Boolean)
/*  111 */       return ((Boolean)paramObject).booleanValue(); 
/*  112 */     throw errorWithClassName("msg.invalid.type", paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double toNumber(Object paramObject) {
/*  121 */     if (paramObject != null && paramObject instanceof Scriptable) {
/*  122 */       paramObject = ((Scriptable)paramObject).getDefaultValue(NumberClass);
/*  123 */       if (paramObject != null && paramObject instanceof Scriptable) {
/*  124 */         throw errorWithClassName("msg.primitive.expected", paramObject);
/*      */       }
/*      */     } 
/*  127 */     if (paramObject == null)
/*  128 */       return 0.0D; 
/*  129 */     if (paramObject instanceof String)
/*  130 */       return toNumber((String)paramObject); 
/*  131 */     if (paramObject instanceof Number)
/*  132 */       return ((Number)paramObject).doubleValue(); 
/*  133 */     if (paramObject instanceof Boolean)
/*  134 */       return ((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D; 
/*  135 */     throw errorWithClassName("msg.invalid.type", paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  143 */   public static double NaN = NaND;
/*  144 */   public static Double NaNobj = new Double(NaND);
/*      */ 
/*      */   
/*  147 */   public static double negativeZero = -0.0D;
/*      */   private static final boolean MSJVM_BUG_WORKAROUNDS = true;
/*      */   private static final int NO_INDEX = 5;
/*      */   private static final char NO_INDEX_CHAR = '5';
/*      */   
/*      */   static double stringToNumber(String paramString, int paramInt1, int paramInt2) {
/*  153 */     char c1 = '9';
/*  154 */     char c2 = 'a';
/*  155 */     char c3 = 'A';
/*  156 */     int i = paramString.length();
/*  157 */     if (paramInt2 < 10) {
/*  158 */       c1 = (char)(48 + paramInt2 - 1);
/*      */     }
/*  160 */     if (paramInt2 > 10) {
/*  161 */       c2 = (char)(97 + paramInt2 - 10);
/*  162 */       c3 = (char)(65 + paramInt2 - 10);
/*      */     } 
/*      */     
/*  165 */     double d = 0.0D; int j;
/*  166 */     for (j = paramInt1; j < i; j++) {
/*  167 */       char c5, c4 = paramString.charAt(j);
/*      */       
/*  169 */       if (c4 >= '0' && c4 <= c1) {
/*  170 */         c5 = c4 - '0';
/*  171 */       } else if (c4 >= 'a' && c4 < c2) {
/*  172 */         c5 = c4 - 'a' + '\n';
/*  173 */       } else if (c4 >= 'A' && c4 < c3) {
/*  174 */         c5 = c4 - 'A' + '\n';
/*      */       } else {
/*      */         break;
/*  177 */       }  d = d * paramInt2 + c5;
/*      */     } 
/*  179 */     if (paramInt1 == j) {
/*  180 */       return NaN;
/*      */     }
/*  182 */     if (d >= 9.007199254740992E15D) {
/*  183 */       if (paramInt2 == 10)
/*      */         
/*      */         try {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  190 */           return Double.valueOf(paramString.substring(paramInt1, j)).doubleValue();
/*  191 */         } catch (NumberFormatException numberFormatException) {
/*  192 */           return NaN;
/*      */         }  
/*  194 */       if (paramInt2 == 2 || paramInt2 == 4 || paramInt2 == 8 || 
/*  195 */         paramInt2 == 16 || paramInt2 == 32) {
/*      */         int k;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  207 */         BinaryDigitReader binaryDigitReader = new BinaryDigitReader(paramInt2, paramString, paramInt1, j);
/*      */         
/*  209 */         d = 0.0D;
/*      */ 
/*      */         
/*      */         do {
/*  213 */           k = binaryDigitReader.getNextBinaryDigit();
/*  214 */         } while (k == 0);
/*      */         
/*  216 */         if (k == 1) {
/*      */           
/*  218 */           d = 1.0D;
/*  219 */           for (byte b = 52; b != 0; b--) {
/*  220 */             k = binaryDigitReader.getNextBinaryDigit();
/*  221 */             if (k < 0)
/*  222 */               return d; 
/*  223 */             d = d * 2.0D + k;
/*      */           } 
/*      */           
/*  226 */           int m = binaryDigitReader.getNextBinaryDigit();
/*  227 */           if (m >= 0) {
/*  228 */             double d1 = 2.0D;
/*  229 */             int n = 0;
/*      */             
/*      */             int i1;
/*  232 */             while ((i1 = binaryDigitReader.getNextBinaryDigit()) >= 0) {
/*  233 */               n |= i1;
/*  234 */               d1 *= 2.0D;
/*      */             } 
/*  236 */             d += (m & (k | n));
/*  237 */             d *= d1;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  243 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double toNumber(String paramString) {
/*      */     char c1;
/*  253 */     int i = paramString.length();
/*  254 */     byte b = 0;
/*      */     
/*      */     while (true) {
/*  257 */       if (b == i)
/*      */       {
/*  259 */         return 0.0D;
/*      */       }
/*  261 */       c1 = paramString.charAt(b);
/*  262 */       if (Character.isWhitespace(c1)) {
/*      */         
/*  264 */         b++; continue;
/*      */       }  break;
/*      */     } 
/*  267 */     if (c1 == '0' && b + 2 < i && 
/*  268 */       Character.toLowerCase(paramString.charAt(b + 1)) == 'x')
/*      */     {
/*  270 */       return stringToNumber(paramString, b + 2, 16);
/*      */     }
/*  272 */     if ((c1 == '+' || c1 == '-') && b + 3 < i && 
/*  273 */       paramString.charAt(b + 1) == '0' && 
/*  274 */       Character.toLowerCase(paramString.charAt(b + 2)) == 'x') {
/*      */       
/*  276 */       double d = stringToNumber(paramString, b + 3, 16);
/*  277 */       return (c1 == '-') ? -d : d;
/*      */     } 
/*      */     
/*  280 */     int j = i - 1;
/*      */     char c2;
/*  282 */     while (Character.isWhitespace(c2 = paramString.charAt(j)))
/*  283 */       j--; 
/*  284 */     if (c2 == 'y') {
/*      */       
/*  286 */       if (c1 == '+' || c1 == '-')
/*  287 */         b++; 
/*  288 */       String str1 = paramString.substring(b, j + 1);
/*  289 */       if (str1.equals("Infinity"))
/*  290 */         return (c1 == '-') ? 
/*  291 */           Double.NEGATIVE_INFINITY : 
/*  292 */           Double.POSITIVE_INFINITY; 
/*  293 */       return NaN;
/*      */     } 
/*      */ 
/*      */     
/*  297 */     String str = paramString.substring(b, j + 1);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  302 */     for (int k = str.length() - 1; k >= 0; ) {
/*  303 */       char c = str.charAt(k);
/*  304 */       if ((c >= '0' && c <= '9') || c == '.' || 
/*  305 */         c == 'e' || c == 'E' || 
/*  306 */         c == '+' || c == '-') {
/*      */         k--; continue;
/*  308 */       }  return NaN;
/*      */     } 
/*      */     
/*      */     try {
/*  312 */       return Double.valueOf(str).doubleValue();
/*  313 */     } catch (NumberFormatException numberFormatException) {
/*  314 */       return NaN;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] padArguments(Object[] paramArrayOfObject, int paramInt) {
/*  325 */     if (paramInt < paramArrayOfObject.length) {
/*  326 */       return paramArrayOfObject;
/*      */     }
/*      */     
/*  329 */     Object[] arrayOfObject = new Object[paramInt]; byte b;
/*  330 */     for (b = 0; b < paramArrayOfObject.length; b++) {
/*  331 */       arrayOfObject[b] = paramArrayOfObject[b];
/*      */     }
/*      */     
/*  334 */     for (; b < paramInt; b++) {
/*  335 */       arrayOfObject[b] = Undefined.instance;
/*      */     }
/*      */     
/*  338 */     return arrayOfObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String escapeString(String paramString) {
/*  350 */     String str = "\bb\ff\nn\rr\tt\013v\"\"''";
/*  351 */     StringBuffer stringBuffer = new StringBuffer(paramString.length());
/*      */     
/*  353 */     for (byte b = 0; b < paramString.length(); b++) {
/*  354 */       char c = paramString.charAt(b);
/*      */ 
/*      */       
/*  357 */       if (c >= ' ' && c <= '~' && 
/*  358 */         c != '"') {
/*      */         
/*  360 */         stringBuffer.append(c);
/*      */       } else {
/*      */         int i;
/*      */ 
/*      */ 
/*      */         
/*  366 */         if ((i = str.indexOf(c)) >= 0) {
/*  367 */           stringBuffer.append("\\");
/*  368 */           stringBuffer.append(str.charAt(i + 1));
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*  373 */         else if (c < 'Ā') {
/*  374 */           String str1 = Integer.toHexString(c);
/*  375 */           if (str1.length() == 1) {
/*  376 */             stringBuffer.append("\\x0");
/*  377 */             stringBuffer.append(str1);
/*      */           } else {
/*  379 */             stringBuffer.append("\\x");
/*  380 */             stringBuffer.append(str1);
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  386 */           String str1 = Integer.toHexString(c);
/*      */           
/*  388 */           stringBuffer.append("\\u");
/*  389 */           for (int j = str1.length(); j < 4; j++)
/*  390 */             stringBuffer.append("0"); 
/*  391 */           stringBuffer.append(str1);
/*      */         } 
/*      */       } 
/*  394 */     }  return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(Object paramObject) {
/*      */     while (true) {
/*  405 */       if (paramObject == null)
/*  406 */         return "null"; 
/*  407 */       if (paramObject instanceof Scriptable) {
/*  408 */         paramObject = ((Scriptable)paramObject).getDefaultValue(StringClass);
/*  409 */         if (paramObject != Undefined.instance && paramObject instanceof Scriptable)
/*  410 */           throw errorWithClassName("msg.primitive.expected", paramObject);  continue;
/*      */       } 
/*      */       break;
/*      */     } 
/*  414 */     if (paramObject instanceof Number)
/*      */     {
/*      */       
/*  417 */       return numberToString(((Number)paramObject).doubleValue(), 10);
/*      */     }
/*  419 */     return paramObject.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public static String numberToString(double paramDouble, int paramInt) {
/*  424 */     if (paramDouble != paramDouble)
/*  425 */       return "NaN"; 
/*  426 */     if (paramDouble == Double.POSITIVE_INFINITY)
/*  427 */       return "Infinity"; 
/*  428 */     if (paramDouble == Double.NEGATIVE_INFINITY)
/*  429 */       return "-Infinity"; 
/*  430 */     if (paramDouble == 0.0D) {
/*  431 */       return "0";
/*      */     }
/*  433 */     if (paramInt < 2 || paramInt > 36) {
/*  434 */       Object[] arrayOfObject = { Integer.toString(paramInt) };
/*  435 */       throw Context.reportRuntimeError(
/*  436 */           getMessage("msg.bad.radix", arrayOfObject));
/*      */     } 
/*      */     
/*  439 */     if (paramInt != 10) {
/*  440 */       return DToA.JS_dtobasestr(paramInt, paramDouble);
/*      */     }
/*      */     
/*  443 */     StringBuffer stringBuffer = new StringBuffer();
/*  444 */     DToA.JS_dtostr(stringBuffer, 0, 0, paramDouble);
/*  445 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  456 */   public static Scriptable toObject(Scriptable paramScriptable, Object paramObject) { return toObject(paramScriptable, paramObject, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable toObject(Scriptable paramScriptable, Object paramObject, Class paramClass) {
/*  462 */     if (paramObject == null) {
/*  463 */       throw NativeGlobal.constructError(
/*  464 */           Context.getContext(), "TypeError", 
/*  465 */           getMessage("msg.null.to.object", null), 
/*  466 */           paramScriptable);
/*      */     }
/*  468 */     if (paramObject instanceof Scriptable) {
/*  469 */       if (paramObject == Undefined.instance) {
/*  470 */         throw NativeGlobal.constructError(
/*  471 */             Context.getContext(), "TypeError", 
/*  472 */             getMessage("msg.undef.to.object", null), 
/*  473 */             paramScriptable);
/*      */       }
/*  475 */       return (Scriptable)paramObject;
/*      */     } 
/*  477 */     String str = (paramObject instanceof String) ? "String" : (
/*  478 */       (paramObject instanceof Number) ? "Number" : (
/*  479 */       (paramObject instanceof Boolean) ? "Boolean" : 
/*  480 */       null));
/*      */     
/*  482 */     if (str == null) {
/*      */       
/*  484 */       Object object = NativeJavaObject.wrap(paramScriptable, paramObject, paramClass);
/*  485 */       if (object instanceof Scriptable)
/*  486 */         return (Scriptable)object; 
/*  487 */       throw errorWithClassName("msg.invalid.type", paramObject);
/*      */     } 
/*      */     
/*  490 */     Object[] arrayOfObject = { paramObject };
/*  491 */     paramScriptable = ScriptableObject.getTopLevelScope(paramScriptable);
/*  492 */     return newObject(Context.getContext(), paramScriptable, 
/*  493 */         str, arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable newObject(Context paramContext, Scriptable paramScriptable, String paramString, Object[] paramArrayOfObject) {
/*  500 */     JavaScriptException javaScriptException = null;
/*      */     try {
/*  502 */       return paramContext.newObject(paramScriptable, paramString, paramArrayOfObject);
/*      */     }
/*  504 */     catch (NotAFunctionException notAFunctionException) {
/*  505 */       javaScriptException = notAFunctionException;
/*      */     }
/*  507 */     catch (PropertyException propertyException2) {
/*  508 */       PropertyException propertyException1 = propertyException2;
/*      */     }
/*  510 */     catch (JavaScriptException javaScriptException1) {
/*  511 */       javaScriptException = javaScriptException1;
/*      */     } 
/*  513 */     throw Context.reportRuntimeError(javaScriptException.getMessage());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double toInteger(Object paramObject) {
/*  521 */     double d = toNumber(paramObject);
/*      */ 
/*      */     
/*  524 */     if (d != d) {
/*  525 */       return 0.0D;
/*      */     }
/*  527 */     if (d == 0.0D || 
/*  528 */       d == Double.POSITIVE_INFINITY || 
/*  529 */       d == Double.NEGATIVE_INFINITY) {
/*  530 */       return d;
/*      */     }
/*  532 */     if (d > 0.0D) {
/*  533 */       return Math.floor(d);
/*      */     }
/*  535 */     return Math.ceil(d);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double toInteger(double paramDouble) {
/*  541 */     if (paramDouble != paramDouble) {
/*  542 */       return 0.0D;
/*      */     }
/*  544 */     if (paramDouble == 0.0D || 
/*  545 */       paramDouble == Double.POSITIVE_INFINITY || 
/*  546 */       paramDouble == Double.NEGATIVE_INFINITY) {
/*  547 */       return paramDouble;
/*      */     }
/*  549 */     if (paramDouble > 0.0D) {
/*  550 */       return Math.floor(paramDouble);
/*      */     }
/*  552 */     return Math.ceil(paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int toInt32(Object paramObject) {
/*  561 */     double d1 = 4.294967296E9D;
/*  562 */     double d2 = 2.147483648E9D;
/*      */ 
/*      */ 
/*      */     
/*  566 */     if (paramObject instanceof Byte) {
/*  567 */       return ((Number)paramObject).intValue();
/*      */     }
/*  569 */     double d3 = toNumber(paramObject);
/*  570 */     if (d3 != d3 || d3 == 0.0D || 
/*  571 */       d3 == Double.POSITIVE_INFINITY || 
/*  572 */       d3 == Double.NEGATIVE_INFINITY) {
/*  573 */       return 0;
/*      */     }
/*  575 */     d3 = Math.IEEEremainder(d3, d1);
/*      */     
/*  577 */     d3 = (d3 >= 0.0D) ? 
/*  578 */       d3 : (
/*  579 */       d3 + d1);
/*      */     
/*  581 */     if (d3 >= d2) {
/*  582 */       return (int)(d3 - d1);
/*      */     }
/*  584 */     return (int)d3;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int toInt32(double paramDouble) {
/*  589 */     double d1 = 4.294967296E9D;
/*  590 */     double d2 = 2.147483648E9D;
/*      */     
/*  592 */     if (paramDouble != paramDouble || paramDouble == 0.0D || 
/*  593 */       paramDouble == Double.POSITIVE_INFINITY || 
/*  594 */       paramDouble == Double.NEGATIVE_INFINITY) {
/*  595 */       return 0;
/*      */     }
/*  597 */     paramDouble = Math.IEEEremainder(paramDouble, d1);
/*      */     
/*  599 */     paramDouble = (paramDouble >= 0.0D) ? 
/*  600 */       paramDouble : (
/*  601 */       paramDouble + d1);
/*      */     
/*  603 */     if (paramDouble >= d2) {
/*  604 */       return (int)(paramDouble - d1);
/*      */     }
/*  606 */     return (int)paramDouble;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long toUint32(double paramDouble) {
/*  617 */     double d = 4.294967296E9D;
/*      */     
/*  619 */     if (paramDouble != paramDouble || paramDouble == 0.0D || 
/*  620 */       paramDouble == Double.POSITIVE_INFINITY || 
/*  621 */       paramDouble == Double.NEGATIVE_INFINITY) {
/*  622 */       return 0L;
/*      */     }
/*  624 */     if (paramDouble > 0.0D) {
/*  625 */       paramDouble = Math.floor(paramDouble);
/*      */     } else {
/*  627 */       paramDouble = Math.ceil(paramDouble);
/*      */     } 
/*  629 */     paramDouble = Math.IEEEremainder(paramDouble, d);
/*      */     
/*  631 */     paramDouble = (paramDouble >= 0.0D) ? 
/*  632 */       paramDouble : (
/*  633 */       paramDouble + d);
/*      */     
/*  635 */     return (long)Math.floor(paramDouble);
/*      */   }
/*      */ 
/*      */   
/*  639 */   public static long toUint32(Object paramObject) { return toUint32(toNumber(paramObject)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char toUint16(Object paramObject) {
/*  647 */     long l = 65536L;
/*      */     
/*  649 */     double d = toNumber(paramObject);
/*  650 */     if (d != d || d == 0.0D || 
/*  651 */       d == Double.POSITIVE_INFINITY || 
/*  652 */       d == Double.NEGATIVE_INFINITY)
/*      */     {
/*  654 */       return Character.MIN_VALUE;
/*      */     }
/*      */     
/*  657 */     d = Math.IEEEremainder(d, l);
/*      */     
/*  659 */     d = (d >= 0.0D) ? 
/*  660 */       d : (
/*  661 */       d + l);
/*      */     
/*  663 */     return (char)(int)Math.floor(d);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  671 */   public static Object unwrapJavaScriptException(JavaScriptException paramJavaScriptException) { return paramJavaScriptException.value; }
/*      */ 
/*      */   
/*      */   public static Object getProp(Object paramObject, String paramString, Scriptable paramScriptable) {
/*      */     Scriptable scriptable1;
/*  676 */     if (paramObject instanceof Scriptable) {
/*  677 */       scriptable1 = (Scriptable)paramObject;
/*      */     } else {
/*  679 */       scriptable1 = toObject(paramScriptable, paramObject);
/*      */     } 
/*  681 */     if (scriptable1 == null || scriptable1 == Undefined.instance) {
/*  682 */       String str = (scriptable1 == null) ? "msg.null.to.object" : 
/*  683 */         "msg.undefined";
/*  684 */       throw NativeGlobal.constructError(
/*  685 */           Context.getContext(), "ConversionError", 
/*  686 */           getMessage(str, null), 
/*  687 */           paramScriptable);
/*      */     } 
/*  689 */     Scriptable scriptable2 = scriptable1;
/*      */     do {
/*  691 */       Object object = scriptable2.get(paramString, scriptable1);
/*  692 */       if (object != Scriptable.NOT_FOUND)
/*  693 */         return object; 
/*  694 */       scriptable2 = scriptable2.getPrototype();
/*  695 */     } while (scriptable2 != null);
/*  696 */     return Undefined.instance;
/*      */   }
/*      */   public static Object getTopLevelProp(Scriptable paramScriptable, String paramString) {
/*      */     Object object;
/*  700 */     Scriptable scriptable = ScriptableObject.getTopLevelScope(paramScriptable);
/*      */     
/*      */     do {
/*  703 */       object = scriptable.get(paramString, scriptable);
/*  704 */       if (object != Scriptable.NOT_FOUND)
/*  705 */         return object; 
/*  706 */       scriptable = scriptable.getPrototype();
/*  707 */     } while (scriptable != null);
/*  708 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable getProto(Object paramObject, Scriptable paramScriptable) {
/*      */     Scriptable scriptable;
/*  717 */     if (paramObject instanceof Scriptable) {
/*  718 */       scriptable = (Scriptable)paramObject;
/*      */     } else {
/*  720 */       scriptable = toObject(paramScriptable, paramObject);
/*      */     } 
/*  722 */     if (scriptable == null) {
/*  723 */       throw NativeGlobal.constructError(
/*  724 */           Context.getContext(), "TypeError", 
/*  725 */           getMessage("msg.null.to.object", null), 
/*  726 */           paramScriptable);
/*      */     }
/*  728 */     return scriptable.getPrototype();
/*      */   }
/*      */   
/*      */   public static Scriptable getParent(Object paramObject) {
/*      */     Scriptable scriptable;
/*      */     try {
/*  734 */       scriptable = (Scriptable)paramObject;
/*      */     }
/*  736 */     catch (ClassCastException classCastException) {
/*  737 */       return null;
/*      */     } 
/*  739 */     if (scriptable == null) {
/*  740 */       return null;
/*      */     }
/*  742 */     return getThis(scriptable.getParentScope());
/*      */   }
/*      */   
/*      */   public static Scriptable getParent(Object paramObject, Scriptable paramScriptable) {
/*      */     Scriptable scriptable;
/*  747 */     if (paramObject instanceof Scriptable) {
/*  748 */       scriptable = (Scriptable)paramObject;
/*      */     } else {
/*  750 */       scriptable = toObject(paramScriptable, paramObject);
/*      */     } 
/*  752 */     if (scriptable == null) {
/*  753 */       throw NativeGlobal.constructError(
/*  754 */           Context.getContext(), "TypeError", 
/*  755 */           getMessage("msg.null.to.object", null), 
/*  756 */           paramScriptable);
/*      */     }
/*  758 */     return scriptable.getParentScope();
/*      */   }
/*      */   
/*      */   public static Object setProto(Object paramObject1, Object paramObject2, Scriptable paramScriptable) {
/*      */     Scriptable scriptable1;
/*  763 */     if (paramObject1 instanceof Scriptable) {
/*  764 */       scriptable1 = (Scriptable)paramObject1;
/*      */     } else {
/*  766 */       scriptable1 = toObject(paramScriptable, paramObject1);
/*      */     } 
/*  768 */     Scriptable scriptable2 = (paramObject2 == null) ? null : toObject(paramScriptable, paramObject2);
/*  769 */     Scriptable scriptable3 = scriptable2;
/*  770 */     while (scriptable3 != null) {
/*  771 */       if (scriptable3 == scriptable1) {
/*  772 */         Object[] arrayOfObject = { "__proto__" };
/*  773 */         throw Context.reportRuntimeError(
/*  774 */             getMessage("msg.cyclic.value", arrayOfObject));
/*      */       } 
/*  776 */       scriptable3 = scriptable3.getPrototype();
/*      */     } 
/*  778 */     if (scriptable1 == null) {
/*  779 */       throw NativeGlobal.constructError(
/*  780 */           Context.getContext(), "TypeError", 
/*  781 */           getMessage("msg.null.to.object", null), 
/*  782 */           paramScriptable);
/*      */     }
/*  784 */     scriptable1.setPrototype(scriptable2);
/*  785 */     return scriptable2;
/*      */   }
/*      */   
/*      */   public static Object setParent(Object paramObject1, Object paramObject2, Scriptable paramScriptable) {
/*      */     Scriptable scriptable1;
/*  790 */     if (paramObject1 instanceof Scriptable) {
/*  791 */       scriptable1 = (Scriptable)paramObject1;
/*      */     } else {
/*  793 */       scriptable1 = toObject(paramScriptable, paramObject1);
/*      */     } 
/*  795 */     Scriptable scriptable2 = (paramObject2 == null) ? null : toObject(paramScriptable, paramObject2);
/*  796 */     Scriptable scriptable3 = scriptable2;
/*  797 */     while (scriptable3 != null) {
/*  798 */       if (scriptable3 == scriptable1) {
/*  799 */         Object[] arrayOfObject = { "__parent__" };
/*  800 */         throw Context.reportRuntimeError(
/*  801 */             getMessage("msg.cyclic.value", arrayOfObject));
/*      */       } 
/*  803 */       scriptable3 = scriptable3.getParentScope();
/*      */     } 
/*  805 */     if (scriptable1 == null) {
/*  806 */       throw NativeGlobal.constructError(
/*  807 */           Context.getContext(), "TypeError", 
/*  808 */           getMessage("msg.null.to.object", null), 
/*  809 */           paramScriptable);
/*      */     }
/*  811 */     scriptable1.setParentScope(scriptable2);
/*  812 */     return scriptable2;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object setProp(Object paramObject1, String paramString, Object paramObject2, Scriptable paramScriptable) {
/*      */     Scriptable scriptable1;
/*  819 */     if (paramObject1 instanceof Scriptable) {
/*  820 */       scriptable1 = (Scriptable)paramObject1;
/*      */     } else {
/*  822 */       scriptable1 = toObject(paramScriptable, paramObject1);
/*      */     } 
/*  824 */     if (scriptable1 == null) {
/*  825 */       throw NativeGlobal.constructError(
/*  826 */           Context.getContext(), "TypeError", 
/*  827 */           getMessage("msg.null.to.object", null), 
/*  828 */           paramScriptable);
/*      */     }
/*  830 */     Scriptable scriptable2 = scriptable1;
/*      */     do {
/*  832 */       if (scriptable2.has(paramString, scriptable1)) {
/*  833 */         scriptable2.put(paramString, scriptable1, paramObject2);
/*  834 */         return paramObject2;
/*      */       } 
/*  836 */       scriptable2 = scriptable2.getPrototype();
/*  837 */     } while (scriptable2 != null);
/*      */     
/*  839 */     scriptable1.put(paramString, scriptable1, paramObject2);
/*  840 */     return paramObject2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  851 */   private static final int MAX_VALUE_LENGTH = Integer.toString(2147483647).length(); private static Method getContextClassLoaderMethod;
/*      */   public static Object[] emptyArgs;
/*      */   
/*      */   private static int indexFromString(String paramString) {
/*  855 */     int i = paramString.length();
/*      */     char c;
/*  857 */     if (i > 0 && (c = paramString.charAt(0)) >= '0' && c <= '9' && 
/*  858 */       i <= MAX_VALUE_LENGTH) {
/*      */       
/*  860 */       char c1 = c - '0';
/*  861 */       char c2 = Character.MIN_VALUE;
/*  862 */       byte b = 1;
/*  863 */       if (c1 != '\000') {
/*  864 */         while (b < i && (c = paramString.charAt(b)) >= '0' && c <= '9') {
/*  865 */           c2 = c1;
/*  866 */           c1 = '\n' * c1 + c - '0';
/*  867 */           b++;
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  873 */       if (b == i && (
/*  874 */         c2 < 214748364 || (
/*  875 */         c2 == 214748364 && 
/*  876 */         c < '\007')))
/*      */       {
/*  878 */         return c1;
/*      */       }
/*      */     } 
/*  881 */     return 5;
/*      */   }
/*      */   
/*      */   static String getStringId(Object paramObject) {
/*  885 */     if (paramObject instanceof Number) {
/*  886 */       double d = ((Number)paramObject).doubleValue();
/*  887 */       int j = (int)d;
/*  888 */       if (j == d)
/*  889 */         return null; 
/*  890 */       return toString(paramObject);
/*      */     } 
/*  892 */     String str = toString(paramObject);
/*  893 */     int i = indexFromString(str);
/*  894 */     if (i != 5 || (str.length() == 1 && 
/*  895 */       str.charAt(0) == '5'))
/*      */     {
/*  897 */       return null;
/*      */     }
/*  899 */     return str;
/*      */   }
/*      */   
/*      */   static int getIntId(Object paramObject) {
/*  903 */     if (paramObject instanceof Number) {
/*  904 */       double d = ((Number)paramObject).doubleValue();
/*  905 */       int j = (int)d;
/*  906 */       if (j == d)
/*  907 */         return j; 
/*  908 */       return 0;
/*      */     } 
/*  910 */     String str = toString(paramObject);
/*  911 */     int i = indexFromString(str);
/*  912 */     if (i != 5 || (str.length() == 1 && 
/*  913 */       str.charAt(0) == '5'))
/*      */     {
/*  915 */       return i;
/*      */     }
/*  917 */     return 0;
/*      */   }
/*      */   
/*      */   public static Object getElem(Object paramObject1, Object paramObject2, Scriptable paramScriptable) {
/*      */     String str;
/*      */     int i;
/*  923 */     if (paramObject2 instanceof Number) {
/*  924 */       double d = ((Number)paramObject2).doubleValue();
/*  925 */       i = (int)d;
/*  926 */       str = (i == d) ? null : toString(paramObject2);
/*      */     } else {
/*  928 */       str = toString(paramObject2);
/*  929 */       i = indexFromString(str);
/*  930 */       if (i != 5) {
/*  931 */         str = null;
/*  932 */       } else if (str.length() == 1 && str.charAt(0) == '5') {
/*      */         
/*  934 */         str = null;
/*      */       } 
/*      */     } 
/*  937 */     Scriptable scriptable1 = (paramObject1 instanceof Scriptable) ? 
/*  938 */       (Scriptable)paramObject1 : 
/*  939 */       toObject(paramScriptable, paramObject1);
/*  940 */     Scriptable scriptable2 = scriptable1;
/*  941 */     if (str != null) {
/*  942 */       if (str.equals("__proto__"))
/*  943 */         return scriptable1.getPrototype(); 
/*  944 */       if (str.equals("__parent__"))
/*  945 */         return scriptable1.getParentScope(); 
/*  946 */       while (scriptable2 != null) {
/*  947 */         Object object = scriptable2.get(str, scriptable1);
/*  948 */         if (object != Scriptable.NOT_FOUND)
/*  949 */           return object; 
/*  950 */         scriptable2 = scriptable2.getPrototype();
/*      */       } 
/*  952 */       return Undefined.instance;
/*      */     } 
/*  954 */     while (scriptable2 != null) {
/*  955 */       Object object = scriptable2.get(i, scriptable1);
/*  956 */       if (object != Scriptable.NOT_FOUND)
/*  957 */         return object; 
/*  958 */       scriptable2 = scriptable2.getPrototype();
/*      */     } 
/*  960 */     return Undefined.instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getElem(Scriptable paramScriptable, int paramInt) {
/*  970 */     Scriptable scriptable = paramScriptable;
/*  971 */     while (scriptable != null) {
/*  972 */       Object object = scriptable.get(paramInt, paramScriptable);
/*  973 */       if (object != Scriptable.NOT_FOUND)
/*  974 */         return object; 
/*  975 */       scriptable = scriptable.getPrototype();
/*      */     } 
/*  977 */     return Undefined.instance;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object setElem(Object paramObject1, Object paramObject2, Object paramObject3, Scriptable paramScriptable) {
/*      */     String str;
/*      */     int i;
/*  985 */     if (paramObject2 instanceof Number) {
/*  986 */       double d = ((Number)paramObject2).doubleValue();
/*  987 */       i = (int)d;
/*  988 */       str = (i == d) ? null : toString(paramObject2);
/*      */     } else {
/*  990 */       str = toString(paramObject2);
/*  991 */       i = indexFromString(str);
/*  992 */       if (i != 5) {
/*  993 */         str = null;
/*  994 */       } else if (str.length() == 1 && str.charAt(0) == '5') {
/*      */         
/*  996 */         str = null;
/*      */       } 
/*      */     } 
/*      */     
/* 1000 */     Scriptable scriptable1 = (paramObject1 instanceof Scriptable) ? 
/* 1001 */       (Scriptable)paramObject1 : 
/* 1002 */       toObject(paramScriptable, paramObject1);
/* 1003 */     Scriptable scriptable2 = scriptable1;
/* 1004 */     if (str != null) {
/* 1005 */       if (str.equals("__proto__"))
/* 1006 */         return setProto(paramObject1, paramObject3, paramScriptable); 
/* 1007 */       if (str.equals("__parent__")) {
/* 1008 */         return setParent(paramObject1, paramObject3, paramScriptable);
/*      */       }
/*      */       do {
/* 1011 */         if (scriptable2.has(str, scriptable1)) {
/* 1012 */           scriptable2.put(str, scriptable1, paramObject3);
/* 1013 */           return paramObject3;
/*      */         } 
/* 1015 */         scriptable2 = scriptable2.getPrototype();
/* 1016 */       } while (scriptable2 != null);
/* 1017 */       scriptable1.put(str, scriptable1, paramObject3);
/* 1018 */       return paramObject3;
/*      */     } 
/*      */     
/*      */     do {
/* 1022 */       if (scriptable2.has(i, scriptable1)) {
/* 1023 */         scriptable2.put(i, scriptable1, paramObject3);
/* 1024 */         return paramObject3;
/*      */       } 
/* 1026 */       scriptable2 = scriptable2.getPrototype();
/* 1027 */     } while (scriptable2 != null);
/* 1028 */     scriptable1.put(i, scriptable1, paramObject3);
/* 1029 */     return paramObject3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object setElem(Scriptable paramScriptable, int paramInt, Object paramObject) {
/* 1038 */     Scriptable scriptable = paramScriptable;
/*      */     do {
/* 1040 */       if (scriptable.has(paramInt, paramScriptable)) {
/* 1041 */         scriptable.put(paramInt, paramScriptable, paramObject);
/* 1042 */         return paramObject;
/*      */       } 
/* 1044 */       scriptable = scriptable.getPrototype();
/* 1045 */     } while (scriptable != null);
/* 1046 */     paramScriptable.put(paramInt, paramScriptable, paramObject);
/* 1047 */     return paramObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object delete(Object paramObject1, Object paramObject2) {
/* 1062 */     if (!(paramObject1 instanceof Scriptable))
/* 1063 */       return Boolean.TRUE; 
/* 1064 */     FlattenedObject flattenedObject = new FlattenedObject((Scriptable)paramObject1);
/* 1065 */     return flattenedObject.deleteProperty(paramObject2) ? Boolean.TRUE : Boolean.FALSE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object name(Scriptable paramScriptable, String paramString) {
/* 1072 */     Scriptable scriptable = paramScriptable;
/*      */     
/* 1074 */     while (scriptable != null) {
/* 1075 */       Scriptable scriptable1 = scriptable;
/*      */       do {
/* 1077 */         Object object = scriptable1.get(paramString, scriptable);
/* 1078 */         if (object != Scriptable.NOT_FOUND)
/* 1079 */           return object; 
/* 1080 */         scriptable1 = scriptable1.getPrototype();
/* 1081 */       } while (scriptable1 != null);
/* 1082 */       scriptable = scriptable.getParentScope();
/*      */     } 
/* 1084 */     Object[] arrayOfObject = { paramString.toString() };
/* 1085 */     throw NativeGlobal.constructError(
/* 1086 */         Context.getContext(), "ReferenceError", 
/* 1087 */         getMessage("msg.is.not.defined", arrayOfObject), 
/* 1088 */         paramScriptable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable bind(Scriptable paramScriptable, String paramString) {
/* 1105 */     Scriptable scriptable = paramScriptable;
/*      */     
/* 1107 */     while (scriptable != null) {
/* 1108 */       Scriptable scriptable1 = scriptable;
/*      */       do {
/* 1110 */         if (scriptable1.has(paramString, scriptable))
/* 1111 */           return scriptable; 
/* 1112 */         scriptable1 = scriptable1.getPrototype();
/* 1113 */       } while (scriptable1 != null);
/* 1114 */       scriptable = scriptable.getParentScope();
/*      */     } 
/* 1116 */     return null;
/*      */   }
/*      */   
/*      */   public static Scriptable getBase(Scriptable paramScriptable, String paramString) {
/* 1120 */     Scriptable scriptable = paramScriptable;
/*      */     
/* 1122 */     while (scriptable != null) {
/* 1123 */       Scriptable scriptable1 = scriptable;
/*      */       do {
/* 1125 */         if (scriptable1.get(paramString, scriptable) != Scriptable.NOT_FOUND)
/* 1126 */           return scriptable; 
/* 1127 */         scriptable1 = scriptable1.getPrototype();
/* 1128 */       } while (scriptable1 != null);
/* 1129 */       scriptable = scriptable.getParentScope();
/*      */     } 
/* 1131 */     Object[] arrayOfObject = { paramString };
/* 1132 */     throw NativeGlobal.constructError(
/* 1133 */         Context.getContext(), "ReferenceError", 
/* 1134 */         getMessage("msg.is.not.defined", arrayOfObject), 
/* 1135 */         paramScriptable);
/*      */   }
/*      */   
/*      */   public static Scriptable getThis(Scriptable paramScriptable) {
/* 1139 */     while (paramScriptable instanceof NativeWith)
/* 1140 */       paramScriptable = paramScriptable.getPrototype(); 
/* 1141 */     if (paramScriptable instanceof NativeCall)
/* 1142 */       paramScriptable = ScriptableObject.getTopLevelScope(paramScriptable); 
/* 1143 */     return paramScriptable;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object setName(Scriptable paramScriptable1, Object paramObject, Scriptable paramScriptable2, String paramString) {
/* 1149 */     if (paramScriptable1 == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1154 */       Scriptable scriptable = paramScriptable2;
/*      */       do {
/* 1156 */         paramScriptable1 = scriptable;
/* 1157 */         scriptable = paramScriptable1.getParentScope();
/* 1158 */       } while (scriptable != null);
/*      */       
/* 1160 */       paramScriptable1.put(paramString, paramScriptable1, paramObject);
/* 1161 */       String[] arrayOfString = { paramString };
/* 1162 */       String str = getMessage("msg.assn.create", arrayOfString);
/* 1163 */       Context.reportWarning(str);
/* 1164 */       return paramObject;
/*      */     } 
/* 1166 */     return setProp(paramScriptable1, paramString, paramObject, paramScriptable2);
/*      */   }
/*      */   
/*      */   public static Enumeration initEnum(Object paramObject, Scriptable paramScriptable) {
/* 1170 */     Scriptable scriptable = toObject(paramScriptable, paramObject);
/* 1171 */     return new IdEnumeration(scriptable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object nextEnum(Enumeration paramEnumeration) {
/* 1177 */     if (!paramEnumeration.hasMoreElements())
/* 1178 */       return null; 
/* 1179 */     return paramEnumeration.nextElement();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object call(Context paramContext, Object paramObject1, Object paramObject2, Object[] paramArrayOfObject) throws JavaScriptException {
/* 1187 */     Scriptable scriptable = null;
/* 1188 */     if (paramObject1 instanceof Scriptable)
/* 1189 */       scriptable = ((Scriptable)paramObject1).getParentScope(); 
/* 1190 */     return call(paramContext, paramObject1, paramObject2, paramArrayOfObject, scriptable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object call(Context paramContext, Object paramObject1, Object paramObject2, Object[] paramArrayOfObject, Scriptable paramScriptable) throws JavaScriptException {
/*      */     Scriptable scriptable;
/*      */     Function function;
/*      */     try {
/* 1199 */       function = (Function)paramObject1;
/*      */     }
/* 1201 */     catch (ClassCastException classCastException) {
/* 1202 */       scriptable = new Object[] { toString(paramObject1) };
/* 1203 */       throw NativeGlobal.constructError(
/* 1204 */           Context.getContext(), "TypeError", 
/* 1205 */           getMessage("msg.isnt.function", 
/* 1206 */             scriptable), 
/* 1207 */           paramScriptable);
/*      */     } 
/*      */ 
/*      */     
/* 1211 */     if (paramObject2 instanceof Scriptable || paramObject2 == null) {
/* 1212 */       scriptable = (Scriptable)paramObject2;
/*      */     } else {
/* 1214 */       scriptable = toObject(paramScriptable, paramObject2);
/*      */     } 
/* 1216 */     return function.call(paramContext, paramScriptable, scriptable, paramArrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object callOrNewSpecial(Context paramContext, Scriptable paramScriptable, Object paramObject1, Object paramObject2, Object paramObject3, Object[] paramArrayOfObject, boolean paramBoolean, String paramString, int paramInt) throws JavaScriptException {
/* 1225 */     if (paramObject1 instanceof FunctionObject) {
/* 1226 */       FunctionObject functionObject = (FunctionObject)paramObject1;
/* 1227 */       Method method = functionObject.method;
/* 1228 */       Class clazz = method.getDeclaringClass();
/* 1229 */       String str = method.getName();
/* 1230 */       if (str.equals("eval") && clazz == NativeGlobal.class)
/* 1231 */         return NativeGlobal.evalSpecial(paramContext, paramScriptable, paramObject3, paramArrayOfObject, 
/* 1232 */             paramString, paramInt); 
/* 1233 */       if (str.equals("With") && clazz == NativeWith.class)
/* 1234 */         return NativeWith.newWithSpecial(paramContext, paramArrayOfObject, functionObject, paramBoolean ^ true); 
/* 1235 */       if (str.equals("jsFunction_exec") && clazz == NativeScript.class)
/* 1236 */         return ((NativeScript)paramObject2).exec(paramContext, ScriptableObject.getTopLevelScope(paramScriptable)); 
/* 1237 */       if (str.equals("exec") && 
/* 1238 */         paramContext.getRegExpProxy() != null && 
/* 1239 */         paramContext.getRegExpProxy().isRegExp(paramObject2)) {
/* 1240 */         return call(paramContext, paramObject1, paramObject2, paramArrayOfObject, paramScriptable);
/*      */       }
/*      */     }
/* 1243 */     else if (paramObject1 instanceof NativeJavaMethod) {
/* 1244 */       return call(paramContext, paramObject1, paramObject2, paramArrayOfObject, paramScriptable);
/*      */     } 
/* 1246 */     if (paramBoolean)
/* 1247 */       return call(paramContext, paramObject1, paramObject3, paramArrayOfObject, paramScriptable); 
/* 1248 */     return newObject(paramContext, paramObject1, paramArrayOfObject, paramScriptable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object callSpecial(Context paramContext, Object paramObject1, Object paramObject2, Object[] paramArrayOfObject, Scriptable paramScriptable1, Scriptable paramScriptable2, String paramString, int paramInt) throws JavaScriptException {
/* 1258 */     return callOrNewSpecial(paramContext, paramScriptable2, paramObject1, paramObject2, 
/* 1259 */         paramScriptable1, paramArrayOfObject, true, 
/* 1260 */         paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable newObject(Context paramContext, Object paramObject, Object[] paramArrayOfObject, Scriptable paramScriptable) throws JavaScriptException {
/*      */     try {
/* 1274 */       Function function = (Function)paramObject;
/* 1275 */       if (function != null) {
/* 1276 */         return function.construct(paramContext, paramScriptable, paramArrayOfObject);
/*      */       }
/*      */     }
/* 1279 */     catch (ClassCastException classCastException) {}
/*      */ 
/*      */     
/* 1282 */     Object[] arrayOfObject = { toString(paramObject) };
/* 1283 */     throw NativeGlobal.constructError(
/* 1284 */         Context.getContext(), "TypeError", 
/* 1285 */         getMessage("msg.isnt.function", arrayOfObject), 
/* 1286 */         paramScriptable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable newObjectSpecial(Context paramContext, Object paramObject, Object[] paramArrayOfObject, Scriptable paramScriptable) throws JavaScriptException {
/* 1293 */     return (Scriptable)callOrNewSpecial(paramContext, paramScriptable, paramObject, null, null, paramArrayOfObject, 
/* 1294 */         false, null, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String typeof(Object paramObject) {
/* 1301 */     if (paramObject == Undefined.instance)
/* 1302 */       return "undefined"; 
/* 1303 */     if (paramObject == null)
/* 1304 */       return "object"; 
/* 1305 */     if (paramObject instanceof Scriptable)
/* 1306 */       return (paramObject instanceof Function) ? "function" : "object"; 
/* 1307 */     if (paramObject instanceof String)
/* 1308 */       return "string"; 
/* 1309 */     if (paramObject instanceof Number)
/* 1310 */       return "number"; 
/* 1311 */     if (paramObject instanceof Boolean)
/* 1312 */       return "boolean"; 
/* 1313 */     throw errorWithClassName("msg.invalid.type", paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String typeofName(Scriptable paramScriptable, String paramString) {
/* 1320 */     Scriptable scriptable = bind(paramScriptable, paramString);
/* 1321 */     if (scriptable == null)
/* 1322 */       return "undefined"; 
/* 1323 */     return typeof(getProp(scriptable, paramString, paramScriptable));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object add(Object paramObject1, Object paramObject2) {
/* 1339 */     if (paramObject1 instanceof Scriptable)
/* 1340 */       paramObject1 = ((Scriptable)paramObject1).getDefaultValue(null); 
/* 1341 */     if (paramObject2 instanceof Scriptable)
/* 1342 */       paramObject2 = ((Scriptable)paramObject2).getDefaultValue(null); 
/* 1343 */     if (!(paramObject1 instanceof String) && !(paramObject2 instanceof String)) {
/* 1344 */       if (paramObject1 instanceof Number && paramObject2 instanceof Number) {
/* 1345 */         return new Double(((Number)paramObject1).doubleValue() + (
/* 1346 */             (Number)paramObject2).doubleValue());
/*      */       }
/* 1348 */       return new Double(toNumber(paramObject1) + toNumber(paramObject2));
/* 1349 */     }  return String.valueOf(toString(paramObject1)) + toString(paramObject2);
/*      */   }
/*      */   
/*      */   public static Object postIncrement(Object paramObject) {
/* 1353 */     if (paramObject instanceof Number) {
/* 1354 */       paramObject = new Double(((Number)paramObject).doubleValue() + 1.0D);
/*      */     } else {
/* 1356 */       paramObject = new Double(toNumber(paramObject) + 1.0D);
/* 1357 */     }  return paramObject;
/*      */   }
/*      */   
/*      */   public static Object postIncrement(Scriptable paramScriptable, String paramString) {
/* 1361 */     Scriptable scriptable = paramScriptable;
/*      */     
/* 1363 */     while (scriptable != null) {
/* 1364 */       Scriptable scriptable1 = scriptable;
/*      */       do {
/* 1366 */         Object object = scriptable1.get(paramString, scriptable);
/* 1367 */         if (object != Scriptable.NOT_FOUND) {
/* 1368 */           Object object1 = object;
/* 1369 */           if (object1 instanceof Number) {
/* 1370 */             object1 = new Double((
/* 1371 */                 (Number)object1).doubleValue() + 1.0D);
/* 1372 */             scriptable1.put(paramString, scriptable, object1);
/* 1373 */             return object;
/*      */           } 
/*      */           
/* 1376 */           object1 = new Double(toNumber(object1) + 1.0D);
/* 1377 */           scriptable1.put(paramString, scriptable, object1);
/* 1378 */           return new Double(toNumber(object));
/*      */         } 
/*      */         
/* 1381 */         scriptable1 = scriptable1.getPrototype();
/* 1382 */       } while (scriptable1 != null);
/* 1383 */       scriptable = scriptable.getParentScope();
/*      */     } 
/* 1385 */     Object[] arrayOfObject = { paramString };
/* 1386 */     throw NativeGlobal.constructError(
/* 1387 */         Context.getContext(), "ReferenceError", 
/* 1388 */         getMessage("msg.is.not.defined", arrayOfObject), 
/* 1389 */         paramScriptable);
/*      */   }
/*      */   
/*      */   public static Object postIncrement(Object paramObject, String paramString, Scriptable paramScriptable) {
/*      */     Scriptable scriptable1;
/* 1394 */     if (paramObject instanceof Scriptable) {
/* 1395 */       scriptable1 = (Scriptable)paramObject;
/*      */     } else {
/* 1397 */       scriptable1 = toObject(paramScriptable, paramObject);
/*      */     } 
/* 1399 */     if (scriptable1 == null) {
/* 1400 */       throw NativeGlobal.constructError(
/* 1401 */           Context.getContext(), "TypeError", 
/* 1402 */           getMessage("msg.null.to.object", null), 
/* 1403 */           paramScriptable);
/*      */     }
/* 1405 */     Scriptable scriptable2 = scriptable1;
/*      */     do {
/* 1407 */       Object object = scriptable2.get(paramString, scriptable1);
/* 1408 */       if (object != Scriptable.NOT_FOUND) {
/* 1409 */         Object object1 = object;
/* 1410 */         if (object1 instanceof Number) {
/* 1411 */           object1 = new Double((
/* 1412 */               (Number)object1).doubleValue() + 1.0D);
/* 1413 */           scriptable2.put(paramString, scriptable1, object1);
/* 1414 */           return object;
/*      */         } 
/*      */         
/* 1417 */         object1 = new Double(toNumber(object1) + 1.0D);
/* 1418 */         scriptable2.put(paramString, scriptable1, object1);
/* 1419 */         return new Double(toNumber(object));
/*      */       } 
/*      */       
/* 1422 */       scriptable2 = scriptable2.getPrototype();
/* 1423 */     } while (scriptable2 != null);
/* 1424 */     return Undefined.instance;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object postIncrementElem(Object paramObject1, Object paramObject2, Scriptable paramScriptable) {
/* 1429 */     Object object = getElem(paramObject1, paramObject2, paramScriptable);
/* 1430 */     if (object == Undefined.instance)
/* 1431 */       return Undefined.instance; 
/* 1432 */     double d = toNumber(object);
/* 1433 */     Double double = new Double(d + 1.0D);
/* 1434 */     setElem(paramObject1, paramObject2, double, paramScriptable);
/* 1435 */     return new Double(d);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object postDecrementElem(Object paramObject1, Object paramObject2, Scriptable paramScriptable) {
/* 1440 */     Object object = getElem(paramObject1, paramObject2, paramScriptable);
/* 1441 */     if (object == Undefined.instance)
/* 1442 */       return Undefined.instance; 
/* 1443 */     double d = toNumber(object);
/* 1444 */     Double double = new Double(d - 1.0D);
/* 1445 */     setElem(paramObject1, paramObject2, double, paramScriptable);
/* 1446 */     return new Double(d);
/*      */   }
/*      */   
/*      */   public static Object postDecrement(Object paramObject) {
/* 1450 */     if (paramObject instanceof Number) {
/* 1451 */       paramObject = new Double(((Number)paramObject).doubleValue() - 1.0D);
/*      */     } else {
/* 1453 */       paramObject = new Double(toNumber(paramObject) - 1.0D);
/* 1454 */     }  return paramObject;
/*      */   }
/*      */   
/*      */   public static Object postDecrement(Scriptable paramScriptable, String paramString) {
/* 1458 */     Scriptable scriptable = paramScriptable;
/*      */     
/* 1460 */     while (scriptable != null) {
/* 1461 */       Scriptable scriptable1 = scriptable;
/*      */       do {
/* 1463 */         Object object = scriptable1.get(paramString, scriptable);
/* 1464 */         if (object != Scriptable.NOT_FOUND) {
/* 1465 */           Object object1 = object;
/* 1466 */           if (object1 instanceof Number) {
/* 1467 */             object1 = new Double((
/* 1468 */                 (Number)object1).doubleValue() - 1.0D);
/* 1469 */             scriptable1.put(paramString, scriptable, object1);
/* 1470 */             return object;
/*      */           } 
/*      */           
/* 1473 */           object1 = new Double(toNumber(object1) - 1.0D);
/* 1474 */           scriptable1.put(paramString, scriptable, object1);
/* 1475 */           return new Double(toNumber(object));
/*      */         } 
/*      */         
/* 1478 */         scriptable1 = scriptable1.getPrototype();
/* 1479 */       } while (scriptable1 != null);
/* 1480 */       scriptable = scriptable.getParentScope();
/*      */     } 
/* 1482 */     Object[] arrayOfObject = { paramString };
/* 1483 */     throw NativeGlobal.constructError(
/* 1484 */         Context.getContext(), "ReferenceError", 
/* 1485 */         getMessage("msg.is.not.defined", arrayOfObject), 
/* 1486 */         paramScriptable);
/*      */   }
/*      */   
/*      */   public static Object postDecrement(Object paramObject, String paramString, Scriptable paramScriptable) {
/*      */     Scriptable scriptable1;
/* 1491 */     if (paramObject instanceof Scriptable) {
/* 1492 */       scriptable1 = (Scriptable)paramObject;
/*      */     } else {
/* 1494 */       scriptable1 = toObject(paramScriptable, paramObject);
/*      */     } 
/* 1496 */     if (scriptable1 == null) {
/* 1497 */       throw NativeGlobal.constructError(
/* 1498 */           Context.getContext(), "TypeError", 
/* 1499 */           getMessage("msg.null.to.object", null), 
/* 1500 */           paramScriptable);
/*      */     }
/* 1502 */     Scriptable scriptable2 = scriptable1;
/*      */     do {
/* 1504 */       Object object = scriptable2.get(paramString, scriptable1);
/* 1505 */       if (object != Scriptable.NOT_FOUND) {
/* 1506 */         Object object1 = object;
/* 1507 */         if (object1 instanceof Number) {
/* 1508 */           object1 = new Double((
/* 1509 */               (Number)object1).doubleValue() - 1.0D);
/* 1510 */           scriptable2.put(paramString, scriptable1, object1);
/* 1511 */           return object;
/*      */         } 
/*      */         
/* 1514 */         object1 = new Double(toNumber(object1) - 1.0D);
/* 1515 */         scriptable2.put(paramString, scriptable1, object1);
/* 1516 */         return new Double(toNumber(object));
/*      */       } 
/*      */       
/* 1519 */       scriptable2 = scriptable2.getPrototype();
/* 1520 */     } while (scriptable2 != null);
/* 1521 */     return Undefined.instance;
/*      */   }
/*      */   
/*      */   public static Object toPrimitive(Object paramObject) {
/* 1525 */     if (paramObject == null || !(paramObject instanceof Scriptable)) {
/* 1526 */       return paramObject;
/*      */     }
/* 1528 */     Object object = ((Scriptable)paramObject).getDefaultValue(null);
/* 1529 */     if (object != null && object instanceof Scriptable)
/* 1530 */       throw NativeGlobal.constructError(
/* 1531 */           Context.getContext(), "TypeError", 
/* 1532 */           getMessage("msg.bad.default.value", null), 
/* 1533 */           paramObject); 
/* 1534 */     return object;
/*      */   }
/*      */   
/*      */   private static Class getTypeOfValue(Object paramObject) {
/* 1538 */     if (paramObject == null)
/* 1539 */       return ScriptableClass; 
/* 1540 */     if (paramObject == Undefined.instance)
/* 1541 */       return UndefinedClass; 
/* 1542 */     if (paramObject instanceof Scriptable)
/* 1543 */       return ScriptableClass; 
/* 1544 */     if (paramObject instanceof Number)
/* 1545 */       return NumberClass; 
/* 1546 */     return paramObject.getClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean eq(Object paramObject1, Object paramObject2) {
/* 1555 */     Object object1 = paramObject1;
/* 1556 */     Object object2 = paramObject2;
/*      */     while (true) {
/* 1558 */       Class clazz1 = getTypeOfValue(paramObject1);
/* 1559 */       Class clazz2 = getTypeOfValue(paramObject2);
/* 1560 */       if (clazz1 == clazz2) {
/* 1561 */         if (clazz1 == UndefinedClass)
/* 1562 */           return true; 
/* 1563 */         if (clazz1 == NumberClass)
/* 1564 */           return !(((Number)paramObject1).doubleValue() != (
/* 1565 */             (Number)paramObject2).doubleValue()); 
/* 1566 */         if (clazz1 == StringClass || clazz1 == BooleanClass)
/* 1567 */           return object1.equals(object2); 
/* 1568 */         if (clazz1 == ScriptableClass) {
/* 1569 */           if (paramObject1 == paramObject2)
/* 1570 */             return true; 
/* 1571 */           if (paramObject1 instanceof NativeJavaObject && 
/* 1572 */             paramObject2 instanceof NativeJavaObject)
/*      */           {
/* 1574 */             return !(((NativeJavaObject)paramObject1).unwrap() != (
/* 1575 */               (NativeJavaObject)paramObject2).unwrap());
/*      */           }
/* 1577 */           return false;
/*      */         } 
/* 1579 */         throw new RuntimeException();
/*      */       } 
/* 1581 */       if (paramObject1 == null && paramObject2 == Undefined.instance)
/* 1582 */         return true; 
/* 1583 */       if (paramObject1 == Undefined.instance && paramObject2 == null)
/* 1584 */         return true; 
/* 1585 */       if (clazz1 == NumberClass && 
/* 1586 */         clazz2 == StringClass)
/*      */       {
/* 1588 */         return !(((Number)paramObject1).doubleValue() != toNumber(paramObject2));
/*      */       }
/* 1590 */       if (clazz1 == StringClass && 
/* 1591 */         clazz2 == NumberClass)
/*      */       {
/* 1593 */         return !(toNumber(paramObject1) != ((Number)paramObject2).doubleValue());
/*      */       }
/* 1595 */       if (clazz1 == BooleanClass) {
/* 1596 */         paramObject1 = new Double(toNumber(paramObject1));
/* 1597 */         object1 = paramObject1;
/*      */         continue;
/*      */       } 
/* 1600 */       if (clazz2 == BooleanClass) {
/* 1601 */         paramObject2 = new Double(toNumber(paramObject2));
/* 1602 */         object2 = paramObject2;
/*      */         continue;
/*      */       } 
/* 1605 */       if ((clazz1 == StringClass || 
/* 1606 */         clazz1 == NumberClass) && 
/* 1607 */         clazz2 == ScriptableClass && paramObject2 != null) {
/*      */         
/* 1609 */         paramObject2 = toPrimitive(paramObject2);
/* 1610 */         object2 = paramObject2;
/*      */         continue;
/*      */       } 
/* 1613 */       if (clazz1 == ScriptableClass && paramObject1 != null && (
/* 1614 */         clazz2 == StringClass || 
/* 1615 */         clazz2 == NumberClass)) {
/*      */         
/* 1617 */         paramObject1 = toPrimitive(paramObject1);
/* 1618 */         object1 = paramObject1; continue;
/*      */       }  break;
/*      */     } 
/* 1621 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Boolean eqB(Object paramObject1, Object paramObject2) {
/* 1626 */     if (eq(paramObject1, paramObject2)) {
/* 1627 */       return Boolean.TRUE;
/*      */     }
/* 1629 */     return Boolean.FALSE;
/*      */   }
/*      */   
/*      */   public static Boolean neB(Object paramObject1, Object paramObject2) {
/* 1633 */     if (eq(paramObject1, paramObject2)) {
/* 1634 */       return Boolean.FALSE;
/*      */     }
/* 1636 */     return Boolean.TRUE;
/*      */   }
/*      */   
/*      */   public static boolean shallowEq(Object paramObject1, Object paramObject2) {
/* 1640 */     Class clazz = getTypeOfValue(paramObject1);
/* 1641 */     if (clazz != getTypeOfValue(paramObject2))
/* 1642 */       return false; 
/* 1643 */     if (clazz == StringClass || clazz == BooleanClass)
/* 1644 */       return paramObject1.equals(paramObject2); 
/* 1645 */     if (clazz == NumberClass)
/* 1646 */       return !(((Number)paramObject1).doubleValue() != (
/* 1647 */         (Number)paramObject2).doubleValue()); 
/* 1648 */     if (clazz == ScriptableClass) {
/* 1649 */       if (paramObject1 == paramObject2)
/* 1650 */         return true; 
/* 1651 */       if (paramObject1 instanceof NativeJavaObject && paramObject2 instanceof NativeJavaObject)
/* 1652 */         return !(((NativeJavaObject)paramObject1).unwrap() != (
/* 1653 */           (NativeJavaObject)paramObject2).unwrap()); 
/* 1654 */       return false;
/*      */     } 
/* 1656 */     if (clazz == UndefinedClass)
/* 1657 */       return true; 
/* 1658 */     return false;
/*      */   }
/*      */   
/*      */   public static Boolean seqB(Object paramObject1, Object paramObject2) {
/* 1662 */     if (shallowEq(paramObject1, paramObject2)) {
/* 1663 */       return Boolean.TRUE;
/*      */     }
/* 1665 */     return Boolean.FALSE;
/*      */   }
/*      */   
/*      */   public static Boolean sneB(Object paramObject1, Object paramObject2) {
/* 1669 */     if (shallowEq(paramObject1, paramObject2)) {
/* 1670 */       return Boolean.FALSE;
/*      */     }
/* 1672 */     return Boolean.TRUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean instanceOf(Scriptable paramScriptable, Object paramObject1, Object paramObject2) {
/* 1682 */     if (!(paramObject2 instanceof Scriptable)) {
/* 1683 */       throw NativeGlobal.constructError(
/* 1684 */           Context.getContext(), "TypeError", 
/* 1685 */           getMessage("msg.instanceof.not.object", null), 
/* 1686 */           paramScriptable);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1692 */     if (!(paramObject1 instanceof Scriptable)) {
/* 1693 */       return false;
/*      */     }
/* 1695 */     return ((Scriptable)paramObject2).hasInstance((Scriptable)paramObject1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean jsDelegatesTo(Scriptable paramScriptable1, Scriptable paramScriptable2) {
/* 1704 */     Scriptable scriptable = paramScriptable1.getPrototype();
/*      */     
/* 1706 */     while (scriptable != null) {
/* 1707 */       if (scriptable.equals(paramScriptable2)) return true; 
/* 1708 */       scriptable = scriptable.getPrototype();
/*      */     } 
/*      */     
/* 1711 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean in(Object paramObject1, Object paramObject2) {
/* 1728 */     if (!(paramObject2 instanceof Scriptable)) {
/* 1729 */       throw NativeGlobal.constructError(
/* 1730 */           Context.getContext(), "TypeError", 
/* 1731 */           getMessage("msg.instanceof.not.object", null), paramObject1);
/*      */     }
/*      */     
/* 1734 */     FlattenedObject flattenedObject = new FlattenedObject((Scriptable)paramObject2);
/* 1735 */     return flattenedObject.hasProperty(paramObject1);
/*      */   }
/*      */   
/*      */   public static Boolean cmp_LTB(Object paramObject1, Object paramObject2) {
/* 1739 */     if (cmp_LT(paramObject1, paramObject2) == 1) {
/* 1740 */       return Boolean.TRUE;
/*      */     }
/* 1742 */     return Boolean.FALSE;
/*      */   }
/*      */   
/*      */   public static int cmp_LT(Object paramObject1, Object paramObject2) {
/* 1746 */     if (paramObject1 instanceof Scriptable)
/* 1747 */       paramObject1 = ((Scriptable)paramObject1).getDefaultValue(NumberClass); 
/* 1748 */     if (paramObject2 instanceof Scriptable)
/* 1749 */       paramObject2 = ((Scriptable)paramObject2).getDefaultValue(NumberClass); 
/* 1750 */     if (!(paramObject1 instanceof String) || !(paramObject2 instanceof String)) {
/* 1751 */       double d1 = toNumber(paramObject1);
/* 1752 */       if (d1 != d1)
/* 1753 */         return 0; 
/* 1754 */       double d2 = toNumber(paramObject2);
/* 1755 */       if (d2 != d2)
/* 1756 */         return 0; 
/* 1757 */       return (d1 < d2) ? 1 : 0;
/*      */     } 
/* 1759 */     return (toString(paramObject1).compareTo(toString(paramObject2)) < 0) ? 1 : 0;
/*      */   }
/*      */   
/*      */   public static Boolean cmp_LEB(Object paramObject1, Object paramObject2) {
/* 1763 */     if (cmp_LE(paramObject1, paramObject2) == 1) {
/* 1764 */       return Boolean.TRUE;
/*      */     }
/* 1766 */     return Boolean.FALSE;
/*      */   }
/*      */   
/*      */   public static int cmp_LE(Object paramObject1, Object paramObject2) {
/* 1770 */     if (paramObject1 instanceof Scriptable)
/* 1771 */       paramObject1 = ((Scriptable)paramObject1).getDefaultValue(NumberClass); 
/* 1772 */     if (paramObject2 instanceof Scriptable)
/* 1773 */       paramObject2 = ((Scriptable)paramObject2).getDefaultValue(NumberClass); 
/* 1774 */     if (!(paramObject1 instanceof String) || !(paramObject2 instanceof String)) {
/* 1775 */       double d1 = toNumber(paramObject1);
/* 1776 */       if (d1 != d1)
/* 1777 */         return 0; 
/* 1778 */       double d2 = toNumber(paramObject2);
/* 1779 */       if (d2 != d2)
/* 1780 */         return 0; 
/* 1781 */       return (d1 <= d2) ? 1 : 0;
/*      */     } 
/* 1783 */     return (toString(paramObject1).compareTo(toString(paramObject2)) <= 0) ? 1 : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String paramString, String[] paramArrayOfString) throws JavaScriptException {
/*      */     Scriptable scriptable2;
/* 1809 */     Context context = Context.enter();
/*      */     
/* 1811 */     Scriptable scriptable1 = context.initStandardObjects(null);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1817 */       scriptable2 = context.newObject(scriptable1, "Array");
/*      */     }
/* 1819 */     catch (PropertyException propertyException) {
/* 1820 */       throw WrappedException.wrapException(propertyException);
/*      */     }
/* 1822 */     catch (NotAFunctionException notAFunctionException) {
/* 1823 */       throw WrappedException.wrapException(notAFunctionException);
/*      */     }
/* 1825 */     catch (JavaScriptException javaScriptException) {
/* 1826 */       throw WrappedException.wrapException(javaScriptException);
/*      */     } 
/* 1828 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 1829 */       scriptable2.put(b, scriptable2, paramArrayOfString[b]);
/*      */     }
/* 1831 */     scriptable1.put("arguments", scriptable1, scriptable2);
/*      */     
/*      */     try {
/* 1834 */       Class clazz = loadClassName(paramString);
/* 1835 */       Script script = (Script)clazz.newInstance();
/* 1836 */       script.exec(context, scriptable1);
/*      */       
/*      */       return;
/* 1839 */     } catch (ClassNotFoundException classNotFoundException) {
/*      */     
/* 1841 */     } catch (InstantiationException instantiationException) {
/*      */     
/* 1843 */     } catch (IllegalAccessException illegalAccessException) {
/*      */     
/*      */     } finally {
/* 1846 */       Context.exit();
/*      */     } 
/* 1848 */     throw new RuntimeException("Error creating script object");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable initScript(Context paramContext, Scriptable paramScriptable1, NativeFunction paramNativeFunction, Scriptable paramScriptable2, boolean paramBoolean) {
/* 1856 */     String[] arrayOfString = paramNativeFunction.names;
/* 1857 */     if (arrayOfString != null) {
/*      */       Object object;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1865 */         object = (ScriptableObject)paramScriptable1;
/* 1866 */       } catch (ClassCastException classCastException) {
/*      */         
/* 1868 */         object = null;
/*      */       } 
/*      */       
/* 1871 */       Scriptable scriptable = paramScriptable1;
/* 1872 */       if (paramBoolean) {
/*      */ 
/*      */ 
/*      */         
/* 1876 */         scriptable = paramScriptable1;
/* 1877 */         while (scriptable instanceof NativeWith)
/* 1878 */           scriptable = scriptable.getParentScope(); 
/*      */       } 
/* 1880 */       for (int i = paramNativeFunction.names.length - 1; i > 0; i--) {
/* 1881 */         String str = paramNativeFunction.names[i];
/*      */ 
/*      */         
/* 1884 */         if (!hasProp(paramScriptable1, str)) {
/* 1885 */           if (object != null && !paramBoolean) {
/* 1886 */             object.defineProperty(str, Undefined.instance, 
/* 1887 */                 4);
/*      */           } else {
/* 1889 */             scriptable.put(str, scriptable, Undefined.instance);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/* 1894 */     if (paramContext.getDebugLevel() > 0);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1899 */     return paramScriptable1;
/*      */   }
/*      */   
/*      */   public static Scriptable runScript(Script paramScript) {
/* 1903 */     Context context = Context.enter();
/* 1904 */     Scriptable scriptable = context.initStandardObjects(new ImporterTopLevel());
/*      */     try {
/* 1906 */       paramScript.exec(context, scriptable);
/* 1907 */     } catch (JavaScriptException javaScriptException) {
/* 1908 */       throw new Error(javaScriptException.toString());
/*      */     } 
/* 1910 */     Context.exit();
/* 1911 */     return scriptable;
/*      */   }
/*      */   
/*      */   public static void setAdapterProto(Scriptable paramScriptable, Object paramObject) {
/* 1915 */     Scriptable scriptable1 = paramScriptable.getPrototype();
/* 1916 */     Scriptable scriptable2 = ScriptableObject.getTopLevelScope(paramScriptable);
/* 1917 */     Scriptable scriptable3 = Context.toObject(paramObject, scriptable2);
/* 1918 */     paramScriptable.setPrototype(scriptable3);
/* 1919 */     scriptable3.setPrototype(scriptable1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable initVarObj(Context paramContext, Scriptable paramScriptable1, NativeFunction paramNativeFunction, Scriptable paramScriptable2, Object[] paramArrayOfObject) {
/* 1926 */     NativeCall nativeCall = new NativeCall(paramContext, paramScriptable1, paramNativeFunction, paramScriptable2, paramArrayOfObject);
/* 1927 */     String[] arrayOfString = paramNativeFunction.names;
/* 1928 */     if (arrayOfString != null) {
/* 1929 */       for (short s = paramNativeFunction.argCount + 1; s < paramNativeFunction.names.length; s++) {
/* 1930 */         String str = paramNativeFunction.names[s];
/* 1931 */         nativeCall.put(str, nativeCall, Undefined.instance);
/*      */       } 
/*      */     }
/* 1934 */     return nativeCall;
/*      */   }
/*      */   
/*      */   public static void popActivation(Context paramContext) {
/* 1938 */     NativeCall nativeCall = paramContext.currentActivation;
/* 1939 */     if (nativeCall != null) {
/* 1940 */       paramContext.currentActivation = nativeCall.caller;
/* 1941 */       nativeCall.caller = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 1946 */   public static Scriptable newScope() { return new NativeObject(); }
/*      */ 
/*      */ 
/*      */   
/* 1950 */   public static Scriptable enterWith(Object paramObject, Scriptable paramScriptable) { return new NativeWith(paramScriptable, toObject(paramScriptable, paramObject)); }
/*      */ 
/*      */ 
/*      */   
/* 1954 */   public static Scriptable leaveWith(Scriptable paramScriptable) { return paramScriptable.getParentScope(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NativeFunction initFunction(NativeFunction paramNativeFunction, Scriptable paramScriptable, String paramString, Context paramContext) {
/* 1962 */     paramNativeFunction.setPrototype(ScriptableObject.getClassPrototype(paramScriptable, "Function"));
/* 1963 */     paramNativeFunction.setParentScope(paramScriptable);
/* 1964 */     if (paramString != null && paramString.length() != 0)
/* 1965 */       setName(paramScriptable, paramNativeFunction, paramScriptable, paramString); 
/* 1966 */     return paramNativeFunction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NativeFunction createFunctionObject(Scriptable paramScriptable, Class paramClass, Context paramContext, boolean paramBoolean) {
/* 1974 */     Constructor[] arrayOfConstructor = paramClass.getConstructors();
/*      */     
/* 1976 */     NativeFunction nativeFunction = null;
/* 1977 */     Object[] arrayOfObject = { paramScriptable, paramContext };
/*      */     try {
/* 1979 */       nativeFunction = (NativeFunction)arrayOfConstructor[0].newInstance(arrayOfObject);
/*      */     }
/* 1981 */     catch (InstantiationException instantiationException) {
/* 1982 */       throw WrappedException.wrapException(instantiationException);
/*      */     }
/* 1984 */     catch (IllegalAccessException illegalAccessException) {
/* 1985 */       throw WrappedException.wrapException(illegalAccessException);
/*      */     }
/* 1987 */     catch (IllegalArgumentException illegalArgumentException) {
/* 1988 */       throw WrappedException.wrapException(illegalArgumentException);
/*      */     }
/* 1990 */     catch (InvocationTargetException invocationTargetException) {
/* 1991 */       throw WrappedException.wrapException(invocationTargetException);
/*      */     } 
/*      */     
/* 1994 */     nativeFunction.setPrototype(ScriptableObject.getClassPrototype(paramScriptable, "Function"));
/* 1995 */     nativeFunction.setParentScope(paramScriptable);
/*      */     
/* 1997 */     String str = nativeFunction.jsGet_name();
/* 1998 */     if (paramBoolean && str != null && str.length() != 0 && 
/* 1999 */       !str.equals("anonymous"))
/*      */     {
/* 2001 */       setProp(paramScriptable, str, nativeFunction, paramScriptable);
/*      */     }
/*      */     
/* 2004 */     return nativeFunction;
/*      */   }
/*      */   
/*      */   static void checkDeprecated(Context paramContext, String paramString) {
/* 2008 */     int i = paramContext.getLanguageVersion();
/* 2009 */     if (i >= 140 || i == 0) {
/* 2010 */       Object[] arrayOfObject = { paramString };
/* 2011 */       String str = getMessage("msg.deprec.ctor", 
/* 2012 */           arrayOfObject);
/* 2013 */       if (i == 0) {
/* 2014 */         Context.reportWarning(str);
/*      */       } else {
/* 2016 */         throw Context.reportRuntimeError(str);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/* 2021 */   public static String getMessage(String paramString, Object[] paramArrayOfObject) { return Context.getMessage(paramString, paramArrayOfObject); }
/*      */ 
/*      */ 
/*      */   
/* 2025 */   public static RegExpProxy getRegExpProxy(Context paramContext) { return paramContext.getRegExpProxy(); }
/*      */ 
/*      */ 
/*      */   
/* 2029 */   public static NativeCall getCurrentActivation(Context paramContext) { return paramContext.currentActivation; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2035 */   public static void setCurrentActivation(Context paramContext, NativeCall paramNativeCall) { paramContext.currentActivation = paramNativeCall; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static  {
/*      */     try {
/* 2043 */       getContextClassLoaderMethod = 
/* 2044 */         Thread.class.getDeclaredMethod("getContextClassLoader", 
/* 2045 */           new Class[0]);
/* 2046 */     } catch (NoSuchMethodException noSuchMethodException) {
/*      */     
/* 2048 */     } catch (SecurityException securityException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2097 */     emptyArgs = new Object[0];
/*      */   }
/*      */   
/*      */   public static Class loadClassName(String paramString) {
/*      */     try {
/*      */       if (getContextClassLoaderMethod != null) {
/*      */         ClassLoader classLoader = (ClassLoader)getContextClassLoaderMethod.invoke(Thread.currentThread(), new Object[0]);
/*      */         if (classLoader != null)
/*      */           return classLoader.loadClass(paramString); 
/*      */       } 
/*      */     } catch (SecurityException securityException) {
/*      */     
/*      */     } catch (IllegalAccessException illegalAccessException) {
/*      */     
/*      */     } catch (InvocationTargetException invocationTargetException) {
/*      */     
/*      */     } catch (ClassNotFoundException classNotFoundException) {}
/*      */     return Class.forName(paramString);
/*      */   }
/*      */   
/*      */   static boolean hasProp(Scriptable paramScriptable, String paramString) {
/*      */     Scriptable scriptable = paramScriptable;
/*      */     do {
/*      */       if (scriptable.has(paramString, paramScriptable))
/*      */         return true; 
/*      */       scriptable = scriptable.getPrototype();
/*      */     } while (scriptable != null);
/*      */     return false;
/*      */   }
/*      */   
/*      */   private static RuntimeException errorWithClassName(String paramString, Object paramObject) {
/*      */     Object[] arrayOfObject = { paramObject.getClass().getName() };
/*      */     return Context.reportRuntimeError(getMessage(paramString, arrayOfObject));
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\ScriptRuntime.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */