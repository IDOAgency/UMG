/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListenerCollection
/*     */   extends Vector
/*     */ {
/*  70 */   public void addListener(Object paramObject) { addElement(paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public void removeListener(Object paramObject) { removeElement(paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public Enumeration getAllListeners() { return elements(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getListeners(Class paramClass) {
/*  99 */     Vector vector = new Vector();
/*     */     
/* 101 */     for (Enumeration enumeration = getAllListeners(); enumeration.hasMoreElements(); ) {
/* 102 */       Object object = enumeration.nextElement();
/* 103 */       if (paramClass.isInstance(object)) {
/* 104 */         vector.addElement(object);
/*     */       }
/*     */     } 
/* 107 */     Object[] arrayOfObject = new Object[vector.size()];
/* 108 */     vector.copyInto(arrayOfObject);
/* 109 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\ListenerCollection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */