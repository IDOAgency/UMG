package org.mozilla.javascript;

import java.util.Enumeration;
import java.util.Vector;

public class ListenerCollection extends Vector {
  public void addListener(Object paramObject) { addElement(paramObject); }
  
  public void removeListener(Object paramObject) { removeElement(paramObject); }
  
  public Enumeration getAllListeners() { return elements(); }
  
  public Object[] getListeners(Class paramClass) {
    Vector vector = new Vector();
    for (Enumeration enumeration = getAllListeners(); enumeration.hasMoreElements(); ) {
      Object object = enumeration.nextElement();
      if (paramClass.isInstance(object))
        vector.addElement(object); 
    } 
    Object[] arrayOfObject = new Object[vector.size()];
    vector.copyInto(arrayOfObject);
    return arrayOfObject;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\ListenerCollection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */