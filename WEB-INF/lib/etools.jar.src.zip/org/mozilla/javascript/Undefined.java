package org.mozilla.javascript;

public class Undefined implements Scriptable {
  public static final Scriptable instance = new Undefined();
  
  public String getClassName() { return "undefined"; }
  
  public boolean has(String paramString, Scriptable paramScriptable) { return false; }
  
  public boolean has(int paramInt, Scriptable paramScriptable) { return false; }
  
  public Object get(String paramString, Scriptable paramScriptable) { throw reportError(); }
  
  public Object get(int paramInt, Scriptable paramScriptable) { throw reportError(); }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) { throw reportError(); }
  
  public void put(int paramInt, Scriptable paramScriptable, Object paramObject) { throw reportError(); }
  
  public void delete(String paramString) { throw reportError(); }
  
  public void delete(int paramInt) { throw reportError(); }
  
  public short getAttributes(String paramString, Scriptable paramScriptable) { throw reportError(); }
  
  public short getAttributes(int paramInt, Scriptable paramScriptable) { throw reportError(); }
  
  public void setAttributes(String paramString, Scriptable paramScriptable, short paramShort) { throw reportError(); }
  
  public void setAttributes(int paramInt, Scriptable paramScriptable, short paramShort) { throw reportError(); }
  
  public Scriptable getPrototype() { throw reportError(); }
  
  public void setPrototype(Scriptable paramScriptable) { throw reportError(); }
  
  public Scriptable getParentScope() { throw reportError(); }
  
  public void setParentScope(Scriptable paramScriptable) { throw reportError(); }
  
  public Object[] getIds() { throw reportError(); }
  
  public Object getDefaultValue(Class paramClass) {
    if (paramClass == ScriptRuntime.StringClass)
      return "undefined"; 
    if (paramClass == ScriptRuntime.NumberClass)
      return ScriptRuntime.NaNobj; 
    if (paramClass == ScriptRuntime.BooleanClass)
      return Boolean.FALSE; 
    return this;
  }
  
  public boolean hasInstance(Scriptable paramScriptable) { throw reportError(); }
  
  public boolean instanceOf(Scriptable paramScriptable) { return false; }
  
  private RuntimeException reportError() {
    String str = Context.getMessage("msg.undefined", null);
    return Context.reportRuntimeError(str);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Undefined.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */