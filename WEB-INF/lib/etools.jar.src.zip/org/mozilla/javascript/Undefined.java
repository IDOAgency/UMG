/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Undefined
/*     */   implements Scriptable
/*     */ {
/*  43 */   public static final Scriptable instance = new Undefined();
/*     */ 
/*     */   
/*  46 */   public String getClassName() { return "undefined"; }
/*     */ 
/*     */ 
/*     */   
/*  50 */   public boolean has(String paramString, Scriptable paramScriptable) { return false; }
/*     */ 
/*     */ 
/*     */   
/*  54 */   public boolean has(int paramInt, Scriptable paramScriptable) { return false; }
/*     */ 
/*     */ 
/*     */   
/*  58 */   public Object get(String paramString, Scriptable paramScriptable) { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/*  62 */   public Object get(int paramInt, Scriptable paramScriptable) { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/*  66 */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/*  70 */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/*  74 */   public void delete(String paramString) { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/*  78 */   public void delete(int paramInt) { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/*  82 */   public short getAttributes(String paramString, Scriptable paramScriptable) { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/*  86 */   public short getAttributes(int paramInt, Scriptable paramScriptable) { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/*  90 */   public void setAttributes(String paramString, Scriptable paramScriptable, short paramShort) { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/*  94 */   public void setAttributes(int paramInt, Scriptable paramScriptable, short paramShort) { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/*  98 */   public Scriptable getPrototype() { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/* 102 */   public void setPrototype(Scriptable paramScriptable) { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/* 106 */   public Scriptable getParentScope() { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/* 110 */   public void setParentScope(Scriptable paramScriptable) { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/* 114 */   public Object[] getIds() { throw reportError(); }
/*     */ 
/*     */   
/*     */   public Object getDefaultValue(Class paramClass) {
/* 118 */     if (paramClass == ScriptRuntime.StringClass)
/* 119 */       return "undefined"; 
/* 120 */     if (paramClass == ScriptRuntime.NumberClass)
/* 121 */       return ScriptRuntime.NaNobj; 
/* 122 */     if (paramClass == ScriptRuntime.BooleanClass)
/* 123 */       return Boolean.FALSE; 
/* 124 */     return this;
/*     */   }
/*     */ 
/*     */   
/* 128 */   public boolean hasInstance(Scriptable paramScriptable) { throw reportError(); }
/*     */ 
/*     */ 
/*     */   
/* 132 */   public boolean instanceOf(Scriptable paramScriptable) { return false; }
/*     */ 
/*     */   
/*     */   private RuntimeException reportError() {
/* 136 */     String str = Context.getMessage("msg.undefined", null);
/* 137 */     return Context.reportRuntimeError(str);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Undefined.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */