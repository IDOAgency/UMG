package org.mozilla.javascript;

import java.lang.reflect.Method;

class BeanProperty {
  Method getter;
  
  Method setter;
  
  BeanProperty(Method paramMethod1, Method paramMethod2) {
    this.getter = paramMethod1;
    this.setter = paramMethod2;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\BeanProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */