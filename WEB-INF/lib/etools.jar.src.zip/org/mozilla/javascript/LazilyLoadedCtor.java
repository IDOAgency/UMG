package org.mozilla.javascript;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class LazilyLoadedCtor {
  private String ctorName;
  
  private String className;
  
  LazilyLoadedCtor(ScriptableObject paramScriptableObject, String paramString1, String paramString2, int paramInt) throws PropertyException {
    this.className = paramString2;
    this.ctorName = paramString1;
    Class clazz = getClass();
    Method[] arrayOfMethod1 = FunctionObject.findMethods(clazz, "getProperty");
    Method[] arrayOfMethod2 = FunctionObject.findMethods(clazz, "setProperty");
    paramScriptableObject.defineProperty(this.ctorName, this, arrayOfMethod1[0], arrayOfMethod2[0], 
        paramInt);
  }
  
  public Object getProperty(ScriptableObject paramScriptableObject) {
    paramScriptableObject.delete(this.ctorName);
    try {
      ScriptableObject.defineClass(paramScriptableObject, Class.forName(this.className));
    } catch (ClassNotFoundException classNotFoundException) {
      throw WrappedException.wrapException(classNotFoundException);
    } catch (InstantiationException instantiationException) {
      throw WrappedException.wrapException(instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      throw WrappedException.wrapException(illegalAccessException);
    } catch (InvocationTargetException invocationTargetException) {
      throw WrappedException.wrapException(invocationTargetException);
    } catch (ClassDefinitionException classDefinitionException) {
      throw WrappedException.wrapException(classDefinitionException);
    } catch (PropertyException propertyException) {
      throw WrappedException.wrapException(propertyException);
    } 
    return paramScriptableObject.get(this.ctorName, paramScriptableObject);
  }
  
  public void setProperty(ScriptableObject paramScriptableObject, Object paramObject) {
    paramScriptableObject.delete(this.ctorName);
    paramScriptableObject.put(this.ctorName, paramScriptableObject, paramObject);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\LazilyLoadedCtor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */