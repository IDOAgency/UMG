/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LazilyLoadedCtor
/*    */ {
/*    */   private String ctorName;
/*    */   private String className;
/*    */   
/*    */   LazilyLoadedCtor(ScriptableObject paramScriptableObject, String paramString1, String paramString2, int paramInt) throws PropertyException {
/* 51 */     this.className = paramString2;
/* 52 */     this.ctorName = paramString1;
/* 53 */     Class clazz = getClass();
/* 54 */     Method[] arrayOfMethod1 = FunctionObject.findMethods(clazz, "getProperty");
/* 55 */     Method[] arrayOfMethod2 = FunctionObject.findMethods(clazz, "setProperty");
/* 56 */     paramScriptableObject.defineProperty(this.ctorName, this, arrayOfMethod1[0], arrayOfMethod2[0], 
/* 57 */         paramInt);
/*    */   }
/*    */   
/*    */   public Object getProperty(ScriptableObject paramScriptableObject) {
/* 61 */     paramScriptableObject.delete(this.ctorName);
/*    */     try {
/* 63 */       ScriptableObject.defineClass(paramScriptableObject, Class.forName(this.className));
/*    */     }
/* 65 */     catch (ClassNotFoundException classNotFoundException) {
/* 66 */       throw WrappedException.wrapException(classNotFoundException);
/*    */     }
/* 68 */     catch (InstantiationException instantiationException) {
/* 69 */       throw WrappedException.wrapException(instantiationException);
/*    */     }
/* 71 */     catch (IllegalAccessException illegalAccessException) {
/* 72 */       throw WrappedException.wrapException(illegalAccessException);
/*    */     }
/* 74 */     catch (InvocationTargetException invocationTargetException) {
/* 75 */       throw WrappedException.wrapException(invocationTargetException);
/*    */     }
/* 77 */     catch (ClassDefinitionException classDefinitionException) {
/* 78 */       throw WrappedException.wrapException(classDefinitionException);
/*    */     }
/* 80 */     catch (PropertyException propertyException) {
/* 81 */       throw WrappedException.wrapException(propertyException);
/*    */     } 
/* 83 */     return paramScriptableObject.get(this.ctorName, paramScriptableObject);
/*    */   }
/*    */   
/*    */   public void setProperty(ScriptableObject paramScriptableObject, Object paramObject) {
/* 87 */     paramScriptableObject.delete(this.ctorName);
/* 88 */     paramScriptableObject.put(this.ctorName, paramScriptableObject, paramObject);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\LazilyLoadedCtor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */