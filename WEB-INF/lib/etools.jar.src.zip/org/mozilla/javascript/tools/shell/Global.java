package org.mozilla.javascript.tools.shell;

import java.lang.reflect.InvocationTargetException;
import org.mozilla.javascript.ClassDefinitionException;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.ImporterTopLevel;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.PropertyException;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.tools.ToolErrorReporter;

public class Global extends ImporterTopLevel {
  public String getClassName() { return "global"; }
  
  public Global() {
    Context context = Context.enter();
    context.initStandardObjects(this, false);
    String[] arrayOfString = { "print", "quit", "version", "load", "help", 
        "loadClass", "defineClass", "spawn" };
    try {
      defineFunctionProperties(arrayOfString, Global.class, 
          2);
    } catch (PropertyException propertyException) {
      throw new Error(propertyException.getMessage());
    } finally {
      Context.exit();
    } 
  }
  
  public static void help(String paramString) { Main.getOut().println(ToolErrorReporter.getMessage("msg.help")); }
  
  public static Object print(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    for (byte b = 0; b < paramArrayOfObject.length; b++) {
      if (b)
        Main.getOut().print(" "); 
      String str = Context.toString(paramArrayOfObject[b]);
      Main.getOut().print(str);
    } 
    Main.getOut().println();
    return Context.getUndefinedValue();
  }
  
  public static void quit(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws IllegalAccessException, InstantiationException, InvocationTargetException, ClassDefinitionException, PropertyException {
    Main.global.exitCode = 0;
    if (paramArrayOfObject.length > 0)
      Main.global.exitCode = (int)Context.toNumber(paramArrayOfObject[0]); 
    Main.global.quitting = true;
  }
  
  public static double version(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    double d = paramContext.getLanguageVersion();
    if (paramArrayOfObject.length > 0) {
      double d1 = Context.toNumber(paramArrayOfObject[0]);
      paramContext.setLanguageVersion((int)d1);
    } 
    return d;
  }
  
  public static void load(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws IllegalAccessException, InstantiationException, InvocationTargetException, ClassDefinitionException, PropertyException {
    for (byte b = 0; b < paramArrayOfObject.length; b++)
      Main.processSource(paramContext, Context.toString(paramArrayOfObject[b])); 
  }
  
  public static void defineClass(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws IllegalAccessException, InstantiationException, InvocationTargetException, ClassDefinitionException, PropertyException {
    Class clazz = getClass(paramArrayOfObject);
    ScriptableObject.defineClass(Main.global, clazz);
  }
  
  public static void loadClass(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws IllegalAccessException, InstantiationException, InvocationTargetException, ClassDefinitionException, PropertyException {
    Class clazz = getClass(paramArrayOfObject);
    if (!Script.class.isAssignableFrom(clazz))
      throw Context.reportRuntimeError(ToolErrorReporter.getMessage(
            "msg.must.implement.Script")); 
    Script script = (Script)clazz.newInstance();
    script.exec(paramContext, Main.global);
  }
  
  private static Class getClass(Object[] paramArrayOfObject) throws IllegalAccessException, InstantiationException, InvocationTargetException {
    if (paramArrayOfObject.length == 0)
      throw Context.reportRuntimeError(ToolErrorReporter.getMessage(
            "msg.expected.string.arg")); 
    String str = Context.toString(paramArrayOfObject[0]);
    try {
      return Class.forName(str);
    } catch (ClassNotFoundException classNotFoundException) {
      throw Context.reportRuntimeError(ToolErrorReporter.getMessage(
            "msg.class.not.found", 
            str));
    } 
  }
  
  public static Object spawn(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    Runner runner;
    Scriptable scriptable = paramFunction.getParentScope();
    if (paramArrayOfObject.length != 0 && paramArrayOfObject[0] instanceof Function) {
      Object[] arrayOfObject = null;
      if (paramArrayOfObject.length > 1 && paramArrayOfObject[1] instanceof Scriptable)
        arrayOfObject = paramContext.getElements((Scriptable)paramArrayOfObject[1]); 
      runner = new Runner(scriptable, (Function)paramArrayOfObject[0], arrayOfObject);
    } else if (paramArrayOfObject.length != 0 && paramArrayOfObject[0] instanceof Script) {
      runner = new Runner(scriptable, (Script)paramArrayOfObject[0]);
    } else {
      throw Context.reportRuntimeError(ToolErrorReporter.getMessage(
            "msg.spawn.args"));
    } 
    Thread thread = new Thread(runner);
    thread.start();
    return thread;
  }
  
  boolean debug = false;
  
  boolean processStdin = true;
  
  boolean quitting;
  
  int exitCode = 0;
  
  NativeArray history;
  
  boolean showDebuggerUI = false;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\tools\shell\Global.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */