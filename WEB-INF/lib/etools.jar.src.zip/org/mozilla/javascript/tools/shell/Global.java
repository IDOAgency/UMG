/*     */ package org.mozilla.javascript.tools.shell;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import org.mozilla.javascript.ClassDefinitionException;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.Function;
/*     */ import org.mozilla.javascript.ImporterTopLevel;
/*     */ import org.mozilla.javascript.NativeArray;
/*     */ import org.mozilla.javascript.PropertyException;
/*     */ import org.mozilla.javascript.Script;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.tools.ToolErrorReporter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Global
/*     */   extends ImporterTopLevel
/*     */ {
/*  63 */   public String getClassName() { return "global"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Global() {
/*  70 */     Context context = Context.enter();
/*     */ 
/*     */ 
/*     */     
/*  74 */     context.initStandardObjects(this, false);
/*     */ 
/*     */ 
/*     */     
/*  78 */     String[] arrayOfString = { "print", "quit", "version", "load", "help", 
/*  79 */         "loadClass", "defineClass", "spawn" };
/*     */     try {
/*  81 */       defineFunctionProperties(arrayOfString, Global.class, 
/*  82 */           2);
/*  83 */     } catch (PropertyException propertyException) {
/*  84 */       throw new Error(propertyException.getMessage());
/*     */     } finally {
/*  86 */       Context.exit();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public static void help(String paramString) { Main.getOut().println(ToolErrorReporter.getMessage("msg.help")); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object print(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 111 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 112 */       if (b) {
/* 113 */         Main.getOut().print(" ");
/*     */       }
/*     */       
/* 116 */       String str = Context.toString(paramArrayOfObject[b]);
/*     */       
/* 118 */       Main.getOut().print(str);
/*     */     } 
/* 120 */     Main.getOut().println();
/* 121 */     return Context.getUndefinedValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void quit(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws IllegalAccessException, InstantiationException, InvocationTargetException, ClassDefinitionException, PropertyException {
/* 135 */     Main.global.exitCode = 0;
/*     */     
/* 137 */     if (paramArrayOfObject.length > 0) {
/* 138 */       Main.global.exitCode = (int)Context.toNumber(paramArrayOfObject[0]);
/*     */     }
/* 140 */     Main.global.quitting = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double version(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 151 */     double d = paramContext.getLanguageVersion();
/* 152 */     if (paramArrayOfObject.length > 0) {
/* 153 */       double d1 = Context.toNumber(paramArrayOfObject[0]);
/* 154 */       paramContext.setLanguageVersion((int)d1);
/*     */     } 
/* 156 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void load(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws IllegalAccessException, InstantiationException, InvocationTargetException, ClassDefinitionException, PropertyException {
/* 168 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 169 */       Main.processSource(paramContext, Context.toString(paramArrayOfObject[b]));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void defineClass(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws IllegalAccessException, InstantiationException, InvocationTargetException, ClassDefinitionException, PropertyException {
/* 196 */     Class clazz = getClass(paramArrayOfObject);
/* 197 */     ScriptableObject.defineClass(Main.global, clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void loadClass(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws IllegalAccessException, InstantiationException, InvocationTargetException, ClassDefinitionException, PropertyException {
/* 224 */     Class clazz = getClass(paramArrayOfObject);
/* 225 */     if (!Script.class.isAssignableFrom(clazz)) {
/* 226 */       throw Context.reportRuntimeError(ToolErrorReporter.getMessage(
/* 227 */             "msg.must.implement.Script"));
/*     */     }
/* 229 */     Script script = (Script)clazz.newInstance();
/* 230 */     script.exec(paramContext, Main.global);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class getClass(Object[] paramArrayOfObject) throws IllegalAccessException, InstantiationException, InvocationTargetException {
/* 237 */     if (paramArrayOfObject.length == 0) {
/* 238 */       throw Context.reportRuntimeError(ToolErrorReporter.getMessage(
/* 239 */             "msg.expected.string.arg"));
/*     */     }
/* 241 */     String str = Context.toString(paramArrayOfObject[0]);
/*     */     try {
/* 243 */       return Class.forName(str);
/*     */     }
/* 245 */     catch (ClassNotFoundException classNotFoundException) {
/* 246 */       throw Context.reportRuntimeError(ToolErrorReporter.getMessage(
/* 247 */             "msg.class.not.found", 
/* 248 */             str));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object spawn(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/*     */     Runner runner;
/* 267 */     Scriptable scriptable = paramFunction.getParentScope();
/*     */     
/* 269 */     if (paramArrayOfObject.length != 0 && paramArrayOfObject[0] instanceof Function) {
/* 270 */       Object[] arrayOfObject = null;
/* 271 */       if (paramArrayOfObject.length > 1 && paramArrayOfObject[1] instanceof Scriptable) {
/* 272 */         arrayOfObject = paramContext.getElements((Scriptable)paramArrayOfObject[1]);
/*     */       }
/* 274 */       runner = new Runner(scriptable, (Function)paramArrayOfObject[0], arrayOfObject);
/* 275 */     } else if (paramArrayOfObject.length != 0 && paramArrayOfObject[0] instanceof Script) {
/* 276 */       runner = new Runner(scriptable, (Script)paramArrayOfObject[0]);
/*     */     } else {
/* 278 */       throw Context.reportRuntimeError(ToolErrorReporter.getMessage(
/* 279 */             "msg.spawn.args"));
/*     */     } 
/* 281 */     Thread thread = new Thread(runner);
/* 282 */     thread.start();
/* 283 */     return thread;
/*     */   }
/*     */   
/*     */   boolean debug = false;
/*     */   boolean processStdin = true;
/*     */   boolean quitting;
/* 289 */   int exitCode = 0;
/*     */   NativeArray history;
/*     */   boolean showDebuggerUI = false;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\tools\shell\Global.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */