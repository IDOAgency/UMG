package org.mozilla.javascript.tools.shell;

import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

public class Environment extends ScriptableObject {
  private Environment thePrototypeInstance = null;
  
  public static void defineClass(ScriptableObject paramScriptableObject) {
    try {
      ScriptableObject.defineClass(paramScriptableObject, Environment.class);
    } catch (Exception exception) {
      throw new Error(exception.getMessage());
    } 
  }
  
  public String getClassName() { return "Environment"; }
  
  public Environment() {
    if (this.thePrototypeInstance == null)
      this.thePrototypeInstance = this; 
  }
  
  public Environment(ScriptableObject paramScriptableObject) {
    setParentScope(paramScriptableObject);
    Object object = ScriptRuntime.getTopLevelProp(paramScriptableObject, "Environment");
    if (object != null && object instanceof Scriptable) {
      Scriptable scriptable = (Scriptable)object;
      setPrototype((Scriptable)scriptable.get("prototype", scriptable));
    } 
  }
  
  public boolean has(String paramString, Scriptable paramScriptable) {
    if (this == this.thePrototypeInstance)
      return super.has(paramString, paramScriptable); 
    return !(System.getProperty(paramString) == null);
  }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    if (this == this.thePrototypeInstance)
      return super.get(paramString, paramScriptable); 
    String str = System.getProperty(paramString);
    if (str != null)
      return ScriptRuntime.toObject(getParentScope(), str); 
    return Scriptable.NOT_FOUND;
  }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
    if (this == this.thePrototypeInstance) {
      super.put(paramString, paramScriptable, paramObject);
    } else {
      System.getProperties().put(paramString, ScriptRuntime.toString(paramObject));
    } 
  }
  
  private Object[] collectIds() {
    Properties properties = System.getProperties();
    Enumeration enumeration = properties.propertyNames();
    Vector vector = new Vector();
    while (enumeration.hasMoreElements())
      vector.addElement(enumeration.nextElement()); 
    Object[] arrayOfObject = new Object[vector.size()];
    vector.copyInto(arrayOfObject);
    return arrayOfObject;
  }
  
  public Object[] getIds() {
    if (this == this.thePrototypeInstance)
      return super.getIds(); 
    return collectIds();
  }
  
  public Object[] getAllIds() {
    if (this == this.thePrototypeInstance)
      return super.getAllIds(); 
    return collectIds();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\tools\shell\Environment.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */