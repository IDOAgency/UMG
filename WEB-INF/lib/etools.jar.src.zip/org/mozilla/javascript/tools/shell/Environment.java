/*     */ package org.mozilla.javascript.tools.shell;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Environment
/*     */   extends ScriptableObject
/*     */ {
/*  60 */   private Environment thePrototypeInstance = null;
/*     */   
/*     */   public static void defineClass(ScriptableObject paramScriptableObject) {
/*     */     try {
/*  64 */       ScriptableObject.defineClass(paramScriptableObject, Environment.class);
/*  65 */     } catch (Exception exception) {
/*  66 */       throw new Error(exception.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  71 */   public String getClassName() { return "Environment"; }
/*     */ 
/*     */   
/*     */   public Environment() {
/*  75 */     if (this.thePrototypeInstance == null)
/*  76 */       this.thePrototypeInstance = this; 
/*     */   }
/*     */   
/*     */   public Environment(ScriptableObject paramScriptableObject) {
/*  80 */     setParentScope(paramScriptableObject);
/*  81 */     Object object = ScriptRuntime.getTopLevelProp(paramScriptableObject, "Environment");
/*  82 */     if (object != null && object instanceof Scriptable) {
/*  83 */       Scriptable scriptable = (Scriptable)object;
/*  84 */       setPrototype((Scriptable)scriptable.get("prototype", scriptable));
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean has(String paramString, Scriptable paramScriptable) {
/*  89 */     if (this == this.thePrototypeInstance) {
/*  90 */       return super.has(paramString, paramScriptable);
/*     */     }
/*  92 */     return !(System.getProperty(paramString) == null);
/*     */   }
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/*  96 */     if (this == this.thePrototypeInstance) {
/*  97 */       return super.get(paramString, paramScriptable);
/*     */     }
/*  99 */     String str = System.getProperty(paramString);
/* 100 */     if (str != null) {
/* 101 */       return ScriptRuntime.toObject(getParentScope(), str);
/*     */     }
/* 103 */     return Scriptable.NOT_FOUND;
/*     */   }
/*     */   
/*     */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
/* 107 */     if (this == this.thePrototypeInstance) {
/* 108 */       super.put(paramString, paramScriptable, paramObject);
/*     */     } else {
/* 110 */       System.getProperties().put(paramString, ScriptRuntime.toString(paramObject));
/*     */     } 
/*     */   }
/*     */   private Object[] collectIds() {
/* 114 */     Properties properties = System.getProperties();
/* 115 */     Enumeration enumeration = properties.propertyNames();
/* 116 */     Vector vector = new Vector();
/* 117 */     while (enumeration.hasMoreElements())
/* 118 */       vector.addElement(enumeration.nextElement()); 
/* 119 */     Object[] arrayOfObject = new Object[vector.size()];
/* 120 */     vector.copyInto(arrayOfObject);
/* 121 */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   public Object[] getIds() {
/* 125 */     if (this == this.thePrototypeInstance)
/* 126 */       return super.getIds(); 
/* 127 */     return collectIds();
/*     */   }
/*     */   
/*     */   public Object[] getAllIds() {
/* 131 */     if (this == this.thePrototypeInstance)
/* 132 */       return super.getAllIds(); 
/* 133 */     return collectIds();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\tools\shell\Environment.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */