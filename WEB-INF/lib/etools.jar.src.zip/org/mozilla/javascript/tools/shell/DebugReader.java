/*     */ package org.mozilla.javascript.tools.shell;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.mozilla.javascript.SourceTextItem;
/*     */ import org.mozilla.javascript.SourceTextManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DebugReader
/*     */   extends BufferedReader
/*     */ {
/*     */   private BufferedReader reader;
/*     */   private SourceTextManager stm;
/*     */   private SourceTextItem sti;
/*     */   
/*     */   public DebugReader(Reader paramReader, SourceTextManager paramSourceTextManager, String paramString) {
/*  46 */     super(null);
/*  47 */     this.reader = new BufferedReader(paramReader);
/*  48 */     this.stm = paramSourceTextManager;
/*  49 */     this.sti = paramSourceTextManager.newItem(paramString);
/*     */   }
/*     */   
/*     */   public int read() throws IOException {
/*  53 */     int i = this.reader.read();
/*  54 */     if (this.sti != null)
/*  55 */       if (i == -1) {
/*  56 */         this.sti.complete();
/*  57 */         this.sti = null;
/*     */       } else {
/*     */         
/*  60 */         this.sti.append((char)i);
/*     */       }  
/*  62 */     return i;
/*     */   }
/*     */   
/*     */   public int read(char[] paramArrayOfChar) throws IOException {
/*  66 */     int i = this.reader.read(paramArrayOfChar);
/*  67 */     if (this.sti != null) {
/*  68 */       if (i == -1) {
/*  69 */         this.sti.complete();
/*  70 */         this.sti = null;
/*     */       }
/*  72 */       else if (i != 0) {
/*  73 */         this.sti.append(paramArrayOfChar, 0, i);
/*     */       } 
/*     */     }
/*  76 */     return i;
/*     */   }
/*     */   
/*     */   public int read(char[] paramArrayOfChar, int paramInt1, int paramInt2) throws IOException {
/*  80 */     int i = this.reader.read(paramArrayOfChar, paramInt1, paramInt2);
/*  81 */     if (this.sti != null) {
/*  82 */       if (i == -1) {
/*  83 */         this.sti.complete();
/*  84 */         this.sti = null;
/*     */       }
/*  86 */       else if (i != 0) {
/*  87 */         this.sti.append(paramArrayOfChar, paramInt1, i);
/*     */       } 
/*     */     }
/*  90 */     return i;
/*     */   }
/*     */   
/*     */   public String readLine() throws IOException {
/*  94 */     String str = this.reader.readLine();
/*  95 */     if (this.sti != null) {
/*  96 */       if (str == null) {
/*  97 */         this.sti.complete();
/*  98 */         this.sti = null;
/*     */       } else {
/*     */         
/* 101 */         this.sti.append(String.valueOf(str) + "\n");
/*     */       } 
/*     */     }
/* 104 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 109 */   public long skip(long paramLong) throws IOException { return this.reader.skip(paramLong); }
/*     */ 
/*     */ 
/*     */   
/* 113 */   public boolean ready() { return this.reader.ready(); }
/*     */ 
/*     */ 
/*     */   
/* 117 */   public boolean markSupported() { return this.reader.markSupported(); }
/*     */ 
/*     */ 
/*     */   
/* 121 */   public void mark(int paramInt) throws IOException { this.reader.mark(paramInt); }
/*     */ 
/*     */ 
/*     */   
/* 125 */   public void reset() throws IOException { this.reader.reset(); }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 129 */     this.reader.close();
/* 130 */     if (this.sti != null) {
/* 131 */       this.sti.complete();
/* 132 */       this.sti = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void finalize() throws IOException {
/* 137 */     if (this.sti != null) {
/* 138 */       this.sti.complete();
/* 139 */       this.sti = null;
/*     */     } 
/* 141 */     this.reader = null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\tools\shell\DebugReader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */