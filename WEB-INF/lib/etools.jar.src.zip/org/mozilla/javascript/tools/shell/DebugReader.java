package org.mozilla.javascript.tools.shell;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import org.mozilla.javascript.SourceTextItem;
import org.mozilla.javascript.SourceTextManager;

public class DebugReader extends BufferedReader {
  private BufferedReader reader;
  
  private SourceTextManager stm;
  
  private SourceTextItem sti;
  
  public DebugReader(Reader paramReader, SourceTextManager paramSourceTextManager, String paramString) {
    super(null);
    this.reader = new BufferedReader(paramReader);
    this.stm = paramSourceTextManager;
    this.sti = paramSourceTextManager.newItem(paramString);
  }
  
  public int read() throws IOException {
    int i = this.reader.read();
    if (this.sti != null)
      if (i == -1) {
        this.sti.complete();
        this.sti = null;
      } else {
        this.sti.append((char)i);
      }  
    return i;
  }
  
  public int read(char[] paramArrayOfChar) throws IOException {
    int i = this.reader.read(paramArrayOfChar);
    if (this.sti != null)
      if (i == -1) {
        this.sti.complete();
        this.sti = null;
      } else if (i != 0) {
        this.sti.append(paramArrayOfChar, 0, i);
      }  
    return i;
  }
  
  public int read(char[] paramArrayOfChar, int paramInt1, int paramInt2) throws IOException {
    int i = this.reader.read(paramArrayOfChar, paramInt1, paramInt2);
    if (this.sti != null)
      if (i == -1) {
        this.sti.complete();
        this.sti = null;
      } else if (i != 0) {
        this.sti.append(paramArrayOfChar, paramInt1, i);
      }  
    return i;
  }
  
  public String readLine() throws IOException {
    String str = this.reader.readLine();
    if (this.sti != null)
      if (str == null) {
        this.sti.complete();
        this.sti = null;
      } else {
        this.sti.append(String.valueOf(str) + "\n");
      }  
    return str;
  }
  
  public long skip(long paramLong) throws IOException { return this.reader.skip(paramLong); }
  
  public boolean ready() { return this.reader.ready(); }
  
  public boolean markSupported() { return this.reader.markSupported(); }
  
  public void mark(int paramInt) throws IOException { this.reader.mark(paramInt); }
  
  public void reset() throws IOException { this.reader.reset(); }
  
  public void close() throws IOException {
    this.reader.close();
    if (this.sti != null) {
      this.sti.complete();
      this.sti = null;
    } 
  }
  
  protected void finalize() throws IOException {
    if (this.sti != null) {
      this.sti.complete();
      this.sti = null;
    } 
    this.reader = null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\tools\shell\DebugReader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */