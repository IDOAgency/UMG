package org.mozilla.javascript.tools.shell;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.tools.ToolErrorReporter;

class Runner implements Runnable {
  private Scriptable scope;
  
  private Function f;
  
  private Script s;
  
  private Object[] args;
  
  Runner(Scriptable paramScriptable, Function paramFunction, Object[] paramArrayOfObject) {
    this.scope = paramScriptable;
    this.f = paramFunction;
    this.args = paramArrayOfObject;
  }
  
  Runner(Scriptable paramScriptable, Script paramScript) {
    this.scope = paramScriptable;
    this.s = paramScript;
  }
  
  public void run() {
    Context context = Context.enter();
    try {
      if (this.f != null) {
        this.f.call(context, this.scope, this.scope, this.args);
      } else {
        this.s.exec(context, this.scope);
      } 
    } catch (JavaScriptException javaScriptException) {
      Context.reportError(ToolErrorReporter.getMessage(
            "msg.uncaughtJSException", 
            javaScriptException.getMessage()));
    } 
    Context.exit();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\tools\shell\Runner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */