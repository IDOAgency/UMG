/*     */ package org.mozilla.javascript.tools.shell;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PushbackReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.EcmaError;
/*     */ import org.mozilla.javascript.EvaluatorException;
/*     */ import org.mozilla.javascript.JavaScriptException;
/*     */ import org.mozilla.javascript.NativeArray;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.SourceTextManager;
/*     */ import org.mozilla.javascript.WrappedException;
/*     */ import org.mozilla.javascript.tools.ToolErrorReporter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Main
/*     */ {
/*     */   protected static ToolErrorReporter errorReporter;
/*     */   protected static Global global;
/*     */   public static InputStream inStream;
/*     */   public static PrintStream outStream;
/*     */   public static PrintStream errStream;
/*     */   private static final int EXITCODE_RUNTIME_ERROR = 3;
/*     */   private static final int EXITCODE_FILE_NOT_FOUND = 4;
/*     */   SourceTextManager debug_stm;
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/*  74 */     int i = exec(paramArrayOfString);
/*  75 */     System.exit(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int exec(String[] paramArrayOfString) {
/*  82 */     Context context = Context.enter();
/*     */     
/*  84 */     errorReporter = new ToolErrorReporter(false, getErr());
/*  85 */     context.setErrorReporter(errorReporter);
/*     */ 
/*     */     
/*  88 */     global = new Global();
/*     */     
/*  90 */     paramArrayOfString = processOptions(context, paramArrayOfString);
/*     */ 
/*     */ 
/*     */     
/*  94 */     Object[] arrayOfObject = paramArrayOfString;
/*  95 */     if (paramArrayOfString.length > 0) {
/*  96 */       int i = paramArrayOfString.length - 1;
/*  97 */       arrayOfObject = new Object[i];
/*  98 */       System.arraycopy(paramArrayOfString, 1, arrayOfObject, 0, i);
/*     */     } 
/* 100 */     Scriptable scriptable = context.newArray(global, arrayOfObject);
/* 101 */     global.defineProperty("arguments", scriptable, 
/* 102 */         2);
/*     */ 
/*     */ 
/*     */     
/* 106 */     Environment.defineClass(global);
/* 107 */     Environment environment = new Environment(global);
/* 108 */     global.defineProperty("environment", environment, 
/* 109 */         2);
/*     */     
/* 111 */     global.history = (NativeArray)context.newArray(global, 0);
/* 112 */     global.defineProperty("history", global.history, 
/* 113 */         2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     if (global.processStdin) {
/* 146 */       processSource(context, (paramArrayOfString.length == 0) ? null : paramArrayOfString[0]);
/*     */     }
/* 148 */     Context.exit();
/* 149 */     return global.exitCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] processOptions(Context paramContext, String[] paramArrayOfString) {
/* 156 */     paramContext.setTargetPackage("");
/* 157 */     for (int i = 0; i < paramArrayOfString.length; i++) {
/* 158 */       String str = paramArrayOfString[i];
/* 159 */       if (!str.startsWith("-")) {
/* 160 */         String[] arrayOfString = new String[paramArrayOfString.length - i];
/* 161 */         for (int j = i; j < paramArrayOfString.length; j++)
/* 162 */           arrayOfString[j - i] = paramArrayOfString[j]; 
/* 163 */         return arrayOfString;
/*     */       } 
/* 165 */       if (str.equals("-version")) {
/* 166 */         if (++i == paramArrayOfString.length)
/* 167 */           usage(str); 
/* 168 */         double d = Context.toNumber(paramArrayOfString[i]);
/* 169 */         if (d != d)
/* 170 */           usage(str); 
/* 171 */         paramContext.setLanguageVersion((int)d);
/*     */       
/*     */       }
/* 174 */       else if (str.equals("-opt") || str.equals("-O")) {
/* 175 */         if (++i == paramArrayOfString.length)
/* 176 */           usage(str); 
/* 177 */         double d = Context.toNumber(paramArrayOfString[i]);
/* 178 */         if (d != d)
/* 179 */           usage(str); 
/* 180 */         paramContext.setOptimizationLevel((int)d);
/*     */       
/*     */       }
/* 183 */       else if (str.equals("-e")) {
/* 184 */         global.processStdin = false;
/* 185 */         if (++i == paramArrayOfString.length)
/* 186 */           usage(str); 
/* 187 */         StringReader stringReader = new StringReader(paramArrayOfString[i]);
/* 188 */         evaluateReader(paramContext, global, stringReader, "<command>", 1);
/*     */       
/*     */       }
/* 191 */       else if (str.equals("-w")) {
/* 192 */         errorReporter.setIsReportingWarnings(true);
/*     */       
/*     */       }
/* 195 */       else if (str.equals("-f")) {
/* 196 */         global.processStdin = false;
/* 197 */         if (++i == paramArrayOfString.length)
/* 198 */           usage(str); 
/* 199 */         if (paramArrayOfString[i].equals("-"))
/* 200 */           global.processStdin = false; 
/* 201 */         processSource(paramContext, paramArrayOfString[i]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 225 */         usage(str);
/*     */       } 
/* 227 */     }  return new String[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void usage(String paramString) {
/* 234 */     p(ToolErrorReporter.getMessage("msg.shell.usage", paramString));
/* 235 */     System.exit(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void processSource(Context paramContext, String paramString) {
/* 246 */     SourceTextManager sourceTextManager = paramContext.getSourceTextManager();
/* 247 */     if (paramString == null || paramString.equals("-")) {
/*     */       
/* 249 */       paramContext.setOptimizationLevel(-1);
/*     */       
/* 251 */       BufferedReader bufferedReader = new BufferedReader(
/* 252 */           new InputStreamReader(getIn()));
/* 253 */       if (sourceTextManager != null)
/* 254 */         bufferedReader = new DebugReader(bufferedReader, sourceTextManager, "<stdin>"); 
/* 255 */       byte b = 1;
/* 256 */       boolean bool = false;
/* 257 */       while (!bool && !global.quitting) {
/* 258 */         byte b1 = b;
/* 259 */         if (paramString == null)
/* 260 */           getErr().print("js> "); 
/* 261 */         getErr().flush();
/* 262 */         String str = "";
/*     */         
/*     */         do {
/*     */           String str1;
/*     */           
/*     */           try {
/* 268 */             str1 = bufferedReader.readLine();
/*     */           }
/* 270 */           catch (IOException iOException) {
/* 271 */             getErr().println(iOException.toString());
/*     */             break;
/*     */           } 
/* 274 */           if (str1 == null) {
/* 275 */             bool = true;
/*     */             break;
/*     */           } 
/* 278 */           str = String.valueOf(str) + str1 + "\n";
/* 279 */           b++;
/* 280 */         } while (!paramContext.stringIsCompilableUnit(str));
/*     */ 
/*     */         
/* 283 */         StringReader stringReader = new StringReader(str);
/* 284 */         Object object = evaluateReader(paramContext, global, stringReader, 
/* 285 */             "<stdin>", b1);
/* 286 */         if (object != Context.getUndefinedValue()) {
/* 287 */           getErr().println(Context.toString(object));
/*     */         }
/* 289 */         NativeArray nativeArray = global.history;
/* 290 */         nativeArray.put((int)nativeArray.jsGet_length(), nativeArray, str);
/* 291 */         if (global.quitting) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */       
/* 296 */       getErr().println();
/*     */     } else {
/* 298 */       DebugReader debugReader = null; try {
/*     */         FileReader fileReader;
/* 300 */         debugReader = new PushbackReader(new FileReader(paramString));
/* 301 */         int i = debugReader.read();
/*     */ 
/*     */ 
/*     */         
/* 305 */         if (i == 35) { do {  }
/* 306 */           while ((i = debugReader.read()) != -1 && 
/* 307 */             i != 10 && i != 13);
/*     */ 
/*     */           
/* 310 */           ((PushbackReader)debugReader).unread(i);
/*     */           
/*     */            }
/*     */         
/*     */         else
/*     */         
/*     */         { 
/* 317 */           debugReader.close();
/* 318 */           fileReader = new FileReader(paramString); }
/*     */         
/* 320 */         if (sourceTextManager != null) {
/* 321 */           debugReader = new DebugReader(fileReader, sourceTextManager, paramString);
/*     */         }
/* 323 */       } catch (FileNotFoundException fileNotFoundException) {
/* 324 */         Context.reportError(ToolErrorReporter.getMessage(
/* 325 */               "msg.couldnt.open", 
/* 326 */               paramString));
/* 327 */         global.exitCode = 4;
/*     */         return;
/* 329 */       } catch (IOException iOException) {
/* 330 */         getErr().println(iOException.toString());
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 336 */       evaluateReader(paramContext, global, debugReader, paramString, 1);
/*     */     } 
/* 338 */     System.gc();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object evaluateReader(Context paramContext, Scriptable paramScriptable, Reader paramReader, String paramString, int paramInt) {
/* 345 */     Object object = Context.getUndefinedValue();
/*     */     try {
/* 347 */       object = paramContext.evaluateReader(paramScriptable, paramReader, paramString, paramInt, null);
/*     */     }
/* 349 */     catch (WrappedException wrappedException) {
/* 350 */       getErr().println(wrappedException.getWrappedException().toString());
/* 351 */       wrappedException.printStackTrace();
/*     */     }
/* 353 */     catch (EcmaError ecmaError) {
/* 354 */       String str = ToolErrorReporter.getMessage(
/* 355 */           "msg.uncaughtJSException", ecmaError.toString());
/* 356 */       global.exitCode = 3;
/* 357 */       if (ecmaError.getSourceName() != null) {
/* 358 */         Context.reportError(str, ecmaError.getSourceName(), 
/* 359 */             ecmaError.getLineNumber(), 
/* 360 */             ecmaError.getLineSource(), 
/* 361 */             ecmaError.getColumnNumber());
/*     */       } else {
/* 363 */         Context.reportError(str);
/*     */       }
/*     */     
/* 366 */     } catch (EvaluatorException evaluatorException) {
/*     */       
/* 368 */       global.exitCode = 3;
/*     */     }
/* 370 */     catch (JavaScriptException javaScriptException) {
/*     */       
/* 372 */       Object object1 = javaScriptException.getValue();
/* 373 */       if (object1 instanceof ThreadDeath)
/* 374 */         throw (ThreadDeath)object1; 
/* 375 */       global.exitCode = 3;
/* 376 */       Context.reportError(ToolErrorReporter.getMessage(
/* 377 */             "msg.uncaughtJSException", 
/* 378 */             javaScriptException.getMessage()));
/*     */     }
/* 380 */     catch (IOException iOException) {
/* 381 */       getErr().println(iOException.toString());
/*     */     } finally {
/*     */       
/*     */       try {
/* 385 */         paramReader.close();
/*     */       }
/* 387 */       catch (IOException iOException) {
/* 388 */         getErr().println(iOException.toString());
/*     */       } 
/*     */     } 
/* 391 */     return object;
/*     */   }
/*     */ 
/*     */   
/* 395 */   private static void p(String paramString) { getOut().println(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 399 */   public static InputStream getIn() { return (inStream == null) ? System.in : inStream; }
/*     */ 
/*     */ 
/*     */   
/* 403 */   public static void setIn(InputStream paramInputStream) { inStream = paramInputStream; }
/*     */ 
/*     */ 
/*     */   
/* 407 */   public static PrintStream getOut() { return (outStream == null) ? System.out : outStream; }
/*     */ 
/*     */ 
/*     */   
/* 411 */   public static void setOut(PrintStream paramPrintStream) { outStream = paramPrintStream; }
/*     */ 
/*     */ 
/*     */   
/* 415 */   public static PrintStream getErr() { return (errStream == null) ? System.err : errStream; }
/*     */ 
/*     */ 
/*     */   
/* 419 */   public static void setErr(PrintStream paramPrintStream) { errStream = paramPrintStream; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\tools\shell\Main.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */