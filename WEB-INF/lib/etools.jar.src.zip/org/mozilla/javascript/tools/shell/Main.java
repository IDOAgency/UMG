package org.mozilla.javascript.tools.shell;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PushbackReader;
import java.io.Reader;
import java.io.StringReader;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.EcmaError;
import org.mozilla.javascript.EvaluatorException;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.SourceTextManager;
import org.mozilla.javascript.WrappedException;
import org.mozilla.javascript.tools.ToolErrorReporter;

public class Main {
  protected static ToolErrorReporter errorReporter;
  
  protected static Global global;
  
  public static InputStream inStream;
  
  public static PrintStream outStream;
  
  public static PrintStream errStream;
  
  private static final int EXITCODE_RUNTIME_ERROR = 3;
  
  private static final int EXITCODE_FILE_NOT_FOUND = 4;
  
  SourceTextManager debug_stm;
  
  public static void main(String[] paramArrayOfString) {
    int i = exec(paramArrayOfString);
    System.exit(i);
  }
  
  public static int exec(String[] paramArrayOfString) {
    Context context = Context.enter();
    errorReporter = new ToolErrorReporter(false, getErr());
    context.setErrorReporter(errorReporter);
    global = new Global();
    paramArrayOfString = processOptions(context, paramArrayOfString);
    Object[] arrayOfObject = paramArrayOfString;
    if (paramArrayOfString.length > 0) {
      int i = paramArrayOfString.length - 1;
      arrayOfObject = new Object[i];
      System.arraycopy(paramArrayOfString, 1, arrayOfObject, 0, i);
    } 
    Scriptable scriptable = context.newArray(global, arrayOfObject);
    global.defineProperty("arguments", scriptable, 
        2);
    Environment.defineClass(global);
    Environment environment = new Environment(global);
    global.defineProperty("environment", environment, 
        2);
    global.history = (NativeArray)context.newArray(global, 0);
    global.defineProperty("history", global.history, 
        2);
    if (global.processStdin)
      processSource(context, (paramArrayOfString.length == 0) ? null : paramArrayOfString[0]); 
    Context.exit();
    return global.exitCode;
  }
  
  public static String[] processOptions(Context paramContext, String[] paramArrayOfString) {
    paramContext.setTargetPackage("");
    for (int i = 0; i < paramArrayOfString.length; i++) {
      String str = paramArrayOfString[i];
      if (!str.startsWith("-")) {
        String[] arrayOfString = new String[paramArrayOfString.length - i];
        for (int j = i; j < paramArrayOfString.length; j++)
          arrayOfString[j - i] = paramArrayOfString[j]; 
        return arrayOfString;
      } 
      if (str.equals("-version")) {
        if (++i == paramArrayOfString.length)
          usage(str); 
        double d = Context.toNumber(paramArrayOfString[i]);
        if (d != d)
          usage(str); 
        paramContext.setLanguageVersion((int)d);
      } else if (str.equals("-opt") || str.equals("-O")) {
        if (++i == paramArrayOfString.length)
          usage(str); 
        double d = Context.toNumber(paramArrayOfString[i]);
        if (d != d)
          usage(str); 
        paramContext.setOptimizationLevel((int)d);
      } else if (str.equals("-e")) {
        global.processStdin = false;
        if (++i == paramArrayOfString.length)
          usage(str); 
        StringReader stringReader = new StringReader(paramArrayOfString[i]);
        evaluateReader(paramContext, global, stringReader, "<command>", 1);
      } else if (str.equals("-w")) {
        errorReporter.setIsReportingWarnings(true);
      } else if (str.equals("-f")) {
        global.processStdin = false;
        if (++i == paramArrayOfString.length)
          usage(str); 
        if (paramArrayOfString[i].equals("-"))
          global.processStdin = false; 
        processSource(paramContext, paramArrayOfString[i]);
      } else {
        usage(str);
      } 
    } 
    return new String[0];
  }
  
  public static void usage(String paramString) {
    p(ToolErrorReporter.getMessage("msg.shell.usage", paramString));
    System.exit(1);
  }
  
  public static void processSource(Context paramContext, String paramString) {
    SourceTextManager sourceTextManager = paramContext.getSourceTextManager();
    if (paramString == null || paramString.equals("-")) {
      paramContext.setOptimizationLevel(-1);
      BufferedReader bufferedReader = new BufferedReader(
          new InputStreamReader(getIn()));
      if (sourceTextManager != null)
        bufferedReader = new DebugReader(bufferedReader, sourceTextManager, "<stdin>"); 
      byte b = 1;
      boolean bool = false;
      while (!bool && !global.quitting) {
        byte b1 = b;
        if (paramString == null)
          getErr().print("js> "); 
        getErr().flush();
        String str = "";
        do {
          String str1;
          try {
            str1 = bufferedReader.readLine();
          } catch (IOException iOException) {
            getErr().println(iOException.toString());
            break;
          } 
          if (str1 == null) {
            bool = true;
            break;
          } 
          str = String.valueOf(str) + str1 + "\n";
          b++;
        } while (!paramContext.stringIsCompilableUnit(str));
        StringReader stringReader = new StringReader(str);
        Object object = evaluateReader(paramContext, global, stringReader, 
            "<stdin>", b1);
        if (object != Context.getUndefinedValue())
          getErr().println(Context.toString(object)); 
        NativeArray nativeArray = global.history;
        nativeArray.put((int)nativeArray.jsGet_length(), nativeArray, str);
        if (global.quitting)
          break; 
      } 
      getErr().println();
    } else {
      DebugReader debugReader = null;
      try {
        FileReader fileReader;
        debugReader = new PushbackReader(new FileReader(paramString));
        int i = debugReader.read();
        if (i == 35) {
          do {
          
          } while ((i = debugReader.read()) != -1 && 
            i != 10 && i != 13);
          ((PushbackReader)debugReader).unread(i);
        } else {
          debugReader.close();
          fileReader = new FileReader(paramString);
        } 
        if (sourceTextManager != null)
          debugReader = new DebugReader(fileReader, sourceTextManager, paramString); 
      } catch (FileNotFoundException fileNotFoundException) {
        Context.reportError(ToolErrorReporter.getMessage(
              "msg.couldnt.open", 
              paramString));
        global.exitCode = 4;
        return;
      } catch (IOException iOException) {
        getErr().println(iOException.toString());
      } 
      evaluateReader(paramContext, global, debugReader, paramString, 1);
    } 
    System.gc();
  }
  
  private static Object evaluateReader(Context paramContext, Scriptable paramScriptable, Reader paramReader, String paramString, int paramInt) {
    Object object = Context.getUndefinedValue();
    try {
      object = paramContext.evaluateReader(paramScriptable, paramReader, paramString, paramInt, null);
    } catch (WrappedException wrappedException) {
      getErr().println(wrappedException.getWrappedException().toString());
      wrappedException.printStackTrace();
    } catch (EcmaError ecmaError) {
      String str = ToolErrorReporter.getMessage(
          "msg.uncaughtJSException", ecmaError.toString());
      global.exitCode = 3;
      if (ecmaError.getSourceName() != null) {
        Context.reportError(str, ecmaError.getSourceName(), 
            ecmaError.getLineNumber(), 
            ecmaError.getLineSource(), 
            ecmaError.getColumnNumber());
      } else {
        Context.reportError(str);
      } 
    } catch (EvaluatorException evaluatorException) {
      global.exitCode = 3;
    } catch (JavaScriptException javaScriptException) {
      Object object1 = javaScriptException.getValue();
      if (object1 instanceof ThreadDeath)
        throw (ThreadDeath)object1; 
      global.exitCode = 3;
      Context.reportError(ToolErrorReporter.getMessage(
            "msg.uncaughtJSException", 
            javaScriptException.getMessage()));
    } catch (IOException iOException) {
      getErr().println(iOException.toString());
    } finally {
      try {
        paramReader.close();
      } catch (IOException iOException) {
        getErr().println(iOException.toString());
      } 
    } 
    return object;
  }
  
  private static void p(String paramString) { getOut().println(paramString); }
  
  public static InputStream getIn() { return (inStream == null) ? System.in : inStream; }
  
  public static void setIn(InputStream paramInputStream) { inStream = paramInputStream; }
  
  public static PrintStream getOut() { return (outStream == null) ? System.out : outStream; }
  
  public static void setOut(PrintStream paramPrintStream) { outStream = paramPrintStream; }
  
  public static PrintStream getErr() { return (errStream == null) ? System.err : errStream; }
  
  public static void setErr(PrintStream paramPrintStream) { errStream = paramPrintStream; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\tools\shell\Main.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */