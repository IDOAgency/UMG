/*     */ package org.mozilla.javascript.tools.jsc;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.tools.ToolErrorReporter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Main
/*     */ {
/*     */   public static void main(String[] paramArrayOfString) {
/*  60 */     Context context = Context.enter();
/*     */     
/*  62 */     reporter = new ToolErrorReporter(true);
/*     */     
/*  64 */     context.setErrorReporter(reporter);
/*     */     
/*  66 */     paramArrayOfString = processOptions(context, paramArrayOfString);
/*     */     
/*  68 */     if (!reporter.hasReportedError()) {
/*  69 */       processSource(context, paramArrayOfString);
/*     */     }
/*  71 */     Context.exit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] processOptions(Context paramContext, String[] paramArrayOfString) {
/*  79 */     paramContext.setTargetPackage("");
/*  80 */     paramContext.setGeneratingDebug(false);
/*  81 */     for (int i = 0; i < paramArrayOfString.length; i++) {
/*  82 */       String str = paramArrayOfString[i];
/*  83 */       if (!str.startsWith("-")) {
/*  84 */         String[] arrayOfString = new String[paramArrayOfString.length - i];
/*  85 */         for (int j = i; j < paramArrayOfString.length; j++)
/*  86 */           arrayOfString[j - i] = paramArrayOfString[j]; 
/*  87 */         return arrayOfString;
/*     */       } 
/*     */       
/*  90 */       try { if (str.equals("-version") && ++i < paramArrayOfString.length)
/*  91 */         { int j = Integer.parseInt(paramArrayOfString[i]);
/*  92 */           paramContext.setLanguageVersion(j);
/*     */            }
/*     */         
/*  95 */         else if ((str.equals("-opt") || str.equals("-O")) && 
/*  96 */           ++i < paramArrayOfString.length)
/*     */         
/*  98 */         { int j = Integer.parseInt(paramArrayOfString[i]);
/*  99 */           paramContext.setOptimizationLevel(j);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */            }
/*     */         
/* 113 */         else if (str.equals("-nosource"))
/* 114 */         { paramContext.setGeneratingSource(false);
/*     */            }
/*     */         
/* 117 */         else if (str.equals("-debug") || str.equals("-g"))
/* 118 */         { paramContext.setGeneratingDebug(true);
/*     */            }
/*     */         
/* 121 */         else if (str.equals("-o") && ++i < paramArrayOfString.length)
/* 122 */         { String str1 = paramArrayOfString[i];
/* 123 */           if (!Character.isJavaIdentifierStart(str1.charAt(0))) {
/* 124 */             Context.reportError(ToolErrorReporter.getMessage(
/* 125 */                   "msg.invalid.classfile.name", 
/* 126 */                   str1));
/*     */           } else {
/*     */             
/* 129 */             for (byte b = 1; b < str1.length(); b++) {
/* 130 */               if ((!Character.isJavaIdentifierPart(str1.charAt(b)) && 
/* 131 */                 str1.charAt(b) != '.') || (str1.charAt(b) == '.' && (
/* 132 */                 !str1.endsWith(".class") || b != str1.length() - 6))) {
/*     */                 
/* 134 */                 Context.reportError(ToolErrorReporter.getMessage(
/* 135 */                       "msg.invalid.classfile.name", 
/* 136 */                       str1));
/*     */                 break;
/*     */               } 
/*     */             } 
/* 140 */             paramContext.setTargetClassFileName(str1);
/* 141 */             hasOutOption = true;
/*     */           }
/*     */            }
/* 144 */         else if (str.equals("-package") && ++i < paramArrayOfString.length)
/* 145 */         { String str1 = paramArrayOfString[i];
/* 146 */           for (byte b = 0; b < str1.length(); b++) {
/* 147 */             if (!Character.isJavaIdentifierStart(str1.charAt(b))) {
/* 148 */               Context.reportError(ToolErrorReporter.getMessage(
/* 149 */                     "msg.package.name", 
/* 150 */                     str1));
/*     */             } else {
/*     */               
/* 153 */               for (byte b1 = ++b; b1 < str1.length(); b1++, b++) {
/* 154 */                 if (str1.charAt(b1) != '.' || 
/* 155 */                   str1.charAt(b1 - 1) == '.' || 
/* 156 */                   b1 == str1.length() - 1)
/*     */                 {
/*     */ 
/*     */                   
/* 160 */                   if (!Character.isJavaIdentifierPart(
/* 161 */                       str1.charAt(b1)))
/*     */                   {
/* 163 */                     Context.reportError(ToolErrorReporter.getMessage(
/* 164 */                           "msg.package.name", 
/* 165 */                           str1));
/*     */                   }
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/* 171 */           paramContext.setTargetPackage(str1);
/*     */            }
/*     */         
/* 174 */         else if (str.equals("-extends") && ++i < paramArrayOfString.length)
/* 175 */         { String str1 = paramArrayOfString[i];
/*     */           try {
/* 177 */             paramContext.setTargetExtends(Class.forName(str1));
/* 178 */           } catch (ClassNotFoundException classNotFoundException) {
/* 179 */             throw new Error(classNotFoundException.toString());
/*     */           }
/*     */            }
/*     */         
/* 183 */         else if (str.equals("-implements") && ++i < paramArrayOfString.length)
/*     */         
/* 185 */         { String str1 = paramArrayOfString[i];
/*     */           try {
/* 187 */             Class[] arrayOfClass = { Class.forName(str1) };
/* 188 */             paramContext.setTargetImplements(arrayOfClass);
/* 189 */           } catch (ClassNotFoundException classNotFoundException) {
/* 190 */             throw new Error(classNotFoundException.toString());
/*     */           }  }
/*     */         else
/*     */         
/* 194 */         { usage(str); }  }
/*     */       catch (NumberFormatException numberFormatException) { Context.reportError(ToolErrorReporter.getMessage("msg.jsc.usage", paramArrayOfString[i])); }
/*     */     
/* 197 */     }  p(ToolErrorReporter.getMessage("msg.no.file"));
/* 198 */     System.exit(1);
/* 199 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void usage(String paramString) {
/* 205 */     p(ToolErrorReporter.getMessage("msg.jsc.usage", paramString));
/* 206 */     System.exit(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void processSource(Context paramContext, String[] paramArrayOfString) {
/* 214 */     if (hasOutOption && paramArrayOfString.length > 1) {
/* 215 */       Context.reportError(ToolErrorReporter.getMessage(
/* 216 */             "msg.multiple.js.to.file", 
/* 217 */             paramContext.getTargetClassFileName()));
/*     */     }
/* 219 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 220 */       String str = paramArrayOfString[b];
/* 221 */       File file = new File(str);
/*     */       
/* 223 */       if (!file.exists()) {
/* 224 */         Context.reportError(ToolErrorReporter.getMessage(
/* 225 */               "msg.jsfile.not.found", 
/* 226 */               str));
/*     */         return;
/*     */       } 
/* 229 */       if (!str.endsWith(".js")) {
/* 230 */         Context.reportError(ToolErrorReporter.getMessage(
/* 231 */               "msg.extension.not.js", 
/* 232 */               str));
/*     */         return;
/*     */       } 
/* 235 */       if (!hasOutOption) {
/* 236 */         String str1 = file.getName();
/* 237 */         String str2 = str1.substring(0, str1.length() - 3);
/* 238 */         String str3 = String.valueOf(getClassName(str2)) + ".class";
/* 239 */         String str4 = (file.getParent() == null) ? str3 : (String.valueOf(file.getParent()) + 
/* 240 */           File.separator + str3);
/* 241 */         paramContext.setTargetClassFileName(str4);
/*     */       } 
/* 243 */       if (paramContext.getTargetClassFileName() == null) {
/* 244 */         Context.reportError(ToolErrorReporter.getMessage("msg.no-opt"));
/*     */       }
/*     */       try {
/* 247 */         FileReader fileReader = new FileReader(str);
/* 248 */         paramContext.compileReader(null, fileReader, str, 1, null);
/*     */       }
/* 250 */       catch (FileNotFoundException fileNotFoundException) {
/* 251 */         Context.reportError(ToolErrorReporter.getMessage(
/* 252 */               "msg.couldnt.open", 
/* 253 */               str));
/*     */         
/*     */         return;
/* 256 */       } catch (IOException iOException) {
/* 257 */         Context.reportError(iOException.toString());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getClassName(String paramString) {
/* 269 */     char[] arrayOfChar = new char[paramString.length() + 1];
/*     */     
/* 271 */     byte b1 = 0;
/*     */     
/* 273 */     if (!Character.isJavaIdentifierStart(paramString.charAt(0))) {
/* 274 */       arrayOfChar[b1++] = '_';
/*     */     }
/* 276 */     for (byte b2 = 0; b2 < paramString.length(); b2++, b1++) {
/* 277 */       char c = paramString.charAt(b2);
/* 278 */       if (Character.isJavaIdentifierPart(c)) {
/* 279 */         arrayOfChar[b1] = c;
/*     */       } else {
/* 281 */         arrayOfChar[b1] = '_';
/*     */       } 
/*     */     } 
/* 284 */     return (new String(arrayOfChar)).trim();
/*     */   }
/*     */ 
/*     */   
/* 288 */   private static void p(String paramString) { System.out.println(paramString); }
/*     */   
/*     */   private static boolean hasOutOption = false;
/*     */   private static ToolErrorReporter reporter;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\tools\jsc\Main.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */