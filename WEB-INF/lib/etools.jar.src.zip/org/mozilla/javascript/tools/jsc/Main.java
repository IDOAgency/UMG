package org.mozilla.javascript.tools.jsc;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.tools.ToolErrorReporter;

public class Main {
  public static void main(String[] paramArrayOfString) {
    Context context = Context.enter();
    reporter = new ToolErrorReporter(true);
    context.setErrorReporter(reporter);
    paramArrayOfString = processOptions(context, paramArrayOfString);
    if (!reporter.hasReportedError())
      processSource(context, paramArrayOfString); 
    Context.exit();
  }
  
  public static String[] processOptions(Context paramContext, String[] paramArrayOfString) {
    paramContext.setTargetPackage("");
    paramContext.setGeneratingDebug(false);
    for (int i = 0; i < paramArrayOfString.length; i++) {
      String str = paramArrayOfString[i];
      if (!str.startsWith("-")) {
        String[] arrayOfString = new String[paramArrayOfString.length - i];
        for (int j = i; j < paramArrayOfString.length; j++)
          arrayOfString[j - i] = paramArrayOfString[j]; 
        return arrayOfString;
      } 
      try {
        if (str.equals("-version") && ++i < paramArrayOfString.length) {
          int j = Integer.parseInt(paramArrayOfString[i]);
          paramContext.setLanguageVersion(j);
        } else if ((str.equals("-opt") || str.equals("-O")) && 
          ++i < paramArrayOfString.length) {
          int j = Integer.parseInt(paramArrayOfString[i]);
          paramContext.setOptimizationLevel(j);
        } else if (str.equals("-nosource")) {
          paramContext.setGeneratingSource(false);
        } else if (str.equals("-debug") || str.equals("-g")) {
          paramContext.setGeneratingDebug(true);
        } else if (str.equals("-o") && ++i < paramArrayOfString.length) {
          String str1 = paramArrayOfString[i];
          if (!Character.isJavaIdentifierStart(str1.charAt(0))) {
            Context.reportError(ToolErrorReporter.getMessage(
                  "msg.invalid.classfile.name", 
                  str1));
          } else {
            for (byte b = 1; b < str1.length(); b++) {
              if ((!Character.isJavaIdentifierPart(str1.charAt(b)) && 
                str1.charAt(b) != '.') || (str1.charAt(b) == '.' && (
                !str1.endsWith(".class") || b != str1.length() - 6))) {
                Context.reportError(ToolErrorReporter.getMessage(
                      "msg.invalid.classfile.name", 
                      str1));
                break;
              } 
            } 
            paramContext.setTargetClassFileName(str1);
            hasOutOption = true;
          } 
        } else if (str.equals("-package") && ++i < paramArrayOfString.length) {
          String str1 = paramArrayOfString[i];
          for (byte b = 0; b < str1.length(); b++) {
            if (!Character.isJavaIdentifierStart(str1.charAt(b))) {
              Context.reportError(ToolErrorReporter.getMessage(
                    "msg.package.name", 
                    str1));
            } else {
              for (byte b1 = ++b; b1 < str1.length(); b1++, b++) {
                if (str1.charAt(b1) != '.' || 
                  str1.charAt(b1 - 1) == '.' || 
                  b1 == str1.length() - 1)
                  if (!Character.isJavaIdentifierPart(
                      str1.charAt(b1)))
                    Context.reportError(ToolErrorReporter.getMessage(
                          "msg.package.name", 
                          str1));  
              } 
            } 
          } 
          paramContext.setTargetPackage(str1);
        } else if (str.equals("-extends") && ++i < paramArrayOfString.length) {
          String str1 = paramArrayOfString[i];
          try {
            paramContext.setTargetExtends(Class.forName(str1));
          } catch (ClassNotFoundException classNotFoundException) {
            throw new Error(classNotFoundException.toString());
          } 
        } else if (str.equals("-implements") && ++i < paramArrayOfString.length) {
          String str1 = paramArrayOfString[i];
          try {
            Class[] arrayOfClass = { Class.forName(str1) };
            paramContext.setTargetImplements(arrayOfClass);
          } catch (ClassNotFoundException classNotFoundException) {
            throw new Error(classNotFoundException.toString());
          } 
        } else {
          usage(str);
        } 
      } catch (NumberFormatException numberFormatException) {
        Context.reportError(ToolErrorReporter.getMessage("msg.jsc.usage", paramArrayOfString[i]));
      } 
    } 
    p(ToolErrorReporter.getMessage("msg.no.file"));
    System.exit(1);
    return null;
  }
  
  public static void usage(String paramString) {
    p(ToolErrorReporter.getMessage("msg.jsc.usage", paramString));
    System.exit(1);
  }
  
  public static void processSource(Context paramContext, String[] paramArrayOfString) {
    if (hasOutOption && paramArrayOfString.length > 1)
      Context.reportError(ToolErrorReporter.getMessage(
            "msg.multiple.js.to.file", 
            paramContext.getTargetClassFileName())); 
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      String str = paramArrayOfString[b];
      File file = new File(str);
      if (!file.exists()) {
        Context.reportError(ToolErrorReporter.getMessage(
              "msg.jsfile.not.found", 
              str));
        return;
      } 
      if (!str.endsWith(".js")) {
        Context.reportError(ToolErrorReporter.getMessage(
              "msg.extension.not.js", 
              str));
        return;
      } 
      if (!hasOutOption) {
        String str1 = file.getName();
        String str2 = str1.substring(0, str1.length() - 3);
        String str3 = String.valueOf(getClassName(str2)) + ".class";
        String str4 = (file.getParent() == null) ? str3 : (String.valueOf(file.getParent()) + 
          File.separator + str3);
        paramContext.setTargetClassFileName(str4);
      } 
      if (paramContext.getTargetClassFileName() == null)
        Context.reportError(ToolErrorReporter.getMessage("msg.no-opt")); 
      try {
        FileReader fileReader = new FileReader(str);
        paramContext.compileReader(null, fileReader, str, 1, null);
      } catch (FileNotFoundException fileNotFoundException) {
        Context.reportError(ToolErrorReporter.getMessage(
              "msg.couldnt.open", 
              str));
        return;
      } catch (IOException iOException) {
        Context.reportError(iOException.toString());
      } 
    } 
  }
  
  static String getClassName(String paramString) {
    char[] arrayOfChar = new char[paramString.length() + 1];
    byte b1 = 0;
    if (!Character.isJavaIdentifierStart(paramString.charAt(0)))
      arrayOfChar[b1++] = '_'; 
    for (byte b2 = 0; b2 < paramString.length(); b2++, b1++) {
      char c = paramString.charAt(b2);
      if (Character.isJavaIdentifierPart(c)) {
        arrayOfChar[b1] = c;
      } else {
        arrayOfChar[b1] = '_';
      } 
    } 
    return (new String(arrayOfChar)).trim();
  }
  
  private static void p(String paramString) { System.out.println(paramString); }
  
  private static boolean hasOutOption = false;
  
  private static ToolErrorReporter reporter;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\tools\jsc\Main.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */