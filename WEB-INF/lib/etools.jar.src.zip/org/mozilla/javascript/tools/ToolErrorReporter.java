package org.mozilla.javascript.tools;

import java.io.PrintStream;
import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ErrorReporter;
import org.mozilla.javascript.EvaluatorException;

public class ToolErrorReporter implements ErrorReporter {
  private final String messagePrefix = "js: ";
  
  private boolean hasReportedErrorFlag;
  
  private boolean reportWarnings;
  
  private PrintStream err;
  
  public ToolErrorReporter(boolean paramBoolean) { this(paramBoolean, System.err); }
  
  public ToolErrorReporter(boolean paramBoolean, PrintStream paramPrintStream) {
    this.messagePrefix = "js: ";
    this.reportWarnings = paramBoolean;
    this.err = paramPrintStream;
  }
  
  public static String getMessage(String paramString) { return getMessage(paramString, null); }
  
  public static String getMessage(String paramString1, String paramString2) {
    Object[] arrayOfObject = { paramString2 };
    return getMessage(paramString1, arrayOfObject);
  }
  
  public static String getMessage(String paramString, Object[] paramArrayOfObject) {
    String str;
    Context context = Context.getCurrentContext();
    Locale locale = (context == null) ? Locale.getDefault() : context.getLocale();
    ResourceBundle resourceBundle = ResourceBundle.getBundle("org.mozilla.javascript.tools.resources.Messages", locale);
    try {
      str = resourceBundle.getString(paramString);
    } catch (MissingResourceException missingResourceException) {
      throw new RuntimeException("no message resource found for message property " + paramString);
    } 
    if (paramArrayOfObject == null)
      return str; 
    MessageFormat messageFormat = new MessageFormat(str);
    return messageFormat.format(paramArrayOfObject);
  }
  
  public void warning(String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2) {
    if (!this.reportWarnings)
      return; 
    Object[] arrayOfObject = { formatMessage(paramString1, paramString2, paramInt1) };
    paramString1 = getMessage("msg.warning", arrayOfObject);
    this.err.println("js: " + paramString1);
    if (paramString3 != null) {
      this.err.println("js: " + paramString3);
      this.err.println("js: " + buildIndicator(paramInt2));
    } 
  }
  
  public void error(String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2) {
    this.hasReportedErrorFlag = true;
    paramString1 = formatMessage(paramString1, paramString2, paramInt1);
    this.err.println("js: " + paramString1);
    if (paramString3 != null) {
      this.err.println("js: " + paramString3);
      this.err.println("js: " + buildIndicator(paramInt2));
    } 
  }
  
  public EvaluatorException runtimeError(String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2) {
    error(paramString1, paramString2, paramInt1, paramString3, paramInt2);
    return new EvaluatorException(paramString1);
  }
  
  public boolean hasReportedError() { return this.hasReportedErrorFlag; }
  
  public boolean isReportingWarnings() { return this.reportWarnings; }
  
  public void setIsReportingWarnings(boolean paramBoolean) { this.reportWarnings = paramBoolean; }
  
  private String formatMessage(String paramString1, String paramString2, int paramInt) {
    if (paramInt > 0) {
      if (paramString2 != null) {
        Object[] arrayOfObject2 = { paramString2, new Integer(paramInt), paramString1 };
        return getMessage("msg.format3", arrayOfObject2);
      } 
      Object[] arrayOfObject1 = { new Integer(paramInt), paramString1 };
      return getMessage("msg.format2", arrayOfObject1);
    } 
    Object[] arrayOfObject = { paramString1 };
    return getMessage("msg.format1", arrayOfObject);
  }
  
  private String buildIndicator(int paramInt) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramInt - 1; b++)
      stringBuffer.append("."); 
    stringBuffer.append("^");
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\tools\ToolErrorReporter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */