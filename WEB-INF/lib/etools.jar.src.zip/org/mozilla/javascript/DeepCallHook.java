package org.mozilla.javascript;

public interface DeepCallHook {
  void postCall(Context paramContext, Object paramObject1, Object paramObject2, JavaScriptException paramJavaScriptException);
  
  Object preCall(Context paramContext, Object paramObject1, Object paramObject2, Object[] paramArrayOfObject);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\DeepCallHook.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */