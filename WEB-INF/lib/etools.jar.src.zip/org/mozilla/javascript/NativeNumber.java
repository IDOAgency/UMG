/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeNumber
/*     */   extends ScriptableObject
/*     */ {
/*     */   private static final int MAX_PRECISION = 100;
/*     */   private static final double defaultValue = 0.0D;
/*     */   private double doubleValue;
/*     */   
/*     */   public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) {
/*  51 */     byte b1 = 
/*  52 */       7;
/*     */ 
/*     */     
/*  55 */     String[] arrayOfString = { "NaN", "POSITIVE_INFINITY", "NEGATIVE_INFINITY", 
/*  56 */         "MAX_VALUE", "MIN_VALUE" };
/*  57 */     double[] arrayOfDouble = { ScriptRuntime.NaN, Double.POSITIVE_INFINITY, 
/*  58 */         Double.NEGATIVE_INFINITY, Double.MAX_VALUE, 
/*  59 */         Double.MIN_VALUE };
/*  60 */     for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
/*  61 */       paramFunctionObject.defineProperty(arrayOfString[b2], new Double(arrayOfDouble[b2]), 7);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public NativeNumber() { this.doubleValue = 0.0D; }
/*     */ 
/*     */ 
/*     */   
/*  75 */   public NativeNumber(double paramDouble) { this.doubleValue = paramDouble; }
/*     */ 
/*     */ 
/*     */   
/*  79 */   public String getClassName() { return "Number"; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
/*  85 */     double d = (paramArrayOfObject.length >= 1) ? 
/*  86 */       ScriptRuntime.toNumber(paramArrayOfObject[0]) : 
/*  87 */       0.0D;
/*  88 */     if (paramBoolean)
/*     */     {
/*  90 */       return new NativeNumber(d);
/*     */     }
/*     */     
/*  93 */     return new Double(d);
/*     */   }
/*     */ 
/*     */   
/*  97 */   public String toString() { return jsFunction_toString(Undefined.instance); }
/*     */ 
/*     */   
/*     */   public String jsFunction_toString(Object paramObject) {
/* 101 */     byte b = (paramObject == Undefined.instance) ? 
/* 102 */       10 : 
/* 103 */       ScriptRuntime.toInt32(paramObject);
/* 104 */     return ScriptRuntime.numberToString(this.doubleValue, b);
/*     */   }
/*     */ 
/*     */   
/* 108 */   public double jsFunction_valueOf() { return this.doubleValue; }
/*     */ 
/*     */ 
/*     */   
/* 112 */   public String jsFunction_toLocaleString(Object paramObject) { return toString(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String jsFunction_toFixed(Object paramObject) {
/* 118 */     return num_to(paramObject, 2, 2, 
/* 119 */         -20, 100, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String jsFunction_toExponential(Object paramObject) {
/* 125 */     return num_to(paramObject, 1, 
/* 126 */         3, 0, 100, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String jsFunction_toPrecision(Object paramObject) {
/* 132 */     return num_to(paramObject, 0, 
/* 133 */         4, 1, 100, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String num_to(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*     */     int i;
/* 141 */     if (paramObject == Undefined.instance) {
/* 142 */       i = 0;
/* 143 */       paramInt2 = paramInt1;
/*     */     } else {
/* 145 */       i = ScriptRuntime.toInt32(paramObject);
/* 146 */       if (i < paramInt3 || i > paramInt4) {
/* 147 */         Object[] arrayOfObject = new Object[1];
/* 148 */         arrayOfObject[0] = Integer.toString(i);
/* 149 */         throw NativeGlobal.constructError(
/* 150 */             Context.getCurrentContext(), "RangeError", 
/* 151 */             ScriptRuntime.getMessage("msg.bad.precision", arrayOfObject), 
/* 152 */             this);
/*     */       } 
/*     */     } 
/* 155 */     StringBuffer stringBuffer = new StringBuffer();
/* 156 */     DToA.JS_dtostr(stringBuffer, paramInt2, i + paramInt5, this.doubleValue);
/* 157 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeNumber.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */