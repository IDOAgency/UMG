package org.mozilla.javascript;

public class NativeNumber extends ScriptableObject {
  private static final int MAX_PRECISION = 100;
  
  private static final double defaultValue = 0.0D;
  
  private double doubleValue;
  
  public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) {
    byte b1 = 
      7;
    String[] arrayOfString = { "NaN", "POSITIVE_INFINITY", "NEGATIVE_INFINITY", 
        "MAX_VALUE", "MIN_VALUE" };
    double[] arrayOfDouble = { ScriptRuntime.NaN, Double.POSITIVE_INFINITY, 
        Double.NEGATIVE_INFINITY, Double.MAX_VALUE, 
        Double.MIN_VALUE };
    for (byte b2 = 0; b2 < arrayOfString.length; b2++)
      paramFunctionObject.defineProperty(arrayOfString[b2], new Double(arrayOfDouble[b2]), 7); 
  }
  
  public NativeNumber() { this.doubleValue = 0.0D; }
  
  public NativeNumber(double paramDouble) { this.doubleValue = paramDouble; }
  
  public String getClassName() { return "Number"; }
  
  public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
    double d = (paramArrayOfObject.length >= 1) ? 
      ScriptRuntime.toNumber(paramArrayOfObject[0]) : 
      0.0D;
    if (paramBoolean)
      return new NativeNumber(d); 
    return new Double(d);
  }
  
  public String toString() { return jsFunction_toString(Undefined.instance); }
  
  public String jsFunction_toString(Object paramObject) {
    byte b = (paramObject == Undefined.instance) ? 
      10 : 
      ScriptRuntime.toInt32(paramObject);
    return ScriptRuntime.numberToString(this.doubleValue, b);
  }
  
  public double jsFunction_valueOf() { return this.doubleValue; }
  
  public String jsFunction_toLocaleString(Object paramObject) { return toString(); }
  
  public String jsFunction_toFixed(Object paramObject) {
    return num_to(paramObject, 2, 2, 
        -20, 100, 0);
  }
  
  public String jsFunction_toExponential(Object paramObject) {
    return num_to(paramObject, 1, 
        3, 0, 100, 1);
  }
  
  public String jsFunction_toPrecision(Object paramObject) {
    return num_to(paramObject, 0, 
        4, 1, 100, 0);
  }
  
  private String num_to(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    int i;
    if (paramObject == Undefined.instance) {
      i = 0;
      paramInt2 = paramInt1;
    } else {
      i = ScriptRuntime.toInt32(paramObject);
      if (i < paramInt3 || i > paramInt4) {
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = Integer.toString(i);
        throw NativeGlobal.constructError(
            Context.getCurrentContext(), "RangeError", 
            ScriptRuntime.getMessage("msg.bad.precision", arrayOfObject), 
            this);
      } 
    } 
    StringBuffer stringBuffer = new StringBuffer();
    DToA.JS_dtostr(stringBuffer, paramInt2, i + paramInt5, this.doubleValue);
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeNumber.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */