package org.mozilla.javascript;

public class InterpretedScript extends NativeScript {
  InterpreterData itsData;
  
  InterpretedScript(InterpreterData paramInterpreterData, Context paramContext) {
    this.itsData = paramInterpreterData;
    this.names = new String[this.itsData.itsVariableTable.size() + 1];
    this.names[0] = "";
    for (byte b = 0; b < this.itsData.itsVariableTable.size(); b++)
      this.names[b + true] = this.itsData.itsVariableTable.getName(b); 
    this.nestedFunctions = this.itsData.itsNestedFunctions;
    this.version = (short)paramContext.getLanguageVersion();
  }
  
  public Object exec(Context paramContext, Scriptable paramScriptable) throws JavaScriptException { return call(paramContext, paramScriptable, paramScriptable, null); }
  
  public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException {
    paramScriptable1 = ScriptRuntime.initScript(paramContext, paramScriptable1, this, paramScriptable2, 
        this.itsData.itsFromEvalCode);
    this.itsData.itsCX = paramContext;
    this.itsData.itsScope = paramScriptable1;
    this.itsData.itsThisObj = paramScriptable2;
    this.itsData.itsInArgs = paramArrayOfObject;
    return Interpreter.interpret(this.itsData);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\InterpretedScript.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */