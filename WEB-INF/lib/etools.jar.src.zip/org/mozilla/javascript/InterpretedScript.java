/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterpretedScript
/*    */   extends NativeScript
/*    */ {
/*    */   InterpreterData itsData;
/*    */   
/*    */   InterpretedScript(InterpreterData paramInterpreterData, Context paramContext) {
/* 42 */     this.itsData = paramInterpreterData;
/* 43 */     this.names = new String[this.itsData.itsVariableTable.size() + 1];
/* 44 */     this.names[0] = "";
/* 45 */     for (byte b = 0; b < this.itsData.itsVariableTable.size(); b++)
/* 46 */       this.names[b + true] = this.itsData.itsVariableTable.getName(b); 
/* 47 */     this.nestedFunctions = this.itsData.itsNestedFunctions;
/* 48 */     this.version = (short)paramContext.getLanguageVersion();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   public Object exec(Context paramContext, Scriptable paramScriptable) throws JavaScriptException { return call(paramContext, paramScriptable, paramScriptable, null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException {
/* 61 */     paramScriptable1 = ScriptRuntime.initScript(paramContext, paramScriptable1, this, paramScriptable2, 
/* 62 */         this.itsData.itsFromEvalCode);
/* 63 */     this.itsData.itsCX = paramContext;
/* 64 */     this.itsData.itsScope = paramScriptable1;
/* 65 */     this.itsData.itsThisObj = paramScriptable2;
/* 66 */     this.itsData.itsInArgs = paramArrayOfObject;
/* 67 */     return Interpreter.interpret(this.itsData);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\InterpretedScript.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */