/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlattenedObject
/*     */ {
/*     */   private Scriptable obj;
/*     */   
/*  72 */   public FlattenedObject(Scriptable paramScriptable) { this.obj = paramScriptable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public Scriptable getObject() { return this.obj; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasProperty(Object paramObject) {
/*  98 */     String str1 = ScriptRuntime.toString(paramObject);
/*  99 */     String str2 = ScriptRuntime.getStringId(str1);
/* 100 */     if (str2 == null)
/* 101 */       return !(getBase(this.obj, ScriptRuntime.getIntId(str1)) == null); 
/* 102 */     return !(getBase(this.obj, str2) == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(Object paramObject) {
/*     */     Object object;
/* 124 */     String str = ScriptRuntime.getStringId(paramObject);
/* 125 */     int i = (str == null) ? ScriptRuntime.getIntId(paramObject) : 0;
/* 126 */     Scriptable scriptable = this.obj;
/*     */     
/*     */     while (true) {
/* 129 */       object = (str == null) ? scriptable.get(i, this.obj) : scriptable.get(str, this.obj);
/* 130 */       if (object == Scriptable.NOT_FOUND) {
/*     */         
/* 132 */         scriptable = scriptable.getPrototype();
/* 133 */         if (scriptable == null)
/* 134 */           return Undefined.instance;  continue;
/*     */       }  break;
/* 136 */     }  if (object instanceof Scriptable)
/* 137 */       return new FlattenedObject((Scriptable)object); 
/* 138 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putProperty(Object paramObject1, Object paramObject2) {
/* 154 */     String str = ScriptRuntime.getStringId(paramObject1);
/* 155 */     if (paramObject2 instanceof FlattenedObject) {
/* 156 */       paramObject2 = ((FlattenedObject)paramObject2).getObject();
/*     */     }
/* 158 */     if (str == null) {
/* 159 */       int i = ScriptRuntime.getIntId(paramObject1);
/* 160 */       Scriptable scriptable1 = getBase(this.obj, i);
/* 161 */       if (scriptable1 == null)
/* 162 */         scriptable1 = this.obj; 
/* 163 */       scriptable1.put(i, this.obj, paramObject2);
/*     */       return;
/*     */     } 
/* 166 */     Scriptable scriptable = getBase(this.obj, str);
/* 167 */     if (scriptable == null)
/* 168 */       scriptable = this.obj; 
/* 169 */     scriptable.put(str, this.obj, paramObject2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean deleteProperty(Object paramObject) {
/* 184 */     String str = ScriptRuntime.getStringId(paramObject);
/* 185 */     if (str == null) {
/* 186 */       int i = ScriptRuntime.getIntId(paramObject);
/* 187 */       Scriptable scriptable1 = getBase(this.obj, i);
/* 188 */       if (scriptable1 == null)
/* 189 */         return true; 
/* 190 */       scriptable1.delete(i);
/* 191 */       return scriptable1.has(i, scriptable1) ^ true;
/*     */     } 
/* 193 */     Scriptable scriptable = getBase(this.obj, str);
/* 194 */     if (scriptable == null)
/* 195 */       return true; 
/* 196 */     scriptable.delete(str);
/* 197 */     return scriptable.has(str, scriptable) ^ true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getIds() {
/* 213 */     Hashtable hashtable = new Hashtable(11);
/* 214 */     Scriptable scriptable = this.obj;
/* 215 */     while (scriptable != null) {
/* 216 */       Object[] arrayOfObject1 = scriptable.getIds();
/* 217 */       for (byte b1 = 0; b1 < arrayOfObject1.length; b1++) {
/* 218 */         hashtable.put(arrayOfObject1[b1], Boolean.TRUE);
/*     */       }
/* 220 */       scriptable = scriptable.getPrototype();
/*     */     } 
/* 222 */     Enumeration enumeration = hashtable.keys();
/*     */     
/* 224 */     Object[] arrayOfObject = new Object[hashtable.size()];
/* 225 */     byte b = 0;
/* 226 */     while (enumeration.hasMoreElements()) {
/* 227 */       Object object = enumeration.nextElement();
/* 228 */       arrayOfObject[b++] = object;
/*     */     } 
/* 230 */     return arrayOfObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object call(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject) throws NotAFunctionException, JavaScriptException {
/* 249 */     if (!(this.obj instanceof Function)) {
/* 250 */       throw new NotAFunctionException();
/*     */     }
/* 252 */     return ScriptRuntime.call(paramContext, this.obj, paramScriptable, paramArrayOfObject, (Function)this.obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable construct(Context paramContext, Object[] paramArrayOfObject) throws NotAFunctionException, JavaScriptException {
/* 271 */     if (!(this.obj instanceof Function)) {
/* 272 */       throw new NotAFunctionException();
/*     */     }
/* 274 */     return ScriptRuntime.newObject(paramContext, this.obj, paramArrayOfObject, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object callMethod(Object paramObject, Object[] paramArrayOfObject) throws PropertyException, NotAFunctionException, JavaScriptException {
/* 306 */     if (!hasProperty(paramObject)) {
/* 307 */       throw new PropertyException(
/* 308 */           Context.getMessage("msg.prop.not.found", null));
/*     */     }
/* 310 */     Object object = getProperty(paramObject);
/* 311 */     if (object instanceof FlattenedObject)
/* 312 */       return ((FlattenedObject)object).call(Context.getContext(), this.obj, paramArrayOfObject); 
/* 313 */     throw new NotAFunctionException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Scriptable getBase(Scriptable paramScriptable, String paramString) {
/* 319 */     Scriptable scriptable = paramScriptable;
/* 320 */     while (scriptable != null) {
/* 321 */       if (scriptable.has(paramString, paramScriptable))
/* 322 */         return scriptable; 
/* 323 */       scriptable = scriptable.getPrototype();
/*     */     } 
/* 325 */     return null;
/*     */   }
/*     */   
/*     */   private static Scriptable getBase(Scriptable paramScriptable, int paramInt) {
/* 329 */     Scriptable scriptable = paramScriptable;
/* 330 */     while (scriptable != null) {
/* 331 */       if (scriptable.has(paramInt, paramScriptable))
/* 332 */         return scriptable; 
/* 333 */       scriptable = scriptable.getPrototype();
/*     */     } 
/* 335 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\FlattenedObject.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */