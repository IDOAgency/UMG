package org.mozilla.javascript;

import java.util.Enumeration;
import java.util.Hashtable;

public class FlattenedObject {
  private Scriptable obj;
  
  public FlattenedObject(Scriptable paramScriptable) { this.obj = paramScriptable; }
  
  public Scriptable getObject() { return this.obj; }
  
  public boolean hasProperty(Object paramObject) {
    String str1 = ScriptRuntime.toString(paramObject);
    String str2 = ScriptRuntime.getStringId(str1);
    if (str2 == null)
      return !(getBase(this.obj, ScriptRuntime.getIntId(str1)) == null); 
    return !(getBase(this.obj, str2) == null);
  }
  
  public Object getProperty(Object paramObject) {
    Object object;
    String str = ScriptRuntime.getStringId(paramObject);
    int i = (str == null) ? ScriptRuntime.getIntId(paramObject) : 0;
    Scriptable scriptable = this.obj;
    while (true) {
      object = (str == null) ? scriptable.get(i, this.obj) : scriptable.get(str, this.obj);
      if (object == Scriptable.NOT_FOUND) {
        scriptable = scriptable.getPrototype();
        if (scriptable == null)
          return Undefined.instance; 
        continue;
      } 
      break;
    } 
    if (object instanceof Scriptable)
      return new FlattenedObject((Scriptable)object); 
    return object;
  }
  
  public void putProperty(Object paramObject1, Object paramObject2) {
    String str = ScriptRuntime.getStringId(paramObject1);
    if (paramObject2 instanceof FlattenedObject)
      paramObject2 = ((FlattenedObject)paramObject2).getObject(); 
    if (str == null) {
      int i = ScriptRuntime.getIntId(paramObject1);
      Scriptable scriptable1 = getBase(this.obj, i);
      if (scriptable1 == null)
        scriptable1 = this.obj; 
      scriptable1.put(i, this.obj, paramObject2);
      return;
    } 
    Scriptable scriptable = getBase(this.obj, str);
    if (scriptable == null)
      scriptable = this.obj; 
    scriptable.put(str, this.obj, paramObject2);
  }
  
  public boolean deleteProperty(Object paramObject) {
    String str = ScriptRuntime.getStringId(paramObject);
    if (str == null) {
      int i = ScriptRuntime.getIntId(paramObject);
      Scriptable scriptable1 = getBase(this.obj, i);
      if (scriptable1 == null)
        return true; 
      scriptable1.delete(i);
      return scriptable1.has(i, scriptable1) ^ true;
    } 
    Scriptable scriptable = getBase(this.obj, str);
    if (scriptable == null)
      return true; 
    scriptable.delete(str);
    return scriptable.has(str, scriptable) ^ true;
  }
  
  public Object[] getIds() {
    Hashtable hashtable = new Hashtable(11);
    Scriptable scriptable = this.obj;
    while (scriptable != null) {
      Object[] arrayOfObject1 = scriptable.getIds();
      for (byte b1 = 0; b1 < arrayOfObject1.length; b1++)
        hashtable.put(arrayOfObject1[b1], Boolean.TRUE); 
      scriptable = scriptable.getPrototype();
    } 
    Enumeration enumeration = hashtable.keys();
    Object[] arrayOfObject = new Object[hashtable.size()];
    byte b = 0;
    while (enumeration.hasMoreElements()) {
      Object object = enumeration.nextElement();
      arrayOfObject[b++] = object;
    } 
    return arrayOfObject;
  }
  
  public Object call(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject) throws NotAFunctionException, JavaScriptException {
    if (!(this.obj instanceof Function))
      throw new NotAFunctionException(); 
    return ScriptRuntime.call(paramContext, this.obj, paramScriptable, paramArrayOfObject, (Function)this.obj);
  }
  
  public Scriptable construct(Context paramContext, Object[] paramArrayOfObject) throws NotAFunctionException, JavaScriptException {
    if (!(this.obj instanceof Function))
      throw new NotAFunctionException(); 
    return ScriptRuntime.newObject(paramContext, this.obj, paramArrayOfObject, null);
  }
  
  public Object callMethod(Object paramObject, Object[] paramArrayOfObject) throws PropertyException, NotAFunctionException, JavaScriptException {
    if (!hasProperty(paramObject))
      throw new PropertyException(
          Context.getMessage("msg.prop.not.found", null)); 
    Object object = getProperty(paramObject);
    if (object instanceof FlattenedObject)
      return ((FlattenedObject)object).call(Context.getContext(), this.obj, paramArrayOfObject); 
    throw new NotAFunctionException();
  }
  
  private static Scriptable getBase(Scriptable paramScriptable, String paramString) {
    Scriptable scriptable = paramScriptable;
    while (scriptable != null) {
      if (scriptable.has(paramString, paramScriptable))
        return scriptable; 
      scriptable = scriptable.getPrototype();
    } 
    return null;
  }
  
  private static Scriptable getBase(Scriptable paramScriptable, int paramInt) {
    Scriptable scriptable = paramScriptable;
    while (scriptable != null) {
      if (scriptable.has(paramInt, paramScriptable))
        return scriptable; 
      scriptable = scriptable.getPrototype();
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\FlattenedObject.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */