package org.mozilla.javascript;

public interface SourceTextItem {
  public static final int INITED = 0;
  
  public static final int PARTIAL = 1;
  
  public static final int COMPLETED = 2;
  
  public static final int ABORTED = 3;
  
  public static final int FAILED = 4;
  
  public static final int CLEARED = 5;
  
  public static final int INVALID = 6;
  
  boolean abort();
  
  boolean append(char paramChar);
  
  boolean append(String paramString);
  
  boolean append(char[] paramArrayOfChar, int paramInt1, int paramInt2);
  
  boolean clear();
  
  boolean complete();
  
  boolean fail();
  
  int getAlterCount();
  
  String getName();
  
  int getStatus();
  
  String getText();
  
  boolean invalidate();
  
  boolean isValid();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\SourceTextItem.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */