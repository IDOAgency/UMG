package org.mozilla.javascript;

import java.io.IOException;
import java.io.StringReader;

public class NativeScript extends NativeFunction implements Script {
  private Script script;
  
  public String getClassName() { return "Script"; }
  
  public void initScript(Scriptable paramScriptable) {}
  
  public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
    String str = (paramArrayOfObject.length == 0) ? 
      "" : 
      ScriptRuntime.toString(paramArrayOfObject[0]);
    Scriptable scriptable = paramContext.ctorScope;
    if (scriptable == null)
      scriptable = paramFunction; 
    return compile(scriptable, str);
  }
  
  public static Script compile(Scriptable paramScriptable, String paramString) {
    Context context = Context.getContext();
    StringReader stringReader = new StringReader(paramString);
    try {
      int[] arrayOfInt = new int[1];
      String str = Context.getSourcePositionFromStack(arrayOfInt);
      if (str == null) {
        str = "<Script object>";
        arrayOfInt[0] = 1;
      } 
      Object object = 
        context.getSecurityDomainForStackDepth(5);
      return context.compileReader(paramScriptable, stringReader, str, arrayOfInt[0], 
          object);
    } catch (IOException iOException) {
      throw new RuntimeException("Unexpected IOException");
    } 
  }
  
  public Scriptable jsFunction_compile(String paramString) {
    this.script = compile(null, paramString);
    return this;
  }
  
  public Object jsFunction_exec() throws JavaScriptException {
    Object[] arrayOfObject = { "exec" };
    throw Context.reportRuntimeError(
        Context.getMessage("msg.cant.call.indirect", arrayOfObject));
  }
  
  public static Object jsFunction_toString(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    Script script1 = ((NativeScript)paramScriptable).script;
    if (script1 == null)
      script1 = (Script)paramScriptable; 
    Scriptable scriptable = ScriptableObject.getTopLevelScope(paramScriptable);
    return paramContext.decompileScript(script1, scriptable, 0);
  }
  
  public String jsGet_name() { return ""; }
  
  public Object exec(Context paramContext, Scriptable paramScriptable) throws JavaScriptException { return (this.script == null) ? Undefined.instance : this.script.exec(paramContext, paramScriptable); }
  
  public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException { return exec(paramContext, paramScriptable1); }
  
  public Scriptable construct(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject) throws JavaScriptException {
    String str = Context.getMessage("msg.script.is.not.constructor", null);
    throw Context.reportRuntimeError(str);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeScript.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */