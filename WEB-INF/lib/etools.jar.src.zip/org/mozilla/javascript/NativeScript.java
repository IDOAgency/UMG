/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeScript
/*     */   extends NativeFunction
/*     */   implements Script
/*     */ {
/*     */   private Script script;
/*     */   
/*  69 */   public String getClassName() { return "Script"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initScript(Scriptable paramScriptable) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
/*  88 */     String str = (paramArrayOfObject.length == 0) ? 
/*  89 */       "" : 
/*  90 */       ScriptRuntime.toString(paramArrayOfObject[0]);
/*  91 */     Scriptable scriptable = paramContext.ctorScope;
/*  92 */     if (scriptable == null)
/*  93 */       scriptable = paramFunction; 
/*  94 */     return compile(scriptable, str);
/*     */   }
/*     */   
/*     */   public static Script compile(Scriptable paramScriptable, String paramString) {
/*  98 */     Context context = Context.getContext();
/*  99 */     StringReader stringReader = new StringReader(paramString);
/*     */     try {
/* 101 */       int[] arrayOfInt = new int[1];
/* 102 */       String str = Context.getSourcePositionFromStack(arrayOfInt);
/* 103 */       if (str == null) {
/* 104 */         str = "<Script object>";
/* 105 */         arrayOfInt[0] = 1;
/*     */       } 
/* 107 */       Object object = 
/* 108 */         context.getSecurityDomainForStackDepth(5);
/* 109 */       return context.compileReader(paramScriptable, stringReader, str, arrayOfInt[0], 
/* 110 */           object);
/*     */     }
/* 112 */     catch (IOException iOException) {
/* 113 */       throw new RuntimeException("Unexpected IOException");
/*     */     } 
/*     */   }
/*     */   
/*     */   public Scriptable jsFunction_compile(String paramString) {
/* 118 */     this.script = compile(null, paramString);
/* 119 */     return this;
/*     */   }
/*     */   
/*     */   public Object jsFunction_exec() throws JavaScriptException {
/* 123 */     Object[] arrayOfObject = { "exec" };
/* 124 */     throw Context.reportRuntimeError(
/* 125 */         Context.getMessage("msg.cant.call.indirect", arrayOfObject));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsFunction_toString(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 131 */     Script script1 = ((NativeScript)paramScriptable).script;
/* 132 */     if (script1 == null)
/* 133 */       script1 = (Script)paramScriptable; 
/* 134 */     Scriptable scriptable = ScriptableObject.getTopLevelScope(paramScriptable);
/* 135 */     return paramContext.decompileScript(script1, scriptable, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public String jsGet_name() { return ""; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 153 */   public Object exec(Context paramContext, Scriptable paramScriptable) throws JavaScriptException { return (this.script == null) ? Undefined.instance : this.script.exec(paramContext, paramScriptable); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException { return exec(paramContext, paramScriptable1); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable construct(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject) throws JavaScriptException {
/* 166 */     String str = Context.getMessage("msg.script.is.not.constructor", null);
/* 167 */     throw Context.reportRuntimeError(str);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeScript.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */