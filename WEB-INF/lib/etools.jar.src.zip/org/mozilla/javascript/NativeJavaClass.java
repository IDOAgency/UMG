/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeJavaClass
/*     */   extends NativeJavaObject
/*     */   implements Function
/*     */ {
/*     */   private Hashtable fieldAndMethods;
/*     */   private Scriptable parent;
/*     */   
/*     */   public NativeJavaClass(Scriptable paramScriptable, Class paramClass) {
/*  63 */     super(paramScriptable, paramClass, JavaMembers.lookupClass(paramScriptable, paramClass, paramClass));
/*  64 */     this.fieldAndMethods = this.members.getFieldAndMethodsObjects(this, this.javaObject, 
/*  65 */         true);
/*     */   }
/*     */ 
/*     */   
/*  69 */   public String getClassName() { return "JavaClass"; }
/*     */ 
/*     */ 
/*     */   
/*  73 */   public boolean has(String paramString, Scriptable paramScriptable) { return this.members.has(paramString, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/*  82 */     if (paramString.equals("prototype")) {
/*  83 */       return null;
/*     */     }
/*  85 */     Object object = Scriptable.NOT_FOUND;
/*     */     
/*  87 */     if (this.fieldAndMethods != null) {
/*  88 */       object = this.fieldAndMethods.get(paramString);
/*  89 */       if (object != null) {
/*  90 */         return object;
/*     */       }
/*     */     } 
/*  93 */     if (this.members.has(paramString, true)) {
/*  94 */       object = this.members.get(this, paramString, this.javaObject, true);
/*     */     } else {
/*     */       
/*     */       try {
/*  98 */         String str = String.valueOf(getClassObject().getName()) + '$' + paramString;
/*  99 */         Class clazz = ScriptRuntime.loadClassName(str);
/* 100 */         NativeJavaClass nativeJavaClass = wrap(ScriptableObject.getTopLevelScope(this), clazz);
/* 101 */         nativeJavaClass.setParentScope(this);
/* 102 */         object = nativeJavaClass;
/* 103 */       } catch (ClassNotFoundException classNotFoundException) {
/* 104 */         throw this.members.reportMemberNotFound(paramString);
/* 105 */       } catch (IllegalArgumentException illegalArgumentException) {
/* 106 */         throw this.members.reportMemberNotFound(paramString);
/*     */       } 
/*     */     } 
/*     */     
/* 110 */     return object;
/*     */   }
/*     */ 
/*     */   
/* 114 */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) { this.members.put(paramString, this.javaObject, paramObject, true); }
/*     */ 
/*     */ 
/*     */   
/* 118 */   public Object[] getIds() { return this.members.getIds(true); }
/*     */ 
/*     */ 
/*     */   
/* 122 */   public Class getClassObject() { return (Class)unwrap(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public static NativeJavaClass wrap(Scriptable paramScriptable, Class paramClass) { return new NativeJavaClass(paramScriptable, paramClass); }
/*     */ 
/*     */   
/*     */   public Object getDefaultValue(Class paramClass) {
/* 131 */     if (paramClass == null || paramClass == ScriptRuntime.StringClass)
/* 132 */       return toString(); 
/* 133 */     if (paramClass == ScriptRuntime.BooleanClass)
/* 134 */       return Boolean.TRUE; 
/* 135 */     if (paramClass == ScriptRuntime.NumberClass)
/* 136 */       return ScriptRuntime.NaNobj; 
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException {
/* 147 */     if (paramArrayOfObject.length == 1 && paramArrayOfObject[0] instanceof Scriptable) {
/* 148 */       Class clazz = getClassObject();
/* 149 */       Scriptable scriptable = (Scriptable)paramArrayOfObject[0];
/*     */       do {
/* 151 */         if (scriptable instanceof Wrapper) {
/* 152 */           Object object = ((Wrapper)scriptable).unwrap();
/* 153 */           if (clazz.isInstance(object))
/* 154 */             return scriptable; 
/*     */         } 
/* 156 */         scriptable = scriptable.getPrototype();
/* 157 */       } while (scriptable != null);
/*     */     } 
/* 159 */     return construct(paramContext, paramScriptable1, paramArrayOfObject);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable construct(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject) throws JavaScriptException {
/* 165 */     Class clazz = getClassObject();
/* 166 */     int i = clazz.getModifiers();
/* 167 */     if (!Modifier.isInterface(i) && 
/* 168 */       !Modifier.isAbstract(i)) {
/*     */       
/* 170 */       Constructor[] arrayOfConstructor = this.members.getConstructors();
/* 171 */       Member member = NativeJavaMethod.findFunction(arrayOfConstructor, paramArrayOfObject);
/* 172 */       Constructor constructor = (Constructor)member;
/* 173 */       if (constructor == null) {
/* 174 */         String str1 = NativeJavaMethod.scriptSignature(paramArrayOfObject);
/* 175 */         Object[] arrayOfObject1 = { clazz.getName(), str1 };
/* 176 */         throw Context.reportRuntimeError(Context.getMessage(
/* 177 */               "msg.no.java.ctor", arrayOfObject1));
/*     */       } 
/*     */ 
/*     */       
/* 181 */       return constructSpecific(paramContext, paramScriptable, 
/* 182 */           this, constructor, paramArrayOfObject);
/*     */     } 
/* 184 */     Scriptable scriptable = ScriptableObject.getTopLevelScope(this);
/* 185 */     String str = "";
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 190 */       Object object = scriptable.get("JavaAdapter", scriptable);
/* 191 */       if (object != Scriptable.NOT_FOUND) {
/* 192 */         Function function = (Function)object;
/* 193 */         Object[] arrayOfObject1 = { this, paramArrayOfObject[0] };
/* 194 */         return function.construct(paramContext, scriptable, 
/* 195 */             arrayOfObject1);
/*     */       } 
/* 197 */     } catch (Exception exception) {
/*     */       
/* 199 */       String str1 = exception.getMessage();
/* 200 */       if (str1 != null)
/* 201 */         str = str1; 
/*     */     } 
/* 203 */     Object[] arrayOfObject = { str, clazz.getName() };
/* 204 */     throw Context.reportRuntimeError(
/* 205 */         Context.getMessage("msg.cant.instantiate", 
/* 206 */           arrayOfObject));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Scriptable constructSpecific(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Constructor paramConstructor, Object[] paramArrayOfObject) throws JavaScriptException {
/* 217 */     Scriptable scriptable = ScriptableObject.getTopLevelScope(paramScriptable2);
/* 218 */     Class clazz = paramConstructor.getDeclaringClass();
/*     */     
/* 220 */     Class[] arrayOfClass = paramConstructor.getParameterTypes();
/* 221 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 222 */       paramArrayOfObject[b] = NativeJavaObject.coerceType(arrayOfClass[b], paramArrayOfObject[b]);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 227 */       return 
/* 228 */         (Scriptable)NativeJavaObject.wrap(scriptable, 
/* 229 */           paramConstructor.newInstance(paramArrayOfObject), 
/* 230 */           clazz);
/*     */     }
/* 232 */     catch (InstantiationException instantiationException) {
/* 233 */       Object[] arrayOfObject = { instantiationException.getMessage(), 
/* 234 */           clazz.getName() };
/* 235 */       throw Context.reportRuntimeError(
/* 236 */           Context.getMessage("msg.cant.instantiate", 
/* 237 */             arrayOfObject));
/* 238 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 239 */       String str1 = NativeJavaMethod.scriptSignature(paramArrayOfObject);
/* 240 */       String str2 = paramConstructor.toString();
/* 241 */       Object[] arrayOfObject = { illegalArgumentException.getMessage(), str2, str1 };
/* 242 */       throw Context.reportRuntimeError(
/* 243 */           Context.getMessage("msg.bad.ctor.sig", 
/* 244 */             arrayOfObject));
/* 245 */     } catch (InvocationTargetException invocationTargetException) {
/* 246 */       throw JavaScriptException.wrapException(paramScriptable1, invocationTargetException);
/* 247 */     } catch (IllegalAccessException illegalAccessException) {
/* 248 */       Object[] arrayOfObject = { illegalAccessException.getMessage() };
/* 249 */       throw Context.reportRuntimeError(
/* 250 */           Context.getMessage("msg.java.internal.private", arrayOfObject));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 255 */   public String toString() { return "[JavaClass " + getClassObject().getName() + "]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasInstance(Scriptable paramScriptable) {
/* 268 */     if (paramScriptable instanceof NativeJavaObject && 
/* 269 */       !(paramScriptable instanceof NativeJavaClass)) {
/* 270 */       Object object = ((NativeJavaObject)paramScriptable).unwrap();
/*     */       
/* 272 */       return getClassObject().isInstance(object);
/*     */     } 
/*     */ 
/*     */     
/* 276 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeJavaClass.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */