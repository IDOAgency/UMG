package org.mozilla.javascript;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Modifier;
import java.util.Hashtable;

public class NativeJavaClass extends NativeJavaObject implements Function {
  private Hashtable fieldAndMethods;
  
  private Scriptable parent;
  
  public NativeJavaClass(Scriptable paramScriptable, Class paramClass) {
    super(paramScriptable, paramClass, JavaMembers.lookupClass(paramScriptable, paramClass, paramClass));
    this.fieldAndMethods = this.members.getFieldAndMethodsObjects(this, this.javaObject, 
        true);
  }
  
  public String getClassName() { return "JavaClass"; }
  
  public boolean has(String paramString, Scriptable paramScriptable) { return this.members.has(paramString, true); }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    if (paramString.equals("prototype"))
      return null; 
    Object object = Scriptable.NOT_FOUND;
    if (this.fieldAndMethods != null) {
      object = this.fieldAndMethods.get(paramString);
      if (object != null)
        return object; 
    } 
    if (this.members.has(paramString, true)) {
      object = this.members.get(this, paramString, this.javaObject, true);
    } else {
      try {
        String str = String.valueOf(getClassObject().getName()) + '$' + paramString;
        Class clazz = ScriptRuntime.loadClassName(str);
        NativeJavaClass nativeJavaClass = wrap(ScriptableObject.getTopLevelScope(this), clazz);
        nativeJavaClass.setParentScope(this);
        object = nativeJavaClass;
      } catch (ClassNotFoundException classNotFoundException) {
        throw this.members.reportMemberNotFound(paramString);
      } catch (IllegalArgumentException illegalArgumentException) {
        throw this.members.reportMemberNotFound(paramString);
      } 
    } 
    return object;
  }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) { this.members.put(paramString, this.javaObject, paramObject, true); }
  
  public Object[] getIds() { return this.members.getIds(true); }
  
  public Class getClassObject() { return (Class)unwrap(); }
  
  public static NativeJavaClass wrap(Scriptable paramScriptable, Class paramClass) { return new NativeJavaClass(paramScriptable, paramClass); }
  
  public Object getDefaultValue(Class paramClass) {
    if (paramClass == null || paramClass == ScriptRuntime.StringClass)
      return toString(); 
    if (paramClass == ScriptRuntime.BooleanClass)
      return Boolean.TRUE; 
    if (paramClass == ScriptRuntime.NumberClass)
      return ScriptRuntime.NaNobj; 
    return this;
  }
  
  public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException {
    if (paramArrayOfObject.length == 1 && paramArrayOfObject[0] instanceof Scriptable) {
      Class clazz = getClassObject();
      Scriptable scriptable = (Scriptable)paramArrayOfObject[0];
      do {
        if (scriptable instanceof Wrapper) {
          Object object = ((Wrapper)scriptable).unwrap();
          if (clazz.isInstance(object))
            return scriptable; 
        } 
        scriptable = scriptable.getPrototype();
      } while (scriptable != null);
    } 
    return construct(paramContext, paramScriptable1, paramArrayOfObject);
  }
  
  public Scriptable construct(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject) throws JavaScriptException {
    Class clazz = getClassObject();
    int i = clazz.getModifiers();
    if (!Modifier.isInterface(i) && 
      !Modifier.isAbstract(i)) {
      Constructor[] arrayOfConstructor = this.members.getConstructors();
      Member member = NativeJavaMethod.findFunction(arrayOfConstructor, paramArrayOfObject);
      Constructor constructor = (Constructor)member;
      if (constructor == null) {
        String str1 = NativeJavaMethod.scriptSignature(paramArrayOfObject);
        Object[] arrayOfObject1 = { clazz.getName(), str1 };
        throw Context.reportRuntimeError(Context.getMessage(
              "msg.no.java.ctor", arrayOfObject1));
      } 
      return constructSpecific(paramContext, paramScriptable, 
          this, constructor, paramArrayOfObject);
    } 
    Scriptable scriptable = ScriptableObject.getTopLevelScope(this);
    String str = "";
    try {
      Object object = scriptable.get("JavaAdapter", scriptable);
      if (object != Scriptable.NOT_FOUND) {
        Function function = (Function)object;
        Object[] arrayOfObject1 = { this, paramArrayOfObject[0] };
        return function.construct(paramContext, scriptable, 
            arrayOfObject1);
      } 
    } catch (Exception exception) {
      String str1 = exception.getMessage();
      if (str1 != null)
        str = str1; 
    } 
    Object[] arrayOfObject = { str, clazz.getName() };
    throw Context.reportRuntimeError(
        Context.getMessage("msg.cant.instantiate", 
          arrayOfObject));
  }
  
  public static Scriptable constructSpecific(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Constructor paramConstructor, Object[] paramArrayOfObject) throws JavaScriptException {
    Scriptable scriptable = ScriptableObject.getTopLevelScope(paramScriptable2);
    Class clazz = paramConstructor.getDeclaringClass();
    Class[] arrayOfClass = paramConstructor.getParameterTypes();
    for (byte b = 0; b < paramArrayOfObject.length; b++)
      paramArrayOfObject[b] = NativeJavaObject.coerceType(arrayOfClass[b], paramArrayOfObject[b]); 
    try {
      return 
        (Scriptable)NativeJavaObject.wrap(scriptable, 
          paramConstructor.newInstance(paramArrayOfObject), 
          clazz);
    } catch (InstantiationException instantiationException) {
      Object[] arrayOfObject = { instantiationException.getMessage(), 
          clazz.getName() };
      throw Context.reportRuntimeError(
          Context.getMessage("msg.cant.instantiate", 
            arrayOfObject));
    } catch (IllegalArgumentException illegalArgumentException) {
      String str1 = NativeJavaMethod.scriptSignature(paramArrayOfObject);
      String str2 = paramConstructor.toString();
      Object[] arrayOfObject = { illegalArgumentException.getMessage(), str2, str1 };
      throw Context.reportRuntimeError(
          Context.getMessage("msg.bad.ctor.sig", 
            arrayOfObject));
    } catch (InvocationTargetException invocationTargetException) {
      throw JavaScriptException.wrapException(paramScriptable1, invocationTargetException);
    } catch (IllegalAccessException illegalAccessException) {
      Object[] arrayOfObject = { illegalAccessException.getMessage() };
      throw Context.reportRuntimeError(
          Context.getMessage("msg.java.internal.private", arrayOfObject));
    } 
  }
  
  public String toString() { return "[JavaClass " + getClassObject().getName() + "]"; }
  
  public boolean hasInstance(Scriptable paramScriptable) {
    if (paramScriptable instanceof NativeJavaObject && 
      !(paramScriptable instanceof NativeJavaClass)) {
      Object object = ((NativeJavaObject)paramScriptable).unwrap();
      return getClassObject().isInstance(object);
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeJavaClass.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */