package org.mozilla.javascript;

final class BinaryDigitReader {
  int lgBase = 0;
  
  int digit;
  
  int digitPos;
  
  String digits;
  
  int start;
  
  int end;
  
  BinaryDigitReader(int paramInt1, String paramString, int paramInt2, int paramInt3) {
    while (paramInt1 != 1) {
      this.lgBase++;
      paramInt1 >>= 1;
    } 
    this.digitPos = 0;
    this.digits = paramString;
    this.start = paramInt2;
    this.end = paramInt3;
  }
  
  int getNextBinaryDigit() {
    if (this.digitPos == 0) {
      if (this.start == this.end)
        return -1; 
      char c = this.digits.charAt(this.start++);
      if (c >= '0' && c <= '9') {
        this.digit = c - '0';
      } else if (c >= 'a' && c <= 'z') {
        this.digit = c - 'a' + '\n';
      } else {
        this.digit = c - 'A' + '\n';
      } 
      this.digitPos = this.lgBase;
    } 
    return this.digit >> --this.digitPos & true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\BinaryDigitReader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */