/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BinaryDigitReader
/*    */ {
/*    */   int digit;
/*    */   int digitPos;
/* 47 */   int lgBase = 0; BinaryDigitReader(int paramInt1, String paramString, int paramInt2, int paramInt3) {
/* 48 */     while (paramInt1 != 1) {
/* 49 */       this.lgBase++;
/* 50 */       paramInt1 >>= 1;
/*    */     } 
/* 52 */     this.digitPos = 0;
/* 53 */     this.digits = paramString;
/* 54 */     this.start = paramInt2;
/* 55 */     this.end = paramInt3;
/*    */   }
/*    */   String digits; int start;
/*    */   int end;
/*    */   
/*    */   int getNextBinaryDigit() {
/* 61 */     if (this.digitPos == 0) {
/* 62 */       if (this.start == this.end) {
/* 63 */         return -1;
/*    */       }
/* 65 */       char c = this.digits.charAt(this.start++);
/* 66 */       if (c >= '0' && c <= '9')
/* 67 */       { this.digit = c - '0'; }
/* 68 */       else if (c >= 'a' && c <= 'z')
/* 69 */       { this.digit = c - 'a' + '\n'; }
/* 70 */       else { this.digit = c - 'A' + '\n'; }
/* 71 */        this.digitPos = this.lgBase;
/*    */     } 
/* 73 */     return this.digit >> --this.digitPos & true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\BinaryDigitReader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */