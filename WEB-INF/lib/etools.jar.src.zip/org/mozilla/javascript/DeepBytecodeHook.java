package org.mozilla.javascript;

public interface DeepBytecodeHook {
  public static final int CONTINUE = 0;
  
  public static final int THROW = 1;
  
  public static final int RETURN_VALUE = 2;
  
  int interrupted(Context paramContext, int paramInt, Object[] paramArrayOfObject);
  
  int trapped(Context paramContext, int paramInt, Object[] paramArrayOfObject);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\DeepBytecodeHook.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */