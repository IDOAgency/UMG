package org.mozilla.javascript;

public interface DeepNewObjectHook {
  void postNewObject(Context paramContext, Object paramObject, Scriptable paramScriptable, Exception paramException);
  
  Object preNewObject(Context paramContext, Object paramObject, Object[] paramArrayOfObject);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\DeepNewObjectHook.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */