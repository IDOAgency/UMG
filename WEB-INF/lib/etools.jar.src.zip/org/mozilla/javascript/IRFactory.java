/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class IRFactory
/*      */ {
/*      */   private TokenStream ts;
/*      */   private Scriptable scope;
/*      */   
/*      */   public IRFactory(TokenStream paramTokenStream, Scriptable paramScriptable) {
/*   51 */     this.ts = paramTokenStream;
/*   52 */     this.scope = paramScriptable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createScript(Object paramObject1, String paramString, int paramInt1, int paramInt2, Object paramObject2) {
/*   61 */     Node node1 = new Node(145, paramString);
/*   62 */     Node node2 = ((Node)paramObject1).getFirstChild();
/*   63 */     if (node2 != null)
/*   64 */       node1.addChildrenToBack(node2); 
/*   65 */     node1.putProp(16, paramString);
/*   66 */     node1.putProp(28, new Integer(paramInt1));
/*   67 */     node1.putProp(29, new Integer(paramInt2));
/*   68 */     if (paramObject2 != null)
/*   69 */       node1.putProp(17, paramObject2); 
/*   70 */     return node1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   77 */   public Object createLeaf(int paramInt) { return new Node(paramInt); }
/*      */ 
/*      */ 
/*      */   
/*   81 */   public Object createLeaf(int paramInt, String paramString) { return new Node(paramInt, paramString); }
/*      */ 
/*      */ 
/*      */   
/*   85 */   public Object createLeaf(int paramInt1, int paramInt2) { return new Node(paramInt1, new Integer(paramInt2)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   93 */   public Object createSwitch(int paramInt) { return new Node(114, new Integer(paramInt)); }
/*      */ 
/*      */ 
/*      */   
/*   97 */   public Object createVariables(int paramInt) { return new Node(122, new Integer(paramInt)); }
/*      */ 
/*      */ 
/*      */   
/*  101 */   public Object createExprStatement(Object paramObject, int paramInt) { return new Node(139, (Node)paramObject, new Integer(paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  108 */   public Object createName(String paramString) { return new Node(44, paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  115 */   public Object createString(String paramString) { return new Node(46, paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  122 */   public Object createNumber(Number paramNumber) { return new Node(45, paramNumber); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createCatch(String paramString, Object paramObject1, Object paramObject2, int paramInt) {
/*  136 */     if (paramObject1 == null)
/*  137 */       paramObject1 = new Node(108, 
/*  138 */           new Integer(52)); 
/*  139 */     Node node = new Node(124, (Node)createName(paramString), 
/*  140 */         (Node)paramObject1, (Node)paramObject2);
/*  141 */     node.setDatum(new Integer(paramInt));
/*  142 */     return node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  149 */   public Object createThrow(Object paramObject, int paramInt) { return new Node(62, (Node)paramObject, new Integer(paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createReturn(Object paramObject, int paramInt) {
/*  156 */     return (paramObject == null) ? 
/*  157 */       new Node(5, new Integer(paramInt)) : 
/*  158 */       new Node(5, (Node)paramObject, new Integer(paramInt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createLabel(String paramString, int paramInt) {
/*  165 */     Node node1 = new Node(135, new Integer(paramInt));
/*  166 */     Node node2 = new Node(44, paramString);
/*  167 */     node1.addChildToBack(node2);
/*  168 */     return node1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createBreak(String paramString, int paramInt) {
/*  175 */     Node node1 = new Node(120, new Integer(paramInt));
/*  176 */     if (paramString == null) {
/*  177 */       return node1;
/*      */     }
/*  179 */     Node node2 = new Node(44, paramString);
/*  180 */     node1.addChildToBack(node2);
/*  181 */     return node1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createContinue(String paramString, int paramInt) {
/*  189 */     Node node1 = new Node(121, new Integer(paramInt));
/*  190 */     if (paramString == null) {
/*  191 */       return node1;
/*      */     }
/*  193 */     Node node2 = new Node(44, paramString);
/*  194 */     node1.addChildToBack(node2);
/*  195 */     return node1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  205 */   public Object createBlock(int paramInt) { return new Node(132, new Integer(paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createFunctionNode(String paramString, Object paramObject1, Object paramObject2) {
/*  211 */     if (paramString == null)
/*  212 */       paramString = ""; 
/*  213 */     return new FunctionNode(paramString, (Node)paramObject1, (Node)paramObject2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createFunction(String paramString1, Object paramObject1, Object paramObject2, String paramString2, int paramInt1, int paramInt2, Object paramObject3, boolean paramBoolean) {
/*  221 */     FunctionNode functionNode = (FunctionNode)createFunctionNode(paramString1, paramObject1, 
/*  222 */         paramObject2);
/*  223 */     functionNode.setFunctionType(paramBoolean ? 2 : 
/*  224 */         1);
/*  225 */     functionNode.putProp(16, paramString2);
/*  226 */     functionNode.putProp(28, new Integer(paramInt1));
/*  227 */     functionNode.putProp(29, new Integer(paramInt2));
/*  228 */     if (paramObject3 != null)
/*  229 */       functionNode.putProp(17, paramObject3); 
/*  230 */     Node node = new Node(109, paramString1);
/*  231 */     node.putProp(5, functionNode);
/*  232 */     return node;
/*      */   }
/*      */   
/*      */   public void setFunctionExpressionStatement(Object paramObject) {
/*  236 */     Node node = (Node)paramObject;
/*  237 */     FunctionNode functionNode = (FunctionNode)node.getProp(5);
/*  238 */     functionNode.setFunctionType((byte)3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  247 */   public void addChildToBack(Object paramObject1, Object paramObject2) { ((Node)paramObject1).addChildToBack((Node)paramObject2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createWhile(Object paramObject1, Object paramObject2, int paramInt) {
/*  255 */     Node node1 = (Node)createDoWhile(paramObject2, paramObject1, paramInt);
/*  256 */     Node node2 = (Node)node1.getProp(3);
/*  257 */     Node node3 = new Node(6);
/*  258 */     node3.putProp(1, node2);
/*  259 */     node1.addChildToFront(node3);
/*  260 */     return node1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createDoWhile(Object paramObject1, Object paramObject2, int paramInt) {
/*  267 */     Node node1 = new Node(137, new Integer(paramInt));
/*  268 */     Node node2 = new Node(136);
/*  269 */     Node node3 = new Node(136);
/*  270 */     Node node4 = new Node(7, (Node)paramObject2);
/*  271 */     node4.putProp(1, node2);
/*  272 */     Node node5 = new Node(136);
/*      */     
/*  274 */     node1.addChildToBack(node2);
/*  275 */     node1.addChildrenToBack((Node)paramObject1);
/*  276 */     node1.addChildToBack(node3);
/*  277 */     node1.addChildToBack(node4);
/*  278 */     node1.addChildToBack(node5);
/*      */     
/*  280 */     node1.putProp(2, node5);
/*  281 */     node1.putProp(3, node3);
/*      */     
/*  283 */     return node1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createFor(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, int paramInt) {
/*  292 */     if (((Node)paramObject2).getType() == 131) {
/*  293 */       paramObject2 = new Node(108, 
/*  294 */           new Integer(52));
/*      */     }
/*  296 */     Node node1 = (Node)createWhile(paramObject2, paramObject4, paramInt);
/*  297 */     Node node2 = (Node)paramObject1;
/*  298 */     if (node2.getType() != 131) {
/*  299 */       if (node2.getType() != 122)
/*  300 */         node2 = new Node(57, node2); 
/*  301 */       node1.addChildToFront(node2);
/*      */     } 
/*  303 */     Node node3 = (Node)node1.getProp(3);
/*  304 */     Node node4 = new Node(136);
/*  305 */     node1.addChildBefore(node4, node3);
/*  306 */     if (((Node)paramObject3).getType() != 131) {
/*  307 */       paramObject3 = createUnary(57, paramObject3);
/*  308 */       node1.addChildAfter((Node)paramObject3, node4);
/*      */     } 
/*  310 */     node1.putProp(3, node4);
/*  311 */     return node1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createForIn(Object paramObject1, Object paramObject2, Object paramObject3, int paramInt) {
/*  320 */     Node node1 = (Node)paramObject1;
/*  321 */     Node node2 = (Node)paramObject2;
/*  322 */     int i = node1.getType();
/*      */     
/*  324 */     Node node3 = node1;
/*  325 */     switch (i)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 122:
/*  339 */         node4 = node1.getLastChild();
/*  340 */         if (node1.getFirstChild() != node4) {
/*  341 */           reportError("msg.mult.index");
/*      */         }
/*  343 */         node3 = new Node(44, node4.getString());
/*      */         break;
/*      */       
/*      */       default:
/*  347 */         reportError("msg.bad.for.in.lhs");
/*  348 */         return node2;
/*      */       case 39: case 41:
/*      */       case 44:
/*  351 */         break; }  Node node4 = new Node(79, node2);
/*  352 */     Node node5 = new Node(80);
/*  353 */     node5.putProp(4, node4);
/*  354 */     Node node6 = createNewTemp(node5);
/*  355 */     Node node7 = new Node(101, new Integer(15));
/*  356 */     node7.addChildToBack(node6);
/*  357 */     node7.addChildToBack(new Node(108, 
/*  358 */           new Integer(49)));
/*  359 */     Node node8 = new Node(132);
/*  360 */     Node node9 = (Node)createAssignment(127, node3, 
/*  361 */         createUseTemp(node6), null, 
/*  362 */         false);
/*  363 */     node8.addChildToBack(new Node(57, node9));
/*  364 */     node8.addChildToBack((Node)paramObject3);
/*  365 */     Node node10 = (Node)createWhile(node7, node8, paramInt);
/*      */     
/*  367 */     node10.addChildToFront(node4);
/*  368 */     if (i == 122) {
/*  369 */       node10.addChildToFront(node1);
/*      */     }
/*  371 */     Node node11 = new Node(138);
/*  372 */     node11.putProp(4, node4);
/*  373 */     node10.addChildToBack(node11);
/*      */     
/*  375 */     return node10;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createTryCatchFinally(Object paramObject1, Object paramObject2, Object paramObject3, int paramInt) {
/*  399 */     Node node1 = (Node)paramObject1;
/*      */ 
/*      */     
/*  402 */     if (node1.getType() == 132 && !node1.hasChildren()) {
/*  403 */       return node1;
/*      */     }
/*  405 */     Node node2 = new Node(75, node1, new Integer(paramInt));
/*  406 */     Node node3 = (Node)paramObject2;
/*  407 */     boolean bool = node3.hasChildren();
/*  408 */     boolean bool1 = false;
/*  409 */     Node node4 = null;
/*  410 */     Node node5 = null;
/*  411 */     if (paramObject3 != null) {
/*  412 */       node4 = (Node)paramObject3;
/*  413 */       bool1 = (node4.getType() == 132 && 
/*  414 */         !node4.hasChildren()) ? 0 : 1;
/*  415 */       if (bool1) {
/*      */         
/*  417 */         node5 = new Node(136);
/*  418 */         node2.putProp(21, node5);
/*      */ 
/*      */         
/*  421 */         Node node = new Node(142);
/*  422 */         node.putProp(1, node5);
/*  423 */         node2.addChildToBack(node);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  428 */     if (!bool1 && !bool) {
/*  429 */       return node1;
/*      */     }
/*  431 */     Node node6 = new Node(136);
/*  432 */     Node node7 = new Node(6);
/*  433 */     node7.putProp(1, node6);
/*  434 */     node2.addChildToBack(node7);
/*      */     
/*  436 */     if (bool) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  471 */       Node node8 = new Node(136);
/*  472 */       node2.putProp(1, node8);
/*      */       
/*  474 */       node2.addChildToBack(node8);
/*      */ 
/*      */       
/*  477 */       Node node9 = createNewLocal(new Node(131));
/*  478 */       node2.addChildToBack(new Node(57, node9));
/*      */       
/*  480 */       Node node10 = new Node(136);
/*      */ 
/*      */ 
/*      */       
/*  484 */       Node node11 = node3.getFirstChild();
/*  485 */       while (node11 != null) {
/*  486 */         Node node13 = new Node(132);
/*  487 */         int i = ((Integer)node11.getDatum()).intValue();
/*      */         
/*  489 */         Node node14 = node11.getFirstChild();
/*  490 */         Node node15 = node14.getNextSibling();
/*  491 */         Node node16 = node15.getNextSibling();
/*  492 */         node11.removeChild(node14);
/*  493 */         node11.removeChild(node15);
/*  494 */         node11.removeChild(node16);
/*      */         
/*  496 */         Node node17 = createNewLocal(new Node(77));
/*  497 */         Node node18 = new Node(40, node17, 
/*  498 */             new Node(46, 
/*  499 */               node14.getString()), 
/*  500 */             createUseLocal(node9));
/*  501 */         node13.addChildToBack(new Node(57, node18));
/*      */         
/*  503 */         node16.addChildToBack(new Node(4));
/*  504 */         Node node19 = new Node(6);
/*  505 */         node19.putProp(1, node10);
/*  506 */         node16.addChildToBack(node19);
/*      */         
/*  508 */         Node node20 = (Node)createIf(node15, node16, null, i);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  514 */         Node node21 = (Node)createWith(createUseLocal(node17), 
/*  515 */             node20, i);
/*  516 */         node13.addChildToBack(node21);
/*      */         
/*  518 */         node2.addChildToBack(node13);
/*      */ 
/*      */         
/*  521 */         node11 = node11.getNextSibling();
/*      */       } 
/*      */ 
/*      */       
/*  525 */       Node node12 = new Node(62, createUseLocal(node9));
/*  526 */       node2.addChildToBack(node12);
/*      */       
/*  528 */       node2.addChildToBack(node10);
/*      */       
/*  530 */       if (bool1) {
/*  531 */         Node node13 = new Node(142);
/*  532 */         node13.putProp(1, node5);
/*  533 */         node2.addChildToBack(node13);
/*  534 */         Node node14 = new Node(6);
/*  535 */         node14.putProp(1, node6);
/*  536 */         node2.addChildToBack(node14);
/*      */       } 
/*      */     } 
/*      */     
/*  540 */     if (bool1) {
/*  541 */       node2.addChildToBack(node5);
/*  542 */       Node node8 = createNewLocal(new Node(131));
/*  543 */       Node node9 = new Node(57, node8);
/*  544 */       node2.addChildToBack(node9);
/*  545 */       node2.addChildToBack(node4);
/*  546 */       Node node10 = createUseLocal(node8);
/*      */ 
/*      */       
/*  549 */       node10.putProp(1, Boolean.TRUE);
/*  550 */       node2.addChildToBack(node10);
/*      */     } 
/*  552 */     node2.addChildToBack(node6);
/*  553 */     return node2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createWith(Object paramObject1, Object paramObject2, int paramInt) {
/*  564 */     Node node1 = new Node(132, new Integer(paramInt));
/*  565 */     node1.addChildToBack(new Node(3, (Node)paramObject1));
/*  566 */     Node node2 = new Node(123, (Node)paramObject2, 
/*  567 */         new Integer(paramInt));
/*  568 */     node1.addChildrenToBack(node2);
/*  569 */     node1.addChildToBack(new Node(4));
/*  570 */     return node1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createArrayLiteral(Object paramObject) {
/*  582 */     Node node2 = new Node(30, 
/*  583 */         new Node(44, "Array")), node1 = node2;
/*  584 */     Node node3 = createNewTemp(node2);
/*  585 */     node2 = node3;
/*      */     
/*  587 */     ShallowNodeIterator shallowNodeIterator = ((Node)paramObject).getChildIterator();
/*      */     
/*  589 */     Node node4 = null;
/*  590 */     byte b = 0;
/*  591 */     while (shallowNodeIterator.hasMoreElements()) {
/*  592 */       node4 = (Node)shallowNodeIterator.nextElement();
/*  593 */       if (node4.getType() == 108 && 
/*  594 */         node4.getInt() == 74) {
/*      */         
/*  596 */         b++;
/*      */         continue;
/*      */       } 
/*  599 */       Node node = new Node(42, createUseTemp(node3), 
/*  600 */           new Node(45, 
/*  601 */             new Integer(b)), 
/*  602 */           node4);
/*  603 */       b++;
/*  604 */       node2 = new Node(95, node2, node);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  617 */     if (Context.getContext().getLanguageVersion() == 120) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  622 */       if (node4 != null && 
/*  623 */         node4.getType() == 108 && 
/*  624 */         node4.getInt() == 74) {
/*      */         
/*  626 */         Node node = new Node(40, 
/*  627 */             createUseTemp(node3), 
/*  628 */             new Node(46, 
/*  629 */               "length"), 
/*  630 */             new Node(45, 
/*  631 */               new Integer(b)));
/*  632 */         node2 = new Node(95, node2, node);
/*      */       } 
/*      */     } else {
/*  635 */       node1.addChildToBack(new Node(45, 
/*  636 */             new Integer(b)));
/*      */     } 
/*  638 */     return new Node(95, node2, createUseTemp(node3));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createObjectLiteral(Object paramObject) {
/*  648 */     Node node1 = new Node(30, new Node(44, 
/*  649 */           "Object"));
/*  650 */     Node node2 = createNewTemp(node1);
/*  651 */     node1 = node2;
/*      */     
/*  653 */     ShallowNodeIterator shallowNodeIterator = ((Node)paramObject).getChildIterator();
/*      */     
/*  655 */     while (shallowNodeIterator.hasMoreElements()) {
/*  656 */       Node node3 = (Node)shallowNodeIterator.nextElement();
/*      */       
/*  658 */       byte b = (node3.getType() == 44) ? 
/*  659 */         40 : 
/*  660 */         42;
/*  661 */       Node node4 = new Node(b, createUseTemp(node2), 
/*  662 */           node3, (Node)shallowNodeIterator.nextElement());
/*  663 */       node1 = new Node(95, node1, node4);
/*      */     } 
/*  665 */     return new Node(95, node1, createUseTemp(node2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createRegExp(String paramString1, String paramString2) {
/*  672 */     if (paramString2.length() == 0) {  } else {  }  return 
/*      */ 
/*      */       
/*  675 */       new Node(56, 
/*  676 */         new Node(46, paramString1), 
/*  677 */         new Node(46, paramString2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createIf(Object paramObject1, Object paramObject2, Object paramObject3, int paramInt) {
/*  686 */     Node node1 = new Node(132, new Integer(paramInt));
/*  687 */     Node node2 = new Node(136);
/*  688 */     Node node3 = new Node(8, (Node)paramObject1);
/*  689 */     node3.putProp(1, node2);
/*      */     
/*  691 */     node1.addChildToBack(node3);
/*  692 */     node1.addChildrenToBack((Node)paramObject2);
/*      */     
/*  694 */     if (paramObject3 != null) {
/*  695 */       Node node4 = new Node(6);
/*  696 */       Node node5 = new Node(136);
/*  697 */       node4.putProp(1, node5);
/*  698 */       node1.addChildToBack(node4);
/*  699 */       node1.addChildToBack(node2);
/*  700 */       node1.addChildrenToBack((Node)paramObject3);
/*  701 */       node1.addChildToBack(node5);
/*      */     } else {
/*  703 */       node1.addChildToBack(node2);
/*      */     } 
/*      */     
/*  706 */     return node1;
/*      */   }
/*      */ 
/*      */   
/*  710 */   public Object createTernary(Object paramObject1, Object paramObject2, Object paramObject3) { return createIf(paramObject1, paramObject2, paramObject3, -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createUnary(int paramInt, Object paramObject) {
/*  717 */     Node node = (Node)paramObject;
/*  718 */     if (paramInt == 31) {
/*  719 */       Node node2, node1; int i = node.getType();
/*      */ 
/*      */       
/*  722 */       if (i == 44) {
/*      */ 
/*      */         
/*  725 */         node.setType(61);
/*  726 */         node1 = node;
/*  727 */         node2 = node.cloneNode();
/*  728 */         node2.setType(46);
/*  729 */       } else if (i == 39 || 
/*  730 */         i == 41) {
/*      */         
/*  732 */         node1 = node.getFirstChild();
/*  733 */         node2 = node.getLastChild();
/*  734 */         node.removeChild(node1);
/*  735 */         node.removeChild(node2);
/*      */       } else {
/*  737 */         return new Node(108, 
/*  738 */             new Integer(52));
/*      */       } 
/*  740 */       return new Node(paramInt, node1, node2);
/*      */     } 
/*  742 */     return new Node(paramInt, node);
/*      */   }
/*      */   
/*      */   public Object createUnary(int paramInt1, int paramInt2, Object paramObject) {
/*  746 */     Node node1 = (Node)paramObject;
/*  747 */     int i = node1.getType();
/*  748 */     if (paramInt2 == 32 && 
/*  749 */       i == 44) {
/*      */       
/*  751 */       node1.setType(32);
/*  752 */       return node1;
/*      */     } 
/*      */     
/*  755 */     if (paramInt1 == 105 || paramInt1 == 106) {
/*      */       
/*  757 */       if (!hasSideEffects(node1) && 
/*  758 */         paramInt2 == 130 && (
/*  759 */         i == 44 || 
/*  760 */         i == 39 || 
/*  761 */         i == 41))
/*      */       {
/*      */ 
/*      */         
/*  765 */         return new Node(paramInt1, node1);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  775 */       Node node = (Node)createNumber(new Double(1.0D));
/*      */       
/*  777 */       return createAssignment((paramInt1 == 105) ? 
/*  778 */           23 : 
/*  779 */           24, 
/*  780 */           node1, 
/*  781 */           node, 
/*  782 */           ScriptRuntime.NumberClass, 
/*  783 */           !(paramInt2 != 130));
/*      */     } 
/*      */     
/*  786 */     Node node2 = new Node(paramInt1, new Integer(paramInt2));
/*  787 */     node2.addChildToBack((Node)paramObject);
/*  788 */     return node2;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createBinary(int paramInt, Object paramObject1, Object paramObject2) {
/*      */     String str;
/*      */     Node node;
/*  796 */     switch (paramInt) {
/*      */       
/*      */       case 107:
/*  799 */         paramInt = 39;
/*  800 */         node = (Node)paramObject2;
/*  801 */         node.setType(46);
/*  802 */         str = node.getString();
/*  803 */         if (str.equals("__proto__") || str.equals("__parent__")) {
/*  804 */           Node node1 = new Node(paramInt, (Node)paramObject1);
/*  805 */           node1.putProp(19, str);
/*  806 */           return node1;
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 89:
/*  812 */         paramInt = 41;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  824 */     return new Node(paramInt, (Node)paramObject1, (Node)paramObject2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object createBinary(int paramInt1, int paramInt2, Object paramObject1, Object paramObject2) {
/*  830 */     if (paramInt1 == 96) {
/*  831 */       return createAssignment(paramInt2, (Node)paramObject1, (Node)paramObject2, 
/*  832 */           null, false);
/*      */     }
/*  834 */     return new Node(paramInt1, (Node)paramObject1, (Node)paramObject2, 
/*  835 */         new Integer(paramInt2));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object createAssignment(int paramInt, Node paramNode1, Node paramNode2, Class paramClass, boolean paramBoolean) {
/*      */     String str;
/*  841 */     int i = paramNode1.getType();
/*      */     
/*  843 */     Node node = null;
/*  844 */     switch (i) {
/*      */       case 44:
/*  846 */         return createSetName(paramInt, paramNode1, paramNode2, paramClass, paramBoolean);
/*      */       
/*      */       case 39:
/*  849 */         str = (String)paramNode1.getProp(19);
/*  850 */         if (str != null) {
/*  851 */           node = new Node(46, str);
/*      */         }
/*      */       case 41:
/*  854 */         if (node == null)
/*  855 */           node = paramNode1.getLastChild(); 
/*  856 */         return createSetProp(i, paramInt, paramNode1.getFirstChild(), 
/*  857 */             node, paramNode2, paramClass, paramBoolean);
/*      */     } 
/*      */ 
/*      */     
/*  861 */     reportError("msg.bad.lhs.assign");
/*  862 */     return paramNode1;
/*      */   }
/*      */ 
/*      */   
/*      */   private Node createConvert(Class paramClass, Node paramNode) {
/*  867 */     if (paramClass == null)
/*  868 */       return paramNode; 
/*  869 */     Node node = new Node(141, paramNode);
/*  870 */     node.putProp(18, ScriptRuntime.NumberClass);
/*  871 */     return node;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object createSetName(int paramInt, Node paramNode1, Node paramNode2, Class paramClass, boolean paramBoolean) {
/*  877 */     if (paramInt == 127) {
/*  878 */       paramNode1.setType(61);
/*  879 */       return new Node(10, paramNode1, paramNode2);
/*      */     } 
/*      */     
/*  882 */     String str = paramNode1.getString();
/*      */     
/*  884 */     if (str.equals("__proto__") || str.equals("__parent__")) {
/*  885 */       Node node = new Node(40, paramNode1, paramNode2);
/*  886 */       node.putProp(19, str);
/*  887 */       return node;
/*      */     } 
/*      */     
/*  890 */     Node node1 = new Node(44, str);
/*  891 */     if (paramClass != null)
/*  892 */       node1 = createConvert(paramClass, node1); 
/*  893 */     if (paramBoolean)
/*  894 */       node1 = createNewTemp(node1); 
/*  895 */     Node node2 = new Node(paramInt, node1, paramNode2);
/*      */     
/*  897 */     Node node3 = new Node(61, str);
/*  898 */     Node node4 = new Node(10, node3, node2);
/*  899 */     if (paramBoolean) {
/*  900 */       node4 = new Node(95, node4, 
/*  901 */           createUseTemp(node1));
/*      */     }
/*  903 */     return node4;
/*      */   }
/*      */   
/*      */   public Node createNewTemp(Node paramNode) {
/*  907 */     int i = paramNode.getType();
/*  908 */     if (i == 46 || i == 45)
/*      */     {
/*      */       
/*  911 */       return paramNode;
/*      */     }
/*  913 */     return new Node(69, paramNode);
/*      */   }
/*      */ 
/*      */   
/*      */   public Node createUseTemp(Node paramNode) {
/*  918 */     int i = paramNode.getType();
/*  919 */     if (i == 69) {
/*  920 */       Node node = new Node(70);
/*  921 */       node.putProp(6, paramNode);
/*  922 */       Integer integer = (Integer)paramNode.getProp(11);
/*  923 */       if (integer == null) {
/*  924 */         integer = new Integer(1);
/*      */       }
/*  926 */       else if (integer.intValue() < Integer.MAX_VALUE) {
/*  927 */         integer = new Integer(integer.intValue() + 1);
/*      */       } 
/*  929 */       paramNode.putProp(11, integer);
/*  930 */       return node;
/*      */     } 
/*  932 */     return paramNode.cloneNode();
/*      */   }
/*      */ 
/*      */   
/*  936 */   public Node createNewLocal(Node paramNode) { return new Node(143, paramNode); }
/*      */ 
/*      */ 
/*      */   
/*      */   public Node createUseLocal(Node paramNode) {
/*  941 */     int i = paramNode.getType();
/*  942 */     if (i == 143) {
/*  943 */       Node node = new Node(144);
/*  944 */       node.putProp(7, paramNode);
/*  945 */       return node;
/*      */     } 
/*  947 */     return paramNode.cloneNode();
/*      */   }
/*      */   
/*      */   public static boolean hasSideEffects(Node paramNode) {
/*  951 */     switch (paramNode.getType()) {
/*      */       case 10:
/*      */       case 30:
/*      */       case 40:
/*      */       case 42:
/*      */       case 43:
/*      */       case 105:
/*      */       case 106:
/*  959 */         return true;
/*      */     } 
/*  961 */     Node node = paramNode.getFirstChild();
/*  962 */     while (node != null) {
/*  963 */       if (hasSideEffects(node)) {
/*  964 */         return true;
/*      */       }
/*  966 */       node = node.getNextSibling();
/*      */     } 
/*      */ 
/*      */     
/*  970 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private Node createSetProp(int paramInt1, int paramInt2, Node paramNode1, Node paramNode2, Node paramNode3, Class paramClass, boolean paramBoolean) {
/*      */     Node node3, node2, node1;
/*  976 */     byte b = (paramInt1 == 39) ? 
/*  977 */       40 : 
/*  978 */       42;
/*      */     
/*  980 */     Object object = paramNode2.getDatum();
/*  981 */     if (b == 40 && object != null && 
/*  982 */       object instanceof String) {
/*      */       
/*  984 */       node1 = (String)object;
/*  985 */       if (node1.equals("__proto__") || node1.equals("__parent__")) {
/*  986 */         node2 = new Node(b, paramNode1, paramNode3);
/*  987 */         node2.putProp(19, node1);
/*  988 */         return node2;
/*      */       } 
/*      */     } 
/*      */     
/*  992 */     if (paramInt2 == 127) {
/*  993 */       return new Node(b, paramNode1, paramNode2, paramNode3);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1006 */     if (hasSideEffects(paramNode3) || 
/* 1007 */       hasSideEffects(paramNode2) || 
/* 1008 */       paramNode1.getType() != 44) {
/* 1009 */       node1 = createNewTemp(paramNode1);
/* 1010 */       Node node6 = createUseTemp(node1);
/*      */       
/* 1012 */       node2 = createNewTemp(paramNode2);
/* 1013 */       Node node7 = createUseTemp(node2);
/*      */       
/* 1015 */       node3 = new Node(paramInt1, node6, node7);
/*      */     } else {
/* 1017 */       node1 = paramNode1.cloneNode();
/* 1018 */       node2 = paramNode2.cloneNode();
/* 1019 */       node3 = new Node(paramInt1, paramNode1, paramNode2);
/*      */     } 
/*      */     
/* 1022 */     if (paramClass != null)
/* 1023 */       node3 = createConvert(paramClass, node3); 
/* 1024 */     if (paramBoolean)
/* 1025 */       node3 = createNewTemp(node3); 
/* 1026 */     Node node4 = new Node(paramInt2, node3, paramNode3);
/*      */     
/* 1028 */     Node node5 = new Node(b, node1, node2, node4);
/* 1029 */     if (paramBoolean) {
/* 1030 */       node5 = new Node(95, node5, 
/* 1031 */           createUseTemp(node3));
/*      */     }
/*      */     
/* 1034 */     return node5;
/*      */   }
/*      */ 
/*      */   
/*      */   private void reportError(String paramString) {
/* 1039 */     if (this.scope != null) {
/* 1040 */       throw NativeGlobal.constructError(
/* 1041 */           Context.getContext(), "SyntaxError", 
/* 1042 */           ScriptRuntime.getMessage(paramString, null), 
/* 1043 */           this.scope);
/*      */     }
/* 1045 */     String str = Context.getMessage(paramString, null);
/* 1046 */     Context.reportError(str, this.ts.getSourceName(), this.ts.getLineno(), 
/* 1047 */         this.ts.getLine(), this.ts.getOffset());
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\IRFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */