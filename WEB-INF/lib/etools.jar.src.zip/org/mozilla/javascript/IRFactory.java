package org.mozilla.javascript;

public class IRFactory {
  private TokenStream ts;
  
  private Scriptable scope;
  
  public IRFactory(TokenStream paramTokenStream, Scriptable paramScriptable) {
    this.ts = paramTokenStream;
    this.scope = paramScriptable;
  }
  
  public Object createScript(Object paramObject1, String paramString, int paramInt1, int paramInt2, Object paramObject2) {
    Node node1 = new Node(145, paramString);
    Node node2 = ((Node)paramObject1).getFirstChild();
    if (node2 != null)
      node1.addChildrenToBack(node2); 
    node1.putProp(16, paramString);
    node1.putProp(28, new Integer(paramInt1));
    node1.putProp(29, new Integer(paramInt2));
    if (paramObject2 != null)
      node1.putProp(17, paramObject2); 
    return node1;
  }
  
  public Object createLeaf(int paramInt) { return new Node(paramInt); }
  
  public Object createLeaf(int paramInt, String paramString) { return new Node(paramInt, paramString); }
  
  public Object createLeaf(int paramInt1, int paramInt2) { return new Node(paramInt1, new Integer(paramInt2)); }
  
  public Object createSwitch(int paramInt) { return new Node(114, new Integer(paramInt)); }
  
  public Object createVariables(int paramInt) { return new Node(122, new Integer(paramInt)); }
  
  public Object createExprStatement(Object paramObject, int paramInt) { return new Node(139, (Node)paramObject, new Integer(paramInt)); }
  
  public Object createName(String paramString) { return new Node(44, paramString); }
  
  public Object createString(String paramString) { return new Node(46, paramString); }
  
  public Object createNumber(Number paramNumber) { return new Node(45, paramNumber); }
  
  public Object createCatch(String paramString, Object paramObject1, Object paramObject2, int paramInt) {
    if (paramObject1 == null)
      paramObject1 = new Node(108, 
          new Integer(52)); 
    Node node = new Node(124, (Node)createName(paramString), 
        (Node)paramObject1, (Node)paramObject2);
    node.setDatum(new Integer(paramInt));
    return node;
  }
  
  public Object createThrow(Object paramObject, int paramInt) { return new Node(62, (Node)paramObject, new Integer(paramInt)); }
  
  public Object createReturn(Object paramObject, int paramInt) {
    return (paramObject == null) ? 
      new Node(5, new Integer(paramInt)) : 
      new Node(5, (Node)paramObject, new Integer(paramInt));
  }
  
  public Object createLabel(String paramString, int paramInt) {
    Node node1 = new Node(135, new Integer(paramInt));
    Node node2 = new Node(44, paramString);
    node1.addChildToBack(node2);
    return node1;
  }
  
  public Object createBreak(String paramString, int paramInt) {
    Node node1 = new Node(120, new Integer(paramInt));
    if (paramString == null)
      return node1; 
    Node node2 = new Node(44, paramString);
    node1.addChildToBack(node2);
    return node1;
  }
  
  public Object createContinue(String paramString, int paramInt) {
    Node node1 = new Node(121, new Integer(paramInt));
    if (paramString == null)
      return node1; 
    Node node2 = new Node(44, paramString);
    node1.addChildToBack(node2);
    return node1;
  }
  
  public Object createBlock(int paramInt) { return new Node(132, new Integer(paramInt)); }
  
  public Object createFunctionNode(String paramString, Object paramObject1, Object paramObject2) {
    if (paramString == null)
      paramString = ""; 
    return new FunctionNode(paramString, (Node)paramObject1, (Node)paramObject2);
  }
  
  public Object createFunction(String paramString1, Object paramObject1, Object paramObject2, String paramString2, int paramInt1, int paramInt2, Object paramObject3, boolean paramBoolean) {
    FunctionNode functionNode = (FunctionNode)createFunctionNode(paramString1, paramObject1, 
        paramObject2);
    functionNode.setFunctionType(paramBoolean ? 2 : 
        1);
    functionNode.putProp(16, paramString2);
    functionNode.putProp(28, new Integer(paramInt1));
    functionNode.putProp(29, new Integer(paramInt2));
    if (paramObject3 != null)
      functionNode.putProp(17, paramObject3); 
    Node node = new Node(109, paramString1);
    node.putProp(5, functionNode);
    return node;
  }
  
  public void setFunctionExpressionStatement(Object paramObject) {
    Node node = (Node)paramObject;
    FunctionNode functionNode = (FunctionNode)node.getProp(5);
    functionNode.setFunctionType((byte)3);
  }
  
  public void addChildToBack(Object paramObject1, Object paramObject2) { ((Node)paramObject1).addChildToBack((Node)paramObject2); }
  
  public Object createWhile(Object paramObject1, Object paramObject2, int paramInt) {
    Node node1 = (Node)createDoWhile(paramObject2, paramObject1, paramInt);
    Node node2 = (Node)node1.getProp(3);
    Node node3 = new Node(6);
    node3.putProp(1, node2);
    node1.addChildToFront(node3);
    return node1;
  }
  
  public Object createDoWhile(Object paramObject1, Object paramObject2, int paramInt) {
    Node node1 = new Node(137, new Integer(paramInt));
    Node node2 = new Node(136);
    Node node3 = new Node(136);
    Node node4 = new Node(7, (Node)paramObject2);
    node4.putProp(1, node2);
    Node node5 = new Node(136);
    node1.addChildToBack(node2);
    node1.addChildrenToBack((Node)paramObject1);
    node1.addChildToBack(node3);
    node1.addChildToBack(node4);
    node1.addChildToBack(node5);
    node1.putProp(2, node5);
    node1.putProp(3, node3);
    return node1;
  }
  
  public Object createFor(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, int paramInt) {
    if (((Node)paramObject2).getType() == 131)
      paramObject2 = new Node(108, 
          new Integer(52)); 
    Node node1 = (Node)createWhile(paramObject2, paramObject4, paramInt);
    Node node2 = (Node)paramObject1;
    if (node2.getType() != 131) {
      if (node2.getType() != 122)
        node2 = new Node(57, node2); 
      node1.addChildToFront(node2);
    } 
    Node node3 = (Node)node1.getProp(3);
    Node node4 = new Node(136);
    node1.addChildBefore(node4, node3);
    if (((Node)paramObject3).getType() != 131) {
      paramObject3 = createUnary(57, paramObject3);
      node1.addChildAfter((Node)paramObject3, node4);
    } 
    node1.putProp(3, node4);
    return node1;
  }
  
  public Object createForIn(Object paramObject1, Object paramObject2, Object paramObject3, int paramInt) {
    Node node1 = (Node)paramObject1;
    Node node2 = (Node)paramObject2;
    int i = node1.getType();
    Node node3 = node1;
    switch (i) {
      case 122:
        node4 = node1.getLastChild();
        if (node1.getFirstChild() != node4)
          reportError("msg.mult.index"); 
        node3 = new Node(44, node4.getString());
        break;
      default:
        reportError("msg.bad.for.in.lhs");
        return node2;
      case 39:
      case 41:
      case 44:
        break;
    } 
    Node node4 = new Node(79, node2);
    Node node5 = new Node(80);
    node5.putProp(4, node4);
    Node node6 = createNewTemp(node5);
    Node node7 = new Node(101, new Integer(15));
    node7.addChildToBack(node6);
    node7.addChildToBack(new Node(108, 
          new Integer(49)));
    Node node8 = new Node(132);
    Node node9 = (Node)createAssignment(127, node3, 
        createUseTemp(node6), null, 
        false);
    node8.addChildToBack(new Node(57, node9));
    node8.addChildToBack((Node)paramObject3);
    Node node10 = (Node)createWhile(node7, node8, paramInt);
    node10.addChildToFront(node4);
    if (i == 122)
      node10.addChildToFront(node1); 
    Node node11 = new Node(138);
    node11.putProp(4, node4);
    node10.addChildToBack(node11);
    return node10;
  }
  
  public Object createTryCatchFinally(Object paramObject1, Object paramObject2, Object paramObject3, int paramInt) {
    Node node1 = (Node)paramObject1;
    if (node1.getType() == 132 && !node1.hasChildren())
      return node1; 
    Node node2 = new Node(75, node1, new Integer(paramInt));
    Node node3 = (Node)paramObject2;
    boolean bool = node3.hasChildren();
    boolean bool1 = false;
    Node node4 = null;
    Node node5 = null;
    if (paramObject3 != null) {
      node4 = (Node)paramObject3;
      bool1 = (node4.getType() == 132 && 
        !node4.hasChildren()) ? 0 : 1;
      if (bool1) {
        node5 = new Node(136);
        node2.putProp(21, node5);
        Node node = new Node(142);
        node.putProp(1, node5);
        node2.addChildToBack(node);
      } 
    } 
    if (!bool1 && !bool)
      return node1; 
    Node node6 = new Node(136);
    Node node7 = new Node(6);
    node7.putProp(1, node6);
    node2.addChildToBack(node7);
    if (bool) {
      Node node8 = new Node(136);
      node2.putProp(1, node8);
      node2.addChildToBack(node8);
      Node node9 = createNewLocal(new Node(131));
      node2.addChildToBack(new Node(57, node9));
      Node node10 = new Node(136);
      Node node11 = node3.getFirstChild();
      while (node11 != null) {
        Node node13 = new Node(132);
        int i = ((Integer)node11.getDatum()).intValue();
        Node node14 = node11.getFirstChild();
        Node node15 = node14.getNextSibling();
        Node node16 = node15.getNextSibling();
        node11.removeChild(node14);
        node11.removeChild(node15);
        node11.removeChild(node16);
        Node node17 = createNewLocal(new Node(77));
        Node node18 = new Node(40, node17, 
            new Node(46, 
              node14.getString()), 
            createUseLocal(node9));
        node13.addChildToBack(new Node(57, node18));
        node16.addChildToBack(new Node(4));
        Node node19 = new Node(6);
        node19.putProp(1, node10);
        node16.addChildToBack(node19);
        Node node20 = (Node)createIf(node15, node16, null, i);
        Node node21 = (Node)createWith(createUseLocal(node17), 
            node20, i);
        node13.addChildToBack(node21);
        node2.addChildToBack(node13);
        node11 = node11.getNextSibling();
      } 
      Node node12 = new Node(62, createUseLocal(node9));
      node2.addChildToBack(node12);
      node2.addChildToBack(node10);
      if (bool1) {
        Node node13 = new Node(142);
        node13.putProp(1, node5);
        node2.addChildToBack(node13);
        Node node14 = new Node(6);
        node14.putProp(1, node6);
        node2.addChildToBack(node14);
      } 
    } 
    if (bool1) {
      node2.addChildToBack(node5);
      Node node8 = createNewLocal(new Node(131));
      Node node9 = new Node(57, node8);
      node2.addChildToBack(node9);
      node2.addChildToBack(node4);
      Node node10 = createUseLocal(node8);
      node10.putProp(1, Boolean.TRUE);
      node2.addChildToBack(node10);
    } 
    node2.addChildToBack(node6);
    return node2;
  }
  
  public Object createWith(Object paramObject1, Object paramObject2, int paramInt) {
    Node node1 = new Node(132, new Integer(paramInt));
    node1.addChildToBack(new Node(3, (Node)paramObject1));
    Node node2 = new Node(123, (Node)paramObject2, 
        new Integer(paramInt));
    node1.addChildrenToBack(node2);
    node1.addChildToBack(new Node(4));
    return node1;
  }
  
  public Object createArrayLiteral(Object paramObject) {
    Node node2 = new Node(30, 
        new Node(44, "Array")), node1 = node2;
    Node node3 = createNewTemp(node2);
    node2 = node3;
    ShallowNodeIterator shallowNodeIterator = ((Node)paramObject).getChildIterator();
    Node node4 = null;
    byte b = 0;
    while (shallowNodeIterator.hasMoreElements()) {
      node4 = (Node)shallowNodeIterator.nextElement();
      if (node4.getType() == 108 && 
        node4.getInt() == 74) {
        b++;
        continue;
      } 
      Node node = new Node(42, createUseTemp(node3), 
          new Node(45, 
            new Integer(b)), 
          node4);
      b++;
      node2 = new Node(95, node2, node);
    } 
    if (Context.getContext().getLanguageVersion() == 120) {
      if (node4 != null && 
        node4.getType() == 108 && 
        node4.getInt() == 74) {
        Node node = new Node(40, 
            createUseTemp(node3), 
            new Node(46, 
              "length"), 
            new Node(45, 
              new Integer(b)));
        node2 = new Node(95, node2, node);
      } 
    } else {
      node1.addChildToBack(new Node(45, 
            new Integer(b)));
    } 
    return new Node(95, node2, createUseTemp(node3));
  }
  
  public Object createObjectLiteral(Object paramObject) {
    Node node1 = new Node(30, new Node(44, 
          "Object"));
    Node node2 = createNewTemp(node1);
    node1 = node2;
    ShallowNodeIterator shallowNodeIterator = ((Node)paramObject).getChildIterator();
    while (shallowNodeIterator.hasMoreElements()) {
      Node node3 = (Node)shallowNodeIterator.nextElement();
      byte b = (node3.getType() == 44) ? 
        40 : 
        42;
      Node node4 = new Node(b, createUseTemp(node2), 
          node3, (Node)shallowNodeIterator.nextElement());
      node1 = new Node(95, node1, node4);
    } 
    return new Node(95, node1, createUseTemp(node2));
  }
  
  public Object createRegExp(String paramString1, String paramString2) {
    if (paramString2.length() == 0) {
    
    } else {
    
    } 
    return 
      
      new Node(56, 
        new Node(46, paramString1), 
        new Node(46, paramString2));
  }
  
  public Object createIf(Object paramObject1, Object paramObject2, Object paramObject3, int paramInt) {
    Node node1 = new Node(132, new Integer(paramInt));
    Node node2 = new Node(136);
    Node node3 = new Node(8, (Node)paramObject1);
    node3.putProp(1, node2);
    node1.addChildToBack(node3);
    node1.addChildrenToBack((Node)paramObject2);
    if (paramObject3 != null) {
      Node node4 = new Node(6);
      Node node5 = new Node(136);
      node4.putProp(1, node5);
      node1.addChildToBack(node4);
      node1.addChildToBack(node2);
      node1.addChildrenToBack((Node)paramObject3);
      node1.addChildToBack(node5);
    } else {
      node1.addChildToBack(node2);
    } 
    return node1;
  }
  
  public Object createTernary(Object paramObject1, Object paramObject2, Object paramObject3) { return createIf(paramObject1, paramObject2, paramObject3, -1); }
  
  public Object createUnary(int paramInt, Object paramObject) {
    Node node = (Node)paramObject;
    if (paramInt == 31) {
      Node node2, node1;
      int i = node.getType();
      if (i == 44) {
        node.setType(61);
        node1 = node;
        node2 = node.cloneNode();
        node2.setType(46);
      } else if (i == 39 || 
        i == 41) {
        node1 = node.getFirstChild();
        node2 = node.getLastChild();
        node.removeChild(node1);
        node.removeChild(node2);
      } else {
        return new Node(108, 
            new Integer(52));
      } 
      return new Node(paramInt, node1, node2);
    } 
    return new Node(paramInt, node);
  }
  
  public Object createUnary(int paramInt1, int paramInt2, Object paramObject) {
    Node node1 = (Node)paramObject;
    int i = node1.getType();
    if (paramInt2 == 32 && 
      i == 44) {
      node1.setType(32);
      return node1;
    } 
    if (paramInt1 == 105 || paramInt1 == 106) {
      if (!hasSideEffects(node1) && 
        paramInt2 == 130 && (
        i == 44 || 
        i == 39 || 
        i == 41))
        return new Node(paramInt1, node1); 
      Node node = (Node)createNumber(new Double(1.0D));
      return createAssignment((paramInt1 == 105) ? 
          23 : 
          24, 
          node1, 
          node, 
          ScriptRuntime.NumberClass, 
          !(paramInt2 != 130));
    } 
    Node node2 = new Node(paramInt1, new Integer(paramInt2));
    node2.addChildToBack((Node)paramObject);
    return node2;
  }
  
  public Object createBinary(int paramInt, Object paramObject1, Object paramObject2) {
    String str;
    Node node;
    switch (paramInt) {
      case 107:
        paramInt = 39;
        node = (Node)paramObject2;
        node.setType(46);
        str = node.getString();
        if (str.equals("__proto__") || str.equals("__parent__")) {
          Node node1 = new Node(paramInt, (Node)paramObject1);
          node1.putProp(19, str);
          return node1;
        } 
        break;
      case 89:
        paramInt = 41;
        break;
    } 
    return new Node(paramInt, (Node)paramObject1, (Node)paramObject2);
  }
  
  public Object createBinary(int paramInt1, int paramInt2, Object paramObject1, Object paramObject2) {
    if (paramInt1 == 96)
      return createAssignment(paramInt2, (Node)paramObject1, (Node)paramObject2, 
          null, false); 
    return new Node(paramInt1, (Node)paramObject1, (Node)paramObject2, 
        new Integer(paramInt2));
  }
  
  public Object createAssignment(int paramInt, Node paramNode1, Node paramNode2, Class paramClass, boolean paramBoolean) {
    String str;
    int i = paramNode1.getType();
    Node node = null;
    switch (i) {
      case 44:
        return createSetName(paramInt, paramNode1, paramNode2, paramClass, paramBoolean);
      case 39:
        str = (String)paramNode1.getProp(19);
        if (str != null)
          node = new Node(46, str); 
      case 41:
        if (node == null)
          node = paramNode1.getLastChild(); 
        return createSetProp(i, paramInt, paramNode1.getFirstChild(), 
            node, paramNode2, paramClass, paramBoolean);
    } 
    reportError("msg.bad.lhs.assign");
    return paramNode1;
  }
  
  private Node createConvert(Class paramClass, Node paramNode) {
    if (paramClass == null)
      return paramNode; 
    Node node = new Node(141, paramNode);
    node.putProp(18, ScriptRuntime.NumberClass);
    return node;
  }
  
  private Object createSetName(int paramInt, Node paramNode1, Node paramNode2, Class paramClass, boolean paramBoolean) {
    if (paramInt == 127) {
      paramNode1.setType(61);
      return new Node(10, paramNode1, paramNode2);
    } 
    String str = paramNode1.getString();
    if (str.equals("__proto__") || str.equals("__parent__")) {
      Node node = new Node(40, paramNode1, paramNode2);
      node.putProp(19, str);
      return node;
    } 
    Node node1 = new Node(44, str);
    if (paramClass != null)
      node1 = createConvert(paramClass, node1); 
    if (paramBoolean)
      node1 = createNewTemp(node1); 
    Node node2 = new Node(paramInt, node1, paramNode2);
    Node node3 = new Node(61, str);
    Node node4 = new Node(10, node3, node2);
    if (paramBoolean)
      node4 = new Node(95, node4, 
          createUseTemp(node1)); 
    return node4;
  }
  
  public Node createNewTemp(Node paramNode) {
    int i = paramNode.getType();
    if (i == 46 || i == 45)
      return paramNode; 
    return new Node(69, paramNode);
  }
  
  public Node createUseTemp(Node paramNode) {
    int i = paramNode.getType();
    if (i == 69) {
      Node node = new Node(70);
      node.putProp(6, paramNode);
      Integer integer = (Integer)paramNode.getProp(11);
      if (integer == null) {
        integer = new Integer(1);
      } else if (integer.intValue() < Integer.MAX_VALUE) {
        integer = new Integer(integer.intValue() + 1);
      } 
      paramNode.putProp(11, integer);
      return node;
    } 
    return paramNode.cloneNode();
  }
  
  public Node createNewLocal(Node paramNode) { return new Node(143, paramNode); }
  
  public Node createUseLocal(Node paramNode) {
    int i = paramNode.getType();
    if (i == 143) {
      Node node = new Node(144);
      node.putProp(7, paramNode);
      return node;
    } 
    return paramNode.cloneNode();
  }
  
  public static boolean hasSideEffects(Node paramNode) {
    switch (paramNode.getType()) {
      case 10:
      case 30:
      case 40:
      case 42:
      case 43:
      case 105:
      case 106:
        return true;
    } 
    Node node = paramNode.getFirstChild();
    while (node != null) {
      if (hasSideEffects(node))
        return true; 
      node = node.getNextSibling();
    } 
    return false;
  }
  
  private Node createSetProp(int paramInt1, int paramInt2, Node paramNode1, Node paramNode2, Node paramNode3, Class paramClass, boolean paramBoolean) {
    Node node3, node2, node1;
    byte b = (paramInt1 == 39) ? 
      40 : 
      42;
    Object object = paramNode2.getDatum();
    if (b == 40 && object != null && 
      object instanceof String) {
      node1 = (String)object;
      if (node1.equals("__proto__") || node1.equals("__parent__")) {
        node2 = new Node(b, paramNode1, paramNode3);
        node2.putProp(19, node1);
        return node2;
      } 
    } 
    if (paramInt2 == 127)
      return new Node(b, paramNode1, paramNode2, paramNode3); 
    if (hasSideEffects(paramNode3) || 
      hasSideEffects(paramNode2) || 
      paramNode1.getType() != 44) {
      node1 = createNewTemp(paramNode1);
      Node node6 = createUseTemp(node1);
      node2 = createNewTemp(paramNode2);
      Node node7 = createUseTemp(node2);
      node3 = new Node(paramInt1, node6, node7);
    } else {
      node1 = paramNode1.cloneNode();
      node2 = paramNode2.cloneNode();
      node3 = new Node(paramInt1, paramNode1, paramNode2);
    } 
    if (paramClass != null)
      node3 = createConvert(paramClass, node3); 
    if (paramBoolean)
      node3 = createNewTemp(node3); 
    Node node4 = new Node(paramInt2, node3, paramNode3);
    Node node5 = new Node(b, node1, node2, node4);
    if (paramBoolean)
      node5 = new Node(95, node5, 
          createUseTemp(node3)); 
    return node5;
  }
  
  private void reportError(String paramString) {
    if (this.scope != null)
      throw NativeGlobal.constructError(
          Context.getContext(), "SyntaxError", 
          ScriptRuntime.getMessage(paramString, null), 
          this.scope); 
    String str = Context.getMessage(paramString, null);
    Context.reportError(str, this.ts.getSourceName(), this.ts.getLineno(), 
        this.ts.getLine(), this.ts.getOffset());
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\IRFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */