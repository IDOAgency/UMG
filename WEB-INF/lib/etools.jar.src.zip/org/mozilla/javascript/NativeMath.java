/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeMath
/*     */   extends ScriptableObject
/*     */ {
/*     */   public static Scriptable init(Scriptable paramScriptable) throws PropertyException {
/*  47 */     NativeMath nativeMath = new NativeMath();
/*  48 */     nativeMath.setPrototype(ScriptableObject.getObjectPrototype(paramScriptable));
/*  49 */     nativeMath.setParentScope(paramScriptable);
/*     */     
/*  51 */     String[] arrayOfString1 = { "atan", "atan2", "ceil", 
/*  52 */         "cos", "floor", "random", 
/*  53 */         "sin", "sqrt", "tan" };
/*     */     
/*  55 */     nativeMath.defineFunctionProperties(arrayOfString1, Math.class, 
/*  56 */         2);
/*     */ 
/*     */ 
/*     */     
/*  60 */     String[] arrayOfString2 = { "acos", "asin", "abs", "exp", "max", "min", 
/*  61 */         "round", "pow", "log" };
/*     */     
/*  63 */     nativeMath.defineFunctionProperties(arrayOfString2, NativeMath.class, 
/*  64 */         2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     ((FunctionObject)nativeMath.get("max", paramScriptable)).setLength((short)2);
/*  71 */     ((FunctionObject)nativeMath.get("min", paramScriptable)).setLength((short)2);
/*     */     
/*  73 */     byte b = 
/*  74 */       7;
/*     */ 
/*     */     
/*  77 */     nativeMath.defineProperty("E", new Double(Math.E), 7);
/*  78 */     nativeMath.defineProperty("PI", new Double(Math.PI), 7);
/*  79 */     nativeMath.defineProperty("LN10", new Double(2.302585092994046D), 7);
/*  80 */     nativeMath.defineProperty("LN2", new Double(0.6931471805599453D), 7);
/*  81 */     nativeMath.defineProperty("LOG2E", new Double(1.4426950408889634D), 7);
/*  82 */     nativeMath.defineProperty("LOG10E", new Double(0.4342944819032518D), 7);
/*  83 */     nativeMath.defineProperty("SQRT1_2", new Double(0.7071067811865476D), 7);
/*  84 */     nativeMath.defineProperty("SQRT2", new Double(1.4142135623730951D), 7);
/*     */ 
/*     */ 
/*     */     
/*  88 */     ScriptableObject scriptableObject = (ScriptableObject)paramScriptable;
/*  89 */     scriptableObject.defineProperty("Math", nativeMath, 2);
/*     */     
/*  91 */     return nativeMath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public String getClassName() { return "Math"; }
/*     */ 
/*     */   
/*     */   public static double abs(double paramDouble) {
/* 102 */     if (paramDouble == 0.0D)
/* 103 */       return 0.0D; 
/* 104 */     if (paramDouble < 0.0D) {
/* 105 */       return -paramDouble;
/*     */     }
/* 107 */     return paramDouble;
/*     */   }
/*     */   
/*     */   public static double acos(double paramDouble) {
/* 111 */     if (paramDouble != paramDouble || 
/* 112 */       paramDouble > 1.0D || 
/* 113 */       paramDouble < -1.0D)
/* 114 */       return NaND; 
/* 115 */     return Math.acos(paramDouble);
/*     */   }
/*     */   
/*     */   public static double asin(double paramDouble) {
/* 119 */     if (paramDouble != paramDouble || 
/* 120 */       paramDouble > 1.0D || 
/* 121 */       paramDouble < -1.0D)
/* 122 */       return NaND; 
/* 123 */     return Math.asin(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static double max(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 129 */     double d = Double.NEGATIVE_INFINITY;
/* 130 */     if (paramArrayOfObject.length == 0)
/* 131 */       return d; 
/* 132 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 133 */       double d1 = ScriptRuntime.toNumber(paramArrayOfObject[b]);
/* 134 */       if (d1 != d1) return d1; 
/* 135 */       d = Math.max(d, d1);
/*     */     } 
/* 137 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static double min(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 143 */     double d = Double.POSITIVE_INFINITY;
/* 144 */     if (paramArrayOfObject.length == 0)
/* 145 */       return d; 
/* 146 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 147 */       double d1 = ScriptRuntime.toNumber(paramArrayOfObject[b]);
/* 148 */       if (d1 != d1) return d1; 
/* 149 */       d = Math.min(d, d1);
/*     */     } 
/* 151 */     return d;
/*     */   }
/*     */   
/*     */   public static double round(double paramDouble) {
/* 155 */     if (paramDouble != paramDouble)
/* 156 */       return paramDouble; 
/* 157 */     if (paramDouble == Double.POSITIVE_INFINITY || paramDouble == Double.NEGATIVE_INFINITY)
/* 158 */       return paramDouble; 
/* 159 */     long l = Math.round(paramDouble);
/* 160 */     if (l == 0L) {
/*     */       
/* 162 */       if (paramDouble < 0.0D)
/* 163 */         return ScriptRuntime.negativeZero; 
/* 164 */       return (paramDouble == 0.0D) ? paramDouble : 0.0D;
/*     */     } 
/* 166 */     return l;
/*     */   }
/*     */   
/*     */   public static double pow(double paramDouble1, double paramDouble2) {
/* 170 */     if (paramDouble2 == 0.0D)
/* 171 */       return 1.0D; 
/* 172 */     if (paramDouble1 == 0.0D && paramDouble2 < 0.0D) {
/* 173 */       Double double = new Double(paramDouble1);
/* 174 */       if (double.equals(new Double(0.0D))) {
/* 175 */         return Double.POSITIVE_INFINITY;
/*     */       }
/* 177 */       if ((int)paramDouble2 == paramDouble2 && ((int)paramDouble2 & true) == 1)
/* 178 */         return Double.NEGATIVE_INFINITY; 
/* 179 */       return Double.POSITIVE_INFINITY;
/*     */     } 
/* 181 */     return Math.pow(paramDouble1, paramDouble2);
/*     */   }
/*     */   
/*     */   public static double exp(double paramDouble) {
/* 185 */     if (paramDouble == Double.POSITIVE_INFINITY)
/* 186 */       return paramDouble; 
/* 187 */     if (paramDouble == Double.NEGATIVE_INFINITY)
/* 188 */       return 0.0D; 
/* 189 */     return Math.exp(paramDouble);
/*     */   }
/*     */   
/*     */   public static double log(double paramDouble) {
/* 193 */     if (paramDouble < 0.0D)
/* 194 */       return NaND; 
/* 195 */     return Math.log(paramDouble);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeMath.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */