package org.mozilla.javascript;

public class NativeMath extends ScriptableObject {
  public static Scriptable init(Scriptable paramScriptable) throws PropertyException {
    NativeMath nativeMath = new NativeMath();
    nativeMath.setPrototype(ScriptableObject.getObjectPrototype(paramScriptable));
    nativeMath.setParentScope(paramScriptable);
    String[] arrayOfString1 = { "atan", "atan2", "ceil", 
        "cos", "floor", "random", 
        "sin", "sqrt", "tan" };
    nativeMath.defineFunctionProperties(arrayOfString1, Math.class, 
        2);
    String[] arrayOfString2 = { "acos", "asin", "abs", "exp", "max", "min", 
        "round", "pow", "log" };
    nativeMath.defineFunctionProperties(arrayOfString2, NativeMath.class, 
        2);
    ((FunctionObject)nativeMath.get("max", paramScriptable)).setLength((short)2);
    ((FunctionObject)nativeMath.get("min", paramScriptable)).setLength((short)2);
    byte b = 
      7;
    nativeMath.defineProperty("E", new Double(Math.E), 7);
    nativeMath.defineProperty("PI", new Double(Math.PI), 7);
    nativeMath.defineProperty("LN10", new Double(2.302585092994046D), 7);
    nativeMath.defineProperty("LN2", new Double(0.6931471805599453D), 7);
    nativeMath.defineProperty("LOG2E", new Double(1.4426950408889634D), 7);
    nativeMath.defineProperty("LOG10E", new Double(0.4342944819032518D), 7);
    nativeMath.defineProperty("SQRT1_2", new Double(0.7071067811865476D), 7);
    nativeMath.defineProperty("SQRT2", new Double(1.4142135623730951D), 7);
    ScriptableObject scriptableObject = (ScriptableObject)paramScriptable;
    scriptableObject.defineProperty("Math", nativeMath, 2);
    return nativeMath;
  }
  
  public String getClassName() { return "Math"; }
  
  public static double abs(double paramDouble) {
    if (paramDouble == 0.0D)
      return 0.0D; 
    if (paramDouble < 0.0D)
      return -paramDouble; 
    return paramDouble;
  }
  
  public static double acos(double paramDouble) {
    if (paramDouble != paramDouble || 
      paramDouble > 1.0D || 
      paramDouble < -1.0D)
      return NaND; 
    return Math.acos(paramDouble);
  }
  
  public static double asin(double paramDouble) {
    if (paramDouble != paramDouble || 
      paramDouble > 1.0D || 
      paramDouble < -1.0D)
      return NaND; 
    return Math.asin(paramDouble);
  }
  
  public static double max(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    double d = Double.NEGATIVE_INFINITY;
    if (paramArrayOfObject.length == 0)
      return d; 
    for (byte b = 0; b < paramArrayOfObject.length; b++) {
      double d1 = ScriptRuntime.toNumber(paramArrayOfObject[b]);
      if (d1 != d1)
        return d1; 
      d = Math.max(d, d1);
    } 
    return d;
  }
  
  public static double min(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    double d = Double.POSITIVE_INFINITY;
    if (paramArrayOfObject.length == 0)
      return d; 
    for (byte b = 0; b < paramArrayOfObject.length; b++) {
      double d1 = ScriptRuntime.toNumber(paramArrayOfObject[b]);
      if (d1 != d1)
        return d1; 
      d = Math.min(d, d1);
    } 
    return d;
  }
  
  public static double round(double paramDouble) {
    if (paramDouble != paramDouble)
      return paramDouble; 
    if (paramDouble == Double.POSITIVE_INFINITY || paramDouble == Double.NEGATIVE_INFINITY)
      return paramDouble; 
    long l = Math.round(paramDouble);
    if (l == 0L) {
      if (paramDouble < 0.0D)
        return ScriptRuntime.negativeZero; 
      return (paramDouble == 0.0D) ? paramDouble : 0.0D;
    } 
    return l;
  }
  
  public static double pow(double paramDouble1, double paramDouble2) {
    if (paramDouble2 == 0.0D)
      return 1.0D; 
    if (paramDouble1 == 0.0D && paramDouble2 < 0.0D) {
      Double double = new Double(paramDouble1);
      if (double.equals(new Double(0.0D)))
        return Double.POSITIVE_INFINITY; 
      if ((int)paramDouble2 == paramDouble2 && ((int)paramDouble2 & true) == 1)
        return Double.NEGATIVE_INFINITY; 
      return Double.POSITIVE_INFINITY;
    } 
    return Math.pow(paramDouble1, paramDouble2);
  }
  
  public static double exp(double paramDouble) {
    if (paramDouble == Double.POSITIVE_INFINITY)
      return paramDouble; 
    if (paramDouble == Double.NEGATIVE_INFINITY)
      return 0.0D; 
    return Math.exp(paramDouble);
  }
  
  public static double log(double paramDouble) {
    if (paramDouble < 0.0D)
      return NaND; 
    return Math.log(paramDouble);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeMath.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */