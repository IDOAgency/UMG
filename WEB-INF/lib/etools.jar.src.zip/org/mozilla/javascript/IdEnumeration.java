package org.mozilla.javascript;

import java.util.Enumeration;
import java.util.Hashtable;

class IdEnumeration implements Enumeration {
  private Object next;
  
  private Scriptable obj;
  
  private int index;
  
  private Object[] array;
  
  private Hashtable used;
  
  IdEnumeration(Scriptable paramScriptable) {
    this.used = new Hashtable(27);
    changeObject(paramScriptable);
    this.next = getNext();
  }
  
  public boolean hasMoreElements() { return !(this.next == null); }
  
  public Object nextElement() {
    Object object = this.next;
    this.used.put(this.next, this.next);
    this.next = getNext();
    return object;
  }
  
  private void changeObject(Scriptable paramScriptable) {
    this.obj = paramScriptable;
    if (this.obj != null) {
      this.array = paramScriptable.getIds();
      if (this.array.length == 0)
        changeObject(this.obj.getPrototype()); 
    } 
    this.index = 0;
  }
  
  private Object getNext() {
    Object object;
    if (this.obj == null)
      return null; 
    while (true) {
      if (this.index == this.array.length) {
        changeObject(this.obj.getPrototype());
        if (this.obj == null)
          return null; 
      } 
      object = this.array[this.index++];
      if ((object instanceof String) ? 
        !this.obj.has((String)object, this.obj) : 
        
        !this.obj.has(((Number)object).intValue(), this.obj))
        continue; 
      if (!this.used.containsKey(object))
        break; 
    } 
    return object;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\IdEnumeration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */