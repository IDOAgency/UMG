/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.io.Reader;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TokenStream
/*      */ {
/*      */   public static final int TSF_NEWLINES = 1;
/*      */   public static final int TSF_FUNCTION = 2;
/*      */   public static final int TSF_RETURN_EXPR = 4;
/*      */   public static final int TSF_RETURN_VOID = 8;
/*      */   public static final int TSF_REGEXP = 16;
/*      */   private static final int EOF_CHAR = -1;
/*      */   public static final int ERROR = -1;
/*      */   public static final int EOF = 0;
/*      */   public static final int EOL = 1;
/*      */   public static final int POPV = 2;
/*      */   public static final int ENTERWITH = 3;
/*      */   public static final int LEAVEWITH = 4;
/*      */   public static final int RETURN = 5;
/*      */   public static final int GOTO = 6;
/*      */   public static final int IFEQ = 7;
/*      */   public static final int IFNE = 8;
/*      */   public static final int DUP = 9;
/*      */   public static final int SETNAME = 10;
/*      */   public static final int BITOR = 11;
/*      */   public static final int BITXOR = 12;
/*      */   public static final int BITAND = 13;
/*      */   public static final int EQ = 14;
/*      */   public static final int NE = 15;
/*      */   public static final int LT = 16;
/*      */   public static final int LE = 17;
/*      */   public static final int GT = 18;
/*      */   public static final int GE = 19;
/*      */   public static final int LSH = 20;
/*      */   public static final int RSH = 21;
/*      */   public static final int URSH = 22;
/*      */   public static final int ADD = 23;
/*      */   public static final int SUB = 24;
/*      */   public static final int MUL = 25;
/*      */   public static final int DIV = 26;
/*      */   public static final int MOD = 27;
/*      */   public static final int BITNOT = 28;
/*      */   public static final int NEG = 29;
/*      */   public static final int NEW = 30;
/*      */   public static final int DELPROP = 31;
/*      */   public static final int TYPEOF = 32;
/*      */   public static final int NAMEINC = 33;
/*      */   public static final int PROPINC = 34;
/*      */   public static final int ELEMINC = 35;
/*      */   public static final int NAMEDEC = 36;
/*      */   public static final int PROPDEC = 37;
/*      */   public static final int ELEMDEC = 38;
/*      */   public static final int GETPROP = 39;
/*      */   public static final int SETPROP = 40;
/*      */   public static final int GETELEM = 41;
/*      */   public static final int SETELEM = 42;
/*      */   public static final int CALL = 43;
/*      */   public static final int NAME = 44;
/*      */   public static final int NUMBER = 45;
/*      */   public static final int STRING = 46;
/*      */   public static final int ZERO = 47;
/*      */   public static final int ONE = 48;
/*      */   public static final int NULL = 49;
/*      */   public static final int THIS = 50;
/*      */   public static final int FALSE = 51;
/*      */   public static final int TRUE = 52;
/*      */   public static final int SHEQ = 53;
/*      */   public static final int SHNE = 54;
/*      */   public static final int CLOSURE = 55;
/*      */   public static final int OBJECT = 56;
/*      */   public static final int POP = 57;
/*      */   public static final int POS = 58;
/*      */   public static final int VARINC = 59;
/*      */   public static final int VARDEC = 60;
/*      */   public static final int BINDNAME = 61;
/*      */   public static final int THROW = 62;
/*      */   public static final int IN = 63;
/*      */   public static final int INSTANCEOF = 64;
/*      */   public static final int GOSUB = 65;
/*      */   public static final int RETSUB = 66;
/*      */   public static final int CALLSPECIAL = 67;
/*      */   public static final int GETTHIS = 68;
/*      */   public static final int NEWTEMP = 69;
/*      */   public static final int USETEMP = 70;
/*      */   public static final int GETBASE = 71;
/*      */   public static final int GETVAR = 72;
/*      */   public static final int SETVAR = 73;
/*      */   public static final int UNDEFINED = 74;
/*      */   public static final int TRY = 75;
/*      */   public static final int ENDTRY = 76;
/*      */   public static final int NEWSCOPE = 77;
/*      */   public static final int TYPEOFNAME = 78;
/*      */   public static final int ENUMINIT = 79;
/*      */   public static final int ENUMNEXT = 80;
/*      */   public static final int GETPROTO = 81;
/*      */   public static final int GETPARENT = 82;
/*      */   public static final int SETPROTO = 83;
/*      */   public static final int SETPARENT = 84;
/*      */   public static final int SCOPE = 85;
/*      */   public static final int GETSCOPEPARENT = 86;
/*      */   public static final int JTHROW = 87;
/*      */   public static final int SEMI = 88;
/*      */   public static final int LB = 89;
/*      */   public static final int RB = 90;
/*      */   public static final int LC = 91;
/*      */   public static final int RC = 92;
/*      */   public static final int LP = 93;
/*      */   public static final int RP = 94;
/*      */   public static final int COMMA = 95;
/*      */   public static final int ASSIGN = 96;
/*      */   public static final int HOOK = 97;
/*      */   public static final int COLON = 98;
/*      */   public static final int OR = 99;
/*      */   public static final int AND = 100;
/*      */   public static final int EQOP = 101;
/*      */   public static final int RELOP = 102;
/*      */   public static final int SHOP = 103;
/*      */   public static final int UNARYOP = 104;
/*      */   public static final int INC = 105;
/*      */   public static final int DEC = 106;
/*      */   public static final int DOT = 107;
/*      */   public static final int PRIMARY = 108;
/*      */   public static final int FUNCTION = 109;
/*      */   public static final int EXPORT = 110;
/*      */   public static final int IMPORT = 111;
/*      */   public static final int IF = 112;
/*      */   public static final int ELSE = 113;
/*      */   public static final int SWITCH = 114;
/*      */   public static final int CASE = 115;
/*      */   public static final int DEFAULT = 116;
/*      */   public static final int WHILE = 117;
/*      */   public static final int DO = 118;
/*      */   public static final int FOR = 119;
/*      */   public static final int BREAK = 120;
/*      */   public static final int CONTINUE = 121;
/*      */   public static final int VAR = 122;
/*      */   public static final int WITH = 123;
/*      */   public static final int CATCH = 124;
/*      */   public static final int FINALLY = 125;
/*      */   public static final int RESERVED = 126;
/*      */   public static final int NOP = 127;
/*      */   public static final int NOT = 128;
/*      */   public static final int PRE = 129;
/*      */   public static final int POST = 130;
/*      */   public static final int VOID = 131;
/*      */   public static final int BLOCK = 132;
/*      */   public static final int ARRAYLIT = 133;
/*      */   public static final int OBJLIT = 134;
/*      */   public static final int LABEL = 135;
/*      */   public static final int TARGET = 136;
/*      */   public static final int LOOP = 137;
/*      */   public static final int ENUMDONE = 138;
/*      */   public static final int EXPRSTMT = 139;
/*      */   public static final int PARENT = 140;
/*      */   public static final int CONVERT = 141;
/*      */   public static final int JSR = 142;
/*      */   public static final int NEWLOCAL = 143;
/*      */   public static final int USELOCAL = 144;
/*      */   public static final int SCRIPT = 145;
/*      */   public static final int LINE = 146;
/*      */   public static final int SOURCEFILE = 147;
/*      */   private static String[] names;
/*      */   private static Hashtable keywords;
/*      */   private LineBuffer in;
/*      */   public int flags;
/*      */   public String regExpFlags;
/*      */   private String sourceName;
/*      */   private String line;
/*      */   private Scriptable scope;
/*      */   private int pushbackToken;
/*      */   private int tokenno;
/*      */   private int op;
/*      */   private String string;
/*      */   private Number number;
/*      */   
/*      */   private static void checkNames() {}
/*      */   
/*  446 */   public String tokenToString(int paramInt) { return ""; }
/*      */ 
/*      */   
/*      */   public static String tokenToName(int paramInt) {
/*  450 */     checkNames();
/*  451 */     return (names == null) ? "" : names[paramInt + 1];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static  {
/*  457 */     String[] arrayOfString = { 
/*  458 */         "break", 
/*  459 */         "case", 
/*  460 */         "continue", 
/*  461 */         "default", 
/*  462 */         "delete", 
/*  463 */         "do", 
/*  464 */         "else", 
/*  465 */         "export", 
/*  466 */         "false", 
/*  467 */         "for", 
/*  468 */         "function", 
/*  469 */         "if", 
/*  470 */         "in", 
/*  471 */         "new", 
/*  472 */         "null", 
/*  473 */         "return", 
/*  474 */         "switch", 
/*  475 */         "this", 
/*  476 */         "true", 
/*  477 */         "typeof", 
/*  478 */         "var", 
/*  479 */         "void", 
/*  480 */         "while", 
/*  481 */         "with", 
/*      */ 
/*      */         
/*  484 */         "abstract", 
/*  485 */         "boolean", 
/*  486 */         "byte", 
/*  487 */         "catch", 
/*  488 */         "char", 
/*  489 */         "class", 
/*  490 */         "const", 
/*  491 */         "debugger", 
/*  492 */         "double", 
/*  493 */         "enum", 
/*  494 */         "extends", 
/*  495 */         "final", 
/*  496 */         "finally", 
/*  497 */         "float", 
/*  498 */         "goto", 
/*  499 */         "implements", 
/*  500 */         "import", 
/*  501 */         "instanceof", 
/*  502 */         "int", 
/*  503 */         "interface", 
/*  504 */         "long", 
/*  505 */         "native", 
/*  506 */         "package", 
/*  507 */         "private", 
/*  508 */         "protected", 
/*  509 */         "public", 
/*  510 */         "short", 
/*  511 */         "static", 
/*  512 */         "super", 
/*  513 */         "synchronized", 
/*  514 */         "throw", 
/*  515 */         "throws", 
/*  516 */         "transient", 
/*  517 */         "try", 
/*  518 */         "volatile" };
/*      */     
/*  520 */     int[] arrayOfInt = { 
/*  521 */         120, 
/*  522 */         115, 
/*  523 */         121, 
/*  524 */         116, 
/*  525 */         31, 
/*  526 */         118, 
/*  527 */         113, 
/*  528 */         110, 
/*  529 */         13164, 
/*  530 */         119, 
/*  531 */         109, 
/*  532 */         112, 
/*  533 */         16230, 
/*  534 */         30, 
/*  535 */         12652, 
/*  536 */         5, 
/*  537 */         114, 
/*  538 */         12908, 
/*  539 */         13420, 
/*  540 */         8296, 
/*  541 */         122, 
/*  542 */         33640, 
/*  543 */         117, 
/*  544 */         123, 
/*  545 */         126, 
/*  546 */         126, 
/*  547 */         126, 
/*  548 */         124, 
/*  549 */         126, 
/*  550 */         126, 
/*  551 */         126, 
/*  552 */         126, 
/*  553 */         126, 
/*  554 */         126, 
/*  555 */         126, 
/*  556 */         126, 
/*  557 */         125, 
/*  558 */         126, 
/*  559 */         126, 
/*  560 */         126, 
/*  561 */         111, 
/*  562 */         16486, 
/*  563 */         126, 
/*  564 */         126, 
/*  565 */         126, 
/*  566 */         126, 
/*  567 */         126, 
/*  568 */         126, 
/*  569 */         126, 
/*  570 */         126, 
/*  571 */         126, 
/*  572 */         126, 
/*  573 */         126, 
/*  574 */         126, 
/*  575 */         62, 
/*  576 */         126, 
/*  577 */         126, 
/*  578 */         75, 
/*  579 */         126 };
/*      */     
/*  581 */     keywords = new Hashtable(arrayOfString.length);
/*  582 */     Integer integer = new Integer(126);
/*  583 */     for (byte b = 0; b < arrayOfString.length; b++)
/*  584 */       keywords.put(arrayOfString[b], (arrayOfInt[b] == 126) ? 
/*  585 */           integer : 
/*  586 */           new Integer(arrayOfInt[b])); 
/*      */   }
/*      */   
/*      */   private int stringToKeyword(String paramString) {
/*  590 */     Integer integer = (Integer)keywords.get(paramString);
/*  591 */     if (integer == null)
/*  592 */       return 0; 
/*  593 */     int i = integer.intValue();
/*  594 */     this.op = i >> 8;
/*  595 */     return i & 0xFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenStream(Reader paramReader, Scriptable paramScriptable, String paramString, int paramInt) {
/* 1399 */     this.string = "";
/*      */     this.in = new LineBuffer(paramReader, paramInt);
/*      */     this.scope = paramScriptable;
/*      */     this.pushbackToken = 0;
/*      */     this.sourceName = paramString;
/*      */     this.flags = 0;
/*      */   }
/*      */   
/*      */   public Scriptable getScope() { return this.scope; }
/*      */   
/*      */   public boolean matchToken(int paramInt) {
/*      */     int i = getToken();
/*      */     if (i == paramInt)
/*      */       return true; 
/*      */     this.tokenno--;
/*      */     this.pushbackToken = i;
/*      */     return false;
/*      */   }
/*      */   
/*      */   public void clearPushback() { this.pushbackToken = 0; }
/*      */   
/*      */   public void ungetToken(int paramInt) {
/*      */     if (this.pushbackToken != 0 && paramInt != -1) {
/*      */       Object[] arrayOfObject = { tokenToString(paramInt), tokenToString(this.pushbackToken) };
/*      */       String str = Context.getMessage("msg.token.replaces.pushback", arrayOfObject);
/*      */       throw new RuntimeException(str);
/*      */     } 
/*      */     this.pushbackToken = paramInt;
/*      */     this.tokenno--;
/*      */   }
/*      */   
/*      */   public int peekToken() {
/*      */     int i = getToken();
/*      */     this.pushbackToken = i;
/*      */     this.tokenno--;
/*      */     return i;
/*      */   }
/*      */   
/*      */   public int peekTokenSameLine() {
/*      */     this.flags |= 0x1;
/*      */     int i = peekToken();
/*      */     this.flags &= 0xFFFFFFFE;
/*      */     if (this.pushbackToken == 1)
/*      */       this.pushbackToken = 0; 
/*      */     return i;
/*      */   }
/*      */   
/*      */   protected static boolean isJSIdentifier(String paramString) {
/*      */     int i = paramString.length();
/*      */     if (i == 0 || !Character.isJavaIdentifierStart(paramString.charAt(0)))
/*      */       return false; 
/*      */     for (byte b = 1; b < i; b++) {
/*      */       char c = paramString.charAt(b);
/*      */       if (!Character.isJavaIdentifierPart(c) && c == '\\' && b + 5 >= i && paramString.charAt(b + 1) == 'u' && isXDigit(paramString.charAt(b + 2)) && isXDigit(paramString.charAt(b + 3)) && isXDigit(paramString.charAt(b + 4)) && isXDigit(paramString.charAt(b + 5)))
/*      */         return false; 
/*      */     } 
/*      */     return true;
/*      */   }
/*      */   
/*      */   private static boolean isAlpha(int paramInt) {
/*      */     return !((paramInt < 97 || paramInt > 122) && (paramInt < 65 || paramInt > 90));
/*      */   }
/*      */   
/*      */   static boolean isDigit(int paramInt) { return !(paramInt < 48 || paramInt > 57); }
/*      */   
/*      */   static boolean isXDigit(int paramInt) {
/*      */     return !((paramInt < 48 || paramInt > 57) && (paramInt < 97 || paramInt > 102) && (paramInt < 65 || paramInt > 70));
/*      */   }
/*      */   
/*      */   public static boolean isJSSpace(int paramInt) {
/*      */     return !(paramInt != 32 && paramInt != 9 && paramInt != 12 && paramInt != 11 && paramInt != 160 && Character.getType((char)paramInt) != 12);
/*      */   }
/*      */   
/*      */   public static boolean isJSLineTerminator(int paramInt) {
/*      */     return !(paramInt != 10 && paramInt != 13 && paramInt != 8232 && paramInt != 8233);
/*      */   }
/*      */   
/*      */   public int getToken() {
/*      */     int i;
/*      */     this.tokenno++;
/*      */     if (this.pushbackToken != 0) {
/*      */       int j = this.pushbackToken;
/*      */       this.pushbackToken = 0;
/*      */       return j;
/*      */     } 
/*      */     do {
/*      */       i = this.in.read();
/*      */       if (i == 10 && (this.flags & true) != 0)
/*      */         break; 
/*      */     } while (isJSSpace(i) || i == 10);
/*      */     if (i == -1)
/*      */       return 0; 
/*      */     boolean bool = false;
/*      */     if (i == 92) {
/*      */       i = this.in.read();
/*      */       if (i == 117) {
/*      */         bool = true;
/*      */       } else {
/*      */         i = 92;
/*      */       } 
/*      */       this.in.unread();
/*      */     } 
/*      */     if (bool || Character.isJavaIdentifierStart((char)i)) {
/*      */       this.in.startString();
/*      */       boolean bool1 = bool;
/*      */       do {
/*      */         i = this.in.read();
/*      */         if (i != 92)
/*      */           continue; 
/*      */         i = this.in.read();
/*      */         bool1 = (i != 117) ? 0 : 1;
/*      */       } while (Character.isJavaIdentifierPart((char)i));
/*      */       this.in.unread();
/*      */       String str = this.in.getString();
/*      */       if (bool1) {
/*      */         char[] arrayOfChar = str.toCharArray();
/*      */         StringBuffer stringBuffer = new StringBuffer();
/*      */         int j = str.indexOf("\\u");
/*      */         int k = 0;
/*      */         while (j != -1) {
/*      */           stringBuffer.append(arrayOfChar, k, j);
/*      */           boolean bool2 = false;
/*      */           if (j + 5 < arrayOfChar.length && isXDigit(arrayOfChar[j + 2])) {
/*      */             int m = Character.digit(arrayOfChar[j + 2], 16);
/*      */             if (isXDigit(arrayOfChar[j + 3])) {
/*      */               m = m << 4 | Character.digit(arrayOfChar[j + 3], 16);
/*      */               if (isXDigit(arrayOfChar[j + 4])) {
/*      */                 m = m << 4 | Character.digit(arrayOfChar[j + 4], 16);
/*      */                 if (isXDigit(arrayOfChar[j + 5])) {
/*      */                   m = m << 4 | Character.digit(arrayOfChar[j + 5], 16);
/*      */                   stringBuffer.append((char)m);
/*      */                   k = j + 6;
/*      */                   bool2 = true;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           if (!bool2) {
/*      */             reportSyntaxError("msg.invalid.escape", null);
/*      */             return -1;
/*      */           } 
/*      */           j = str.indexOf("\\u", k);
/*      */         } 
/*      */         stringBuffer.append(arrayOfChar, k, arrayOfChar.length - k);
/*      */         str = stringBuffer.toString();
/*      */       } else {
/*      */         int j;
/*      */         if ((j = stringToKeyword(str)) != 0)
/*      */           return j; 
/*      */       } 
/*      */       this.string = str;
/*      */       return 44;
/*      */     } 
/*      */     if (isDigit(i) || (i == 46 && isDigit(this.in.peek()))) {
/*      */       byte b = 10;
/*      */       this.in.startString();
/*      */       double d = ScriptRuntime.NaN;
/*      */       long l = 0L;
/*      */       boolean bool1 = true;
/*      */       if (i == 48) {
/*      */         i = this.in.read();
/*      */         if (i == 120 || i == 88) {
/*      */           i = this.in.read();
/*      */           b = 16;
/*      */           this.in.startString();
/*      */         } else if (isDigit(i)) {
/*      */           if (i < 56) {
/*      */             b = 8;
/*      */             this.in.startString();
/*      */           } else {
/*      */             Object[] arrayOfObject = { String.valueOf((char)i) };
/*      */             Context.reportWarning(Context.getMessage("msg.bad.octal.literal", arrayOfObject), getSourceName(), this.in.getLineno(), getLine(), getOffset());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       while (isXDigit(i) && (b >= 16 || (!isAlpha(i) && (b != 8 || i < 56))))
/*      */         i = this.in.read(); 
/*      */       if (b == 10 && (i == 46 || i == 101 || i == 69)) {
/*      */         bool1 = false;
/*      */         if (i == 46)
/*      */           do {
/*      */             i = this.in.read();
/*      */           } while (isDigit(i)); 
/*      */         if (i == 101 || i == 69) {
/*      */           i = this.in.read();
/*      */           if (i == 43 || i == 45)
/*      */             i = this.in.read(); 
/*      */           if (!isDigit(i)) {
/*      */             this.in.getString();
/*      */             reportSyntaxError("msg.missing.exponent", null);
/*      */             return -1;
/*      */           } 
/*      */           do {
/*      */             i = this.in.read();
/*      */           } while (isDigit(i));
/*      */         } 
/*      */       } 
/*      */       this.in.unread();
/*      */       String str = this.in.getString();
/*      */       if (b == 10 && !bool1) {
/*      */         try {
/*      */           d = Double.valueOf(str).doubleValue();
/*      */         } catch (NumberFormatException numberFormatException) {
/*      */           Object[] arrayOfObject = { numberFormatException.getMessage() };
/*      */           reportSyntaxError("msg.caught.nfe", arrayOfObject);
/*      */           return -1;
/*      */         } 
/*      */       } else {
/*      */         d = ScriptRuntime.stringToNumber(str, 0, b);
/*      */         l = (long)d;
/*      */         if (l != d)
/*      */           bool1 = false; 
/*      */       } 
/*      */       if (!bool1) {
/*      */         this.number = new Double(d);
/*      */       } else if (l >= -128L && l <= 127L) {
/*      */         this.number = new Byte((byte)(int)l);
/*      */       } else if (l >= -32768L && l <= 32767L) {
/*      */         this.number = new Short((short)(int)l);
/*      */       } else if (l >= -2147483648L && l <= 2147483647L) {
/*      */         this.number = new Integer((int)l);
/*      */       } else {
/*      */         this.number = new Double(l);
/*      */       } 
/*      */       return 45;
/*      */     } 
/*      */     if (i == 34 || i == 39) {
/*      */       StringBuffer stringBuffer = null;
/*      */       int j = i;
/*      */       int k = 0;
/*      */       i = this.in.read();
/*      */       this.in.startString();
/*      */       while (i != j) {
/*      */         if (i == 10 || i == -1) {
/*      */           this.in.unread();
/*      */           this.in.getString();
/*      */           reportSyntaxError("msg.unterminated.string.lit", null);
/*      */           return -1;
/*      */         } 
/*      */         if (i == 92) {
/*      */           if (stringBuffer == null) {
/*      */             this.in.unread();
/*      */             stringBuffer = new StringBuffer(this.in.getString());
/*      */             this.in.read();
/*      */           } 
/*      */           switch (i = this.in.read()) {
/*      */             case 98:
/*      */               i = 8;
/*      */               break;
/*      */             case 102:
/*      */               i = 12;
/*      */               break;
/*      */             case 110:
/*      */               i = 10;
/*      */               break;
/*      */             case 114:
/*      */               i = 13;
/*      */               break;
/*      */             case 116:
/*      */               i = 9;
/*      */               break;
/*      */             case 118:
/*      */               i = 11;
/*      */               break;
/*      */             default:
/*      */               if (isDigit(i) && i < 56) {
/*      */                 k = i - 48;
/*      */                 i = this.in.read();
/*      */                 if (isDigit(i) && i < 56) {
/*      */                   k = 8 * k + i - 48;
/*      */                   i = this.in.read();
/*      */                   if (isDigit(i) && i < 56) {
/*      */                     k = 8 * k + i - 48;
/*      */                     i = this.in.read();
/*      */                   } 
/*      */                 } 
/*      */                 this.in.unread();
/*      */                 if (k > 255) {
/*      */                   reportSyntaxError("msg.oct.esc.too.large", null);
/*      */                   return -1;
/*      */                 } 
/*      */                 i = k;
/*      */                 break;
/*      */               } 
/*      */               if (i == 117) {
/*      */                 int m = this.in.read();
/*      */                 if (!isXDigit(m)) {
/*      */                   this.in.unread();
/*      */                   i = 117;
/*      */                   break;
/*      */                 } 
/*      */                 k = Character.digit((char)m, 16);
/*      */                 int n = this.in.read();
/*      */                 if (!isXDigit(n)) {
/*      */                   this.in.unread();
/*      */                   stringBuffer.append('u');
/*      */                   i = m;
/*      */                   break;
/*      */                 } 
/*      */                 k = 16 * k + Character.digit((char)n, 16);
/*      */                 int i1 = this.in.read();
/*      */                 if (!isXDigit(i1)) {
/*      */                   this.in.unread();
/*      */                   stringBuffer.append('u');
/*      */                   stringBuffer.append((char)m);
/*      */                   i = n;
/*      */                   break;
/*      */                 } 
/*      */                 k = 16 * k + Character.digit((char)i1, 16);
/*      */                 int i2 = this.in.read();
/*      */                 if (!isXDigit(i2)) {
/*      */                   this.in.unread();
/*      */                   stringBuffer.append('u');
/*      */                   stringBuffer.append((char)m);
/*      */                   stringBuffer.append((char)n);
/*      */                   i = i1;
/*      */                   break;
/*      */                 } 
/*      */                 k = 16 * k + Character.digit((char)i2, 16);
/*      */                 i = k;
/*      */                 break;
/*      */               } 
/*      */               if (i == 120) {
/*      */                 int m = this.in.read();
/*      */                 if (!isXDigit(m)) {
/*      */                   this.in.unread();
/*      */                   i = 120;
/*      */                   break;
/*      */                 } 
/*      */                 k = Character.digit((char)m, 16);
/*      */                 int n = this.in.read();
/*      */                 if (!isXDigit(n)) {
/*      */                   this.in.unread();
/*      */                   stringBuffer.append('x');
/*      */                   i = m;
/*      */                   break;
/*      */                 } 
/*      */                 k = 16 * k + Character.digit((char)n, 16);
/*      */                 i = k;
/*      */               } 
/*      */               break;
/*      */           } 
/*      */         } 
/*      */         if (stringBuffer != null)
/*      */           stringBuffer.append((char)i); 
/*      */         i = this.in.read();
/*      */       } 
/*      */       if (stringBuffer != null) {
/*      */         this.string = stringBuffer.toString();
/*      */       } else {
/*      */         this.in.unread();
/*      */         this.string = this.in.getString();
/*      */         this.in.read();
/*      */       } 
/*      */       return 46;
/*      */     } 
/*      */     switch (i) {
/*      */       case 10:
/*      */         return 1;
/*      */       case 59:
/*      */         return 88;
/*      */       case 91:
/*      */         return 89;
/*      */       case 93:
/*      */         return 90;
/*      */       case 123:
/*      */         return 91;
/*      */       case 125:
/*      */         return 92;
/*      */       case 40:
/*      */         return 93;
/*      */       case 41:
/*      */         return 94;
/*      */       case 44:
/*      */         return 95;
/*      */       case 63:
/*      */         return 97;
/*      */       case 58:
/*      */         return 98;
/*      */       case 46:
/*      */         return 107;
/*      */       case 124:
/*      */         if (this.in.match('|'))
/*      */           return 99; 
/*      */         if (this.in.match('=')) {
/*      */           this.op = 11;
/*      */           return 96;
/*      */         } 
/*      */         return 11;
/*      */       case 94:
/*      */         if (this.in.match('=')) {
/*      */           this.op = 12;
/*      */           return 96;
/*      */         } 
/*      */         return 12;
/*      */       case 38:
/*      */         if (this.in.match('&'))
/*      */           return 100; 
/*      */         if (this.in.match('=')) {
/*      */           this.op = 13;
/*      */           return 96;
/*      */         } 
/*      */         return 13;
/*      */       case 61:
/*      */         if (this.in.match('=')) {
/*      */           if (this.in.match('=')) {
/*      */             this.op = 53;
/*      */           } else {
/*      */             this.op = 14;
/*      */           } 
/*      */           return 101;
/*      */         } 
/*      */         this.op = 127;
/*      */         return 96;
/*      */       case 33:
/*      */         if (this.in.match('=')) {
/*      */           if (this.in.match('=')) {
/*      */             this.op = 54;
/*      */           } else {
/*      */             this.op = 15;
/*      */           } 
/*      */           return 101;
/*      */         } 
/*      */         this.op = 128;
/*      */         return 104;
/*      */       case 60:
/*      */         if (this.in.match('!')) {
/*      */           if (this.in.match('-')) {
/*      */             if (this.in.match('-')) {
/*      */               do {
/*      */               
/*      */               } while ((i = this.in.read()) != -1 && i != 10);
/*      */               this.in.unread();
/*      */               return getToken();
/*      */             } 
/*      */             this.in.unread();
/*      */           } 
/*      */           this.in.unread();
/*      */         } 
/*      */         if (this.in.match('<')) {
/*      */           if (this.in.match('=')) {
/*      */             this.op = 20;
/*      */             return 96;
/*      */           } 
/*      */           this.op = 20;
/*      */           return 103;
/*      */         } 
/*      */         if (this.in.match('=')) {
/*      */           this.op = 17;
/*      */           return 102;
/*      */         } 
/*      */         this.op = 16;
/*      */         return 102;
/*      */       case 62:
/*      */         if (this.in.match('>')) {
/*      */           if (this.in.match('>')) {
/*      */             if (this.in.match('=')) {
/*      */               this.op = 22;
/*      */               return 96;
/*      */             } 
/*      */             this.op = 22;
/*      */             return 103;
/*      */           } 
/*      */           if (this.in.match('=')) {
/*      */             this.op = 21;
/*      */             return 96;
/*      */           } 
/*      */           this.op = 21;
/*      */           return 103;
/*      */         } 
/*      */         if (this.in.match('=')) {
/*      */           this.op = 19;
/*      */           return 102;
/*      */         } 
/*      */         this.op = 18;
/*      */         return 102;
/*      */       case 42:
/*      */         if (this.in.match('=')) {
/*      */           this.op = 25;
/*      */           return 96;
/*      */         } 
/*      */         return 25;
/*      */       case 47:
/*      */         if (this.in.match('/')) {
/*      */           do {
/*      */           
/*      */           } while ((i = this.in.read()) != -1 && i != 10);
/*      */           this.in.unread();
/*      */           return getToken();
/*      */         } 
/*      */         if (this.in.match('*')) {
/*      */           while ((i = this.in.read()) != -1 && (i != 42 || !this.in.match('/'))) {
/*      */             if (i != 10 && i == 47 && this.in.match('*')) {
/*      */               if (this.in.match('/'))
/*      */                 return getToken(); 
/*      */               reportSyntaxError("msg.nested.comment", null);
/*      */               return -1;
/*      */             } 
/*      */           } 
/*      */           if (i == -1) {
/*      */             reportSyntaxError("msg.unterminated.comment", null);
/*      */             return -1;
/*      */           } 
/*      */           return getToken();
/*      */         } 
/*      */         if ((this.flags & 0x10) != 0) {
/*      */           StringBuffer stringBuffer1 = new StringBuffer();
/*      */           while ((i = this.in.read()) != 47) {
/*      */             if (i == 10 || i == -1) {
/*      */               this.in.unread();
/*      */               reportSyntaxError("msg.unterminated.re.lit", null);
/*      */               return -1;
/*      */             } 
/*      */             if (i == 92) {
/*      */               stringBuffer1.append((char)i);
/*      */               i = this.in.read();
/*      */             } 
/*      */             stringBuffer1.append((char)i);
/*      */           } 
/*      */           StringBuffer stringBuffer2 = new StringBuffer();
/*      */           while (true) {
/*      */             while (this.in.match('g'))
/*      */               stringBuffer2.append('g'); 
/*      */             if (this.in.match('i')) {
/*      */               stringBuffer2.append('i');
/*      */               continue;
/*      */             } 
/*      */             if (this.in.match('m')) {
/*      */               stringBuffer2.append('m');
/*      */               continue;
/*      */             } 
/*      */             break;
/*      */           } 
/*      */           if (isAlpha(this.in.peek())) {
/*      */             reportSyntaxError("msg.invalid.re.flag", null);
/*      */             return -1;
/*      */           } 
/*      */           this.string = stringBuffer1.toString();
/*      */           this.regExpFlags = stringBuffer2.toString();
/*      */           return 56;
/*      */         } 
/*      */         if (this.in.match('=')) {
/*      */           this.op = 26;
/*      */           return 96;
/*      */         } 
/*      */         return 26;
/*      */       case 37:
/*      */         this.op = 27;
/*      */         if (this.in.match('='))
/*      */           return 96; 
/*      */         return 27;
/*      */       case 126:
/*      */         this.op = 28;
/*      */         return 104;
/*      */       case 43:
/*      */       case 45:
/*      */         if (this.in.match('=')) {
/*      */           if (i == 43) {
/*      */             this.op = 23;
/*      */             return 96;
/*      */           } 
/*      */           this.op = 24;
/*      */           return 96;
/*      */         } 
/*      */         if (this.in.match((char)i)) {
/*      */           if (i == 43)
/*      */             return 105; 
/*      */           return 106;
/*      */         } 
/*      */         if (i == 45)
/*      */           return 24; 
/*      */         return 23;
/*      */     } 
/*      */     reportSyntaxError("msg.illegal.character", null);
/*      */     return -1;
/*      */   }
/*      */   
/*      */   public void reportSyntaxError(String paramString, Object[] paramArrayOfObject) {
/*      */     String str = Context.getMessage(paramString, paramArrayOfObject);
/*      */     if (this.scope != null)
/*      */       throw NativeGlobal.constructError(Context.getContext(), "SyntaxError", str, this.scope, getSourceName(), getLineno(), getOffset(), getLine()); 
/*      */     Context.reportError(str, getSourceName(), getLineno(), getLine(), getOffset());
/*      */   }
/*      */   
/*      */   public String getSourceName() { return this.sourceName; }
/*      */   
/*      */   public int getLineno() { return this.in.getLineno(); }
/*      */   
/*      */   public int getOp() { return this.op; }
/*      */   
/*      */   public String getString() { return this.string; }
/*      */   
/*      */   public Number getNumber() { return this.number; }
/*      */   
/*      */   public String getLine() { return this.in.getLine(); }
/*      */   
/*      */   public int getOffset() { return this.in.getOffset(); }
/*      */   
/*      */   public int getTokenno() { return this.tokenno; }
/*      */   
/*      */   public boolean eof() { return this.in.eof(); }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\TokenStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */