/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImporterTopLevel
/*     */   extends ScriptableObject
/*     */ {
/*     */   private Vector importedPackages;
/*     */   
/*     */   public ImporterTopLevel() {
/*  75 */     String[] arrayOfString = { "importClass", "importPackage" };
/*     */     
/*     */     try {
/*  78 */       defineFunctionProperties(arrayOfString, ImporterTopLevel.class, 
/*  79 */           2);
/*  80 */     } catch (PropertyException propertyException) {
/*  81 */       throw new Error();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  86 */   public String getClassName() { return "global"; }
/*     */ 
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/*  90 */     Object object = super.get(paramString, paramScriptable);
/*  91 */     if (object == Scriptable.NOT_FOUND && this.importedPackages != null) {
/*  92 */       for (byte b = 0; b < this.importedPackages.size(); b++) {
/*  93 */         Object object1 = this.importedPackages.elementAt(b);
/*  94 */         NativeJavaPackage nativeJavaPackage = (NativeJavaPackage)object1;
/*  95 */         Object object2 = nativeJavaPackage.getPkgProperty(paramString, paramScriptable, false);
/*  96 */         if (object2 != null && !(object2 instanceof NativeJavaPackage)) {
/*  97 */           if (object == Scriptable.NOT_FOUND) {
/*  98 */             object = object2;
/*     */           } else {
/* 100 */             String[] arrayOfString = { object.toString(), object2.toString() };
/* 101 */             throw Context.reportRuntimeError(
/* 102 */                 Context.getMessage("msg.ambig.import", 
/* 103 */                   arrayOfString));
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/* 108 */     return object;
/*     */   }
/*     */   
/*     */   public void importClass(Object paramObject) {
/* 112 */     if (!(paramObject instanceof NativeJavaClass)) {
/* 113 */       String[] arrayOfString = { Context.toString(paramObject) };
/* 114 */       throw Context.reportRuntimeError(
/* 115 */           Context.getMessage("msg.not.class", arrayOfString));
/*     */     } 
/* 117 */     String str1 = ((NativeJavaClass)paramObject).getClassObject().getName();
/* 118 */     String str2 = str1.substring(str1.lastIndexOf('.') + 1);
/* 119 */     Object object = get(str2, this);
/* 120 */     if (object != Scriptable.NOT_FOUND && object != paramObject) {
/* 121 */       String[] arrayOfString = { str2 };
/* 122 */       throw Context.reportRuntimeError(
/* 123 */           Context.getMessage("msg.prop.defined", arrayOfString));
/*     */     } 
/* 125 */     defineProperty(str2, paramObject, 2);
/*     */   }
/*     */   
/*     */   public void importPackage(Object paramObject) {
/* 129 */     if (this.importedPackages == null)
/* 130 */       this.importedPackages = new Vector(); 
/* 131 */     if (!(paramObject instanceof NativeJavaPackage)) {
/* 132 */       String[] arrayOfString = { Context.toString(paramObject) };
/* 133 */       throw Context.reportRuntimeError(
/* 134 */           Context.getMessage("msg.not.pkg", arrayOfString));
/*     */     } 
/* 136 */     for (byte b = 0; b < this.importedPackages.size(); b++) {
/* 137 */       if (paramObject == this.importedPackages.elementAt(b))
/*     */         return; 
/*     */     } 
/* 140 */     this.importedPackages.addElement(paramObject);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\ImporterTopLevel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */