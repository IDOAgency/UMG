package org.mozilla.javascript;

import java.util.Vector;

public class ImporterTopLevel extends ScriptableObject {
  private Vector importedPackages;
  
  public ImporterTopLevel() {
    String[] arrayOfString = { "importClass", "importPackage" };
    try {
      defineFunctionProperties(arrayOfString, ImporterTopLevel.class, 
          2);
    } catch (PropertyException propertyException) {
      throw new Error();
    } 
  }
  
  public String getClassName() { return "global"; }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    Object object = super.get(paramString, paramScriptable);
    if (object == Scriptable.NOT_FOUND && this.importedPackages != null)
      for (byte b = 0; b < this.importedPackages.size(); b++) {
        Object object1 = this.importedPackages.elementAt(b);
        NativeJavaPackage nativeJavaPackage = (NativeJavaPackage)object1;
        Object object2 = nativeJavaPackage.getPkgProperty(paramString, paramScriptable, false);
        if (object2 != null && !(object2 instanceof NativeJavaPackage))
          if (object == Scriptable.NOT_FOUND) {
            object = object2;
          } else {
            String[] arrayOfString = { object.toString(), object2.toString() };
            throw Context.reportRuntimeError(
                Context.getMessage("msg.ambig.import", 
                  arrayOfString));
          }  
      }  
    return object;
  }
  
  public void importClass(Object paramObject) {
    if (!(paramObject instanceof NativeJavaClass)) {
      String[] arrayOfString = { Context.toString(paramObject) };
      throw Context.reportRuntimeError(
          Context.getMessage("msg.not.class", arrayOfString));
    } 
    String str1 = ((NativeJavaClass)paramObject).getClassObject().getName();
    String str2 = str1.substring(str1.lastIndexOf('.') + 1);
    Object object = get(str2, this);
    if (object != Scriptable.NOT_FOUND && object != paramObject) {
      String[] arrayOfString = { str2 };
      throw Context.reportRuntimeError(
          Context.getMessage("msg.prop.defined", arrayOfString));
    } 
    defineProperty(str2, paramObject, 2);
  }
  
  public void importPackage(Object paramObject) {
    if (this.importedPackages == null)
      this.importedPackages = new Vector(); 
    if (!(paramObject instanceof NativeJavaPackage)) {
      String[] arrayOfString = { Context.toString(paramObject) };
      throw Context.reportRuntimeError(
          Context.getMessage("msg.not.pkg", arrayOfString));
    } 
    for (byte b = 0; b < this.importedPackages.size(); b++) {
      if (paramObject == this.importedPackages.elementAt(b))
        return; 
    } 
    this.importedPackages.addElement(paramObject);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\ImporterTopLevel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */