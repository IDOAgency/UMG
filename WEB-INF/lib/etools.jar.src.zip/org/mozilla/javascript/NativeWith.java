/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeWith
/*     */   implements Scriptable
/*     */ {
/*     */   private Scriptable prototype;
/*     */   private Scriptable parent;
/*     */   private Scriptable constructor;
/*     */   
/*     */   public static void init(Scriptable paramScriptable) {
/*  49 */     NativeWith nativeWith = new NativeWith();
/*  50 */     nativeWith.setPrototype(ScriptableObject.getObjectPrototype(paramScriptable));
/*  51 */     Method[] arrayOfMethod = FunctionObject.findMethods(NativeWith.class, 
/*  52 */         "jsConstructor");
/*  53 */     FunctionObject functionObject = new FunctionObject("With", arrayOfMethod[0], paramScriptable);
/*  54 */     functionObject.addAsConstructor(paramScriptable, nativeWith);
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeWith() {}
/*     */   
/*     */   public NativeWith(Scriptable paramScriptable1, Scriptable paramScriptable2) {
/*  61 */     this.parent = paramScriptable1;
/*  62 */     this.prototype = paramScriptable2;
/*     */   }
/*     */ 
/*     */   
/*  66 */   public String getClassName() { return "With"; }
/*     */ 
/*     */   
/*     */   public boolean has(String paramString, Scriptable paramScriptable) {
/*  70 */     if (paramScriptable == this)
/*  71 */       paramScriptable = this.prototype; 
/*  72 */     return this.prototype.has(paramString, paramScriptable);
/*     */   }
/*     */   
/*     */   public boolean has(int paramInt, Scriptable paramScriptable) {
/*  76 */     if (paramScriptable == this)
/*  77 */       paramScriptable = this.prototype; 
/*  78 */     return this.prototype.has(paramInt, paramScriptable);
/*     */   }
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/*  82 */     if (paramScriptable == this)
/*  83 */       paramScriptable = this.prototype; 
/*  84 */     return this.prototype.get(paramString, paramScriptable);
/*     */   }
/*     */   
/*     */   public Object get(int paramInt, Scriptable paramScriptable) {
/*  88 */     if (paramScriptable == this)
/*  89 */       paramScriptable = this.prototype; 
/*  90 */     return this.prototype.get(paramInt, paramScriptable);
/*     */   }
/*     */   
/*     */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
/*  94 */     if (paramScriptable == this)
/*  95 */       paramScriptable = this.prototype; 
/*  96 */     this.prototype.put(paramString, paramScriptable, paramObject);
/*     */   }
/*     */   
/*     */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
/* 100 */     if (paramScriptable == this)
/* 101 */       paramScriptable = this.prototype; 
/* 102 */     this.prototype.put(paramInt, paramScriptable, paramObject);
/*     */   }
/*     */ 
/*     */   
/* 106 */   public void delete(String paramString) { this.prototype.delete(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 110 */   public void delete(int paramInt) { this.prototype.delete(paramInt); }
/*     */ 
/*     */ 
/*     */   
/* 114 */   public Scriptable getPrototype() { return this.prototype; }
/*     */ 
/*     */ 
/*     */   
/* 118 */   public void setPrototype(Scriptable paramScriptable) { this.prototype = paramScriptable; }
/*     */ 
/*     */ 
/*     */   
/* 122 */   public Scriptable getParentScope() { return this.parent; }
/*     */ 
/*     */ 
/*     */   
/* 126 */   public void setParentScope(Scriptable paramScriptable) { this.parent = paramScriptable; }
/*     */ 
/*     */ 
/*     */   
/* 130 */   public Object[] getIds() { return this.prototype.getIds(); }
/*     */ 
/*     */ 
/*     */   
/* 134 */   public Object getDefaultValue(Class paramClass) { return this.prototype.getDefaultValue(paramClass); }
/*     */ 
/*     */ 
/*     */   
/* 138 */   public boolean hasInstance(Scriptable paramScriptable) { return this.prototype.hasInstance(paramScriptable); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
/* 144 */     Object[] arrayOfObject = { "With" };
/* 145 */     throw Context.reportRuntimeError(
/* 146 */         Context.getMessage("msg.cant.call.indirect", arrayOfObject));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object newWithSpecial(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
/* 152 */     if (!paramBoolean) {
/* 153 */       Object[] arrayOfObject = { "With" };
/* 154 */       throw Context.reportRuntimeError(
/* 155 */           Context.getMessage("msg.only.from.new", arrayOfObject));
/*     */     } 
/*     */     
/* 158 */     ScriptRuntime.checkDeprecated(paramContext, "With");
/*     */     
/* 160 */     Scriptable scriptable = ScriptableObject.getTopLevelScope(paramFunction);
/* 161 */     NativeWith nativeWith = new NativeWith();
/* 162 */     nativeWith.setPrototype((paramArrayOfObject.length == 0) ? 
/* 163 */         ScriptableObject.getClassPrototype(scriptable, 
/* 164 */           "Object") : 
/* 165 */         ScriptRuntime.toObject(scriptable, paramArrayOfObject[0]));
/* 166 */     nativeWith.setParentScope(scriptable);
/* 167 */     return nativeWith;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeWith.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */