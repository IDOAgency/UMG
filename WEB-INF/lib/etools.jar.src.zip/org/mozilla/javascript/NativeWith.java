package org.mozilla.javascript;

import java.lang.reflect.Method;

public class NativeWith implements Scriptable {
  private Scriptable prototype;
  
  private Scriptable parent;
  
  private Scriptable constructor;
  
  public static void init(Scriptable paramScriptable) {
    NativeWith nativeWith = new NativeWith();
    nativeWith.setPrototype(ScriptableObject.getObjectPrototype(paramScriptable));
    Method[] arrayOfMethod = FunctionObject.findMethods(NativeWith.class, 
        "jsConstructor");
    FunctionObject functionObject = new FunctionObject("With", arrayOfMethod[0], paramScriptable);
    functionObject.addAsConstructor(paramScriptable, nativeWith);
  }
  
  public NativeWith() {}
  
  public NativeWith(Scriptable paramScriptable1, Scriptable paramScriptable2) {
    this.parent = paramScriptable1;
    this.prototype = paramScriptable2;
  }
  
  public String getClassName() { return "With"; }
  
  public boolean has(String paramString, Scriptable paramScriptable) {
    if (paramScriptable == this)
      paramScriptable = this.prototype; 
    return this.prototype.has(paramString, paramScriptable);
  }
  
  public boolean has(int paramInt, Scriptable paramScriptable) {
    if (paramScriptable == this)
      paramScriptable = this.prototype; 
    return this.prototype.has(paramInt, paramScriptable);
  }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    if (paramScriptable == this)
      paramScriptable = this.prototype; 
    return this.prototype.get(paramString, paramScriptable);
  }
  
  public Object get(int paramInt, Scriptable paramScriptable) {
    if (paramScriptable == this)
      paramScriptable = this.prototype; 
    return this.prototype.get(paramInt, paramScriptable);
  }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
    if (paramScriptable == this)
      paramScriptable = this.prototype; 
    this.prototype.put(paramString, paramScriptable, paramObject);
  }
  
  public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
    if (paramScriptable == this)
      paramScriptable = this.prototype; 
    this.prototype.put(paramInt, paramScriptable, paramObject);
  }
  
  public void delete(String paramString) { this.prototype.delete(paramString); }
  
  public void delete(int paramInt) { this.prototype.delete(paramInt); }
  
  public Scriptable getPrototype() { return this.prototype; }
  
  public void setPrototype(Scriptable paramScriptable) { this.prototype = paramScriptable; }
  
  public Scriptable getParentScope() { return this.parent; }
  
  public void setParentScope(Scriptable paramScriptable) { this.parent = paramScriptable; }
  
  public Object[] getIds() { return this.prototype.getIds(); }
  
  public Object getDefaultValue(Class paramClass) { return this.prototype.getDefaultValue(paramClass); }
  
  public boolean hasInstance(Scriptable paramScriptable) { return this.prototype.hasInstance(paramScriptable); }
  
  public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
    Object[] arrayOfObject = { "With" };
    throw Context.reportRuntimeError(
        Context.getMessage("msg.cant.call.indirect", arrayOfObject));
  }
  
  public static Object newWithSpecial(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
    if (!paramBoolean) {
      Object[] arrayOfObject = { "With" };
      throw Context.reportRuntimeError(
          Context.getMessage("msg.only.from.new", arrayOfObject));
    } 
    ScriptRuntime.checkDeprecated(paramContext, "With");
    Scriptable scriptable = ScriptableObject.getTopLevelScope(paramFunction);
    NativeWith nativeWith = new NativeWith();
    nativeWith.setPrototype((paramArrayOfObject.length == 0) ? 
        ScriptableObject.getClassPrototype(scriptable, 
          "Object") : 
        ScriptRuntime.toObject(scriptable, paramArrayOfObject[0]));
    nativeWith.setParentScope(scriptable);
    return nativeWith;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeWith.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */