package org.mozilla.javascript;

class DefaultErrorReporter implements ErrorReporter {
  public void warning(String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2) {}
  
  public void error(String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2) { throw new EvaluatorException(paramString1); }
  
  public EvaluatorException runtimeError(String paramString1, String paramString2, int paramInt1, String paramString3, int paramInt2) { return new EvaluatorException(paramString1); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\DefaultErrorReporter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */