/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Arguments
/*     */   extends ScriptableObject
/*     */ {
/*     */   private NativeCall activation;
/*     */   private Object[] args;
/*     */   private boolean hasCaller;
/*     */   
/*     */   public Arguments(NativeCall paramNativeCall) {
/*  49 */     this.activation = paramNativeCall;
/*     */     
/*  51 */     Scriptable scriptable = paramNativeCall.getParentScope();
/*  52 */     setParentScope(scriptable);
/*  53 */     setPrototype(ScriptableObject.getObjectPrototype(scriptable));
/*     */     
/*  55 */     this.args = paramNativeCall.getOriginalArguments();
/*  56 */     int i = this.args.length;
/*  57 */     NativeFunction nativeFunction = paramNativeCall.funObj;
/*     */     
/*  59 */     defineProperty("length", new Integer(i), 
/*  60 */         2);
/*  61 */     defineProperty("callee", nativeFunction, 2);
/*     */     
/*  63 */     this.hasCaller = !(paramNativeCall.funObj.version > 130 || 
/*  64 */       paramNativeCall.funObj.version == 0);
/*     */   }
/*     */ 
/*     */   
/*  68 */   public String getClassName() { return "Arguments"; }
/*     */ 
/*     */ 
/*     */   
/*  72 */   public boolean has(String paramString, Scriptable paramScriptable) { return !((!this.hasCaller || !paramString.equals("caller")) && !super.has(paramString, paramScriptable)); }
/*     */ 
/*     */   
/*     */   public boolean has(int paramInt, Scriptable paramScriptable) {
/*  76 */     Object[] arrayOfObject = this.activation.getOriginalArguments();
/*  77 */     return !((paramInt < 0 || paramInt >= arrayOfObject.length) && !super.has(paramInt, paramScriptable));
/*     */   }
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/*  81 */     if (this.hasCaller && paramString.equals("caller")) {
/*  82 */       NativeCall nativeCall = this.activation.caller;
/*  83 */       if (nativeCall == null || nativeCall.originalArgs == null)
/*  84 */         return null; 
/*  85 */       return nativeCall.get("arguments", nativeCall);
/*     */     } 
/*  87 */     return super.get(paramString, paramScriptable);
/*     */   }
/*     */   
/*     */   public Object get(int paramInt, Scriptable paramScriptable) {
/*  91 */     if (paramInt >= 0 && paramInt < this.args.length) {
/*  92 */       NativeFunction nativeFunction = this.activation.funObj;
/*  93 */       if (paramInt < nativeFunction.argCount)
/*  94 */         return this.activation.get(nativeFunction.names[paramInt + 1], this.activation); 
/*  95 */       return this.args[paramInt];
/*     */     } 
/*  97 */     return super.get(paramInt, paramScriptable);
/*     */   }
/*     */   
/*     */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
/* 101 */     if (paramString.equals("caller"))
/*     */     {
/*     */       
/* 104 */       this.hasCaller = false;
/*     */     }
/* 106 */     super.put(paramString, paramScriptable, paramObject);
/*     */   }
/*     */   
/*     */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
/* 110 */     if (paramInt >= 0 && paramInt < this.args.length) {
/* 111 */       NativeFunction nativeFunction = this.activation.funObj;
/* 112 */       if (paramInt < nativeFunction.argCount) {
/* 113 */         this.activation.put(nativeFunction.names[paramInt + 1], this.activation, paramObject);
/*     */       } else {
/* 115 */         this.args[paramInt] = paramObject;
/*     */       }  return;
/*     */     } 
/* 118 */     super.put(paramInt, paramScriptable, paramObject);
/*     */   }
/*     */   
/*     */   public void delete(String paramString) {
/* 122 */     if (paramString.equals("caller"))
/* 123 */       this.hasCaller = false; 
/* 124 */     super.delete(paramString);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Arguments.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */