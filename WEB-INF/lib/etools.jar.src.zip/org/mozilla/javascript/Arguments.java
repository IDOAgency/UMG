package org.mozilla.javascript;

class Arguments extends ScriptableObject {
  private NativeCall activation;
  
  private Object[] args;
  
  private boolean hasCaller;
  
  public Arguments(NativeCall paramNativeCall) {
    this.activation = paramNativeCall;
    Scriptable scriptable = paramNativeCall.getParentScope();
    setParentScope(scriptable);
    setPrototype(ScriptableObject.getObjectPrototype(scriptable));
    this.args = paramNativeCall.getOriginalArguments();
    int i = this.args.length;
    NativeFunction nativeFunction = paramNativeCall.funObj;
    defineProperty("length", new Integer(i), 
        2);
    defineProperty("callee", nativeFunction, 2);
    this.hasCaller = !(paramNativeCall.funObj.version > 130 || 
      paramNativeCall.funObj.version == 0);
  }
  
  public String getClassName() { return "Arguments"; }
  
  public boolean has(String paramString, Scriptable paramScriptable) { return !((!this.hasCaller || !paramString.equals("caller")) && !super.has(paramString, paramScriptable)); }
  
  public boolean has(int paramInt, Scriptable paramScriptable) {
    Object[] arrayOfObject = this.activation.getOriginalArguments();
    return !((paramInt < 0 || paramInt >= arrayOfObject.length) && !super.has(paramInt, paramScriptable));
  }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    if (this.hasCaller && paramString.equals("caller")) {
      NativeCall nativeCall = this.activation.caller;
      if (nativeCall == null || nativeCall.originalArgs == null)
        return null; 
      return nativeCall.get("arguments", nativeCall);
    } 
    return super.get(paramString, paramScriptable);
  }
  
  public Object get(int paramInt, Scriptable paramScriptable) {
    if (paramInt >= 0 && paramInt < this.args.length) {
      NativeFunction nativeFunction = this.activation.funObj;
      if (paramInt < nativeFunction.argCount)
        return this.activation.get(nativeFunction.names[paramInt + 1], this.activation); 
      return this.args[paramInt];
    } 
    return super.get(paramInt, paramScriptable);
  }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
    if (paramString.equals("caller"))
      this.hasCaller = false; 
    super.put(paramString, paramScriptable, paramObject);
  }
  
  public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
    if (paramInt >= 0 && paramInt < this.args.length) {
      NativeFunction nativeFunction = this.activation.funObj;
      if (paramInt < nativeFunction.argCount) {
        this.activation.put(nativeFunction.names[paramInt + 1], this.activation, paramObject);
      } else {
        this.args[paramInt] = paramObject;
      } 
      return;
    } 
    super.put(paramInt, paramScriptable, paramObject);
  }
  
  public void delete(String paramString) {
    if (paramString.equals("caller"))
      this.hasCaller = false; 
    super.delete(paramString);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Arguments.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */