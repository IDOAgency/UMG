/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WrappedException
/*     */   extends EvaluatorException
/*     */   implements Wrapper
/*     */ {
/*     */   private Throwable exception;
/*     */   
/*     */   public WrappedException(Throwable paramThrowable) {
/*  55 */     super(paramThrowable.getMessage());
/*  56 */     this.exception = paramThrowable.fillInStackTrace();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public String getMessage() { return "WrappedException of " + this.exception.toString(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public String getLocalizedMessage() { return "WrappedException of " + this.exception.getLocalizedMessage(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public Throwable getWrappedException() { return this.exception; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public Object unwrap() { return this.exception; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EvaluatorException wrapException(Throwable paramThrowable) {
/* 107 */     if (paramThrowable instanceof InvocationTargetException)
/* 108 */       paramThrowable = ((InvocationTargetException)paramThrowable).getTargetException(); 
/* 109 */     if (paramThrowable instanceof EvaluatorException)
/* 110 */       return (EvaluatorException)paramThrowable; 
/* 111 */     return new WrappedException(paramThrowable);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\WrappedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */