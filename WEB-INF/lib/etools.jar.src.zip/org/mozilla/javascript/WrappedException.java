package org.mozilla.javascript;

import java.lang.reflect.InvocationTargetException;

public class WrappedException extends EvaluatorException implements Wrapper {
  private Throwable exception;
  
  public WrappedException(Throwable paramThrowable) {
    super(paramThrowable.getMessage());
    this.exception = paramThrowable.fillInStackTrace();
  }
  
  public String getMessage() { return "WrappedException of " + this.exception.toString(); }
  
  public String getLocalizedMessage() { return "WrappedException of " + this.exception.getLocalizedMessage(); }
  
  public Throwable getWrappedException() { return this.exception; }
  
  public Object unwrap() { return this.exception; }
  
  public static EvaluatorException wrapException(Throwable paramThrowable) {
    if (paramThrowable instanceof InvocationTargetException)
      paramThrowable = ((InvocationTargetException)paramThrowable).getTargetException(); 
    if (paramThrowable instanceof EvaluatorException)
      return (EvaluatorException)paramThrowable; 
    return new WrappedException(paramThrowable);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\WrappedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */