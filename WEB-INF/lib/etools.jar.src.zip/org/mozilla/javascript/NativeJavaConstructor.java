package org.mozilla.javascript;

import java.lang.reflect.Constructor;

public class NativeJavaConstructor extends NativeFunction implements Function {
  Constructor constructor;
  
  public NativeJavaConstructor(Constructor paramConstructor) {
    this.constructor = paramConstructor;
    this.names = new String[1];
    this.names[0] = "<init>" + NativeJavaMethod.signature(paramConstructor);
  }
  
  public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException {
    if (this.constructor == null)
      throw new RuntimeException("No constructor defined for call"); 
    for (byte b = 0; b < paramArrayOfObject.length; b++) {
      if (paramArrayOfObject[b] instanceof Wrapper)
        paramArrayOfObject[b] = ((Wrapper)paramArrayOfObject[b]).unwrap(); 
    } 
    return NativeJavaClass.constructSpecific(paramContext, paramScriptable1, 
        this, this.constructor, paramArrayOfObject);
  }
  
  public String toString() { return "[JavaConstructor " + this.constructor.getName() + "]"; }
  
  Constructor getConstructor() { return this.constructor; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeJavaConstructor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */