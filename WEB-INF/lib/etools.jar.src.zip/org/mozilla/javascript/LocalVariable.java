/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVariable
/*    */ {
/*    */   private String itsName;
/*    */   private int itsIndex;
/*    */   private boolean itsIsParameter;
/*    */   
/*    */   public LocalVariable(String paramString, boolean paramBoolean) {
/* 76 */     this.itsIndex = -1;
/*    */     this.itsName = paramString;
/*    */     this.itsIsParameter = paramBoolean;
/*    */   }
/*    */   
/*    */   public void setIndex(int paramInt) { this.itsIndex = paramInt; }
/*    */   
/*    */   public int getIndex() { return this.itsIndex; }
/*    */   
/*    */   public void setIsParameter() { this.itsIsParameter = true; }
/*    */   
/*    */   public boolean isParameter() { return this.itsIsParameter; }
/*    */   
/*    */   public String getName() { return this.itsName; }
/*    */   
/*    */   public int getStartPC() { return -1; }
/*    */   
/*    */   public short getJRegister() { return -1; }
/*    */   
/*    */   public boolean isNumber() { return false; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\LocalVariable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */