package org.mozilla.javascript;

class InterpretedFunction extends NativeFunction {
  InterpreterData itsData;
  
  Scriptable itsClosure;
  
  InterpretedFunction(InterpreterData paramInterpreterData, Context paramContext) {
    this.itsData = paramInterpreterData;
    init(paramContext);
  }
  
  void init(Context paramContext) {
    this.names = new String[this.itsData.itsVariableTable.size() + 1];
    this.names[0] = this.itsData.itsName;
    for (byte b = 0; b < this.itsData.itsVariableTable.size(); b++)
      this.names[b + true] = this.itsData.itsVariableTable.getName(b); 
    this.argCount = (short)this.itsData.itsVariableTable.getParameterCount();
    this.source = this.itsData.itsSource;
    this.nestedFunctions = this.itsData.itsNestedFunctions;
    if (paramContext != null)
      this.version = (short)paramContext.getLanguageVersion(); 
  }
  
  InterpretedFunction(InterpretedFunction paramInterpretedFunction, Scriptable paramScriptable, Context paramContext) {
    this.itsData = paramInterpretedFunction.itsData;
    this.itsClosure = paramScriptable;
    init(paramContext);
  }
  
  public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException {
    this.itsData.itsCX = paramContext;
    if (this.itsClosure != null) {
      paramScriptable1 = this.itsClosure;
    } else if (!this.itsData.itsUseDynamicScope) {
      paramScriptable1 = getParentScope();
    } 
    if (this.itsData.itsNeedsActivation)
      paramScriptable1 = ScriptRuntime.initVarObj(paramContext, paramScriptable1, this, paramScriptable2, paramArrayOfObject); 
    this.itsData.itsScope = paramScriptable1;
    this.itsData.itsThisObj = paramScriptable2;
    this.itsData.itsInArgs = paramArrayOfObject;
    return Interpreter.interpret(this.itsData);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\InterpretedFunction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */