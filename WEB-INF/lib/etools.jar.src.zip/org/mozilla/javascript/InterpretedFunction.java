/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InterpretedFunction
/*    */   extends NativeFunction
/*    */ {
/*    */   InterpreterData itsData;
/*    */   Scriptable itsClosure;
/*    */   
/*    */   InterpretedFunction(InterpreterData paramInterpreterData, Context paramContext) {
/* 42 */     this.itsData = paramInterpreterData;
/* 43 */     init(paramContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void init(Context paramContext) {
/* 51 */     this.names = new String[this.itsData.itsVariableTable.size() + 1];
/* 52 */     this.names[0] = this.itsData.itsName;
/* 53 */     for (byte b = 0; b < this.itsData.itsVariableTable.size(); b++)
/* 54 */       this.names[b + true] = this.itsData.itsVariableTable.getName(b); 
/* 55 */     this.argCount = (short)this.itsData.itsVariableTable.getParameterCount();
/* 56 */     this.source = this.itsData.itsSource;
/* 57 */     this.nestedFunctions = this.itsData.itsNestedFunctions;
/* 58 */     if (paramContext != null) {
/* 59 */       this.version = (short)paramContext.getLanguageVersion();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   InterpretedFunction(InterpretedFunction paramInterpretedFunction, Scriptable paramScriptable, Context paramContext) {
/* 65 */     this.itsData = paramInterpretedFunction.itsData;
/* 66 */     this.itsClosure = paramScriptable;
/* 67 */     init(paramContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException {
/* 74 */     this.itsData.itsCX = paramContext;
/* 75 */     if (this.itsClosure != null) {
/* 76 */       paramScriptable1 = this.itsClosure;
/* 77 */     } else if (!this.itsData.itsUseDynamicScope) {
/* 78 */       paramScriptable1 = getParentScope();
/* 79 */     }  if (this.itsData.itsNeedsActivation)
/* 80 */       paramScriptable1 = ScriptRuntime.initVarObj(paramContext, paramScriptable1, this, paramScriptable2, paramArrayOfObject); 
/* 81 */     this.itsData.itsScope = paramScriptable1;
/* 82 */     this.itsData.itsThisObj = paramScriptable2;
/* 83 */     this.itsData.itsInArgs = paramArrayOfObject;
/* 84 */     return Interpreter.interpret(this.itsData);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\InterpretedFunction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */