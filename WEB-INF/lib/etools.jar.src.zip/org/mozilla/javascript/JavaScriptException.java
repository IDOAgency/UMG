/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaScriptException
/*    */   extends Exception
/*    */ {
/*    */   Object value;
/*    */   
/*    */   public JavaScriptException(Object paramObject) {
/* 57 */     super(ScriptRuntime.toString(paramObject));
/* 58 */     this.value = paramObject;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 67 */   public String getMessage() { return ScriptRuntime.toString(this.value); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static JavaScriptException wrapException(Scriptable paramScriptable, Throwable paramThrowable) {
/* 73 */     if (paramThrowable instanceof InvocationTargetException)
/* 74 */       paramThrowable = ((InvocationTargetException)paramThrowable).getTargetException(); 
/* 75 */     if (paramThrowable instanceof JavaScriptException)
/* 76 */       return (JavaScriptException)paramThrowable; 
/* 77 */     Object object = NativeJavaObject.wrap(paramScriptable, paramThrowable, Throwable.class);
/* 78 */     return new JavaScriptException(object);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 90 */     if (this.value != null && this.value instanceof Wrapper)
/*    */     {
/* 92 */       return ((Wrapper)this.value).unwrap();
/*    */     }
/* 94 */     return this.value;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\JavaScriptException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */