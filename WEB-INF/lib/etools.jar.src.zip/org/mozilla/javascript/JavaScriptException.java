package org.mozilla.javascript;

import java.lang.reflect.InvocationTargetException;

public class JavaScriptException extends Exception {
  Object value;
  
  public JavaScriptException(Object paramObject) {
    super(ScriptRuntime.toString(paramObject));
    this.value = paramObject;
  }
  
  public String getMessage() { return ScriptRuntime.toString(this.value); }
  
  static JavaScriptException wrapException(Scriptable paramScriptable, Throwable paramThrowable) {
    if (paramThrowable instanceof InvocationTargetException)
      paramThrowable = ((InvocationTargetException)paramThrowable).getTargetException(); 
    if (paramThrowable instanceof JavaScriptException)
      return (JavaScriptException)paramThrowable; 
    Object object = NativeJavaObject.wrap(paramScriptable, paramThrowable, Throwable.class);
    return new JavaScriptException(object);
  }
  
  public Object getValue() {
    if (this.value != null && this.value instanceof Wrapper)
      return ((Wrapper)this.value).unwrap(); 
    return this.value;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\JavaScriptException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */