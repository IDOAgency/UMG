/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeBoolean
/*    */   extends ScriptableObject
/*    */ {
/*    */   private boolean booleanValue;
/*    */   
/*    */   public NativeBoolean() {}
/*    */   
/* 53 */   public NativeBoolean(boolean paramBoolean) { this.booleanValue = paramBoolean; }
/*    */ 
/*    */ 
/*    */   
/* 57 */   public String getClassName() { return "Boolean"; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getDefaultValue(Class paramClass) {
/* 63 */     if (paramClass == ScriptRuntime.BooleanClass)
/* 64 */       return this.booleanValue ? Boolean.TRUE : Boolean.FALSE; 
/* 65 */     return super.getDefaultValue(paramClass);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
/* 71 */     boolean bool = (paramArrayOfObject.length >= 1) ? 
/* 72 */       ScriptRuntime.toBoolean(paramArrayOfObject[0]) : 
/* 73 */       0;
/* 74 */     if (paramBoolean)
/*    */     {
/* 76 */       return new NativeBoolean(bool);
/*    */     }
/*    */ 
/*    */     
/* 80 */     return bool ? Boolean.TRUE : Boolean.FALSE;
/*    */   }
/*    */ 
/*    */   
/* 84 */   public String jsFunction_toString() { return this.booleanValue ? "true" : "false"; }
/*    */ 
/*    */ 
/*    */   
/* 88 */   public boolean jsFunction_valueOf() { return this.booleanValue; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeBoolean.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */