package org.mozilla.javascript;

public class NativeBoolean extends ScriptableObject {
  private boolean booleanValue;
  
  public NativeBoolean() {}
  
  public NativeBoolean(boolean paramBoolean) { this.booleanValue = paramBoolean; }
  
  public String getClassName() { return "Boolean"; }
  
  public Object getDefaultValue(Class paramClass) {
    if (paramClass == ScriptRuntime.BooleanClass)
      return this.booleanValue ? Boolean.TRUE : Boolean.FALSE; 
    return super.getDefaultValue(paramClass);
  }
  
  public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
    boolean bool = (paramArrayOfObject.length >= 1) ? 
      ScriptRuntime.toBoolean(paramArrayOfObject[0]) : 
      0;
    if (paramBoolean)
      return new NativeBoolean(bool); 
    return bool ? Boolean.TRUE : Boolean.FALSE;
  }
  
  public String jsFunction_toString() { return this.booleanValue ? "true" : "false"; }
  
  public boolean jsFunction_valueOf() { return this.booleanValue; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeBoolean.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */