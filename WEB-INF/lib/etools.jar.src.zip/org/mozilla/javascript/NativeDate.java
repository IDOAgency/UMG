package org.mozilla.javascript;

import java.lang.reflect.Constructor;
import java.text.DateFormat;
import java.util.Date;
import java.util.TimeZone;

public class NativeDate extends ScriptableObject {
  private static final double HalfTimeDomain = 8.64E15D;
  
  private static final double HoursPerDay = 24.0D;
  
  private static final double MinutesPerHour = 60.0D;
  
  private static final double SecondsPerMinute = 60.0D;
  
  private static final double msPerSecond = 1000.0D;
  
  private static final double MinutesPerDay = 1440.0D;
  
  private static final double SecondsPerDay = 86400.0D;
  
  private static final double SecondsPerHour = 3600.0D;
  
  private static final double msPerDay = 8.64E7D;
  
  private static final double msPerHour = 3600000.0D;
  
  private static final double msPerMinute = 60000.0D;
  
  private static final boolean TZO_WORKAROUND = false;
  
  private static final int MAXARGS = 7;
  
  public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) throws PropertyException {
    ((ScriptableObject)paramScriptable2).defineProperty("toGMTString", 
        paramScriptable2.get("toUTCString", paramScriptable2), 
        2);
    String[] arrayOfString = { "setSeconds", "setUTCSeconds", 
        "setMinutes", "setUTCMinutes", 
        "setHours", "setUTCHours", 
        "setMonth", "setUTCMonth", 
        "setFullYear", "setUTCFullYear" };
    short[] arrayOfShort = { 2, 2, 
        3, 3, 
        4, 4, 
        2, 2, 
        3, 3 };
    for (byte b = 0; b < arrayOfString.length; b++) {
      Object object = paramScriptable2.get(arrayOfString[b], paramScriptable2);
      ((FunctionObject)object).setLength(arrayOfShort[b]);
    } 
    ((NativeDate)paramScriptable2).date = ScriptRuntime.NaN;
  }
  
  public String getClassName() { return "Date"; }
  
  public Object getDefaultValue(Class paramClass) {
    if (paramClass == null)
      paramClass = ScriptRuntime.StringClass; 
    return super.getDefaultValue(paramClass);
  }
  
  private static boolean isFinite(double paramDouble) {
    if (paramDouble != paramDouble || 
      paramDouble == Double.POSITIVE_INFINITY || 
      paramDouble == Double.NEGATIVE_INFINITY)
      return false; 
    return true;
  }
  
  private static double Day(double paramDouble) { return Math.floor(paramDouble / 8.64E7D); }
  
  private static double TimeWithinDay(double paramDouble) {
    double d = paramDouble % 8.64E7D;
    if (d < 0.0D)
      d += 8.64E7D; 
    return d;
  }
  
  private static int DaysInYear(int paramInt) {
    if (paramInt % 4 == 0 && (paramInt % 100 != 0 || paramInt % 400 == 0))
      return 366; 
    return 365;
  }
  
  private static double DayFromYear(double paramDouble) { return 365.0D * (paramDouble - 1970.0D) + Math.floor((paramDouble - 1969.0D) / 4.0D) - 
      Math.floor((paramDouble - 1901.0D) / 100.0D) + Math.floor((paramDouble - 1601.0D) / 400.0D); }
  
  private static double TimeFromYear(double paramDouble) { return DayFromYear(paramDouble) * 8.64E7D; }
  
  private static int YearFromTime(double paramDouble) {
    int i = (int)Math.floor(paramDouble / 8.64E7D / 366.0D) + 1970;
    int j = (int)Math.floor(paramDouble / 8.64E7D / 365.0D) + 1970;
    if (j < i) {
      int k = i;
      i = j;
      j = k;
    } 
    while (j > i) {
      int k = (j + i) / 2;
      if (TimeFromYear(k) > paramDouble) {
        j = k - 1;
        continue;
      } 
      if (TimeFromYear(k) <= paramDouble) {
        int m = k + 1;
        if (TimeFromYear(m) > paramDouble)
          return k; 
        i = k + 1;
      } 
    } 
    return i;
  }
  
  private static boolean InLeapYear(double paramDouble) { return !(DaysInYear(YearFromTime(paramDouble)) != 366); }
  
  private static int DayWithinYear(double paramDouble) {
    int i = YearFromTime(paramDouble);
    return (int)(Day(paramDouble) - DayFromYear(i));
  }
  
  private static double DayFromMonth(int paramInt, boolean paramBoolean) {
    double[] arrayOfDouble1 = { 
        0, 31.0D, 59.0D, 90.0D, 120.0D, 151.0D, 
        181.0D, 212.0D, 243.0D, 273.0D, 
        304.0D, 334.0D };
    double[] arrayOfDouble2 = { 
        0, 31.0D, 60.0D, 91.0D, 121.0D, 152.0D, 
        182.0D, 213.0D, 244.0D, 274.0D, 
        305.0D, 335.0D };
    if (paramBoolean)
      return arrayOfDouble2[paramInt]; 
    return arrayOfDouble1[paramInt];
  }
  
  private static int MonthFromTime(double paramDouble) {
    int i = DayWithinYear(paramDouble);
    byte b;
    if (i < (b = 31))
      return 0; 
    if (InLeapYear(paramDouble)) {
      b += 29;
    } else {
      b += 28;
    } 
    if (i < b)
      return 1; 
    b += 31;
    if (i < b)
      return 2; 
    b += 30;
    if (i < b)
      return 3; 
    b += 31;
    if (i < b)
      return 4; 
    b += 30;
    if (i < b)
      return 5; 
    b += 31;
    if (i < b)
      return 6; 
    b += 31;
    if (i < b)
      return 7; 
    b += 30;
    if (i < b)
      return 8; 
    b += 31;
    if (i < b)
      return 9; 
    b += 30;
    if (i < b)
      return 10; 
    return 11;
  }
  
  private static int DateFromTime(double paramDouble) {
    int i = DayWithinYear(paramDouble);
    int k;
    if (i <= (k = 30))
      return i + 1; 
    int j = k;
    if (InLeapYear(paramDouble)) {
      k += 29;
    } else {
      k += 28;
    } 
    if (i <= k)
      return i - j; 
    j = k;
    k += 31;
    if (i <= k)
      return i - j; 
    j = k;
    k += 30;
    if (i <= k)
      return i - j; 
    j = k;
    k += 31;
    if (i <= k)
      return i - j; 
    j = k;
    k += 30;
    if (i <= k)
      return i - j; 
    j = k;
    k += 31;
    if (i <= k)
      return i - j; 
    j = k;
    k += 31;
    if (i <= k)
      return i - j; 
    j = k;
    k += 30;
    if (i <= k)
      return i - j; 
    j = k;
    k += 31;
    if (i <= k)
      return i - j; 
    j = k;
    k += 30;
    if (i <= k)
      return i - j; 
    j = k;
    return i - j;
  }
  
  private static int WeekDay(double paramDouble) {
    double d = Day(paramDouble) + 4.0D;
    d %= 7.0D;
    if (d < 0.0D)
      d += 7.0D; 
    return (int)d;
  }
  
  private static double Now() { return System.currentTimeMillis(); }
  
  private static double DaylightSavingTA(double paramDouble) {
    Date date1 = new Date((long)paramDouble);
    if (thisTimeZone.inDaylightTime(date1))
      return 3600000.0D; 
    return 0.0D;
  }
  
  private static double LocalTime(double paramDouble) { return paramDouble + LocalTZA + DaylightSavingTA(paramDouble); }
  
  private static double internalUTC(double paramDouble) { return paramDouble - LocalTZA - DaylightSavingTA(paramDouble - LocalTZA); }
  
  private static int HourFromTime(double paramDouble) {
    double d = Math.floor(paramDouble / 3600000.0D) % 24.0D;
    if (d < 0.0D)
      d += 24.0D; 
    return (int)d;
  }
  
  private static int MinFromTime(double paramDouble) {
    double d = Math.floor(paramDouble / 60000.0D) % 60.0D;
    if (d < 0.0D)
      d += 60.0D; 
    return (int)d;
  }
  
  private static int SecFromTime(double paramDouble) {
    double d = Math.floor(paramDouble / 1000.0D) % 60.0D;
    if (d < 0.0D)
      d += 60.0D; 
    return (int)d;
  }
  
  private static int msFromTime(double paramDouble) {
    double d = paramDouble % 1000.0D;
    if (d < 0.0D)
      d += 1000.0D; 
    return (int)d;
  }
  
  private static double MakeTime(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) { return ((paramDouble1 * 60.0D + paramDouble2) * 60.0D + paramDouble3) * 
      1000.0D + paramDouble4; }
  
  private static double MakeDay(double paramDouble1, double paramDouble2, double paramDouble3) {
    paramDouble1 += Math.floor(paramDouble2 / 12.0D);
    paramDouble2 %= 12.0D;
    if (paramDouble2 < 0.0D)
      paramDouble2 += 12.0D; 
    boolean bool = !(DaysInYear((int)paramDouble1) != 366);
    double d1 = Math.floor(TimeFromYear(paramDouble1) / 8.64E7D);
    double d2 = DayFromMonth((int)paramDouble2, bool);
    return d1 + d2 + paramDouble3 - 1.0D;
  }
  
  private static double MakeDate(double paramDouble1, double paramDouble2) { return paramDouble1 * 8.64E7D + paramDouble2; }
  
  private static double TimeClip(double paramDouble) {
    if (paramDouble != paramDouble || 
      paramDouble == Double.POSITIVE_INFINITY || 
      paramDouble == Double.NEGATIVE_INFINITY || 
      Math.abs(paramDouble) > 8.64E15D)
      return ScriptRuntime.NaN; 
    if (paramDouble > 0.0D)
      return Math.floor(paramDouble + 0.0D); 
    return Math.ceil(paramDouble + 0.0D);
  }
  
  private static double date_msecFromDate(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7) {
    double d1 = MakeDay(paramDouble1, paramDouble2, paramDouble3);
    double d2 = MakeTime(paramDouble4, paramDouble5, paramDouble6, paramDouble7);
    return MakeDate(d1, d2);
  }
  
  public static double jsStaticFunction_UTC(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    double[] arrayOfDouble = new double[7];
    for (byte b = 0; b < 7; b++) {
      if (b < paramArrayOfObject.length) {
        double d = ScriptRuntime.toNumber(paramArrayOfObject[b]);
        if (d != d || Double.isInfinite(d))
          return ScriptRuntime.NaN; 
        arrayOfDouble[b] = ScriptRuntime.toInteger(paramArrayOfObject[b]);
      } else {
        arrayOfDouble[b] = 0.0D;
      } 
    } 
    if (arrayOfDouble[0] >= 0.0D && arrayOfDouble[0] <= 99.0D)
      arrayOfDouble[0] = arrayOfDouble[0] + 1900.0D; 
    if (arrayOfDouble[2] < 1.0D)
      arrayOfDouble[2] = 1.0D; 
    null = date_msecFromDate(arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2], 
        arrayOfDouble[3], arrayOfDouble[4], arrayOfDouble[5], arrayOfDouble[6]);
    return TimeClip(null);
  }
  
  private static String[] wtb = { 
      "am", "pm", 
      "monday", "tuesday", "wednesday", "thursday", "friday", 
      "saturday", "sunday", 
      "january", 
      "february", "march", "april", "may", "june", 
      "july", "august", "september", "october", "november", 
      "december", 
      "gmt", "ut", "utc", "est", "edt", "cst", "cdt", 
      "mst", "mdt", 
      "pst", "pdt" };
  
  private static int[] ttb = { 
      -1, -2, 
      2, 3, 4, 5, 6, 7, 8, 9, 
      10, 11, 12, 13, 
      10000, 10000, 10000, 
      10300, 10240, 
      10360, 
      10300, 
      10420, 10360, 
      10480, 10420 };
  
  private static boolean date_regionMatches(String paramString1, int paramInt1, String paramString2, int paramInt2, int paramInt3) {
    boolean bool = false;
    int i = paramString1.length();
    int j = paramString2.length();
    while (paramInt3 > 0 && paramInt1 < i && paramInt2 < j && 
      Character.toLowerCase(paramString1.charAt(paramInt1)) == 
      Character.toLowerCase(paramString2.charAt(paramInt2))) {
      paramInt1++;
      paramInt2++;
      paramInt3--;
    } 
    if (paramInt3 == 0)
      bool = true; 
    return bool;
  }
  
  private static double date_parseString(String paramString) {
    int i = -1;
    int j = -1;
    int k = -1;
    int m = -1;
    int n = -1;
    int i1 = -1;
    int i2 = 0;
    char c = Character.MIN_VALUE;
    byte b = 0;
    int i3 = -1;
    double d = -1.0D;
    int i4 = 0;
    int i5 = 0;
    boolean bool = false;
    if (paramString == null)
      return ScriptRuntime.NaN; 
    i5 = paramString.length();
    while (b < i5) {
      i2 = paramString.charAt(b);
      b++;
      if (i2 <= 32 || i2 == 44 || i2 == 45) {
        if (b < i5) {
          c = paramString.charAt(b);
          if (i2 == 45 && c >= '0' && c <= '9')
            i4 = i2; 
        } 
        continue;
      } 
      if (i2 == 40) {
        byte b2 = 1;
        while (b < i5) {
          i2 = paramString.charAt(b);
          b++;
          if (i2 == 40) {
            b2++;
            continue;
          } 
          if (i2 == 41 && 
            --b2 <= 0)
            break; 
        } 
        continue;
      } 
      if (i2 >= 48 && i2 <= 57) {
        i3 = i2 - '0';
        while (b < i5 && (i2 = paramString.charAt(b)) >= '0' && i2 <= 57) {
          i3 = i3 * 10 + i2 - 48;
          b++;
        } 
        if (i4 == 43 || i4 == 45) {
          bool = true;
          if (i3 < 24) {
            i3 *= 60;
          } else {
            i3 = i3 % 100 + i3 / 100 * 60;
          } 
          if (i4 == 43)
            i3 = -i3; 
          if (d != 0.0D && d != -1.0D)
            return ScriptRuntime.NaN; 
          d = i3;
        } else if (i3 >= 70 || (
          i4 == 47 && j >= 0 && k >= 0 && i < 0)) {
          if (i >= 0)
            return ScriptRuntime.NaN; 
          if (i2 <= 32 || i2 == 44 || i2 == 47 || b >= i5) {
            i = (i3 < 100) ? (i3 + 1900) : i3;
          } else {
            return ScriptRuntime.NaN;
          } 
        } else if (i2 == 58) {
          if (m < 0) {
            m = i3;
          } else if (n < 0) {
            n = i3;
          } else {
            return ScriptRuntime.NaN;
          } 
        } else if (i2 == 47) {
          if (j < 0) {
            j = i3 - 1;
          } else if (k < 0) {
            k = i3;
          } else {
            return ScriptRuntime.NaN;
          } 
        } else {
          if (b < i5 && i2 != 44 && i2 > 32 && i2 != 45)
            return ScriptRuntime.NaN; 
          if (bool && i3 < 60) {
            if (d < 0.0D) {
              d -= i3;
            } else {
              d += i3;
            } 
          } else if (m >= 0 && n < 0) {
            n = i3;
          } else if (n >= 0 && i1 < 0) {
            i1 = i3;
          } else if (k < 0) {
            k = i3;
          } else {
            return ScriptRuntime.NaN;
          } 
        } 
        i4 = 0;
        continue;
      } 
      if (i2 == 47 || i2 == 58 || i2 == 43 || i2 == 45) {
        i4 = i2;
        continue;
      } 
      byte b1 = b - 1;
      while (b < i5) {
        i2 = paramString.charAt(b);
        if ((i2 < 65 || i2 > 90) && (i2 < 97 || i2 > 122))
          break; 
        b++;
      } 
      if (b <= b1 + 1)
        return ScriptRuntime.NaN; 
      int i6;
      for (i6 = wtb.length; --i6 >= 0;) {
        if (date_regionMatches(wtb[i6], 0, paramString, b1, b - b1)) {
          int i7 = ttb[i6];
          if (i7 != 0) {
            if (i7 < 0) {
              if (m > 12 || m < 0)
                return ScriptRuntime.NaN; 
              if (i7 == -1 && m == 12) {
                m = 0;
                break;
              } 
              if (i7 == -2 && m != 12)
                m += 12; 
              break;
            } 
            if (i7 <= 13) {
              if (j < 0) {
                j = i7 - 2;
                break;
              } 
              return ScriptRuntime.NaN;
            } 
            d = (i7 - 10000);
          } 
          break;
        } 
      } 
      if (i6 < 0)
        return ScriptRuntime.NaN; 
      i4 = 0;
    } 
    if (i < 0 || j < 0 || k < 0)
      return ScriptRuntime.NaN; 
    if (i1 < 0)
      i1 = 0; 
    if (n < 0)
      n = 0; 
    if (m < 0)
      m = 0; 
    if (d == -1.0D) {
      double d1 = date_msecFromDate(i, j, k, m, n, i1, 0.0D);
      return internalUTC(d1);
    } 
    null = date_msecFromDate(i, j, k, m, n, i1, 0.0D);
    return d * 60000.0D;
  }
  
  public static double jsStaticFunction_parse(String paramString) { return date_parseString(paramString); }
  
  private static String date_format(double paramDouble) {
    StringBuffer stringBuffer = new StringBuffer(60);
    double d = LocalTime(paramDouble);
    int i = (int)Math.floor((LocalTZA + DaylightSavingTA(paramDouble)) / 
        60000.0D);
    int j = i / 60 * 100 + i % 60;
    String str1 = Integer.toString(DateFromTime(d));
    String str2 = Integer.toString(HourFromTime(d));
    String str3 = Integer.toString(MinFromTime(d));
    String str4 = Integer.toString(SecFromTime(d));
    String str5 = Integer.toString((j > 0) ? j : -j);
    int k = YearFromTime(d);
    String str6 = Integer.toString((k > 0) ? k : -k);
    stringBuffer.append(days[WeekDay(d)]);
    stringBuffer.append(" ");
    stringBuffer.append(months[MonthFromTime(d)]);
    if (str1.length() == 1) {
      stringBuffer.append(" 0");
    } else {
      stringBuffer.append(" ");
    } 
    stringBuffer.append(str1);
    if (str2.length() == 1) {
      stringBuffer.append(" 0");
    } else {
      stringBuffer.append(" ");
    } 
    stringBuffer.append(str2);
    if (str3.length() == 1) {
      stringBuffer.append(":0");
    } else {
      stringBuffer.append(":");
    } 
    stringBuffer.append(str3);
    if (str4.length() == 1) {
      stringBuffer.append(":0");
    } else {
      stringBuffer.append(":");
    } 
    stringBuffer.append(str4);
    if (j > 0) {
      stringBuffer.append(" GMT+");
    } else {
      stringBuffer.append(" GMT-");
    } 
    int m;
    for (m = str5.length(); m < 4; m++)
      stringBuffer.append("0"); 
    stringBuffer.append(str5);
    if (timeZoneFormatter != null) {
      stringBuffer.append(" (");
      Date date1 = new Date((long)paramDouble);
      stringBuffer.append(timeZoneFormatter.format(date1));
      stringBuffer.append(") ");
    } else {
      stringBuffer.append(" ");
    } 
    if (k < 0)
      stringBuffer.append("-"); 
    for (m = str6.length(); m < 4; m++)
      stringBuffer.append("0"); 
    stringBuffer.append(str6);
    return stringBuffer.toString();
  }
  
  public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
    if (!paramBoolean)
      return date_format(Now()); 
    NativeDate nativeDate = new NativeDate();
    if (paramArrayOfObject.length == 0) {
      nativeDate.date = Now();
      return nativeDate;
    } 
    if (paramArrayOfObject.length == 1) {
      double d;
      if (!(paramArrayOfObject[0] instanceof String)) {
        d = ScriptRuntime.toNumber(paramArrayOfObject[0]);
      } else {
        String str = (String)paramArrayOfObject[0];
        d = date_parseString(str);
      } 
      nativeDate.date = TimeClip(d);
      return nativeDate;
    } 
    double[] arrayOfDouble = new double[7];
    for (byte b = 0; b < 7; b++) {
      if (b < paramArrayOfObject.length) {
        double d = ScriptRuntime.toNumber(paramArrayOfObject[b]);
        if (d != d || Double.isInfinite(d)) {
          nativeDate.date = ScriptRuntime.NaN;
          return nativeDate;
        } 
        arrayOfDouble[b] = ScriptRuntime.toInteger(paramArrayOfObject[b]);
      } else {
        arrayOfDouble[b] = 0.0D;
      } 
    } 
    if (arrayOfDouble[0] >= 0.0D && arrayOfDouble[0] <= 99.0D)
      arrayOfDouble[0] = arrayOfDouble[0] + 1900.0D; 
    if (arrayOfDouble[2] < 1.0D)
      arrayOfDouble[2] = 1.0D; 
    double d1 = MakeDay(arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2]);
    double d2 = MakeTime(arrayOfDouble[3], arrayOfDouble[4], arrayOfDouble[5], arrayOfDouble[6]);
    d2 = MakeDate(d1, d2);
    d2 = internalUTC(d2);
    nativeDate.date = TimeClip(d2);
    return nativeDate;
  }
  
  private static String js_NaN_date_str = "Invalid Date";
  
  private static String[] days = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
  
  private static String[] months = { 
      "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
      "Jul", "Aug", "Sep", "Oct", 
      "Nov", "Dec" };
  
  public String jsFunction_toString() {
    if (this.date != this.date)
      return js_NaN_date_str; 
    return date_format(this.date);
  }
  
  public String jsFunction_toLocaleString() {
    if (this.date != this.date)
      return js_NaN_date_str; 
    Date date1 = new Date((long)this.date);
    return localeDateFormatter.format(date1);
  }
  
  public String jsFunction_toUTCString() {
    if (this.date != this.date)
      return js_NaN_date_str; 
    StringBuffer stringBuffer = new StringBuffer(60);
    String str1 = Integer.toString(DateFromTime(this.date));
    String str2 = Integer.toString(HourFromTime(this.date));
    String str3 = Integer.toString(MinFromTime(this.date));
    String str4 = Integer.toString(SecFromTime(this.date));
    int i = YearFromTime(this.date);
    String str5 = Integer.toString((i > 0) ? i : -i);
    stringBuffer.append(days[WeekDay(this.date)]);
    stringBuffer.append(", ");
    if (str1.length() == 1)
      stringBuffer.append("0"); 
    stringBuffer.append(str1);
    stringBuffer.append(" ");
    stringBuffer.append(months[MonthFromTime(this.date)]);
    if (i < 0) {
      stringBuffer.append(" -");
    } else {
      stringBuffer.append(" ");
    } 
    for (int j = str5.length(); j < 4; j++)
      stringBuffer.append("0"); 
    stringBuffer.append(str5);
    if (str2.length() == 1) {
      stringBuffer.append(" 0");
    } else {
      stringBuffer.append(" ");
    } 
    stringBuffer.append(str2);
    if (str3.length() == 1) {
      stringBuffer.append(":0");
    } else {
      stringBuffer.append(":");
    } 
    stringBuffer.append(str3);
    if (str4.length() == 1) {
      stringBuffer.append(":0");
    } else {
      stringBuffer.append(":");
    } 
    stringBuffer.append(str4);
    stringBuffer.append(" GMT");
    return stringBuffer.toString();
  }
  
  public double jsFunction_valueOf() { return this.date; }
  
  public double jsFunction_getTime() { return this.date; }
  
  public double jsFunction_getYear() {
    if (this.date != this.date)
      return this.date; 
    int i = YearFromTime(LocalTime(this.date));
    Context context = Context.getContext();
    int j = context.getLanguageVersion();
    if (j == 100 || 
      j == 110 || 
      j == 120) {
      if (i >= 1900 && i < 2000)
        i -= 1900; 
    } else {
      i -= 1900;
    } 
    return i;
  }
  
  public double jsFunction_getFullYear() {
    if (this.date != this.date)
      return this.date; 
    return YearFromTime(LocalTime(this.date));
  }
  
  public double jsFunction_getUTCFullYear() {
    if (this.date != this.date)
      return this.date; 
    return YearFromTime(this.date);
  }
  
  public double jsFunction_getMonth() {
    if (this.date != this.date)
      return this.date; 
    return MonthFromTime(LocalTime(this.date));
  }
  
  public double jsFunction_getUTCMonth() {
    if (this.date != this.date)
      return this.date; 
    return MonthFromTime(this.date);
  }
  
  public double jsFunction_getDate() {
    if (this.date != this.date)
      return this.date; 
    return DateFromTime(LocalTime(this.date));
  }
  
  public double jsFunction_getUTCDate() {
    if (this.date != this.date)
      return this.date; 
    return DateFromTime(this.date);
  }
  
  public double jsFunction_getDay() {
    if (this.date != this.date)
      return this.date; 
    return WeekDay(LocalTime(this.date));
  }
  
  public double jsFunction_getUTCDay() {
    if (this.date != this.date)
      return this.date; 
    return WeekDay(this.date);
  }
  
  public double jsFunction_getHours() {
    if (this.date != this.date)
      return this.date; 
    return HourFromTime(LocalTime(this.date));
  }
  
  public double jsFunction_getUTCHours() {
    if (this.date != this.date)
      return this.date; 
    return HourFromTime(this.date);
  }
  
  public double jsFunction_getMinutes() {
    if (this.date != this.date)
      return this.date; 
    return MinFromTime(LocalTime(this.date));
  }
  
  public double jsFunction_getUTCMinutes() {
    if (this.date != this.date)
      return this.date; 
    return MinFromTime(this.date);
  }
  
  public double jsFunction_getSeconds() {
    if (this.date != this.date)
      return this.date; 
    return SecFromTime(LocalTime(this.date));
  }
  
  public double jsFunction_getUTCSeconds() {
    if (this.date != this.date)
      return this.date; 
    return SecFromTime(this.date);
  }
  
  public double jsFunction_getMilliseconds() {
    if (this.date != this.date)
      return this.date; 
    return msFromTime(LocalTime(this.date));
  }
  
  public double jsFunction_getUTCMilliseconds() {
    if (this.date != this.date)
      return this.date; 
    return msFromTime(this.date);
  }
  
  public double jsFunction_getTimezoneOffset() {
    if (this.date != this.date)
      return this.date; 
    return (this.date - LocalTime(this.date)) / 60000.0D;
  }
  
  public double jsFunction_setTime(double paramDouble) {
    this.date = TimeClip(paramDouble);
    return this.date;
  }
  
  private static NativeDate checkInstance(Scriptable paramScriptable, Function paramFunction) {
    if (paramScriptable == null || !(paramScriptable instanceof NativeDate)) {
      Context context = Context.getCurrentContext();
      Object[] arrayOfObject = { ((NativeFunction)paramFunction).names[0] };
      String str = Context.getMessage("msg.incompat.call", arrayOfObject);
      throw NativeGlobal.constructError(context, "TypeError", str, paramFunction);
    } 
    return (NativeDate)paramScriptable;
  }
  
  private static double makeTime(Scriptable paramScriptable, Object[] paramArrayOfObject, int paramInt, boolean paramBoolean, Function paramFunction) {
    double d5, d4, d3, d2, d1, arrayOfDouble[] = new double[4];
    NativeDate nativeDate = checkInstance(paramScriptable, paramFunction);
    double d8 = nativeDate.date;
    if (d8 != d8)
      return d8; 
    if (paramArrayOfObject.length == 0)
      paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1); 
    byte b;
    for (b = 0; b < paramArrayOfObject.length && b < paramInt; b++) {
      arrayOfDouble[b] = ScriptRuntime.toNumber(paramArrayOfObject[b]);
      if (arrayOfDouble[b] != arrayOfDouble[b] || Double.isInfinite(arrayOfDouble[b])) {
        nativeDate.date = ScriptRuntime.NaN;
        return nativeDate.date;
      } 
      arrayOfDouble[b] = ScriptRuntime.toInteger(arrayOfDouble[b]);
    } 
    if (paramBoolean) {
      d5 = LocalTime(d8);
    } else {
      d5 = d8;
    } 
    b = 0;
    int i = paramArrayOfObject.length;
    if (paramInt >= 4 && b < i) {
      d1 = arrayOfDouble[b++];
    } else {
      d1 = HourFromTime(d5);
    } 
    if (paramInt >= 3 && b < i) {
      d2 = arrayOfDouble[b++];
    } else {
      d2 = MinFromTime(d5);
    } 
    if (paramInt >= 2 && b < i) {
      d3 = arrayOfDouble[b++];
    } else {
      d3 = SecFromTime(d5);
    } 
    if (paramInt >= 1 && b < i) {
      d4 = arrayOfDouble[b++];
    } else {
      d4 = msFromTime(d5);
    } 
    double d6 = MakeTime(d1, d2, d3, d4);
    double d7 = MakeDate(Day(d5), d6);
    if (paramBoolean)
      d7 = internalUTC(d7); 
    d8 = TimeClip(d7);
    nativeDate.date = d8;
    return d8;
  }
  
  public static double jsFunction_setMilliseconds(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 1, true, paramFunction); }
  
  public static double jsFunction_setUTCMilliseconds(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 1, false, paramFunction); }
  
  public static double jsFunction_setSeconds(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 2, true, paramFunction); }
  
  public static double jsFunction_setUTCSeconds(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 2, false, paramFunction); }
  
  public static double jsFunction_setMinutes(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 3, true, paramFunction); }
  
  public static double jsFunction_setUTCMinutes(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 3, false, paramFunction); }
  
  public static double jsFunction_setHours(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 4, true, paramFunction); }
  
  public static double jsFunction_setUTCHours(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 4, false, paramFunction); }
  
  private static double makeDate(Scriptable paramScriptable, Object[] paramArrayOfObject, int paramInt, boolean paramBoolean, Function paramFunction) {
    double d4, d2, d1, arrayOfDouble[] = new double[3];
    NativeDate nativeDate = checkInstance(paramScriptable, paramFunction);
    double d6 = nativeDate.date;
    if (paramArrayOfObject.length == 0)
      paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1); 
    byte b;
    for (b = 0; b < paramArrayOfObject.length && b < paramInt; b++) {
      arrayOfDouble[b] = ScriptRuntime.toNumber(paramArrayOfObject[b]);
      if (arrayOfDouble[b] != arrayOfDouble[b] || Double.isInfinite(arrayOfDouble[b])) {
        nativeDate.date = ScriptRuntime.NaN;
        return nativeDate.date;
      } 
      arrayOfDouble[b] = ScriptRuntime.toInteger(arrayOfDouble[b]);
    } 
    if (d6 != d6) {
      if (paramArrayOfObject.length < 3)
        return ScriptRuntime.NaN; 
      d4 = 0.0D;
    } else if (paramBoolean) {
      d4 = LocalTime(d6);
    } else {
      d4 = d6;
    } 
    b = 0;
    int i = paramArrayOfObject.length;
    if (paramInt >= 3 && b < i) {
      d1 = arrayOfDouble[b++];
    } else {
      d1 = YearFromTime(d4);
    } 
    if (paramInt >= 2 && b < i) {
      d2 = arrayOfDouble[b++];
    } else {
      d2 = MonthFromTime(d4);
    } 
    if (paramInt >= 1 && b < i) {
      d3 = arrayOfDouble[b++];
    } else {
      d3 = DateFromTime(d4);
    } 
    double d3 = MakeDay(d1, d2, d3);
    double d5 = MakeDate(d3, TimeWithinDay(d4));
    if (paramBoolean)
      d5 = internalUTC(d5); 
    d6 = TimeClip(d5);
    nativeDate.date = d6;
    return d6;
  }
  
  public static double jsFunction_setDate(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeDate(paramScriptable, paramArrayOfObject, 1, true, paramFunction); }
  
  public static double jsFunction_setUTCDate(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeDate(paramScriptable, paramArrayOfObject, 1, false, paramFunction); }
  
  public static double jsFunction_setMonth(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeDate(paramScriptable, paramArrayOfObject, 2, true, paramFunction); }
  
  public static double jsFunction_setUTCMonth(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeDate(paramScriptable, paramArrayOfObject, 2, false, paramFunction); }
  
  public static double jsFunction_setFullYear(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeDate(paramScriptable, paramArrayOfObject, 3, true, paramFunction); }
  
  public static double jsFunction_setUTCFullYear(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeDate(paramScriptable, paramArrayOfObject, 3, false, paramFunction); }
  
  public double jsFunction_setYear(double paramDouble) {
    if (paramDouble != paramDouble || Double.isInfinite(paramDouble)) {
      this.date = ScriptRuntime.NaN;
      return this.date;
    } 
    if (this.date != this.date)
      this.date = 0.0D; 
    if (paramDouble >= 0.0D && paramDouble <= 99.0D)
      paramDouble += 1900.0D; 
    double d1 = MakeDay(paramDouble, MonthFromTime(this.date), DateFromTime(this.date));
    double d2 = MakeDate(d1, TimeWithinDay(this.date));
    d2 = internalUTC(d2);
    this.date = TimeClip(d2);
    return this.date;
  }
  
  private static final TimeZone thisTimeZone = TimeZone.getDefault();
  
  private static final double LocalTZA = thisTimeZone.getRawOffset();
  
  private static DateFormat timeZoneFormatter;
  
  private static final DateFormat localeDateFormatter;
  
  private double date;
  
  static  {
    try {
      Class[] arrayOfClass = { String.class };
      Object[] arrayOfObject = { "zzz" };
      Class clazz = Class.forName("java.text.SimpleDateFormat");
      Constructor constructor = 
        clazz.getDeclaredConstructor(arrayOfClass);
      timeZoneFormatter = 
        (DateFormat)constructor.newInstance(arrayOfObject);
    } catch (Exception exception) {
      timeZoneFormatter = null;
    } 
    localeDateFormatter = DateFormat.getDateTimeInstance(1, 
        1);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeDate.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */