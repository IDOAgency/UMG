/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.text.DateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NativeDate
/*      */   extends ScriptableObject
/*      */ {
/*      */   private static final double HalfTimeDomain = 8.64E15D;
/*      */   private static final double HoursPerDay = 24.0D;
/*      */   private static final double MinutesPerHour = 60.0D;
/*      */   private static final double SecondsPerMinute = 60.0D;
/*      */   private static final double msPerSecond = 1000.0D;
/*      */   private static final double MinutesPerDay = 1440.0D;
/*      */   private static final double SecondsPerDay = 86400.0D;
/*      */   private static final double SecondsPerHour = 3600.0D;
/*      */   private static final double msPerDay = 8.64E7D;
/*      */   private static final double msPerHour = 3600000.0D;
/*      */   private static final double msPerMinute = 60000.0D;
/*      */   private static final boolean TZO_WORKAROUND = false;
/*      */   private static final int MAXARGS = 7;
/*      */   
/*      */   public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) throws PropertyException {
/*   61 */     ((ScriptableObject)paramScriptable2).defineProperty("toGMTString", 
/*   62 */         paramScriptable2.get("toUTCString", paramScriptable2), 
/*   63 */         2);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   68 */     String[] arrayOfString = { "setSeconds", "setUTCSeconds", 
/*   69 */         "setMinutes", "setUTCMinutes", 
/*   70 */         "setHours", "setUTCHours", 
/*   71 */         "setMonth", "setUTCMonth", 
/*   72 */         "setFullYear", "setUTCFullYear" };
/*      */ 
/*      */     
/*   75 */     short[] arrayOfShort = { 2, 2, 
/*   76 */         3, 3, 
/*   77 */         4, 4, 
/*   78 */         2, 2, 
/*   79 */         3, 3 };
/*      */ 
/*      */     
/*   82 */     for (byte b = 0; b < arrayOfString.length; b++) {
/*   83 */       Object object = paramScriptable2.get(arrayOfString[b], paramScriptable2);
/*   84 */       ((FunctionObject)object).setLength(arrayOfShort[b]);
/*      */     } 
/*      */ 
/*      */     
/*   88 */     ((NativeDate)paramScriptable2).date = ScriptRuntime.NaN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   95 */   public String getClassName() { return "Date"; }
/*      */ 
/*      */   
/*      */   public Object getDefaultValue(Class paramClass) {
/*   99 */     if (paramClass == null)
/*  100 */       paramClass = ScriptRuntime.StringClass; 
/*  101 */     return super.getDefaultValue(paramClass);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isFinite(double paramDouble) {
/*  107 */     if (paramDouble != paramDouble || 
/*  108 */       paramDouble == Double.POSITIVE_INFINITY || 
/*  109 */       paramDouble == Double.NEGATIVE_INFINITY) {
/*  110 */       return false;
/*      */     }
/*  112 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  128 */   private static double Day(double paramDouble) { return Math.floor(paramDouble / 8.64E7D); }
/*      */ 
/*      */ 
/*      */   
/*      */   private static double TimeWithinDay(double paramDouble) {
/*  133 */     double d = paramDouble % 8.64E7D;
/*  134 */     if (d < 0.0D)
/*  135 */       d += 8.64E7D; 
/*  136 */     return d;
/*      */   }
/*      */   
/*      */   private static int DaysInYear(int paramInt) {
/*  140 */     if (paramInt % 4 == 0 && (paramInt % 100 != 0 || paramInt % 400 == 0)) {
/*  141 */       return 366;
/*      */     }
/*  143 */     return 365;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  151 */   private static double DayFromYear(double paramDouble) { return 365.0D * (paramDouble - 1970.0D) + Math.floor((paramDouble - 1969.0D) / 4.0D) - 
/*  152 */       Math.floor((paramDouble - 1901.0D) / 100.0D) + Math.floor((paramDouble - 1601.0D) / 400.0D); }
/*      */ 
/*      */ 
/*      */   
/*  156 */   private static double TimeFromYear(double paramDouble) { return DayFromYear(paramDouble) * 8.64E7D; }
/*      */ 
/*      */   
/*      */   private static int YearFromTime(double paramDouble) {
/*  160 */     int i = (int)Math.floor(paramDouble / 8.64E7D / 366.0D) + 1970;
/*  161 */     int j = (int)Math.floor(paramDouble / 8.64E7D / 365.0D) + 1970;
/*      */ 
/*      */ 
/*      */     
/*  165 */     if (j < i) {
/*  166 */       int k = i;
/*  167 */       i = j;
/*  168 */       j = k;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  177 */     while (j > i) {
/*  178 */       int k = (j + i) / 2;
/*  179 */       if (TimeFromYear(k) > paramDouble) {
/*  180 */         j = k - 1; continue;
/*      */       } 
/*  182 */       if (TimeFromYear(k) <= paramDouble) {
/*  183 */         int m = k + 1;
/*  184 */         if (TimeFromYear(m) > paramDouble) {
/*  185 */           return k;
/*      */         }
/*  187 */         i = k + 1;
/*      */       } 
/*      */     } 
/*      */     
/*  191 */     return i;
/*      */   }
/*      */ 
/*      */   
/*  195 */   private static boolean InLeapYear(double paramDouble) { return !(DaysInYear(YearFromTime(paramDouble)) != 366); }
/*      */ 
/*      */   
/*      */   private static int DayWithinYear(double paramDouble) {
/*  199 */     int i = YearFromTime(paramDouble);
/*  200 */     return (int)(Day(paramDouble) - DayFromYear(i));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double DayFromMonth(int paramInt, boolean paramBoolean) {
/*  208 */     double[] arrayOfDouble1 = { 0, 31.0D, 59.0D, 90.0D, 120.0D, 151.0D, 
/*  209 */         181.0D, 212.0D, 243.0D, 273.0D, 304.0D, 334.0D };
/*  210 */     double[] arrayOfDouble2 = { 0, 31.0D, 60.0D, 91.0D, 121.0D, 152.0D, 
/*  211 */         182.0D, 213.0D, 244.0D, 274.0D, 305.0D, 335.0D };
/*  212 */     if (paramBoolean) {
/*  213 */       return arrayOfDouble2[paramInt];
/*      */     }
/*  215 */     return arrayOfDouble1[paramInt];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static int MonthFromTime(double paramDouble) {
/*  221 */     int i = DayWithinYear(paramDouble);
/*      */     byte b;
/*  223 */     if (i < (b = 31)) {
/*  224 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*  228 */     if (InLeapYear(paramDouble)) {
/*  229 */       b += 29;
/*      */     } else {
/*  231 */       b += 28;
/*      */     } 
/*  233 */     if (i < b)
/*  234 */       return 1; 
/*  235 */     b += 31; if (i < b)
/*  236 */       return 2; 
/*  237 */     b += 30; if (i < b)
/*  238 */       return 3; 
/*  239 */     b += 31; if (i < b)
/*  240 */       return 4; 
/*  241 */     b += 30; if (i < b)
/*  242 */       return 5; 
/*  243 */     b += 31; if (i < b)
/*  244 */       return 6; 
/*  245 */     b += 31; if (i < b)
/*  246 */       return 7; 
/*  247 */     b += 30; if (i < b)
/*  248 */       return 8; 
/*  249 */     b += 31; if (i < b)
/*  250 */       return 9; 
/*  251 */     b += 30; if (i < b)
/*  252 */       return 10; 
/*  253 */     return 11;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static int DateFromTime(double paramDouble) {
/*  259 */     int i = DayWithinYear(paramDouble); int k;
/*  260 */     if (i <= (k = 30))
/*  261 */       return i + 1; 
/*  262 */     int j = k;
/*      */ 
/*      */ 
/*      */     
/*  266 */     if (InLeapYear(paramDouble)) {
/*  267 */       k += 29;
/*      */     } else {
/*  269 */       k += 28;
/*      */     } 
/*  271 */     if (i <= k)
/*  272 */       return i - j; 
/*  273 */     j = k;
/*  274 */     k += 31; if (i <= k)
/*  275 */       return i - j; 
/*  276 */     j = k;
/*  277 */     k += 30; if (i <= k)
/*  278 */       return i - j; 
/*  279 */     j = k;
/*  280 */     k += 31; if (i <= k)
/*  281 */       return i - j; 
/*  282 */     j = k;
/*  283 */     k += 30; if (i <= k)
/*  284 */       return i - j; 
/*  285 */     j = k;
/*  286 */     k += 31; if (i <= k)
/*  287 */       return i - j; 
/*  288 */     j = k;
/*  289 */     k += 31; if (i <= k)
/*  290 */       return i - j; 
/*  291 */     j = k;
/*  292 */     k += 30; if (i <= k)
/*  293 */       return i - j; 
/*  294 */     j = k;
/*  295 */     k += 31; if (i <= k)
/*  296 */       return i - j; 
/*  297 */     j = k;
/*  298 */     k += 30; if (i <= k)
/*  299 */       return i - j; 
/*  300 */     j = k;
/*      */     
/*  302 */     return i - j;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int WeekDay(double paramDouble) {
/*  307 */     double d = Day(paramDouble) + 4.0D;
/*  308 */     d %= 7.0D;
/*  309 */     if (d < 0.0D)
/*  310 */       d += 7.0D; 
/*  311 */     return (int)d;
/*      */   }
/*      */ 
/*      */   
/*  315 */   private static double Now() { return System.currentTimeMillis(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double DaylightSavingTA(double paramDouble) {
/*  328 */     Date date1 = new Date((long)paramDouble);
/*  329 */     if (thisTimeZone.inDaylightTime(date1)) {
/*  330 */       return 3600000.0D;
/*      */     }
/*  332 */     return 0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  362 */   private static double LocalTime(double paramDouble) { return paramDouble + LocalTZA + DaylightSavingTA(paramDouble); }
/*      */ 
/*      */ 
/*      */   
/*  366 */   private static double internalUTC(double paramDouble) { return paramDouble - LocalTZA - DaylightSavingTA(paramDouble - LocalTZA); }
/*      */ 
/*      */ 
/*      */   
/*      */   private static int HourFromTime(double paramDouble) {
/*  371 */     double d = Math.floor(paramDouble / 3600000.0D) % 24.0D;
/*  372 */     if (d < 0.0D)
/*  373 */       d += 24.0D; 
/*  374 */     return (int)d;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int MinFromTime(double paramDouble) {
/*  379 */     double d = Math.floor(paramDouble / 60000.0D) % 60.0D;
/*  380 */     if (d < 0.0D)
/*  381 */       d += 60.0D; 
/*  382 */     return (int)d;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int SecFromTime(double paramDouble) {
/*  387 */     double d = Math.floor(paramDouble / 1000.0D) % 60.0D;
/*  388 */     if (d < 0.0D)
/*  389 */       d += 60.0D; 
/*  390 */     return (int)d;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int msFromTime(double paramDouble) {
/*  395 */     double d = paramDouble % 1000.0D;
/*  396 */     if (d < 0.0D)
/*  397 */       d += 1000.0D; 
/*  398 */     return (int)d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  404 */   private static double MakeTime(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) { return ((paramDouble1 * 60.0D + paramDouble2) * 60.0D + paramDouble3) * 
/*  405 */       1000.0D + paramDouble4; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double MakeDay(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  414 */     paramDouble1 += Math.floor(paramDouble2 / 12.0D);
/*      */     
/*  416 */     paramDouble2 %= 12.0D;
/*  417 */     if (paramDouble2 < 0.0D) {
/*  418 */       paramDouble2 += 12.0D;
/*      */     }
/*  420 */     boolean bool = !(DaysInYear((int)paramDouble1) != 366);
/*      */     
/*  422 */     double d1 = Math.floor(TimeFromYear(paramDouble1) / 8.64E7D);
/*  423 */     double d2 = DayFromMonth((int)paramDouble2, bool);
/*      */ 
/*      */ 
/*      */     
/*  427 */     return d1 + d2 + paramDouble3 - 1.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  432 */   private static double MakeDate(double paramDouble1, double paramDouble2) { return paramDouble1 * 8.64E7D + paramDouble2; }
/*      */ 
/*      */   
/*      */   private static double TimeClip(double paramDouble) {
/*  436 */     if (paramDouble != paramDouble || 
/*  437 */       paramDouble == Double.POSITIVE_INFINITY || 
/*  438 */       paramDouble == Double.NEGATIVE_INFINITY || 
/*  439 */       Math.abs(paramDouble) > 8.64E15D)
/*      */     {
/*  441 */       return ScriptRuntime.NaN;
/*      */     }
/*  443 */     if (paramDouble > 0.0D) {
/*  444 */       return Math.floor(paramDouble + 0.0D);
/*      */     }
/*  446 */     return Math.ceil(paramDouble + 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double date_msecFromDate(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7) {
/*  461 */     double d1 = MakeDay(paramDouble1, paramDouble2, paramDouble3);
/*  462 */     double d2 = MakeTime(paramDouble4, paramDouble5, paramDouble6, paramDouble7);
/*  463 */     return MakeDate(d1, d2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double jsStaticFunction_UTC(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/*  472 */     double[] arrayOfDouble = new double[7];
/*      */ 
/*      */ 
/*      */     
/*  476 */     for (byte b = 0; b < 7; b++) {
/*  477 */       if (b < paramArrayOfObject.length) {
/*  478 */         double d = ScriptRuntime.toNumber(paramArrayOfObject[b]);
/*  479 */         if (d != d || Double.isInfinite(d)) {
/*  480 */           return ScriptRuntime.NaN;
/*      */         }
/*  482 */         arrayOfDouble[b] = ScriptRuntime.toInteger(paramArrayOfObject[b]);
/*      */       } else {
/*  484 */         arrayOfDouble[b] = 0.0D;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  489 */     if (arrayOfDouble[0] >= 0.0D && arrayOfDouble[0] <= 99.0D) {
/*  490 */       arrayOfDouble[0] = arrayOfDouble[0] + 1900.0D;
/*      */     }
/*      */ 
/*      */     
/*  494 */     if (arrayOfDouble[2] < 1.0D) {
/*  495 */       arrayOfDouble[2] = 1.0D;
/*      */     }
/*  497 */     null = date_msecFromDate(arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2], 
/*  498 */         arrayOfDouble[3], arrayOfDouble[4], arrayOfDouble[5], arrayOfDouble[6]);
/*  499 */     return TimeClip(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] wtb = { 
/*  514 */       "am", "pm", 
/*  515 */       "monday", "tuesday", "wednesday", "thursday", "friday", 
/*  516 */       "saturday", "sunday", 
/*  517 */       "january", "february", "march", "april", "may", "june", 
/*  518 */       "july", "august", "september", "october", "november", "december", 
/*  519 */       "gmt", "ut", "utc", "est", "edt", "cst", "cdt", 
/*  520 */       "mst", "mdt", "pst", "pdt" };
/*      */ 
/*      */ 
/*      */   
/*      */   private static int[] ttb = { 
/*  525 */       -1, -2, 
/*  526 */       2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 
/*  527 */       10000, 10000, 10000, 
/*  528 */       10300, 10240, 
/*  529 */       10360, 10300, 
/*  530 */       10420, 10360, 
/*  531 */       10480, 10420 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean date_regionMatches(String paramString1, int paramInt1, String paramString2, int paramInt2, int paramInt3) {
/*  539 */     boolean bool = false;
/*      */     
/*  541 */     int i = paramString1.length();
/*  542 */     int j = paramString2.length();
/*      */     
/*  544 */     while (paramInt3 > 0 && paramInt1 < i && paramInt2 < j && 
/*  545 */       Character.toLowerCase(paramString1.charAt(paramInt1)) == 
/*  546 */       Character.toLowerCase(paramString2.charAt(paramInt2))) {
/*      */       
/*  548 */       paramInt1++;
/*  549 */       paramInt2++;
/*  550 */       paramInt3--;
/*      */     } 
/*      */     
/*  553 */     if (paramInt3 == 0) {
/*  554 */       bool = true;
/*      */     }
/*  556 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static double date_parseString(String paramString) {
/*  562 */     int i = -1;
/*  563 */     int j = -1;
/*  564 */     int k = -1;
/*  565 */     int m = -1;
/*  566 */     int n = -1;
/*  567 */     int i1 = -1;
/*  568 */     int i2 = 0;
/*  569 */     char c = Character.MIN_VALUE;
/*  570 */     byte b = 0;
/*  571 */     int i3 = -1;
/*  572 */     double d = -1.0D;
/*  573 */     int i4 = 0;
/*  574 */     int i5 = 0;
/*  575 */     boolean bool = false;
/*      */     
/*  577 */     if (paramString == null)
/*  578 */       return ScriptRuntime.NaN; 
/*  579 */     i5 = paramString.length();
/*  580 */     while (b < i5) {
/*  581 */       i2 = paramString.charAt(b);
/*  582 */       b++;
/*  583 */       if (i2 <= 32 || i2 == 44 || i2 == 45) {
/*  584 */         if (b < i5) {
/*  585 */           c = paramString.charAt(b);
/*  586 */           if (i2 == 45 && c >= '0' && c <= '9') {
/*  587 */             i4 = i2;
/*      */           }
/*      */         } 
/*      */         continue;
/*      */       } 
/*  592 */       if (i2 == 40) {
/*  593 */         byte b2 = 1;
/*  594 */         while (b < i5) {
/*  595 */           i2 = paramString.charAt(b);
/*  596 */           b++;
/*  597 */           if (i2 == 40) {
/*  598 */             b2++; continue;
/*  599 */           }  if (i2 == 41 && 
/*  600 */             --b2 <= 0)
/*      */             break; 
/*      */         } 
/*      */         continue;
/*      */       } 
/*  605 */       if (i2 >= 48 && i2 <= 57) {
/*  606 */         i3 = i2 - '0';
/*  607 */         while (b < i5 && (i2 = paramString.charAt(b)) >= '0' && i2 <= 57) {
/*  608 */           i3 = i3 * 10 + i2 - 48;
/*  609 */           b++;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  619 */         if (i4 == 43 || i4 == 45)
/*      */         
/*  621 */         { bool = true;
/*      */ 
/*      */           
/*  624 */           if (i3 < 24) {
/*  625 */             i3 *= 60;
/*      */           } else {
/*  627 */             i3 = i3 % 100 + i3 / 100 * 60;
/*  628 */           }  if (i4 == 43)
/*  629 */             i3 = -i3; 
/*  630 */           if (d != 0.0D && d != -1.0D)
/*  631 */             return ScriptRuntime.NaN; 
/*  632 */           d = i3; }
/*  633 */         else if (i3 >= 70 || (
/*  634 */           i4 == 47 && j >= 0 && k >= 0 && i < 0))
/*  635 */         { if (i >= 0)
/*  636 */             return ScriptRuntime.NaN; 
/*  637 */           if (i2 <= 32 || i2 == 44 || i2 == 47 || b >= i5)
/*  638 */           { i = (i3 < 100) ? (i3 + 1900) : i3; }
/*      */           else
/*  640 */           { return ScriptRuntime.NaN; }  }
/*  641 */         else if (i2 == 58)
/*  642 */         { if (m < 0)
/*  643 */           { m = i3; }
/*  644 */           else if (n < 0)
/*  645 */           { n = i3; }
/*      */           else
/*  647 */           { return ScriptRuntime.NaN; }  }
/*  648 */         else if (i2 == 47)
/*  649 */         { if (j < 0)
/*  650 */           { j = i3 - 1; }
/*  651 */           else if (k < 0)
/*  652 */           { k = i3; }
/*      */           else
/*  654 */           { return ScriptRuntime.NaN; }  }
/*  655 */         else { if (b < i5 && i2 != 44 && i2 > 32 && i2 != 45)
/*  656 */             return ScriptRuntime.NaN; 
/*  657 */           if (bool && i3 < 60) {
/*  658 */             if (d < 0.0D)
/*  659 */             { d -= i3; }
/*      */             else
/*  661 */             { d += i3; } 
/*  662 */           } else if (m >= 0 && n < 0) {
/*  663 */             n = i3;
/*  664 */           } else if (n >= 0 && i1 < 0) {
/*  665 */             i1 = i3;
/*  666 */           } else if (k < 0) {
/*  667 */             k = i3;
/*      */           } else {
/*  669 */             return ScriptRuntime.NaN;
/*      */           }  }
/*  671 */          i4 = 0; continue;
/*  672 */       }  if (i2 == 47 || i2 == 58 || i2 == 43 || i2 == 45) {
/*  673 */         i4 = i2; continue;
/*      */       } 
/*  675 */       byte b1 = b - 1;
/*      */       
/*  677 */       while (b < i5) {
/*  678 */         i2 = paramString.charAt(b);
/*  679 */         if ((i2 < 65 || i2 > 90) && (i2 < 97 || i2 > 122))
/*      */           break; 
/*  681 */         b++;
/*      */       } 
/*  683 */       if (b <= b1 + 1)
/*  684 */         return ScriptRuntime.NaN;  int i6;
/*  685 */       for (i6 = wtb.length; --i6 >= 0;) {
/*  686 */         if (date_regionMatches(wtb[i6], 0, paramString, b1, b - b1)) {
/*  687 */           int i7 = ttb[i6];
/*  688 */           if (i7 != 0) {
/*  689 */             if (i7 < 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  694 */               if (m > 12 || m < 0) {
/*  695 */                 return ScriptRuntime.NaN;
/*      */               }
/*  697 */               if (i7 == -1 && m == 12) {
/*  698 */                 m = 0; break;
/*  699 */               }  if (i7 == -2 && m != 12)
/*  700 */                 m += 12; 
/*      */               break;
/*      */             } 
/*  703 */             if (i7 <= 13) {
/*  704 */               if (j < 0) {
/*  705 */                 j = i7 - 2; break;
/*      */               } 
/*  707 */               return ScriptRuntime.NaN;
/*      */             } 
/*      */             
/*  710 */             d = (i7 - 10000);
/*      */           } 
/*      */           break;
/*      */         } 
/*      */       } 
/*  715 */       if (i6 < 0)
/*  716 */         return ScriptRuntime.NaN; 
/*  717 */       i4 = 0;
/*      */     } 
/*      */     
/*  720 */     if (i < 0 || j < 0 || k < 0)
/*  721 */       return ScriptRuntime.NaN; 
/*  722 */     if (i1 < 0)
/*  723 */       i1 = 0; 
/*  724 */     if (n < 0)
/*  725 */       n = 0; 
/*  726 */     if (m < 0)
/*  727 */       m = 0; 
/*  728 */     if (d == -1.0D) {
/*      */       
/*  730 */       double d1 = date_msecFromDate(i, j, k, m, n, i1, 0.0D);
/*  731 */       return internalUTC(d1);
/*      */     } 
/*      */     
/*  734 */     null = date_msecFromDate(i, j, k, m, n, i1, 0.0D);
/*  735 */     return d * 60000.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  740 */   public static double jsStaticFunction_parse(String paramString) { return date_parseString(paramString); }
/*      */ 
/*      */   
/*      */   private static String date_format(double paramDouble) {
/*  744 */     StringBuffer stringBuffer = new StringBuffer(60);
/*  745 */     double d = LocalTime(paramDouble);
/*      */ 
/*      */ 
/*      */     
/*  749 */     int i = (int)Math.floor((LocalTZA + DaylightSavingTA(paramDouble)) / 
/*  750 */         60000.0D);
/*      */     
/*  752 */     int j = i / 60 * 100 + i % 60;
/*      */     
/*  754 */     String str1 = Integer.toString(DateFromTime(d));
/*  755 */     String str2 = Integer.toString(HourFromTime(d));
/*  756 */     String str3 = Integer.toString(MinFromTime(d));
/*  757 */     String str4 = Integer.toString(SecFromTime(d));
/*  758 */     String str5 = Integer.toString((j > 0) ? j : -j);
/*  759 */     int k = YearFromTime(d);
/*  760 */     String str6 = Integer.toString((k > 0) ? k : -k);
/*      */     
/*  762 */     stringBuffer.append(days[WeekDay(d)]);
/*  763 */     stringBuffer.append(" ");
/*  764 */     stringBuffer.append(months[MonthFromTime(d)]);
/*  765 */     if (str1.length() == 1) {
/*  766 */       stringBuffer.append(" 0");
/*      */     } else {
/*  768 */       stringBuffer.append(" ");
/*  769 */     }  stringBuffer.append(str1);
/*  770 */     if (str2.length() == 1) {
/*  771 */       stringBuffer.append(" 0");
/*      */     } else {
/*  773 */       stringBuffer.append(" ");
/*  774 */     }  stringBuffer.append(str2);
/*  775 */     if (str3.length() == 1) {
/*  776 */       stringBuffer.append(":0");
/*      */     } else {
/*  778 */       stringBuffer.append(":");
/*  779 */     }  stringBuffer.append(str3);
/*  780 */     if (str4.length() == 1) {
/*  781 */       stringBuffer.append(":0");
/*      */     } else {
/*  783 */       stringBuffer.append(":");
/*  784 */     }  stringBuffer.append(str4);
/*  785 */     if (j > 0) {
/*  786 */       stringBuffer.append(" GMT+");
/*      */     } else {
/*  788 */       stringBuffer.append(" GMT-");
/*      */     }  int m;
/*  790 */     for (m = str5.length(); m < 4; m++)
/*  791 */       stringBuffer.append("0"); 
/*  792 */     stringBuffer.append(str5);
/*      */ 
/*      */ 
/*      */     
/*  796 */     if (timeZoneFormatter != null) {
/*  797 */       stringBuffer.append(" (");
/*  798 */       Date date1 = new Date((long)paramDouble);
/*  799 */       stringBuffer.append(timeZoneFormatter.format(date1));
/*  800 */       stringBuffer.append(") ");
/*      */     } else {
/*  802 */       stringBuffer.append(" ");
/*      */     } 
/*      */     
/*  805 */     if (k < 0)
/*  806 */       stringBuffer.append("-"); 
/*  807 */     for (m = str6.length(); m < 4; m++)
/*  808 */       stringBuffer.append("0"); 
/*  809 */     stringBuffer.append(str6);
/*  810 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
/*  819 */     if (!paramBoolean) {
/*  820 */       return date_format(Now());
/*      */     }
/*  822 */     NativeDate nativeDate = new NativeDate();
/*      */ 
/*      */ 
/*      */     
/*  826 */     if (paramArrayOfObject.length == 0) {
/*  827 */       nativeDate.date = Now();
/*  828 */       return nativeDate;
/*      */     } 
/*      */ 
/*      */     
/*  832 */     if (paramArrayOfObject.length == 1) {
/*      */       double d;
/*      */       
/*  835 */       if (!(paramArrayOfObject[0] instanceof String)) {
/*  836 */         d = ScriptRuntime.toNumber(paramArrayOfObject[0]);
/*      */       } else {
/*      */         
/*  839 */         String str = (String)paramArrayOfObject[0];
/*  840 */         d = date_parseString(str);
/*      */       } 
/*  842 */       nativeDate.date = TimeClip(d);
/*  843 */       return nativeDate;
/*      */     } 
/*      */ 
/*      */     
/*  847 */     double[] arrayOfDouble = new double[7];
/*      */ 
/*      */ 
/*      */     
/*  851 */     for (byte b = 0; b < 7; b++) {
/*  852 */       if (b < paramArrayOfObject.length) {
/*  853 */         double d = ScriptRuntime.toNumber(paramArrayOfObject[b]);
/*      */         
/*  855 */         if (d != d || Double.isInfinite(d)) {
/*  856 */           nativeDate.date = ScriptRuntime.NaN;
/*  857 */           return nativeDate;
/*      */         } 
/*  859 */         arrayOfDouble[b] = ScriptRuntime.toInteger(paramArrayOfObject[b]);
/*      */       } else {
/*  861 */         arrayOfDouble[b] = 0.0D;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  866 */     if (arrayOfDouble[0] >= 0.0D && arrayOfDouble[0] <= 99.0D) {
/*  867 */       arrayOfDouble[0] = arrayOfDouble[0] + 1900.0D;
/*      */     }
/*      */ 
/*      */     
/*  871 */     if (arrayOfDouble[2] < 1.0D) {
/*  872 */       arrayOfDouble[2] = 1.0D;
/*      */     }
/*  874 */     double d1 = MakeDay(arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2]);
/*  875 */     double d2 = MakeTime(arrayOfDouble[3], arrayOfDouble[4], arrayOfDouble[5], arrayOfDouble[6]);
/*  876 */     d2 = MakeDate(d1, d2);
/*  877 */     d2 = internalUTC(d2);
/*  878 */     nativeDate.date = TimeClip(d2);
/*      */     
/*  880 */     return nativeDate;
/*      */   }
/*      */ 
/*      */   
/*  884 */   private static String js_NaN_date_str = "Invalid Date";
/*      */ 
/*      */   
/*  887 */   private static String[] days = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
/*      */ 
/*      */   
/*      */   private static String[] months = { 
/*  891 */       "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
/*  892 */       "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String jsFunction_toString() {
/*  901 */     if (this.date != this.date) {
/*  902 */       return js_NaN_date_str;
/*      */     }
/*  904 */     return date_format(this.date);
/*      */   }
/*      */   
/*      */   public String jsFunction_toLocaleString() {
/*  908 */     if (this.date != this.date) {
/*  909 */       return js_NaN_date_str;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  914 */     Date date1 = new Date((long)this.date);
/*  915 */     return localeDateFormatter.format(date1);
/*      */   }
/*      */   
/*      */   public String jsFunction_toUTCString() {
/*  919 */     if (this.date != this.date) {
/*  920 */       return js_NaN_date_str;
/*      */     }
/*  922 */     StringBuffer stringBuffer = new StringBuffer(60);
/*      */     
/*  924 */     String str1 = Integer.toString(DateFromTime(this.date));
/*  925 */     String str2 = Integer.toString(HourFromTime(this.date));
/*  926 */     String str3 = Integer.toString(MinFromTime(this.date));
/*  927 */     String str4 = Integer.toString(SecFromTime(this.date));
/*  928 */     int i = YearFromTime(this.date);
/*  929 */     String str5 = Integer.toString((i > 0) ? i : -i);
/*      */     
/*  931 */     stringBuffer.append(days[WeekDay(this.date)]);
/*  932 */     stringBuffer.append(", ");
/*  933 */     if (str1.length() == 1)
/*  934 */       stringBuffer.append("0"); 
/*  935 */     stringBuffer.append(str1);
/*  936 */     stringBuffer.append(" ");
/*  937 */     stringBuffer.append(months[MonthFromTime(this.date)]);
/*  938 */     if (i < 0) {
/*  939 */       stringBuffer.append(" -");
/*      */     } else {
/*  941 */       stringBuffer.append(" ");
/*      */     } 
/*  943 */     for (int j = str5.length(); j < 4; j++)
/*  944 */       stringBuffer.append("0"); 
/*  945 */     stringBuffer.append(str5);
/*      */     
/*  947 */     if (str2.length() == 1) {
/*  948 */       stringBuffer.append(" 0");
/*      */     } else {
/*  950 */       stringBuffer.append(" ");
/*  951 */     }  stringBuffer.append(str2);
/*  952 */     if (str3.length() == 1) {
/*  953 */       stringBuffer.append(":0");
/*      */     } else {
/*  955 */       stringBuffer.append(":");
/*  956 */     }  stringBuffer.append(str3);
/*  957 */     if (str4.length() == 1) {
/*  958 */       stringBuffer.append(":0");
/*      */     } else {
/*  960 */       stringBuffer.append(":");
/*  961 */     }  stringBuffer.append(str4);
/*      */     
/*  963 */     stringBuffer.append(" GMT");
/*  964 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */   
/*  968 */   public double jsFunction_valueOf() { return this.date; }
/*      */ 
/*      */ 
/*      */   
/*  972 */   public double jsFunction_getTime() { return this.date; }
/*      */ 
/*      */   
/*      */   public double jsFunction_getYear() {
/*  976 */     if (this.date != this.date) {
/*  977 */       return this.date;
/*      */     }
/*  979 */     int i = YearFromTime(LocalTime(this.date));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  992 */     Context context = Context.getContext();
/*  993 */     int j = context.getLanguageVersion();
/*  994 */     if (j == 100 || 
/*  995 */       j == 110 || 
/*  996 */       j == 120) {
/*      */       
/*  998 */       if (i >= 1900 && i < 2000)
/*  999 */         i -= 1900; 
/*      */     } else {
/* 1001 */       i -= 1900;
/*      */     } 
/* 1003 */     return i;
/*      */   }
/*      */   
/*      */   public double jsFunction_getFullYear() {
/* 1007 */     if (this.date != this.date)
/* 1008 */       return this.date; 
/* 1009 */     return YearFromTime(LocalTime(this.date));
/*      */   }
/*      */   
/*      */   public double jsFunction_getUTCFullYear() {
/* 1013 */     if (this.date != this.date)
/* 1014 */       return this.date; 
/* 1015 */     return YearFromTime(this.date);
/*      */   }
/*      */   
/*      */   public double jsFunction_getMonth() {
/* 1019 */     if (this.date != this.date)
/* 1020 */       return this.date; 
/* 1021 */     return MonthFromTime(LocalTime(this.date));
/*      */   }
/*      */   
/*      */   public double jsFunction_getUTCMonth() {
/* 1025 */     if (this.date != this.date)
/* 1026 */       return this.date; 
/* 1027 */     return MonthFromTime(this.date);
/*      */   }
/*      */   
/*      */   public double jsFunction_getDate() {
/* 1031 */     if (this.date != this.date)
/* 1032 */       return this.date; 
/* 1033 */     return DateFromTime(LocalTime(this.date));
/*      */   }
/*      */   
/*      */   public double jsFunction_getUTCDate() {
/* 1037 */     if (this.date != this.date)
/* 1038 */       return this.date; 
/* 1039 */     return DateFromTime(this.date);
/*      */   }
/*      */   
/*      */   public double jsFunction_getDay() {
/* 1043 */     if (this.date != this.date)
/* 1044 */       return this.date; 
/* 1045 */     return WeekDay(LocalTime(this.date));
/*      */   }
/*      */   
/*      */   public double jsFunction_getUTCDay() {
/* 1049 */     if (this.date != this.date)
/* 1050 */       return this.date; 
/* 1051 */     return WeekDay(this.date);
/*      */   }
/*      */   
/*      */   public double jsFunction_getHours() {
/* 1055 */     if (this.date != this.date)
/* 1056 */       return this.date; 
/* 1057 */     return HourFromTime(LocalTime(this.date));
/*      */   }
/*      */   
/*      */   public double jsFunction_getUTCHours() {
/* 1061 */     if (this.date != this.date)
/* 1062 */       return this.date; 
/* 1063 */     return HourFromTime(this.date);
/*      */   }
/*      */   
/*      */   public double jsFunction_getMinutes() {
/* 1067 */     if (this.date != this.date)
/* 1068 */       return this.date; 
/* 1069 */     return MinFromTime(LocalTime(this.date));
/*      */   }
/*      */   
/*      */   public double jsFunction_getUTCMinutes() {
/* 1073 */     if (this.date != this.date)
/* 1074 */       return this.date; 
/* 1075 */     return MinFromTime(this.date);
/*      */   }
/*      */   
/*      */   public double jsFunction_getSeconds() {
/* 1079 */     if (this.date != this.date)
/* 1080 */       return this.date; 
/* 1081 */     return SecFromTime(LocalTime(this.date));
/*      */   }
/*      */   
/*      */   public double jsFunction_getUTCSeconds() {
/* 1085 */     if (this.date != this.date)
/* 1086 */       return this.date; 
/* 1087 */     return SecFromTime(this.date);
/*      */   }
/*      */   
/*      */   public double jsFunction_getMilliseconds() {
/* 1091 */     if (this.date != this.date)
/* 1092 */       return this.date; 
/* 1093 */     return msFromTime(LocalTime(this.date));
/*      */   }
/*      */   
/*      */   public double jsFunction_getUTCMilliseconds() {
/* 1097 */     if (this.date != this.date)
/* 1098 */       return this.date; 
/* 1099 */     return msFromTime(this.date);
/*      */   }
/*      */   
/*      */   public double jsFunction_getTimezoneOffset() {
/* 1103 */     if (this.date != this.date)
/* 1104 */       return this.date; 
/* 1105 */     return (this.date - LocalTime(this.date)) / 60000.0D;
/*      */   }
/*      */   
/*      */   public double jsFunction_setTime(double paramDouble) {
/* 1109 */     this.date = TimeClip(paramDouble);
/* 1110 */     return this.date;
/*      */   }
/*      */ 
/*      */   
/*      */   private static NativeDate checkInstance(Scriptable paramScriptable, Function paramFunction) {
/* 1115 */     if (paramScriptable == null || !(paramScriptable instanceof NativeDate)) {
/* 1116 */       Context context = Context.getCurrentContext();
/* 1117 */       Object[] arrayOfObject = { ((NativeFunction)paramFunction).names[0] };
/* 1118 */       String str = Context.getMessage("msg.incompat.call", arrayOfObject);
/* 1119 */       throw NativeGlobal.constructError(context, "TypeError", str, paramFunction);
/*      */     } 
/* 1121 */     return (NativeDate)paramScriptable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double makeTime(Scriptable paramScriptable, Object[] paramArrayOfObject, int paramInt, boolean paramBoolean, Function paramFunction) {
/* 1129 */     double d5, d4, d3, d2, d1, arrayOfDouble[] = new double[4];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1136 */     NativeDate nativeDate = checkInstance(paramScriptable, paramFunction);
/* 1137 */     double d8 = nativeDate.date;
/*      */ 
/*      */     
/* 1140 */     if (d8 != d8) {
/* 1141 */       return d8;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1151 */     if (paramArrayOfObject.length == 0)
/* 1152 */       paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1); 
/*      */     byte b;
/* 1154 */     for (b = 0; b < paramArrayOfObject.length && b < paramInt; b++) {
/* 1155 */       arrayOfDouble[b] = ScriptRuntime.toNumber(paramArrayOfObject[b]);
/*      */ 
/*      */       
/* 1158 */       if (arrayOfDouble[b] != arrayOfDouble[b] || Double.isInfinite(arrayOfDouble[b])) {
/* 1159 */         nativeDate.date = ScriptRuntime.NaN;
/* 1160 */         return nativeDate.date;
/*      */       } 
/* 1162 */       arrayOfDouble[b] = ScriptRuntime.toInteger(arrayOfDouble[b]);
/*      */     } 
/*      */     
/* 1165 */     if (paramBoolean) {
/* 1166 */       d5 = LocalTime(d8);
/*      */     } else {
/* 1168 */       d5 = d8;
/*      */     } 
/* 1170 */     b = 0;
/* 1171 */     int i = paramArrayOfObject.length;
/*      */     
/* 1173 */     if (paramInt >= 4 && b < i) {
/* 1174 */       d1 = arrayOfDouble[b++];
/*      */     } else {
/* 1176 */       d1 = HourFromTime(d5);
/*      */     } 
/* 1178 */     if (paramInt >= 3 && b < i) {
/* 1179 */       d2 = arrayOfDouble[b++];
/*      */     } else {
/* 1181 */       d2 = MinFromTime(d5);
/*      */     } 
/* 1183 */     if (paramInt >= 2 && b < i) {
/* 1184 */       d3 = arrayOfDouble[b++];
/*      */     } else {
/* 1186 */       d3 = SecFromTime(d5);
/*      */     } 
/* 1188 */     if (paramInt >= 1 && b < i) {
/* 1189 */       d4 = arrayOfDouble[b++];
/*      */     } else {
/* 1191 */       d4 = msFromTime(d5);
/*      */     } 
/* 1193 */     double d6 = MakeTime(d1, d2, d3, d4);
/* 1194 */     double d7 = MakeDate(Day(d5), d6);
/*      */     
/* 1196 */     if (paramBoolean)
/* 1197 */       d7 = internalUTC(d7); 
/* 1198 */     d8 = TimeClip(d7);
/*      */     
/* 1200 */     nativeDate.date = d8;
/* 1201 */     return d8;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1209 */   public static double jsFunction_setMilliseconds(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 1, true, paramFunction); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1217 */   public static double jsFunction_setUTCMilliseconds(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 1, false, paramFunction); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1225 */   public static double jsFunction_setSeconds(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 2, true, paramFunction); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1233 */   public static double jsFunction_setUTCSeconds(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 2, false, paramFunction); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1241 */   public static double jsFunction_setMinutes(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 3, true, paramFunction); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1249 */   public static double jsFunction_setUTCMinutes(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 3, false, paramFunction); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1257 */   public static double jsFunction_setHours(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 4, true, paramFunction); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1265 */   public static double jsFunction_setUTCHours(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeTime(paramScriptable, paramArrayOfObject, 4, false, paramFunction); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double makeDate(Scriptable paramScriptable, Object[] paramArrayOfObject, int paramInt, boolean paramBoolean, Function paramFunction) {
/* 1273 */     double d4, d2, d1, arrayOfDouble[] = new double[3];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1278 */     NativeDate nativeDate = checkInstance(paramScriptable, paramFunction);
/* 1279 */     double d6 = nativeDate.date;
/*      */ 
/*      */     
/* 1282 */     if (paramArrayOfObject.length == 0)
/* 1283 */       paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1); 
/*      */     byte b;
/* 1285 */     for (b = 0; b < paramArrayOfObject.length && b < paramInt; b++) {
/* 1286 */       arrayOfDouble[b] = ScriptRuntime.toNumber(paramArrayOfObject[b]);
/*      */ 
/*      */       
/* 1289 */       if (arrayOfDouble[b] != arrayOfDouble[b] || Double.isInfinite(arrayOfDouble[b])) {
/* 1290 */         nativeDate.date = ScriptRuntime.NaN;
/* 1291 */         return nativeDate.date;
/*      */       } 
/* 1293 */       arrayOfDouble[b] = ScriptRuntime.toInteger(arrayOfDouble[b]);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1298 */     if (d6 != d6) {
/* 1299 */       if (paramArrayOfObject.length < 3) {
/* 1300 */         return ScriptRuntime.NaN;
/*      */       }
/* 1302 */       d4 = 0.0D;
/*      */     
/*      */     }
/* 1305 */     else if (paramBoolean) {
/* 1306 */       d4 = LocalTime(d6);
/*      */     } else {
/* 1308 */       d4 = d6;
/*      */     } 
/*      */     
/* 1311 */     b = 0;
/* 1312 */     int i = paramArrayOfObject.length;
/*      */     
/* 1314 */     if (paramInt >= 3 && b < i) {
/* 1315 */       d1 = arrayOfDouble[b++];
/*      */     } else {
/* 1317 */       d1 = YearFromTime(d4);
/*      */     } 
/* 1319 */     if (paramInt >= 2 && b < i) {
/* 1320 */       d2 = arrayOfDouble[b++];
/*      */     } else {
/* 1322 */       d2 = MonthFromTime(d4);
/*      */     } 
/* 1324 */     if (paramInt >= 1 && b < i) {
/* 1325 */       d3 = arrayOfDouble[b++];
/*      */     } else {
/* 1327 */       d3 = DateFromTime(d4);
/*      */     } 
/* 1329 */     double d3 = MakeDay(d1, d2, d3);
/* 1330 */     double d5 = MakeDate(d3, TimeWithinDay(d4));
/*      */     
/* 1332 */     if (paramBoolean) {
/* 1333 */       d5 = internalUTC(d5);
/*      */     }
/* 1335 */     d6 = TimeClip(d5);
/*      */     
/* 1337 */     nativeDate.date = d6;
/* 1338 */     return d6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1346 */   public static double jsFunction_setDate(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeDate(paramScriptable, paramArrayOfObject, 1, true, paramFunction); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1354 */   public static double jsFunction_setUTCDate(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeDate(paramScriptable, paramArrayOfObject, 1, false, paramFunction); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1362 */   public static double jsFunction_setMonth(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeDate(paramScriptable, paramArrayOfObject, 2, true, paramFunction); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1370 */   public static double jsFunction_setUTCMonth(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeDate(paramScriptable, paramArrayOfObject, 2, false, paramFunction); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1378 */   public static double jsFunction_setFullYear(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeDate(paramScriptable, paramArrayOfObject, 3, true, paramFunction); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1386 */   public static double jsFunction_setUTCFullYear(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) { return makeDate(paramScriptable, paramArrayOfObject, 3, false, paramFunction); }
/*      */ 
/*      */ 
/*      */   
/*      */   public double jsFunction_setYear(double paramDouble) {
/* 1391 */     if (paramDouble != paramDouble || Double.isInfinite(paramDouble)) {
/* 1392 */       this.date = ScriptRuntime.NaN;
/* 1393 */       return this.date;
/*      */     } 
/*      */     
/* 1396 */     if (this.date != this.date) {
/* 1397 */       this.date = 0.0D;
/*      */     }
/* 1399 */     if (paramDouble >= 0.0D && paramDouble <= 99.0D) {
/* 1400 */       paramDouble += 1900.0D;
/*      */     }
/* 1402 */     double d1 = MakeDay(paramDouble, MonthFromTime(this.date), DateFromTime(this.date));
/* 1403 */     double d2 = MakeDate(d1, TimeWithinDay(this.date));
/* 1404 */     d2 = internalUTC(d2);
/*      */     
/* 1406 */     this.date = TimeClip(d2);
/* 1407 */     return this.date;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1412 */   private static final TimeZone thisTimeZone = TimeZone.getDefault();
/*      */   
/* 1414 */   private static final double LocalTZA = thisTimeZone.getRawOffset(); private static DateFormat timeZoneFormatter; private static final DateFormat localeDateFormatter;
/*      */   private double date;
/*      */   
/*      */   static  {
/*      */     try {
/* 1419 */       Class[] arrayOfClass = { String.class };
/* 1420 */       Object[] arrayOfObject = { "zzz" };
/* 1421 */       Class clazz = Class.forName("java.text.SimpleDateFormat");
/* 1422 */       Constructor constructor = 
/* 1423 */         clazz.getDeclaredConstructor(arrayOfClass);
/* 1424 */       timeZoneFormatter = 
/* 1425 */         (DateFormat)constructor.newInstance(arrayOfObject);
/* 1426 */     } catch (Exception exception) {
/*      */ 
/*      */ 
/*      */       
/* 1430 */       timeZoneFormatter = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1435 */     localeDateFormatter = DateFormat.getDateTimeInstance(1, 
/* 1436 */         1);
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeDate.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */