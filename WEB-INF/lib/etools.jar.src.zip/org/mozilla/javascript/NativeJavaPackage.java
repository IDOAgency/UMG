package org.mozilla.javascript;

import java.lang.reflect.Method;

public class NativeJavaPackage extends ScriptableObject {
  static final String[] commonPackages = { "java.lang", 
      "java.lang.reflect", 
      "java.io", 
      "java.math", 
      "java.util", 
      "java.util.zip", 
      "java.text", 
      "java.text.resources", 
      "java.applet" };
  
  private String packageName;
  
  public static Scriptable init(Scriptable paramScriptable) throws PropertyException {
    NativeJavaPackage nativeJavaPackage1 = new NativeJavaPackage("");
    nativeJavaPackage1.setPrototype(ScriptableObject.getObjectPrototype(paramScriptable));
    nativeJavaPackage1.setParentScope(paramScriptable);
    NativeJavaPackage nativeJavaPackage2 = (NativeJavaPackage)nativeJavaPackage1.get("java", 
        nativeJavaPackage1);
    ScriptableObject scriptableObject = (ScriptableObject)paramScriptable;
    scriptableObject.defineProperty("Packages", nativeJavaPackage1, 2);
    scriptableObject.defineProperty("java", nativeJavaPackage2, 2);
    for (byte b = 0; b < commonPackages.length; b++)
      nativeJavaPackage1.forcePackage(commonPackages[b]); 
    NativeJavaObject.initJSObject();
    Method[] arrayOfMethod = FunctionObject.findMethods(NativeJavaPackage.class, 
        "jsFunction_getClass");
    FunctionObject functionObject = new FunctionObject("getClass", arrayOfMethod[0], scriptableObject);
    scriptableObject.defineProperty("getClass", functionObject, 2);
    return nativeJavaPackage1;
  }
  
  void forcePackage(String paramString) {
    NativeJavaPackage nativeJavaPackage;
    int i = paramString.indexOf('.');
    if (i == -1)
      i = paramString.length(); 
    String str = paramString.substring(0, i);
    Object object = super.get(str, this);
    if (object != null && object instanceof NativeJavaPackage) {
      nativeJavaPackage = (NativeJavaPackage)object;
    } else {
      String str1 = (this.packageName.length() == 0) ? 
        str : (
        String.valueOf(this.packageName) + "." + str);
      nativeJavaPackage = new NativeJavaPackage(str1);
      nativeJavaPackage.setParentScope(this);
      nativeJavaPackage.setPrototype(this.prototype);
      super.put(str, this, nativeJavaPackage);
    } 
    if (i < paramString.length())
      nativeJavaPackage.forcePackage(paramString.substring(i + 1)); 
  }
  
  public NativeJavaPackage(String paramString) { this.packageName = paramString; }
  
  public String getClassName() { return "JavaPackage"; }
  
  public boolean has(String paramString, int paramInt, Scriptable paramScriptable) { return true; }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) {}
  
  public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
    throw Context.reportRuntimeError(
        Context.getMessage("msg.pkg.int", null));
  }
  
  public Object get(String paramString, Scriptable paramScriptable) { return getPkgProperty(paramString, paramScriptable, true); }
  
  public Object get(int paramInt, Scriptable paramScriptable) { return Scriptable.NOT_FOUND; }
  
  Object getPkgProperty(String paramString, Scriptable paramScriptable, boolean paramBoolean) {
    Object object1;
    Object object = super.get(paramString, paramScriptable);
    if (object != Scriptable.NOT_FOUND)
      return object; 
    String str = (this.packageName.length() == 0) ? 
      paramString : (
      String.valueOf(this.packageName) + "." + paramString);
    Context context = Context.getContext();
    SecuritySupport securitySupport = context.getSecuritySupport();
    try {
      if (securitySupport != null && !securitySupport.visibleToScripts(str))
        throw new ClassNotFoundException(); 
      Class clazz = ScriptRuntime.loadClassName(str);
      object1 = NativeJavaClass.wrap(ScriptableObject.getTopLevelScope(this), clazz);
      object1.setParentScope(this);
      object1.setPrototype(this.prototype);
    } catch (ClassNotFoundException classNotFoundException) {
      if (paramBoolean) {
        NativeJavaPackage nativeJavaPackage = new NativeJavaPackage(str);
        nativeJavaPackage.setParentScope(this);
        nativeJavaPackage.setPrototype(this.prototype);
        object1 = nativeJavaPackage;
      } else {
        object1 = null;
      } 
    } 
    if (object1 != null)
      super.put(paramString, paramScriptable, object1); 
    return object1;
  }
  
  public Object getDefaultValue(Class paramClass) { return toString(); }
  
  public String toString() { return "[JavaPackage " + this.packageName + "]"; }
  
  public static Scriptable jsFunction_getClass(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    if (paramArrayOfObject.length > 0 && paramArrayOfObject[0] instanceof NativeJavaObject) {
      NativeJavaObject nativeJavaObject = (NativeJavaObject)paramArrayOfObject[0];
      Scriptable scriptable = ScriptableObject.getTopLevelScope(paramScriptable);
      Class clazz = nativeJavaObject.unwrap().getClass();
      String str = "Packages." + clazz.getName();
      int i = 0;
      while (true) {
        int j = str.indexOf('.', i);
        String str1 = (j == -1) ? 
          str.substring(i) : 
          str.substring(i, j);
        Object object = scriptable.get(str1, scriptable);
        if (object instanceof Scriptable) {
          scriptable = (Scriptable)object;
          if (j == -1)
            return scriptable; 
          i = j + 1;
          continue;
        } 
        break;
      } 
    } 
    throw Context.reportRuntimeError(
        Context.getMessage("msg.not.java.obj", null));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeJavaPackage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */