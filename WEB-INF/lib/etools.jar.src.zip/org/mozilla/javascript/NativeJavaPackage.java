/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeJavaPackage
/*     */   extends ScriptableObject
/*     */ {
/*  60 */   static final String[] commonPackages = { "java.lang", 
/*  61 */       "java.lang.reflect", 
/*  62 */       "java.io", 
/*  63 */       "java.math", 
/*  64 */       "java.util", 
/*  65 */       "java.util.zip", 
/*  66 */       "java.text", 
/*  67 */       "java.text.resources", 
/*  68 */       "java.applet" };
/*     */   
/*     */   private String packageName;
/*     */ 
/*     */   
/*     */   public static Scriptable init(Scriptable paramScriptable) throws PropertyException {
/*  74 */     NativeJavaPackage nativeJavaPackage1 = new NativeJavaPackage("");
/*  75 */     nativeJavaPackage1.setPrototype(ScriptableObject.getObjectPrototype(paramScriptable));
/*  76 */     nativeJavaPackage1.setParentScope(paramScriptable);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     NativeJavaPackage nativeJavaPackage2 = (NativeJavaPackage)nativeJavaPackage1.get("java", 
/*  82 */         nativeJavaPackage1);
/*     */ 
/*     */ 
/*     */     
/*  86 */     ScriptableObject scriptableObject = (ScriptableObject)paramScriptable;
/*     */     
/*  88 */     scriptableObject.defineProperty("Packages", nativeJavaPackage1, 2);
/*  89 */     scriptableObject.defineProperty("java", nativeJavaPackage2, 2);
/*     */     
/*  91 */     for (byte b = 0; b < commonPackages.length; b++) {
/*  92 */       nativeJavaPackage1.forcePackage(commonPackages[b]);
/*     */     }
/*  94 */     NativeJavaObject.initJSObject();
/*     */     
/*  96 */     Method[] arrayOfMethod = FunctionObject.findMethods(NativeJavaPackage.class, 
/*  97 */         "jsFunction_getClass");
/*  98 */     FunctionObject functionObject = new FunctionObject("getClass", arrayOfMethod[0], scriptableObject);
/*  99 */     scriptableObject.defineProperty("getClass", functionObject, 2);
/*     */ 
/*     */     
/* 102 */     return nativeJavaPackage1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void forcePackage(String paramString) {
/*     */     NativeJavaPackage nativeJavaPackage;
/* 109 */     int i = paramString.indexOf('.');
/* 110 */     if (i == -1) {
/* 111 */       i = paramString.length();
/*     */     }
/* 113 */     String str = paramString.substring(0, i);
/* 114 */     Object object = super.get(str, this);
/* 115 */     if (object != null && object instanceof NativeJavaPackage) {
/* 116 */       nativeJavaPackage = (NativeJavaPackage)object;
/*     */     } else {
/* 118 */       String str1 = (this.packageName.length() == 0) ? 
/* 119 */         str : (
/* 120 */         String.valueOf(this.packageName) + "." + str);
/* 121 */       nativeJavaPackage = new NativeJavaPackage(str1);
/* 122 */       nativeJavaPackage.setParentScope(this);
/* 123 */       nativeJavaPackage.setPrototype(this.prototype);
/* 124 */       super.put(str, this, nativeJavaPackage);
/*     */     } 
/* 126 */     if (i < paramString.length()) {
/* 127 */       nativeJavaPackage.forcePackage(paramString.substring(i + 1));
/*     */     }
/*     */   }
/*     */   
/* 131 */   public NativeJavaPackage(String paramString) { this.packageName = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 135 */   public String getClassName() { return "JavaPackage"; }
/*     */ 
/*     */ 
/*     */   
/* 139 */   public boolean has(String paramString, int paramInt, Scriptable paramScriptable) { return true; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) {}
/*     */ 
/*     */   
/*     */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
/* 147 */     throw Context.reportRuntimeError(
/* 148 */         Context.getMessage("msg.pkg.int", null));
/*     */   }
/*     */ 
/*     */   
/* 152 */   public Object get(String paramString, Scriptable paramScriptable) { return getPkgProperty(paramString, paramScriptable, true); }
/*     */ 
/*     */ 
/*     */   
/* 156 */   public Object get(int paramInt, Scriptable paramScriptable) { return Scriptable.NOT_FOUND; }
/*     */ 
/*     */ 
/*     */   
/*     */   Object getPkgProperty(String paramString, Scriptable paramScriptable, boolean paramBoolean) {
/*     */     Object object1;
/* 162 */     Object object = super.get(paramString, paramScriptable);
/* 163 */     if (object != Scriptable.NOT_FOUND) {
/* 164 */       return object;
/*     */     }
/* 166 */     String str = (this.packageName.length() == 0) ? 
/* 167 */       paramString : (
/* 168 */       String.valueOf(this.packageName) + "." + paramString);
/* 169 */     Context context = Context.getContext();
/* 170 */     SecuritySupport securitySupport = context.getSecuritySupport();
/*     */     
/*     */     try {
/* 173 */       if (securitySupport != null && !securitySupport.visibleToScripts(str))
/* 174 */         throw new ClassNotFoundException(); 
/* 175 */       Class clazz = ScriptRuntime.loadClassName(str);
/* 176 */       object1 = NativeJavaClass.wrap(ScriptableObject.getTopLevelScope(this), clazz);
/* 177 */       object1.setParentScope(this);
/* 178 */       object1.setPrototype(this.prototype);
/* 179 */     } catch (ClassNotFoundException classNotFoundException) {
/* 180 */       if (paramBoolean) {
/* 181 */         NativeJavaPackage nativeJavaPackage = new NativeJavaPackage(str);
/* 182 */         nativeJavaPackage.setParentScope(this);
/* 183 */         nativeJavaPackage.setPrototype(this.prototype);
/* 184 */         object1 = nativeJavaPackage;
/*     */       } else {
/* 186 */         object1 = null;
/*     */       } 
/*     */     } 
/* 189 */     if (object1 != null)
/*     */     {
/*     */       
/* 192 */       super.put(paramString, paramScriptable, object1);
/*     */     }
/* 194 */     return object1;
/*     */   }
/*     */ 
/*     */   
/* 198 */   public Object getDefaultValue(Class paramClass) { return toString(); }
/*     */ 
/*     */ 
/*     */   
/* 202 */   public String toString() { return "[JavaPackage " + this.packageName + "]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Scriptable jsFunction_getClass(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 210 */     if (paramArrayOfObject.length > 0 && paramArrayOfObject[0] instanceof NativeJavaObject) {
/* 211 */       NativeJavaObject nativeJavaObject = (NativeJavaObject)paramArrayOfObject[0];
/* 212 */       Scriptable scriptable = ScriptableObject.getTopLevelScope(paramScriptable);
/* 213 */       Class clazz = nativeJavaObject.unwrap().getClass();
/*     */ 
/*     */       
/* 216 */       String str = "Packages." + clazz.getName();
/* 217 */       int i = 0;
/*     */       while (true) {
/* 219 */         int j = str.indexOf('.', i);
/* 220 */         String str1 = (j == -1) ? 
/* 221 */           str.substring(i) : 
/* 222 */           str.substring(i, j);
/* 223 */         Object object = scriptable.get(str1, scriptable);
/* 224 */         if (object instanceof Scriptable) {
/*     */           
/* 226 */           scriptable = (Scriptable)object;
/* 227 */           if (j == -1)
/* 228 */             return scriptable; 
/* 229 */           i = j + 1; continue;
/*     */         }  break;
/*     */       } 
/* 232 */     }  throw Context.reportRuntimeError(
/* 233 */         Context.getMessage("msg.not.java.obj", null));
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeJavaPackage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */