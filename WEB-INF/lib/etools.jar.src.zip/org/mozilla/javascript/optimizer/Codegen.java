package org.mozilla.javascript.optimizer;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Vector;
import org.mozilla.classfile.ClassFileWriter;
import org.mozilla.javascript.ClassNameHelper;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.FunctionNode;
import org.mozilla.javascript.IRFactory;
import org.mozilla.javascript.Interpreter;
import org.mozilla.javascript.JavaAdapter;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.NativeScript;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.SecuritySupport;
import org.mozilla.javascript.ShallowNodeIterator;
import org.mozilla.javascript.TokenStream;
import org.mozilla.javascript.VariableTable;
import org.mozilla.javascript.WrappedException;

public class Codegen extends Interpreter {
  private static final String normalFunctionSuperClassName = "org.mozilla.javascript.NativeFunction";
  
  private static final String normalScriptSuperClassName = "org.mozilla.javascript.NativeScript";
  
  private static final String debugFunctionSuperClassName = "org.mozilla.javascript.debug.NativeFunctionDebug";
  
  private static final String debugScriptSuperClassName = "org.mozilla.javascript.debug.NativeScriptDebug";
  
  private String superClassName;
  
  private String superClassSlashName;
  
  private String name;
  
  private int ordinal;
  
  boolean inFunction;
  
  boolean inDirectCallFunction;
  
  private ClassFileWriter classFile;
  
  private Vector namesVector;
  
  private Vector classFilesVector;
  
  private short scriptRuntimeIndex;
  
  private int version;
  
  private OptClassNameHelper itsNameHelper;
  
  private static JavaScriptClassLoader classLoader;
  
  private String itsSourceFile;
  
  private int itsLineNumber;
  
  private int stackDepth;
  
  private int stackDepthMax;
  
  private static final int MAX_LOCALS = 256;
  
  private boolean[] locals;
  
  private short firstFreeLocal;
  
  private short localsMax;
  
  private ConstantList itsConstantList = new ConstantList();
  
  private short variableObjectLocal;
  
  private short scriptResultLocal;
  
  private short contextLocal;
  
  private short argsLocal;
  
  private short thisObjLocal;
  
  private short funObjLocal;
  
  private short debug_pcLocal;
  
  private short debugStopSubRetLocal;
  
  private short itsZeroArgArray;
  
  private short itsOneArgArray;
  
  private boolean hasVarsInRegs;
  
  private boolean itsForcedObjectParameters;
  
  private boolean trivialInit;
  
  private short itsLocalAllocationBase;
  
  private OptVariableTable vars;
  
  private OptVariableTable debugVars;
  
  private int epilogueLabel;
  
  private int optLevel;
  
  private static final int debugLevel = 0;
  
  private int debugStopSubLabel;
  
  private short[] debugLineMap;
  
  private short debugLineEntryCount;
  
  private static final int DEBUG_LINE_MAP_INITIAL_SIZE = 100;
  
  private static final int DEBUG_LINE_MAP_RESIZE_INCREMENT = 100;
  
  public IRFactory createIRFactory(TokenStream paramTokenStream, ClassNameHelper paramClassNameHelper, Scriptable paramScriptable) { return new OptIRFactory(paramTokenStream, paramClassNameHelper, paramScriptable); }
  
  public Node transform(Node paramNode, TokenStream paramTokenStream, Scriptable paramScriptable) {
    OptTransformer optTransformer = new OptTransformer(new Hashtable(11));
    return optTransformer.transform(paramNode, null, paramTokenStream, paramScriptable);
  }
  
  public Object compile(Context paramContext, Scriptable paramScriptable, Node paramNode, Object paramObject, SecuritySupport paramSecuritySupport, ClassNameHelper paramClassNameHelper) throws IOException {
    Vector vector1 = new Vector();
    Vector vector2 = new Vector();
    String str = null;
    IllegalArgumentException illegalArgumentException = null;
    Class clazz = null;
    try {
      if (paramContext.getOptimizationLevel() > 0)
        (new Optimizer()).optimize(paramNode, paramContext.getOptimizationLevel()); 
      str = generateCode(paramNode, vector2, vector1, paramClassNameHelper);
      for (byte b = 0; b < vector2.size(); b++) {
        String str1 = (String)vector2.elementAt(b);
        byte[] arrayOfByte = (byte[])vector1.elementAt(b);
        if (paramClassNameHelper.getGeneratingDirectory() != null) {
          try {
            int i = str1.lastIndexOf('.');
            if (i != -1)
              str1 = str1.substring(i + 1); 
            String str2 = 
              paramClassNameHelper.getTargetClassFileName(str1);
            FileOutputStream fileOutputStream = new FileOutputStream(str2);
            fileOutputStream.write(arrayOfByte);
            fileOutputStream.close();
          } catch (IOException iOException) {
            throw WrappedException.wrapException(iOException);
          } 
        } else {
          try {
            Class clazz1;
            if (paramSecuritySupport == null) {
              if (Context.isSecurityDomainRequired())
                throw new SecurityException("Required security context missing"); 
              if (classLoader == null)
                classLoader = new JavaScriptClassLoader(); 
              clazz1 = classLoader.defineClass(str1, arrayOfByte);
              ClassLoader classLoader1 = clazz1.getClassLoader();
              clazz1 = classLoader1.loadClass(str1);
            } else {
              clazz1 = paramSecuritySupport.defineClass(str1, arrayOfByte, 
                  paramObject);
            } 
            if (str1.equals(str))
              clazz = clazz1; 
          } catch (ClassFormatError classFormatError) {
            throw new RuntimeException(classFormatError.toString());
          } catch (ClassNotFoundException classNotFoundException) {
            throw new RuntimeException(classNotFoundException.toString());
          } 
        } 
      } 
    } catch (SecurityException securityException) {
      illegalArgumentException = securityException;
    } catch (IllegalArgumentException illegalArgumentException1) {
      illegalArgumentException = illegalArgumentException1;
    } 
    if (illegalArgumentException != null)
      throw new RuntimeException("Malformed optimizer package " + illegalArgumentException); 
    OptClassNameHelper optClassNameHelper = (OptClassNameHelper)paramClassNameHelper;
    if (optClassNameHelper.getTargetImplements() != null || 
      optClassNameHelper.getTargetExtends() != null) {
      String str1 = optClassNameHelper.getJavaScriptClassName(null, true);
      NativeObject nativeObject = new NativeObject();
      ShallowNodeIterator shallowNodeIterator = paramNode.getChildIterator();
      while (shallowNodeIterator.hasMoreElements()) {
        Node node = shallowNodeIterator.nextNode();
        if (node.getType() == 109)
          nativeObject.put((String)node.getDatum(), nativeObject, 
              node.getProp(5)); 
      } 
      try {
        Class clazz1 = optClassNameHelper.getTargetExtends();
        if (clazz1 == null)
          clazz1 = Object.class; 
        JavaAdapter.createAdapterClass(paramContext, nativeObject, str1, 
            clazz1, 
            optClassNameHelper.getTargetImplements(), 
            str, 
            optClassNameHelper);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new Error(classNotFoundException.toString());
      } 
    } 
    if (paramNode instanceof OptFunctionNode)
      return ScriptRuntime.createFunctionObject(paramScriptable, clazz, paramContext, true); 
    try {
      if (clazz == null)
        return null; 
      NativeScript nativeScript = (NativeScript)clazz.newInstance();
      if (paramScriptable != null) {
        nativeScript.setPrototype(ScriptableObject.getClassPrototype(paramScriptable, 
              "Script"));
        nativeScript.setParentScope(paramScriptable);
      } 
      return nativeScript;
    } catch (InstantiationException instantiationException) {
    
    } catch (IllegalAccessException illegalAccessException) {}
    throw new RuntimeException("Unable to instantiate compiled class");
  }
  
  void addByteCode(byte paramByte) { this.classFile.add(paramByte); }
  
  void addByteCode(byte paramByte, int paramInt) { this.classFile.add(paramByte, paramInt); }
  
  void addByteCode(byte paramByte, String paramString) { this.classFile.add(paramByte, paramString); }
  
  void addVirtualInvoke(String paramString1, String paramString2, String paramString3, String paramString4) {
    this.classFile.add((byte)-74, 
        paramString1, 
        paramString2, 
        paramString3, 
        paramString4);
  }
  
  void addStaticInvoke(String paramString1, String paramString2, String paramString3, String paramString4) {
    this.classFile.add((byte)-72, 
        paramString1, 
        paramString2, 
        paramString3, 
        paramString4);
  }
  
  void addScriptRuntimeInvoke(String paramString1, String paramString2, String paramString3) {
    this.classFile.add((byte)-72, 
        "org/mozilla/javascript/ScriptRuntime", 
        paramString1, 
        paramString2, 
        paramString3);
  }
  
  void addOptRuntimeInvoke(String paramString1, String paramString2, String paramString3) {
    this.classFile.add((byte)-72, 
        "org/mozilla/javascript/optimizer/OptRuntime", 
        paramString1, 
        paramString2, 
        paramString3);
  }
  
  void addSpecialInvoke(String paramString1, String paramString2, String paramString3, String paramString4) {
    this.classFile.add((byte)-73, 
        paramString1, 
        paramString2, 
        paramString3, 
        paramString4);
  }
  
  void addDoubleConstructor() {
    this.classFile.add((byte)-73, 
        "java/lang/Double", 
        "<init>", "(D)", "V");
  }
  
  public int markLabel(int paramInt) { return this.classFile.markLabel(paramInt); }
  
  public int markLabel(int paramInt, short paramShort) { return this.classFile.markLabel(paramInt, paramShort); }
  
  public int acquireLabel() { return this.classFile.acquireLabel(); }
  
  public void emitDirectConstructor(OptFunctionNode paramOptFunctionNode) {
    int i = 
      17;
    this.classFile.startMethod("constructDirect", 
        String.valueOf(paramOptFunctionNode.getDirectCallParameterSignature()) + 
        "Ljava/lang/Object;", 
        i);
    int j = paramOptFunctionNode.getVariableTable().getParameterCount();
    short s = (short)(4 + j * 3 + 1);
    addByteCode((byte)-69, "org/mozilla/javascript/NativeObject");
    addByteCode((byte)89);
    this.classFile.add((byte)-73, 
        "org/mozilla/javascript/NativeObject", 
        "<init>", "()", "V");
    astore(s);
    aload(s);
    aload((short)0);
    addVirtualInvoke("org/mozilla/javascript/NativeFunction", 
        "getClassPrototype", 
        "()", "Lorg/mozilla/javascript/Scriptable;");
    this.classFile.add((byte)-71, 
        "org/mozilla/javascript/Scriptable", 
        "setPrototype", 
        "(Lorg/mozilla/javascript/Scriptable;)", 
        "V");
    aload(s);
    aload((short)0);
    addVirtualInvoke("org/mozilla/javascript/NativeFunction", 
        "getParentScope", 
        "()", "Lorg/mozilla/javascript/Scriptable;");
    this.classFile.add((byte)-71, 
        "org/mozilla/javascript/Scriptable", 
        "setPrototype", 
        "(Lorg/mozilla/javascript/Scriptable;)", 
        "V");
    aload((short)0);
    aload((short)1);
    aload((short)2);
    aload(s);
    for (byte b = 0; b < j; b++) {
      aload((short)(4 + b * 3));
      dload((short)(5 + b * 3));
    } 
    aload((short)(4 + j * 3));
    addVirtualInvoke(this.name, 
        "callDirect", 
        paramOptFunctionNode.getDirectCallParameterSignature(), 
        "Ljava/lang/Object;");
    astore((short)(s + 1));
    int k = acquireLabel();
    aload((short)(s + 1));
    addByteCode((byte)-58, k);
    aload((short)(s + 1));
    pushUndefined();
    addByteCode((byte)-91, k);
    aload((short)(s + 1));
    addByteCode((byte)-63, "org/mozilla/javascript/Scriptable");
    addByteCode((byte)-103, k);
    aload((short)(s + 1));
    addByteCode((byte)-64, "org/mozilla/javascript/Scriptable");
    addByteCode((byte)-80);
    markLabel(k);
    aload(s);
    addByteCode((byte)-80);
    this.classFile.stopMethod((short)(s + 2), null);
  }
  
  public String generateCode(Node paramNode, Vector paramVector1, Vector paramVector2, ClassNameHelper paramClassNameHelper) {
    Node node;
    this.itsNameHelper = (OptClassNameHelper)paramClassNameHelper;
    this.namesVector = paramVector1;
    this.classFilesVector = paramVector2;
    Context context = Context.getCurrentContext();
    this.itsSourceFile = null;
    if (context.isGeneratingDebug())
      this.itsSourceFile = (String)paramNode.getProp(16); 
    this.version = context.getLanguageVersion();
    this.optLevel = context.getOptimizationLevel();
    this.inFunction = !(paramNode.getType() != 109);
    this.superClassName = this.inFunction ? 
      "org.mozilla.javascript.NativeFunction" : 
      "org.mozilla.javascript.NativeScript";
    this.superClassSlashName = this.superClassName.replace('.', '/');
    if (this.inFunction) {
      OptFunctionNode optFunctionNode = (OptFunctionNode)paramNode;
      this.inDirectCallFunction = optFunctionNode.isTargetOfDirectCall();
      this.vars = (OptVariableTable)optFunctionNode.getVariableTable();
      this.name = optFunctionNode.getClassName();
      this.classFile = new ClassFileWriter(this.name, this.superClassName, this.itsSourceFile);
      Node node1 = paramNode.getFirstChild();
      String str = optFunctionNode.getFunctionName();
      generateInit(context, "<init>", paramNode, str, node1);
      if (optFunctionNode.isTargetOfDirectCall()) {
        this.classFile.startMethod("call", 
            
            "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;", (short)
            
            17);
        addByteCode((byte)42);
        addByteCode((byte)43);
        addByteCode((byte)44);
        addByteCode((byte)45);
        for (byte b = 0; b < this.vars.getParameterCount(); b++) {
          push(b);
          addByteCode((byte)25, 4);
          addByteCode((byte)-66);
          int i = acquireLabel();
          int j = acquireLabel();
          addByteCode((byte)-94, i);
          addByteCode((byte)25, 4);
          push(b);
          addByteCode((byte)50);
          push(0.0D);
          addByteCode((byte)-89, j);
          markLabel(i);
          pushUndefined();
          push(0.0D);
          markLabel(j);
        } 
        addByteCode((byte)25, 4);
        addVirtualInvoke(this.name, 
            "callDirect", 
            optFunctionNode.getDirectCallParameterSignature(), 
            "Ljava/lang/Object;");
        addByteCode((byte)-80);
        this.classFile.stopMethod((short)5, null);
        emitDirectConstructor(optFunctionNode);
        startNewMethod("callDirect", 
            String.valueOf(optFunctionNode.getDirectCallParameterSignature()) + 
            "Ljava/lang/Object;", 
            1, false, true);
        this.vars.assignParameterJRegs();
        if (!optFunctionNode.getParameterNumberContext()) {
          this.itsForcedObjectParameters = true;
          for (byte b1 = 0; b1 < this.vars.getParameterCount(); b1++) {
            OptLocalVariable optLocalVariable = (OptLocalVariable)this.vars.get(b1);
            aload(optLocalVariable.getJRegister());
            this.classFile.add((byte)-78, 
                "java/lang/Void", 
                "TYPE", 
                "Ljava/lang/Class;");
            int i = acquireLabel();
            addByteCode((byte)-90, i);
            addByteCode((byte)-69, "java/lang/Double");
            addByteCode((byte)89);
            dload((short)(optLocalVariable.getJRegister() + 1));
            addDoubleConstructor();
            astore(optLocalVariable.getJRegister());
            markLabel(i);
          } 
        } 
        generatePrologue(context, paramNode, true, this.vars.getParameterCount());
      } else {
        startNewMethod("call", 
            
            "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;", 
            
            1, false, true);
        generatePrologue(context, paramNode, true, -1);
      } 
      node = paramNode.getLastChild();
    } else {
      if (paramNode.getType() != 145)
        badTree(); 
      this.vars = (OptVariableTable)paramNode.getProp(10);
      boolean bool = !(this.itsNameHelper.getTargetExtends() != null || 
        this.itsNameHelper.getTargetImplements() != null);
      this.name = this.itsNameHelper.getJavaScriptClassName(null, bool);
      this.classFile = new ClassFileWriter(this.name, this.superClassName, this.itsSourceFile);
      this.classFile.addInterface("org/mozilla/javascript/Script");
      generateScriptCtor(context, paramNode);
      generateMain(context);
      generateInit(context, "initScript", paramNode, "", null);
      generateExecute(context);
      startNewMethod("call", 
          
          "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;", 
          
          1, false, true);
      generatePrologue(context, paramNode, false, -1);
      paramNode.addChildToBack(new Node(5));
      node = paramNode;
    } 
    generateCodeFromNode(node, null, -1, -1);
    generateEpilogue();
    finishMethod(context, this.debugVars);
    emitConstantDudeInitializers();
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(512);
    try {
      this.classFile.write(byteArrayOutputStream);
    } catch (IOException iOException) {
      throw new RuntimeException("unexpected IOException");
    } 
    byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
    this.namesVector.addElement(this.name);
    this.classFilesVector.addElement(arrayOfByte);
    this.classFile = null;
    return this.name;
  }
  
  private void generateCodeFromNode(Node paramNode1, Node paramNode2, int paramInt1, int paramInt2) {
    Object object;
    Integer integer;
    int i = paramNode1.getType();
    Node node = paramNode1.getFirstChild();
    switch (i) {
      case 123:
      case 135:
      case 137:
        visitStatement(paramNode1);
        while (node != null) {
          generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
          node = node.getNextSibling();
        } 
        return;
      case 115:
      case 116:
      case 127:
      case 131:
      case 132:
      case 145:
        visitStatement(paramNode1);
        while (node != null) {
          generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
          node = node.getNextSibling();
        } 
        return;
      case 109:
        if (this.inFunction || paramNode2.getType() != 145) {
          FunctionNode functionNode = (FunctionNode)paramNode1.getProp(5);
          byte b = functionNode.getFunctionType();
          if (b != 1)
            visitFunction(functionNode, !(b != 3)); 
        } 
        return;
      case 44:
        visitName(paramNode1);
        return;
      case 30:
      case 43:
        visitCall(paramNode1, i, node);
        return;
      case 45:
      case 46:
        visitLiteral(paramNode1);
        return;
      case 108:
        visitPrimary(paramNode1);
        return;
      case 56:
        visitObject(paramNode1);
        return;
      case 75:
        visitTryCatchFinally(paramNode1, node);
        return;
      case 62:
        visitThrow(paramNode1, node);
        return;
      case 5:
        visitReturn(paramNode1, node);
        return;
      case 114:
        visitSwitch(paramNode1, node);
        return;
      case 95:
        generateCodeFromNode(node, paramNode1, -1, -1);
        addByteCode((byte)87);
        generateCodeFromNode(node.getNextSibling(), 
            paramNode1, paramInt1, paramInt2);
        return;
      case 77:
        addScriptRuntimeInvoke("newScope", "()", 
            "Lorg/mozilla/javascript/Scriptable;");
        return;
      case 3:
        visitEnterWith(paramNode1, node);
        return;
      case 4:
        visitLeaveWith(paramNode1, node);
        return;
      case 79:
        visitEnumInit(paramNode1, node);
        return;
      case 80:
        visitEnumNext(paramNode1, node);
        return;
      case 138:
        visitEnumDone(paramNode1, node);
        return;
      case 57:
        visitStatement(paramNode1);
        if (node.getType() == 73) {
          visitSetVar(node, node.getFirstChild(), false);
        } else {
          while (node != null) {
            generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
            node = node.getNextSibling();
          } 
          if (paramNode1.getProp(26) != null) {
            addByteCode((byte)88);
          } else {
            addByteCode((byte)87);
          } 
        } 
        return;
      case 2:
        visitStatement(paramNode1);
        while (node != null) {
          generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
          node = node.getNextSibling();
        } 
        astore(this.scriptResultLocal);
        return;
      case 136:
        visitTarget(paramNode1);
        return;
      case 6:
      case 7:
      case 8:
      case 142:
        visitGOTO(paramNode1, i, node);
        return;
      case 104:
        visitUnary(paramNode1, node, paramInt1, paramInt2);
        return;
      case 32:
        visitTypeof(paramNode1, node);
        return;
      case 105:
        visitIncDec(paramNode1, true);
        return;
      case 106:
        visitIncDec(paramNode1, false);
        return;
      case 99:
      case 100:
        if (paramInt1 == -1) {
          generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
          addByteCode((byte)89);
          addScriptRuntimeInvoke("toBoolean", "(Ljava/lang/Object;)", "Z");
          int j = acquireLabel();
          if (i == 100) {
            addByteCode((byte)-103, j);
          } else {
            addByteCode((byte)-102, j);
          } 
          addByteCode((byte)87);
          generateCodeFromNode(node.getNextSibling(), paramNode1, paramInt1, paramInt2);
          markLabel(j);
        } else {
          int j = acquireLabel();
          if (i == 100) {
            generateCodeFromNode(node, paramNode1, j, paramInt2);
            if ((node.getType() != 104 || node.getInt() != 128) && 
              node.getType() != 100 && 
              node.getType() != 99 && 
              node.getType() != 102 && 
              node.getType() != 101) {
              addScriptRuntimeInvoke("toBoolean", 
                  "(Ljava/lang/Object;)", "Z");
              addByteCode((byte)-102, j);
              addByteCode((byte)-89, paramInt2);
            } 
          } else {
            generateCodeFromNode(node, paramNode1, paramInt1, j);
            if ((node.getType() != 104 || node.getInt() != 128) && 
              node.getType() != 100 && 
              node.getType() != 99 && 
              node.getType() != 102 && 
              node.getType() != 101) {
              addScriptRuntimeInvoke("toBoolean", 
                  "(Ljava/lang/Object;)", "Z");
              addByteCode((byte)-102, paramInt1);
              addByteCode((byte)-89, j);
            } 
          } 
          markLabel(j);
          node = node.getNextSibling();
          generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
          if ((node.getType() != 104 || node.getInt() != 128) && 
            node.getType() != 100 && 
            node.getType() != 99 && 
            node.getType() != 102 && 
            node.getType() != 101) {
            addScriptRuntimeInvoke("toBoolean", 
                "(Ljava/lang/Object;)", "Z");
            addByteCode((byte)-102, paramInt1);
            addByteCode((byte)-89, paramInt2);
          } 
        } 
        return;
      case 23:
        generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
        generateCodeFromNode(node.getNextSibling(), 
            paramNode1, paramInt1, paramInt2);
        integer = 
          (Integer)paramNode1.getProp(26);
        if (integer != null) {
          if (integer.intValue() == 0) {
            addByteCode((byte)99);
          } else if (integer.intValue() == 1) {
            addOptRuntimeInvoke("add", 
                "(DLjava/lang/Object;)", 
                "Ljava/lang/Object;");
          } else {
            addOptRuntimeInvoke("add", 
                "(Ljava/lang/Object;D)", 
                "Ljava/lang/Object;");
          } 
        } else {
          addScriptRuntimeInvoke("add", 
              "(Ljava/lang/Object;Ljava/lang/Object;)", 
              "Ljava/lang/Object;");
        } 
        return;
      case 25:
        visitArithmetic(paramNode1, (byte)107, node, paramNode2);
        return;
      case 24:
        visitArithmetic(paramNode1, (byte)103, node, paramNode2);
        return;
      case 26:
      case 27:
        visitArithmetic(paramNode1, (i == 26) ? 
            111 : 
            115, node, paramNode2);
        return;
      case 11:
      case 12:
      case 13:
      case 20:
      case 21:
      case 22:
        visitBitOp(paramNode1, i, node);
        return;
      case 141:
        object = paramNode1.getProp(18);
        if (object == ScriptRuntime.NumberClass) {
          addByteCode((byte)-69, "java/lang/Double");
          addByteCode((byte)89);
          generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
          addScriptRuntimeInvoke("toNumber", 
              "(Ljava/lang/Object;)", "D");
          addDoubleConstructor();
        } else if (object == ScriptRuntime.DoubleClass) {
          generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
          addScriptRuntimeInvoke("toNumber", 
              "(Ljava/lang/Object;)", "D");
        } else if (object == ScriptRuntime.ObjectClass) {
          if (node.getType() == 45 && 
            node.getProp(26) != null) {
            Object object1 = 
              node.getProp(26);
            node.putProp(26, null);
            generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
            node.putProp(26, object1);
          } else {
            addByteCode((byte)-69, "java/lang/Double");
            addByteCode((byte)89);
            generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
            addDoubleConstructor();
          } 
        } else {
          badTree();
        } 
        return;
      case 102:
        if (paramInt1 == -1) {
          visitRelOp(paramNode1, node, paramNode2);
        } else {
          visitGOTOingRelOp(paramNode1, node, paramNode2, paramInt1, paramInt2);
        } 
        return;
      case 101:
        visitEqOp(paramNode1, node, paramNode2, paramInt1, paramInt2);
        return;
      case 39:
        visitGetProp(paramNode1, node);
        return;
      case 41:
        while (node != null) {
          generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
          node = node.getNextSibling();
        } 
        aload(this.variableObjectLocal);
        if (paramNode1.getProp(26) != null) {
          addOptRuntimeInvoke("getElem", 
              "(Ljava/lang/Object;DLorg/mozilla/javascript/Scriptable;)", 
              
              "Ljava/lang/Object;");
        } else {
          addScriptRuntimeInvoke("getElem", 
              "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
              
              "Ljava/lang/Object;");
        } 
        return;
      case 72:
        object = 
          (OptLocalVariable)paramNode1.getProp(24);
        visitGetVar(object, 
            !(paramNode1.getProp(26) == null), 
            paramNode1.getString());
        return;
      case 73:
        visitSetVar(paramNode1, node, true);
        return;
      case 10:
        visitSetName(paramNode1, node);
        return;
      case 40:
        visitSetProp(paramNode1, node);
        return;
      case 42:
        while (node != null) {
          generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
          node = node.getNextSibling();
        } 
        aload(this.variableObjectLocal);
        if (paramNode1.getProp(26) != null) {
          addOptRuntimeInvoke("setElem", 
              "(Ljava/lang/Object;DLjava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
              
              "Ljava/lang/Object;");
        } else {
          addScriptRuntimeInvoke("setElem", 
              "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
              
              "Ljava/lang/Object;");
        } 
        return;
      case 31:
        while (node != null) {
          generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
          node = node.getNextSibling();
        } 
        addScriptRuntimeInvoke("delete", 
            "(Ljava/lang/Object;Ljava/lang/Object;)", 
            "Ljava/lang/Object;");
        return;
      case 61:
      case 71:
        visitBind(paramNode1, i, node);
        return;
      case 68:
        generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
        addScriptRuntimeInvoke("getThis", 
            "(Lorg/mozilla/javascript/Scriptable;)", 
            "Lorg/mozilla/javascript/Scriptable;");
        return;
      case 140:
        generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
        addScriptRuntimeInvoke("getParent", 
            "(Ljava/lang/Object;)", 
            "Lorg/mozilla/javascript/Scriptable;");
        return;
      case 69:
        visitNewTemp(paramNode1, node);
        return;
      case 70:
        visitUseTemp(paramNode1, node);
        return;
      case 143:
        visitNewLocal(paramNode1, node);
        return;
      case 144:
        visitUseLocal(paramNode1, node);
        return;
    } 
    throw new RuntimeException("Unexpected node type " + 
        TokenStream.tokenToName(i));
  }
  
  private void startNewMethod(String paramString1, String paramString2, int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    this.locals = new boolean[256];
    this.localsMax = (short)(paramInt + 1);
    this.firstFreeLocal = 0;
    this.contextLocal = -1;
    this.variableObjectLocal = -1;
    this.scriptResultLocal = -1;
    this.argsLocal = -1;
    this.thisObjLocal = -1;
    this.funObjLocal = -1;
    this.debug_pcLocal = -1;
    this.debugStopSubRetLocal = -1;
    this.itsZeroArgArray = -1;
    this.itsOneArgArray = -1;
    short s = 1;
    if (paramBoolean1)
      s = (short)(s | 0x8); 
    if (paramBoolean2)
      s = (short)(s | 0x10); 
    this.epilogueLabel = -1;
    this.classFile.startMethod(paramString1, paramString2, s);
  }
  
  private void finishMethod(Context paramContext, VariableTable paramVariableTable) {
    this.classFile.stopMethod((short)(this.localsMax + 1), paramVariableTable);
    this.contextLocal = -1;
  }
  
  private void generateMain(Context paramContext) {
    startNewMethod("main", "([Ljava/lang/String;)V", 1, true, true);
    push(this.name);
    addByteCode((byte)42);
    addScriptRuntimeInvoke("main", 
        "(Ljava/lang/String;[Ljava/lang/String;)", 
        "V");
    addByteCode((byte)-79);
    finishMethod(paramContext, null);
  }
  
  private void generateExecute(Context paramContext) {
    String str1 = 
      "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
    startNewMethod("exec", str1, 2, false, true);
    String str2 = this.name.replace('.', '/');
    if (!this.trivialInit) {
      addByteCode((byte)42);
      addByteCode((byte)44);
      addByteCode((byte)43);
      addVirtualInvoke(str2, 
          "initScript", 
          "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;)", 
          
          "V");
    } 
    addByteCode((byte)42);
    addByteCode((byte)43);
    addByteCode((byte)44);
    addByteCode((byte)89);
    addByteCode((byte)1);
    addVirtualInvoke(str2, 
        "call", 
        
        "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)", 
        
        "Ljava/lang/Object;");
    addByteCode((byte)-80);
    finishMethod(paramContext, null);
  }
  
  private void generateScriptCtor(Context paramContext, Node paramNode) {
    startNewMethod("<init>", "()V", 1, false, false);
    addByteCode((byte)42);
    addSpecialInvoke(this.superClassSlashName, 
        "<init>", "()", "V");
    addByteCode((byte)-79);
    finishMethod(paramContext, null);
  }
  
  private void setNonTrivialInit(String paramString) {
    if (!this.trivialInit)
      return; 
    this.trivialInit = false;
    startNewMethod(paramString, 
        "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;)V", 
        1, false, false);
    reserveWordLocal(0);
    this.variableObjectLocal = reserveWordLocal(1);
    this.contextLocal = reserveWordLocal(2);
  }
  
  private void generateInit(Context paramContext, String paramString1, Node paramNode1, String paramString2, Node paramNode2) {
    VariableTable variableTable;
    this.trivialInit = true;
    boolean bool = false;
    if (paramNode1 instanceof OptFunctionNode) {
      variableTable = ((OptFunctionNode)paramNode1).getVariableTable();
    } else {
      variableTable = (VariableTable)paramNode1.getProp(10);
    } 
    if (paramString1.equals("<init>")) {
      bool = true;
      setNonTrivialInit(paramString1);
      addByteCode((byte)42);
      addSpecialInvoke(this.superClassSlashName, "<init>", "()", "V");
      addByteCode((byte)42);
      addByteCode((byte)43);
      this.classFile.add((byte)-75, 
          "org/mozilla/javascript/ScriptableObject", 
          "parent", "Lorg/mozilla/javascript/Scriptable;");
    } 
    if (paramString2.length() != 0 || (variableTable != null && variableTable.size() > 0)) {
      setNonTrivialInit(paramString1);
      if (variableTable == null)
        variableTable = new OptVariableTable(); 
      push((variableTable.size() + 1));
      addByteCode((byte)-67, "java/lang/String");
      addByteCode((byte)89);
      short s = getNewWordLocal();
      astore(s);
      addByteCode((byte)89);
      push(0L);
      this.classFile.addLoadConstant(paramString2);
      addByteCode((byte)83);
      if (variableTable != null)
        for (byte b = 0; b < variableTable.size(); b++) {
          aload(s);
          push((b + true));
          push(variableTable.getName(b));
          addByteCode((byte)83);
        }  
      releaseWordLocal(s);
      addByteCode((byte)42);
      addByteCode((byte)95);
      this.classFile.add((byte)-75, 
          "org/mozilla/javascript/NativeFunction", 
          "names", "[Ljava/lang/String;");
    } 
    boolean bool1 = (variableTable == null) ? 0 : variableTable.getParameterCount();
    if (bool1) {
      setNonTrivialInit(paramString1);
      addByteCode((byte)42);
      push(bool1);
      this.classFile.add((byte)-75, 
          "org/mozilla/javascript/NativeFunction", 
          "argCount", "S");
    } 
    if (paramContext.getLanguageVersion() != 0) {
      setNonTrivialInit(paramString1);
      addByteCode((byte)42);
      push(paramContext.getLanguageVersion());
      this.classFile.add((byte)-75, 
          "org/mozilla/javascript/NativeFunction", 
          "version", "S");
    } 
    String str = (String)paramNode1.getProp(17);
    if (str != null && 
      paramContext.isGeneratingSource() && 
      str.length() < 65536) {
      setNonTrivialInit(paramString1);
      addByteCode((byte)42);
      push(str);
      this.classFile.add((byte)-75, 
          "org/mozilla/javascript/NativeFunction", 
          "source", "Ljava/lang/String;");
    } 
    Vector vector1 = (Vector)paramNode1.getProp(12);
    if (vector1 != null) {
      setNonTrivialInit(paramString1);
      generateRegExpLiterals(vector1, bool);
    } 
    Vector vector2 = (Vector)paramNode1.getProp(5);
    if (vector2 != null) {
      setNonTrivialInit(paramString1);
      generateFunctionInits(vector2);
    } 
    if (paramNode1 instanceof OptFunctionNode) {
      OptFunctionNode optFunctionNode = (OptFunctionNode)paramNode1;
      Vector vector = (
        (OptFunctionNode)paramNode1).getDirectCallTargets();
      if (vector != null) {
        setNonTrivialInit(paramString1);
        this.classFile.addField("EmptyArray", 
            "[Ljava/lang/Object;", (short)
            2);
        addByteCode((byte)42);
        push(0L);
        addByteCode((byte)-67, "java/lang/Object");
        this.classFile.add((byte)-75, 
            ClassFileWriter.fullyQualifiedForm(this.name), 
            "EmptyArray", 
            "[Ljava/lang/Object;");
      } 
      if (optFunctionNode.isTargetOfDirectCall()) {
        setNonTrivialInit(paramString1);
        String str1 = 
          ClassFileWriter.fullyQualifiedForm(optFunctionNode.getClassName());
        String str2 = str1.replace('/', '_');
        this.classFile.addField(str2, 
            "L" + str1 + ";", (short)
            
            9);
        addByteCode((byte)42);
        this.classFile.add((byte)-77, 
            str1, 
            str2, 
            "L" + str1 + ";");
      } 
    } 
    if (!this.trivialInit) {
      addByteCode((byte)-79);
      finishMethod(paramContext, null);
    } 
  }
  
  private void generateDebugInit(Context paramContext, Node paramNode) {}
  
  private void generateRegExpLiterals(Vector paramVector, boolean paramBoolean) {
    for (byte b = 0; b < paramVector.size(); b++) {
      Node node1 = (Node)paramVector.elementAt(b);
      StringBuffer stringBuffer = new StringBuffer("_re");
      stringBuffer.append(b);
      String str = stringBuffer.toString();
      short s = 2;
      if (paramBoolean)
        s = (short)(s | 0x10); 
      this.classFile.addField(str, 
          "Lorg/mozilla/javascript/regexp/NativeRegExp;", 
          s);
      addByteCode((byte)42);
      addByteCode((byte)-69, "org/mozilla/javascript/regexp/NativeRegExp");
      addByteCode((byte)89);
      aload(this.contextLocal);
      aload(this.variableObjectLocal);
      Node node2 = node1.getFirstChild();
      push(node2.getString());
      Node node3 = node1.getLastChild();
      if (node2 == node3) {
        addByteCode((byte)1);
      } else {
        push(node3.getString());
      } 
      push(0L);
      addSpecialInvoke("org/mozilla/javascript/regexp/NativeRegExp", 
          "<init>", 
          
          "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Ljava/lang/String;Z)", 
          
          "V");
      node1.putProp(12, str);
      this.classFile.add((byte)-75, 
          ClassFileWriter.fullyQualifiedForm(this.name), 
          str, "Lorg/mozilla/javascript/regexp/NativeRegExp;");
    } 
  }
  
  private void generateFunctionInits(Vector paramVector) {
    push(paramVector.size());
    addByteCode((byte)-67, "org/mozilla/javascript/NativeFunction");
    for (short s = 0; s < paramVector.size(); s = (short)(s + 1)) {
      addByteCode((byte)89);
      push(s);
      Node node = (Node)paramVector.elementAt(s);
      Codegen codegen = new Codegen();
      String str1 = codegen.generateCode(node, this.namesVector, 
          this.classFilesVector, 
          this.itsNameHelper);
      addByteCode((byte)-69, str1);
      addByteCode((byte)89);
      if (this.inFunction) {
        addByteCode((byte)42);
      } else {
        aload(this.variableObjectLocal);
      } 
      aload(this.contextLocal);
      addSpecialInvoke(str1, "<init>", 
          "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;)", 
          
          "V");
      if (this.inFunction) {
        addByteCode((byte)42);
      } else {
        aload(this.variableObjectLocal);
      } 
      String str2 = node.getString();
      if (str2 != null) {
        push(str2);
      } else {
        addByteCode((byte)1);
      } 
      aload(this.contextLocal);
      addScriptRuntimeInvoke("initFunction", 
          
          "(Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Lorg/mozilla/javascript/Context;)", 
          
          "Lorg/mozilla/javascript/NativeFunction;");
      node.putProp(5, new Short(s));
      addByteCode((byte)83);
    } 
    addByteCode((byte)42);
    addByteCode((byte)95);
    this.classFile.add((byte)-75, "org/mozilla/javascript/NativeFunction", 
        "nestedFunctions", "[Lorg/mozilla/javascript/NativeFunction;");
  }
  
  private void generatePrologue(Context paramContext, Node paramNode, boolean paramBoolean, int paramInt) {
    String str;
    this.funObjLocal = reserveWordLocal(0);
    this.contextLocal = reserveWordLocal(1);
    this.variableObjectLocal = reserveWordLocal(2);
    this.thisObjLocal = reserveWordLocal(3);
    if (paramBoolean && !paramContext.hasCompileFunctionsWithDynamicScope() && 
      paramInt == -1) {
      aload(this.funObjLocal);
      this.classFile.add((byte)-71, 
          "org/mozilla/javascript/Scriptable", 
          "getParentScope", 
          "()", 
          "Lorg/mozilla/javascript/Scriptable;");
      astore(this.variableObjectLocal);
    } 
    if (paramInt > 0)
      for (byte b = 0; b < 3 * paramInt; b++)
        reserveWordLocal(b + 4);  
    this.argsLocal = reserveWordLocal((paramInt <= 0) ? 
        4 : (3 * paramInt + 4));
    Integer integer = (Integer)paramNode.getProp(22);
    if (integer != null) {
      this.itsLocalAllocationBase = (short)(this.argsLocal + 1);
      for (short s = 0; s < integer.intValue(); s++)
        reserveWordLocal(this.itsLocalAllocationBase + s); 
    } 
    this.hasVarsInRegs = !(!paramBoolean || (
      (OptFunctionNode)paramNode).requiresActivation());
    if (this.hasVarsInRegs) {
      int i = this.vars.getParameterCount();
      if (paramBoolean && i > 0 && paramInt < 0) {
        aload(this.argsLocal);
        addByteCode((byte)-66);
        push(i);
        int j = acquireLabel();
        addByteCode((byte)-94, j);
        aload(this.argsLocal);
        push(i);
        addScriptRuntimeInvoke("padArguments", 
            "([Ljava/lang/Object;I)", 
            "[Ljava/lang/Object;");
        astore(this.argsLocal);
        markLabel(j);
      } 
      short s = -1;
      for (byte b = 0; b < this.vars.size(); b++) {
        OptLocalVariable optLocalVariable = (OptLocalVariable)this.vars.get(b);
        if (optLocalVariable.isNumber()) {
          optLocalVariable.assignJRegister(getNewWordPairLocal());
          push(0.0D);
          dstore(optLocalVariable.getJRegister());
        } else if (optLocalVariable.isParameter()) {
          if (paramInt < 0) {
            optLocalVariable.assignJRegister(getNewWordLocal());
            aload(this.argsLocal);
            push(b);
            addByteCode((byte)50);
            astore(optLocalVariable.getJRegister());
          } 
        } else {
          optLocalVariable.assignJRegister(getNewWordLocal());
          if (s == -1) {
            pushUndefined();
            s = optLocalVariable.getJRegister();
          } else {
            aload(s);
          } 
          astore(optLocalVariable.getJRegister());
        } 
        optLocalVariable.setStartPC(this.classFile.getCurrentCodeOffset());
      } 
      this.debugVars = this.vars;
      return;
    } 
    if (paramInt > 0) {
      aload(this.argsLocal);
      push(paramInt);
      addOptRuntimeInvoke("padStart", 
          "([Ljava/lang/Object;I)", 
          "[Ljava/lang/Object;");
      astore(this.argsLocal);
      for (byte b = 0; b < paramInt; b++) {
        aload(this.argsLocal);
        push(b);
        aload((short)(3 * b + 4));
        addByteCode((byte)83);
      } 
    } 
    if (paramBoolean) {
      aload(this.contextLocal);
      aload(this.variableObjectLocal);
      aload(this.funObjLocal);
      aload(this.thisObjLocal);
      aload(this.argsLocal);
      addScriptRuntimeInvoke("initVarObj", 
          
          "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)", 
          
          "Lorg/mozilla/javascript/Scriptable;");
      str = "activation";
    } else {
      aload(this.contextLocal);
      aload(this.variableObjectLocal);
      aload(this.funObjLocal);
      aload(this.thisObjLocal);
      push(0L);
      addScriptRuntimeInvoke("initScript", 
          
          "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;Z)", 
          
          "Lorg/mozilla/javascript/Scriptable;");
      str = "global";
    } 
    astore(this.variableObjectLocal);
    Vector vector = (Vector)paramNode.getProp(5);
    if (paramBoolean && vector != null)
      for (byte b = 0; b < vector.size(); b++) {
        FunctionNode functionNode = (FunctionNode)vector.elementAt(b);
        if (functionNode.getFunctionType() == 1)
          visitFunction(functionNode, true); 
      }  
    if (paramContext.isGeneratingDebug()) {
      this.debugVars = new OptVariableTable();
      this.debugVars.addLocal(str);
      OptLocalVariable optLocalVariable = (OptLocalVariable)this.debugVars.get(str);
      optLocalVariable.assignJRegister(this.variableObjectLocal);
      optLocalVariable.setStartPC(this.classFile.getCurrentCodeOffset());
    } 
    if (!paramBoolean) {
      this.scriptResultLocal = getNewWordLocal();
      pushUndefined();
      astore(this.scriptResultLocal);
    } 
    if (paramBoolean && ((OptFunctionNode)paramNode).containsCalls(-1)) {
      if (((OptFunctionNode)paramNode).containsCalls(0)) {
        this.itsZeroArgArray = getNewWordLocal();
        this.classFile.add((byte)-78, 
            "org/mozilla/javascript/ScriptRuntime", 
            "emptyArgs", "[Ljava/lang/Object;");
        astore(this.itsZeroArgArray);
      } 
      if (((OptFunctionNode)paramNode).containsCalls(1)) {
        this.itsOneArgArray = getNewWordLocal();
        push(1L);
        addByteCode((byte)-67, "java/lang/Object");
        astore(this.itsOneArgArray);
      } 
    } 
  }
  
  private void generateEpilogue() {
    if (this.epilogueLabel != -1)
      this.classFile.markLabel(this.epilogueLabel); 
    if (!this.hasVarsInRegs || !this.inFunction) {
      aload(this.contextLocal);
      addScriptRuntimeInvoke("popActivation", 
          "(Lorg/mozilla/javascript/Context;)", 
          "V");
    } 
    addByteCode((byte)-80);
  }
  
  private void generateDebugStopSubroutine() {}
  
  private short addDebugPCEntry(short paramShort) { return -1; }
  
  private void writeDebugPCEntries() {}
  
  private void buildDebugTrapMap() {}
  
  private void visitFunction(Node paramNode, boolean paramBoolean) {
    aload(this.variableObjectLocal);
    Short short = (Short)paramNode.getProp(5);
    aload(this.funObjLocal);
    this.classFile.add((byte)-76, "org/mozilla/javascript/NativeFunction", 
        "nestedFunctions", "[Lorg/mozilla/javascript/NativeFunction;");
    push(short.shortValue());
    addByteCode((byte)50);
    addVirtualInvoke("java/lang/Object", "getClass", "()", "Ljava/lang/Class;");
    aload(this.contextLocal);
    addByteCode((byte)16, paramBoolean ? 1 : 0);
    addScriptRuntimeInvoke("createFunctionObject", 
        
        "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Class;Lorg/mozilla/javascript/Context;Z)", 
        
        "Lorg/mozilla/javascript/NativeFunction;");
  }
  
  private void visitTarget(Node paramNode) {
    Object object = paramNode.getProp(20);
    if (object == null) {
      int i = markLabel(acquireLabel());
      paramNode.putProp(20, new Integer(i));
    } else {
      int i = ((Integer)object).intValue();
      markLabel(i);
    } 
  }
  
  private void visitGOTO(Node paramNode1, int paramInt, Node paramNode2) {
    int i;
    Node node = (Node)paramNode1.getProp(1);
    Object object = node.getProp(20);
    if (object == null) {
      i = acquireLabel();
      node.putProp(20, new Integer(i));
    } else {
      i = ((Integer)object).intValue();
    } 
    int j = acquireLabel();
    if (paramInt == 7 || paramInt == 8) {
      if (paramNode2 == null) {
        addScriptRuntimeInvoke("toBoolean", "(Ljava/lang/Object;)", "Z");
        if (paramInt == 7) {
          addByteCode((byte)-102, i);
        } else {
          addByteCode((byte)-103, i);
        } 
      } else {
        if (paramInt == 7) {
          generateCodeFromNode(paramNode2, paramNode1, i, j);
        } else {
          generateCodeFromNode(paramNode2, paramNode1, j, i);
        } 
        if ((paramNode2.getType() != 104 || paramNode2.getInt() != 128) && 
          paramNode2.getType() != 100 && 
          paramNode2.getType() != 99 && 
          paramNode2.getType() != 102 && 
          paramNode2.getType() != 101) {
          addScriptRuntimeInvoke("toBoolean", 
              "(Ljava/lang/Object;)", "Z");
          if (paramInt == 7) {
            addByteCode((byte)-102, i);
          } else {
            addByteCode((byte)-103, i);
          } 
        } 
      } 
    } else {
      while (paramNode2 != null) {
        generateCodeFromNode(paramNode2, paramNode1, -1, -1);
        paramNode2 = paramNode2.getNextSibling();
      } 
      if (paramInt == 142) {
        addByteCode((byte)-88, i);
      } else {
        addByteCode((byte)-89, i);
      } 
    } 
    markLabel(j);
  }
  
  private void visitEnumInit(Node paramNode1, Node paramNode2) {
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    aload(this.variableObjectLocal);
    addScriptRuntimeInvoke("initEnum", 
        "(Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
        "Ljava/util/Enumeration;");
    short s = getNewWordLocal();
    astore(s);
    paramNode1.putProp(7, new Integer(s));
  }
  
  private void visitEnumNext(Node paramNode1, Node paramNode2) {
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    Node node = (Node)paramNode1.getProp(4);
    Integer integer = (Integer)node.getProp(7);
    aload(integer.shortValue());
    addScriptRuntimeInvoke("nextEnum", "(Ljava/util/Enumeration;)", "Ljava/lang/Object;");
  }
  
  private void visitEnumDone(Node paramNode1, Node paramNode2) {
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    Node node = (Node)paramNode1.getProp(4);
    Integer integer = (Integer)node.getProp(7);
    releaseWordLocal(integer.shortValue());
  }
  
  private void visitEnterWith(Node paramNode1, Node paramNode2) {
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    aload(this.variableObjectLocal);
    addScriptRuntimeInvoke("enterWith", 
        "(Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
        
        "Lorg/mozilla/javascript/Scriptable;");
    astore(this.variableObjectLocal);
  }
  
  private void visitLeaveWith(Node paramNode1, Node paramNode2) {
    aload(this.variableObjectLocal);
    addScriptRuntimeInvoke("leaveWith", 
        "(Lorg/mozilla/javascript/Scriptable;)", 
        "Lorg/mozilla/javascript/Scriptable;");
    astore(this.variableObjectLocal);
  }
  
  private void resetTargets(Node paramNode) {
    if (paramNode.getType() == 136)
      paramNode.putProp(20, null); 
    Node node = paramNode.getFirstChild();
    while (node != null) {
      resetTargets(node);
      node = node.getNextSibling();
    } 
  }
  
  private void visitCall(Node paramNode1, int paramInt, Node paramNode2) {
    Node node = paramNode2;
    OptFunctionNode optFunctionNode = (OptFunctionNode)paramNode1.getProp(27);
    if (optFunctionNode != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      int i = acquireLabel();
      String str1 = ClassFileWriter.fullyQualifiedForm(optFunctionNode.getClassName());
      String str2 = str1.replace('/', '_');
      this.classFile.add((byte)-78, 
          ClassFileWriter.fullyQualifiedForm(str1), 
          str2, 
          "L" + str1 + ";");
      short s = this.classFile.getStackTop();
      addByteCode((byte)92);
      addByteCode((byte)-90, i);
      addByteCode((byte)95);
      addByteCode((byte)87);
      addByteCode((byte)89);
      this.classFile.add((byte)-71, 
          "org/mozilla/javascript/Scriptable", 
          "getParentScope", 
          "()", "Lorg/mozilla/javascript/Scriptable;");
      aload(this.contextLocal);
      addByteCode((byte)95);
      if (paramInt == 30) {
        addByteCode((byte)1);
      } else {
        paramNode2 = paramNode2.getNextSibling();
        generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      } 
      paramNode2 = paramNode2.getNextSibling();
      while (paramNode2 != null) {
        boolean bool = false;
        if (paramNode2.getType() == 72 && 
          this.inDirectCallFunction) {
          OptLocalVariable optLocalVariable = 
            (OptLocalVariable)paramNode2.getProp(24);
          if (optLocalVariable.isParameter()) {
            bool = true;
            aload(optLocalVariable.getJRegister());
            dload((short)(optLocalVariable.getJRegister() + 1));
          } 
        } 
        if (!bool) {
          Integer integer = 
            (Integer)paramNode2.getProp(26);
          if (integer != null && 
            integer.intValue() == 0) {
            this.classFile.add((byte)-78, 
                "java/lang/Void", 
                "TYPE", 
                "Ljava/lang/Class;");
            generateCodeFromNode(paramNode2, paramNode1, -1, -1);
          } else {
            generateCodeFromNode(paramNode2, paramNode1, -1, -1);
            push(0.0D);
          } 
        } 
        resetTargets(paramNode2);
        paramNode2 = paramNode2.getNextSibling();
      } 
      addByteCode((byte)42);
      this.classFile.add((byte)-76, 
          ClassFileWriter.fullyQualifiedForm(this.name), 
          "EmptyArray", 
          "[Ljava/lang/Object;");
      if (paramInt == 30) {
        addVirtualInvoke(optFunctionNode.getClassName(), 
            "constructDirect", 
            optFunctionNode.getDirectCallParameterSignature(), 
            "Ljava/lang/Object;");
      } else {
        addVirtualInvoke(optFunctionNode.getClassName(), 
            "callDirect", 
            optFunctionNode.getDirectCallParameterSignature(), 
            "Ljava/lang/Object;");
      } 
      int j = acquireLabel();
      addByteCode((byte)-89, j);
      markLabel(i, s);
      addByteCode((byte)87);
      visitRegularCall(paramNode1, paramInt, node, true);
      markLabel(j);
    } else {
      visitRegularCall(paramNode1, paramInt, node, false);
    } 
  }
  
  private String getSimpleCallName(Node paramNode) {
    Node node = paramNode.getFirstChild();
    if (node.getType() == 39) {
      Node node1 = node.getFirstChild();
      if (node1.getType() == 69) {
        Node node2 = node1.getNextSibling();
        Node node3 = node1.getFirstChild();
        if (node3.getType() == 71) {
          String str = node3.getString();
          if (node2 != null && 
            node2.getType() == 46 && 
            str.equals(node2.getString())) {
            Node node4 = node.getNextSibling();
            if (node4.getType() == 68) {
              Node node5 = node4.getFirstChild();
              if (node5.getType() == 70) {
                Node node6 = (Node)node5.getProp(6);
                if (node6 == node1)
                  return str; 
              } 
            } 
          } 
        } 
      } 
    } 
    return null;
  }
  
  private void constructArgArray(int paramInt) {
    if (paramInt == 0) {
      if (this.itsZeroArgArray >= 0) {
        aload(this.itsZeroArgArray);
      } else {
        push(0L);
        addByteCode((byte)-67, "java/lang/Object");
      } 
    } else if (paramInt == 1) {
      if (this.itsOneArgArray >= 0) {
        aload(this.itsOneArgArray);
      } else {
        push(1L);
        addByteCode((byte)-67, "java/lang/Object");
      } 
    } else {
      push(paramInt);
      addByteCode((byte)-67, "java/lang/Object");
    } 
  }
  
  private void visitRegularCall(Node paramNode1, int paramInt, Node paramNode2, boolean paramBoolean) {
    String str5, str4, str3, str2;
    OptFunctionNode optFunctionNode = (OptFunctionNode)paramNode1.getProp(27);
    Node node = paramNode2;
    byte b1 = 0;
    byte b2 = (paramInt == 30) ? 1 : 2;
    while (paramNode2 != null) {
      b1++;
      paramNode2 = paramNode2.getNextSibling();
    } 
    paramNode2 = node;
    byte b3 = -b2;
    if (paramBoolean && paramNode2 != null) {
      paramNode2 = paramNode2.getNextSibling();
      b3++;
      aload(this.contextLocal);
      addByteCode((byte)95);
    } else {
      aload(this.contextLocal);
    } 
    if (paramBoolean && paramInt == 30)
      constructArgArray(b1 - b2); 
    boolean bool1 = (paramNode1.getProp(30) == null) ? 0 : 1;
    boolean bool2 = false;
    String str1 = null;
    if (paramInt != 30) {
      str1 = getSimpleCallName(paramNode1);
      if (str1 != null && !bool1) {
        bool2 = true;
        push(str1);
        aload(this.variableObjectLocal);
        paramNode2 = paramNode2.getNextSibling().getNextSibling();
        b3 = 0;
        push((b1 - b2));
        addByteCode((byte)-67, "java/lang/Object");
      } 
    } 
    while (paramNode2 != null) {
      if (b3 < 0) {
        generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      } else {
        addByteCode((byte)89);
        push(b3);
        if (optFunctionNode != null) {
          boolean bool = false;
          if (paramNode2.getType() == 72 && 
            this.inDirectCallFunction) {
            str3 = 
              (OptLocalVariable)paramNode2.getProp(24);
            if (str3.isParameter()) {
              paramNode2.putProp(26, null);
              generateCodeFromNode(paramNode2, paramNode1, -1, -1);
              bool = true;
            } 
          } 
          if (!bool) {
            str3 = 
              (Integer)paramNode2.getProp(26);
            if (str3 != null && 
              str3.intValue() == 0) {
              addByteCode((byte)-69, "java/lang/Double");
              addByteCode((byte)89);
              generateCodeFromNode(paramNode2, paramNode1, -1, -1);
              addDoubleConstructor();
            } else {
              generateCodeFromNode(paramNode2, paramNode1, -1, -1);
            } 
          } 
        } else {
          generateCodeFromNode(paramNode2, paramNode1, -1, -1);
        } 
        addByteCode((byte)83);
      } 
      b3++;
      if (b3 == 0)
        constructArgArray(b1 - b2); 
      paramNode2 = paramNode2.getNextSibling();
    } 
    if (bool1) {
      str2 = "org/mozilla/javascript/ScriptRuntime";
      str3 = "newObjectSpecial";
      str4 = "callSpecial";
      if (paramInt != 30) {
        str5 = 
          
          "(Lorg/mozilla/javascript/Context;Ljava/lang/Object;Ljava/lang/Object;[Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;I)";
        aload(this.thisObjLocal);
        aload(this.variableObjectLocal);
        push((this.itsSourceFile == null) ? "" : this.itsSourceFile);
        push(this.itsLineNumber);
      } else {
        str5 = 
          
          "(Lorg/mozilla/javascript/Context;Ljava/lang/Object;[Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)";
        aload(this.variableObjectLocal);
      } 
    } else {
      str3 = "newObject";
      if (bool2) {
        str5 = 
          
          "(Lorg/mozilla/javascript/Context;Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)";
        str4 = "callSimple";
        str2 = "org/mozilla/javascript/optimizer/OptRuntime";
      } else {
        aload(this.variableObjectLocal);
        if (paramInt == 30) {
          str5 = 
            
            "(Lorg/mozilla/javascript/Context;Ljava/lang/Object;[Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)";
        } else {
          str5 = 
            
            "(Lorg/mozilla/javascript/Context;Ljava/lang/Object;Ljava/lang/Object;[Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)";
        } 
        str4 = "call";
        str2 = "org/mozilla/javascript/ScriptRuntime";
      } 
    } 
    if (paramInt == 30) {
      addStaticInvoke(str2, 
          str3, 
          str5, 
          "Lorg/mozilla/javascript/Scriptable;");
    } else {
      addStaticInvoke(str2, 
          str4, 
          str5, 
          "Ljava/lang/Object;");
    } 
  }
  
  private void visitStatement(Node paramNode) {
    Object object = paramNode.getDatum();
    if (object == null || !(object instanceof Number))
      return; 
    this.itsLineNumber = ((Number)object).shortValue();
    if (this.itsLineNumber == -1)
      return; 
    this.classFile.addLineNumberEntry((short)this.itsLineNumber);
  }
  
  private void visitTryCatchFinally(Node paramNode1, Node paramNode2) {
    short s = getNewWordLocal();
    aload(this.variableObjectLocal);
    astore(s);
    int i = markLabel(acquireLabel(), (short)1);
    visitStatement(paramNode1);
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    Node node1 = (Node)paramNode1.getProp(1);
    Node node2 = (Node)paramNode1.getProp(21);
    int j = acquireLabel();
    addByteCode((byte)-89, j);
    if (node1 != null) {
      int k = this.classFile.markHandler(acquireLabel());
      short s1 = getNewWordLocal();
      astore(s1);
      aload(s);
      astore(this.variableObjectLocal);
      aload(s1);
      releaseWordLocal(s1);
      addScriptRuntimeInvoke("unwrapJavaScriptException", 
          "(Lorg/mozilla/javascript/JavaScriptException;)", 
          "Ljava/lang/Object;");
      int m = (
        (Integer)node1.getProp(20)).intValue();
      addByteCode((byte)-89, m);
      this.classFile
        .addExceptionHandler(i, m, k, 
          "org/mozilla/javascript/JavaScriptException");
      k = this.classFile.markHandler(acquireLabel());
      s1 = getNewWordLocal();
      astore(s1);
      aload(s);
      astore(this.variableObjectLocal);
      aload(s1);
      addVirtualInvoke("org/mozilla/javascript/EcmaError", 
          "getErrorObject", 
          "()", 
          "Lorg/mozilla/javascript/Scriptable;");
      releaseWordLocal(s1);
      addByteCode((byte)-89, m);
      this.classFile
        .addExceptionHandler(i, m, k, 
          "org/mozilla/javascript/EcmaError");
    } 
    if (node2 != null) {
      int k = this.classFile.markHandler(acquireLabel());
      aload(s);
      astore(this.variableObjectLocal);
      short s1 = this.itsLocalAllocationBase = (short)(this.itsLocalAllocationBase + 1);
      astore(s1);
      int m = (
        (Integer)node2.getProp(20)).intValue();
      addByteCode((byte)-88, m);
      aload(s1);
      addByteCode((byte)-65);
      this.classFile.addExceptionHandler(i, m, 
          k, null);
    } 
    releaseWordLocal(s);
    markLabel(j);
  }
  
  private void visitThrow(Node paramNode1, Node paramNode2) {
    visitStatement(paramNode1);
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    addByteCode((byte)-69, 
        "org/mozilla/javascript/JavaScriptException");
    addByteCode((byte)90);
    addByteCode((byte)95);
    addSpecialInvoke("org/mozilla/javascript/JavaScriptException", 
        "<init>", "(Ljava/lang/Object;)", "V");
    addByteCode((byte)-65);
  }
  
  private void visitReturn(Node paramNode1, Node paramNode2) {
    visitStatement(paramNode1);
    if (paramNode2 != null) {
      do {
        generateCodeFromNode(paramNode2, paramNode1, -1, -1);
        paramNode2 = paramNode2.getNextSibling();
      } while (paramNode2 != null);
    } else if (this.inFunction) {
      pushUndefined();
    } else {
      aload(this.scriptResultLocal);
    } 
    if (this.epilogueLabel == -1)
      this.epilogueLabel = this.classFile.acquireLabel(); 
    addByteCode((byte)-89, this.epilogueLabel);
  }
  
  private void visitSwitch(Node paramNode1, Node paramNode2) {
    visitStatement(paramNode1);
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    short s = getNewWordLocal();
    astore(s);
    Vector vector = (Vector)paramNode1.getProp(13);
    for (byte b = 0; b < vector.size(); b++) {
      Node node3 = (Node)vector.elementAt(b);
      Node node4 = node3.getFirstChild();
      generateCodeFromNode(node4, node3, -1, -1);
      aload(s);
      addScriptRuntimeInvoke("seqB", 
          "(Ljava/lang/Object;Ljava/lang/Object;)", 
          "Ljava/lang/Boolean;");
      Node node5 = new Node(136);
      node3.replaceChild(node4, node5);
      generateGOTO(7, node5);
    } 
    Node node1 = (Node)paramNode1.getProp(14);
    if (node1 != null) {
      Node node = new Node(136);
      node1.getFirstChild().addChildToFront(node);
      generateGOTO(6, node);
    } 
    Node node2 = (Node)paramNode1.getProp(2);
    generateGOTO(6, node2);
  }
  
  private void generateGOTO(int paramInt, Node paramNode) {
    Node node = new Node(paramInt);
    node.putProp(1, paramNode);
    visitGOTO(node, paramInt, null);
  }
  
  private void visitUnary(Node paramNode1, Node paramNode2, int paramInt1, int paramInt2) {
    int i = paramNode1.getInt();
    switch (i) {
      case 128:
        if (paramInt1 != -1) {
          generateCodeFromNode(paramNode2, paramNode1, paramInt2, paramInt1);
          if ((paramNode2.getType() != 104 || paramNode2.getInt() != 128) && 
            paramNode2.getType() != 100 && 
            paramNode2.getType() != 99 && 
            paramNode2.getType() != 102 && 
            paramNode2.getType() != 101) {
            addScriptRuntimeInvoke("toBoolean", 
                "(Ljava/lang/Object;)", "Z");
            addByteCode((byte)-102, paramInt2);
            addByteCode((byte)-89, paramInt1);
          } 
        } else {
          int j = acquireLabel();
          int k = acquireLabel();
          int m = acquireLabel();
          generateCodeFromNode(paramNode2, paramNode1, j, k);
          if ((paramNode2.getType() != 104 || paramNode2.getInt() != 128) && 
            paramNode2.getType() != 100 && 
            paramNode2.getType() != 99 && 
            paramNode2.getType() != 102 && 
            paramNode2.getType() != 101) {
            addScriptRuntimeInvoke("toBoolean", 
                "(Ljava/lang/Object;)", "Z");
            addByteCode((byte)-103, k);
            addByteCode((byte)-89, j);
          } 
          markLabel(j);
          this.classFile.add((byte)-78, "java/lang/Boolean", 
              "FALSE", "Ljava/lang/Boolean;");
          addByteCode((byte)-89, m);
          markLabel(k);
          this.classFile.add((byte)-78, "java/lang/Boolean", 
              "TRUE", "Ljava/lang/Boolean;");
          markLabel(m);
          this.classFile.adjustStackTop(-1);
        } 
        return;
      case 32:
        visitTypeof(paramNode1, paramNode2);
        return;
      case 131:
        generateCodeFromNode(paramNode2, paramNode1, -1, -1);
        addByteCode((byte)87);
        pushUndefined();
        return;
      case 28:
        addByteCode((byte)-69, "java/lang/Double");
        addByteCode((byte)89);
        generateCodeFromNode(paramNode2, paramNode1, -1, -1);
        addScriptRuntimeInvoke("toInt32", 
            "(Ljava/lang/Object;)", "I");
        push(-1L);
        addByteCode((byte)-126);
        addByteCode((byte)-121);
        addDoubleConstructor();
        return;
      case 23:
      case 24:
        addByteCode((byte)-69, "java/lang/Double");
        addByteCode((byte)89);
        generateCodeFromNode(paramNode2, paramNode1, -1, -1);
        addScriptRuntimeInvoke("toNumber", "(Ljava/lang/Object;)", "D");
        if (i == 24)
          addByteCode((byte)119); 
        addDoubleConstructor();
        return;
    } 
    badTree();
  }
  
  private void visitTypeof(Node paramNode1, Node paramNode2) {
    if (paramNode1.getType() == 104) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      addScriptRuntimeInvoke("typeof", 
          "(Ljava/lang/Object;)", "Ljava/lang/String;");
      return;
    } 
    String str = paramNode1.getString();
    if (this.hasVarsInRegs) {
      OptLocalVariable optLocalVariable = (OptLocalVariable)this.vars.get(str);
      if (optLocalVariable != null) {
        if (optLocalVariable.isNumber()) {
          push("number");
          return;
        } 
        visitGetVar(optLocalVariable, false, str);
        addScriptRuntimeInvoke("typeof", 
            "(Ljava/lang/Object;)", "Ljava/lang/String;");
        return;
      } 
    } 
    aload(this.variableObjectLocal);
    push(str);
    addScriptRuntimeInvoke("typeofName", 
        "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)", 
        "Ljava/lang/String;");
  }
  
  private void visitIncDec(Node paramNode, boolean paramBoolean) {
    Node node = paramNode.getFirstChild();
    if (paramNode.getProp(26) != null) {
      OptLocalVariable optLocalVariable = 
        (OptLocalVariable)node.getProp(24);
      if (optLocalVariable.getJRegister() == -1)
        optLocalVariable.assignJRegister(getNewWordPairLocal()); 
      dload(optLocalVariable.getJRegister());
      addByteCode((byte)92);
      push(1.0D);
      addByteCode(paramBoolean ? 99 : 103);
      dstore(optLocalVariable.getJRegister());
    } else {
      OptLocalVariable optLocalVariable = 
        (OptLocalVariable)node.getProp(24);
      String str = paramBoolean ? "postIncrement" : "postDecrement";
      if (this.hasVarsInRegs && node.getType() == 72) {
        if (optLocalVariable == null)
          optLocalVariable = (OptLocalVariable)this.vars.get(node.getString()); 
        if (optLocalVariable.getJRegister() == -1)
          optLocalVariable.assignJRegister(getNewWordLocal()); 
        aload(optLocalVariable.getJRegister());
        addByteCode((byte)89);
        addScriptRuntimeInvoke(str, 
            "(Ljava/lang/Object;)", "Ljava/lang/Object;");
        astore(optLocalVariable.getJRegister());
      } else if (node.getType() == 39) {
        Node node1 = node.getFirstChild();
        generateCodeFromNode(node1, paramNode, -1, -1);
        generateCodeFromNode(node1.getNextSibling(), paramNode, -1, -1);
        aload(this.variableObjectLocal);
        addScriptRuntimeInvoke(str, 
            "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;)", 
            
            "Ljava/lang/Object;");
      } else if (node.getType() == 41) {
        str = String.valueOf(str) + "Elem";
        Node node1 = node.getFirstChild();
        generateCodeFromNode(node1, paramNode, -1, -1);
        generateCodeFromNode(node1.getNextSibling(), paramNode, -1, -1);
        aload(this.variableObjectLocal);
        addScriptRuntimeInvoke(str, 
            "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
            
            "Ljava/lang/Object;");
      } else {
        aload(this.variableObjectLocal);
        push(node.getString());
        addScriptRuntimeInvoke(str, 
            "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)", 
            "Ljava/lang/Object;");
      } 
    } 
  }
  
  private boolean isArithmeticNode(Node paramNode) {
    int i = paramNode.getType();
    return !(i != 24 && 
      i != 27 && 
      i != 26 && 
      i != 25);
  }
  
  private void visitArithmetic(Node paramNode1, byte paramByte, Node paramNode2, Node paramNode3) {
    Integer integer = (Integer)paramNode1.getProp(26);
    if (integer != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
      addByteCode(paramByte);
    } else {
      boolean bool = isArithmeticNode(paramNode3);
      if (!bool) {
        addByteCode((byte)-69, "java/lang/Double");
        addByteCode((byte)89);
      } 
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      if (!isArithmeticNode(paramNode2))
        addScriptRuntimeInvoke("toNumber", "(Ljava/lang/Object;)", "D"); 
      generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
      if (!isArithmeticNode(paramNode2.getNextSibling()))
        addScriptRuntimeInvoke("toNumber", "(Ljava/lang/Object;)", "D"); 
      addByteCode(paramByte);
      if (!bool)
        addDoubleConstructor(); 
    } 
  }
  
  private void visitBitOp(Node paramNode1, int paramInt, Node paramNode2) {
    Integer integer = (Integer)paramNode1.getProp(26);
    if (integer == null) {
      addByteCode((byte)-69, "java/lang/Double");
      addByteCode((byte)89);
    } 
    generateCodeFromNode(paramNode2, paramNode1, -1, -1);
    if (paramInt == 22) {
      addScriptRuntimeInvoke("toUint32", "(Ljava/lang/Object;)", "J");
      generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
      addScriptRuntimeInvoke("toInt32", "(Ljava/lang/Object;)", "I");
      push(31L);
      addByteCode((byte)126);
      addByteCode((byte)125);
      addByteCode((byte)-118);
      addDoubleConstructor();
      return;
    } 
    if (integer == null) {
      addScriptRuntimeInvoke("toInt32", "(Ljava/lang/Object;)", "I");
      generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
      addScriptRuntimeInvoke("toInt32", "(Ljava/lang/Object;)", "I");
    } else {
      addScriptRuntimeInvoke("toInt32", "(D)", "I");
      generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
      addScriptRuntimeInvoke("toInt32", "(D)", "I");
    } 
    switch (paramInt) {
      case 11:
        addByteCode(-128);
        break;
      case 12:
        addByteCode((byte)-126);
        break;
      case 13:
        addByteCode((byte)126);
        break;
      case 21:
        addByteCode((byte)122);
        break;
      case 20:
        addByteCode((byte)120);
        break;
      default:
        badTree();
        break;
    } 
    addByteCode((byte)-121);
    if (integer == null)
      addDoubleConstructor(); 
  }
  
  private boolean nodeIsDirectCallParameter(Node paramNode) {
    if (paramNode.getType() == 72) {
      OptLocalVariable optLocalVariable = 
        (OptLocalVariable)paramNode.getProp(24);
      if (optLocalVariable != null && optLocalVariable.isParameter() && this.inDirectCallFunction && 
        !this.itsForcedObjectParameters)
        return true; 
    } 
    return false;
  }
  
  private void genSimpleCompare(int paramInt1, int paramInt2, int paramInt3) {
    switch (paramInt1) {
      case 17:
        addByteCode((byte)-104);
        addByteCode((byte)-98, paramInt2);
        break;
      case 19:
        addByteCode((byte)-105);
        addByteCode((byte)-100, paramInt2);
        break;
      case 16:
        addByteCode((byte)-104);
        addByteCode((byte)-101, paramInt2);
        break;
      case 18:
        addByteCode((byte)-105);
        addByteCode((byte)-99, paramInt2);
        break;
    } 
    if (paramInt3 != -1)
      addByteCode((byte)-89, paramInt3); 
  }
  
  private void visitGOTOingRelOp(Node paramNode1, Node paramNode2, Node paramNode3, int paramInt1, int paramInt2) {
    int i = paramNode1.getInt();
    Integer integer = (Integer)paramNode1.getProp(26);
    if (integer != null && 
      integer.intValue() == 0) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
      genSimpleCompare(i, paramInt1, paramInt2);
    } else if (i == 64) {
      aload(this.variableObjectLocal);
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
      addScriptRuntimeInvoke("instanceOf", 
          "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Ljava/lang/Object;)", 
          "Z");
      addByteCode((byte)-102, paramInt1);
      addByteCode((byte)-89, paramInt2);
    } else if (i == 63) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
      addScriptRuntimeInvoke("in", 
          "(Ljava/lang/Object;Ljava/lang/Object;)", "Z");
      addByteCode((byte)-102, paramInt1);
      addByteCode((byte)-89, paramInt2);
    } else {
      Node node = paramNode2.getNextSibling();
      boolean bool1 = nodeIsDirectCallParameter(paramNode2);
      boolean bool2 = nodeIsDirectCallParameter(node);
      if (bool1 || bool2)
        if (bool1) {
          if (bool2) {
            OptLocalVariable optLocalVariable1 = 
              (OptLocalVariable)paramNode2.getProp(24);
            aload(optLocalVariable1.getJRegister());
            this.classFile.add((byte)-78, 
                "java/lang/Void", 
                "TYPE", 
                "Ljava/lang/Class;");
            int j = acquireLabel();
            addByteCode((byte)-90, j);
            OptLocalVariable optLocalVariable2 = 
              (OptLocalVariable)node.getProp(24);
            aload(optLocalVariable2.getJRegister());
            this.classFile.add((byte)-78, 
                "java/lang/Void", 
                "TYPE", 
                "Ljava/lang/Class;");
            addByteCode((byte)-90, j);
            dload((short)(optLocalVariable1.getJRegister() + 1));
            dload((short)(optLocalVariable2.getJRegister() + 1));
            genSimpleCompare(i, paramInt1, paramInt2);
            markLabel(j);
          } else if (integer != null && 
            integer.intValue() == 2) {
            OptLocalVariable optLocalVariable = 
              (OptLocalVariable)paramNode2.getProp(24);
            aload(optLocalVariable.getJRegister());
            this.classFile.add((byte)-78, 
                "java/lang/Void", 
                "TYPE", 
                "Ljava/lang/Class;");
            int j = acquireLabel();
            addByteCode((byte)-90, j);
            dload((short)(optLocalVariable.getJRegister() + 1));
            generateCodeFromNode(node, paramNode1, -1, -1);
            genSimpleCompare(i, paramInt1, paramInt2);
            markLabel(j);
          } 
        } else if (integer != null && 
          integer.intValue() == 1) {
          OptLocalVariable optLocalVariable = 
            (OptLocalVariable)node.getProp(24);
          aload(optLocalVariable.getJRegister());
          this.classFile.add((byte)-78, 
              "java/lang/Void", 
              "TYPE", 
              "Ljava/lang/Class;");
          int j = acquireLabel();
          addByteCode((byte)-90, j);
          generateCodeFromNode(paramNode2, paramNode1, -1, -1);
          dload((short)(optLocalVariable.getJRegister() + 1));
          genSimpleCompare(i, paramInt1, paramInt2);
          markLabel(j);
        }  
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      generateCodeFromNode(node, paramNode1, -1, -1);
      if (integer == null) {
        if (i == 19 || i == 18)
          addByteCode((byte)95); 
        String str = (i == 16 || 
          i == 18) ? "cmp_LT" : "cmp_LE";
        addScriptRuntimeInvoke(str, 
            "(Ljava/lang/Object;Ljava/lang/Object;)", "I");
      } else {
        boolean bool = 
          (integer.intValue() != 1) ? 0 : 1;
        if (i == 19 || i == 18)
          if (bool) {
            addByteCode((byte)91);
            addByteCode((byte)87);
            bool = false;
          } else {
            addByteCode((byte)93);
            addByteCode((byte)88);
            bool = true;
          }  
        String str = (i == 16 || 
          i == 18) ? "cmp_LT" : "cmp_LE";
        if (bool) {
          addOptRuntimeInvoke(str, 
              "(DLjava/lang/Object;)", "I");
        } else {
          addOptRuntimeInvoke(str, 
              "(Ljava/lang/Object;D)", "I");
        } 
      } 
      addByteCode((byte)-102, paramInt1);
      addByteCode((byte)-89, paramInt2);
    } 
  }
  
  private void visitRelOp(Node paramNode1, Node paramNode2, Node paramNode3) {
    int i = paramNode1.getInt();
    Integer integer = (Integer)paramNode1.getProp(26);
    if ((integer != null && 
      integer.intValue() == 0) || 
      i == 64 || 
      i == 63) {
      if (i == 64)
        aload(this.variableObjectLocal); 
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
      int j = acquireLabel();
      int k = acquireLabel();
      if (i == 64) {
        addScriptRuntimeInvoke("instanceOf", 
            "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Ljava/lang/Object;)", 
            "Z");
        addByteCode((byte)-102, j);
      } else if (i == 63) {
        addScriptRuntimeInvoke("in", 
            "(Ljava/lang/Object;Ljava/lang/Object;)", "Z");
        addByteCode((byte)-102, j);
      } else {
        genSimpleCompare(i, j, -1);
      } 
      this.classFile.add((byte)-78, "java/lang/Boolean", 
          "FALSE", "Ljava/lang/Boolean;");
      addByteCode((byte)-89, k);
      markLabel(j);
      this.classFile.add((byte)-78, "java/lang/Boolean", 
          "TRUE", "Ljava/lang/Boolean;");
      markLabel(k);
      this.classFile.adjustStackTop(-1);
    } else {
      String str = (i == 16 || 
        i == 18) ? "cmp_LTB" : "cmp_LEB";
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
      if (integer == null) {
        if (i == 19 || i == 18)
          addByteCode((byte)95); 
        addScriptRuntimeInvoke(str, 
            "(Ljava/lang/Object;Ljava/lang/Object;)", 
            "Ljava/lang/Boolean;");
      } else {
        boolean bool = 
          (integer.intValue() != 1) ? 0 : 1;
        if (i == 19 || i == 18)
          if (bool) {
            addByteCode((byte)91);
            addByteCode((byte)87);
            bool = false;
          } else {
            addByteCode((byte)93);
            addByteCode((byte)88);
            bool = true;
          }  
        if (bool) {
          addOptRuntimeInvoke(str, 
              "(DLjava/lang/Object;)", 
              "Ljava/lang/Boolean;");
        } else {
          addOptRuntimeInvoke(str, 
              "(Ljava/lang/Object;D)", 
              "Ljava/lang/Boolean;");
        } 
      } 
    } 
  }
  
  private Number nodeIsConvertToObjectOfNumber(Node paramNode) {
    if (paramNode.getType() == 141) {
      Object object = paramNode.getProp(18);
      if (object == ScriptRuntime.ObjectClass) {
        Node node = paramNode.getFirstChild();
        if (node.getType() == 45)
          return (Number)node.getDatum(); 
      } 
    } 
    return null;
  }
  
  private void visitEqOp(Node paramNode1, Node paramNode2, Node paramNode3, int paramInt1, int paramInt2) {
    int i = paramNode1.getInt();
    Node node = paramNode2.getNextSibling();
    if (paramInt1 == -1) {
      String str;
      if (node.getType() == 108 && 
        node.getInt() == 49) {
        generateCodeFromNode(paramNode2, paramNode1, -1, -1);
        addByteCode((byte)89);
        addByteCode((byte)-58, 15);
        pushUndefined();
        addByteCode((byte)-91, 10);
        if (i == 14 || i == 53) {
          this.classFile.add((byte)-78, "java/lang/Boolean", 
              "FALSE", "Ljava/lang/Boolean;");
        } else {
          this.classFile.add((byte)-78, "java/lang/Boolean", 
              "TRUE", "Ljava/lang/Boolean;");
        } 
        addByteCode((byte)-89, 7);
        addByteCode((byte)87);
        if (i == 14 || i == 53) {
          this.classFile.add((byte)-78, "java/lang/Boolean", 
              "TRUE", "Ljava/lang/Boolean;");
        } else {
          this.classFile.add((byte)-78, "java/lang/Boolean", 
              "FALSE", "Ljava/lang/Boolean;");
        } 
        return;
      } 
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
      switch (i) {
        case 14:
          str = (this.version == 120) ? "seqB" : "eqB";
          break;
        case 15:
          str = (this.version == 120) ? "sneB" : "neB";
          break;
        case 53:
          str = "seqB";
          break;
        case 54:
          str = "sneB";
          break;
        default:
          str = null;
          badTree();
          break;
      } 
      addScriptRuntimeInvoke(str, 
          "(Ljava/lang/Object;Ljava/lang/Object;)", 
          "Ljava/lang/Boolean;");
    } else {
      String str;
      if (node.getType() == 108 && 
        node.getInt() == 49) {
        generateCodeFromNode(paramNode2, paramNode1, -1, -1);
        boolean bool = (paramNode2.getType() != 72) ? 0 : 1;
        if (!bool)
          addByteCode((byte)89); 
        int j = acquireLabel();
        if (i == 14 || i == 53) {
          addByteCode((byte)-58, 
              bool ? paramInt1 : j);
          short s = this.classFile.getStackTop();
          if (bool)
            generateCodeFromNode(paramNode2, paramNode1, -1, -1); 
          pushUndefined();
          addByteCode((byte)-91, paramInt1);
          addByteCode((byte)-89, paramInt2);
          if (!bool) {
            markLabel(j, s);
            addByteCode((byte)87);
            addByteCode((byte)-89, paramInt1);
          } 
        } else {
          addByteCode((byte)-58, 
              bool ? paramInt2 : j);
          short s = this.classFile.getStackTop();
          if (bool)
            generateCodeFromNode(paramNode2, paramNode1, -1, -1); 
          pushUndefined();
          addByteCode((byte)-91, paramInt2);
          addByteCode((byte)-89, paramInt1);
          if (!bool) {
            markLabel(j, s);
            addByteCode((byte)87);
            addByteCode((byte)-89, paramInt2);
          } 
        } 
        return;
      } 
      Node node1 = paramNode2.getNextSibling();
      Number number = nodeIsConvertToObjectOfNumber(node1);
      if (nodeIsDirectCallParameter(paramNode2) && 
        number != null) {
        OptLocalVariable optLocalVariable = 
          (OptLocalVariable)paramNode2.getProp(24);
        aload(optLocalVariable.getJRegister());
        this.classFile.add((byte)-78, 
            "java/lang/Void", 
            "TYPE", 
            "Ljava/lang/Class;");
        int j = acquireLabel();
        addByteCode((byte)-90, j);
        dload((short)(optLocalVariable.getJRegister() + 1));
        push(number.doubleValue());
        addByteCode((byte)-105);
        if (i == 14) {
          addByteCode((byte)-103, paramInt1);
        } else {
          addByteCode((byte)-102, paramInt1);
        } 
        addByteCode((byte)-89, paramInt2);
        markLabel(j);
      } 
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      generateCodeFromNode(node1, paramNode1, -1, -1);
      switch (i) {
        case 14:
          str = (this.version == 120) ? "shallowEq" : "eq";
          addScriptRuntimeInvoke(str, 
              "(Ljava/lang/Object;Ljava/lang/Object;)", "Z");
          break;
        case 15:
          str = (this.version == 120) ? "shallowNeq" : "neq";
          addOptRuntimeInvoke(str, 
              "(Ljava/lang/Object;Ljava/lang/Object;)", "Z");
          break;
        case 53:
          str = "shallowEq";
          addScriptRuntimeInvoke(str, 
              "(Ljava/lang/Object;Ljava/lang/Object;)", "Z");
          break;
        case 54:
          str = "shallowNeq";
          addOptRuntimeInvoke(str, 
              "(Ljava/lang/Object;Ljava/lang/Object;)", "Z");
          break;
        default:
          str = null;
          badTree();
          break;
      } 
      addByteCode((byte)-102, paramInt1);
      addByteCode((byte)-89, paramInt2);
    } 
  }
  
  private void visitLiteral(Node paramNode) {
    if (paramNode.getType() == 46) {
      push(paramNode.getString());
    } else {
      Number number = (Number)paramNode.getDatum();
      if (paramNode.getProp(26) != null) {
        push(number.doubleValue());
      } else {
        String str1 = "";
        String str2 = "";
        boolean bool = false;
        if (number instanceof Float)
          number = new Double(number.floatValue()); 
        if (number instanceof Integer) {
          str1 = "Integer";
          str2 = "I";
          bool = true;
        } else if (number instanceof Double) {
          str1 = "Double";
          str2 = "D";
        } else if (number instanceof Byte) {
          str1 = "Byte";
          str2 = "B";
          bool = true;
        } else if (number instanceof Short) {
          str1 = "Short";
          str2 = "S";
          bool = true;
        } else {
          throw Context.reportRuntimeError(
              "NumberNode contains unsupported Number type: " + 
              number.getClass().getName());
        } 
        if (this.itsConstantList.itsTop >= 2000) {
          addByteCode((byte)-69, "java/lang/" + str1);
          addByteCode((byte)89);
          if (bool) {
            push(number.longValue());
          } else {
            push(number.doubleValue());
          } 
          addSpecialInvoke("java/lang/" + 
              str1, 
              "<init>", 
              "(" + 
              str2 + 
              ")", 
              "V");
        } else {
          this.classFile.add((byte)-78, 
              ClassFileWriter.fullyQualifiedForm(this.name), 
              "jsK_" + 
              this.itsConstantList.addConstant(str1, 
                str2, 
                number, 
                bool), 
              "Ljava/lang/" + str1 + ";");
        } 
      } 
    } 
  }
  
  private void emitConstantDudeInitializers() {
    if (this.itsConstantList.itsTop == 0)
      return; 
    this.classFile.startMethod("<clinit>", "()V", (short)
        24);
    for (byte b = 0; b < this.itsConstantList.itsTop; b++) {
      addByteCode((byte)-69, 
          "java/lang/" + 
          (this.itsConstantList.itsList[b]).itsWrapperType);
      addByteCode((byte)89);
      if ((this.itsConstantList.itsList[b]).itsIsInteger) {
        push((this.itsConstantList.itsList[b]).itsLValue);
      } else {
        push((this.itsConstantList.itsList[b]).itsDValue);
      } 
      addSpecialInvoke("java/lang/" + 
          (this.itsConstantList.itsList[b]).itsWrapperType, 
          "<init>", 
          "(" + 
          (this.itsConstantList.itsList[b]).itsSignature + 
          ")", 
          "V");
      this.classFile.addField("jsK_" + b, 
          "Ljava/lang/" + 
          (this.itsConstantList.itsList[b]).itsWrapperType + ";", (short)
          8);
      this.classFile.add((byte)-77, 
          ClassFileWriter.fullyQualifiedForm(this.name), 
          "jsK_" + b, 
          "Ljava/lang/" + 
          (this.itsConstantList.itsList[b]).itsWrapperType + ";");
    } 
    addByteCode((byte)-79);
    this.classFile.stopMethod((short)0, null);
  }
  
  private void visitPrimary(Node paramNode) {
    int i = paramNode.getInt();
    switch (i) {
      case 50:
        aload(this.thisObjLocal);
        return;
      case 49:
        addByteCode((byte)1);
        return;
      case 52:
        this.classFile.add((byte)-78, "java/lang/Boolean", 
            "TRUE", "Ljava/lang/Boolean;");
        return;
      case 51:
        this.classFile.add((byte)-78, "java/lang/Boolean", 
            "FALSE", "Ljava/lang/Boolean;");
        return;
      case 74:
        pushUndefined();
        return;
    } 
    badTree();
  }
  
  private void visitObject(Node paramNode) {
    Node node = (Node)paramNode.getProp(12);
    String str = (String)node.getProp(12);
    aload(this.funObjLocal);
    this.classFile.add((byte)-76, 
        ClassFileWriter.fullyQualifiedForm(this.name), 
        str, "Lorg/mozilla/javascript/regexp/NativeRegExp;");
  }
  
  private void visitName(Node paramNode) {
    aload(this.variableObjectLocal);
    push(paramNode.getString());
    addScriptRuntimeInvoke("name", 
        "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)", 
        "Ljava/lang/Object;");
  }
  
  private void visitSetName(Node paramNode1, Node paramNode2) {
    String str = paramNode1.getFirstChild().getString();
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    aload(this.variableObjectLocal);
    push(str);
    addScriptRuntimeInvoke("setName", 
        "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)", 
        
        "Ljava/lang/Object;");
  }
  
  private void visitGetVar(OptLocalVariable paramOptLocalVariable, boolean paramBoolean, String paramString) {
    if (this.hasVarsInRegs && paramOptLocalVariable == null)
      paramOptLocalVariable = (OptLocalVariable)this.vars.get(paramString); 
    if (paramOptLocalVariable != null) {
      if (paramOptLocalVariable.getJRegister() == -1)
        if (paramOptLocalVariable.isNumber()) {
          paramOptLocalVariable.assignJRegister(getNewWordPairLocal());
        } else {
          paramOptLocalVariable.assignJRegister(getNewWordLocal());
        }  
      if (paramOptLocalVariable.isParameter() && this.inDirectCallFunction && 
        !this.itsForcedObjectParameters) {
        if (paramBoolean) {
          aload(paramOptLocalVariable.getJRegister());
          this.classFile.add((byte)-78, 
              "java/lang/Void", 
              "TYPE", 
              "Ljava/lang/Class;");
          int i = acquireLabel();
          int j = acquireLabel();
          addByteCode((byte)-91, i);
          aload(paramOptLocalVariable.getJRegister());
          addScriptRuntimeInvoke("toNumber", "(Ljava/lang/Object;)", "D");
          addByteCode((byte)-89, j);
          markLabel(i);
          dload((short)(paramOptLocalVariable.getJRegister() + 1));
          markLabel(j);
        } else {
          aload(paramOptLocalVariable.getJRegister());
          this.classFile.add((byte)-78, 
              "java/lang/Void", 
              "TYPE", 
              "Ljava/lang/Class;");
          int i = acquireLabel();
          int j = acquireLabel();
          addByteCode((byte)-91, i);
          aload(paramOptLocalVariable.getJRegister());
          addByteCode((byte)-89, j);
          markLabel(i);
          addByteCode((byte)-69, "java/lang/Double");
          addByteCode((byte)89);
          dload((short)(paramOptLocalVariable.getJRegister() + 1));
          addDoubleConstructor();
          markLabel(j);
        } 
      } else if (paramOptLocalVariable.isNumber()) {
        dload(paramOptLocalVariable.getJRegister());
      } else {
        aload(paramOptLocalVariable.getJRegister());
      } 
      return;
    } 
    aload(this.variableObjectLocal);
    push(paramString);
    aload(this.variableObjectLocal);
    addScriptRuntimeInvoke("getProp", 
        "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;)", 
        
        "Ljava/lang/Object;");
  }
  
  private void visitSetVar(Node paramNode1, Node paramNode2, boolean paramBoolean) {
    OptLocalVariable optLocalVariable = (OptLocalVariable)paramNode1.getProp(24);
    if (this.hasVarsInRegs && optLocalVariable == null)
      optLocalVariable = (OptLocalVariable)this.vars.get(paramNode2.getString()); 
    if (optLocalVariable != null) {
      generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
      if (optLocalVariable.getJRegister() == -1)
        if (optLocalVariable.isNumber()) {
          optLocalVariable.assignJRegister(getNewWordPairLocal());
        } else {
          optLocalVariable.assignJRegister(getNewWordLocal());
        }  
      if (optLocalVariable.isParameter() && 
        this.inDirectCallFunction && 
        !this.itsForcedObjectParameters) {
        if (paramNode1.getProp(26) != null) {
          if (paramBoolean)
            addByteCode((byte)92); 
          aload(optLocalVariable.getJRegister());
          this.classFile.add((byte)-78, 
              "java/lang/Void", 
              "TYPE", 
              "Ljava/lang/Class;");
          int i = acquireLabel();
          int j = acquireLabel();
          addByteCode((byte)-91, i);
          addByteCode((byte)-69, "java/lang/Double");
          addByteCode((byte)89);
          addByteCode((byte)94);
          addByteCode((byte)88);
          addDoubleConstructor();
          astore(optLocalVariable.getJRegister());
          addByteCode((byte)-89, j);
          markLabel(i);
          dstore((short)(optLocalVariable.getJRegister() + 1));
          markLabel(j);
        } else {
          if (paramBoolean)
            addByteCode((byte)89); 
          astore(optLocalVariable.getJRegister());
        } 
      } else if (paramNode1.getProp(26) != null) {
        dstore(optLocalVariable.getJRegister());
        if (paramBoolean)
          dload(optLocalVariable.getJRegister()); 
      } else {
        astore(optLocalVariable.getJRegister());
        if (paramBoolean)
          aload(optLocalVariable.getJRegister()); 
      } 
      return;
    } 
    paramNode2.setType(61);
    paramNode1.setType(10);
    visitSetName(paramNode1, paramNode2);
    if (!paramBoolean)
      addByteCode((byte)87); 
  }
  
  private void visitGetProp(Node paramNode1, Node paramNode2) {
    String str = (String)paramNode1.getProp(19);
    if (str != null) {
      while (paramNode2 != null) {
        generateCodeFromNode(paramNode2, paramNode1, -1, -1);
        paramNode2 = paramNode2.getNextSibling();
      } 
      aload(this.variableObjectLocal);
      String str1 = null;
      if (str.equals("__proto__")) {
        str1 = "getProto";
      } else if (str.equals("__parent__")) {
        str1 = "getParent";
      } else {
        badTree();
      } 
      addScriptRuntimeInvoke(str1, 
          "(Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
          "Lorg/mozilla/javascript/Scriptable;");
      return;
    } 
    Node node = paramNode2.getNextSibling();
    generateCodeFromNode(paramNode2, paramNode1, -1, -1);
    generateCodeFromNode(node, paramNode1, -1, -1);
    if (node.getType() == 46) {
      if ((paramNode2.getType() == 108 && 
        paramNode2.getInt() == 50) || (
        paramNode2.getType() == 69 && 
        paramNode2.getFirstChild().getType() == 108 && 
        paramNode2.getFirstChild().getInt() == 50)) {
        aload(this.variableObjectLocal);
        addOptRuntimeInvoke("thisGet", 
            
            "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;)", 
            
            "Ljava/lang/Object;");
      } else {
        aload(this.variableObjectLocal);
        addScriptRuntimeInvoke("getProp", 
            "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;)", 
            
            "Ljava/lang/Object;");
      } 
    } else {
      aload(this.variableObjectLocal);
      addScriptRuntimeInvoke("getProp", 
          "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;)", 
          
          "Ljava/lang/Object;");
    } 
  }
  
  private void visitSetProp(Node paramNode1, Node paramNode2) {
    String str = (String)paramNode1.getProp(19);
    if (str != null) {
      while (paramNode2 != null) {
        generateCodeFromNode(paramNode2, paramNode1, -1, -1);
        paramNode2 = paramNode2.getNextSibling();
      } 
      aload(this.variableObjectLocal);
      String str1 = null;
      if (str.equals("__proto__")) {
        str1 = "setProto";
      } else if (str.equals("__parent__")) {
        str1 = "setParent";
      } else {
        badTree();
      } 
      addScriptRuntimeInvoke(str1, 
          "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
          
          "Ljava/lang/Object;");
      return;
    } 
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    aload(this.variableObjectLocal);
    addScriptRuntimeInvoke("setProp", 
        "(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
        
        "Ljava/lang/Object;");
  }
  
  private void visitBind(Node paramNode1, int paramInt, Node paramNode2) {
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    aload(this.variableObjectLocal);
    push(paramNode1.getString());
    addScriptRuntimeInvoke((paramInt == 61) ? "bind" : "getBase", 
        "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)", 
        "Lorg/mozilla/javascript/Scriptable;");
  }
  
  private short getLocalFromNode(Node paramNode) {
    Integer integer = (Integer)paramNode.getProp(7);
    if (integer == null) {
      this.itsLocalAllocationBase = (short)(this.itsLocalAllocationBase + 1);
      short s = (paramNode.getType() == 143 || paramNode.getType() == 144) ? this.itsLocalAllocationBase : getNewWordLocal();
      paramNode.putProp(7, new Integer(s));
      return s;
    } 
    return integer.shortValue();
  }
  
  private void visitNewTemp(Node paramNode1, Node paramNode2) {
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    short s = getLocalFromNode(paramNode1);
    addByteCode((byte)89);
    astore(s);
    Integer integer = (Integer)paramNode1.getProp(11);
    if (integer == null || integer.intValue() == 0)
      releaseWordLocal(s); 
  }
  
  private void visitUseTemp(Node paramNode1, Node paramNode2) {
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    Node node = (Node)paramNode1.getProp(6);
    short s = getLocalFromNode(node);
    if (paramNode1.getProp(true) != null) {
      addByteCode((byte)-87, s);
    } else {
      aload(s);
    } 
    Integer integer = (Integer)node.getProp(11);
    if (integer == null) {
      releaseWordLocal(s);
    } else if (integer.intValue() < Integer.MAX_VALUE) {
      int i = integer.intValue() - 1;
      if (i == 0)
        releaseWordLocal(s); 
      node.putProp(11, new Integer(i));
    } 
  }
  
  private void visitNewLocal(Node paramNode1, Node paramNode2) {
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    short s = getLocalFromNode(paramNode1);
    addByteCode((byte)89);
    astore(s);
  }
  
  private void visitUseLocal(Node paramNode1, Node paramNode2) {
    while (paramNode2 != null) {
      generateCodeFromNode(paramNode2, paramNode1, -1, -1);
      paramNode2 = paramNode2.getNextSibling();
    } 
    Node node = (Node)paramNode1.getProp(7);
    short s = getLocalFromNode(node);
    if (paramNode1.getProp(true) != null) {
      addByteCode((byte)-87, s);
    } else {
      aload(s);
    } 
  }
  
  private void dstore(short paramShort) { xstore((byte)71, (byte)57, paramShort); }
  
  private void istore(short paramShort) { xstore((byte)59, (byte)54, paramShort); }
  
  private void astore(short paramShort) { xstore((byte)75, (byte)58, paramShort); }
  
  private void xstore(byte paramByte1, byte paramByte2, short paramShort) {
    switch (paramShort) {
      case 0:
        addByteCode(paramByte1);
        return;
      case 1:
        addByteCode((byte)(paramByte1 + 1));
        return;
      case 2:
        addByteCode((byte)(paramByte1 + 2));
        return;
      case 3:
        addByteCode((byte)(paramByte1 + 3));
        return;
    } 
    if (paramShort < 0 || paramShort >= 127)
      throw new RuntimeException("bad local"); 
    addByteCode(paramByte2, (byte)paramShort);
  }
  
  private void dload(short paramShort) { xload((byte)38, (byte)24, paramShort); }
  
  private void iload(short paramShort) { xload((byte)26, (byte)21, paramShort); }
  
  private void aload(short paramShort) { xload((byte)42, (byte)25, paramShort); }
  
  private void xload(byte paramByte1, byte paramByte2, short paramShort) {
    switch (paramShort) {
      case 0:
        addByteCode(paramByte1);
        return;
      case 1:
        addByteCode((byte)(paramByte1 + 1));
        return;
      case 2:
        addByteCode((byte)(paramByte1 + 2));
        return;
      case 3:
        addByteCode((byte)(paramByte1 + 3));
        return;
    } 
    if (paramShort < 0 || paramShort >= 127)
      throw new RuntimeException("bad local"); 
    addByteCode(paramByte2, (byte)paramShort);
  }
  
  private short getNewWordPairLocal() {
    short s = this.firstFreeLocal;
    while (s < 255) {
      if (this.locals[s] || 
        this.locals[s + 1])
        s = (short)(s + 1); 
    } 
    if (s < 255) {
      this.locals[s] = true;
      this.locals[s + 1] = true;
      if (s == this.firstFreeLocal) {
        for (short s1 = this.firstFreeLocal + 2; s1 < 256; s1++) {
          if (!this.locals[s1]) {
            this.firstFreeLocal = (short)s1;
            if (this.localsMax < this.firstFreeLocal)
              this.localsMax = this.firstFreeLocal; 
            return s;
          } 
        } 
      } else {
        return s;
      } 
    } 
    throw Context.reportRuntimeError("Program too complex (out of locals)");
  }
  
  private short reserveWordLocal(int paramInt) {
    if (getNewWordLocal() != paramInt)
      throw new RuntimeException("Local allocation error"); 
    return (short)paramInt;
  }
  
  private short getNewWordLocal() {
    short s1 = this.firstFreeLocal;
    this.locals[s1] = true;
    for (short s2 = this.firstFreeLocal + 1; s2 < 256; s2++) {
      if (!this.locals[s2]) {
        this.firstFreeLocal = (short)s2;
        if (this.localsMax < this.firstFreeLocal)
          this.localsMax = this.firstFreeLocal; 
        return s1;
      } 
    } 
    throw Context.reportRuntimeError("Program too complex (out of locals)");
  }
  
  private void releaseWordpairLocal(short paramShort) {
    if (paramShort < this.firstFreeLocal)
      this.firstFreeLocal = paramShort; 
    this.locals[paramShort] = false;
    this.locals[paramShort + 1] = false;
  }
  
  private void releaseWordLocal(short paramShort) {
    if (paramShort < this.firstFreeLocal)
      this.firstFreeLocal = paramShort; 
    this.locals[paramShort] = false;
  }
  
  private void push(long paramLong) {
    if (paramLong == -1L) {
      addByteCode((byte)2);
    } else if (paramLong >= 0L && paramLong <= 5L) {
      addByteCode((byte)(int)(3L + paramLong));
    } else if (paramLong >= -128L && paramLong <= 127L) {
      addByteCode((byte)16, (byte)(int)paramLong);
    } else if (paramLong >= -32768L && paramLong <= 32767L) {
      addByteCode((byte)17, (short)(int)paramLong);
    } else if (paramLong >= -2147483648L && paramLong <= 2147483647L) {
      this.classFile.addLoadConstant((int)paramLong);
    } else {
      this.classFile.addLoadConstant(paramLong);
    } 
  }
  
  private void push(double paramDouble) {
    if (paramDouble == 0.0D) {
      addByteCode((byte)14);
    } else if (paramDouble == 1.0D) {
      addByteCode((byte)15);
    } else {
      this.classFile.addLoadConstant(paramDouble);
    } 
  }
  
  private void push(String paramString) { this.classFile.addLoadConstant(paramString); }
  
  private void pushUndefined() {
    this.classFile.add((byte)-78, "org/mozilla/javascript/Undefined", 
        "instance", "Lorg/mozilla/javascript/Scriptable;");
  }
  
  private void badTree() { throw new RuntimeException("Bad tree in codegen"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\Codegen.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */