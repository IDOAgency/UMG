/*      */ package org.mozilla.javascript.optimizer;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ import org.mozilla.classfile.ClassFileWriter;
/*      */ import org.mozilla.javascript.ClassNameHelper;
/*      */ import org.mozilla.javascript.Context;
/*      */ import org.mozilla.javascript.FunctionNode;
/*      */ import org.mozilla.javascript.IRFactory;
/*      */ import org.mozilla.javascript.Interpreter;
/*      */ import org.mozilla.javascript.JavaAdapter;
/*      */ import org.mozilla.javascript.NativeObject;
/*      */ import org.mozilla.javascript.NativeScript;
/*      */ import org.mozilla.javascript.Node;
/*      */ import org.mozilla.javascript.ScriptRuntime;
/*      */ import org.mozilla.javascript.Scriptable;
/*      */ import org.mozilla.javascript.ScriptableObject;
/*      */ import org.mozilla.javascript.SecuritySupport;
/*      */ import org.mozilla.javascript.ShallowNodeIterator;
/*      */ import org.mozilla.javascript.TokenStream;
/*      */ import org.mozilla.javascript.VariableTable;
/*      */ import org.mozilla.javascript.WrappedException;
/*      */ 
/*      */ public class Codegen
/*      */   extends Interpreter
/*      */ {
/*      */   private static final String normalFunctionSuperClassName = "org.mozilla.javascript.NativeFunction";
/*      */   private static final String normalScriptSuperClassName = "org.mozilla.javascript.NativeScript";
/*      */   private static final String debugFunctionSuperClassName = "org.mozilla.javascript.debug.NativeFunctionDebug";
/*      */   private static final String debugScriptSuperClassName = "org.mozilla.javascript.debug.NativeScriptDebug";
/*      */   private String superClassName;
/*      */   private String superClassSlashName;
/*      */   private String name;
/*      */   private int ordinal;
/*      */   boolean inFunction;
/*      */   boolean inDirectCallFunction;
/*      */   private ClassFileWriter classFile;
/*      */   private Vector namesVector;
/*      */   private Vector classFilesVector;
/*      */   private short scriptRuntimeIndex;
/*      */   private int version;
/*      */   private OptClassNameHelper itsNameHelper;
/*      */   private static JavaScriptClassLoader classLoader;
/*      */   private String itsSourceFile;
/*      */   private int itsLineNumber;
/*      */   private int stackDepth;
/*      */   private int stackDepthMax;
/*      */   private static final int MAX_LOCALS = 256;
/*      */   private boolean[] locals;
/*      */   private short firstFreeLocal;
/*      */   private short localsMax;
/*   55 */   private ConstantList itsConstantList = new ConstantList(); private short variableObjectLocal; private short scriptResultLocal; private short contextLocal; private short argsLocal; private short thisObjLocal; private short funObjLocal; private short debug_pcLocal; private short debugStopSubRetLocal;
/*      */   private short itsZeroArgArray;
/*      */   private short itsOneArgArray;
/*      */   private boolean hasVarsInRegs;
/*      */   private boolean itsForcedObjectParameters;
/*      */   
/*   61 */   public IRFactory createIRFactory(TokenStream paramTokenStream, ClassNameHelper paramClassNameHelper, Scriptable paramScriptable) { return new OptIRFactory(paramTokenStream, paramClassNameHelper, paramScriptable); }
/*      */   private boolean trivialInit; private short itsLocalAllocationBase; private OptVariableTable vars; private OptVariableTable debugVars; private int epilogueLabel; private int optLevel; private static final int debugLevel = 0; private int debugStopSubLabel; private short[] debugLineMap; private short debugLineEntryCount; private static final int DEBUG_LINE_MAP_INITIAL_SIZE = 100; private static final int DEBUG_LINE_MAP_RESIZE_INCREMENT = 100;
/*      */   
/*      */   public Node transform(Node paramNode, TokenStream paramTokenStream, Scriptable paramScriptable) {
/*   65 */     OptTransformer optTransformer = new OptTransformer(new Hashtable(11));
/*   66 */     return optTransformer.transform(paramNode, null, paramTokenStream, paramScriptable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object compile(Context paramContext, Scriptable paramScriptable, Node paramNode, Object paramObject, SecuritySupport paramSecuritySupport, ClassNameHelper paramClassNameHelper) throws IOException {
/*   75 */     Vector vector1 = new Vector();
/*   76 */     Vector vector2 = new Vector();
/*   77 */     String str = null;
/*      */     
/*   79 */     IllegalArgumentException illegalArgumentException = null;
/*   80 */     Class clazz = null;
/*      */     
/*      */     try {
/*   83 */       if (paramContext.getOptimizationLevel() > 0) {
/*   84 */         (new Optimizer()).optimize(paramNode, paramContext.getOptimizationLevel());
/*      */       }
/*   86 */       str = generateCode(paramNode, vector2, vector1, paramClassNameHelper);
/*      */       
/*   88 */       for (byte b = 0; b < vector2.size(); b++) {
/*   89 */         String str1 = (String)vector2.elementAt(b);
/*   90 */         byte[] arrayOfByte = (byte[])vector1.elementAt(b);
/*   91 */         if (paramClassNameHelper.getGeneratingDirectory() != null) {
/*      */           try {
/*   93 */             int i = str1.lastIndexOf('.');
/*   94 */             if (i != -1)
/*   95 */               str1 = str1.substring(i + 1); 
/*   96 */             String str2 = 
/*   97 */               paramClassNameHelper.getTargetClassFileName(str1);
/*   98 */             FileOutputStream fileOutputStream = new FileOutputStream(str2);
/*   99 */             fileOutputStream.write(arrayOfByte);
/*  100 */             fileOutputStream.close();
/*      */           }
/*  102 */           catch (IOException iOException) {
/*  103 */             throw WrappedException.wrapException(iOException);
/*      */           } 
/*      */         } else {
/*      */           try {
/*      */             Class clazz1;
/*  108 */             if (paramSecuritySupport == null) {
/*  109 */               if (Context.isSecurityDomainRequired()) {
/*  110 */                 throw new SecurityException("Required security context missing");
/*      */               }
/*  112 */               if (classLoader == null)
/*  113 */                 classLoader = new JavaScriptClassLoader(); 
/*  114 */               clazz1 = classLoader.defineClass(str1, arrayOfByte);
/*  115 */               ClassLoader classLoader1 = clazz1.getClassLoader();
/*  116 */               clazz1 = classLoader1.loadClass(str1);
/*      */             } else {
/*  118 */               clazz1 = paramSecuritySupport.defineClass(str1, arrayOfByte, 
/*  119 */                   paramObject);
/*      */             } 
/*  121 */             if (str1.equals(str))
/*  122 */               clazz = clazz1; 
/*  123 */           } catch (ClassFormatError classFormatError) {
/*  124 */             throw new RuntimeException(classFormatError.toString());
/*  125 */           } catch (ClassNotFoundException classNotFoundException) {
/*  126 */             throw new RuntimeException(classNotFoundException.toString());
/*      */           }
/*      */         
/*      */         } 
/*      */       } 
/*  131 */     } catch (SecurityException securityException) {
/*  132 */       illegalArgumentException = securityException;
/*      */     }
/*  134 */     catch (IllegalArgumentException illegalArgumentException1) {
/*  135 */       illegalArgumentException = illegalArgumentException1;
/*      */     } 
/*  137 */     if (illegalArgumentException != null) {
/*  138 */       throw new RuntimeException("Malformed optimizer package " + illegalArgumentException);
/*      */     }
/*  140 */     OptClassNameHelper optClassNameHelper = (OptClassNameHelper)paramClassNameHelper;
/*  141 */     if (optClassNameHelper.getTargetImplements() != null || 
/*  142 */       optClassNameHelper.getTargetExtends() != null) {
/*      */       
/*  144 */       String str1 = optClassNameHelper.getJavaScriptClassName(null, true);
/*  145 */       NativeObject nativeObject = new NativeObject();
/*  146 */       ShallowNodeIterator shallowNodeIterator = paramNode.getChildIterator();
/*  147 */       while (shallowNodeIterator.hasMoreElements()) {
/*  148 */         Node node = shallowNodeIterator.nextNode();
/*  149 */         if (node.getType() == 109)
/*  150 */           nativeObject.put((String)node.getDatum(), nativeObject, 
/*  151 */               node.getProp(5)); 
/*      */       } 
/*      */       try {
/*  154 */         Class clazz1 = optClassNameHelper.getTargetExtends();
/*  155 */         if (clazz1 == null)
/*  156 */           clazz1 = Object.class; 
/*  157 */         JavaAdapter.createAdapterClass(paramContext, nativeObject, str1, 
/*  158 */             clazz1, 
/*  159 */             optClassNameHelper.getTargetImplements(), 
/*  160 */             str, 
/*  161 */             optClassNameHelper);
/*  162 */       } catch (ClassNotFoundException classNotFoundException) {
/*      */         
/*  164 */         throw new Error(classNotFoundException.toString());
/*      */       } 
/*      */     } 
/*  167 */     if (paramNode instanceof OptFunctionNode) {
/*  168 */       return ScriptRuntime.createFunctionObject(paramScriptable, clazz, paramContext, true);
/*      */     }
/*      */     try {
/*  171 */       if (clazz == null)
/*  172 */         return null; 
/*  173 */       NativeScript nativeScript = (NativeScript)clazz.newInstance();
/*  174 */       if (paramScriptable != null) {
/*  175 */         nativeScript.setPrototype(ScriptableObject.getClassPrototype(paramScriptable, 
/*  176 */               "Script"));
/*  177 */         nativeScript.setParentScope(paramScriptable);
/*      */       } 
/*  179 */       return nativeScript;
/*      */     }
/*  181 */     catch (InstantiationException instantiationException) {
/*      */     
/*  183 */     } catch (IllegalAccessException illegalAccessException) {}
/*      */     
/*  185 */     throw new RuntimeException("Unable to instantiate compiled class");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  191 */   void addByteCode(byte paramByte) { this.classFile.add(paramByte); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  196 */   void addByteCode(byte paramByte, int paramInt) { this.classFile.add(paramByte, paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  201 */   void addByteCode(byte paramByte, String paramString) { this.classFile.add(paramByte, paramString); }
/*      */ 
/*      */ 
/*      */   
/*      */   void addVirtualInvoke(String paramString1, String paramString2, String paramString3, String paramString4) {
/*  206 */     this.classFile.add((byte)-74, 
/*  207 */         paramString1, 
/*  208 */         paramString2, 
/*  209 */         paramString3, 
/*  210 */         paramString4);
/*      */   }
/*      */ 
/*      */   
/*      */   void addStaticInvoke(String paramString1, String paramString2, String paramString3, String paramString4) {
/*  215 */     this.classFile.add((byte)-72, 
/*  216 */         paramString1, 
/*  217 */         paramString2, 
/*  218 */         paramString3, 
/*  219 */         paramString4);
/*      */   }
/*      */ 
/*      */   
/*      */   void addScriptRuntimeInvoke(String paramString1, String paramString2, String paramString3) {
/*  224 */     this.classFile.add((byte)-72, 
/*  225 */         "org/mozilla/javascript/ScriptRuntime", 
/*  226 */         paramString1, 
/*  227 */         paramString2, 
/*  228 */         paramString3);
/*      */   }
/*      */ 
/*      */   
/*      */   void addOptRuntimeInvoke(String paramString1, String paramString2, String paramString3) {
/*  233 */     this.classFile.add((byte)-72, 
/*  234 */         "org/mozilla/javascript/optimizer/OptRuntime", 
/*  235 */         paramString1, 
/*  236 */         paramString2, 
/*  237 */         paramString3);
/*      */   }
/*      */ 
/*      */   
/*      */   void addSpecialInvoke(String paramString1, String paramString2, String paramString3, String paramString4) {
/*  242 */     this.classFile.add((byte)-73, 
/*  243 */         paramString1, 
/*  244 */         paramString2, 
/*  245 */         paramString3, 
/*  246 */         paramString4);
/*      */   }
/*      */ 
/*      */   
/*      */   void addDoubleConstructor() {
/*  251 */     this.classFile.add((byte)-73, 
/*  252 */         "java/lang/Double", 
/*  253 */         "<init>", "(D)", "V");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  258 */   public int markLabel(int paramInt) { return this.classFile.markLabel(paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  263 */   public int markLabel(int paramInt, short paramShort) { return this.classFile.markLabel(paramInt, paramShort); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  268 */   public int acquireLabel() { return this.classFile.acquireLabel(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void emitDirectConstructor(OptFunctionNode paramOptFunctionNode) {
/*  293 */     int i = 
/*  294 */       17;
/*  295 */     this.classFile.startMethod("constructDirect", 
/*  296 */         String.valueOf(paramOptFunctionNode.getDirectCallParameterSignature()) + 
/*  297 */         "Ljava/lang/Object;", 
/*  298 */         i);
/*      */     
/*  300 */     int j = paramOptFunctionNode.getVariableTable().getParameterCount();
/*  301 */     short s = (short)(4 + j * 3 + 1);
/*      */     
/*  303 */     addByteCode((byte)-69, "org/mozilla/javascript/NativeObject");
/*  304 */     addByteCode((byte)89);
/*  305 */     this.classFile.add((byte)-73, 
/*  306 */         "org/mozilla/javascript/NativeObject", 
/*  307 */         "<init>", "()", "V");
/*  308 */     astore(s);
/*      */     
/*  310 */     aload(s);
/*  311 */     aload((short)0);
/*  312 */     addVirtualInvoke("org/mozilla/javascript/NativeFunction", 
/*  313 */         "getClassPrototype", 
/*  314 */         "()", "Lorg/mozilla/javascript/Scriptable;");
/*  315 */     this.classFile.add((byte)-71, 
/*  316 */         "org/mozilla/javascript/Scriptable", 
/*  317 */         "setPrototype", 
/*  318 */         "(Lorg/mozilla/javascript/Scriptable;)", 
/*  319 */         "V");
/*      */ 
/*      */     
/*  322 */     aload(s);
/*  323 */     aload((short)0);
/*  324 */     addVirtualInvoke("org/mozilla/javascript/NativeFunction", 
/*  325 */         "getParentScope", 
/*  326 */         "()", "Lorg/mozilla/javascript/Scriptable;");
/*  327 */     this.classFile.add((byte)-71, 
/*  328 */         "org/mozilla/javascript/Scriptable", 
/*  329 */         "setPrototype", 
/*  330 */         "(Lorg/mozilla/javascript/Scriptable;)", 
/*  331 */         "V");
/*      */ 
/*      */     
/*  334 */     aload((short)0);
/*  335 */     aload((short)1);
/*  336 */     aload((short)2);
/*  337 */     aload(s);
/*  338 */     for (byte b = 0; b < j; b++) {
/*  339 */       aload((short)(4 + b * 3));
/*  340 */       dload((short)(5 + b * 3));
/*      */     } 
/*  342 */     aload((short)(4 + j * 3));
/*  343 */     addVirtualInvoke(this.name, 
/*  344 */         "callDirect", 
/*  345 */         paramOptFunctionNode.getDirectCallParameterSignature(), 
/*  346 */         "Ljava/lang/Object;");
/*  347 */     astore((short)(s + 1));
/*      */     
/*  349 */     int k = acquireLabel();
/*  350 */     aload((short)(s + 1));
/*  351 */     addByteCode((byte)-58, k);
/*  352 */     aload((short)(s + 1));
/*  353 */     pushUndefined();
/*  354 */     addByteCode((byte)-91, k);
/*  355 */     aload((short)(s + 1));
/*  356 */     addByteCode((byte)-63, "org/mozilla/javascript/Scriptable");
/*  357 */     addByteCode((byte)-103, k);
/*  358 */     aload((short)(s + 1));
/*  359 */     addByteCode((byte)-64, "org/mozilla/javascript/Scriptable");
/*  360 */     addByteCode((byte)-80);
/*  361 */     markLabel(k);
/*      */     
/*  363 */     aload(s);
/*  364 */     addByteCode((byte)-80);
/*      */     
/*  366 */     this.classFile.stopMethod((short)(s + 2), null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String generateCode(Node paramNode, Vector paramVector1, Vector paramVector2, ClassNameHelper paramClassNameHelper) {
/*      */     Node node;
/*  373 */     this.itsNameHelper = (OptClassNameHelper)paramClassNameHelper;
/*  374 */     this.namesVector = paramVector1;
/*  375 */     this.classFilesVector = paramVector2;
/*  376 */     Context context = Context.getCurrentContext();
/*  377 */     this.itsSourceFile = null;
/*  378 */     if (context.isGeneratingDebug())
/*  379 */       this.itsSourceFile = (String)paramNode.getProp(16); 
/*  380 */     this.version = context.getLanguageVersion();
/*  381 */     this.optLevel = context.getOptimizationLevel();
/*  382 */     this.inFunction = !(paramNode.getType() != 109);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  388 */     this.superClassName = this.inFunction ? 
/*  389 */       "org.mozilla.javascript.NativeFunction" : 
/*  390 */       "org.mozilla.javascript.NativeScript";
/*      */     
/*  392 */     this.superClassSlashName = this.superClassName.replace('.', '/');
/*      */ 
/*      */     
/*  395 */     if (this.inFunction) {
/*  396 */       OptFunctionNode optFunctionNode = (OptFunctionNode)paramNode;
/*  397 */       this.inDirectCallFunction = optFunctionNode.isTargetOfDirectCall();
/*  398 */       this.vars = (OptVariableTable)optFunctionNode.getVariableTable();
/*  399 */       this.name = optFunctionNode.getClassName();
/*  400 */       this.classFile = new ClassFileWriter(this.name, this.superClassName, this.itsSourceFile);
/*  401 */       Node node1 = paramNode.getFirstChild();
/*  402 */       String str = optFunctionNode.getFunctionName();
/*  403 */       generateInit(context, "<init>", paramNode, str, node1);
/*  404 */       if (optFunctionNode.isTargetOfDirectCall()) {
/*  405 */         this.classFile.startMethod("call", 
/*      */ 
/*      */             
/*  408 */             "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;", (short)
/*      */ 
/*      */             
/*  411 */             17);
/*  412 */         addByteCode((byte)42);
/*  413 */         addByteCode((byte)43);
/*  414 */         addByteCode((byte)44);
/*  415 */         addByteCode((byte)45);
/*  416 */         for (byte b = 0; b < this.vars.getParameterCount(); b++) {
/*  417 */           push(b);
/*  418 */           addByteCode((byte)25, 4);
/*  419 */           addByteCode((byte)-66);
/*  420 */           int i = acquireLabel();
/*  421 */           int j = acquireLabel();
/*  422 */           addByteCode((byte)-94, i);
/*  423 */           addByteCode((byte)25, 4);
/*  424 */           push(b);
/*  425 */           addByteCode((byte)50);
/*  426 */           push(0.0D);
/*  427 */           addByteCode((byte)-89, j);
/*  428 */           markLabel(i);
/*  429 */           pushUndefined();
/*  430 */           push(0.0D);
/*  431 */           markLabel(j);
/*      */         } 
/*  433 */         addByteCode((byte)25, 4);
/*  434 */         addVirtualInvoke(this.name, 
/*  435 */             "callDirect", 
/*  436 */             optFunctionNode.getDirectCallParameterSignature(), 
/*  437 */             "Ljava/lang/Object;");
/*  438 */         addByteCode((byte)-80);
/*  439 */         this.classFile.stopMethod((short)5, null);
/*      */ 
/*      */         
/*  442 */         emitDirectConstructor(optFunctionNode);
/*      */         
/*  444 */         startNewMethod("callDirect", 
/*  445 */             String.valueOf(optFunctionNode.getDirectCallParameterSignature()) + 
/*  446 */             "Ljava/lang/Object;", 
/*  447 */             1, false, true);
/*  448 */         this.vars.assignParameterJRegs();
/*  449 */         if (!optFunctionNode.getParameterNumberContext()) {
/*      */           
/*  451 */           this.itsForcedObjectParameters = true;
/*  452 */           for (byte b1 = 0; b1 < this.vars.getParameterCount(); b1++) {
/*  453 */             OptLocalVariable optLocalVariable = (OptLocalVariable)this.vars.get(b1);
/*  454 */             aload(optLocalVariable.getJRegister());
/*  455 */             this.classFile.add((byte)-78, 
/*  456 */                 "java/lang/Void", 
/*  457 */                 "TYPE", 
/*  458 */                 "Ljava/lang/Class;");
/*  459 */             int i = acquireLabel();
/*  460 */             addByteCode((byte)-90, i);
/*  461 */             addByteCode((byte)-69, "java/lang/Double");
/*  462 */             addByteCode((byte)89);
/*  463 */             dload((short)(optLocalVariable.getJRegister() + 1));
/*  464 */             addDoubleConstructor();
/*  465 */             astore(optLocalVariable.getJRegister());
/*  466 */             markLabel(i);
/*      */           } 
/*      */         } 
/*  469 */         generatePrologue(context, paramNode, true, this.vars.getParameterCount());
/*      */       } else {
/*  471 */         startNewMethod("call", 
/*      */ 
/*      */             
/*  474 */             "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;", 
/*      */             
/*  476 */             1, false, true);
/*  477 */         generatePrologue(context, paramNode, true, -1);
/*      */       } 
/*  479 */       node = paramNode.getLastChild();
/*      */     } else {
/*      */       
/*  482 */       if (paramNode.getType() != 145)
/*  483 */         badTree(); 
/*  484 */       this.vars = (OptVariableTable)paramNode.getProp(10);
/*  485 */       boolean bool = !(this.itsNameHelper.getTargetExtends() != null || 
/*  486 */         this.itsNameHelper.getTargetImplements() != null);
/*  487 */       this.name = this.itsNameHelper.getJavaScriptClassName(null, bool);
/*  488 */       this.classFile = new ClassFileWriter(this.name, this.superClassName, this.itsSourceFile);
/*  489 */       this.classFile.addInterface("org/mozilla/javascript/Script");
/*  490 */       generateScriptCtor(context, paramNode);
/*  491 */       generateMain(context);
/*  492 */       generateInit(context, "initScript", paramNode, "", null);
/*  493 */       generateExecute(context);
/*  494 */       startNewMethod("call", 
/*      */ 
/*      */           
/*  497 */           "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;", 
/*      */           
/*  499 */           1, false, true);
/*  500 */       generatePrologue(context, paramNode, false, -1);
/*  501 */       paramNode.addChildToBack(new Node(5));
/*  502 */       node = paramNode;
/*      */     } 
/*      */     
/*  505 */     generateCodeFromNode(node, null, -1, -1);
/*      */     
/*  507 */     generateEpilogue();
/*      */     
/*  509 */     finishMethod(context, this.debugVars);
/*      */     
/*  511 */     emitConstantDudeInitializers();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  517 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(512);
/*      */     try {
/*  519 */       this.classFile.write(byteArrayOutputStream);
/*      */     }
/*  521 */     catch (IOException iOException) {
/*  522 */       throw new RuntimeException("unexpected IOException");
/*      */     } 
/*  524 */     byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
/*      */     
/*  526 */     this.namesVector.addElement(this.name);
/*  527 */     this.classFilesVector.addElement(arrayOfByte);
/*  528 */     this.classFile = null;
/*      */     
/*  530 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateCodeFromNode(Node paramNode1, Node paramNode2, int paramInt1, int paramInt2) {
/*      */     Object object;
/*      */     Integer integer;
/*  538 */     int i = paramNode1.getType();
/*  539 */     Node node = paramNode1.getFirstChild();
/*  540 */     switch (i) {
/*      */       case 123:
/*      */       case 135:
/*      */       case 137:
/*  544 */         visitStatement(paramNode1);
/*  545 */         while (node != null) {
/*  546 */           generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  547 */           node = node.getNextSibling();
/*      */         } 
/*      */         return;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 115:
/*      */       case 116:
/*      */       case 127:
/*      */       case 131:
/*      */       case 132:
/*      */       case 145:
/*  560 */         visitStatement(paramNode1);
/*  561 */         while (node != null) {
/*  562 */           generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  563 */           node = node.getNextSibling();
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 109:
/*  568 */         if (this.inFunction || paramNode2.getType() != 145) {
/*  569 */           FunctionNode functionNode = (FunctionNode)paramNode1.getProp(5);
/*  570 */           byte b = functionNode.getFunctionType();
/*  571 */           if (b != 1) {
/*  572 */             visitFunction(functionNode, !(b != 3));
/*      */           }
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 44:
/*  578 */         visitName(paramNode1);
/*      */         return;
/*      */       
/*      */       case 30:
/*      */       case 43:
/*  583 */         visitCall(paramNode1, i, node);
/*      */         return;
/*      */       
/*      */       case 45:
/*      */       case 46:
/*  588 */         visitLiteral(paramNode1);
/*      */         return;
/*      */       
/*      */       case 108:
/*  592 */         visitPrimary(paramNode1);
/*      */         return;
/*      */       
/*      */       case 56:
/*  596 */         visitObject(paramNode1);
/*      */         return;
/*      */       
/*      */       case 75:
/*  600 */         visitTryCatchFinally(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 62:
/*  604 */         visitThrow(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 5:
/*  608 */         visitReturn(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 114:
/*  612 */         visitSwitch(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 95:
/*  616 */         generateCodeFromNode(node, paramNode1, -1, -1);
/*  617 */         addByteCode((byte)87);
/*  618 */         generateCodeFromNode(node.getNextSibling(), 
/*  619 */             paramNode1, paramInt1, paramInt2);
/*      */         return;
/*      */       
/*      */       case 77:
/*  623 */         addScriptRuntimeInvoke("newScope", "()", 
/*  624 */             "Lorg/mozilla/javascript/Scriptable;");
/*      */         return;
/*      */       
/*      */       case 3:
/*  628 */         visitEnterWith(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 4:
/*  632 */         visitLeaveWith(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 79:
/*  636 */         visitEnumInit(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 80:
/*  640 */         visitEnumNext(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 138:
/*  644 */         visitEnumDone(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 57:
/*  648 */         visitStatement(paramNode1);
/*  649 */         if (node.getType() == 73) {
/*      */ 
/*      */           
/*  652 */           visitSetVar(node, node.getFirstChild(), false);
/*      */         } else {
/*      */           
/*  655 */           while (node != null) {
/*  656 */             generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  657 */             node = node.getNextSibling();
/*      */           } 
/*  659 */           if (paramNode1.getProp(26) != null) {
/*  660 */             addByteCode((byte)88);
/*      */           } else {
/*  662 */             addByteCode((byte)87);
/*      */           } 
/*      */         } 
/*      */         return;
/*      */       case 2:
/*  667 */         visitStatement(paramNode1);
/*  668 */         while (node != null) {
/*  669 */           generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  670 */           node = node.getNextSibling();
/*      */         } 
/*  672 */         astore(this.scriptResultLocal);
/*      */         return;
/*      */       
/*      */       case 136:
/*  676 */         visitTarget(paramNode1);
/*      */         return;
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 142:
/*  683 */         visitGOTO(paramNode1, i, node);
/*      */         return;
/*      */       
/*      */       case 104:
/*  687 */         visitUnary(paramNode1, node, paramInt1, paramInt2);
/*      */         return;
/*      */       
/*      */       case 32:
/*  691 */         visitTypeof(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 105:
/*  695 */         visitIncDec(paramNode1, true);
/*      */         return;
/*      */       
/*      */       case 106:
/*  699 */         visitIncDec(paramNode1, false);
/*      */         return;
/*      */       
/*      */       case 99:
/*      */       case 100:
/*  704 */         if (paramInt1 == -1) {
/*  705 */           generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  706 */           addByteCode((byte)89);
/*  707 */           addScriptRuntimeInvoke("toBoolean", "(Ljava/lang/Object;)", "Z");
/*  708 */           int j = acquireLabel();
/*  709 */           if (i == 100) {
/*  710 */             addByteCode((byte)-103, j);
/*      */           } else {
/*  712 */             addByteCode((byte)-102, j);
/*  713 */           }  addByteCode((byte)87);
/*  714 */           generateCodeFromNode(node.getNextSibling(), paramNode1, paramInt1, paramInt2);
/*  715 */           markLabel(j);
/*      */         } else {
/*      */           
/*  718 */           int j = acquireLabel();
/*  719 */           if (i == 100) {
/*  720 */             generateCodeFromNode(node, paramNode1, j, paramInt2);
/*  721 */             if ((node.getType() != 104 || node.getInt() != 128) && 
/*  722 */               node.getType() != 100 && 
/*  723 */               node.getType() != 99 && 
/*  724 */               node.getType() != 102 && 
/*  725 */               node.getType() != 101) {
/*      */ 
/*      */               
/*  728 */               addScriptRuntimeInvoke("toBoolean", 
/*  729 */                   "(Ljava/lang/Object;)", "Z");
/*  730 */               addByteCode((byte)-102, j);
/*  731 */               addByteCode((byte)-89, paramInt2);
/*      */             } 
/*      */           } else {
/*      */             
/*  735 */             generateCodeFromNode(node, paramNode1, paramInt1, j);
/*  736 */             if ((node.getType() != 104 || node.getInt() != 128) && 
/*  737 */               node.getType() != 100 && 
/*  738 */               node.getType() != 99 && 
/*  739 */               node.getType() != 102 && 
/*  740 */               node.getType() != 101) {
/*      */ 
/*      */               
/*  743 */               addScriptRuntimeInvoke("toBoolean", 
/*  744 */                   "(Ljava/lang/Object;)", "Z");
/*  745 */               addByteCode((byte)-102, paramInt1);
/*  746 */               addByteCode((byte)-89, j);
/*      */             } 
/*      */           } 
/*  749 */           markLabel(j);
/*  750 */           node = node.getNextSibling();
/*  751 */           generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  752 */           if ((node.getType() != 104 || node.getInt() != 128) && 
/*  753 */             node.getType() != 100 && 
/*  754 */             node.getType() != 99 && 
/*  755 */             node.getType() != 102 && 
/*  756 */             node.getType() != 101) {
/*      */ 
/*      */             
/*  759 */             addScriptRuntimeInvoke("toBoolean", 
/*  760 */                 "(Ljava/lang/Object;)", "Z");
/*  761 */             addByteCode((byte)-102, paramInt1);
/*  762 */             addByteCode((byte)-89, paramInt2);
/*      */           } 
/*      */         } 
/*      */         return;
/*      */ 
/*      */       
/*      */       case 23:
/*  769 */         generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  770 */         generateCodeFromNode(node.getNextSibling(), 
/*  771 */             paramNode1, paramInt1, paramInt2);
/*  772 */         integer = 
/*  773 */           (Integer)paramNode1.getProp(26);
/*  774 */         if (integer != null) {
/*  775 */           if (integer.intValue() == 0) {
/*  776 */             addByteCode((byte)99);
/*      */           
/*      */           }
/*  779 */           else if (integer.intValue() == 1) {
/*  780 */             addOptRuntimeInvoke("add", 
/*  781 */                 "(DLjava/lang/Object;)", 
/*  782 */                 "Ljava/lang/Object;");
/*      */           } else {
/*      */             
/*  785 */             addOptRuntimeInvoke("add", 
/*  786 */                 "(Ljava/lang/Object;D)", 
/*  787 */                 "Ljava/lang/Object;");
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  792 */           addScriptRuntimeInvoke("add", 
/*  793 */               "(Ljava/lang/Object;Ljava/lang/Object;)", 
/*  794 */               "Ljava/lang/Object;");
/*      */         } 
/*      */         return;
/*      */ 
/*      */       
/*      */       case 25:
/*  800 */         visitArithmetic(paramNode1, (byte)107, node, paramNode2);
/*      */         return;
/*      */       
/*      */       case 24:
/*  804 */         visitArithmetic(paramNode1, (byte)103, node, paramNode2);
/*      */         return;
/*      */       
/*      */       case 26:
/*      */       case 27:
/*  809 */         visitArithmetic(paramNode1, (i == 26) ? 
/*  810 */             111 : 
/*  811 */             115, node, paramNode2);
/*      */         return;
/*      */       
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 20:
/*      */       case 21:
/*      */       case 22:
/*  820 */         visitBitOp(paramNode1, i, node);
/*      */         return;
/*      */       
/*      */       case 141:
/*  824 */         object = paramNode1.getProp(18);
/*  825 */         if (object == ScriptRuntime.NumberClass) {
/*  826 */           addByteCode((byte)-69, "java/lang/Double");
/*  827 */           addByteCode((byte)89);
/*  828 */           generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  829 */           addScriptRuntimeInvoke("toNumber", 
/*  830 */               "(Ljava/lang/Object;)", "D");
/*  831 */           addDoubleConstructor();
/*      */         
/*      */         }
/*  834 */         else if (object == ScriptRuntime.DoubleClass) {
/*      */ 
/*      */           
/*  837 */           generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  838 */           addScriptRuntimeInvoke("toNumber", 
/*  839 */               "(Ljava/lang/Object;)", "D");
/*      */         
/*      */         }
/*  842 */         else if (object == ScriptRuntime.ObjectClass) {
/*  843 */           if (node.getType() == 45 && 
/*  844 */             node.getProp(26) != null) {
/*      */             
/*  846 */             Object object1 = 
/*  847 */               node.getProp(26);
/*  848 */             node.putProp(26, null);
/*  849 */             generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  850 */             node.putProp(26, object1);
/*      */           } else {
/*      */             
/*  853 */             addByteCode((byte)-69, "java/lang/Double");
/*  854 */             addByteCode((byte)89);
/*  855 */             generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  856 */             addDoubleConstructor();
/*      */           } 
/*      */         } else {
/*      */           
/*  860 */           badTree();
/*      */         } 
/*      */         return;
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  867 */         if (paramInt1 == -1) {
/*  868 */           visitRelOp(paramNode1, node, paramNode2);
/*      */         } else {
/*  870 */           visitGOTOingRelOp(paramNode1, node, paramNode2, paramInt1, paramInt2);
/*      */         } 
/*      */         return;
/*      */       case 101:
/*  874 */         visitEqOp(paramNode1, node, paramNode2, paramInt1, paramInt2);
/*      */         return;
/*      */       
/*      */       case 39:
/*  878 */         visitGetProp(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 41:
/*  882 */         while (node != null) {
/*  883 */           generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  884 */           node = node.getNextSibling();
/*      */         } 
/*  886 */         aload(this.variableObjectLocal);
/*  887 */         if (paramNode1.getProp(26) != null) {
/*  888 */           addOptRuntimeInvoke("getElem", 
/*  889 */               "(Ljava/lang/Object;DLorg/mozilla/javascript/Scriptable;)", 
/*      */               
/*  891 */               "Ljava/lang/Object;");
/*      */         } else {
/*      */           
/*  894 */           addScriptRuntimeInvoke("getElem", 
/*  895 */               "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
/*      */               
/*  897 */               "Ljava/lang/Object;");
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 72:
/*  902 */         object = 
/*  903 */           (OptLocalVariable)paramNode1.getProp(24);
/*  904 */         visitGetVar(object, 
/*  905 */             !(paramNode1.getProp(26) == null), 
/*  906 */             paramNode1.getString());
/*      */         return;
/*      */ 
/*      */       
/*      */       case 73:
/*  911 */         visitSetVar(paramNode1, node, true);
/*      */         return;
/*      */       
/*      */       case 10:
/*  915 */         visitSetName(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 40:
/*  919 */         visitSetProp(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 42:
/*  923 */         while (node != null) {
/*  924 */           generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  925 */           node = node.getNextSibling();
/*      */         } 
/*  927 */         aload(this.variableObjectLocal);
/*  928 */         if (paramNode1.getProp(26) != null) {
/*  929 */           addOptRuntimeInvoke("setElem", 
/*  930 */               "(Ljava/lang/Object;DLjava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
/*      */               
/*  932 */               "Ljava/lang/Object;");
/*      */         } else {
/*      */           
/*  935 */           addScriptRuntimeInvoke("setElem", 
/*  936 */               "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
/*      */               
/*  938 */               "Ljava/lang/Object;");
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 31:
/*  943 */         while (node != null) {
/*  944 */           generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  945 */           node = node.getNextSibling();
/*      */         } 
/*  947 */         addScriptRuntimeInvoke("delete", 
/*  948 */             "(Ljava/lang/Object;Ljava/lang/Object;)", 
/*  949 */             "Ljava/lang/Object;");
/*      */         return;
/*      */       
/*      */       case 61:
/*      */       case 71:
/*  954 */         visitBind(paramNode1, i, node);
/*      */         return;
/*      */       
/*      */       case 68:
/*  958 */         generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  959 */         addScriptRuntimeInvoke("getThis", 
/*  960 */             "(Lorg/mozilla/javascript/Scriptable;)", 
/*  961 */             "Lorg/mozilla/javascript/Scriptable;");
/*      */         return;
/*      */       
/*      */       case 140:
/*  965 */         generateCodeFromNode(node, paramNode1, paramInt1, paramInt2);
/*  966 */         addScriptRuntimeInvoke("getParent", 
/*  967 */             "(Ljava/lang/Object;)", 
/*  968 */             "Lorg/mozilla/javascript/Scriptable;");
/*      */         return;
/*      */       
/*      */       case 69:
/*  972 */         visitNewTemp(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 70:
/*  976 */         visitUseTemp(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 143:
/*  980 */         visitNewLocal(paramNode1, node);
/*      */         return;
/*      */       
/*      */       case 144:
/*  984 */         visitUseLocal(paramNode1, node);
/*      */         return;
/*      */     } 
/*      */     
/*  988 */     throw new RuntimeException("Unexpected node type " + 
/*  989 */         TokenStream.tokenToName(i));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void startNewMethod(String paramString1, String paramString2, int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
/*  998 */     this.locals = new boolean[256];
/*  999 */     this.localsMax = (short)(paramInt + 1);
/* 1000 */     this.firstFreeLocal = 0;
/* 1001 */     this.contextLocal = -1;
/* 1002 */     this.variableObjectLocal = -1;
/* 1003 */     this.scriptResultLocal = -1;
/* 1004 */     this.argsLocal = -1;
/* 1005 */     this.thisObjLocal = -1;
/* 1006 */     this.funObjLocal = -1;
/* 1007 */     this.debug_pcLocal = -1;
/* 1008 */     this.debugStopSubRetLocal = -1;
/* 1009 */     this.itsZeroArgArray = -1;
/* 1010 */     this.itsOneArgArray = -1;
/* 1011 */     short s = 1;
/* 1012 */     if (paramBoolean1)
/* 1013 */       s = (short)(s | 0x8); 
/* 1014 */     if (paramBoolean2)
/* 1015 */       s = (short)(s | 0x10); 
/* 1016 */     this.epilogueLabel = -1;
/* 1017 */     this.classFile.startMethod(paramString1, paramString2, s);
/*      */   }
/*      */   
/*      */   private void finishMethod(Context paramContext, VariableTable paramVariableTable) {
/* 1021 */     this.classFile.stopMethod((short)(this.localsMax + 1), paramVariableTable);
/* 1022 */     this.contextLocal = -1;
/*      */   }
/*      */   
/*      */   private void generateMain(Context paramContext) {
/* 1026 */     startNewMethod("main", "([Ljava/lang/String;)V", 1, true, true);
/*      */     
/* 1028 */     push(this.name);
/* 1029 */     addByteCode((byte)42);
/* 1030 */     addScriptRuntimeInvoke("main", 
/* 1031 */         "(Ljava/lang/String;[Ljava/lang/String;)", 
/* 1032 */         "V");
/* 1033 */     addByteCode((byte)-79);
/* 1034 */     finishMethod(paramContext, null);
/*      */   }
/*      */ 
/*      */   
/*      */   private void generateExecute(Context paramContext) {
/* 1039 */     String str1 = 
/* 1040 */       "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
/*      */     
/* 1042 */     startNewMethod("exec", str1, 2, false, true);
/* 1043 */     String str2 = this.name.replace('.', '/');
/*      */     
/* 1045 */     if (!this.trivialInit) {
/*      */       
/* 1047 */       addByteCode((byte)42);
/* 1048 */       addByteCode((byte)44);
/* 1049 */       addByteCode((byte)43);
/* 1050 */       addVirtualInvoke(str2, 
/* 1051 */           "initScript", 
/* 1052 */           "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;)", 
/*      */           
/* 1054 */           "V");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1069 */     addByteCode((byte)42);
/* 1070 */     addByteCode((byte)43);
/* 1071 */     addByteCode((byte)44);
/* 1072 */     addByteCode((byte)89);
/* 1073 */     addByteCode((byte)1);
/* 1074 */     addVirtualInvoke(str2, 
/* 1075 */         "call", 
/*      */ 
/*      */         
/* 1078 */         "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)", 
/*      */         
/* 1080 */         "Ljava/lang/Object;");
/*      */ 
/*      */     
/* 1083 */     addByteCode((byte)-80);
/* 1084 */     finishMethod(paramContext, null);
/*      */   }
/*      */   
/*      */   private void generateScriptCtor(Context paramContext, Node paramNode) {
/* 1088 */     startNewMethod("<init>", "()V", 1, false, false);
/* 1089 */     addByteCode((byte)42);
/* 1090 */     addSpecialInvoke(this.superClassSlashName, 
/* 1091 */         "<init>", "()", "V");
/* 1092 */     addByteCode((byte)-79);
/* 1093 */     finishMethod(paramContext, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setNonTrivialInit(String paramString) {
/* 1105 */     if (!this.trivialInit)
/*      */       return; 
/* 1107 */     this.trivialInit = false;
/* 1108 */     startNewMethod(paramString, 
/* 1109 */         "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;)V", 
/* 1110 */         1, false, false);
/* 1111 */     reserveWordLocal(0);
/* 1112 */     this.variableObjectLocal = reserveWordLocal(1);
/* 1113 */     this.contextLocal = reserveWordLocal(2);
/*      */   }
/*      */ 
/*      */   
/*      */   private void generateInit(Context paramContext, String paramString1, Node paramNode1, String paramString2, Node paramNode2) {
/*      */     VariableTable variableTable;
/* 1119 */     this.trivialInit = true;
/* 1120 */     boolean bool = false;
/*      */     
/* 1122 */     if (paramNode1 instanceof OptFunctionNode) {
/* 1123 */       variableTable = ((OptFunctionNode)paramNode1).getVariableTable();
/*      */     } else {
/* 1125 */       variableTable = (VariableTable)paramNode1.getProp(10);
/*      */     } 
/* 1127 */     if (paramString1.equals("<init>")) {
/* 1128 */       bool = true;
/* 1129 */       setNonTrivialInit(paramString1);
/* 1130 */       addByteCode((byte)42);
/* 1131 */       addSpecialInvoke(this.superClassSlashName, "<init>", "()", "V");
/*      */       
/* 1133 */       addByteCode((byte)42);
/* 1134 */       addByteCode((byte)43);
/* 1135 */       this.classFile.add((byte)-75, 
/* 1136 */           "org/mozilla/javascript/ScriptableObject", 
/* 1137 */           "parent", "Lorg/mozilla/javascript/Scriptable;");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1147 */     if (paramString2.length() != 0 || (variableTable != null && variableTable.size() > 0)) {
/* 1148 */       setNonTrivialInit(paramString1);
/* 1149 */       if (variableTable == null)
/* 1150 */         variableTable = new OptVariableTable(); 
/* 1151 */       push((variableTable.size() + 1));
/* 1152 */       addByteCode((byte)-67, "java/lang/String");
/* 1153 */       addByteCode((byte)89);
/* 1154 */       short s = getNewWordLocal();
/* 1155 */       astore(s);
/* 1156 */       addByteCode((byte)89);
/* 1157 */       push(0L);
/* 1158 */       this.classFile.addLoadConstant(paramString2);
/* 1159 */       addByteCode((byte)83);
/* 1160 */       if (variableTable != null) {
/* 1161 */         for (byte b = 0; b < variableTable.size(); b++) {
/* 1162 */           aload(s);
/* 1163 */           push((b + true));
/* 1164 */           push(variableTable.getName(b));
/* 1165 */           addByteCode((byte)83);
/*      */         } 
/*      */       }
/* 1168 */       releaseWordLocal(s);
/* 1169 */       addByteCode((byte)42);
/* 1170 */       addByteCode((byte)95);
/* 1171 */       this.classFile.add((byte)-75, 
/* 1172 */           "org/mozilla/javascript/NativeFunction", 
/* 1173 */           "names", "[Ljava/lang/String;");
/*      */     } 
/*      */     
/* 1176 */     boolean bool1 = (variableTable == null) ? 0 : variableTable.getParameterCount();
/* 1177 */     if (bool1) {
/* 1178 */       setNonTrivialInit(paramString1);
/* 1179 */       addByteCode((byte)42);
/* 1180 */       push(bool1);
/* 1181 */       this.classFile.add((byte)-75, 
/* 1182 */           "org/mozilla/javascript/NativeFunction", 
/* 1183 */           "argCount", "S");
/*      */     } 
/*      */ 
/*      */     
/* 1187 */     if (paramContext.getLanguageVersion() != 0) {
/* 1188 */       setNonTrivialInit(paramString1);
/* 1189 */       addByteCode((byte)42);
/* 1190 */       push(paramContext.getLanguageVersion());
/* 1191 */       this.classFile.add((byte)-75, 
/* 1192 */           "org/mozilla/javascript/NativeFunction", 
/* 1193 */           "version", "S");
/*      */     } 
/*      */ 
/*      */     
/* 1197 */     String str = (String)paramNode1.getProp(17);
/* 1198 */     if (str != null && 
/* 1199 */       paramContext.isGeneratingSource() && 
/* 1200 */       str.length() < 65536) {
/* 1201 */       setNonTrivialInit(paramString1);
/* 1202 */       addByteCode((byte)42);
/* 1203 */       push(str);
/* 1204 */       this.classFile.add((byte)-75, 
/* 1205 */           "org/mozilla/javascript/NativeFunction", 
/* 1206 */           "source", "Ljava/lang/String;");
/*      */     } 
/*      */ 
/*      */     
/* 1210 */     Vector vector1 = (Vector)paramNode1.getProp(12);
/* 1211 */     if (vector1 != null) {
/* 1212 */       setNonTrivialInit(paramString1);
/* 1213 */       generateRegExpLiterals(vector1, bool);
/*      */     } 
/*      */     
/* 1216 */     Vector vector2 = (Vector)paramNode1.getProp(5);
/* 1217 */     if (vector2 != null) {
/* 1218 */       setNonTrivialInit(paramString1);
/* 1219 */       generateFunctionInits(vector2);
/*      */     } 
/*      */     
/* 1222 */     if (paramNode1 instanceof OptFunctionNode) {
/*      */       
/* 1224 */       OptFunctionNode optFunctionNode = (OptFunctionNode)paramNode1;
/* 1225 */       Vector vector = (
/* 1226 */         (OptFunctionNode)paramNode1).getDirectCallTargets();
/* 1227 */       if (vector != null) {
/* 1228 */         setNonTrivialInit(paramString1);
/* 1229 */         this.classFile.addField("EmptyArray", 
/* 1230 */             "[Ljava/lang/Object;", (short)
/* 1231 */             2);
/* 1232 */         addByteCode((byte)42);
/* 1233 */         push(0L);
/* 1234 */         addByteCode((byte)-67, "java/lang/Object");
/* 1235 */         this.classFile.add((byte)-75, 
/* 1236 */             ClassFileWriter.fullyQualifiedForm(this.name), 
/* 1237 */             "EmptyArray", 
/* 1238 */             "[Ljava/lang/Object;");
/*      */       } 
/* 1240 */       if (optFunctionNode.isTargetOfDirectCall()) {
/* 1241 */         setNonTrivialInit(paramString1);
/* 1242 */         String str1 = 
/* 1243 */           ClassFileWriter.fullyQualifiedForm(optFunctionNode.getClassName());
/* 1244 */         String str2 = str1.replace('/', '_');
/* 1245 */         this.classFile.addField(str2, 
/* 1246 */             "L" + str1 + ";", (short)
/*      */             
/* 1248 */             9);
/* 1249 */         addByteCode((byte)42);
/* 1250 */         this.classFile.add((byte)-77, 
/* 1251 */             str1, 
/* 1252 */             str2, 
/* 1253 */             "L" + str1 + ";");
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1275 */     if (!this.trivialInit) {
/* 1276 */       addByteCode((byte)-79);
/* 1277 */       finishMethod(paramContext, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateDebugInit(Context paramContext, Node paramNode) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateRegExpLiterals(Vector paramVector, boolean paramBoolean) {
/* 1345 */     for (byte b = 0; b < paramVector.size(); b++) {
/* 1346 */       Node node1 = (Node)paramVector.elementAt(b);
/* 1347 */       StringBuffer stringBuffer = new StringBuffer("_re");
/* 1348 */       stringBuffer.append(b);
/* 1349 */       String str = stringBuffer.toString();
/* 1350 */       short s = 2;
/* 1351 */       if (paramBoolean)
/* 1352 */         s = (short)(s | 0x10); 
/* 1353 */       this.classFile.addField(str, 
/* 1354 */           "Lorg/mozilla/javascript/regexp/NativeRegExp;", 
/* 1355 */           s);
/* 1356 */       addByteCode((byte)42);
/*      */       
/* 1358 */       addByteCode((byte)-69, "org/mozilla/javascript/regexp/NativeRegExp");
/* 1359 */       addByteCode((byte)89);
/*      */       
/* 1361 */       aload(this.contextLocal);
/* 1362 */       aload(this.variableObjectLocal);
/* 1363 */       Node node2 = node1.getFirstChild();
/* 1364 */       push(node2.getString());
/* 1365 */       Node node3 = node1.getLastChild();
/* 1366 */       if (node2 == node3) {
/* 1367 */         addByteCode((byte)1);
/*      */       } else {
/* 1369 */         push(node3.getString());
/*      */       } 
/* 1371 */       push(0L);
/*      */       
/* 1373 */       addSpecialInvoke("org/mozilla/javascript/regexp/NativeRegExp", 
/* 1374 */           "<init>", 
/*      */           
/* 1376 */           "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Ljava/lang/String;Z)", 
/*      */           
/* 1378 */           "V");
/*      */       
/* 1380 */       node1.putProp(12, str);
/* 1381 */       this.classFile.add((byte)-75, 
/* 1382 */           ClassFileWriter.fullyQualifiedForm(this.name), 
/* 1383 */           str, "Lorg/mozilla/javascript/regexp/NativeRegExp;");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateFunctionInits(Vector paramVector) {
/* 1390 */     push(paramVector.size());
/* 1391 */     addByteCode((byte)-67, "org/mozilla/javascript/NativeFunction");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1400 */     for (short s = 0; s < paramVector.size(); s = (short)(s + 1)) {
/* 1401 */       addByteCode((byte)89);
/* 1402 */       push(s);
/*      */       
/* 1404 */       Node node = (Node)paramVector.elementAt(s);
/* 1405 */       Codegen codegen = new Codegen();
/* 1406 */       String str1 = codegen.generateCode(node, this.namesVector, 
/* 1407 */           this.classFilesVector, 
/* 1408 */           this.itsNameHelper);
/*      */       
/* 1410 */       addByteCode((byte)-69, str1);
/* 1411 */       addByteCode((byte)89);
/* 1412 */       if (this.inFunction) {
/* 1413 */         addByteCode((byte)42);
/*      */       } else {
/* 1415 */         aload(this.variableObjectLocal);
/*      */       } 
/* 1417 */       aload(this.contextLocal);
/* 1418 */       addSpecialInvoke(str1, "<init>", 
/* 1419 */           "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;)", 
/*      */           
/* 1421 */           "V");
/*      */ 
/*      */ 
/*      */       
/* 1425 */       if (this.inFunction) {
/* 1426 */         addByteCode((byte)42);
/*      */       } else {
/* 1428 */         aload(this.variableObjectLocal);
/*      */       } 
/*      */       
/* 1431 */       String str2 = node.getString();
/* 1432 */       if (str2 != null) {
/* 1433 */         push(str2);
/*      */       } else {
/* 1435 */         addByteCode((byte)1);
/*      */       } 
/*      */       
/* 1438 */       aload(this.contextLocal);
/* 1439 */       addScriptRuntimeInvoke("initFunction", 
/*      */ 
/*      */           
/* 1442 */           "(Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Lorg/mozilla/javascript/Context;)", 
/*      */           
/* 1444 */           "Lorg/mozilla/javascript/NativeFunction;");
/* 1445 */       node.putProp(5, new Short(s));
/* 1446 */       addByteCode((byte)83);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1453 */     addByteCode((byte)42);
/* 1454 */     addByteCode((byte)95);
/*      */     
/* 1456 */     this.classFile.add((byte)-75, "org/mozilla/javascript/NativeFunction", 
/* 1457 */         "nestedFunctions", "[Lorg/mozilla/javascript/NativeFunction;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generatePrologue(Context paramContext, Node paramNode, boolean paramBoolean, int paramInt) {
/*      */     String str;
/* 1474 */     this.funObjLocal = reserveWordLocal(0);
/* 1475 */     this.contextLocal = reserveWordLocal(1);
/* 1476 */     this.variableObjectLocal = reserveWordLocal(2);
/* 1477 */     this.thisObjLocal = reserveWordLocal(3);
/*      */     
/* 1479 */     if (paramBoolean && !paramContext.hasCompileFunctionsWithDynamicScope() && 
/* 1480 */       paramInt == -1) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1485 */       aload(this.funObjLocal);
/* 1486 */       this.classFile.add((byte)-71, 
/* 1487 */           "org/mozilla/javascript/Scriptable", 
/* 1488 */           "getParentScope", 
/* 1489 */           "()", 
/* 1490 */           "Lorg/mozilla/javascript/Scriptable;");
/* 1491 */       astore(this.variableObjectLocal);
/*      */     } 
/*      */     
/* 1494 */     if (paramInt > 0) {
/* 1495 */       for (byte b = 0; b < 3 * paramInt; b++) {
/* 1496 */         reserveWordLocal(b + 4);
/*      */       }
/*      */     }
/* 1499 */     this.argsLocal = reserveWordLocal((paramInt <= 0) ? 
/* 1500 */         4 : (3 * paramInt + 4));
/*      */ 
/*      */ 
/*      */     
/* 1504 */     Integer integer = (Integer)paramNode.getProp(22);
/* 1505 */     if (integer != null) {
/* 1506 */       this.itsLocalAllocationBase = (short)(this.argsLocal + 1);
/* 1507 */       for (short s = 0; s < integer.intValue(); s++) {
/* 1508 */         reserveWordLocal(this.itsLocalAllocationBase + s);
/*      */       }
/*      */     } 
/*      */     
/* 1512 */     this.hasVarsInRegs = !(!paramBoolean || (
/* 1513 */       (OptFunctionNode)paramNode).requiresActivation());
/* 1514 */     if (this.hasVarsInRegs) {
/*      */       
/* 1516 */       int i = this.vars.getParameterCount();
/* 1517 */       if (paramBoolean && i > 0 && paramInt < 0) {
/*      */ 
/*      */         
/* 1520 */         aload(this.argsLocal);
/* 1521 */         addByteCode((byte)-66);
/* 1522 */         push(i);
/* 1523 */         int j = acquireLabel();
/* 1524 */         addByteCode((byte)-94, j);
/* 1525 */         aload(this.argsLocal);
/* 1526 */         push(i);
/* 1527 */         addScriptRuntimeInvoke("padArguments", 
/* 1528 */             "([Ljava/lang/Object;I)", 
/* 1529 */             "[Ljava/lang/Object;");
/* 1530 */         astore(this.argsLocal);
/* 1531 */         markLabel(j);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1536 */       short s = -1;
/* 1537 */       for (byte b = 0; b < this.vars.size(); b++) {
/* 1538 */         OptLocalVariable optLocalVariable = (OptLocalVariable)this.vars.get(b);
/* 1539 */         if (optLocalVariable.isNumber()) {
/* 1540 */           optLocalVariable.assignJRegister(getNewWordPairLocal());
/* 1541 */           push(0.0D);
/* 1542 */           dstore(optLocalVariable.getJRegister());
/* 1543 */         } else if (optLocalVariable.isParameter()) {
/* 1544 */           if (paramInt < 0) {
/* 1545 */             optLocalVariable.assignJRegister(getNewWordLocal());
/* 1546 */             aload(this.argsLocal);
/* 1547 */             push(b);
/* 1548 */             addByteCode((byte)50);
/* 1549 */             astore(optLocalVariable.getJRegister());
/*      */           } 
/*      */         } else {
/* 1552 */           optLocalVariable.assignJRegister(getNewWordLocal());
/* 1553 */           if (s == -1) {
/* 1554 */             pushUndefined();
/* 1555 */             s = optLocalVariable.getJRegister();
/*      */           } else {
/* 1557 */             aload(s);
/*      */           } 
/* 1559 */           astore(optLocalVariable.getJRegister());
/*      */         } 
/* 1561 */         optLocalVariable.setStartPC(this.classFile.getCurrentCodeOffset());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1567 */       this.debugVars = this.vars;
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1573 */     if (paramInt > 0) {
/*      */ 
/*      */ 
/*      */       
/* 1577 */       aload(this.argsLocal);
/* 1578 */       push(paramInt);
/* 1579 */       addOptRuntimeInvoke("padStart", 
/* 1580 */           "([Ljava/lang/Object;I)", 
/* 1581 */           "[Ljava/lang/Object;");
/* 1582 */       astore(this.argsLocal);
/* 1583 */       for (byte b = 0; b < paramInt; b++) {
/* 1584 */         aload(this.argsLocal);
/* 1585 */         push(b);
/*      */ 
/*      */         
/* 1588 */         aload((short)(3 * b + 4));
/* 1589 */         addByteCode((byte)83);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1594 */     if (paramBoolean) {
/* 1595 */       aload(this.contextLocal);
/* 1596 */       aload(this.variableObjectLocal);
/* 1597 */       aload(this.funObjLocal);
/* 1598 */       aload(this.thisObjLocal);
/* 1599 */       aload(this.argsLocal);
/* 1600 */       addScriptRuntimeInvoke("initVarObj", 
/*      */ 
/*      */ 
/*      */           
/* 1604 */           "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)", 
/*      */           
/* 1606 */           "Lorg/mozilla/javascript/Scriptable;");
/* 1607 */       str = "activation";
/*      */     } else {
/* 1609 */       aload(this.contextLocal);
/* 1610 */       aload(this.variableObjectLocal);
/* 1611 */       aload(this.funObjLocal);
/* 1612 */       aload(this.thisObjLocal);
/* 1613 */       push(0L);
/* 1614 */       addScriptRuntimeInvoke("initScript", 
/*      */ 
/*      */           
/* 1617 */           "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;Z)", 
/*      */           
/* 1619 */           "Lorg/mozilla/javascript/Scriptable;");
/* 1620 */       str = "global";
/*      */     } 
/* 1622 */     astore(this.variableObjectLocal);
/*      */     
/* 1624 */     Vector vector = (Vector)paramNode.getProp(5);
/* 1625 */     if (paramBoolean && vector != null) {
/* 1626 */       for (byte b = 0; b < vector.size(); b++) {
/* 1627 */         FunctionNode functionNode = (FunctionNode)vector.elementAt(b);
/* 1628 */         if (functionNode.getFunctionType() == 1) {
/* 1629 */           visitFunction(functionNode, true);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1635 */     if (paramContext.isGeneratingDebug()) {
/* 1636 */       this.debugVars = new OptVariableTable();
/* 1637 */       this.debugVars.addLocal(str);
/* 1638 */       OptLocalVariable optLocalVariable = (OptLocalVariable)this.debugVars.get(str);
/* 1639 */       optLocalVariable.assignJRegister(this.variableObjectLocal);
/* 1640 */       optLocalVariable.setStartPC(this.classFile.getCurrentCodeOffset());
/*      */     } 
/*      */     
/* 1643 */     if (!paramBoolean) {
/*      */       
/* 1645 */       this.scriptResultLocal = getNewWordLocal();
/* 1646 */       pushUndefined();
/* 1647 */       astore(this.scriptResultLocal);
/*      */     } 
/*      */     
/* 1650 */     if (paramBoolean && ((OptFunctionNode)paramNode).containsCalls(-1)) {
/* 1651 */       if (((OptFunctionNode)paramNode).containsCalls(0)) {
/* 1652 */         this.itsZeroArgArray = getNewWordLocal();
/* 1653 */         this.classFile.add((byte)-78, 
/* 1654 */             "org/mozilla/javascript/ScriptRuntime", 
/* 1655 */             "emptyArgs", "[Ljava/lang/Object;");
/* 1656 */         astore(this.itsZeroArgArray);
/*      */       } 
/* 1658 */       if (((OptFunctionNode)paramNode).containsCalls(1)) {
/* 1659 */         this.itsOneArgArray = getNewWordLocal();
/* 1660 */         push(1L);
/* 1661 */         addByteCode((byte)-67, "java/lang/Object");
/* 1662 */         astore(this.itsOneArgArray);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateEpilogue() {
/* 1679 */     if (this.epilogueLabel != -1) {
/* 1680 */       this.classFile.markLabel(this.epilogueLabel);
/*      */     }
/* 1682 */     if (!this.hasVarsInRegs || !this.inFunction) {
/*      */       
/* 1684 */       aload(this.contextLocal);
/* 1685 */       addScriptRuntimeInvoke("popActivation", 
/* 1686 */           "(Lorg/mozilla/javascript/Context;)", 
/* 1687 */           "V");
/*      */     } 
/* 1689 */     addByteCode((byte)-80);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateDebugStopSubroutine() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1871 */   private short addDebugPCEntry(short paramShort) { return -1; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeDebugPCEntries() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void buildDebugTrapMap() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitFunction(Node paramNode, boolean paramBoolean) {
/* 1924 */     aload(this.variableObjectLocal);
/* 1925 */     Short short = (Short)paramNode.getProp(5);
/* 1926 */     aload(this.funObjLocal);
/* 1927 */     this.classFile.add((byte)-76, "org/mozilla/javascript/NativeFunction", 
/* 1928 */         "nestedFunctions", "[Lorg/mozilla/javascript/NativeFunction;");
/* 1929 */     push(short.shortValue());
/* 1930 */     addByteCode((byte)50);
/* 1931 */     addVirtualInvoke("java/lang/Object", "getClass", "()", "Ljava/lang/Class;");
/* 1932 */     aload(this.contextLocal);
/* 1933 */     addByteCode((byte)16, paramBoolean ? 1 : 0);
/*      */     
/* 1935 */     addScriptRuntimeInvoke("createFunctionObject", 
/*      */         
/* 1937 */         "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Class;Lorg/mozilla/javascript/Context;Z)", 
/*      */         
/* 1939 */         "Lorg/mozilla/javascript/NativeFunction;");
/*      */   }
/*      */ 
/*      */   
/*      */   private void visitTarget(Node paramNode) {
/* 1944 */     Object object = paramNode.getProp(20);
/* 1945 */     if (object == null) {
/* 1946 */       int i = markLabel(acquireLabel());
/* 1947 */       paramNode.putProp(20, new Integer(i));
/*      */     } else {
/*      */       
/* 1950 */       int i = ((Integer)object).intValue();
/* 1951 */       markLabel(i);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void visitGOTO(Node paramNode1, int paramInt, Node paramNode2) {
/*      */     int i;
/* 1957 */     Node node = (Node)paramNode1.getProp(1);
/* 1958 */     Object object = node.getProp(20);
/*      */     
/* 1960 */     if (object == null) {
/* 1961 */       i = acquireLabel();
/* 1962 */       node.putProp(20, new Integer(i));
/*      */     } else {
/*      */       
/* 1965 */       i = ((Integer)object).intValue();
/* 1966 */     }  int j = acquireLabel();
/*      */     
/* 1968 */     if (paramInt == 7 || paramInt == 8) {
/* 1969 */       if (paramNode2 == null) {
/*      */ 
/*      */ 
/*      */         
/* 1973 */         addScriptRuntimeInvoke("toBoolean", "(Ljava/lang/Object;)", "Z");
/* 1974 */         if (paramInt == 7) {
/* 1975 */           addByteCode((byte)-102, i);
/*      */         } else {
/* 1977 */           addByteCode((byte)-103, i);
/*      */         } 
/*      */       } else {
/* 1980 */         if (paramInt == 7) {
/* 1981 */           generateCodeFromNode(paramNode2, paramNode1, i, j);
/*      */         } else {
/* 1983 */           generateCodeFromNode(paramNode2, paramNode1, j, i);
/* 1984 */         }  if ((paramNode2.getType() != 104 || paramNode2.getInt() != 128) && 
/* 1985 */           paramNode2.getType() != 100 && 
/* 1986 */           paramNode2.getType() != 99 && 
/* 1987 */           paramNode2.getType() != 102 && 
/* 1988 */           paramNode2.getType() != 101) {
/*      */ 
/*      */           
/* 1991 */           addScriptRuntimeInvoke("toBoolean", 
/* 1992 */               "(Ljava/lang/Object;)", "Z");
/* 1993 */           if (paramInt == 7) {
/* 1994 */             addByteCode((byte)-102, i);
/*      */           } else {
/* 1996 */             addByteCode((byte)-103, i);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } else {
/* 2001 */       while (paramNode2 != null) {
/* 2002 */         generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2003 */         paramNode2 = paramNode2.getNextSibling();
/*      */       } 
/* 2005 */       if (paramInt == 142) {
/* 2006 */         addByteCode((byte)-88, i);
/*      */       } else {
/* 2008 */         addByteCode((byte)-89, i);
/*      */       } 
/* 2010 */     }  markLabel(j);
/*      */   }
/*      */   
/*      */   private void visitEnumInit(Node paramNode1, Node paramNode2) {
/* 2014 */     while (paramNode2 != null) {
/* 2015 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2016 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/* 2018 */     aload(this.variableObjectLocal);
/* 2019 */     addScriptRuntimeInvoke("initEnum", 
/* 2020 */         "(Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
/* 2021 */         "Ljava/util/Enumeration;");
/* 2022 */     short s = getNewWordLocal();
/* 2023 */     astore(s);
/* 2024 */     paramNode1.putProp(7, new Integer(s));
/*      */   }
/*      */   
/*      */   private void visitEnumNext(Node paramNode1, Node paramNode2) {
/* 2028 */     while (paramNode2 != null) {
/* 2029 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2030 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/* 2032 */     Node node = (Node)paramNode1.getProp(4);
/* 2033 */     Integer integer = (Integer)node.getProp(7);
/* 2034 */     aload(integer.shortValue());
/* 2035 */     addScriptRuntimeInvoke("nextEnum", "(Ljava/util/Enumeration;)", "Ljava/lang/Object;");
/*      */   }
/*      */   
/*      */   private void visitEnumDone(Node paramNode1, Node paramNode2) {
/* 2039 */     while (paramNode2 != null) {
/* 2040 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2041 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/* 2043 */     Node node = (Node)paramNode1.getProp(4);
/* 2044 */     Integer integer = (Integer)node.getProp(7);
/* 2045 */     releaseWordLocal(integer.shortValue());
/*      */   }
/*      */   
/*      */   private void visitEnterWith(Node paramNode1, Node paramNode2) {
/* 2049 */     while (paramNode2 != null) {
/* 2050 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2051 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/* 2053 */     aload(this.variableObjectLocal);
/* 2054 */     addScriptRuntimeInvoke("enterWith", 
/* 2055 */         "(Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
/*      */         
/* 2057 */         "Lorg/mozilla/javascript/Scriptable;");
/* 2058 */     astore(this.variableObjectLocal);
/*      */   }
/*      */   
/*      */   private void visitLeaveWith(Node paramNode1, Node paramNode2) {
/* 2062 */     aload(this.variableObjectLocal);
/* 2063 */     addScriptRuntimeInvoke("leaveWith", 
/* 2064 */         "(Lorg/mozilla/javascript/Scriptable;)", 
/* 2065 */         "Lorg/mozilla/javascript/Scriptable;");
/* 2066 */     astore(this.variableObjectLocal);
/*      */   }
/*      */ 
/*      */   
/*      */   private void resetTargets(Node paramNode) {
/* 2071 */     if (paramNode.getType() == 136) {
/* 2072 */       paramNode.putProp(20, null);
/*      */     }
/* 2074 */     Node node = paramNode.getFirstChild();
/* 2075 */     while (node != null) {
/* 2076 */       resetTargets(node);
/* 2077 */       node = node.getNextSibling();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitCall(Node paramNode1, int paramInt, Node paramNode2) {
/* 2086 */     Node node = paramNode2;
/* 2087 */     OptFunctionNode optFunctionNode = (OptFunctionNode)paramNode1.getProp(27);
/* 2088 */     if (optFunctionNode != null) {
/* 2089 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2090 */       int i = acquireLabel();
/*      */       
/* 2092 */       String str1 = ClassFileWriter.fullyQualifiedForm(optFunctionNode.getClassName());
/* 2093 */       String str2 = str1.replace('/', '_');
/*      */       
/* 2095 */       this.classFile.add((byte)-78, 
/* 2096 */           ClassFileWriter.fullyQualifiedForm(str1), 
/* 2097 */           str2, 
/* 2098 */           "L" + str1 + ";");
/* 2099 */       short s = this.classFile.getStackTop();
/*      */       
/* 2101 */       addByteCode((byte)92);
/* 2102 */       addByteCode((byte)-90, i);
/* 2103 */       addByteCode((byte)95);
/* 2104 */       addByteCode((byte)87);
/*      */       
/* 2106 */       addByteCode((byte)89);
/* 2107 */       this.classFile.add((byte)-71, 
/* 2108 */           "org/mozilla/javascript/Scriptable", 
/* 2109 */           "getParentScope", 
/* 2110 */           "()", "Lorg/mozilla/javascript/Scriptable;");
/* 2111 */       aload(this.contextLocal);
/* 2112 */       addByteCode((byte)95);
/*      */       
/* 2114 */       if (paramInt == 30) {
/* 2115 */         addByteCode((byte)1);
/*      */       } else {
/* 2117 */         paramNode2 = paramNode2.getNextSibling();
/* 2118 */         generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2127 */       paramNode2 = paramNode2.getNextSibling();
/* 2128 */       while (paramNode2 != null) {
/* 2129 */         boolean bool = false;
/* 2130 */         if (paramNode2.getType() == 72 && 
/* 2131 */           this.inDirectCallFunction) {
/* 2132 */           OptLocalVariable optLocalVariable = 
/* 2133 */             (OptLocalVariable)paramNode2.getProp(24);
/* 2134 */           if (optLocalVariable.isParameter()) {
/* 2135 */             bool = true;
/* 2136 */             aload(optLocalVariable.getJRegister());
/* 2137 */             dload((short)(optLocalVariable.getJRegister() + 1));
/*      */           } 
/*      */         } 
/* 2140 */         if (!bool) {
/* 2141 */           Integer integer = 
/* 2142 */             (Integer)paramNode2.getProp(26);
/* 2143 */           if (integer != null && 
/* 2144 */             integer.intValue() == 0) {
/* 2145 */             this.classFile.add((byte)-78, 
/* 2146 */                 "java/lang/Void", 
/* 2147 */                 "TYPE", 
/* 2148 */                 "Ljava/lang/Class;");
/* 2149 */             generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/*      */           } else {
/*      */             
/* 2152 */             generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2153 */             push(0.0D);
/*      */           } 
/*      */         } 
/* 2156 */         resetTargets(paramNode2);
/* 2157 */         paramNode2 = paramNode2.getNextSibling();
/*      */       } 
/*      */       
/* 2160 */       addByteCode((byte)42);
/* 2161 */       this.classFile.add((byte)-76, 
/* 2162 */           ClassFileWriter.fullyQualifiedForm(this.name), 
/* 2163 */           "EmptyArray", 
/* 2164 */           "[Ljava/lang/Object;");
/*      */       
/* 2166 */       if (paramInt == 30) {
/* 2167 */         addVirtualInvoke(optFunctionNode.getClassName(), 
/* 2168 */             "constructDirect", 
/* 2169 */             optFunctionNode.getDirectCallParameterSignature(), 
/* 2170 */             "Ljava/lang/Object;");
/*      */       } else {
/* 2172 */         addVirtualInvoke(optFunctionNode.getClassName(), 
/* 2173 */             "callDirect", 
/* 2174 */             optFunctionNode.getDirectCallParameterSignature(), 
/* 2175 */             "Ljava/lang/Object;");
/*      */       } 
/* 2177 */       int j = acquireLabel();
/* 2178 */       addByteCode((byte)-89, j);
/* 2179 */       markLabel(i, s);
/* 2180 */       addByteCode((byte)87);
/*      */       
/* 2182 */       visitRegularCall(paramNode1, paramInt, node, true);
/* 2183 */       markLabel(j);
/*      */     } else {
/*      */       
/* 2186 */       visitRegularCall(paramNode1, paramInt, node, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getSimpleCallName(Node paramNode) {
/* 2210 */     Node node = paramNode.getFirstChild();
/* 2211 */     if (node.getType() == 39) {
/* 2212 */       Node node1 = node.getFirstChild();
/* 2213 */       if (node1.getType() == 69) {
/* 2214 */         Node node2 = node1.getNextSibling();
/* 2215 */         Node node3 = node1.getFirstChild();
/* 2216 */         if (node3.getType() == 71) {
/* 2217 */           String str = node3.getString();
/* 2218 */           if (node2 != null && 
/* 2219 */             node2.getType() == 46 && 
/* 2220 */             str.equals(node2.getString())) {
/* 2221 */             Node node4 = node.getNextSibling();
/* 2222 */             if (node4.getType() == 68) {
/* 2223 */               Node node5 = node4.getFirstChild();
/* 2224 */               if (node5.getType() == 70) {
/* 2225 */                 Node node6 = (Node)node5.getProp(6);
/* 2226 */                 if (node6 == node1) {
/* 2227 */                   return str;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2237 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private void constructArgArray(int paramInt) {
/* 2242 */     if (paramInt == 0) {
/* 2243 */       if (this.itsZeroArgArray >= 0) {
/* 2244 */         aload(this.itsZeroArgArray);
/*      */       } else {
/* 2246 */         push(0L);
/* 2247 */         addByteCode((byte)-67, "java/lang/Object");
/*      */       }
/*      */     
/*      */     }
/* 2251 */     else if (paramInt == 1) {
/* 2252 */       if (this.itsOneArgArray >= 0) {
/* 2253 */         aload(this.itsOneArgArray);
/*      */       } else {
/* 2255 */         push(1L);
/* 2256 */         addByteCode((byte)-67, "java/lang/Object");
/*      */       } 
/*      */     } else {
/*      */       
/* 2260 */       push(paramInt);
/* 2261 */       addByteCode((byte)-67, "java/lang/Object");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitRegularCall(Node paramNode1, int paramInt, Node paramNode2, boolean paramBoolean) {
/*      */     String str5, str4, str3, str2;
/* 2283 */     OptFunctionNode optFunctionNode = (OptFunctionNode)paramNode1.getProp(27);
/* 2284 */     Node node = paramNode2;
/* 2285 */     byte b1 = 0;
/* 2286 */     byte b2 = (paramInt == 30) ? 1 : 2;
/* 2287 */     while (paramNode2 != null) {
/* 2288 */       b1++;
/* 2289 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/*      */     
/* 2292 */     paramNode2 = node;
/*      */ 
/*      */     
/* 2295 */     byte b3 = -b2;
/* 2296 */     if (paramBoolean && paramNode2 != null) {
/* 2297 */       paramNode2 = paramNode2.getNextSibling();
/* 2298 */       b3++;
/* 2299 */       aload(this.contextLocal);
/* 2300 */       addByteCode((byte)95);
/*      */     } else {
/*      */       
/* 2303 */       aload(this.contextLocal);
/*      */     } 
/* 2305 */     if (paramBoolean && paramInt == 30) {
/* 2306 */       constructArgArray(b1 - b2);
/*      */     }
/* 2308 */     boolean bool1 = (paramNode1.getProp(30) == null) ? 0 : 1;
/* 2309 */     boolean bool2 = false;
/* 2310 */     String str1 = null;
/* 2311 */     if (paramInt != 30) {
/* 2312 */       str1 = getSimpleCallName(paramNode1);
/* 2313 */       if (str1 != null && !bool1) {
/* 2314 */         bool2 = true;
/* 2315 */         push(str1);
/* 2316 */         aload(this.variableObjectLocal);
/* 2317 */         paramNode2 = paramNode2.getNextSibling().getNextSibling();
/* 2318 */         b3 = 0;
/* 2319 */         push((b1 - b2));
/* 2320 */         addByteCode((byte)-67, "java/lang/Object");
/*      */       } 
/*      */     } 
/*      */     
/* 2324 */     while (paramNode2 != null) {
/* 2325 */       if (b3 < 0) {
/* 2326 */         generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/*      */       } else {
/* 2328 */         addByteCode((byte)89);
/* 2329 */         push(b3);
/* 2330 */         if (optFunctionNode != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2337 */           boolean bool = false;
/* 2338 */           if (paramNode2.getType() == 72 && 
/* 2339 */             this.inDirectCallFunction) {
/* 2340 */             str3 = 
/* 2341 */               (OptLocalVariable)paramNode2.getProp(24);
/* 2342 */             if (str3.isParameter()) {
/* 2343 */               paramNode2.putProp(26, null);
/* 2344 */               generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2345 */               bool = true;
/*      */             } 
/*      */           } 
/* 2348 */           if (!bool) {
/* 2349 */             str3 = 
/* 2350 */               (Integer)paramNode2.getProp(26);
/* 2351 */             if (str3 != null && 
/* 2352 */               str3.intValue() == 0) {
/* 2353 */               addByteCode((byte)-69, "java/lang/Double");
/* 2354 */               addByteCode((byte)89);
/* 2355 */               generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2356 */               addDoubleConstructor();
/*      */             } else {
/*      */               
/* 2359 */               generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/*      */             } 
/*      */           } 
/*      */         } else {
/* 2363 */           generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2364 */         }  addByteCode((byte)83);
/*      */       } 
/* 2366 */       b3++;
/* 2367 */       if (b3 == 0)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 2372 */         constructArgArray(b1 - b2);
/*      */       }
/* 2374 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2393 */     if (bool1) {
/* 2394 */       str2 = "org/mozilla/javascript/ScriptRuntime";
/* 2395 */       str3 = "newObjectSpecial";
/* 2396 */       str4 = "callSpecial";
/* 2397 */       if (paramInt != 30) {
/* 2398 */         str5 = 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2403 */           "(Lorg/mozilla/javascript/Context;Ljava/lang/Object;Ljava/lang/Object;[Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;I)";
/*      */         
/* 2405 */         aload(this.thisObjLocal);
/* 2406 */         aload(this.variableObjectLocal);
/* 2407 */         push((this.itsSourceFile == null) ? "" : this.itsSourceFile);
/* 2408 */         push(this.itsLineNumber);
/*      */       } else {
/* 2410 */         str5 = 
/*      */           
/* 2412 */           "(Lorg/mozilla/javascript/Context;Ljava/lang/Object;[Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)";
/*      */         
/* 2414 */         aload(this.variableObjectLocal);
/*      */       } 
/*      */     } else {
/* 2417 */       str3 = "newObject";
/* 2418 */       if (bool2) {
/* 2419 */         str5 = 
/*      */           
/* 2421 */           "(Lorg/mozilla/javascript/Context;Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)";
/*      */         
/* 2423 */         str4 = "callSimple";
/* 2424 */         str2 = "org/mozilla/javascript/optimizer/OptRuntime";
/*      */       } else {
/* 2426 */         aload(this.variableObjectLocal);
/* 2427 */         if (paramInt == 30) {
/* 2428 */           str5 = 
/*      */             
/* 2430 */             "(Lorg/mozilla/javascript/Context;Ljava/lang/Object;[Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)";
/*      */         } else {
/*      */           
/* 2433 */           str5 = 
/*      */ 
/*      */             
/* 2436 */             "(Lorg/mozilla/javascript/Context;Ljava/lang/Object;Ljava/lang/Object;[Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)";
/*      */         } 
/*      */         
/* 2439 */         str4 = "call";
/* 2440 */         str2 = "org/mozilla/javascript/ScriptRuntime";
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2458 */     if (paramInt == 30) {
/* 2459 */       addStaticInvoke(str2, 
/* 2460 */           str3, 
/* 2461 */           str5, 
/* 2462 */           "Lorg/mozilla/javascript/Scriptable;");
/*      */     } else {
/* 2464 */       addStaticInvoke(str2, 
/* 2465 */           str4, 
/* 2466 */           str5, 
/* 2467 */           "Ljava/lang/Object;");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void visitStatement(Node paramNode) {
/* 2472 */     Object object = paramNode.getDatum();
/* 2473 */     if (object == null || !(object instanceof Number))
/*      */       return; 
/* 2475 */     this.itsLineNumber = ((Number)object).shortValue();
/* 2476 */     if (this.itsLineNumber == -1)
/*      */       return; 
/* 2478 */     this.classFile.addLineNumberEntry((short)this.itsLineNumber);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitTryCatchFinally(Node paramNode1, Node paramNode2) {
/* 2524 */     short s = getNewWordLocal();
/* 2525 */     aload(this.variableObjectLocal);
/* 2526 */     astore(s);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2533 */     int i = markLabel(acquireLabel(), (short)1);
/*      */     
/* 2535 */     visitStatement(paramNode1);
/* 2536 */     while (paramNode2 != null) {
/* 2537 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2538 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/*      */     
/* 2541 */     Node node1 = (Node)paramNode1.getProp(1);
/* 2542 */     Node node2 = (Node)paramNode1.getProp(21);
/*      */ 
/*      */     
/* 2545 */     int j = acquireLabel();
/* 2546 */     addByteCode((byte)-89, j);
/*      */ 
/*      */ 
/*      */     
/* 2550 */     if (node1 != null) {
/* 2551 */       int k = this.classFile.markHandler(acquireLabel());
/*      */ 
/*      */       
/* 2554 */       short s1 = getNewWordLocal();
/* 2555 */       astore(s1);
/*      */ 
/*      */       
/* 2558 */       aload(s);
/* 2559 */       astore(this.variableObjectLocal);
/*      */       
/* 2561 */       aload(s1);
/* 2562 */       releaseWordLocal(s1);
/*      */ 
/*      */       
/* 2565 */       addScriptRuntimeInvoke("unwrapJavaScriptException", 
/* 2566 */           "(Lorg/mozilla/javascript/JavaScriptException;)", 
/* 2567 */           "Ljava/lang/Object;");
/*      */ 
/*      */       
/* 2570 */       int m = (
/* 2571 */         (Integer)node1.getProp(20)).intValue();
/* 2572 */       addByteCode((byte)-89, m);
/*      */ 
/*      */       
/* 2575 */       this.classFile
/* 2576 */         .addExceptionHandler(i, m, k, 
/* 2577 */           "org/mozilla/javascript/JavaScriptException");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2584 */       k = this.classFile.markHandler(acquireLabel());
/* 2585 */       s1 = getNewWordLocal();
/* 2586 */       astore(s1);
/* 2587 */       aload(s);
/* 2588 */       astore(this.variableObjectLocal);
/* 2589 */       aload(s1);
/* 2590 */       addVirtualInvoke("org/mozilla/javascript/EcmaError", 
/* 2591 */           "getErrorObject", 
/* 2592 */           "()", 
/* 2593 */           "Lorg/mozilla/javascript/Scriptable;");
/* 2594 */       releaseWordLocal(s1);
/* 2595 */       addByteCode((byte)-89, m);
/* 2596 */       this.classFile
/* 2597 */         .addExceptionHandler(i, m, k, 
/* 2598 */           "org/mozilla/javascript/EcmaError");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2605 */     if (node2 != null) {
/* 2606 */       int k = this.classFile.markHandler(acquireLabel());
/*      */ 
/*      */       
/* 2609 */       aload(s);
/* 2610 */       astore(this.variableObjectLocal);
/*      */       
/* 2612 */       short s1 = this.itsLocalAllocationBase = (short)(this.itsLocalAllocationBase + 1);
/* 2613 */       astore(s1);
/*      */ 
/*      */       
/* 2616 */       int m = (
/* 2617 */         (Integer)node2.getProp(20)).intValue();
/* 2618 */       addByteCode((byte)-88, m);
/*      */ 
/*      */       
/* 2621 */       aload(s1);
/* 2622 */       addByteCode((byte)-65);
/*      */ 
/*      */       
/* 2625 */       this.classFile.addExceptionHandler(i, m, 
/* 2626 */           k, null);
/*      */     } 
/* 2628 */     releaseWordLocal(s);
/* 2629 */     markLabel(j);
/*      */   }
/*      */   
/*      */   private void visitThrow(Node paramNode1, Node paramNode2) {
/* 2633 */     visitStatement(paramNode1);
/* 2634 */     while (paramNode2 != null) {
/* 2635 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2636 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/*      */     
/* 2639 */     addByteCode((byte)-69, 
/* 2640 */         "org/mozilla/javascript/JavaScriptException");
/* 2641 */     addByteCode((byte)90);
/* 2642 */     addByteCode((byte)95);
/* 2643 */     addSpecialInvoke("org/mozilla/javascript/JavaScriptException", 
/* 2644 */         "<init>", "(Ljava/lang/Object;)", "V");
/*      */     
/* 2646 */     addByteCode((byte)-65);
/*      */   }
/*      */   
/*      */   private void visitReturn(Node paramNode1, Node paramNode2) {
/* 2650 */     visitStatement(paramNode1);
/* 2651 */     if (paramNode2 != null) {
/*      */       do {
/* 2653 */         generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2654 */         paramNode2 = paramNode2.getNextSibling();
/* 2655 */       } while (paramNode2 != null);
/* 2656 */     } else if (this.inFunction) {
/* 2657 */       pushUndefined();
/*      */     } else {
/* 2659 */       aload(this.scriptResultLocal);
/*      */     } 
/*      */     
/* 2662 */     if (this.epilogueLabel == -1)
/* 2663 */       this.epilogueLabel = this.classFile.acquireLabel(); 
/* 2664 */     addByteCode((byte)-89, this.epilogueLabel);
/*      */   }
/*      */   
/*      */   private void visitSwitch(Node paramNode1, Node paramNode2) {
/* 2668 */     visitStatement(paramNode1);
/* 2669 */     while (paramNode2 != null) {
/* 2670 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2671 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/*      */ 
/*      */     
/* 2675 */     short s = getNewWordLocal();
/* 2676 */     astore(s);
/*      */     
/* 2678 */     Vector vector = (Vector)paramNode1.getProp(13);
/* 2679 */     for (byte b = 0; b < vector.size(); b++) {
/* 2680 */       Node node3 = (Node)vector.elementAt(b);
/* 2681 */       Node node4 = node3.getFirstChild();
/* 2682 */       generateCodeFromNode(node4, node3, -1, -1);
/* 2683 */       aload(s);
/* 2684 */       addScriptRuntimeInvoke("seqB", 
/* 2685 */           "(Ljava/lang/Object;Ljava/lang/Object;)", 
/* 2686 */           "Ljava/lang/Boolean;");
/* 2687 */       Node node5 = new Node(136);
/* 2688 */       node3.replaceChild(node4, node5);
/* 2689 */       generateGOTO(7, node5);
/*      */     } 
/*      */     
/* 2692 */     Node node1 = (Node)paramNode1.getProp(14);
/* 2693 */     if (node1 != null) {
/* 2694 */       Node node = new Node(136);
/* 2695 */       node1.getFirstChild().addChildToFront(node);
/* 2696 */       generateGOTO(6, node);
/*      */     } 
/*      */     
/* 2699 */     Node node2 = (Node)paramNode1.getProp(2);
/* 2700 */     generateGOTO(6, node2);
/*      */   }
/*      */   
/*      */   private void generateGOTO(int paramInt, Node paramNode) {
/* 2704 */     Node node = new Node(paramInt);
/* 2705 */     node.putProp(1, paramNode);
/* 2706 */     visitGOTO(node, paramInt, null);
/*      */   }
/*      */   
/*      */   private void visitUnary(Node paramNode1, Node paramNode2, int paramInt1, int paramInt2) {
/* 2710 */     int i = paramNode1.getInt();
/* 2711 */     switch (i) {
/*      */       
/*      */       case 128:
/* 2714 */         if (paramInt1 != -1) {
/* 2715 */           generateCodeFromNode(paramNode2, paramNode1, paramInt2, paramInt1);
/* 2716 */           if ((paramNode2.getType() != 104 || paramNode2.getInt() != 128) && 
/* 2717 */             paramNode2.getType() != 100 && 
/* 2718 */             paramNode2.getType() != 99 && 
/* 2719 */             paramNode2.getType() != 102 && 
/* 2720 */             paramNode2.getType() != 101) {
/*      */ 
/*      */             
/* 2723 */             addScriptRuntimeInvoke("toBoolean", 
/* 2724 */                 "(Ljava/lang/Object;)", "Z");
/* 2725 */             addByteCode((byte)-102, paramInt2);
/* 2726 */             addByteCode((byte)-89, paramInt1);
/*      */           } 
/*      */         } else {
/*      */           
/* 2730 */           int j = acquireLabel();
/* 2731 */           int k = acquireLabel();
/* 2732 */           int m = acquireLabel();
/* 2733 */           generateCodeFromNode(paramNode2, paramNode1, j, k);
/*      */           
/* 2735 */           if ((paramNode2.getType() != 104 || paramNode2.getInt() != 128) && 
/* 2736 */             paramNode2.getType() != 100 && 
/* 2737 */             paramNode2.getType() != 99 && 
/* 2738 */             paramNode2.getType() != 102 && 
/* 2739 */             paramNode2.getType() != 101) {
/*      */ 
/*      */             
/* 2742 */             addScriptRuntimeInvoke("toBoolean", 
/* 2743 */                 "(Ljava/lang/Object;)", "Z");
/* 2744 */             addByteCode((byte)-103, k);
/* 2745 */             addByteCode((byte)-89, j);
/*      */           } 
/*      */           
/* 2748 */           markLabel(j);
/* 2749 */           this.classFile.add((byte)-78, "java/lang/Boolean", 
/* 2750 */               "FALSE", "Ljava/lang/Boolean;");
/* 2751 */           addByteCode((byte)-89, m);
/* 2752 */           markLabel(k);
/* 2753 */           this.classFile.add((byte)-78, "java/lang/Boolean", 
/* 2754 */               "TRUE", "Ljava/lang/Boolean;");
/* 2755 */           markLabel(m);
/* 2756 */           this.classFile.adjustStackTop(-1);
/*      */         } 
/*      */         return;
/*      */ 
/*      */       
/*      */       case 32:
/* 2762 */         visitTypeof(paramNode1, paramNode2);
/*      */         return;
/*      */       
/*      */       case 131:
/* 2766 */         generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2767 */         addByteCode((byte)87);
/* 2768 */         pushUndefined();
/*      */         return;
/*      */       
/*      */       case 28:
/* 2772 */         addByteCode((byte)-69, "java/lang/Double");
/* 2773 */         addByteCode((byte)89);
/* 2774 */         generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2775 */         addScriptRuntimeInvoke("toInt32", 
/* 2776 */             "(Ljava/lang/Object;)", "I");
/* 2777 */         push(-1L);
/* 2778 */         addByteCode((byte)-126);
/* 2779 */         addByteCode((byte)-121);
/* 2780 */         addDoubleConstructor();
/*      */         return;
/*      */       
/*      */       case 23:
/*      */       case 24:
/* 2785 */         addByteCode((byte)-69, "java/lang/Double");
/* 2786 */         addByteCode((byte)89);
/* 2787 */         generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2788 */         addScriptRuntimeInvoke("toNumber", "(Ljava/lang/Object;)", "D");
/* 2789 */         if (i == 24) {
/* 2790 */           addByteCode((byte)119);
/*      */         }
/* 2792 */         addDoubleConstructor();
/*      */         return;
/*      */     } 
/*      */     
/* 2796 */     badTree();
/*      */   }
/*      */ 
/*      */   
/*      */   private void visitTypeof(Node paramNode1, Node paramNode2) {
/* 2801 */     if (paramNode1.getType() == 104) {
/* 2802 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2803 */       addScriptRuntimeInvoke("typeof", 
/* 2804 */           "(Ljava/lang/Object;)", "Ljava/lang/String;");
/*      */       return;
/*      */     } 
/* 2807 */     String str = paramNode1.getString();
/* 2808 */     if (this.hasVarsInRegs) {
/* 2809 */       OptLocalVariable optLocalVariable = (OptLocalVariable)this.vars.get(str);
/* 2810 */       if (optLocalVariable != null) {
/* 2811 */         if (optLocalVariable.isNumber()) {
/* 2812 */           push("number");
/*      */           return;
/*      */         } 
/* 2815 */         visitGetVar(optLocalVariable, false, str);
/* 2816 */         addScriptRuntimeInvoke("typeof", 
/* 2817 */             "(Ljava/lang/Object;)", "Ljava/lang/String;");
/*      */         return;
/*      */       } 
/*      */     } 
/* 2821 */     aload(this.variableObjectLocal);
/* 2822 */     push(str);
/* 2823 */     addScriptRuntimeInvoke("typeofName", 
/* 2824 */         "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)", 
/* 2825 */         "Ljava/lang/String;");
/*      */   }
/*      */ 
/*      */   
/*      */   private void visitIncDec(Node paramNode, boolean paramBoolean) {
/* 2830 */     Node node = paramNode.getFirstChild();
/* 2831 */     if (paramNode.getProp(26) != null) {
/* 2832 */       OptLocalVariable optLocalVariable = 
/* 2833 */         (OptLocalVariable)node.getProp(24);
/* 2834 */       if (optLocalVariable.getJRegister() == -1)
/* 2835 */         optLocalVariable.assignJRegister(getNewWordPairLocal()); 
/* 2836 */       dload(optLocalVariable.getJRegister());
/* 2837 */       addByteCode((byte)92);
/* 2838 */       push(1.0D);
/* 2839 */       addByteCode(paramBoolean ? 99 : 103);
/* 2840 */       dstore(optLocalVariable.getJRegister());
/*      */     } else {
/* 2842 */       OptLocalVariable optLocalVariable = 
/* 2843 */         (OptLocalVariable)node.getProp(24);
/* 2844 */       String str = paramBoolean ? "postIncrement" : "postDecrement";
/* 2845 */       if (this.hasVarsInRegs && node.getType() == 72) {
/* 2846 */         if (optLocalVariable == null)
/* 2847 */           optLocalVariable = (OptLocalVariable)this.vars.get(node.getString()); 
/* 2848 */         if (optLocalVariable.getJRegister() == -1)
/* 2849 */           optLocalVariable.assignJRegister(getNewWordLocal()); 
/* 2850 */         aload(optLocalVariable.getJRegister());
/* 2851 */         addByteCode((byte)89);
/* 2852 */         addScriptRuntimeInvoke(str, 
/* 2853 */             "(Ljava/lang/Object;)", "Ljava/lang/Object;");
/* 2854 */         astore(optLocalVariable.getJRegister());
/*      */       }
/* 2856 */       else if (node.getType() == 39) {
/* 2857 */         Node node1 = node.getFirstChild();
/* 2858 */         generateCodeFromNode(node1, paramNode, -1, -1);
/* 2859 */         generateCodeFromNode(node1.getNextSibling(), paramNode, -1, -1);
/* 2860 */         aload(this.variableObjectLocal);
/* 2861 */         addScriptRuntimeInvoke(str, 
/* 2862 */             "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;)", 
/*      */             
/* 2864 */             "Ljava/lang/Object;");
/*      */       
/*      */       }
/* 2867 */       else if (node.getType() == 41) {
/* 2868 */         str = String.valueOf(str) + "Elem";
/* 2869 */         Node node1 = node.getFirstChild();
/* 2870 */         generateCodeFromNode(node1, paramNode, -1, -1);
/* 2871 */         generateCodeFromNode(node1.getNextSibling(), paramNode, -1, -1);
/* 2872 */         aload(this.variableObjectLocal);
/* 2873 */         addScriptRuntimeInvoke(str, 
/* 2874 */             "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
/*      */             
/* 2876 */             "Ljava/lang/Object;");
/*      */       } else {
/*      */         
/* 2879 */         aload(this.variableObjectLocal);
/* 2880 */         push(node.getString());
/* 2881 */         addScriptRuntimeInvoke(str, 
/* 2882 */             "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)", 
/* 2883 */             "Ljava/lang/Object;");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isArithmeticNode(Node paramNode) {
/* 2891 */     int i = paramNode.getType();
/* 2892 */     return !(i != 24 && 
/* 2893 */       i != 27 && 
/* 2894 */       i != 26 && 
/* 2895 */       i != 25);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitArithmetic(Node paramNode1, byte paramByte, Node paramNode2, Node paramNode3) {
/* 2901 */     Integer integer = (Integer)paramNode1.getProp(26);
/* 2902 */     if (integer != null) {
/* 2903 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2904 */       generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
/* 2905 */       addByteCode(paramByte);
/*      */     } else {
/*      */       
/* 2908 */       boolean bool = isArithmeticNode(paramNode3);
/* 2909 */       if (!bool) {
/* 2910 */         addByteCode((byte)-69, "java/lang/Double");
/* 2911 */         addByteCode((byte)89);
/*      */       } 
/* 2913 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 2914 */       if (!isArithmeticNode(paramNode2))
/* 2915 */         addScriptRuntimeInvoke("toNumber", "(Ljava/lang/Object;)", "D"); 
/* 2916 */       generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
/* 2917 */       if (!isArithmeticNode(paramNode2.getNextSibling()))
/* 2918 */         addScriptRuntimeInvoke("toNumber", "(Ljava/lang/Object;)", "D"); 
/* 2919 */       addByteCode(paramByte);
/* 2920 */       if (!bool) {
/* 2921 */         addDoubleConstructor();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void visitBitOp(Node paramNode1, int paramInt, Node paramNode2) {
/* 2927 */     Integer integer = (Integer)paramNode1.getProp(26);
/* 2928 */     if (integer == null) {
/* 2929 */       addByteCode((byte)-69, "java/lang/Double");
/* 2930 */       addByteCode((byte)89);
/*      */     } 
/* 2932 */     generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2937 */     if (paramInt == 22) {
/* 2938 */       addScriptRuntimeInvoke("toUint32", "(Ljava/lang/Object;)", "J");
/* 2939 */       generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
/* 2940 */       addScriptRuntimeInvoke("toInt32", "(Ljava/lang/Object;)", "I");
/*      */ 
/*      */       
/* 2943 */       push(31L);
/* 2944 */       addByteCode((byte)126);
/* 2945 */       addByteCode((byte)125);
/* 2946 */       addByteCode((byte)-118);
/* 2947 */       addDoubleConstructor();
/*      */       return;
/*      */     } 
/* 2950 */     if (integer == null) {
/* 2951 */       addScriptRuntimeInvoke("toInt32", "(Ljava/lang/Object;)", "I");
/* 2952 */       generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
/* 2953 */       addScriptRuntimeInvoke("toInt32", "(Ljava/lang/Object;)", "I");
/*      */     } else {
/*      */       
/* 2956 */       addScriptRuntimeInvoke("toInt32", "(D)", "I");
/* 2957 */       generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
/* 2958 */       addScriptRuntimeInvoke("toInt32", "(D)", "I");
/*      */     } 
/* 2960 */     switch (paramInt) {
/*      */       case 11:
/* 2962 */         addByteCode(-128);
/*      */         break;
/*      */       case 12:
/* 2965 */         addByteCode((byte)-126);
/*      */         break;
/*      */       case 13:
/* 2968 */         addByteCode((byte)126);
/*      */         break;
/*      */       case 21:
/* 2971 */         addByteCode((byte)122);
/*      */         break;
/*      */       case 20:
/* 2974 */         addByteCode((byte)120);
/*      */         break;
/*      */       default:
/* 2977 */         badTree(); break;
/*      */     } 
/* 2979 */     addByteCode((byte)-121);
/* 2980 */     if (integer == null) {
/* 2981 */       addDoubleConstructor();
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean nodeIsDirectCallParameter(Node paramNode) {
/* 2986 */     if (paramNode.getType() == 72) {
/* 2987 */       OptLocalVariable optLocalVariable = 
/* 2988 */         (OptLocalVariable)paramNode.getProp(24);
/* 2989 */       if (optLocalVariable != null && optLocalVariable.isParameter() && this.inDirectCallFunction && 
/* 2990 */         !this.itsForcedObjectParameters)
/*      */       {
/* 2992 */         return true;
/*      */       }
/*      */     } 
/* 2995 */     return false;
/*      */   }
/*      */   
/*      */   private void genSimpleCompare(int paramInt1, int paramInt2, int paramInt3) {
/* 2999 */     switch (paramInt1) {
/*      */       case 17:
/* 3001 */         addByteCode((byte)-104);
/* 3002 */         addByteCode((byte)-98, paramInt2);
/*      */         break;
/*      */       case 19:
/* 3005 */         addByteCode((byte)-105);
/* 3006 */         addByteCode((byte)-100, paramInt2);
/*      */         break;
/*      */       case 16:
/* 3009 */         addByteCode((byte)-104);
/* 3010 */         addByteCode((byte)-101, paramInt2);
/*      */         break;
/*      */       case 18:
/* 3013 */         addByteCode((byte)-105);
/* 3014 */         addByteCode((byte)-99, paramInt2);
/*      */         break;
/*      */     } 
/* 3017 */     if (paramInt3 != -1) {
/* 3018 */       addByteCode((byte)-89, paramInt3);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void visitGOTOingRelOp(Node paramNode1, Node paramNode2, Node paramNode3, int paramInt1, int paramInt2) {
/* 3024 */     int i = paramNode1.getInt();
/* 3025 */     Integer integer = (Integer)paramNode1.getProp(26);
/* 3026 */     if (integer != null && 
/* 3027 */       integer.intValue() == 0) {
/* 3028 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3029 */       generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
/* 3030 */       genSimpleCompare(i, paramInt1, paramInt2);
/*      */     
/*      */     }
/* 3033 */     else if (i == 64) {
/* 3034 */       aload(this.variableObjectLocal);
/* 3035 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3036 */       generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
/* 3037 */       addScriptRuntimeInvoke("instanceOf", 
/* 3038 */           "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Ljava/lang/Object;)", 
/* 3039 */           "Z");
/* 3040 */       addByteCode((byte)-102, paramInt1);
/* 3041 */       addByteCode((byte)-89, paramInt2);
/* 3042 */     } else if (i == 63) {
/* 3043 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3044 */       generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
/* 3045 */       addScriptRuntimeInvoke("in", 
/* 3046 */           "(Ljava/lang/Object;Ljava/lang/Object;)", "Z");
/* 3047 */       addByteCode((byte)-102, paramInt1);
/* 3048 */       addByteCode((byte)-89, paramInt2);
/*      */     } else {
/* 3050 */       Node node = paramNode2.getNextSibling();
/* 3051 */       boolean bool1 = nodeIsDirectCallParameter(paramNode2);
/* 3052 */       boolean bool2 = nodeIsDirectCallParameter(node);
/* 3053 */       if (bool1 || bool2) {
/* 3054 */         if (bool1) {
/* 3055 */           if (bool2) {
/* 3056 */             OptLocalVariable optLocalVariable1 = 
/* 3057 */               (OptLocalVariable)paramNode2.getProp(24);
/* 3058 */             aload(optLocalVariable1.getJRegister());
/* 3059 */             this.classFile.add((byte)-78, 
/* 3060 */                 "java/lang/Void", 
/* 3061 */                 "TYPE", 
/* 3062 */                 "Ljava/lang/Class;");
/* 3063 */             int j = acquireLabel();
/* 3064 */             addByteCode((byte)-90, j);
/* 3065 */             OptLocalVariable optLocalVariable2 = 
/* 3066 */               (OptLocalVariable)node.getProp(24);
/* 3067 */             aload(optLocalVariable2.getJRegister());
/* 3068 */             this.classFile.add((byte)-78, 
/* 3069 */                 "java/lang/Void", 
/* 3070 */                 "TYPE", 
/* 3071 */                 "Ljava/lang/Class;");
/* 3072 */             addByteCode((byte)-90, j);
/* 3073 */             dload((short)(optLocalVariable1.getJRegister() + 1));
/* 3074 */             dload((short)(optLocalVariable2.getJRegister() + 1));
/* 3075 */             genSimpleCompare(i, paramInt1, paramInt2);
/* 3076 */             markLabel(j);
/*      */ 
/*      */ 
/*      */           
/*      */           }
/* 3081 */           else if (integer != null && 
/* 3082 */             integer.intValue() == 2) {
/* 3083 */             OptLocalVariable optLocalVariable = 
/* 3084 */               (OptLocalVariable)paramNode2.getProp(24);
/* 3085 */             aload(optLocalVariable.getJRegister());
/* 3086 */             this.classFile.add((byte)-78, 
/* 3087 */                 "java/lang/Void", 
/* 3088 */                 "TYPE", 
/* 3089 */                 "Ljava/lang/Class;");
/* 3090 */             int j = acquireLabel();
/* 3091 */             addByteCode((byte)-90, j);
/* 3092 */             dload((short)(optLocalVariable.getJRegister() + 1));
/* 3093 */             generateCodeFromNode(node, paramNode1, -1, -1);
/* 3094 */             genSimpleCompare(i, paramInt1, paramInt2);
/* 3095 */             markLabel(j);
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/* 3102 */         else if (integer != null && 
/* 3103 */           integer.intValue() == 1) {
/* 3104 */           OptLocalVariable optLocalVariable = 
/* 3105 */             (OptLocalVariable)node.getProp(24);
/* 3106 */           aload(optLocalVariable.getJRegister());
/* 3107 */           this.classFile.add((byte)-78, 
/* 3108 */               "java/lang/Void", 
/* 3109 */               "TYPE", 
/* 3110 */               "Ljava/lang/Class;");
/* 3111 */           int j = acquireLabel();
/* 3112 */           addByteCode((byte)-90, j);
/* 3113 */           generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3114 */           dload((short)(optLocalVariable.getJRegister() + 1));
/* 3115 */           genSimpleCompare(i, paramInt1, paramInt2);
/* 3116 */           markLabel(j);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 3121 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3122 */       generateCodeFromNode(node, paramNode1, -1, -1);
/* 3123 */       if (integer == null) {
/* 3124 */         if (i == 19 || i == 18) {
/* 3125 */           addByteCode((byte)95);
/*      */         }
/* 3127 */         String str = (i == 16 || 
/* 3128 */           i == 18) ? "cmp_LT" : "cmp_LE";
/* 3129 */         addScriptRuntimeInvoke(str, 
/* 3130 */             "(Ljava/lang/Object;Ljava/lang/Object;)", "I");
/*      */       } else {
/*      */         
/* 3133 */         boolean bool = 
/* 3134 */           (integer.intValue() != 1) ? 0 : 1;
/* 3135 */         if (i == 19 || i == 18) {
/* 3136 */           if (bool) {
/* 3137 */             addByteCode((byte)91);
/* 3138 */             addByteCode((byte)87);
/* 3139 */             bool = false;
/*      */           } else {
/*      */             
/* 3142 */             addByteCode((byte)93);
/* 3143 */             addByteCode((byte)88);
/* 3144 */             bool = true;
/*      */           } 
/*      */         }
/* 3147 */         String str = (i == 16 || 
/* 3148 */           i == 18) ? "cmp_LT" : "cmp_LE";
/* 3149 */         if (bool) {
/* 3150 */           addOptRuntimeInvoke(str, 
/* 3151 */               "(DLjava/lang/Object;)", "I");
/*      */         } else {
/* 3153 */           addOptRuntimeInvoke(str, 
/* 3154 */               "(Ljava/lang/Object;D)", "I");
/*      */         } 
/* 3156 */       }  addByteCode((byte)-102, paramInt1);
/* 3157 */       addByteCode((byte)-89, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitRelOp(Node paramNode1, Node paramNode2, Node paramNode3) {
/* 3166 */     int i = paramNode1.getInt();
/* 3167 */     Integer integer = (Integer)paramNode1.getProp(26);
/* 3168 */     if ((integer != null && 
/* 3169 */       integer.intValue() == 0) || 
/* 3170 */       i == 64 || 
/* 3171 */       i == 63) {
/*      */       
/* 3173 */       if (i == 64)
/* 3174 */         aload(this.variableObjectLocal); 
/* 3175 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3176 */       generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
/* 3177 */       int j = acquireLabel();
/* 3178 */       int k = acquireLabel();
/* 3179 */       if (i == 64) {
/* 3180 */         addScriptRuntimeInvoke("instanceOf", 
/* 3181 */             "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Ljava/lang/Object;)", 
/* 3182 */             "Z");
/* 3183 */         addByteCode((byte)-102, j);
/*      */       
/*      */       }
/* 3186 */       else if (i == 63) {
/* 3187 */         addScriptRuntimeInvoke("in", 
/* 3188 */             "(Ljava/lang/Object;Ljava/lang/Object;)", "Z");
/* 3189 */         addByteCode((byte)-102, j);
/*      */       } else {
/*      */         
/* 3192 */         genSimpleCompare(i, j, -1);
/*      */       } 
/*      */       
/* 3195 */       this.classFile.add((byte)-78, "java/lang/Boolean", 
/* 3196 */           "FALSE", "Ljava/lang/Boolean;");
/* 3197 */       addByteCode((byte)-89, k);
/* 3198 */       markLabel(j);
/* 3199 */       this.classFile.add((byte)-78, "java/lang/Boolean", 
/* 3200 */           "TRUE", "Ljava/lang/Boolean;");
/* 3201 */       markLabel(k);
/* 3202 */       this.classFile.adjustStackTop(-1);
/*      */     } else {
/*      */       
/* 3205 */       String str = (i == 16 || 
/* 3206 */         i == 18) ? "cmp_LTB" : "cmp_LEB";
/* 3207 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3208 */       generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
/* 3209 */       if (integer == null) {
/* 3210 */         if (i == 19 || i == 18) {
/* 3211 */           addByteCode((byte)95);
/*      */         }
/* 3213 */         addScriptRuntimeInvoke(str, 
/* 3214 */             "(Ljava/lang/Object;Ljava/lang/Object;)", 
/* 3215 */             "Ljava/lang/Boolean;");
/*      */       } else {
/*      */         
/* 3218 */         boolean bool = 
/* 3219 */           (integer.intValue() != 1) ? 0 : 1;
/* 3220 */         if (i == 19 || i == 18) {
/* 3221 */           if (bool) {
/* 3222 */             addByteCode((byte)91);
/* 3223 */             addByteCode((byte)87);
/* 3224 */             bool = false;
/*      */           } else {
/*      */             
/* 3227 */             addByteCode((byte)93);
/* 3228 */             addByteCode((byte)88);
/* 3229 */             bool = true;
/*      */           } 
/*      */         }
/* 3232 */         if (bool) {
/* 3233 */           addOptRuntimeInvoke(str, 
/* 3234 */               "(DLjava/lang/Object;)", 
/* 3235 */               "Ljava/lang/Boolean;");
/*      */         } else {
/* 3237 */           addOptRuntimeInvoke(str, 
/* 3238 */               "(Ljava/lang/Object;D)", 
/* 3239 */               "Ljava/lang/Boolean;");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private Number nodeIsConvertToObjectOfNumber(Node paramNode) {
/* 3246 */     if (paramNode.getType() == 141) {
/* 3247 */       Object object = paramNode.getProp(18);
/* 3248 */       if (object == ScriptRuntime.ObjectClass) {
/* 3249 */         Node node = paramNode.getFirstChild();
/* 3250 */         if (node.getType() == 45)
/* 3251 */           return (Number)node.getDatum(); 
/*      */       } 
/*      */     } 
/* 3254 */     return null;
/*      */   }
/*      */   
/*      */   private void visitEqOp(Node paramNode1, Node paramNode2, Node paramNode3, int paramInt1, int paramInt2) {
/* 3258 */     int i = paramNode1.getInt();
/* 3259 */     Node node = paramNode2.getNextSibling();
/* 3260 */     if (paramInt1 == -1) {
/* 3261 */       String str; if (node.getType() == 108 && 
/* 3262 */         node.getInt() == 49) {
/*      */         
/* 3264 */         generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3265 */         addByteCode((byte)89);
/* 3266 */         addByteCode((byte)-58, 15);
/* 3267 */         pushUndefined();
/* 3268 */         addByteCode((byte)-91, 10);
/* 3269 */         if (i == 14 || i == 53) {
/* 3270 */           this.classFile.add((byte)-78, "java/lang/Boolean", 
/* 3271 */               "FALSE", "Ljava/lang/Boolean;");
/*      */         } else {
/* 3273 */           this.classFile.add((byte)-78, "java/lang/Boolean", 
/* 3274 */               "TRUE", "Ljava/lang/Boolean;");
/* 3275 */         }  addByteCode((byte)-89, 7);
/* 3276 */         addByteCode((byte)87);
/* 3277 */         if (i == 14 || i == 53) {
/* 3278 */           this.classFile.add((byte)-78, "java/lang/Boolean", 
/* 3279 */               "TRUE", "Ljava/lang/Boolean;");
/*      */         } else {
/* 3281 */           this.classFile.add((byte)-78, "java/lang/Boolean", 
/* 3282 */               "FALSE", "Ljava/lang/Boolean;");
/*      */         } 
/*      */         return;
/*      */       } 
/* 3286 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3287 */       generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
/*      */ 
/*      */ 
/*      */       
/* 3291 */       switch (i) {
/*      */         case 14:
/* 3293 */           str = (this.version == 120) ? "seqB" : "eqB";
/*      */           break;
/*      */         
/*      */         case 15:
/* 3297 */           str = (this.version == 120) ? "sneB" : "neB";
/*      */           break;
/*      */         
/*      */         case 53:
/* 3301 */           str = "seqB";
/*      */           break;
/*      */         
/*      */         case 54:
/* 3305 */           str = "sneB";
/*      */           break;
/*      */         
/*      */         default:
/* 3309 */           str = null;
/* 3310 */           badTree(); break;
/*      */       } 
/* 3312 */       addScriptRuntimeInvoke(str, 
/* 3313 */           "(Ljava/lang/Object;Ljava/lang/Object;)", 
/* 3314 */           "Ljava/lang/Boolean;");
/*      */     } else {
/*      */       String str;
/* 3317 */       if (node.getType() == 108 && 
/* 3318 */         node.getInt() == 49) {
/*      */         
/* 3320 */         generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3329 */         boolean bool = (paramNode2.getType() != 72) ? 0 : 1;
/* 3330 */         if (!bool) addByteCode((byte)89); 
/* 3331 */         int j = acquireLabel();
/* 3332 */         if (i == 14 || i == 53) {
/* 3333 */           addByteCode((byte)-58, 
/* 3334 */               bool ? paramInt1 : j);
/* 3335 */           short s = this.classFile.getStackTop();
/* 3336 */           if (bool) generateCodeFromNode(paramNode2, paramNode1, -1, -1); 
/* 3337 */           pushUndefined();
/* 3338 */           addByteCode((byte)-91, paramInt1);
/* 3339 */           addByteCode((byte)-89, paramInt2);
/* 3340 */           if (!bool) {
/* 3341 */             markLabel(j, s);
/* 3342 */             addByteCode((byte)87);
/* 3343 */             addByteCode((byte)-89, paramInt1);
/*      */           } 
/*      */         } else {
/*      */           
/* 3347 */           addByteCode((byte)-58, 
/* 3348 */               bool ? paramInt2 : j);
/* 3349 */           short s = this.classFile.getStackTop();
/* 3350 */           if (bool) generateCodeFromNode(paramNode2, paramNode1, -1, -1); 
/* 3351 */           pushUndefined();
/* 3352 */           addByteCode((byte)-91, paramInt2);
/* 3353 */           addByteCode((byte)-89, paramInt1);
/* 3354 */           if (!bool) {
/* 3355 */             markLabel(j, s);
/* 3356 */             addByteCode((byte)87);
/* 3357 */             addByteCode((byte)-89, paramInt2);
/*      */           } 
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/* 3363 */       Node node1 = paramNode2.getNextSibling();
/*      */       
/* 3365 */       Number number = nodeIsConvertToObjectOfNumber(node1);
/* 3366 */       if (nodeIsDirectCallParameter(paramNode2) && 
/* 3367 */         number != null) {
/* 3368 */         OptLocalVariable optLocalVariable = 
/* 3369 */           (OptLocalVariable)paramNode2.getProp(24);
/* 3370 */         aload(optLocalVariable.getJRegister());
/* 3371 */         this.classFile.add((byte)-78, 
/* 3372 */             "java/lang/Void", 
/* 3373 */             "TYPE", 
/* 3374 */             "Ljava/lang/Class;");
/* 3375 */         int j = acquireLabel();
/* 3376 */         addByteCode((byte)-90, j);
/* 3377 */         dload((short)(optLocalVariable.getJRegister() + 1));
/* 3378 */         push(number.doubleValue());
/* 3379 */         addByteCode((byte)-105);
/* 3380 */         if (i == 14) {
/* 3381 */           addByteCode((byte)-103, paramInt1);
/*      */         } else {
/* 3383 */           addByteCode((byte)-102, paramInt1);
/* 3384 */         }  addByteCode((byte)-89, paramInt2);
/* 3385 */         markLabel(j);
/*      */       } 
/*      */ 
/*      */       
/* 3389 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3390 */       generateCodeFromNode(node1, paramNode1, -1, -1);
/*      */ 
/*      */       
/* 3393 */       switch (i) {
/*      */         case 14:
/* 3395 */           str = (this.version == 120) ? "shallowEq" : "eq";
/* 3396 */           addScriptRuntimeInvoke(str, 
/* 3397 */               "(Ljava/lang/Object;Ljava/lang/Object;)", "Z");
/*      */           break;
/*      */         
/*      */         case 15:
/* 3401 */           str = (this.version == 120) ? "shallowNeq" : "neq";
/* 3402 */           addOptRuntimeInvoke(str, 
/* 3403 */               "(Ljava/lang/Object;Ljava/lang/Object;)", "Z");
/*      */           break;
/*      */         
/*      */         case 53:
/* 3407 */           str = "shallowEq";
/* 3408 */           addScriptRuntimeInvoke(str, 
/* 3409 */               "(Ljava/lang/Object;Ljava/lang/Object;)", "Z");
/*      */           break;
/*      */         
/*      */         case 54:
/* 3413 */           str = "shallowNeq";
/* 3414 */           addOptRuntimeInvoke(str, 
/* 3415 */               "(Ljava/lang/Object;Ljava/lang/Object;)", "Z");
/*      */           break;
/*      */         
/*      */         default:
/* 3419 */           str = null;
/* 3420 */           badTree(); break;
/*      */       } 
/* 3422 */       addByteCode((byte)-102, paramInt1);
/* 3423 */       addByteCode((byte)-89, paramInt2);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void visitLiteral(Node paramNode) {
/* 3428 */     if (paramNode.getType() == 46) {
/*      */       
/* 3430 */       push(paramNode.getString());
/*      */     } else {
/* 3432 */       Number number = (Number)paramNode.getDatum();
/* 3433 */       if (paramNode.getProp(26) != null) {
/* 3434 */         push(number.doubleValue());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3445 */         String str1 = "";
/* 3446 */         String str2 = "";
/* 3447 */         boolean bool = false;
/*      */         
/* 3449 */         if (number instanceof Float) {
/* 3450 */           number = new Double(number.floatValue());
/*      */         }
/*      */         
/* 3453 */         if (number instanceof Integer) {
/* 3454 */           str1 = "Integer";
/* 3455 */           str2 = "I";
/* 3456 */           bool = true;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 3462 */         else if (number instanceof Double) {
/* 3463 */           str1 = "Double";
/* 3464 */           str2 = "D";
/* 3465 */         } else if (number instanceof Byte) {
/* 3466 */           str1 = "Byte";
/* 3467 */           str2 = "B";
/* 3468 */           bool = true;
/* 3469 */         } else if (number instanceof Short) {
/* 3470 */           str1 = "Short";
/* 3471 */           str2 = "S";
/* 3472 */           bool = true;
/*      */         } else {
/* 3474 */           throw Context.reportRuntimeError(
/* 3475 */               "NumberNode contains unsupported Number type: " + 
/* 3476 */               number.getClass().getName());
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3484 */         if (this.itsConstantList.itsTop >= 2000) {
/* 3485 */           addByteCode((byte)-69, "java/lang/" + str1);
/* 3486 */           addByteCode((byte)89);
/* 3487 */           if (bool) {
/* 3488 */             push(number.longValue());
/*      */           } else {
/* 3490 */             push(number.doubleValue());
/* 3491 */           }  addSpecialInvoke("java/lang/" + 
/* 3492 */               str1, 
/* 3493 */               "<init>", 
/* 3494 */               "(" + 
/* 3495 */               str2 + 
/* 3496 */               ")", 
/* 3497 */               "V");
/*      */         } else {
/*      */           
/* 3500 */           this.classFile.add((byte)-78, 
/* 3501 */               ClassFileWriter.fullyQualifiedForm(this.name), 
/* 3502 */               "jsK_" + 
/* 3503 */               this.itsConstantList.addConstant(str1, 
/* 3504 */                 str2, 
/* 3505 */                 number, 
/* 3506 */                 bool), 
/* 3507 */               "Ljava/lang/" + str1 + ";");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void emitConstantDudeInitializers() {
/* 3514 */     if (this.itsConstantList.itsTop == 0)
/*      */       return; 
/* 3516 */     this.classFile.startMethod("<clinit>", "()V", (short)
/* 3517 */         24);
/*      */     
/* 3519 */     for (byte b = 0; b < this.itsConstantList.itsTop; b++) {
/* 3520 */       addByteCode((byte)-69, 
/* 3521 */           "java/lang/" + 
/* 3522 */           (this.itsConstantList.itsList[b]).itsWrapperType);
/* 3523 */       addByteCode((byte)89);
/* 3524 */       if ((this.itsConstantList.itsList[b]).itsIsInteger) {
/* 3525 */         push((this.itsConstantList.itsList[b]).itsLValue);
/*      */       } else {
/* 3527 */         push((this.itsConstantList.itsList[b]).itsDValue);
/* 3528 */       }  addSpecialInvoke("java/lang/" + 
/* 3529 */           (this.itsConstantList.itsList[b]).itsWrapperType, 
/* 3530 */           "<init>", 
/* 3531 */           "(" + 
/* 3532 */           (this.itsConstantList.itsList[b]).itsSignature + 
/* 3533 */           ")", 
/* 3534 */           "V");
/* 3535 */       this.classFile.addField("jsK_" + b, 
/* 3536 */           "Ljava/lang/" + 
/* 3537 */           (this.itsConstantList.itsList[b]).itsWrapperType + ";", (short)
/* 3538 */           8);
/* 3539 */       this.classFile.add((byte)-77, 
/* 3540 */           ClassFileWriter.fullyQualifiedForm(this.name), 
/* 3541 */           "jsK_" + b, 
/* 3542 */           "Ljava/lang/" + 
/* 3543 */           (this.itsConstantList.itsList[b]).itsWrapperType + ";");
/*      */     } 
/* 3545 */     addByteCode((byte)-79);
/* 3546 */     this.classFile.stopMethod((short)0, null);
/*      */   }
/*      */   
/*      */   private void visitPrimary(Node paramNode) {
/* 3550 */     int i = paramNode.getInt();
/* 3551 */     switch (i) {
/*      */       
/*      */       case 50:
/* 3554 */         aload(this.thisObjLocal);
/*      */         return;
/*      */       
/*      */       case 49:
/* 3558 */         addByteCode((byte)1);
/*      */         return;
/*      */       
/*      */       case 52:
/* 3562 */         this.classFile.add((byte)-78, "java/lang/Boolean", 
/* 3563 */             "TRUE", "Ljava/lang/Boolean;");
/*      */         return;
/*      */       
/*      */       case 51:
/* 3567 */         this.classFile.add((byte)-78, "java/lang/Boolean", 
/* 3568 */             "FALSE", "Ljava/lang/Boolean;");
/*      */         return;
/*      */       
/*      */       case 74:
/* 3572 */         pushUndefined();
/*      */         return;
/*      */     } 
/*      */     
/* 3576 */     badTree();
/*      */   }
/*      */ 
/*      */   
/*      */   private void visitObject(Node paramNode) {
/* 3581 */     Node node = (Node)paramNode.getProp(12);
/* 3582 */     String str = (String)node.getProp(12);
/* 3583 */     aload(this.funObjLocal);
/* 3584 */     this.classFile.add((byte)-76, 
/* 3585 */         ClassFileWriter.fullyQualifiedForm(this.name), 
/* 3586 */         str, "Lorg/mozilla/javascript/regexp/NativeRegExp;");
/*      */   }
/*      */   
/*      */   private void visitName(Node paramNode) {
/* 3590 */     aload(this.variableObjectLocal);
/* 3591 */     push(paramNode.getString());
/* 3592 */     addScriptRuntimeInvoke("name", 
/* 3593 */         "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)", 
/* 3594 */         "Ljava/lang/Object;");
/*      */   }
/*      */   
/*      */   private void visitSetName(Node paramNode1, Node paramNode2) {
/* 3598 */     String str = paramNode1.getFirstChild().getString();
/* 3599 */     while (paramNode2 != null) {
/* 3600 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3601 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/* 3603 */     aload(this.variableObjectLocal);
/* 3604 */     push(str);
/* 3605 */     addScriptRuntimeInvoke("setName", 
/* 3606 */         "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)", 
/*      */         
/* 3608 */         "Ljava/lang/Object;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitGetVar(OptLocalVariable paramOptLocalVariable, boolean paramBoolean, String paramString) {
/* 3615 */     if (this.hasVarsInRegs && paramOptLocalVariable == null)
/* 3616 */       paramOptLocalVariable = (OptLocalVariable)this.vars.get(paramString); 
/* 3617 */     if (paramOptLocalVariable != null) {
/* 3618 */       if (paramOptLocalVariable.getJRegister() == -1)
/* 3619 */         if (paramOptLocalVariable.isNumber()) {
/* 3620 */           paramOptLocalVariable.assignJRegister(getNewWordPairLocal());
/*      */         } else {
/* 3622 */           paramOptLocalVariable.assignJRegister(getNewWordLocal());
/* 3623 */         }   if (paramOptLocalVariable.isParameter() && this.inDirectCallFunction && 
/* 3624 */         !this.itsForcedObjectParameters) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3632 */         if (paramBoolean) {
/* 3633 */           aload(paramOptLocalVariable.getJRegister());
/* 3634 */           this.classFile.add((byte)-78, 
/* 3635 */               "java/lang/Void", 
/* 3636 */               "TYPE", 
/* 3637 */               "Ljava/lang/Class;");
/* 3638 */           int i = acquireLabel();
/* 3639 */           int j = acquireLabel();
/* 3640 */           addByteCode((byte)-91, i);
/* 3641 */           aload(paramOptLocalVariable.getJRegister());
/* 3642 */           addScriptRuntimeInvoke("toNumber", "(Ljava/lang/Object;)", "D");
/* 3643 */           addByteCode((byte)-89, j);
/* 3644 */           markLabel(i);
/* 3645 */           dload((short)(paramOptLocalVariable.getJRegister() + 1));
/* 3646 */           markLabel(j);
/*      */         } else {
/* 3648 */           aload(paramOptLocalVariable.getJRegister());
/* 3649 */           this.classFile.add((byte)-78, 
/* 3650 */               "java/lang/Void", 
/* 3651 */               "TYPE", 
/* 3652 */               "Ljava/lang/Class;");
/* 3653 */           int i = acquireLabel();
/* 3654 */           int j = acquireLabel();
/* 3655 */           addByteCode((byte)-91, i);
/* 3656 */           aload(paramOptLocalVariable.getJRegister());
/* 3657 */           addByteCode((byte)-89, j);
/* 3658 */           markLabel(i);
/* 3659 */           addByteCode((byte)-69, "java/lang/Double");
/* 3660 */           addByteCode((byte)89);
/* 3661 */           dload((short)(paramOptLocalVariable.getJRegister() + 1));
/* 3662 */           addDoubleConstructor();
/* 3663 */           markLabel(j);
/*      */         }
/*      */       
/* 3666 */       } else if (paramOptLocalVariable.isNumber()) {
/* 3667 */         dload(paramOptLocalVariable.getJRegister());
/*      */       } else {
/* 3669 */         aload(paramOptLocalVariable.getJRegister());
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/* 3674 */     aload(this.variableObjectLocal);
/* 3675 */     push(paramString);
/* 3676 */     aload(this.variableObjectLocal);
/* 3677 */     addScriptRuntimeInvoke("getProp", 
/* 3678 */         "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;)", 
/*      */         
/* 3680 */         "Ljava/lang/Object;");
/*      */   }
/*      */   
/*      */   private void visitSetVar(Node paramNode1, Node paramNode2, boolean paramBoolean) {
/* 3684 */     OptLocalVariable optLocalVariable = (OptLocalVariable)paramNode1.getProp(24);
/*      */     
/* 3686 */     if (this.hasVarsInRegs && optLocalVariable == null)
/* 3687 */       optLocalVariable = (OptLocalVariable)this.vars.get(paramNode2.getString()); 
/* 3688 */     if (optLocalVariable != null) {
/* 3689 */       generateCodeFromNode(paramNode2.getNextSibling(), paramNode1, -1, -1);
/* 3690 */       if (optLocalVariable.getJRegister() == -1)
/* 3691 */         if (optLocalVariable.isNumber()) {
/* 3692 */           optLocalVariable.assignJRegister(getNewWordPairLocal());
/*      */         } else {
/* 3694 */           optLocalVariable.assignJRegister(getNewWordLocal());
/*      */         }  
/* 3696 */       if (optLocalVariable.isParameter() && 
/* 3697 */         this.inDirectCallFunction && 
/* 3698 */         !this.itsForcedObjectParameters) {
/* 3699 */         if (paramNode1.getProp(26) != null) {
/* 3700 */           if (paramBoolean) addByteCode((byte)92); 
/* 3701 */           aload(optLocalVariable.getJRegister());
/* 3702 */           this.classFile.add((byte)-78, 
/* 3703 */               "java/lang/Void", 
/* 3704 */               "TYPE", 
/* 3705 */               "Ljava/lang/Class;");
/* 3706 */           int i = acquireLabel();
/* 3707 */           int j = acquireLabel();
/* 3708 */           addByteCode((byte)-91, i);
/* 3709 */           addByteCode((byte)-69, "java/lang/Double");
/* 3710 */           addByteCode((byte)89);
/* 3711 */           addByteCode((byte)94);
/* 3712 */           addByteCode((byte)88);
/* 3713 */           addDoubleConstructor();
/* 3714 */           astore(optLocalVariable.getJRegister());
/* 3715 */           addByteCode((byte)-89, j);
/* 3716 */           markLabel(i);
/* 3717 */           dstore((short)(optLocalVariable.getJRegister() + 1));
/* 3718 */           markLabel(j);
/*      */         } else {
/*      */           
/* 3721 */           if (paramBoolean) addByteCode((byte)89); 
/* 3722 */           astore(optLocalVariable.getJRegister());
/*      */         }
/*      */       
/*      */       }
/* 3726 */       else if (paramNode1.getProp(26) != null) {
/* 3727 */         dstore(optLocalVariable.getJRegister());
/* 3728 */         if (paramBoolean) dload(optLocalVariable.getJRegister());
/*      */       
/*      */       } else {
/* 3731 */         astore(optLocalVariable.getJRegister());
/* 3732 */         if (paramBoolean) aload(optLocalVariable.getJRegister());
/*      */       
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 3739 */     paramNode2.setType(61);
/* 3740 */     paramNode1.setType(10);
/* 3741 */     visitSetName(paramNode1, paramNode2);
/* 3742 */     if (!paramBoolean) {
/* 3743 */       addByteCode((byte)87);
/*      */     }
/*      */   }
/*      */   
/*      */   private void visitGetProp(Node paramNode1, Node paramNode2) {
/* 3748 */     String str = (String)paramNode1.getProp(19);
/* 3749 */     if (str != null) {
/* 3750 */       while (paramNode2 != null) {
/* 3751 */         generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3752 */         paramNode2 = paramNode2.getNextSibling();
/*      */       } 
/* 3754 */       aload(this.variableObjectLocal);
/* 3755 */       String str1 = null;
/* 3756 */       if (str.equals("__proto__")) {
/* 3757 */         str1 = "getProto";
/* 3758 */       } else if (str.equals("__parent__")) {
/* 3759 */         str1 = "getParent";
/*      */       } else {
/* 3761 */         badTree();
/*      */       } 
/* 3763 */       addScriptRuntimeInvoke(str1, 
/* 3764 */           "(Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
/* 3765 */           "Lorg/mozilla/javascript/Scriptable;");
/*      */       return;
/*      */     } 
/* 3768 */     Node node = paramNode2.getNextSibling();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3774 */     generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3775 */     generateCodeFromNode(node, paramNode1, -1, -1);
/* 3776 */     if (node.getType() == 46) {
/* 3777 */       if ((paramNode2.getType() == 108 && 
/* 3778 */         paramNode2.getInt() == 50) || (
/* 3779 */         paramNode2.getType() == 69 && 
/* 3780 */         paramNode2.getFirstChild().getType() == 108 && 
/* 3781 */         paramNode2.getFirstChild().getInt() == 50)) {
/*      */         
/* 3783 */         aload(this.variableObjectLocal);
/* 3784 */         addOptRuntimeInvoke("thisGet", 
/*      */             
/* 3786 */             "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;)", 
/*      */             
/* 3788 */             "Ljava/lang/Object;");
/*      */       } else {
/*      */         
/* 3791 */         aload(this.variableObjectLocal);
/* 3792 */         addScriptRuntimeInvoke("getProp", 
/* 3793 */             "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;)", 
/*      */             
/* 3795 */             "Ljava/lang/Object;");
/*      */       } 
/*      */     } else {
/*      */       
/* 3799 */       aload(this.variableObjectLocal);
/* 3800 */       addScriptRuntimeInvoke("getProp", 
/* 3801 */           "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;)", 
/*      */           
/* 3803 */           "Ljava/lang/Object;");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void visitSetProp(Node paramNode1, Node paramNode2) {
/* 3808 */     String str = (String)paramNode1.getProp(19);
/* 3809 */     if (str != null) {
/* 3810 */       while (paramNode2 != null) {
/* 3811 */         generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3812 */         paramNode2 = paramNode2.getNextSibling();
/*      */       } 
/* 3814 */       aload(this.variableObjectLocal);
/* 3815 */       String str1 = null;
/* 3816 */       if (str.equals("__proto__")) {
/* 3817 */         str1 = "setProto";
/* 3818 */       } else if (str.equals("__parent__")) {
/* 3819 */         str1 = "setParent";
/*      */       } else {
/* 3821 */         badTree();
/*      */       } 
/* 3823 */       addScriptRuntimeInvoke(str1, 
/* 3824 */           "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
/*      */           
/* 3826 */           "Ljava/lang/Object;");
/*      */       return;
/*      */     } 
/* 3829 */     while (paramNode2 != null) {
/* 3830 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3831 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/* 3833 */     aload(this.variableObjectLocal);
/* 3834 */     addScriptRuntimeInvoke("setProp", 
/* 3835 */         "(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)", 
/*      */         
/* 3837 */         "Ljava/lang/Object;");
/*      */   }
/*      */   
/*      */   private void visitBind(Node paramNode1, int paramInt, Node paramNode2) {
/* 3841 */     while (paramNode2 != null) {
/* 3842 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3843 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/*      */     
/* 3846 */     aload(this.variableObjectLocal);
/* 3847 */     push(paramNode1.getString());
/* 3848 */     addScriptRuntimeInvoke((paramInt == 61) ? "bind" : "getBase", 
/* 3849 */         "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)", 
/* 3850 */         "Lorg/mozilla/javascript/Scriptable;");
/*      */   }
/*      */   
/*      */   private short getLocalFromNode(Node paramNode) {
/* 3854 */     Integer integer = (Integer)paramNode.getProp(7);
/* 3855 */     if (integer == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3861 */       this.itsLocalAllocationBase = (short)(this.itsLocalAllocationBase + 1); short s = (paramNode.getType() == 143 || paramNode.getType() == 144) ? this.itsLocalAllocationBase : getNewWordLocal();
/*      */       
/* 3863 */       paramNode.putProp(7, new Integer(s));
/* 3864 */       return s;
/*      */     } 
/* 3866 */     return integer.shortValue();
/*      */   }
/*      */ 
/*      */   
/*      */   private void visitNewTemp(Node paramNode1, Node paramNode2) {
/* 3871 */     while (paramNode2 != null) {
/* 3872 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3873 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/* 3875 */     short s = getLocalFromNode(paramNode1);
/* 3876 */     addByteCode((byte)89);
/* 3877 */     astore(s);
/* 3878 */     Integer integer = (Integer)paramNode1.getProp(11);
/* 3879 */     if (integer == null || integer.intValue() == 0)
/* 3880 */       releaseWordLocal(s); 
/*      */   }
/*      */   
/*      */   private void visitUseTemp(Node paramNode1, Node paramNode2) {
/* 3884 */     while (paramNode2 != null) {
/* 3885 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3886 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/* 3888 */     Node node = (Node)paramNode1.getProp(6);
/* 3889 */     short s = getLocalFromNode(node);
/*      */ 
/*      */ 
/*      */     
/* 3893 */     if (paramNode1.getProp(true) != null) {
/* 3894 */       addByteCode((byte)-87, s);
/*      */     } else {
/* 3896 */       aload(s);
/* 3897 */     }  Integer integer = (Integer)node.getProp(11);
/* 3898 */     if (integer == null) {
/* 3899 */       releaseWordLocal(s);
/*      */     }
/* 3901 */     else if (integer.intValue() < Integer.MAX_VALUE) {
/* 3902 */       int i = integer.intValue() - 1;
/* 3903 */       if (i == 0)
/* 3904 */         releaseWordLocal(s); 
/* 3905 */       node.putProp(11, new Integer(i));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void visitNewLocal(Node paramNode1, Node paramNode2) {
/* 3911 */     while (paramNode2 != null) {
/* 3912 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3913 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/* 3915 */     short s = getLocalFromNode(paramNode1);
/* 3916 */     addByteCode((byte)89);
/* 3917 */     astore(s);
/*      */   }
/*      */   
/*      */   private void visitUseLocal(Node paramNode1, Node paramNode2) {
/* 3921 */     while (paramNode2 != null) {
/* 3922 */       generateCodeFromNode(paramNode2, paramNode1, -1, -1);
/* 3923 */       paramNode2 = paramNode2.getNextSibling();
/*      */     } 
/* 3925 */     Node node = (Node)paramNode1.getProp(7);
/* 3926 */     short s = getLocalFromNode(node);
/*      */ 
/*      */ 
/*      */     
/* 3930 */     if (paramNode1.getProp(true) != null) {
/* 3931 */       addByteCode((byte)-87, s);
/*      */     } else {
/* 3933 */       aload(s);
/*      */     } 
/*      */   }
/*      */   
/* 3937 */   private void dstore(short paramShort) { xstore((byte)71, (byte)57, paramShort); }
/*      */ 
/*      */ 
/*      */   
/* 3941 */   private void istore(short paramShort) { xstore((byte)59, (byte)54, paramShort); }
/*      */ 
/*      */ 
/*      */   
/* 3945 */   private void astore(short paramShort) { xstore((byte)75, (byte)58, paramShort); }
/*      */ 
/*      */   
/*      */   private void xstore(byte paramByte1, byte paramByte2, short paramShort) {
/* 3949 */     switch (paramShort) {
/*      */       case 0:
/* 3951 */         addByteCode(paramByte1);
/*      */         return;
/*      */       case 1:
/* 3954 */         addByteCode((byte)(paramByte1 + 1));
/*      */         return;
/*      */       case 2:
/* 3957 */         addByteCode((byte)(paramByte1 + 2));
/*      */         return;
/*      */       case 3:
/* 3960 */         addByteCode((byte)(paramByte1 + 3));
/*      */         return;
/*      */     } 
/* 3963 */     if (paramShort < 0 || paramShort >= 127)
/* 3964 */       throw new RuntimeException("bad local"); 
/* 3965 */     addByteCode(paramByte2, (byte)paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3971 */   private void dload(short paramShort) { xload((byte)38, (byte)24, paramShort); }
/*      */ 
/*      */ 
/*      */   
/* 3975 */   private void iload(short paramShort) { xload((byte)26, (byte)21, paramShort); }
/*      */ 
/*      */ 
/*      */   
/* 3979 */   private void aload(short paramShort) { xload((byte)42, (byte)25, paramShort); }
/*      */ 
/*      */   
/*      */   private void xload(byte paramByte1, byte paramByte2, short paramShort) {
/* 3983 */     switch (paramShort) {
/*      */       case 0:
/* 3985 */         addByteCode(paramByte1);
/*      */         return;
/*      */       case 1:
/* 3988 */         addByteCode((byte)(paramByte1 + 1));
/*      */         return;
/*      */       case 2:
/* 3991 */         addByteCode((byte)(paramByte1 + 2));
/*      */         return;
/*      */       case 3:
/* 3994 */         addByteCode((byte)(paramByte1 + 3));
/*      */         return;
/*      */     } 
/* 3997 */     if (paramShort < 0 || paramShort >= 127)
/* 3998 */       throw new RuntimeException("bad local"); 
/* 3999 */     addByteCode(paramByte2, (byte)paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private short getNewWordPairLocal() {
/* 4005 */     short s = this.firstFreeLocal;
/*      */     
/* 4007 */     while (s < 255) {
/*      */       
/* 4009 */       if (this.locals[s] || 
/* 4010 */         this.locals[s + 1])
/*      */       {
/* 4012 */         s = (short)(s + 1); } 
/*      */     } 
/* 4014 */     if (s < 255) {
/* 4015 */       this.locals[s] = true;
/* 4016 */       this.locals[s + 1] = true;
/* 4017 */       if (s == this.firstFreeLocal) {
/* 4018 */         for (short s1 = this.firstFreeLocal + 2; s1 < 256; s1++) {
/* 4019 */           if (!this.locals[s1]) {
/* 4020 */             this.firstFreeLocal = (short)s1;
/* 4021 */             if (this.localsMax < this.firstFreeLocal)
/* 4022 */               this.localsMax = this.firstFreeLocal; 
/* 4023 */             return s;
/*      */           } 
/*      */         } 
/*      */       } else {
/*      */         
/* 4028 */         return s;
/*      */       } 
/*      */     } 
/* 4031 */     throw Context.reportRuntimeError("Program too complex (out of locals)");
/*      */   }
/*      */ 
/*      */   
/*      */   private short reserveWordLocal(int paramInt) {
/* 4036 */     if (getNewWordLocal() != paramInt)
/* 4037 */       throw new RuntimeException("Local allocation error"); 
/* 4038 */     return (short)paramInt;
/*      */   }
/*      */   
/*      */   private short getNewWordLocal() {
/* 4042 */     short s1 = this.firstFreeLocal;
/* 4043 */     this.locals[s1] = true;
/* 4044 */     for (short s2 = this.firstFreeLocal + 1; s2 < 256; s2++) {
/* 4045 */       if (!this.locals[s2]) {
/* 4046 */         this.firstFreeLocal = (short)s2;
/* 4047 */         if (this.localsMax < this.firstFreeLocal)
/* 4048 */           this.localsMax = this.firstFreeLocal; 
/* 4049 */         return s1;
/*      */       } 
/*      */     } 
/* 4052 */     throw Context.reportRuntimeError("Program too complex (out of locals)");
/*      */   }
/*      */ 
/*      */   
/*      */   private void releaseWordpairLocal(short paramShort) {
/* 4057 */     if (paramShort < this.firstFreeLocal)
/* 4058 */       this.firstFreeLocal = paramShort; 
/* 4059 */     this.locals[paramShort] = false;
/* 4060 */     this.locals[paramShort + 1] = false;
/*      */   }
/*      */   
/*      */   private void releaseWordLocal(short paramShort) {
/* 4064 */     if (paramShort < this.firstFreeLocal)
/* 4065 */       this.firstFreeLocal = paramShort; 
/* 4066 */     this.locals[paramShort] = false;
/*      */   }
/*      */   
/*      */   private void push(long paramLong) {
/* 4070 */     if (paramLong == -1L) {
/* 4071 */       addByteCode((byte)2);
/* 4072 */     } else if (paramLong >= 0L && paramLong <= 5L) {
/* 4073 */       addByteCode((byte)(int)(3L + paramLong));
/* 4074 */     } else if (paramLong >= -128L && paramLong <= 127L) {
/* 4075 */       addByteCode((byte)16, (byte)(int)paramLong);
/* 4076 */     } else if (paramLong >= -32768L && paramLong <= 32767L) {
/* 4077 */       addByteCode((byte)17, (short)(int)paramLong);
/* 4078 */     } else if (paramLong >= -2147483648L && paramLong <= 2147483647L) {
/* 4079 */       this.classFile.addLoadConstant((int)paramLong);
/*      */     } else {
/* 4081 */       this.classFile.addLoadConstant(paramLong);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void push(double paramDouble) {
/* 4086 */     if (paramDouble == 0.0D) {
/* 4087 */       addByteCode((byte)14);
/* 4088 */     } else if (paramDouble == 1.0D) {
/* 4089 */       addByteCode((byte)15);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 4095 */       this.classFile.addLoadConstant(paramDouble);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 4100 */   private void push(String paramString) { this.classFile.addLoadConstant(paramString); }
/*      */ 
/*      */   
/*      */   private void pushUndefined() {
/* 4104 */     this.classFile.add((byte)-78, "org/mozilla/javascript/Undefined", 
/* 4105 */         "instance", "Lorg/mozilla/javascript/Scriptable;");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 4110 */   private void badTree() { throw new RuntimeException("Bad tree in codegen"); }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\Codegen.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */