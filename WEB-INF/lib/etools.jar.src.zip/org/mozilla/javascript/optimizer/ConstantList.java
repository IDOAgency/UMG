package org.mozilla.javascript.optimizer;

class ConstantList {
  int addConstant(String paramString1, String paramString2, Number paramNumber, boolean paramBoolean) {
    long l = paramNumber.longValue();
    double d = paramNumber.doubleValue();
    for (byte b = 0; b < this.itsTop; b++) {
      if (paramString2.equals((this.itsList[b]).itsSignature))
        if ((this.itsList[b]).itsIsInteger) {
          if (paramBoolean && l == (this.itsList[b]).itsLValue)
            return b; 
        } else if (!paramBoolean && d == (this.itsList[b]).itsDValue) {
          return b;
        }  
    } 
    if (this.itsTop == this.itsList.length) {
      ConstantDude[] arrayOfConstantDude = new ConstantDude[this.itsList.length * 2];
      System.arraycopy(this.itsList, 0, arrayOfConstantDude, 0, this.itsList.length);
      this.itsList = arrayOfConstantDude;
    } 
    if (paramBoolean) {
      this.itsList[this.itsTop] = new ConstantDude(paramString1, paramString2, l);
    } else {
      this.itsList[this.itsTop] = new ConstantDude(paramString1, paramString2, d);
    } 
    return this.itsTop++;
  }
  
  ConstantDude[] itsList = new ConstantDude[128];
  
  int itsTop;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\ConstantList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */