package org.mozilla.javascript.optimizer;

class DataFlowBitSet {
  private int[] itsBits;
  
  int itsSize;
  
  DataFlowBitSet(int paramInt) {
    this.itsSize = paramInt;
    this.itsBits = new int[(paramInt >> 5) + 1];
  }
  
  int size() { return this.itsSize; }
  
  void set(int paramInt) {
    if (paramInt < 0 || paramInt >= this.itsSize)
      throw new RuntimeException("DataFlowBitSet bad index " + paramInt); 
    this.itsBits[paramInt >> 5] = this.itsBits[paramInt >> 5] | 1 << (paramInt & 0x1F);
  }
  
  boolean test(int paramInt) {
    if (paramInt < 0 || paramInt >= this.itsSize)
      throw new RuntimeException("DataFlowBitSet bad index " + paramInt); 
    return !((this.itsBits[paramInt >> 5] & 1 << (paramInt & 0x1F)) == 0);
  }
  
  void not() {
    int i = this.itsBits.length;
    for (byte b = 0; b < i; b++)
      this.itsBits[b] = this.itsBits[b] ^ 0xFFFFFFFF; 
  }
  
  void clear(int paramInt) {
    if (paramInt < 0 || paramInt >= this.itsSize)
      throw new RuntimeException("DataFlowBitSet bad index " + paramInt); 
    this.itsBits[paramInt >> 5] = this.itsBits[paramInt >> 5] & (1 << (paramInt & 0x1F) ^ 0xFFFFFFFF);
  }
  
  void clear() {
    int i = this.itsBits.length;
    for (byte b = 0; b < i; b++)
      this.itsBits[b] = 0; 
  }
  
  void or(DataFlowBitSet paramDataFlowBitSet) {
    int i = this.itsBits.length;
    for (byte b = 0; b < i; b++)
      this.itsBits[b] = this.itsBits[b] | paramDataFlowBitSet.itsBits[b]; 
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("DataFlowBitSet, size = " + this.itsSize + "\n");
    for (byte b = 0; b < this.itsBits.length; b++)
      stringBuffer.append(String.valueOf(Integer.toHexString(this.itsBits[b])) + " "); 
    return stringBuffer.toString();
  }
  
  boolean df(DataFlowBitSet paramDataFlowBitSet1, DataFlowBitSet paramDataFlowBitSet2, DataFlowBitSet paramDataFlowBitSet3) {
    int i = this.itsBits.length;
    boolean bool = false;
    for (byte b = 0; b < i; b++) {
      int j = this.itsBits[b];
      this.itsBits[b] = (paramDataFlowBitSet1.itsBits[b] | paramDataFlowBitSet2.itsBits[b]) & paramDataFlowBitSet3.itsBits[b];
      bool |= ((j == this.itsBits[b]) ? 0 : 1);
    } 
    return bool;
  }
  
  boolean df2(DataFlowBitSet paramDataFlowBitSet1, DataFlowBitSet paramDataFlowBitSet2, DataFlowBitSet paramDataFlowBitSet3) {
    int i = this.itsBits.length;
    boolean bool = false;
    for (byte b = 0; b < i; b++) {
      int j = this.itsBits[b];
      this.itsBits[b] = paramDataFlowBitSet1.itsBits[b] & paramDataFlowBitSet3.itsBits[b] | paramDataFlowBitSet2.itsBits[b];
      bool |= ((j == this.itsBits[b]) ? 0 : 1);
    } 
    return bool;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\DataFlowBitSet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */