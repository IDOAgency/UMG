/*     */ package org.mozilla.javascript.optimizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DataFlowBitSet
/*     */ {
/*     */   private int[] itsBits;
/*     */   int itsSize;
/*     */   
/*     */   DataFlowBitSet(int paramInt) {
/*  47 */     this.itsSize = paramInt;
/*  48 */     this.itsBits = new int[(paramInt >> 5) + 1];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  53 */   int size() { return this.itsSize; }
/*     */ 
/*     */ 
/*     */   
/*     */   void set(int paramInt) {
/*  58 */     if (paramInt < 0 || paramInt >= this.itsSize)
/*  59 */       throw new RuntimeException("DataFlowBitSet bad index " + paramInt); 
/*  60 */     this.itsBits[paramInt >> 5] = this.itsBits[paramInt >> 5] | 1 << (paramInt & 0x1F);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean test(int paramInt) {
/*  65 */     if (paramInt < 0 || paramInt >= this.itsSize)
/*  66 */       throw new RuntimeException("DataFlowBitSet bad index " + paramInt); 
/*  67 */     return !((this.itsBits[paramInt >> 5] & 1 << (paramInt & 0x1F)) == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   void not() {
/*  72 */     int i = this.itsBits.length;
/*  73 */     for (byte b = 0; b < i; b++) {
/*  74 */       this.itsBits[b] = this.itsBits[b] ^ 0xFFFFFFFF;
/*     */     }
/*     */   }
/*     */   
/*     */   void clear(int paramInt) {
/*  79 */     if (paramInt < 0 || paramInt >= this.itsSize)
/*  80 */       throw new RuntimeException("DataFlowBitSet bad index " + paramInt); 
/*  81 */     this.itsBits[paramInt >> 5] = this.itsBits[paramInt >> 5] & (1 << (paramInt & 0x1F) ^ 0xFFFFFFFF);
/*     */   }
/*     */ 
/*     */   
/*     */   void clear() {
/*  86 */     int i = this.itsBits.length;
/*  87 */     for (byte b = 0; b < i; b++) {
/*  88 */       this.itsBits[b] = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   void or(DataFlowBitSet paramDataFlowBitSet) {
/*  93 */     int i = this.itsBits.length;
/*  94 */     for (byte b = 0; b < i; b++) {
/*  95 */       this.itsBits[b] = this.itsBits[b] | paramDataFlowBitSet.itsBits[b];
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 100 */     StringBuffer stringBuffer = new StringBuffer();
/* 101 */     stringBuffer.append("DataFlowBitSet, size = " + this.itsSize + "\n");
/* 102 */     for (byte b = 0; b < this.itsBits.length; b++)
/* 103 */       stringBuffer.append(String.valueOf(Integer.toHexString(this.itsBits[b])) + " "); 
/* 104 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean df(DataFlowBitSet paramDataFlowBitSet1, DataFlowBitSet paramDataFlowBitSet2, DataFlowBitSet paramDataFlowBitSet3) {
/* 109 */     int i = this.itsBits.length;
/* 110 */     boolean bool = false;
/* 111 */     for (byte b = 0; b < i; b++) {
/* 112 */       int j = this.itsBits[b];
/* 113 */       this.itsBits[b] = (paramDataFlowBitSet1.itsBits[b] | paramDataFlowBitSet2.itsBits[b]) & paramDataFlowBitSet3.itsBits[b];
/* 114 */       bool |= ((j == this.itsBits[b]) ? 0 : 1);
/*     */     } 
/* 116 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean df2(DataFlowBitSet paramDataFlowBitSet1, DataFlowBitSet paramDataFlowBitSet2, DataFlowBitSet paramDataFlowBitSet3) {
/* 121 */     int i = this.itsBits.length;
/* 122 */     boolean bool = false;
/* 123 */     for (byte b = 0; b < i; b++) {
/* 124 */       int j = this.itsBits[b];
/* 125 */       this.itsBits[b] = paramDataFlowBitSet1.itsBits[b] & paramDataFlowBitSet3.itsBits[b] | paramDataFlowBitSet2.itsBits[b];
/* 126 */       bool |= ((j == this.itsBits[b]) ? 0 : 1);
/*     */     } 
/* 128 */     return bool;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\DataFlowBitSet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */