package org.mozilla.javascript.optimizer;

import org.mozilla.javascript.ClassNameHelper;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.IRFactory;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.TokenStream;

public class OptIRFactory extends IRFactory {
  private ClassNameHelper nameHelper;
  
  public OptIRFactory(TokenStream paramTokenStream, ClassNameHelper paramClassNameHelper, Scriptable paramScriptable) {
    super(paramTokenStream, paramScriptable);
    this.nameHelper = paramClassNameHelper;
  }
  
  public Object createFunctionNode(String paramString, Object paramObject1, Object paramObject2) {
    if (paramString == null)
      paramString = ""; 
    OptFunctionNode optFunctionNode = new OptFunctionNode(paramString, (Node)paramObject1, 
        (Node)paramObject2, 
        this.nameHelper);
    Context context = Context.getCurrentContext();
    if (context != null && context.getDebugLevel() > 0)
      optFunctionNode.setRequiresActivation(true); 
    return optFunctionNode;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\OptIRFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */