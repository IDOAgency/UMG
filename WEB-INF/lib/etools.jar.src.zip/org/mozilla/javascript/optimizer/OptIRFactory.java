/*    */ package org.mozilla.javascript.optimizer;
/*    */ 
/*    */ import org.mozilla.javascript.ClassNameHelper;
/*    */ import org.mozilla.javascript.Context;
/*    */ import org.mozilla.javascript.IRFactory;
/*    */ import org.mozilla.javascript.Node;
/*    */ import org.mozilla.javascript.Scriptable;
/*    */ import org.mozilla.javascript.TokenStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptIRFactory
/*    */   extends IRFactory
/*    */ {
/*    */   private ClassNameHelper nameHelper;
/*    */   
/*    */   public OptIRFactory(TokenStream paramTokenStream, ClassNameHelper paramClassNameHelper, Scriptable paramScriptable) {
/* 50 */     super(paramTokenStream, paramScriptable);
/* 51 */     this.nameHelper = paramClassNameHelper;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object createFunctionNode(String paramString, Object paramObject1, Object paramObject2) {
/* 57 */     if (paramString == null)
/* 58 */       paramString = ""; 
/* 59 */     OptFunctionNode optFunctionNode = new OptFunctionNode(paramString, (Node)paramObject1, 
/* 60 */         (Node)paramObject2, 
/* 61 */         this.nameHelper);
/* 62 */     Context context = Context.getCurrentContext();
/* 63 */     if (context != null && context.getDebugLevel() > 0)
/* 64 */       optFunctionNode.setRequiresActivation(true); 
/* 65 */     return optFunctionNode;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\OptIRFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */