package org.mozilla.javascript.optimizer;

import java.io.File;
import org.mozilla.javascript.ClassNameHelper;

public class OptClassNameHelper implements ClassNameHelper {
  private String generatingDirectory;
  
  public String getGeneratingDirectory() { return this.generatingDirectory; }
  
  public String getJavaScriptClassName(String paramString, boolean paramBoolean) {
    StringBuffer stringBuffer = new StringBuffer();
    if (this.packageName != null && this.packageName.length() > 0) {
      stringBuffer.append(this.packageName);
      stringBuffer.append('.');
    } 
    stringBuffer.append(this.initialName);
    if (this.generatingDirectory != null) {
      if (paramString != null) {
        stringBuffer.append('$');
        stringBuffer.append(paramString);
      } else if (!paramBoolean) {
        stringBuffer.append(++this.serial);
      } 
    } else {
      stringBuffer.append(globalSerial++);
    } 
    return stringBuffer.toString();
  }
  
  public String getTargetClassFileName() { return getTargetClassFileName(getInitialClassName()); }
  
  public void setTargetClassFileName(String paramString) {
    String str;
    int i = paramString.lastIndexOf(File.separatorChar);
    if (i == -1) {
      this.generatingDirectory = "";
      str = paramString;
    } else {
      this.generatingDirectory = paramString.substring(0, i);
      str = paramString.substring(i + 1);
    } 
    if (str.endsWith(".class"))
      str = str.substring(0, str.length() - 6); 
    setInitialClassName(str);
  }
  
  public String getTargetPackage() { return this.packageName; }
  
  public void setTargetPackage(String paramString) { this.packageName = paramString; }
  
  public String getTargetClassFileName(String paramString) {
    if (this.generatingDirectory == null)
      return null; 
    StringBuffer stringBuffer = new StringBuffer();
    if (this.generatingDirectory.length() > 0) {
      stringBuffer.append(this.generatingDirectory);
      stringBuffer.append(File.separator);
    } 
    stringBuffer.append(paramString);
    stringBuffer.append(".class");
    return stringBuffer.toString();
  }
  
  public Class getTargetExtends() { return this.targetExtends; }
  
  public void setTargetExtends(Class paramClass) { this.targetExtends = paramClass; }
  
  public Class[] getTargetImplements() { return this.targetImplements; }
  
  public void setTargetImplements(Class[] paramArrayOfClass) { this.targetImplements = paramArrayOfClass; }
  
  String getInitialClassName() { return this.initialName; }
  
  void setInitialClassName(String paramString) {
    this.initialName = paramString;
    this.serial = 0;
  }
  
  private String packageName = "org.mozilla.javascript.gen";
  
  private String initialName = "c";
  
  private static int globalSerial = 1;
  
  private int serial = 1;
  
  private Class targetExtends;
  
  private Class[] targetImplements;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\OptClassNameHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */