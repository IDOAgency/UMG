/*     */ package org.mozilla.javascript.optimizer;
/*     */ 
/*     */ import java.io.File;
/*     */ import org.mozilla.javascript.ClassNameHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptClassNameHelper
/*     */   implements ClassNameHelper
/*     */ {
/*     */   private String generatingDirectory;
/*     */   
/*  45 */   public String getGeneratingDirectory() { return this.generatingDirectory; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJavaScriptClassName(String paramString, boolean paramBoolean) {
/*  51 */     StringBuffer stringBuffer = new StringBuffer();
/*  52 */     if (this.packageName != null && this.packageName.length() > 0) {
/*  53 */       stringBuffer.append(this.packageName);
/*  54 */       stringBuffer.append('.');
/*     */     } 
/*  56 */     stringBuffer.append(this.initialName);
/*  57 */     if (this.generatingDirectory != null) {
/*  58 */       if (paramString != null) {
/*  59 */         stringBuffer.append('$');
/*  60 */         stringBuffer.append(paramString);
/*  61 */       } else if (!paramBoolean) {
/*  62 */         stringBuffer.append(++this.serial);
/*     */       } 
/*     */     } else {
/*  65 */       stringBuffer.append(globalSerial++);
/*     */     } 
/*  67 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/*  71 */   public String getTargetClassFileName() { return getTargetClassFileName(getInitialClassName()); }
/*     */   
/*     */   public void setTargetClassFileName(String paramString) {
/*     */     String str;
/*  75 */     int i = paramString.lastIndexOf(File.separatorChar);
/*     */     
/*  77 */     if (i == -1) {
/*  78 */       this.generatingDirectory = "";
/*  79 */       str = paramString;
/*     */     } else {
/*  81 */       this.generatingDirectory = paramString.substring(0, i);
/*  82 */       str = paramString.substring(i + 1);
/*     */     } 
/*  84 */     if (str.endsWith(".class"))
/*  85 */       str = str.substring(0, str.length() - 6); 
/*  86 */     setInitialClassName(str);
/*     */   }
/*     */ 
/*     */   
/*  90 */   public String getTargetPackage() { return this.packageName; }
/*     */ 
/*     */ 
/*     */   
/*  94 */   public void setTargetPackage(String paramString) { this.packageName = paramString; }
/*     */ 
/*     */   
/*     */   public String getTargetClassFileName(String paramString) {
/*  98 */     if (this.generatingDirectory == null)
/*  99 */       return null; 
/* 100 */     StringBuffer stringBuffer = new StringBuffer();
/* 101 */     if (this.generatingDirectory.length() > 0) {
/* 102 */       stringBuffer.append(this.generatingDirectory);
/* 103 */       stringBuffer.append(File.separator);
/*     */     } 
/* 105 */     stringBuffer.append(paramString);
/* 106 */     stringBuffer.append(".class");
/* 107 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/* 111 */   public Class getTargetExtends() { return this.targetExtends; }
/*     */ 
/*     */ 
/*     */   
/* 115 */   public void setTargetExtends(Class paramClass) { this.targetExtends = paramClass; }
/*     */ 
/*     */ 
/*     */   
/* 119 */   public Class[] getTargetImplements() { return this.targetImplements; }
/*     */ 
/*     */ 
/*     */   
/* 123 */   public void setTargetImplements(Class[] paramArrayOfClass) { this.targetImplements = paramArrayOfClass; }
/*     */ 
/*     */ 
/*     */   
/* 127 */   String getInitialClassName() { return this.initialName; }
/*     */ 
/*     */   
/*     */   void setInitialClassName(String paramString) {
/* 131 */     this.initialName = paramString;
/* 132 */     this.serial = 0;
/*     */   }
/*     */ 
/*     */   
/* 136 */   private String packageName = "org.mozilla.javascript.gen";
/* 137 */   private String initialName = "c";
/* 138 */   private static int globalSerial = 1;
/* 139 */   private int serial = 1;
/*     */   private Class targetExtends;
/*     */   private Class[] targetImplements;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\OptClassNameHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */