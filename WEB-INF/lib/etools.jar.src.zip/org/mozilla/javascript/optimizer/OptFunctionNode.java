/*     */ package org.mozilla.javascript.optimizer;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import org.mozilla.javascript.ClassNameHelper;
/*     */ import org.mozilla.javascript.FunctionNode;
/*     */ import org.mozilla.javascript.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptFunctionNode
/*     */   extends FunctionNode
/*     */ {
/*     */   private String itsClassName;
/*     */   private boolean itsIsTargetOfDirectCall;
/*     */   private boolean itsContainsCalls;
/*     */   private boolean[] itsContainsCallsCount;
/*     */   private boolean itsParameterNumberContext;
/*     */   private Vector itsDirectCallTargets;
/*     */   
/*     */   public OptFunctionNode(String paramString, Node paramNode1, Node paramNode2, ClassNameHelper paramClassNameHelper) {
/*  47 */     super(paramString, paramNode1, paramNode2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     this.itsContainsCallsCount = new boolean[4];
/*     */     this.itsVariableTable = new OptVariableTable();
/*     */     OptClassNameHelper optClassNameHelper = (OptClassNameHelper)paramClassNameHelper;
/*     */     this.itsClassName = optClassNameHelper.getJavaScriptClassName(paramString, false);
/*     */   }
/*     */   
/*     */   public String getDirectCallParameterSignature() {
/*     */     StringBuffer stringBuffer = new StringBuffer("(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;");
/*     */     int i = this.itsVariableTable.getParameterCount();
/*     */     for (byte b = 0; b < i; b++)
/*     */       stringBuffer.append("Ljava/lang/Object;D"); 
/*     */     stringBuffer.append("[Ljava/lang/Object;)");
/*     */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public String getClassName() { return this.itsClassName; }
/*     */   
/*     */   public boolean isTargetOfDirectCall() { return this.itsIsTargetOfDirectCall; }
/*     */   
/*     */   public void addDirectCallTarget(FunctionNode paramFunctionNode) {
/*     */     if (this.itsDirectCallTargets == null)
/*     */       this.itsDirectCallTargets = new Vector(); 
/*     */     for (byte b = 0; b < this.itsDirectCallTargets.size(); b++) {
/*     */       if ((FunctionNode)this.itsDirectCallTargets.elementAt(b) == paramFunctionNode)
/*     */         return; 
/*     */     } 
/*     */     this.itsDirectCallTargets.addElement(paramFunctionNode);
/*     */   }
/*     */   
/*     */   public Vector getDirectCallTargets() { return this.itsDirectCallTargets; }
/*     */   
/*     */   public void setIsTargetOfDirectCall() { this.itsIsTargetOfDirectCall = true; }
/*     */   
/*     */   public void setParameterNumberContext(boolean paramBoolean) { this.itsParameterNumberContext = paramBoolean; }
/*     */   
/*     */   public boolean getParameterNumberContext() { return this.itsParameterNumberContext; }
/*     */   
/*     */   public boolean containsCalls(int paramInt) {
/*     */     if (paramInt < this.itsContainsCallsCount.length && paramInt >= 0)
/*     */       return this.itsContainsCallsCount[paramInt]; 
/*     */     return this.itsContainsCalls;
/*     */   }
/*     */   
/*     */   public void setContainsCalls(int paramInt) {
/*     */     if (paramInt < this.itsContainsCallsCount.length)
/*     */       this.itsContainsCallsCount[paramInt] = true; 
/*     */     this.itsContainsCalls = true;
/*     */   }
/*     */   
/*     */   public void incrementLocalCount() {
/*     */     Integer integer = (Integer)getProp(22);
/*     */     if (integer == null) {
/*     */       putProp(22, new Integer(1));
/*     */     } else {
/*     */       putProp(22, new Integer(integer.intValue() + 1));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\OptFunctionNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */