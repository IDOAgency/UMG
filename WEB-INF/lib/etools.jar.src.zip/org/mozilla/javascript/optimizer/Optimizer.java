package org.mozilla.javascript.optimizer;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Vector;
import org.mozilla.javascript.FunctionNode;
import org.mozilla.javascript.IRFactory;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.PreorderNodeIterator;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.VariableTable;

public class Optimizer {
  static final boolean DEBUG_OPTIMIZER = false;
  
  static final boolean DO_CONSTANT_FOLDING = true;
  
  static int blockCount = 0;
  
  boolean inDirectCallFunction;
  
  boolean parameterUsedInNumberContext;
  
  int itsOptLevel;
  
  void optimizeFunction(OptFunctionNode paramOptFunctionNode) {
    if (paramOptFunctionNode.requiresActivation())
      return; 
    this.inDirectCallFunction = paramOptFunctionNode.isTargetOfDirectCall();
    Node[] arrayOfNode = buildStatementList(paramOptFunctionNode);
    Block[] arrayOfBlock = Block.buildBlocks(arrayOfNode);
    Object object = null;
    try {
      OptVariableTable optVariableTable = 
        (OptVariableTable)paramOptFunctionNode.getVariableTable();
      if (optVariableTable != null) {
        optVariableTable.establishIndices();
        for (byte b = 0; b < arrayOfNode.length; b++)
          replaceVariableAccess(arrayOfNode[b], optVariableTable); 
        foldConstants(paramOptFunctionNode, null);
        reachingDefDataFlow(optVariableTable, arrayOfBlock);
        typeFlow(optVariableTable, arrayOfBlock);
        findSinglyTypedVars(optVariableTable, arrayOfBlock);
        localCSE(arrayOfBlock, paramOptFunctionNode);
        if (!paramOptFunctionNode.requiresActivation()) {
          this.parameterUsedInNumberContext = false;
          for (byte b1 = 0; b1 < arrayOfNode.length; b1++)
            rewriteForNumberVariables(arrayOfNode[b1]); 
          paramOptFunctionNode.setParameterNumberContext(this.parameterUsedInNumberContext);
        } 
      } 
    } catch (IOException iOException) {}
  }
  
  public void optimize(Node paramNode, int paramInt) {
    this.itsOptLevel = paramInt;
    PreorderNodeIterator preorderNodeIterator = paramNode.getPreorderIterator();
    Node node;
    while ((node = preorderNodeIterator.nextNode()) != null) {
      if (node.getType() == 109) {
        OptFunctionNode optFunctionNode = 
          (OptFunctionNode)node.getProp(5);
        if (optFunctionNode != null)
          optimizeFunction(optFunctionNode); 
      } 
    } 
  }
  
  void findSinglyTypedVars(VariableTable paramVariableTable, Block[] paramArrayOfBlock) {
    for (byte b = 0; b < paramVariableTable.size(); b++) {
      OptLocalVariable optLocalVariable = (OptLocalVariable)paramVariableTable.get(b);
      if (!optLocalVariable.isParameter()) {
        int i = optLocalVariable.getTypeUnion();
        if (i == 1)
          optLocalVariable.setIsNumber(); 
      } 
    } 
  }
  
  void doBlockLocalCSE(Block[] paramArrayOfBlock, Block paramBlock, Hashtable paramHashtable, boolean[] paramArrayOfBoolean, OptFunctionNode paramOptFunctionNode) {
    if (!paramArrayOfBoolean[paramBlock.getBlockID()]) {
      paramArrayOfBoolean[paramBlock.getBlockID()] = true;
      paramHashtable = paramBlock.localCSE(paramHashtable, paramOptFunctionNode);
      Block[] arrayOfBlock = paramArrayOfBlock[paramBlock.getBlockID()].getSuccessorList();
      if (arrayOfBlock != null)
        for (byte b = 0; b < arrayOfBlock.length; b++) {
          int i = arrayOfBlock[b].getBlockID();
          Block[] arrayOfBlock1 = paramArrayOfBlock[i].getPredecessorList();
          if (arrayOfBlock1.length == 1)
            doBlockLocalCSE(paramArrayOfBlock, arrayOfBlock[b], 
                (Hashtable)paramHashtable.clone(), 
                paramArrayOfBoolean, paramOptFunctionNode); 
        }  
    } 
  }
  
  void localCSE(Block[] paramArrayOfBlock, OptFunctionNode paramOptFunctionNode) {
    boolean[] arrayOfBoolean = new boolean[paramArrayOfBlock.length];
    doBlockLocalCSE(paramArrayOfBlock, paramArrayOfBlock[0], null, arrayOfBoolean, paramOptFunctionNode);
    for (byte b = 0; b < paramArrayOfBlock.length; b++) {
      if (!arrayOfBoolean[b])
        paramArrayOfBlock[b].localCSE(null, paramOptFunctionNode); 
    } 
  }
  
  void typeFlow(VariableTable paramVariableTable, Block[] paramArrayOfBlock) {
    boolean[] arrayOfBoolean1 = new boolean[paramArrayOfBlock.length];
    boolean[] arrayOfBoolean2 = new boolean[paramArrayOfBlock.length];
    byte b = 0;
    boolean bool = false;
    arrayOfBoolean1[b] = true;
    while (true) {
      if (arrayOfBoolean1[b] || !arrayOfBoolean2[b]) {
        arrayOfBoolean2[b] = true;
        arrayOfBoolean1[b] = false;
        if (paramArrayOfBlock[b].doTypeFlow()) {
          Block[] arrayOfBlock = paramArrayOfBlock[b].getSuccessorList();
          if (arrayOfBlock != null)
            for (byte b1 = 0; b1 < arrayOfBlock.length; b1++) {
              int i = arrayOfBlock[b1].getBlockID();
              arrayOfBoolean1[i] = true;
              bool |= ((i >= b) ? 0 : 1);
            }  
        } 
      } 
      if (b == paramArrayOfBlock.length - 1) {
        if (bool) {
          b = 0;
          bool = false;
          continue;
        } 
        break;
      } 
      b++;
    } 
  }
  
  void reachingDefDataFlow(VariableTable paramVariableTable, Block[] paramArrayOfBlock) {
    for (byte b1 = 0; b1 < paramArrayOfBlock.length; b1++)
      paramArrayOfBlock[b1].initLiveOnEntrySets(paramVariableTable); 
    boolean[] arrayOfBoolean1 = new boolean[paramArrayOfBlock.length];
    boolean[] arrayOfBoolean2 = new boolean[paramArrayOfBlock.length];
    int i = paramArrayOfBlock.length - 1;
    boolean bool = false;
    arrayOfBoolean1[i] = true;
    while (true) {
      if (arrayOfBoolean1[i] || !arrayOfBoolean2[i]) {
        arrayOfBoolean2[i] = true;
        arrayOfBoolean1[i] = false;
        if (paramArrayOfBlock[i].doReachedUseDataFlow()) {
          Block[] arrayOfBlock = paramArrayOfBlock[i].getPredecessorList();
          if (arrayOfBlock != null)
            for (byte b = 0; b < arrayOfBlock.length; b++) {
              int j = arrayOfBlock[b].getBlockID();
              arrayOfBoolean1[j] = true;
              bool |= ((j <= i) ? 0 : 1);
            }  
        } 
      } 
      if (i == 0) {
        if (bool) {
          i = paramArrayOfBlock.length - 1;
          bool = false;
          continue;
        } 
        break;
      } 
      i--;
    } 
    for (byte b2 = 0; b2 < paramArrayOfBlock.length; b2++)
      paramArrayOfBlock[b2].markVolatileVariables(paramVariableTable); 
    paramArrayOfBlock[0].markAnyTypeVariables(paramVariableTable);
  }
  
  void markDCPNumberContext(Node paramNode) {
    if (this.inDirectCallFunction && paramNode.getType() == 72) {
      OptLocalVariable optLocalVariable = 
        (OptLocalVariable)paramNode.getProp(24);
      if (optLocalVariable != null && optLocalVariable.isParameter())
        this.parameterUsedInNumberContext = true; 
    } 
  }
  
  boolean convertParameter(Node paramNode) {
    if (this.inDirectCallFunction && paramNode.getType() == 72) {
      OptLocalVariable optLocalVariable = 
        (OptLocalVariable)paramNode.getProp(24);
      if (optLocalVariable != null && optLocalVariable.isParameter()) {
        paramNode.putProp(26, null);
        return true;
      } 
    } 
    return false;
  }
  
  int rewriteForNumberVariables(Node paramNode) {
    int i1, n, m;
    OptLocalVariable optLocalVariable2;
    int j;
    Node node5;
    int k, i;
    Node node4;
    OptLocalVariable optLocalVariable1;
    Node node2;
    FunctionNode functionNode;
    Node node3;
    switch (paramNode.getType()) {
      case 57:
        node3 = paramNode.getFirstChild();
        i = rewriteForNumberVariables(node3);
        if (i == 1)
          paramNode.putProp(26, new Integer(0)); 
        return 0;
      case 45:
        paramNode.putProp(26, new Integer(0));
        return 1;
      case 72:
        optLocalVariable1 = 
          (OptLocalVariable)paramNode.getProp(24);
        if (optLocalVariable1 != null) {
          if (this.inDirectCallFunction && optLocalVariable1.isParameter()) {
            paramNode.putProp(26, new Integer(0));
            return 1;
          } 
          if (optLocalVariable1.isNumber()) {
            paramNode.putProp(26, new Integer(0));
            return 1;
          } 
        } 
        return 0;
      case 105:
      case 106:
        node2 = paramNode.getFirstChild();
        if (node2.getType() == 72) {
          OptLocalVariable optLocalVariable = 
            (OptLocalVariable)node2.getProp(24);
          if (optLocalVariable != null && optLocalVariable.isNumber()) {
            paramNode.putProp(26, new Integer(0));
            markDCPNumberContext(node2);
            return 1;
          } 
          return 0;
        } 
        return 0;
      case 73:
        node2 = paramNode.getFirstChild();
        node4 = node2.getNextSibling();
        k = rewriteForNumberVariables(node4);
        optLocalVariable2 = 
          (OptLocalVariable)paramNode.getProp(24);
        if (this.inDirectCallFunction && optLocalVariable2.isParameter()) {
          if (k == 1) {
            if (!convertParameter(node4)) {
              paramNode.putProp(26, new Integer(0));
              return 1;
            } 
            markDCPNumberContext(node4);
            return 0;
          } 
          return k;
        } 
        if (optLocalVariable2 != null && optLocalVariable2.isNumber()) {
          if (k != 1) {
            paramNode.removeChild(node4);
            Node node = new Node(141, node4);
            node.putProp(18, Double.class);
            paramNode.addChildToBack(node);
          } 
          paramNode.putProp(26, new Integer(0));
          markDCPNumberContext(node4);
          return 1;
        } 
        if (k == 1 && 
          !convertParameter(node4)) {
          paramNode.removeChild(node4);
          Node node = new Node(141, node4);
          node.putProp(18, Object.class);
          paramNode.addChildToBack(node);
        } 
        return 0;
      case 102:
        node2 = paramNode.getFirstChild();
        node4 = node2.getNextSibling();
        k = rewriteForNumberVariables(node2);
        m = rewriteForNumberVariables(node4);
        markDCPNumberContext(node2);
        markDCPNumberContext(node4);
        if (paramNode.getInt() == 64 || 
          paramNode.getInt() == 63) {
          if (k == 1 && 
            !convertParameter(node2)) {
            paramNode.removeChild(node2);
            Node node = new Node(141, node2);
            node.putProp(18, Object.class);
            paramNode.addChildToFront(node);
          } 
          if (m == 1 && 
            !convertParameter(node4)) {
            paramNode.removeChild(node4);
            Node node = new Node(141, node4);
            node.putProp(18, Object.class);
            paramNode.addChildToBack(node);
          } 
        } else if (convertParameter(node2)) {
          if (convertParameter(node4))
            return 0; 
          if (m == 1)
            paramNode.putProp(26, 
                new Integer(2)); 
        } else if (convertParameter(node4)) {
          if (k == 1)
            paramNode.putProp(26, 
                new Integer(1)); 
        } else if (k == 1) {
          if (m == 1) {
            paramNode.putProp(26, 
                new Integer(0));
          } else {
            paramNode.putProp(26, 
                new Integer(1));
          } 
        } else if (m == 1) {
          paramNode.putProp(26, 
              new Integer(2));
        } 
        return 0;
      case 23:
        node2 = paramNode.getFirstChild();
        node4 = node2.getNextSibling();
        k = rewriteForNumberVariables(node2);
        m = rewriteForNumberVariables(node4);
        if (convertParameter(node2)) {
          if (convertParameter(node4))
            return 0; 
          if (m == 1)
            paramNode.putProp(26, new Integer(2)); 
        } else if (convertParameter(node4)) {
          if (k == 1)
            paramNode.putProp(26, new Integer(1)); 
        } else if (k == 1) {
          if (m == 1) {
            paramNode.putProp(26, new Integer(0));
            return 1;
          } 
          paramNode.putProp(26, new Integer(1));
        } else if (m == 1) {
          paramNode.putProp(26, new Integer(2));
        } 
        return 0;
      case 11:
      case 12:
      case 13:
      case 20:
      case 21:
      case 24:
      case 25:
      case 26:
      case 27:
        node2 = paramNode.getFirstChild();
        node4 = node2.getNextSibling();
        k = rewriteForNumberVariables(node2);
        m = rewriteForNumberVariables(node4);
        markDCPNumberContext(node2);
        markDCPNumberContext(node4);
        if (k == 1) {
          if (m == 1) {
            paramNode.putProp(26, 
                new Integer(0));
            return 1;
          } 
          if (!convertParameter(node4)) {
            paramNode.removeChild(node4);
            Node node = new Node(141, node4);
            node.putProp(18, Double.class);
            paramNode.addChildToBack(node);
            paramNode.putProp(26, 
                new Integer(0));
          } 
          return 1;
        } 
        if (m == 1) {
          if (!convertParameter(node2)) {
            paramNode.removeChild(node2);
            Node node = new Node(141, node2);
            node.putProp(18, Double.class);
            paramNode.addChildToFront(node);
            paramNode.putProp(26, 
                new Integer(0));
          } 
          return 1;
        } 
        if (!convertParameter(node2)) {
          paramNode.removeChild(node2);
          Node node = new Node(141, node2);
          node.putProp(18, Double.class);
          paramNode.addChildToFront(node);
        } 
        if (!convertParameter(node4)) {
          paramNode.removeChild(node4);
          Node node = new Node(141, node4);
          node.putProp(18, Double.class);
          paramNode.addChildToBack(node);
        } 
        paramNode.putProp(26, 
            new Integer(0));
        return 1;
      case 42:
        node2 = paramNode.getFirstChild();
        node4 = node2.getNextSibling();
        node5 = node4.getNextSibling();
        m = rewriteForNumberVariables(node2);
        if (m == 1 && 
          !convertParameter(node2)) {
          paramNode.removeChild(node2);
          Node node = new Node(141, node2);
          node.putProp(18, Object.class);
          paramNode.addChildToFront(node);
        } 
        n = rewriteForNumberVariables(node4);
        if (n == 1) {
          paramNode.putProp(26, new Integer(1));
          markDCPNumberContext(node4);
        } 
        i1 = rewriteForNumberVariables(node5);
        if (i1 == 1 && 
          !convertParameter(node5)) {
          paramNode.removeChild(node5);
          Node node = new Node(141, node5);
          node.putProp(18, Object.class);
          paramNode.addChildToBack(node);
        } 
        return 0;
      case 41:
        node2 = paramNode.getFirstChild();
        node4 = node2.getNextSibling();
        j = rewriteForNumberVariables(node2);
        if (j == 1 && 
          !convertParameter(node2)) {
          paramNode.removeChild(node2);
          Node node = new Node(141, node2);
          node.putProp(18, Object.class);
          paramNode.addChildToFront(node);
        } 
        m = rewriteForNumberVariables(node4);
        if (m == 1) {
          paramNode.putProp(26, new Integer(2));
          markDCPNumberContext(node4);
        } 
        return 0;
      case 43:
        functionNode = 
          (FunctionNode)paramNode.getProp(27);
        if (functionNode != null) {
          node4 = paramNode.getFirstChild();
          rewriteForNumberVariables(node4);
          node4 = node4.getNextSibling();
          rewriteForNumberVariables(node4);
          node4 = node4.getNextSibling();
          while (node4 != null) {
            j = rewriteForNumberVariables(node4);
            if (j == 1)
              markDCPNumberContext(node4); 
            node4 = node4.getNextSibling();
          } 
          return 0;
        } 
        break;
    } 
    Node node1 = paramNode.getFirstChild();
    while (node1 != null) {
      node4 = node1.getNextSibling();
      j = rewriteForNumberVariables(node1);
      if (j == 1 && 
        !convertParameter(node1)) {
        paramNode.removeChild(node1);
        Node node = new Node(141, node1);
        node.putProp(18, Object.class);
        if (node4 == null) {
          paramNode.addChildToBack(node);
        } else {
          paramNode.addChildBefore(node, node4);
        } 
      } 
      node1 = node4;
    } 
    return 0;
  }
  
  void foldConstants(Node paramNode1, Node paramNode2) {
    Node node2 = null;
    Node node1 = paramNode1.getFirstChild();
    if (node1 == null)
      return; 
    node2 = node1.getNextSibling();
    if (node2 == null) {
      foldConstants(node1, paramNode1);
      return;
    } 
    foldConstants(node1, paramNode1);
    foldConstants(node2, paramNode1);
    Node node3 = node2.getNextSibling();
    while (node3 != null) {
      foldConstants(node3, paramNode1);
      node3 = node3.getNextSibling();
    } 
    node1 = paramNode1.getFirstChild();
    if (node1 == null)
      return; 
    node2 = node1.getNextSibling();
    if (node2 == null)
      return; 
    int i = node1.getType();
    int j = node2.getType();
    switch (paramNode1.getType()) {
      case 23:
        if (i == 45 && j == 45) {
          if (node1.getDatum() instanceof Double || 
            node2.getDatum() instanceof Double) {
            paramNode2.replaceChild(paramNode1, new Node(45, 
                  new Double(node1.getDouble() + node2.getDouble())));
            break;
          } 
          long l = node1.getLong() + node2.getLong();
          paramNode2.replaceChild(paramNode1, new Node(45, 
                toSmallestType(l)));
          break;
        } 
        if (i == 46 && j == 46) {
          paramNode2.replaceChild(paramNode1, new Node(46, 
                String.valueOf(node1.getString()) + node2.getString()));
          break;
        } 
        if (i == 46 && j == 45) {
          paramNode2.replaceChild(paramNode1, new Node(46, String.valueOf(node1.getString()) + 
                ScriptRuntime.numberToString(node2.getDouble(), 10)));
          break;
        } 
        if (i == 45 && j == 46)
          paramNode2.replaceChild(paramNode1, new Node(46, 
                String.valueOf(ScriptRuntime.numberToString(node1.getDouble(), 10)) + 
                node2.getString())); 
        break;
      case 24:
        if (i == 45 && j == 45) {
          if (node1.getDatum() instanceof Double || node2.getDatum() instanceof Double) {
            paramNode2.replaceChild(paramNode1, new Node(45, 
                  new Double(node1.getDouble() - 
                    node2.getDouble())));
            break;
          } 
          long l = node1.getLong() - node2.getLong();
          paramNode2.replaceChild(paramNode1, new Node(45, 
                toSmallestType(l)));
          break;
        } 
        if (i == 45 && node1.getDouble() == 0.0D) {
          paramNode2.replaceChild(paramNode1, new Node(104, node2, 
                new Integer(24)));
          break;
        } 
        if (j == 45 && node2.getDouble() == 0.0D)
          paramNode2.replaceChild(paramNode1, node1); 
        break;
      case 25:
        if (i == 45 && j == 45) {
          if (node1.getDatum() instanceof Double || node2.getDatum() instanceof Double) {
            paramNode2.replaceChild(paramNode1, new Node(45, 
                  new Double(node1.getDouble() * 
                    node2.getDouble())));
            break;
          } 
          long l = 
            node1.getLong() * 
            node2.getLong();
          paramNode2.replaceChild(paramNode1, new Node(45, 
                toSmallestType(l)));
          break;
        } 
        if (i == 45) {
          double d = ((Number)node1.getDatum()).doubleValue();
          if (d == 1.0D)
            paramNode2.replaceChild(paramNode1, node2); 
          break;
        } 
        if (j == 45) {
          double d = ((Number)node2.getDatum()).doubleValue();
          if (d == 1.0D)
            paramNode2.replaceChild(paramNode1, node1); 
        } 
        break;
      case 26:
        if (i == 45 && j == 45) {
          if (node1.getDatum() instanceof Double || node2.getDatum() instanceof Double) {
            double d = node2.getDouble();
            if (d == 0.0D)
              return; 
            paramNode2.replaceChild(paramNode1, new Node(45, 
                  new Double(node1.getDouble() / d)));
            break;
          } 
          int k = node2.getInt();
          if (k == 0)
            return; 
          long l = 
            node1.getLong() / 
            node2.getLong();
          paramNode2.replaceChild(paramNode1, new Node(45, 
                toSmallestType(l)));
          break;
        } 
        if (j == 45 && 
          node2.getDouble() == 1.0D)
          paramNode2.replaceChild(paramNode1, node1); 
        break;
      case 100:
        if (((i == 108 && node1.getInt() == 49) || (
          i == 108 && node1.getInt() == 74)) && 
          !IRFactory.hasSideEffects(node2)) {
          paramNode2.replaceChild(paramNode1, new Node(108, new Integer(51)));
          break;
        } 
        if (((j == 108 && node2.getInt() == 49) || (
          j == 108 && node2.getInt() == 74)) && 
          !IRFactory.hasSideEffects(node1)) {
          paramNode2.replaceChild(paramNode1, new Node(108, new Integer(51)));
          break;
        } 
        if ((i == 108 && ((Integer)node1.getDatum()).intValue() == 52) || (
          i == 45 && ((Number)node1.getDatum()).doubleValue() != 0.0D)) {
          paramNode2.replaceChild(paramNode1, node2);
          break;
        } 
        if ((j == 108 && ((Integer)node2.getDatum()).intValue() == 52) || (
          j == 45 && ((Number)node2.getDatum()).doubleValue() != 0.0D))
          paramNode2.replaceChild(paramNode1, node1); 
        break;
      case 99:
        if ((i == 108 && node1.getInt() == 49) || (
          i == 108 && node1.getInt() == 74) || (
          i == 108 && node1.getInt() == 51) || (
          i == 45 && ((Number)node1.getDatum()).doubleValue() == 0.0D)) {
          paramNode2.replaceChild(paramNode1, node2);
          break;
        } 
        if ((j == 108 && node2.getInt() == 49) || (
          j == 108 && node2.getInt() == 74) || (
          j == 108 && node2.getInt() == 51) || (
          j == 45 && ((Number)node2.getDatum()).doubleValue() == 0.0D)) {
          paramNode2.replaceChild(paramNode1, node1);
          break;
        } 
        if (((i == 108 && ((Integer)node1.getDatum()).intValue() == 52) || (
          i == 45 && ((Number)node1.getDatum()).doubleValue() != 0.0D)) && 
          !IRFactory.hasSideEffects(node2)) {
          paramNode2.replaceChild(paramNode1, new Node(108, new Integer(52)));
          break;
        } 
        if (((j == 108 && ((Integer)node2.getDatum()).intValue() == 52) || (
          j == 45 && ((Number)node2.getDatum()).doubleValue() != 0.0D)) && 
          !IRFactory.hasSideEffects(node1))
          paramNode2.replaceChild(paramNode1, new Node(108, new Integer(52))); 
        break;
      case 132:
        if (node1.getType() == 8) {
          Node node = node1.getFirstChild();
          if (node.getType() == 108) {
            int k = node.getInt();
            if (k == 51 || k == 49 || k == 74) {
              Node node4 = null;
              try {
                node4 = 
                  node2.getNextSibling().getNextSibling().getNextSibling().getFirstChild();
              } catch (Exception exception) {
                return;
              } 
              if (node4 != null)
                paramNode2.replaceChild(paramNode1, node4); 
              break;
            } 
            if ((node.getType() == 108 && node.getInt() == 52) || (
              node.getType() == 45 && ((Number)node.getDatum()).doubleValue() != 0.0D))
              if (node2.getType() == 132)
                paramNode2.replaceChild(paramNode1, node2.getFirstChild());  
          } 
        } 
        break;
    } 
  }
  
  private static Number toSmallestType(long paramLong) {
    if (paramLong >= -128L && paramLong <= 127L)
      return new Byte((byte)(int)paramLong); 
    if (paramLong >= -32768L && 
      paramLong <= 32767L)
      return new Short((short)(int)paramLong); 
    if (paramLong >= -2147483648L && 
      paramLong <= 2147483647L)
      return new Integer((int)paramLong); 
    return new Double(paramLong);
  }
  
  void replaceVariableAccess(Node paramNode, VariableTable paramVariableTable) {
    OptLocalVariable optLocalVariable;
    String str;
    Node node = paramNode.getFirstChild();
    while (node != null) {
      replaceVariableAccess(node, paramVariableTable);
      node = node.getNextSibling();
    } 
    switch (paramNode.getType()) {
      case 73:
        str = paramNode.getFirstChild().getString();
        optLocalVariable = 
          (OptLocalVariable)paramVariableTable.get(str);
        if (optLocalVariable != null)
          paramNode.putProp(24, optLocalVariable); 
        break;
      case 72:
        str = paramNode.getString();
        optLocalVariable = 
          (OptLocalVariable)paramVariableTable.get(str);
        if (optLocalVariable != null)
          paramNode.putProp(24, optLocalVariable); 
        break;
    } 
  }
  
  private Node[] buildStatementList(FunctionNode paramFunctionNode) {
    Vector vector = new Vector();
    StmtNodeIterator stmtNodeIterator = new StmtNodeIterator(paramFunctionNode);
    Node node = stmtNodeIterator.nextNode();
    while (node != null) {
      vector.addElement(node);
      node = stmtNodeIterator.nextNode();
    } 
    Node[] arrayOfNode = new Node[vector.size()];
    for (byte b = 0; b < vector.size(); b++)
      arrayOfNode[b] = (Node)vector.elementAt(b); 
    return arrayOfNode;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\Optimizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */