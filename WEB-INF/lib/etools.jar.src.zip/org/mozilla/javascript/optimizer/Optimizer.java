/*      */ package org.mozilla.javascript.optimizer;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ import org.mozilla.javascript.FunctionNode;
/*      */ import org.mozilla.javascript.IRFactory;
/*      */ import org.mozilla.javascript.Node;
/*      */ import org.mozilla.javascript.PreorderNodeIterator;
/*      */ import org.mozilla.javascript.ScriptRuntime;
/*      */ import org.mozilla.javascript.VariableTable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Optimizer
/*      */ {
/*      */   static final boolean DEBUG_OPTIMIZER = false;
/*      */   static final boolean DO_CONSTANT_FOLDING = true;
/*   60 */   static int blockCount = 0;
/*      */   
/*      */   boolean inDirectCallFunction;
/*      */   boolean parameterUsedInNumberContext;
/*      */   int itsOptLevel;
/*      */   
/*      */   void optimizeFunction(OptFunctionNode paramOptFunctionNode) {
/*   67 */     if (paramOptFunctionNode.requiresActivation())
/*      */       return; 
/*   69 */     this.inDirectCallFunction = paramOptFunctionNode.isTargetOfDirectCall();
/*      */     
/*   71 */     Node[] arrayOfNode = buildStatementList(paramOptFunctionNode);
/*   72 */     Block[] arrayOfBlock = Block.buildBlocks(arrayOfNode);
/*   73 */     Object object = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*   84 */       OptVariableTable optVariableTable = 
/*   85 */         (OptVariableTable)paramOptFunctionNode.getVariableTable();
/*   86 */       if (optVariableTable != null)
/*      */       {
/*   88 */         optVariableTable.establishIndices();
/*   89 */         for (byte b = 0; b < arrayOfNode.length; b++) {
/*   90 */           replaceVariableAccess(arrayOfNode[b], optVariableTable);
/*      */         }
/*      */         
/*   93 */         foldConstants(paramOptFunctionNode, null);
/*      */ 
/*      */         
/*   96 */         reachingDefDataFlow(optVariableTable, arrayOfBlock);
/*   97 */         typeFlow(optVariableTable, arrayOfBlock);
/*   98 */         findSinglyTypedVars(optVariableTable, arrayOfBlock);
/*   99 */         localCSE(arrayOfBlock, paramOptFunctionNode);
/*  100 */         if (!paramOptFunctionNode.requiresActivation())
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  108 */           this.parameterUsedInNumberContext = false;
/*  109 */           for (byte b1 = 0; b1 < arrayOfNode.length; b1++) {
/*  110 */             rewriteForNumberVariables(arrayOfNode[b1]);
/*      */           }
/*  112 */           paramOptFunctionNode.setParameterNumberContext(this.parameterUsedInNumberContext);
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  126 */     catch (IOException iOException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void optimize(Node paramNode, int paramInt) {
/*  136 */     this.itsOptLevel = paramInt;
/*      */     
/*  138 */     PreorderNodeIterator preorderNodeIterator = paramNode.getPreorderIterator();
/*      */     Node node;
/*  140 */     while ((node = preorderNodeIterator.nextNode()) != null) {
/*      */ 
/*      */       
/*  143 */       if (node.getType() == 109) {
/*  144 */         OptFunctionNode optFunctionNode = 
/*  145 */           (OptFunctionNode)node.getProp(5);
/*  146 */         if (optFunctionNode != null) {
/*  147 */           optimizeFunction(optFunctionNode);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void findSinglyTypedVars(VariableTable paramVariableTable, Block[] paramArrayOfBlock) {
/*  170 */     for (byte b = 0; b < paramVariableTable.size(); b++) {
/*  171 */       OptLocalVariable optLocalVariable = (OptLocalVariable)paramVariableTable.get(b);
/*  172 */       if (!optLocalVariable.isParameter()) {
/*  173 */         int i = optLocalVariable.getTypeUnion();
/*  174 */         if (i == 1) {
/*  175 */           optLocalVariable.setIsNumber();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doBlockLocalCSE(Block[] paramArrayOfBlock, Block paramBlock, Hashtable paramHashtable, boolean[] paramArrayOfBoolean, OptFunctionNode paramOptFunctionNode) {
/*  185 */     if (!paramArrayOfBoolean[paramBlock.getBlockID()]) {
/*  186 */       paramArrayOfBoolean[paramBlock.getBlockID()] = true;
/*  187 */       paramHashtable = paramBlock.localCSE(paramHashtable, paramOptFunctionNode);
/*  188 */       Block[] arrayOfBlock = paramArrayOfBlock[paramBlock.getBlockID()].getSuccessorList();
/*  189 */       if (arrayOfBlock != null) {
/*  190 */         for (byte b = 0; b < arrayOfBlock.length; b++) {
/*  191 */           int i = arrayOfBlock[b].getBlockID();
/*  192 */           Block[] arrayOfBlock1 = paramArrayOfBlock[i].getPredecessorList();
/*  193 */           if (arrayOfBlock1.length == 1) {
/*  194 */             doBlockLocalCSE(paramArrayOfBlock, arrayOfBlock[b], 
/*  195 */                 (Hashtable)paramHashtable.clone(), 
/*  196 */                 paramArrayOfBoolean, paramOptFunctionNode);
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   void localCSE(Block[] paramArrayOfBlock, OptFunctionNode paramOptFunctionNode) {
/*  204 */     boolean[] arrayOfBoolean = new boolean[paramArrayOfBlock.length];
/*  205 */     doBlockLocalCSE(paramArrayOfBlock, paramArrayOfBlock[0], null, arrayOfBoolean, paramOptFunctionNode);
/*  206 */     for (byte b = 0; b < paramArrayOfBlock.length; b++) {
/*  207 */       if (!arrayOfBoolean[b]) paramArrayOfBlock[b].localCSE(null, paramOptFunctionNode);
/*      */     
/*      */     } 
/*      */   }
/*      */   
/*      */   void typeFlow(VariableTable paramVariableTable, Block[] paramArrayOfBlock) {
/*  213 */     boolean[] arrayOfBoolean1 = new boolean[paramArrayOfBlock.length];
/*  214 */     boolean[] arrayOfBoolean2 = new boolean[paramArrayOfBlock.length];
/*  215 */     byte b = 0;
/*  216 */     boolean bool = false;
/*  217 */     arrayOfBoolean1[b] = true;
/*      */     while (true) {
/*  219 */       if (arrayOfBoolean1[b] || !arrayOfBoolean2[b]) {
/*  220 */         arrayOfBoolean2[b] = true;
/*  221 */         arrayOfBoolean1[b] = false;
/*  222 */         if (paramArrayOfBlock[b].doTypeFlow()) {
/*  223 */           Block[] arrayOfBlock = paramArrayOfBlock[b].getSuccessorList();
/*  224 */           if (arrayOfBlock != null) {
/*  225 */             for (byte b1 = 0; b1 < arrayOfBlock.length; b1++) {
/*  226 */               int i = arrayOfBlock[b1].getBlockID();
/*  227 */               arrayOfBoolean1[i] = true;
/*  228 */               bool |= ((i >= b) ? 0 : 1);
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*  233 */       if (b == paramArrayOfBlock.length - 1) {
/*  234 */         if (bool) {
/*  235 */           b = 0;
/*  236 */           bool = false;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         break;
/*      */       } 
/*  242 */       b++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reachingDefDataFlow(VariableTable paramVariableTable, Block[] paramArrayOfBlock) {
/*  253 */     for (byte b1 = 0; b1 < paramArrayOfBlock.length; b1++) {
/*  254 */       paramArrayOfBlock[b1].initLiveOnEntrySets(paramVariableTable);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  261 */     boolean[] arrayOfBoolean1 = new boolean[paramArrayOfBlock.length];
/*  262 */     boolean[] arrayOfBoolean2 = new boolean[paramArrayOfBlock.length];
/*  263 */     int i = paramArrayOfBlock.length - 1;
/*  264 */     boolean bool = false;
/*  265 */     arrayOfBoolean1[i] = true;
/*      */     while (true) {
/*  267 */       if (arrayOfBoolean1[i] || !arrayOfBoolean2[i]) {
/*  268 */         arrayOfBoolean2[i] = true;
/*  269 */         arrayOfBoolean1[i] = false;
/*  270 */         if (paramArrayOfBlock[i].doReachedUseDataFlow()) {
/*  271 */           Block[] arrayOfBlock = paramArrayOfBlock[i].getPredecessorList();
/*  272 */           if (arrayOfBlock != null) {
/*  273 */             for (byte b = 0; b < arrayOfBlock.length; b++) {
/*  274 */               int j = arrayOfBlock[b].getBlockID();
/*  275 */               arrayOfBoolean1[j] = true;
/*  276 */               bool |= ((j <= i) ? 0 : 1);
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*  281 */       if (i == 0) {
/*  282 */         if (bool) {
/*  283 */           i = paramArrayOfBlock.length - 1;
/*  284 */           bool = false;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         break;
/*      */       } 
/*  290 */       i--;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  302 */     for (byte b2 = 0; b2 < paramArrayOfBlock.length; b2++) {
/*  303 */       paramArrayOfBlock[b2].markVolatileVariables(paramVariableTable);
/*      */     }
/*      */     
/*  306 */     paramArrayOfBlock[0].markAnyTypeVariables(paramVariableTable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void markDCPNumberContext(Node paramNode) {
/*  342 */     if (this.inDirectCallFunction && paramNode.getType() == 72) {
/*      */       
/*  344 */       OptLocalVariable optLocalVariable = 
/*  345 */         (OptLocalVariable)paramNode.getProp(24);
/*  346 */       if (optLocalVariable != null && optLocalVariable.isParameter()) {
/*  347 */         this.parameterUsedInNumberContext = true;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   boolean convertParameter(Node paramNode) {
/*  354 */     if (this.inDirectCallFunction && paramNode.getType() == 72) {
/*      */       
/*  356 */       OptLocalVariable optLocalVariable = 
/*  357 */         (OptLocalVariable)paramNode.getProp(24);
/*  358 */       if (optLocalVariable != null && optLocalVariable.isParameter()) {
/*  359 */         paramNode.putProp(26, null);
/*  360 */         return true;
/*      */       } 
/*      */     } 
/*  363 */     return false; } int rewriteForNumberVariables(Node paramNode) { int i1, n, m; OptLocalVariable optLocalVariable2; Node node5; int j, k; Node node4;
/*      */     int i;
/*      */     OptLocalVariable optLocalVariable1;
/*      */     Node node2, node3;
/*      */     FunctionNode functionNode;
/*  368 */     switch (paramNode.getType()) {
/*      */       case 57:
/*  370 */         node3 = paramNode.getFirstChild();
/*  371 */         i = rewriteForNumberVariables(node3);
/*  372 */         if (i == 1)
/*  373 */           paramNode.putProp(26, new Integer(0)); 
/*  374 */         return 0;
/*      */       
/*      */       case 45:
/*  377 */         paramNode.putProp(26, new Integer(0));
/*  378 */         return 1;
/*      */       
/*      */       case 72:
/*  381 */         optLocalVariable1 = 
/*  382 */           (OptLocalVariable)paramNode.getProp(24);
/*  383 */         if (optLocalVariable1 != null) {
/*  384 */           if (this.inDirectCallFunction && optLocalVariable1.isParameter()) {
/*  385 */             paramNode.putProp(26, new Integer(0));
/*  386 */             return 1;
/*      */           } 
/*      */           
/*  389 */           if (optLocalVariable1.isNumber()) {
/*  390 */             paramNode.putProp(26, new Integer(0));
/*  391 */             return 1;
/*      */           } 
/*      */         } 
/*  394 */         return 0;
/*      */ 
/*      */       
/*      */       case 105:
/*      */       case 106:
/*  399 */         node2 = paramNode.getFirstChild();
/*  400 */         if (node2.getType() == 72) {
/*  401 */           OptLocalVariable optLocalVariable = 
/*  402 */             (OptLocalVariable)node2.getProp(24);
/*  403 */           if (optLocalVariable != null && optLocalVariable.isNumber()) {
/*  404 */             paramNode.putProp(26, new Integer(0));
/*  405 */             markDCPNumberContext(node2);
/*  406 */             return 1;
/*      */           } 
/*      */           
/*  409 */           return 0;
/*      */         } 
/*      */         
/*  412 */         return 0;
/*      */       
/*      */       case 73:
/*  415 */         node2 = paramNode.getFirstChild();
/*  416 */         node4 = node2.getNextSibling();
/*  417 */         k = rewriteForNumberVariables(node4);
/*  418 */         optLocalVariable2 = 
/*  419 */           (OptLocalVariable)paramNode.getProp(24);
/*  420 */         if (this.inDirectCallFunction && optLocalVariable2.isParameter()) {
/*  421 */           if (k == 1) {
/*  422 */             if (!convertParameter(node4)) {
/*  423 */               paramNode.putProp(26, new Integer(0));
/*  424 */               return 1;
/*      */             } 
/*  426 */             markDCPNumberContext(node4);
/*  427 */             return 0;
/*      */           } 
/*      */           
/*  430 */           return k;
/*      */         } 
/*      */         
/*  433 */         if (optLocalVariable2 != null && optLocalVariable2.isNumber()) {
/*  434 */           if (k != 1) {
/*  435 */             paramNode.removeChild(node4);
/*  436 */             Node node = new Node(141, node4);
/*  437 */             node.putProp(18, Double.class);
/*  438 */             paramNode.addChildToBack(node);
/*      */           } 
/*  440 */           paramNode.putProp(26, new Integer(0));
/*  441 */           markDCPNumberContext(node4);
/*  442 */           return 1;
/*      */         } 
/*      */         
/*  445 */         if (k == 1 && 
/*  446 */           !convertParameter(node4)) {
/*  447 */           paramNode.removeChild(node4);
/*  448 */           Node node = new Node(141, node4);
/*  449 */           node.putProp(18, Object.class);
/*  450 */           paramNode.addChildToBack(node);
/*      */         } 
/*      */         
/*  453 */         return 0;
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  458 */         node2 = paramNode.getFirstChild();
/*  459 */         node4 = node2.getNextSibling();
/*  460 */         k = rewriteForNumberVariables(node2);
/*  461 */         m = rewriteForNumberVariables(node4);
/*  462 */         markDCPNumberContext(node2);
/*  463 */         markDCPNumberContext(node4);
/*      */         
/*  465 */         if (paramNode.getInt() == 64 || 
/*  466 */           paramNode.getInt() == 63) {
/*  467 */           if (k == 1 && 
/*  468 */             !convertParameter(node2)) {
/*  469 */             paramNode.removeChild(node2);
/*  470 */             Node node = new Node(141, node2);
/*  471 */             node.putProp(18, Object.class);
/*  472 */             paramNode.addChildToFront(node);
/*      */           } 
/*      */           
/*  475 */           if (m == 1 && 
/*  476 */             !convertParameter(node4)) {
/*  477 */             paramNode.removeChild(node4);
/*  478 */             Node node = new Node(141, node4);
/*  479 */             node.putProp(18, Object.class);
/*  480 */             paramNode.addChildToBack(node);
/*      */           
/*      */           }
/*      */         
/*      */         }
/*  485 */         else if (convertParameter(node2)) {
/*  486 */           if (convertParameter(node4)) {
/*  487 */             return 0;
/*      */           }
/*      */           
/*  490 */           if (m == 1) {
/*  491 */             paramNode.putProp(26, 
/*  492 */                 new Integer(2));
/*      */           
/*      */           }
/*      */         
/*      */         }
/*  497 */         else if (convertParameter(node4)) {
/*  498 */           if (k == 1) {
/*  499 */             paramNode.putProp(26, 
/*  500 */                 new Integer(1));
/*      */           
/*      */           }
/*      */         }
/*  504 */         else if (k == 1) {
/*  505 */           if (m == 1) {
/*  506 */             paramNode.putProp(26, 
/*  507 */                 new Integer(0));
/*      */           } else {
/*      */             
/*  510 */             paramNode.putProp(26, 
/*  511 */                 new Integer(1));
/*      */           }
/*      */         
/*      */         }
/*  515 */         else if (m == 1) {
/*  516 */           paramNode.putProp(26, 
/*  517 */               new Integer(2));
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  524 */         return 0;
/*      */ 
/*      */       
/*      */       case 23:
/*  528 */         node2 = paramNode.getFirstChild();
/*  529 */         node4 = node2.getNextSibling();
/*  530 */         k = rewriteForNumberVariables(node2);
/*  531 */         m = rewriteForNumberVariables(node4);
/*      */ 
/*      */         
/*  534 */         if (convertParameter(node2)) {
/*  535 */           if (convertParameter(node4)) {
/*  536 */             return 0;
/*      */           }
/*      */           
/*  539 */           if (m == 1) {
/*  540 */             paramNode.putProp(26, new Integer(2));
/*      */           
/*      */           }
/*      */         
/*      */         }
/*  545 */         else if (convertParameter(node4)) {
/*  546 */           if (k == 1) {
/*  547 */             paramNode.putProp(26, new Integer(1));
/*      */           
/*      */           }
/*      */         }
/*  551 */         else if (k == 1) {
/*  552 */           if (m == 1) {
/*  553 */             paramNode.putProp(26, new Integer(0));
/*  554 */             return 1;
/*      */           } 
/*      */           
/*  557 */           paramNode.putProp(26, new Integer(1));
/*      */ 
/*      */         
/*      */         }
/*  561 */         else if (m == 1) {
/*  562 */           paramNode.putProp(26, new Integer(2));
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  567 */         return 0;
/*      */ 
/*      */       
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 20:
/*      */       case 21:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*  579 */         node2 = paramNode.getFirstChild();
/*  580 */         node4 = node2.getNextSibling();
/*  581 */         k = rewriteForNumberVariables(node2);
/*  582 */         m = rewriteForNumberVariables(node4);
/*  583 */         markDCPNumberContext(node2);
/*  584 */         markDCPNumberContext(node4);
/*  585 */         if (k == 1) {
/*  586 */           if (m == 1) {
/*  587 */             paramNode.putProp(26, 
/*  588 */                 new Integer(0));
/*  589 */             return 1;
/*      */           } 
/*      */           
/*  592 */           if (!convertParameter(node4)) {
/*  593 */             paramNode.removeChild(node4);
/*  594 */             Node node = new Node(141, node4);
/*  595 */             node.putProp(18, Double.class);
/*  596 */             paramNode.addChildToBack(node);
/*  597 */             paramNode.putProp(26, 
/*  598 */                 new Integer(0));
/*      */           } 
/*  600 */           return 1;
/*      */         } 
/*      */ 
/*      */         
/*  604 */         if (m == 1) {
/*  605 */           if (!convertParameter(node2)) {
/*  606 */             paramNode.removeChild(node2);
/*  607 */             Node node = new Node(141, node2);
/*  608 */             node.putProp(18, Double.class);
/*  609 */             paramNode.addChildToFront(node);
/*  610 */             paramNode.putProp(26, 
/*  611 */                 new Integer(0));
/*      */           } 
/*  613 */           return 1;
/*      */         } 
/*      */         
/*  616 */         if (!convertParameter(node2)) {
/*  617 */           paramNode.removeChild(node2);
/*  618 */           Node node = new Node(141, node2);
/*  619 */           node.putProp(18, Double.class);
/*  620 */           paramNode.addChildToFront(node);
/*      */         } 
/*  622 */         if (!convertParameter(node4)) {
/*  623 */           paramNode.removeChild(node4);
/*  624 */           Node node = new Node(141, node4);
/*  625 */           node.putProp(18, Double.class);
/*  626 */           paramNode.addChildToBack(node);
/*      */         } 
/*  628 */         paramNode.putProp(26, 
/*  629 */             new Integer(0));
/*  630 */         return 1;
/*      */ 
/*      */ 
/*      */       
/*      */       case 42:
/*  635 */         node2 = paramNode.getFirstChild();
/*  636 */         node4 = node2.getNextSibling();
/*  637 */         node5 = node4.getNextSibling();
/*  638 */         m = rewriteForNumberVariables(node2);
/*  639 */         if (m == 1 && 
/*  640 */           !convertParameter(node2)) {
/*  641 */           paramNode.removeChild(node2);
/*  642 */           Node node = new Node(141, node2);
/*  643 */           node.putProp(18, Object.class);
/*  644 */           paramNode.addChildToFront(node);
/*      */         } 
/*      */         
/*  647 */         n = rewriteForNumberVariables(node4);
/*  648 */         if (n == 1) {
/*      */ 
/*      */ 
/*      */           
/*  652 */           paramNode.putProp(26, new Integer(1));
/*  653 */           markDCPNumberContext(node4);
/*      */         } 
/*  655 */         i1 = rewriteForNumberVariables(node5);
/*  656 */         if (i1 == 1 && 
/*  657 */           !convertParameter(node5)) {
/*  658 */           paramNode.removeChild(node5);
/*  659 */           Node node = new Node(141, node5);
/*  660 */           node.putProp(18, Object.class);
/*  661 */           paramNode.addChildToBack(node);
/*      */         } 
/*      */         
/*  664 */         return 0;
/*      */       
/*      */       case 41:
/*  667 */         node2 = paramNode.getFirstChild();
/*  668 */         node4 = node2.getNextSibling();
/*  669 */         j = rewriteForNumberVariables(node2);
/*  670 */         if (j == 1 && 
/*  671 */           !convertParameter(node2)) {
/*  672 */           paramNode.removeChild(node2);
/*  673 */           Node node = new Node(141, node2);
/*  674 */           node.putProp(18, Object.class);
/*  675 */           paramNode.addChildToFront(node);
/*      */         } 
/*      */         
/*  678 */         m = rewriteForNumberVariables(node4);
/*  679 */         if (m == 1) {
/*      */ 
/*      */ 
/*      */           
/*  683 */           paramNode.putProp(26, new Integer(2));
/*  684 */           markDCPNumberContext(node4);
/*      */         } 
/*  686 */         return 0;
/*      */ 
/*      */       
/*      */       case 43:
/*  690 */         functionNode = 
/*  691 */           (FunctionNode)paramNode.getProp(27);
/*  692 */         if (functionNode != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  697 */           node4 = paramNode.getFirstChild();
/*  698 */           rewriteForNumberVariables(node4);
/*  699 */           node4 = node4.getNextSibling();
/*  700 */           rewriteForNumberVariables(node4);
/*  701 */           node4 = node4.getNextSibling();
/*  702 */           while (node4 != null) {
/*  703 */             j = rewriteForNumberVariables(node4);
/*  704 */             if (j == 1) {
/*  705 */               markDCPNumberContext(node4);
/*      */             }
/*  707 */             node4 = node4.getNextSibling();
/*      */           } 
/*  709 */           return 0;
/*      */         } 
/*      */         break;
/*      */     } 
/*      */     
/*  714 */     Node node1 = paramNode.getFirstChild();
/*  715 */     while (node1 != null) {
/*  716 */       node4 = node1.getNextSibling();
/*  717 */       j = rewriteForNumberVariables(node1);
/*  718 */       if (j == 1 && 
/*  719 */         !convertParameter(node1)) {
/*  720 */         paramNode.removeChild(node1);
/*  721 */         Node node = new Node(141, node1);
/*  722 */         node.putProp(18, Object.class);
/*  723 */         if (node4 == null) {
/*  724 */           paramNode.addChildToBack(node);
/*      */         } else {
/*  726 */           paramNode.addChildBefore(node, node4);
/*      */         } 
/*      */       } 
/*  729 */       node1 = node4;
/*      */     } 
/*  731 */     return 0; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void foldConstants(Node paramNode1, Node paramNode2) {
/*  741 */     Node node2 = null;
/*      */     
/*  743 */     Node node1 = paramNode1.getFirstChild();
/*  744 */     if (node1 == null) {
/*      */       return;
/*      */     }
/*  747 */     node2 = node1.getNextSibling();
/*      */     
/*  749 */     if (node2 == null) {
/*  750 */       foldConstants(node1, paramNode1);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  756 */     foldConstants(node1, paramNode1);
/*  757 */     foldConstants(node2, paramNode1);
/*      */ 
/*      */     
/*  760 */     Node node3 = node2.getNextSibling();
/*  761 */     while (node3 != null) {
/*  762 */       foldConstants(node3, paramNode1);
/*  763 */       node3 = node3.getNextSibling();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  768 */     node1 = paramNode1.getFirstChild();
/*  769 */     if (node1 == null) {
/*      */       return;
/*      */     }
/*  772 */     node2 = node1.getNextSibling();
/*      */     
/*  774 */     if (node2 == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  780 */     int i = node1.getType();
/*  781 */     int j = node2.getType();
/*      */ 
/*      */     
/*  784 */     switch (paramNode1.getType()) {
/*      */ 
/*      */       
/*      */       case 23:
/*  788 */         if (i == 45 && j == 45) {
/*  789 */           if (node1.getDatum() instanceof Double || 
/*  790 */             node2.getDatum() instanceof Double) {
/*  791 */             paramNode2.replaceChild(paramNode1, new Node(45, 
/*  792 */                   new Double(node1.getDouble() + node2.getDouble()))); break;
/*      */           } 
/*  794 */           long l = node1.getLong() + node2.getLong();
/*      */           
/*  796 */           paramNode2.replaceChild(paramNode1, new Node(45, 
/*  797 */                 toSmallestType(l)));
/*      */           
/*      */           break;
/*      */         } 
/*  801 */         if (i == 46 && j == 46) {
/*  802 */           paramNode2.replaceChild(paramNode1, new Node(46, 
/*  803 */                 String.valueOf(node1.getString()) + node2.getString()));
/*      */           break;
/*      */         } 
/*  806 */         if (i == 46 && j == 45) {
/*  807 */           paramNode2.replaceChild(paramNode1, new Node(46, String.valueOf(node1.getString()) + 
/*  808 */                 ScriptRuntime.numberToString(node2.getDouble(), 10)));
/*      */           break;
/*      */         } 
/*  811 */         if (i == 45 && j == 46) {
/*  812 */           paramNode2.replaceChild(paramNode1, new Node(46, 
/*  813 */                 String.valueOf(ScriptRuntime.numberToString(node1.getDouble(), 10)) + 
/*  814 */                 node2.getString()));
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  824 */         if (i == 45 && j == 45) {
/*  825 */           if (node1.getDatum() instanceof Double || node2.getDatum() instanceof Double) {
/*  826 */             paramNode2.replaceChild(paramNode1, new Node(45, 
/*  827 */                   new Double(node1.getDouble() - 
/*  828 */                     node2.getDouble()))); break;
/*      */           } 
/*  830 */           long l = node1.getLong() - node2.getLong();
/*  831 */           paramNode2.replaceChild(paramNode1, new Node(45, 
/*  832 */                 toSmallestType(l)));
/*      */           
/*      */           break;
/*      */         } 
/*  836 */         if (i == 45 && node1.getDouble() == 0.0D) {
/*  837 */           paramNode2.replaceChild(paramNode1, new Node(104, node2, 
/*  838 */                 new Integer(24)));
/*      */           break;
/*      */         } 
/*  841 */         if (j == 45 && node2.getDouble() == 0.0D) {
/*  842 */           paramNode2.replaceChild(paramNode1, node1);
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 25:
/*  848 */         if (i == 45 && j == 45) {
/*      */ 
/*      */           
/*  851 */           if (node1.getDatum() instanceof Double || node2.getDatum() instanceof Double) {
/*  852 */             paramNode2.replaceChild(paramNode1, new Node(45, 
/*  853 */                   new Double(node1.getDouble() * 
/*  854 */                     node2.getDouble()))); break;
/*      */           } 
/*  856 */           long l = 
/*  857 */             node1.getLong() * 
/*  858 */             node2.getLong();
/*      */           
/*  860 */           paramNode2.replaceChild(paramNode1, new Node(45, 
/*  861 */                 toSmallestType(l)));
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/*  866 */         if (i == 45) {
/*  867 */           double d = ((Number)node1.getDatum()).doubleValue();
/*      */           
/*  869 */           if (d == 1.0D)
/*  870 */             paramNode2.replaceChild(paramNode1, node2); 
/*      */           break;
/*      */         } 
/*  873 */         if (j == 45) {
/*  874 */           double d = ((Number)node2.getDatum()).doubleValue();
/*      */           
/*  876 */           if (d == 1.0D) {
/*  877 */             paramNode2.replaceChild(paramNode1, node1);
/*      */           }
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 26:
/*  884 */         if (i == 45 && j == 45) {
/*      */           
/*  886 */           if (node1.getDatum() instanceof Double || node2.getDatum() instanceof Double) {
/*  887 */             double d = node2.getDouble();
/*      */             
/*  889 */             if (d == 0.0D) {
/*      */               return;
/*      */             }
/*  892 */             paramNode2.replaceChild(paramNode1, new Node(45, 
/*  893 */                   new Double(node1.getDouble() / d))); break;
/*      */           } 
/*  895 */           int k = node2.getInt();
/*      */           
/*  897 */           if (k == 0) {
/*      */             return;
/*      */           }
/*  900 */           long l = 
/*  901 */             node1.getLong() / 
/*  902 */             node2.getLong();
/*      */           
/*  904 */           paramNode2.replaceChild(paramNode1, new Node(45, 
/*  905 */                 toSmallestType(l)));
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/*  911 */         if (j == 45 && 
/*  912 */           node2.getDouble() == 1.0D) {
/*  913 */           paramNode2.replaceChild(paramNode1, node1);
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 100:
/*  919 */         if (((i == 108 && node1.getInt() == 49) || (
/*  920 */           i == 108 && node1.getInt() == 74)) && 
/*  921 */           !IRFactory.hasSideEffects(node2)) {
/*      */           
/*  923 */           paramNode2.replaceChild(paramNode1, new Node(108, new Integer(51)));
/*      */           
/*      */           break;
/*      */         } 
/*  927 */         if (((j == 108 && node2.getInt() == 49) || (
/*  928 */           j == 108 && node2.getInt() == 74)) && 
/*  929 */           !IRFactory.hasSideEffects(node1)) {
/*      */           
/*  931 */           paramNode2.replaceChild(paramNode1, new Node(108, new Integer(51)));
/*      */           
/*      */           break;
/*      */         } 
/*  935 */         if ((i == 108 && ((Integer)node1.getDatum()).intValue() == 52) || (
/*  936 */           i == 45 && ((Number)node1.getDatum()).doubleValue() != 0.0D)) {
/*      */           
/*  938 */           paramNode2.replaceChild(paramNode1, node2);
/*      */           
/*      */           break;
/*      */         } 
/*  942 */         if ((j == 108 && ((Integer)node2.getDatum()).intValue() == 52) || (
/*  943 */           j == 45 && ((Number)node2.getDatum()).doubleValue() != 0.0D))
/*      */         {
/*  945 */           paramNode2.replaceChild(paramNode1, node1);
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 99:
/*  951 */         if ((i == 108 && node1.getInt() == 49) || (
/*  952 */           i == 108 && node1.getInt() == 74) || (
/*  953 */           i == 108 && node1.getInt() == 51) || (
/*  954 */           i == 45 && ((Number)node1.getDatum()).doubleValue() == 0.0D)) {
/*      */           
/*  956 */           paramNode2.replaceChild(paramNode1, node2);
/*      */           
/*      */           break;
/*      */         } 
/*  960 */         if ((j == 108 && node2.getInt() == 49) || (
/*  961 */           j == 108 && node2.getInt() == 74) || (
/*  962 */           j == 108 && node2.getInt() == 51) || (
/*  963 */           j == 45 && ((Number)node2.getDatum()).doubleValue() == 0.0D)) {
/*      */           
/*  965 */           paramNode2.replaceChild(paramNode1, node1);
/*      */           
/*      */           break;
/*      */         } 
/*  969 */         if (((i == 108 && ((Integer)node1.getDatum()).intValue() == 52) || (
/*  970 */           i == 45 && ((Number)node1.getDatum()).doubleValue() != 0.0D)) && 
/*  971 */           !IRFactory.hasSideEffects(node2)) {
/*      */           
/*  973 */           paramNode2.replaceChild(paramNode1, new Node(108, new Integer(52)));
/*      */           
/*      */           break;
/*      */         } 
/*  977 */         if (((j == 108 && ((Integer)node2.getDatum()).intValue() == 52) || (
/*  978 */           j == 45 && ((Number)node2.getDatum()).doubleValue() != 0.0D)) && 
/*  979 */           !IRFactory.hasSideEffects(node1))
/*      */         {
/*  981 */           paramNode2.replaceChild(paramNode1, new Node(108, new Integer(52)));
/*      */         }
/*      */         break;
/*      */       
/*      */       case 132:
/*  986 */         if (node1.getType() == 8) {
/*  987 */           Node node = node1.getFirstChild();
/*      */           
/*  989 */           if (node.getType() == 108) {
/*  990 */             int k = node.getInt();
/*  991 */             if (k == 51 || k == 49 || k == 74) {
/*  992 */               Node node4 = null;
/*      */               try {
/*  994 */                 node4 = 
/*  995 */                   node2.getNextSibling().getNextSibling().getNextSibling().getFirstChild();
/*  996 */               } catch (Exception exception) {
/*      */                 return;
/*      */               } 
/*      */               
/* 1000 */               if (node4 != null) {
/* 1001 */                 paramNode2.replaceChild(paramNode1, node4);
/*      */               }
/*      */               break;
/*      */             } 
/* 1005 */             if ((node.getType() == 108 && node.getInt() == 52) || (
/* 1006 */               node.getType() == 45 && ((Number)node.getDatum()).doubleValue() != 0.0D))
/*      */             {
/* 1008 */               if (node2.getType() == 132) {
/* 1009 */                 paramNode2.replaceChild(paramNode1, node2.getFirstChild());
/*      */               }
/*      */             }
/*      */           } 
/*      */         } 
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Number toSmallestType(long paramLong) {
/* 1023 */     if (paramLong >= -128L && paramLong <= 127L)
/* 1024 */       return new Byte((byte)(int)paramLong); 
/* 1025 */     if (paramLong >= -32768L && 
/* 1026 */       paramLong <= 32767L)
/* 1027 */       return new Short((short)(int)paramLong); 
/* 1028 */     if (paramLong >= -2147483648L && 
/* 1029 */       paramLong <= 2147483647L) {
/* 1030 */       return new Integer((int)paramLong);
/*      */     }
/* 1032 */     return new Double(paramLong);
/*      */   }
/*      */   void replaceVariableAccess(Node paramNode, VariableTable paramVariableTable) {
/*      */     OptLocalVariable optLocalVariable;
/*      */     String str;
/* 1037 */     Node node = paramNode.getFirstChild();
/* 1038 */     while (node != null) {
/* 1039 */       replaceVariableAccess(node, paramVariableTable);
/* 1040 */       node = node.getNextSibling();
/*      */     } 
/* 1042 */     switch (paramNode.getType()) {
/*      */       case 73:
/* 1044 */         str = paramNode.getFirstChild().getString();
/* 1045 */         optLocalVariable = 
/* 1046 */           (OptLocalVariable)paramVariableTable.get(str);
/* 1047 */         if (optLocalVariable != null) {
/* 1048 */           paramNode.putProp(24, optLocalVariable);
/*      */         }
/*      */         break;
/*      */       case 72:
/* 1052 */         str = paramNode.getString();
/* 1053 */         optLocalVariable = 
/* 1054 */           (OptLocalVariable)paramVariableTable.get(str);
/* 1055 */         if (optLocalVariable != null) {
/* 1056 */           paramNode.putProp(24, optLocalVariable);
/*      */         }
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node[] buildStatementList(FunctionNode paramFunctionNode) {
/* 1066 */     Vector vector = new Vector();
/*      */     
/* 1068 */     StmtNodeIterator stmtNodeIterator = new StmtNodeIterator(paramFunctionNode);
/* 1069 */     Node node = stmtNodeIterator.nextNode();
/* 1070 */     while (node != null) {
/* 1071 */       vector.addElement(node);
/* 1072 */       node = stmtNodeIterator.nextNode();
/*      */     } 
/* 1074 */     Node[] arrayOfNode = new Node[vector.size()];
/* 1075 */     for (byte b = 0; b < vector.size(); b++) {
/* 1076 */       arrayOfNode[b] = (Node)vector.elementAt(b);
/*      */     }
/* 1078 */     return arrayOfNode;
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\Optimizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */