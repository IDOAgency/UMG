/*    */ package org.mozilla.javascript.optimizer;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import org.mozilla.javascript.LocalVariable;
/*    */ import org.mozilla.javascript.VariableTable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptVariableTable
/*    */   extends VariableTable
/*    */ {
/*    */   public void print(PrintWriter paramPrintWriter) {
/* 47 */     System.out.println("Variable Table, size = " + this.itsVariables.size());
/* 48 */     for (byte b = 0; b < this.itsVariables.size(); b++) {
/* 49 */       LocalVariable localVariable = (LocalVariable)this.itsVariables.elementAt(b);
/* 50 */       paramPrintWriter.println(localVariable.toString());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void assignParameterJRegs() {
/* 60 */     short s = 4;
/* 61 */     for (byte b = 0; b < this.varStart; b++) {
/* 62 */       OptLocalVariable optLocalVariable = 
/* 63 */         (OptLocalVariable)this.itsVariables.elementAt(b);
/* 64 */       optLocalVariable.assignJRegister(s);
/* 65 */       s = (short)(s + 3);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 71 */   public LocalVariable createLocalVariable(String paramString, boolean paramBoolean) { return new OptLocalVariable(paramString, paramBoolean); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\OptVariableTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */