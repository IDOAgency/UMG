package org.mozilla.javascript.optimizer;

import java.io.PrintWriter;
import org.mozilla.javascript.LocalVariable;
import org.mozilla.javascript.VariableTable;

public class OptVariableTable extends VariableTable {
  public void print(PrintWriter paramPrintWriter) {
    System.out.println("Variable Table, size = " + this.itsVariables.size());
    for (byte b = 0; b < this.itsVariables.size(); b++) {
      LocalVariable localVariable = (LocalVariable)this.itsVariables.elementAt(b);
      paramPrintWriter.println(localVariable.toString());
    } 
  }
  
  public void assignParameterJRegs() {
    short s = 4;
    for (byte b = 0; b < this.varStart; b++) {
      OptLocalVariable optLocalVariable = 
        (OptLocalVariable)this.itsVariables.elementAt(b);
      optLocalVariable.assignJRegister(s);
      s = (short)(s + 3);
    } 
  }
  
  public LocalVariable createLocalVariable(String paramString, boolean paramBoolean) { return new OptLocalVariable(paramString, paramBoolean); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\OptVariableTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */