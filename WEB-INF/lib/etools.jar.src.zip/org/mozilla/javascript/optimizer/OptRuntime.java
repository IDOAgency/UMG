package org.mozilla.javascript.optimizer;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.NativeGlobal;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Undefined;

public final class OptRuntime extends ScriptRuntime {
  public static Object getElem(Object paramObject, double paramDouble, Scriptable paramScriptable) {
    int i = (int)paramDouble;
    String str = (i == paramDouble) ? null : ScriptRuntime.toString(new Double(paramDouble));
    Scriptable scriptable1 = (paramObject instanceof Scriptable) ? 
      (Scriptable)paramObject : 
      ScriptRuntime.toObject(paramScriptable, paramObject);
    Scriptable scriptable2 = scriptable1;
    if (str != null) {
      while (scriptable2 != null) {
        Object object = scriptable2.get(str, scriptable1);
        if (object != Scriptable.NOT_FOUND)
          return object; 
        scriptable2 = scriptable2.getPrototype();
      } 
      return Undefined.instance;
    } 
    while (scriptable2 != null) {
      Object object = scriptable2.get(i, scriptable1);
      if (object != Scriptable.NOT_FOUND)
        return object; 
      scriptable2 = scriptable2.getPrototype();
    } 
    return Undefined.instance;
  }
  
  public static Object setElem(Object paramObject1, double paramDouble, Object paramObject2, Scriptable paramScriptable) {
    int i = (int)paramDouble;
    String str = (i == paramDouble) ? 
      null : ScriptRuntime.toString(new Double(paramDouble));
    Scriptable scriptable1 = (paramObject1 instanceof Scriptable) ? 
      (Scriptable)paramObject1 : 
      ScriptRuntime.toObject(paramScriptable, paramObject1);
    Scriptable scriptable2 = scriptable1;
    if (str != null) {
      do {
        if (scriptable2.has(str, scriptable1)) {
          scriptable2.put(str, scriptable1, paramObject2);
          return paramObject2;
        } 
        scriptable2 = scriptable2.getPrototype();
      } while (scriptable2 != null);
      scriptable1.put(str, scriptable1, paramObject2);
      return paramObject2;
    } 
    do {
      if (scriptable2.has(i, scriptable1)) {
        scriptable2.put(i, scriptable1, paramObject2);
        return paramObject2;
      } 
      scriptable2 = scriptable2.getPrototype();
    } while (scriptable2 != null);
    scriptable1.put(i, scriptable1, paramObject2);
    return paramObject2;
  }
  
  public static Object add(Object paramObject, double paramDouble) {
    if (paramObject instanceof Scriptable)
      paramObject = ((Scriptable)paramObject).getDefaultValue(null); 
    if (!(paramObject instanceof String))
      return new Double(ScriptRuntime.toNumber(paramObject) + paramDouble); 
    return String.valueOf(ScriptRuntime.toString(paramObject)) + ScriptRuntime.numberToString(paramDouble, 10);
  }
  
  public static Object add(double paramDouble, Object paramObject) {
    if (paramObject instanceof Scriptable)
      paramObject = ((Scriptable)paramObject).getDefaultValue(null); 
    if (!(paramObject instanceof String))
      return new Double(ScriptRuntime.toNumber(paramObject) + paramDouble); 
    return String.valueOf(ScriptRuntime.numberToString(paramDouble, 10)) + ScriptRuntime.toString(paramObject);
  }
  
  public static boolean neq(Object paramObject1, Object paramObject2) { return ScriptRuntime.eq(paramObject1, paramObject2) ^ true; }
  
  public static boolean shallowNeq(Object paramObject1, Object paramObject2) { return ScriptRuntime.shallowEq(paramObject1, paramObject2) ^ true; }
  
  public static Boolean cmp_LTB(double paramDouble, Object paramObject) {
    if (cmp_LT(paramDouble, paramObject) == 1)
      return Boolean.TRUE; 
    return Boolean.FALSE;
  }
  
  public static int cmp_LT(double paramDouble, Object paramObject) {
    if (paramObject instanceof Scriptable)
      paramObject = ((Scriptable)paramObject).getDefaultValue(ScriptRuntime.NumberClass); 
    if (!(paramObject instanceof String)) {
      if (paramDouble != paramDouble)
        return 0; 
      double d = ScriptRuntime.toNumber(paramObject);
      if (d != d)
        return 0; 
      return (paramDouble < d) ? 1 : 0;
    } 
    return (ScriptRuntime.toString(new Double(paramDouble)).compareTo(ScriptRuntime.toString(paramObject)) < 0) ? 1 : 0;
  }
  
  public static Boolean cmp_LTB(Object paramObject, double paramDouble) {
    if (cmp_LT(paramObject, paramDouble) == 1)
      return Boolean.TRUE; 
    return Boolean.FALSE;
  }
  
  public static int cmp_LT(Object paramObject, double paramDouble) {
    if (paramObject instanceof Scriptable)
      paramObject = ((Scriptable)paramObject).getDefaultValue(ScriptRuntime.NumberClass); 
    if (!(paramObject instanceof String)) {
      double d = ScriptRuntime.toNumber(paramObject);
      if (d != d)
        return 0; 
      if (paramDouble != paramDouble)
        return 0; 
      return (d < paramDouble) ? 1 : 0;
    } 
    return (ScriptRuntime.toString(paramObject).compareTo(ScriptRuntime.toString(new Double(paramDouble))) < 0) ? 1 : 0;
  }
  
  public static Boolean cmp_LEB(double paramDouble, Object paramObject) {
    if (cmp_LE(paramDouble, paramObject) == 1)
      return Boolean.TRUE; 
    return Boolean.FALSE;
  }
  
  public static int cmp_LE(double paramDouble, Object paramObject) {
    if (paramObject instanceof Scriptable)
      paramObject = ((Scriptable)paramObject).getDefaultValue(ScriptRuntime.NumberClass); 
    if (!(paramObject instanceof String)) {
      if (paramDouble != paramDouble)
        return 0; 
      double d = ScriptRuntime.toNumber(paramObject);
      if (d != d)
        return 0; 
      return (paramDouble <= d) ? 1 : 0;
    } 
    return (ScriptRuntime.toString(new Double(paramDouble)).compareTo(ScriptRuntime.toString(paramObject)) <= 0) ? 1 : 0;
  }
  
  public static Boolean cmp_LEB(Object paramObject, double paramDouble) {
    if (cmp_LE(paramObject, paramDouble) == 1)
      return Boolean.TRUE; 
    return Boolean.FALSE;
  }
  
  public static int cmp_LE(Object paramObject, double paramDouble) {
    if (paramObject instanceof Scriptable)
      paramObject = ((Scriptable)paramObject).getDefaultValue(ScriptRuntime.NumberClass); 
    if (!(paramObject instanceof String)) {
      double d = ScriptRuntime.toNumber(paramObject);
      if (d != d)
        return 0; 
      if (paramDouble != paramDouble)
        return 0; 
      return (d <= paramDouble) ? 1 : 0;
    } 
    return (ScriptRuntime.toString(paramObject).compareTo(ScriptRuntime.toString(new Double(paramDouble))) <= 0) ? 1 : 0;
  }
  
  public static int cmp(Object paramObject1, Object paramObject2) {
    if (paramObject1 instanceof Scriptable)
      paramObject1 = ((Scriptable)paramObject1).getDefaultValue(ScriptRuntime.NumberClass); 
    if (paramObject2 instanceof Scriptable)
      paramObject2 = ((Scriptable)paramObject2).getDefaultValue(ScriptRuntime.NumberClass); 
    if (!(paramObject1 instanceof String) || !(paramObject2 instanceof String)) {
      double d1 = ScriptRuntime.toNumber(paramObject1);
      if (d1 != d1)
        return -1; 
      double d2 = ScriptRuntime.toNumber(paramObject2);
      if (d2 != d2)
        return -1; 
      return (d1 < d2) ? 1 : 0;
    } 
    return (ScriptRuntime.toString(paramObject1).compareTo(ScriptRuntime.toString(paramObject2)) < 0) ? 1 : 0;
  }
  
  public static Object callSimple(Context paramContext, String paramString, Scriptable paramScriptable, Object[] paramArrayOfObject) throws JavaScriptException {
    Function function;
    Scriptable scriptable1 = paramScriptable;
    Object object = null;
    Scriptable scriptable2 = null;
    while (scriptable1 != null) {
      function = scriptable1;
      while (true) {
        object = function.get(paramString, scriptable1);
        if (object != Scriptable.NOT_FOUND) {
          scriptable2 = scriptable1;
          break;
        } 
        function = function.getPrototype();
        if (function == null)
          scriptable1 = scriptable1.getParentScope(); 
      } 
      break;
    } 
    if (object == null || object == Scriptable.NOT_FOUND) {
      function = new Object[] { paramString };
      throw NativeGlobal.constructError(
          paramContext, "ReferenceError", 
          ScriptRuntime.getMessage("msg.is.not.defined", function), 
          paramScriptable);
    } 
    while (scriptable2 instanceof org.mozilla.javascript.NativeWith)
      scriptable2 = scriptable2.getPrototype(); 
    if (scriptable2 instanceof org.mozilla.javascript.NativeCall)
      scriptable2 = ScriptableObject.getTopLevelScope(scriptable2); 
    try {
      function = (Function)object;
    } catch (ClassCastException classCastException) {
      Object[] arrayOfObject = { ScriptRuntime.toString(object) };
      throw Context.reportRuntimeError(
          ScriptRuntime.getMessage("msg.isnt.function", arrayOfObject));
    } 
    return function.call(paramContext, paramScriptable, scriptable2, paramArrayOfObject);
  }
  
  public static Object thisGet(Scriptable paramScriptable1, String paramString, Scriptable paramScriptable2) {
    Object object = paramScriptable1.get(paramString, paramScriptable1);
    if (object != Scriptable.NOT_FOUND)
      return object; 
    Scriptable scriptable1 = paramScriptable1;
    if (scriptable1 == null)
      throw Context.reportRuntimeError(
          ScriptRuntime.getMessage("msg.null.to.object", null)); 
    Scriptable scriptable2 = scriptable1;
    do {
      object = scriptable2.get(paramString, scriptable1);
      if (object != Scriptable.NOT_FOUND)
        return object; 
      scriptable2 = scriptable2.getPrototype();
    } while (scriptable2 != null);
    return Undefined.instance;
  }
  
  public static Object[] padStart(Object[] paramArrayOfObject, int paramInt) {
    Object[] arrayOfObject = new Object[paramArrayOfObject.length + paramInt];
    System.arraycopy(paramArrayOfObject, 0, arrayOfObject, paramInt, paramArrayOfObject.length);
    return arrayOfObject;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\OptRuntime.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */