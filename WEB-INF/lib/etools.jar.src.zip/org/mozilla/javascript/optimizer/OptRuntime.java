/*     */ package org.mozilla.javascript.optimizer;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.Function;
/*     */ import org.mozilla.javascript.JavaScriptException;
/*     */ import org.mozilla.javascript.NativeGlobal;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OptRuntime
/*     */   extends ScriptRuntime
/*     */ {
/*     */   public static Object getElem(Object paramObject, double paramDouble, Scriptable paramScriptable) {
/*  52 */     int i = (int)paramDouble;
/*  53 */     String str = (i == paramDouble) ? null : ScriptRuntime.toString(new Double(paramDouble));
/*  54 */     Scriptable scriptable1 = (paramObject instanceof Scriptable) ? 
/*  55 */       (Scriptable)paramObject : 
/*  56 */       ScriptRuntime.toObject(paramScriptable, paramObject);
/*  57 */     Scriptable scriptable2 = scriptable1;
/*  58 */     if (str != null) {
/*  59 */       while (scriptable2 != null) {
/*  60 */         Object object = scriptable2.get(str, scriptable1);
/*  61 */         if (object != Scriptable.NOT_FOUND)
/*  62 */           return object; 
/*  63 */         scriptable2 = scriptable2.getPrototype();
/*     */       } 
/*  65 */       return Undefined.instance;
/*     */     } 
/*  67 */     while (scriptable2 != null) {
/*  68 */       Object object = scriptable2.get(i, scriptable1);
/*  69 */       if (object != Scriptable.NOT_FOUND)
/*  70 */         return object; 
/*  71 */       scriptable2 = scriptable2.getPrototype();
/*     */     } 
/*  73 */     return Undefined.instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object setElem(Object paramObject1, double paramDouble, Object paramObject2, Scriptable paramScriptable) {
/*  81 */     int i = (int)paramDouble;
/*  82 */     String str = (i == paramDouble) ? 
/*  83 */       null : ScriptRuntime.toString(new Double(paramDouble));
/*     */     
/*  85 */     Scriptable scriptable1 = (paramObject1 instanceof Scriptable) ? 
/*  86 */       (Scriptable)paramObject1 : 
/*  87 */       ScriptRuntime.toObject(paramScriptable, paramObject1);
/*  88 */     Scriptable scriptable2 = scriptable1;
/*  89 */     if (str != null) {
/*     */       do {
/*  91 */         if (scriptable2.has(str, scriptable1)) {
/*  92 */           scriptable2.put(str, scriptable1, paramObject2);
/*  93 */           return paramObject2;
/*     */         } 
/*  95 */         scriptable2 = scriptable2.getPrototype();
/*  96 */       } while (scriptable2 != null);
/*  97 */       scriptable1.put(str, scriptable1, paramObject2);
/*  98 */       return paramObject2;
/*     */     } 
/*     */     
/*     */     do {
/* 102 */       if (scriptable2.has(i, scriptable1)) {
/* 103 */         scriptable2.put(i, scriptable1, paramObject2);
/* 104 */         return paramObject2;
/*     */       } 
/* 106 */       scriptable2 = scriptable2.getPrototype();
/* 107 */     } while (scriptable2 != null);
/* 108 */     scriptable1.put(i, scriptable1, paramObject2);
/* 109 */     return paramObject2;
/*     */   }
/*     */   
/*     */   public static Object add(Object paramObject, double paramDouble) {
/* 113 */     if (paramObject instanceof Scriptable)
/* 114 */       paramObject = ((Scriptable)paramObject).getDefaultValue(null); 
/* 115 */     if (!(paramObject instanceof String))
/* 116 */       return new Double(ScriptRuntime.toNumber(paramObject) + paramDouble); 
/* 117 */     return String.valueOf(ScriptRuntime.toString(paramObject)) + ScriptRuntime.numberToString(paramDouble, 10);
/*     */   }
/*     */   
/*     */   public static Object add(double paramDouble, Object paramObject) {
/* 121 */     if (paramObject instanceof Scriptable)
/* 122 */       paramObject = ((Scriptable)paramObject).getDefaultValue(null); 
/* 123 */     if (!(paramObject instanceof String))
/* 124 */       return new Double(ScriptRuntime.toNumber(paramObject) + paramDouble); 
/* 125 */     return String.valueOf(ScriptRuntime.numberToString(paramDouble, 10)) + ScriptRuntime.toString(paramObject);
/*     */   }
/*     */ 
/*     */   
/* 129 */   public static boolean neq(Object paramObject1, Object paramObject2) { return ScriptRuntime.eq(paramObject1, paramObject2) ^ true; }
/*     */ 
/*     */ 
/*     */   
/* 133 */   public static boolean shallowNeq(Object paramObject1, Object paramObject2) { return ScriptRuntime.shallowEq(paramObject1, paramObject2) ^ true; }
/*     */ 
/*     */   
/*     */   public static Boolean cmp_LTB(double paramDouble, Object paramObject) {
/* 137 */     if (cmp_LT(paramDouble, paramObject) == 1) {
/* 138 */       return Boolean.TRUE;
/*     */     }
/* 140 */     return Boolean.FALSE;
/*     */   }
/*     */   
/*     */   public static int cmp_LT(double paramDouble, Object paramObject) {
/* 144 */     if (paramObject instanceof Scriptable)
/* 145 */       paramObject = ((Scriptable)paramObject).getDefaultValue(ScriptRuntime.NumberClass); 
/* 146 */     if (!(paramObject instanceof String)) {
/* 147 */       if (paramDouble != paramDouble)
/* 148 */         return 0; 
/* 149 */       double d = ScriptRuntime.toNumber(paramObject);
/* 150 */       if (d != d)
/* 151 */         return 0; 
/* 152 */       return (paramDouble < d) ? 1 : 0;
/*     */     } 
/* 154 */     return (ScriptRuntime.toString(new Double(paramDouble)).compareTo(ScriptRuntime.toString(paramObject)) < 0) ? 1 : 0;
/*     */   }
/*     */   
/*     */   public static Boolean cmp_LTB(Object paramObject, double paramDouble) {
/* 158 */     if (cmp_LT(paramObject, paramDouble) == 1) {
/* 159 */       return Boolean.TRUE;
/*     */     }
/* 161 */     return Boolean.FALSE;
/*     */   }
/*     */   
/*     */   public static int cmp_LT(Object paramObject, double paramDouble) {
/* 165 */     if (paramObject instanceof Scriptable)
/* 166 */       paramObject = ((Scriptable)paramObject).getDefaultValue(ScriptRuntime.NumberClass); 
/* 167 */     if (!(paramObject instanceof String)) {
/* 168 */       double d = ScriptRuntime.toNumber(paramObject);
/* 169 */       if (d != d)
/* 170 */         return 0; 
/* 171 */       if (paramDouble != paramDouble)
/* 172 */         return 0; 
/* 173 */       return (d < paramDouble) ? 1 : 0;
/*     */     } 
/* 175 */     return (ScriptRuntime.toString(paramObject).compareTo(ScriptRuntime.toString(new Double(paramDouble))) < 0) ? 1 : 0;
/*     */   }
/*     */   
/*     */   public static Boolean cmp_LEB(double paramDouble, Object paramObject) {
/* 179 */     if (cmp_LE(paramDouble, paramObject) == 1) {
/* 180 */       return Boolean.TRUE;
/*     */     }
/* 182 */     return Boolean.FALSE;
/*     */   }
/*     */   
/*     */   public static int cmp_LE(double paramDouble, Object paramObject) {
/* 186 */     if (paramObject instanceof Scriptable)
/* 187 */       paramObject = ((Scriptable)paramObject).getDefaultValue(ScriptRuntime.NumberClass); 
/* 188 */     if (!(paramObject instanceof String)) {
/* 189 */       if (paramDouble != paramDouble)
/* 190 */         return 0; 
/* 191 */       double d = ScriptRuntime.toNumber(paramObject);
/* 192 */       if (d != d)
/* 193 */         return 0; 
/* 194 */       return (paramDouble <= d) ? 1 : 0;
/*     */     } 
/* 196 */     return (ScriptRuntime.toString(new Double(paramDouble)).compareTo(ScriptRuntime.toString(paramObject)) <= 0) ? 1 : 0;
/*     */   }
/*     */   
/*     */   public static Boolean cmp_LEB(Object paramObject, double paramDouble) {
/* 200 */     if (cmp_LE(paramObject, paramDouble) == 1) {
/* 201 */       return Boolean.TRUE;
/*     */     }
/* 203 */     return Boolean.FALSE;
/*     */   }
/*     */   
/*     */   public static int cmp_LE(Object paramObject, double paramDouble) {
/* 207 */     if (paramObject instanceof Scriptable)
/* 208 */       paramObject = ((Scriptable)paramObject).getDefaultValue(ScriptRuntime.NumberClass); 
/* 209 */     if (!(paramObject instanceof String)) {
/* 210 */       double d = ScriptRuntime.toNumber(paramObject);
/* 211 */       if (d != d)
/* 212 */         return 0; 
/* 213 */       if (paramDouble != paramDouble)
/* 214 */         return 0; 
/* 215 */       return (d <= paramDouble) ? 1 : 0;
/*     */     } 
/* 217 */     return (ScriptRuntime.toString(paramObject).compareTo(ScriptRuntime.toString(new Double(paramDouble))) <= 0) ? 1 : 0;
/*     */   }
/*     */   
/*     */   public static int cmp(Object paramObject1, Object paramObject2) {
/* 221 */     if (paramObject1 instanceof Scriptable)
/* 222 */       paramObject1 = ((Scriptable)paramObject1).getDefaultValue(ScriptRuntime.NumberClass); 
/* 223 */     if (paramObject2 instanceof Scriptable)
/* 224 */       paramObject2 = ((Scriptable)paramObject2).getDefaultValue(ScriptRuntime.NumberClass); 
/* 225 */     if (!(paramObject1 instanceof String) || !(paramObject2 instanceof String)) {
/* 226 */       double d1 = ScriptRuntime.toNumber(paramObject1);
/* 227 */       if (d1 != d1)
/* 228 */         return -1; 
/* 229 */       double d2 = ScriptRuntime.toNumber(paramObject2);
/* 230 */       if (d2 != d2)
/* 231 */         return -1; 
/* 232 */       return (d1 < d2) ? 1 : 0;
/*     */     } 
/* 234 */     return (ScriptRuntime.toString(paramObject1).compareTo(ScriptRuntime.toString(paramObject2)) < 0) ? 1 : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object callSimple(Context paramContext, String paramString, Scriptable paramScriptable, Object[] paramArrayOfObject) throws JavaScriptException {
/*     */     Function function;
/* 241 */     Scriptable scriptable1 = paramScriptable;
/* 242 */     Object object = null;
/* 243 */     Scriptable scriptable2 = null;
/*     */     
/* 245 */     while (scriptable1 != null) {
/* 246 */       function = scriptable1;
/*     */       while (true) {
/* 248 */         object = function.get(paramString, scriptable1);
/* 249 */         if (object != Scriptable.NOT_FOUND) {
/* 250 */           scriptable2 = scriptable1;
/*     */           break;
/*     */         } 
/* 253 */         function = function.getPrototype();
/* 254 */         if (function == null)
/* 255 */           scriptable1 = scriptable1.getParentScope(); 
/*     */       }  break;
/* 257 */     }  if (object == null || object == Scriptable.NOT_FOUND) {
/* 258 */       function = new Object[] { paramString };
/* 259 */       throw NativeGlobal.constructError(
/* 260 */           paramContext, "ReferenceError", 
/* 261 */           ScriptRuntime.getMessage("msg.is.not.defined", function), 
/* 262 */           paramScriptable);
/*     */     } 
/*     */     
/* 265 */     while (scriptable2 instanceof org.mozilla.javascript.NativeWith)
/* 266 */       scriptable2 = scriptable2.getPrototype(); 
/* 267 */     if (scriptable2 instanceof org.mozilla.javascript.NativeCall) {
/* 268 */       scriptable2 = ScriptableObject.getTopLevelScope(scriptable2);
/*     */     }
/*     */     
/*     */     try {
/* 272 */       function = (Function)object;
/*     */     }
/* 274 */     catch (ClassCastException classCastException) {
/* 275 */       Object[] arrayOfObject = { ScriptRuntime.toString(object) };
/* 276 */       throw Context.reportRuntimeError(
/* 277 */           ScriptRuntime.getMessage("msg.isnt.function", arrayOfObject));
/*     */     } 
/*     */     
/* 280 */     return function.call(paramContext, paramScriptable, scriptable2, paramArrayOfObject);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object thisGet(Scriptable paramScriptable1, String paramString, Scriptable paramScriptable2) {
/* 286 */     Object object = paramScriptable1.get(paramString, paramScriptable1);
/* 287 */     if (object != Scriptable.NOT_FOUND) {
/* 288 */       return object;
/*     */     }
/* 290 */     Scriptable scriptable1 = paramScriptable1;
/* 291 */     if (scriptable1 == null) {
/* 292 */       throw Context.reportRuntimeError(
/* 293 */           ScriptRuntime.getMessage("msg.null.to.object", null));
/*     */     }
/* 295 */     Scriptable scriptable2 = scriptable1;
/*     */     do {
/* 297 */       object = scriptable2.get(paramString, scriptable1);
/* 298 */       if (object != Scriptable.NOT_FOUND) {
/* 299 */         return object;
/*     */       }
/* 301 */       scriptable2 = scriptable2.getPrototype();
/* 302 */     } while (scriptable2 != null);
/* 303 */     return Undefined.instance;
/*     */   }
/*     */   
/*     */   public static Object[] padStart(Object[] paramArrayOfObject, int paramInt) {
/* 307 */     Object[] arrayOfObject = new Object[paramArrayOfObject.length + paramInt];
/* 308 */     System.arraycopy(paramArrayOfObject, 0, arrayOfObject, paramInt, paramArrayOfObject.length);
/* 309 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\OptRuntime.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */