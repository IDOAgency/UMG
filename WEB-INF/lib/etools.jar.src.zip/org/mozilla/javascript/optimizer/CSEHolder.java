package org.mozilla.javascript.optimizer;

import org.mozilla.javascript.Node;

class CSEHolder {
  Node getPropParent;
  
  Node getPropChild;
  
  CSEHolder(Node paramNode1, Node paramNode2) {
    this.getPropParent = paramNode1;
    this.getPropChild = paramNode2;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\CSEHolder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */