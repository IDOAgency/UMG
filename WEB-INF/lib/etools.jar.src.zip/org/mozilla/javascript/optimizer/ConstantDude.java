package org.mozilla.javascript.optimizer;

class ConstantDude {
  String itsWrapperType;
  
  String itsSignature;
  
  long itsLValue;
  
  double itsDValue;
  
  boolean itsIsInteger;
  
  ConstantDude(String paramString1, String paramString2, long paramLong) {
    this.itsWrapperType = paramString1;
    this.itsSignature = paramString2;
    this.itsIsInteger = true;
    this.itsLValue = paramLong;
  }
  
  ConstantDude(String paramString1, String paramString2, double paramDouble) {
    this.itsWrapperType = paramString1;
    this.itsSignature = paramString2;
    this.itsIsInteger = false;
    this.itsDValue = paramDouble;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\ConstantDude.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */