package org.mozilla.javascript.optimizer;

import java.util.Enumeration;
import java.util.Hashtable;
import org.mozilla.javascript.Node;

public class FatBlock {
  private Hashtable itsSuccessors;
  
  private Hashtable itsPredecessors;
  
  private Block itsShadowOfFormerSelf;
  
  public FatBlock(int paramInt1, int paramInt2, Node[] paramArrayOfNode) {
    this.itsSuccessors = new Hashtable(4);
    this.itsPredecessors = new Hashtable(4);
    this.itsShadowOfFormerSelf = new Block(paramInt1, paramInt2, paramArrayOfNode);
  }
  
  public Node getEndNode() { return this.itsShadowOfFormerSelf.getEndNode(); }
  
  public Block getSlimmerSelf() { return this.itsShadowOfFormerSelf; }
  
  private Block[] reduceToArray(Hashtable paramHashtable) {
    Block[] arrayOfBlock = null;
    if (!paramHashtable.isEmpty()) {
      arrayOfBlock = new Block[paramHashtable.size()];
      Enumeration enumeration = paramHashtable.elements();
      byte b = 0;
      while (enumeration.hasMoreElements()) {
        FatBlock fatBlock = (FatBlock)enumeration.nextElement();
        arrayOfBlock[b++] = fatBlock.itsShadowOfFormerSelf;
      } 
    } 
    return arrayOfBlock;
  }
  
  Block diet() {
    this.itsShadowOfFormerSelf.setSuccessorList(reduceToArray(this.itsSuccessors));
    this.itsShadowOfFormerSelf.setPredecessorList(reduceToArray(this.itsPredecessors));
    return this.itsShadowOfFormerSelf;
  }
  
  public void addSuccessor(FatBlock paramFatBlock) { this.itsSuccessors.put(paramFatBlock, paramFatBlock); }
  
  public void addPredecessor(FatBlock paramFatBlock) { this.itsPredecessors.put(paramFatBlock, paramFatBlock); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\FatBlock.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */