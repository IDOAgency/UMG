/*    */ package org.mozilla.javascript.optimizer;
/*    */ 
/*    */ import org.mozilla.javascript.LocalVariable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptLocalVariable
/*    */   extends LocalVariable
/*    */ {
/*    */   private short itsJRegister;
/*    */   private boolean itsLiveAcrossCall;
/*    */   private boolean itsIsNumber;
/*    */   private TypeEvent itsTypeUnion;
/*    */   private int initPC;
/*    */   
/*    */   public OptLocalVariable(String paramString, boolean paramBoolean) {
/* 44 */     super(paramString, paramBoolean);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 90 */     this.itsJRegister = -1;
/*    */     byte b = paramBoolean ? 3 : 0;
/*    */     this.itsTypeUnion = new TypeEvent(b);
/*    */   }
/*    */   
/*    */   public String toString() {
/*    */     return "LocalVariable : '" + getName() + "', index = " + getIndex() + ", LiveAcrossCall = " + this.itsLiveAcrossCall + ", isNumber = " + this.itsIsNumber + ", isParameter = " + isParameter() + ", JRegister = " + this.itsJRegister;
/*    */   }
/*    */   
/*    */   public void setIsNumber() { this.itsIsNumber = true; }
/*    */   
/*    */   public boolean isNumber() { return this.itsIsNumber; }
/*    */   
/*    */   public void markLiveAcrossCall() { this.itsLiveAcrossCall = true; }
/*    */   
/*    */   public void clearLiveAcrossCall() { this.itsLiveAcrossCall = false; }
/*    */   
/*    */   public boolean isLiveAcrossCall() { return this.itsLiveAcrossCall; }
/*    */   
/*    */   public void assignJRegister(short paramShort) { this.itsJRegister = paramShort; }
/*    */   
/*    */   public short getJRegister() { return this.itsJRegister; }
/*    */   
/*    */   public boolean assignType(int paramInt) { return this.itsTypeUnion.add(paramInt); }
/*    */   
/*    */   public int getTypeUnion() { return this.itsTypeUnion.getEvent(); }
/*    */   
/*    */   public int getStartPC() { return this.initPC; }
/*    */   
/*    */   public void setStartPC(int paramInt) { this.initPC = paramInt; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\OptLocalVariable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */