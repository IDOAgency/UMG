/*     */ package org.mozilla.javascript.optimizer;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.FunctionNode;
/*     */ import org.mozilla.javascript.IRFactory;
/*     */ import org.mozilla.javascript.Node;
/*     */ import org.mozilla.javascript.NodeTransformer;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.TokenStream;
/*     */ import org.mozilla.javascript.VariableTable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OptTransformer
/*     */   extends NodeTransformer
/*     */ {
/*     */   private Hashtable theFnClassNameList;
/*     */   
/*  55 */   OptTransformer(Hashtable paramHashtable) { this.theFnClassNameList = paramHashtable; }
/*     */ 
/*     */ 
/*     */   
/*  59 */   public NodeTransformer newInstance() { return new OptTransformer((Hashtable)this.theFnClassNameList.clone()); }
/*     */ 
/*     */ 
/*     */   
/*  63 */   public IRFactory createIRFactory(TokenStream paramTokenStream, Scriptable paramScriptable) { return new IRFactory(paramTokenStream, paramScriptable); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node transform(Node paramNode1, Node paramNode2, TokenStream paramTokenStream, Scriptable paramScriptable) {
/*  72 */     collectContainedFunctions(paramNode1.getFirstChild());
/*     */     
/*  74 */     return super.transform(paramNode1, paramNode2, paramTokenStream, paramScriptable);
/*     */   }
/*     */ 
/*     */   
/*  78 */   protected VariableTable createVariableTable() { return new OptVariableTable(); }
/*     */ 
/*     */ 
/*     */   
/*     */   private int detectDirectCall(Node paramNode1, Node paramNode2) {
/*  83 */     Context context = Context.getCurrentContext();
/*  84 */     int i = context.getOptimizationLevel();
/*  85 */     Node node1 = paramNode1.getFirstChild();
/*     */ 
/*     */     
/*  88 */     byte b = 0;
/*  89 */     Node node2 = node1.getNextSibling();
/*  90 */     while (node2 != null) {
/*  91 */       node2 = node2.getNextSibling();
/*  92 */       b++;
/*     */     } 
/*     */     
/*  95 */     if (paramNode2.getType() == 109 && i > 0) {
/*  96 */       if (node1.getType() == 44) {
/*  97 */         markDirectCall(paramNode2, paramNode1, b, node1.getString());
/*     */       }
/*  99 */       else if (node1.getType() == 39) {
/* 100 */         Node node = node1.getFirstChild().getNextSibling();
/* 101 */         markDirectCall(paramNode2, paramNode1, b, node.getString());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 106 */     return b;
/*     */   }
/*     */   
/*     */   protected void visitNew(Node paramNode1, Node paramNode2) {
/* 110 */     detectDirectCall(paramNode1, paramNode2);
/* 111 */     super.visitNew(paramNode1, paramNode2);
/*     */   }
/*     */   
/*     */   protected void visitCall(Node paramNode1, Node paramNode2) {
/* 115 */     int i = detectDirectCall(paramNode1, paramNode2);
/* 116 */     if (this.inFunction && i == 0) {
/* 117 */       ((OptFunctionNode)paramNode2).setContainsCalls(i);
/*     */     }
/* 119 */     super.visitCall(paramNode1, paramNode2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void markDirectCall(Node paramNode1, Node paramNode2, int paramInt, String paramString) {
/* 137 */     OptFunctionNode optFunctionNode = 
/* 138 */       (OptFunctionNode)this.theFnClassNameList.get(paramString);
/* 139 */     if (optFunctionNode != null) {
/* 140 */       VariableTable variableTable = optFunctionNode.getVariableTable();
/*     */ 
/*     */ 
/*     */       
/* 144 */       if (variableTable.getParameterCount() > 32) {
/*     */         return;
/*     */       }
/* 147 */       if (paramInt == variableTable.getParameterCount()) {
/* 148 */         paramNode2.putProp(27, optFunctionNode);
/* 149 */         ((OptFunctionNode)paramNode1)
/* 150 */           .addDirectCallTarget(optFunctionNode);
/* 151 */         optFunctionNode.setIsTargetOfDirectCall();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void collectContainedFunctions(Node paramNode) {
/* 162 */     for (Node node = paramNode; node != null; node = node.getNextSibling()) {
/* 163 */       if (node.getType() == 109) {
/* 164 */         FunctionNode functionNode = 
/* 165 */           (FunctionNode)node.getProp(5);
/* 166 */         if (functionNode.getFunctionName().length() != 0) {
/* 167 */           String str = functionNode.getFunctionName();
/* 168 */           Object object = this.theFnClassNameList.get(str);
/* 169 */           if (object == functionNode) {
/*     */             return;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 184 */           this.theFnClassNameList.put(str, functionNode);
/*     */         } 
/* 186 */         addParameters(functionNode);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\OptTransformer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */