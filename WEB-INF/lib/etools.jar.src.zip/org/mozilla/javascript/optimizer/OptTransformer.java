package org.mozilla.javascript.optimizer;

import java.util.Hashtable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.FunctionNode;
import org.mozilla.javascript.IRFactory;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.NodeTransformer;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.TokenStream;
import org.mozilla.javascript.VariableTable;

class OptTransformer extends NodeTransformer {
  private Hashtable theFnClassNameList;
  
  OptTransformer(Hashtable paramHashtable) { this.theFnClassNameList = paramHashtable; }
  
  public NodeTransformer newInstance() { return new OptTransformer((Hashtable)this.theFnClassNameList.clone()); }
  
  public IRFactory createIRFactory(TokenStream paramTokenStream, Scriptable paramScriptable) { return new IRFactory(paramTokenStream, paramScriptable); }
  
  public Node transform(Node paramNode1, Node paramNode2, TokenStream paramTokenStream, Scriptable paramScriptable) {
    collectContainedFunctions(paramNode1.getFirstChild());
    return super.transform(paramNode1, paramNode2, paramTokenStream, paramScriptable);
  }
  
  protected VariableTable createVariableTable() { return new OptVariableTable(); }
  
  private int detectDirectCall(Node paramNode1, Node paramNode2) {
    Context context = Context.getCurrentContext();
    int i = context.getOptimizationLevel();
    Node node1 = paramNode1.getFirstChild();
    byte b = 0;
    Node node2 = node1.getNextSibling();
    while (node2 != null) {
      node2 = node2.getNextSibling();
      b++;
    } 
    if (paramNode2.getType() == 109 && i > 0)
      if (node1.getType() == 44) {
        markDirectCall(paramNode2, paramNode1, b, node1.getString());
      } else if (node1.getType() == 39) {
        Node node = node1.getFirstChild().getNextSibling();
        markDirectCall(paramNode2, paramNode1, b, node.getString());
      }  
    return b;
  }
  
  protected void visitNew(Node paramNode1, Node paramNode2) {
    detectDirectCall(paramNode1, paramNode2);
    super.visitNew(paramNode1, paramNode2);
  }
  
  protected void visitCall(Node paramNode1, Node paramNode2) {
    int i = detectDirectCall(paramNode1, paramNode2);
    if (this.inFunction && i == 0)
      ((OptFunctionNode)paramNode2).setContainsCalls(i); 
    super.visitCall(paramNode1, paramNode2);
  }
  
  void markDirectCall(Node paramNode1, Node paramNode2, int paramInt, String paramString) {
    OptFunctionNode optFunctionNode = 
      (OptFunctionNode)this.theFnClassNameList.get(paramString);
    if (optFunctionNode != null) {
      VariableTable variableTable = optFunctionNode.getVariableTable();
      if (variableTable.getParameterCount() > 32)
        return; 
      if (paramInt == variableTable.getParameterCount()) {
        paramNode2.putProp(27, optFunctionNode);
        ((OptFunctionNode)paramNode1)
          .addDirectCallTarget(optFunctionNode);
        optFunctionNode.setIsTargetOfDirectCall();
      } 
    } 
  }
  
  void collectContainedFunctions(Node paramNode) {
    for (Node node = paramNode; node != null; node = node.getNextSibling()) {
      if (node.getType() == 109) {
        FunctionNode functionNode = 
          (FunctionNode)node.getProp(5);
        if (functionNode.getFunctionName().length() != 0) {
          String str = functionNode.getFunctionName();
          Object object = this.theFnClassNameList.get(str);
          if (object == functionNode)
            return; 
          this.theFnClassNameList.put(str, functionNode);
        } 
        addParameters(functionNode);
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\OptTransformer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */