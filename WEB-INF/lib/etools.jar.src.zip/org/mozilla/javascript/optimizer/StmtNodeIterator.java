/*    */ package org.mozilla.javascript.optimizer;
/*    */ 
/*    */ import java.util.Stack;
/*    */ import org.mozilla.javascript.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StmtNodeIterator
/*    */ {
/*    */   private Stack itsStack;
/*    */   private Node itsStart;
/*    */   private Node itsCurrentNode;
/*    */   
/*    */   public StmtNodeIterator(Node paramNode) {
/* 90 */     this.itsStack = new Stack();
/*    */     this.itsStart = paramNode;
/*    */   }
/*    */   
/*    */   private Node findFirstInterestingNode(Node paramNode) {
/*    */     if (paramNode == null)
/*    */       return null; 
/*    */     if (paramNode.getType() == 132 || paramNode.getType() == 137 || paramNode.getType() == 109) {
/*    */       if (paramNode.getFirst() == null)
/*    */         return findFirstInterestingNode(paramNode.getNext()); 
/*    */       this.itsStack.push(paramNode);
/*    */       return findFirstInterestingNode(paramNode.getFirst());
/*    */     } 
/*    */     return paramNode;
/*    */   }
/*    */   
/*    */   public Node nextNode() {
/*    */     if (this.itsCurrentNode == null)
/*    */       return this.itsCurrentNode = findFirstInterestingNode(this.itsStart); 
/*    */     this.itsCurrentNode = this.itsCurrentNode.getNext();
/*    */     if (this.itsCurrentNode == null) {
/*    */       while (!this.itsStack.isEmpty()) {
/*    */         Node node = (Node)this.itsStack.pop();
/*    */         if (node.getNext() != null)
/*    */           return this.itsCurrentNode = findFirstInterestingNode(node.getNext()); 
/*    */       } 
/*    */       return null;
/*    */     } 
/*    */     return this.itsCurrentNode = findFirstInterestingNode(this.itsCurrentNode);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\StmtNodeIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */