/*    */ package org.mozilla.javascript.optimizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeEvent
/*    */ {
/*    */   public static final int EventBitLength = 2;
/*    */   public static final int AnyType = 3;
/*    */   public static final int NumberType = 1;
/*    */   public static final int NoType = 0;
/*    */   private int itsEvent;
/*    */   
/* 50 */   public TypeEvent(int paramInt) { this.itsEvent = paramInt; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   public boolean add(int paramInt) { return !((this.itsEvent |= paramInt) == paramInt); }
/*    */ 
/*    */   
/* 58 */   public int getEvent() { return this.itsEvent; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\TypeEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */