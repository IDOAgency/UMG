/*     */ package org.mozilla.javascript.optimizer;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import org.mozilla.javascript.IRFactory;
/*     */ import org.mozilla.javascript.Node;
/*     */ import org.mozilla.javascript.VariableTable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Block
/*     */ {
/*     */   private IRFactory itsIRFactory;
/*     */   private Block[] itsSuccessors;
/*     */   private Block[] itsPredecessors;
/*     */   private int itsStartNodeIndex;
/*     */   private int itsEndNodeIndex;
/*     */   private Node[] itsStatementNodes;
/*     */   private int itsBlockID;
/*     */   private DataFlowBitSet itsLiveOnEntrySet;
/*     */   private DataFlowBitSet itsLiveOnExitSet;
/*     */   private DataFlowBitSet itsUseBeforeDefSet;
/*     */   private DataFlowBitSet itsNotDefSet;
/*     */   
/*     */   public Block(int paramInt1, int paramInt2, Node[] paramArrayOfNode) {
/*  52 */     this.itsStartNodeIndex = paramInt1;
/*  53 */     this.itsEndNodeIndex = paramInt2;
/*  54 */     this.itsStatementNodes = paramArrayOfNode;
/*     */   }
/*     */   
/*  57 */   public void setBlockID(int paramInt) { this.itsBlockID = paramInt; }
/*  58 */   public int getBlockID() { return this.itsBlockID; }
/*  59 */   public Node getStartNode() { return this.itsStatementNodes[this.itsStartNodeIndex]; }
/*  60 */   public Node getEndNode() { return this.itsStatementNodes[this.itsEndNodeIndex]; }
/*     */   
/*  62 */   public Block[] getPredecessorList() { return this.itsPredecessors; }
/*  63 */   public Block[] getSuccessorList() { return this.itsSuccessors; }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Block[] buildBlocks(Node[] paramArrayOfNode) {
/*  68 */     Hashtable hashtable = new Hashtable();
/*  69 */     Vector vector = new Vector();
/*     */ 
/*     */     
/*  72 */     byte b1 = 0;
/*     */     
/*  74 */     for (byte b2 = 0; b2 < paramArrayOfNode.length; b2++) {
/*  75 */       FatBlock fatBlock; switch (paramArrayOfNode[b2].getType()) {
/*     */         
/*     */         case 136:
/*  78 */           if (b2 != b1) {
/*  79 */             FatBlock fatBlock1 = new FatBlock(b1, 
/*  80 */                 b2 - true, paramArrayOfNode);
/*  81 */             if (paramArrayOfNode[b1].getType() == 
/*  82 */               136)
/*  83 */               hashtable.put(paramArrayOfNode[b1], fatBlock1); 
/*  84 */             vector.addElement(fatBlock1);
/*     */             
/*  86 */             b1 = b2;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 6:
/*     */         case 7:
/*     */         case 8:
/*  94 */           fatBlock = new FatBlock(b1, 
/*  95 */               b2, paramArrayOfNode);
/*  96 */           if (paramArrayOfNode[b1].getType() == 
/*  97 */             136)
/*  98 */             hashtable.put(paramArrayOfNode[b1], fatBlock); 
/*  99 */           vector.addElement(fatBlock);
/*     */           
/* 101 */           b1 = b2 + 1;
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 107 */     if (b1 != paramArrayOfNode.length) {
/* 108 */       FatBlock fatBlock = new FatBlock(b1, 
/* 109 */           paramArrayOfNode.length - 1, 
/* 110 */           paramArrayOfNode);
/* 111 */       if (paramArrayOfNode[b1].getType() == 136)
/* 112 */         hashtable.put(paramArrayOfNode[b1], fatBlock); 
/* 113 */       vector.addElement(fatBlock);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 118 */     for (byte b3 = 0; b3 < vector.size(); b3++) {
/* 119 */       FatBlock fatBlock = (FatBlock)vector.elementAt(b3);
/*     */       
/* 121 */       Node node = fatBlock.getEndNode();
/* 122 */       int i = node.getType();
/*     */       
/* 124 */       if (i != 6 && 
/* 125 */         b3 < vector.size() - 1) {
/* 126 */         FatBlock fatBlock1 = (FatBlock)vector.elementAt(b3 + 1);
/* 127 */         fatBlock.addSuccessor(fatBlock1);
/* 128 */         fatBlock1.addPredecessor(fatBlock);
/*     */       } 
/*     */ 
/*     */       
/* 132 */       if (i == 8 || 
/* 133 */         i == 7 || 
/* 134 */         i == 6) {
/* 135 */         Node node1 = (Node)node.getProp(1);
/* 136 */         FatBlock fatBlock1 = 
/* 137 */           (FatBlock)hashtable.get(node1);
/* 138 */         node1.putProp(23, 
/* 139 */             fatBlock1.getSlimmerSelf());
/* 140 */         fatBlock.addSuccessor(fatBlock1);
/* 141 */         fatBlock1.addPredecessor(fatBlock);
/*     */       } 
/*     */     } 
/*     */     
/* 145 */     Block[] arrayOfBlock = new Block[vector.size()];
/*     */     
/* 147 */     for (byte b4 = 0; b4 < vector.size(); b4++) {
/* 148 */       FatBlock fatBlock = (FatBlock)vector.elementAt(b4);
/* 149 */       arrayOfBlock[b4] = fatBlock.diet();
/* 150 */       arrayOfBlock[b4].setBlockID(b4);
/*     */     } 
/*     */     
/* 153 */     return arrayOfBlock;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String toString(Block[] paramArrayOfBlock, Node[] paramArrayOfNode) {
/* 158 */     StringWriter stringWriter = new StringWriter();
/* 159 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 161 */     printWriter.println(String.valueOf(paramArrayOfBlock.length) + " Blocks");
/* 162 */     for (byte b = 0; b < paramArrayOfBlock.length; b++) {
/* 163 */       Block block = paramArrayOfBlock[b];
/* 164 */       printWriter.println("#" + block.itsBlockID);
/* 165 */       printWriter.println("from " + block.itsStartNodeIndex + 
/* 166 */           " " + 
/* 167 */           paramArrayOfNode[block.itsStartNodeIndex].toString());
/* 168 */       printWriter.println("thru " + block.itsEndNodeIndex + 
/* 169 */           " " + 
/* 170 */           paramArrayOfNode[block.itsEndNodeIndex].toString());
/* 171 */       printWriter.print("Predecessors ");
/* 172 */       if (block.itsPredecessors != null) {
/* 173 */         for (byte b1 = 0; b1 < block.itsPredecessors.length; b1++)
/* 174 */           printWriter.print(String.valueOf(block.itsPredecessors[b1].getBlockID()) + " "); 
/* 175 */         printWriter.println();
/*     */       } else {
/*     */         
/* 178 */         printWriter.println("none");
/* 179 */       }  printWriter.print("Successors ");
/* 180 */       if (block.itsSuccessors != null) {
/* 181 */         for (byte b1 = 0; b1 < block.itsSuccessors.length; b1++)
/* 182 */           printWriter.print(String.valueOf(block.itsSuccessors[b1].getBlockID()) + " "); 
/* 183 */         printWriter.println();
/*     */       } else {
/*     */         
/* 186 */         printWriter.println("none");
/*     */       } 
/* 188 */     }  return stringWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void lookForVariablesAndCalls(Node paramNode, boolean[] paramArrayOfBoolean, VariableTable paramVariableTable) {
/*     */     Object object2;
/*     */     Node node2;
/*     */     int i;
/*     */     Node node1;
/* 199 */     switch (paramNode.getType()) {
/*     */       
/*     */       case 73:
/* 202 */         node1 = paramNode.getFirstChild();
/* 203 */         node2 = node1.getNextSibling();
/* 204 */         lookForVariablesAndCalls(node2, paramArrayOfBoolean, paramVariableTable);
/* 205 */         object2 = paramNode.getProp(24);
/* 206 */         if (object2 != null) {
/* 207 */           int j = ((OptLocalVariable)object2).getIndex();
/* 208 */           paramArrayOfBoolean[j] = true;
/*     */         } 
/*     */         return;
/*     */       
/*     */       case 43:
/* 213 */         node1 = paramNode.getFirstChild();
/* 214 */         while (node1 != null) {
/* 215 */           lookForVariablesAndCalls(node1, paramArrayOfBoolean, paramVariableTable);
/* 216 */           node1 = node1.getNextSibling();
/*     */         } 
/* 218 */         for (i = 0; i < paramArrayOfBoolean.length; i++) {
/* 219 */           if (paramArrayOfBoolean[i]) {
/* 220 */             ((OptLocalVariable)paramVariableTable.get(i)).markLiveAcrossCall();
/*     */           }
/*     */         } 
/*     */         return;
/*     */       
/*     */       case 72:
/* 226 */         object1 = paramNode.getProp(24);
/* 227 */         if (object1 != null) {
/* 228 */           i = ((OptLocalVariable)object1).getIndex();
/* 229 */           if (paramNode.getProp(25) != null && 
/* 230 */             !this.itsLiveOnExitSet.test(i)) {
/* 231 */             paramArrayOfBoolean[i] = false;
/*     */           }
/*     */         } 
/*     */         return;
/*     */     } 
/* 236 */     Object object1 = paramNode.getFirstChild();
/* 237 */     while (object1 != null) {
/* 238 */       lookForVariablesAndCalls(object1, paramArrayOfBoolean, paramVariableTable);
/* 239 */       object1 = object1.getNextSibling();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void markAnyTypeVariables(VariableTable paramVariableTable) {
/* 247 */     for (byte b = 0; b < paramVariableTable.size(); b++) {
/* 248 */       if (this.itsLiveOnEntrySet.test(b)) {
/* 249 */         ((OptLocalVariable)paramVariableTable.get(b)).assignType(3);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   void markVolatileVariables(VariableTable paramVariableTable) {
/* 255 */     boolean[] arrayOfBoolean = new boolean[paramVariableTable.size()];
/* 256 */     for (byte b = 0; b < arrayOfBoolean.length; b++)
/* 257 */       arrayOfBoolean[b] = this.itsLiveOnEntrySet.test(b); 
/* 258 */     for (int i = this.itsStartNodeIndex; i <= this.itsEndNodeIndex; i++) {
/* 259 */       Node node = this.itsStatementNodes[i];
/* 260 */       lookForVariablesAndCalls(node, arrayOfBoolean, paramVariableTable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void lookForVariableAccess(Node paramNode, Node[] paramArrayOfNode) {
/*     */     Object object2;
/*     */     Node node2, node1;
/* 274 */     switch (paramNode.getType()) {
/*     */       
/*     */       case 105:
/*     */       case 106:
/* 278 */         node1 = paramNode.getFirstChild();
/* 279 */         if (node1.getType() == 72) {
/* 280 */           Object object = node1.getProp(24);
/* 281 */           if (object != null) {
/* 282 */             int i = ((OptLocalVariable)object).getIndex();
/* 283 */             if (!this.itsNotDefSet.test(i))
/* 284 */               this.itsUseBeforeDefSet.set(i); 
/* 285 */             this.itsNotDefSet.set(i);
/*     */           } 
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case 73:
/* 292 */         node1 = paramNode.getFirstChild();
/* 293 */         node2 = node1.getNextSibling();
/* 294 */         lookForVariableAccess(node2, paramArrayOfNode);
/* 295 */         object2 = paramNode.getProp(24);
/* 296 */         if (object2 != null) {
/* 297 */           int i = ((OptLocalVariable)object2).getIndex();
/* 298 */           this.itsNotDefSet.set(i);
/* 299 */           if (paramArrayOfNode[i] != null) {
/* 300 */             paramArrayOfNode[i].putProp(25, 
/* 301 */                 object2);
/*     */           }
/*     */         } 
/*     */         return;
/*     */       
/*     */       case 72:
/* 307 */         object1 = paramNode.getProp(24);
/* 308 */         if (object1 != null) {
/* 309 */           int i = ((OptLocalVariable)object1).getIndex();
/* 310 */           if (!this.itsNotDefSet.test(i))
/* 311 */             this.itsUseBeforeDefSet.set(i); 
/* 312 */           paramArrayOfNode[i] = paramNode;
/*     */         } 
/*     */         return;
/*     */     } 
/*     */     
/* 317 */     Object object1 = paramNode.getFirstChild();
/* 318 */     while (object1 != null) {
/* 319 */       lookForVariableAccess(object1, paramArrayOfNode);
/* 320 */       object1 = object1.getNextSibling();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initLiveOnEntrySets(VariableTable paramVariableTable) {
/* 333 */     int i = paramVariableTable.size();
/* 334 */     Node[] arrayOfNode = new Node[i];
/* 335 */     this.itsUseBeforeDefSet = new DataFlowBitSet(i);
/* 336 */     this.itsNotDefSet = new DataFlowBitSet(i);
/* 337 */     this.itsLiveOnEntrySet = new DataFlowBitSet(i);
/* 338 */     this.itsLiveOnExitSet = new DataFlowBitSet(i);
/* 339 */     for (int j = this.itsStartNodeIndex; j <= this.itsEndNodeIndex; j++) {
/* 340 */       Node node = this.itsStatementNodes[j];
/* 341 */       lookForVariableAccess(node, arrayOfNode);
/*     */     } 
/* 343 */     for (byte b = 0; b < i; b++) {
/* 344 */       if (arrayOfNode[b] != null)
/* 345 */         arrayOfNode[b].putProp(25, this); 
/*     */     } 
/* 347 */     this.itsNotDefSet.not();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean doReachedUseDataFlow() {
/* 358 */     this.itsLiveOnExitSet.clear();
/* 359 */     if (this.itsSuccessors != null)
/* 360 */       for (byte b = 0; b < this.itsSuccessors.length; b++)
/* 361 */         this.itsLiveOnExitSet.or((this.itsSuccessors[b]).itsLiveOnEntrySet);  
/* 362 */     return this.itsLiveOnEntrySet.df2(this.itsLiveOnExitSet, 
/* 363 */         this.itsUseBeforeDefSet, this.itsNotDefSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int findExpressionType(Node paramNode) {
/*     */     int j;
/*     */     OptLocalVariable optLocalVariable;
/* 374 */     switch (paramNode.getType()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 45:
/* 385 */         return 1;
/*     */       
/*     */       case 30:
/*     */       case 43:
/* 389 */         return 0;
/*     */       
/*     */       case 41:
/* 392 */         return 3;
/*     */       
/*     */       case 72:
/* 395 */         optLocalVariable = 
/* 396 */           (OptLocalVariable)paramNode.getProp(24);
/* 397 */         if (optLocalVariable != null) {
/* 398 */           return optLocalVariable.getTypeUnion();
/*     */         }
/*     */       
/*     */       case 11:
/*     */       case 12:
/*     */       case 13:
/*     */       case 20:
/*     */       case 21:
/*     */       case 22:
/*     */       case 24:
/*     */       case 26:
/*     */       case 27:
/*     */       case 105:
/*     */       case 106:
/* 412 */         return 1;
/*     */ 
/*     */ 
/*     */       
/*     */       case 23:
/* 417 */         node = paramNode.getFirstChild();
/* 418 */         i = findExpressionType(node);
/* 419 */         j = findExpressionType(node.getNextSibling());
/* 420 */         return i | j;
/*     */     } 
/*     */     
/* 423 */     Node node = paramNode.getFirstChild();
/* 424 */     if (node == null) {
/* 425 */       return 3;
/*     */     }
/* 427 */     int i = 0;
/* 428 */     while (node != null) {
/* 429 */       i |= findExpressionType(node);
/* 430 */       node = node.getNextSibling();
/*     */     } 
/* 432 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean findDefPoints(Node paramNode) {
/*     */     Node node3;
/*     */     OptLocalVariable optLocalVariable2;
/*     */     Node node2;
/* 440 */     boolean bool = false;
/* 441 */     switch (paramNode.getType())
/*     */     { default:
/* 443 */         node1 = paramNode.getFirstChild();
/* 444 */         while (node1 != null) {
/* 445 */           bool |= findDefPoints(node1);
/* 446 */           node1 = node1.getNextSibling();
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 492 */         return bool;case 105: case 106: node1 = paramNode.getFirstChild(); optLocalVariable2 = (OptLocalVariable)node1.getProp(24); if (optLocalVariable2 != null) bool |= optLocalVariable2.assignType(1);  return bool;case 40: node1 = paramNode.getFirstChild(); node2 = node1.getNextSibling(); node3 = node2.getNextSibling(); if (node1 != null) { if (node1.getType() == 72) { OptLocalVariable optLocalVariable = (OptLocalVariable)node1.getProp(24); if (optLocalVariable != null) optLocalVariable.assignType(3);  }  bool |= findDefPoints(node1); }  if (node2 != null) bool |= findDefPoints(node2);  if (node3 != null) bool |= findDefPoints(node3);  return bool;case 73: break; }  Node node1 = paramNode.getFirstChild(); OptLocalVariable optLocalVariable1 = (OptLocalVariable)paramNode.getProp(24); if (optLocalVariable1 != null) { node3 = node1.getNextSibling(); int i = findExpressionType(node3); bool |= optLocalVariable1.assignType(i); }  return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void localCSE(Node paramNode1, Node paramNode2, Hashtable paramHashtable, OptFunctionNode paramOptFunctionNode) {
/*     */     Node node3, node2;
/* 499 */     switch (paramNode2.getType()) {
/*     */       default:
/* 501 */         node1 = paramNode2.getFirstChild();
/* 502 */         while (node1 != null) {
/* 503 */           localCSE(paramNode2, node1, paramHashtable, paramOptFunctionNode);
/* 504 */           node1 = node1.getNextSibling();
/*     */         } 
/*     */         return;
/*     */       
/*     */       case 105:
/*     */       case 106:
/* 510 */         node1 = paramNode2.getFirstChild();
/* 511 */         if (node1.getType() == 39) {
/* 512 */           Node node = node1.getFirstChild().getNextSibling();
/* 513 */           if (node.getType() == 46) {
/* 514 */             paramHashtable.remove(node.getString());
/*     */           } else {
/* 516 */             paramHashtable.clear();
/*     */           }
/*     */         
/* 519 */         } else if (node1.getType() != 72) {
/* 520 */           paramHashtable.clear();
/*     */         } 
/*     */         return;
/*     */       case 40:
/* 524 */         node1 = paramNode2.getFirstChild();
/* 525 */         node2 = node1.getNextSibling();
/* 526 */         node3 = node2.getNextSibling();
/* 527 */         if (node1 != null) localCSE(paramNode2, node1, paramHashtable, paramOptFunctionNode); 
/* 528 */         if (node2 != null) localCSE(paramNode2, node2, paramHashtable, paramOptFunctionNode); 
/* 529 */         if (node3 != null) localCSE(paramNode2, node3, paramHashtable, paramOptFunctionNode); 
/* 530 */         if (node2.getType() == 46) {
/* 531 */           paramHashtable.remove(node2.getString());
/*     */         }
/*     */         else {
/*     */           
/* 535 */           paramHashtable.clear();
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case 39:
/* 541 */         node1 = paramNode2.getFirstChild();
/* 542 */         if (node1 != null) localCSE(paramNode2, node1, paramHashtable, paramOptFunctionNode); 
/* 543 */         if (node1.getType() == 108 && 
/* 544 */           node1.getInt() == 50) {
/* 545 */           node2 = node1.getNextSibling();
/* 546 */           if (node2.getType() == 46) {
/* 547 */             String str = node2.getString();
/*     */             
/* 549 */             Object object = paramHashtable.get(str);
/* 550 */             if (object == null) {
/* 551 */               paramHashtable.put(str, new CSEHolder(paramNode1, paramNode2));
/*     */             
/*     */             }
/* 554 */             else if (paramNode1 != null) {
/*     */               Node node4;
/*     */               
/* 557 */               if (object instanceof CSEHolder) {
/* 558 */                 CSEHolder cSEHolder = (CSEHolder)object;
/* 559 */                 Node node = cSEHolder.getPropChild.getNextSibling();
/* 560 */                 cSEHolder.getPropParent.removeChild(cSEHolder.getPropChild);
/* 561 */                 node4 = this.itsIRFactory.createNewLocal(cSEHolder.getPropChild);
/* 562 */                 paramOptFunctionNode.incrementLocalCount();
/* 563 */                 if (node == null) {
/* 564 */                   cSEHolder.getPropParent.addChildToBack(node4);
/*     */                 } else {
/* 566 */                   cSEHolder.getPropParent.addChildBefore(node4, node);
/* 567 */                 }  paramHashtable.put(str, node4);
/*     */               } else {
/*     */                 
/* 570 */                 node4 = (Node)object;
/* 571 */               }  Node node5 = paramNode2.getNextSibling();
/* 572 */               paramNode1.removeChild(paramNode2);
/* 573 */               Node node6 = this.itsIRFactory.createUseLocal(node4);
/* 574 */               if (node5 == null) {
/* 575 */                 paramNode1.addChildToBack(node6);
/*     */               } else {
/* 577 */                 paramNode1.addChildBefore(node6, node5);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         return;
/*     */       
/*     */       case 42:
/* 585 */         node1 = paramNode2.getFirstChild();
/* 586 */         node2 = node1.getNextSibling();
/* 587 */         node3 = node2.getNextSibling();
/* 588 */         if (node1 != null) localCSE(paramNode2, node1, paramHashtable, paramOptFunctionNode); 
/* 589 */         if (node2 != null) localCSE(paramNode2, node2, paramHashtable, paramOptFunctionNode); 
/* 590 */         if (node3 != null) localCSE(paramNode2, node3, paramHashtable, paramOptFunctionNode); 
/* 591 */         paramHashtable.clear();
/*     */         return;
/*     */       case 43:
/*     */         break;
/*     */     } 
/* 596 */     Node node1 = paramNode2.getFirstChild();
/* 597 */     while (node1 != null) {
/* 598 */       localCSE(paramNode2, node1, paramHashtable, paramOptFunctionNode);
/* 599 */       node1 = node1.getNextSibling();
/*     */     } 
/* 601 */     paramHashtable.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Hashtable localCSE(Hashtable paramHashtable, OptFunctionNode paramOptFunctionNode) {
/* 612 */     this.itsIRFactory = new IRFactory(null, null);
/* 613 */     if (paramHashtable == null) paramHashtable = new Hashtable(5); 
/* 614 */     for (int i = this.itsStartNodeIndex; i <= this.itsEndNodeIndex; i++) {
/* 615 */       Node node = this.itsStatementNodes[i];
/* 616 */       if (node != null)
/* 617 */         localCSE(null, node, paramHashtable, paramOptFunctionNode); 
/*     */     } 
/* 619 */     return paramHashtable;
/*     */   }
/*     */ 
/*     */   
/*     */   void findDefs() {
/* 624 */     for (int i = this.itsStartNodeIndex; i <= this.itsEndNodeIndex; i++) {
/* 625 */       Node node = this.itsStatementNodes[i];
/* 626 */       if (node != null) {
/* 627 */         findDefPoints(node);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean doTypeFlow() {
/* 633 */     boolean bool = false;
/*     */     
/* 635 */     for (int i = this.itsStartNodeIndex; i <= this.itsEndNodeIndex; i++) {
/* 636 */       Node node = this.itsStatementNodes[i];
/* 637 */       if (node != null) {
/* 638 */         bool |= findDefPoints(node);
/*     */       }
/*     */     } 
/* 641 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 646 */   public boolean isLiveOnEntry(int paramInt) { return !(this.itsLiveOnEntrySet == null || !this.itsLiveOnEntrySet.test(paramInt)); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void printLiveOnEntrySet(PrintWriter paramPrintWriter, VariableTable paramVariableTable) {
/* 651 */     for (byte b = 0; b < paramVariableTable.size(); b++) {
/* 652 */       if (this.itsUseBeforeDefSet.test(b))
/* 653 */         paramPrintWriter.println(String.valueOf(paramVariableTable.get(b).getName()) + " is used before def'd"); 
/* 654 */       if (this.itsNotDefSet.test(b))
/* 655 */         paramPrintWriter.println(String.valueOf(paramVariableTable.get(b).getName()) + " is not def'd"); 
/* 656 */       if (this.itsLiveOnEntrySet.test(b))
/* 657 */         paramPrintWriter.println(String.valueOf(paramVariableTable.get(b).getName()) + " is live on entry"); 
/* 658 */       if (this.itsLiveOnExitSet.test(b))
/* 659 */         paramPrintWriter.println(String.valueOf(paramVariableTable.get(b).getName()) + " is live on exit"); 
/*     */     } 
/*     */   }
/*     */   
/* 663 */   public void setSuccessorList(Block[] paramArrayOfBlock) { this.itsSuccessors = paramArrayOfBlock; }
/* 664 */   public void setPredecessorList(Block[] paramArrayOfBlock) { this.itsPredecessors = paramArrayOfBlock; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\Block.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */