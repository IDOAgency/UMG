package org.mozilla.javascript.optimizer;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Hashtable;
import java.util.Vector;
import org.mozilla.javascript.IRFactory;
import org.mozilla.javascript.Node;
import org.mozilla.javascript.VariableTable;

public class Block {
  private IRFactory itsIRFactory;
  
  private Block[] itsSuccessors;
  
  private Block[] itsPredecessors;
  
  private int itsStartNodeIndex;
  
  private int itsEndNodeIndex;
  
  private Node[] itsStatementNodes;
  
  private int itsBlockID;
  
  private DataFlowBitSet itsLiveOnEntrySet;
  
  private DataFlowBitSet itsLiveOnExitSet;
  
  private DataFlowBitSet itsUseBeforeDefSet;
  
  private DataFlowBitSet itsNotDefSet;
  
  public Block(int paramInt1, int paramInt2, Node[] paramArrayOfNode) {
    this.itsStartNodeIndex = paramInt1;
    this.itsEndNodeIndex = paramInt2;
    this.itsStatementNodes = paramArrayOfNode;
  }
  
  public void setBlockID(int paramInt) { this.itsBlockID = paramInt; }
  
  public int getBlockID() { return this.itsBlockID; }
  
  public Node getStartNode() { return this.itsStatementNodes[this.itsStartNodeIndex]; }
  
  public Node getEndNode() { return this.itsStatementNodes[this.itsEndNodeIndex]; }
  
  public Block[] getPredecessorList() { return this.itsPredecessors; }
  
  public Block[] getSuccessorList() { return this.itsSuccessors; }
  
  public static Block[] buildBlocks(Node[] paramArrayOfNode) {
    Hashtable hashtable = new Hashtable();
    Vector vector = new Vector();
    byte b1 = 0;
    for (byte b2 = 0; b2 < paramArrayOfNode.length; b2++) {
      FatBlock fatBlock;
      switch (paramArrayOfNode[b2].getType()) {
        case 136:
          if (b2 != b1) {
            FatBlock fatBlock1 = new FatBlock(b1, 
                b2 - true, paramArrayOfNode);
            if (paramArrayOfNode[b1].getType() == 
              136)
              hashtable.put(paramArrayOfNode[b1], fatBlock1); 
            vector.addElement(fatBlock1);
            b1 = b2;
          } 
          break;
        case 6:
        case 7:
        case 8:
          fatBlock = new FatBlock(b1, 
              b2, paramArrayOfNode);
          if (paramArrayOfNode[b1].getType() == 
            136)
            hashtable.put(paramArrayOfNode[b1], fatBlock); 
          vector.addElement(fatBlock);
          b1 = b2 + 1;
          break;
      } 
    } 
    if (b1 != paramArrayOfNode.length) {
      FatBlock fatBlock = new FatBlock(b1, 
          paramArrayOfNode.length - 1, 
          paramArrayOfNode);
      if (paramArrayOfNode[b1].getType() == 136)
        hashtable.put(paramArrayOfNode[b1], fatBlock); 
      vector.addElement(fatBlock);
    } 
    for (byte b3 = 0; b3 < vector.size(); b3++) {
      FatBlock fatBlock = (FatBlock)vector.elementAt(b3);
      Node node = fatBlock.getEndNode();
      int i = node.getType();
      if (i != 6 && 
        b3 < vector.size() - 1) {
        FatBlock fatBlock1 = (FatBlock)vector.elementAt(b3 + 1);
        fatBlock.addSuccessor(fatBlock1);
        fatBlock1.addPredecessor(fatBlock);
      } 
      if (i == 8 || 
        i == 7 || 
        i == 6) {
        Node node1 = (Node)node.getProp(1);
        FatBlock fatBlock1 = 
          (FatBlock)hashtable.get(node1);
        node1.putProp(23, 
            fatBlock1.getSlimmerSelf());
        fatBlock.addSuccessor(fatBlock1);
        fatBlock1.addPredecessor(fatBlock);
      } 
    } 
    Block[] arrayOfBlock = new Block[vector.size()];
    for (byte b4 = 0; b4 < vector.size(); b4++) {
      FatBlock fatBlock = (FatBlock)vector.elementAt(b4);
      arrayOfBlock[b4] = fatBlock.diet();
      arrayOfBlock[b4].setBlockID(b4);
    } 
    return arrayOfBlock;
  }
  
  public static String toString(Block[] paramArrayOfBlock, Node[] paramArrayOfNode) {
    StringWriter stringWriter = new StringWriter();
    PrintWriter printWriter = new PrintWriter(stringWriter);
    printWriter.println(String.valueOf(paramArrayOfBlock.length) + " Blocks");
    for (byte b = 0; b < paramArrayOfBlock.length; b++) {
      Block block = paramArrayOfBlock[b];
      printWriter.println("#" + block.itsBlockID);
      printWriter.println("from " + block.itsStartNodeIndex + 
          " " + 
          paramArrayOfNode[block.itsStartNodeIndex].toString());
      printWriter.println("thru " + block.itsEndNodeIndex + 
          " " + 
          paramArrayOfNode[block.itsEndNodeIndex].toString());
      printWriter.print("Predecessors ");
      if (block.itsPredecessors != null) {
        for (byte b1 = 0; b1 < block.itsPredecessors.length; b1++)
          printWriter.print(String.valueOf(block.itsPredecessors[b1].getBlockID()) + " "); 
        printWriter.println();
      } else {
        printWriter.println("none");
      } 
      printWriter.print("Successors ");
      if (block.itsSuccessors != null) {
        for (byte b1 = 0; b1 < block.itsSuccessors.length; b1++)
          printWriter.print(String.valueOf(block.itsSuccessors[b1].getBlockID()) + " "); 
        printWriter.println();
      } else {
        printWriter.println("none");
      } 
    } 
    return stringWriter.toString();
  }
  
  void lookForVariablesAndCalls(Node paramNode, boolean[] paramArrayOfBoolean, VariableTable paramVariableTable) {
    Object object2;
    int i;
    Node node2, node1;
    switch (paramNode.getType()) {
      case 73:
        node1 = paramNode.getFirstChild();
        node2 = node1.getNextSibling();
        lookForVariablesAndCalls(node2, paramArrayOfBoolean, paramVariableTable);
        object2 = paramNode.getProp(24);
        if (object2 != null) {
          int j = ((OptLocalVariable)object2).getIndex();
          paramArrayOfBoolean[j] = true;
        } 
        return;
      case 43:
        node1 = paramNode.getFirstChild();
        while (node1 != null) {
          lookForVariablesAndCalls(node1, paramArrayOfBoolean, paramVariableTable);
          node1 = node1.getNextSibling();
        } 
        for (i = 0; i < paramArrayOfBoolean.length; i++) {
          if (paramArrayOfBoolean[i])
            ((OptLocalVariable)paramVariableTable.get(i)).markLiveAcrossCall(); 
        } 
        return;
      case 72:
        object1 = paramNode.getProp(24);
        if (object1 != null) {
          i = ((OptLocalVariable)object1).getIndex();
          if (paramNode.getProp(25) != null && 
            !this.itsLiveOnExitSet.test(i))
            paramArrayOfBoolean[i] = false; 
        } 
        return;
    } 
    Object object1 = paramNode.getFirstChild();
    while (object1 != null) {
      lookForVariablesAndCalls(object1, paramArrayOfBoolean, paramVariableTable);
      object1 = object1.getNextSibling();
    } 
  }
  
  void markAnyTypeVariables(VariableTable paramVariableTable) {
    for (byte b = 0; b < paramVariableTable.size(); b++) {
      if (this.itsLiveOnEntrySet.test(b))
        ((OptLocalVariable)paramVariableTable.get(b)).assignType(3); 
    } 
  }
  
  void markVolatileVariables(VariableTable paramVariableTable) {
    boolean[] arrayOfBoolean = new boolean[paramVariableTable.size()];
    for (byte b = 0; b < arrayOfBoolean.length; b++)
      arrayOfBoolean[b] = this.itsLiveOnEntrySet.test(b); 
    for (int i = this.itsStartNodeIndex; i <= this.itsEndNodeIndex; i++) {
      Node node = this.itsStatementNodes[i];
      lookForVariablesAndCalls(node, arrayOfBoolean, paramVariableTable);
    } 
  }
  
  void lookForVariableAccess(Node paramNode, Node[] paramArrayOfNode) {
    Object object2;
    Node node2, node1;
    switch (paramNode.getType()) {
      case 105:
      case 106:
        node1 = paramNode.getFirstChild();
        if (node1.getType() == 72) {
          Object object = node1.getProp(24);
          if (object != null) {
            int i = ((OptLocalVariable)object).getIndex();
            if (!this.itsNotDefSet.test(i))
              this.itsUseBeforeDefSet.set(i); 
            this.itsNotDefSet.set(i);
          } 
        } 
        return;
      case 73:
        node1 = paramNode.getFirstChild();
        node2 = node1.getNextSibling();
        lookForVariableAccess(node2, paramArrayOfNode);
        object2 = paramNode.getProp(24);
        if (object2 != null) {
          int i = ((OptLocalVariable)object2).getIndex();
          this.itsNotDefSet.set(i);
          if (paramArrayOfNode[i] != null)
            paramArrayOfNode[i].putProp(25, 
                object2); 
        } 
        return;
      case 72:
        object1 = paramNode.getProp(24);
        if (object1 != null) {
          int i = ((OptLocalVariable)object1).getIndex();
          if (!this.itsNotDefSet.test(i))
            this.itsUseBeforeDefSet.set(i); 
          paramArrayOfNode[i] = paramNode;
        } 
        return;
    } 
    Object object1 = paramNode.getFirstChild();
    while (object1 != null) {
      lookForVariableAccess(object1, paramArrayOfNode);
      object1 = object1.getNextSibling();
    } 
  }
  
  public void initLiveOnEntrySets(VariableTable paramVariableTable) {
    int i = paramVariableTable.size();
    Node[] arrayOfNode = new Node[i];
    this.itsUseBeforeDefSet = new DataFlowBitSet(i);
    this.itsNotDefSet = new DataFlowBitSet(i);
    this.itsLiveOnEntrySet = new DataFlowBitSet(i);
    this.itsLiveOnExitSet = new DataFlowBitSet(i);
    for (int j = this.itsStartNodeIndex; j <= this.itsEndNodeIndex; j++) {
      Node node = this.itsStatementNodes[j];
      lookForVariableAccess(node, arrayOfNode);
    } 
    for (byte b = 0; b < i; b++) {
      if (arrayOfNode[b] != null)
        arrayOfNode[b].putProp(25, this); 
    } 
    this.itsNotDefSet.not();
  }
  
  boolean doReachedUseDataFlow() {
    this.itsLiveOnExitSet.clear();
    if (this.itsSuccessors != null)
      for (byte b = 0; b < this.itsSuccessors.length; b++)
        this.itsLiveOnExitSet.or((this.itsSuccessors[b]).itsLiveOnEntrySet);  
    return this.itsLiveOnEntrySet.df2(this.itsLiveOnExitSet, 
        this.itsUseBeforeDefSet, this.itsNotDefSet);
  }
  
  int findExpressionType(Node paramNode) {
    int j;
    OptLocalVariable optLocalVariable;
    switch (paramNode.getType()) {
      case 45:
        return 1;
      case 30:
      case 43:
        return 0;
      case 41:
        return 3;
      case 72:
        optLocalVariable = 
          (OptLocalVariable)paramNode.getProp(24);
        if (optLocalVariable != null)
          return optLocalVariable.getTypeUnion(); 
      case 11:
      case 12:
      case 13:
      case 20:
      case 21:
      case 22:
      case 24:
      case 26:
      case 27:
      case 105:
      case 106:
        return 1;
      case 23:
        node = paramNode.getFirstChild();
        i = findExpressionType(node);
        j = findExpressionType(node.getNextSibling());
        return i | j;
    } 
    Node node = paramNode.getFirstChild();
    if (node == null)
      return 3; 
    int i = 0;
    while (node != null) {
      i |= findExpressionType(node);
      node = node.getNextSibling();
    } 
    return i;
  }
  
  boolean findDefPoints(Node paramNode) {
    Node node3;
    OptLocalVariable optLocalVariable2;
    Node node2;
    boolean bool = false;
    switch (paramNode.getType()) {
      default:
        node1 = paramNode.getFirstChild();
        while (node1 != null) {
          bool |= findDefPoints(node1);
          node1 = node1.getNextSibling();
        } 
        return bool;
      case 105:
      case 106:
        node1 = paramNode.getFirstChild();
        optLocalVariable2 = (OptLocalVariable)node1.getProp(24);
        if (optLocalVariable2 != null)
          bool |= optLocalVariable2.assignType(1); 
        return bool;
      case 40:
        node1 = paramNode.getFirstChild();
        node2 = node1.getNextSibling();
        node3 = node2.getNextSibling();
        if (node1 != null) {
          if (node1.getType() == 72) {
            OptLocalVariable optLocalVariable = (OptLocalVariable)node1.getProp(24);
            if (optLocalVariable != null)
              optLocalVariable.assignType(3); 
          } 
          bool |= findDefPoints(node1);
        } 
        if (node2 != null)
          bool |= findDefPoints(node2); 
        if (node3 != null)
          bool |= findDefPoints(node3); 
        return bool;
      case 73:
        break;
    } 
    Node node1 = paramNode.getFirstChild();
    OptLocalVariable optLocalVariable1 = (OptLocalVariable)paramNode.getProp(24);
    if (optLocalVariable1 != null) {
      node3 = node1.getNextSibling();
      int i = findExpressionType(node3);
      bool |= optLocalVariable1.assignType(i);
    } 
    return bool;
  }
  
  void localCSE(Node paramNode1, Node paramNode2, Hashtable paramHashtable, OptFunctionNode paramOptFunctionNode) {
    Node node3, node2;
    switch (paramNode2.getType()) {
      default:
        node1 = paramNode2.getFirstChild();
        while (node1 != null) {
          localCSE(paramNode2, node1, paramHashtable, paramOptFunctionNode);
          node1 = node1.getNextSibling();
        } 
        return;
      case 105:
      case 106:
        node1 = paramNode2.getFirstChild();
        if (node1.getType() == 39) {
          Node node = node1.getFirstChild().getNextSibling();
          if (node.getType() == 46) {
            paramHashtable.remove(node.getString());
          } else {
            paramHashtable.clear();
          } 
        } else if (node1.getType() != 72) {
          paramHashtable.clear();
        } 
        return;
      case 40:
        node1 = paramNode2.getFirstChild();
        node2 = node1.getNextSibling();
        node3 = node2.getNextSibling();
        if (node1 != null)
          localCSE(paramNode2, node1, paramHashtable, paramOptFunctionNode); 
        if (node2 != null)
          localCSE(paramNode2, node2, paramHashtable, paramOptFunctionNode); 
        if (node3 != null)
          localCSE(paramNode2, node3, paramHashtable, paramOptFunctionNode); 
        if (node2.getType() == 46) {
          paramHashtable.remove(node2.getString());
        } else {
          paramHashtable.clear();
        } 
        return;
      case 39:
        node1 = paramNode2.getFirstChild();
        if (node1 != null)
          localCSE(paramNode2, node1, paramHashtable, paramOptFunctionNode); 
        if (node1.getType() == 108 && 
          node1.getInt() == 50) {
          node2 = node1.getNextSibling();
          if (node2.getType() == 46) {
            String str = node2.getString();
            Object object = paramHashtable.get(str);
            if (object == null) {
              paramHashtable.put(str, new CSEHolder(paramNode1, paramNode2));
            } else if (paramNode1 != null) {
              Node node4;
              if (object instanceof CSEHolder) {
                CSEHolder cSEHolder = (CSEHolder)object;
                Node node = cSEHolder.getPropChild.getNextSibling();
                cSEHolder.getPropParent.removeChild(cSEHolder.getPropChild);
                node4 = this.itsIRFactory.createNewLocal(cSEHolder.getPropChild);
                paramOptFunctionNode.incrementLocalCount();
                if (node == null) {
                  cSEHolder.getPropParent.addChildToBack(node4);
                } else {
                  cSEHolder.getPropParent.addChildBefore(node4, node);
                } 
                paramHashtable.put(str, node4);
              } else {
                node4 = (Node)object;
              } 
              Node node5 = paramNode2.getNextSibling();
              paramNode1.removeChild(paramNode2);
              Node node6 = this.itsIRFactory.createUseLocal(node4);
              if (node5 == null) {
                paramNode1.addChildToBack(node6);
              } else {
                paramNode1.addChildBefore(node6, node5);
              } 
            } 
          } 
        } 
        return;
      case 42:
        node1 = paramNode2.getFirstChild();
        node2 = node1.getNextSibling();
        node3 = node2.getNextSibling();
        if (node1 != null)
          localCSE(paramNode2, node1, paramHashtable, paramOptFunctionNode); 
        if (node2 != null)
          localCSE(paramNode2, node2, paramHashtable, paramOptFunctionNode); 
        if (node3 != null)
          localCSE(paramNode2, node3, paramHashtable, paramOptFunctionNode); 
        paramHashtable.clear();
        return;
      case 43:
        break;
    } 
    Node node1 = paramNode2.getFirstChild();
    while (node1 != null) {
      localCSE(paramNode2, node1, paramHashtable, paramOptFunctionNode);
      node1 = node1.getNextSibling();
    } 
    paramHashtable.clear();
  }
  
  Hashtable localCSE(Hashtable paramHashtable, OptFunctionNode paramOptFunctionNode) {
    this.itsIRFactory = new IRFactory(null, null);
    if (paramHashtable == null)
      paramHashtable = new Hashtable(5); 
    for (int i = this.itsStartNodeIndex; i <= this.itsEndNodeIndex; i++) {
      Node node = this.itsStatementNodes[i];
      if (node != null)
        localCSE(null, node, paramHashtable, paramOptFunctionNode); 
    } 
    return paramHashtable;
  }
  
  void findDefs() {
    for (int i = this.itsStartNodeIndex; i <= this.itsEndNodeIndex; i++) {
      Node node = this.itsStatementNodes[i];
      if (node != null)
        findDefPoints(node); 
    } 
  }
  
  public boolean doTypeFlow() {
    boolean bool = false;
    for (int i = this.itsStartNodeIndex; i <= this.itsEndNodeIndex; i++) {
      Node node = this.itsStatementNodes[i];
      if (node != null)
        bool |= findDefPoints(node); 
    } 
    return bool;
  }
  
  public boolean isLiveOnEntry(int paramInt) { return !(this.itsLiveOnEntrySet == null || !this.itsLiveOnEntrySet.test(paramInt)); }
  
  public void printLiveOnEntrySet(PrintWriter paramPrintWriter, VariableTable paramVariableTable) {
    for (byte b = 0; b < paramVariableTable.size(); b++) {
      if (this.itsUseBeforeDefSet.test(b))
        paramPrintWriter.println(String.valueOf(paramVariableTable.get(b).getName()) + " is used before def'd"); 
      if (this.itsNotDefSet.test(b))
        paramPrintWriter.println(String.valueOf(paramVariableTable.get(b).getName()) + " is not def'd"); 
      if (this.itsLiveOnEntrySet.test(b))
        paramPrintWriter.println(String.valueOf(paramVariableTable.get(b).getName()) + " is live on entry"); 
      if (this.itsLiveOnExitSet.test(b))
        paramPrintWriter.println(String.valueOf(paramVariableTable.get(b).getName()) + " is live on exit"); 
    } 
  }
  
  public void setSuccessorList(Block[] paramArrayOfBlock) { this.itsSuccessors = paramArrayOfBlock; }
  
  public void setPredecessorList(Block[] paramArrayOfBlock) { this.itsPredecessors = paramArrayOfBlock; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\Block.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */