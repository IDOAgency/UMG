package org.mozilla.javascript.optimizer;

final class JavaScriptClassLoader extends ClassLoader {
  public Class defineClass(String paramString, byte[] paramArrayOfByte) { return defineClass(paramString, paramArrayOfByte, 0, paramArrayOfByte.length); }
  
  protected Class loadClass(String paramString, boolean paramBoolean) throws ClassNotFoundException {
    Class clazz = findLoadedClass(paramString);
    if (clazz == null) {
      ClassLoader classLoader = JavaScriptClassLoader.class.getClassLoader();
      if (classLoader != null)
        return classLoader.loadClass(paramString); 
      clazz = findSystemClass(paramString);
    } 
    if (paramBoolean)
      resolveClass(clazz); 
    return clazz;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\JavaScriptClassLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */