/*    */ package org.mozilla.javascript.optimizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JavaScriptClassLoader
/*    */   extends ClassLoader
/*    */ {
/* 53 */   public Class defineClass(String paramString, byte[] paramArrayOfByte) { return defineClass(paramString, paramArrayOfByte, 0, paramArrayOfByte.length); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Class loadClass(String paramString, boolean paramBoolean) throws ClassNotFoundException {
/* 59 */     Class clazz = findLoadedClass(paramString);
/* 60 */     if (clazz == null) {
/*    */       
/* 62 */       ClassLoader classLoader = JavaScriptClassLoader.class.getClassLoader();
/* 63 */       if (classLoader != null)
/* 64 */         return classLoader.loadClass(paramString); 
/* 65 */       clazz = findSystemClass(paramString);
/*    */     } 
/* 67 */     if (paramBoolean)
/* 68 */       resolveClass(clazz); 
/* 69 */     return clazz;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\optimizer\JavaScriptClassLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */