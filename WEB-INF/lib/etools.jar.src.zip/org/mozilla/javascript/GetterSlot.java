package org.mozilla.javascript;

import java.lang.reflect.Method;

class GetterSlot extends Slot {
  Object delegateTo;
  
  Method getter;
  
  Method setter;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\GetterSlot.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */