/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JavaMembers
/*     */ {
/*     */   JavaMembers(Scriptable paramScriptable, Class paramClass) {
/*  55 */     this.members = new Hashtable(23);
/*  56 */     this.staticMembers = new Hashtable(7);
/*  57 */     this.cl = paramClass;
/*  58 */     reflect(paramScriptable, paramClass);
/*     */   }
/*     */   
/*     */   boolean has(String paramString, boolean paramBoolean) {
/*  62 */     Hashtable hashtable = paramBoolean ? this.staticMembers : this.members;
/*  63 */     Object object = hashtable.get(paramString);
/*  64 */     if (object != null) {
/*  65 */       return true;
/*     */     }
/*  67 */     Member member = findExplicitFunction(paramString, paramBoolean);
/*  68 */     return !(member == null);
/*     */   }
/*     */ 
/*     */   
/*     */   Object get(Scriptable paramScriptable, String paramString, Object paramObject, boolean paramBoolean) {
/*     */     Class clazz;
/*     */     Object object2;
/*  75 */     Hashtable hashtable = paramBoolean ? this.staticMembers : this.members;
/*  76 */     Object object1 = hashtable.get(paramString);
/*  77 */     if (!paramBoolean && object1 == null)
/*     */     {
/*  79 */       object1 = this.staticMembers.get(paramString);
/*     */     }
/*  81 */     if (object1 == null) {
/*  82 */       object1 = getExplicitFunction(paramScriptable, paramString, 
/*  83 */           paramObject, paramBoolean);
/*  84 */       if (object1 == null)
/*  85 */         return Scriptable.NOT_FOUND; 
/*     */     } 
/*  87 */     if (object1 instanceof Scriptable) {
/*  88 */       return object1;
/*     */     }
/*     */     
/*     */     try {
/*  92 */       if (object1 instanceof BeanProperty) {
/*  93 */         BeanProperty beanProperty = (BeanProperty)object1;
/*  94 */         object2 = beanProperty.getter.invoke(paramObject, ScriptRuntime.emptyArgs);
/*  95 */         clazz = beanProperty.getter.getReturnType();
/*     */       } else {
/*  97 */         Field field = (Field)object1;
/*  98 */         object2 = field.get(paramBoolean ? null : paramObject);
/*  99 */         clazz = field.getType();
/*     */       } 
/* 101 */     } catch (IllegalAccessException illegalAccessException) {
/* 102 */       throw new RuntimeException("unexpected IllegalAccessException accessing Java field");
/*     */     }
/* 104 */     catch (InvocationTargetException invocationTargetException) {
/* 105 */       throw new WrappedException(invocationTargetException.getTargetException());
/*     */     } 
/*     */     
/* 108 */     paramScriptable = ScriptableObject.getTopLevelScope(paramScriptable);
/* 109 */     return NativeJavaObject.wrap(paramScriptable, object2, clazz);
/*     */   }
/*     */   
/*     */   Member findExplicitFunction(String paramString, boolean paramBoolean) {
/* 113 */     Hashtable hashtable = paramBoolean ? this.staticMembers : this.members;
/* 114 */     int i = paramString.indexOf('(');
/* 115 */     Method[] arrayOfMethod = null;
/* 116 */     NativeJavaMethod nativeJavaMethod = null;
/* 117 */     boolean bool = (!paramBoolean || i != 0) ? 0 : 1;
/*     */     
/* 119 */     if (bool) {
/*     */       
/* 121 */       arrayOfMethod = this.ctors;
/*     */     }
/* 123 */     else if (i > 0) {
/*     */       
/* 125 */       String str = paramString.substring(0, i);
/* 126 */       Object object = hashtable.get(str);
/* 127 */       if (!paramBoolean && object == null)
/*     */       {
/* 129 */         object = this.staticMembers.get(str);
/*     */       }
/* 131 */       if (object != null && object instanceof NativeJavaMethod) {
/* 132 */         nativeJavaMethod = (NativeJavaMethod)object;
/* 133 */         arrayOfMethod = nativeJavaMethod.getMethods();
/*     */       } 
/*     */     } 
/*     */     
/* 137 */     if (arrayOfMethod != null) {
/* 138 */       for (byte b = 0; b < arrayOfMethod.length; b++) {
/* 139 */         String str = 
/* 140 */           NativeJavaMethod.signature(arrayOfMethod[b]);
/* 141 */         if (paramString.equals(str)) {
/* 142 */           return arrayOfMethod[b];
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Object getExplicitFunction(Scriptable paramScriptable, String paramString, Object paramObject, boolean paramBoolean) {
/* 153 */     Hashtable hashtable = paramBoolean ? this.staticMembers : this.members;
/* 154 */     Object object = null;
/* 155 */     Member member = findExplicitFunction(paramString, paramBoolean);
/*     */     
/* 157 */     if (member != null) {
/* 158 */       Scriptable scriptable = 
/* 159 */         ScriptableObject.getFunctionPrototype(paramScriptable);
/*     */       
/* 161 */       if (member instanceof Constructor) {
/* 162 */         NativeJavaConstructor nativeJavaConstructor = 
/* 163 */           new NativeJavaConstructor((Constructor)member);
/* 164 */         nativeJavaConstructor.setPrototype(scriptable);
/* 165 */         object = nativeJavaConstructor;
/* 166 */         hashtable.put(paramString, nativeJavaConstructor);
/*     */       } else {
/* 168 */         String str = member.getName();
/* 169 */         object = hashtable.get(str);
/*     */         
/* 171 */         if (object instanceof NativeJavaMethod && (
/* 172 */           (NativeJavaMethod)object).getMethods().length > 1) {
/* 173 */           NativeJavaMethod nativeJavaMethod = 
/* 174 */             new NativeJavaMethod((Method)member, paramString);
/* 175 */           nativeJavaMethod.setPrototype(scriptable);
/* 176 */           hashtable.put(paramString, nativeJavaMethod);
/* 177 */           object = nativeJavaMethod;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 182 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String paramString, Object paramObject1, Object paramObject2, boolean paramBoolean) {
/* 189 */     Hashtable hashtable = paramBoolean ? this.staticMembers : this.members;
/* 190 */     Object object = hashtable.get(paramString);
/* 191 */     if (!paramBoolean && object == null)
/*     */     {
/* 193 */       object = this.staticMembers.get(paramString);
/*     */     }
/* 195 */     if (object == null)
/* 196 */       throw reportMemberNotFound(paramString); 
/* 197 */     if (object instanceof FieldAndMethods) {
/* 198 */       FieldAndMethods fieldAndMethods1 = (FieldAndMethods)hashtable.get(paramString);
/* 199 */       object = fieldAndMethods1.getField();
/*     */     } 
/*     */ 
/*     */     
/* 203 */     if (object instanceof BeanProperty) {
/*     */       try {
/* 205 */         Method method = ((BeanProperty)object).setter;
/* 206 */         if (method == null)
/* 207 */           throw reportMemberNotFound(paramString); 
/* 208 */         Class[] arrayOfClass = method.getParameterTypes();
/* 209 */         Object[] arrayOfObject = { NativeJavaObject.coerceType(arrayOfClass[0], paramObject2) };
/* 210 */         method.invoke(paramObject1, arrayOfObject);
/* 211 */       } catch (IllegalAccessException illegalAccessException) {
/* 212 */         throw new RuntimeException("unexpected IllegalAccessException accessing Java field");
/*     */       }
/* 214 */       catch (InvocationTargetException invocationTargetException) {
/* 215 */         throw new WrappedException(invocationTargetException.getTargetException());
/*     */       } 
/*     */     } else {
/*     */       
/* 219 */       Field field = null;
/*     */       try {
/* 221 */         field = (Field)object;
/* 222 */         if (field == null) {
/* 223 */           Object[] arrayOfObject = { paramString };
/* 224 */           throw Context.reportRuntimeError(
/* 225 */               Context.getMessage("msg.java.internal.private", arrayOfObject));
/*     */         } 
/* 227 */         field.set(paramObject1, NativeJavaObject.coerceType(field.getType(), 
/* 228 */               paramObject2));
/* 229 */       } catch (ClassCastException classCastException) {
/* 230 */         Object[] arrayOfObject = { paramString };
/* 231 */         throw Context.reportRuntimeError(
/* 232 */             Context.getMessage("msg.java.method.assign", 
/* 233 */               arrayOfObject));
/* 234 */       } catch (IllegalAccessException illegalAccessException) {
/* 235 */         throw new RuntimeException("unexpected IllegalAccessException accessing Java field");
/*     */       }
/* 237 */       catch (IllegalArgumentException illegalArgumentException) {
/* 238 */         Object[] arrayOfObject = { paramObject2.getClass().getName(), field, 
/* 239 */             paramObject1.getClass().getName() };
/* 240 */         throw Context.reportRuntimeError(Context.getMessage(
/* 241 */               "msg.java.internal.field.type", arrayOfObject));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   Object[] getIds(boolean paramBoolean) {
/* 247 */     Hashtable hashtable = paramBoolean ? this.staticMembers : this.members;
/* 248 */     int i = hashtable.size();
/* 249 */     Object[] arrayOfObject = new Object[i];
/* 250 */     Enumeration enumeration = hashtable.keys();
/* 251 */     for (byte b = 0; b < i; b++)
/* 252 */       arrayOfObject[b] = enumeration.nextElement(); 
/* 253 */     return arrayOfObject;
/*     */   }
/*     */ 
/*     */   
/* 257 */   Class getReflectedClass() { return this.cl; }
/*     */ 
/*     */   
/*     */   void reflectField(Scriptable paramScriptable, Field paramField) {
/* 261 */     int i = paramField.getModifiers();
/* 262 */     if (!Modifier.isPublic(i))
/*     */       return; 
/* 264 */     boolean bool = Modifier.isStatic(i);
/* 265 */     Hashtable hashtable = bool ? this.staticMembers : this.members;
/* 266 */     String str = paramField.getName();
/* 267 */     Object object = hashtable.get(str);
/* 268 */     if (object != null) {
/* 269 */       if (object instanceof NativeJavaMethod) {
/* 270 */         NativeJavaMethod nativeJavaMethod = (NativeJavaMethod)object;
/* 271 */         FieldAndMethods fieldAndMethods1 = new FieldAndMethods(nativeJavaMethod.getMethods(), 
/* 272 */             paramField, 
/* 273 */             null);
/* 274 */         fieldAndMethods1.setPrototype(ScriptableObject.getFunctionPrototype(paramScriptable));
/* 275 */         getFieldAndMethodsTable(bool).put(str, fieldAndMethods1);
/* 276 */         hashtable.put(str, fieldAndMethods1);
/*     */         return;
/*     */       } 
/* 279 */       if (object instanceof Field) {
/* 280 */         Field field = (Field)object;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 286 */         if (field.getDeclaringClass().isAssignableFrom(paramField.getDeclaringClass()))
/* 287 */           hashtable.put(str, paramField); 
/*     */         return;
/*     */       } 
/* 290 */       throw new RuntimeException("unknown member type");
/*     */     } 
/* 292 */     hashtable.put(str, paramField);
/*     */   }
/*     */   
/*     */   void reflectMethod(Scriptable paramScriptable, Method paramMethod) {
/* 296 */     int i = paramMethod.getModifiers();
/* 297 */     if (!Modifier.isPublic(i))
/*     */       return; 
/* 299 */     boolean bool = Modifier.isStatic(i);
/* 300 */     Hashtable hashtable = bool ? this.staticMembers : this.members;
/* 301 */     String str = paramMethod.getName();
/* 302 */     NativeJavaMethod nativeJavaMethod = (NativeJavaMethod)hashtable.get(str);
/* 303 */     if (nativeJavaMethod == null) {
/* 304 */       nativeJavaMethod = new NativeJavaMethod();
/* 305 */       if (paramScriptable != null)
/* 306 */         nativeJavaMethod.setPrototype(ScriptableObject.getFunctionPrototype(paramScriptable)); 
/* 307 */       hashtable.put(str, nativeJavaMethod);
/* 308 */       nativeJavaMethod.add(paramMethod);
/*     */     } else {
/* 310 */       nativeJavaMethod.add(paramMethod);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void reflect(Scriptable paramScriptable, Class paramClass) {
/* 318 */     Method[] arrayOfMethod = paramClass.getMethods();
/* 319 */     for (byte b1 = 0; b1 < arrayOfMethod.length; b1++) {
/* 320 */       reflectMethod(paramScriptable, arrayOfMethod[b1]);
/*     */     }
/* 322 */     Field[] arrayOfField = paramClass.getFields();
/* 323 */     for (byte b2 = 0; b2 < arrayOfField.length; b2++) {
/* 324 */       reflectField(paramScriptable, arrayOfField[b2]);
/*     */     }
/* 326 */     makeBeanProperties(paramScriptable, false);
/* 327 */     makeBeanProperties(paramScriptable, true);
/*     */     
/* 329 */     this.ctors = paramClass.getConstructors();
/*     */   }
/*     */   
/*     */   Hashtable getFieldAndMethodsTable(boolean paramBoolean) {
/* 333 */     Hashtable hashtable = paramBoolean ? this.staticFieldAndMethods : 
/* 334 */       this.fieldAndMethods;
/* 335 */     if (hashtable == null) {
/* 336 */       hashtable = new Hashtable(11);
/* 337 */       if (paramBoolean) {
/* 338 */         this.staticFieldAndMethods = hashtable;
/*     */       } else {
/* 340 */         this.fieldAndMethods = hashtable;
/*     */       } 
/*     */     } 
/* 343 */     return hashtable;
/*     */   }
/*     */   
/*     */   void makeBeanProperties(Scriptable paramScriptable, boolean paramBoolean) {
/* 347 */     Hashtable hashtable1 = paramBoolean ? this.staticMembers : this.members;
/* 348 */     Hashtable hashtable2 = new Hashtable();
/*     */ 
/*     */     
/* 351 */     for (Enumeration enumeration1 = hashtable1.keys(); enumeration1.hasMoreElements(); ) {
/*     */ 
/*     */       
/* 354 */       String str = (String)enumeration1.nextElement();
/* 355 */       boolean bool1 = str.startsWith("get");
/* 356 */       boolean bool2 = str.startsWith("is");
/* 357 */       if (bool1 || bool2) {
/*     */         
/* 359 */         String str1 = str.substring(bool1 ? 3 : 2);
/* 360 */         if (str1.length() != 0) {
/*     */ 
/*     */ 
/*     */           
/* 364 */           String str2 = str1;
/* 365 */           if (str1.length() > 1 && 
/* 366 */             Character.isUpperCase(str1.charAt(0)) && 
/* 367 */             !Character.isUpperCase(str1.charAt(1)))
/*     */           {
/* 369 */             str2 = String.valueOf(Character.toLowerCase(str1.charAt(0))) + 
/* 370 */               str1.substring(1);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 375 */           if (!hashtable1.containsKey(str2)) {
/*     */ 
/*     */ 
/*     */             
/* 379 */             Object object = hashtable1.get(str);
/* 380 */             if (object instanceof NativeJavaMethod) {
/*     */               
/* 382 */               NativeJavaMethod nativeJavaMethod = (NativeJavaMethod)object;
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 387 */               Method[] arrayOfMethod = nativeJavaMethod.getMethods();
/*     */               Class arrayOfClass[], clazz;
/* 389 */               if (arrayOfMethod != null && 
/* 390 */                 arrayOfMethod.length == 1 && (
/* 391 */                 clazz = arrayOfMethod[false].getReturnType()) != null && (
/* 392 */                 arrayOfClass = arrayOfMethod[0].getParameterTypes()) != null && 
/* 393 */                 arrayOfClass.length == 0)
/*     */               {
/*     */ 
/*     */                 
/* 397 */                 if (!paramBoolean || Modifier.isStatic(arrayOfMethod[0].getModifiers())) {
/*     */ 
/*     */ 
/*     */                   
/* 401 */                   Method method = null;
/* 402 */                   String str3 = "set" + str1;
/* 403 */                   if (hashtable1.containsKey(str3)) {
/*     */ 
/*     */                     
/* 406 */                     object = hashtable1.get(str3);
/* 407 */                     if (object instanceof NativeJavaMethod) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                       
/* 417 */                       NativeJavaMethod nativeJavaMethod1 = (NativeJavaMethod)object;
/* 418 */                       Method[] arrayOfMethod1 = nativeJavaMethod1.getMethods();
/* 419 */                       for (byte b = 1; b <= 2 && method == null; b++) {
/* 420 */                         for (byte b1 = 0; b1 < arrayOfMethod1.length; b1++) {
/* 421 */                           if (arrayOfMethod1[b1].getReturnType() == void.class && (
/* 422 */                             !paramBoolean || Modifier.isStatic(arrayOfMethod1[b1].getModifiers())) && (
/* 423 */                             arrayOfClass = arrayOfMethod1[b1].getParameterTypes()) != null && 
/* 424 */                             arrayOfClass.length == 1)
/*     */                           {
/* 426 */                             if ((b == 1 && arrayOfClass[false] == clazz) || (
/* 427 */                               b == 2 && arrayOfClass[0].isAssignableFrom(clazz))) {
/* 428 */                               method = arrayOfMethod1[b1];
/*     */                               
/*     */                               break;
/*     */                             } 
/*     */                           }
/*     */                         } 
/*     */                       } 
/*     */                     } 
/*     */                   } 
/*     */                   
/* 438 */                   BeanProperty beanProperty = new BeanProperty(arrayOfMethod[0], method);
/* 439 */                   hashtable2.put(str2, beanProperty);
/*     */                 }  } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 445 */     }  for (Enumeration enumeration2 = hashtable2.keys(); enumeration2.hasMoreElements(); ) {
/* 446 */       String str = (String)enumeration2.nextElement();
/* 447 */       Object object = hashtable2.get(str);
/* 448 */       hashtable1.put(str, object);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Hashtable getFieldAndMethodsObjects(Scriptable paramScriptable, Object paramObject, boolean paramBoolean) {
/* 455 */     Hashtable hashtable1 = paramBoolean ? this.staticFieldAndMethods : this.fieldAndMethods;
/* 456 */     if (hashtable1 == null)
/* 457 */       return null; 
/* 458 */     int i = hashtable1.size();
/* 459 */     Hashtable hashtable2 = new Hashtable(Math.max(i, 1));
/* 460 */     Enumeration enumeration = hashtable1.elements();
/* 461 */     while (i-- > 0) {
/* 462 */       FieldAndMethods fieldAndMethods1 = (FieldAndMethods)enumeration.nextElement();
/* 463 */       fieldAndMethods1 = (FieldAndMethods)fieldAndMethods1.clone();
/* 464 */       fieldAndMethods1.setJavaObject(paramObject);
/* 465 */       hashtable2.put(fieldAndMethods1.getName(), fieldAndMethods1);
/*     */     } 
/* 467 */     return hashtable2;
/*     */   }
/*     */ 
/*     */   
/* 471 */   Constructor[] getConstructors() { return this.ctors; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JavaMembers lookupClass(Scriptable paramScriptable, Class paramClass1, Class paramClass2) {
/* 477 */     Class clazz = paramClass1;
/* 478 */     Hashtable hashtable = classTable;
/* 479 */     JavaMembers javaMembers = (JavaMembers)hashtable.get(clazz);
/* 480 */     if (javaMembers != null)
/* 481 */       return javaMembers; 
/* 482 */     if (paramClass2 != null && paramClass2 != paramClass1 && 
/* 483 */       !Modifier.isPublic(paramClass1.getModifiers()) && 
/* 484 */       Modifier.isPublic(paramClass2.getModifiers()))
/*     */     {
/* 486 */       clazz = paramClass2;
/*     */     }
/*     */     try {
/* 489 */       javaMembers = new JavaMembers(paramScriptable, clazz);
/* 490 */     } catch (SecurityException securityException) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 495 */       if (clazz != paramClass2) {
/* 496 */         javaMembers = new JavaMembers(paramScriptable, paramClass2);
/*     */       } else {
/* 498 */         throw securityException;
/*     */       } 
/* 500 */     }  if (Context.isCachingEnabled)
/* 501 */       hashtable.put(clazz, javaMembers); 
/* 502 */     return javaMembers;
/*     */   }
/*     */   
/*     */   RuntimeException reportMemberNotFound(String paramString) {
/* 506 */     Object[] arrayOfObject = { this.cl.getName(), 
/* 507 */         paramString };
/* 508 */     return Context.reportRuntimeError(
/* 509 */         Context.getMessage("msg.java.member.not.found", 
/* 510 */           arrayOfObject));
/*     */   }
/*     */   
/* 513 */   static Hashtable classTable = new Hashtable();
/*     */   private Class cl;
/*     */   private Hashtable members;
/*     */   private Hashtable fieldAndMethods;
/*     */   private Hashtable staticMembers;
/*     */   private Hashtable staticFieldAndMethods;
/*     */   private Constructor[] ctors;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\JavaMembers.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */