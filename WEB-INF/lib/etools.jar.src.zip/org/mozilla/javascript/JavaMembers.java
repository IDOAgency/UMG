package org.mozilla.javascript;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Enumeration;
import java.util.Hashtable;

class JavaMembers {
  JavaMembers(Scriptable paramScriptable, Class paramClass) {
    this.members = new Hashtable(23);
    this.staticMembers = new Hashtable(7);
    this.cl = paramClass;
    reflect(paramScriptable, paramClass);
  }
  
  boolean has(String paramString, boolean paramBoolean) {
    Hashtable hashtable = paramBoolean ? this.staticMembers : this.members;
    Object object = hashtable.get(paramString);
    if (object != null)
      return true; 
    Member member = findExplicitFunction(paramString, paramBoolean);
    return !(member == null);
  }
  
  Object get(Scriptable paramScriptable, String paramString, Object paramObject, boolean paramBoolean) {
    Class clazz;
    Object object2;
    Hashtable hashtable = paramBoolean ? this.staticMembers : this.members;
    Object object1 = hashtable.get(paramString);
    if (!paramBoolean && object1 == null)
      object1 = this.staticMembers.get(paramString); 
    if (object1 == null) {
      object1 = getExplicitFunction(paramScriptable, paramString, 
          paramObject, paramBoolean);
      if (object1 == null)
        return Scriptable.NOT_FOUND; 
    } 
    if (object1 instanceof Scriptable)
      return object1; 
    try {
      if (object1 instanceof BeanProperty) {
        BeanProperty beanProperty = (BeanProperty)object1;
        object2 = beanProperty.getter.invoke(paramObject, ScriptRuntime.emptyArgs);
        clazz = beanProperty.getter.getReturnType();
      } else {
        Field field = (Field)object1;
        object2 = field.get(paramBoolean ? null : paramObject);
        clazz = field.getType();
      } 
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException("unexpected IllegalAccessException accessing Java field");
    } catch (InvocationTargetException invocationTargetException) {
      throw new WrappedException(invocationTargetException.getTargetException());
    } 
    paramScriptable = ScriptableObject.getTopLevelScope(paramScriptable);
    return NativeJavaObject.wrap(paramScriptable, object2, clazz);
  }
  
  Member findExplicitFunction(String paramString, boolean paramBoolean) {
    Hashtable hashtable = paramBoolean ? this.staticMembers : this.members;
    int i = paramString.indexOf('(');
    Method[] arrayOfMethod = null;
    NativeJavaMethod nativeJavaMethod = null;
    boolean bool = (!paramBoolean || i != 0) ? 0 : 1;
    if (bool) {
      arrayOfMethod = this.ctors;
    } else if (i > 0) {
      String str = paramString.substring(0, i);
      Object object = hashtable.get(str);
      if (!paramBoolean && object == null)
        object = this.staticMembers.get(str); 
      if (object != null && object instanceof NativeJavaMethod) {
        nativeJavaMethod = (NativeJavaMethod)object;
        arrayOfMethod = nativeJavaMethod.getMethods();
      } 
    } 
    if (arrayOfMethod != null)
      for (byte b = 0; b < arrayOfMethod.length; b++) {
        String str = 
          NativeJavaMethod.signature(arrayOfMethod[b]);
        if (paramString.equals(str))
          return arrayOfMethod[b]; 
      }  
    return null;
  }
  
  Object getExplicitFunction(Scriptable paramScriptable, String paramString, Object paramObject, boolean paramBoolean) {
    Hashtable hashtable = paramBoolean ? this.staticMembers : this.members;
    Object object = null;
    Member member = findExplicitFunction(paramString, paramBoolean);
    if (member != null) {
      Scriptable scriptable = 
        ScriptableObject.getFunctionPrototype(paramScriptable);
      if (member instanceof Constructor) {
        NativeJavaConstructor nativeJavaConstructor = 
          new NativeJavaConstructor((Constructor)member);
        nativeJavaConstructor.setPrototype(scriptable);
        object = nativeJavaConstructor;
        hashtable.put(paramString, nativeJavaConstructor);
      } else {
        String str = member.getName();
        object = hashtable.get(str);
        if (object instanceof NativeJavaMethod && (
          (NativeJavaMethod)object).getMethods().length > 1) {
          NativeJavaMethod nativeJavaMethod = 
            new NativeJavaMethod((Method)member, paramString);
          nativeJavaMethod.setPrototype(scriptable);
          hashtable.put(paramString, nativeJavaMethod);
          object = nativeJavaMethod;
        } 
      } 
    } 
    return object;
  }
  
  public void put(String paramString, Object paramObject1, Object paramObject2, boolean paramBoolean) {
    Hashtable hashtable = paramBoolean ? this.staticMembers : this.members;
    Object object = hashtable.get(paramString);
    if (!paramBoolean && object == null)
      object = this.staticMembers.get(paramString); 
    if (object == null)
      throw reportMemberNotFound(paramString); 
    if (object instanceof FieldAndMethods) {
      FieldAndMethods fieldAndMethods1 = (FieldAndMethods)hashtable.get(paramString);
      object = fieldAndMethods1.getField();
    } 
    if (object instanceof BeanProperty) {
      try {
        Method method = ((BeanProperty)object).setter;
        if (method == null)
          throw reportMemberNotFound(paramString); 
        Class[] arrayOfClass = method.getParameterTypes();
        Object[] arrayOfObject = { NativeJavaObject.coerceType(arrayOfClass[0], paramObject2) };
        method.invoke(paramObject1, arrayOfObject);
      } catch (IllegalAccessException illegalAccessException) {
        throw new RuntimeException("unexpected IllegalAccessException accessing Java field");
      } catch (InvocationTargetException invocationTargetException) {
        throw new WrappedException(invocationTargetException.getTargetException());
      } 
    } else {
      Field field = null;
      try {
        field = (Field)object;
        if (field == null) {
          Object[] arrayOfObject = { paramString };
          throw Context.reportRuntimeError(
              Context.getMessage("msg.java.internal.private", arrayOfObject));
        } 
        field.set(paramObject1, NativeJavaObject.coerceType(field.getType(), 
              paramObject2));
      } catch (ClassCastException classCastException) {
        Object[] arrayOfObject = { paramString };
        throw Context.reportRuntimeError(
            Context.getMessage("msg.java.method.assign", 
              arrayOfObject));
      } catch (IllegalAccessException illegalAccessException) {
        throw new RuntimeException("unexpected IllegalAccessException accessing Java field");
      } catch (IllegalArgumentException illegalArgumentException) {
        Object[] arrayOfObject = { paramObject2.getClass().getName(), field, 
            paramObject1.getClass().getName() };
        throw Context.reportRuntimeError(Context.getMessage(
              "msg.java.internal.field.type", arrayOfObject));
      } 
    } 
  }
  
  Object[] getIds(boolean paramBoolean) {
    Hashtable hashtable = paramBoolean ? this.staticMembers : this.members;
    int i = hashtable.size();
    Object[] arrayOfObject = new Object[i];
    Enumeration enumeration = hashtable.keys();
    for (byte b = 0; b < i; b++)
      arrayOfObject[b] = enumeration.nextElement(); 
    return arrayOfObject;
  }
  
  Class getReflectedClass() { return this.cl; }
  
  void reflectField(Scriptable paramScriptable, Field paramField) {
    int i = paramField.getModifiers();
    if (!Modifier.isPublic(i))
      return; 
    boolean bool = Modifier.isStatic(i);
    Hashtable hashtable = bool ? this.staticMembers : this.members;
    String str = paramField.getName();
    Object object = hashtable.get(str);
    if (object != null) {
      if (object instanceof NativeJavaMethod) {
        NativeJavaMethod nativeJavaMethod = (NativeJavaMethod)object;
        FieldAndMethods fieldAndMethods1 = new FieldAndMethods(nativeJavaMethod.getMethods(), 
            paramField, 
            null);
        fieldAndMethods1.setPrototype(ScriptableObject.getFunctionPrototype(paramScriptable));
        getFieldAndMethodsTable(bool).put(str, fieldAndMethods1);
        hashtable.put(str, fieldAndMethods1);
        return;
      } 
      if (object instanceof Field) {
        Field field = (Field)object;
        if (field.getDeclaringClass().isAssignableFrom(paramField.getDeclaringClass()))
          hashtable.put(str, paramField); 
        return;
      } 
      throw new RuntimeException("unknown member type");
    } 
    hashtable.put(str, paramField);
  }
  
  void reflectMethod(Scriptable paramScriptable, Method paramMethod) {
    int i = paramMethod.getModifiers();
    if (!Modifier.isPublic(i))
      return; 
    boolean bool = Modifier.isStatic(i);
    Hashtable hashtable = bool ? this.staticMembers : this.members;
    String str = paramMethod.getName();
    NativeJavaMethod nativeJavaMethod = (NativeJavaMethod)hashtable.get(str);
    if (nativeJavaMethod == null) {
      nativeJavaMethod = new NativeJavaMethod();
      if (paramScriptable != null)
        nativeJavaMethod.setPrototype(ScriptableObject.getFunctionPrototype(paramScriptable)); 
      hashtable.put(str, nativeJavaMethod);
      nativeJavaMethod.add(paramMethod);
    } else {
      nativeJavaMethod.add(paramMethod);
    } 
  }
  
  void reflect(Scriptable paramScriptable, Class paramClass) {
    Method[] arrayOfMethod = paramClass.getMethods();
    for (byte b1 = 0; b1 < arrayOfMethod.length; b1++)
      reflectMethod(paramScriptable, arrayOfMethod[b1]); 
    Field[] arrayOfField = paramClass.getFields();
    for (byte b2 = 0; b2 < arrayOfField.length; b2++)
      reflectField(paramScriptable, arrayOfField[b2]); 
    makeBeanProperties(paramScriptable, false);
    makeBeanProperties(paramScriptable, true);
    this.ctors = paramClass.getConstructors();
  }
  
  Hashtable getFieldAndMethodsTable(boolean paramBoolean) {
    Hashtable hashtable = paramBoolean ? this.staticFieldAndMethods : 
      this.fieldAndMethods;
    if (hashtable == null) {
      hashtable = new Hashtable(11);
      if (paramBoolean) {
        this.staticFieldAndMethods = hashtable;
      } else {
        this.fieldAndMethods = hashtable;
      } 
    } 
    return hashtable;
  }
  
  void makeBeanProperties(Scriptable paramScriptable, boolean paramBoolean) {
    Hashtable hashtable1 = paramBoolean ? this.staticMembers : this.members;
    Hashtable hashtable2 = new Hashtable();
    for (Enumeration enumeration1 = hashtable1.keys(); enumeration1.hasMoreElements(); ) {
      String str = (String)enumeration1.nextElement();
      boolean bool1 = str.startsWith("get");
      boolean bool2 = str.startsWith("is");
      if (bool1 || bool2) {
        String str1 = str.substring(bool1 ? 3 : 2);
        if (str1.length() != 0) {
          String str2 = str1;
          if (str1.length() > 1 && 
            Character.isUpperCase(str1.charAt(0)) && 
            !Character.isUpperCase(str1.charAt(1)))
            str2 = String.valueOf(Character.toLowerCase(str1.charAt(0))) + 
              str1.substring(1); 
          if (!hashtable1.containsKey(str2)) {
            Object object = hashtable1.get(str);
            if (object instanceof NativeJavaMethod) {
              NativeJavaMethod nativeJavaMethod = (NativeJavaMethod)object;
              Method[] arrayOfMethod = nativeJavaMethod.getMethods();
              Class arrayOfClass[], clazz;
              if (arrayOfMethod != null && 
                arrayOfMethod.length == 1 && (
                clazz = arrayOfMethod[false].getReturnType()) != null && (
                arrayOfClass = arrayOfMethod[0].getParameterTypes()) != null && 
                arrayOfClass.length == 0)
                if (!paramBoolean || Modifier.isStatic(arrayOfMethod[0].getModifiers())) {
                  Method method = null;
                  String str3 = "set" + str1;
                  if (hashtable1.containsKey(str3)) {
                    object = hashtable1.get(str3);
                    if (object instanceof NativeJavaMethod) {
                      NativeJavaMethod nativeJavaMethod1 = (NativeJavaMethod)object;
                      Method[] arrayOfMethod1 = nativeJavaMethod1.getMethods();
                      for (byte b = 1; b <= 2 && method == null; b++) {
                        for (byte b1 = 0; b1 < arrayOfMethod1.length; b1++) {
                          if (arrayOfMethod1[b1].getReturnType() == void.class && (
                            !paramBoolean || Modifier.isStatic(arrayOfMethod1[b1].getModifiers())) && (
                            arrayOfClass = arrayOfMethod1[b1].getParameterTypes()) != null && 
                            arrayOfClass.length == 1)
                            if ((b == 1 && arrayOfClass[false] == clazz) || (
                              b == 2 && arrayOfClass[0].isAssignableFrom(clazz))) {
                              method = arrayOfMethod1[b1];
                              break;
                            }  
                        } 
                      } 
                    } 
                  } 
                  BeanProperty beanProperty = new BeanProperty(arrayOfMethod[0], method);
                  hashtable2.put(str2, beanProperty);
                }  
            } 
          } 
        } 
      } 
    } 
    for (Enumeration enumeration2 = hashtable2.keys(); enumeration2.hasMoreElements(); ) {
      String str = (String)enumeration2.nextElement();
      Object object = hashtable2.get(str);
      hashtable1.put(str, object);
    } 
  }
  
  Hashtable getFieldAndMethodsObjects(Scriptable paramScriptable, Object paramObject, boolean paramBoolean) {
    Hashtable hashtable1 = paramBoolean ? this.staticFieldAndMethods : this.fieldAndMethods;
    if (hashtable1 == null)
      return null; 
    int i = hashtable1.size();
    Hashtable hashtable2 = new Hashtable(Math.max(i, 1));
    Enumeration enumeration = hashtable1.elements();
    while (i-- > 0) {
      FieldAndMethods fieldAndMethods1 = (FieldAndMethods)enumeration.nextElement();
      fieldAndMethods1 = (FieldAndMethods)fieldAndMethods1.clone();
      fieldAndMethods1.setJavaObject(paramObject);
      hashtable2.put(fieldAndMethods1.getName(), fieldAndMethods1);
    } 
    return hashtable2;
  }
  
  Constructor[] getConstructors() { return this.ctors; }
  
  static JavaMembers lookupClass(Scriptable paramScriptable, Class paramClass1, Class paramClass2) {
    Class clazz = paramClass1;
    Hashtable hashtable = classTable;
    JavaMembers javaMembers = (JavaMembers)hashtable.get(clazz);
    if (javaMembers != null)
      return javaMembers; 
    if (paramClass2 != null && paramClass2 != paramClass1 && 
      !Modifier.isPublic(paramClass1.getModifiers()) && 
      Modifier.isPublic(paramClass2.getModifiers()))
      clazz = paramClass2; 
    try {
      javaMembers = new JavaMembers(paramScriptable, clazz);
    } catch (SecurityException securityException) {
      if (clazz != paramClass2) {
        javaMembers = new JavaMembers(paramScriptable, paramClass2);
      } else {
        throw securityException;
      } 
    } 
    if (Context.isCachingEnabled)
      hashtable.put(clazz, javaMembers); 
    return javaMembers;
  }
  
  RuntimeException reportMemberNotFound(String paramString) {
    Object[] arrayOfObject = { this.cl.getName(), 
        paramString };
    return Context.reportRuntimeError(
        Context.getMessage("msg.java.member.not.found", 
          arrayOfObject));
  }
  
  static Hashtable classTable = new Hashtable();
  
  private Class cl;
  
  private Hashtable members;
  
  private Hashtable fieldAndMethods;
  
  private Hashtable staticMembers;
  
  private Hashtable staticFieldAndMethods;
  
  private Constructor[] ctors;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\JavaMembers.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */