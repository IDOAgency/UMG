package org.mozilla.javascript;

import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Method;

public class NativeGlobal {
  public static void init(Scriptable paramScriptable) throws PropertyException, NotAFunctionException, JavaScriptException {
    String[] arrayOfString1 = { 
        "eval", 
        "parseInt", 
        "parseFloat", 
        "escape", 
        "unescape", 
        "isNaN", 
        "isFinite", 
        "decodeURI", 
        "decodeURIComponent", 
        "encodeURI", 
        "encodeURIComponent" };
    ScriptableObject scriptableObject = (ScriptableObject)paramScriptable;
    scriptableObject.defineFunctionProperties(arrayOfString1, NativeGlobal.class, 
        2);
    scriptableObject.defineProperty("NaN", ScriptRuntime.NaNobj, 
        2);
    scriptableObject.defineProperty("Infinity", new Double(Double.POSITIVE_INFINITY), 
        2);
    scriptableObject.defineProperty("undefined", Undefined.instance, 
        2);
    String[] arrayOfString2 = { "ConversionError", 
        "EvalError", 
        "RangeError", 
        "ReferenceError", 
        "SyntaxError", 
        "TypeError", 
        "URIError" };
    Method[] arrayOfMethod = FunctionObject.findMethods(NativeGlobal.class, 
        "CommonError");
    Context context = Context.getContext();
    for (byte b = 0; b < arrayOfString2.length; b++) {
      String str = arrayOfString2[b];
      FunctionObject functionObject = new FunctionObject(str, arrayOfMethod[0], scriptableObject);
      scriptableObject.defineProperty(str, functionObject, 2);
      Scriptable scriptable = context.newObject(paramScriptable, "Error");
      scriptable.put("name", scriptable, str);
      functionObject.put("prototype", functionObject, scriptable);
    } 
  }
  
  public static Object parseInt(String paramString, int paramInt) { // Byte code:
    //   0: aload_0
    //   1: invokevirtual length : ()I
    //   4: istore_2
    //   5: iload_2
    //   6: ifne -> 13
    //   9: getstatic org/mozilla/javascript/ScriptRuntime.NaNobj : Ljava/lang/Double;
    //   12: areturn
    //   13: iconst_0
    //   14: istore_3
    //   15: iconst_0
    //   16: istore #4
    //   18: aload_0
    //   19: iload #4
    //   21: invokevirtual charAt : (I)C
    //   24: istore #5
    //   26: iload #5
    //   28: invokestatic isWhitespace : (C)Z
    //   31: ifeq -> 43
    //   34: iinc #4, 1
    //   37: iload #4
    //   39: iload_2
    //   40: if_icmplt -> 18
    //   43: iload #5
    //   45: bipush #43
    //   47: if_icmpeq -> 67
    //   50: iload #5
    //   52: bipush #45
    //   54: if_icmpeq -> 61
    //   57: iconst_0
    //   58: goto -> 62
    //   61: iconst_1
    //   62: dup
    //   63: istore_3
    //   64: ifeq -> 70
    //   67: iinc #4, 1
    //   70: iconst_m1
    //   71: istore #6
    //   73: iload_1
    //   74: ifne -> 82
    //   77: iconst_m1
    //   78: istore_1
    //   79: goto -> 149
    //   82: iload_1
    //   83: iconst_2
    //   84: if_icmplt -> 93
    //   87: iload_1
    //   88: bipush #36
    //   90: if_icmple -> 97
    //   93: getstatic org/mozilla/javascript/ScriptRuntime.NaNobj : Ljava/lang/Double;
    //   96: areturn
    //   97: iload_1
    //   98: bipush #16
    //   100: if_icmpne -> 149
    //   103: iload_2
    //   104: iload #4
    //   106: isub
    //   107: iconst_1
    //   108: if_icmple -> 149
    //   111: aload_0
    //   112: iload #4
    //   114: invokevirtual charAt : (I)C
    //   117: bipush #48
    //   119: if_icmpne -> 149
    //   122: aload_0
    //   123: iload #4
    //   125: iconst_1
    //   126: iadd
    //   127: invokevirtual charAt : (I)C
    //   130: istore #5
    //   132: iload #5
    //   134: bipush #120
    //   136: if_icmpeq -> 146
    //   139: iload #5
    //   141: bipush #88
    //   143: if_icmpne -> 149
    //   146: iinc #4, 2
    //   149: iload_1
    //   150: iconst_m1
    //   151: if_icmpne -> 222
    //   154: bipush #10
    //   156: istore_1
    //   157: iload_2
    //   158: iload #4
    //   160: isub
    //   161: iconst_1
    //   162: if_icmple -> 222
    //   165: aload_0
    //   166: iload #4
    //   168: invokevirtual charAt : (I)C
    //   171: bipush #48
    //   173: if_icmpne -> 222
    //   176: aload_0
    //   177: iload #4
    //   179: iconst_1
    //   180: iadd
    //   181: invokevirtual charAt : (I)C
    //   184: istore #5
    //   186: iload #5
    //   188: bipush #120
    //   190: if_icmpeq -> 200
    //   193: iload #5
    //   195: bipush #88
    //   197: if_icmpne -> 209
    //   200: bipush #16
    //   202: istore_1
    //   203: iinc #4, 2
    //   206: goto -> 222
    //   209: iload #5
    //   211: bipush #46
    //   213: if_icmpeq -> 222
    //   216: bipush #8
    //   218: istore_1
    //   219: iinc #4, 1
    //   222: aload_0
    //   223: iload #4
    //   225: iload_1
    //   226: invokestatic stringToNumber : (Ljava/lang/String;II)D
    //   229: dstore #7
    //   231: new java/lang/Double
    //   234: dup
    //   235: iload_3
    //   236: ifeq -> 245
    //   239: dload #7
    //   241: dneg
    //   242: goto -> 247
    //   245: dload #7
    //   247: invokespecial <init> : (D)V
    //   250: areturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #116	-> 0
    //   #117	-> 5
    //   #118	-> 9
    //   #120	-> 13
    //   #121	-> 15
    //   #124	-> 18
    //   #125	-> 26
    //   #127	-> 34
    //   #128	-> 37
    //   #130	-> 43
    //   #131	-> 67
    //   #133	-> 70
    //   #134	-> 73
    //   #133	-> 77
    //   #135	-> 78
    //   #134	-> 79
    //   #136	-> 82
    //   #137	-> 93
    //   #138	-> 97
    //   #139	-> 111
    //   #141	-> 122
    //   #142	-> 132
    //   #143	-> 146
    //   #146	-> 149
    //   #133	-> 150
    //   #146	-> 151
    //   #147	-> 154
    //   #148	-> 157
    //   #149	-> 176
    //   #150	-> 186
    //   #151	-> 200
    //   #152	-> 203
    //   #150	-> 206
    //   #153	-> 209
    //   #154	-> 216
    //   #155	-> 219
    //   #160	-> 222
    //   #161	-> 231 }
  
  public static Object parseFloat(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    if (paramArrayOfObject.length < 1)
      return ScriptRuntime.NaNobj; 
    String str = ScriptRuntime.toString(paramArrayOfObject[0]);
    int i = str.length();
    if (i == 0)
      return ScriptRuntime.NaNobj; 
    byte b1;
    char c;
    for (b1 = 0; TokenStream.isJSSpace(c = str.charAt(b1)) && b1 + 1 < i; b1++);
    byte b = b1;
    if (c == '+' || c == '-')
      c = str.charAt(++b1); 
    if (c == 'I') {
      double d;
      if (b1 + 8 <= i && str.substring(b1, b1 + 8).equals("Infinity")) {
        d = (str.charAt(b) == '-') ? Double.NEGATIVE_INFINITY : 
          Double.POSITIVE_INFINITY;
      } else {
        return ScriptRuntime.NaNobj;
      } 
      return new Double(d);
    } 
    byte b2 = -1;
    byte b3 = -1;
    while (b1 < i) {
      switch (str.charAt(b1)) {
        case '.':
          if (b2 == -1) {
            b2 = b1;
          } else {
            break;
          } 
        case 'E':
        case 'e':
          if (b3 == -1) {
            b3 = b1;
          } else {
            break;
          } 
        case '+':
        case '-':
          if (b3 != b1 - 1)
            break; 
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
          b1++;
          continue;
      } 
      break;
    } 
    str = str.substring(b, b1);
    try {
      return Double.valueOf(str);
    } catch (NumberFormatException numberFormatException) {
      return ScriptRuntime.NaNobj;
    } 
  }
  
  private static int URL_XALPHAS = 1;
  
  private static int URL_XPALPHAS = 2;
  
  private static int URL_PATH = 4;
  
  public static Object escape(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    char[] arrayOfChar = { 
        '0', '1', '2', '3', '4', '5', '6', '7', 
        '8', '9', 
        'A', 'B', 'C', 'D', 'E', 'F' };
    if (paramArrayOfObject.length < 1)
      paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1); 
    String str = ScriptRuntime.toString(paramArrayOfObject[0]);
    int i = URL_XALPHAS | URL_XPALPHAS | URL_PATH;
    if (paramArrayOfObject.length > 1) {
      double d = ScriptRuntime.toNumber(paramArrayOfObject[1]);
      if (d != d || (i = (int)d) != d || (
        i & ((URL_XALPHAS | URL_XPALPHAS | URL_PATH) ^ 0xFFFFFFFF)) != 0) {
        String str1 = 
          Context.getMessage("msg.bad.esc.mask", null);
        Context.reportError(str1);
        i = URL_XALPHAS | URL_XPALPHAS | URL_PATH;
      } 
    } 
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < str.length(); b++) {
      char c = str.charAt(b);
      if (i != 0 && ((
        c >= '0' && c <= '9') || (
        c >= 'A' && c <= 'Z') || (
        c >= 'a' && c <= 'z') || 
        c == '@' || c == '*' || c == '_' || 
        c == '-' || c == '.' || ((
        c == '/' || c == '+') && i > 3))) {
        stringBuffer.append(c);
      } else if (c < 'Ā') {
        if (c == ' ' && i == URL_XPALPHAS) {
          stringBuffer.append('+');
        } else {
          stringBuffer.append('%');
          stringBuffer.append(arrayOfChar[c >> '\004']);
          stringBuffer.append(arrayOfChar[c & 0xF]);
        } 
      } else {
        stringBuffer.append('%');
        stringBuffer.append('u');
        stringBuffer.append(arrayOfChar[c >> '\f']);
        stringBuffer.append(arrayOfChar[(c & 0xF00) >> '\b']);
        stringBuffer.append(arrayOfChar[(c & 0xF0) >> '\004']);
        stringBuffer.append(arrayOfChar[c & 0xF]);
      } 
    } 
    return stringBuffer.toString();
  }
  
  public static Object unescape(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    if (paramArrayOfObject.length < 1)
      paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1); 
    String str = ScriptRuntime.toString(paramArrayOfObject[0]);
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < str.length(); b++) {
      char c = str.charAt(b);
      if (c != '%' || b == str.length() - 1) {
        stringBuffer.append(c);
      } else {
        byte b2;
        byte b1;
        if (str.charAt(b + 1) == 'u') {
          b2 = b + 2;
          b1 = b + 6;
        } else {
          b2 = b + 1;
          b1 = b + 3;
        } 
        if (b1 > str.length()) {
          stringBuffer.append('%');
        } else {
          String str1 = str.substring(b2, b1);
          byte b3 = 0;
          while (true) {
            if (b3 >= str1.length()) {
              b = b1 - 1;
              stringBuffer.append(new Character((char)Integer.valueOf(str1, 16).intValue()));
              break;
            } 
            if (!TokenStream.isXDigit(str1.charAt(b3))) {
              stringBuffer.append('%');
              break;
            } 
            b3++;
          } 
        } 
      } 
    } 
    return stringBuffer.toString();
  }
  
  public static Object isNaN(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    if (paramArrayOfObject.length < 1)
      return Boolean.TRUE; 
    double d = ScriptRuntime.toNumber(paramArrayOfObject[0]);
    return (d != d) ? Boolean.TRUE : Boolean.FALSE;
  }
  
  public static Object isFinite(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    if (paramArrayOfObject.length < 1)
      return Boolean.FALSE; 
    double d = ScriptRuntime.toNumber(paramArrayOfObject[0]);
    return (d != d || d == Double.POSITIVE_INFINITY || 
      d == Double.NEGATIVE_INFINITY) ? 
      Boolean.FALSE : 
      Boolean.TRUE;
  }
  
  public static Object eval(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    Object[] arrayOfObject = { "eval" };
    String str = ScriptRuntime.getMessage("msg.cant.call.indirect", arrayOfObject);
    throw constructError(paramContext, "EvalError", str, paramFunction);
  }
  
  public static Object evalSpecial(Context paramContext, Scriptable paramScriptable, Object paramObject, Object[] paramArrayOfObject, String paramString, int paramInt) throws JavaScriptException {
    if (paramArrayOfObject.length < 1)
      return Undefined.instance; 
    Object object = paramArrayOfObject[0];
    if (!(object instanceof String)) {
      String str = Context.getMessage("msg.eval.nonstring", null);
      Context.reportWarning(str);
      return object;
    } 
    int[] arrayOfInt = { paramInt };
    if (paramString == null) {
      paramString = Context.getSourcePositionFromStack(arrayOfInt);
      if (paramString == null) {
        paramString = "<eval'ed string>";
        arrayOfInt[0] = 1;
      } 
    } 
    try {
      StringReader stringReader = new StringReader((String)object);
      Object object1 = paramContext.getSecurityDomainForStackDepth(3);
      int i = paramContext.getOptimizationLevel();
      paramContext.setOptimizationLevel(-1);
      Script script = paramContext.compileReader(paramScriptable, stringReader, paramString, arrayOfInt[0], 
          object1);
      paramContext.setOptimizationLevel(i);
      if (script == null) {
        String str = Context.getMessage("msg.syntax", null);
        throw new EvaluatorException(str);
      } 
      InterpretedScript interpretedScript = (InterpretedScript)script;
      interpretedScript.itsData.itsFromEvalCode = true;
      return interpretedScript.call(paramContext, paramScriptable, (Scriptable)paramObject, null);
    } catch (IOException iOException) {
      throw new RuntimeException("unexpected io exception");
    } 
  }
  
  public static EcmaError constructError(Context paramContext, String paramString1, String paramString2, Object paramObject) {
    int[] arrayOfInt = new int[1];
    String str = Context.getSourcePositionFromStack(arrayOfInt);
    return constructError(paramContext, paramString1, paramString2, paramObject, 
        str, arrayOfInt[0], 0, null);
  }
  
  public static EcmaError constructError(Context paramContext, String paramString1, String paramString2, Object paramObject, String paramString3, int paramInt1, int paramInt2, String paramString4) {
    Scriptable scriptable;
    try {
      scriptable = (Scriptable)paramObject;
    } catch (ClassCastException classCastException) {
      throw new RuntimeException(classCastException.toString());
    } 
    Object[] arrayOfObject = { paramString2 };
    try {
      Scriptable scriptable1 = paramContext.newObject(scriptable, paramString1, arrayOfObject);
      return new EcmaError((NativeError)scriptable1, paramString3, 
          paramInt1, paramInt2, paramString4);
    } catch (PropertyException propertyException) {
      throw new RuntimeException(propertyException.toString());
    } catch (JavaScriptException javaScriptException) {
      throw new RuntimeException(javaScriptException.toString());
    } catch (NotAFunctionException notAFunctionException) {
      throw new RuntimeException(notAFunctionException.toString());
    } 
  }
  
  public static Object CommonError(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
    NativeError nativeError = new NativeError();
    nativeError.setPrototype((Scriptable)paramFunction.get("prototype", paramFunction));
    nativeError.setParentScope(paramContext.ctorScope);
    if (paramArrayOfObject.length > 0)
      nativeError.put("message", nativeError, paramArrayOfObject[0]); 
    return nativeError;
  }
  
  private static String encode(Context paramContext, String paramString1, String paramString2) {
    byte b = 0;
    char[] arrayOfChar = new char[6];
    StringBuffer stringBuffer = new StringBuffer();
    while (b < paramString1.length()) {
      char c = paramString1.charAt(b);
      if (paramString2.indexOf(c) != -1) {
        stringBuffer.append(c);
      } else {
        char c1;
        if (c >= '?' && c <= '?')
          throw Context.reportRuntimeError(
              Context.getMessage("msg.bad.uri", null)); 
        if (c < '?' || c > '?') {
          c1 = c;
        } else {
          b++;
          if (b == paramString1.length())
            throw Context.reportRuntimeError(
                Context.getMessage("msg.bad.uri", null)); 
          char c2 = paramString1.charAt(b);
          if (c2 < '?' || c2 > '?')
            throw Context.reportRuntimeError(
                Context.getMessage("msg.bad.uri", null)); 
          c1 = (c - '?' << '\n') + c2 - '?' + 65536;
        } 
        int i = oneUcs4ToUtf8Char(arrayOfChar, c1);
        for (byte b1 = 0; b1 < i; b1++) {
          stringBuffer.append('%');
          if (arrayOfChar[b1] < '\020')
            stringBuffer.append('0'); 
          stringBuffer.append(Integer.toHexString(arrayOfChar[b1]));
        } 
      } 
      b++;
    } 
    return stringBuffer.toString();
  }
  
  private static boolean isHex(char paramChar) {
    return !((paramChar < '0' || paramChar > '9') && (
      paramChar < 'a' || paramChar > 'f') && (
      paramChar < 'A' || paramChar > 'F'));
  }
  
  private static int unHex(char paramChar) {
    if (paramChar >= '0' && paramChar <= '9')
      return paramChar - '0'; 
    if (paramChar >= 'a' && paramChar <= 'f')
      return paramChar - 'a' + '\n'; 
    return paramChar - 'A' + '\n';
  }
  
  private static String decode(Context paramContext, String paramString1, String paramString2) {
    byte b = 0;
    char[] arrayOfChar = new char[6];
    StringBuffer stringBuffer = new StringBuffer();
    while (b < paramString1.length()) {
      char c = paramString1.charAt(b);
      if (c == '%') {
        byte b1 = b;
        if (b + 2 >= paramString1.length())
          throw Context.reportRuntimeError(
              Context.getMessage("msg.bad.uri", null)); 
        if (!isHex(paramString1.charAt(b + 1)) || !isHex(paramString1.charAt(b + 2)))
          throw Context.reportRuntimeError(
              Context.getMessage("msg.bad.uri", null)); 
        int i = unHex(paramString1.charAt(b + 1)) * 16 + unHex(paramString1.charAt(b + 2));
        b += 2;
        if ((i & 0x80) == 0) {
          c = (char)i;
        } else {
          byte b3 = 1;
          for (; (i & '' >>> b3) != 0; b3++);
          if (b3 == 1 || b3 > 6)
            throw Context.reportRuntimeError(
                Context.getMessage("msg.bad.uri", null)); 
          arrayOfChar[0] = (char)i;
          if (b + 3 * (b3 - 1) >= paramString1.length())
            throw Context.reportRuntimeError(
                Context.getMessage("msg.bad.uri", null)); 
          for (byte b2 = 1; b2 < b3; b2++) {
            b++;
            if (paramString1.charAt(b) != '%')
              throw Context.reportRuntimeError(
                  Context.getMessage("msg.bad.uri", null)); 
            if (!isHex(paramString1.charAt(b + 1)) || 
              !isHex(paramString1.charAt(b + 2)))
              throw Context.reportRuntimeError(
                  Context.getMessage("msg.bad.uri", null)); 
            i = unHex(paramString1.charAt(b + 1)) * 16 + 
              unHex(paramString1.charAt(b + 2));
            if ((i & 0xC0) != 128)
              throw Context.reportRuntimeError(
                  Context.getMessage("msg.bad.uri", null)); 
            b += 2;
            arrayOfChar[b2] = (char)i;
          } 
          int j = utf8ToOneUcs4Char(arrayOfChar, b3);
          if (j >= 65536) {
            j -= 65536;
            if (j > 1048575)
              throw Context.reportRuntimeError(
                  Context.getMessage("msg.bad.uri", null)); 
            c = (char)((j & 0x3FF) + 56320);
            char c1 = (char)((j >>> 10) + 55296);
            stringBuffer.append(c1);
          } else {
            c = (char)j;
          } 
        } 
        if (paramString2.indexOf(c) != -1) {
          for (byte b2 = 0; b2 < b - b1 + 1; b2++)
            stringBuffer.append(paramString1.charAt(b1 + b2)); 
        } else {
          stringBuffer.append(c);
        } 
      } else {
        stringBuffer.append(c);
      } 
      b++;
    } 
    return stringBuffer.toString();
  }
  
  private static String uriReservedPlusPound = ";/?:@&=+$,#";
  
  private static String uriUnescaped = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_.!~*'()";
  
  public static String decodeURI(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    String str = ScriptRuntime.toString(paramArrayOfObject[0]);
    return decode(paramContext, str, uriReservedPlusPound);
  }
  
  public static String decodeURIComponent(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    String str = ScriptRuntime.toString(paramArrayOfObject[0]);
    return decode(paramContext, str, "");
  }
  
  public static Object encodeURI(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    String str = ScriptRuntime.toString(paramArrayOfObject[0]);
    return encode(paramContext, str, String.valueOf(uriReservedPlusPound) + uriUnescaped);
  }
  
  public static String encodeURIComponent(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    String str = ScriptRuntime.toString(paramArrayOfObject[0]);
    return encode(paramContext, str, uriUnescaped);
  }
  
  private static int oneUcs4ToUtf8Char(char[] paramArrayOfChar, int paramInt) {
    byte b = 1;
    if (paramInt < 128 && paramInt >= 0) {
      paramArrayOfChar[0] = (char)paramInt;
    } else {
      int i = paramInt >>> 11;
      b = 2;
      while (i != 0) {
        i >>>= 5;
        b++;
      } 
      byte b1 = b;
      while (--b1 > 0) {
        paramArrayOfChar[b1] = (char)(paramInt & 0x3F | 0x80);
        paramInt >>>= 6;
      } 
      paramArrayOfChar[0] = (char)('Ā' - (1 << 8 - b) + paramInt);
    } 
    return b;
  }
  
  private static int utf8ToOneUcs4Char(char[] paramArrayOfChar, int paramInt) {
    char c;
    byte b = 0;
    if (paramInt == 1) {
      c = paramArrayOfChar[0];
    } else {
      c = paramArrayOfChar[b++] & (1 << 7 - paramInt) - 1;
      while (--paramInt > 0)
        c = c << '\006' | paramArrayOfChar[b++] & 0x3F; 
    } 
    return c;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeGlobal.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */