/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeGlobal
/*     */ {
/*     */   public static void init(Scriptable paramScriptable) throws PropertyException, NotAFunctionException, JavaScriptException {
/*  60 */     String[] arrayOfString1 = { "eval", 
/*  61 */         "parseInt", 
/*  62 */         "parseFloat", 
/*  63 */         "escape", 
/*  64 */         "unescape", 
/*  65 */         "isNaN", 
/*  66 */         "isFinite", 
/*  67 */         "decodeURI", 
/*  68 */         "decodeURIComponent", 
/*  69 */         "encodeURI", 
/*  70 */         "encodeURIComponent" };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     ScriptableObject scriptableObject = (ScriptableObject)paramScriptable;
/*  76 */     scriptableObject.defineFunctionProperties(arrayOfString1, NativeGlobal.class, 
/*  77 */         2);
/*     */     
/*  79 */     scriptableObject.defineProperty("NaN", ScriptRuntime.NaNobj, 
/*  80 */         2);
/*  81 */     scriptableObject.defineProperty("Infinity", new Double(Double.POSITIVE_INFINITY), 
/*  82 */         2);
/*  83 */     scriptableObject.defineProperty("undefined", Undefined.instance, 
/*  84 */         2);
/*     */     
/*  86 */     String[] arrayOfString2 = { "ConversionError", 
/*  87 */         "EvalError", 
/*  88 */         "RangeError", 
/*  89 */         "ReferenceError", 
/*  90 */         "SyntaxError", 
/*  91 */         "TypeError", 
/*  92 */         "URIError" };
/*     */     
/*  94 */     Method[] arrayOfMethod = FunctionObject.findMethods(NativeGlobal.class, 
/*  95 */         "CommonError");
/*  96 */     Context context = Context.getContext();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     for (byte b = 0; b < arrayOfString2.length; b++) {
/* 102 */       String str = arrayOfString2[b];
/* 103 */       FunctionObject functionObject = new FunctionObject(str, arrayOfMethod[0], scriptableObject);
/* 104 */       scriptableObject.defineProperty(str, functionObject, 2);
/* 105 */       Scriptable scriptable = context.newObject(paramScriptable, "Error");
/* 106 */       scriptable.put("name", scriptable, str);
/* 107 */       functionObject.put("prototype", functionObject, scriptable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object parseInt(String paramString, int paramInt) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokevirtual length : ()I
/*     */     //   4: istore_2
/*     */     //   5: iload_2
/*     */     //   6: ifne -> 13
/*     */     //   9: getstatic org/mozilla/javascript/ScriptRuntime.NaNobj : Ljava/lang/Double;
/*     */     //   12: areturn
/*     */     //   13: iconst_0
/*     */     //   14: istore_3
/*     */     //   15: iconst_0
/*     */     //   16: istore #4
/*     */     //   18: aload_0
/*     */     //   19: iload #4
/*     */     //   21: invokevirtual charAt : (I)C
/*     */     //   24: istore #5
/*     */     //   26: iload #5
/*     */     //   28: invokestatic isWhitespace : (C)Z
/*     */     //   31: ifeq -> 43
/*     */     //   34: iinc #4, 1
/*     */     //   37: iload #4
/*     */     //   39: iload_2
/*     */     //   40: if_icmplt -> 18
/*     */     //   43: iload #5
/*     */     //   45: bipush #43
/*     */     //   47: if_icmpeq -> 67
/*     */     //   50: iload #5
/*     */     //   52: bipush #45
/*     */     //   54: if_icmpeq -> 61
/*     */     //   57: iconst_0
/*     */     //   58: goto -> 62
/*     */     //   61: iconst_1
/*     */     //   62: dup
/*     */     //   63: istore_3
/*     */     //   64: ifeq -> 70
/*     */     //   67: iinc #4, 1
/*     */     //   70: iconst_m1
/*     */     //   71: istore #6
/*     */     //   73: iload_1
/*     */     //   74: ifne -> 82
/*     */     //   77: iconst_m1
/*     */     //   78: istore_1
/*     */     //   79: goto -> 149
/*     */     //   82: iload_1
/*     */     //   83: iconst_2
/*     */     //   84: if_icmplt -> 93
/*     */     //   87: iload_1
/*     */     //   88: bipush #36
/*     */     //   90: if_icmple -> 97
/*     */     //   93: getstatic org/mozilla/javascript/ScriptRuntime.NaNobj : Ljava/lang/Double;
/*     */     //   96: areturn
/*     */     //   97: iload_1
/*     */     //   98: bipush #16
/*     */     //   100: if_icmpne -> 149
/*     */     //   103: iload_2
/*     */     //   104: iload #4
/*     */     //   106: isub
/*     */     //   107: iconst_1
/*     */     //   108: if_icmple -> 149
/*     */     //   111: aload_0
/*     */     //   112: iload #4
/*     */     //   114: invokevirtual charAt : (I)C
/*     */     //   117: bipush #48
/*     */     //   119: if_icmpne -> 149
/*     */     //   122: aload_0
/*     */     //   123: iload #4
/*     */     //   125: iconst_1
/*     */     //   126: iadd
/*     */     //   127: invokevirtual charAt : (I)C
/*     */     //   130: istore #5
/*     */     //   132: iload #5
/*     */     //   134: bipush #120
/*     */     //   136: if_icmpeq -> 146
/*     */     //   139: iload #5
/*     */     //   141: bipush #88
/*     */     //   143: if_icmpne -> 149
/*     */     //   146: iinc #4, 2
/*     */     //   149: iload_1
/*     */     //   150: iconst_m1
/*     */     //   151: if_icmpne -> 222
/*     */     //   154: bipush #10
/*     */     //   156: istore_1
/*     */     //   157: iload_2
/*     */     //   158: iload #4
/*     */     //   160: isub
/*     */     //   161: iconst_1
/*     */     //   162: if_icmple -> 222
/*     */     //   165: aload_0
/*     */     //   166: iload #4
/*     */     //   168: invokevirtual charAt : (I)C
/*     */     //   171: bipush #48
/*     */     //   173: if_icmpne -> 222
/*     */     //   176: aload_0
/*     */     //   177: iload #4
/*     */     //   179: iconst_1
/*     */     //   180: iadd
/*     */     //   181: invokevirtual charAt : (I)C
/*     */     //   184: istore #5
/*     */     //   186: iload #5
/*     */     //   188: bipush #120
/*     */     //   190: if_icmpeq -> 200
/*     */     //   193: iload #5
/*     */     //   195: bipush #88
/*     */     //   197: if_icmpne -> 209
/*     */     //   200: bipush #16
/*     */     //   202: istore_1
/*     */     //   203: iinc #4, 2
/*     */     //   206: goto -> 222
/*     */     //   209: iload #5
/*     */     //   211: bipush #46
/*     */     //   213: if_icmpeq -> 222
/*     */     //   216: bipush #8
/*     */     //   218: istore_1
/*     */     //   219: iinc #4, 1
/*     */     //   222: aload_0
/*     */     //   223: iload #4
/*     */     //   225: iload_1
/*     */     //   226: invokestatic stringToNumber : (Ljava/lang/String;II)D
/*     */     //   229: dstore #7
/*     */     //   231: new java/lang/Double
/*     */     //   234: dup
/*     */     //   235: iload_3
/*     */     //   236: ifeq -> 245
/*     */     //   239: dload #7
/*     */     //   241: dneg
/*     */     //   242: goto -> 247
/*     */     //   245: dload #7
/*     */     //   247: invokespecial <init> : (D)V
/*     */     //   250: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #116	-> 0
/*     */     //   #117	-> 5
/*     */     //   #118	-> 9
/*     */     //   #120	-> 13
/*     */     //   #121	-> 15
/*     */     //   #124	-> 18
/*     */     //   #125	-> 26
/*     */     //   #127	-> 34
/*     */     //   #128	-> 37
/*     */     //   #130	-> 43
/*     */     //   #131	-> 67
/*     */     //   #133	-> 70
/*     */     //   #134	-> 73
/*     */     //   #133	-> 77
/*     */     //   #135	-> 78
/*     */     //   #134	-> 79
/*     */     //   #136	-> 82
/*     */     //   #137	-> 93
/*     */     //   #138	-> 97
/*     */     //   #139	-> 111
/*     */     //   #141	-> 122
/*     */     //   #142	-> 132
/*     */     //   #143	-> 146
/*     */     //   #146	-> 149
/*     */     //   #133	-> 150
/*     */     //   #146	-> 151
/*     */     //   #147	-> 154
/*     */     //   #148	-> 157
/*     */     //   #149	-> 176
/*     */     //   #150	-> 186
/*     */     //   #151	-> 200
/*     */     //   #152	-> 203
/*     */     //   #150	-> 206
/*     */     //   #153	-> 209
/*     */     //   #154	-> 216
/*     */     //   #155	-> 219
/*     */     //   #160	-> 222
/*     */     //   #161	-> 231 }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object parseFloat(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 175 */     if (paramArrayOfObject.length < 1)
/* 176 */       return ScriptRuntime.NaNobj; 
/* 177 */     String str = ScriptRuntime.toString(paramArrayOfObject[0]);
/* 178 */     int i = str.length();
/* 179 */     if (i == 0) {
/* 180 */       return ScriptRuntime.NaNobj;
/*     */     }
/*     */     
/*     */     byte b1;
/*     */     char c;
/* 185 */     for (b1 = 0; TokenStream.isJSSpace(c = str.charAt(b1)) && b1 + 1 < i; b1++);
/*     */ 
/*     */ 
/*     */     
/* 189 */     byte b = b1;
/*     */     
/* 191 */     if (c == '+' || c == '-') {
/* 192 */       c = str.charAt(++b1);
/*     */     }
/* 194 */     if (c == 'I') {
/*     */       double d;
/*     */       
/* 197 */       if (b1 + 8 <= i && str.substring(b1, b1 + 8).equals("Infinity")) {
/* 198 */         d = (str.charAt(b) == '-') ? Double.NEGATIVE_INFINITY : 
/* 199 */           Double.POSITIVE_INFINITY;
/*     */       } else {
/* 201 */         return ScriptRuntime.NaNobj;
/* 202 */       }  return new Double(d);
/*     */     } 
/*     */ 
/*     */     
/* 206 */     byte b2 = -1;
/* 207 */     byte b3 = -1;
/* 208 */     while (b1 < i) {
/* 209 */       switch (str.charAt(b1))
/*     */       { case '.':
/* 211 */           if (b2 == -1)
/*     */           
/* 213 */           { b2 = b1; }
/*     */           else { break; }
/*     */         
/*     */         case 'E':
/*     */         case 'e':
/* 218 */           if (b3 == -1) {
/*     */             
/* 220 */             b3 = b1;
/*     */           } else {
/*     */             break;
/*     */           } 
/*     */         case '+':
/*     */         case '-':
/* 226 */           if (b3 != b1 - 1)
/*     */             break; 
/*     */         case '0':
/*     */         case '1':
/*     */         case '2':
/*     */         case '3':
/*     */         case '4':
/*     */         case '5':
/*     */         case '6':
/*     */         case '7':
/*     */         case '8':
/*     */         case '9':
/*     */           b1++; continue; }  break;
/* 239 */     }  str = str.substring(b, b1);
/*     */     try {
/* 241 */       return Double.valueOf(str);
/*     */     }
/* 243 */     catch (NumberFormatException numberFormatException) {
/* 244 */       return ScriptRuntime.NaNobj;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 256 */   private static int URL_XALPHAS = 1;
/* 257 */   private static int URL_XPALPHAS = 2;
/* 258 */   private static int URL_PATH = 4;
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object escape(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 263 */     char[] arrayOfChar = { '0', '1', '2', '3', '4', '5', '6', '7', 
/* 264 */         '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */     
/* 266 */     if (paramArrayOfObject.length < 1) {
/* 267 */       paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1);
/*     */     }
/* 269 */     String str = ScriptRuntime.toString(paramArrayOfObject[0]);
/*     */     
/* 271 */     int i = URL_XALPHAS | URL_XPALPHAS | URL_PATH;
/* 272 */     if (paramArrayOfObject.length > 1) {
/* 273 */       double d = ScriptRuntime.toNumber(paramArrayOfObject[1]);
/* 274 */       if (d != d || (i = (int)d) != d || (
/* 275 */         i & ((URL_XALPHAS | URL_XPALPHAS | URL_PATH) ^ 0xFFFFFFFF)) != 0) {
/*     */         
/* 277 */         String str1 = 
/* 278 */           Context.getMessage("msg.bad.esc.mask", null);
/* 279 */         Context.reportError(str1);
/*     */         
/* 281 */         i = URL_XALPHAS | URL_XPALPHAS | URL_PATH;
/*     */       } 
/*     */     } 
/*     */     
/* 285 */     StringBuffer stringBuffer = new StringBuffer();
/* 286 */     for (byte b = 0; b < str.length(); b++) {
/* 287 */       char c = str.charAt(b);
/* 288 */       if (i != 0 && ((
/* 289 */         c >= '0' && c <= '9') || (
/* 290 */         c >= 'A' && c <= 'Z') || (
/* 291 */         c >= 'a' && c <= 'z') || 
/* 292 */         c == '@' || c == '*' || c == '_' || 
/* 293 */         c == '-' || c == '.' || ((
/* 294 */         c == '/' || c == '+') && i > 3))) {
/* 295 */         stringBuffer.append(c);
/* 296 */       } else if (c < 'Ā') {
/* 297 */         if (c == ' ' && i == URL_XPALPHAS) {
/* 298 */           stringBuffer.append('+');
/*     */         } else {
/* 300 */           stringBuffer.append('%');
/* 301 */           stringBuffer.append(arrayOfChar[c >> '\004']);
/* 302 */           stringBuffer.append(arrayOfChar[c & 0xF]);
/*     */         } 
/*     */       } else {
/* 305 */         stringBuffer.append('%');
/* 306 */         stringBuffer.append('u');
/* 307 */         stringBuffer.append(arrayOfChar[c >> '\f']);
/* 308 */         stringBuffer.append(arrayOfChar[(c & 0xF00) >> '\b']);
/* 309 */         stringBuffer.append(arrayOfChar[(c & 0xF0) >> '\004']);
/* 310 */         stringBuffer.append(arrayOfChar[c & 0xF]);
/*     */       } 
/*     */     } 
/* 313 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object unescape(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 323 */     if (paramArrayOfObject.length < 1) {
/* 324 */       paramArrayOfObject = ScriptRuntime.padArguments(paramArrayOfObject, 1);
/*     */     }
/* 326 */     String str = ScriptRuntime.toString(paramArrayOfObject[0]);
/* 327 */     StringBuffer stringBuffer = new StringBuffer();
/* 328 */     for (byte b = 0; b < str.length(); b++) {
/* 329 */       char c = str.charAt(b);
/* 330 */       if (c != '%' || b == str.length() - 1) {
/* 331 */         stringBuffer.append(c);
/*     */       } else {
/*     */         byte b2;
/*     */         
/*     */         byte b1;
/* 336 */         if (str.charAt(b + 1) == 'u') {
/* 337 */           b2 = b + 2;
/* 338 */           b1 = b + 6;
/*     */         } else {
/* 340 */           b2 = b + 1;
/* 341 */           b1 = b + 3;
/*     */         } 
/* 343 */         if (b1 > str.length()) {
/* 344 */           stringBuffer.append('%');
/*     */         } else {
/*     */           
/* 347 */           String str1 = str.substring(b2, b1);
/* 348 */           byte b3 = 0; while (true) { if (b3 >= str1.length())
/*     */             
/*     */             { 
/*     */ 
/*     */               
/* 353 */               b = b1 - 1;
/* 354 */               stringBuffer.append(new Character((char)Integer.valueOf(str1, 16).intValue())); break; }  if (!TokenStream.isXDigit(str1.charAt(b3))) { stringBuffer.append('%'); break; }  b3++; } 
/*     */         } 
/*     */       } 
/* 357 */     }  return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object isNaN(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 367 */     if (paramArrayOfObject.length < 1)
/* 368 */       return Boolean.TRUE; 
/* 369 */     double d = ScriptRuntime.toNumber(paramArrayOfObject[0]);
/* 370 */     return (d != d) ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object isFinite(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 376 */     if (paramArrayOfObject.length < 1)
/* 377 */       return Boolean.FALSE; 
/* 378 */     double d = ScriptRuntime.toNumber(paramArrayOfObject[0]);
/* 379 */     return (d != d || d == Double.POSITIVE_INFINITY || 
/* 380 */       d == Double.NEGATIVE_INFINITY) ? 
/* 381 */       Boolean.FALSE : 
/* 382 */       Boolean.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object eval(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 389 */     Object[] arrayOfObject = { "eval" };
/* 390 */     String str = ScriptRuntime.getMessage("msg.cant.call.indirect", arrayOfObject);
/* 391 */     throw constructError(paramContext, "EvalError", str, paramFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object evalSpecial(Context paramContext, Scriptable paramScriptable, Object paramObject, Object[] paramArrayOfObject, String paramString, int paramInt) throws JavaScriptException {
/* 404 */     if (paramArrayOfObject.length < 1)
/* 405 */       return Undefined.instance; 
/* 406 */     Object object = paramArrayOfObject[0];
/* 407 */     if (!(object instanceof String)) {
/* 408 */       String str = Context.getMessage("msg.eval.nonstring", null);
/* 409 */       Context.reportWarning(str);
/* 410 */       return object;
/*     */     } 
/* 412 */     int[] arrayOfInt = { paramInt };
/* 413 */     if (paramString == null) {
/* 414 */       paramString = Context.getSourcePositionFromStack(arrayOfInt);
/* 415 */       if (paramString == null) {
/* 416 */         paramString = "<eval'ed string>";
/* 417 */         arrayOfInt[0] = 1;
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 422 */       StringReader stringReader = new StringReader((String)object);
/* 423 */       Object object1 = paramContext.getSecurityDomainForStackDepth(3);
/*     */ 
/*     */ 
/*     */       
/* 427 */       int i = paramContext.getOptimizationLevel();
/* 428 */       paramContext.setOptimizationLevel(-1);
/* 429 */       Script script = paramContext.compileReader(paramScriptable, stringReader, paramString, arrayOfInt[0], 
/* 430 */           object1);
/* 431 */       paramContext.setOptimizationLevel(i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 437 */       if (script == null) {
/* 438 */         String str = Context.getMessage("msg.syntax", null);
/* 439 */         throw new EvaluatorException(str);
/*     */       } 
/*     */       
/* 442 */       InterpretedScript interpretedScript = (InterpretedScript)script;
/* 443 */       interpretedScript.itsData.itsFromEvalCode = true;
/* 444 */       return interpretedScript.call(paramContext, paramScriptable, (Scriptable)paramObject, null);
/*     */ 
/*     */     
/*     */     }
/* 448 */     catch (IOException iOException) {
/*     */       
/* 450 */       throw new RuntimeException("unexpected io exception");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EcmaError constructError(Context paramContext, String paramString1, String paramString2, Object paramObject) {
/* 465 */     int[] arrayOfInt = new int[1];
/* 466 */     String str = Context.getSourcePositionFromStack(arrayOfInt);
/* 467 */     return constructError(paramContext, paramString1, paramString2, paramObject, 
/* 468 */         str, arrayOfInt[0], 0, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EcmaError constructError(Context paramContext, String paramString1, String paramString2, Object paramObject, String paramString3, int paramInt1, int paramInt2, String paramString4) {
/*     */     Scriptable scriptable;
/*     */     try {
/* 487 */       scriptable = (Scriptable)paramObject;
/*     */     }
/* 489 */     catch (ClassCastException classCastException) {
/* 490 */       throw new RuntimeException(classCastException.toString());
/*     */     } 
/*     */     
/* 493 */     Object[] arrayOfObject = { paramString2 };
/*     */     try {
/* 495 */       Scriptable scriptable1 = paramContext.newObject(scriptable, paramString1, arrayOfObject);
/* 496 */       return new EcmaError((NativeError)scriptable1, paramString3, 
/* 497 */           paramInt1, paramInt2, paramString4);
/*     */     }
/* 499 */     catch (PropertyException propertyException) {
/* 500 */       throw new RuntimeException(propertyException.toString());
/*     */     }
/* 502 */     catch (JavaScriptException javaScriptException) {
/* 503 */       throw new RuntimeException(javaScriptException.toString());
/*     */     }
/* 505 */     catch (NotAFunctionException notAFunctionException) {
/* 506 */       throw new RuntimeException(notAFunctionException.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object CommonError(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) {
/* 517 */     NativeError nativeError = new NativeError();
/* 518 */     nativeError.setPrototype((Scriptable)paramFunction.get("prototype", paramFunction));
/* 519 */     nativeError.setParentScope(paramContext.ctorScope);
/* 520 */     if (paramArrayOfObject.length > 0)
/* 521 */       nativeError.put("message", nativeError, paramArrayOfObject[0]); 
/* 522 */     return nativeError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String encode(Context paramContext, String paramString1, String paramString2) {
/* 534 */     byte b = 0;
/*     */ 
/*     */     
/* 537 */     char[] arrayOfChar = new char[6];
/*     */ 
/*     */     
/* 540 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 542 */     while (b < paramString1.length()) {
/* 543 */       char c = paramString1.charAt(b);
/* 544 */       if (paramString2.indexOf(c) != -1) {
/* 545 */         stringBuffer.append(c);
/*     */       } else {
/* 547 */         char c1; if (c >= '?' && c <= '?') {
/* 548 */           throw Context.reportRuntimeError(
/* 549 */               Context.getMessage("msg.bad.uri", null));
/*     */         }
/* 551 */         if (c < '?' || c > '?') {
/* 552 */           c1 = c;
/*     */         } else {
/* 554 */           b++;
/* 555 */           if (b == paramString1.length()) {
/* 556 */             throw Context.reportRuntimeError(
/* 557 */                 Context.getMessage("msg.bad.uri", null));
/*     */           }
/* 559 */           char c2 = paramString1.charAt(b);
/* 560 */           if (c2 < '?' || c2 > '?') {
/* 561 */             throw Context.reportRuntimeError(
/* 562 */                 Context.getMessage("msg.bad.uri", null));
/*     */           }
/* 564 */           c1 = (c - '?' << '\n') + c2 - '?' + 65536;
/*     */         } 
/* 566 */         int i = oneUcs4ToUtf8Char(arrayOfChar, c1);
/* 567 */         for (byte b1 = 0; b1 < i; b1++) {
/* 568 */           stringBuffer.append('%');
/* 569 */           if (arrayOfChar[b1] < '\020')
/* 570 */             stringBuffer.append('0'); 
/* 571 */           stringBuffer.append(Integer.toHexString(arrayOfChar[b1]));
/*     */         } 
/*     */       } 
/* 574 */       b++;
/*     */     } 
/* 576 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   private static boolean isHex(char paramChar) {
/* 580 */     return !((paramChar < '0' || paramChar > '9') && (
/* 581 */       paramChar < 'a' || paramChar > 'f') && (
/* 582 */       paramChar < 'A' || paramChar > 'F'));
/*     */   }
/*     */   
/*     */   private static int unHex(char paramChar) {
/* 586 */     if (paramChar >= '0' && paramChar <= '9') {
/* 587 */       return paramChar - '0';
/*     */     }
/* 589 */     if (paramChar >= 'a' && paramChar <= 'f') {
/* 590 */       return paramChar - 'a' + '\n';
/*     */     }
/* 592 */     return paramChar - 'A' + '\n';
/*     */   }
/*     */ 
/*     */   
/*     */   private static String decode(Context paramContext, String paramString1, String paramString2) {
/* 597 */     byte b = 0;
/*     */ 
/*     */ 
/*     */     
/* 601 */     char[] arrayOfChar = new char[6];
/*     */ 
/*     */ 
/*     */     
/* 605 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 607 */     while (b < paramString1.length()) {
/* 608 */       char c = paramString1.charAt(b);
/* 609 */       if (c == '%') {
/* 610 */         byte b1 = b;
/* 611 */         if (b + 2 >= paramString1.length())
/* 612 */           throw Context.reportRuntimeError(
/* 613 */               Context.getMessage("msg.bad.uri", null)); 
/* 614 */         if (!isHex(paramString1.charAt(b + 1)) || !isHex(paramString1.charAt(b + 2)))
/* 615 */           throw Context.reportRuntimeError(
/* 616 */               Context.getMessage("msg.bad.uri", null)); 
/* 617 */         int i = unHex(paramString1.charAt(b + 1)) * 16 + unHex(paramString1.charAt(b + 2));
/* 618 */         b += 2;
/* 619 */         if ((i & 0x80) == 0) {
/* 620 */           c = (char)i;
/*     */         } else {
/* 622 */           byte b3 = 1;
/* 623 */           for (; (i & '' >>> b3) != 0; b3++);
/* 624 */           if (b3 == 1 || b3 > 6)
/* 625 */             throw Context.reportRuntimeError(
/* 626 */                 Context.getMessage("msg.bad.uri", null)); 
/* 627 */           arrayOfChar[0] = (char)i;
/* 628 */           if (b + 3 * (b3 - 1) >= paramString1.length())
/* 629 */             throw Context.reportRuntimeError(
/* 630 */                 Context.getMessage("msg.bad.uri", null)); 
/* 631 */           for (byte b2 = 1; b2 < b3; b2++) {
/* 632 */             b++;
/* 633 */             if (paramString1.charAt(b) != '%')
/* 634 */               throw Context.reportRuntimeError(
/* 635 */                   Context.getMessage("msg.bad.uri", null)); 
/* 636 */             if (!isHex(paramString1.charAt(b + 1)) || 
/* 637 */               !isHex(paramString1.charAt(b + 2)))
/* 638 */               throw Context.reportRuntimeError(
/* 639 */                   Context.getMessage("msg.bad.uri", null)); 
/* 640 */             i = unHex(paramString1.charAt(b + 1)) * 16 + 
/* 641 */               unHex(paramString1.charAt(b + 2));
/* 642 */             if ((i & 0xC0) != 128)
/* 643 */               throw Context.reportRuntimeError(
/* 644 */                   Context.getMessage("msg.bad.uri", null)); 
/* 645 */             b += 2;
/* 646 */             arrayOfChar[b2] = (char)i;
/*     */           } 
/* 648 */           int j = utf8ToOneUcs4Char(arrayOfChar, b3);
/* 649 */           if (j >= 65536) {
/* 650 */             j -= 65536;
/* 651 */             if (j > 1048575)
/* 652 */               throw Context.reportRuntimeError(
/* 653 */                   Context.getMessage("msg.bad.uri", null)); 
/* 654 */             c = (char)((j & 0x3FF) + 56320);
/* 655 */             char c1 = (char)((j >>> 10) + 55296);
/* 656 */             stringBuffer.append(c1);
/*     */           } else {
/*     */             
/* 659 */             c = (char)j;
/*     */           } 
/* 661 */         }  if (paramString2.indexOf(c) != -1) {
/* 662 */           for (byte b2 = 0; b2 < b - b1 + 1; b2++) {
/* 663 */             stringBuffer.append(paramString1.charAt(b1 + b2));
/*     */           }
/*     */         } else {
/* 666 */           stringBuffer.append(c);
/*     */         } 
/*     */       } else {
/* 669 */         stringBuffer.append(c);
/* 670 */       }  b++;
/*     */     } 
/* 672 */     return stringBuffer.toString();
/*     */   }
/*     */   
/* 675 */   private static String uriReservedPlusPound = ";/?:@&=+$,#";
/*     */   
/* 677 */   private static String uriUnescaped = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_.!~*'()";
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decodeURI(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 682 */     String str = ScriptRuntime.toString(paramArrayOfObject[0]);
/* 683 */     return decode(paramContext, str, uriReservedPlusPound);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decodeURIComponent(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 689 */     String str = ScriptRuntime.toString(paramArrayOfObject[0]);
/* 690 */     return decode(paramContext, str, "");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object encodeURI(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 696 */     String str = ScriptRuntime.toString(paramArrayOfObject[0]);
/* 697 */     return encode(paramContext, str, String.valueOf(uriReservedPlusPound) + uriUnescaped);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encodeURIComponent(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 703 */     String str = ScriptRuntime.toString(paramArrayOfObject[0]);
/* 704 */     return encode(paramContext, str, uriUnescaped);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int oneUcs4ToUtf8Char(char[] paramArrayOfChar, int paramInt) {
/* 712 */     byte b = 1;
/*     */ 
/*     */     
/* 715 */     if (paramInt < 128 && paramInt >= 0) {
/* 716 */       paramArrayOfChar[0] = (char)paramInt;
/*     */     } else {
/*     */       
/* 719 */       int i = paramInt >>> 11;
/* 720 */       b = 2;
/* 721 */       while (i != 0) {
/* 722 */         i >>>= 5;
/* 723 */         b++;
/*     */       } 
/* 725 */       byte b1 = b;
/* 726 */       while (--b1 > 0) {
/* 727 */         paramArrayOfChar[b1] = (char)(paramInt & 0x3F | 0x80);
/* 728 */         paramInt >>>= 6;
/*     */       } 
/* 730 */       paramArrayOfChar[0] = (char)('Ā' - (1 << 8 - b) + paramInt);
/*     */     } 
/* 732 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int utf8ToOneUcs4Char(char[] paramArrayOfChar, int paramInt) {
/*     */     char c;
/* 742 */     byte b = 0;
/*     */     
/* 744 */     if (paramInt == 1) {
/* 745 */       c = paramArrayOfChar[0];
/*     */     }
/*     */     else {
/*     */       
/* 749 */       c = paramArrayOfChar[b++] & (1 << 7 - paramInt) - 1;
/* 750 */       while (--paramInt > 0)
/*     */       {
/* 752 */         c = c << '\006' | paramArrayOfChar[b++] & 0x3F;
/*     */       }
/*     */     } 
/* 755 */     return c;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeGlobal.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */