package org.mozilla.javascript;

import java.io.IOException;

class Parser {
  private int lastExprEndLine;
  
  private IRFactory nf;
  
  private ErrorReporter er;
  
  private boolean ok;
  
  public Parser(IRFactory paramIRFactory) { this.nf = paramIRFactory; }
  
  private void mustMatchToken(TokenStream paramTokenStream, int paramInt, String paramString) throws IOException, JavaScriptException {
    int i;
    if ((i = paramTokenStream.getToken()) != paramInt) {
      reportError(paramTokenStream, paramString);
      paramTokenStream.ungetToken(i);
    } 
  }
  
  private void reportError(TokenStream paramTokenStream, String paramString) throws JavaScriptException {
    this.ok = false;
    paramTokenStream.reportSyntaxError(paramString, null);
    throw new JavaScriptException(paramString);
  }
  
  public Object parse(TokenStream paramTokenStream) throws IOException {
    this.ok = true;
    Source source = new Source();
    int i = paramTokenStream.getLineno();
    Object object = this.nf.createLeaf(132);
    while (true) {
      paramTokenStream.flags |= 0x10;
      int j = paramTokenStream.getToken();
      paramTokenStream.flags &= 0xFFFFFFEF;
      if (j > 0) {
        if (j == 109)
          try {
            this.nf.addChildToBack(object, function(paramTokenStream, source, false));
            source.append('\001');
            wellTerminated(paramTokenStream, 109);
            continue;
          } catch (JavaScriptException javaScriptException) {
            this.ok = false;
            break;
          }  
        paramTokenStream.ungetToken(j);
        this.nf.addChildToBack(object, statement(paramTokenStream, source));
        continue;
      } 
      break;
    } 
    if (!this.ok)
      return null; 
    return this.nf.createScript(object, paramTokenStream.getSourceName(), 
        i, paramTokenStream.getLineno(), 
        source.buf.toString());
  }
  
  private Object parseFunctionBody(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
    int i = paramTokenStream.flags;
    paramTokenStream.flags &= 0xFFFFFFF3;
    paramTokenStream.flags |= 0x2;
    Object object = this.nf.createBlock(paramTokenStream.getLineno());
    try {
      int j;
      while ((j = paramTokenStream.peekToken()) > 0 && j != 92) {
        if (j == 109) {
          paramTokenStream.getToken();
          this.nf.addChildToBack(object, function(paramTokenStream, paramSource, false));
          paramSource.append('\001');
          wellTerminated(paramTokenStream, 109);
          continue;
        } 
        this.nf.addChildToBack(object, statement(paramTokenStream, paramSource));
      } 
    } catch (JavaScriptException javaScriptException) {
      this.ok = false;
    } finally {
      paramTokenStream.flags = i;
    } 
    return object;
  }
  
  private Object function(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
    String str = null;
    Object object1 = this.nf.createLeaf(93);
    int i = paramTokenStream.getLineno();
    paramSource.append('m');
    paramSource.append(paramSource.functionNumber);
    paramSource.functionNumber = (char)(paramSource.functionNumber + '\001');
    paramSource = new Source();
    paramSource.append('m');
    if (paramTokenStream.matchToken(44)) {
      str = paramTokenStream.getString();
      paramSource.addString(44, str);
    } 
    mustMatchToken(paramTokenStream, 93, "msg.no.paren.parms");
    paramSource.append(']');
    if (!paramTokenStream.matchToken(94)) {
      boolean bool = true;
      do {
        if (!bool)
          paramSource.append('_'); 
        bool = false;
        mustMatchToken(paramTokenStream, 44, "msg.no.parm");
        String str1 = paramTokenStream.getString();
        this.nf.addChildToBack(object1, this.nf.createName(str1));
        paramSource.addString(44, str1);
      } while (paramTokenStream.matchToken(95));
      mustMatchToken(paramTokenStream, 94, "msg.no.paren.after.parms");
    } 
    paramSource.append('^');
    mustMatchToken(paramTokenStream, 91, "msg.no.brace.body");
    paramSource.append('[');
    paramSource.append('\001');
    Object object2 = parseFunctionBody(paramTokenStream, paramSource);
    mustMatchToken(paramTokenStream, 92, "msg.no.brace.after.body");
    paramSource.append('\\');
    return this.nf.createFunction(str, object1, object2, 
        paramTokenStream.getSourceName(), 
        i, paramTokenStream.getLineno(), 
        paramSource.buf.toString(), 
        paramBoolean);
  }
  
  private Object statements(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
    Object object = this.nf.createBlock(paramTokenStream.getLineno());
    int i;
    while ((i = paramTokenStream.peekToken()) > 0 && i != 92)
      this.nf.addChildToBack(object, statement(paramTokenStream, paramSource)); 
    return object;
  }
  
  private Object condition(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
    mustMatchToken(paramTokenStream, 93, "msg.no.paren.cond");
    paramSource.append(']');
    Object object = expr(paramTokenStream, paramSource, false);
    mustMatchToken(paramTokenStream, 94, "msg.no.paren.after.cond");
    paramSource.append('^');
    return object;
  }
  
  private boolean wellTerminated(TokenStream paramTokenStream, int paramInt) throws IOException, JavaScriptException {
    int i = paramTokenStream.peekTokenSameLine();
    if (i == -1)
      return false; 
    if (i != 0 && i != 1 && 
      i != 88 && i != 92) {
      int j = Context.getContext().getLanguageVersion();
      if ((i == 109 || paramInt == 109) && 
        j < 120)
        return true; 
      reportError(paramTokenStream, "msg.no.semi.stmt");
    } 
    return true;
  }
  
  private String matchLabel(TokenStream paramTokenStream) throws IOException, JavaScriptException {
    int i = paramTokenStream.getLineno();
    String str = null;
    int j = paramTokenStream.peekTokenSameLine();
    if (j == 44) {
      paramTokenStream.getToken();
      str = paramTokenStream.getString();
    } 
    if (i == paramTokenStream.getLineno())
      wellTerminated(paramTokenStream, -1); 
    return str;
  }
  
  private Object statement(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
    try {
      return statementHelper(paramTokenStream, paramSource);
    } catch (JavaScriptException javaScriptException) {
      int j, i = paramTokenStream.getLineno();
      do {
        j = paramTokenStream.getToken();
      } while (j != 88 && j != 1 && 
        j != 0 && j != -1);
      return this.nf.createExprStatement(this.nf.createName("error"), i);
    } 
  }
  
  private Object statementHelper(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
    int i2;
    Object object7;
    boolean bool2;
    Object object6, object5;
    int i1;
    Object object4, object2;
    int m, n;
    Object object3;
    int k;
    Object object1 = null;
    boolean bool1 = false;
    int j = 0;
    int i = paramTokenStream.getToken();
    switch (i) {
      case 112:
        bool1 = true;
        paramSource.append('p');
        n = paramTokenStream.getLineno();
        object4 = condition(paramTokenStream, paramSource);
        paramSource.append('[');
        paramSource.append('\001');
        object5 = statement(paramTokenStream, paramSource);
        object6 = null;
        if (paramTokenStream.matchToken(113)) {
          paramSource.append('\\');
          paramSource.append('q');
          paramSource.append('[');
          paramSource.append('\001');
          object6 = statement(paramTokenStream, paramSource);
        } 
        paramSource.append('\\');
        paramSource.append('\001');
        object1 = this.nf.createIf(object4, object5, object6, n);
        break;
      case 114:
        bool1 = true;
        paramSource.append('r');
        object1 = this.nf.createSwitch(paramTokenStream.getLineno());
        object3 = null;
        mustMatchToken(paramTokenStream, 93, "msg.no.paren.switch");
        paramSource.append(']');
        this.nf.addChildToBack(object1, expr(paramTokenStream, paramSource, false));
        mustMatchToken(paramTokenStream, 94, "msg.no.paren.after.switch");
        paramSource.append('^');
        mustMatchToken(paramTokenStream, 91, "msg.no.brace.switch");
        paramSource.append('[');
        paramSource.append('\001');
        while ((i = paramTokenStream.getToken()) != 92 && i != 0) {
          switch (i) {
            case 115:
              paramSource.append('s');
              object3 = this.nf.createUnary(115, expr(paramTokenStream, paramSource, false));
              paramSource.append('b');
              paramSource.append('\001');
              break;
            case 116:
              object3 = this.nf.createLeaf(116);
              paramSource.append('t');
              paramSource.append('b');
              paramSource.append('\001');
              break;
            default:
              reportError(paramTokenStream, "msg.bad.switch");
              break;
          } 
          mustMatchToken(paramTokenStream, 98, "msg.no.colon.case");
          object4 = this.nf.createLeaf(132);
          while ((i = paramTokenStream.peekToken()) != 92 && i != 115 && 
            i != 116 && i != 0)
            this.nf.addChildToBack(object4, statement(paramTokenStream, paramSource)); 
          this.nf.addChildToBack(object3, object4);
          this.nf.addChildToBack(object1, object3);
        } 
        paramSource.append('\\');
        paramSource.append('\001');
        break;
      case 117:
        bool1 = true;
        paramSource.append('u');
        m = paramTokenStream.getLineno();
        object4 = condition(paramTokenStream, paramSource);
        paramSource.append('[');
        paramSource.append('\001');
        object5 = statement(paramTokenStream, paramSource);
        paramSource.append('\\');
        paramSource.append('\001');
        object1 = this.nf.createWhile(object4, object5, m);
        break;
      case 118:
        paramSource.append('v');
        paramSource.append('[');
        paramSource.append('\001');
        m = paramTokenStream.getLineno();
        object4 = statement(paramTokenStream, paramSource);
        paramSource.append('\\');
        mustMatchToken(paramTokenStream, 117, "msg.no.while.do");
        paramSource.append('u');
        object5 = condition(paramTokenStream, paramSource);
        object1 = this.nf.createDoWhile(object4, object5, m);
        break;
      case 119:
        bool1 = true;
        paramSource.append('w');
        m = paramTokenStream.getLineno();
        object6 = null;
        mustMatchToken(paramTokenStream, 93, "msg.no.paren.for");
        paramSource.append(']');
        i = paramTokenStream.peekToken();
        if (i == 88) {
          object4 = this.nf.createLeaf(131);
        } else if (i == 122) {
          paramTokenStream.getToken();
          object4 = variables(paramTokenStream, paramSource, true);
        } else {
          object4 = expr(paramTokenStream, paramSource, true);
        } 
        i = paramTokenStream.peekToken();
        if (i == 102 && paramTokenStream.getOp() == 63) {
          paramTokenStream.matchToken(102);
          paramSource.append('?');
          object5 = expr(paramTokenStream, paramSource, false);
        } else {
          mustMatchToken(paramTokenStream, 88, 
              "msg.no.semi.for");
          paramSource.append('X');
          if (paramTokenStream.peekToken() == 88) {
            object5 = this.nf.createLeaf(131);
          } else {
            object5 = expr(paramTokenStream, paramSource, false);
          } 
          mustMatchToken(paramTokenStream, 88, 
              "msg.no.semi.for.cond");
          paramSource.append('X');
          if (paramTokenStream.peekToken() == 94) {
            object6 = this.nf.createLeaf(131);
          } else {
            object6 = expr(paramTokenStream, paramSource, false);
          } 
        } 
        mustMatchToken(paramTokenStream, 94, "msg.no.paren.for.ctrl");
        paramSource.append('^');
        paramSource.append('[');
        paramSource.append('\001');
        object7 = statement(paramTokenStream, paramSource);
        paramSource.append('\\');
        paramSource.append('\001');
        if (object6 == null) {
          object1 = this.nf.createForIn(object4, object5, object7, m);
          break;
        } 
        object1 = this.nf.createFor(object4, object5, object6, object7, m);
        break;
      case 75:
        m = paramTokenStream.getLineno();
        object5 = null;
        object6 = null;
        bool1 = true;
        paramSource.append('K');
        paramSource.append('[');
        paramSource.append('\001');
        object4 = statement(paramTokenStream, paramSource);
        paramSource.append('\\');
        paramSource.append('\001');
        object5 = this.nf.createLeaf(132);
        bool2 = false;
        i2 = paramTokenStream.peekToken();
        if (i2 == 124) {
          while (paramTokenStream.matchToken(124)) {
            if (bool2)
              reportError(paramTokenStream, "msg.catch.unreachable"); 
            paramSource.append('|');
            mustMatchToken(paramTokenStream, 93, "msg.no.paren.catch");
            paramSource.append(']');
            mustMatchToken(paramTokenStream, 44, "msg.bad.catchcond");
            String str = paramTokenStream.getString();
            paramSource.addString(44, str);
            Object object = null;
            if (paramTokenStream.matchToken(112)) {
              paramSource.append('p');
              object = expr(paramTokenStream, paramSource, false);
            } else {
              bool2 = true;
            } 
            mustMatchToken(paramTokenStream, 94, "msg.bad.catchcond");
            paramSource.append('^');
            mustMatchToken(paramTokenStream, 91, "msg.no.brace.catchblock");
            paramSource.append('[');
            paramSource.append('\001');
            this.nf.addChildToBack(object5, 
                this.nf.createCatch(str, object, 
                  statements(paramTokenStream, paramSource), 
                  paramTokenStream.getLineno()));
            mustMatchToken(paramTokenStream, 92, "msg.no.brace.after.body");
            paramSource.append('\\');
            paramSource.append('\001');
          } 
        } else if (i2 != 125) {
          mustMatchToken(paramTokenStream, 125, "msg.try.no.catchfinally");
        } 
        if (paramTokenStream.matchToken(125)) {
          paramSource.append('}');
          paramSource.append('[');
          paramSource.append('\001');
          object6 = statement(paramTokenStream, paramSource);
          paramSource.append('\\');
          paramSource.append('\001');
        } 
        object1 = this.nf.createTryCatchFinally(object4, object5, 
            object6, m);
        break;
      case 62:
        m = paramTokenStream.getLineno();
        paramSource.append('>');
        object1 = this.nf.createThrow(expr(paramTokenStream, paramSource, false), m);
        if (m == paramTokenStream.getLineno())
          wellTerminated(paramTokenStream, -1); 
        break;
      case 120:
        m = paramTokenStream.getLineno();
        paramSource.append('x');
        object4 = matchLabel(paramTokenStream);
        if (object4 != null)
          paramSource.addString(44, object4); 
        object1 = this.nf.createBreak(object4, m);
        break;
      case 121:
        m = paramTokenStream.getLineno();
        paramSource.append('y');
        object4 = matchLabel(paramTokenStream);
        if (object4 != null)
          paramSource.addString(44, object4); 
        object1 = this.nf.createContinue(object4, m);
        break;
      case 123:
        bool1 = true;
        paramSource.append('{');
        m = paramTokenStream.getLineno();
        mustMatchToken(paramTokenStream, 93, "msg.no.paren.with");
        paramSource.append(']');
        object4 = expr(paramTokenStream, paramSource, false);
        mustMatchToken(paramTokenStream, 94, "msg.no.paren.after.with");
        paramSource.append('^');
        paramSource.append('[');
        paramSource.append('\001');
        object5 = statement(paramTokenStream, paramSource);
        paramSource.append('\\');
        paramSource.append('\001');
        object1 = this.nf.createWith(object4, object5, m);
        break;
      case 122:
        m = paramTokenStream.getLineno();
        object1 = variables(paramTokenStream, paramSource, false);
        if (paramTokenStream.getLineno() == m)
          wellTerminated(paramTokenStream, -1); 
        break;
      case 5:
        object2 = null;
        i1 = 0;
        paramSource.append('\005');
        if ((paramTokenStream.flags & 0x2) == 0)
          reportError(paramTokenStream, "msg.bad.return"); 
        paramTokenStream.flags |= 0x10;
        i = paramTokenStream.peekTokenSameLine();
        paramTokenStream.flags &= 0xFFFFFFEF;
        if (i != 0 && i != 1 && i != 88 && i != 92) {
          i1 = paramTokenStream.getLineno();
          object2 = expr(paramTokenStream, paramSource, false);
          if (paramTokenStream.getLineno() == i1)
            wellTerminated(paramTokenStream, -1); 
          paramTokenStream.flags |= 0x4;
        } else {
          paramTokenStream.flags |= 0x8;
        } 
        object1 = this.nf.createReturn(object2, i1);
        break;
      case 91:
        bool1 = true;
        object1 = statements(paramTokenStream, paramSource);
        mustMatchToken(paramTokenStream, 92, "msg.no.brace.block");
        break;
      case -1:
      case 1:
      case 88:
        object1 = this.nf.createLeaf(131);
        bool1 = true;
        break;
      default:
        j = i;
        k = paramTokenStream.getTokenno();
        paramTokenStream.ungetToken(i);
        i1 = paramTokenStream.getLineno();
        object1 = expr(paramTokenStream, paramSource, false);
        if (paramTokenStream.peekToken() == 98) {
          if (j != 44 || paramTokenStream.getTokenno() != k)
            reportError(paramTokenStream, "msg.bad.label"); 
          paramTokenStream.getToken();
          object5 = paramTokenStream.getString();
          object1 = this.nf.createLabel(object5, i1);
          paramSource.append('b');
          paramSource.append('\001');
          return object1;
        } 
        if (j == 109)
          this.nf.setFunctionExpressionStatement(object1); 
        object1 = this.nf.createExprStatement(object1, i1);
        if (paramTokenStream.getLineno() == i1 || (
          j == 109 && 
          paramTokenStream.getLineno() == this.lastExprEndLine))
          wellTerminated(paramTokenStream, j); 
        break;
    } 
    paramTokenStream.matchToken(88);
    if (!bool1) {
      paramSource.append('X');
      paramSource.append('\001');
    } 
    return object1;
  }
  
  private Object variables(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
    Object object = this.nf.createVariables(paramTokenStream.getLineno());
    boolean bool = true;
    paramSource.append('z');
    do {
      mustMatchToken(paramTokenStream, 44, "msg.bad.var");
      String str = paramTokenStream.getString();
      if (!bool)
        paramSource.append('_'); 
      bool = false;
      paramSource.addString(44, str);
      Object object1 = this.nf.createName(str);
      if (paramTokenStream.matchToken(96)) {
        if (paramTokenStream.getOp() != 127)
          reportError(paramTokenStream, "msg.bad.var.init"); 
        paramSource.append('`');
        paramSource.append('');
        Object object2 = assignExpr(paramTokenStream, paramSource, paramBoolean);
        this.nf.addChildToBack(object1, object2);
      } 
      this.nf.addChildToBack(object, object1);
    } while (paramTokenStream.matchToken(95));
    return object;
  }
  
  private Object expr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
    Object object = assignExpr(paramTokenStream, paramSource, paramBoolean);
    while (paramTokenStream.matchToken(95)) {
      paramSource.append('_');
      object = this.nf.createBinary(95, object, assignExpr(paramTokenStream, paramSource, 
            paramBoolean));
    } 
    return object;
  }
  
  private Object assignExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
    Object object = condExpr(paramTokenStream, paramSource, paramBoolean);
    if (paramTokenStream.matchToken(96)) {
      paramSource.append('`');
      paramSource.append((char)paramTokenStream.getOp());
      object = this.nf.createBinary(96, paramTokenStream.getOp(), object, 
          assignExpr(paramTokenStream, paramSource, paramBoolean));
    } 
    return object;
  }
  
  private Object condExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
    Object object = orExpr(paramTokenStream, paramSource, paramBoolean);
    if (paramTokenStream.matchToken(97)) {
      paramSource.append('a');
      Object object1 = assignExpr(paramTokenStream, paramSource, false);
      mustMatchToken(paramTokenStream, 98, "msg.no.colon.cond");
      paramSource.append('b');
      Object object2 = assignExpr(paramTokenStream, paramSource, paramBoolean);
      return this.nf.createTernary(object, object1, object2);
    } 
    return object;
  }
  
  private Object orExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
    Object object = andExpr(paramTokenStream, paramSource, paramBoolean);
    if (paramTokenStream.matchToken(99)) {
      paramSource.append('c');
      object = this.nf.createBinary(99, object, orExpr(paramTokenStream, paramSource, paramBoolean));
    } 
    return object;
  }
  
  private Object andExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
    Object object = bitOrExpr(paramTokenStream, paramSource, paramBoolean);
    if (paramTokenStream.matchToken(100)) {
      paramSource.append('d');
      object = this.nf.createBinary(100, object, andExpr(paramTokenStream, paramSource, paramBoolean));
    } 
    return object;
  }
  
  private Object bitOrExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
    Object object = bitXorExpr(paramTokenStream, paramSource, paramBoolean);
    while (paramTokenStream.matchToken(11)) {
      paramSource.append('\013');
      object = this.nf.createBinary(11, object, bitXorExpr(paramTokenStream, paramSource, 
            paramBoolean));
    } 
    return object;
  }
  
  private Object bitXorExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
    Object object = bitAndExpr(paramTokenStream, paramSource, paramBoolean);
    while (paramTokenStream.matchToken(12)) {
      paramSource.append('\f');
      object = this.nf.createBinary(12, object, bitAndExpr(paramTokenStream, paramSource, 
            paramBoolean));
    } 
    return object;
  }
  
  private Object bitAndExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
    Object object = eqExpr(paramTokenStream, paramSource, paramBoolean);
    while (paramTokenStream.matchToken(13)) {
      paramSource.append('\r');
      object = this.nf.createBinary(13, object, eqExpr(paramTokenStream, paramSource, paramBoolean));
    } 
    return object;
  }
  
  private Object eqExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
    Object object = relExpr(paramTokenStream, paramSource, paramBoolean);
    while (paramTokenStream.matchToken(101)) {
      paramSource.append('e');
      paramSource.append((char)paramTokenStream.getOp());
      object = this.nf.createBinary(101, paramTokenStream.getOp(), object, 
          relExpr(paramTokenStream, paramSource, paramBoolean));
    } 
    return object;
  }
  
  private Object relExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
    Object object = shiftExpr(paramTokenStream, paramSource);
    while (paramTokenStream.matchToken(102)) {
      int i = paramTokenStream.getOp();
      if (paramBoolean && i == 63) {
        paramTokenStream.ungetToken(102);
        break;
      } 
      paramSource.append('f');
      paramSource.append((char)i);
      object = this.nf.createBinary(102, i, object, 
          shiftExpr(paramTokenStream, paramSource));
    } 
    return object;
  }
  
  private Object shiftExpr(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
    Object object = addExpr(paramTokenStream, paramSource);
    while (paramTokenStream.matchToken(103)) {
      paramSource.append('g');
      paramSource.append((char)paramTokenStream.getOp());
      object = this.nf.createBinary(paramTokenStream.getOp(), object, addExpr(paramTokenStream, paramSource));
    } 
    return object;
  }
  
  private Object addExpr(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
    Object object = mulExpr(paramTokenStream, paramSource);
    int i;
    while ((i = paramTokenStream.getToken()) == 23 || i == 24) {
      paramSource.append((char)i);
      object = this.nf.createBinary(i, object, mulExpr(paramTokenStream, paramSource));
    } 
    paramTokenStream.ungetToken(i);
    return object;
  }
  
  private Object mulExpr(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
    Object object = unaryExpr(paramTokenStream, paramSource);
    int i;
    while ((i = paramTokenStream.peekToken()) == 25 || 
      i == 26 || 
      i == 27) {
      i = paramTokenStream.getToken();
      paramSource.append((char)i);
      object = this.nf.createBinary(i, object, unaryExpr(paramTokenStream, paramSource));
    } 
    return object;
  }
  
  private Object unaryExpr(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
    int k;
    Object object;
    int j;
    paramTokenStream.flags |= 0x10;
    int i = paramTokenStream.getToken();
    paramTokenStream.flags &= 0xFFFFFFEF;
    switch (i) {
      case 104:
        paramSource.append('h');
        paramSource.append((char)paramTokenStream.getOp());
        return this.nf.createUnary(104, paramTokenStream.getOp(), 
            unaryExpr(paramTokenStream, paramSource));
      case 23:
      case 24:
        paramSource.append('h');
        paramSource.append((char)i);
        return this.nf.createUnary(104, i, unaryExpr(paramTokenStream, paramSource));
      case 105:
      case 106:
        paramSource.append((char)i);
        return this.nf.createUnary(i, 129, memberExpr(paramTokenStream, paramSource, true));
      case 31:
        paramSource.append('\037');
        return this.nf.createUnary(31, unaryExpr(paramTokenStream, paramSource));
      default:
        paramTokenStream.ungetToken(i);
        j = paramTokenStream.getLineno();
        object = memberExpr(paramTokenStream, paramSource, true);
        if (((k = paramTokenStream.peekToken()) == 105 || 
          k == 106) && 
          paramTokenStream.getLineno() == j) {
          int m = paramTokenStream.getToken();
          paramSource.append((char)m);
          return this.nf.createUnary(m, 130, object);
        } 
        return object;
      case -1:
        break;
    } 
    return this.nf.createName("err");
  }
  
  private Object argumentList(TokenStream paramTokenStream, Source paramSource, Object paramObject) throws IOException, JavaScriptException {
    paramTokenStream.flags |= 0x10;
    boolean bool = paramTokenStream.matchToken(94);
    paramTokenStream.flags &= 0xFFFFFFEF;
    if (!bool) {
      boolean bool1 = true;
      do {
        if (!bool1)
          paramSource.append('_'); 
        bool1 = false;
        this.nf.addChildToBack(paramObject, assignExpr(paramTokenStream, paramSource, false));
      } while (paramTokenStream.matchToken(95));
      mustMatchToken(paramTokenStream, 94, "msg.no.paren.arg");
    } 
    paramSource.append('^');
    return paramObject;
  }
  
  private Object memberExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
    Object object;
    paramTokenStream.flags |= 0x10;
    int i = paramTokenStream.peekToken();
    paramTokenStream.flags &= 0xFFFFFFEF;
    if (i == 30) {
      paramTokenStream.getToken();
      paramSource.append('\036');
      object = this.nf.createLeaf(30);
      this.nf.addChildToBack(object, memberExpr(paramTokenStream, paramSource, false));
      if (paramTokenStream.matchToken(93)) {
        paramSource.append(']');
        object = argumentList(paramTokenStream, paramSource, object);
      } 
      i = paramTokenStream.peekToken();
      if (i == 91)
        this.nf.addChildToBack(object, primaryExpr(paramTokenStream, paramSource)); 
    } else {
      object = primaryExpr(paramTokenStream, paramSource);
    } 
    this.lastExprEndLine = paramTokenStream.getLineno();
    while ((i = paramTokenStream.getToken()) > 0) {
      if (i == 107) {
        paramSource.append('k');
        mustMatchToken(paramTokenStream, 44, "msg.no.name.after.dot");
        String str = paramTokenStream.getString();
        paramSource.addString(44, str);
        object = this.nf.createBinary(107, object, 
            this.nf.createName(paramTokenStream.getString()));
        this.lastExprEndLine = paramTokenStream.getLineno();
        continue;
      } 
      if (i == 89) {
        paramSource.append('Y');
        object = this.nf.createBinary(89, object, expr(paramTokenStream, paramSource, false));
        mustMatchToken(paramTokenStream, 90, "msg.no.bracket.index");
        paramSource.append('Z');
        this.lastExprEndLine = paramTokenStream.getLineno();
        continue;
      } 
      if (paramBoolean && i == 93) {
        object = this.nf.createUnary(43, object);
        paramSource.append(']');
        object = argumentList(paramTokenStream, paramSource, object);
        this.lastExprEndLine = paramTokenStream.getLineno();
        continue;
      } 
      paramTokenStream.ungetToken(i);
      break;
    } 
    return object;
  }
  
  private Object primaryExpr(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
    String str4, str3, str2;
    Number number;
    boolean bool;
    String str1;
    Object object;
    paramTokenStream.flags |= 0x10;
    int i = paramTokenStream.getToken();
    paramTokenStream.flags &= 0xFFFFFFEF;
    switch (i) {
      case 109:
        return function(paramTokenStream, paramSource, true);
      case 89:
        paramSource.append('Y');
        object = this.nf.createLeaf(133);
        paramTokenStream.flags |= 0x10;
        bool = paramTokenStream.matchToken(90);
        paramTokenStream.flags &= 0xFFFFFFEF;
        if (!bool) {
          boolean bool1 = true;
          while (true) {
            paramTokenStream.flags |= 0x10;
            i = paramTokenStream.peekToken();
            paramTokenStream.flags &= 0xFFFFFFEF;
            if (!bool1) {
              paramSource.append('_');
            } else {
              bool1 = false;
            } 
            if (i != 90) {
              if (i == 95) {
                this.nf.addChildToBack(object, this.nf.createLeaf(108, 
                      74));
              } else {
                this.nf.addChildToBack(object, assignExpr(paramTokenStream, paramSource, false));
              } 
              if (!paramTokenStream.matchToken(95))
                break; 
              continue;
            } 
            break;
          } 
          mustMatchToken(paramTokenStream, 90, "msg.no.bracket.arg");
        } 
        paramSource.append('Z');
        return this.nf.createArrayLiteral(object);
      case 91:
        object = this.nf.createLeaf(134);
        paramSource.append('[');
        if (!paramTokenStream.matchToken(92)) {
          bool = true;
          do {
            Number number1;
            String str;
            Object object1;
            if (!bool) {
              paramSource.append('_');
            } else {
              bool = false;
            } 
            i = paramTokenStream.getToken();
            switch (i) {
              case 44:
              case 46:
                str = paramTokenStream.getString();
                paramSource.addString(44, str);
                object1 = this.nf.createString(paramTokenStream.getString());
                break;
              case 45:
                number1 = paramTokenStream.getNumber();
                paramSource.addNumber(number1);
                object1 = this.nf.createNumber(number1);
                break;
              case 92:
                paramTokenStream.ungetToken(i);
                break;
              default:
                reportError(paramTokenStream, "msg.bad.prop");
                break;
            } 
            mustMatchToken(paramTokenStream, 98, "msg.no.colon.prop");
            paramSource.append('');
            this.nf.addChildToBack(object, object1);
            this.nf.addChildToBack(object, assignExpr(paramTokenStream, paramSource, false));
          } while (paramTokenStream.matchToken(95));
          mustMatchToken(paramTokenStream, 92, "msg.no.brace.prop");
        } 
        paramSource.append('\\');
        return this.nf.createObjectLiteral(object);
      case 93:
        paramSource.append(']');
        object = expr(paramTokenStream, paramSource, false);
        paramSource.append('^');
        mustMatchToken(paramTokenStream, 94, "msg.no.paren");
        return object;
      case 44:
        str1 = paramTokenStream.getString();
        paramSource.addString(44, str1);
        return this.nf.createName(str1);
      case 45:
        number = paramTokenStream.getNumber();
        paramSource.addNumber(number);
        return this.nf.createNumber(number);
      case 46:
        str2 = paramTokenStream.getString();
        paramSource.addString(46, str2);
        return this.nf.createString(str2);
      case 56:
        str3 = paramTokenStream.regExpFlags;
        paramTokenStream.regExpFlags = null;
        str4 = paramTokenStream.getString();
        paramSource.addString(56, String.valueOf('/') + str4 + '/' + str3);
        return this.nf.createRegExp(str4, str3);
      case 108:
        paramSource.append('l');
        paramSource.append((char)paramTokenStream.getOp());
        return this.nf.createLeaf(108, paramTokenStream.getOp());
      case 126:
        reportError(paramTokenStream, "msg.reserved.id");
        break;
      default:
        reportError(paramTokenStream, "msg.syntax");
        break;
      case -1:
        break;
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Parser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */