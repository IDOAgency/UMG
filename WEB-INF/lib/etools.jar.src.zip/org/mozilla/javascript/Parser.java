/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.io.IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class Parser
/*      */ {
/*      */   private int lastExprEndLine;
/*      */   private IRFactory nf;
/*      */   private ErrorReporter er;
/*      */   private boolean ok;
/*      */   
/*   59 */   public Parser(IRFactory paramIRFactory) { this.nf = paramIRFactory; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void mustMatchToken(TokenStream paramTokenStream, int paramInt, String paramString) throws IOException, JavaScriptException {
/*      */     int i;
/*   66 */     if ((i = paramTokenStream.getToken()) != paramInt) {
/*   67 */       reportError(paramTokenStream, paramString);
/*   68 */       paramTokenStream.ungetToken(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void reportError(TokenStream paramTokenStream, String paramString) throws JavaScriptException {
/*   75 */     this.ok = false;
/*   76 */     paramTokenStream.reportSyntaxError(paramString, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   83 */     throw new JavaScriptException(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object parse(TokenStream paramTokenStream) throws IOException {
/*  101 */     this.ok = true;
/*  102 */     Source source = new Source();
/*      */ 
/*      */     
/*  105 */     int i = paramTokenStream.getLineno();
/*      */ 
/*      */ 
/*      */     
/*  109 */     Object object = this.nf.createLeaf(132);
/*      */     
/*      */     while (true) {
/*  112 */       paramTokenStream.flags |= 0x10;
/*  113 */       int j = paramTokenStream.getToken();
/*  114 */       paramTokenStream.flags &= 0xFFFFFFEF;
/*      */       
/*  116 */       if (j > 0) {
/*      */ 
/*      */ 
/*      */         
/*  120 */         if (j == 109) {
/*      */           try {
/*  122 */             this.nf.addChildToBack(object, function(paramTokenStream, source, false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  128 */             source.append('\001');
/*  129 */             wellTerminated(paramTokenStream, 109); continue;
/*  130 */           } catch (JavaScriptException javaScriptException) {
/*  131 */             this.ok = false;
/*      */             break;
/*      */           } 
/*      */         }
/*  135 */         paramTokenStream.ungetToken(j);
/*  136 */         this.nf.addChildToBack(object, statement(paramTokenStream, source)); continue;
/*      */       } 
/*      */       break;
/*      */     } 
/*  140 */     if (!this.ok)
/*      */     {
/*  142 */       return null;
/*      */     }
/*      */     
/*  145 */     return this.nf.createScript(object, paramTokenStream.getSourceName(), 
/*  146 */         i, paramTokenStream.getLineno(), 
/*  147 */         source.buf.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object parseFunctionBody(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
/*  160 */     int i = paramTokenStream.flags;
/*  161 */     paramTokenStream.flags &= 0xFFFFFFF3;
/*      */     
/*  163 */     paramTokenStream.flags |= 0x2;
/*      */     
/*  165 */     Object object = this.nf.createBlock(paramTokenStream.getLineno());
/*      */     try {
/*      */       int j;
/*  168 */       while ((j = paramTokenStream.peekToken()) > 0 && j != 92) {
/*  169 */         if (j == 109) {
/*  170 */           paramTokenStream.getToken();
/*  171 */           this.nf.addChildToBack(object, function(paramTokenStream, paramSource, false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  177 */           paramSource.append('\001');
/*  178 */           wellTerminated(paramTokenStream, 109); continue;
/*      */         } 
/*  180 */         this.nf.addChildToBack(object, statement(paramTokenStream, paramSource));
/*      */       }
/*      */     
/*  183 */     } catch (JavaScriptException javaScriptException) {
/*  184 */       this.ok = false;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  189 */       paramTokenStream.flags = i;
/*      */     } 
/*      */     
/*  192 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object function(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
/*  198 */     String str = null;
/*  199 */     Object object1 = this.nf.createLeaf(93);
/*      */     
/*  201 */     int i = paramTokenStream.getLineno();
/*      */ 
/*      */     
/*  204 */     paramSource.append('m');
/*  205 */     paramSource.append(paramSource.functionNumber);
/*  206 */     paramSource.functionNumber = (char)(paramSource.functionNumber + '\001');
/*      */ 
/*      */     
/*  209 */     paramSource = new Source();
/*      */ 
/*      */ 
/*      */     
/*  213 */     paramSource.append('m');
/*      */     
/*  215 */     if (paramTokenStream.matchToken(44)) {
/*  216 */       str = paramTokenStream.getString();
/*  217 */       paramSource.addString(44, str);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  222 */     mustMatchToken(paramTokenStream, 93, "msg.no.paren.parms");
/*  223 */     paramSource.append(']');
/*      */     
/*  225 */     if (!paramTokenStream.matchToken(94)) {
/*  226 */       boolean bool = true;
/*      */       do {
/*  228 */         if (!bool)
/*  229 */           paramSource.append('_'); 
/*  230 */         bool = false;
/*  231 */         mustMatchToken(paramTokenStream, 44, "msg.no.parm");
/*  232 */         String str1 = paramTokenStream.getString();
/*  233 */         this.nf.addChildToBack(object1, this.nf.createName(str1));
/*      */         
/*  235 */         paramSource.addString(44, str1);
/*  236 */       } while (paramTokenStream.matchToken(95));
/*      */       
/*  238 */       mustMatchToken(paramTokenStream, 94, "msg.no.paren.after.parms");
/*      */     } 
/*  240 */     paramSource.append('^');
/*      */     
/*  242 */     mustMatchToken(paramTokenStream, 91, "msg.no.brace.body");
/*  243 */     paramSource.append('[');
/*  244 */     paramSource.append('\001');
/*  245 */     Object object2 = parseFunctionBody(paramTokenStream, paramSource);
/*  246 */     mustMatchToken(paramTokenStream, 92, "msg.no.brace.after.body");
/*  247 */     paramSource.append('\\');
/*      */ 
/*      */ 
/*      */     
/*  251 */     return this.nf.createFunction(str, object1, object2, 
/*  252 */         paramTokenStream.getSourceName(), 
/*  253 */         i, paramTokenStream.getLineno(), 
/*  254 */         paramSource.buf.toString(), 
/*  255 */         paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object statements(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
/*  261 */     Object object = this.nf.createBlock(paramTokenStream.getLineno());
/*      */     
/*      */     int i;
/*  264 */     while ((i = paramTokenStream.peekToken()) > 0 && i != 92) {
/*  265 */       this.nf.addChildToBack(object, statement(paramTokenStream, paramSource));
/*      */     }
/*      */     
/*  268 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object condition(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
/*  275 */     mustMatchToken(paramTokenStream, 93, "msg.no.paren.cond");
/*  276 */     paramSource.append(']');
/*  277 */     Object object = expr(paramTokenStream, paramSource, false);
/*  278 */     mustMatchToken(paramTokenStream, 94, "msg.no.paren.after.cond");
/*  279 */     paramSource.append('^');
/*      */ 
/*      */ 
/*      */     
/*  283 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean wellTerminated(TokenStream paramTokenStream, int paramInt) throws IOException, JavaScriptException {
/*  289 */     int i = paramTokenStream.peekTokenSameLine();
/*  290 */     if (i == -1) {
/*  291 */       return false;
/*      */     }
/*      */     
/*  294 */     if (i != 0 && i != 1 && 
/*  295 */       i != 88 && i != 92) {
/*      */       
/*  297 */       int j = Context.getContext().getLanguageVersion();
/*  298 */       if ((i == 109 || paramInt == 109) && 
/*  299 */         j < 120)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  305 */         return true;
/*      */       }
/*  307 */       reportError(paramTokenStream, "msg.no.semi.stmt");
/*      */     } 
/*      */     
/*  310 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String matchLabel(TokenStream paramTokenStream) throws IOException, JavaScriptException {
/*  317 */     int i = paramTokenStream.getLineno();
/*      */     
/*  319 */     String str = null;
/*      */     
/*  321 */     int j = paramTokenStream.peekTokenSameLine();
/*  322 */     if (j == 44) {
/*  323 */       paramTokenStream.getToken();
/*  324 */       str = paramTokenStream.getString();
/*      */     } 
/*      */     
/*  327 */     if (i == paramTokenStream.getLineno()) {
/*  328 */       wellTerminated(paramTokenStream, -1);
/*      */     }
/*  330 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object statement(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
/*      */     try {
/*  337 */       return statementHelper(paramTokenStream, paramSource);
/*  338 */     } catch (JavaScriptException javaScriptException) {
/*      */       
/*  340 */       int j, i = paramTokenStream.getLineno();
/*      */       
/*      */       do {
/*  343 */         j = paramTokenStream.getToken();
/*  344 */       } while (j != 88 && j != 1 && 
/*  345 */         j != 0 && j != -1);
/*  346 */       return this.nf.createExprStatement(this.nf.createName("error"), i);
/*      */     } 
/*      */   }
/*      */   private Object statementHelper(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
/*      */     int i2;
/*      */     boolean bool2;
/*      */     Object object7, object6, object5, object4;
/*      */     int i1;
/*      */     Object object3;
/*      */     int k, n;
/*      */     Object object2;
/*      */     int m;
/*  358 */     Object object1 = null;
/*      */ 
/*      */ 
/*      */     
/*  362 */     boolean bool1 = false;
/*      */ 
/*      */ 
/*      */     
/*  366 */     int j = 0;
/*      */     
/*  368 */     int i = paramTokenStream.getToken();
/*      */     
/*  370 */     switch (i) {
/*      */       case 112:
/*  372 */         bool1 = true;
/*      */         
/*  374 */         paramSource.append('p');
/*  375 */         n = paramTokenStream.getLineno();
/*  376 */         object4 = condition(paramTokenStream, paramSource);
/*  377 */         paramSource.append('[');
/*  378 */         paramSource.append('\001');
/*  379 */         object5 = statement(paramTokenStream, paramSource);
/*  380 */         object6 = null;
/*  381 */         if (paramTokenStream.matchToken(113)) {
/*  382 */           paramSource.append('\\');
/*  383 */           paramSource.append('q');
/*  384 */           paramSource.append('[');
/*  385 */           paramSource.append('\001');
/*  386 */           object6 = statement(paramTokenStream, paramSource);
/*      */         } 
/*  388 */         paramSource.append('\\');
/*  389 */         paramSource.append('\001');
/*  390 */         object1 = this.nf.createIf(object4, object5, object6, n);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 114:
/*  395 */         bool1 = true;
/*      */         
/*  397 */         paramSource.append('r');
/*  398 */         object1 = this.nf.createSwitch(paramTokenStream.getLineno());
/*      */         
/*  400 */         object3 = null;
/*      */ 
/*      */         
/*  403 */         mustMatchToken(paramTokenStream, 93, "msg.no.paren.switch");
/*  404 */         paramSource.append(']');
/*  405 */         this.nf.addChildToBack(object1, expr(paramTokenStream, paramSource, false));
/*  406 */         mustMatchToken(paramTokenStream, 94, "msg.no.paren.after.switch");
/*  407 */         paramSource.append('^');
/*  408 */         mustMatchToken(paramTokenStream, 91, "msg.no.brace.switch");
/*  409 */         paramSource.append('[');
/*  410 */         paramSource.append('\001');
/*      */         
/*  412 */         while ((i = paramTokenStream.getToken()) != 92 && i != 0) {
/*  413 */           switch (i) {
/*      */             case 115:
/*  415 */               paramSource.append('s');
/*  416 */               object3 = this.nf.createUnary(115, expr(paramTokenStream, paramSource, false));
/*  417 */               paramSource.append('b');
/*  418 */               paramSource.append('\001');
/*      */               break;
/*      */             
/*      */             case 116:
/*  422 */               object3 = this.nf.createLeaf(116);
/*  423 */               paramSource.append('t');
/*  424 */               paramSource.append('b');
/*  425 */               paramSource.append('\001');
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/*  430 */               reportError(paramTokenStream, "msg.bad.switch");
/*      */               break;
/*      */           } 
/*  433 */           mustMatchToken(paramTokenStream, 98, "msg.no.colon.case");
/*      */           
/*  435 */           object4 = this.nf.createLeaf(132);
/*      */           
/*  437 */           while ((i = paramTokenStream.peekToken()) != 92 && i != 115 && 
/*  438 */             i != 116 && i != 0)
/*      */           {
/*  440 */             this.nf.addChildToBack(object4, statement(paramTokenStream, paramSource));
/*      */           }
/*      */           
/*  443 */           this.nf.addChildToBack(object3, object4);
/*      */           
/*  445 */           this.nf.addChildToBack(object1, object3);
/*      */         } 
/*  447 */         paramSource.append('\\');
/*  448 */         paramSource.append('\001');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 117:
/*  453 */         bool1 = true;
/*      */         
/*  455 */         paramSource.append('u');
/*  456 */         m = paramTokenStream.getLineno();
/*  457 */         object4 = condition(paramTokenStream, paramSource);
/*  458 */         paramSource.append('[');
/*  459 */         paramSource.append('\001');
/*  460 */         object5 = statement(paramTokenStream, paramSource);
/*  461 */         paramSource.append('\\');
/*  462 */         paramSource.append('\001');
/*      */         
/*  464 */         object1 = this.nf.createWhile(object4, object5, m);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 118:
/*  470 */         paramSource.append('v');
/*  471 */         paramSource.append('[');
/*  472 */         paramSource.append('\001');
/*      */         
/*  474 */         m = paramTokenStream.getLineno();
/*      */         
/*  476 */         object4 = statement(paramTokenStream, paramSource);
/*      */         
/*  478 */         paramSource.append('\\');
/*  479 */         mustMatchToken(paramTokenStream, 117, "msg.no.while.do");
/*  480 */         paramSource.append('u');
/*  481 */         object5 = condition(paramTokenStream, paramSource);
/*      */         
/*  483 */         object1 = this.nf.createDoWhile(object4, object5, m);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 119:
/*  488 */         bool1 = true;
/*      */         
/*  490 */         paramSource.append('w');
/*  491 */         m = paramTokenStream.getLineno();
/*      */ 
/*      */ 
/*      */         
/*  495 */         object6 = null;
/*      */ 
/*      */         
/*  498 */         mustMatchToken(paramTokenStream, 93, "msg.no.paren.for");
/*  499 */         paramSource.append(']');
/*  500 */         i = paramTokenStream.peekToken();
/*  501 */         if (i == 88) {
/*  502 */           object4 = this.nf.createLeaf(131);
/*      */         }
/*  504 */         else if (i == 122) {
/*      */           
/*  506 */           paramTokenStream.getToken();
/*  507 */           object4 = variables(paramTokenStream, paramSource, true);
/*      */         } else {
/*      */           
/*  510 */           object4 = expr(paramTokenStream, paramSource, true);
/*      */         } 
/*      */ 
/*      */         
/*  514 */         i = paramTokenStream.peekToken();
/*  515 */         if (i == 102 && paramTokenStream.getOp() == 63) {
/*  516 */           paramTokenStream.matchToken(102);
/*  517 */           paramSource.append('?');
/*      */           
/*  519 */           object5 = expr(paramTokenStream, paramSource, false);
/*      */         } else {
/*  521 */           mustMatchToken(paramTokenStream, 88, 
/*  522 */               "msg.no.semi.for");
/*  523 */           paramSource.append('X');
/*  524 */           if (paramTokenStream.peekToken() == 88) {
/*      */             
/*  526 */             object5 = this.nf.createLeaf(131);
/*      */           } else {
/*  528 */             object5 = expr(paramTokenStream, paramSource, false);
/*      */           } 
/*      */           
/*  531 */           mustMatchToken(paramTokenStream, 88, 
/*  532 */               "msg.no.semi.for.cond");
/*  533 */           paramSource.append('X');
/*  534 */           if (paramTokenStream.peekToken() == 94) {
/*  535 */             object6 = this.nf.createLeaf(131);
/*      */           } else {
/*  537 */             object6 = expr(paramTokenStream, paramSource, false);
/*      */           } 
/*      */         } 
/*      */         
/*  541 */         mustMatchToken(paramTokenStream, 94, "msg.no.paren.for.ctrl");
/*  542 */         paramSource.append('^');
/*  543 */         paramSource.append('[');
/*  544 */         paramSource.append('\001');
/*  545 */         object7 = statement(paramTokenStream, paramSource);
/*  546 */         paramSource.append('\\');
/*  547 */         paramSource.append('\001');
/*      */         
/*  549 */         if (object6 == null) {
/*      */           
/*  551 */           object1 = this.nf.createForIn(object4, object5, object7, m); break;
/*      */         } 
/*  553 */         object1 = this.nf.createFor(object4, object5, object6, object7, m);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 75:
/*  559 */         m = paramTokenStream.getLineno();
/*      */ 
/*      */         
/*  562 */         object5 = null;
/*  563 */         object6 = null;
/*      */         
/*  565 */         bool1 = true;
/*  566 */         paramSource.append('K');
/*  567 */         paramSource.append('[');
/*  568 */         paramSource.append('\001');
/*  569 */         object4 = statement(paramTokenStream, paramSource);
/*  570 */         paramSource.append('\\');
/*  571 */         paramSource.append('\001');
/*      */         
/*  573 */         object5 = this.nf.createLeaf(132);
/*      */         
/*  575 */         bool2 = false;
/*  576 */         i2 = paramTokenStream.peekToken();
/*  577 */         if (i2 == 124) {
/*  578 */           while (paramTokenStream.matchToken(124)) {
/*  579 */             if (bool2) {
/*  580 */               reportError(paramTokenStream, "msg.catch.unreachable");
/*      */             }
/*  582 */             paramSource.append('|');
/*  583 */             mustMatchToken(paramTokenStream, 93, "msg.no.paren.catch");
/*  584 */             paramSource.append(']');
/*      */             
/*  586 */             mustMatchToken(paramTokenStream, 44, "msg.bad.catchcond");
/*  587 */             String str = paramTokenStream.getString();
/*  588 */             paramSource.addString(44, str);
/*      */             
/*  590 */             Object object = null;
/*  591 */             if (paramTokenStream.matchToken(112)) {
/*  592 */               paramSource.append('p');
/*  593 */               object = expr(paramTokenStream, paramSource, false);
/*      */             } else {
/*  595 */               bool2 = true;
/*      */             } 
/*      */             
/*  598 */             mustMatchToken(paramTokenStream, 94, "msg.bad.catchcond");
/*  599 */             paramSource.append('^');
/*  600 */             mustMatchToken(paramTokenStream, 91, "msg.no.brace.catchblock");
/*  601 */             paramSource.append('[');
/*  602 */             paramSource.append('\001');
/*      */             
/*  604 */             this.nf.addChildToBack(object5, 
/*  605 */                 this.nf.createCatch(str, object, 
/*  606 */                   statements(paramTokenStream, paramSource), 
/*  607 */                   paramTokenStream.getLineno()));
/*      */             
/*  609 */             mustMatchToken(paramTokenStream, 92, "msg.no.brace.after.body");
/*  610 */             paramSource.append('\\');
/*  611 */             paramSource.append('\001');
/*      */           } 
/*  613 */         } else if (i2 != 125) {
/*  614 */           mustMatchToken(paramTokenStream, 125, "msg.try.no.catchfinally");
/*      */         } 
/*      */         
/*  617 */         if (paramTokenStream.matchToken(125)) {
/*  618 */           paramSource.append('}');
/*      */           
/*  620 */           paramSource.append('[');
/*  621 */           paramSource.append('\001');
/*  622 */           object6 = statement(paramTokenStream, paramSource);
/*  623 */           paramSource.append('\\');
/*  624 */           paramSource.append('\001');
/*      */         } 
/*      */         
/*  627 */         object1 = this.nf.createTryCatchFinally(object4, object5, 
/*  628 */             object6, m);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 62:
/*  633 */         m = paramTokenStream.getLineno();
/*  634 */         paramSource.append('>');
/*  635 */         object1 = this.nf.createThrow(expr(paramTokenStream, paramSource, false), m);
/*  636 */         if (m == paramTokenStream.getLineno()) {
/*  637 */           wellTerminated(paramTokenStream, -1);
/*      */         }
/*      */         break;
/*      */       case 120:
/*  641 */         m = paramTokenStream.getLineno();
/*      */         
/*  643 */         paramSource.append('x');
/*      */ 
/*      */         
/*  646 */         object4 = matchLabel(paramTokenStream);
/*  647 */         if (object4 != null) {
/*  648 */           paramSource.addString(44, object4);
/*      */         }
/*  650 */         object1 = this.nf.createBreak(object4, m);
/*      */         break;
/*      */       
/*      */       case 121:
/*  654 */         m = paramTokenStream.getLineno();
/*      */         
/*  656 */         paramSource.append('y');
/*      */ 
/*      */         
/*  659 */         object4 = matchLabel(paramTokenStream);
/*  660 */         if (object4 != null) {
/*  661 */           paramSource.addString(44, object4);
/*      */         }
/*  663 */         object1 = this.nf.createContinue(object4, m);
/*      */         break;
/*      */       
/*      */       case 123:
/*  667 */         bool1 = true;
/*      */         
/*  669 */         paramSource.append('{');
/*  670 */         m = paramTokenStream.getLineno();
/*  671 */         mustMatchToken(paramTokenStream, 93, "msg.no.paren.with");
/*  672 */         paramSource.append(']');
/*  673 */         object4 = expr(paramTokenStream, paramSource, false);
/*  674 */         mustMatchToken(paramTokenStream, 94, "msg.no.paren.after.with");
/*  675 */         paramSource.append('^');
/*  676 */         paramSource.append('[');
/*  677 */         paramSource.append('\001');
/*      */         
/*  679 */         object5 = statement(paramTokenStream, paramSource);
/*      */         
/*  681 */         paramSource.append('\\');
/*  682 */         paramSource.append('\001');
/*      */         
/*  684 */         object1 = this.nf.createWith(object4, object5, m);
/*      */         break;
/*      */       
/*      */       case 122:
/*  688 */         m = paramTokenStream.getLineno();
/*  689 */         object1 = variables(paramTokenStream, paramSource, false);
/*  690 */         if (paramTokenStream.getLineno() == m) {
/*  691 */           wellTerminated(paramTokenStream, -1);
/*      */         }
/*      */         break;
/*      */       case 5:
/*  695 */         object2 = null;
/*  696 */         i1 = 0;
/*      */         
/*  698 */         paramSource.append('\005');
/*      */ 
/*      */         
/*  701 */         if ((paramTokenStream.flags & 0x2) == 0) {
/*  702 */           reportError(paramTokenStream, "msg.bad.return");
/*      */         }
/*      */         
/*  705 */         paramTokenStream.flags |= 0x10;
/*  706 */         i = paramTokenStream.peekTokenSameLine();
/*  707 */         paramTokenStream.flags &= 0xFFFFFFEF;
/*      */         
/*  709 */         if (i != 0 && i != 1 && i != 88 && i != 92) {
/*  710 */           i1 = paramTokenStream.getLineno();
/*  711 */           object2 = expr(paramTokenStream, paramSource, false);
/*  712 */           if (paramTokenStream.getLineno() == i1)
/*  713 */             wellTerminated(paramTokenStream, -1); 
/*  714 */           paramTokenStream.flags |= 0x4;
/*      */         } else {
/*  716 */           paramTokenStream.flags |= 0x8;
/*      */         } 
/*      */ 
/*      */         
/*  720 */         object1 = this.nf.createReturn(object2, i1);
/*      */         break;
/*      */       
/*      */       case 91:
/*  724 */         bool1 = true;
/*      */         
/*  726 */         object1 = statements(paramTokenStream, paramSource);
/*  727 */         mustMatchToken(paramTokenStream, 92, "msg.no.brace.block");
/*      */         break;
/*      */ 
/*      */       
/*      */       case -1:
/*      */       case 1:
/*      */       case 88:
/*  734 */         object1 = this.nf.createLeaf(131);
/*  735 */         bool1 = true;
/*      */         break;
/*      */       
/*      */       default:
/*  739 */         j = i;
/*  740 */         k = paramTokenStream.getTokenno();
/*  741 */         paramTokenStream.ungetToken(i);
/*  742 */         i1 = paramTokenStream.getLineno();
/*      */         
/*  744 */         object1 = expr(paramTokenStream, paramSource, false);
/*      */         
/*  746 */         if (paramTokenStream.peekToken() == 98) {
/*      */ 
/*      */ 
/*      */           
/*  750 */           if (j != 44 || paramTokenStream.getTokenno() != k) {
/*  751 */             reportError(paramTokenStream, "msg.bad.label");
/*      */           }
/*  753 */           paramTokenStream.getToken();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  759 */           object5 = paramTokenStream.getString();
/*  760 */           object1 = this.nf.createLabel(object5, i1);
/*      */ 
/*      */ 
/*      */           
/*  764 */           paramSource.append('b');
/*  765 */           paramSource.append('\001');
/*  766 */           return object1;
/*      */         } 
/*      */         
/*  769 */         if (j == 109) {
/*  770 */           this.nf.setFunctionExpressionStatement(object1);
/*      */         }
/*  772 */         object1 = this.nf.createExprStatement(object1, i1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  786 */         if (paramTokenStream.getLineno() == i1 || (
/*  787 */           j == 109 && 
/*  788 */           paramTokenStream.getLineno() == this.lastExprEndLine))
/*      */         {
/*  790 */           wellTerminated(paramTokenStream, j);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  795 */     paramTokenStream.matchToken(88);
/*  796 */     if (!bool1) {
/*  797 */       paramSource.append('X');
/*  798 */       paramSource.append('\001');
/*      */     } 
/*      */     
/*  801 */     return object1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object variables(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
/*  807 */     Object object = this.nf.createVariables(paramTokenStream.getLineno());
/*  808 */     boolean bool = true;
/*      */     
/*  810 */     paramSource.append('z');
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/*  815 */       mustMatchToken(paramTokenStream, 44, "msg.bad.var");
/*  816 */       String str = paramTokenStream.getString();
/*      */       
/*  818 */       if (!bool)
/*  819 */         paramSource.append('_'); 
/*  820 */       bool = false;
/*      */       
/*  822 */       paramSource.addString(44, str);
/*  823 */       Object object1 = this.nf.createName(str);
/*      */ 
/*      */ 
/*      */       
/*  827 */       if (paramTokenStream.matchToken(96)) {
/*  828 */         if (paramTokenStream.getOp() != 127) {
/*  829 */           reportError(paramTokenStream, "msg.bad.var.init");
/*      */         }
/*  831 */         paramSource.append('`');
/*  832 */         paramSource.append('');
/*      */         
/*  834 */         Object object2 = assignExpr(paramTokenStream, paramSource, paramBoolean);
/*  835 */         this.nf.addChildToBack(object1, object2);
/*      */       } 
/*  837 */       this.nf.addChildToBack(object, object1);
/*  838 */     } while (paramTokenStream.matchToken(95));
/*      */ 
/*      */     
/*  841 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object expr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
/*  847 */     Object object = assignExpr(paramTokenStream, paramSource, paramBoolean);
/*  848 */     while (paramTokenStream.matchToken(95)) {
/*  849 */       paramSource.append('_');
/*  850 */       object = this.nf.createBinary(95, object, assignExpr(paramTokenStream, paramSource, 
/*  851 */             paramBoolean));
/*      */     } 
/*  853 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object assignExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
/*  859 */     Object object = condExpr(paramTokenStream, paramSource, paramBoolean);
/*      */     
/*  861 */     if (paramTokenStream.matchToken(96)) {
/*      */       
/*  863 */       paramSource.append('`');
/*  864 */       paramSource.append((char)paramTokenStream.getOp());
/*  865 */       object = this.nf.createBinary(96, paramTokenStream.getOp(), object, 
/*  866 */           assignExpr(paramTokenStream, paramSource, paramBoolean));
/*      */     } 
/*      */     
/*  869 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object condExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
/*  878 */     Object object = orExpr(paramTokenStream, paramSource, paramBoolean);
/*      */     
/*  880 */     if (paramTokenStream.matchToken(97)) {
/*  881 */       paramSource.append('a');
/*  882 */       Object object1 = assignExpr(paramTokenStream, paramSource, false);
/*  883 */       mustMatchToken(paramTokenStream, 98, "msg.no.colon.cond");
/*  884 */       paramSource.append('b');
/*  885 */       Object object2 = assignExpr(paramTokenStream, paramSource, paramBoolean);
/*  886 */       return this.nf.createTernary(object, object1, object2);
/*      */     } 
/*      */     
/*  889 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object orExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
/*  895 */     Object object = andExpr(paramTokenStream, paramSource, paramBoolean);
/*  896 */     if (paramTokenStream.matchToken(99)) {
/*  897 */       paramSource.append('c');
/*  898 */       object = this.nf.createBinary(99, object, orExpr(paramTokenStream, paramSource, paramBoolean));
/*      */     } 
/*      */     
/*  901 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object andExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
/*  907 */     Object object = bitOrExpr(paramTokenStream, paramSource, paramBoolean);
/*  908 */     if (paramTokenStream.matchToken(100)) {
/*  909 */       paramSource.append('d');
/*  910 */       object = this.nf.createBinary(100, object, andExpr(paramTokenStream, paramSource, paramBoolean));
/*      */     } 
/*      */     
/*  913 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object bitOrExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
/*  919 */     Object object = bitXorExpr(paramTokenStream, paramSource, paramBoolean);
/*  920 */     while (paramTokenStream.matchToken(11)) {
/*  921 */       paramSource.append('\013');
/*  922 */       object = this.nf.createBinary(11, object, bitXorExpr(paramTokenStream, paramSource, 
/*  923 */             paramBoolean));
/*      */     } 
/*  925 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object bitXorExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
/*  931 */     Object object = bitAndExpr(paramTokenStream, paramSource, paramBoolean);
/*  932 */     while (paramTokenStream.matchToken(12)) {
/*  933 */       paramSource.append('\f');
/*  934 */       object = this.nf.createBinary(12, object, bitAndExpr(paramTokenStream, paramSource, 
/*  935 */             paramBoolean));
/*      */     } 
/*  937 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object bitAndExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
/*  943 */     Object object = eqExpr(paramTokenStream, paramSource, paramBoolean);
/*  944 */     while (paramTokenStream.matchToken(13)) {
/*  945 */       paramSource.append('\r');
/*  946 */       object = this.nf.createBinary(13, object, eqExpr(paramTokenStream, paramSource, paramBoolean));
/*      */     } 
/*  948 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object eqExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
/*  954 */     Object object = relExpr(paramTokenStream, paramSource, paramBoolean);
/*  955 */     while (paramTokenStream.matchToken(101)) {
/*  956 */       paramSource.append('e');
/*  957 */       paramSource.append((char)paramTokenStream.getOp());
/*  958 */       object = this.nf.createBinary(101, paramTokenStream.getOp(), object, 
/*  959 */           relExpr(paramTokenStream, paramSource, paramBoolean));
/*      */     } 
/*  961 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object relExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
/*  967 */     Object object = shiftExpr(paramTokenStream, paramSource);
/*  968 */     while (paramTokenStream.matchToken(102)) {
/*  969 */       int i = paramTokenStream.getOp();
/*  970 */       if (paramBoolean && i == 63) {
/*  971 */         paramTokenStream.ungetToken(102);
/*      */         break;
/*      */       } 
/*  974 */       paramSource.append('f');
/*  975 */       paramSource.append((char)i);
/*  976 */       object = this.nf.createBinary(102, i, object, 
/*  977 */           shiftExpr(paramTokenStream, paramSource));
/*      */     } 
/*  979 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object shiftExpr(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
/*  985 */     Object object = addExpr(paramTokenStream, paramSource);
/*  986 */     while (paramTokenStream.matchToken(103)) {
/*  987 */       paramSource.append('g');
/*  988 */       paramSource.append((char)paramTokenStream.getOp());
/*  989 */       object = this.nf.createBinary(paramTokenStream.getOp(), object, addExpr(paramTokenStream, paramSource));
/*      */     } 
/*  991 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object addExpr(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
/*  998 */     Object object = mulExpr(paramTokenStream, paramSource);
/*      */     int i;
/* 1000 */     while ((i = paramTokenStream.getToken()) == 23 || i == 24) {
/* 1001 */       paramSource.append((char)i);
/*      */       
/* 1003 */       object = this.nf.createBinary(i, object, mulExpr(paramTokenStream, paramSource));
/*      */     } 
/* 1005 */     paramTokenStream.ungetToken(i);
/*      */     
/* 1007 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object mulExpr(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
/* 1015 */     Object object = unaryExpr(paramTokenStream, paramSource);
/*      */     int i;
/* 1017 */     while ((i = paramTokenStream.peekToken()) == 25 || 
/* 1018 */       i == 26 || 
/* 1019 */       i == 27) {
/* 1020 */       i = paramTokenStream.getToken();
/* 1021 */       paramSource.append((char)i);
/* 1022 */       object = this.nf.createBinary(i, object, unaryExpr(paramTokenStream, paramSource));
/*      */     } 
/*      */ 
/*      */     
/* 1026 */     return object;
/*      */   }
/*      */ 
/*      */   
/*      */   private Object unaryExpr(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
/*      */     int k;
/*      */     Object object;
/*      */     int j;
/* 1034 */     paramTokenStream.flags |= 0x10;
/* 1035 */     int i = paramTokenStream.getToken();
/* 1036 */     paramTokenStream.flags &= 0xFFFFFFEF;
/*      */     
/* 1038 */     switch (i)
/*      */     { case 104:
/* 1040 */         paramSource.append('h');
/* 1041 */         paramSource.append((char)paramTokenStream.getOp());
/* 1042 */         return this.nf.createUnary(104, paramTokenStream.getOp(), 
/* 1043 */             unaryExpr(paramTokenStream, paramSource));
/*      */       
/*      */       case 23:
/*      */       case 24:
/* 1047 */         paramSource.append('h');
/* 1048 */         paramSource.append((char)i);
/* 1049 */         return this.nf.createUnary(104, i, unaryExpr(paramTokenStream, paramSource));
/*      */       
/*      */       case 105:
/*      */       case 106:
/* 1053 */         paramSource.append((char)i);
/* 1054 */         return this.nf.createUnary(i, 129, memberExpr(paramTokenStream, paramSource, true));
/*      */       
/*      */       case 31:
/* 1057 */         paramSource.append('\037');
/* 1058 */         return this.nf.createUnary(31, unaryExpr(paramTokenStream, paramSource));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1064 */         paramTokenStream.ungetToken(i);
/*      */         
/* 1066 */         j = paramTokenStream.getLineno();
/*      */         
/* 1068 */         object = memberExpr(paramTokenStream, paramSource, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1078 */         if (((k = paramTokenStream.peekToken()) == 105 || 
/* 1079 */           k == 106) && 
/* 1080 */           paramTokenStream.getLineno() == j) {
/*      */           
/* 1082 */           int m = paramTokenStream.getToken();
/* 1083 */           paramSource.append((char)m);
/* 1084 */           return this.nf.createUnary(m, 130, object);
/*      */         } 
/* 1086 */         return object;
/*      */       case -1:
/* 1088 */         break; }  return this.nf.createName("err");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object argumentList(TokenStream paramTokenStream, Source paramSource, Object paramObject) throws IOException, JavaScriptException {
/* 1096 */     paramTokenStream.flags |= 0x10;
/* 1097 */     boolean bool = paramTokenStream.matchToken(94);
/* 1098 */     paramTokenStream.flags &= 0xFFFFFFEF;
/* 1099 */     if (!bool) {
/* 1100 */       boolean bool1 = true;
/*      */       do {
/* 1102 */         if (!bool1)
/* 1103 */           paramSource.append('_'); 
/* 1104 */         bool1 = false;
/* 1105 */         this.nf.addChildToBack(paramObject, assignExpr(paramTokenStream, paramSource, false));
/* 1106 */       } while (paramTokenStream.matchToken(95));
/*      */       
/* 1108 */       mustMatchToken(paramTokenStream, 94, "msg.no.paren.arg");
/*      */     } 
/* 1110 */     paramSource.append('^');
/* 1111 */     return paramObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object memberExpr(TokenStream paramTokenStream, Source paramSource, boolean paramBoolean) throws IOException, JavaScriptException {
/*      */     Object object;
/* 1123 */     paramTokenStream.flags |= 0x10;
/* 1124 */     int i = paramTokenStream.peekToken();
/* 1125 */     paramTokenStream.flags &= 0xFFFFFFEF;
/* 1126 */     if (i == 30) {
/*      */       
/* 1128 */       paramTokenStream.getToken();
/* 1129 */       paramSource.append('\036');
/*      */ 
/*      */       
/* 1132 */       object = this.nf.createLeaf(30);
/* 1133 */       this.nf.addChildToBack(object, memberExpr(paramTokenStream, paramSource, false));
/*      */       
/* 1135 */       if (paramTokenStream.matchToken(93)) {
/* 1136 */         paramSource.append(']');
/*      */         
/* 1138 */         object = argumentList(paramTokenStream, paramSource, object);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1150 */       i = paramTokenStream.peekToken();
/* 1151 */       if (i == 91) {
/* 1152 */         this.nf.addChildToBack(object, primaryExpr(paramTokenStream, paramSource));
/*      */       }
/*      */     } else {
/* 1155 */       object = primaryExpr(paramTokenStream, paramSource);
/*      */     } 
/*      */     
/* 1158 */     this.lastExprEndLine = paramTokenStream.getLineno();
/* 1159 */     while ((i = paramTokenStream.getToken()) > 0) {
/* 1160 */       if (i == 107) {
/* 1161 */         paramSource.append('k');
/* 1162 */         mustMatchToken(paramTokenStream, 44, "msg.no.name.after.dot");
/* 1163 */         String str = paramTokenStream.getString();
/* 1164 */         paramSource.addString(44, str);
/* 1165 */         object = this.nf.createBinary(107, object, 
/* 1166 */             this.nf.createName(paramTokenStream.getString()));
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1171 */         this.lastExprEndLine = paramTokenStream.getLineno(); continue;
/* 1172 */       }  if (i == 89) {
/* 1173 */         paramSource.append('Y');
/* 1174 */         object = this.nf.createBinary(89, object, expr(paramTokenStream, paramSource, false));
/*      */         
/* 1176 */         mustMatchToken(paramTokenStream, 90, "msg.no.bracket.index");
/* 1177 */         paramSource.append('Z');
/* 1178 */         this.lastExprEndLine = paramTokenStream.getLineno(); continue;
/* 1179 */       }  if (paramBoolean && i == 93) {
/*      */ 
/*      */         
/* 1182 */         object = this.nf.createUnary(43, object);
/* 1183 */         paramSource.append(']');
/*      */ 
/*      */         
/* 1186 */         object = argumentList(paramTokenStream, paramSource, object);
/* 1187 */         this.lastExprEndLine = paramTokenStream.getLineno(); continue;
/*      */       } 
/* 1189 */       paramTokenStream.ungetToken(i);
/*      */ 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 1195 */     return object;
/*      */   }
/*      */ 
/*      */   
/*      */   private Object primaryExpr(TokenStream paramTokenStream, Source paramSource) throws IOException, JavaScriptException {
/*      */     String str4, str3, str2;
/*      */     Number number;
/*      */     String str1;
/*      */     boolean bool;
/*      */     Object object;
/* 1205 */     paramTokenStream.flags |= 0x10;
/* 1206 */     int i = paramTokenStream.getToken();
/* 1207 */     paramTokenStream.flags &= 0xFFFFFFEF;
/*      */     
/* 1209 */     switch (i) {
/*      */       
/*      */       case 109:
/* 1212 */         return function(paramTokenStream, paramSource, true);
/*      */ 
/*      */       
/*      */       case 89:
/* 1216 */         paramSource.append('Y');
/* 1217 */         object = this.nf.createLeaf(133);
/*      */         
/* 1219 */         paramTokenStream.flags |= 0x10;
/* 1220 */         bool = paramTokenStream.matchToken(90);
/* 1221 */         paramTokenStream.flags &= 0xFFFFFFEF;
/*      */         
/* 1223 */         if (!bool) {
/* 1224 */           boolean bool1 = true;
/*      */           while (true)
/* 1226 */           { paramTokenStream.flags |= 0x10;
/* 1227 */             i = paramTokenStream.peekToken();
/* 1228 */             paramTokenStream.flags &= 0xFFFFFFEF;
/*      */             
/* 1230 */             if (!bool1) {
/* 1231 */               paramSource.append('_');
/*      */             } else {
/* 1233 */               bool1 = false;
/*      */             } 
/* 1235 */             if (i != 90)
/*      */             
/*      */             { 
/*      */               
/* 1239 */               if (i == 95) {
/* 1240 */                 this.nf.addChildToBack(object, this.nf.createLeaf(108, 
/* 1241 */                       74));
/*      */               } else {
/* 1243 */                 this.nf.addChildToBack(object, assignExpr(paramTokenStream, paramSource, false));
/*      */               } 
/*      */               
/* 1246 */               if (!paramTokenStream.matchToken(95))
/* 1247 */                 break;  continue; }  break; }  mustMatchToken(paramTokenStream, 90, "msg.no.bracket.arg");
/*      */         } 
/* 1249 */         paramSource.append('Z');
/* 1250 */         return this.nf.createArrayLiteral(object);
/*      */ 
/*      */       
/*      */       case 91:
/* 1254 */         object = this.nf.createLeaf(134);
/*      */         
/* 1256 */         paramSource.append('[');
/* 1257 */         if (!paramTokenStream.matchToken(92)) {
/*      */           
/* 1259 */           bool = true;
/*      */           do {
/*      */             Number number1;
/*      */             String str;
/*      */             Object object1;
/* 1264 */             if (!bool) {
/* 1265 */               paramSource.append('_');
/*      */             } else {
/* 1267 */               bool = false;
/*      */             } 
/* 1269 */             i = paramTokenStream.getToken();
/* 1270 */             switch (i) {
/*      */               
/*      */               case 44:
/*      */               case 46:
/* 1274 */                 str = paramTokenStream.getString();
/* 1275 */                 paramSource.addString(44, str);
/* 1276 */                 object1 = this.nf.createString(paramTokenStream.getString());
/*      */                 break;
/*      */               case 45:
/* 1279 */                 number1 = paramTokenStream.getNumber();
/* 1280 */                 paramSource.addNumber(number1);
/* 1281 */                 object1 = this.nf.createNumber(number1);
/*      */                 break;
/*      */               
/*      */               case 92:
/* 1285 */                 paramTokenStream.ungetToken(i);
/*      */                 break;
/*      */               default:
/* 1288 */                 reportError(paramTokenStream, "msg.bad.prop");
/*      */                 break;
/*      */             } 
/* 1291 */             mustMatchToken(paramTokenStream, 98, "msg.no.colon.prop");
/*      */ 
/*      */ 
/*      */             
/* 1295 */             paramSource.append('');
/* 1296 */             this.nf.addChildToBack(object, object1);
/* 1297 */             this.nf.addChildToBack(object, assignExpr(paramTokenStream, paramSource, false));
/*      */           }
/* 1299 */           while (paramTokenStream.matchToken(95));
/*      */           
/* 1301 */           mustMatchToken(paramTokenStream, 92, "msg.no.brace.prop");
/*      */         } 
/* 1303 */         paramSource.append('\\');
/* 1304 */         return this.nf.createObjectLiteral(object);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 93:
/* 1314 */         paramSource.append(']');
/* 1315 */         object = expr(paramTokenStream, paramSource, false);
/* 1316 */         paramSource.append('^');
/* 1317 */         mustMatchToken(paramTokenStream, 94, "msg.no.paren");
/* 1318 */         return object;
/*      */       
/*      */       case 44:
/* 1321 */         str1 = paramTokenStream.getString();
/* 1322 */         paramSource.addString(44, str1);
/* 1323 */         return this.nf.createName(str1);
/*      */       
/*      */       case 45:
/* 1326 */         number = paramTokenStream.getNumber();
/* 1327 */         paramSource.addNumber(number);
/* 1328 */         return this.nf.createNumber(number);
/*      */       
/*      */       case 46:
/* 1331 */         str2 = paramTokenStream.getString();
/* 1332 */         paramSource.addString(46, str2);
/* 1333 */         return this.nf.createString(str2);
/*      */ 
/*      */       
/*      */       case 56:
/* 1337 */         str3 = paramTokenStream.regExpFlags;
/* 1338 */         paramTokenStream.regExpFlags = null;
/* 1339 */         str4 = paramTokenStream.getString();
/* 1340 */         paramSource.addString(56, String.valueOf('/') + str4 + '/' + str3);
/* 1341 */         return this.nf.createRegExp(str4, str3);
/*      */ 
/*      */       
/*      */       case 108:
/* 1345 */         paramSource.append('l');
/* 1346 */         paramSource.append((char)paramTokenStream.getOp());
/* 1347 */         return this.nf.createLeaf(108, paramTokenStream.getOp());
/*      */       
/*      */       case 126:
/* 1350 */         reportError(paramTokenStream, "msg.reserved.id");
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1358 */         reportError(paramTokenStream, "msg.syntax"); break;
/*      */       case -1:
/*      */         break;
/*      */     } 
/* 1362 */     return null;
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\Parser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */