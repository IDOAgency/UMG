/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionNode
/*    */   extends Node
/*    */ {
/*    */   public static final byte FUNCTION_STATEMENT = 1;
/*    */   public static final byte FUNCTION_EXPRESSION = 2;
/*    */   public static final byte FUNCTION_EXPRESSION_STATEMENT = 3;
/*    */   protected VariableTable itsVariableTable;
/*    */   protected boolean itsNeedsActivation;
/*    */   protected byte itsFunctionType;
/*    */   
/*    */   public FunctionNode(String paramString, Node paramNode1, Node paramNode2) {
/* 44 */     super(109, paramNode1, paramNode2, paramString);
/* 45 */     this.itsVariableTable = new VariableTable();
/*    */   }
/*    */ 
/*    */   
/* 49 */   public String getFunctionName() { return getString(); }
/*    */ 
/*    */ 
/*    */   
/* 53 */   public VariableTable getVariableTable() { return this.itsVariableTable; }
/*    */ 
/*    */ 
/*    */   
/* 57 */   public boolean requiresActivation() { return this.itsNeedsActivation; }
/*    */ 
/*    */ 
/*    */   
/* 61 */   public boolean setRequiresActivation(boolean paramBoolean) { return this.itsNeedsActivation = paramBoolean; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 84 */   public byte getFunctionType() { return this.itsFunctionType; }
/*    */ 
/*    */ 
/*    */   
/* 88 */   public void setFunctionType(byte paramByte) { this.itsFunctionType = paramByte; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\FunctionNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */