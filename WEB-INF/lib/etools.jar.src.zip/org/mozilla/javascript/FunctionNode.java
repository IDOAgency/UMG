package org.mozilla.javascript;

public class FunctionNode extends Node {
  public static final byte FUNCTION_STATEMENT = 1;
  
  public static final byte FUNCTION_EXPRESSION = 2;
  
  public static final byte FUNCTION_EXPRESSION_STATEMENT = 3;
  
  protected VariableTable itsVariableTable;
  
  protected boolean itsNeedsActivation;
  
  protected byte itsFunctionType;
  
  public FunctionNode(String paramString, Node paramNode1, Node paramNode2) {
    super(109, paramNode1, paramNode2, paramString);
    this.itsVariableTable = new VariableTable();
  }
  
  public String getFunctionName() { return getString(); }
  
  public VariableTable getVariableTable() { return this.itsVariableTable; }
  
  public boolean requiresActivation() { return this.itsNeedsActivation; }
  
  public boolean setRequiresActivation(boolean paramBoolean) { return this.itsNeedsActivation = paramBoolean; }
  
  public byte getFunctionType() { return this.itsFunctionType; }
  
  public void setFunctionType(byte paramByte) { this.itsFunctionType = paramByte; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\FunctionNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */