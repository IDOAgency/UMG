/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeArray
/*     */   extends ScriptableObject
/*     */ {
/*     */   private static final int lengthAttr = 6;
/*     */   private long length;
/*     */   private Object[] dense;
/*     */   private static final int maximumDenseLength = 10000;
/*     */   
/*     */   public NativeArray() {
/*  68 */     this.dense = null;
/*  69 */     this.length = 0L;
/*     */   }
/*     */   
/*     */   public NativeArray(long paramLong) {
/*  73 */     int i = (int)paramLong;
/*  74 */     if (i == paramLong && i > 0) {
/*  75 */       if (i > 10000)
/*  76 */         i = 10000; 
/*  77 */       this.dense = new Object[i];
/*  78 */       for (byte b = 0; b < i; b++)
/*  79 */         this.dense[b] = Scriptable.NOT_FOUND; 
/*     */     } 
/*  81 */     this.length = paramLong;
/*     */   }
/*     */   
/*     */   public NativeArray(Object[] paramArrayOfObject) {
/*  85 */     this.dense = paramArrayOfObject;
/*  86 */     this.length = paramArrayOfObject.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) {
/*  95 */     String[] arrayOfString = { "reverse", 
/*  96 */         "toString" };
/*     */ 
/*     */     
/*  99 */     short[] arrayOfShort = new short[2];
/*     */ 
/*     */ 
/*     */     
/* 103 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 104 */       Object object = paramScriptable2.get(arrayOfString[b], paramScriptable2);
/* 105 */       ((FunctionObject)object).setLength(arrayOfShort[b]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 110 */   public String getClassName() { return "Array"; }
/*     */ 
/*     */   
/*     */   public Object get(int paramInt, Scriptable paramScriptable) {
/* 114 */     if (this.dense != null && paramInt >= 0 && paramInt < this.dense.length)
/* 115 */       return this.dense[paramInt]; 
/* 116 */     return super.get(paramInt, paramScriptable);
/*     */   }
/*     */   
/*     */   public boolean has(int paramInt, Scriptable paramScriptable) {
/* 120 */     if (this.dense != null && paramInt >= 0 && paramInt < this.dense.length)
/* 121 */       return !(this.dense[paramInt] == Scriptable.NOT_FOUND); 
/* 122 */     return super.has(paramInt, paramScriptable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
/* 129 */     double d = ScriptRuntime.toNumber(paramString);
/*     */     
/* 131 */     if (ScriptRuntime.toUint32(d) == d && 
/* 132 */       ScriptRuntime.numberToString(d, 10).equals(paramString) && 
/* 133 */       this.length <= d && d != 4.294967295E9D)
/*     */     {
/* 135 */       this.length = (long)d + 1L;
/*     */     }
/*     */     
/* 138 */     super.put(paramString, paramScriptable, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
/* 144 */     if (this.length <= paramInt)
/*     */     {
/* 146 */       this.length = paramInt + 1L;
/*     */     }
/*     */     
/* 149 */     if (this.dense != null && paramInt >= 0 && paramInt < this.dense.length) {
/* 150 */       this.dense[paramInt] = paramObject;
/*     */       
/*     */       return;
/*     */     } 
/* 154 */     super.put(paramInt, paramScriptable, paramObject);
/*     */   }
/*     */   
/*     */   public void delete(int paramInt) {
/* 158 */     if (this.dense != null && paramInt >= 0 && paramInt < this.dense.length) {
/* 159 */       this.dense[paramInt] = Scriptable.NOT_FOUND;
/*     */       return;
/*     */     } 
/* 162 */     super.delete(paramInt);
/*     */   }
/*     */   
/*     */   public Object[] getIds() {
/* 166 */     Object[] arrayOfObject1 = super.getIds();
/* 167 */     if (this.dense == null)
/* 168 */       return arrayOfObject1; 
/* 169 */     int i = 0;
/* 170 */     int j = this.dense.length;
/* 171 */     if (j > this.length)
/* 172 */       j = (int)this.length; 
/* 173 */     for (int k = j - 1; k >= 0; k--) {
/* 174 */       if (this.dense[k] != Scriptable.NOT_FOUND)
/* 175 */         i++; 
/*     */     } 
/* 177 */     i += arrayOfObject1.length;
/* 178 */     Object[] arrayOfObject2 = new Object[i];
/* 179 */     System.arraycopy(arrayOfObject1, 0, arrayOfObject2, 0, arrayOfObject1.length);
/* 180 */     for (int m = j - 1; m >= 0; m--) {
/* 181 */       if (this.dense[m] != Scriptable.NOT_FOUND)
/* 182 */         arrayOfObject2[--i] = new Integer(m); 
/*     */     } 
/* 184 */     return arrayOfObject2;
/*     */   }
/*     */   
/*     */   public Object getDefaultValue(Class paramClass) {
/* 188 */     if (paramClass == ScriptRuntime.NumberClass) {
/* 189 */       Context context = Context.getContext();
/* 190 */       if (context.getLanguageVersion() == 120)
/* 191 */         return new Long(this.length); 
/*     */     } 
/* 193 */     return super.getDefaultValue(paramClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) throws JavaScriptException {
/* 203 */     if (!paramBoolean)
/*     */     {
/* 205 */       return paramFunction.construct(paramContext, paramFunction.getParentScope(), paramArrayOfObject);
/*     */     }
/* 207 */     if (paramArrayOfObject.length == 0) {
/* 208 */       return new NativeArray();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 213 */     if (paramContext.getLanguageVersion() == 120) {
/* 214 */       return new NativeArray(paramArrayOfObject);
/*     */     }
/*     */     
/* 217 */     if (paramArrayOfObject.length > 1 || !(paramArrayOfObject[0] instanceof Number)) {
/* 218 */       return new NativeArray(paramArrayOfObject);
/*     */     }
/* 220 */     long l = ScriptRuntime.toUint32(paramArrayOfObject[0]);
/* 221 */     if (l != ((Number)paramArrayOfObject[0]).doubleValue())
/* 222 */       throw Context.reportRuntimeError(
/* 223 */           Context.getMessage("msg.arraylength.bad", null)); 
/* 224 */     return new NativeArray(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 233 */   public long jsGet_length() { return this.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void jsSet_length(Object paramObject) {
/* 244 */     if (!(paramObject instanceof Number)) {
/* 245 */       throw Context.reportRuntimeError(
/* 246 */           Context.getMessage("msg.arraylength.bad", null));
/*     */     }
/* 248 */     long l = ScriptRuntime.toUint32(paramObject);
/* 249 */     if (l != ((Number)paramObject).doubleValue()) {
/* 250 */       throw Context.reportRuntimeError(
/* 251 */           Context.getMessage("msg.arraylength.bad", null));
/*     */     }
/* 253 */     if (l < this.length)
/*     */     {
/* 255 */       if (this.length - l > 4096L) {
/*     */         
/* 257 */         Object[] arrayOfObject = getIds();
/* 258 */         for (byte b = 0; b < arrayOfObject.length; b++) {
/* 259 */           if (arrayOfObject[b] instanceof String) {
/*     */             
/* 261 */             String str = (String)arrayOfObject[b];
/* 262 */             double d = ScriptRuntime.toNumber(str);
/* 263 */             if (d == d && d < this.length) {
/* 264 */               delete(str);
/*     */             }
/*     */           } else {
/* 267 */             int i = ((Number)arrayOfObject[b]).intValue();
/* 268 */             if (i >= l)
/* 269 */               delete(i); 
/*     */           } 
/*     */         } 
/*     */       } else {
/* 273 */         for (long l1 = l; l1 < this.length; l1++) {
/*     */           
/* 275 */           if (hasElem(this, l1))
/* 276 */             ScriptRuntime.delete(this, new Long(l1)); 
/*     */         } 
/*     */       } 
/*     */     }
/* 280 */     this.length = l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static double getLengthProperty(Scriptable paramScriptable) {
/* 291 */     if (paramScriptable instanceof NativeString)
/* 292 */       return ((NativeString)paramScriptable).jsGet_length(); 
/* 293 */     if (paramScriptable instanceof NativeArray)
/* 294 */       return ((NativeArray)paramScriptable).jsGet_length(); 
/* 295 */     return ScriptRuntime.toUint32(
/* 296 */         ScriptRuntime.getProp(paramScriptable, "length", paramScriptable));
/*     */   }
/*     */   
/*     */   static boolean hasLengthProperty(Object paramObject) {
/* 300 */     if (!(paramObject instanceof Scriptable) || paramObject == Context.getUndefinedValue())
/* 301 */       return false; 
/* 302 */     if (paramObject instanceof NativeString || paramObject instanceof NativeArray)
/* 303 */       return true; 
/* 304 */     Scriptable scriptable = (Scriptable)paramObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 310 */     Object object = ScriptRuntime.getProp(scriptable, "length", scriptable);
/* 311 */     return object instanceof Number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasElem(Scriptable paramScriptable, long paramLong) {
/* 320 */     return (paramLong > 2147483647L) ? 
/* 321 */       paramScriptable.has(Long.toString(paramLong), paramScriptable) : 
/* 322 */       paramScriptable.has((int)paramLong, paramScriptable);
/*     */   }
/*     */   
/*     */   private static Object getElem(Scriptable paramScriptable, long paramLong) {
/* 326 */     if (paramLong > 2147483647L) {
/* 327 */       String str = Long.toString(paramLong);
/* 328 */       return ScriptRuntime.getElem(paramScriptable, str, paramScriptable);
/*     */     } 
/* 330 */     return ScriptRuntime.getElem(paramScriptable, (int)paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void setElem(Scriptable paramScriptable, long paramLong, Object paramObject) {
/* 335 */     if (paramLong > 2147483647L) {
/* 336 */       String str = Long.toString(paramLong);
/* 337 */       ScriptRuntime.setElem(paramScriptable, str, paramObject, paramScriptable);
/*     */     } else {
/* 339 */       ScriptRuntime.setElem(paramScriptable, (int)paramLong, paramObject);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String jsFunction_toString(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 346 */     return toStringHelper(paramContext, paramScriptable, 
/* 347 */         !(paramContext.getLanguageVersion() != 120));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String toStringHelper(Context paramContext, Scriptable paramScriptable, boolean paramBoolean) {
/*     */     String str;
/* 357 */     long l1 = (long)getLengthProperty(paramScriptable);
/*     */     
/* 359 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 361 */     if (paramContext.iterating == null)
/* 362 */       paramContext.iterating = new Hashtable(31); 
/* 363 */     boolean bool1 = (paramContext.iterating.get(paramScriptable) != Boolean.TRUE) ? 0 : 1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 368 */     if (paramBoolean) {
/* 369 */       stringBuffer.append("[");
/* 370 */       str = ", ";
/*     */     } else {
/* 372 */       str = ",";
/*     */     } 
/*     */     
/* 375 */     boolean bool2 = false;
/* 376 */     long l2 = 0L;
/*     */     
/* 378 */     if (!bool1) {
/* 379 */       for (l2 = 0L; l2 < l1; l2++) {
/* 380 */         if (l2 > 0L)
/* 381 */           stringBuffer.append(str); 
/* 382 */         Object object = getElem(paramScriptable, l2);
/* 383 */         if (object == null || object == Undefined.instance) {
/* 384 */           bool2 = false;
/*     */         } else {
/*     */           
/* 387 */           bool2 = true;
/*     */           
/* 389 */           if (object instanceof String) {
/* 390 */             if (paramBoolean) {
/* 391 */               stringBuffer.append("\"");
/* 392 */               stringBuffer.append(
/* 393 */                   ScriptRuntime.escapeString(ScriptRuntime.toString(object)));
/* 394 */               stringBuffer.append("\"");
/*     */             } else {
/* 396 */               stringBuffer.append(ScriptRuntime.toString(object));
/*     */             } 
/*     */           } else {
/*     */ 
/*     */             
/*     */             try {
/*     */ 
/*     */ 
/*     */               
/* 405 */               paramContext.iterating.put(paramScriptable, Boolean.TRUE);
/* 406 */               stringBuffer.append(ScriptRuntime.toString(object));
/*     */             } finally {
/* 408 */               paramContext.iterating.remove(paramScriptable);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/* 414 */     if (paramBoolean)
/*     */     {
/* 416 */       if (!bool2 && l2 > 0L) {
/* 417 */         stringBuffer.append(", ]");
/*     */       } else {
/* 419 */         stringBuffer.append("]");
/*     */       }  } 
/* 421 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String jsFunction_join(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/*     */     String str;
/* 430 */     StringBuffer stringBuffer = new StringBuffer();
/*     */ 
/*     */     
/* 433 */     double d = getLengthProperty(paramScriptable);
/*     */ 
/*     */     
/* 436 */     if (paramArrayOfObject.length < 1) {
/* 437 */       str = ",";
/*     */     } else {
/* 439 */       str = ScriptRuntime.toString(paramArrayOfObject[0]);
/*     */     } 
/* 441 */     for (long l = 0L; l < d; l++) {
/* 442 */       if (l > 0L)
/* 443 */         stringBuffer.append(str); 
/* 444 */       Object object = getElem(paramScriptable, l);
/* 445 */       if (object != null && object != Undefined.instance)
/*     */       {
/* 447 */         stringBuffer.append(ScriptRuntime.toString(object)); } 
/*     */     } 
/* 449 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Scriptable jsFunction_reverse(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 458 */     long l1 = (long)getLengthProperty(paramScriptable);
/*     */     
/* 460 */     long l2 = l1 / 2L;
/* 461 */     for (long l3 = 0L; l3 < l2; l3++) {
/* 462 */       long l = l1 - l3 - 1L;
/* 463 */       Object object1 = getElem(paramScriptable, l3);
/* 464 */       Object object2 = getElem(paramScriptable, l);
/* 465 */       setElem(paramScriptable, l3, object2);
/* 466 */       setElem(paramScriptable, l, object1);
/*     */     } 
/* 468 */     return paramScriptable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Scriptable jsFunction_sort(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/*     */     Object object;
/* 478 */     long l = (long)getLengthProperty(paramScriptable);
/*     */ 
/*     */     
/* 481 */     if (paramArrayOfObject.length > 0 && Undefined.instance != paramArrayOfObject[false]) {
/*     */       
/* 483 */       object = paramArrayOfObject[0];
/*     */     } else {
/*     */       
/* 486 */       object = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 493 */     if (l >= 2147483647L) {
/* 494 */       qsort_extended(paramContext, object, paramScriptable, 0L, l - 1L);
/*     */     }
/*     */     else {
/*     */       
/* 498 */       Object[] arrayOfObject = new Object[(int)l];
/* 499 */       for (byte b1 = 0; b1 < l; b1++) {
/* 500 */         arrayOfObject[b1] = getElem(paramScriptable, b1);
/*     */       }
/*     */       
/* 503 */       qsort(paramContext, object, arrayOfObject, 0, (int)l - 1, paramFunction);
/*     */ 
/*     */       
/* 506 */       for (byte b2 = 0; b2 < l; b2++) {
/* 507 */         setElem(paramScriptable, b2, arrayOfObject[b2]);
/*     */       }
/*     */     } 
/* 510 */     return paramScriptable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double qsortCompare(Context paramContext, Object paramObject1, Object paramObject2, Object paramObject3, Scriptable paramScriptable) throws JavaScriptException {
/* 517 */     Scriptable scriptable = Undefined.instance;
/*     */ 
/*     */     
/* 520 */     if (scriptable == paramObject2 || scriptable == paramObject3) {
/* 521 */       if (scriptable != paramObject2)
/* 522 */         return -1.0D; 
/* 523 */       if (scriptable != paramObject3)
/* 524 */         return 1.0D; 
/* 525 */       return 0.0D;
/*     */     } 
/*     */     
/* 528 */     if (paramObject1 == null) {
/*     */       
/* 530 */       String str1 = ScriptRuntime.toString(paramObject2);
/* 531 */       String str2 = ScriptRuntime.toString(paramObject3);
/*     */       
/* 533 */       return str1.compareTo(str2);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 541 */     Object[] arrayOfObject = { paramObject2, paramObject3 };
/*     */ 
/*     */ 
/*     */     
/* 545 */     double d = 
/* 546 */       ScriptRuntime.toNumber(ScriptRuntime.call(paramContext, paramObject1, null, arrayOfObject, paramScriptable));
/*     */     
/* 548 */     return (d == d) ? d : 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void qsort(Context paramContext, Object paramObject, Object[] paramArrayOfObject, int paramInt1, int paramInt2, Scriptable paramScriptable) throws JavaScriptException {
/* 560 */     while (paramInt1 < paramInt2) {
/* 561 */       int i = paramInt1;
/* 562 */       int j = paramInt2;
/* 563 */       int k = i;
/* 564 */       Object object = paramArrayOfObject[k];
/* 565 */       while (i < j) {
/*     */         int m; while (true) {
/* 567 */           m = j;
/* 568 */           if (qsortCompare(paramContext, paramObject, paramArrayOfObject[j], object, 
/* 569 */               paramScriptable) > 0.0D) {
/*     */             
/* 571 */             j--; continue;
/*     */           }  break;
/* 573 */         }  paramArrayOfObject[k] = paramArrayOfObject[m];
/* 574 */         while (i < j && qsortCompare(paramContext, paramObject, paramArrayOfObject[k], 
/* 575 */             object, paramScriptable) <= 0.0D)
/*     */         {
/*     */           
/* 578 */           k = ++i;
/*     */         }
/* 580 */         paramArrayOfObject[m] = paramArrayOfObject[k];
/*     */       } 
/* 582 */       paramArrayOfObject[k] = object;
/* 583 */       if (i - paramInt1 < paramInt2 - i) {
/* 584 */         qsort(paramContext, paramObject, paramArrayOfObject, paramInt1, i - 1, paramScriptable);
/* 585 */         paramInt1 = i + 1; continue;
/*     */       } 
/* 587 */       qsort(paramContext, paramObject, paramArrayOfObject, i + 1, paramInt2, paramScriptable);
/* 588 */       paramInt2 = i - 1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void qsort_extended(Context paramContext, Object paramObject, Scriptable paramScriptable, long paramLong1, long paramLong2) throws JavaScriptException {
/* 603 */     while (paramLong1 < paramLong2) {
/* 604 */       long l1 = paramLong1;
/* 605 */       long l2 = paramLong2;
/* 606 */       long l3 = l1;
/* 607 */       Object object = getElem(paramScriptable, l3);
/* 608 */       while (l1 < l2) {
/*     */         long l; while (true) {
/* 610 */           l = l2;
/* 611 */           if (qsortCompare(paramContext, paramObject, getElem(paramScriptable, l2), 
/* 612 */               object, paramScriptable) > 0.0D) {
/*     */             
/* 614 */             l2--; continue;
/*     */           }  break;
/* 616 */         }  setElem(paramScriptable, l3, getElem(paramScriptable, l));
/* 617 */         while (l1 < l2 && qsortCompare(paramContext, paramObject, 
/* 618 */             getElem(paramScriptable, l3), 
/* 619 */             object, paramScriptable) <= 0.0D)
/*     */         {
/*     */           
/* 622 */           l3 = ++l1;
/*     */         }
/* 624 */         setElem(paramScriptable, l, getElem(paramScriptable, l3));
/*     */       } 
/* 626 */       setElem(paramScriptable, l3, object);
/* 627 */       if (l1 - paramLong1 < paramLong2 - l1) {
/* 628 */         qsort_extended(paramContext, paramObject, paramScriptable, paramLong1, l1 - 1L);
/* 629 */         paramLong1 = l1 + 1L; continue;
/*     */       } 
/* 631 */       qsort_extended(paramContext, paramObject, paramScriptable, l1 + 1L, paramLong2);
/* 632 */       paramLong2 = l1 - 1L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsFunction_push(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 644 */     double d = getLengthProperty(paramScriptable);
/* 645 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 646 */       setElem(paramScriptable, (long)d + b, paramArrayOfObject[b]);
/*     */     }
/*     */     
/* 649 */     d += paramArrayOfObject.length;
/* 650 */     ScriptRuntime.setProp(paramScriptable, "length", new Double(d), paramScriptable);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 656 */     if (paramContext.getLanguageVersion() == 120)
/*     */     {
/* 658 */       return (paramArrayOfObject.length == 0) ? 
/* 659 */         Context.getUndefinedValue() : 
/* 660 */         paramArrayOfObject[paramArrayOfObject.length - 1];
/*     */     }
/*     */     
/* 663 */     return new Long((long)d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsFunction_pop(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/*     */     Object object;
/* 670 */     double d = getLengthProperty(paramScriptable);
/* 671 */     if (d > 0.0D) {
/* 672 */       d--;
/*     */ 
/*     */       
/* 675 */       object = getElem(paramScriptable, (long)d);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 680 */       object = Context.getUndefinedValue();
/*     */     } 
/*     */ 
/*     */     
/* 684 */     ScriptRuntime.setProp(paramScriptable, "length", new Double(d), paramScriptable);
/*     */     
/* 686 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsFunction_shift(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/*     */     Object object;
/* 693 */     double d = getLengthProperty(paramScriptable);
/* 694 */     if (d > 0.0D) {
/* 695 */       long l = 0L;
/* 696 */       d--;
/*     */ 
/*     */       
/* 699 */       object = getElem(paramScriptable, l);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 705 */       if (d > 0.0D) {
/* 706 */         for (l = 1L; l <= d; l++) {
/* 707 */           Object object1 = getElem(paramScriptable, l);
/* 708 */           setElem(paramScriptable, l - 1L, object1);
/*     */         }
/*     */       
/*     */       }
/*     */     } else {
/*     */       
/* 714 */       object = Context.getUndefinedValue();
/*     */     } 
/* 716 */     ScriptRuntime.setProp(paramScriptable, "length", new Double(d), paramScriptable);
/* 717 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsFunction_unshift(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 724 */     double d = getLengthProperty(paramScriptable);
/* 725 */     int i = paramArrayOfObject.length;
/*     */     
/* 727 */     if (paramArrayOfObject.length > 0) {
/*     */       
/* 729 */       if (d > 0.0D) {
/* 730 */         for (long l = (long)d - 1L; l >= 0L; l--) {
/* 731 */           Object object = getElem(paramScriptable, l);
/* 732 */           setElem(paramScriptable, l + i, object);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 737 */       for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 738 */         setElem(paramScriptable, b, paramArrayOfObject[b]);
/*     */       }
/*     */ 
/*     */       
/* 742 */       d += paramArrayOfObject.length;
/* 743 */       ScriptRuntime.setProp(paramScriptable, "length", 
/* 744 */           new Double(d), paramScriptable);
/*     */     } 
/* 746 */     return new Long((long)d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object jsFunction_splice(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/*     */     double d5, d3;
/* 753 */     Scriptable scriptable = ScriptableObject.getTopLevelScope(paramFunction);
/* 754 */     Object object = ScriptRuntime.newObject(paramContext, scriptable, "Array", null);
/* 755 */     int i = paramArrayOfObject.length;
/* 756 */     if (i == 0)
/* 757 */       return object; 
/* 758 */     double d1 = getLengthProperty(paramScriptable);
/*     */ 
/*     */     
/* 761 */     double d2 = ScriptRuntime.toInteger(paramArrayOfObject[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 766 */     if (d2 < 0.0D) {
/* 767 */       d2 += d1;
/* 768 */       if (d2 < 0.0D)
/* 769 */         d2 = 0.0D; 
/* 770 */     } else if (d2 > d1) {
/* 771 */       d2 = d1;
/*     */     } 
/* 773 */     i--;
/*     */ 
/*     */     
/* 776 */     double d4 = d1 - d2;
/*     */     
/* 778 */     if (paramArrayOfObject.length == 1) {
/* 779 */       d5 = d4;
/* 780 */       d3 = d1;
/*     */     } else {
/* 782 */       d5 = ScriptRuntime.toInteger(paramArrayOfObject[1]);
/* 783 */       if (d5 < 0.0D) {
/* 784 */         d5 = 0.0D;
/* 785 */       } else if (d5 > d4) {
/* 786 */         d5 = d4;
/* 787 */       }  d3 = d2 + d5;
/*     */       
/* 789 */       i--;
/*     */     } 
/*     */     
/* 792 */     long l1 = (long)d2;
/* 793 */     long l2 = (long)d3;
/*     */ 
/*     */     
/* 796 */     if (d5 > 0.0D) {
/* 797 */       Object object1; if (d5 == 1.0D && 
/* 798 */         paramContext.getLanguageVersion() == 120) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 811 */         object1 = getElem(paramScriptable, l1);
/*     */       } else {
/* 813 */         for (long l = l1; l < l2; l++) {
/* 814 */           Scriptable scriptable1 = (Scriptable)object1;
/* 815 */           Object object2 = getElem(paramScriptable, l);
/* 816 */           setElem(scriptable1, l - l1, object2);
/*     */         } 
/*     */       } 
/* 819 */     } else if (d5 == 0.0D && 
/* 820 */       paramContext.getLanguageVersion() == 120) {
/*     */ 
/*     */       
/* 823 */       object = Context.getUndefinedValue();
/*     */     } 
/*     */ 
/*     */     
/* 827 */     d4 = i - d5;
/*     */     
/* 829 */     if (d4 > 0.0D) {
/* 830 */       for (long l = (long)d1 - 1L; l >= l2; l--) {
/* 831 */         Object object1 = getElem(paramScriptable, l);
/* 832 */         setElem(paramScriptable, l + (long)d4, object1);
/*     */       } 
/* 834 */     } else if (d4 < 0.0D) {
/* 835 */       for (long l = l2; l < d1; l++) {
/* 836 */         Object object1 = getElem(paramScriptable, l);
/* 837 */         setElem(paramScriptable, l + (long)d4, object1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 842 */     int j = paramArrayOfObject.length - i;
/* 843 */     for (int k = 0; k < i; k++) {
/* 844 */       setElem(paramScriptable, l1 + k, paramArrayOfObject[k + j]);
/*     */     }
/*     */ 
/*     */     
/* 848 */     ScriptRuntime.setProp(paramScriptable, "length", 
/* 849 */         new Double(d1 + d4), paramScriptable);
/* 850 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Scriptable jsFunction_concat(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 869 */     Scriptable scriptable1 = ScriptableObject.getTopLevelScope(paramFunction);
/* 870 */     Scriptable scriptable2 = ScriptRuntime.newObject(paramContext, scriptable1, "Array", null);
/*     */     
/* 872 */     long l = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 877 */     if (hasLengthProperty(paramScriptable)) {
/* 878 */       double d = getLengthProperty(paramScriptable);
/*     */ 
/*     */       
/* 881 */       for (l = 0L; l < d; l++) {
/* 882 */         Object object = getElem(paramScriptable, l);
/* 883 */         setElem(scriptable2, l, object);
/*     */       } 
/*     */     } else {
/* 886 */       setElem(scriptable2, l++, paramScriptable);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 893 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 894 */       if (hasLengthProperty(paramArrayOfObject[b])) {
/*     */         
/* 896 */         Scriptable scriptable = (Scriptable)paramArrayOfObject[b];
/* 897 */         double d = getLengthProperty(scriptable);
/* 898 */         for (long l1 = 0L; l1 < d; l1++, l++) {
/* 899 */           Object object = getElem(scriptable, l1);
/* 900 */           setElem(scriptable2, l, object);
/*     */         } 
/*     */       } else {
/* 903 */         setElem(scriptable2, l++, paramArrayOfObject[b]);
/*     */       } 
/*     */     } 
/* 906 */     return scriptable2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Scriptable jsFunction_slice(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
/* 912 */     Scriptable scriptable1 = ScriptableObject.getTopLevelScope(paramFunction);
/* 913 */     Scriptable scriptable2 = ScriptRuntime.newObject(paramContext, scriptable1, "Array", null);
/* 914 */     double d1 = getLengthProperty(paramScriptable);
/*     */     
/* 916 */     double d2 = 0.0D;
/* 917 */     double d3 = d1;
/*     */     
/* 919 */     if (paramArrayOfObject.length > 0) {
/* 920 */       d2 = ScriptRuntime.toInteger(paramArrayOfObject[0]);
/* 921 */       if (d2 < 0.0D) {
/* 922 */         d2 += d1;
/* 923 */         if (d2 < 0.0D)
/* 924 */           d2 = 0.0D; 
/* 925 */       } else if (d2 > d1) {
/* 926 */         d2 = d1;
/*     */       } 
/*     */       
/* 929 */       if (paramArrayOfObject.length > 1) {
/* 930 */         d3 = ScriptRuntime.toInteger(paramArrayOfObject[1]);
/* 931 */         if (d3 < 0.0D) {
/* 932 */           d3 += d1;
/* 933 */           if (d3 < 0.0D)
/* 934 */             d3 = 0.0D; 
/* 935 */         } else if (d3 > d1) {
/* 936 */           d3 = d1;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 941 */     long l1 = (long)d2;
/* 942 */     long l2 = (long)d3;
/* 943 */     for (long l3 = l1; l3 < l2; l3++) {
/* 944 */       Object object = getElem(paramScriptable, l3);
/* 945 */       setElem(scriptable2, l3 - l1, object);
/*     */     } 
/*     */     
/* 948 */     return scriptable2;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeArray.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */