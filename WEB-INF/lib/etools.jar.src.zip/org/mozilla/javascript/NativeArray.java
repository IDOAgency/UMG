package org.mozilla.javascript;

import java.util.Hashtable;

public class NativeArray extends ScriptableObject {
  private static final int lengthAttr = 6;
  
  private long length;
  
  private Object[] dense;
  
  private static final int maximumDenseLength = 10000;
  
  public NativeArray() {
    this.dense = null;
    this.length = 0L;
  }
  
  public NativeArray(long paramLong) {
    int i = (int)paramLong;
    if (i == paramLong && i > 0) {
      if (i > 10000)
        i = 10000; 
      this.dense = new Object[i];
      for (byte b = 0; b < i; b++)
        this.dense[b] = Scriptable.NOT_FOUND; 
    } 
    this.length = paramLong;
  }
  
  public NativeArray(Object[] paramArrayOfObject) {
    this.dense = paramArrayOfObject;
    this.length = paramArrayOfObject.length;
  }
  
  public static void finishInit(Scriptable paramScriptable1, FunctionObject paramFunctionObject, Scriptable paramScriptable2) {
    String[] arrayOfString = { "reverse", 
        "toString" };
    short[] arrayOfShort = new short[2];
    for (byte b = 0; b < arrayOfString.length; b++) {
      Object object = paramScriptable2.get(arrayOfString[b], paramScriptable2);
      ((FunctionObject)object).setLength(arrayOfShort[b]);
    } 
  }
  
  public String getClassName() { return "Array"; }
  
  public Object get(int paramInt, Scriptable paramScriptable) {
    if (this.dense != null && paramInt >= 0 && paramInt < this.dense.length)
      return this.dense[paramInt]; 
    return super.get(paramInt, paramScriptable);
  }
  
  public boolean has(int paramInt, Scriptable paramScriptable) {
    if (this.dense != null && paramInt >= 0 && paramInt < this.dense.length)
      return !(this.dense[paramInt] == Scriptable.NOT_FOUND); 
    return super.has(paramInt, paramScriptable);
  }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
    double d = ScriptRuntime.toNumber(paramString);
    if (ScriptRuntime.toUint32(d) == d && 
      ScriptRuntime.numberToString(d, 10).equals(paramString) && 
      this.length <= d && d != 4.294967295E9D)
      this.length = (long)d + 1L; 
    super.put(paramString, paramScriptable, paramObject);
  }
  
  public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
    if (this.length <= paramInt)
      this.length = paramInt + 1L; 
    if (this.dense != null && paramInt >= 0 && paramInt < this.dense.length) {
      this.dense[paramInt] = paramObject;
      return;
    } 
    super.put(paramInt, paramScriptable, paramObject);
  }
  
  public void delete(int paramInt) {
    if (this.dense != null && paramInt >= 0 && paramInt < this.dense.length) {
      this.dense[paramInt] = Scriptable.NOT_FOUND;
      return;
    } 
    super.delete(paramInt);
  }
  
  public Object[] getIds() {
    Object[] arrayOfObject1 = super.getIds();
    if (this.dense == null)
      return arrayOfObject1; 
    int i = 0;
    int j = this.dense.length;
    if (j > this.length)
      j = (int)this.length; 
    for (int k = j - 1; k >= 0; k--) {
      if (this.dense[k] != Scriptable.NOT_FOUND)
        i++; 
    } 
    i += arrayOfObject1.length;
    Object[] arrayOfObject2 = new Object[i];
    System.arraycopy(arrayOfObject1, 0, arrayOfObject2, 0, arrayOfObject1.length);
    for (int m = j - 1; m >= 0; m--) {
      if (this.dense[m] != Scriptable.NOT_FOUND)
        arrayOfObject2[--i] = new Integer(m); 
    } 
    return arrayOfObject2;
  }
  
  public Object getDefaultValue(Class paramClass) {
    if (paramClass == ScriptRuntime.NumberClass) {
      Context context = Context.getContext();
      if (context.getLanguageVersion() == 120)
        return new Long(this.length); 
    } 
    return super.getDefaultValue(paramClass);
  }
  
  public static Object jsConstructor(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) throws JavaScriptException {
    if (!paramBoolean)
      return paramFunction.construct(paramContext, paramFunction.getParentScope(), paramArrayOfObject); 
    if (paramArrayOfObject.length == 0)
      return new NativeArray(); 
    if (paramContext.getLanguageVersion() == 120)
      return new NativeArray(paramArrayOfObject); 
    if (paramArrayOfObject.length > 1 || !(paramArrayOfObject[0] instanceof Number))
      return new NativeArray(paramArrayOfObject); 
    long l = ScriptRuntime.toUint32(paramArrayOfObject[0]);
    if (l != ((Number)paramArrayOfObject[0]).doubleValue())
      throw Context.reportRuntimeError(
          Context.getMessage("msg.arraylength.bad", null)); 
    return new NativeArray(l);
  }
  
  public long jsGet_length() { return this.length; }
  
  public void jsSet_length(Object paramObject) {
    if (!(paramObject instanceof Number))
      throw Context.reportRuntimeError(
          Context.getMessage("msg.arraylength.bad", null)); 
    long l = ScriptRuntime.toUint32(paramObject);
    if (l != ((Number)paramObject).doubleValue())
      throw Context.reportRuntimeError(
          Context.getMessage("msg.arraylength.bad", null)); 
    if (l < this.length)
      if (this.length - l > 4096L) {
        Object[] arrayOfObject = getIds();
        for (byte b = 0; b < arrayOfObject.length; b++) {
          if (arrayOfObject[b] instanceof String) {
            String str = (String)arrayOfObject[b];
            double d = ScriptRuntime.toNumber(str);
            if (d == d && d < this.length)
              delete(str); 
          } else {
            int i = ((Number)arrayOfObject[b]).intValue();
            if (i >= l)
              delete(i); 
          } 
        } 
      } else {
        for (long l1 = l; l1 < this.length; l1++) {
          if (hasElem(this, l1))
            ScriptRuntime.delete(this, new Long(l1)); 
        } 
      }  
    this.length = l;
  }
  
  static double getLengthProperty(Scriptable paramScriptable) {
    if (paramScriptable instanceof NativeString)
      return ((NativeString)paramScriptable).jsGet_length(); 
    if (paramScriptable instanceof NativeArray)
      return ((NativeArray)paramScriptable).jsGet_length(); 
    return ScriptRuntime.toUint32(
        ScriptRuntime.getProp(paramScriptable, "length", paramScriptable));
  }
  
  static boolean hasLengthProperty(Object paramObject) {
    if (!(paramObject instanceof Scriptable) || paramObject == Context.getUndefinedValue())
      return false; 
    if (paramObject instanceof NativeString || paramObject instanceof NativeArray)
      return true; 
    Scriptable scriptable = (Scriptable)paramObject;
    Object object = ScriptRuntime.getProp(scriptable, "length", scriptable);
    return object instanceof Number;
  }
  
  private static boolean hasElem(Scriptable paramScriptable, long paramLong) {
    return (paramLong > 2147483647L) ? 
      paramScriptable.has(Long.toString(paramLong), paramScriptable) : 
      paramScriptable.has((int)paramLong, paramScriptable);
  }
  
  private static Object getElem(Scriptable paramScriptable, long paramLong) {
    if (paramLong > 2147483647L) {
      String str = Long.toString(paramLong);
      return ScriptRuntime.getElem(paramScriptable, str, paramScriptable);
    } 
    return ScriptRuntime.getElem(paramScriptable, (int)paramLong);
  }
  
  private static void setElem(Scriptable paramScriptable, long paramLong, Object paramObject) {
    if (paramLong > 2147483647L) {
      String str = Long.toString(paramLong);
      ScriptRuntime.setElem(paramScriptable, str, paramObject, paramScriptable);
    } else {
      ScriptRuntime.setElem(paramScriptable, (int)paramLong, paramObject);
    } 
  }
  
  public static String jsFunction_toString(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    return toStringHelper(paramContext, paramScriptable, 
        !(paramContext.getLanguageVersion() != 120));
  }
  
  private static String toStringHelper(Context paramContext, Scriptable paramScriptable, boolean paramBoolean) {
    String str;
    long l1 = (long)getLengthProperty(paramScriptable);
    StringBuffer stringBuffer = new StringBuffer();
    if (paramContext.iterating == null)
      paramContext.iterating = new Hashtable(31); 
    boolean bool1 = (paramContext.iterating.get(paramScriptable) != Boolean.TRUE) ? 0 : 1;
    if (paramBoolean) {
      stringBuffer.append("[");
      str = ", ";
    } else {
      str = ",";
    } 
    boolean bool2 = false;
    long l2 = 0L;
    if (!bool1)
      for (l2 = 0L; l2 < l1; l2++) {
        if (l2 > 0L)
          stringBuffer.append(str); 
        Object object = getElem(paramScriptable, l2);
        if (object == null || object == Undefined.instance) {
          bool2 = false;
        } else {
          bool2 = true;
          if (object instanceof String) {
            if (paramBoolean) {
              stringBuffer.append("\"");
              stringBuffer.append(
                  ScriptRuntime.escapeString(ScriptRuntime.toString(object)));
              stringBuffer.append("\"");
            } else {
              stringBuffer.append(ScriptRuntime.toString(object));
            } 
          } else {
            try {
              paramContext.iterating.put(paramScriptable, Boolean.TRUE);
              stringBuffer.append(ScriptRuntime.toString(object));
            } finally {
              paramContext.iterating.remove(paramScriptable);
            } 
          } 
        } 
      }  
    if (paramBoolean)
      if (!bool2 && l2 > 0L) {
        stringBuffer.append(", ]");
      } else {
        stringBuffer.append("]");
      }  
    return stringBuffer.toString();
  }
  
  public static String jsFunction_join(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    String str;
    StringBuffer stringBuffer = new StringBuffer();
    double d = getLengthProperty(paramScriptable);
    if (paramArrayOfObject.length < 1) {
      str = ",";
    } else {
      str = ScriptRuntime.toString(paramArrayOfObject[0]);
    } 
    for (long l = 0L; l < d; l++) {
      if (l > 0L)
        stringBuffer.append(str); 
      Object object = getElem(paramScriptable, l);
      if (object != null && object != Undefined.instance)
        stringBuffer.append(ScriptRuntime.toString(object)); 
    } 
    return stringBuffer.toString();
  }
  
  public static Scriptable jsFunction_reverse(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    long l1 = (long)getLengthProperty(paramScriptable);
    long l2 = l1 / 2L;
    for (long l3 = 0L; l3 < l2; l3++) {
      long l = l1 - l3 - 1L;
      Object object1 = getElem(paramScriptable, l3);
      Object object2 = getElem(paramScriptable, l);
      setElem(paramScriptable, l3, object2);
      setElem(paramScriptable, l, object1);
    } 
    return paramScriptable;
  }
  
  public static Scriptable jsFunction_sort(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    Object object;
    long l = (long)getLengthProperty(paramScriptable);
    if (paramArrayOfObject.length > 0 && Undefined.instance != paramArrayOfObject[false]) {
      object = paramArrayOfObject[0];
    } else {
      object = null;
    } 
    if (l >= 2147483647L) {
      qsort_extended(paramContext, object, paramScriptable, 0L, l - 1L);
    } else {
      Object[] arrayOfObject = new Object[(int)l];
      for (byte b1 = 0; b1 < l; b1++)
        arrayOfObject[b1] = getElem(paramScriptable, b1); 
      qsort(paramContext, object, arrayOfObject, 0, (int)l - 1, paramFunction);
      for (byte b2 = 0; b2 < l; b2++)
        setElem(paramScriptable, b2, arrayOfObject[b2]); 
    } 
    return paramScriptable;
  }
  
  private static double qsortCompare(Context paramContext, Object paramObject1, Object paramObject2, Object paramObject3, Scriptable paramScriptable) throws JavaScriptException {
    Scriptable scriptable = Undefined.instance;
    if (scriptable == paramObject2 || scriptable == paramObject3) {
      if (scriptable != paramObject2)
        return -1.0D; 
      if (scriptable != paramObject3)
        return 1.0D; 
      return 0.0D;
    } 
    if (paramObject1 == null) {
      String str1 = ScriptRuntime.toString(paramObject2);
      String str2 = ScriptRuntime.toString(paramObject3);
      return str1.compareTo(str2);
    } 
    Object[] arrayOfObject = { paramObject2, paramObject3 };
    double d = 
      ScriptRuntime.toNumber(ScriptRuntime.call(paramContext, paramObject1, null, arrayOfObject, paramScriptable));
    return (d == d) ? d : 0.0D;
  }
  
  private static void qsort(Context paramContext, Object paramObject, Object[] paramArrayOfObject, int paramInt1, int paramInt2, Scriptable paramScriptable) throws JavaScriptException {
    while (paramInt1 < paramInt2) {
      int i = paramInt1;
      int j = paramInt2;
      int k = i;
      Object object = paramArrayOfObject[k];
      while (i < j) {
        int m;
        while (true) {
          m = j;
          if (qsortCompare(paramContext, paramObject, paramArrayOfObject[j], object, 
              paramScriptable) > 0.0D) {
            j--;
            continue;
          } 
          break;
        } 
        paramArrayOfObject[k] = paramArrayOfObject[m];
        while (i < j && qsortCompare(paramContext, paramObject, paramArrayOfObject[k], 
            object, paramScriptable) <= 0.0D)
          k = ++i; 
        paramArrayOfObject[m] = paramArrayOfObject[k];
      } 
      paramArrayOfObject[k] = object;
      if (i - paramInt1 < paramInt2 - i) {
        qsort(paramContext, paramObject, paramArrayOfObject, paramInt1, i - 1, paramScriptable);
        paramInt1 = i + 1;
        continue;
      } 
      qsort(paramContext, paramObject, paramArrayOfObject, i + 1, paramInt2, paramScriptable);
      paramInt2 = i - 1;
    } 
  }
  
  private static void qsort_extended(Context paramContext, Object paramObject, Scriptable paramScriptable, long paramLong1, long paramLong2) throws JavaScriptException {
    while (paramLong1 < paramLong2) {
      long l1 = paramLong1;
      long l2 = paramLong2;
      long l3 = l1;
      Object object = getElem(paramScriptable, l3);
      while (l1 < l2) {
        long l;
        while (true) {
          l = l2;
          if (qsortCompare(paramContext, paramObject, getElem(paramScriptable, l2), 
              object, paramScriptable) > 0.0D) {
            l2--;
            continue;
          } 
          break;
        } 
        setElem(paramScriptable, l3, getElem(paramScriptable, l));
        while (l1 < l2 && qsortCompare(paramContext, paramObject, 
            getElem(paramScriptable, l3), 
            object, paramScriptable) <= 0.0D)
          l3 = ++l1; 
        setElem(paramScriptable, l, getElem(paramScriptable, l3));
      } 
      setElem(paramScriptable, l3, object);
      if (l1 - paramLong1 < paramLong2 - l1) {
        qsort_extended(paramContext, paramObject, paramScriptable, paramLong1, l1 - 1L);
        paramLong1 = l1 + 1L;
        continue;
      } 
      qsort_extended(paramContext, paramObject, paramScriptable, l1 + 1L, paramLong2);
      paramLong2 = l1 - 1L;
    } 
  }
  
  public static Object jsFunction_push(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    double d = getLengthProperty(paramScriptable);
    for (byte b = 0; b < paramArrayOfObject.length; b++)
      setElem(paramScriptable, (long)d + b, paramArrayOfObject[b]); 
    d += paramArrayOfObject.length;
    ScriptRuntime.setProp(paramScriptable, "length", new Double(d), paramScriptable);
    if (paramContext.getLanguageVersion() == 120)
      return (paramArrayOfObject.length == 0) ? 
        Context.getUndefinedValue() : 
        paramArrayOfObject[paramArrayOfObject.length - 1]; 
    return new Long((long)d);
  }
  
  public static Object jsFunction_pop(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    Object object;
    double d = getLengthProperty(paramScriptable);
    if (d > 0.0D) {
      d--;
      object = getElem(paramScriptable, (long)d);
    } else {
      object = Context.getUndefinedValue();
    } 
    ScriptRuntime.setProp(paramScriptable, "length", new Double(d), paramScriptable);
    return object;
  }
  
  public static Object jsFunction_shift(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    Object object;
    double d = getLengthProperty(paramScriptable);
    if (d > 0.0D) {
      long l = 0L;
      d--;
      object = getElem(paramScriptable, l);
      if (d > 0.0D)
        for (l = 1L; l <= d; l++) {
          Object object1 = getElem(paramScriptable, l);
          setElem(paramScriptable, l - 1L, object1);
        }  
    } else {
      object = Context.getUndefinedValue();
    } 
    ScriptRuntime.setProp(paramScriptable, "length", new Double(d), paramScriptable);
    return object;
  }
  
  public static Object jsFunction_unshift(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    double d = getLengthProperty(paramScriptable);
    int i = paramArrayOfObject.length;
    if (paramArrayOfObject.length > 0) {
      if (d > 0.0D)
        for (long l = (long)d - 1L; l >= 0L; l--) {
          Object object = getElem(paramScriptable, l);
          setElem(paramScriptable, l + i, object);
        }  
      for (byte b = 0; b < paramArrayOfObject.length; b++)
        setElem(paramScriptable, b, paramArrayOfObject[b]); 
      d += paramArrayOfObject.length;
      ScriptRuntime.setProp(paramScriptable, "length", 
          new Double(d), paramScriptable);
    } 
    return new Long((long)d);
  }
  
  public static Object jsFunction_splice(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    double d5, d3;
    Scriptable scriptable = ScriptableObject.getTopLevelScope(paramFunction);
    Object object = ScriptRuntime.newObject(paramContext, scriptable, "Array", null);
    int i = paramArrayOfObject.length;
    if (i == 0)
      return object; 
    double d1 = getLengthProperty(paramScriptable);
    double d2 = ScriptRuntime.toInteger(paramArrayOfObject[0]);
    if (d2 < 0.0D) {
      d2 += d1;
      if (d2 < 0.0D)
        d2 = 0.0D; 
    } else if (d2 > d1) {
      d2 = d1;
    } 
    i--;
    double d4 = d1 - d2;
    if (paramArrayOfObject.length == 1) {
      d5 = d4;
      d3 = d1;
    } else {
      d5 = ScriptRuntime.toInteger(paramArrayOfObject[1]);
      if (d5 < 0.0D) {
        d5 = 0.0D;
      } else if (d5 > d4) {
        d5 = d4;
      } 
      d3 = d2 + d5;
      i--;
    } 
    long l1 = (long)d2;
    long l2 = (long)d3;
    if (d5 > 0.0D) {
      Object object1;
      if (d5 == 1.0D && 
        paramContext.getLanguageVersion() == 120) {
        object1 = getElem(paramScriptable, l1);
      } else {
        for (long l = l1; l < l2; l++) {
          Scriptable scriptable1 = (Scriptable)object1;
          Object object2 = getElem(paramScriptable, l);
          setElem(scriptable1, l - l1, object2);
        } 
      } 
    } else if (d5 == 0.0D && 
      paramContext.getLanguageVersion() == 120) {
      object = Context.getUndefinedValue();
    } 
    d4 = i - d5;
    if (d4 > 0.0D) {
      for (long l = (long)d1 - 1L; l >= l2; l--) {
        Object object1 = getElem(paramScriptable, l);
        setElem(paramScriptable, l + (long)d4, object1);
      } 
    } else if (d4 < 0.0D) {
      for (long l = l2; l < d1; l++) {
        Object object1 = getElem(paramScriptable, l);
        setElem(paramScriptable, l + (long)d4, object1);
      } 
    } 
    int j = paramArrayOfObject.length - i;
    for (int k = 0; k < i; k++)
      setElem(paramScriptable, l1 + k, paramArrayOfObject[k + j]); 
    ScriptRuntime.setProp(paramScriptable, "length", 
        new Double(d1 + d4), paramScriptable);
    return object;
  }
  
  public static Scriptable jsFunction_concat(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    Scriptable scriptable1 = ScriptableObject.getTopLevelScope(paramFunction);
    Scriptable scriptable2 = ScriptRuntime.newObject(paramContext, scriptable1, "Array", null);
    long l = 0L;
    if (hasLengthProperty(paramScriptable)) {
      double d = getLengthProperty(paramScriptable);
      for (l = 0L; l < d; l++) {
        Object object = getElem(paramScriptable, l);
        setElem(scriptable2, l, object);
      } 
    } else {
      setElem(scriptable2, l++, paramScriptable);
    } 
    for (byte b = 0; b < paramArrayOfObject.length; b++) {
      if (hasLengthProperty(paramArrayOfObject[b])) {
        Scriptable scriptable = (Scriptable)paramArrayOfObject[b];
        double d = getLengthProperty(scriptable);
        for (long l1 = 0L; l1 < d; l1++, l++) {
          Object object = getElem(scriptable, l1);
          setElem(scriptable2, l, object);
        } 
      } else {
        setElem(scriptable2, l++, paramArrayOfObject[b]);
      } 
    } 
    return scriptable2;
  }
  
  public static Scriptable jsFunction_slice(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) {
    Scriptable scriptable1 = ScriptableObject.getTopLevelScope(paramFunction);
    Scriptable scriptable2 = ScriptRuntime.newObject(paramContext, scriptable1, "Array", null);
    double d1 = getLengthProperty(paramScriptable);
    double d2 = 0.0D;
    double d3 = d1;
    if (paramArrayOfObject.length > 0) {
      d2 = ScriptRuntime.toInteger(paramArrayOfObject[0]);
      if (d2 < 0.0D) {
        d2 += d1;
        if (d2 < 0.0D)
          d2 = 0.0D; 
      } else if (d2 > d1) {
        d2 = d1;
      } 
      if (paramArrayOfObject.length > 1) {
        d3 = ScriptRuntime.toInteger(paramArrayOfObject[1]);
        if (d3 < 0.0D) {
          d3 += d1;
          if (d3 < 0.0D)
            d3 = 0.0D; 
        } else if (d3 > d1) {
          d3 = d1;
        } 
      } 
    } 
    long l1 = (long)d2;
    long l2 = (long)d3;
    for (long l3 = l1; l3 < l2; l3++) {
      Object object = getElem(paramScriptable, l3);
      setElem(scriptable2, l3 - l1, object);
    } 
    return scriptable2;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeArray.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */