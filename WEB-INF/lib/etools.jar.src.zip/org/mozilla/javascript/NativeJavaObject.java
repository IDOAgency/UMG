/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeJavaObject
/*     */   implements Scriptable, Wrapper
/*     */ {
/*     */   static final int JSTYPE_UNDEFINED = 0;
/*     */   static final int JSTYPE_NULL = 1;
/*     */   static final int JSTYPE_BOOLEAN = 2;
/*     */   static final int JSTYPE_NUMBER = 3;
/*     */   static final int JSTYPE_STRING = 4;
/*     */   static final int JSTYPE_JAVA_CLASS = 5;
/*     */   static final int JSTYPE_JAVA_OBJECT = 6;
/*     */   static final int JSTYPE_JAVA_ARRAY = 7;
/*     */   static final int JSTYPE_OBJECT = 8;
/*     */   public static final byte CONVERSION_TRIVIAL = 1;
/*     */   public static final byte CONVERSION_NONTRIVIAL = 0;
/*     */   public static final byte CONVERSION_NONE = 99;
/*     */   protected Scriptable prototype;
/*     */   protected Scriptable parent;
/*     */   protected Object javaObject;
/*     */   protected JavaMembers members;
/*     */   private Hashtable fieldAndMethods;
/*     */   static Class jsObjectClass;
/*     */   static Constructor jsObjectCtor;
/*     */   static Method jsObjectGetScriptable;
/*     */   
/*     */   public NativeJavaObject(Scriptable paramScriptable, Object paramObject, JavaMembers paramJavaMembers) {
/*  60 */     this.parent = paramScriptable;
/*  61 */     this.javaObject = paramObject;
/*  62 */     this.members = paramJavaMembers;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeJavaObject(Scriptable paramScriptable, Object paramObject, Class paramClass) {
/*  68 */     this.parent = paramScriptable;
/*  69 */     this.javaObject = paramObject;
/*  70 */     Class clazz = (paramObject != null) ? paramObject.getClass() : 
/*  71 */       paramClass;
/*  72 */     this.members = JavaMembers.lookupClass(paramScriptable, clazz, paramClass);
/*  73 */     this.fieldAndMethods = this.members.getFieldAndMethodsObjects(this, paramObject, false);
/*     */   }
/*     */ 
/*     */   
/*  77 */   public boolean has(String paramString, Scriptable paramScriptable) { return this.members.has(paramString, false); }
/*     */ 
/*     */ 
/*     */   
/*  81 */   public boolean has(int paramInt, Scriptable paramScriptable) { return false; }
/*     */ 
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/*  85 */     if (this.fieldAndMethods != null) {
/*  86 */       Object object = this.fieldAndMethods.get(paramString);
/*  87 */       if (object != null) {
/*  88 */         return object;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  93 */     return this.members.get(this, paramString, this.javaObject, false);
/*     */   }
/*     */ 
/*     */   
/*  97 */   public Object get(int paramInt, Scriptable paramScriptable) { throw this.members.reportMemberNotFound(Integer.toString(paramInt)); }
/*     */ 
/*     */ 
/*     */   
/* 101 */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) { this.members.put(paramString, this.javaObject, paramObject, false); }
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) { throw this.members.reportMemberNotFound(Integer.toString(paramInt)); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public boolean hasInstance(Scriptable paramScriptable) { return false; }
/*     */ 
/*     */   
/*     */   public void delete(String paramString) {}
/*     */ 
/*     */   
/*     */   public void delete(int paramInt) {}
/*     */ 
/*     */   
/*     */   public Scriptable getPrototype() {
/* 120 */     if (this.prototype == null && this.javaObject.getClass() == ScriptRuntime.StringClass) {
/* 121 */       return ScriptableObject.getClassPrototype(this.parent, "String");
/*     */     }
/* 123 */     return this.prototype;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public void setPrototype(Scriptable paramScriptable) { this.prototype = paramScriptable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public Scriptable getParentScope() { return this.parent; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public void setParentScope(Scriptable paramScriptable) { this.parent = paramScriptable; }
/*     */ 
/*     */ 
/*     */   
/* 148 */   public Object[] getIds() { return this.members.getIds(false); }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object wrap(Scriptable paramScriptable, Object paramObject, Class paramClass) {
/* 153 */     if (paramObject == null)
/* 154 */       return paramObject; 
/* 155 */     Class clazz = paramObject.getClass();
/* 156 */     if (paramClass != null && paramClass.isPrimitive()) {
/* 157 */       if (paramClass == void.class)
/* 158 */         return Undefined.instance; 
/* 159 */       if (paramClass == char.class)
/* 160 */         return new Integer(((Character)paramObject).charValue()); 
/* 161 */       return paramObject;
/*     */     } 
/* 163 */     if (clazz.isArray())
/* 164 */       return NativeJavaArray.wrap(paramScriptable, paramObject); 
/* 165 */     if (paramObject instanceof Scriptable) {
/* 166 */       return paramObject;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 180 */     return new NativeJavaObject(paramScriptable, paramObject, paramClass);
/*     */   }
/*     */ 
/*     */   
/* 184 */   public Object unwrap() { return this.javaObject; }
/*     */ 
/*     */ 
/*     */   
/* 188 */   public String getClassName() { return "JavaObject"; }
/*     */ 
/*     */   
/*     */   Function getConverter(String paramString) {
/* 192 */     Object object = get(paramString, this);
/* 193 */     if (object instanceof Function) {
/* 194 */       return (Function)object;
/*     */     }
/* 196 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Object callConverter(Function paramFunction) throws JavaScriptException {
/* 202 */     Function function = paramFunction;
/* 203 */     return function.call(Context.getContext(), function.getParentScope(), 
/* 204 */         this, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Object callConverter(String paramString) throws JavaScriptException {
/* 210 */     Function function = getConverter(paramString);
/* 211 */     if (function == null) {
/* 212 */       Object[] arrayOfObject = { paramString, this.javaObject.getClass().getName() };
/* 213 */       throw Context.reportRuntimeError(
/* 214 */           Context.getMessage("msg.java.conversion.implicit_method", 
/* 215 */             arrayOfObject));
/*     */     } 
/* 217 */     return callConverter(function);
/*     */   }
/*     */   
/*     */   public Object getDefaultValue(Class paramClass) {
/* 221 */     if (paramClass == null || paramClass == ScriptRuntime.StringClass)
/* 222 */       return this.javaObject.toString(); 
/*     */     try {
/* 224 */       if (paramClass == ScriptRuntime.BooleanClass)
/* 225 */         return callConverter("booleanValue"); 
/* 226 */       if (paramClass == ScriptRuntime.NumberClass) {
/* 227 */         return callConverter("doubleValue");
/*     */       }
/*     */     }
/* 230 */     catch (JavaScriptException javaScriptException) {}
/*     */ 
/*     */     
/* 233 */     throw Context.reportRuntimeError(
/* 234 */         Context.getMessage("msg.default.value", null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canConvert(Object paramObject, Class paramClass) {
/* 244 */     int i = getConversionWeight(paramObject, paramClass);
/*     */     
/* 246 */     return !(i >= 99);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getConversionWeight(Object paramObject, Class paramClass) {
/*     */     Object object;
/* 273 */     int i = getJSTypeCode(paramObject);
/*     */     
/* 275 */     int j = 99;
/*     */     
/* 277 */     switch (i) {
/*     */       
/*     */       case 0:
/* 280 */         if (paramClass == ScriptRuntime.StringClass || 
/* 281 */           paramClass == ScriptRuntime.ObjectClass) {
/* 282 */           j = 1;
/*     */         }
/*     */         break;
/*     */       
/*     */       case 1:
/* 287 */         if (!paramClass.isPrimitive()) {
/* 288 */           j = 1;
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case 2:
/* 294 */         if (paramClass == boolean.class) {
/* 295 */           j = 1; break;
/*     */         } 
/* 297 */         if (paramClass == ScriptRuntime.BooleanClass) {
/* 298 */           j = 2; break;
/*     */         } 
/* 300 */         if (paramClass == ScriptRuntime.ObjectClass) {
/* 301 */           j = 3; break;
/*     */         } 
/* 303 */         if (paramClass == ScriptRuntime.StringClass) {
/* 304 */           j = 4;
/*     */         }
/*     */         break;
/*     */       
/*     */       case 3:
/* 309 */         if (paramClass.isPrimitive()) {
/* 310 */           if (paramClass == double.class) {
/* 311 */             j = 1; break;
/*     */           } 
/* 313 */           if (paramClass != boolean.class) {
/* 314 */             j = 1 + getSizeRank(paramClass);
/*     */           }
/*     */           break;
/*     */         } 
/* 318 */         if (paramClass == ScriptRuntime.StringClass) {
/*     */           
/* 320 */           j = 9; break;
/*     */         } 
/* 322 */         if (paramClass == ScriptRuntime.ObjectClass) {
/* 323 */           j = 10; break;
/*     */         } 
/* 325 */         if (ScriptRuntime.NumberClass.isAssignableFrom(paramClass))
/*     */         {
/* 327 */           j = 2;
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case 4:
/* 333 */         if (paramClass == ScriptRuntime.StringClass) {
/* 334 */           j = 1; break;
/*     */         } 
/* 336 */         if (paramClass == ScriptRuntime.ObjectClass) {
/* 337 */           j = 2; break;
/*     */         } 
/* 339 */         if (paramClass.isPrimitive() && paramClass != boolean.class) {
/* 340 */           if (paramClass == char.class) {
/* 341 */             j = 3;
/*     */             break;
/*     */           } 
/* 344 */           j = 4;
/*     */         } 
/*     */         break;
/*     */ 
/*     */       
/*     */       case 5:
/* 350 */         if (paramClass == ScriptRuntime.ClassClass) {
/* 351 */           j = 1;
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 357 */         if (paramClass == ScriptRuntime.ObjectClass) {
/* 358 */           j = 3; break;
/*     */         } 
/* 360 */         if (paramClass == ScriptRuntime.StringClass) {
/* 361 */           j = 4;
/*     */         }
/*     */         break;
/*     */       
/*     */       case 6:
/*     */       case 7:
/* 367 */         if (paramClass == ScriptRuntime.StringClass) {
/* 368 */           j = 2; break;
/*     */         } 
/* 370 */         if (paramClass.isPrimitive() && paramClass != boolean.class) {
/* 371 */           j = 
/* 372 */             (i == 7) ? 
/* 373 */             0 : (
/* 374 */             2 + getSizeRank(paramClass));
/*     */           break;
/*     */         } 
/* 377 */         object = paramObject;
/* 378 */         if (object instanceof NativeJavaObject) {
/* 379 */           object = ((NativeJavaObject)object).unwrap();
/*     */         }
/* 381 */         if (paramClass.isInstance(object)) {
/* 382 */           j = 0;
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 8:
/* 393 */         if (paramObject instanceof NativeArray && paramClass.isArray()) {
/*     */ 
/*     */ 
/*     */           
/* 397 */           j = 1; break;
/*     */         } 
/* 399 */         if (paramClass == ScriptRuntime.ObjectClass) {
/* 400 */           j = 2; break;
/*     */         } 
/* 402 */         if (paramClass == ScriptRuntime.StringClass) {
/* 403 */           j = 3; break;
/*     */         } 
/* 405 */         if (paramClass.isPrimitive() || paramClass != boolean.class) {
/* 406 */           j = 3 + getSizeRank(paramClass);
/*     */         }
/*     */         break;
/*     */     } 
/*     */     
/* 411 */     return j;
/*     */   }
/*     */ 
/*     */   
/*     */   static int getSizeRank(Class paramClass) {
/* 416 */     if (paramClass == double.class) {
/* 417 */       return 1;
/*     */     }
/* 419 */     if (paramClass == float.class) {
/* 420 */       return 2;
/*     */     }
/* 422 */     if (paramClass == long.class) {
/* 423 */       return 3;
/*     */     }
/* 425 */     if (paramClass == int.class) {
/* 426 */       return 4;
/*     */     }
/* 428 */     if (paramClass == short.class) {
/* 429 */       return 5;
/*     */     }
/* 431 */     if (paramClass == char.class) {
/* 432 */       return 6;
/*     */     }
/* 434 */     if (paramClass == byte.class) {
/* 435 */       return 7;
/*     */     }
/* 437 */     if (paramClass == boolean.class) {
/* 438 */       return 99;
/*     */     }
/*     */     
/* 441 */     return 8;
/*     */   }
/*     */ 
/*     */   
/*     */   static int getJSTypeCode(Object paramObject) {
/* 446 */     if (paramObject == null) {
/* 447 */       return 1;
/*     */     }
/* 449 */     if (paramObject == Undefined.instance) {
/* 450 */       return 0;
/*     */     }
/* 452 */     if (paramObject instanceof Scriptable) {
/* 453 */       if (paramObject instanceof NativeJavaClass) {
/* 454 */         return 5;
/*     */       }
/* 456 */       if (paramObject instanceof NativeJavaArray) {
/* 457 */         return 7;
/*     */       }
/* 459 */       if (paramObject instanceof NativeJavaObject) {
/* 460 */         return 6;
/*     */       }
/*     */       
/* 463 */       return 8;
/*     */     } 
/*     */ 
/*     */     
/* 467 */     Class clazz = paramObject.getClass();
/*     */     
/* 469 */     if (clazz == ScriptRuntime.StringClass) {
/* 470 */       return 4;
/*     */     }
/* 472 */     if (clazz == ScriptRuntime.BooleanClass) {
/* 473 */       return 2;
/*     */     }
/* 475 */     if (paramObject instanceof Number) {
/* 476 */       return 3;
/*     */     }
/* 478 */     if (clazz == ScriptRuntime.ClassClass) {
/* 479 */       return 5;
/*     */     }
/* 481 */     if (clazz.isArray()) {
/* 482 */       return 7;
/*     */     }
/*     */     
/* 485 */     return 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object coerceType(Class paramClass, Object paramObject) {
/* 495 */     if (paramObject != null && paramObject.getClass() == paramClass) {
/* 496 */       return paramObject;
/*     */     }
/*     */     
/* 499 */     switch (getJSTypeCode(paramObject)) {
/*     */ 
/*     */       
/*     */       case 1:
/* 503 */         if (paramClass.isPrimitive()) {
/* 504 */           reportConversionError(paramObject, paramClass);
/*     */         }
/* 506 */         return null;
/*     */       
/*     */       case 0:
/* 509 */         if (paramClass == ScriptRuntime.StringClass || 
/* 510 */           paramClass == ScriptRuntime.ObjectClass) {
/* 511 */           return "undefined";
/*     */         }
/*     */         
/* 514 */         reportConversionError("undefined", paramClass);
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/* 520 */         if (paramClass == boolean.class || 
/* 521 */           paramClass == ScriptRuntime.BooleanClass || 
/* 522 */           paramClass == ScriptRuntime.ObjectClass) {
/* 523 */           return paramObject;
/*     */         }
/* 525 */         if (paramClass == ScriptRuntime.StringClass) {
/* 526 */           return paramObject.toString();
/*     */         }
/*     */         
/* 529 */         reportConversionError(paramObject, paramClass);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 3:
/* 534 */         if (paramClass == ScriptRuntime.StringClass) {
/* 535 */           return ScriptRuntime.toString(paramObject);
/*     */         }
/* 537 */         if (paramClass == ScriptRuntime.ObjectClass) {
/* 538 */           return coerceToNumber(double.class, paramObject);
/*     */         }
/* 540 */         if ((paramClass.isPrimitive() && paramClass != boolean.class) || 
/* 541 */           ScriptRuntime.NumberClass.isAssignableFrom(paramClass)) {
/* 542 */           return coerceToNumber(paramClass, paramObject);
/*     */         }
/*     */         
/* 545 */         reportConversionError(paramObject, paramClass);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 4:
/* 550 */         if (paramClass == ScriptRuntime.StringClass || 
/* 551 */           paramClass == ScriptRuntime.ObjectClass) {
/* 552 */           return paramObject;
/*     */         }
/* 554 */         if (paramClass == char.class || 
/* 555 */           paramClass == ScriptRuntime.CharacterClass) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 560 */           if (((String)paramObject).length() == 1) {
/* 561 */             return new Character(((String)paramObject).charAt(0));
/*     */           }
/*     */           
/* 564 */           return coerceToNumber(paramClass, paramObject);
/*     */         } 
/*     */         
/* 567 */         if ((paramClass.isPrimitive() && paramClass != boolean.class) || 
/* 568 */           ScriptRuntime.NumberClass.isAssignableFrom(paramClass)) {
/* 569 */           return coerceToNumber(paramClass, paramObject);
/*     */         }
/*     */         
/* 572 */         reportConversionError(paramObject, paramClass);
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 583 */         if (paramObject instanceof Wrapper) {
/* 584 */           paramObject = ((Wrapper)paramObject).unwrap();
/*     */         }
/*     */         
/* 587 */         if (paramClass == ScriptRuntime.ClassClass || 
/* 588 */           paramClass == ScriptRuntime.ObjectClass) {
/* 589 */           return paramObject;
/*     */         }
/* 591 */         if (paramClass == ScriptRuntime.StringClass) {
/* 592 */           return paramObject.toString();
/*     */         }
/*     */         
/* 595 */         reportConversionError(paramObject, paramClass);
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 6:
/*     */       case 7:
/* 602 */         if (paramClass.isPrimitive()) {
/* 603 */           if (paramClass == boolean.class) {
/* 604 */             reportConversionError(paramObject, paramClass);
/*     */           }
/* 606 */           return coerceToNumber(paramClass, paramObject);
/*     */         } 
/*     */         
/* 609 */         if (paramObject instanceof Wrapper) {
/* 610 */           paramObject = ((Wrapper)paramObject).unwrap();
/*     */         }
/* 612 */         if (paramClass == ScriptRuntime.StringClass) {
/* 613 */           return paramObject.toString();
/*     */         }
/*     */         
/* 616 */         if (paramClass.isInstance(paramObject)) {
/* 617 */           return paramObject;
/*     */         }
/*     */         
/* 620 */         reportConversionError(paramObject, paramClass);
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 8:
/* 632 */         if (paramClass == ScriptRuntime.StringClass) {
/* 633 */           return ScriptRuntime.toString(paramObject);
/*     */         }
/* 635 */         if (paramClass.isPrimitive()) {
/* 636 */           if (paramClass == boolean.class) {
/* 637 */             reportConversionError(paramObject, paramClass);
/*     */           }
/* 639 */           return coerceToNumber(paramClass, paramObject);
/*     */         } 
/* 641 */         if (paramClass.isInstance(paramObject)) {
/* 642 */           return paramObject;
/*     */         }
/* 644 */         if (paramClass.isArray() && paramObject instanceof NativeArray) {
/*     */ 
/*     */           
/* 647 */           NativeArray nativeArray = (NativeArray)paramObject;
/* 648 */           long l = nativeArray.jsGet_length();
/* 649 */           Class clazz = paramClass.getComponentType();
/* 650 */           Object object = Array.newInstance(clazz, (int)l);
/* 651 */           for (byte b = 0; b < l; b++) {
/*     */             try {
/* 653 */               Array.set(object, b, coerceType(clazz, 
/* 654 */                     nativeArray.get(b, nativeArray)));
/*     */             }
/* 656 */             catch (EvaluatorException evaluatorException) {
/* 657 */               reportConversionError(paramObject, paramClass);
/*     */             } 
/*     */           } 
/*     */           
/* 661 */           return object;
/*     */         } 
/*     */         
/* 664 */         reportConversionError(paramObject, paramClass);
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 669 */     return paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object coerceToJSObject(Class paramClass, Scriptable paramScriptable) {
/* 676 */     if (ScriptRuntime.ScriptableClass.isAssignableFrom(paramClass)) {
/* 677 */       return paramScriptable;
/*     */     }
/*     */     try {
/* 680 */       Object[] arrayOfObject = { paramScriptable };
/* 681 */       return jsObjectCtor.newInstance(arrayOfObject);
/* 682 */     } catch (InstantiationException instantiationException) {
/* 683 */       throw new EvaluatorException("error generating JSObject wrapper for " + 
/* 684 */           paramScriptable);
/* 685 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 686 */       throw new EvaluatorException("JSObject constructor doesn't want [Scriptable]!");
/* 687 */     } catch (InvocationTargetException invocationTargetException) {
/* 688 */       throw WrappedException.wrapException(invocationTargetException.getTargetException());
/* 689 */     } catch (IllegalAccessException illegalAccessException) {
/* 690 */       throw new EvaluatorException("JSObject constructor is protected/private!");
/*     */     } 
/*     */   }
/*     */   
/*     */   static Object coerceToNumber(Class paramClass, Object paramObject) {
/* 695 */     Class clazz = paramObject.getClass();
/*     */ 
/*     */     
/* 698 */     if (paramClass == char.class || paramClass == ScriptRuntime.CharacterClass) {
/* 699 */       if (clazz == ScriptRuntime.CharacterClass) {
/* 700 */         return paramObject;
/*     */       }
/* 702 */       return new Character((char)(int)toInteger(paramObject, 
/* 703 */             ScriptRuntime.CharacterClass, 
/* 704 */             0.0D, 
/* 705 */             65535.0D));
/*     */     } 
/*     */ 
/*     */     
/* 709 */     if (paramClass == ScriptRuntime.ObjectClass || 
/* 710 */       paramClass == ScriptRuntime.DoubleClass || paramClass == double.class) {
/* 711 */       return (clazz == ScriptRuntime.DoubleClass) ? 
/* 712 */         paramObject : 
/* 713 */         new Double(toDouble(paramObject));
/*     */     }
/*     */     
/* 716 */     if (paramClass == ScriptRuntime.FloatClass || paramClass == float.class) {
/* 717 */       if (clazz == ScriptRuntime.FloatClass) {
/* 718 */         return paramObject;
/*     */       }
/*     */       
/* 721 */       double d1 = toDouble(paramObject);
/* 722 */       if (Double.isInfinite(d1) || Double.isNaN(d1) || 
/* 723 */         d1 == 0.0D) {
/* 724 */         return new Float((float)d1);
/*     */       }
/*     */       
/* 727 */       double d2 = Math.abs(d1);
/* 728 */       if (d2 < 1.401298464324817E-45D) {
/* 729 */         return new Float((d1 > 0.0D) ? 0.0D : -0.0D);
/*     */       }
/* 731 */       if (d2 > 3.4028234663852886E38D) {
/* 732 */         return new Float((d1 > 0.0D) ? 
/* 733 */             Float.POSITIVE_INFINITY : 
/* 734 */             Float.NEGATIVE_INFINITY);
/*     */       }
/*     */       
/* 737 */       return new Float((float)d1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 744 */     if (paramClass == ScriptRuntime.IntegerClass || paramClass == int.class) {
/* 745 */       if (clazz == ScriptRuntime.IntegerClass) {
/* 746 */         return paramObject;
/*     */       }
/*     */       
/* 749 */       return new Integer((int)toInteger(paramObject, 
/* 750 */             ScriptRuntime.IntegerClass, 
/* 751 */             -2.147483648E9D, 
/* 752 */             2.147483647E9D));
/*     */     } 
/*     */ 
/*     */     
/* 756 */     if (paramClass == ScriptRuntime.LongClass || paramClass == long.class) {
/* 757 */       if (clazz == ScriptRuntime.LongClass) {
/* 758 */         return paramObject;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 768 */       double d1 = Double.longBitsToDouble(4890909195324358655L);
/* 769 */       double d2 = Double.longBitsToDouble(-4332462841530417152L);
/* 770 */       return new Long(toInteger(paramObject, 
/* 771 */             ScriptRuntime.LongClass, 
/* 772 */             d2, 
/* 773 */             d1));
/*     */     } 
/*     */ 
/*     */     
/* 777 */     if (paramClass == ScriptRuntime.ShortClass || paramClass == short.class) {
/* 778 */       if (clazz == ScriptRuntime.ShortClass) {
/* 779 */         return paramObject;
/*     */       }
/*     */       
/* 782 */       return new Short((short)(int)toInteger(paramObject, 
/* 783 */             ScriptRuntime.ShortClass, 
/* 784 */             -32768.0D, 
/* 785 */             32767.0D));
/*     */     } 
/*     */ 
/*     */     
/* 789 */     if (paramClass == ScriptRuntime.ByteClass || paramClass == byte.class) {
/* 790 */       if (clazz == ScriptRuntime.ByteClass) {
/* 791 */         return paramObject;
/*     */       }
/*     */       
/* 794 */       return new Byte((byte)(int)toInteger(paramObject, 
/* 795 */             ScriptRuntime.ByteClass, 
/* 796 */             -128.0D, 
/* 797 */             127.0D));
/*     */     } 
/*     */ 
/*     */     
/* 801 */     return new Double(toDouble(paramObject));
/*     */   }
/*     */   
/*     */   static double toDouble(Object paramObject) {
/*     */     Object object;
/* 806 */     if (paramObject instanceof Number) {
/* 807 */       return ((Number)paramObject).doubleValue();
/*     */     }
/* 809 */     if (paramObject instanceof String) {
/* 810 */       return ScriptRuntime.toNumber((String)paramObject);
/*     */     }
/* 812 */     if (paramObject instanceof Scriptable) {
/* 813 */       if (paramObject instanceof Wrapper)
/*     */       {
/* 815 */         return toDouble(((Wrapper)paramObject).unwrap());
/*     */       }
/*     */       
/* 818 */       return ScriptRuntime.toNumber(paramObject);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 824 */       object = paramObject.getClass().getMethod("doubleValue", null);
/*     */     }
/* 826 */     catch (NoSuchMethodException noSuchMethodException) {
/* 827 */       object = null;
/*     */     }
/* 829 */     catch (SecurityException securityException) {
/* 830 */       object = null;
/*     */     } 
/* 832 */     if (object != null) {
/*     */       try {
/* 834 */         return ((Number)object.invoke(paramObject, null)).doubleValue();
/*     */       }
/* 836 */       catch (IllegalAccessException illegalAccessException) {
/*     */         
/* 838 */         reportConversionError(paramObject, double.class);
/*     */       }
/* 840 */       catch (InvocationTargetException invocationTargetException) {
/*     */         
/* 842 */         reportConversionError(paramObject, double.class);
/*     */       } 
/*     */     }
/* 845 */     return ScriptRuntime.toNumber(paramObject.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   static long toInteger(Object paramObject, Class paramClass, double paramDouble1, double paramDouble2) {
/* 850 */     double d = toDouble(paramObject);
/*     */     
/* 852 */     if (Double.isInfinite(d) || Double.isNaN(d))
/*     */     {
/* 854 */       reportConversionError(ScriptRuntime.toString(paramObject), paramClass);
/*     */     }
/*     */     
/* 857 */     if (d > 0.0D) {
/* 858 */       d = Math.floor(d);
/*     */     } else {
/*     */       
/* 861 */       d = Math.ceil(d);
/*     */     } 
/*     */     
/* 864 */     if (d < paramDouble1 || d > paramDouble2)
/*     */     {
/* 866 */       reportConversionError(ScriptRuntime.toString(paramObject), paramClass);
/*     */     }
/* 868 */     return (long)d;
/*     */   }
/*     */   
/*     */   static void reportConversionError(Object paramObject, Class paramClass) {
/* 872 */     Object[] arrayOfObject = { paramObject.toString(), 
/* 873 */         NativeJavaMethod.javaSignature(paramClass) };
/*     */     
/* 875 */     throw Context.reportRuntimeError(
/* 876 */         Context.getMessage("msg.conversion.not.allowed", arrayOfObject));
/*     */   }
/*     */   
/*     */   public static void initJSObject() {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeJavaObject.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */