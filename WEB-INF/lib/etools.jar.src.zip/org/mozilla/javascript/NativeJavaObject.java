package org.mozilla.javascript;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Hashtable;

public class NativeJavaObject implements Scriptable, Wrapper {
  static final int JSTYPE_UNDEFINED = 0;
  
  static final int JSTYPE_NULL = 1;
  
  static final int JSTYPE_BOOLEAN = 2;
  
  static final int JSTYPE_NUMBER = 3;
  
  static final int JSTYPE_STRING = 4;
  
  static final int JSTYPE_JAVA_CLASS = 5;
  
  static final int JSTYPE_JAVA_OBJECT = 6;
  
  static final int JSTYPE_JAVA_ARRAY = 7;
  
  static final int JSTYPE_OBJECT = 8;
  
  public static final byte CONVERSION_TRIVIAL = 1;
  
  public static final byte CONVERSION_NONTRIVIAL = 0;
  
  public static final byte CONVERSION_NONE = 99;
  
  protected Scriptable prototype;
  
  protected Scriptable parent;
  
  protected Object javaObject;
  
  protected JavaMembers members;
  
  private Hashtable fieldAndMethods;
  
  static Class jsObjectClass;
  
  static Constructor jsObjectCtor;
  
  static Method jsObjectGetScriptable;
  
  public NativeJavaObject(Scriptable paramScriptable, Object paramObject, JavaMembers paramJavaMembers) {
    this.parent = paramScriptable;
    this.javaObject = paramObject;
    this.members = paramJavaMembers;
  }
  
  public NativeJavaObject(Scriptable paramScriptable, Object paramObject, Class paramClass) {
    this.parent = paramScriptable;
    this.javaObject = paramObject;
    Class clazz = (paramObject != null) ? paramObject.getClass() : 
      paramClass;
    this.members = JavaMembers.lookupClass(paramScriptable, clazz, paramClass);
    this.fieldAndMethods = this.members.getFieldAndMethodsObjects(this, paramObject, false);
  }
  
  public boolean has(String paramString, Scriptable paramScriptable) { return this.members.has(paramString, false); }
  
  public boolean has(int paramInt, Scriptable paramScriptable) { return false; }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    if (this.fieldAndMethods != null) {
      Object object = this.fieldAndMethods.get(paramString);
      if (object != null)
        return object; 
    } 
    return this.members.get(this, paramString, this.javaObject, false);
  }
  
  public Object get(int paramInt, Scriptable paramScriptable) { throw this.members.reportMemberNotFound(Integer.toString(paramInt)); }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) { this.members.put(paramString, this.javaObject, paramObject, false); }
  
  public void put(int paramInt, Scriptable paramScriptable, Object paramObject) { throw this.members.reportMemberNotFound(Integer.toString(paramInt)); }
  
  public boolean hasInstance(Scriptable paramScriptable) { return false; }
  
  public void delete(String paramString) {}
  
  public void delete(int paramInt) {}
  
  public Scriptable getPrototype() {
    if (this.prototype == null && this.javaObject.getClass() == ScriptRuntime.StringClass)
      return ScriptableObject.getClassPrototype(this.parent, "String"); 
    return this.prototype;
  }
  
  public void setPrototype(Scriptable paramScriptable) { this.prototype = paramScriptable; }
  
  public Scriptable getParentScope() { return this.parent; }
  
  public void setParentScope(Scriptable paramScriptable) { this.parent = paramScriptable; }
  
  public Object[] getIds() { return this.members.getIds(false); }
  
  public static Object wrap(Scriptable paramScriptable, Object paramObject, Class paramClass) {
    if (paramObject == null)
      return paramObject; 
    Class clazz = paramObject.getClass();
    if (paramClass != null && paramClass.isPrimitive()) {
      if (paramClass == void.class)
        return Undefined.instance; 
      if (paramClass == char.class)
        return new Integer(((Character)paramObject).charValue()); 
      return paramObject;
    } 
    if (clazz.isArray())
      return NativeJavaArray.wrap(paramScriptable, paramObject); 
    if (paramObject instanceof Scriptable)
      return paramObject; 
    return new NativeJavaObject(paramScriptable, paramObject, paramClass);
  }
  
  public Object unwrap() { return this.javaObject; }
  
  public String getClassName() { return "JavaObject"; }
  
  Function getConverter(String paramString) {
    Object object = get(paramString, this);
    if (object instanceof Function)
      return (Function)object; 
    return null;
  }
  
  Object callConverter(Function paramFunction) throws JavaScriptException {
    Function function = paramFunction;
    return function.call(Context.getContext(), function.getParentScope(), 
        this, new Object[0]);
  }
  
  Object callConverter(String paramString) throws JavaScriptException {
    Function function = getConverter(paramString);
    if (function == null) {
      Object[] arrayOfObject = { paramString, this.javaObject.getClass().getName() };
      throw Context.reportRuntimeError(
          Context.getMessage("msg.java.conversion.implicit_method", 
            arrayOfObject));
    } 
    return callConverter(function);
  }
  
  public Object getDefaultValue(Class paramClass) {
    if (paramClass == null || paramClass == ScriptRuntime.StringClass)
      return this.javaObject.toString(); 
    try {
      if (paramClass == ScriptRuntime.BooleanClass)
        return callConverter("booleanValue"); 
      if (paramClass == ScriptRuntime.NumberClass)
        return callConverter("doubleValue"); 
    } catch (JavaScriptException javaScriptException) {}
    throw Context.reportRuntimeError(
        Context.getMessage("msg.default.value", null));
  }
  
  public static boolean canConvert(Object paramObject, Class paramClass) {
    int i = getConversionWeight(paramObject, paramClass);
    return !(i >= 99);
  }
  
  public static int getConversionWeight(Object paramObject, Class paramClass) {
    Object object;
    int i = getJSTypeCode(paramObject);
    int j = 99;
    switch (i) {
      case 0:
        if (paramClass == ScriptRuntime.StringClass || 
          paramClass == ScriptRuntime.ObjectClass)
          j = 1; 
        break;
      case 1:
        if (!paramClass.isPrimitive())
          j = 1; 
        break;
      case 2:
        if (paramClass == boolean.class) {
          j = 1;
          break;
        } 
        if (paramClass == ScriptRuntime.BooleanClass) {
          j = 2;
          break;
        } 
        if (paramClass == ScriptRuntime.ObjectClass) {
          j = 3;
          break;
        } 
        if (paramClass == ScriptRuntime.StringClass)
          j = 4; 
        break;
      case 3:
        if (paramClass.isPrimitive()) {
          if (paramClass == double.class) {
            j = 1;
            break;
          } 
          if (paramClass != boolean.class)
            j = 1 + getSizeRank(paramClass); 
          break;
        } 
        if (paramClass == ScriptRuntime.StringClass) {
          j = 9;
          break;
        } 
        if (paramClass == ScriptRuntime.ObjectClass) {
          j = 10;
          break;
        } 
        if (ScriptRuntime.NumberClass.isAssignableFrom(paramClass))
          j = 2; 
        break;
      case 4:
        if (paramClass == ScriptRuntime.StringClass) {
          j = 1;
          break;
        } 
        if (paramClass == ScriptRuntime.ObjectClass) {
          j = 2;
          break;
        } 
        if (paramClass.isPrimitive() && paramClass != boolean.class) {
          if (paramClass == char.class) {
            j = 3;
            break;
          } 
          j = 4;
        } 
        break;
      case 5:
        if (paramClass == ScriptRuntime.ClassClass) {
          j = 1;
          break;
        } 
        if (paramClass == ScriptRuntime.ObjectClass) {
          j = 3;
          break;
        } 
        if (paramClass == ScriptRuntime.StringClass)
          j = 4; 
        break;
      case 6:
      case 7:
        if (paramClass == ScriptRuntime.StringClass) {
          j = 2;
          break;
        } 
        if (paramClass.isPrimitive() && paramClass != boolean.class) {
          j = 
            (i == 7) ? 
            0 : (
            2 + getSizeRank(paramClass));
          break;
        } 
        object = paramObject;
        if (object instanceof NativeJavaObject)
          object = ((NativeJavaObject)object).unwrap(); 
        if (paramClass.isInstance(object))
          j = 0; 
        break;
      case 8:
        if (paramObject instanceof NativeArray && paramClass.isArray()) {
          j = 1;
          break;
        } 
        if (paramClass == ScriptRuntime.ObjectClass) {
          j = 2;
          break;
        } 
        if (paramClass == ScriptRuntime.StringClass) {
          j = 3;
          break;
        } 
        if (paramClass.isPrimitive() || paramClass != boolean.class)
          j = 3 + getSizeRank(paramClass); 
        break;
    } 
    return j;
  }
  
  static int getSizeRank(Class paramClass) {
    if (paramClass == double.class)
      return 1; 
    if (paramClass == float.class)
      return 2; 
    if (paramClass == long.class)
      return 3; 
    if (paramClass == int.class)
      return 4; 
    if (paramClass == short.class)
      return 5; 
    if (paramClass == char.class)
      return 6; 
    if (paramClass == byte.class)
      return 7; 
    if (paramClass == boolean.class)
      return 99; 
    return 8;
  }
  
  static int getJSTypeCode(Object paramObject) {
    if (paramObject == null)
      return 1; 
    if (paramObject == Undefined.instance)
      return 0; 
    if (paramObject instanceof Scriptable) {
      if (paramObject instanceof NativeJavaClass)
        return 5; 
      if (paramObject instanceof NativeJavaArray)
        return 7; 
      if (paramObject instanceof NativeJavaObject)
        return 6; 
      return 8;
    } 
    Class clazz = paramObject.getClass();
    if (clazz == ScriptRuntime.StringClass)
      return 4; 
    if (clazz == ScriptRuntime.BooleanClass)
      return 2; 
    if (paramObject instanceof Number)
      return 3; 
    if (clazz == ScriptRuntime.ClassClass)
      return 5; 
    if (clazz.isArray())
      return 7; 
    return 6;
  }
  
  public static Object coerceType(Class paramClass, Object paramObject) {
    if (paramObject != null && paramObject.getClass() == paramClass)
      return paramObject; 
    switch (getJSTypeCode(paramObject)) {
      case 1:
        if (paramClass.isPrimitive())
          reportConversionError(paramObject, paramClass); 
        return null;
      case 0:
        if (paramClass == ScriptRuntime.StringClass || 
          paramClass == ScriptRuntime.ObjectClass)
          return "undefined"; 
        reportConversionError("undefined", paramClass);
        break;
      case 2:
        if (paramClass == boolean.class || 
          paramClass == ScriptRuntime.BooleanClass || 
          paramClass == ScriptRuntime.ObjectClass)
          return paramObject; 
        if (paramClass == ScriptRuntime.StringClass)
          return paramObject.toString(); 
        reportConversionError(paramObject, paramClass);
        break;
      case 3:
        if (paramClass == ScriptRuntime.StringClass)
          return ScriptRuntime.toString(paramObject); 
        if (paramClass == ScriptRuntime.ObjectClass)
          return coerceToNumber(double.class, paramObject); 
        if ((paramClass.isPrimitive() && paramClass != boolean.class) || 
          ScriptRuntime.NumberClass.isAssignableFrom(paramClass))
          return coerceToNumber(paramClass, paramObject); 
        reportConversionError(paramObject, paramClass);
        break;
      case 4:
        if (paramClass == ScriptRuntime.StringClass || 
          paramClass == ScriptRuntime.ObjectClass)
          return paramObject; 
        if (paramClass == char.class || 
          paramClass == ScriptRuntime.CharacterClass) {
          if (((String)paramObject).length() == 1)
            return new Character(((String)paramObject).charAt(0)); 
          return coerceToNumber(paramClass, paramObject);
        } 
        if ((paramClass.isPrimitive() && paramClass != boolean.class) || 
          ScriptRuntime.NumberClass.isAssignableFrom(paramClass))
          return coerceToNumber(paramClass, paramObject); 
        reportConversionError(paramObject, paramClass);
        break;
      case 5:
        if (paramObject instanceof Wrapper)
          paramObject = ((Wrapper)paramObject).unwrap(); 
        if (paramClass == ScriptRuntime.ClassClass || 
          paramClass == ScriptRuntime.ObjectClass)
          return paramObject; 
        if (paramClass == ScriptRuntime.StringClass)
          return paramObject.toString(); 
        reportConversionError(paramObject, paramClass);
        break;
      case 6:
      case 7:
        if (paramClass.isPrimitive()) {
          if (paramClass == boolean.class)
            reportConversionError(paramObject, paramClass); 
          return coerceToNumber(paramClass, paramObject);
        } 
        if (paramObject instanceof Wrapper)
          paramObject = ((Wrapper)paramObject).unwrap(); 
        if (paramClass == ScriptRuntime.StringClass)
          return paramObject.toString(); 
        if (paramClass.isInstance(paramObject))
          return paramObject; 
        reportConversionError(paramObject, paramClass);
        break;
      case 8:
        if (paramClass == ScriptRuntime.StringClass)
          return ScriptRuntime.toString(paramObject); 
        if (paramClass.isPrimitive()) {
          if (paramClass == boolean.class)
            reportConversionError(paramObject, paramClass); 
          return coerceToNumber(paramClass, paramObject);
        } 
        if (paramClass.isInstance(paramObject))
          return paramObject; 
        if (paramClass.isArray() && paramObject instanceof NativeArray) {
          NativeArray nativeArray = (NativeArray)paramObject;
          long l = nativeArray.jsGet_length();
          Class clazz = paramClass.getComponentType();
          Object object = Array.newInstance(clazz, (int)l);
          for (byte b = 0; b < l; b++) {
            try {
              Array.set(object, b, coerceType(clazz, 
                    nativeArray.get(b, nativeArray)));
            } catch (EvaluatorException evaluatorException) {
              reportConversionError(paramObject, paramClass);
            } 
          } 
          return object;
        } 
        reportConversionError(paramObject, paramClass);
        break;
    } 
    return paramObject;
  }
  
  static Object coerceToJSObject(Class paramClass, Scriptable paramScriptable) {
    if (ScriptRuntime.ScriptableClass.isAssignableFrom(paramClass))
      return paramScriptable; 
    try {
      Object[] arrayOfObject = { paramScriptable };
      return jsObjectCtor.newInstance(arrayOfObject);
    } catch (InstantiationException instantiationException) {
      throw new EvaluatorException("error generating JSObject wrapper for " + 
          paramScriptable);
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new EvaluatorException("JSObject constructor doesn't want [Scriptable]!");
    } catch (InvocationTargetException invocationTargetException) {
      throw WrappedException.wrapException(invocationTargetException.getTargetException());
    } catch (IllegalAccessException illegalAccessException) {
      throw new EvaluatorException("JSObject constructor is protected/private!");
    } 
  }
  
  static Object coerceToNumber(Class paramClass, Object paramObject) {
    Class clazz = paramObject.getClass();
    if (paramClass == char.class || paramClass == ScriptRuntime.CharacterClass) {
      if (clazz == ScriptRuntime.CharacterClass)
        return paramObject; 
      return new Character((char)(int)toInteger(paramObject, 
            ScriptRuntime.CharacterClass, 
            0.0D, 
            65535.0D));
    } 
    if (paramClass == ScriptRuntime.ObjectClass || 
      paramClass == ScriptRuntime.DoubleClass || paramClass == double.class)
      return (clazz == ScriptRuntime.DoubleClass) ? 
        paramObject : 
        new Double(toDouble(paramObject)); 
    if (paramClass == ScriptRuntime.FloatClass || paramClass == float.class) {
      if (clazz == ScriptRuntime.FloatClass)
        return paramObject; 
      double d1 = toDouble(paramObject);
      if (Double.isInfinite(d1) || Double.isNaN(d1) || 
        d1 == 0.0D)
        return new Float((float)d1); 
      double d2 = Math.abs(d1);
      if (d2 < 1.401298464324817E-45D)
        return new Float((d1 > 0.0D) ? 0.0D : -0.0D); 
      if (d2 > 3.4028234663852886E38D)
        return new Float((d1 > 0.0D) ? 
            Float.POSITIVE_INFINITY : 
            Float.NEGATIVE_INFINITY); 
      return new Float((float)d1);
    } 
    if (paramClass == ScriptRuntime.IntegerClass || paramClass == int.class) {
      if (clazz == ScriptRuntime.IntegerClass)
        return paramObject; 
      return new Integer((int)toInteger(paramObject, 
            ScriptRuntime.IntegerClass, 
            -2.147483648E9D, 
            2.147483647E9D));
    } 
    if (paramClass == ScriptRuntime.LongClass || paramClass == long.class) {
      if (clazz == ScriptRuntime.LongClass)
        return paramObject; 
      double d1 = Double.longBitsToDouble(4890909195324358655L);
      double d2 = Double.longBitsToDouble(-4332462841530417152L);
      return new Long(toInteger(paramObject, 
            ScriptRuntime.LongClass, 
            d2, 
            d1));
    } 
    if (paramClass == ScriptRuntime.ShortClass || paramClass == short.class) {
      if (clazz == ScriptRuntime.ShortClass)
        return paramObject; 
      return new Short((short)(int)toInteger(paramObject, 
            ScriptRuntime.ShortClass, 
            -32768.0D, 
            32767.0D));
    } 
    if (paramClass == ScriptRuntime.ByteClass || paramClass == byte.class) {
      if (clazz == ScriptRuntime.ByteClass)
        return paramObject; 
      return new Byte((byte)(int)toInteger(paramObject, 
            ScriptRuntime.ByteClass, 
            -128.0D, 
            127.0D));
    } 
    return new Double(toDouble(paramObject));
  }
  
  static double toDouble(Object paramObject) {
    Object object;
    if (paramObject instanceof Number)
      return ((Number)paramObject).doubleValue(); 
    if (paramObject instanceof String)
      return ScriptRuntime.toNumber((String)paramObject); 
    if (paramObject instanceof Scriptable) {
      if (paramObject instanceof Wrapper)
        return toDouble(((Wrapper)paramObject).unwrap()); 
      return ScriptRuntime.toNumber(paramObject);
    } 
    try {
      object = paramObject.getClass().getMethod("doubleValue", null);
    } catch (NoSuchMethodException noSuchMethodException) {
      object = null;
    } catch (SecurityException securityException) {
      object = null;
    } 
    if (object != null)
      try {
        return ((Number)object.invoke(paramObject, null)).doubleValue();
      } catch (IllegalAccessException illegalAccessException) {
        reportConversionError(paramObject, double.class);
      } catch (InvocationTargetException invocationTargetException) {
        reportConversionError(paramObject, double.class);
      }  
    return ScriptRuntime.toNumber(paramObject.toString());
  }
  
  static long toInteger(Object paramObject, Class paramClass, double paramDouble1, double paramDouble2) {
    double d = toDouble(paramObject);
    if (Double.isInfinite(d) || Double.isNaN(d))
      reportConversionError(ScriptRuntime.toString(paramObject), paramClass); 
    if (d > 0.0D) {
      d = Math.floor(d);
    } else {
      d = Math.ceil(d);
    } 
    if (d < paramDouble1 || d > paramDouble2)
      reportConversionError(ScriptRuntime.toString(paramObject), paramClass); 
    return (long)d;
  }
  
  static void reportConversionError(Object paramObject, Class paramClass) {
    Object[] arrayOfObject = { paramObject.toString(), 
        NativeJavaMethod.javaSignature(paramClass) };
    throw Context.reportRuntimeError(
        Context.getMessage("msg.conversion.not.allowed", arrayOfObject));
  }
  
  public static void initJSObject() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeJavaObject.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */