package org.mozilla.javascript;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Vector;

public class FunctionObject extends NativeFunction {
  private static final short VARARGS_METHOD = -1;
  
  private static final short VARARGS_CTOR = -2;
  
  private static boolean sawSecurityException;
  
  static Method[] methodsCache;
  
  Method method;
  
  Constructor ctor;
  
  private Class[] types;
  
  private short parmsLength;
  
  private short lengthPropertyValue;
  
  private boolean hasVoidReturn;
  
  private boolean isStatic;
  
  private boolean useDynamicScope;
  
  public FunctionObject(String paramString, Member paramMember, Scriptable paramScriptable) {
    if (paramMember instanceof Constructor) {
      this.ctor = (Constructor)paramMember;
      this.isStatic = true;
      this.types = this.ctor.getParameterTypes();
      str = this.ctor.getName();
    } else {
      this.method = (Method)paramMember;
      this.isStatic = Modifier.isStatic(this.method.getModifiers());
      this.types = this.method.getParameterTypes();
      str = this.method.getName();
    } 
    String[] arrayOfString = { paramString };
    this.names = arrayOfString;
    if (this.types.length == 4 && (this.types[1].isArray() || this.types[2].isArray())) {
      if (this.types[1].isArray()) {
        if (!this.isStatic || 
          this.types[false] != Context.class || 
          this.types[true].getComponentType() != ScriptRuntime.ObjectClass || 
          this.types[2] != ScriptRuntime.FunctionClass || 
          this.types[3] != boolean.class) {
          String[] arrayOfString1 = { str };
          String str1 = Context.getMessage("msg.varargs.ctor", 
              arrayOfString1);
          throw Context.reportRuntimeError(str1);
        } 
        this.parmsLength = -2;
      } else {
        if (!this.isStatic || 
          this.types[false] != Context.class || 
          this.types[true] != ScriptRuntime.ScriptableClass || 
          this.types[2].getComponentType() != ScriptRuntime.ObjectClass || 
          this.types[3] != ScriptRuntime.FunctionClass) {
          String[] arrayOfString1 = { str };
          String str1 = Context.getMessage("msg.varargs.fun", 
              arrayOfString1);
          throw Context.reportRuntimeError(str1);
        } 
        this.parmsLength = -1;
      } 
      s = 1;
    } else {
      this.parmsLength = (short)this.types.length;
      boolean bool = false;
      for (byte b = 0; b < this.parmsLength; b++) {
        Class clazz = this.types[b];
        if (clazz != ScriptRuntime.ObjectClass)
          if (clazz == ScriptRuntime.StringClass || 
            clazz == ScriptRuntime.BooleanClass || 
            ScriptRuntime.NumberClass.isAssignableFrom(clazz) || 
            Scriptable.class.isAssignableFrom(clazz)) {
            bool = true;
          } else if (clazz == boolean.class) {
            bool = true;
            this.types[b] = ScriptRuntime.BooleanClass;
          } else if (clazz == byte.class) {
            bool = true;
            this.types[b] = ScriptRuntime.ByteClass;
          } else if (clazz == short.class) {
            bool = true;
            this.types[b] = ScriptRuntime.ShortClass;
          } else if (clazz == int.class) {
            bool = true;
            this.types[b] = ScriptRuntime.IntegerClass;
          } else if (clazz == float.class) {
            bool = true;
            this.types[b] = ScriptRuntime.FloatClass;
          } else if (clazz == double.class) {
            bool = true;
            this.types[b] = ScriptRuntime.DoubleClass;
          } else {
            Object[] arrayOfObject = { str };
            throw Context.reportRuntimeError(
                Context.getMessage("msg.bad.parms", arrayOfObject));
          }  
      } 
      if (!bool)
        this.types = null; 
      s = this.parmsLength;
    } 
    this.lengthPropertyValue = (short)s;
    this.hasVoidReturn = !(this.method == null || this.method.getReturnType() != void.class);
    this.argCount = (short)s;
    setParentScope(paramScriptable);
    setPrototype(ScriptableObject.getFunctionPrototype(paramScriptable));
    Context context = Context.getCurrentContext();
    this.useDynamicScope = !(context == null || 
      !context.hasCompileFunctionsWithDynamicScope());
  }
  
  public boolean has(String paramString, Scriptable paramScriptable) { return !(!paramString.equals("length") && !super.has(paramString, paramScriptable)); }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    if (paramString.equals("length"))
      return new Integer(this.lengthPropertyValue); 
    return super.get(paramString, paramScriptable);
  }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
    if (!paramString.equals("length"))
      super.put(paramString, paramScriptable, paramObject); 
  }
  
  public void setLength(short paramShort) { this.lengthPropertyValue = paramShort; }
  
  public static Method[] findMethods(Class paramClass, String paramString) { return findMethods(getMethodList(paramClass), paramString); }
  
  static Method[] findMethods(Method[] paramArrayOfMethod, String paramString) {
    Vector vector = null;
    Method method1 = null;
    for (byte b = 0; b < paramArrayOfMethod.length; b++) {
      if (paramArrayOfMethod[b] != null)
        if (paramArrayOfMethod[b].getName().equals(paramString))
          if (method1 == null) {
            method1 = paramArrayOfMethod[b];
          } else {
            if (vector == null) {
              vector = new Vector(5);
              vector.addElement(method1);
            } 
            vector.addElement(paramArrayOfMethod[b]);
          }   
    } 
    if (vector == null) {
      if (method1 == null)
        return null; 
      return new Method[] { method1 };
    } 
    Method[] arrayOfMethod = new Method[vector.size()];
    vector.copyInto(arrayOfMethod);
    return arrayOfMethod;
  }
  
  static Method[] getMethodList(Class paramClass) {
    Method[] arrayOfMethod1 = methodsCache;
    if (arrayOfMethod1 != null && arrayOfMethod1[false].getDeclaringClass() == paramClass)
      return arrayOfMethod1; 
    Method[] arrayOfMethod2 = null;
    try {
      if (!sawSecurityException)
        arrayOfMethod2 = paramClass.getDeclaredMethods(); 
    } catch (SecurityException securityException) {
      sawSecurityException = true;
    } 
    if (arrayOfMethod2 == null)
      arrayOfMethod2 = paramClass.getMethods(); 
    byte b1 = 0;
    for (byte b2 = 0; b2 < arrayOfMethod2.length; b2++) {
      if (sawSecurityException ? (
        arrayOfMethod2[b2].getDeclaringClass() != paramClass) : (
        Modifier.isPublic(arrayOfMethod2[b2].getModifiers()) ^ true)) {
        arrayOfMethod2[b2] = null;
      } else {
        b1++;
      } 
    } 
    Method[] arrayOfMethod3 = new Method[b1];
    byte b3 = 0;
    for (byte b4 = 0; b4 < arrayOfMethod2.length; b4++) {
      if (arrayOfMethod2[b4] != null)
        arrayOfMethod3[b3++] = arrayOfMethod2[b4]; 
    } 
    if (arrayOfMethod3.length > 0 && Context.isCachingEnabled)
      methodsCache = arrayOfMethod3; 
    return arrayOfMethod3;
  }
  
  public void addAsConstructor(Scriptable paramScriptable1, Scriptable paramScriptable2) {
    setParentScope(paramScriptable1);
    setPrototype(ScriptableObject.getFunctionPrototype(paramScriptable1));
    paramScriptable2.setParentScope(this);
    byte b = 
      7;
    defineProperty("prototype", paramScriptable2, 7);
    String str = paramScriptable2.getClassName();
    if (!str.equals("With")) {
      if (paramScriptable2 instanceof ScriptableObject)
        ((ScriptableObject)paramScriptable2).defineProperty("constructor", 
            this, 7); 
      paramScriptable2.put("constructor", paramScriptable2, this);
    } 
    if (paramScriptable1 instanceof ScriptableObject) {
      ((ScriptableObject)paramScriptable1).defineProperty(str, this, 
          2);
    } else {
      paramScriptable1.put(str, paramScriptable1, this);
    } 
    setParentScope(paramScriptable1);
  }
  
  public static Object convertArg(Scriptable paramScriptable, Object paramObject, Class paramClass) {
    if (paramClass == ScriptRuntime.BooleanClass || 
      paramClass == boolean.class)
      return ScriptRuntime.toBoolean(paramObject) ? Boolean.TRUE : 
        Boolean.FALSE; 
    if (paramClass == ScriptRuntime.StringClass)
      return ScriptRuntime.toString(paramObject); 
    if (paramClass == ScriptRuntime.IntegerClass || 
      paramClass == int.class)
      return new Integer(ScriptRuntime.toInt32(paramObject)); 
    if (paramClass == ScriptRuntime.DoubleClass || 
      paramClass == double.class)
      return new Double(ScriptRuntime.toNumber(paramObject)); 
    if (paramClass == ScriptRuntime.ScriptableClass)
      return ScriptRuntime.toObject(paramScriptable, paramObject); 
    if (paramClass == ScriptRuntime.ObjectClass)
      return paramObject; 
    Object[] arrayOfObject = { paramClass.getName() };
    throw Context.reportRuntimeError(
        Context.getMessage("msg.cant.convert", arrayOfObject));
  }
  
  public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException {
    byte b;
    Object[] arrayOfObject;
    if (this.parmsLength < 0)
      return callVarargs(paramContext, paramScriptable2, paramArrayOfObject, false); 
    if (!this.isStatic) {
      arrayOfObject = (this.method != null) ? this.method.getDeclaringClass() : 
        this.ctor.getDeclaringClass();
      while (!arrayOfObject.isInstance(paramScriptable2)) {
        paramScriptable2 = paramScriptable2.getPrototype();
        if (paramScriptable2 == null || !this.useDynamicScope) {
          Object[] arrayOfObject1 = { this.names[0] };
          String str = Context.getMessage("msg.incompat.call", arrayOfObject1);
          throw NativeGlobal.constructError(paramContext, "TypeError", str, paramScriptable1);
        } 
      } 
    } 
    if (this.parmsLength == paramArrayOfObject.length) {
      arrayOfObject = paramArrayOfObject;
      b = (this.types == null) ? this.parmsLength : 0;
    } else {
      arrayOfObject = new Object[this.parmsLength];
      b = 0;
    } 
    for (; b < this.parmsLength; b++) {
      Object object = (b < paramArrayOfObject.length) ? 
        paramArrayOfObject[b] : 
        Undefined.instance;
      if (this.types != null)
        object = convertArg(this, object, this.types[b]); 
      arrayOfObject[b] = object;
    } 
    try {
      Object object = (this.method != null) ? 
        this.method.invoke(paramScriptable2, arrayOfObject) : 
        this.ctor.newInstance(arrayOfObject);
      return this.hasVoidReturn ? Undefined.instance : object;
    } catch (InvocationTargetException invocationTargetException) {
      throw JavaScriptException.wrapException(paramScriptable1, invocationTargetException);
    } catch (IllegalAccessException illegalAccessException) {
      throw WrappedException.wrapException(illegalAccessException);
    } catch (InstantiationException instantiationException) {
      throw WrappedException.wrapException(instantiationException);
    } 
  }
  
  public Scriptable construct(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject) throws JavaScriptException {
    if (this.method == null || this.parmsLength == -2) {
      Scriptable scriptable;
      if (this.method != null) {
        paramContext.ctorScope = paramScriptable;
        scriptable = (Scriptable)callVarargs(paramContext, null, paramArrayOfObject, true);
        paramContext.ctorScope = null;
      } else {
        scriptable = (Scriptable)call(paramContext, paramScriptable, null, paramArrayOfObject);
      } 
      if (scriptable.getPrototype() == null)
        scriptable.setPrototype(getClassPrototype()); 
      if (scriptable.getParentScope() == null) {
        Scriptable scriptable1 = getParentScope();
        if (scriptable != scriptable1)
          scriptable.setParentScope(scriptable1); 
      } 
      return scriptable;
    } 
    if (this.method != null && !this.isStatic) {
      Scriptable scriptable;
      try {
        scriptable = (Scriptable)this.method.getDeclaringClass().newInstance();
      } catch (IllegalAccessException illegalAccessException) {
        throw WrappedException.wrapException(illegalAccessException);
      } catch (InstantiationException instantiationException) {
        throw WrappedException.wrapException(instantiationException);
      } 
      scriptable.setPrototype(getClassPrototype());
      scriptable.setParentScope(getParentScope());
      Object object = call(paramContext, paramScriptable, scriptable, paramArrayOfObject);
      if (object != null && object != Undefined.instance && 
        object instanceof Scriptable)
        return (Scriptable)object; 
      return scriptable;
    } 
    return super.construct(paramContext, paramScriptable, paramArrayOfObject);
  }
  
  private Object callVarargs(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, boolean paramBoolean) throws JavaScriptException {
    try {
      if (this.parmsLength == -1) {
        Object[] arrayOfObject1 = { paramContext, paramScriptable, paramArrayOfObject, this };
        Object object = this.method.invoke(null, arrayOfObject1);
        return this.hasVoidReturn ? Undefined.instance : object;
      } 
      Boolean bool = paramBoolean ? Boolean.TRUE : Boolean.FALSE;
      Object[] arrayOfObject = { paramContext, paramArrayOfObject, this, bool };
      return (this.method == null) ? 
        this.ctor.newInstance(arrayOfObject) : 
        this.method.invoke(null, arrayOfObject);
    } catch (InvocationTargetException invocationTargetException) {
      Throwable throwable = invocationTargetException.getTargetException();
      if (throwable instanceof EvaluatorException)
        throw (EvaluatorException)throwable; 
      if (throwable instanceof EcmaError)
        throw (EcmaError)throwable; 
      FunctionObject functionObject = (paramScriptable == null) ? this : paramScriptable;
      throw JavaScriptException.wrapException(functionObject, throwable);
    } catch (IllegalAccessException illegalAccessException) {
      throw WrappedException.wrapException(illegalAccessException);
    } catch (InstantiationException instantiationException) {
      throw WrappedException.wrapException(instantiationException);
    } 
  }
  
  boolean isVarArgsMethod() { return !(this.parmsLength != -1); }
  
  boolean isVarArgsConstructor() { return !(this.parmsLength != -2); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\FunctionObject.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */