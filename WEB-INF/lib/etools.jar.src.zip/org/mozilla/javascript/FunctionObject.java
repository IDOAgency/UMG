/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionObject
/*     */   extends NativeFunction
/*     */ {
/*     */   private static final short VARARGS_METHOD = -1;
/*     */   private static final short VARARGS_CTOR = -2;
/*     */   private static boolean sawSecurityException;
/*     */   static Method[] methodsCache;
/*     */   Method method;
/*     */   Constructor ctor;
/*     */   private Class[] types;
/*     */   private short parmsLength;
/*     */   private short lengthPropertyValue;
/*     */   private boolean hasVoidReturn;
/*     */   private boolean isStatic;
/*     */   private boolean useDynamicScope;
/*     */   
/*     */   public FunctionObject(String paramString, Member paramMember, Scriptable paramScriptable) {
/* 115 */     if (paramMember instanceof Constructor) {
/* 116 */       this.ctor = (Constructor)paramMember;
/* 117 */       this.isStatic = true;
/* 118 */       this.types = this.ctor.getParameterTypes();
/* 119 */       str = this.ctor.getName();
/*     */     } else {
/* 121 */       this.method = (Method)paramMember;
/* 122 */       this.isStatic = Modifier.isStatic(this.method.getModifiers());
/* 123 */       this.types = this.method.getParameterTypes();
/* 124 */       str = this.method.getName();
/*     */     } 
/* 126 */     String[] arrayOfString = { paramString };
/* 127 */     this.names = arrayOfString;
/*     */     
/* 129 */     if (this.types.length == 4 && (this.types[1].isArray() || this.types[2].isArray())) {
/*     */       
/* 131 */       if (this.types[1].isArray()) {
/* 132 */         if (!this.isStatic || 
/* 133 */           this.types[false] != Context.class || 
/* 134 */           this.types[true].getComponentType() != ScriptRuntime.ObjectClass || 
/* 135 */           this.types[2] != ScriptRuntime.FunctionClass || 
/* 136 */           this.types[3] != boolean.class) {
/*     */           
/* 138 */           String[] arrayOfString1 = { str };
/* 139 */           String str1 = Context.getMessage("msg.varargs.ctor", 
/* 140 */               arrayOfString1);
/* 141 */           throw Context.reportRuntimeError(str1);
/*     */         } 
/* 143 */         this.parmsLength = -2;
/*     */       } else {
/* 145 */         if (!this.isStatic || 
/* 146 */           this.types[false] != Context.class || 
/* 147 */           this.types[true] != ScriptRuntime.ScriptableClass || 
/* 148 */           this.types[2].getComponentType() != ScriptRuntime.ObjectClass || 
/* 149 */           this.types[3] != ScriptRuntime.FunctionClass) {
/*     */           
/* 151 */           String[] arrayOfString1 = { str };
/* 152 */           String str1 = Context.getMessage("msg.varargs.fun", 
/* 153 */               arrayOfString1);
/* 154 */           throw Context.reportRuntimeError(str1);
/*     */         } 
/* 156 */         this.parmsLength = -1;
/*     */       } 
/*     */       
/* 159 */       s = 1;
/*     */     } else {
/* 161 */       this.parmsLength = (short)this.types.length;
/* 162 */       boolean bool = false;
/* 163 */       for (byte b = 0; b < this.parmsLength; b++) {
/* 164 */         Class clazz = this.types[b];
/* 165 */         if (clazz != ScriptRuntime.ObjectClass)
/*     */         {
/* 167 */           if (clazz == ScriptRuntime.StringClass || 
/* 168 */             clazz == ScriptRuntime.BooleanClass || 
/* 169 */             ScriptRuntime.NumberClass.isAssignableFrom(clazz) || 
/* 170 */             Scriptable.class.isAssignableFrom(clazz)) {
/*     */             
/* 172 */             bool = true;
/* 173 */           } else if (clazz == boolean.class) {
/* 174 */             bool = true;
/* 175 */             this.types[b] = ScriptRuntime.BooleanClass;
/* 176 */           } else if (clazz == byte.class) {
/* 177 */             bool = true;
/* 178 */             this.types[b] = ScriptRuntime.ByteClass;
/* 179 */           } else if (clazz == short.class) {
/* 180 */             bool = true;
/* 181 */             this.types[b] = ScriptRuntime.ShortClass;
/* 182 */           } else if (clazz == int.class) {
/* 183 */             bool = true;
/* 184 */             this.types[b] = ScriptRuntime.IntegerClass;
/* 185 */           } else if (clazz == float.class) {
/* 186 */             bool = true;
/* 187 */             this.types[b] = ScriptRuntime.FloatClass;
/* 188 */           } else if (clazz == double.class) {
/* 189 */             bool = true;
/* 190 */             this.types[b] = ScriptRuntime.DoubleClass;
/*     */           }
/*     */           else {
/*     */             
/* 194 */             Object[] arrayOfObject = { str };
/* 195 */             throw Context.reportRuntimeError(
/* 196 */                 Context.getMessage("msg.bad.parms", arrayOfObject));
/*     */           }  } 
/*     */       } 
/* 199 */       if (!bool)
/* 200 */         this.types = null; 
/* 201 */       s = this.parmsLength;
/*     */     } 
/*     */ 
/*     */     
/* 205 */     this.lengthPropertyValue = (short)s;
/*     */     
/* 207 */     this.hasVoidReturn = !(this.method == null || this.method.getReturnType() != void.class);
/* 208 */     this.argCount = (short)s;
/*     */     
/* 210 */     setParentScope(paramScriptable);
/* 211 */     setPrototype(ScriptableObject.getFunctionPrototype(paramScriptable));
/* 212 */     Context context = Context.getCurrentContext();
/* 213 */     this.useDynamicScope = !(context == null || 
/* 214 */       !context.hasCompileFunctionsWithDynamicScope());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 233 */   public boolean has(String paramString, Scriptable paramScriptable) { return !(!paramString.equals("length") && !super.has(paramString, paramScriptable)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/* 248 */     if (paramString.equals("length"))
/* 249 */       return new Integer(this.lengthPropertyValue); 
/* 250 */     return super.get(paramString, paramScriptable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
/* 263 */     if (!paramString.equals("length")) {
/* 264 */       super.put(paramString, paramScriptable, paramObject);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 282 */   public void setLength(short paramShort) { this.lengthPropertyValue = paramShort; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   public static Method[] findMethods(Class paramClass, String paramString) { return findMethods(getMethodList(paramClass), paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Method[] findMethods(Method[] paramArrayOfMethod, String paramString) {
/* 306 */     Vector vector = null;
/* 307 */     Method method1 = null;
/* 308 */     for (byte b = 0; b < paramArrayOfMethod.length; b++) {
/* 309 */       if (paramArrayOfMethod[b] != null)
/*     */       {
/* 311 */         if (paramArrayOfMethod[b].getName().equals(paramString))
/* 312 */           if (method1 == null) {
/* 313 */             method1 = paramArrayOfMethod[b];
/*     */           } else {
/* 315 */             if (vector == null) {
/* 316 */               vector = new Vector(5);
/* 317 */               vector.addElement(method1);
/*     */             } 
/* 319 */             vector.addElement(paramArrayOfMethod[b]);
/*     */           }  
/*     */       }
/*     */     } 
/* 323 */     if (vector == null) {
/* 324 */       if (method1 == null)
/* 325 */         return null; 
/* 326 */       return new Method[] { method1 };
/*     */     } 
/*     */     
/* 329 */     Method[] arrayOfMethod = new Method[vector.size()];
/* 330 */     vector.copyInto(arrayOfMethod);
/* 331 */     return arrayOfMethod;
/*     */   }
/*     */   
/*     */   static Method[] getMethodList(Class paramClass) {
/* 335 */     Method[] arrayOfMethod1 = methodsCache;
/* 336 */     if (arrayOfMethod1 != null && arrayOfMethod1[false].getDeclaringClass() == paramClass)
/* 337 */       return arrayOfMethod1; 
/* 338 */     Method[] arrayOfMethod2 = null;
/*     */ 
/*     */     
/*     */     try {
/* 342 */       if (!sawSecurityException)
/* 343 */         arrayOfMethod2 = paramClass.getDeclaredMethods(); 
/* 344 */     } catch (SecurityException securityException) {
/*     */       
/* 346 */       sawSecurityException = true;
/*     */     } 
/* 348 */     if (arrayOfMethod2 == null) {
/* 349 */       arrayOfMethod2 = paramClass.getMethods();
/*     */     }
/* 351 */     byte b1 = 0;
/* 352 */     for (byte b2 = 0; b2 < arrayOfMethod2.length; b2++) {
/* 353 */       if (sawSecurityException ? (
/* 354 */         arrayOfMethod2[b2].getDeclaringClass() != paramClass) : (
/* 355 */         Modifier.isPublic(arrayOfMethod2[b2].getModifiers()) ^ true)) {
/*     */         
/* 357 */         arrayOfMethod2[b2] = null;
/*     */       } else {
/* 359 */         b1++;
/*     */       } 
/*     */     } 
/* 362 */     Method[] arrayOfMethod3 = new Method[b1];
/* 363 */     byte b3 = 0;
/* 364 */     for (byte b4 = 0; b4 < arrayOfMethod2.length; b4++) {
/* 365 */       if (arrayOfMethod2[b4] != null)
/* 366 */         arrayOfMethod3[b3++] = arrayOfMethod2[b4]; 
/*     */     } 
/* 368 */     if (arrayOfMethod3.length > 0 && Context.isCachingEnabled)
/* 369 */       methodsCache = arrayOfMethod3; 
/* 370 */     return arrayOfMethod3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAsConstructor(Scriptable paramScriptable1, Scriptable paramScriptable2) {
/* 390 */     setParentScope(paramScriptable1);
/* 391 */     setPrototype(ScriptableObject.getFunctionPrototype(paramScriptable1));
/* 392 */     paramScriptable2.setParentScope(this);
/* 393 */     byte b = 
/* 394 */       7;
/*     */     
/* 396 */     defineProperty("prototype", paramScriptable2, 7);
/* 397 */     String str = paramScriptable2.getClassName();
/* 398 */     if (!str.equals("With")) {
/*     */ 
/*     */       
/* 401 */       if (paramScriptable2 instanceof ScriptableObject) {
/* 402 */         ((ScriptableObject)paramScriptable2).defineProperty("constructor", 
/* 403 */             this, 7);
/*     */       }
/* 405 */       paramScriptable2.put("constructor", paramScriptable2, this);
/*     */     } 
/*     */     
/* 408 */     if (paramScriptable1 instanceof ScriptableObject) {
/* 409 */       ((ScriptableObject)paramScriptable1).defineProperty(str, this, 
/* 410 */           2);
/*     */     } else {
/* 412 */       paramScriptable1.put(str, paramScriptable1, this);
/*     */     } 
/* 414 */     setParentScope(paramScriptable1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object convertArg(Scriptable paramScriptable, Object paramObject, Class paramClass) {
/* 420 */     if (paramClass == ScriptRuntime.BooleanClass || 
/* 421 */       paramClass == boolean.class)
/* 422 */       return ScriptRuntime.toBoolean(paramObject) ? Boolean.TRUE : 
/* 423 */         Boolean.FALSE; 
/* 424 */     if (paramClass == ScriptRuntime.StringClass)
/* 425 */       return ScriptRuntime.toString(paramObject); 
/* 426 */     if (paramClass == ScriptRuntime.IntegerClass || 
/* 427 */       paramClass == int.class)
/* 428 */       return new Integer(ScriptRuntime.toInt32(paramObject)); 
/* 429 */     if (paramClass == ScriptRuntime.DoubleClass || 
/* 430 */       paramClass == double.class)
/* 431 */       return new Double(ScriptRuntime.toNumber(paramObject)); 
/* 432 */     if (paramClass == ScriptRuntime.ScriptableClass)
/* 433 */       return ScriptRuntime.toObject(paramScriptable, paramObject); 
/* 434 */     if (paramClass == ScriptRuntime.ObjectClass) {
/* 435 */       return paramObject;
/*     */     }
/*     */ 
/*     */     
/* 439 */     Object[] arrayOfObject = { paramClass.getName() };
/* 440 */     throw Context.reportRuntimeError(
/* 441 */         Context.getMessage("msg.cant.convert", arrayOfObject));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException {
/*     */     byte b;
/*     */     Object[] arrayOfObject;
/* 459 */     if (this.parmsLength < 0) {
/* 460 */       return callVarargs(paramContext, paramScriptable2, paramArrayOfObject, false);
/*     */     }
/* 462 */     if (!this.isStatic) {
/*     */       
/* 464 */       arrayOfObject = (this.method != null) ? this.method.getDeclaringClass() : 
/* 465 */         this.ctor.getDeclaringClass();
/* 466 */       while (!arrayOfObject.isInstance(paramScriptable2)) {
/* 467 */         paramScriptable2 = paramScriptable2.getPrototype();
/* 468 */         if (paramScriptable2 == null || !this.useDynamicScope) {
/*     */           
/* 470 */           Object[] arrayOfObject1 = { this.names[0] };
/* 471 */           String str = Context.getMessage("msg.incompat.call", arrayOfObject1);
/* 472 */           throw NativeGlobal.constructError(paramContext, "TypeError", str, paramScriptable1);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 478 */     if (this.parmsLength == paramArrayOfObject.length) {
/* 479 */       arrayOfObject = paramArrayOfObject;
/*     */       
/* 481 */       b = (this.types == null) ? this.parmsLength : 0;
/*     */     } else {
/* 483 */       arrayOfObject = new Object[this.parmsLength];
/* 484 */       b = 0;
/*     */     } 
/* 486 */     for (; b < this.parmsLength; b++) {
/* 487 */       Object object = (b < paramArrayOfObject.length) ? 
/* 488 */         paramArrayOfObject[b] : 
/* 489 */         Undefined.instance;
/* 490 */       if (this.types != null) {
/* 491 */         object = convertArg(this, object, this.types[b]);
/*     */       }
/* 493 */       arrayOfObject[b] = object;
/*     */     } 
/*     */     try {
/* 496 */       Object object = (this.method != null) ? 
/* 497 */         this.method.invoke(paramScriptable2, arrayOfObject) : 
/* 498 */         this.ctor.newInstance(arrayOfObject);
/* 499 */       return this.hasVoidReturn ? Undefined.instance : object;
/*     */     }
/* 501 */     catch (InvocationTargetException invocationTargetException) {
/* 502 */       throw JavaScriptException.wrapException(paramScriptable1, invocationTargetException);
/*     */     }
/* 504 */     catch (IllegalAccessException illegalAccessException) {
/* 505 */       throw WrappedException.wrapException(illegalAccessException);
/*     */     }
/* 507 */     catch (InstantiationException instantiationException) {
/* 508 */       throw WrappedException.wrapException(instantiationException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable construct(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject) throws JavaScriptException {
/* 531 */     if (this.method == null || this.parmsLength == -2) {
/*     */       Scriptable scriptable;
/* 533 */       if (this.method != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 538 */         paramContext.ctorScope = paramScriptable;
/* 539 */         scriptable = (Scriptable)callVarargs(paramContext, null, paramArrayOfObject, true);
/* 540 */         paramContext.ctorScope = null;
/*     */       } else {
/* 542 */         scriptable = (Scriptable)call(paramContext, paramScriptable, null, paramArrayOfObject);
/*     */       } 
/*     */       
/* 545 */       if (scriptable.getPrototype() == null)
/* 546 */         scriptable.setPrototype(getClassPrototype()); 
/* 547 */       if (scriptable.getParentScope() == null) {
/* 548 */         Scriptable scriptable1 = getParentScope();
/* 549 */         if (scriptable != scriptable1) {
/* 550 */           scriptable.setParentScope(scriptable1);
/*     */         }
/*     */       } 
/* 553 */       return scriptable;
/* 554 */     }  if (this.method != null && !this.isStatic) {
/*     */       Scriptable scriptable;
/*     */       try {
/* 557 */         scriptable = (Scriptable)this.method.getDeclaringClass().newInstance();
/* 558 */       } catch (IllegalAccessException illegalAccessException) {
/* 559 */         throw WrappedException.wrapException(illegalAccessException);
/* 560 */       } catch (InstantiationException instantiationException) {
/* 561 */         throw WrappedException.wrapException(instantiationException);
/*     */       } 
/*     */       
/* 564 */       scriptable.setPrototype(getClassPrototype());
/* 565 */       scriptable.setParentScope(getParentScope());
/*     */       
/* 567 */       Object object = call(paramContext, paramScriptable, scriptable, paramArrayOfObject);
/* 568 */       if (object != null && object != Undefined.instance && 
/* 569 */         object instanceof Scriptable)
/*     */       {
/* 571 */         return (Scriptable)object;
/*     */       }
/* 573 */       return scriptable;
/*     */     } 
/*     */     
/* 576 */     return super.construct(paramContext, paramScriptable, paramArrayOfObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object callVarargs(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, boolean paramBoolean) throws JavaScriptException {
/*     */     try {
/* 584 */       if (this.parmsLength == -1) {
/* 585 */         Object[] arrayOfObject1 = { paramContext, paramScriptable, paramArrayOfObject, this };
/* 586 */         Object object = this.method.invoke(null, arrayOfObject1);
/* 587 */         return this.hasVoidReturn ? Undefined.instance : object;
/*     */       } 
/* 589 */       Boolean bool = paramBoolean ? Boolean.TRUE : Boolean.FALSE;
/* 590 */       Object[] arrayOfObject = { paramContext, paramArrayOfObject, this, bool };
/* 591 */       return (this.method == null) ? 
/* 592 */         this.ctor.newInstance(arrayOfObject) : 
/* 593 */         this.method.invoke(null, arrayOfObject);
/*     */     
/*     */     }
/* 596 */     catch (InvocationTargetException invocationTargetException) {
/* 597 */       Throwable throwable = invocationTargetException.getTargetException();
/* 598 */       if (throwable instanceof EvaluatorException)
/* 599 */         throw (EvaluatorException)throwable; 
/* 600 */       if (throwable instanceof EcmaError)
/* 601 */         throw (EcmaError)throwable; 
/* 602 */       FunctionObject functionObject = (paramScriptable == null) ? this : paramScriptable;
/* 603 */       throw JavaScriptException.wrapException(functionObject, throwable);
/*     */     }
/* 605 */     catch (IllegalAccessException illegalAccessException) {
/* 606 */       throw WrappedException.wrapException(illegalAccessException);
/*     */     }
/* 608 */     catch (InstantiationException instantiationException) {
/* 609 */       throw WrappedException.wrapException(instantiationException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 614 */   boolean isVarArgsMethod() { return !(this.parmsLength != -1); }
/*     */ 
/*     */ 
/*     */   
/* 618 */   boolean isVarArgsConstructor() { return !(this.parmsLength != -2); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\FunctionObject.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */