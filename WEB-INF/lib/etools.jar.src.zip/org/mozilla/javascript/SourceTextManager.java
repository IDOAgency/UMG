package org.mozilla.javascript;

import java.util.Enumeration;

public interface SourceTextManager {
  Enumeration getAllItems();
  
  SourceTextItem getItem(String paramString);
  
  SourceTextItem newItem(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\SourceTextManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */