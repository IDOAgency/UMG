package org.mozilla.javascript;

import java.util.Hashtable;
import java.util.Stack;
import java.util.Vector;

public class NodeTransformer {
  protected Stack loops;
  
  protected Stack loopEnds;
  
  protected boolean inFunction;
  
  protected IRFactory irFactory;
  
  public NodeTransformer newInstance() { return new NodeTransformer(); }
  
  public IRFactory createIRFactory(TokenStream paramTokenStream, Scriptable paramScriptable) { return new IRFactory(paramTokenStream, paramScriptable); }
  
  public Node transform(Node paramNode1, Node paramNode2, TokenStream paramTokenStream, Scriptable paramScriptable) {
    this.loops = new Stack();
    this.loopEnds = new Stack();
    this.inFunction = !(paramNode1.getType() != 109);
    if (!this.inFunction)
      addVariables(paramNode1, getVariableTable(paramNode1)); 
    this.irFactory = createIRFactory(paramTokenStream, paramScriptable);
    boolean bool = false;
    PreorderNodeIterator preorderNodeIterator = paramNode1.getPreorderIterator();
    Node node;
    label242: while ((node = preorderNodeIterator.nextNode()) != null) {
      Node node9;
      byte b;
      Node node8, node7;
      int k;
      Node node6;
      int j;
      String str4;
      VariableTable variableTable2;
      Vector vector2;
      String str2;
      boolean bool1;
      NodeTransformer nodeTransformer;
      Node node5, node4;
      Integer integer2;
      VariableTable variableTable1;
      String str3;
      Node node3;
      Integer integer1;
      Node node2;
      String str1;
      Vector vector1;
      FunctionNode functionNode;
      ShallowNodeIterator shallowNodeIterator;
      Node node1;
      int i = node.getType();
      switch (i) {
        case 109:
          if (node == paramNode1) {
            VariableTable variableTable = getVariableTable(paramNode1);
            addVariables(paramNode1, variableTable);
            Node node10 = node.getLastChild();
            Node node11 = node10.getLastChild();
            if (node11 == null || 
              node11.getType() != 5)
              node10.addChildToBack(new Node(5)); 
            continue;
          } 
          if (this.inFunction)
            ((FunctionNode)paramNode1).setRequiresActivation(true); 
          functionNode = 
            (FunctionNode)node.getProp(5);
          addParameters(functionNode);
          nodeTransformer = newInstance();
          functionNode = 
            (FunctionNode)nodeTransformer.transform(functionNode, paramNode1, paramTokenStream, paramScriptable);
          node.putProp(5, functionNode);
          vector2 = (Vector)paramNode1.getProp(5);
          if (vector2 == null) {
            vector2 = new Vector(7);
            paramNode1.putProp(5, vector2);
          } 
          vector2.addElement(functionNode);
        case 135:
          node3 = node.getFirstChild();
          node.removeChild(node3);
          str3 = node3.getString();
          for (j = this.loops.size() - 1; j >= 0; j--) {
            Node node10 = (Node)this.loops.elementAt(j);
            if (node10.getType() == 135) {
              String str = (String)node10.getProp(20);
              if (str3.equals(str)) {
                Object[] arrayOfObject = { str3 };
                String str5 = Context.getMessage("msg.dup.label", 
                    arrayOfObject);
                reportMessage(Context.getContext(), str5, node, 
                    paramNode1, true, paramScriptable);
                continue label242;
              } 
            } 
          } 
          node.putProp(20, str3);
          node6 = new Node(136);
          node7 = preorderNodeIterator.getCurrentParent();
          node8 = node.getNextSibling();
          while (node8 != null && (
            node8.getType() == 135 || 
            node8.getType() == 136))
            node8 = node8.getNextSibling(); 
          if (node8 != null) {
            node7.addChildAfter(node6, node8);
            node.putProp(2, node6);
            if (node8.getType() == 137)
              node.putProp(3, 
                  node8.getProp(3)); 
            this.loops.push(node);
            this.loopEnds.push(node6);
          } 
        case 114:
          node3 = new Node(136);
          node5 = preorderNodeIterator.getCurrentParent();
          node5.addChildAfter(node3, node);
          str4 = node;
          node6 = (node.getFirstChild()).next;
          while (node6 != null) {
            node7 = node6.next;
            node.removeChild(node6);
            node5.addChildAfter(node6, str4);
            str4 = node6;
            node6 = node7;
          } 
          node.putProp(2, node3);
          this.loops.push(node);
          this.loopEnds.push(node3);
          node.putProp(13, new Vector(13));
        case 115:
        case 116:
          node3 = (Node)this.loops.peek();
          if (i == 115) {
            Vector vector = (Vector)node3.getProp(13);
            vector.addElement(node);
            continue;
          } 
          node3.putProp(14, node);
        case 143:
          integer1 = 
            (Integer)paramNode1.getProp(22);
          if (integer1 == null) {
            paramNode1.putProp(22, new Integer(1));
            continue;
          } 
          paramNode1.putProp(22, 
              new Integer(integer1.intValue() + 1));
        case 137:
          this.loops.push(node);
          this.loopEnds.push(node.getProp(2));
        case 123:
          if (this.inFunction)
            ((FunctionNode)paramNode1).setRequiresActivation(true); 
          this.loops.push(node);
          node2 = node.getNextSibling();
          if (node2.getType() != 4)
            throw new RuntimeException("Unexpected tree"); 
          this.loopEnds.push(node2);
        case 75:
          node2 = (Node)node.getProp(21);
          if (node2 != null) {
            bool = true;
            this.loops.push(node);
            this.loopEnds.push(node2);
          } 
          integer2 = 
            (Integer)paramNode1.getProp(22);
          if (integer2 == null) {
            paramNode1.putProp(22, new Integer(1));
            continue;
          } 
          paramNode1.putProp(22, 
              new Integer(integer2.intValue() + 1));
        case 4:
        case 136:
          if (!this.loopEnds.empty() && this.loopEnds.peek() == node) {
            this.loopEnds.pop();
            this.loops.pop();
          } 
        case 5:
          if (bool) {
            node2 = preorderNodeIterator.getCurrentParent();
            for (int m = this.loops.size() - 1; m >= 0; m--) {
              str4 = (Node)this.loops.elementAt(m);
              int n = str4.getType();
              if (n == 75) {
                node7 = new Node(142);
                Object object = str4.getProp(21);
                node7.putProp(1, object);
                node2.addChildBefore(node7, node);
              } else if (n == 123) {
                node2.addChildBefore(new Node(4), 
                    node);
              } 
            } 
          } 
        case 120:
        case 121:
          node2 = null;
          bool1 = node.hasChildren();
          str4 = null;
          if (bool1) {
            node6 = node.getFirstChild();
            str4 = node6.getString();
            node.removeChild(node6);
          } 
          node7 = preorderNodeIterator.getCurrentParent();
          for (k = this.loops.size() - 1; k >= 0; k--) {
            node8 = (Node)this.loops.elementAt(k);
            int m = node8.getType();
            if (m == 123) {
              node7.addChildBefore(new Node(4), 
                  node);
            } else if (m == 75) {
              Node node10 = new Node(142);
              Object object = node8.getProp(21);
              node10.putProp(1, object);
              node7.addChildBefore(node10, node);
            } else {
              if (!bool1 && (
                m == 137 || (
                m == 114 && 
                i == 120))) {
                node2 = node8;
                break;
              } 
              if (bool1 && 
                m == 135 && 
                str4.equals((String)node8.getProp(20))) {
                node2 = node8;
                break;
              } 
            } 
          } 
          b = (i == 120) ? 
            2 : 
            3;
          node9 = (node2 == null) ? 
            null : 
            (Node)node2.getProp(b);
          if (node2 == null || node9 == null) {
            String str;
            if (!bool1) {
              if (i == 121) {
                str = 
                  Context.getMessage("msg.continue.outside", null);
              } else {
                str = 
                  Context.getMessage("msg.bad.break", null);
              } 
            } else if (node2 != null) {
              str = Context.getMessage("msg.continue.nonloop", 
                  null);
            } else {
              Object[] arrayOfObject = { str4 };
              str = 
                Context.getMessage("msg.undef.label", arrayOfObject);
            } 
            reportMessage(Context.getContext(), str, node, 
                paramNode1, true, paramScriptable);
            node.setType(127);
            continue;
          } 
          node.setType(6);
          node.putProp(1, node9);
        case 43:
          if (isSpecialCallName(paramNode1, node))
            node.putProp(30, Boolean.TRUE); 
          visitCall(node, paramNode1);
        case 30:
          if (isSpecialCallName(paramNode1, node))
            node.putProp(30, Boolean.TRUE); 
          visitNew(node, paramNode1);
        case 107:
          node2 = node.getLastChild();
          node2.setType(46);
        case 139:
          node.setType(this.inFunction ? 57 : 2);
        case 56:
          vector1 = (Vector)paramNode1.getProp(12);
          if (vector1 == null) {
            vector1 = new Vector(3);
            paramNode1.putProp(12, vector1);
          } 
          vector1.addElement(node);
          node4 = new Node(56);
          preorderNodeIterator.replaceCurrent(node4);
          node4.putProp(12, node);
        case 122:
          shallowNodeIterator = node.getChildIterator();
          node4 = new Node(132);
          while (shallowNodeIterator.hasMoreElements()) {
            Node node10 = shallowNodeIterator.nextNode();
            if (node10.hasChildren()) {
              Node node11 = node10.getFirstChild();
              node10.removeChild(node11);
              node7 = (Node)this.irFactory.createAssignment(
                  127, node10, node11, null, 
                  false);
              Node node12 = new Node(57, node7, node.getDatum());
              node4.addChildToBack(node12);
            } 
          } 
          preorderNodeIterator.replaceCurrent(node4);
        case 10:
        case 31:
          if (!this.inFunction || inWithStatement())
            continue; 
          node1 = node.getFirstChild();
          if (node1 == null || node1.getType() != 61)
            continue; 
          str2 = node1.getString();
          if (str2.equals("arguments"))
            ((FunctionNode)paramNode1).setRequiresActivation(true); 
          variableTable2 = getVariableTable(paramNode1);
          if (variableTable2.get(str2) != null) {
            if (i == 10) {
              node.setType(73);
              node1.setType(46);
              continue;
            } 
            Node node10 = new Node(108, 
                new Integer(51));
            preorderNodeIterator.replaceCurrent(node10);
          } 
        case 39:
          if (this.inFunction) {
            node1 = node.getFirstChild().getNextSibling();
            str2 = (node1 == null) ? "" : node1.getString();
            if (str2.equals("arguments") || (
              str2.equals("length") && 
              Context.getContext().getLanguageVersion() == 
              120))
              ((FunctionNode)paramNode1).setRequiresActivation(true); 
          } 
        case 44:
          if (!this.inFunction || inWithStatement())
            continue; 
          str1 = node.getString();
          if (str1.equals("arguments"))
            ((FunctionNode)paramNode1).setRequiresActivation(true); 
          variableTable1 = getVariableTable(paramNode1);
          if (variableTable1.get(str1) != null)
            node.setType(72); 
      } 
    } 
    return paramNode1;
  }
  
  protected void addVariables(Node paramNode, VariableTable paramVariableTable) {
    boolean bool = (paramNode.getType() != 109) ? 0 : 1;
    PreorderNodeIterator preorderNodeIterator = paramNode.getPreorderIterator();
    Hashtable hashtable = null;
    Node node;
    while ((node = preorderNodeIterator.nextNode()) != null) {
      int i = node.getType();
      if (bool && i == 109 && 
        node != paramNode) {
        String str = node.getString();
        if (str != null) {
          paramVariableTable.removeLocal(str);
          if (hashtable == null)
            hashtable = new Hashtable(); 
          hashtable.put(str, Boolean.TRUE);
        } else {
          continue;
        } 
      } 
      if (i == 122) {
        ShallowNodeIterator shallowNodeIterator = node.getChildIterator();
        while (shallowNodeIterator.hasMoreElements()) {
          Node node1 = shallowNodeIterator.nextNode();
          if (hashtable == null || hashtable.get(node1.getString()) == null)
            paramVariableTable.addLocal(node1.getString()); 
        } 
      } 
    } 
  }
  
  protected void addParameters(FunctionNode paramFunctionNode) {
    VariableTable variableTable = paramFunctionNode.getVariableTable();
    Node node = paramFunctionNode.getFirstChild();
    if (node.getType() == 93 && variableTable.getParameterCount() == 0) {
      ShallowNodeIterator shallowNodeIterator = node.getChildIterator();
      while (shallowNodeIterator.hasMoreElements()) {
        Node node1 = shallowNodeIterator.nextNode();
        String str = node1.getString();
        variableTable.addParameter(str);
      } 
    } 
  }
  
  protected void visitNew(Node paramNode1, Node paramNode2) {}
  
  protected void visitCall(Node paramNode1, Node paramNode2) {
    Node node1 = paramNode1.getFirstChild();
    byte b = 0;
    Node node2 = node1.getNextSibling();
    while (node2 != null) {
      node2 = node2.getNextSibling();
      b++;
    } 
    boolean bool = false;
    if (node1.getType() == 44) {
      VariableTable variableTable = getVariableTable(paramNode2);
      String str = node1.getString();
      if (this.inFunction && variableTable.get(str) != null && !inWithStatement()) {
        node1.setType(72);
      } else {
        paramNode1.removeChild(node1);
        node1.setType(71);
        Node node6 = node1.cloneNode();
        node6.setType(46);
        Node node7 = new Node(39, node1, node6);
        paramNode1.addChildToFront(node7);
        node1 = node7;
        bool = (!inWithStatement() && this.inFunction) ? 0 : 1;
      } 
    } 
    if (node1.getType() != 39 && 
      node1.getType() != 41) {
      paramNode1.removeChild(node1);
      Node node6 = this.irFactory.createNewTemp(node1);
      Node node7 = this.irFactory.createUseTemp(node6);
      node7.putProp(6, node6);
      Node node8 = new Node(140, node7);
      paramNode1.addChildToFront(node8);
      paramNode1.addChildToFront(node6);
      return;
    } 
    Node node3 = node1.getFirstChild();
    node1.removeChild(node3);
    Node node4 = this.irFactory.createNewTemp(node3);
    node1.addChildToFront(node4);
    Node node5 = this.irFactory.createUseTemp(node4);
    node5.putProp(6, node4);
    if (bool)
      node5 = new Node(68, node5); 
    paramNode1.addChildAfter(node5, node1);
  }
  
  protected boolean inWithStatement() {
    for (int i = this.loops.size() - 1; i >= 0; i--) {
      Node node = (Node)this.loops.elementAt(i);
      if (node.getType() == 123)
        return true; 
    } 
    return false;
  }
  
  private boolean isSpecialCallName(Node paramNode1, Node paramNode2) {
    Node node = paramNode2.getFirstChild();
    boolean bool = false;
    if (node.getType() == 44) {
      String str = node.getString();
      bool = !(!str.equals("eval") && !str.equals("With"));
    } else if (node.getType() == 39) {
      String str = node.getLastChild().getString();
      bool = str.equals("exec");
    } 
    if (bool) {
      if (this.inFunction)
        ((FunctionNode)paramNode1).setRequiresActivation(true); 
      return true;
    } 
    return false;
  }
  
  protected VariableTable createVariableTable() { return new VariableTable(); }
  
  protected VariableTable getVariableTable(Node paramNode) {
    if (this.inFunction)
      return ((FunctionNode)paramNode).getVariableTable(); 
    VariableTable variableTable = (VariableTable)paramNode.getProp(10);
    if (variableTable == null) {
      variableTable = createVariableTable();
      paramNode.putProp(10, variableTable);
    } 
    return variableTable;
  }
  
  protected void reportMessage(Context paramContext, String paramString, Node paramNode1, Node paramNode2, boolean paramBoolean, Scriptable paramScriptable) {
    Object object1 = paramNode1.getDatum();
    int i = 0;
    if (object1 != null && object1 instanceof Integer)
      i = ((Integer)object1).intValue(); 
    Object object2 = (paramNode2 == null) ? 
      null : 
      paramNode2.getProp(16);
    if (paramBoolean) {
      if (paramScriptable != null)
        throw NativeGlobal.constructError(
            paramContext, "SyntaxError", paramString, paramScriptable, 
            (String)object2, i, 0, null); 
      Context.reportError(paramString, (String)object2, i, null, 0);
    } else {
      Context.reportWarning(paramString, (String)object2, i, null, 0);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NodeTransformer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */