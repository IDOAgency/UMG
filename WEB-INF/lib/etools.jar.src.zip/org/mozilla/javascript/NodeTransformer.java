/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.Stack;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NodeTransformer
/*     */ {
/*     */   protected Stack loops;
/*     */   protected Stack loopEnds;
/*     */   protected boolean inFunction;
/*     */   protected IRFactory irFactory;
/*     */   
/*  58 */   public NodeTransformer newInstance() { return new NodeTransformer(); }
/*     */ 
/*     */ 
/*     */   
/*  62 */   public IRFactory createIRFactory(TokenStream paramTokenStream, Scriptable paramScriptable) { return new IRFactory(paramTokenStream, paramScriptable); }
/*     */ 
/*     */ 
/*     */   
/*     */   public Node transform(Node paramNode1, Node paramNode2, TokenStream paramTokenStream, Scriptable paramScriptable) {
/*  67 */     this.loops = new Stack();
/*  68 */     this.loopEnds = new Stack();
/*  69 */     this.inFunction = !(paramNode1.getType() != 109);
/*  70 */     if (!this.inFunction) {
/*  71 */       addVariables(paramNode1, getVariableTable(paramNode1));
/*     */     }
/*  73 */     this.irFactory = createIRFactory(paramTokenStream, paramScriptable);
/*     */ 
/*     */     
/*  76 */     boolean bool = false;
/*     */     
/*  78 */     PreorderNodeIterator preorderNodeIterator = paramNode1.getPreorderIterator();
/*     */     Node node;
/*  80 */     label242: while ((node = preorderNodeIterator.nextNode()) != null) {
/*  81 */       Node node9; byte b; Node node8, node7, node6; int k; VariableTable variableTable2; Vector vector2; int j; String str4; Integer integer2; Node node4; boolean bool1; String str3, str2; Node node5; VariableTable variableTable1; NodeTransformer nodeTransformer; Node node1; ShallowNodeIterator shallowNodeIterator; Node node2; Vector vector1; Integer integer1; String str1; Node node3; FunctionNode functionNode; int i = node.getType();
/*     */ 
/*     */       
/*  84 */       switch (i) {
/*     */         
/*     */         case 109:
/*  87 */           if (node == paramNode1) {
/*     */ 
/*     */             
/*  90 */             VariableTable variableTable = getVariableTable(paramNode1);
/*  91 */             addVariables(paramNode1, variableTable);
/*     */ 
/*     */             
/*  94 */             Node node10 = node.getLastChild();
/*  95 */             Node node11 = node10.getLastChild();
/*  96 */             if (node11 == null || 
/*  97 */               node11.getType() != 5)
/*     */             {
/*  99 */               node10.addChildToBack(new Node(5));
/*     */             }
/*     */             continue;
/*     */           } 
/* 103 */           if (this.inFunction)
/*     */           {
/* 105 */             ((FunctionNode)paramNode1).setRequiresActivation(true);
/*     */           }
/* 107 */           functionNode = 
/* 108 */             (FunctionNode)node.getProp(5);
/* 109 */           addParameters(functionNode);
/* 110 */           nodeTransformer = newInstance();
/* 111 */           functionNode = 
/* 112 */             (FunctionNode)nodeTransformer.transform(functionNode, paramNode1, paramTokenStream, paramScriptable);
/* 113 */           node.putProp(5, functionNode);
/* 114 */           vector2 = (Vector)paramNode1.getProp(5);
/* 115 */           if (vector2 == null) {
/* 116 */             vector2 = new Vector(7);
/* 117 */             paramNode1.putProp(5, vector2);
/*     */           } 
/* 119 */           vector2.addElement(functionNode);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 135:
/* 125 */           node3 = node.getFirstChild();
/* 126 */           node.removeChild(node3);
/* 127 */           str3 = node3.getString();
/*     */ 
/*     */           
/* 130 */           for (j = this.loops.size() - 1; j >= 0; j--) {
/* 131 */             Node node10 = (Node)this.loops.elementAt(j);
/* 132 */             if (node10.getType() == 135) {
/* 133 */               String str = (String)node10.getProp(20);
/* 134 */               if (str3.equals(str)) {
/* 135 */                 Object[] arrayOfObject = { str3 };
/* 136 */                 String str5 = Context.getMessage("msg.dup.label", 
/* 137 */                     arrayOfObject);
/* 138 */                 reportMessage(Context.getContext(), str5, node, 
/* 139 */                     paramNode1, true, paramScriptable);
/*     */                 
/*     */                 continue label242;
/*     */               } 
/*     */             } 
/*     */           } 
/* 145 */           node.putProp(20, str3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 151 */           node6 = new Node(136);
/* 152 */           node7 = preorderNodeIterator.getCurrentParent();
/* 153 */           node8 = node.getNextSibling();
/* 154 */           while (node8 != null && (
/* 155 */             node8.getType() == 135 || 
/* 156 */             node8.getType() == 136))
/* 157 */             node8 = node8.getNextSibling(); 
/* 158 */           if (node8 != null) {
/*     */             
/* 160 */             node7.addChildAfter(node6, node8);
/* 161 */             node.putProp(2, node6);
/*     */             
/* 163 */             if (node8.getType() == 137) {
/* 164 */               node.putProp(3, 
/* 165 */                   node8.getProp(3));
/*     */             }
/*     */             
/* 168 */             this.loops.push(node);
/* 169 */             this.loopEnds.push(node6);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 114:
/* 176 */           node3 = new Node(136);
/* 177 */           node5 = preorderNodeIterator.getCurrentParent();
/* 178 */           node5.addChildAfter(node3, node);
/*     */ 
/*     */           
/* 181 */           str4 = node;
/* 182 */           node6 = (node.getFirstChild()).next;
/* 183 */           while (node6 != null) {
/* 184 */             node7 = node6.next;
/* 185 */             node.removeChild(node6);
/* 186 */             node5.addChildAfter(node6, str4);
/* 187 */             str4 = node6;
/* 188 */             node6 = node7;
/*     */           } 
/*     */           
/* 191 */           node.putProp(2, node3);
/* 192 */           this.loops.push(node);
/* 193 */           this.loopEnds.push(node3);
/* 194 */           node.putProp(13, new Vector(13));
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 115:
/*     */         case 116:
/* 201 */           node3 = (Node)this.loops.peek();
/* 202 */           if (i == 115) {
/* 203 */             Vector vector = (Vector)node3.getProp(13);
/* 204 */             vector.addElement(node); continue;
/*     */           } 
/* 206 */           node3.putProp(14, node);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 143:
/* 212 */           integer1 = 
/* 213 */             (Integer)paramNode1.getProp(22);
/* 214 */           if (integer1 == null) {
/* 215 */             paramNode1.putProp(22, new Integer(1));
/*     */             continue;
/*     */           } 
/* 218 */           paramNode1.putProp(22, 
/* 219 */               new Integer(integer1.intValue() + 1));
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 137:
/* 225 */           this.loops.push(node);
/* 226 */           this.loopEnds.push(node.getProp(2));
/*     */ 
/*     */ 
/*     */         
/*     */         case 123:
/* 231 */           if (this.inFunction)
/*     */           {
/* 233 */             ((FunctionNode)paramNode1).setRequiresActivation(true);
/*     */           }
/* 235 */           this.loops.push(node);
/* 236 */           node2 = node.getNextSibling();
/* 237 */           if (node2.getType() != 4) {
/* 238 */             throw new RuntimeException("Unexpected tree");
/*     */           }
/* 240 */           this.loopEnds.push(node2);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 75:
/* 246 */           node2 = (Node)node.getProp(21);
/* 247 */           if (node2 != null) {
/* 248 */             bool = true;
/* 249 */             this.loops.push(node);
/* 250 */             this.loopEnds.push(node2);
/*     */           } 
/* 252 */           integer2 = 
/* 253 */             (Integer)paramNode1.getProp(22);
/* 254 */           if (integer2 == null) {
/* 255 */             paramNode1.putProp(22, new Integer(1));
/*     */             continue;
/*     */           } 
/* 258 */           paramNode1.putProp(22, 
/* 259 */               new Integer(integer2.intValue() + 1));
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 4:
/*     */         case 136:
/* 266 */           if (!this.loopEnds.empty() && this.loopEnds.peek() == node) {
/* 267 */             this.loopEnds.pop();
/* 268 */             this.loops.pop();
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 5:
/* 281 */           if (bool) {
/*     */ 
/*     */             
/* 284 */             node2 = preorderNodeIterator.getCurrentParent();
/* 285 */             for (int m = this.loops.size() - 1; m >= 0; m--) {
/* 286 */               str4 = (Node)this.loops.elementAt(m);
/* 287 */               int n = str4.getType();
/* 288 */               if (n == 75) {
/* 289 */                 node7 = new Node(142);
/* 290 */                 Object object = str4.getProp(21);
/* 291 */                 node7.putProp(1, object);
/* 292 */                 node2.addChildBefore(node7, node);
/* 293 */               } else if (n == 123) {
/* 294 */                 node2.addChildBefore(new Node(4), 
/* 295 */                     node);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */         
/*     */         case 120:
/*     */         case 121:
/* 304 */           node2 = null;
/* 305 */           bool1 = node.hasChildren();
/* 306 */           str4 = null;
/* 307 */           if (bool1) {
/*     */             
/* 309 */             node6 = node.getFirstChild();
/* 310 */             str4 = node6.getString();
/* 311 */             node.removeChild(node6);
/*     */           } 
/*     */ 
/*     */           
/* 315 */           node7 = preorderNodeIterator.getCurrentParent();
/* 316 */           for (k = this.loops.size() - 1; k >= 0; k--) {
/* 317 */             node8 = (Node)this.loops.elementAt(k);
/* 318 */             int m = node8.getType();
/* 319 */             if (m == 123)
/* 320 */             { node7.addChildBefore(new Node(4), 
/* 321 */                   node); }
/* 322 */             else if (m == 75)
/* 323 */             { Node node10 = new Node(142);
/* 324 */               Object object = node8.getProp(21);
/* 325 */               node10.putProp(1, object);
/* 326 */               node7.addChildBefore(node10, node); }
/* 327 */             else { if (!bool1 && (
/* 328 */                 m == 137 || (
/* 329 */                 m == 114 && 
/* 330 */                 i == 120))) {
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 335 */                 node2 = node8; break;
/*     */               } 
/* 337 */               if (bool1 && 
/* 338 */                 m == 135 && 
/* 339 */                 str4.equals((String)node8.getProp(20))) {
/*     */                 
/* 341 */                 node2 = node8; break;
/*     */               }  }
/*     */           
/*     */           } 
/* 345 */           b = (i == 120) ? 
/* 346 */             2 : 
/* 347 */             3;
/* 348 */           node9 = (node2 == null) ? 
/* 349 */             null : 
/* 350 */             (Node)node2.getProp(b);
/* 351 */           if (node2 == null || node9 == null) {
/*     */             String str;
/* 353 */             if (!bool1) {
/*     */               
/* 355 */               if (i == 121) {
/* 356 */                 str = 
/* 357 */                   Context.getMessage("msg.continue.outside", null);
/*     */               } else {
/* 359 */                 str = 
/* 360 */                   Context.getMessage("msg.bad.break", null);
/*     */               } 
/* 362 */             } else if (node2 != null) {
/* 363 */               str = Context.getMessage("msg.continue.nonloop", 
/* 364 */                   null);
/*     */             } else {
/* 366 */               Object[] arrayOfObject = { str4 };
/* 367 */               str = 
/* 368 */                 Context.getMessage("msg.undef.label", arrayOfObject);
/*     */             } 
/* 370 */             reportMessage(Context.getContext(), str, node, 
/* 371 */                 paramNode1, true, paramScriptable);
/* 372 */             node.setType(127);
/*     */             continue;
/*     */           } 
/* 375 */           node.setType(6);
/* 376 */           node.putProp(1, node9);
/*     */ 
/*     */ 
/*     */         
/*     */         case 43:
/* 381 */           if (isSpecialCallName(paramNode1, node))
/* 382 */             node.putProp(30, Boolean.TRUE); 
/* 383 */           visitCall(node, paramNode1);
/*     */ 
/*     */         
/*     */         case 30:
/* 387 */           if (isSpecialCallName(paramNode1, node))
/* 388 */             node.putProp(30, Boolean.TRUE); 
/* 389 */           visitNew(node, paramNode1);
/*     */ 
/*     */ 
/*     */         
/*     */         case 107:
/* 394 */           node2 = node.getLastChild();
/* 395 */           node2.setType(46);
/*     */ 
/*     */ 
/*     */         
/*     */         case 139:
/* 400 */           node.setType(this.inFunction ? 57 : 2);
/*     */ 
/*     */ 
/*     */         
/*     */         case 56:
/* 405 */           vector1 = (Vector)paramNode1.getProp(12);
/* 406 */           if (vector1 == null) {
/* 407 */             vector1 = new Vector(3);
/* 408 */             paramNode1.putProp(12, vector1);
/*     */           } 
/* 410 */           vector1.addElement(node);
/* 411 */           node4 = new Node(56);
/* 412 */           preorderNodeIterator.replaceCurrent(node4);
/* 413 */           node4.putProp(12, node);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 122:
/* 419 */           shallowNodeIterator = node.getChildIterator();
/* 420 */           node4 = new Node(132);
/* 421 */           while (shallowNodeIterator.hasMoreElements()) {
/* 422 */             Node node10 = shallowNodeIterator.nextNode();
/* 423 */             if (node10.hasChildren()) {
/*     */               
/* 425 */               Node node11 = node10.getFirstChild();
/* 426 */               node10.removeChild(node11);
/* 427 */               node7 = (Node)this.irFactory.createAssignment(
/* 428 */                   127, node10, node11, null, 
/* 429 */                   false);
/* 430 */               Node node12 = new Node(57, node7, node.getDatum());
/* 431 */               node4.addChildToBack(node12);
/*     */             } 
/* 433 */           }  preorderNodeIterator.replaceCurrent(node4);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 10:
/*     */         case 31:
/* 440 */           if (!this.inFunction || inWithStatement())
/*     */             continue; 
/* 442 */           node1 = node.getFirstChild();
/* 443 */           if (node1 == null || node1.getType() != 61)
/*     */             continue; 
/* 445 */           str2 = node1.getString();
/* 446 */           if (str2.equals("arguments"))
/*     */           {
/* 448 */             ((FunctionNode)paramNode1).setRequiresActivation(true);
/*     */           }
/* 450 */           variableTable2 = getVariableTable(paramNode1);
/* 451 */           if (variableTable2.get(str2) != null) {
/* 452 */             if (i == 10) {
/* 453 */               node.setType(73);
/* 454 */               node1.setType(46);
/*     */               continue;
/*     */             } 
/* 457 */             Node node10 = new Node(108, 
/* 458 */                 new Integer(51));
/* 459 */             preorderNodeIterator.replaceCurrent(node10);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 39:
/* 466 */           if (this.inFunction) {
/* 467 */             node1 = node.getFirstChild().getNextSibling();
/* 468 */             str2 = (node1 == null) ? "" : node1.getString();
/* 469 */             if (str2.equals("arguments") || (
/* 470 */               str2.equals("length") && 
/* 471 */               Context.getContext().getLanguageVersion() == 
/* 472 */               120))
/*     */             {
/*     */ 
/*     */               
/* 476 */               ((FunctionNode)paramNode1).setRequiresActivation(true);
/*     */             }
/*     */           } 
/*     */ 
/*     */ 
/*     */         
/*     */         case 44:
/* 483 */           if (!this.inFunction || inWithStatement())
/*     */             continue; 
/* 485 */           str1 = node.getString();
/* 486 */           if (str1.equals("arguments"))
/*     */           {
/* 488 */             ((FunctionNode)paramNode1).setRequiresActivation(true);
/*     */           }
/* 490 */           variableTable1 = getVariableTable(paramNode1);
/* 491 */           if (variableTable1.get(str1) != null) {
/* 492 */             node.setType(72);
/*     */           }
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 499 */     return paramNode1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addVariables(Node paramNode, VariableTable paramVariableTable) {
/* 505 */     boolean bool = (paramNode.getType() != 109) ? 0 : 1;
/* 506 */     PreorderNodeIterator preorderNodeIterator = paramNode.getPreorderIterator();
/* 507 */     Hashtable hashtable = null;
/*     */     Node node;
/* 509 */     while ((node = preorderNodeIterator.nextNode()) != null) {
/* 510 */       int i = node.getType();
/* 511 */       if (bool && i == 109 && 
/* 512 */         node != paramNode) {
/*     */ 
/*     */ 
/*     */         
/* 516 */         String str = node.getString();
/* 517 */         if (str != null)
/*     */         
/* 519 */         { paramVariableTable.removeLocal(str);
/* 520 */           if (hashtable == null)
/* 521 */             hashtable = new Hashtable(); 
/* 522 */           hashtable.put(str, Boolean.TRUE); } else { continue; }
/*     */       
/* 524 */       }  if (i == 122) {
/*     */         
/* 526 */         ShallowNodeIterator shallowNodeIterator = node.getChildIterator();
/* 527 */         while (shallowNodeIterator.hasMoreElements()) {
/* 528 */           Node node1 = shallowNodeIterator.nextNode();
/* 529 */           if (hashtable == null || hashtable.get(node1.getString()) == null)
/* 530 */             paramVariableTable.addLocal(node1.getString()); 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   protected void addParameters(FunctionNode paramFunctionNode) {
/* 536 */     VariableTable variableTable = paramFunctionNode.getVariableTable();
/* 537 */     Node node = paramFunctionNode.getFirstChild();
/* 538 */     if (node.getType() == 93 && variableTable.getParameterCount() == 0) {
/*     */ 
/*     */       
/* 541 */       ShallowNodeIterator shallowNodeIterator = node.getChildIterator();
/* 542 */       while (shallowNodeIterator.hasMoreElements()) {
/* 543 */         Node node1 = shallowNodeIterator.nextNode();
/* 544 */         String str = node1.getString();
/* 545 */         variableTable.addParameter(str);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void visitNew(Node paramNode1, Node paramNode2) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void visitCall(Node paramNode1, Node paramNode2) {
/* 570 */     Node node1 = paramNode1.getFirstChild();
/*     */     
/* 572 */     byte b = 0;
/* 573 */     Node node2 = node1.getNextSibling();
/* 574 */     while (node2 != null) {
/* 575 */       node2 = node2.getNextSibling();
/* 576 */       b++;
/*     */     } 
/* 578 */     boolean bool = false;
/* 579 */     if (node1.getType() == 44) {
/* 580 */       VariableTable variableTable = getVariableTable(paramNode2);
/* 581 */       String str = node1.getString();
/* 582 */       if (this.inFunction && variableTable.get(str) != null && !inWithStatement()) {
/*     */         
/* 584 */         node1.setType(72);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 589 */         paramNode1.removeChild(node1);
/* 590 */         node1.setType(71);
/* 591 */         Node node6 = node1.cloneNode();
/* 592 */         node6.setType(46);
/* 593 */         Node node7 = new Node(39, node1, node6);
/* 594 */         paramNode1.addChildToFront(node7);
/* 595 */         node1 = node7;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 606 */         bool = (!inWithStatement() && this.inFunction) ? 0 : 1;
/*     */       } 
/*     */     } 
/*     */     
/* 610 */     if (node1.getType() != 39 && 
/* 611 */       node1.getType() != 41) {
/*     */       
/* 613 */       paramNode1.removeChild(node1);
/* 614 */       Node node6 = this.irFactory.createNewTemp(node1);
/* 615 */       Node node7 = this.irFactory.createUseTemp(node6);
/* 616 */       node7.putProp(6, node6);
/* 617 */       Node node8 = new Node(140, node7);
/* 618 */       paramNode1.addChildToFront(node8);
/* 619 */       paramNode1.addChildToFront(node6);
/*     */       return;
/*     */     } 
/* 622 */     Node node3 = node1.getFirstChild();
/* 623 */     node1.removeChild(node3);
/* 624 */     Node node4 = this.irFactory.createNewTemp(node3);
/* 625 */     node1.addChildToFront(node4);
/* 626 */     Node node5 = this.irFactory.createUseTemp(node4);
/* 627 */     node5.putProp(6, node4);
/* 628 */     if (bool)
/* 629 */       node5 = new Node(68, node5); 
/* 630 */     paramNode1.addChildAfter(node5, node1);
/*     */   }
/*     */   
/*     */   protected boolean inWithStatement() {
/* 634 */     for (int i = this.loops.size() - 1; i >= 0; i--) {
/* 635 */       Node node = (Node)this.loops.elementAt(i);
/* 636 */       if (node.getType() == 123)
/* 637 */         return true; 
/*     */     } 
/* 639 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSpecialCallName(Node paramNode1, Node paramNode2) {
/* 647 */     Node node = paramNode2.getFirstChild();
/* 648 */     boolean bool = false;
/* 649 */     if (node.getType() == 44) {
/* 650 */       String str = node.getString();
/* 651 */       bool = !(!str.equals("eval") && !str.equals("With"));
/*     */     }
/* 653 */     else if (node.getType() == 39) {
/* 654 */       String str = node.getLastChild().getString();
/* 655 */       bool = str.equals("exec");
/*     */     } 
/*     */     
/* 658 */     if (bool) {
/*     */       
/* 660 */       if (this.inFunction)
/* 661 */         ((FunctionNode)paramNode1).setRequiresActivation(true); 
/* 662 */       return true;
/*     */     } 
/* 664 */     return false;
/*     */   }
/*     */ 
/*     */   
/* 668 */   protected VariableTable createVariableTable() { return new VariableTable(); }
/*     */ 
/*     */   
/*     */   protected VariableTable getVariableTable(Node paramNode) {
/* 672 */     if (this.inFunction) {
/* 673 */       return ((FunctionNode)paramNode).getVariableTable();
/*     */     }
/* 675 */     VariableTable variableTable = (VariableTable)paramNode.getProp(10);
/* 676 */     if (variableTable == null) {
/* 677 */       variableTable = createVariableTable();
/* 678 */       paramNode.putProp(10, variableTable);
/*     */     } 
/* 680 */     return variableTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportMessage(Context paramContext, String paramString, Node paramNode1, Node paramNode2, boolean paramBoolean, Scriptable paramScriptable) {
/* 687 */     Object object1 = paramNode1.getDatum();
/* 688 */     int i = 0;
/* 689 */     if (object1 != null && object1 instanceof Integer)
/* 690 */       i = ((Integer)object1).intValue(); 
/* 691 */     Object object2 = (paramNode2 == null) ? 
/* 692 */       null : 
/* 693 */       paramNode2.getProp(16);
/* 694 */     if (paramBoolean) {
/* 695 */       if (paramScriptable != null) {
/* 696 */         throw NativeGlobal.constructError(
/* 697 */             paramContext, "SyntaxError", paramString, paramScriptable, 
/* 698 */             (String)object2, i, 0, null);
/*     */       }
/* 700 */       Context.reportError(paramString, (String)object2, i, null, 0);
/*     */     } else {
/*     */       
/* 703 */       Context.reportWarning(paramString, (String)object2, i, null, 0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NodeTransformer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */