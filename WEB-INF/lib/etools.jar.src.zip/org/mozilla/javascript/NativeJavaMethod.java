/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeJavaMethod
/*     */   extends NativeFunction
/*     */   implements Function
/*     */ {
/*     */   static final int PREFERENCE_EQUAL = 0;
/*     */   static final int PREFERENCE_FIRST_ARG = 1;
/*     */   static final int PREFERENCE_SECOND_ARG = 2;
/*     */   static final int PREFERENCE_AMBIGUOUS = 3;
/*     */   private static final boolean debug = false;
/*     */   Method[] methods;
/*     */   
/*  58 */   public NativeJavaMethod() { this.names = new String[1]; }
/*     */ 
/*     */   
/*     */   public NativeJavaMethod(Method[] paramArrayOfMethod) {
/*  62 */     this.methods = paramArrayOfMethod;
/*  63 */     this.names = new String[1];
/*  64 */     this.names[0] = paramArrayOfMethod[0].getName();
/*     */   }
/*     */   
/*     */   public NativeJavaMethod(Method paramMethod, String paramString) {
/*  68 */     this.methods = new Method[1];
/*  69 */     this.methods[0] = paramMethod;
/*  70 */     this.names = new String[1];
/*  71 */     this.names[0] = paramString;
/*     */   }
/*     */   
/*     */   public void add(Method paramMethod) {
/*  75 */     if (this.names[false] == null) {
/*  76 */       this.names[0] = paramMethod.getName();
/*  77 */     } else if (!this.names[0].equals(paramMethod.getName())) {
/*  78 */       throw new RuntimeException("internal method name mismatch");
/*     */     } 
/*     */     
/*  81 */     boolean bool = (this.methods == null) ? 0 : this.methods.length;
/*  82 */     Method[] arrayOfMethod = new Method[bool + true];
/*  83 */     for (byte b = 0; b < bool; b++)
/*  84 */       arrayOfMethod[b] = this.methods[b]; 
/*  85 */     arrayOfMethod[bool] = paramMethod;
/*  86 */     this.methods = arrayOfMethod;
/*     */   }
/*     */   
/*     */   static String scriptSignature(Object paramObject) {
/*  90 */     if (paramObject == null) {
/*  91 */       return "null";
/*     */     }
/*     */     
/*  94 */     Class clazz = paramObject.getClass();
/*  95 */     if (clazz == ScriptRuntime.UndefinedClass)
/*  96 */       return "undefined"; 
/*  97 */     if (clazz == ScriptRuntime.BooleanClass)
/*  98 */       return "boolean"; 
/*  99 */     if (clazz == ScriptRuntime.StringClass)
/* 100 */       return "string"; 
/* 101 */     if (ScriptRuntime.NumberClass.isAssignableFrom(clazz))
/* 102 */       return "number"; 
/* 103 */     if (paramObject instanceof NativeJavaObject) {
/* 104 */       return ((NativeJavaObject)paramObject).unwrap().getClass().getName();
/*     */     }
/* 106 */     if (paramObject instanceof Scriptable) {
/* 107 */       if (paramObject instanceof Function)
/* 108 */         return "function"; 
/* 109 */       return "object";
/*     */     } 
/* 111 */     return javaSignature(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   static String scriptSignature(Object[] paramArrayOfObject) {
/* 116 */     StringBuffer stringBuffer = new StringBuffer();
/* 117 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 118 */       if (b)
/* 119 */         stringBuffer.append(','); 
/* 120 */       stringBuffer.append(scriptSignature(paramArrayOfObject[b]));
/*     */     } 
/* 122 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   static String javaSignature(Class paramClass) {
/* 126 */     if (paramClass == null) {
/* 127 */       return "null";
/*     */     }
/* 129 */     if (paramClass.isArray()) {
/* 130 */       return String.valueOf(javaSignature(paramClass.getComponentType())) + "[]";
/*     */     }
/* 132 */     return paramClass.getName();
/*     */   }
/*     */   
/*     */   static String javaSignature(Class[] paramArrayOfClass) {
/* 136 */     StringBuffer stringBuffer = new StringBuffer();
/* 137 */     for (byte b = 0; b < paramArrayOfClass.length; b++) {
/* 138 */       if (b)
/* 139 */         stringBuffer.append(','); 
/* 140 */       stringBuffer.append(javaSignature(paramArrayOfClass[b]));
/*     */     } 
/* 142 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static String signature(Member paramMember) {
/* 148 */     if (paramMember instanceof Method) {
/* 149 */       Class[] arrayOfClass1 = ((Method)paramMember).getParameterTypes();
/* 150 */       return String.valueOf(paramMember.getName()) + "(" + javaSignature(arrayOfClass1) + ")";
/*     */     } 
/*     */     
/* 153 */     Class[] arrayOfClass = ((Constructor)paramMember).getParameterTypes();
/* 154 */     return "(" + javaSignature(arrayOfClass) + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 159 */     StringBuffer stringBuffer = new StringBuffer();
/* 160 */     for (byte b = 0; b < this.methods.length; b++) {
/* 161 */       stringBuffer.append(javaSignature(this.methods[b].getReturnType()));
/* 162 */       stringBuffer.append(' ');
/* 163 */       stringBuffer.append(signature(this.methods[b]));
/* 164 */       stringBuffer.append('\n');
/*     */     } 
/* 166 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException {
/*     */     Object object;
/* 174 */     if (this.methods.length == 0) {
/* 175 */       throw new RuntimeException("No methods defined for call");
/*     */     }
/*     */     
/* 178 */     Method method = (Method)findFunction(this.methods, paramArrayOfObject);
/* 179 */     if (method == null) {
/* 180 */       Class clazz = this.methods[0].getDeclaringClass();
/* 181 */       String str = String.valueOf(clazz.getName()) + "." + this.names[0] + "(" + 
/* 182 */         scriptSignature(paramArrayOfObject) + ")";
/* 183 */       object = new Object[] { str };
/* 184 */       throw Context.reportRuntimeError(
/* 185 */           Context.getMessage("msg.java.no_such_method", object));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 190 */     Class[] arrayOfClass = method.getParameterTypes();
/*     */ 
/*     */     
/* 193 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 194 */       paramArrayOfObject[b] = NativeJavaObject.coerceType(arrayOfClass[b], paramArrayOfObject[b]);
/*     */     }
/*     */     
/* 197 */     if (Modifier.isStatic(method.getModifiers())) {
/* 198 */       object = null;
/*     */     } else {
/* 200 */       Scriptable scriptable = paramScriptable2;
/* 201 */       while (!(scriptable instanceof NativeJavaObject)) {
/* 202 */         scriptable = scriptable.getPrototype();
/* 203 */         if (scriptable == null) {
/* 204 */           Object[] arrayOfObject = { this.names[0] };
/* 205 */           throw Context.reportRuntimeError(
/* 206 */               Context.getMessage("msg.nonjava.method", arrayOfObject));
/*     */         } 
/*     */       } 
/* 209 */       object = ((NativeJavaObject)scriptable).unwrap();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 216 */       Object object1 = method.invoke(object, paramArrayOfObject);
/* 217 */       Class clazz = method.getReturnType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 226 */       Object object2 = NativeJavaObject.wrap(paramScriptable1, object1, clazz);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 234 */       if (object2 == Undefined.instance)
/* 235 */         return object2; 
/* 236 */       if (object2 == null && clazz == void.class)
/* 237 */         return Undefined.instance; 
/* 238 */       return object2;
/* 239 */     } catch (IllegalAccessException illegalAccessException) {
/* 240 */       throw Context.reportRuntimeError(illegalAccessException.getMessage());
/* 241 */     } catch (InvocationTargetException invocationTargetException) {
/* 242 */       throw JavaScriptException.wrapException(paramScriptable1, invocationTargetException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Member findFunction(Member[] paramArrayOfMember, Object[] paramArrayOfObject) {
/* 252 */     if (paramArrayOfMember.length == 0)
/* 253 */       return null; 
/* 254 */     boolean bool = paramArrayOfMember[0] instanceof Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 273 */     Member member = null;
/* 274 */     Class[] arrayOfClass = null;
/*     */     
/* 276 */     Vector vector = null;
/*     */     
/* 278 */     for (byte b = 0; b < paramArrayOfMember.length; b++) {
/* 279 */       Member member1 = paramArrayOfMember[b];
/* 280 */       Class[] arrayOfClass1 = bool ? (
/* 281 */         (Method)member1).getParameterTypes() : (
/* 282 */         (Constructor)member1).getParameterTypes();
/* 283 */       if (arrayOfClass1.length == paramArrayOfObject.length)
/*     */       {
/*     */         
/* 286 */         if (arrayOfClass == null) {
/*     */           byte b1;
/* 288 */           for (b1 = 0; b1 < arrayOfClass1.length && 
/* 289 */             NativeJavaObject.canConvert(paramArrayOfObject[b1], arrayOfClass1[b1]); b1++);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 295 */           if (b1 == arrayOfClass1.length) {
/*     */             
/* 297 */             member = member1;
/* 298 */             arrayOfClass = arrayOfClass1;
/*     */           } 
/*     */         } else {
/*     */           
/* 302 */           int j = 
/* 303 */             preferSignature(paramArrayOfObject, 
/* 304 */               arrayOfClass1, 
/* 305 */               arrayOfClass);
/* 306 */           if (j == 3) {
/*     */ 
/*     */             
/* 309 */             if (vector == null)
/* 310 */               vector = new Vector(); 
/* 311 */             vector.addElement(member1);
/*     */           }
/* 313 */           else if (j == 1) {
/*     */             
/* 315 */             member = member1;
/* 316 */             arrayOfClass = arrayOfClass1;
/*     */           
/*     */           }
/* 319 */           else if (j == 0 && 
/* 320 */             Modifier.isStatic(member.getModifiers()) && 
/* 321 */             member.getDeclaringClass().isAssignableFrom(
/* 322 */               member1.getDeclaringClass())) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 330 */             member = member1;
/* 331 */             arrayOfClass = arrayOfClass1;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 339 */     if (vector == null) {
/* 340 */       return member;
/*     */     }
/*     */ 
/*     */     
/* 344 */     for (int i = vector.size() - 1; i >= 0; i--) {
/* 345 */       Member member1 = (Member)vector.elementAt(i);
/* 346 */       Class[] arrayOfClass1 = bool ? (
/* 347 */         (Method)member1).getParameterTypes() : (
/* 348 */         (Constructor)member1).getParameterTypes();
/* 349 */       int j = 
/* 350 */         preferSignature(paramArrayOfObject, 
/* 351 */           arrayOfClass1, 
/* 352 */           arrayOfClass);
/*     */       
/* 354 */       if (j == 1) {
/*     */         
/* 356 */         member = member1;
/* 357 */         arrayOfClass = arrayOfClass1;
/* 358 */         vector.removeElementAt(i);
/*     */       }
/* 360 */       else if (j == 2) {
/*     */         
/* 362 */         vector.removeElementAt(i);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 369 */     if (vector.size() > 0) {
/*     */       String str;
/* 371 */       StringBuffer stringBuffer = new StringBuffer();
/* 372 */       boolean bool1 = member instanceof Constructor;
/*     */       
/* 374 */       vector.addElement(member);
/*     */       
/* 376 */       for (byte b1 = 0; b1 < vector.size(); b1++) {
/* 377 */         if (b1) {
/* 378 */           stringBuffer.append(", ");
/*     */         }
/* 380 */         str = (Member)vector.elementAt(b1);
/* 381 */         if (!bool1) {
/* 382 */           Class clazz = ((Method)str).getReturnType();
/* 383 */           stringBuffer.append(clazz);
/* 384 */           stringBuffer.append(' ');
/*     */         } 
/* 386 */         stringBuffer.append(signature(str));
/*     */       } 
/*     */ 
/*     */       
/* 390 */       if (bool1) {
/* 391 */         Object[] arrayOfObject = {
/* 392 */             member.getName(), 
/* 393 */             scriptSignature(paramArrayOfObject), 
/* 394 */             stringBuffer.toString()
/*     */           };
/* 396 */         str = 
/* 397 */           Context.getMessage("msg.constructor.ambiguous", arrayOfObject);
/*     */       } else {
/*     */         
/* 400 */         Object[] arrayOfObject = {
/* 401 */             member.getDeclaringClass().getName(), 
/* 402 */             member.getName(), 
/* 403 */             scriptSignature(paramArrayOfObject), 
/* 404 */             stringBuffer.toString()
/*     */           };
/* 406 */         str = Context.getMessage("msg.method.ambiguous", arrayOfObject);
/*     */       } 
/*     */ 
/*     */       
/* 410 */       throw Context.reportRuntimeError(str);
/*     */     } 
/*     */     
/* 413 */     return member;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int preferSignature(Object[] paramArrayOfObject, Class[] paramArrayOfClass1, Class[] paramArrayOfClass2) {
/* 431 */     int i = 0;
/*     */     
/* 433 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/* 434 */       Class clazz1 = paramArrayOfClass1[b];
/* 435 */       Class clazz2 = paramArrayOfClass2[b];
/*     */       
/* 437 */       if (clazz1 != clazz2) {
/*     */ 
/*     */ 
/*     */         
/* 441 */         i |= 
/* 442 */           preferConversion(paramArrayOfObject[b], 
/* 443 */             clazz1, 
/* 444 */             clazz2);
/*     */         
/* 446 */         if (i == 3)
/*     */           break; 
/*     */       } 
/*     */     } 
/* 450 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int preferConversion(Object paramObject, Class paramClass1, Class paramClass2) {
/* 462 */     int i = 
/* 463 */       NativeJavaObject.getConversionWeight(paramObject, paramClass1);
/* 464 */     int j = 
/* 465 */       NativeJavaObject.getConversionWeight(paramObject, paramClass2);
/*     */     
/* 467 */     if (i == 0 && 
/* 468 */       j == 0) {
/*     */       
/* 470 */       if (paramClass1.isAssignableFrom(paramClass2)) {
/* 471 */         return 2;
/*     */       }
/* 473 */       if (paramClass2.isAssignableFrom(paramClass1)) {
/* 474 */         return 1;
/*     */       }
/*     */     } else {
/*     */       
/* 478 */       if (i < j) {
/* 479 */         return 1;
/*     */       }
/* 481 */       if (i > j) {
/* 482 */         return 2;
/*     */       }
/*     */     } 
/* 485 */     return 3;
/*     */   }
/*     */ 
/*     */   
/* 489 */   Method[] getMethods() { return this.methods; }
/*     */   
/*     */   private static void printDebug(String paramString, Member paramMember, Object[] paramArrayOfObject) {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeJavaMethod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */