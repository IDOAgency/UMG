package org.mozilla.javascript;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Vector;

public class NativeJavaMethod extends NativeFunction implements Function {
  static final int PREFERENCE_EQUAL = 0;
  
  static final int PREFERENCE_FIRST_ARG = 1;
  
  static final int PREFERENCE_SECOND_ARG = 2;
  
  static final int PREFERENCE_AMBIGUOUS = 3;
  
  private static final boolean debug = false;
  
  Method[] methods;
  
  public NativeJavaMethod() { this.names = new String[1]; }
  
  public NativeJavaMethod(Method[] paramArrayOfMethod) {
    this.methods = paramArrayOfMethod;
    this.names = new String[1];
    this.names[0] = paramArrayOfMethod[0].getName();
  }
  
  public NativeJavaMethod(Method paramMethod, String paramString) {
    this.methods = new Method[1];
    this.methods[0] = paramMethod;
    this.names = new String[1];
    this.names[0] = paramString;
  }
  
  public void add(Method paramMethod) {
    if (this.names[false] == null) {
      this.names[0] = paramMethod.getName();
    } else if (!this.names[0].equals(paramMethod.getName())) {
      throw new RuntimeException("internal method name mismatch");
    } 
    boolean bool = (this.methods == null) ? 0 : this.methods.length;
    Method[] arrayOfMethod = new Method[bool + true];
    for (byte b = 0; b < bool; b++)
      arrayOfMethod[b] = this.methods[b]; 
    arrayOfMethod[bool] = paramMethod;
    this.methods = arrayOfMethod;
  }
  
  static String scriptSignature(Object paramObject) {
    if (paramObject == null)
      return "null"; 
    Class clazz = paramObject.getClass();
    if (clazz == ScriptRuntime.UndefinedClass)
      return "undefined"; 
    if (clazz == ScriptRuntime.BooleanClass)
      return "boolean"; 
    if (clazz == ScriptRuntime.StringClass)
      return "string"; 
    if (ScriptRuntime.NumberClass.isAssignableFrom(clazz))
      return "number"; 
    if (paramObject instanceof NativeJavaObject)
      return ((NativeJavaObject)paramObject).unwrap().getClass().getName(); 
    if (paramObject instanceof Scriptable) {
      if (paramObject instanceof Function)
        return "function"; 
      return "object";
    } 
    return javaSignature(clazz);
  }
  
  static String scriptSignature(Object[] paramArrayOfObject) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramArrayOfObject.length; b++) {
      if (b)
        stringBuffer.append(','); 
      stringBuffer.append(scriptSignature(paramArrayOfObject[b]));
    } 
    return stringBuffer.toString();
  }
  
  static String javaSignature(Class paramClass) {
    if (paramClass == null)
      return "null"; 
    if (paramClass.isArray())
      return String.valueOf(javaSignature(paramClass.getComponentType())) + "[]"; 
    return paramClass.getName();
  }
  
  static String javaSignature(Class[] paramArrayOfClass) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramArrayOfClass.length; b++) {
      if (b)
        stringBuffer.append(','); 
      stringBuffer.append(javaSignature(paramArrayOfClass[b]));
    } 
    return stringBuffer.toString();
  }
  
  static String signature(Member paramMember) {
    if (paramMember instanceof Method) {
      Class[] arrayOfClass1 = ((Method)paramMember).getParameterTypes();
      return String.valueOf(paramMember.getName()) + "(" + javaSignature(arrayOfClass1) + ")";
    } 
    Class[] arrayOfClass = ((Constructor)paramMember).getParameterTypes();
    return "(" + javaSignature(arrayOfClass) + ")";
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < this.methods.length; b++) {
      stringBuffer.append(javaSignature(this.methods[b].getReturnType()));
      stringBuffer.append(' ');
      stringBuffer.append(signature(this.methods[b]));
      stringBuffer.append('\n');
    } 
    return stringBuffer.toString();
  }
  
  public Object call(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject) throws JavaScriptException {
    Object object;
    if (this.methods.length == 0)
      throw new RuntimeException("No methods defined for call"); 
    Method method = (Method)findFunction(this.methods, paramArrayOfObject);
    if (method == null) {
      Class clazz = this.methods[0].getDeclaringClass();
      String str = String.valueOf(clazz.getName()) + "." + this.names[0] + "(" + 
        scriptSignature(paramArrayOfObject) + ")";
      object = new Object[] { str };
      throw Context.reportRuntimeError(
          Context.getMessage("msg.java.no_such_method", object));
    } 
    Class[] arrayOfClass = method.getParameterTypes();
    for (byte b = 0; b < paramArrayOfObject.length; b++)
      paramArrayOfObject[b] = NativeJavaObject.coerceType(arrayOfClass[b], paramArrayOfObject[b]); 
    if (Modifier.isStatic(method.getModifiers())) {
      object = null;
    } else {
      Scriptable scriptable = paramScriptable2;
      while (!(scriptable instanceof NativeJavaObject)) {
        scriptable = scriptable.getPrototype();
        if (scriptable == null) {
          Object[] arrayOfObject = { this.names[0] };
          throw Context.reportRuntimeError(
              Context.getMessage("msg.nonjava.method", arrayOfObject));
        } 
      } 
      object = ((NativeJavaObject)scriptable).unwrap();
    } 
    try {
      Object object1 = method.invoke(object, paramArrayOfObject);
      Class clazz = method.getReturnType();
      Object object2 = NativeJavaObject.wrap(paramScriptable1, object1, clazz);
      if (object2 == Undefined.instance)
        return object2; 
      if (object2 == null && clazz == void.class)
        return Undefined.instance; 
      return object2;
    } catch (IllegalAccessException illegalAccessException) {
      throw Context.reportRuntimeError(illegalAccessException.getMessage());
    } catch (InvocationTargetException invocationTargetException) {
      throw JavaScriptException.wrapException(paramScriptable1, invocationTargetException);
    } 
  }
  
  static Member findFunction(Member[] paramArrayOfMember, Object[] paramArrayOfObject) {
    if (paramArrayOfMember.length == 0)
      return null; 
    boolean bool = paramArrayOfMember[0] instanceof Method;
    Member member = null;
    Class[] arrayOfClass = null;
    Vector vector = null;
    for (byte b = 0; b < paramArrayOfMember.length; b++) {
      Member member1 = paramArrayOfMember[b];
      Class[] arrayOfClass1 = bool ? (
        (Method)member1).getParameterTypes() : (
        (Constructor)member1).getParameterTypes();
      if (arrayOfClass1.length == paramArrayOfObject.length)
        if (arrayOfClass == null) {
          byte b1;
          for (b1 = 0; b1 < arrayOfClass1.length && 
            NativeJavaObject.canConvert(paramArrayOfObject[b1], arrayOfClass1[b1]); b1++);
          if (b1 == arrayOfClass1.length) {
            member = member1;
            arrayOfClass = arrayOfClass1;
          } 
        } else {
          int j = 
            preferSignature(paramArrayOfObject, 
              arrayOfClass1, 
              arrayOfClass);
          if (j == 3) {
            if (vector == null)
              vector = new Vector(); 
            vector.addElement(member1);
          } else if (j == 1) {
            member = member1;
            arrayOfClass = arrayOfClass1;
          } else if (j == 0 && 
            Modifier.isStatic(member.getModifiers()) && 
            member.getDeclaringClass().isAssignableFrom(
              member1.getDeclaringClass())) {
            member = member1;
            arrayOfClass = arrayOfClass1;
          } 
        }  
    } 
    if (vector == null)
      return member; 
    for (int i = vector.size() - 1; i >= 0; i--) {
      Member member1 = (Member)vector.elementAt(i);
      Class[] arrayOfClass1 = bool ? (
        (Method)member1).getParameterTypes() : (
        (Constructor)member1).getParameterTypes();
      int j = 
        preferSignature(paramArrayOfObject, 
          arrayOfClass1, 
          arrayOfClass);
      if (j == 1) {
        member = member1;
        arrayOfClass = arrayOfClass1;
        vector.removeElementAt(i);
      } else if (j == 2) {
        vector.removeElementAt(i);
      } 
    } 
    if (vector.size() > 0) {
      String str;
      StringBuffer stringBuffer = new StringBuffer();
      boolean bool1 = member instanceof Constructor;
      vector.addElement(member);
      for (byte b1 = 0; b1 < vector.size(); b1++) {
        if (b1)
          stringBuffer.append(", "); 
        str = (Member)vector.elementAt(b1);
        if (!bool1) {
          Class clazz = ((Method)str).getReturnType();
          stringBuffer.append(clazz);
          stringBuffer.append(' ');
        } 
        stringBuffer.append(signature(str));
      } 
      if (bool1) {
        Object[] arrayOfObject = { member.getName(), 
            scriptSignature(paramArrayOfObject), 
            stringBuffer.toString() };
        str = 
          Context.getMessage("msg.constructor.ambiguous", arrayOfObject);
      } else {
        Object[] arrayOfObject = { member.getDeclaringClass().getName(), 
            member.getName(), 
            scriptSignature(paramArrayOfObject), 
            stringBuffer.toString() };
        str = Context.getMessage("msg.method.ambiguous", arrayOfObject);
      } 
      throw Context.reportRuntimeError(str);
    } 
    return member;
  }
  
  public static int preferSignature(Object[] paramArrayOfObject, Class[] paramArrayOfClass1, Class[] paramArrayOfClass2) {
    int i = 0;
    for (byte b = 0; b < paramArrayOfObject.length; b++) {
      Class clazz1 = paramArrayOfClass1[b];
      Class clazz2 = paramArrayOfClass2[b];
      if (clazz1 != clazz2) {
        i |= 
          preferConversion(paramArrayOfObject[b], 
            clazz1, 
            clazz2);
        if (i == 3)
          break; 
      } 
    } 
    return i;
  }
  
  public static int preferConversion(Object paramObject, Class paramClass1, Class paramClass2) {
    int i = 
      NativeJavaObject.getConversionWeight(paramObject, paramClass1);
    int j = 
      NativeJavaObject.getConversionWeight(paramObject, paramClass2);
    if (i == 0 && 
      j == 0) {
      if (paramClass1.isAssignableFrom(paramClass2))
        return 2; 
      if (paramClass2.isAssignableFrom(paramClass1))
        return 1; 
    } else {
      if (i < j)
        return 1; 
      if (i > j)
        return 2; 
    } 
    return 3;
  }
  
  Method[] getMethods() { return this.methods; }
  
  private static void printDebug(String paramString, Member paramMember, Object[] paramArrayOfObject) {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\NativeJavaMethod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */