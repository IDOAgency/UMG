package org.mozilla.javascript;

public interface RegExpProxy {
  Object executeRegExp(Object paramObject, Scriptable paramScriptable, String paramString, int[] paramArrayOfInt, boolean paramBoolean);
  
  int find_split(Function paramFunction, String paramString1, String paramString2, Object paramObject, int[] paramArrayOfInt1, int[] paramArrayOfInt2, boolean[] paramArrayOfBoolean, String[][] paramArrayOfString);
  
  boolean isRegExp(Object paramObject);
  
  Object match(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException;
  
  Object newRegExp(Context paramContext, Scriptable paramScriptable, String paramString1, String paramString2, boolean paramBoolean);
  
  Object replace(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException;
  
  Object search(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject, Function paramFunction) throws JavaScriptException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\RegExpProxy.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */