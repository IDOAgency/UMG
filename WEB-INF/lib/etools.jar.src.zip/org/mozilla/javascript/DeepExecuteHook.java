package org.mozilla.javascript;

public interface DeepExecuteHook {
  void postExecute(Context paramContext, Object paramObject1, Object paramObject2, JavaScriptException paramJavaScriptException);
  
  Object preExecute(Context paramContext, NativeFunction paramNativeFunction, Scriptable paramScriptable);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\DeepExecuteHook.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */