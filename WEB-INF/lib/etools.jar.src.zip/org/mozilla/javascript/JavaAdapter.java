package org.mozilla.javascript;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Hashtable;
import org.mozilla.classfile.ClassFileWriter;

public class JavaAdapter extends ScriptableObject {
  private static int serial;
  
  private static MyClassLoader classLoader;
  
  public boolean equals(Object paramObject) { return super.equals(paramObject); }
  
  public String getClassName() { return "JavaAdapter"; }
  
  public static Object convertResult(Object paramObject, String paramString) throws ClassNotFoundException {
    Class clazz = ScriptRuntime.loadClassName(paramString);
    if (paramObject == Undefined.instance && 
      clazz != ScriptRuntime.ObjectClass && 
      clazz != ScriptRuntime.StringClass)
      return null; 
    return NativeJavaObject.coerceType(clazz, paramObject);
  }
  
  public static Object js_JavaAdapter(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) throws InstantiationException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, ClassNotFoundException {
    Class clazz1 = Object.class;
    Class[] arrayOfClass1 = new Class[paramArrayOfObject.length - 1];
    byte b1 = 0;
    for (byte b2 = 0; b2 < paramArrayOfObject.length - 1; b2++) {
      if (!(paramArrayOfObject[b2] instanceof NativeJavaClass))
        throw new RuntimeException("expected java class object"); 
      Class clazz = ((NativeJavaClass)paramArrayOfObject[b2]).getClassObject();
      if (!clazz.isInterface()) {
        clazz1 = clazz;
        break;
      } 
      arrayOfClass1[b1++] = clazz;
    } 
    Class[] arrayOfClass2 = new Class[b1];
    System.arraycopy(arrayOfClass1, 0, arrayOfClass2, 0, b1);
    Scriptable scriptable = (Scriptable)paramArrayOfObject[paramArrayOfObject.length - 1];
    ClassSignature classSignature = new ClassSignature(clazz1, arrayOfClass2, scriptable);
    Class clazz2 = (Class)generatedClasses.get(classSignature);
    if (clazz2 == null) {
      String str = "adapter" + serial++;
      clazz2 = createAdapterClass(paramContext, scriptable, str, 
          clazz1, arrayOfClass2, 
          null, null);
      generatedClasses.put(classSignature, clazz2);
    } 
    Class[] arrayOfClass3 = { Scriptable.class };
    Object[] arrayOfObject = { scriptable };
    Object object = clazz2.getConstructor(arrayOfClass3).newInstance(arrayOfObject);
    return Context.toObject(object, ScriptableObject.getTopLevelScope(paramFunction));
  }
  
  public static Class createAdapterClass(Context paramContext, Scriptable paramScriptable, String paramString1, Class paramClass, Class[] paramArrayOfClass, String paramString2, ClassNameHelper paramClassNameHelper) throws ClassNotFoundException {
    ClassFileWriter classFileWriter = new ClassFileWriter(paramString1, 
        paramClass.getName(), 
        "<adapter>");
    classFileWriter.addField("self", "Lorg/mozilla/javascript/Scriptable;", (short)
        17);
    boolean bool = (paramArrayOfClass == null) ? 0 : paramArrayOfClass.length;
    for (byte b1 = 0; b1 < bool; b1++) {
      if (paramArrayOfClass[b1] != null)
        classFileWriter.addInterface(paramArrayOfClass[b1].getName()); 
    } 
    String str = paramClass.getName().replace('.', '/');
    generateCtor(classFileWriter, paramString1, str);
    if (paramString2 != null)
      generateEmptyCtor(classFileWriter, paramString1, str, paramString2); 
    Hashtable hashtable1 = new Hashtable();
    Hashtable hashtable2 = new Hashtable();
    for (byte b2 = 0; b2 < bool; b2++) {
      Method[] arrayOfMethod1 = paramArrayOfClass[b2].getMethods();
      for (byte b = 0; b < arrayOfMethod1.length; b++) {
        Method method = arrayOfMethod1[b];
        int i = method.getModifiers();
        if (!Modifier.isStatic(i) && !Modifier.isFinal(i)) {
          String str1 = method.getName();
          String str2 = String.valueOf(str1) + getMethodSignature(method);
          if (!hashtable1.containsKey(str2)) {
            generateMethod(classFileWriter, paramString1, str1, 
                method.getParameterTypes(), 
                method.getReturnType());
            hashtable1.put(str2, Boolean.TRUE);
            hashtable2.put(str1, Boolean.TRUE);
          } 
        } 
      } 
    } 
    Method[] arrayOfMethod = paramClass.getMethods();
    for (byte b3 = 0; b3 < arrayOfMethod.length; b3++) {
      Method method = arrayOfMethod[b3];
      int i = method.getModifiers();
      if (!Modifier.isStatic(i) && !Modifier.isFinal(i)) {
        boolean bool1 = Modifier.isAbstract(i);
        if (bool1 || (
          paramScriptable != null && paramScriptable.has(method.getName(), paramScriptable))) {
          String str1 = method.getName();
          String str2 = getMethodSignature(method);
          String str3 = String.valueOf(str1) + str2;
          if (!hashtable1.containsKey(str3)) {
            generateMethod(classFileWriter, paramString1, str1, 
                method.getParameterTypes(), 
                method.getReturnType());
            hashtable1.put(str3, Boolean.TRUE);
            hashtable2.put(str1, Boolean.TRUE);
          } 
          if (!bool1)
            generateSuper(classFileWriter, paramString1, str, 
                str1, str2, 
                method.getParameterTypes(), 
                method.getReturnType()); 
        } 
      } 
    } 
    Object[] arrayOfObject = paramScriptable.getIds();
    for (byte b4 = 0; b4 < arrayOfObject.length; b4++) {
      if (arrayOfObject[b4] instanceof String) {
        String str1 = (String)arrayOfObject[b4];
        if (!hashtable2.containsKey(str1)) {
          int i;
          Object object = paramScriptable.get(str1, paramScriptable);
          if (object instanceof Scriptable) {
            Scriptable scriptable = (Scriptable)object;
            if (scriptable instanceof Function) {
              i = (int)Context.toNumber(getProperty(scriptable, "length"));
            } else {
              continue;
            } 
          } else if (object instanceof FunctionNode) {
            i = ((FunctionNode)object).getVariableTable().getParameterCount();
          } else {
            continue;
          } 
          Class[] arrayOfClass = new Class[i];
          for (byte b = 0; b < i; b++)
            arrayOfClass[b] = Object.class; 
          generateMethod(classFileWriter, paramString1, str1, arrayOfClass, Object.class);
        } 
      } 
      continue;
    } 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(512);
    try {
      classFileWriter.write(byteArrayOutputStream);
    } catch (IOException iOException) {
      throw new RuntimeException("unexpected IOException");
    } 
    byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
    if (paramClassNameHelper != null && paramClassNameHelper.getGeneratingDirectory() != null) {
      try {
        int i = paramString1.lastIndexOf('.');
        if (i != -1)
          paramString1 = paramString1.substring(i + 1); 
        String str1 = paramClassNameHelper.getTargetClassFileName(paramString1);
        FileOutputStream fileOutputStream = new FileOutputStream(str1);
        fileOutputStream.write(arrayOfByte);
        fileOutputStream.close();
      } catch (IOException iOException) {
        throw WrappedException.wrapException(iOException);
      } 
      return null;
    } 
    SecuritySupport securitySupport = paramContext.getSecuritySupport();
    if (securitySupport != null) {
      Object object = paramContext.getSecurityDomainForStackDepth(-1);
      return securitySupport.defineClass(paramString1, arrayOfByte, object);
    } 
    if (classLoader == null)
      classLoader = new MyClassLoader(); 
    classLoader.defineClass(paramString1, arrayOfByte);
    return classLoader.loadClass(paramString1, true);
  }
  
  public static Object callMethod(Scriptable paramScriptable, String paramString, Object[] paramArrayOfObject) {
    if (paramScriptable.has(paramString, paramScriptable))
      try {
        Context context = Context.enter();
        Object object = paramScriptable.get(paramString, paramScriptable);
        return ScriptRuntime.call(context, object, paramScriptable, paramArrayOfObject, paramScriptable);
      } catch (JavaScriptException javaScriptException) {
      
      } finally {
        Context.exit();
      }  
    return Context.getUndefinedValue();
  }
  
  public static Scriptable toObject(Object paramObject, Scriptable paramScriptable, Class paramClass) {
    Context.enter();
    try {
      return Context.toObject(paramObject, paramScriptable, paramClass);
    } finally {
      Context.exit();
    } 
  }
  
  private static void generateCtor(ClassFileWriter paramClassFileWriter, String paramString1, String paramString2) {
    paramClassFileWriter.startMethod("<init>", 
        "(Lorg/mozilla/javascript/Scriptable;)V", (short)
        1);
    paramClassFileWriter.add((byte)42);
    paramClassFileWriter.add((byte)-73, paramString2, "<init>", "()", "V");
    paramClassFileWriter.add((byte)42);
    paramClassFileWriter.add((byte)43);
    paramClassFileWriter.add((byte)-75, paramString1, "self", 
        "Lorg/mozilla/javascript/Scriptable;");
    paramClassFileWriter.add((byte)43);
    paramClassFileWriter.add((byte)42);
    paramClassFileWriter.add((byte)-72, 
        "org/mozilla/javascript/ScriptRuntime", 
        "setAdapterProto", 
        "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)", 
        
        "V");
    paramClassFileWriter.add((byte)-79);
    paramClassFileWriter.stopMethod((short)20, null);
  }
  
  private static void generateEmptyCtor(ClassFileWriter paramClassFileWriter, String paramString1, String paramString2, String paramString3) {
    paramClassFileWriter.startMethod("<init>", "()V", (short)1);
    paramClassFileWriter.add((byte)42);
    paramClassFileWriter.add((byte)-73, paramString2, "<init>", "()", "V");
    paramClassFileWriter.add((byte)-69, paramString3);
    paramClassFileWriter.add((byte)89);
    paramClassFileWriter.add((byte)-73, paramString3, "<init>", "()", "V");
    paramClassFileWriter.add((byte)-72, 
        "org/mozilla/javascript/ScriptRuntime", 
        "runScript", 
        "(Lorg/mozilla/javascript/Script;)", 
        "Lorg/mozilla/javascript/Scriptable;");
    paramClassFileWriter.add((byte)76);
    paramClassFileWriter.add((byte)42);
    paramClassFileWriter.add((byte)43);
    paramClassFileWriter.add((byte)-75, paramString1, "self", 
        "Lorg/mozilla/javascript/Scriptable;");
    paramClassFileWriter.add((byte)43);
    paramClassFileWriter.add((byte)42);
    paramClassFileWriter.add((byte)-72, 
        "org/mozilla/javascript/ScriptRuntime", 
        "setAdapterProto", 
        "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)", 
        
        "V");
    paramClassFileWriter.add((byte)-79);
    paramClassFileWriter.stopMethod((short)20, null);
  }
  
  private static int generateWrapParam(ClassFileWriter paramClassFileWriter, int paramInt, Class paramClass) {
    if (paramClass.equals(boolean.class)) {
      paramClassFileWriter.add((byte)-69, "java/lang/Boolean");
      paramClassFileWriter.add((byte)89);
      paramClassFileWriter.add((byte)21, paramInt++);
      paramClassFileWriter.add((byte)-73, "java/lang/Boolean", 
          "<init>", "(Z)", "V");
    } else if (paramClass.equals(char.class)) {
      paramClassFileWriter.add((byte)-69, "java/lang/String");
      paramClassFileWriter.add((byte)89);
      paramClassFileWriter.add((byte)4);
      paramClassFileWriter.add((byte)-68, 5);
      paramClassFileWriter.add((byte)89);
      paramClassFileWriter.add((byte)3);
      paramClassFileWriter.add((byte)21, paramInt++);
      paramClassFileWriter.add((byte)85);
      paramClassFileWriter.add((byte)-73, "java/lang/String", 
          "<init>", "([C)", "V");
    } else {
      paramClassFileWriter.add((byte)-69, "java/lang/Double");
      paramClassFileWriter.add((byte)89);
      String str = paramClass.getName();
      switch (str.charAt(0)) {
        case 'b':
        case 'i':
        case 's':
          paramClassFileWriter.add((byte)21, paramInt++);
          paramClassFileWriter.add((byte)-121);
          break;
        case 'l':
          paramClassFileWriter.add((byte)22, paramInt);
          paramClassFileWriter.add((byte)-118);
          paramInt += 2;
          break;
        case 'f':
          paramClassFileWriter.add((byte)23, paramInt++);
          paramClassFileWriter.add((byte)-115);
          break;
        case 'd':
          paramClassFileWriter.add((byte)24, paramInt);
          paramInt += 2;
          break;
      } 
      paramClassFileWriter.add((byte)-73, "java/lang/Double", 
          "<init>", "(D)", "V");
    } 
    return paramInt;
  }
  
  private static void generateReturnResult(ClassFileWriter paramClassFileWriter, Class paramClass) {
    if (paramClass.equals(boolean.class)) {
      paramClassFileWriter.add((byte)-72, 
          "org/mozilla/javascript/Context", 
          "toBoolean", "(Ljava/lang/Object;)", 
          "Z");
      paramClassFileWriter.add((byte)-84);
    } else if (paramClass.equals(char.class)) {
      paramClassFileWriter.add((byte)-72, 
          "org/mozilla/javascript/Context", 
          "toString", "(Ljava/lang/Object;)", 
          "Ljava/lang/String;");
      paramClassFileWriter.add((byte)3);
      paramClassFileWriter.add((byte)-74, "java/lang/String", "charAt", 
          "(I)", "C");
      paramClassFileWriter.add((byte)-84);
    } else {
      if (paramClass.isPrimitive()) {
        paramClassFileWriter.add((byte)-72, 
            "org/mozilla/javascript/Context", 
            "toNumber", "(Ljava/lang/Object;)", 
            "D");
        String str1 = paramClass.getName();
        switch (str1.charAt(0)) {
          case 'b':
          case 'i':
          case 's':
            paramClassFileWriter.add((byte)-114);
            paramClassFileWriter.add((byte)-84);
            return;
          case 'l':
            paramClassFileWriter.add((byte)-113);
            paramClassFileWriter.add((byte)-83);
            return;
          case 'f':
            paramClassFileWriter.add((byte)-112);
            paramClassFileWriter.add((byte)-82);
            return;
          case 'd':
            paramClassFileWriter.add((byte)-81);
            return;
        } 
        throw new RuntimeException("Unexpected return type " + 
            paramClass.toString());
      } 
      String str = paramClass.getName();
      paramClassFileWriter.addLoadConstant(str);
      paramClassFileWriter.add((byte)-72, 
          "org/mozilla/javascript/JavaAdapter", 
          "convertResult", 
          "(Ljava/lang/Object;Ljava/lang/String;)", 
          
          "Ljava/lang/Object;");
      paramClassFileWriter.add((byte)-64, str.replace('.', '/'));
      paramClassFileWriter.add((byte)-80);
    } 
  }
  
  private static void generateMethod(ClassFileWriter paramClassFileWriter, String paramString1, String paramString2, Class[] paramArrayOfClass, Class paramClass) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append('(');
    short s = 1;
    for (byte b1 = 0; b1 < paramArrayOfClass.length; b1++) {
      Class clazz1 = paramArrayOfClass[b1];
      appendTypeString(stringBuffer, clazz1);
      if (clazz1.equals(long.class) || clazz1.equals(double.class)) {
        s = (short)(s + 2);
      } else {
        s = (short)(s + 1);
      } 
    } 
    stringBuffer.append(')');
    appendTypeString(stringBuffer, paramClass);
    String str = stringBuffer.toString();
    paramClassFileWriter.startMethod(paramString2, str, (short)
        1);
    paramClassFileWriter.add((byte)16, (byte)paramArrayOfClass.length);
    paramClassFileWriter.add((byte)-67, "java/lang/Object");
    paramClassFileWriter.add((byte)58, s);
    short s1 = (short)(s + 1);
    boolean bool = false;
    int i = 1;
    for (byte b2 = 0; b2 < paramArrayOfClass.length; b2++) {
      paramClassFileWriter.add((byte)25, s);
      paramClassFileWriter.add((byte)16, b2);
      if (paramArrayOfClass[b2].isPrimitive()) {
        i = generateWrapParam(paramClassFileWriter, i, paramArrayOfClass[b2]);
      } else {
        paramClassFileWriter.add((byte)25, i++);
        if (!bool) {
          paramClassFileWriter.add((byte)42);
          paramClassFileWriter.add((byte)-76, paramString1, "self", 
              "Lorg/mozilla/javascript/Scriptable;");
          paramClassFileWriter.add((byte)58, s1);
          bool = true;
        } 
        paramClassFileWriter.add((byte)25, s1);
        paramClassFileWriter.addLoadConstant(paramArrayOfClass[b2].getName());
        paramClassFileWriter.add((byte)-72, 
            "org/mozilla/javascript/ScriptRuntime", 
            "loadClassName", 
            "(Ljava/lang/String;)", 
            "Ljava/lang/Class;");
        paramClassFileWriter.add((byte)-72, 
            "org/mozilla/javascript/JavaAdapter", 
            "toObject", 
            
            "(Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Class;)", 
            
            "Lorg/mozilla/javascript/Scriptable;");
      } 
      paramClassFileWriter.add((byte)83);
    } 
    paramClassFileWriter.add((byte)42);
    paramClassFileWriter.add((byte)-76, paramString1, "self", 
        "Lorg/mozilla/javascript/Scriptable;");
    paramClassFileWriter.addLoadConstant(paramString2);
    paramClassFileWriter.add((byte)25, s);
    paramClassFileWriter.add((byte)-72, 
        "org/mozilla/javascript/JavaAdapter", 
        "callMethod", 
        "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;[Ljava/lang/Object;)", 
        
        "Ljava/lang/Object;");
    Class clazz = paramClass;
    if (clazz.equals(void.class)) {
      paramClassFileWriter.add((byte)87);
      paramClassFileWriter.add((byte)-79);
    } else {
      generateReturnResult(paramClassFileWriter, clazz);
    } 
    paramClassFileWriter.stopMethod((short)(s1 + 1), null);
  }
  
  private static int generatePushParam(ClassFileWriter paramClassFileWriter, int paramInt, Class paramClass) {
    String str = paramClass.getName();
    switch (str.charAt(0)) {
      case 'b':
      case 'c':
      case 'i':
      case 's':
      case 'z':
        paramClassFileWriter.add((byte)21, paramInt++);
        break;
      case 'l':
        paramClassFileWriter.add((byte)22, paramInt);
        paramInt += 2;
        break;
      case 'f':
        paramClassFileWriter.add((byte)23, paramInt++);
        break;
      case 'd':
        paramClassFileWriter.add((byte)24, paramInt);
        paramInt += 2;
        break;
    } 
    return paramInt;
  }
  
  private static void generatePopResult(ClassFileWriter paramClassFileWriter, Class paramClass) {
    if (paramClass.isPrimitive()) {
      String str = paramClass.getName();
      switch (str.charAt(0)) {
        case 'b':
        case 'c':
        case 'i':
        case 's':
        case 'z':
          paramClassFileWriter.add((byte)-84);
          break;
        case 'l':
          paramClassFileWriter.add((byte)-83);
          break;
        case 'f':
          paramClassFileWriter.add((byte)-82);
          break;
        case 'd':
          paramClassFileWriter.add((byte)-81);
          break;
      } 
    } else {
      paramClassFileWriter.add((byte)-80);
    } 
  }
  
  private static void generateSuper(ClassFileWriter paramClassFileWriter, String paramString1, String paramString2, String paramString3, String paramString4, Class[] paramArrayOfClass, Class paramClass) {
    paramClassFileWriter.startMethod("super$" + paramString3, paramString4, (short)
        1);
    paramClassFileWriter.add((byte)25, 0);
    int i = 1;
    for (byte b = 0; b < paramArrayOfClass.length; b++) {
      if (paramArrayOfClass[b].isPrimitive()) {
        i = generatePushParam(paramClassFileWriter, i, paramArrayOfClass[b]);
      } else {
        paramClassFileWriter.add((byte)25, i++);
      } 
    } 
    int j = paramString4.indexOf(')');
    paramClassFileWriter.add((byte)-73, 
        paramString2, 
        paramString3, 
        paramString4.substring(0, j + 1), 
        paramString4.substring(j + 1));
    Class clazz = paramClass;
    if (!clazz.equals(void.class)) {
      generatePopResult(paramClassFileWriter, clazz);
    } else {
      paramClassFileWriter.add((byte)-79);
    } 
    paramClassFileWriter.stopMethod((short)(i + 1), null);
  }
  
  private static String getMethodSignature(Method paramMethod) {
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append('(');
    for (byte b = 0; b < arrayOfClass.length; b++) {
      Class clazz = arrayOfClass[b];
      appendTypeString(stringBuffer, clazz);
    } 
    stringBuffer.append(')');
    appendTypeString(stringBuffer, paramMethod.getReturnType());
    return stringBuffer.toString();
  }
  
  private static StringBuffer appendTypeString(StringBuffer paramStringBuffer, Class paramClass) {
    while (paramClass.isArray()) {
      paramStringBuffer.append('[');
      paramClass = paramClass.getComponentType();
    } 
    if (paramClass.isPrimitive()) {
      if (paramClass.equals(boolean.class)) {
        paramStringBuffer.append('Z');
      } else if (paramClass.equals(long.class)) {
        paramStringBuffer.append('J');
      } else {
        String str = paramClass.getName();
        paramStringBuffer.append(Character.toUpperCase(str.charAt(0)));
      } 
    } else {
      paramStringBuffer.append('L');
      paramStringBuffer.append(paramClass.getName().replace('.', '/'));
      paramStringBuffer.append(';');
    } 
    return paramStringBuffer;
  }
  
  private static Object getProperty(Scriptable paramScriptable, String paramString) {
    Scriptable scriptable = paramScriptable;
    Object object = null;
    while (true) {
      object = scriptable.get(paramString, paramScriptable);
      if (object == Scriptable.NOT_FOUND) {
        scriptable = scriptable.getPrototype();
        if (scriptable == null)
          return Undefined.instance; 
        continue;
      } 
      break;
    } 
    return object;
  }
  
  static final class MyClassLoader extends ClassLoader {
    public Class defineClass(String param1String, byte[] param1ArrayOfByte) { return defineClass(param1String, param1ArrayOfByte, 0, param1ArrayOfByte.length); }
    
    protected Class loadClass(String param1String, boolean param1Boolean) throws ClassNotFoundException {
      Class clazz = findLoadedClass(param1String);
      if (clazz == null) {
        ClassLoader classLoader = getClass().getClassLoader();
        try {
          if (classLoader != null)
            return classLoader.loadClass(param1String); 
          clazz = findSystemClass(param1String);
        } catch (ClassNotFoundException classNotFoundException) {
          return ScriptRuntime.loadClassName(param1String);
        } 
      } 
      if (param1Boolean)
        resolveClass(clazz); 
      return clazz;
    }
  }
  
  static class ClassSignature {
    Class mSuperClass;
    
    Class[] mInterfaces;
    
    Object[] mProperties;
    
    ClassSignature(Class param1Class, Class[] param1ArrayOfClass, Scriptable param1Scriptable) {
      this.mSuperClass = param1Class;
      this.mInterfaces = param1ArrayOfClass;
      this.mProperties = param1Scriptable.getIds();
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object instanceof ClassSignature) {
        ClassSignature classSignature = (ClassSignature)param1Object;
        if (this.mSuperClass == classSignature.mSuperClass) {
          Class[] arrayOfClass = classSignature.mInterfaces;
          if (this.mInterfaces != arrayOfClass) {
            if (this.mInterfaces == null || arrayOfClass == null)
              return false; 
            if (this.mInterfaces.length != arrayOfClass.length)
              return false; 
            for (byte b1 = 0; b1 < arrayOfClass.length; b1++) {
              if (this.mInterfaces[b1] != arrayOfClass[b1])
                return false; 
            } 
          } 
          Object[] arrayOfObject = classSignature.mProperties;
          if (this.mProperties.length != arrayOfObject.length)
            return false; 
          for (byte b = 0; b < arrayOfObject.length; b++) {
            if (!this.mProperties[b].equals(arrayOfObject[b]))
              return false; 
          } 
          return true;
        } 
      } 
      return false;
    }
    
    public int hashCode() { return this.mSuperClass.hashCode(); }
  }
  
  private static Hashtable generatedClasses = new Hashtable(7);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\JavaAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */