/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Hashtable;
/*     */ import org.mozilla.classfile.ClassFileWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaAdapter
/*     */   extends ScriptableObject
/*     */ {
/*     */   private static int serial;
/*     */   private static MyClassLoader classLoader;
/*     */   
/*  49 */   public boolean equals(Object paramObject) { return super.equals(paramObject); }
/*     */ 
/*     */ 
/*     */   
/*  53 */   public String getClassName() { return "JavaAdapter"; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object convertResult(Object paramObject, String paramString) throws ClassNotFoundException {
/*  59 */     Class clazz = ScriptRuntime.loadClassName(paramString);
/*  60 */     if (paramObject == Undefined.instance && 
/*  61 */       clazz != ScriptRuntime.ObjectClass && 
/*  62 */       clazz != ScriptRuntime.StringClass)
/*     */     {
/*     */       
/*  65 */       return null;
/*     */     }
/*  67 */     return NativeJavaObject.coerceType(clazz, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object js_JavaAdapter(Context paramContext, Object[] paramArrayOfObject, Function paramFunction, boolean paramBoolean) throws InstantiationException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, ClassNotFoundException {
/*  76 */     Class clazz1 = Object.class;
/*  77 */     Class[] arrayOfClass1 = new Class[paramArrayOfObject.length - 1];
/*  78 */     byte b1 = 0;
/*  79 */     for (byte b2 = 0; b2 < paramArrayOfObject.length - 1; b2++) {
/*  80 */       if (!(paramArrayOfObject[b2] instanceof NativeJavaClass))
/*     */       {
/*  82 */         throw new RuntimeException("expected java class object");
/*     */       }
/*  84 */       Class clazz = ((NativeJavaClass)paramArrayOfObject[b2]).getClassObject();
/*  85 */       if (!clazz.isInterface()) {
/*  86 */         clazz1 = clazz;
/*     */         break;
/*     */       } 
/*  89 */       arrayOfClass1[b1++] = clazz;
/*     */     } 
/*     */     
/*  92 */     Class[] arrayOfClass2 = new Class[b1];
/*  93 */     System.arraycopy(arrayOfClass1, 0, arrayOfClass2, 0, b1);
/*  94 */     Scriptable scriptable = (Scriptable)paramArrayOfObject[paramArrayOfObject.length - 1];
/*     */     
/*  96 */     ClassSignature classSignature = new ClassSignature(clazz1, arrayOfClass2, scriptable);
/*  97 */     Class clazz2 = (Class)generatedClasses.get(classSignature);
/*  98 */     if (clazz2 == null) {
/*  99 */       String str = "adapter" + serial++;
/* 100 */       clazz2 = createAdapterClass(paramContext, scriptable, str, 
/* 101 */           clazz1, arrayOfClass2, 
/* 102 */           null, null);
/* 103 */       generatedClasses.put(classSignature, clazz2);
/*     */     } 
/*     */     
/* 106 */     Class[] arrayOfClass3 = { Scriptable.class };
/* 107 */     Object[] arrayOfObject = { scriptable };
/* 108 */     Object object = clazz2.getConstructor(arrayOfClass3).newInstance(arrayOfObject);
/* 109 */     return Context.toObject(object, ScriptableObject.getTopLevelScope(paramFunction));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class createAdapterClass(Context paramContext, Scriptable paramScriptable, String paramString1, Class paramClass, Class[] paramArrayOfClass, String paramString2, ClassNameHelper paramClassNameHelper) throws ClassNotFoundException {
/* 119 */     ClassFileWriter classFileWriter = new ClassFileWriter(paramString1, 
/* 120 */         paramClass.getName(), 
/* 121 */         "<adapter>");
/* 122 */     classFileWriter.addField("self", "Lorg/mozilla/javascript/Scriptable;", (short)
/* 123 */         17);
/*     */     
/* 125 */     boolean bool = (paramArrayOfClass == null) ? 0 : paramArrayOfClass.length;
/* 126 */     for (byte b1 = 0; b1 < bool; b1++) {
/* 127 */       if (paramArrayOfClass[b1] != null) {
/* 128 */         classFileWriter.addInterface(paramArrayOfClass[b1].getName());
/*     */       }
/*     */     } 
/* 131 */     String str = paramClass.getName().replace('.', '/');
/* 132 */     generateCtor(classFileWriter, paramString1, str);
/* 133 */     if (paramString2 != null) {
/* 134 */       generateEmptyCtor(classFileWriter, paramString1, str, paramString2);
/*     */     }
/* 136 */     Hashtable hashtable1 = new Hashtable();
/* 137 */     Hashtable hashtable2 = new Hashtable();
/*     */ 
/*     */     
/* 140 */     for (byte b2 = 0; b2 < bool; b2++) {
/* 141 */       Method[] arrayOfMethod1 = paramArrayOfClass[b2].getMethods();
/* 142 */       for (byte b = 0; b < arrayOfMethod1.length; b++) {
/* 143 */         Method method = arrayOfMethod1[b];
/* 144 */         int i = method.getModifiers();
/* 145 */         if (!Modifier.isStatic(i) && !Modifier.isFinal(i)) {
/*     */ 
/*     */ 
/*     */           
/* 149 */           String str1 = method.getName();
/* 150 */           String str2 = String.valueOf(str1) + getMethodSignature(method);
/* 151 */           if (!hashtable1.containsKey(str2)) {
/* 152 */             generateMethod(classFileWriter, paramString1, str1, 
/* 153 */                 method.getParameterTypes(), 
/* 154 */                 method.getReturnType());
/* 155 */             hashtable1.put(str2, Boolean.TRUE);
/* 156 */             hashtable2.put(str1, Boolean.TRUE);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     Method[] arrayOfMethod = paramClass.getMethods();
/* 166 */     for (byte b3 = 0; b3 < arrayOfMethod.length; b3++) {
/* 167 */       Method method = arrayOfMethod[b3];
/* 168 */       int i = method.getModifiers();
/* 169 */       if (!Modifier.isStatic(i) && !Modifier.isFinal(i)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 174 */         boolean bool1 = Modifier.isAbstract(i);
/* 175 */         if (bool1 || (
/* 176 */           paramScriptable != null && paramScriptable.has(method.getName(), paramScriptable))) {
/*     */ 
/*     */ 
/*     */           
/* 180 */           String str1 = method.getName();
/* 181 */           String str2 = getMethodSignature(method);
/* 182 */           String str3 = String.valueOf(str1) + str2;
/* 183 */           if (!hashtable1.containsKey(str3)) {
/* 184 */             generateMethod(classFileWriter, paramString1, str1, 
/* 185 */                 method.getParameterTypes(), 
/* 186 */                 method.getReturnType());
/* 187 */             hashtable1.put(str3, Boolean.TRUE);
/* 188 */             hashtable2.put(str1, Boolean.TRUE);
/*     */           } 
/*     */ 
/*     */           
/* 192 */           if (!bool1) {
/* 193 */             generateSuper(classFileWriter, paramString1, str, 
/* 194 */                 str1, str2, 
/* 195 */                 method.getParameterTypes(), 
/* 196 */                 method.getReturnType());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 203 */     Object[] arrayOfObject = paramScriptable.getIds();
/* 204 */     for (byte b4 = 0; b4 < arrayOfObject.length; b4++) {
/* 205 */       if (arrayOfObject[b4] instanceof String) {
/*     */         
/* 207 */         String str1 = (String)arrayOfObject[b4];
/* 208 */         if (!hashtable2.containsKey(str1)) {
/*     */           int i;
/* 210 */           Object object = paramScriptable.get(str1, paramScriptable);
/*     */           
/* 212 */           if (object instanceof Scriptable) {
/* 213 */             Scriptable scriptable = (Scriptable)object;
/* 214 */             if (scriptable instanceof Function)
/*     */             
/* 216 */             { i = (int)Context.toNumber(getProperty(scriptable, "length")); } else { continue; } 
/* 217 */           } else if (object instanceof FunctionNode) {
/* 218 */             i = ((FunctionNode)object).getVariableTable().getParameterCount();
/*     */           } else {
/*     */             continue;
/*     */           } 
/* 222 */           Class[] arrayOfClass = new Class[i];
/* 223 */           for (byte b = 0; b < i; b++)
/* 224 */             arrayOfClass[b] = Object.class; 
/* 225 */           generateMethod(classFileWriter, paramString1, str1, arrayOfClass, Object.class);
/*     */         } 
/*     */       }  continue;
/* 228 */     }  ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(512);
/*     */     try {
/* 230 */       classFileWriter.write(byteArrayOutputStream);
/*     */     }
/* 232 */     catch (IOException iOException) {
/* 233 */       throw new RuntimeException("unexpected IOException");
/*     */     } 
/* 235 */     byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
/*     */     
/* 237 */     if (paramClassNameHelper != null && paramClassNameHelper.getGeneratingDirectory() != null) {
/*     */       
/*     */       try {
/* 240 */         int i = paramString1.lastIndexOf('.');
/* 241 */         if (i != -1)
/* 242 */           paramString1 = paramString1.substring(i + 1); 
/* 243 */         String str1 = paramClassNameHelper.getTargetClassFileName(paramString1);
/* 244 */         FileOutputStream fileOutputStream = new FileOutputStream(str1);
/* 245 */         fileOutputStream.write(arrayOfByte);
/* 246 */         fileOutputStream.close();
/*     */       }
/* 248 */       catch (IOException iOException) {
/* 249 */         throw WrappedException.wrapException(iOException);
/*     */       } 
/* 251 */       return null;
/*     */     } 
/*     */     
/* 254 */     SecuritySupport securitySupport = paramContext.getSecuritySupport();
/* 255 */     if (securitySupport != null) {
/* 256 */       Object object = paramContext.getSecurityDomainForStackDepth(-1);
/* 257 */       return securitySupport.defineClass(paramString1, arrayOfByte, object);
/*     */     } 
/* 259 */     if (classLoader == null)
/* 260 */       classLoader = new MyClassLoader(); 
/* 261 */     classLoader.defineClass(paramString1, arrayOfByte);
/* 262 */     return classLoader.loadClass(paramString1, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object callMethod(Scriptable paramScriptable, String paramString, Object[] paramArrayOfObject) {
/* 273 */     if (paramScriptable.has(paramString, paramScriptable)) {
/*     */       try {
/* 275 */         Context context = Context.enter();
/* 276 */         Object object = paramScriptable.get(paramString, paramScriptable);
/* 277 */         return ScriptRuntime.call(context, object, paramScriptable, paramArrayOfObject, paramScriptable);
/* 278 */       } catch (JavaScriptException javaScriptException) {
/*     */       
/*     */       } finally {
/* 281 */         Context.exit();
/*     */       } 
/*     */     }
/* 284 */     return Context.getUndefinedValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Scriptable toObject(Object paramObject, Scriptable paramScriptable, Class paramClass) {
/* 290 */     Context.enter();
/*     */     try {
/* 292 */       return Context.toObject(paramObject, paramScriptable, paramClass);
/*     */     } finally {
/* 294 */       Context.exit();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void generateCtor(ClassFileWriter paramClassFileWriter, String paramString1, String paramString2) {
/* 301 */     paramClassFileWriter.startMethod("<init>", 
/* 302 */         "(Lorg/mozilla/javascript/Scriptable;)V", (short)
/* 303 */         1);
/*     */ 
/*     */     
/* 306 */     paramClassFileWriter.add((byte)42);
/* 307 */     paramClassFileWriter.add((byte)-73, paramString2, "<init>", "()", "V");
/*     */ 
/*     */     
/* 310 */     paramClassFileWriter.add((byte)42);
/* 311 */     paramClassFileWriter.add((byte)43);
/* 312 */     paramClassFileWriter.add((byte)-75, paramString1, "self", 
/* 313 */         "Lorg/mozilla/javascript/Scriptable;");
/*     */ 
/*     */ 
/*     */     
/* 317 */     paramClassFileWriter.add((byte)43);
/* 318 */     paramClassFileWriter.add((byte)42);
/* 319 */     paramClassFileWriter.add((byte)-72, 
/* 320 */         "org/mozilla/javascript/ScriptRuntime", 
/* 321 */         "setAdapterProto", 
/* 322 */         "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)", 
/*     */         
/* 324 */         "V");
/*     */     
/* 326 */     paramClassFileWriter.add((byte)-79);
/* 327 */     paramClassFileWriter.stopMethod((short)20, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void generateEmptyCtor(ClassFileWriter paramClassFileWriter, String paramString1, String paramString2, String paramString3) {
/* 333 */     paramClassFileWriter.startMethod("<init>", "()V", (short)1);
/*     */ 
/*     */     
/* 336 */     paramClassFileWriter.add((byte)42);
/* 337 */     paramClassFileWriter.add((byte)-73, paramString2, "<init>", "()", "V");
/*     */ 
/*     */     
/* 340 */     paramClassFileWriter.add((byte)-69, paramString3);
/* 341 */     paramClassFileWriter.add((byte)89);
/* 342 */     paramClassFileWriter.add((byte)-73, paramString3, "<init>", "()", "V");
/*     */ 
/*     */     
/* 345 */     paramClassFileWriter.add((byte)-72, 
/* 346 */         "org/mozilla/javascript/ScriptRuntime", 
/* 347 */         "runScript", 
/* 348 */         "(Lorg/mozilla/javascript/Script;)", 
/* 349 */         "Lorg/mozilla/javascript/Scriptable;");
/* 350 */     paramClassFileWriter.add((byte)76);
/*     */ 
/*     */     
/* 353 */     paramClassFileWriter.add((byte)42);
/* 354 */     paramClassFileWriter.add((byte)43);
/* 355 */     paramClassFileWriter.add((byte)-75, paramString1, "self", 
/* 356 */         "Lorg/mozilla/javascript/Scriptable;");
/*     */ 
/*     */ 
/*     */     
/* 360 */     paramClassFileWriter.add((byte)43);
/* 361 */     paramClassFileWriter.add((byte)42);
/* 362 */     paramClassFileWriter.add((byte)-72, 
/* 363 */         "org/mozilla/javascript/ScriptRuntime", 
/* 364 */         "setAdapterProto", 
/* 365 */         "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)", 
/*     */         
/* 367 */         "V");
/*     */     
/* 369 */     paramClassFileWriter.add((byte)-79);
/* 370 */     paramClassFileWriter.stopMethod((short)20, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int generateWrapParam(ClassFileWriter paramClassFileWriter, int paramInt, Class paramClass) {
/* 381 */     if (paramClass.equals(boolean.class)) {
/*     */       
/* 383 */       paramClassFileWriter.add((byte)-69, "java/lang/Boolean");
/* 384 */       paramClassFileWriter.add((byte)89);
/* 385 */       paramClassFileWriter.add((byte)21, paramInt++);
/* 386 */       paramClassFileWriter.add((byte)-73, "java/lang/Boolean", 
/* 387 */           "<init>", "(Z)", "V");
/*     */     }
/* 389 */     else if (paramClass.equals(char.class)) {
/*     */       
/* 391 */       paramClassFileWriter.add((byte)-69, "java/lang/String");
/* 392 */       paramClassFileWriter.add((byte)89);
/* 393 */       paramClassFileWriter.add((byte)4);
/* 394 */       paramClassFileWriter.add((byte)-68, 5);
/* 395 */       paramClassFileWriter.add((byte)89);
/* 396 */       paramClassFileWriter.add((byte)3);
/* 397 */       paramClassFileWriter.add((byte)21, paramInt++);
/* 398 */       paramClassFileWriter.add((byte)85);
/* 399 */       paramClassFileWriter.add((byte)-73, "java/lang/String", 
/* 400 */           "<init>", "([C)", "V");
/*     */     } else {
/*     */       
/* 403 */       paramClassFileWriter.add((byte)-69, "java/lang/Double");
/* 404 */       paramClassFileWriter.add((byte)89);
/* 405 */       String str = paramClass.getName();
/* 406 */       switch (str.charAt(0)) {
/*     */         
/*     */         case 'b':
/*     */         case 'i':
/*     */         case 's':
/* 411 */           paramClassFileWriter.add((byte)21, paramInt++);
/* 412 */           paramClassFileWriter.add((byte)-121);
/*     */           break;
/*     */         
/*     */         case 'l':
/* 416 */           paramClassFileWriter.add((byte)22, paramInt);
/* 417 */           paramClassFileWriter.add((byte)-118);
/* 418 */           paramInt += 2;
/*     */           break;
/*     */         
/*     */         case 'f':
/* 422 */           paramClassFileWriter.add((byte)23, paramInt++);
/* 423 */           paramClassFileWriter.add((byte)-115);
/*     */           break;
/*     */         case 'd':
/* 426 */           paramClassFileWriter.add((byte)24, paramInt);
/* 427 */           paramInt += 2;
/*     */           break;
/*     */       } 
/* 430 */       paramClassFileWriter.add((byte)-73, "java/lang/Double", 
/* 431 */           "<init>", "(D)", "V");
/*     */     } 
/* 433 */     return paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void generateReturnResult(ClassFileWriter paramClassFileWriter, Class paramClass) {
/* 447 */     if (paramClass.equals(boolean.class))
/* 448 */     { paramClassFileWriter.add((byte)-72, 
/* 449 */           "org/mozilla/javascript/Context", 
/* 450 */           "toBoolean", "(Ljava/lang/Object;)", 
/* 451 */           "Z");
/* 452 */       paramClassFileWriter.add((byte)-84); }
/* 453 */     else if (paramClass.equals(char.class))
/*     */     
/*     */     { 
/*     */       
/* 457 */       paramClassFileWriter.add((byte)-72, 
/* 458 */           "org/mozilla/javascript/Context", 
/* 459 */           "toString", "(Ljava/lang/Object;)", 
/* 460 */           "Ljava/lang/String;");
/* 461 */       paramClassFileWriter.add((byte)3);
/* 462 */       paramClassFileWriter.add((byte)-74, "java/lang/String", "charAt", 
/* 463 */           "(I)", "C");
/* 464 */       paramClassFileWriter.add((byte)-84); }
/* 465 */     else { if (paramClass.isPrimitive()) {
/* 466 */         paramClassFileWriter.add((byte)-72, 
/* 467 */             "org/mozilla/javascript/Context", 
/* 468 */             "toNumber", "(Ljava/lang/Object;)", 
/* 469 */             "D");
/* 470 */         String str1 = paramClass.getName();
/* 471 */         switch (str1.charAt(0)) {
/*     */           case 'b':
/*     */           case 'i':
/*     */           case 's':
/* 475 */             paramClassFileWriter.add((byte)-114);
/* 476 */             paramClassFileWriter.add((byte)-84);
/*     */             return;
/*     */           case 'l':
/* 479 */             paramClassFileWriter.add((byte)-113);
/* 480 */             paramClassFileWriter.add((byte)-83);
/*     */             return;
/*     */           case 'f':
/* 483 */             paramClassFileWriter.add((byte)-112);
/* 484 */             paramClassFileWriter.add((byte)-82);
/*     */             return;
/*     */           case 'd':
/* 487 */             paramClassFileWriter.add((byte)-81);
/*     */             return;
/*     */         } 
/* 490 */         throw new RuntimeException("Unexpected return type " + 
/* 491 */             paramClass.toString());
/*     */       } 
/*     */       
/* 494 */       String str = paramClass.getName();
/* 495 */       paramClassFileWriter.addLoadConstant(str);
/* 496 */       paramClassFileWriter.add((byte)-72, 
/* 497 */           "org/mozilla/javascript/JavaAdapter", 
/* 498 */           "convertResult", 
/* 499 */           "(Ljava/lang/Object;Ljava/lang/String;)", 
/*     */           
/* 501 */           "Ljava/lang/Object;");
/*     */       
/* 503 */       paramClassFileWriter.add((byte)-64, str.replace('.', '/'));
/* 504 */       paramClassFileWriter.add((byte)-80); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void generateMethod(ClassFileWriter paramClassFileWriter, String paramString1, String paramString2, Class[] paramArrayOfClass, Class paramClass) {
/* 512 */     StringBuffer stringBuffer = new StringBuffer();
/* 513 */     stringBuffer.append('(');
/* 514 */     short s = 1;
/* 515 */     for (byte b1 = 0; b1 < paramArrayOfClass.length; b1++) {
/* 516 */       Class clazz1 = paramArrayOfClass[b1];
/* 517 */       appendTypeString(stringBuffer, clazz1);
/* 518 */       if (clazz1.equals(long.class) || clazz1.equals(double.class)) {
/* 519 */         s = (short)(s + 2);
/*     */       } else {
/* 521 */         s = (short)(s + 1);
/*     */       } 
/* 523 */     }  stringBuffer.append(')');
/* 524 */     appendTypeString(stringBuffer, paramClass);
/* 525 */     String str = stringBuffer.toString();
/*     */ 
/*     */     
/* 528 */     paramClassFileWriter.startMethod(paramString2, str, (short)
/* 529 */         1);
/* 530 */     paramClassFileWriter.add((byte)16, (byte)paramArrayOfClass.length);
/* 531 */     paramClassFileWriter.add((byte)-67, "java/lang/Object");
/* 532 */     paramClassFileWriter.add((byte)58, s);
/*     */ 
/*     */     
/* 535 */     short s1 = (short)(s + 1);
/* 536 */     boolean bool = false;
/*     */     
/* 538 */     int i = 1;
/* 539 */     for (byte b2 = 0; b2 < paramArrayOfClass.length; b2++) {
/* 540 */       paramClassFileWriter.add((byte)25, s);
/* 541 */       paramClassFileWriter.add((byte)16, b2);
/* 542 */       if (paramArrayOfClass[b2].isPrimitive()) {
/* 543 */         i = generateWrapParam(paramClassFileWriter, i, paramArrayOfClass[b2]);
/*     */       }
/*     */       else {
/*     */         
/* 547 */         paramClassFileWriter.add((byte)25, i++);
/* 548 */         if (!bool) {
/*     */ 
/*     */           
/* 551 */           paramClassFileWriter.add((byte)42);
/* 552 */           paramClassFileWriter.add((byte)-76, paramString1, "self", 
/* 553 */               "Lorg/mozilla/javascript/Scriptable;");
/* 554 */           paramClassFileWriter.add((byte)58, s1);
/* 555 */           bool = true;
/*     */         } 
/* 557 */         paramClassFileWriter.add((byte)25, s1);
/*     */ 
/*     */         
/* 560 */         paramClassFileWriter.addLoadConstant(paramArrayOfClass[b2].getName());
/* 561 */         paramClassFileWriter.add((byte)-72, 
/* 562 */             "org/mozilla/javascript/ScriptRuntime", 
/* 563 */             "loadClassName", 
/* 564 */             "(Ljava/lang/String;)", 
/* 565 */             "Ljava/lang/Class;");
/*     */         
/* 567 */         paramClassFileWriter.add((byte)-72, 
/* 568 */             "org/mozilla/javascript/JavaAdapter", 
/* 569 */             "toObject", 
/*     */             
/* 571 */             "(Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Class;)", 
/*     */             
/* 573 */             "Lorg/mozilla/javascript/Scriptable;");
/*     */       } 
/* 575 */       paramClassFileWriter.add((byte)83);
/*     */     } 
/*     */     
/* 578 */     paramClassFileWriter.add((byte)42);
/* 579 */     paramClassFileWriter.add((byte)-76, paramString1, "self", 
/* 580 */         "Lorg/mozilla/javascript/Scriptable;");
/*     */     
/* 582 */     paramClassFileWriter.addLoadConstant(paramString2);
/* 583 */     paramClassFileWriter.add((byte)25, s);
/*     */ 
/*     */ 
/*     */     
/* 587 */     paramClassFileWriter.add((byte)-72, 
/* 588 */         "org/mozilla/javascript/JavaAdapter", 
/* 589 */         "callMethod", 
/* 590 */         "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;[Ljava/lang/Object;)", 
/*     */         
/* 592 */         "Ljava/lang/Object;");
/*     */     
/* 594 */     Class clazz = paramClass;
/* 595 */     if (clazz.equals(void.class)) {
/* 596 */       paramClassFileWriter.add((byte)87);
/* 597 */       paramClassFileWriter.add((byte)-79);
/*     */     } else {
/* 599 */       generateReturnResult(paramClassFileWriter, clazz);
/*     */     } 
/* 601 */     paramClassFileWriter.stopMethod((short)(s1 + 1), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int generatePushParam(ClassFileWriter paramClassFileWriter, int paramInt, Class paramClass) {
/* 611 */     String str = paramClass.getName();
/* 612 */     switch (str.charAt(0)) {
/*     */       
/*     */       case 'b':
/*     */       case 'c':
/*     */       case 'i':
/*     */       case 's':
/*     */       case 'z':
/* 619 */         paramClassFileWriter.add((byte)21, paramInt++);
/*     */         break;
/*     */       
/*     */       case 'l':
/* 623 */         paramClassFileWriter.add((byte)22, paramInt);
/* 624 */         paramInt += 2;
/*     */         break;
/*     */       
/*     */       case 'f':
/* 628 */         paramClassFileWriter.add((byte)23, paramInt++);
/*     */         break;
/*     */       case 'd':
/* 631 */         paramClassFileWriter.add((byte)24, paramInt);
/* 632 */         paramInt += 2;
/*     */         break;
/*     */     } 
/* 635 */     return paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void generatePopResult(ClassFileWriter paramClassFileWriter, Class paramClass) {
/* 646 */     if (paramClass.isPrimitive()) {
/* 647 */       String str = paramClass.getName();
/* 648 */       switch (str.charAt(0)) {
/*     */         case 'b':
/*     */         case 'c':
/*     */         case 'i':
/*     */         case 's':
/*     */         case 'z':
/* 654 */           paramClassFileWriter.add((byte)-84);
/*     */           break;
/*     */         case 'l':
/* 657 */           paramClassFileWriter.add((byte)-83);
/*     */           break;
/*     */         case 'f':
/* 660 */           paramClassFileWriter.add((byte)-82);
/*     */           break;
/*     */         case 'd':
/* 663 */           paramClassFileWriter.add((byte)-81);
/*     */           break;
/*     */       } 
/*     */     } else {
/* 667 */       paramClassFileWriter.add((byte)-80);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void generateSuper(ClassFileWriter paramClassFileWriter, String paramString1, String paramString2, String paramString3, String paramString4, Class[] paramArrayOfClass, Class paramClass) {
/* 681 */     paramClassFileWriter.startMethod("super$" + paramString3, paramString4, (short)
/* 682 */         1);
/*     */ 
/*     */     
/* 685 */     paramClassFileWriter.add((byte)25, 0);
/*     */ 
/*     */     
/* 688 */     int i = 1;
/* 689 */     for (byte b = 0; b < paramArrayOfClass.length; b++) {
/* 690 */       if (paramArrayOfClass[b].isPrimitive()) {
/* 691 */         i = generatePushParam(paramClassFileWriter, i, paramArrayOfClass[b]);
/*     */       } else {
/* 693 */         paramClassFileWriter.add((byte)25, i++);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 698 */     int j = paramString4.indexOf(')');
/*     */ 
/*     */     
/* 701 */     paramClassFileWriter.add((byte)-73, 
/* 702 */         paramString2, 
/* 703 */         paramString3, 
/* 704 */         paramString4.substring(0, j + 1), 
/* 705 */         paramString4.substring(j + 1));
/*     */ 
/*     */     
/* 708 */     Class clazz = paramClass;
/* 709 */     if (!clazz.equals(void.class)) {
/* 710 */       generatePopResult(paramClassFileWriter, clazz);
/*     */     } else {
/* 712 */       paramClassFileWriter.add((byte)-79);
/*     */     } 
/* 714 */     paramClassFileWriter.stopMethod((short)(i + 1), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getMethodSignature(Method paramMethod) {
/* 721 */     Class[] arrayOfClass = paramMethod.getParameterTypes();
/* 722 */     StringBuffer stringBuffer = new StringBuffer();
/* 723 */     stringBuffer.append('(');
/* 724 */     for (byte b = 0; b < arrayOfClass.length; b++) {
/* 725 */       Class clazz = arrayOfClass[b];
/* 726 */       appendTypeString(stringBuffer, clazz);
/*     */     } 
/* 728 */     stringBuffer.append(')');
/* 729 */     appendTypeString(stringBuffer, paramMethod.getReturnType());
/* 730 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static StringBuffer appendTypeString(StringBuffer paramStringBuffer, Class paramClass) {
/* 735 */     while (paramClass.isArray()) {
/* 736 */       paramStringBuffer.append('[');
/* 737 */       paramClass = paramClass.getComponentType();
/*     */     } 
/* 739 */     if (paramClass.isPrimitive()) {
/* 740 */       if (paramClass.equals(boolean.class)) {
/* 741 */         paramStringBuffer.append('Z');
/*     */       }
/* 743 */       else if (paramClass.equals(long.class)) {
/* 744 */         paramStringBuffer.append('J');
/*     */       } else {
/* 746 */         String str = paramClass.getName();
/* 747 */         paramStringBuffer.append(Character.toUpperCase(str.charAt(0)));
/*     */       } 
/*     */     } else {
/* 750 */       paramStringBuffer.append('L');
/* 751 */       paramStringBuffer.append(paramClass.getName().replace('.', '/'));
/* 752 */       paramStringBuffer.append(';');
/*     */     } 
/* 754 */     return paramStringBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object getProperty(Scriptable paramScriptable, String paramString) {
/* 762 */     Scriptable scriptable = paramScriptable;
/* 763 */     Object object = null;
/*     */     while (true) {
/* 765 */       object = scriptable.get(paramString, paramScriptable);
/* 766 */       if (object == Scriptable.NOT_FOUND) {
/*     */         
/* 768 */         scriptable = scriptable.getPrototype();
/* 769 */         if (scriptable == null)
/* 770 */           return Undefined.instance;  continue;
/*     */       }  break;
/* 772 */     }  return object;
/*     */   }
/*     */   
/*     */   static final class MyClassLoader
/*     */     extends ClassLoader {
/* 777 */     public Class defineClass(String param1String, byte[] param1ArrayOfByte) { return defineClass(param1String, param1ArrayOfByte, 0, param1ArrayOfByte.length); }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Class loadClass(String param1String, boolean param1Boolean) throws ClassNotFoundException {
/* 783 */       Class clazz = findLoadedClass(param1String);
/* 784 */       if (clazz == null) {
/* 785 */         ClassLoader classLoader = getClass().getClassLoader();
/*     */         try {
/* 787 */           if (classLoader != null)
/* 788 */             return classLoader.loadClass(param1String); 
/* 789 */           clazz = findSystemClass(param1String);
/* 790 */         } catch (ClassNotFoundException classNotFoundException) {
/* 791 */           return ScriptRuntime.loadClassName(param1String);
/*     */         } 
/*     */       } 
/* 794 */       if (param1Boolean)
/* 795 */         resolveClass(clazz); 
/* 796 */       return clazz;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class ClassSignature
/*     */   {
/*     */     Class mSuperClass;
/*     */     
/*     */     Class[] mInterfaces;
/*     */     
/*     */     Object[] mProperties;
/*     */     
/*     */     ClassSignature(Class param1Class, Class[] param1ArrayOfClass, Scriptable param1Scriptable) {
/* 810 */       this.mSuperClass = param1Class;
/* 811 */       this.mInterfaces = param1ArrayOfClass;
/* 812 */       this.mProperties = param1Scriptable.getIds();
/*     */     }
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 816 */       if (param1Object instanceof ClassSignature) {
/* 817 */         ClassSignature classSignature = (ClassSignature)param1Object;
/* 818 */         if (this.mSuperClass == classSignature.mSuperClass) {
/* 819 */           Class[] arrayOfClass = classSignature.mInterfaces;
/* 820 */           if (this.mInterfaces != arrayOfClass) {
/* 821 */             if (this.mInterfaces == null || arrayOfClass == null)
/* 822 */               return false; 
/* 823 */             if (this.mInterfaces.length != arrayOfClass.length)
/* 824 */               return false; 
/* 825 */             for (byte b1 = 0; b1 < arrayOfClass.length; b1++) {
/* 826 */               if (this.mInterfaces[b1] != arrayOfClass[b1])
/* 827 */                 return false; 
/*     */             } 
/* 829 */           }  Object[] arrayOfObject = classSignature.mProperties;
/* 830 */           if (this.mProperties.length != arrayOfObject.length)
/* 831 */             return false; 
/* 832 */           for (byte b = 0; b < arrayOfObject.length; b++) {
/* 833 */             if (!this.mProperties[b].equals(arrayOfObject[b]))
/* 834 */               return false; 
/* 835 */           }  return true;
/*     */         } 
/*     */       } 
/* 838 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 842 */     public int hashCode() { return this.mSuperClass.hashCode(); }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 848 */   private static Hashtable generatedClasses = new Hashtable(7);
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\JavaAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */