/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LineBuffer
/*     */ {
/*     */   static final int BUFLEN = 256;
/*     */   private Reader in;
/*     */   private char[] otherBuffer;
/*     */   private char[] buffer;
/*     */   private int offset;
/*     */   private int end;
/*     */   private int otherEnd;
/*     */   private int lineno;
/*     */   private int lineStart;
/*     */   private int otherStart;
/*     */   private int prevStart;
/*     */   private boolean lastWasCR;
/*     */   private boolean hitEOF;
/*     */   private int stringStart;
/*     */   private StringBuffer stringSoFar;
/*     */   private boolean hadCFSinceStringStart;
/*     */   
/*     */   LineBuffer(Reader paramReader, int paramInt) {
/* 390 */     this.otherBuffer = null;
/* 391 */     this.buffer = null;
/*     */ 
/*     */     
/* 394 */     this.offset = 0;
/* 395 */     this.end = 0;
/*     */ 
/*     */ 
/*     */     
/* 399 */     this.lineStart = 0;
/* 400 */     this.otherStart = 0;
/* 401 */     this.prevStart = 0;
/*     */     
/* 403 */     this.lastWasCR = false;
/* 404 */     this.hitEOF = false;
/*     */     
/* 406 */     this.stringStart = -1;
/* 407 */     this.stringSoFar = null;
/* 408 */     this.hadCFSinceStringStart = false;
/*     */     this.in = paramReader;
/*     */     this.lineno = paramInt;
/*     */   }
/*     */   
/*     */   int read() {
/*     */     while (true) {
/*     */       if (this.end == this.offset && !fill())
/*     */         return -1; 
/*     */       if ((this.buffer[this.offset] & 0xDFD0) == '\000') {
/*     */         if (this.buffer[this.offset] == '\r') {
/*     */           if (this.offset + 1 < this.end) {
/*     */             if (this.buffer[this.offset + 1] == '\n')
/*     */               this.offset++; 
/*     */           } else {
/*     */             this.lastWasCR = true;
/*     */           } 
/*     */         } else if (this.buffer[this.offset] != '\n' && this.buffer[this.offset] != ' ' && this.buffer[this.offset] != ' ') {
/*     */           if (Character.getType(this.buffer[this.offset]) == 16) {
/*     */             this.hadCFSinceStringStart = true;
/*     */             this.offset++;
/*     */             continue;
/*     */           } 
/*     */           return this.buffer[this.offset++];
/*     */         } 
/*     */         this.offset++;
/*     */         this.prevStart = this.lineStart;
/*     */         this.lineStart = this.offset;
/*     */         this.lineno++;
/*     */         return 10;
/*     */       } 
/*     */       if (this.buffer[this.offset] >= '' && Character.getType(this.buffer[this.offset]) == 16) {
/*     */         this.hadCFSinceStringStart = true;
/*     */         this.offset++;
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/*     */     return this.buffer[this.offset++];
/*     */   }
/*     */   
/*     */   void unread() {
/*     */     if (this.offset == 0)
/*     */       return; 
/*     */     this.offset--;
/*     */     if ((this.buffer[this.offset] & 0xFFF0) == '\000' && (this.buffer[this.offset] == '\r' || this.buffer[this.offset] == '\n')) {
/*     */       this.lineStart = this.prevStart;
/*     */       this.lineno--;
/*     */     } 
/*     */   }
/*     */   
/*     */   int peek() {
/*     */     if (this.end == this.offset && !fill())
/*     */       return -1; 
/*     */     if (this.buffer[this.offset] == '\r')
/*     */       return 10; 
/*     */     return this.buffer[this.offset];
/*     */   }
/*     */   
/*     */   boolean match(char paramChar) throws IOException {
/*     */     if (this.end == this.offset && !fill())
/*     */       return false; 
/*     */     if (this.buffer[this.offset] == paramChar) {
/*     */       this.offset++;
/*     */       return true;
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   String getLine() {
/*     */     StringBuffer stringBuffer = new StringBuffer();
/*     */     int i = this.lineStart;
/*     */     if (i >= this.offset) {
/*     */       if (this.otherStart < this.otherEnd)
/*     */         stringBuffer.append(this.otherBuffer, this.otherStart, this.otherEnd - this.otherStart); 
/*     */       i = 0;
/*     */     } 
/*     */     stringBuffer.append(this.buffer, i, this.offset - i);
/*     */     int j = this.offset;
/*     */     while (true) {
/*     */       if (j == this.buffer.length) {
/*     */         char[] arrayOfChar = new char[this.buffer.length * 2];
/*     */         System.arraycopy(this.buffer, 0, arrayOfChar, 0, this.buffer.length);
/*     */         this.buffer = arrayOfChar;
/*     */         int k = 0;
/*     */         try {
/*     */           k = this.in.read(this.buffer, this.end, this.buffer.length - this.end);
/*     */         } catch (IOException iOException) {}
/*     */         if (k >= 0) {
/*     */           this.end += k;
/*     */         } else {
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       if (this.buffer[j] == '\r' || this.buffer[j] == '\n')
/*     */         break; 
/*     */       j++;
/*     */     } 
/*     */     stringBuffer.append(this.buffer, this.offset, j - this.offset);
/*     */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   int getOffset() {
/*     */     if (this.lineStart >= this.offset)
/*     */       return this.offset + this.otherEnd - this.otherStart; 
/*     */     return this.offset - this.lineStart;
/*     */   }
/*     */   
/*     */   void startString() {
/*     */     if (this.offset == 0) {
/*     */       this.stringSoFar = new StringBuffer();
/*     */       this.stringSoFar.append(this.otherBuffer, this.otherEnd - 1, 1);
/*     */       this.stringStart = -1;
/*     */       this.hadCFSinceStringStart = !(this.otherBuffer[this.otherEnd - 1] < '' || Character.getType(this.otherBuffer[this.otherEnd - 1]) != 16);
/*     */     } else {
/*     */       this.stringSoFar = null;
/*     */       this.stringStart = this.offset - 1;
/*     */       this.hadCFSinceStringStart = !(this.buffer[this.stringStart] < '' || Character.getType(this.buffer[this.stringStart]) != 16);
/*     */     } 
/*     */   }
/*     */   
/*     */   String getString() {
/*     */     String str;
/*     */     int i = (this.offset > 0 && this.buffer[this.offset] == '\n' && this.buffer[this.offset - 1] == '\r') ? 1 : 0;
/*     */     if (this.stringStart != -1) {
/*     */       str = new String(this.buffer, this.stringStart, this.offset - this.stringStart - i);
/*     */     } else {
/*     */       if (this.stringSoFar == null)
/*     */         this.stringSoFar = new StringBuffer(); 
/*     */       str = this.stringSoFar.append(this.buffer, 0, this.offset - i).toString();
/*     */     } 
/*     */     this.stringStart = -1;
/*     */     this.stringSoFar = null;
/*     */     if (this.hadCFSinceStringStart) {
/*     */       char[] arrayOfChar = str.toCharArray();
/*     */       StringBuffer stringBuffer = null;
/*     */       for (byte b = 0; b < arrayOfChar.length; b++) {
/*     */         if (Character.getType(arrayOfChar[b]) == 16) {
/*     */           if (stringBuffer == null) {
/*     */             stringBuffer = new StringBuffer();
/*     */             stringBuffer.append(arrayOfChar, 0, b);
/*     */           } 
/*     */         } else if (stringBuffer != null) {
/*     */           stringBuffer.append(arrayOfChar[b]);
/*     */         } 
/*     */       } 
/*     */       if (stringBuffer != null)
/*     */         str = stringBuffer.toString(); 
/*     */     } 
/*     */     return str;
/*     */   }
/*     */   
/*     */   boolean fill() {
/*     */     if (this.end - this.offset != 0)
/*     */       throw new IOException("fill of non-empty buffer"); 
/*     */     int i = (this.offset > 0 && this.lastWasCR) ? 1 : 0;
/*     */     if (this.stringStart != -1) {
/*     */       this.stringSoFar = new StringBuffer();
/*     */       this.stringSoFar.append(this.buffer, this.stringStart, this.end - this.stringStart - i);
/*     */       this.stringStart = -1;
/*     */     } else if (this.stringSoFar != null) {
/*     */       this.stringSoFar.append(this.buffer, 0, this.end - i);
/*     */     } 
/*     */     char[] arrayOfChar = this.buffer;
/*     */     this.buffer = this.otherBuffer;
/*     */     this.otherBuffer = arrayOfChar;
/*     */     if (this.buffer == null)
/*     */       this.buffer = new char[256]; 
/*     */     this.otherStart = this.lineStart;
/*     */     this.otherEnd = this.end;
/*     */     this.prevStart = this.lineStart = (this.otherBuffer == null) ? 0 : (this.buffer.length + 1);
/*     */     this.offset = 0;
/*     */     this.end = this.in.read(this.buffer, 0, this.buffer.length);
/*     */     if (this.end < 0) {
/*     */       this.end = 0;
/*     */       this.hitEOF = true;
/*     */       return false;
/*     */     } 
/*     */     if (this.lastWasCR) {
/*     */       if (this.buffer[0] == '\n') {
/*     */         this.offset++;
/*     */         if (this.end == 1)
/*     */           return fill(); 
/*     */       } 
/*     */       this.lineStart = this.offset;
/*     */       this.lastWasCR = false;
/*     */     } 
/*     */     return true;
/*     */   }
/*     */   
/*     */   int getLineno() { return this.lineno; }
/*     */   
/*     */   boolean eof() { return this.hitEOF; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\org\mozilla\javascript\LineBuffer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */