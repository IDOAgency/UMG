package com.ibm.xml.parser;

import java.util.BitSet;

public class CM1op extends CMNode {
  static final long serialVersionUID = -7652557073411492117L;
  
  int type;
  
  CMNode node;
  
  public CM1op(int paramInt, CMNode paramCMNode) {
    this.type = paramInt;
    this.node = paramCMNode;
  }
  
  public int getType() { return this.type; }
  
  public CMNode getNode() { return this.node; }
  
  public void setNode(CMNode paramCMNode) { this.node = paramCMNode; }
  
  public String toString() { return String.valueOf(this.node.toString()) + (char)this.type; }
  
  boolean nullable() {
    if (this.nullable == null) {
      boolean bool = false;
      switch (this.type) {
        case 42:
          bool = true;
          break;
        case 43:
          bool = this.node.nullable();
          break;
        case 63:
          bool = true;
          break;
      } 
      this.nullable = new Boolean(bool);
    } 
    return this.nullable.booleanValue();
  }
  
  CMNode cloneNode() { return new CM1op(this.type, this.node.cloneNode()); }
  
  BitSet firstpos() {
    if (this.firstPos == null)
      this.firstPos = this.node.firstpos(); 
    return this.firstPos;
  }
  
  BitSet lastpos() {
    if (this.lastPos == null)
      this.lastPos = this.node.lastpos(); 
    return this.lastPos;
  }
  
  void prepare(int paramInt) { this.node.prepare(paramInt); }
  
  void setFollowpos(BitSet[] paramArrayOfBitSet) throws LibraryException {
    this.node.setFollowpos(paramArrayOfBitSet);
    if (this.type == 43)
      throw new LibraryException("com.ibm.xml.parser.CM1op#setFollowpos(): This method should not have been called for plus (+) operator."); 
    if (this.type == 42)
      for (byte b = 0; b < paramArrayOfBitSet.length; b++) {
        if (lastpos().get(b))
          paramArrayOfBitSet[b].or(firstpos()); 
      }  
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == null)
      return false; 
    if (!(paramObject instanceof CM1op))
      return false; 
    CM1op cM1op = (CM1op)paramObject;
    return (cM1op.getType() != getType()) ? false : cM1op.getNode().equals(getNode());
  }
  
  public int hashCode() { return getNode().hashCode(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\CM1op.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */