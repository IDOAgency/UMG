package com.ibm.xml.parser;

import java.io.Serializable;
import java.util.BitSet;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class ContentModel implements Cloneable, Serializable {
  static final long serialVersionUID = 5286575228052158978L;
  
  private static final boolean DEBUG_VALIDATION = false;
  
  TXDocument factory;
  
  int type = 4;
  
  CMNode modelGroupNode;
  
  CMNode rootContentModelNode;
  
  Hashtable symbolHashTable;
  
  Object[] symbolNextStateTable;
  
  boolean[] terminalFlag;
  
  String pseudo;
  
  public ContentModel(int paramInt) { this.type = paramInt; }
  
  public ContentModel(CMNode paramCMNode) {
    this.type = 4;
    this.modelGroupNode = paramCMNode;
  }
  
  public Object clone() {
    ContentModel contentModel = (this.factory == null) ? new ContentModel(this.type) : this.factory.createContentModel(this.type);
    contentModel.setFactory(getFactory());
    if (this.modelGroupNode != null)
      contentModel.modelGroupNode = this.modelGroupNode.cloneNode(); 
    contentModel.pseudo = this.pseudo;
    return contentModel;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == null)
      return false; 
    if (!(paramObject instanceof ContentModel))
      return false; 
    ContentModel contentModel = (ContentModel)paramObject;
    return (contentModel.getType() != getType()) ? false : ((getType() != 4) ? true : ((this.modelGroupNode == null) ? true : this.modelGroupNode.equals(contentModel.modelGroupNode)));
  }
  
  public int hashCode() { return this.modelGroupNode.hashCode(); }
  
  public String toString() {
    if (this.pseudo != null)
      return this.pseudo; 
    String str = "com.ibm.xml.parser.ContentModel#toString(): Internal error";
    switch (this.type) {
      case 1:
        str = "EMPTY";
        break;
      case 2:
        str = "ANY";
        break;
      case 4:
        if (this.modelGroupNode instanceof CM1op && ((CM1op)this.modelGroupNode).getNode() instanceof CMLeaf) {
          CM1op cM1op = (CM1op)this.modelGroupNode;
          str = "(" + cM1op.getNode() + ")" + (char)cM1op.getType();
          break;
        } 
        if (this.modelGroupNode instanceof CMLeaf) {
          str = "(" + this.modelGroupNode + ")";
          break;
        } 
        str = this.modelGroupNode.toString();
        break;
    } 
    return str;
  }
  
  public TXDocument getFactory() { return this.factory; }
  
  public void setFactory(TXDocument paramTXDocument) { this.factory = paramTXDocument; }
  
  public CMNode getContentModelNode() { return this.modelGroupNode; }
  
  public void setContentModelNode(CMNode paramCMNode) {
    this.modelGroupNode = paramCMNode;
    this.rootContentModelNode = null;
  }
  
  public String getPseudoContentModel() { return this.pseudo; }
  
  public void setPseudoContentModel(String paramString) { this.pseudo = paramString; }
  
  int getType() { return this.type; }
  
  void setType(int paramInt) {
    this.type = paramInt;
    if (paramInt == 1 || paramInt == 2)
      this.modelGroupNode = null; 
  }
  
  void toDFA() {
    if (this.modelGroupNode == null)
      return; 
    if (this.rootContentModelNode != null)
      return; 
    CMLeaf cMLeaf = new CMLeaf(" *EOC* ");
    this.rootContentModelNode = new CM2op(44, checkPlus(this.modelGroupNode), cMLeaf);
    Vector vector1 = new Vector();
    countLeaf(vector1, this.rootContentModelNode);
    int i = vector1.size();
    this.rootContentModelNode.prepare(i);
    this.symbolHashTable = new Hashtable();
    byte b1 = 0;
    for (byte b2 = 0; b2 < i; b2++) {
      String str = ((CMLeaf)vector1.elementAt(b2)).getName();
      if (str != null && !this.symbolHashTable.containsKey(str))
        this.symbolHashTable.put(str, new Symbol(str, b1++)); 
    } 
    BitSet[] arrayOfBitSet = new BitSet[i];
    for (byte b3 = 0; b3 < i; b3++)
      arrayOfBitSet[b3] = new BitSet(i); 
    this.rootContentModelNode.setFollowpos(arrayOfBitSet);
    Vector vector2 = new Vector();
    Vector vector3 = new Vector();
    Hashtable hashtable = new Hashtable();
    BitSet bitSet1 = this.rootContentModelNode.firstpos();
    byte b4 = 0;
    byte b5 = 0;
    int j = cMLeaf.getPosition();
    Vector vector4 = new Vector();
    hashtable.put(bitSet1, new Integer(b4++));
    vector2.addElement(bitSet1);
    vector3.addElement(makeArrayFilledMinus1(b1));
    BitSet bitSet2 = new BitSet(i);
    while (b5 < b4) {
      bitSet1 = (BitSet)vector2.elementAt(b5++);
      int[] arrayOfInt = (int[])vector3.elementAt(((Integer)hashtable.get(bitSet1)).intValue());
      vector4.addElement(new Boolean(bitSet1.get(j)));
      Enumeration enumeration = this.symbolHashTable.elements();
      while (enumeration.hasMoreElements()) {
        Symbol symbol = (Symbol)enumeration.nextElement();
        BitSet bitSet = new BitSet(i);
        for (byte b = 0; b < i; b++) {
          if (bitSet1.get(b)) {
            CMLeaf cMLeaf1 = (CMLeaf)vector1.elementAt(b);
            if (cMLeaf1.getName().equals(symbol.m_sym))
              bitSet.or(arrayOfBitSet[b]); 
          } 
        } 
        if (!bitSet2.equals(bitSet)) {
          if (!hashtable.containsKey(bitSet)) {
            vector2.addElement(bitSet);
            vector3.addElement(makeArrayFilledMinus1(b1));
            hashtable.put(bitSet, new Integer(b4++));
          } 
          arrayOfInt[symbol.m_id] = ((Integer)hashtable.get(bitSet)).intValue();
        } 
      } 
    } 
    this.symbolNextStateTable = new Object[vector3.size()];
    vector3.copyInto(this.symbolNextStateTable);
    this.terminalFlag = new boolean[vector3.size()];
    for (byte b6 = 0; b6 < vector4.size(); b6++)
      this.terminalFlag[b6] = ((Boolean)vector4.elementAt(b6)).booleanValue(); 
  }
  
  boolean check(TXElement paramTXElement) throws LibraryException {
    if (this.type == 1)
      return !paramTXElement.hasChildNodes(); 
    if (this.type == 2)
      return true; 
    if (this.type == 4) {
      toDFA();
      int i = 0;
      TXElement tXElement = paramTXElement;
      for (Node node = paramTXElement.getFirstChild(); node != null || tXElement.getNodeType() != 1; node = node.getNextSibling()) {
        if (node == null) {
          node = tXElement.getNextSibling();
          Node node1 = tXElement.getParentNode();
          continue;
        } 
        if (node.getNodeType() == 5) {
          Node node1 = node;
          node = node.getFirstChild();
          continue;
        } 
        short s = node.getNodeType();
        if ((s == 3 && !((TXText)node).getIsIgnorableWhitespace()) || s == 1) {
          String str = (s == 3) ? "#PCDATA" : node.getNodeName();
          int j = getSymbolID(str);
          if (j < 0)
            return false; 
          i = (int[])this.symbolNextStateTable[i][j];
          if (i < 0)
            return false; 
        } 
      } 
      return this.terminalFlag[i];
    } 
    throw new LibraryException("com.ibm.xml.parser.ContentModel#check(" + paramTXElement + "): Unsupported element declaration type detected. " + toString());
  }
  
  Node validate(TXElement paramTXElement) {
    if (this.type == 1)
      return paramTXElement.hasChildNodes() ? paramTXElement : null; 
    if (this.type == 2)
      return null; 
    Node node = null;
    if (this.type == 4) {
      toDFA();
      int i = 0;
      TXElement tXElement = paramTXElement;
      Node node1 = paramTXElement.getFirstChild();
      while (node1 != null) {
        Node node2;
        short s = node1.getNodeType();
        if (s == 5) {
          node2 = node1;
          node1 = node1.getFirstChild();
        } else if (s == 1 || (s == 3 && !((TXText)node1).getIsIgnorableWhitespace())) {
          String str = (s == 3) ? "#PCDATA" : node1.getNodeName();
          int j = getSymbolID(str);
          if (j < 0) {
            node = node1;
            break;
          } 
          i = (int[])this.symbolNextStateTable[i][j];
          if (i < 0) {
            node = node1;
            break;
          } 
          node1 = node1.getNextSibling();
        } else {
          node1 = node1.getNextSibling();
        } 
        if (node1 == null && node2 != paramTXElement) {
          node1 = node2.getNextSibling();
          node2 = node2.getParentNode();
        } 
      } 
      if (node == null && !this.terminalFlag[i])
        node = paramTXElement; 
    } else {
      node = paramTXElement;
    } 
    return node;
  }
  
  Hashtable prepareTable() {
    Hashtable hashtable = new Hashtable();
    toDFA();
    if (this.type == 4) {
      Enumeration enumeration = this.symbolHashTable.elements();
      while (enumeration.hasMoreElements()) {
        Symbol symbol = (Symbol)enumeration.nextElement();
        hashtable.put(symbol.m_sym, new InsertableElement(symbol.m_sym, false));
      } 
    } 
    hashtable.put("#PCDATA", new InsertableElement("#PCDATA", false));
    hashtable.put(" *EOC* ", new InsertableElement(" *EOC* ", false));
    hashtable.put(" *ERROR* ", new InsertableElement(" *ERROR* ", false));
    return hashtable;
  }
  
  static void cleanTable(Hashtable paramHashtable) {
    Enumeration enumeration = paramHashtable.elements();
    while (enumeration.hasMoreElements()) {
      InsertableElement insertableElement = (InsertableElement)enumeration.nextElement();
      insertableElement.status = false;
      insertableElement.index = -1;
    } 
    if (paramHashtable.get("#PCDATA") == null)
      paramHashtable.put("#PCDATA", new InsertableElement("#PCDATA", false)); 
    if (paramHashtable.get(" *EOC* ") == null)
      paramHashtable.put(" *EOC* ", new InsertableElement(" *EOC* ", false)); 
    if (paramHashtable.get(" *ERROR* ") == null)
      paramHashtable.put(" *ERROR* ", new InsertableElement(" *ERROR* ", false)); 
  }
  
  static Object[] makeLinearContents(Element paramElement, int paramInt) {
    Vector vector = new Vector();
    Element element = paramElement;
    for (Node node = paramElement.getFirstChild(); node != null || !(element instanceof Element); node = node.getNextSibling()) {
      Node node1;
      if (node == null) {
        node = element.getNextSibling();
        node1 = element.getParentNode();
        continue;
      } 
      if (node instanceof org.w3c.dom.EntityReference) {
        node1 = node;
        node = node.getFirstChild();
        if (vector.size() < paramInt)
          paramInt--; 
        continue;
      } 
      vector.addElement(node);
      if (vector.size() < paramInt && node1 instanceof org.w3c.dom.EntityReference)
        paramInt++; 
    } 
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = vector;
    arrayOfObject[1] = new Integer(paramInt);
    return arrayOfObject;
  }
  
  Hashtable getInsertableElements(Element paramElement, int paramInt, Hashtable paramHashtable, boolean paramBoolean) {
    cleanTable(paramHashtable);
    if (this.type == 1) {
      ((InsertableElement)paramHashtable.get("#PCDATA")).status = false;
      ((InsertableElement)paramHashtable.get(" *EOC* ")).status = true;
      InsertableElement insertableElement = (InsertableElement)paramHashtable.get(" *ERROR* ");
      if (!paramElement.hasChildNodes()) {
        insertableElement.status = false;
      } else {
        insertableElement.status = true;
        insertableElement.index = 0;
      } 
    } else if (this.type == 2) {
      Enumeration enumeration = paramHashtable.elements();
      while (enumeration.hasMoreElements()) {
        InsertableElement insertableElement = (InsertableElement)enumeration.nextElement();
        insertableElement.status = true;
      } 
      ((InsertableElement)paramHashtable.get(" *ERROR* ")).status = false;
    } else if (this.type == 4) {
      Object[] arrayOfObject = makeLinearContents(paramElement, paramInt);
      paramInt = ((Integer)arrayOfObject[1]).intValue();
      Vector vector = (Vector)arrayOfObject[0];
      if (paramInt < 0) {
        paramInt = 0;
      } else if (vector.size() < paramInt) {
        paramInt = vector.size();
      } 
      toDFA();
      int i = 0;
      boolean bool = false;
      byte b;
      for (b = 0; b < paramInt; b++) {
        Node node = (Node)vector.elementAt(b);
        short s = node.getNodeType();
        if ((s == 3 && !((TXText)node).getIsIgnorableWhitespace()) || s == 1) {
          String str = (s == 3) ? "#PCDATA" : node.getNodeName();
          int j = getSymbolID(str);
          if (j < 0) {
            bool = true;
            break;
          } 
          i = (int[])this.symbolNextStateTable[i][j];
          if (i < 0) {
            bool = true;
            break;
          } 
        } 
      } 
      if (!bool) {
        Enumeration enumeration = this.symbolHashTable.elements();
        while (enumeration.hasMoreElements()) {
          Symbol symbol = (Symbol)enumeration.nextElement();
          InsertableElement insertableElement = (InsertableElement)paramHashtable.get(symbol.m_sym);
          if (insertableElement == null)
            paramHashtable.put(symbol.m_sym, insertableElement = new InsertableElement(symbol.m_sym)); 
          int j = (int[])this.symbolNextStateTable[i][symbol.m_id];
          insertableElement.status = paramBoolean ? checkAfterTargetPosition(vector, paramInt, j) : ((j < 0) ? 0 : 1);
        } 
        ((InsertableElement)paramHashtable.get(" *EOC* ")).status = this.terminalFlag[i];
      } else {
        InsertableElement insertableElement = (InsertableElement)paramHashtable.get(" *ERROR* ");
        insertableElement.status = true;
        insertableElement.index = b;
      } 
    } 
    return paramHashtable;
  }
  
  boolean checkAfterTargetPosition(Vector paramVector, int paramInt1, int paramInt2) {
    if (paramInt2 < 0)
      return false; 
    for (int i = paramInt1; i < paramVector.size(); i++) {
      Node node = (Node)paramVector.elementAt(i);
      short s = node.getNodeType();
      if ((s == 3 && !((TXText)node).getIsIgnorableWhitespace()) || s == 1) {
        String str = (s == 3) ? "#PCDATA" : node.getNodeName();
        int j = getSymbolID(str);
        if (j < 0)
          return false; 
        paramInt2 = (int[])this.symbolNextStateTable[paramInt2][j];
        if (paramInt2 < 0)
          return false; 
      } 
    } 
    return this.terminalFlag[paramInt2];
  }
  
  Vector getChildrenOrder() {
    if (this.modelGroupNode == null)
      return null; 
    Vector vector = new Vector();
    appendNode(vector, this.modelGroupNode);
    return vector;
  }
  
  private void appendNode(Vector paramVector, CMNode paramCMNode) throws LibraryException {
    if (paramCMNode instanceof CM1op) {
      appendNode(paramVector, ((CM1op)paramCMNode).getNode());
      return;
    } 
    if (paramCMNode instanceof CM2op) {
      appendNode(paramVector, ((CM2op)paramCMNode).getLeft());
      appendNode(paramVector, ((CM2op)paramCMNode).getRight());
      return;
    } 
    if (paramCMNode instanceof CMLeaf) {
      paramVector.addElement(((CMLeaf)paramCMNode).getName());
      return;
    } 
    throw new LibraryException("com.ibm.xml.parser.ContentModel#appendNode(): Invalid CMNode detected.");
  }
  
  private void countLeaf(Vector paramVector, CMNode paramCMNode) throws LibraryException {
    if (paramCMNode instanceof CMLeaf) {
      ((CMLeaf)paramCMNode).setPosition(paramVector.size());
      paramVector.addElement(paramCMNode);
      return;
    } 
    if (paramCMNode instanceof CM1op) {
      countLeaf(paramVector, ((CM1op)paramCMNode).getNode());
      return;
    } 
    if (paramCMNode instanceof CM2op) {
      countLeaf(paramVector, ((CM2op)paramCMNode).getLeft());
      countLeaf(paramVector, ((CM2op)paramCMNode).getRight());
    } 
  }
  
  private CMNode checkPlus(CMNode paramCMNode) {
    CMNode cMNode = null;
    if (paramCMNode instanceof CM1op) {
      CM1op cM1op = (CM1op)paramCMNode;
      if (cM1op.getType() == 43) {
        CMNode cMNode1 = checkPlus(cM1op.getNode());
        cMNode = new CM2op(44, cMNode1, new CM1op(42, cMNode1.cloneNode()));
      } else {
        CM1op cM1op1 = new CM1op(cM1op.getType(), checkPlus(cM1op.getNode()));
      } 
    } else if (paramCMNode instanceof CM2op) {
      CM2op cM2op = (CM2op)paramCMNode;
      cMNode = new CM2op(cM2op.getType(), checkPlus(cM2op.getLeft()), checkPlus(cM2op.getRight()));
    } else if (paramCMNode instanceof CMLeaf) {
      if (((CMLeaf)paramCMNode).getName().equals("#PCDATA")) {
        CM1op cM1op = new CM1op(42, paramCMNode);
      } else {
        cMNode = paramCMNode;
      } 
    } 
    return cMNode;
  }
  
  private int getSymbolID(String paramString) {
    Symbol symbol = (Symbol)this.symbolHashTable.get(paramString);
    return (symbol == null) ? -1 : symbol.m_id;
  }
  
  private int[] makeArrayFilledMinus1(int paramInt) {
    int[] arrayOfInt = new int[paramInt];
    for (byte b = 0; b < paramInt; b++)
      arrayOfInt[b] = -1; 
    return arrayOfInt;
  }
  
  static class Symbol {
    String m_sym;
    
    int m_id;
    
    Symbol(String param1String, int param1Int) {
      this.m_sym = param1String;
      this.m_id = param1Int;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\ContentModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */