package com.ibm.xml.parser;

import java.io.InputStream;
import java.io.Reader;

public class Source {
  InputStream inputStream;
  
  Reader reader;
  
  String encoding;
  
  public Source(InputStream paramInputStream) { this.inputStream = paramInputStream; }
  
  public Source(InputStream paramInputStream, String paramString) {
    this.inputStream = paramInputStream;
    this.encoding = paramString;
  }
  
  public Source(Reader paramReader) { this.reader = paramReader; }
  
  public InputStream getInputStream() { return this.inputStream; }
  
  public String getEncoding() { return this.encoding; }
  
  public Reader getReader() { return this.reader; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\Source.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */