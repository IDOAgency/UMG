package com.ibm.xml.parser;

public class Match {
  public static final int QNAME = 0;
  
  public static final int NSLOCAL = 2;
  
  public static final int NS = 4;
  
  public static boolean matchName(Namespace paramNamespace, int paramInt, String paramString1, String paramString2) {
    boolean bool = false;
    switch (paramInt) {
      case 0:
        if (paramString2.equals("*")) {
          bool = true;
          break;
        } 
        bool = paramNamespace.getName().equals(paramString2);
        break;
      case 2:
        bool = !(((paramString1 != null || paramNamespace.getNSName() != null) && !paramString1.equals(paramNamespace.getNSName())) || !paramString2.equals(paramNamespace.getNSLocalName()));
        break;
      case 4:
        bool = paramString1.equals(paramNamespace.getNSName());
        break;
    } 
    return bool;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\Match.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */