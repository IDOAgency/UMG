package com.ibm.xml.parser;

public interface NoRequiredAttributeHandler {
  TXElement handleNoRequiredAttribute(TXElement paramTXElement, String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\NoRequiredAttributeHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */