package com.ibm.xml.parser;

public class Version {
  public static String S_VERSION = "1.1.16";
  
  public static int MAJOR = 1;
  
  public static int MINOR = 1;
  
  public static int SUBMINOR = 16;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\Version.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */