package com.ibm.xml.parser.util;

import com.ibm.xml.parser.AttDef;
import com.ibm.xml.parser.Attlist;
import com.ibm.xml.parser.Child;
import com.ibm.xml.parser.ContentModel;
import com.ibm.xml.parser.DTD;
import com.ibm.xml.parser.ElementDecl;
import com.ibm.xml.parser.EntityDecl;
import com.ibm.xml.parser.ExternalID;
import com.ibm.xml.parser.GeneralReference;
import com.ibm.xml.parser.PseudoNode;
import com.ibm.xml.parser.StylesheetPI;
import com.ibm.xml.parser.TXAttribute;
import com.ibm.xml.parser.TXCDATASection;
import com.ibm.xml.parser.TXComment;
import com.ibm.xml.parser.TXDocument;
import com.ibm.xml.parser.TXElement;
import com.ibm.xml.parser.TXNotation;
import com.ibm.xml.parser.TXPI;
import com.ibm.xml.parser.TXText;
import java.util.Enumeration;
import javax.swing.tree.TreeNode;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.Element;
import org.w3c.dom.EntityReference;
import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;

public class TreeFactory extends TXDocument implements TreeNode {
  public String convertValueToText(Object paramObject) {
    String str = "";
    switch (((Child)paramObject).getNodeType()) {
      case 1:
        str = toStringElement((TXElement)paramObject, null);
        break;
      case 2:
        str = toStringAttribute((TXAttribute)paramObject, null);
        break;
      case 7:
        str = toStringPI((ProcessingInstruction)paramObject, null);
        break;
      case 8:
        str = toStringComment((Comment)paramObject, null);
        break;
      case 3:
        str = toStringText((Text)paramObject, null);
        break;
      case 4:
        str = toStringCDATA((CDATASection)paramObject, null);
        break;
      case 9:
        str = toStringDocument((TXDocument)paramObject, null);
        break;
      case 10:
        str = toStringDTD((DTD)paramObject, null);
        break;
      case 20:
        str = toStringElementDecl((ElementDecl)paramObject, null);
        break;
      case 21:
        str = toStringAttlist((Attlist)paramObject, null);
        break;
      case 22:
        str = toStringAttDef((AttDef)paramObject, null);
        break;
      case 6:
        str = toStringEntityDecl((EntityDecl)paramObject, null);
        break;
      case 12:
        str = toStringNotation((TXNotation)paramObject, null);
        break;
      case 5:
        str = toStringGeneralReference((GeneralReference)paramObject, null);
        break;
      case 23:
        str = toStringPseudoNode((PseudoNode)paramObject, null);
        break;
    } 
    return str;
  }
  
  public String toStringAttDef(AttDef paramAttDef, String paramString) { return paramAttDef.getName(); }
  
  public String toStringAttlist(Attlist paramAttlist, String paramString) { return "!ATTLIST " + paramAttlist.getName(); }
  
  public String toStringDTD(DTD paramDTD, String paramString) { return "!DOCTYPE " + paramDTD.getName(); }
  
  public String toStringElementDecl(ElementDecl paramElementDecl, String paramString) { return "!ELEMENT " + paramElementDecl.getName(); }
  
  public String toStringEntityDecl(EntityDecl paramEntityDecl, String paramString) { return "!ENTITY " + (paramEntityDecl.isParameter() ? "% " : "") + paramEntityDecl.getNodeName(); }
  
  public String toStringComment(Comment paramComment, String paramString) { return "<!--" + paramComment.getData() + "-->"; }
  
  public String toStringDocument(TXDocument paramTXDocument, String paramString) { return "[DOCUMENT]"; }
  
  public String toStringElement(TXElement paramTXElement, String paramString) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("<");
    stringBuffer.append(paramTXElement.getNodeName());
    Enumeration enumeration = paramTXElement.attributeElements();
    while (enumeration.hasMoreElements()) {
      stringBuffer.append(" ");
      stringBuffer.append(((TXAttribute)enumeration.nextElement()).toXMLString(paramString));
    } 
    stringBuffer.append(">");
    return stringBuffer.toString();
  }
  
  public String toStringNotation(TXNotation paramTXNotation, String paramString) { return "!NOTATION " + paramTXNotation.getNodeName(); }
  
  public String toStringPI(ProcessingInstruction paramProcessingInstruction, String paramString) { return "<?" + paramProcessingInstruction.getTarget() + paramProcessingInstruction.getData() + "?>"; }
  
  public String toStringText(Text paramText, String paramString) { return "\"" + TXText.makePrintable(paramText.getData()) + "\""; }
  
  public String toStringCDATA(CDATASection paramCDATASection, String paramString) { return "<![CDATA[" + paramCDATASection.getData() + "]]>"; }
  
  public String toStringAttribute(TXAttribute paramTXAttribute, String paramString) { return ""; }
  
  public String toStringGeneralReference(GeneralReference paramGeneralReference, String paramString) { return "&" + paramGeneralReference.getName() + ";"; }
  
  public String toStringPseudoNode(PseudoNode paramPseudoNode, String paramString) { return paramPseudoNode.getData(); }
  
  public Element createElement(String paramString) {
    TreeElement treeElement = new TreeElement(paramString);
    treeElement.setFactory(this);
    return treeElement;
  }
  
  public TXText createTextNode(String paramString, boolean paramBoolean) {
    TreeText treeText = new TreeText(paramString);
    treeText.setFactory(this);
    treeText.setIsIgnorableWhitespace(paramBoolean);
    return treeText;
  }
  
  public TXText createTextNode(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) {
    TreeText treeText = new TreeText(new String(paramArrayOfChar, paramInt1, paramInt2));
    treeText.setFactory(this);
    treeText.setIsIgnorableWhitespace(paramBoolean);
    return treeText;
  }
  
  public CDATASection createCDATASection(String paramString) {
    TreeCDATASection treeCDATASection = new TreeCDATASection(paramString);
    treeCDATASection.setFactory(this);
    return treeCDATASection;
  }
  
  public Comment createComment(String paramString) {
    TreeComment treeComment = new TreeComment(paramString);
    treeComment.setFactory(this);
    return treeComment;
  }
  
  public ProcessingInstruction createProcessingInstruction(String paramString1, String paramString2) {
    TreePI treePI = new TreePI(paramString1, paramString2);
    treePI.setFactory(this);
    return treePI;
  }
  
  public StylesheetPI createStylesheetPI(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    TreeStylesheetPI treeStylesheetPI = new TreeStylesheetPI(paramString1, paramString2, paramString3, paramString4, paramString5);
    treeStylesheetPI.setFactory(this);
    return treeStylesheetPI;
  }
  
  public DTD createDTD() {
    TreeDTD treeDTD = new TreeDTD();
    treeDTD.setFactory(this);
    return treeDTD;
  }
  
  public DTD createDTD(String paramString, ExternalID paramExternalID) {
    TreeDTD treeDTD = new TreeDTD(paramString, paramExternalID);
    treeDTD.setFactory(this);
    return treeDTD;
  }
  
  public ElementDecl createElementDecl(String paramString, ContentModel paramContentModel) {
    TreeElementDecl treeElementDecl = new TreeElementDecl(paramString, paramContentModel);
    treeElementDecl.setFactory(this);
    return treeElementDecl;
  }
  
  public Attlist createAttlist(String paramString) {
    TreeAttlist treeAttlist = new TreeAttlist(paramString);
    treeAttlist.setFactory(this);
    return treeAttlist;
  }
  
  public AttDef createAttDef(String paramString) {
    TreeAttDef treeAttDef = new TreeAttDef(paramString);
    treeAttDef.setFactory(this);
    return treeAttDef;
  }
  
  public EntityDecl createEntityDecl(String paramString1, String paramString2, boolean paramBoolean) {
    TreeEntity treeEntity = new TreeEntity(paramString1, paramString2, paramBoolean);
    treeEntity.setFactory(this);
    return treeEntity;
  }
  
  public EntityDecl createEntity(String paramString1, ExternalID paramExternalID, boolean paramBoolean, String paramString2) {
    TreeEntity treeEntity = new TreeEntity(paramString1, paramExternalID, paramBoolean, paramString2);
    treeEntity.setFactory(this);
    return treeEntity;
  }
  
  public TXNotation createNotation(String paramString, ExternalID paramExternalID) {
    TreeNotation treeNotation = new TreeNotation(paramString, paramExternalID);
    treeNotation.setFactory(this);
    return treeNotation;
  }
  
  public EntityReference createEntityReference(String paramString) {
    TreeGeneralReference treeGeneralReference = new TreeGeneralReference(paramString);
    treeGeneralReference.setFactory(this);
    return treeGeneralReference;
  }
  
  public PseudoNode createPseudoNode(String paramString) {
    TreePseudoNode treePseudoNode = new TreePseudoNode(paramString);
    treePseudoNode.setFactory(this);
    return treePseudoNode;
  }
  
  public Enumeration children() { return elements(); }
  
  public boolean getAllowsChildren() { return true; }
  
  public TreeNode getChildAt(int paramInt) { return (TreeNode)getChildNodes().item(paramInt); }
  
  public int getChildCount() { return getChildNodes().getLength(); }
  
  public int getIndex(TreeNode paramTreeNode) {
    byte b = 0;
    for (Node node = getFirstChild(); node != null; node = node.getNextSibling()) {
      if (node == paramTreeNode)
        return b; 
      b++;
    } 
    return -1;
  }
  
  public TreeNode getParent() { return (TreeNode)getParentNode(); }
  
  public boolean isLeaf() { return false; }
  
  public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  
  public static class TreeElement extends TXElement implements TreeNode {
    public TreeElement(String param1String) { super(param1String); }
    
    public Enumeration children() { return elements(); }
    
    public boolean getAllowsChildren() { return true; }
    
    public TreeNode getChildAt(int param1Int) { return (TreeNode)getChildNodes().item(param1Int); }
    
    public int getChildCount() { return getChildNodes().getLength(); }
    
    public int getIndex(TreeNode param1TreeNode) {
      byte b = 0;
      for (Node node = getFirstChild(); node != null; node = node.getNextSibling()) {
        if (node == param1TreeNode)
          return b; 
        b++;
      } 
      return -1;
    }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return !hasChildNodes(); }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
  
  public static class TreeDTD extends DTD implements TreeNode {
    public TreeDTD() {}
    
    public TreeDTD(String param1String, ExternalID param1ExternalID) { super(param1String, param1ExternalID); }
    
    public Enumeration children() { return elements(); }
    
    public boolean getAllowsChildren() { return true; }
    
    public TreeNode getChildAt(int param1Int) { return (TreeNode)getChildNodes().item(param1Int); }
    
    public int getChildCount() { return getChildNodes().getLength(); }
    
    public int getIndex(TreeNode param1TreeNode) {
      byte b = 0;
      for (Node node = getFirstChild(); node != null; node = node.getNextSibling()) {
        if (node == param1TreeNode)
          return b; 
        b++;
      } 
      return -1;
    }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return !hasChildNodes(); }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
  
  public static class TreeText extends TXText implements TreeNode {
    public TreeText(String param1String) { super(param1String); }
    
    public Enumeration children() { return null; }
    
    public boolean getAllowsChildren() { return false; }
    
    public TreeNode getChildAt(int param1Int) { return null; }
    
    public int getChildCount() { return 0; }
    
    public int getIndex(TreeNode param1TreeNode) { return -1; }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return true; }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
  
  public static class TreeCDATASection extends TXCDATASection implements TreeNode {
    public TreeCDATASection(String param1String) { super(param1String); }
    
    public Enumeration children() { return null; }
    
    public boolean getAllowsChildren() { return false; }
    
    public TreeNode getChildAt(int param1Int) { return null; }
    
    public int getChildCount() { return 0; }
    
    public int getIndex(TreeNode param1TreeNode) { return -1; }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return true; }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
  
  public static class TreeComment extends TXComment implements TreeNode {
    public TreeComment(String param1String) { super(param1String); }
    
    public Enumeration children() { return null; }
    
    public boolean getAllowsChildren() { return false; }
    
    public TreeNode getChildAt(int param1Int) { return null; }
    
    public int getChildCount() { return 0; }
    
    public int getIndex(TreeNode param1TreeNode) { return -1; }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return true; }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
  
  public static class TreePI extends TXPI implements TreeNode {
    public TreePI(String param1String1, String param1String2) { super(param1String1, param1String2); }
    
    public Enumeration children() { return null; }
    
    public boolean getAllowsChildren() { return false; }
    
    public TreeNode getChildAt(int param1Int) { return null; }
    
    public int getChildCount() { return 0; }
    
    public int getIndex(TreeNode param1TreeNode) { return -1; }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return true; }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
  
  public static class TreeStylesheetPI extends StylesheetPI implements TreeNode {
    public TreeStylesheetPI(String param1String1, String param1String2, String param1String3, String param1String4, String param1String5) { super(param1String1, param1String2, param1String3, param1String4, param1String5); }
    
    public Enumeration children() { return null; }
    
    public boolean getAllowsChildren() { return false; }
    
    public TreeNode getChildAt(int param1Int) { return null; }
    
    public int getChildCount() { return 0; }
    
    public int getIndex(TreeNode param1TreeNode) { return -1; }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return true; }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
  
  public static class TreeElementDecl extends ElementDecl implements TreeNode {
    public TreeElementDecl(String param1String, ContentModel param1ContentModel) { super(param1String, param1ContentModel); }
    
    public Enumeration children() { return null; }
    
    public boolean getAllowsChildren() { return false; }
    
    public TreeNode getChildAt(int param1Int) { return null; }
    
    public int getChildCount() { return 0; }
    
    public int getIndex(TreeNode param1TreeNode) { return -1; }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return true; }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
  
  public static class TreeAttlist extends Attlist implements TreeNode {
    public TreeAttlist(String param1String) { super(param1String); }
    
    public Enumeration children() { return elements(); }
    
    public boolean getAllowsChildren() { return true; }
    
    public TreeNode getChildAt(int param1Int) { return (TreeNode)elementAt(param1Int); }
    
    public int getChildCount() { return size(); }
    
    public int getIndex(TreeNode param1TreeNode) {
      Enumeration enumeration = elements();
      for (byte b = 0; enumeration.hasMoreElements(); b++) {
        if (param1TreeNode == enumeration.nextElement())
          return b; 
      } 
      return -1;
    }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return !(size() != 0); }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
  
  public static class TreeAttDef extends AttDef implements TreeNode {
    public TreeAttDef(String param1String) { super(param1String); }
    
    public Enumeration children() { return null; }
    
    public boolean getAllowsChildren() { return false; }
    
    public TreeNode getChildAt(int param1Int) { return null; }
    
    public int getChildCount() { return 0; }
    
    public int getIndex(TreeNode param1TreeNode) { return -1; }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return true; }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
  
  public static class TreeEntity extends EntityDecl implements TreeNode {
    public TreeEntity(String param1String1, String param1String2, boolean param1Boolean) { super(param1String1, param1String2, param1Boolean); }
    
    public TreeEntity(String param1String1, ExternalID param1ExternalID, boolean param1Boolean, String param1String2) { super(param1String1, param1ExternalID, param1Boolean, param1String2); }
    
    public Enumeration children() { return null; }
    
    public boolean getAllowsChildren() { return false; }
    
    public TreeNode getChildAt(int param1Int) { return null; }
    
    public int getChildCount() { return 0; }
    
    public int getIndex(TreeNode param1TreeNode) { return -1; }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return true; }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
  
  public static class TreeNotation extends TXNotation implements TreeNode {
    public TreeNotation(String param1String, ExternalID param1ExternalID) { super(param1String, param1ExternalID); }
    
    public Enumeration children() { return null; }
    
    public boolean getAllowsChildren() { return false; }
    
    public TreeNode getChildAt(int param1Int) { return null; }
    
    public int getChildCount() { return 0; }
    
    public int getIndex(TreeNode param1TreeNode) { return -1; }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return true; }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
  
  public static class TreeGeneralReference extends GeneralReference implements TreeNode {
    public TreeGeneralReference(String param1String) { super(param1String); }
    
    public Enumeration children() { return elements(); }
    
    public boolean getAllowsChildren() { return true; }
    
    public TreeNode getChildAt(int param1Int) { return (TreeNode)getChildNodes().item(param1Int); }
    
    public int getChildCount() { return getChildNodes().getLength(); }
    
    public int getIndex(TreeNode param1TreeNode) {
      byte b = 0;
      for (Node node = getFirstChild(); node != null; node = node.getNextSibling()) {
        if (node == param1TreeNode)
          return b; 
        b++;
      } 
      return -1;
    }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return !hasChildNodes(); }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
  
  public static class TreePseudoNode extends PseudoNode implements TreeNode {
    public TreePseudoNode(String param1String) { super(param1String); }
    
    public Enumeration children() { return null; }
    
    public boolean getAllowsChildren() { return false; }
    
    public TreeNode getChildAt(int param1Int) { return null; }
    
    public int getChildCount() { return 0; }
    
    public int getIndex(TreeNode param1TreeNode) { return -1; }
    
    public TreeNode getParent() { return (TreeNode)getParentNode(); }
    
    public boolean isLeaf() { return true; }
    
    public String toString() { return ((TreeFactory)getFactory()).convertValueToText(this); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parse\\util\TreeFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */