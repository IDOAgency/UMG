package com.ibm.xml.parser.util;

import com.ibm.xml.parser.AttDef;
import com.ibm.xml.parser.Attlist;
import com.ibm.xml.parser.DTD;
import com.ibm.xml.parser.ElementDecl;
import com.ibm.xml.parser.EntityDecl;
import com.ibm.xml.parser.GeneralReference;
import com.ibm.xml.parser.TXAttribute;
import com.ibm.xml.parser.TXDocument;
import com.ibm.xml.parser.TXElement;
import com.ibm.xml.parser.TXNotation;
import com.ibm.xml.parser.TXPI;
import com.ibm.xml.parser.TXText;
import com.ibm.xml.parser.ToNextSiblingTraversalException;
import com.ibm.xml.parser.ToXMLStringVisitor;
import com.ibm.xml.parser.Util;
import java.io.Writer;
import java.util.Hashtable;
import org.w3c.dom.Node;

public class HTMLPrintVisitor extends ToXMLStringVisitor {
  protected int level;
  
  protected String doctype;
  
  static Hashtable s_empties = new Hashtable();
  
  static Hashtable s_entities;
  
  public HTMLPrintVisitor(Writer paramWriter, String paramString1, String paramString2) {
    super(paramWriter, paramString1);
    this.doctype = paramString2;
    this.isPrintNonSpecifiedAttributes = false;
  }
  
  public HTMLPrintVisitor(Writer paramWriter, String paramString) { this(paramWriter, paramString, null); }
  
  public HTMLPrintVisitor(Writer paramWriter) { this(paramWriter, null, null); }
  
  public void visitDocumentPre(TXDocument paramTXDocument) throws Exception {
    if (this.doctype != null)
      this.writer.write(this.doctype); 
  }
  
  public void visitDocumentPost(TXDocument paramTXDocument) throws Exception {
    this.writer.write("\n");
    this.writer.flush();
  }
  
  public void visitElementPre(TXElement paramTXElement) throws Exception {
    this.level++;
    this.writer.write("<" + paramTXElement.getTagName().toUpperCase());
    TXAttribute[] arrayOfTXAttribute = paramTXElement.getAttributeArray();
    for (byte b = 0; b < arrayOfTXAttribute.length; b++) {
      TXAttribute tXAttribute = arrayOfTXAttribute[b];
      if (this.isPrintNonSpecifiedAttributes || tXAttribute.getSpecified())
        visitAttributePre(tXAttribute); 
    } 
    this.writer.write(">");
  }
  
  public void visitElementPost(TXElement paramTXElement) throws Exception {
    String str = paramTXElement.getTagName().toUpperCase();
    if (paramTXElement.hasChildNodes() || s_empties.get(str) == null)
      this.writer.write("</" + str + ">"); 
    this.level--;
  }
  
  public void visitAttributePre(TXAttribute paramTXAttribute) throws Exception {
    String str = paramTXAttribute.getName().toLowerCase();
    if (str.equals("xml:lang"))
      str = "lang"; 
    this.writer.write(" " + str + "=\"" + Util.backReference(paramTXAttribute.getValue(), "&<>\"", this.encoding) + "\"");
  }
  
  public void visitPIPre(TXPI paramTXPI) throws Exception {}
  
  public void visitTextPre(TXText paramTXText) throws Exception {
    if (this.level > 0) {
      if (paramTXText instanceof com.ibm.xml.parser.TXCDATASection) {
        this.writer.write(paramTXText.getData());
        return;
      } 
      this.writer.write(Util.backReference(paramTXText.getData(), this.encoding));
    } 
  }
  
  public void visitDTDPre(DTD paramDTD) throws Exception { throw new ToNextSiblingTraversalException(); }
  
  public void visitDTDPost(DTD paramDTD) throws Exception {}
  
  public void visitElementDeclPre(ElementDecl paramElementDecl) throws Exception {}
  
  public void visitAttlistPre(Attlist paramAttlist) throws Exception {}
  
  public void visitAttDefPre(AttDef paramAttDef) throws Exception {}
  
  public void visitEntityDeclPre(EntityDecl paramEntityDecl) throws Exception {}
  
  public void visitNotationPre(TXNotation paramTXNotation) throws Exception {}
  
  public void visitGeneralReferencePre(GeneralReference paramGeneralReference) throws Exception {
    String str = paramGeneralReference.getName();
    if (s_entities.get(str) != null && paramGeneralReference.getChildNodes().getLength() == 1) {
      Node node = paramGeneralReference.getFirstChild();
      if (node.getNodeType() == 3 && node.getNodeValue().length() == 1) {
        this.writer.write(String.valueOf('&') + str + ';');
        throw new ToNextSiblingTraversalException();
      } 
    } 
  }
  
  static  {
    s_empties.put("AREA", "AREA");
    s_empties.put("BASE", "BASE");
    s_empties.put("BR", "BR");
    s_empties.put("COL", "COL");
    s_empties.put("HR", "HR");
    s_empties.put("IMG", "IMG");
    s_empties.put("INPUT", "INPUT");
    s_empties.put("LINK", "LINK");
    s_empties.put("META", "META");
    s_empties.put("PARAM", "PARAM");
    s_empties.put("BASEFONT", "BASEFONT");
    s_empties.put("FRAME", "FRAME");
    s_empties.put("ISINDEX", "ISINDEX");
    s_entities = new Hashtable();
    s_entities.put("nbsp", "nbsp");
    s_entities.put("iexcl", "iexcl");
    s_entities.put("cent", "cent");
    s_entities.put("pound", "pound");
    s_entities.put("curren", "curren");
    s_entities.put("yen", "yen");
    s_entities.put("brvbar", "brvbar");
    s_entities.put("sect", "sect");
    s_entities.put("uml", "uml");
    s_entities.put("copy", "copy");
    s_entities.put("ordf", "ordf");
    s_entities.put("laquo", "laquo");
    s_entities.put("not", "not");
    s_entities.put("shy", "shy");
    s_entities.put("reg", "reg");
    s_entities.put("macr", "macr");
    s_entities.put("deg", "deg");
    s_entities.put("plusmn", "plusmn");
    s_entities.put("sup2", "sup2");
    s_entities.put("sup3", "sup3");
    s_entities.put("acute", "acute");
    s_entities.put("micro", "micro");
    s_entities.put("para", "para");
    s_entities.put("middot", "middot");
    s_entities.put("cedil", "cedil");
    s_entities.put("sup1", "sup1");
    s_entities.put("ordm", "ordm");
    s_entities.put("raquo", "raquo");
    s_entities.put("frac14", "frac14");
    s_entities.put("frac12", "frac12");
    s_entities.put("frac34", "frac34");
    s_entities.put("iquest", "iquest");
    s_entities.put("Agrave", "Agrave");
    s_entities.put("Aacute", "Aacute");
    s_entities.put("Acirc", "Acirc");
    s_entities.put("Atilde", "Atilde");
    s_entities.put("Auml", "Auml");
    s_entities.put("Aring", "Aring");
    s_entities.put("AElig", "AElig");
    s_entities.put("Ccedil", "Ccedil");
    s_entities.put("Egrave", "Egrave");
    s_entities.put("Eacute", "Eacute");
    s_entities.put("Ecirc", "Ecirc");
    s_entities.put("Euml", "Euml");
    s_entities.put("Igrave", "Igrave");
    s_entities.put("Iacute", "Iacute");
    s_entities.put("Icirc", "Icirc");
    s_entities.put("Iuml", "Iuml");
    s_entities.put("ETH", "ETH");
    s_entities.put("Ntilde", "Ntilde");
    s_entities.put("Ograve", "Ograve");
    s_entities.put("Oacute", "Oacute");
    s_entities.put("Ocirc", "Ocirc");
    s_entities.put("Otilde", "Otilde");
    s_entities.put("Ouml", "Ouml");
    s_entities.put("times", "times");
    s_entities.put("Oslash", "Oslash");
    s_entities.put("Ugrave", "Ugrave");
    s_entities.put("Uacute", "Uacute");
    s_entities.put("Ucirc", "Ucirc");
    s_entities.put("Uuml", "Uuml");
    s_entities.put("Yacute", "Yacute");
    s_entities.put("THORN", "THORN");
    s_entities.put("szlig", "szlig");
    s_entities.put("agrave", "agrave");
    s_entities.put("aacute", "aacute");
    s_entities.put("acirc", "acirc");
    s_entities.put("atilde", "atilde");
    s_entities.put("auml", "auml");
    s_entities.put("aring", "aring");
    s_entities.put("aelig", "aelig");
    s_entities.put("ccedil", "ccedil");
    s_entities.put("egrave", "egrave");
    s_entities.put("eacute", "eacute");
    s_entities.put("ecirc", "ecirc");
    s_entities.put("euml", "euml");
    s_entities.put("igrave", "igrave");
    s_entities.put("iacute", "iacute");
    s_entities.put("icirc", "icirc");
    s_entities.put("iuml", "iuml");
    s_entities.put("eth", "eth");
    s_entities.put("ntilde", "ntilde");
    s_entities.put("ograve", "ograve");
    s_entities.put("oacute", "oacute");
    s_entities.put("ocirc", "ocirc");
    s_entities.put("otilde", "otilde");
    s_entities.put("ouml", "ouml");
    s_entities.put("divide", "divide");
    s_entities.put("oslash", "oslash");
    s_entities.put("ugrave", "ugrave");
    s_entities.put("uacute", "uacute");
    s_entities.put("ucirc", "ucirc");
    s_entities.put("uuml", "uuml");
    s_entities.put("yacute", "yacute");
    s_entities.put("thorn", "thorn");
    s_entities.put("yuml", "yuml");
    s_entities.put("fnof", "fnof");
    s_entities.put("Alpha", "Alpha");
    s_entities.put("Beta", "Beta");
    s_entities.put("Gamma", "Gamma");
    s_entities.put("Delta", "Delta");
    s_entities.put("Epsilon", "Epsilon");
    s_entities.put("Zeta", "Zeta");
    s_entities.put("Eta", "Eta");
    s_entities.put("Theta", "Theta");
    s_entities.put("Iota", "Iota");
    s_entities.put("Kappa", "Kappa");
    s_entities.put("Lambda", "Lambda");
    s_entities.put("Mu", "Mu");
    s_entities.put("Nu", "Nu");
    s_entities.put("Xi", "Xi");
    s_entities.put("Omicron", "Omicron");
    s_entities.put("Pi", "Pi");
    s_entities.put("Rho", "Rho");
    s_entities.put("Sigma", "Sigma");
    s_entities.put("Tau", "Tau");
    s_entities.put("Upsilon", "Upsilon");
    s_entities.put("Phi", "Phi");
    s_entities.put("Chi", "Chi");
    s_entities.put("Psi", "Psi");
    s_entities.put("Omega", "Omega");
    s_entities.put("alpha", "alpha");
    s_entities.put("beta", "beta");
    s_entities.put("gamma", "gamma");
    s_entities.put("delta", "delta");
    s_entities.put("epsilon", "epsilon");
    s_entities.put("zeta", "zeta");
    s_entities.put("eta", "eta");
    s_entities.put("theta", "theta");
    s_entities.put("iota", "iota");
    s_entities.put("kappa", "kappa");
    s_entities.put("lambda", "lambda");
    s_entities.put("mu", "mu");
    s_entities.put("nu", "nu");
    s_entities.put("xi", "xi");
    s_entities.put("omicron", "omicron");
    s_entities.put("pi", "pi");
    s_entities.put("rho", "rho");
    s_entities.put("sigmaf", "sigmaf");
    s_entities.put("sigma", "sigma");
    s_entities.put("tau", "tau");
    s_entities.put("upsilon", "upsilon");
    s_entities.put("phi", "phi");
    s_entities.put("chi", "chi");
    s_entities.put("psi", "psi");
    s_entities.put("omega", "omega");
    s_entities.put("thetasym", "thetasym");
    s_entities.put("upsih", "upsih");
    s_entities.put("piv", "piv");
    s_entities.put("bull", "bull");
    s_entities.put("hellip", "hellip");
    s_entities.put("prime", "prime");
    s_entities.put("Prime", "Prime");
    s_entities.put("oline", "oline");
    s_entities.put("frasl", "frasl");
    s_entities.put("weierp", "weierp");
    s_entities.put("image", "image");
    s_entities.put("real", "real");
    s_entities.put("trade", "trade");
    s_entities.put("alefsym", "alefsym");
    s_entities.put("larr", "larr");
    s_entities.put("uarr", "uarr");
    s_entities.put("rarr", "rarr");
    s_entities.put("darr", "darr");
    s_entities.put("harr", "harr");
    s_entities.put("crarr", "crarr");
    s_entities.put("lArr", "lArr");
    s_entities.put("uArr", "uArr");
    s_entities.put("rArr", "rArr");
    s_entities.put("dArr", "dArr");
    s_entities.put("hArr", "hArr");
    s_entities.put("forall", "forall");
    s_entities.put("part", "part");
    s_entities.put("exist", "exist");
    s_entities.put("empty", "empty");
    s_entities.put("nabla", "nabla");
    s_entities.put("isin", "isin");
    s_entities.put("notin", "notin");
    s_entities.put("ni", "ni");
    s_entities.put("prod", "prod");
    s_entities.put("sum", "sum");
    s_entities.put("minus", "minus");
    s_entities.put("lowast", "lowast");
    s_entities.put("radic", "radic");
    s_entities.put("prop", "prop");
    s_entities.put("infin", "infin");
    s_entities.put("ang", "ang");
    s_entities.put("and", "and");
    s_entities.put("or", "or");
    s_entities.put("cap", "cap");
    s_entities.put("cup", "cup");
    s_entities.put("int", "int");
    s_entities.put("there4", "there4");
    s_entities.put("sim", "sim");
    s_entities.put("cong", "cong");
    s_entities.put("asymp", "asymp");
    s_entities.put("ne", "ne");
    s_entities.put("equiv", "equiv");
    s_entities.put("le", "le");
    s_entities.put("ge", "ge");
    s_entities.put("sub", "sub");
    s_entities.put("sup", "sup");
    s_entities.put("nsub", "nsub");
    s_entities.put("sube", "sube");
    s_entities.put("supe", "supe");
    s_entities.put("oplus", "oplus");
    s_entities.put("otimes", "otimes");
    s_entities.put("perp", "perp");
    s_entities.put("sdot", "sdot");
    s_entities.put("lceil", "lceil");
    s_entities.put("rceil", "rceil");
    s_entities.put("lfloor", "lfloor");
    s_entities.put("rfloor", "rfloor");
    s_entities.put("lang", "lang");
    s_entities.put("rang", "rang");
    s_entities.put("loz", "loz");
    s_entities.put("spades", "spades");
    s_entities.put("clubs", "clubs");
    s_entities.put("hearts", "hearts");
    s_entities.put("diams", "diams");
    s_entities.put("fnof", "fnof");
    s_entities.put("Alpha", "Alpha");
    s_entities.put("Beta", "Beta");
    s_entities.put("Gamma", "Gamma");
    s_entities.put("Delta", "Delta");
    s_entities.put("Epsilon", "Epsilon");
    s_entities.put("Zeta", "Zeta");
    s_entities.put("Eta", "Eta");
    s_entities.put("Theta", "Theta");
    s_entities.put("Iota", "Iota");
    s_entities.put("Kappa", "Kappa");
    s_entities.put("Lambda", "Lambda");
    s_entities.put("Mu", "Mu");
    s_entities.put("Nu", "Nu");
    s_entities.put("Xi", "Xi");
    s_entities.put("Omicron", "Omicron");
    s_entities.put("Pi", "Pi");
    s_entities.put("Rho", "Rho");
    s_entities.put("Sigma", "Sigma");
    s_entities.put("Tau", "Tau");
    s_entities.put("Upsilon", "Upsilon");
    s_entities.put("Phi", "Phi");
    s_entities.put("Chi", "Chi");
    s_entities.put("Psi", "Psi");
    s_entities.put("Omega", "Omega");
    s_entities.put("alpha", "alpha");
    s_entities.put("beta", "beta");
    s_entities.put("gamma", "gamma");
    s_entities.put("delta", "delta");
    s_entities.put("epsilon", "epsilon");
    s_entities.put("zeta", "zeta");
    s_entities.put("eta", "eta");
    s_entities.put("theta", "theta");
    s_entities.put("iota", "iota");
    s_entities.put("kappa", "kappa");
    s_entities.put("lambda", "lambda");
    s_entities.put("mu", "mu");
    s_entities.put("nu", "nu");
    s_entities.put("xi", "xi");
    s_entities.put("omicron", "omicron");
    s_entities.put("pi", "pi");
    s_entities.put("rho", "rho");
    s_entities.put("sigmaf", "sigmaf");
    s_entities.put("sigma", "sigma");
    s_entities.put("tau", "tau");
    s_entities.put("upsilon", "upsilon");
    s_entities.put("phi", "phi");
    s_entities.put("chi", "chi");
    s_entities.put("psi", "psi");
    s_entities.put("omega", "omega");
    s_entities.put("thetasym", "thetasym");
    s_entities.put("upsih", "upsih");
    s_entities.put("piv", "piv");
    s_entities.put("bull", "bull");
    s_entities.put("hellip", "hellip");
    s_entities.put("prime", "prime");
    s_entities.put("Prime", "Prime");
    s_entities.put("oline", "oline");
    s_entities.put("frasl", "frasl");
    s_entities.put("weierp", "weierp");
    s_entities.put("image", "image");
    s_entities.put("real", "real");
    s_entities.put("trade", "trade");
    s_entities.put("alefsym", "alefsym");
    s_entities.put("larr", "larr");
    s_entities.put("uarr", "uarr");
    s_entities.put("rarr", "rarr");
    s_entities.put("darr", "darr");
    s_entities.put("harr", "harr");
    s_entities.put("crarr", "crarr");
    s_entities.put("lArr", "lArr");
    s_entities.put("uArr", "uArr");
    s_entities.put("rArr", "rArr");
    s_entities.put("dArr", "dArr");
    s_entities.put("hArr", "hArr");
    s_entities.put("forall", "forall");
    s_entities.put("part", "part");
    s_entities.put("exist", "exist");
    s_entities.put("empty", "empty");
    s_entities.put("nabla", "nabla");
    s_entities.put("isin", "isin");
    s_entities.put("notin", "notin");
    s_entities.put("ni", "ni");
    s_entities.put("prod", "prod");
    s_entities.put("sum", "sum");
    s_entities.put("minus", "minus");
    s_entities.put("lowast", "lowast");
    s_entities.put("radic", "radic");
    s_entities.put("prop", "prop");
    s_entities.put("infin", "infin");
    s_entities.put("ang", "ang");
    s_entities.put("and", "and");
    s_entities.put("or", "or");
    s_entities.put("cap", "cap");
    s_entities.put("cup", "cup");
    s_entities.put("int", "int");
    s_entities.put("there4", "there4");
    s_entities.put("sim", "sim");
    s_entities.put("cong", "cong");
    s_entities.put("asymp", "asymp");
    s_entities.put("ne", "ne");
    s_entities.put("equiv", "equiv");
    s_entities.put("le", "le");
    s_entities.put("ge", "ge");
    s_entities.put("sub", "sub");
    s_entities.put("sup", "sup");
    s_entities.put("nsub", "nsub");
    s_entities.put("sube", "sube");
    s_entities.put("supe", "supe");
    s_entities.put("oplus", "oplus");
    s_entities.put("otimes", "otimes");
    s_entities.put("perp", "perp");
    s_entities.put("sdot", "sdot");
    s_entities.put("lceil", "lceil");
    s_entities.put("rceil", "rceil");
    s_entities.put("lfloor", "lfloor");
    s_entities.put("rfloor", "rfloor");
    s_entities.put("lang", "lang");
    s_entities.put("rang", "rang");
    s_entities.put("loz", "loz");
    s_entities.put("spades", "spades");
    s_entities.put("clubs", "clubs");
    s_entities.put("hearts", "hearts");
    s_entities.put("diams", "diams");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parse\\util\HTMLPrintVisitor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */