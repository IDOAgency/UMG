package com.ibm.xml.parser.util;

import com.ibm.xml.parser.EndTraversalException;
import com.ibm.xml.parser.ToNextSiblingTraversalException;
import com.ibm.xml.parser.TreeTraversal;
import com.ibm.xml.parser.Visitee;
import com.ibm.xml.parser.Visitor;
import org.w3c.dom.Node;

public class RecursivePreorderTreeTraversal extends TreeTraversal {
  boolean endTraversal = false;
  
  public RecursivePreorderTreeTraversal(Visitor paramVisitor) {
    super(paramVisitor);
    this.endTraversal = false;
  }
  
  public void traverse(Node paramNode) throws Exception {
    try {
      if (paramNode != null && !this.endTraversal) {
        try {
          ((Visitee)paramNode).acceptPre(getVisitor());
          for (Node node = paramNode.getFirstChild(); node != null && !this.endTraversal; node = node.getNextSibling())
            traverse(node); 
        } catch (ToNextSiblingTraversalException toNextSiblingTraversalException) {}
        if (!this.endTraversal) {
          ((Visitee)paramNode).acceptPost(getVisitor());
          return;
        } 
      } 
    } catch (EndTraversalException endTraversalException) {
      this.endTraversal = true;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parse\\util\RecursivePreorderTreeTraversal.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */