package com.ibm.xml.parser;

import java.io.Serializable;
import java.util.BitSet;

public abstract class CMNode implements Serializable {
  static final long serialVersionUID = -5763796053832459314L;
  
  BitSet firstPos;
  
  BitSet lastPos;
  
  BitSet followPos;
  
  Boolean nullable;
  
  abstract CMNode cloneNode();
  
  abstract boolean nullable();
  
  abstract BitSet firstpos();
  
  abstract BitSet lastpos();
  
  abstract void prepare(int paramInt);
  
  abstract void setFollowpos(BitSet[] paramArrayOfBitSet);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\CMNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */