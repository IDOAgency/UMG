package com.ibm.xml.parser;

public interface ElementHandler {
  TXElement handleElement(TXElement paramTXElement);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\ElementHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */