package com.ibm.xml.parser;

import java.io.ByteArrayInputStream;
import java.io.CharArrayReader;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Entity;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class EntityDecl extends Parent {
  static final long serialVersionUID = 1661279924518265405L;
  
  String name;
  
  boolean isParameter = false;
  
  String value;
  
  ExternalID externalID;
  
  String ndata;
  
  byte[] rawByteStream;
  
  String encoding;
  
  char[] rawCharStream;
  
  boolean parsed = false;
  
  public EntityDecl(String paramString1, String paramString2, boolean paramBoolean) {
    this.name = paramString1;
    this.value = paramString2;
    this.isParameter = paramBoolean;
  }
  
  public EntityDecl(String paramString1, ExternalID paramExternalID, boolean paramBoolean, String paramString2) {
    this.name = paramString1;
    this.externalID = paramExternalID;
    this.isParameter = paramBoolean;
    this.ndata = paramString2;
  }
  
  public Object clone() { return cloneNode(true); }
  
  public Node cloneNode(boolean paramBoolean) {
    checkFactory();
    EntityDecl entityDecl = null;
    if (this.externalID != null) {
      entityDecl = this.factory.createEntityDecl(this.name, new ExternalID(this.externalID.publicID, this.externalID.systemID), this.isParameter, this.ndata);
    } else {
      entityDecl = this.factory.createEntityDecl(this.name, this.value, this.isParameter);
    } 
    entityDecl.setFactory(getFactory());
    if (paramBoolean) {
      entityDecl.children.ensureCapacity(this.children.getLength());
      for (byte b = 0; b < this.children.getLength(); b++)
        entityDecl.appendChild(this.children.item(b).cloneNode(true)); 
      entityDecl.parsed = this.parsed;
    } 
    return entityDecl;
  }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (paramNode == null)
      return false; 
    if (!(paramNode instanceof EntityDecl))
      return false; 
    EntityDecl entityDecl = (EntityDecl)paramNode;
    if (!this.name.equals(entityDecl.name))
      return false; 
    if ((entityDecl.value != null || this.value != null) && (entityDecl.value == null || !entityDecl.value.equals(this.value)))
      return false; 
    if (this.externalID != null) {
      if (!this.externalID.equals(entityDecl.externalID))
        return false; 
      if ((entityDecl.externalID.systemID != null || this.externalID.systemID != null) && (entityDecl.externalID.systemID == null || !entityDecl.externalID.systemID.equals(this.externalID.systemID)))
        return false; 
      if ((entityDecl.externalID.publicID != null || this.externalID.publicID != null) && (entityDecl.externalID.publicID == null || !entityDecl.externalID.publicID.equals(this.externalID.publicID)))
        return false; 
    } else if (entityDecl.externalID != null) {
      return false;
    } 
    return ((entityDecl.ndata != null || this.ndata != null) && (entityDecl.ndata == null || !entityDecl.ndata.equals(this.ndata))) ? false : (!(paramBoolean && !entityDecl.children.equals(this.children, paramBoolean)));
  }
  
  public short getNodeType() { return 6; }
  
  public String getNodeName() { return this.name; }
  
  public String getName() { return this.name; }
  
  public boolean isParameter() { return this.isParameter; }
  
  public String getValue() { return this.value; }
  
  public String getSystemId() { return this.externalID.getSystemLiteral(); }
  
  public String getPublicId() { return this.externalID.getPubidLiteral(); }
  
  public ExternalID getExternalID() { return this.externalID; }
  
  public boolean isExternal() { return !(this.externalID == null); }
  
  public String getNDATAType() { return this.ndata; }
  
  public String getNotationName() { return this.ndata; }
  
  public boolean isNDATA() { return !(this.ndata == null); }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitEntityDeclPre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitEntityDeclPost(this); }
  
  Source getInputStream() { return (this.rawByteStream != null) ? new Source(new ByteArrayInputStream(this.rawByteStream), this.encoding) : new Source(new CharArrayReader(this.rawCharStream)); }
  
  void setValue(String paramString) { this.value = paramString; }
  
  void setParsed(boolean paramBoolean) { this.parsed = paramBoolean; }
  
  boolean getParsed() { return this.parsed; }
  
  protected void checkChildType(Node paramNode) throws DOMException {
    switch (paramNode.getNodeType()) {
      default:
        throw new TXDOMException((short)3, "Specified node type (" + paramNode.getNodeType() + ") can't be a child of EntityReference.");
      case 1:
      case 3:
      case 4:
      case 5:
      case 7:
      case 8:
      case 23:
        break;
    } 
  }
  
  protected Entity getEntityImpl() {
    if (isParameter())
      throw new RuntimeException("XML4J internal error: EntityImpl for parameter entity."); 
    return new EntityImpl(this);
  }
  
  static class EntityImpl implements Entity {
    EntityDecl decl;
    
    EntityImpl(EntityDecl param1EntityDecl) { this.decl = param1EntityDecl; }
    
    public Node getParentNode() { return null; }
    
    public String getPublicId() { return this.decl.getPublicId(); }
    
    public String getSystemId() { return this.decl.getSystemId(); }
    
    public String getNotationName() { return this.decl.getNotationName(); }
    
    public String getNodeName() { return this.decl.getNodeName(); }
    
    public String getNodeValue() { return null; }
    
    public void setNodeValue(String param1String) { throw new TXDOMException((short)7, "This Entity is read-only."); }
    
    public short getNodeType() { return 6; }
    
    public NodeList getChildNodes() { return this.decl.getChildNodes(); }
    
    public Node getFirstChild() { return this.decl.getFirstChild(); }
    
    public Node getLastChild() { return this.decl.getLastChild(); }
    
    public Node getPreviousSibling() { return this.decl.getPreviousSibling(); }
    
    public Node getNextSibling() { return this.decl.getNextSibling(); }
    
    public NamedNodeMap getAttributes() { return null; }
    
    public Document getOwnerDocument() { return this.decl.getOwnerDocument(); }
    
    public Node insertBefore(Node param1Node1, Node param1Node2) { throw new TXDOMException((short)7, "This Entity is read-only."); }
    
    public Node replaceChild(Node param1Node1, Node param1Node2) { throw new TXDOMException((short)7, "This Entity is read-only."); }
    
    public Node removeChild(Node param1Node) { throw new TXDOMException((short)7, "This Entity is read-only."); }
    
    public Node appendChild(Node param1Node) { throw new TXDOMException((short)7, "This Entity is read-only."); }
    
    public boolean hasChildNodes() { return this.decl.hasChildNodes(); }
    
    public Node cloneNode(boolean param1Boolean) { return ((EntityDecl)this.decl.cloneNode(param1Boolean)).getEntityImpl(); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\EntityDecl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */