package com.ibm.xml.parser;

import org.w3c.dom.Comment;
import org.w3c.dom.Node;

public class TXComment extends TXCharacterData implements Comment {
  static final long serialVersionUID = 1828125899632355320L;
  
  public TXComment(String paramString) { this.data = paramString; }
  
  public Object clone() {
    checkFactory();
    TXComment tXComment = (TXComment)this.factory.createComment(this.data);
    tXComment.setFactory(getFactory());
    return tXComment;
  }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (paramNode == null)
      return false; 
    if (!(paramNode instanceof Comment))
      return false; 
    Comment comment = (Comment)paramNode;
    return comment.getData().equals(getData());
  }
  
  public short getNodeType() { return 8; }
  
  public String getNodeName() { return "#comment"; }
  
  public String getText() { return ""; }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitCommentPre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitCommentPost(this); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TXComment.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */