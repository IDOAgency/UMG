package com.ibm.xml.parser;

public class ToNextSiblingTraversalException extends TreeTraversalException {
  public ToNextSiblingTraversalException() {}
  
  public ToNextSiblingTraversalException(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\ToNextSiblingTraversalException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */