package com.ibm.xml.parser;

import java.util.BitSet;

public class CMLeaf extends CMNode {
  static final long serialVersionUID = 8334965779973489245L;
  
  String name;
  
  int position;
  
  int maxPosition;
  
  public CMLeaf(String paramString) { this.name = paramString; }
  
  public String getName() { return this.name; }
  
  public String toString() { return this.name; }
  
  CMNode cloneNode() {
    CMLeaf cMLeaf = new CMLeaf(this.name);
    cMLeaf.position = this.position;
    cMLeaf.maxPosition = this.maxPosition;
    return cMLeaf;
  }
  
  void setPosition(int paramInt) { this.position = paramInt; }
  
  int getPosition() { return this.position; }
  
  boolean nullable() {
    if (this.nullable == null)
      this.nullable = new Boolean(false); 
    return false;
  }
  
  BitSet firstpos() {
    if (this.firstPos == null) {
      this.firstPos = new BitSet(this.maxPosition);
      this.firstPos.set(this.position);
    } 
    return this.firstPos;
  }
  
  BitSet lastpos() {
    if (this.lastPos == null) {
      this.lastPos = new BitSet(this.maxPosition);
      this.lastPos.set(this.position);
    } 
    return this.lastPos;
  }
  
  void prepare(int paramInt) { this.maxPosition = paramInt; }
  
  void setFollowpos(BitSet[] paramArrayOfBitSet) {}
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof CMLeaf))
      return false; 
    CMLeaf cMLeaf = (CMLeaf)paramObject;
    return cMLeaf.getName().equals(getName());
  }
  
  public int hashCode() { return getName().hashCode(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\CMLeaf.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */