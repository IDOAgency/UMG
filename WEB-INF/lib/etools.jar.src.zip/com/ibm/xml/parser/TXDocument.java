package com.ibm.xml.parser;

import java.io.IOException;
import java.io.Writer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;
import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.Entity;
import org.w3c.dom.EntityReference;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;

public class TXDocument extends Parent implements Document {
  static final long serialVersionUID = -7547414605402949958L;
  
  static TXDocument s_instance = null;
  
  static DOMImplementation s_domImpl = null;
  
  MessageDigest messageDigest;
  
  String defDigestAlgorithm = "MD5";
  
  TXElement rootElement;
  
  DTD doctype;
  
  String standalone;
  
  String xmlVersion;
  
  String xmlEncoding;
  
  boolean isCheckDocument = false;
  
  boolean checkValidity = false;
  
  boolean isProcessNamespace = false;
  
  boolean isCheckNodeLoop = true;
  
  boolean isAddFixedAttributes = true;
  
  public String expandedNameSeparator = ":";
  
  public Object clone() { return cloneNode(true); }
  
  public Node cloneNode(boolean paramBoolean) {
    TXDocument tXDocument;
    checkFactory();
    try {
      tXDocument = (TXDocument)getClass().newInstance();
    } catch (InstantiationException instantiationException) {
      throw new LibraryException("TXDocument#cloneNode(): " + instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      throw new LibraryException("TXDocument#cloneNode(): " + illegalAccessException);
    } 
    tXDocument.setFactory(getFactory());
    tXDocument.defDigestAlgorithm = "MD5";
    tXDocument.standalone = this.standalone;
    tXDocument.xmlVersion = this.xmlVersion;
    tXDocument.xmlEncoding = this.xmlEncoding;
    tXDocument.isCheckDocument = this.isCheckDocument;
    tXDocument.checkValidity = this.checkValidity;
    tXDocument.isProcessNamespace = this.isProcessNamespace;
    tXDocument.isCheckNodeLoop = this.isCheckNodeLoop;
    tXDocument.isAddFixedAttributes = this.isAddFixedAttributes;
    if (paramBoolean) {
      tXDocument.children.ensureCapacity(this.children.getLength());
      for (byte b = 0; b < this.children.getLength(); b++)
        tXDocument.appendChild(this.children.item(b).cloneNode(true)); 
    } 
    tXDocument.rootElement = (TXElement)tXDocument.getDocumentElement();
    tXDocument.doctype = tXDocument.getDTD();
    return tXDocument;
  }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (!(paramNode instanceof TXDocument))
      return false; 
    TXDocument tXDocument = (TXDocument)paramNode;
    return ((tXDocument.standalone != null || this.standalone != null) && (tXDocument.standalone == null || !tXDocument.standalone.equals(this.standalone))) ? false : (((tXDocument.xmlVersion != null || this.xmlVersion != null) && (tXDocument.xmlVersion == null || !tXDocument.xmlVersion.equals(this.xmlVersion))) ? false : (((tXDocument.xmlEncoding != null || this.xmlEncoding != null) && (tXDocument.xmlEncoding == null || !tXDocument.xmlEncoding.equals(this.xmlEncoding))) ? false : (!(paramBoolean && !tXDocument.children.equals(this.children, paramBoolean)))));
  }
  
  public short getNodeType() { return 9; }
  
  public String getNodeName() { return "#document"; }
  
  public Element getDocumentElement() { return this.rootElement; }
  
  void setDocumentElement(Element paramElement) { this.rootElement = (TXElement)paramElement; }
  
  public String getRootName() { return (this.rootElement == null) ? null : this.rootElement.getTagName(); }
  
  public NodeList getElementsByTagName(String paramString) { return (this.rootElement != null) ? this.rootElement.getElementsByTagName(paramString) : TXNodeList.emptyNodeList; }
  
  public DocumentType getDoctype() { return this.doctype; }
  
  public DTD getDTD() { return this.doctype; }
  
  public boolean isCheckValidity() { return this.checkValidity; }
  
  protected void resetCheckValidity() {
    this.checkValidity = false;
    if (this.doctype != null) {
      Enumeration enumeration = this.doctype.getElementDeclarations();
      if (enumeration.hasMoreElements())
        this.checkValidity = true; 
    } 
  }
  
  public String getStandalone() { return this.standalone; }
  
  public boolean isStandalone() { return (this.standalone == null) ? false : "yes".equals(this.standalone); }
  
  public void setStandalone(String paramString) {
    this.standalone = paramString;
    if (this.xmlVersion == null)
      this.xmlVersion = "1.0"; 
  }
  
  public String getVersion() { return this.xmlVersion; }
  
  public void setVersion(String paramString) { this.xmlVersion = paramString; }
  
  public String getEncoding() { return this.xmlEncoding; }
  
  public void setEncoding(String paramString) {
    this.xmlEncoding = paramString;
    if (this.xmlVersion == null)
      this.xmlVersion = "1.0"; 
  }
  
  public void setProcessNamespace(boolean paramBoolean) { this.isProcessNamespace = paramBoolean; }
  
  public boolean isProcessNamespace() { return this.isProcessNamespace; }
  
  protected void realInsert(Node paramNode, int paramInt) throws LibraryException {
    super.realInsert(paramNode, paramInt);
    if (paramNode instanceof DTD) {
      if (this.doctype != null)
        removeChild(this.doctype); 
      this.doctype = (DTD)paramNode;
      return;
    } 
    if (paramNode instanceof TXElement) {
      if (this.rootElement != null)
        throw new LibraryException("com.ibm.xml.parser.TXDocument#insert(): Document root Element was set twice."); 
      setDocumentElement((Element)paramNode);
    } 
  }
  
  public Node replaceChild(Node paramNode1, Node paramNode2) throws DOMException {
    if (paramNode1.getNodeType() == 1 && getDocumentElement() != null && paramNode2.getNodeType() != 1)
      throw new TXDOMException((short)3, "Root element already exists."); 
    super.replaceChild(paramNode1, paramNode2);
    if (paramNode1.getNodeType() != 1 && paramNode2.getNodeType() == 1)
      setDocumentElement(null); 
    if (paramNode1.getNodeType() == 1)
      setDocumentElement((Element)paramNode1); 
    return paramNode2;
  }
  
  public Node removeChild(Node paramNode) throws DOMException {
    super.removeChild(paramNode);
    if (paramNode == getDocumentElement()) {
      setDocumentElement(null);
    } else if (paramNode == getDoctype()) {
      this.doctype = null;
    } 
    return paramNode;
  }
  
  public void printWithFormat(Writer paramWriter) throws IOException, LibraryException { printWithFormat(paramWriter, null, 2); }
  
  public void printWithFormat(Writer paramWriter, String paramString) throws IOException, LibraryException { printWithFormat(paramWriter, paramString, 2); }
  
  public void printWithFormat(Writer paramWriter, String paramString, int paramInt) throws IOException, LibraryException {
    try {
      FormatPrintVisitor formatPrintVisitor = new FormatPrintVisitor(paramWriter, paramString, paramInt);
      (new NonRecursivePreorderTreeTraversal(formatPrintVisitor)).traverse(this);
      return;
    } catch (IOException iOException) {
      throw iOException;
    } catch (Exception exception) {
      throw new LibraryException("com.ibm.xml.parser.TXDocument#printWithFormat(): Unexpected Exception: " + exception.toString());
    } 
  }
  
  public void setPrintInternalDTD(boolean paramBoolean) {
    if (this.doctype != null)
      this.doctype.setPrintInternalDTD(paramBoolean); 
  }
  
  public String getText() { return (this.rootElement != null) ? this.rootElement.getText() : ""; }
  
  public DOMImplementation getImplementation() {
    if (s_domImpl == null)
      s_domImpl = new DOMImplementation() {
          public boolean hasFeature(String param1String1, String param1String2) { return !param1String1.equalsIgnoreCase("XML") ? false : ((param1String2 == null) ? true : param1String2.equals("1.0")); }
        }; 
    return s_domImpl;
  }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitDocumentPre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitDocumentPost(this); }
  
  public Document getOwnerDocument() { return null; }
  
  public TXDocument getFactory() { return this; }
  
  public static TXDocument getInstance() {
    if (s_instance == null)
      s_instance = new TXDocument(); 
    return s_instance;
  }
  
  public Element createElement(String paramString) throws DOMException {
    if (!Util.checkName(paramString))
      throw new TXDOMException((short)5, "Invalid name: " + paramString); 
    TXElement tXElement = new TXElement(paramString);
    tXElement.setFactory(this);
    return tXElement;
  }
  
  public Attr createAttribute(String paramString) throws DOMException {
    if (!Util.checkName(paramString))
      throw new TXDOMException((short)5, "Invalid name: " + paramString); 
    TXAttribute tXAttribute = new TXAttribute(paramString, null);
    tXAttribute.setFactory(this);
    return tXAttribute;
  }
  
  TXText createAttributeValue(String paramString) { return createTextNode(paramString, false); }
  
  public Text createTextNode(String paramString) { return createTextNode(paramString, false); }
  
  public TXText createTextNode(String paramString, boolean paramBoolean) {
    TXText tXText = new TXText(paramString);
    tXText.setFactory(this);
    tXText.setIsIgnorableWhitespace(paramBoolean);
    return tXText;
  }
  
  public TXText createTextNode(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) {
    TXText tXText = new TXText(new String(paramArrayOfChar, paramInt1, paramInt2));
    tXText.setFactory(this);
    tXText.setIsIgnorableWhitespace(paramBoolean);
    return tXText;
  }
  
  public CDATASection createCDATASection(String paramString) throws DOMException {
    TXCDATASection tXCDATASection = new TXCDATASection(paramString);
    tXCDATASection.setFactory(this);
    return tXCDATASection;
  }
  
  public Comment createComment(String paramString) {
    TXComment tXComment = new TXComment(paramString);
    tXComment.setFactory(this);
    return tXComment;
  }
  
  public ProcessingInstruction createProcessingInstruction(String paramString1, String paramString2) throws DOMException {
    if (!Util.checkName(paramString1))
      throw new TXDOMException((short)5, "Invalid PI target name: " + paramString1); 
    TXPI tXPI = new TXPI(paramString1, paramString2);
    tXPI.setFactory(this);
    return tXPI;
  }
  
  public StylesheetPI createStylesheetPI(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    StylesheetPI stylesheetPI = new StylesheetPI(paramString1, paramString2, paramString3, paramString4, paramString5);
    stylesheetPI.setFactory(this);
    return stylesheetPI;
  }
  
  public DTD createDTD() {
    DTD dTD = new DTD();
    dTD.setFactory(this);
    return dTD;
  }
  
  public DTD createDTD(String paramString, ExternalID paramExternalID) {
    DTD dTD = new DTD(paramString, paramExternalID);
    dTD.setFactory(this);
    return dTD;
  }
  
  public ElementDecl createElementDecl(String paramString, ContentModel paramContentModel) {
    ElementDecl elementDecl = new ElementDecl(paramString, paramContentModel);
    elementDecl.setFactory(this);
    return elementDecl;
  }
  
  public ContentModel createContentModel(int paramInt) {
    ContentModel contentModel = new ContentModel(paramInt);
    contentModel.setFactory(this);
    return contentModel;
  }
  
  public ContentModel createContentModel(CMNode paramCMNode) {
    ContentModel contentModel = new ContentModel(paramCMNode);
    contentModel.setFactory(this);
    return contentModel;
  }
  
  public Attlist createAttlist(String paramString) {
    Attlist attlist = new Attlist(paramString);
    attlist.setFactory(this);
    return attlist;
  }
  
  public AttDef createAttDef(String paramString) {
    AttDef attDef = new AttDef(paramString);
    attDef.setFactory(this);
    return attDef;
  }
  
  public EntityDecl createEntityDecl(String paramString1, String paramString2, boolean paramBoolean) {
    EntityDecl entityDecl = new EntityDecl(paramString1, paramString2, paramBoolean);
    entityDecl.setFactory(this);
    return entityDecl;
  }
  
  public EntityDecl createEntityDecl(String paramString1, ExternalID paramExternalID, boolean paramBoolean, String paramString2) {
    EntityDecl entityDecl = new EntityDecl(paramString1, paramExternalID, paramBoolean, paramString2);
    entityDecl.setFactory(this);
    return entityDecl;
  }
  
  public TXNotation createNotation(String paramString, ExternalID paramExternalID) {
    TXNotation tXNotation = new TXNotation(paramString, paramExternalID);
    tXNotation.setFactory(this);
    return tXNotation;
  }
  
  public EntityReference createEntityReference(String paramString) throws DOMException {
    if (!Util.checkName(paramString))
      throw new TXDOMException((short)5, "Invalid entity name: " + paramString); 
    GeneralReference generalReference = new GeneralReference(paramString);
    generalReference.setFactory(this);
    return generalReference;
  }
  
  public DocumentFragment createDocumentFragment() {
    TXDocumentFragment tXDocumentFragment = new TXDocumentFragment();
    tXDocumentFragment.setFactory(this);
    return tXDocumentFragment;
  }
  
  public Entity createEntity() { return null; }
  
  public MessageDigest createMessageDigest() throws NoSuchAlgorithmException {
    if (this.messageDigest == null) {
      this.messageDigest = MessageDigest.getInstance(this.defDigestAlgorithm);
    } else {
      this.messageDigest.reset();
    } 
    return this.messageDigest;
  }
  
  public void setDigestAlgorithm(String paramString) {
    if (!this.defDigestAlgorithm.equals(paramString)) {
      this.defDigestAlgorithm = paramString;
      this.messageDigest = null;
    } 
  }
  
  protected void checkChildType(Node paramNode) throws DOMException {
    switch (paramNode.getNodeType()) {
      default:
        throw new TXDOMException((short)3, "Specified node type (" + paramNode.getNodeType() + ") can't be a child of Document.");
      case 1:
      case 3:
      case 7:
      case 8:
      case 10:
      case 23:
        break;
    } 
  }
  
  public boolean isCheckOwnerDocument() { return this.isCheckDocument; }
  
  public void setCheckOwnerDocument(boolean paramBoolean) { this.isCheckDocument = paramBoolean; }
  
  public boolean isCheckNodeLoop() { return this.isCheckNodeLoop; }
  
  public void setCheckNodeLoop(boolean paramBoolean) { this.isCheckNodeLoop = paramBoolean; }
  
  public boolean isAddFixedAttributes() { return this.isAddFixedAttributes; }
  
  public void setAddFixedAttributes(boolean paramBoolean) { this.isAddFixedAttributes = paramBoolean; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TXDocument.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */