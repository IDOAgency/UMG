package com.ibm.xml.parser;

import java.io.IOException;
import java.io.Writer;
import java.util.Vector;

public class Util {
  public static boolean checkName(String paramString) { // Byte code:
    //   0: aload_0
    //   1: invokevirtual length : ()I
    //   4: iconst_1
    //   5: if_icmpge -> 10
    //   8: iconst_0
    //   9: ireturn
    //   10: aload_0
    //   11: iconst_0
    //   12: invokevirtual charAt : (I)C
    //   15: istore_1
    //   16: iload_1
    //   17: istore_2
    //   18: iload_2
    //   19: ldc 65536
    //   21: if_icmpge -> 28
    //   24: iload_2
    //   25: ifge -> 32
    //   28: iconst_0
    //   29: goto -> 43
    //   32: iconst_2
    //   33: getstatic com/ibm/xml/parser/XMLChar.flags : [B
    //   36: iload_2
    //   37: baload
    //   38: iand
    //   39: ifne -> 60
    //   42: iconst_0
    //   43: ifne -> 60
    //   46: iload_1
    //   47: bipush #95
    //   49: if_icmpeq -> 60
    //   52: iload_1
    //   53: bipush #58
    //   55: if_icmpeq -> 60
    //   58: iconst_0
    //   59: ireturn
    //   60: iconst_1
    //   61: istore_2
    //   62: goto -> 105
    //   65: aload_0
    //   66: iload_2
    //   67: invokevirtual charAt : (I)C
    //   70: istore_3
    //   71: iload_3
    //   72: ldc 65536
    //   74: if_icmpge -> 81
    //   77: iload_3
    //   78: ifge -> 85
    //   81: iconst_0
    //   82: goto -> 97
    //   85: bipush #8
    //   87: getstatic com/ibm/xml/parser/XMLChar.flags : [B
    //   90: iload_3
    //   91: baload
    //   92: iand
    //   93: ifne -> 102
    //   96: iconst_0
    //   97: ifne -> 102
    //   100: iconst_0
    //   101: ireturn
    //   102: iinc #2, 1
    //   105: iload_2
    //   106: aload_0
    //   107: invokevirtual length : ()I
    //   110: if_icmplt -> 65
    //   113: iconst_1
    //   114: ireturn }
  
  public static boolean checkNCName(String paramString) { // Byte code:
    //   0: aload_0
    //   1: invokevirtual length : ()I
    //   4: iconst_1
    //   5: if_icmpge -> 10
    //   8: iconst_0
    //   9: ireturn
    //   10: aload_0
    //   11: iconst_0
    //   12: invokevirtual charAt : (I)C
    //   15: istore_1
    //   16: iload_1
    //   17: ldc 65536
    //   19: if_icmpge -> 26
    //   22: iload_1
    //   23: ifge -> 30
    //   26: iconst_0
    //   27: goto -> 41
    //   30: iconst_2
    //   31: getstatic com/ibm/xml/parser/XMLChar.flags : [B
    //   34: iload_1
    //   35: baload
    //   36: iand
    //   37: ifne -> 52
    //   40: iconst_0
    //   41: ifne -> 52
    //   44: iload_1
    //   45: bipush #95
    //   47: if_icmpeq -> 52
    //   50: iconst_0
    //   51: ireturn
    //   52: iconst_1
    //   53: istore_2
    //   54: goto -> 103
    //   57: aload_0
    //   58: iload_2
    //   59: invokevirtual charAt : (I)C
    //   62: istore_1
    //   63: iload_1
    //   64: bipush #58
    //   66: if_icmpeq -> 98
    //   69: iload_1
    //   70: ldc 65536
    //   72: if_icmpge -> 79
    //   75: iload_1
    //   76: ifge -> 83
    //   79: iconst_0
    //   80: goto -> 95
    //   83: bipush #8
    //   85: getstatic com/ibm/xml/parser/XMLChar.flags : [B
    //   88: iload_1
    //   89: baload
    //   90: iand
    //   91: ifne -> 100
    //   94: iconst_0
    //   95: ifne -> 100
    //   98: iconst_0
    //   99: ireturn
    //   100: iinc #2, 1
    //   103: iload_2
    //   104: aload_0
    //   105: invokevirtual length : ()I
    //   108: if_icmplt -> 57
    //   111: iconst_1
    //   112: ireturn }
  
  public static boolean checkNmtoken(String paramString) {
    if (paramString.length() < 1)
      return false; 
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if ((0x8 & XMLChar.flags[c]) == 0) {
      
      } else {
        continue;
      } 
      if (!((c >= 65536 || c < '\000') ? 0 : 0))
        return false; 
      continue;
    } 
    return true;
  }
  
  public static boolean checkAllSpace(String paramString) {
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if (c < '\000' || c >= '' || ((0x4 & XMLChar.flags[c]) == 0 && !false))
        return false; 
    } 
    return true;
  }
  
  public static boolean checkEncoding(String paramString) {
    if (paramString.length() < 1)
      return false; 
    if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(paramString.charAt(0)) < 0)
      return false; 
    for (byte b = 1; b < paramString.length(); b++) {
      if ("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ._-".indexOf(paramString.charAt(b)) < 0)
        return false; 
    } 
    return true;
  }
  
  public static boolean checkLanguageID(String paramString) {
    int i = paramString.length();
    if (i < 2)
      return false; 
    char c1 = paramString.charAt(0);
    char c2 = paramString.charAt(1);
    byte b = 2;
    if (((c1 < 'a' || c1 > 'z') && (c1 < 'A' || c1 > 'Z')) || ((c2 < 'a' || c2 > 'z') && (c2 < 'A' || c2 > 'Z')))
      if (c2 == '-' && (c1 == 'i' || c1 == 'I' || c1 == 'x' || c1 == 'X') && i >= 3) {
        c1 = paramString.charAt(b++);
        if ((c1 < 'a' || c1 > 'z') && (c1 < 'A' || c1 > 'Z'))
          return false; 
        while (b < i) {
          c1 = paramString.charAt(b);
          if ((c1 >= 'a' && c1 <= 'z') || (c1 >= 'A' && c1 <= 'Z')) {
            b++;
            continue;
          } 
          break;
        } 
      } else {
        return false;
      }  
    while (b < i) {
      if (b + 2 > i)
        return false; 
      if (paramString.charAt(b++) != '-')
        return false; 
      c1 = paramString.charAt(b++);
      if ((c1 < 'a' || c1 > 'z') && (c1 < 'A' || c1 > 'Z'))
        return false; 
      while (b < i) {
        c1 = paramString.charAt(b);
        if ((c1 >= 'a' && c1 <= 'z') || (c1 >= 'A' && c1 <= 'Z')) {
          b++;
          continue;
        } 
        break;
      } 
    } 
    return true;
  }
  
  public static boolean checkVersionNum(String paramString) {
    if (paramString.length() < 1)
      return false; 
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z') && (c < '0' || c > '9') && "_.:-".indexOf(c) < 0)
        return false; 
    } 
    return true;
  }
  
  public static int getInvalidURIChar(String paramString) {
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z') && (c < '0' || c > '9') && ";/?:@&=+$,-_.!~*'()%".indexOf(c) < 0)
        return b; 
    } 
    return -1;
  }
  
  public static boolean isURN(String paramString) { return !(paramString.length() <= 4 || !paramString.substring(0, 4).equalsIgnoreCase("urn:")); }
  
  public static String normalizeURN(String paramString) {
    boolean bool = true;
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if (c >= 'A' && c <= 'Z')
        bool = false; 
      if (b >= 4 && c == ':')
        return bool ? paramString : (String.valueOf(paramString.substring(0, b).toLowerCase()) + paramString.substring(b)); 
    } 
    return paramString;
  }
  
  public static String backReference(String paramString1, String paramString2) {
    StringBuffer stringBuffer = new StringBuffer(paramString1.length() * 12 / 10);
    for (byte b = 0; b < paramString1.length(); b++) {
      char c = paramString1.charAt(b);
      if (c == '<') {
        stringBuffer.append("&lt;");
      } else if (c == '>') {
        stringBuffer.append("&gt;");
      } else if (c == '&') {
        stringBuffer.append("&amp;");
      } else if (c >= '?' && c < '?') {
        if (b + 1 >= paramString1.length())
          throw new LibraryException("com.ibm.xml.parser.Util#backReference(): Invalid UTF-16 surrogate detected: " + Integer.toHexString(c) + " ?"); 
        char c1 = paramString1.charAt(++b);
        if (c1 < '?' || c1 >= '')
          throw new LibraryException("com.ibm.xml.parser.Util#backReference(): Invalid UTF-16 surrogate detected: " + Integer.toHexString(c) + " " + Integer.toHexString(c1)); 
        c1 = (c - '?' << '\n') + c1 - '?' + 65536;
        stringBuffer.append("&#x");
        stringBuffer.append(Integer.toHexString(c1));
        stringBuffer.append(";");
      } else {
        stringBuffer.append(c);
      } 
    } 
    return stringBuffer.toString();
  }
  
  public static String backReferenceForEntity(String paramString1, String paramString2) { return backReference(paramString1, "&\"'%\r\n\t", paramString2); }
  
  public static String backReference(String paramString1, String paramString2, String paramString3) {
    StringBuffer stringBuffer = new StringBuffer(paramString1.length() * 12 / 10);
    for (byte b = 0; b < paramString1.length(); b++) {
      char c = paramString1.charAt(b);
      int i = paramString2.indexOf(c);
      if (i >= 0) {
        stringBuffer.append("&#");
        stringBuffer.append(Integer.toString(c));
        stringBuffer.append(";");
      } else if (c >= '?' && c < '?') {
        if (b + 1 >= paramString1.length())
          throw new LibraryException("com.ibm.xml.parser.Util#backReference(): Invalid UTF-16 surrogate detected: " + Integer.toHexString(c) + " ?"); 
        char c1 = paramString1.charAt(++b);
        if (c1 < '?' || c1 >= '')
          throw new LibraryException("com.ibm.xml.parser.Util#backReference(): Invalid UTF-16 surrogate detected: " + Integer.toHexString(c) + " " + Integer.toHexString(c1)); 
        c1 = (c - '?' << '\n') + c1 - '?' + 65536;
        stringBuffer.append("&#x");
        stringBuffer.append(Integer.toHexString(c1));
        stringBuffer.append(";");
      } else {
        stringBuffer.append(c);
      } 
    } 
    return stringBuffer.toString();
  }
  
  public static void printSpace(Writer paramWriter, int paramInt) throws IOException {
    for (byte b = 0; b < paramInt; b++)
      paramWriter.write(" "); 
  }
  
  public static void indent(Writer paramWriter, int paramInt) throws IOException {
    paramWriter.write("\n");
    printSpace(paramWriter, paramInt);
  }
  
  public static Vector sortStringVector(Vector paramVector) {
    String[] arrayOfString = new String[paramVector.size()];
    paramVector.copyInto(arrayOfString);
    heapSort(arrayOfString, arrayOfString.length);
    paramVector.removeAllElements();
    paramVector.ensureCapacity(arrayOfString.length);
    for (byte b = 0; b < arrayOfString.length; b++)
      paramVector.addElement(arrayOfString[b]); 
    return paramVector;
  }
  
  public static void heapSort(String[] paramArrayOfString) { heapSort(paramArrayOfString, paramArrayOfString.length); }
  
  public static void heapSort(String[] paramArrayOfString, int paramInt) {
    int i;
    for (i = paramInt / 2; i >= 0; i--)
      fall(paramArrayOfString, paramInt, i); 
    for (i = paramInt - 1; i > 0; i--) {
      String str = paramArrayOfString[0];
      paramArrayOfString[0] = paramArrayOfString[i];
      paramArrayOfString[i] = str;
      fall(paramArrayOfString, i, 0);
    } 
  }
  
  private static void fall(String[] paramArrayOfString, int paramInt1, int paramInt2) {
    int i = 2 * paramInt2 + 1;
    if (i < paramInt1) {
      if (i + 1 < paramInt1 && paramArrayOfString[i].compareTo(paramArrayOfString[i + 1]) < 0)
        i = 2 * paramInt2 + 2; 
      if (paramArrayOfString[paramInt2].compareTo(paramArrayOfString[i]) < 0) {
        String str = paramArrayOfString[paramInt2];
        paramArrayOfString[paramInt2] = paramArrayOfString[i];
        paramArrayOfString[i] = str;
        fall(paramArrayOfString, paramInt1, i);
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\Util.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */