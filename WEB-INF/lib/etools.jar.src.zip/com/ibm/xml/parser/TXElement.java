package com.ibm.xml.parser;

import java.util.Enumeration;
import java.util.Vector;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class TXElement extends Parent implements Element, Namespace {
  static final long serialVersionUID = 1851699621748517673L;
  
  public static final String S_XMLNS = "xmlns";
  
  public static final String S_XMLNAMESPACEURI = "http://www.w3.org/XML/1998/namespace";
  
  String name;
  
  TXAttributeList attributes;
  
  boolean isPreserveSpace = false;
  
  public TXElement(String paramString) { setTagName(paramString); }
  
  public Object clone() {
    TXElement tXElement = cloneWithoutChildren();
    tXElement.children.ensureCapacity(this.children.getLength());
    for (byte b = 0; b < this.children.getLength(); b++)
      tXElement.insertBefore(this.children.item(b).cloneNode(true), null); 
    return tXElement;
  }
  
  public TXElement cloneWithoutChildren() {
    checkFactory();
    TXElement tXElement = (TXElement)this.factory.createElement(getTagName());
    tXElement.setFactory(getFactory());
    tXElement.setPreserveSpace(this.isPreserveSpace);
    if (this.attributes != null)
      for (byte b = 0; b < this.attributes.getLength(); b++)
        tXElement.setAttributeNode((TXAttribute)this.attributes.item(b).cloneNode(true));  
    return tXElement;
  }
  
  public Node cloneNode(boolean paramBoolean) { return paramBoolean ? (Node)clone() : cloneWithoutChildren(); }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (paramNode == null)
      return false; 
    if (!(paramNode instanceof TXElement))
      return false; 
    TXElement tXElement = (TXElement)paramNode;
    if (!tXElement.getTagName().equals(getTagName()))
      return false; 
    NamedNodeMap namedNodeMap1 = tXElement.getAttributes();
    NamedNodeMap namedNodeMap2 = getAttributes();
    if (namedNodeMap1.getLength() != namedNodeMap2.getLength())
      return false; 
    for (byte b = 0; b < namedNodeMap1.getLength(); b++) {
      Attr attr1 = (Attr)namedNodeMap1.item(b);
      Attr attr2 = (Attr)namedNodeMap2.getNamedItem(attr1.getName());
      if (attr2 == null || !((Child)attr1).equals(attr2, true))
        return false; 
    } 
    return !(paramBoolean && !tXElement.children.equals(this.children, paramBoolean));
  }
  
  public short getNodeType() { return 1; }
  
  public String getNodeName() { return getTagName(); }
  
  public String getTagName() { return this.name; }
  
  public String getName() { return getTagName(); }
  
  public void setTagName(String paramString) {
    this.name = paramString;
    clearDigest();
  }
  
  public String getAttribute(String paramString) {
    if (this.attributes != null) {
      TXAttribute tXAttribute = (TXAttribute)this.attributes.getNamedItem(paramString);
      return (tXAttribute == null) ? "" : tXAttribute.getValue();
    } 
    return "";
  }
  
  String getAttributeOrNull(String paramString) {
    if (this.attributes != null) {
      TXAttribute tXAttribute = (TXAttribute)this.attributes.getNamedItem(paramString);
      return (tXAttribute == null) ? null : tXAttribute.getValue();
    } 
    return null;
  }
  
  public Attr getAttributeNode(String paramString) { return (this.attributes != null) ? (Attr)this.attributes.getNamedItem(paramString) : null; }
  
  public void setAttribute(String paramString1, String paramString2) throws DOMException {
    checkFactory();
    Attr attr = getAttributeNode(paramString1);
    if (attr == null) {
      attr = this.factory.createAttribute(paramString1);
      setAttributeNode(attr);
      attr.setValue(paramString2);
      return;
    } 
    attr.setValue(paramString2);
    clearDigest();
  }
  
  public void setAttribute(TXAttribute paramTXAttribute) {
    makeAttributeList();
    this.attributes.setNamedItem(paramTXAttribute);
  }
  
  public Attr setAttributeNode(Attr paramAttr) {
    makeAttributeList();
    return (Attr)this.attributes.setNamedItem(paramAttr);
  }
  
  public void removeAttribute(String paramString) {
    if (this.attributes != null)
      this.attributes.removeNamedItem(paramString); 
    resetDefaultAttribute(paramString);
  }
  
  public Attr removeAttributeNode(Attr paramAttr) {
    Attr attr = null;
    if (this.attributes != null) {
      String str = getAttributeOrNull(paramAttr.getName());
      if (str != null && str.equals(paramAttr.getValue()))
        attr = (Attr)this.attributes.removeNamedItem(paramAttr.getName()); 
    } 
    resetDefaultAttribute(paramAttr.getName());
    return attr;
  }
  
  protected void resetDefaultAttribute(String paramString) {
    Attr attr;
    TXDocument tXDocument = (TXDocument)getOwnerDocument();
    DTD dTD = (DTD)tXDocument.getDoctype();
    if (dTD == null)
      return; 
    AttDef attDef = dTD.getAttributeDeclaration(getNodeName(), paramString);
    if (attDef == null)
      return; 
    switch (attDef.getDefaultType()) {
      case 1:
        if (!tXDocument.isAddFixedAttributes())
          return; 
      case -1:
        attr = tXDocument.createAttribute(paramString);
        attr.setNodeValue(attDef.getDefaultStringValue());
        ((TXAttribute)attr).setSpecified(false);
        setAttributeNode(attr);
        return;
    } 
  }
  
  public NamedNodeMap getAttributes() {
    makeAttributeList();
    return this.attributes;
  }
  
  public TXAttribute[] getAttributeArray() { return (this.attributes == null) ? new TXAttribute[0] : this.attributes.makeArray(); }
  
  public Enumeration attributeElements() {
    makeAttributeList();
    return this.attributes.elements();
  }
  
  public String getNSLocalName() { return getLocalNameForQName(getNodeName()); }
  
  public String getNSName() { return getNamespaceForQName(getNodeName()); }
  
  public String getUniversalName() {
    String str = getNSName();
    return (str == null) ? getNSLocalName() : (String.valueOf(str) + ":" + getNSLocalName());
  }
  
  public String createExpandedName() {
    String str = getNSName();
    return (str == null || str.length() == 0) ? getNSLocalName() : (String.valueOf(str) + (getFactory()).expandedNameSeparator + getNSLocalName());
  }
  
  public boolean isEmpty() { return !(this.children.getLength() != 0); }
  
  public boolean isPreserveSpace() { return this.isPreserveSpace; }
  
  public void setPreserveSpace(boolean paramBoolean) { this.isPreserveSpace = paramBoolean; }
  
  public String getLanguage() {
    String str = getAttributeOrNull("xml:lang");
    if (str != null)
      return str; 
    if (this.parent != null) {
      if (this.parent instanceof TXElement)
        return ((TXElement)this.parent).getLanguage(); 
      if (this.parent instanceof GeneralReference)
        return ((GeneralReference)this.parent).getLanguage(); 
    } 
    return null;
  }
  
  public void normalize() { normalize(this, isPreserveSpace()); }
  
  private static void normalize(Node paramNode, boolean paramBoolean) {
    Node node1 = paramNode.getFirstChild();
    if (node1 == null)
      return; 
    if (node1.getNodeType() == 1) {
      normalize(node1, ((TXElement)node1).isPreserveSpace());
    } else if (node1.getNodeType() == 5) {
      normalize(node1, paramBoolean);
    } 
    Node node2;
    while ((node2 = node1.getNextSibling()) != null) {
      short s = node2.getNodeType();
      if (s == 3 && node1.getNodeType() == 3) {
        ((Text)node2).setData(String.valueOf(node1.getNodeValue()) + node2.getNodeValue());
        paramNode.removeChild(node1);
        if (!paramBoolean && Util.checkAllSpace(node2.getNodeValue())) {
          Node node3 = node2.getPreviousSibling();
          Node node4 = node2.getNextSibling();
          if ((node3 == null || node3.getNodeType() != 3) && (node4 == null || node4.getNodeType() != 3))
            ((TXText)node2).setIsIgnorableWhitespace(true); 
        } 
      } else if (s == 1) {
        normalize(node2, ((TXElement)node2).isPreserveSpace());
      } else if (s == 5) {
        normalize(node2, paramBoolean);
      } 
      node1 = node2;
    } 
  }
  
  public void addTextElement(TXText paramTXText) {
    if (paramTXText == null)
      return; 
    if (paramTXText instanceof org.w3c.dom.CDATASection) {
      appendChild(paramTXText);
      return;
    } 
    Node node = getLastChild();
    if (node == null) {
      appendChild(paramTXText);
      return;
    } 
    if (node.getNodeType() == 3) {
      ((Text)node).appendData(paramTXText.getData());
      if (!paramTXText.getIsIgnorableWhitespace() || !((TXText)node).getIsIgnorableWhitespace())
        ((TXText)node).setIsIgnorableWhitespace(false); 
      return;
    } 
    appendChild(paramTXText);
  }
  
  public TXElement searchDescendants(String paramString) { return searchDescendants(0, null, paramString); }
  
  public TXElement searchDescendants(int paramInt, String paramString1, String paramString2) {
    for (Child child = (Child)getFirstChild(); child != null; child = (Child)child.getNextSibling()) {
      if (child instanceof TXElement) {
        if (Match.matchName((TXElement)child, paramInt, paramString1, paramString2))
          return (TXElement)child; 
        TXElement tXElement = ((TXElement)child).searchDescendants(paramInt, paramString1, paramString2);
        if (tXElement != null)
          return tXElement; 
      } 
    } 
    return null;
  }
  
  public TXElement getElementNamed(String paramString) { return getNthElementNamed(0, 0, null, paramString); }
  
  public TXElement getElementNamed(String paramString1, String paramString2) { return getNthElementNamed(0, 2, paramString1, paramString2); }
  
  public TXElement getElementNamed(int paramInt, String paramString1, String paramString2) { return getNthElementNamed(0, paramInt, paramString1, paramString2); }
  
  public TXElement getNthElementNamed(int paramInt, String paramString) { return getNthElementNamed(paramInt, 0, null, paramString); }
  
  public TXElement getNthElementNamed(int paramInt, String paramString1, String paramString2) { return getNthElementNamed(paramInt, 2, paramString1, paramString2); }
  
  public TXElement getNthElementNamed(int paramInt1, int paramInt2, String paramString1, String paramString2) {
    for (Node node = getFirstChild(); node != null; node = node.getNextSibling()) {
      if (node instanceof TXElement) {
        TXElement tXElement = (TXElement)node;
        if (Match.matchName(tXElement, paramInt2, paramString1, paramString2)) {
          if (paramInt1 == 0)
            return tXElement; 
          paramInt1--;
        } 
      } 
    } 
    return null;
  }
  
  public TXElement[] searchChildrenAll(String paramString) {
    Vector vector = new Vector();
    for (Node node = getFirstChild(); node != null; node = node.getNextSibling()) {
      if (node instanceof Element && Match.matchName((Namespace)node, 0, null, paramString))
        vector.addElement(node); 
    } 
    TXElement[] arrayOfTXElement = new TXElement[vector.size()];
    vector.copyInto(arrayOfTXElement);
    return arrayOfTXElement;
  }
  
  public NodeList getElementsByTagName(String paramString) { return new TXNodeList.VectorNodeList(realSearchDescendantsAll(0, null, paramString)); }
  
  public TXElement[] searchDescendantsAll(String paramString) { return searchDescendantsAll(0, null, paramString); }
  
  public TXElement[] searchDescendantsAll(int paramInt, String paramString1, String paramString2) {
    Vector vector = realSearchDescendantsAll(paramInt, paramString1, paramString2);
    TXElement[] arrayOfTXElement = new TXElement[vector.size()];
    vector.copyInto(arrayOfTXElement);
    return arrayOfTXElement;
  }
  
  public NodeList getElementsNamed(String paramString) { return getElementsNamed(0, null, paramString); }
  
  public NodeList getElementsNamed(String paramString1, String paramString2) { return getElementsNamed(2, paramString1, paramString2); }
  
  public NodeList getElementsNamed(int paramInt, String paramString1, String paramString2) {
    Vector vector = new Vector();
    for (Node node = getFirstChild(); node != null; node = node.getNextSibling()) {
      if (node instanceof Element && Match.matchName((Namespace)node, paramInt, paramString1, paramString2))
        vector.addElement(node); 
    } 
    return new TXNodeList.VectorNodeList(vector);
  }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitElementPre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitElementPost(this); }
  
  private Vector realSearchDescendantsAll(int paramInt, String paramString1, String paramString2) {
    Vector vector = new Vector();
    SearchElementVisitor searchElementVisitor = new SearchElementVisitor(vector, paramInt, paramString1, paramString2);
    try {
      (new NonRecursivePreorderTreeTraversal(searchElementVisitor)).traverse(this);
    } catch (Exception exception) {}
    return vector;
  }
  
  private void makeAttributeList() {
    if (this.attributes == null) {
      checkFactory();
      this.attributes = new TXAttributeList();
      this.attributes.setParent(this);
    } 
  }
  
  protected void checkChildType(Node paramNode) throws DOMException {
    switch (paramNode.getNodeType()) {
      default:
        throw new TXDOMException((short)3, "Specified node type (" + paramNode.getNodeType() + ") can't be a child of Element.");
      case 1:
      case 3:
      case 4:
      case 5:
      case 7:
      case 8:
      case 23:
        break;
    } 
  }
  
  public String getNamespaceForPrefix(String paramString) {
    if (paramString.equals("xml"))
      return "http://www.w3.org/XML/1998/namespace"; 
    if (paramString.equals("xmlns"))
      return paramString; 
    String str = (paramString.length() == 0) ? "xmlns" : ("xmlns:" + paramString);
    Node node = this;
    do {
      short s;
      String str1 = ((TXElement)node).getAttributeOrNull(str);
      if (str1 != null)
        return str1; 
      do {
        node = node.getParentNode();
        if (node == null)
          return (str == "xmlns") ? "" : null; 
        s = node.getNodeType();
      } while (s == 5);
      if (s != 1)
        return (str == "xmlns") ? "" : null; 
    } while (node != null);
    return null;
  }
  
  public String getNamespaceForQName(String paramString) {
    int i = paramString.indexOf(':');
    String str = (i < 0) ? "" : paramString.substring(0, i).intern();
    return getNamespaceForPrefix(str);
  }
  
  public static String getLocalNameForQName(String paramString) {
    int i = paramString.indexOf(':');
    return (i < 0) ? paramString : paramString.substring(i + 1).intern();
  }
  
  public void collectNamespaceAttributes() { collectNamespaceAttributes(getParentNode()); }
  
  public void collectNamespaceAttributes(Node paramNode) throws DOMException {
    if (!getFactory().isProcessNamespace())
      return; 
    short s;
    while (paramNode != null && ((s = paramNode.getNodeType()) == 1 || s == 5)) {
      if (s == 1) {
        NamedNodeMap namedNodeMap = paramNode.getAttributes();
        for (byte b = 0; b < namedNodeMap.getLength(); b++) {
          Node node = namedNodeMap.item(b);
          String str = node.getNodeName();
          if ((str.equals("xmlns") || str.startsWith("xmlns:")) && getAttributeNode(str) == null)
            setAttribute(str, node.getNodeValue()); 
        } 
      } 
      paramNode = paramNode.getParentNode();
    } 
  }
  
  public void removeOverlappedNamespaceAttributes() {
    if (!getFactory().isProcessNamespace())
      return; 
    Vector vector = new Vector();
    NamedNodeMap namedNodeMap = getAttributes();
    for (byte b1 = 0; b1 < namedNodeMap.getLength(); b1++) {
      Node node = namedNodeMap.item(b1);
      String str = node.getNodeName();
      if (str.equals("xmlns") || str.startsWith("xmlns:")) {
        short s;
        for (Node node1 = getParentNode(); node1 != null && ((s = node1.getNodeType()) == 1 || s == 5); node1 = node1.getParentNode()) {
          if (s == 1) {
            TXElement tXElement = (TXElement)node1;
            String str1 = tXElement.getAttributeOrNull(str);
            if (str1 != null && str1.equals(node.getNodeValue()))
              vector.addElement(str); 
          } 
        } 
      } 
    } 
    for (byte b2 = 0; b2 < vector.size(); b2++)
      removeAttribute((String)vector.elementAt(b2)); 
  }
  
  static class SearchElementVisitor extends NOOPVisitor {
    Vector result;
    
    int matchtype;
    
    String nsorpre;
    
    String ename;
    
    SearchElementVisitor(Vector param1Vector, int param1Int, String param1String1, String param1String2) {
      this.result = param1Vector;
      this.matchtype = param1Int;
      this.nsorpre = param1String1;
      this.ename = param1String2;
    }
    
    public void visitElementPre(TXElement param1TXElement) throws Exception {
      if (Match.matchName(param1TXElement, this.matchtype, this.nsorpre, this.ename))
        this.result.addElement(param1TXElement); 
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TXElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */