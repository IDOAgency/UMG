package com.ibm.xml.parser;

public interface PIHandler {
  void handlePI(String paramString1, String paramString2);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\PIHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */