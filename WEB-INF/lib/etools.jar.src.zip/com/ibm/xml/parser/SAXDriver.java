package com.ibm.xml.parser;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Locale;
import java.util.Stack;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;
import org.xml.sax.AttributeList;
import org.xml.sax.DTDHandler;
import org.xml.sax.DocumentHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.HandlerBase;
import org.xml.sax.InputSource;
import org.xml.sax.Parser;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.LocatorImpl;

public class SAXDriver implements Parser, AttributeList, ErrorListener, TagHandler, StreamProducer {
  static HandlerBase s_defaulthandler = new HandlerBase();
  
  Parser parser;
  
  Locale locale;
  
  EntityResolver entityHandler = s_defaulthandler;
  
  DTDHandler dtdHandler = s_defaulthandler;
  
  DocumentHandler documentHandler = s_defaulthandler;
  
  ErrorHandler errorHandler = s_defaulthandler;
  
  TXAttribute[] attributes;
  
  DTD dtd;
  
  String currentSystemID;
  
  Stack stack;
  
  int depth;
  
  RuntimeException userException;
  
  boolean pause = false;
  
  public void setLocale(Locale paramLocale) throws SAXException {
    this.locale = paramLocale;
    if (this.parser != null)
      this.parser.setLocale(paramLocale); 
  }
  
  public void setEntityResolver(EntityResolver paramEntityResolver) { this.entityHandler = paramEntityResolver; }
  
  public void setDTDHandler(DTDHandler paramDTDHandler) { this.dtdHandler = paramDTDHandler; }
  
  public void setDocumentHandler(DocumentHandler paramDocumentHandler) { this.documentHandler = paramDocumentHandler; }
  
  public void setErrorHandler(ErrorHandler paramErrorHandler) { this.errorHandler = paramErrorHandler; }
  
  public void parse(InputSource paramInputSource) throws SAXException {
    this.depth = 0;
    this.pause = false;
    this.stack = new Stack();
    this.currentSystemID = paramInputSource.getSystemId();
    this.documentHandler.startDocument();
    try {
      this.parser = new Parser(this.currentSystemID, this, this);
      this.parser.setSAXDriver(this);
      if (this.locale != null)
        this.parser.setLocale(this.locale); 
      this.parser.setElementFactory(new SAXDocument(this));
      this.parser.setTagHandler(this);
      this.stack.push(this.currentSystemID);
      if (paramInputSource.getByteStream() != null) {
        this.parser.readStream(paramInputSource.getByteStream());
      } else if (paramInputSource.getCharacterStream() != null) {
        this.parser.readStream(paramInputSource.getCharacterStream());
      } else {
        this.parser.readStream(getInputStream(this.currentSystemID, null, this.currentSystemID));
      } 
      if (this.userException == null)
        this.documentHandler.endDocument(); 
    } catch (SAXException sAXException) {
      throw sAXException;
    } catch (ExceptionWrapper exceptionWrapper) {
      throw exceptionWrapper.wrapped;
    } catch (Exception exception) {
      throw new SAXException(exception);
    } finally {
      this.parser = null;
      this.attributes = null;
      this.dtd = null;
      this.currentSystemID = null;
      this.stack = null;
      this.userException = null;
    } 
  }
  
  public void parse(String paramString) throws SAXException { parse(new InputSource(paramString)); }
  
  public int getLength() { return this.attributes.length; }
  
  public String getName(int paramInt) { return this.attributes[paramInt].getName(); }
  
  public String getType(int paramInt) {
    int i = this.attributes[paramInt].getType();
    if (i == 0)
      i = 1; 
    return AttDef.S_TYPESTR[i];
  }
  
  public String getType(String paramString) {
    int i = searchAttribute(paramString);
    return (i < 0) ? null : getType(i);
  }
  
  public String getValue(int paramInt) { return this.attributes[paramInt].getValue(); }
  
  public String getValue(String paramString) {
    int i = searchAttribute(paramString);
    return (i < 0) ? null : getValue(i);
  }
  
  public Source getInputStream(String paramString1, String paramString2, String paramString3) throws IOException, RuntimeException {
    Source source = null;
    String str = this.currentSystemID;
    if (paramString3 != null)
      try {
        this.stack.push(str);
        this.currentSystemID = paramString3;
        InputSource inputSource = this.entityHandler.resolveEntity(paramString2, paramString3);
        if (inputSource != null) {
          if (inputSource.getSystemId() != null)
            this.currentSystemID = paramString3 = inputSource.getSystemId(); 
          if (inputSource.getByteStream() != null) {
            source = new Source(inputSource.getByteStream());
          } else if (inputSource.getCharacterStream() != null) {
            source = new Source(inputSource.getCharacterStream());
          } 
        } 
        if (source == null) {
          URL uRL;
          if (str == null) {
            uRL = new URL(paramString3);
          } else {
            uRL = new URL(new URL(str), paramString3);
          } 
          this.currentSystemID = uRL.toString();
          source = new Source(uRL.openStream());
        } 
      } catch (MalformedURLException malformedURLException) {
        source = new Source(new FileInputStream(paramString3));
      } catch (SAXException sAXException) {
        throw new ExceptionWrapper(this, sAXException);
      }  
    return source;
  }
  
  public void closeInputStream(Source paramSource) {
    try {
      this.currentSystemID = (String)this.stack.pop();
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  public void loadCatalog(Reader paramReader) throws IOException {}
  
  public int error(String paramString1, int paramInt1, int paramInt2, Object paramObject, String paramString2) throws RuntimeException {
    if (this.userException != null)
      throw this.userException; 
    LocatorImpl locatorImpl = new LocatorImpl();
    locatorImpl.setSystemId(paramString1);
    locatorImpl.setLineNumber(paramInt1);
    locatorImpl.setColumnNumber(paramInt2);
    SAXParseException sAXParseException = new SAXParseException(paramString2, locatorImpl);
    boolean bool1 = (!(paramObject instanceof String) || !((String)paramObject).startsWith("W_")) ? 0 : 1;
    boolean bool2 = (!(paramObject instanceof String) || !((String)paramObject).startsWith("V_")) ? 0 : 1;
    try {
      if (bool1) {
        this.errorHandler.warning(sAXParseException);
      } else if (bool2) {
        this.errorHandler.error(sAXParseException);
      } else {
        this.errorHandler.fatalError(sAXParseException);
      } 
    } catch (SAXException sAXException) {
      this.userException = new ExceptionWrapper(this, sAXException);
      throw this.userException;
    } 
    return 0;
  }
  
  public void handleStartTag(TXElement paramTXElement, boolean paramBoolean) throws RuntimeException {
    this.depth++;
    if (!this.pause) {
      this.attributes = paramTXElement.getAttributeArray();
      try {
        this.documentHandler.startElement(paramTXElement.getNodeName(), this);
      } catch (SAXException sAXException) {
        throw new ExceptionWrapper(this, sAXException);
      } 
      this.attributes = null;
    } 
  }
  
  public void handleEndTag(TXElement paramTXElement, boolean paramBoolean) throws RuntimeException {
    this.depth--;
    if (!this.pause)
      try {
        this.documentHandler.endElement(paramTXElement.getNodeName());
        return;
      } catch (SAXException sAXException) {
        throw new ExceptionWrapper(this, sAXException);
      }  
  }
  
  private int searchAttribute(String paramString) {
    for (byte b = 0; b < this.attributes.length; b++) {
      if (paramString.equals(this.attributes[b].getName()))
        return b; 
    } 
    return -1;
  }
  
  void pauseEvent(boolean paramBoolean) { this.pause = paramBoolean; }
  
  class ExceptionWrapper extends RuntimeException {
    private final SAXDriver this$0;
    
    SAXException wrapped;
    
    ExceptionWrapper(SAXDriver this$0, SAXException param1SAXException) {
      super(param1SAXException.getMessage());
      this.this$0 = this$0;
      this.this$0 = this$0;
      this.wrapped = param1SAXException;
    }
    
    public String getMessage() { return this.wrapped.getMessage(); }
  }
  
  class SAXDocument extends TXDocument {
    private final SAXDriver this$0;
    
    public DTD createDTD(String param1String, ExternalID param1ExternalID) { return this.this$0.dtd = super.createDTD(param1String, param1ExternalID); }
    
    public EntityDecl createEntityDecl(String param1String1, ExternalID param1ExternalID, boolean param1Boolean, String param1String2) throws RuntimeException {
      if (param1String2 != null)
        try {
          this.this$0.dtdHandler.unparsedEntityDecl(param1String1, param1ExternalID.getPubidLiteral(), param1ExternalID.getSystemLiteral(), param1String2);
        } catch (SAXException sAXException) {
          throw new SAXDriver.ExceptionWrapper(this.this$0, sAXException);
        }  
      return super.createEntityDecl(param1String1, param1ExternalID, param1Boolean, param1String2);
    }
    
    public TXNotation createNotation(String param1String, ExternalID param1ExternalID) throws RuntimeException {
      try {
        this.this$0.dtdHandler.notationDecl(param1String, param1ExternalID.getPubidLiteral(), param1ExternalID.getSystemLiteral());
      } catch (SAXException sAXException) {
        throw new SAXDriver.ExceptionWrapper(this.this$0, sAXException);
      } 
      return super.createNotation(param1String, param1ExternalID);
    }
    
    TXText createAttributeValue(String param1String) throws RuntimeException { return null; }
    
    public Text createTextNode(String param1String) throws RuntimeException { return createTextNode(param1String, false); }
    
    public TXText createTextNode(String param1String, boolean param1Boolean) throws RuntimeException {
      if (this.this$0.depth > 0 && !this.this$0.pause) {
        char[] arrayOfChar = param1String.toCharArray();
        try {
          if (param1Boolean) {
            this.this$0.documentHandler.ignorableWhitespace(arrayOfChar, 0, arrayOfChar.length);
          } else {
            this.this$0.documentHandler.characters(arrayOfChar, 0, arrayOfChar.length);
          } 
        } catch (SAXException sAXException) {
          throw new SAXDriver.ExceptionWrapper(this.this$0, sAXException);
        } 
      } 
      return null;
    }
    
    public TXText createTextNode(char[] param1ArrayOfChar, int param1Int1, int param1Int2, boolean param1Boolean) throws RuntimeException {
      if (this.this$0.depth > 0 && !this.this$0.pause)
        try {
          if (param1Boolean) {
            this.this$0.documentHandler.ignorableWhitespace(param1ArrayOfChar, param1Int1, param1Int2);
          } else {
            this.this$0.documentHandler.characters(param1ArrayOfChar, param1Int1, param1Int2);
          } 
        } catch (SAXException sAXException) {
          throw new SAXDriver.ExceptionWrapper(this.this$0, sAXException);
        }  
      return null;
    }
    
    public CDATASection createCDATASection(String param1String) throws RuntimeException {
      if (!this.this$0.pause)
        try {
          char[] arrayOfChar = param1String.toCharArray();
          this.this$0.documentHandler.characters(arrayOfChar, 0, arrayOfChar.length);
        } catch (SAXException sAXException) {
          throw new SAXDriver.ExceptionWrapper(this.this$0, sAXException);
        }  
      return null;
    }
    
    public Comment createComment(String param1String) { return null; }
    
    public ProcessingInstruction createProcessingInstruction(String param1String1, String param1String2) throws RuntimeException {
      if (!this.this$0.pause)
        try {
          this.this$0.documentHandler.processingInstruction(param1String1, param1String2);
        } catch (SAXException sAXException) {
          throw new SAXDriver.ExceptionWrapper(this.this$0, sAXException);
        }  
      return null;
    }
    
    public StylesheetPI createStylesheetPI(String param1String1, String param1String2, String param1String3, String param1String4, String param1String5) throws RuntimeException {
      if (!this.this$0.pause)
        try {
          this.this$0.documentHandler.processingInstruction(param1String1, param1String2);
        } catch (SAXException sAXException) {
          throw new SAXDriver.ExceptionWrapper(this.this$0, sAXException);
        }  
      return null;
    }
    
    SAXDocument(SAXDriver this$0) {
      this.this$0 = this$0;
      this.this$0 = this$0;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\SAXDriver.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */