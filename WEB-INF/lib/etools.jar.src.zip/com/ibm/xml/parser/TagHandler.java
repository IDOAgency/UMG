package com.ibm.xml.parser;

public interface TagHandler {
  void handleStartTag(TXElement paramTXElement, boolean paramBoolean);
  
  void handleEndTag(TXElement paramTXElement, boolean paramBoolean);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TagHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */