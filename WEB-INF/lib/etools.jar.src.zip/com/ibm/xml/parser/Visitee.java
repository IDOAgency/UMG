package com.ibm.xml.parser;

public interface Visitee {
  void acceptPre(Visitor paramVisitor) throws Exception;
  
  void acceptPost(Visitor paramVisitor) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\Visitee.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */