package com.ibm.xml.parser;

import java.io.IOException;
import java.io.Reader;

public interface StreamProducer {
  Source getInputStream(String paramString1, String paramString2, String paramString3) throws IOException;
  
  void closeInputStream(Source paramSource);
  
  void loadCatalog(Reader paramReader) throws IOException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\StreamProducer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */