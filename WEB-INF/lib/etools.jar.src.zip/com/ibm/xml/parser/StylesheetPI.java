package com.ibm.xml.parser;

public class StylesheetPI extends TXPI {
  static final long serialVersionUID = -5551516051977603120L;
  
  public static final String S_XMLSTYLESHEET = "xml:stylesheet";
  
  public static final String S_XMLALTSTYLESHEET = "xml:alternate-stylesheet";
  
  public static final String S_STYLESHEET = "stylesheet";
  
  public static final String S_ALTSTYLESHEET = "alternate-stylesheet";
  
  public static final String S_TEXTCSS = "text/css";
  
  String type;
  
  String hrefURI;
  
  String title;
  
  public StylesheetPI(String paramString) { this("xml:stylesheet", " type=\"text/css\" href=\"" + paramString + "\"", "text/css", paramString, null); }
  
  public StylesheetPI(String paramString1, String paramString2, String paramString3) { this("xml:stylesheet", (paramString3 == null) ? (" type=\"" + paramString1 + "\" href=\"" + paramString2 + "\"") : (" type=\"" + paramString1 + "\" href=\"" + paramString2 + "\" title=\"" + paramString3 + "\""), paramString1, paramString2, paramString3); }
  
  public StylesheetPI(String paramString1, String paramString2, String paramString3, String paramString4) { this(paramString1, (paramString4 == null) ? (" type=\"" + paramString2 + "\" href=\"" + paramString3 + "\"") : (" type=\"" + paramString2 + "\" href=\"" + paramString3 + "\" title=\"" + paramString4 + "\""), paramString2, paramString3, paramString4); }
  
  public StylesheetPI(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) throws LibraryException {
    super(paramString1, paramString2);
    if (!paramString1.equals("xml:stylesheet") && !paramString1.equals("xml:alternate-stylesheet"))
      throw new LibraryException("Invalid stylesheet declaration detected."); 
    this.type = paramString3;
    this.hrefURI = paramString4;
    this.title = paramString5;
  }
  
  public Object clone() {
    checkFactory();
    StylesheetPI stylesheetPI = this.factory.createStylesheetPI(this.name, this.data, this.type, this.hrefURI, this.title);
    stylesheetPI.setFactory(getFactory());
    return stylesheetPI;
  }
  
  public String getType() { return this.type; }
  
  public String getHref() { return this.hrefURI; }
  
  public String getTitle() { return this.title; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\StylesheetPI.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */