package com.ibm.xml.parser;

import org.w3c.dom.CharacterData;
import org.w3c.dom.DOMException;

public abstract class TXCharacterData extends Child implements CharacterData {
  static final long serialVersionUID = 8142858563528507880L;
  
  String data;
  
  public String getNodeValue() { return getData(); }
  
  public String getData() { return this.data; }
  
  public void setNodeValue(String paramString) { setData(paramString); }
  
  public void setData(String paramString) {
    this.data = paramString;
    clearDigest();
  }
  
  public int getLength() { return this.data.length(); }
  
  public String substringData(int paramInt1, int paramInt2) throws DOMException {
    if (paramInt1 < 0 || paramInt1 >= this.data.length())
      throw new TXDOMException((short)1, "Out of bounds: " + paramInt1 + ", the length of data is " + this.data.length()); 
    if (paramInt2 < 0)
      throw new TXDOMException((short)1, "Invalid count: " + paramInt2); 
    int i = paramInt1 + paramInt2;
    if (i > this.data.length())
      i = this.data.length(); 
    return this.data.substring(paramInt1, i);
  }
  
  public void appendData(String paramString) {
    StringBuffer stringBuffer = new StringBuffer(this.data.length() + paramString.length());
    stringBuffer.append(this.data);
    stringBuffer.append(paramString);
    this.data = stringBuffer.toString();
    clearDigest();
  }
  
  public void insertData(int paramInt, String paramString) throws DOMException {
    if (paramInt < 0 || paramInt > this.data.length())
      throw new TXDOMException((short)1, "offset is out of bounds: " + paramInt); 
    StringBuffer stringBuffer = new StringBuffer(this.data.length() + paramString.length());
    stringBuffer.append(this.data);
    stringBuffer.insert(paramInt, paramString);
    this.data = stringBuffer.toString();
    clearDigest();
  }
  
  public void deleteData(int paramInt1, int paramInt2) throws DOMException {
    if (paramInt1 < 0 || paramInt1 >= this.data.length())
      throw new TXDOMException((short)1, "Out of bounds: " + paramInt1 + ", the length of data is " + this.data.length()); 
    if (paramInt2 < 0)
      throw new TXDOMException((short)1, "Invalid count: " + paramInt2); 
    int i = paramInt1 + paramInt2;
    if (i >= this.data.length()) {
      this.data = this.data.substring(0, paramInt1);
    } else {
      this.data = String.valueOf(this.data.substring(0, paramInt1)) + this.data.substring(paramInt1 + paramInt2);
    } 
    clearDigest();
  }
  
  public void replaceData(int paramInt1, int paramInt2, String paramString) throws DOMException {
    if (paramInt1 < 0 || paramInt1 >= this.data.length())
      throw new TXDOMException((short)1, "Out of bounds: " + paramInt1 + ", the length of data is " + this.data.length()); 
    if (paramInt2 < 0)
      throw new TXDOMException((short)1, "Invalid count: " + paramInt2); 
    int i = paramInt1 + paramInt2;
    if (i >= this.data.length()) {
      this.data = String.valueOf(this.data.substring(0, paramInt1)) + paramString;
    } else {
      this.data = String.valueOf(this.data.substring(0, paramInt1)) + paramString + this.data.substring(i);
    } 
    clearDigest();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TXCharacterData.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */