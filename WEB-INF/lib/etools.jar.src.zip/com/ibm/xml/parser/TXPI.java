package com.ibm.xml.parser;

import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;

public class TXPI extends Child implements ProcessingInstruction {
  static final long serialVersionUID = 5857404877602965574L;
  
  String name;
  
  String data;
  
  public TXPI(String paramString1, String paramString2) {
    this.name = paramString1;
    if (paramString2.length() > 0) {
      byte b;
      for (b = 0; b < paramString2.length(); b++) {
        char c = paramString2.charAt(b);
        if (c < '\000' || c >= '' || ((0x4 & XMLChar.flags[c]) == 0 && !false))
          break; 
      } 
      this.data = paramString2.substring(b);
      return;
    } 
    this.data = paramString2;
  }
  
  public Object clone() {
    checkFactory();
    TXPI tXPI = (TXPI)this.factory.createProcessingInstruction(this.name, this.data);
    tXPI.setFactory(getFactory());
    return tXPI;
  }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (paramNode == null)
      return false; 
    if (!(paramNode instanceof ProcessingInstruction))
      return false; 
    ProcessingInstruction processingInstruction = (ProcessingInstruction)paramNode;
    return !(!processingInstruction.getTarget().equals(getTarget()) || !processingInstruction.getData().equals(getData()));
  }
  
  public short getNodeType() { return 7; }
  
  public String getNodeName() { return getTarget(); }
  
  public String getName() { return this.name; }
  
  public String getTarget() { return this.name; }
  
  public void setTarget(String paramString) {
    this.name = paramString;
    clearDigest();
  }
  
  public String getData() { return this.data; }
  
  public String getNodeValue() { return getData(); }
  
  public void setData(String paramString) {
    this.data = paramString;
    clearDigest();
  }
  
  public void setNodeValue(String paramString) { setData(paramString); }
  
  public String getText() { return ""; }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitPIPre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitPIPost(this); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TXPI.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */