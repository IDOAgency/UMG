package com.ibm.xml.parser;

import org.w3c.dom.Node;

public class ElementDecl extends Child {
  static final long serialVersionUID = 1933367195772929307L;
  
  public static final int EMPTY = 1;
  
  public static final int ANY = 2;
  
  public static final int MODEL_GROUP = 4;
  
  String name;
  
  ContentModel contentModel;
  
  public ElementDecl(String paramString, ContentModel paramContentModel) {
    this.name = paramString;
    this.contentModel = paramContentModel;
  }
  
  public Object clone() {
    checkFactory();
    ElementDecl elementDecl = this.factory.createElementDecl(this.name, null);
    elementDecl.setFactory(getFactory());
    elementDecl.contentModel = (ContentModel)this.contentModel.clone();
    return elementDecl;
  }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (paramNode == null)
      return false; 
    if (!(paramNode instanceof ElementDecl))
      return false; 
    ElementDecl elementDecl = (ElementDecl)paramNode;
    return !elementDecl.getName().equals(getName()) ? false : elementDecl.contentModel.equals(this.contentModel);
  }
  
  public short getNodeType() { return 20; }
  
  public String getNodeName() { return "#element-declaration"; }
  
  public String getName() { return this.name; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public int getContentType() { return getXML4JContentModel().getType(); }
  
  public void setContentType(int paramInt) { getXML4JContentModel().setType(paramInt); }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitElementDeclPre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitElementDeclPost(this); }
  
  ContentModel getXML4JContentModel() { return this.contentModel; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\ElementDecl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */