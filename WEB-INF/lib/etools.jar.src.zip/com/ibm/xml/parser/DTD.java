package com.ibm.xml.parser;

import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;
import org.w3c.dom.DOMException;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.Notation;

public class DTD extends Parent implements DocumentType {
  static final long serialVersionUID = 8746509003209143695L;
  
  private static final boolean DEBUG_VALIDATION = false;
  
  public static final String CM_EOC = " *EOC* ";
  
  public static final String CM_ERROR = " *ERROR* ";
  
  public static final String CM_PCDATA = "#PCDATA";
  
  private String name;
  
  private String xmlEncoding;
  
  private TXNodeList internalChildren;
  
  private TXNodeList externalChildren = new TXNodeList();
  
  private ExternalID externalID;
  
  private Hashtable elementDecls = new Hashtable();
  
  private Hashtable attListDecls = new Hashtable();
  
  private Hashtable notationDecls = new Hashtable();
  
  private boolean parsingExternal = false;
  
  boolean isPrintInternalDTD = true;
  
  private Hashtable idHash;
  
  EntityPool entityPool;
  
  public DTD() { this.internalChildren = this.children; }
  
  public DTD(String paramString, ExternalID paramExternalID) {
    this.name = paramString;
    this.externalID = paramExternalID;
    this.internalChildren = this.children;
  }
  
  public Object clone() { return cloneNode(true); }
  
  public Node cloneNode(boolean paramBoolean) {
    checkFactory();
    DTD dTD = this.factory.createDTD(this.name, this.externalID);
    dTD.setFactory(getFactory());
    dTD.isPrintInternalDTD = this.isPrintInternalDTD;
    dTD.xmlEncoding = this.xmlEncoding;
    EntityPool entityPool1 = new EntityPool();
    entityPool1.add(this.factory.createEntityDecl("lt", "&#60;", false));
    entityPool1.add(this.factory.createEntityDecl("gt", "&#62;", false));
    entityPool1.add(this.factory.createEntityDecl("amp", "&#38;", false));
    entityPool1.add(this.factory.createEntityDecl("apos", "&#39;", false));
    entityPool1.add(this.factory.createEntityDecl("quot", "&#34;", false));
    dTD.setEntityPool(entityPool1);
    if (paramBoolean) {
      dTD.setParsingExternal(true);
      dTD.externalChildren.ensureCapacity(this.externalChildren.getLength());
      for (byte b1 = 0; b1 < this.externalChildren.getLength(); b1++)
        dTD.appendChild((Child)((Child)this.externalChildren.item(b1)).clone()); 
      dTD.setParsingExternal(false);
      dTD.internalChildren.ensureCapacity(this.internalChildren.getLength());
      for (byte b2 = 0; b2 < this.internalChildren.getLength(); b2++)
        dTD.appendChild((Child)((Child)this.internalChildren.item(b2)).clone()); 
    } 
    dTD.setParsingExternal(this.parsingExternal);
    return dTD;
  }
  
  public short getNodeType() { return 10; }
  
  public String getNodeName() { return this.name; }
  
  public String getName() { return this.name; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (paramNode == null)
      return false; 
    if (!(paramNode instanceof DTD))
      return false; 
    DTD dTD = (DTD)paramNode;
    if ((dTD.name != null || this.name != null) && (dTD.name == null || !dTD.name.equals(this.name)))
      return false; 
    if ((dTD.externalID != null || this.externalID != null) && (dTD.externalID == null || !dTD.externalID.equals(this.externalID)))
      return false; 
    if ((dTD.xmlEncoding != null || this.xmlEncoding != null) && (dTD.xmlEncoding == null || !dTD.xmlEncoding.equalsIgnoreCase(this.xmlEncoding)))
      return false; 
    if (paramBoolean) {
      if (!dTD.internalChildren.equals(this.internalChildren, paramBoolean))
        return false; 
      if (!dTD.externalChildren.equals(this.externalChildren, paramBoolean))
        return false; 
    } 
    return true;
  }
  
  public void setParsingExternal(boolean paramBoolean) {
    this.parsingExternal = paramBoolean;
    this.children = paramBoolean ? this.externalChildren : this.internalChildren;
  }
  
  public boolean isParsingExternal() { return this.parsingExternal; }
  
  public Enumeration internalElements() { return this.internalChildren.elements(); }
  
  public Enumeration externalElements() { return this.externalChildren.elements(); }
  
  public ExternalID getExternalID() { return this.externalID; }
  
  public void setExternalID(ExternalID paramExternalID) { this.externalID = paramExternalID; }
  
  public Enumeration getAttributeDeclarations(String paramString) {
    Hashtable hashtable = (Hashtable)this.attListDecls.get(paramString);
    if (hashtable == null)
      hashtable = new Hashtable(); 
    return hashtable.elements();
  }
  
  public AttDef getAttributeDeclaration(String paramString1, String paramString2) {
    Hashtable hashtable = (Hashtable)this.attListDecls.get(paramString1);
    return (hashtable == null) ? null : (AttDef)hashtable.get(paramString2);
  }
  
  public boolean isAttributeDeclared(String paramString1, String paramString2) { return !(getAttributeDeclaration(paramString1, paramString2) == null); }
  
  public Enumeration getElementDeclarations() { return this.elementDecls.elements(); }
  
  public ElementDecl getElementDeclaration(String paramString) { return (ElementDecl)this.elementDecls.get(paramString); }
  
  public boolean isElementDeclared(String paramString) { return this.elementDecls.containsKey(paramString); }
  
  public Vector makeContentElementList(String paramString) {
    ElementDecl elementDecl = (ElementDecl)this.elementDecls.get(paramString);
    return (elementDecl == null) ? null : elementDecl.getXML4JContentModel().getChildrenOrder();
  }
  
  public Enumeration getNotationEnumeration() { return this.notationDecls.elements(); }
  
  public Notation getNotation(String paramString) {
    TXNotation tXNotation = (TXNotation)this.notationDecls.get(paramString);
    return (tXNotation == null) ? null : tXNotation.getNotationImpl();
  }
  
  public NamedNodeMap getNotations() { return new HashNamedNodeMap(this.notationDecls); }
  
  public void setEncoding(String paramString) { this.xmlEncoding = paramString; }
  
  public void printExternal(Writer paramWriter, String paramString) throws IOException {
    if (this.xmlEncoding != null)
      paramWriter.write("<?xml encoding=\"" + this.xmlEncoding + "\"?>"); 
    for (byte b = 0; b < this.externalChildren.getLength(); b++)
      ((Child)this.externalChildren.item(b)).print(paramWriter, paramString); 
    paramWriter.flush();
  }
  
  public boolean checkContent(TXElement paramTXElement) {
    ElementDecl elementDecl = (ElementDecl)this.elementDecls.get(paramTXElement.getNodeName());
    return (elementDecl == null) ? false : elementDecl.getXML4JContentModel().check(paramTXElement);
  }
  
  public Node validate(TXElement paramTXElement) {
    ElementDecl elementDecl = (ElementDecl)this.elementDecls.get(paramTXElement.getNodeName());
    if (elementDecl == null)
      return paramTXElement; 
    Node node = validateAttributes(paramTXElement);
    if (node == null)
      node = elementDecl.getXML4JContentModel().validate(paramTXElement); 
    return node;
  }
  
  public ContentModel getContentModel(String paramString) {
    ElementDecl elementDecl = (ElementDecl)this.elementDecls.get(paramString);
    return (elementDecl == null) ? null : elementDecl.getXML4JContentModel();
  }
  
  public int getContentType(String paramString) {
    ElementDecl elementDecl = (ElementDecl)this.elementDecls.get(paramString);
    return (elementDecl == null) ? -1 : elementDecl.getXML4JContentModel().getType();
  }
  
  public Hashtable prepareTable(String paramString) {
    ElementDecl elementDecl = (ElementDecl)this.elementDecls.get(paramString);
    return (elementDecl == null) ? null : elementDecl.getXML4JContentModel().prepareTable();
  }
  
  public Hashtable getInsertableElements(Element paramElement, int paramInt, Hashtable paramHashtable) {
    ContentModel contentModel = getContentModel(paramElement.getNodeName());
    return (contentModel == null) ? null : contentModel.getInsertableElements(paramElement, paramInt, paramHashtable, false);
  }
  
  public Hashtable getAppendableElements(Element paramElement, Hashtable paramHashtable) { return getInsertableElements(paramElement, paramElement.getChildNodes().getLength(), paramHashtable); }
  
  public Hashtable getInsertableElementsForValidContent(Element paramElement, int paramInt, Hashtable paramHashtable) {
    ContentModel contentModel = getContentModel(paramElement.getNodeName());
    return (contentModel == null) ? null : contentModel.getInsertableElements(paramElement, paramInt, paramHashtable, true);
  }
  
  public boolean registID(Element paramElement, String paramString) {
    if (this.idHash == null)
      this.idHash = new Hashtable(); 
    if (this.idHash.containsKey(paramString))
      return false; 
    this.idHash.put(paramString, paramElement);
    return true;
  }
  
  public boolean unregistID(String paramString) {
    if (this.idHash == null)
      return false; 
    if (!this.idHash.containsKey(paramString))
      return false; 
    this.idHash.remove(paramString);
    return true;
  }
  
  public Element checkID(String paramString) { return (this.idHash == null) ? null : (Element)this.idHash.get(paramString); }
  
  public Enumeration IDs() { return (this.idHash == null) ? (new Hashtable()).keys() : this.idHash.keys(); }
  
  public Enumeration getEntityEnumeration() { return this.entityPool.elements(); }
  
  public Enumeration getParameterEntityEnumeration() { return this.entityPool.parameterEntityElements(); }
  
  public EntityDecl getEntityDecl(String paramString, boolean paramBoolean) {
    EntityDecl entityDecl;
    if (paramBoolean) {
      entityDecl = this.entityPool.referPara(paramString);
    } else {
      entityDecl = this.entityPool.refer(paramString);
    } 
    return entityDecl;
  }
  
  public NamedNodeMap getEntities() { return new HashNamedNodeMap(this.entityPool.getEntityHash()); }
  
  public int getInternalSize() { return this.internalChildren.getLength(); }
  
  public int getExternalSize() { return this.externalChildren.getLength(); }
  
  public void setPrintInternalDTD(boolean paramBoolean) { this.isPrintInternalDTD = paramBoolean; }
  
  public boolean isPrintInternalDTD() { return this.isPrintInternalDTD; }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitDTDPre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitDTDPost(this); }
  
  public void setEntityPool(EntityPool paramEntityPool) { this.entityPool = paramEntityPool; }
  
  protected void realInsert(Node paramNode, int paramInt) throws DOMException {
    if (paramNode == null)
      return; 
    super.realInsert(paramNode, paramInt);
    if (paramNode instanceof ElementDecl) {
      ElementDecl elementDecl = (ElementDecl)paramNode;
      this.elementDecls.put(elementDecl.getName(), elementDecl);
      return;
    } 
    if (paramNode instanceof Attlist) {
      Attlist attlist = (Attlist)paramNode;
      String str = attlist.getName();
      Hashtable hashtable = (Hashtable)this.attListDecls.get(str);
      if (hashtable == null) {
        hashtable = new Hashtable();
        this.attListDecls.put(str, hashtable);
      } 
      for (byte b = 0; b < attlist.size(); b++) {
        AttDef attDef = attlist.elementAt(b);
        if (hashtable.get(attDef.getName()) == null)
          hashtable.put(attDef.getName(), attDef); 
      } 
      return;
    } 
    if (paramNode instanceof TXNotation) {
      TXNotation tXNotation = (TXNotation)paramNode;
      this.notationDecls.put(tXNotation.getNodeName(), tXNotation);
      return;
    } 
    if (paramNode instanceof EntityDecl) {
      EntityDecl entityDecl = (EntityDecl)paramNode;
      this.entityPool.add(entityDecl);
    } 
  }
  
  protected void checkChildType(Node paramNode) throws DOMException {
    switch (paramNode.getNodeType()) {
      default:
        throw new TXDOMException((short)3, "Specified node type (" + paramNode.getNodeType() + ") can't be a child of DocumentType.");
      case 3:
      case 6:
      case 7:
      case 8:
      case 12:
      case 20:
      case 21:
      case 23:
        break;
    } 
  }
  
  Node validateAttributes(TXElement paramTXElement) {
    NamedNodeMap namedNodeMap = paramTXElement.getAttributes();
    String str = paramTXElement.getNodeName();
    Hashtable hashtable = (Hashtable)this.attListDecls.get(str);
    if (hashtable == null || hashtable.size() == 0) {
      if (namedNodeMap != null && namedNodeMap.getLength() > 0)
        return namedNodeMap.item(0); 
    } else if (namedNodeMap == null) {
      Enumeration enumeration = hashtable.keys();
      while (enumeration.hasMoreElements()) {
        String str1 = (String)enumeration.nextElement();
        AttDef attDef = (AttDef)hashtable.get(str1);
        if (attDef.getDefaultType() == 2)
          return paramTXElement; 
      } 
    } else {
      Vector vector = new Vector();
      Enumeration enumeration = hashtable.keys();
      while (enumeration.hasMoreElements()) {
        String str1 = (String)enumeration.nextElement();
        vector.addElement(hashtable.get(str1));
      } 
      int i = vector.size();
      for (AttDef attDef = (AttDef)vector.firstElement(); attDef != null; attDef = (vector.size() > 0) ? (AttDef)vector.firstElement() : null) {
        String str1 = attDef.getName();
        Node node = namedNodeMap.getNamedItem(str1);
        int k = attDef.getDefaultType();
        switch (k) {
          case 1:
            if (node != null && !node.getNodeValue().equals(attDef.getDefaultStringValue()))
              return node; 
            break;
          case 2:
            if (node == null)
              return paramTXElement; 
            break;
        } 
        if (node != null) {
          byte b;
          int n;
          Enumeration enumeration1;
          StringTokenizer stringTokenizer;
          int m = attDef.getDeclaredType();
          String str2 = node.getNodeValue();
          switch (m) {
            case 1:
              n = str2.length();
              for (b = 0; b < n; b++) {
                char c = str2.charAt(b);
                char c1 = c;
                if ((true & XMLChar.flags[c1]) == 0) {
                
                } else {
                  continue;
                } 
                if (!((c1 >= 1114112 || c1 < '\000') ? 0 : ((c1 >= 65536) ? 1 : 0)))
                  return node; 
                continue;
              } 
              break;
            case 5:
              if (this.entityPool == null || this.entityPool.refer(str2.trim()) == null)
                return node; 
              break;
            case 6:
              if (this.entityPool == null)
                return node; 
              stringTokenizer = new StringTokenizer(str2);
              while (stringTokenizer.hasMoreTokens()) {
                String str3 = stringTokenizer.nextToken();
                if (this.entityPool.refer(str3) == null)
                  return node; 
              } 
              break;
            case 2:
              if (!Util.checkName(str2.trim()))
                return node; 
              break;
            case 3:
              if (this.idHash == null || this.idHash.get(str2.trim()) == null)
                return node; 
              break;
            case 4:
              if (this.idHash == null)
                return node; 
              stringTokenizer = new StringTokenizer(str2);
              while (stringTokenizer.hasMoreTokens()) {
                String str3 = stringTokenizer.nextToken();
                if (this.idHash.get(str3) == null)
                  return node; 
              } 
              break;
            case 7:
              if (!Util.checkNmtoken(str2.trim()))
                return node; 
              break;
            case 8:
              stringTokenizer = new StringTokenizer(str2);
              while (stringTokenizer.hasMoreTokens()) {
                String str3 = stringTokenizer.nextToken();
                if (!Util.checkNmtoken(str3))
                  return node; 
              } 
              break;
            case 9:
              if (getNotation(str2.trim()) == null)
                return node; 
              break;
            case 10:
              enumeration1 = attDef.elements();
              if (enumeration1 == null)
                return node; 
              b = 0;
              str2 = str2.trim();
              while (enumeration1.hasMoreElements()) {
                String str3 = (String)enumeration1.nextElement();
                if (str2.equals(str3)) {
                  b = 1;
                  break;
                } 
              } 
              if (b == 0)
                return node; 
              break;
          } 
        } 
        vector.removeElementAt(0);
      } 
      int j = namedNodeMap.getLength();
      if (j > i)
        for (byte b = 0; b < j; b++) {
          Node node = namedNodeMap.item(b);
          String str1 = node.getNodeName();
          if (getAttributeDeclaration(str, str1) == null)
            return node; 
        }  
    } 
    return null;
  }
  
  static class HashNamedNodeMap implements NamedNodeMap {
    Hashtable hash;
    
    Node[] data;
    
    HashNamedNodeMap(Hashtable param1Hashtable) {
      this.hash = param1Hashtable;
      makeArray();
    }
    
    public Node getNamedItem(String param1String) {
      Object object = this.hash.get(param1String);
      if (object == null)
        return null; 
      if (object instanceof TXNotation)
        return ((TXNotation)object).getNotationImpl(); 
      if (object instanceof EntityDecl)
        return ((EntityDecl)object).getEntityImpl(); 
      throw new RuntimeException("XML4J internal error: non-supported hash.");
    }
    
    public Node setNamedItem(Node param1Node) { throw new TXDOMException((short)7, "This NamedNodeMap is read-only."); }
    
    public Node removeNamedItem(String param1String) { throw new TXDOMException((short)7, "This NamedNodeMap is read-only."); }
    
    public Node item(int param1Int) { return this.data[param1Int]; }
    
    public int getLength() { return this.data.length; }
    
    private void makeArray() {
      this.data = new Node[this.hash.size()];
      Enumeration enumeration = this.hash.elements();
      byte b = 0;
      while (enumeration.hasMoreElements())
        this.data[b++] = (Node)enumeration.nextElement(); 
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\DTD.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */