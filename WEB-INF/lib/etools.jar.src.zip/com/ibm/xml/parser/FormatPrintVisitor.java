package com.ibm.xml.parser;

import java.io.Writer;
import java.util.Stack;
import org.w3c.dom.Node;

public class FormatPrintVisitor extends ToXMLStringVisitor implements Visitor {
  protected int currentIndent;
  
  protected int indent = 2;
  
  protected boolean ispreserve = false;
  
  protected Stack preserves = new Stack();
  
  protected boolean isprevtext = false;
  
  public FormatPrintVisitor(Writer paramWriter, String paramString, int paramInt) {
    super(paramWriter, paramString);
    this.indent = paramInt;
  }
  
  public FormatPrintVisitor(Writer paramWriter, String paramString) { this(paramWriter, paramString, 2); }
  
  public FormatPrintVisitor(Writer paramWriter) { this(paramWriter, null, 2); }
  
  public void visitDocumentPost(TXDocument paramTXDocument) throws Exception {
    this.writer.write(10);
    super.visitDocumentPost(paramTXDocument);
  }
  
  public void visitElementPre(TXElement paramTXElement) throws Exception {
    if (!this.ispreserve && !this.isprevtext) {
      Writer writer = this.writer;
      int i = this.currentIndent;
      writer.write("\n");
      Util.printSpace(writer, i);
    } 
    super.visitElementPre(paramTXElement);
    this.currentIndent += this.indent;
    if (paramTXElement.hasChildNodes()) {
      Child child = (Child)paramTXElement.getFirstChild();
      this.preserves.push(new Boolean(this.ispreserve));
      if (paramTXElement.children.getLength() == 1 && child.getNodeType() == 3) {
        this.ispreserve = true;
      } else {
        this.ispreserve = paramTXElement.isPreserveSpace();
      } 
    } 
    this.isprevtext = false;
  }
  
  public void visitElementPost(TXElement paramTXElement) throws Exception {
    this.currentIndent -= this.indent;
    if (paramTXElement.hasChildNodes()) {
      if (!this.ispreserve && !this.isprevtext) {
        Writer writer = this.writer;
        int i = this.currentIndent;
        writer.write("\n");
        Util.printSpace(writer, i);
      } 
      this.writer.write("</");
      this.writer.write(paramTXElement.getTagName());
      this.writer.write(">");
      this.ispreserve = ((Boolean)this.preserves.pop()).booleanValue();
    } 
    this.isprevtext = false;
  }
  
  public void visitPIPre(TXPI paramTXPI) throws Exception {
    if (!this.ispreserve && !this.isprevtext) {
      Writer writer = this.writer;
      int i = this.currentIndent;
      writer.write("\n");
      Util.printSpace(writer, i);
    } 
    super.visitPIPre(paramTXPI);
  }
  
  public void visitCommentPre(TXComment paramTXComment) throws Exception {
    if (!this.ispreserve && !this.isprevtext) {
      Writer writer = this.writer;
      int i = this.currentIndent;
      writer.write("\n");
      Util.printSpace(writer, i);
    } 
    super.visitCommentPre(paramTXComment);
  }
  
  public void visitTextPre(TXText paramTXText) throws Exception {
    if (!this.ispreserve && paramTXText.getIsIgnorableWhitespace()) {
      this.isprevtext = false;
      return;
    } 
    if (paramTXText instanceof org.w3c.dom.CDATASection) {
      if (!this.ispreserve && !this.isprevtext) {
        Writer writer = this.writer;
        int i = this.currentIndent;
        writer.write("\n");
        Util.printSpace(writer, i);
      } 
      this.writer.write("<![CDATA[");
      this.writer.write(paramTXText.getData());
      this.writer.write("]]>");
      return;
    } 
    this.writer.write(Util.backReference(paramTXText.getData(), this.encoding));
    this.isprevtext = true;
  }
  
  public void visitDTDPre(DTD paramDTD) throws Exception {
    Writer writer = this.writer;
    int i = this.currentIndent;
    writer.write("\n");
    Util.printSpace(writer, i);
    this.writer.write("<!DOCTYPE ");
    this.writer.write(paramDTD.getName());
    this.writer.write(" ");
    if (paramDTD.getExternalID() != null) {
      this.writer.write(paramDTD.getExternalID().toString());
      this.writer.write(" ");
    } 
    this.currentIndent += this.indent;
    if (paramDTD.isPrintInternalDTD() && paramDTD.getInternalSize() > 0) {
      this.writer.write("[\n");
      for (Node node = paramDTD.getFirstChild(); node != null; node = node.getNextSibling()) {
        if (node.getNodeType() != 3)
          try {
            ((Child)node).acceptPre(this);
          } catch (ToNextSiblingTraversalException toNextSiblingTraversalException) {} 
      } 
    } 
    throw new ToNextSiblingTraversalException();
  }
  
  public void visitDTDPost(DTD paramDTD) throws Exception {
    this.currentIndent -= this.indent;
    if (paramDTD.isPrintInternalDTD() && paramDTD.getInternalSize() > 0) {
      Util.printSpace(this.writer, this.currentIndent);
      this.writer.write("]");
    } 
    this.writer.write(">");
  }
  
  public void visitElementDeclPre(ElementDecl paramElementDecl) throws Exception {
    Util.printSpace(this.writer, this.currentIndent);
    super.visitElementDeclPre(paramElementDecl);
    this.writer.write(10);
  }
  
  public void visitAttlistPre(Attlist paramAttlist) throws Exception {
    Util.printSpace(this.writer, this.currentIndent);
    super.visitAttlistPre(paramAttlist);
    this.writer.write(10);
  }
  
  public void visitEntityDeclPre(EntityDecl paramEntityDecl) throws Exception {
    Util.printSpace(this.writer, this.currentIndent);
    try {
      super.visitEntityDeclPre(paramEntityDecl);
    } catch (ToNextSiblingTraversalException toNextSiblingTraversalException) {}
    this.writer.write(10);
    throw new ToNextSiblingTraversalException();
  }
  
  public void visitNotationPre(TXNotation paramTXNotation) throws Exception {
    Util.printSpace(this.writer, this.currentIndent);
    super.visitNotationPre(paramTXNotation);
    this.writer.write(10);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\FormatPrintVisitor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */