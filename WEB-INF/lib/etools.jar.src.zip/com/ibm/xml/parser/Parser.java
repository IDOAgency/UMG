package com.ibm.xml.parser;

import com.ibm.xml.framework.AttrPool;
import com.ibm.xml.framework.EntityPool;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLDocumentHandler;
import com.ibm.xml.framework.XMLDocumentTypeHandler;
import com.ibm.xml.internal.DefaultScanner;
import com.ibm.xml.internal.ErrorCode;
import com.ibm.xml.parsers.TXDOMParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import org.w3c.dom.Node;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class Parser extends TXDOMParser {
  private static final String ALL_TAG_NAMES = " ALL ";
  
  private static final boolean DEBUG = false;
  
  StreamProducer streamProducer;
  
  ErrorListener errorListener;
  
  int errorCount;
  
  int validityFailureCount;
  
  int warnCount;
  
  boolean isKeepComment;
  
  boolean isEndBy1stError;
  
  boolean isProcessNamespace;
  
  boolean isProcessExternalDTD;
  
  boolean isWarningRedefinedEntity;
  
  boolean isWarningNoXMLDecl;
  
  boolean isWarningNoDoctypeDecl;
  
  ReferenceHandler referenceHandler;
  
  TagHandler tagHandler;
  
  Vector preRootHandlers;
  
  Vector piHandlers;
  
  Hashtable elementHandlerHash;
  
  SAXDriver saxdriver;
  
  public Parser(String paramString) { this(paramString, null, null); }
  
  public Parser(String paramString, ErrorListener paramErrorListener, StreamProducer paramStreamProducer) {
    Stderr stderr = (paramErrorListener == null || paramStreamProducer == null) ? new Stderr(paramString) : null;
    this.errorListener = (paramErrorListener != null) ? paramErrorListener : stderr;
    this.streamProducer = (paramStreamProducer != null) ? paramStreamProducer : stderr;
    initParser();
  }
  
  private void initParser() {
    setAllowJavaEncodingName(false);
    setEndBy1stError(true);
    setExpandEntityReferences(false);
    setKeepComment(true);
    setProcessExternalDTD(true);
    setProcessNamespace(false);
    setWarningNoDoctypeDecl(false);
    setWarningNoXMLDecl(true);
    setWarningRedefinedEntity(true);
    Handler handler = new Handler(this);
    setDocumentHandler(handler);
    setDocumentTypeHandler(handler);
    setErrorHandler(handler);
    getEntityHandler().setEntityResolver(handler);
  }
  
  public void setElementFactory(TXDocument paramTXDocument) { this.fDocument = paramTXDocument; }
  
  public Source getInputStream(String paramString1, String paramString2, String paramString3) throws IOException { return this.streamProducer.getInputStream(paramString1, paramString2, paramString3); }
  
  public void closeInputStream(Source paramSource) { this.streamProducer.closeInputStream(paramSource); }
  
  public void loadCatalog(Reader paramReader) throws IOException { this.streamProducer.loadCatalog(paramReader); }
  
  public void setTagHandler(TagHandler paramTagHandler) { this.tagHandler = paramTagHandler; }
  
  public void setReferenceHandler(ReferenceHandler paramReferenceHandler) { this.referenceHandler = paramReferenceHandler; }
  
  public void addPreRootHandler(PreRootHandler paramPreRootHandler) {
    if (this.preRootHandlers == null)
      this.preRootHandlers = new Vector(); 
    this.preRootHandlers.addElement(paramPreRootHandler);
  }
  
  public void addPIHandler(PIHandler paramPIHandler) {
    if (this.piHandlers == null)
      this.piHandlers = new Vector(); 
    this.piHandlers.addElement(paramPIHandler);
  }
  
  public void addElementHandler(ElementHandler paramElementHandler) { addElementHandler(paramElementHandler, " ALL "); }
  
  public void addElementHandler(ElementHandler paramElementHandler, String paramString) {
    if (this.elementHandlerHash == null)
      this.elementHandlerHash = new Hashtable(); 
    Vector vector = (Vector)this.elementHandlerHash.get(paramString);
    if (vector == null) {
      vector = new Vector();
      this.elementHandlerHash.put(paramString, vector);
    } 
    vector.addElement(paramElementHandler);
  }
  
  void setSAXDriver(SAXDriver paramSAXDriver) {
    this.saxdriver = paramSAXDriver;
    if (paramSAXDriver != null)
      setNormalizeTextNodes(false); 
  }
  
  public int getNumberOfErrors() { return this.errorCount + this.validityFailureCount; }
  
  public int getNumberOfWarnings() { return this.warnCount; }
  
  public void setKeepComment(boolean paramBoolean) { this.isKeepComment = paramBoolean; }
  
  public void setExpandEntityReferences(boolean paramBoolean) { super.setExpandEntityReferences(paramBoolean); }
  
  public void setProcessExternalDTD(boolean paramBoolean) { this.isProcessExternalDTD = paramBoolean; }
  
  public void setProcessNamespace(boolean paramBoolean) {
    this.isProcessNamespace = paramBoolean;
    setValidationHandler(null);
  }
  
  public void setAllowJavaEncodingName(boolean paramBoolean) { super.setAllowJavaEncodingName(paramBoolean); }
  
  public void setPreserveSpace(boolean paramBoolean) { throw new IllegalArgumentException("setPreserveSpace not supported"); }
  
  public void setEndBy1stError(boolean paramBoolean) {
    this.isEndBy1stError = paramBoolean;
    setContinueAfterFatalError(!paramBoolean);
  }
  
  public TXDocument readStream(InputStream paramInputStream) { return readStream(new Source(paramInputStream)); }
  
  public TXDocument readStream(Reader paramReader) { return readStream(new Source(paramReader)); }
  
  public TXDocument readStream(Source paramSource) {
    try {
      InputSource inputSource = new InputSource();
      inputSource.setByteStream(paramSource.getInputStream());
      inputSource.setCharacterStream(paramSource.getReader());
      inputSource.setEncoding(paramSource.getEncoding());
      if (this.streamProducer instanceof Stderr) {
        Stderr stderr = (Stderr)this.streamProducer;
        inputSource.setPublicId(stderr.getPublicId());
        inputSource.setSystemId(stderr.getSystemId());
      } 
      parse(inputSource);
      return (TXDocument)getDocument();
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public DTD readDTDStream(InputStream paramInputStream) throws IOException { return readDTDStream(new Source(paramInputStream)); }
  
  public DTD readDTDStream(Reader paramReader) throws IOException { return readDTDStream(new Source(paramReader)); }
  
  public DTD readDTDStream(Source paramSource) throws IOException {
    try {
      InputSource inputSource = new InputSource();
      inputSource.setByteStream(paramSource.getInputStream());
      inputSource.setCharacterStream(paramSource.getReader());
      inputSource.setEncoding(paramSource.getEncoding());
      parseDTD(inputSource);
      return ((TXDocument)getDocument()).getDTD();
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public final void parseDTD(InputSource paramInputSource) throws SAXException, IOException {
    if (this.fParseInProgress)
      throw new SAXException("parse may not be called while parsing"); 
    if (this.fNeedReset)
      resetOrCopy(); 
    try {
      checkHandlers();
      this.fParseInProgress = true;
      this.fNeedReset = true;
      ((DefaultScanner)this.fScanner).scanDTD(paramInputSource);
      this.fParseInProgress = false;
      return;
    } catch (SAXException sAXException) {
      this.fParseInProgress = false;
      throw sAXException;
    } catch (IOException iOException) {
      this.fParseInProgress = false;
      throw iOException;
    } catch (Exception exception) {
      this.fParseInProgress = false;
      throw new SAXException(exception);
    } 
  }
  
  public void addNoRequiredAttributeHandler(NoRequiredAttributeHandler paramNoRequiredAttributeHandler) { throw new IllegalArgumentException("addNoRequiredAttributeHandler is not supported"); }
  
  public void setErrorNoByteMark(boolean paramBoolean) { throw new IllegalArgumentException("setErrorNoByteMark not supported"); }
  
  public int getReaderBufferSize() { throw new IllegalArgumentException("setReaderBufferSize is not supported"); }
  
  public void setReaderBufferSize(int paramInt) { throw new IllegalArgumentException("setReaderBufferSize is not supported"); }
  
  public void setWarningRedefinedEntity(boolean paramBoolean) { this.isWarningRedefinedEntity = paramBoolean; }
  
  public void setWarningNoXMLDecl(boolean paramBoolean) { this.isWarningNoXMLDecl = paramBoolean; }
  
  public void setWarningNoDoctypeDecl(boolean paramBoolean) { this.isWarningNoDoctypeDecl = paramBoolean; }
  
  public void stop() { getParserState().getScanner().stop(); }
  
  protected void handleError(String paramString1, String paramString2) throws Exception {
    Locator locator = getLocator();
    this.errorListener.error(locator.getSystemId(), locator.getLineNumber(), locator.getColumnNumber(), paramString1, paramString2);
    super.handleError(paramString1, paramString2);
  }
  
  public void reset() {
    super.reset();
    this.warnCount = 0;
    this.validityFailureCount = 0;
    this.errorCount = 0;
    this.errorListener = null;
    this.streamProducer = null;
    this.tagHandler = null;
    this.preRootHandlers = null;
    this.piHandlers = null;
    this.elementHandlerHash = null;
    this.referenceHandler = null;
  }
  
  Node getCurrentNode() { return this.fCurrentNode; }
  
  void setRealParent(Node paramNode) {
    Node node = (Node)this.fNodeStack.peek();
    node.removeChild(node.getLastChild());
    node.appendChild(paramNode);
  }
  
  TXElement getCurrentParent() { return (TXElement)this.fCurrentParent; }
  
  private final void errorString1(int paramInt, String paramString) throws Exception {
    String str1 = ErrorCode.getErrorKey(paramInt);
    if (!errorHandlingEnabled() && !isFatal(str1))
      return; 
    String[] arrayOfString = new String[1];
    arrayOfString[0] = paramString;
    String str2 = getErrorMsgString(str1, arrayOfString);
    handleError(str1, str2);
  }
  
  private final void errorString4(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4) throws Exception {
    String str1 = ErrorCode.getErrorKey(paramInt);
    if (!errorHandlingEnabled() && (getContinueAfterFatalError() || !isFatal(str1)))
      return; 
    String[] arrayOfString = new String[4];
    arrayOfString[0] = paramString1;
    arrayOfString[1] = paramString2;
    arrayOfString[2] = paramString3;
    arrayOfString[3] = paramString4;
    String str2 = getErrorMsgString(str1, arrayOfString);
    handleError(str1, str2);
  }
  
  void TXNamespaceCode(TXElement paramTXElement, int paramInt1, int paramInt2) {
    TXAttribute[] arrayOfTXAttribute = paramTXElement.getAttributeArray();
    if (this.isProcessNamespace)
      try {
        String[] arrayOfString = new String[arrayOfTXAttribute.length];
        AttrPool attrPool = getParserState().getAttrPool();
        attrPool.getAttributeList(paramInt2);
        for (byte b = 0; b < arrayOfTXAttribute.length; b++) {
          String str1 = arrayOfTXAttribute[b].getNodeName();
          int j = checkNamespace(paramTXElement, str1);
          if (j != -1)
            errorString1(j, str1); 
          if (arrayOfTXAttribute[b].getValue().length() == 0 && str1.startsWith("xmlns:"))
            errorString1(142, str1); 
          arrayOfString[b] = arrayOfTXAttribute[b].getNSLocalName();
          String str2 = arrayOfTXAttribute[b].getNSName();
          if (str2 != null)
            for (byte b1 = 0; b1 < b; b1++) {
              if (arrayOfString[b1].equals(arrayOfString[b])) {
                String str = arrayOfTXAttribute[b1].getNSName();
                if (str != null && str.equals(str2))
                  errorString4(144, arrayOfTXAttribute[b].getNodeName(), str2, arrayOfString[b], arrayOfTXAttribute[b1].getNodeName()); 
              } 
            }  
        } 
        int i = checkNamespace(paramTXElement, paramTXElement.getName());
        if (i != -1) {
          error1(i, paramInt1);
          return;
        } 
      } catch (Exception exception) {
        return;
      }  
  }
  
  int checkNamespace(TXElement paramTXElement, String paramString) {
    int i = paramString.indexOf(':');
    return (i < 0) ? -1 : ((paramTXElement.getNamespaceForPrefix(paramString.substring(false, i)) == null) ? 136 : ((paramString.indexOf(':', i + 1) >= 0) ? 135 : -1));
  }
  
  class Handler implements XMLDocumentTypeHandler, XMLDocumentHandler, ErrorHandler, EntityResolver {
    private final Parser this$0;
    
    public void doctypeDecl(int param1Int) {
      Vector vector = this.this$0.preRootHandlers;
      if (vector != null) {
        Enumeration enumeration = vector.elements();
        if (enumeration.hasMoreElements()) {
          TXDocument tXDocument = (TXDocument)this.this$0.getDocument();
          String str = this.this$0.getParserState().getStringPool().toString(param1Int);
          do {
            PreRootHandler preRootHandler = (PreRootHandler)enumeration.nextElement();
            preRootHandler.handlePreRoot(tXDocument, str);
          } while (enumeration.hasMoreElements());
        } 
      } 
      this.this$0.doctypeDecl(param1Int);
    }
    
    public void startInternalSubset() { this.this$0.startInternalSubset(); }
    
    public void endInternalSubset() { this.this$0.endInternalSubset(); }
    
    public void startExternalSubset(int param1Int1, int param1Int2) throws Exception { this.this$0.startExternalSubset(param1Int1, param1Int2); }
    
    public void endExternalSubset() { this.this$0.endExternalSubset(); }
    
    public void elementDecl(int param1Int) { this.this$0.elementDecl(param1Int); }
    
    public void unparsedEntityDecl(int param1Int) { this.this$0.unparsedEntityDecl(param1Int); }
    
    public void attlistDecl(int param1Int1, int param1Int2) throws Exception { this.this$0.attlistDecl(param1Int1, param1Int2); }
    
    public void internalEntityDecl(int param1Int) { this.this$0.internalEntityDecl(param1Int); }
    
    public void externalEntityDecl(int param1Int) { this.this$0.externalEntityDecl(param1Int); }
    
    public void notationDecl(int param1Int) { this.this$0.notationDecl(param1Int); }
    
    public boolean sendCharDataAsCharArray() { return this.this$0.sendCharDataAsCharArray(); }
    
    public void endDocument() { this.this$0.endDocument(); }
    
    public void characters(int param1Int, boolean param1Boolean) throws Exception { this.this$0.characters(param1Int, param1Boolean); }
    
    public void ignorableWhitespace(int param1Int, boolean param1Boolean) throws Exception { this.this$0.ignorableWhitespace(param1Int, param1Boolean); }
    
    public void comment(int param1Int) {
      if (this.this$0.isKeepComment) {
        this.this$0.comment(param1Int);
        return;
      } 
      this.this$0.getParserState().getStringPool().releaseString(param1Int);
    }
    
    public void characters(char[] param1ArrayOfChar, int param1Int1, int param1Int2, boolean param1Boolean) throws Exception { this.this$0.characters(param1ArrayOfChar, param1Int1, param1Int2, param1Boolean); }
    
    public void ignorableWhitespace(char[] param1ArrayOfChar, int param1Int1, int param1Int2, boolean param1Boolean) throws Exception { this.this$0.ignorableWhitespace(param1ArrayOfChar, param1Int1, param1Int2, param1Boolean); }
    
    public void startDocument(int param1Int1, int param1Int2, int param1Int3) throws Exception { this.this$0.startDocument(param1Int1, param1Int2, param1Int3); }
    
    public void startEntityReference(int param1Int) {
      this.this$0.startEntityReference(param1Int);
      ReferenceHandler referenceHandler = this.this$0.referenceHandler;
      if (referenceHandler != null) {
        ParserState parserState = this.this$0.getParserState();
        EntityPool entityPool = parserState.getEntityPool();
        StringPool stringPool = parserState.getStringPool();
        String str = stringPool.toString(entityPool.getEntityName(param1Int));
        referenceHandler.startReference(str);
      } 
    }
    
    public void endEntityReference(int param1Int) {
      this.this$0.endEntityReference(param1Int);
      ReferenceHandler referenceHandler = this.this$0.referenceHandler;
      if (referenceHandler != null) {
        ParserState parserState = this.this$0.getParserState();
        EntityPool entityPool = parserState.getEntityPool();
        StringPool stringPool = parserState.getStringPool();
        String str = stringPool.toString(entityPool.getEntityName(param1Int));
        referenceHandler.endReference(str);
      } 
    }
    
    public void processingInstruction(int param1Int1, int param1Int2) throws Exception {
      if (this.this$0.piHandlers != null) {
        Enumeration enumeration = this.this$0.piHandlers.elements();
        if (enumeration.hasMoreElements()) {
          StringPool stringPool = this.this$0.getParserState().getStringPool();
          String str1 = stringPool.toString(param1Int1);
          String str2 = stringPool.toString(param1Int2);
          do {
            PIHandler pIHandler = (PIHandler)enumeration.nextElement();
            pIHandler.handlePI(str1, str2);
          } while (enumeration.hasMoreElements());
        } 
      } 
      this.this$0.processingInstruction(param1Int1, param1Int2);
    }
    
    public void startElement(int param1Int1, int param1Int2) throws Exception {
      this.this$0.startElement(param1Int1, param1Int2);
      TagHandler tagHandler = this.this$0.tagHandler;
      if (tagHandler != null) {
        TXElement tXElement = this.this$0.getCurrentParent();
        tagHandler.handleStartTag(tXElement, tXElement.hasChildNodes());
      } 
      this.this$0.TXNamespaceCode(this.this$0.getCurrentParent(), param1Int1, param1Int2);
    }
    
    public void endElement(int param1Int) {
      TagHandler tagHandler = this.this$0.tagHandler;
      if (tagHandler != null) {
        TXElement tXElement = this.this$0.getCurrentParent();
        tagHandler.handleEndTag(tXElement, tXElement.hasChildNodes());
      } 
      StringPool stringPool = this.this$0.getParserState().getStringPool();
      String str = stringPool.toString(param1Int);
      String[] arrayOfString = { str, " ALL " };
      Hashtable hashtable = this.this$0.elementHandlerHash;
      if (hashtable != null)
        for (byte b = 0; b < arrayOfString.length; b++) {
          Vector vector = (Vector)hashtable.get(arrayOfString[b]);
          if (vector != null) {
            TXElement tXElement = this.this$0.getCurrentParent();
            Enumeration enumeration = vector.elements();
            while (enumeration.hasMoreElements()) {
              ElementHandler elementHandler = (ElementHandler)enumeration.nextElement();
              this.this$0.setRealParent(elementHandler.handleElement(tXElement));
            } 
          } 
        }  
      this.this$0.endElement(param1Int);
    }
    
    public void warning(SAXParseException param1SAXParseException) throws SAXException { this.this$0.warnCount++; }
    
    public void error(SAXParseException param1SAXParseException) throws SAXException {
      this.this$0.validityFailureCount++;
      if (this.this$0.isEndBy1stError)
        throw param1SAXParseException; 
    }
    
    public void fatalError(SAXParseException param1SAXParseException) throws SAXException { this.this$0.errorCount++; }
    
    public InputSource resolveEntity(String param1String1, String param1String2) throws SAXException, IOException {
      Source source = this.this$0.streamProducer.getInputStream("", param1String1, param1String2);
      InputSource inputSource = new InputSource();
      inputSource.setByteStream(source.getInputStream());
      inputSource.setCharacterStream(source.getReader());
      inputSource.setEncoding(source.getEncoding());
      inputSource.setPublicId(param1String1);
      inputSource.setSystemId(param1String2);
      return inputSource;
    }
    
    Handler(Parser this$0) {
      this.this$0 = this$0;
      this.this$0 = this$0;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\Parser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */