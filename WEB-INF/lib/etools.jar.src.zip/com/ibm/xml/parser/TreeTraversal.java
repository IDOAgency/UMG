package com.ibm.xml.parser;

import org.w3c.dom.Node;

public abstract class TreeTraversal {
  private Visitor visitor;
  
  public TreeTraversal(Visitor paramVisitor) { this.visitor = paramVisitor; }
  
  public Visitor getVisitor() { return this.visitor; }
  
  public abstract void traverse(Node paramNode) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TreeTraversal.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */