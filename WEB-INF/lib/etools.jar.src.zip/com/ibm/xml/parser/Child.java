package com.ibm.xml.parser;

import com.ibm.xml.xpointer.XPointer;
import java.io.IOException;
import java.io.Serializable;
import java.io.Writer;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public abstract class Child implements Node, Cloneable, Serializable, Visitee {
  static final long serialVersionUID = 6737260867707773565L;
  
  public static final int ELEMENT_DECL = 20;
  
  public static final int ATTLIST = 21;
  
  public static final int ATTDEF = 22;
  
  public static final int PSEUDONODE = 23;
  
  public static final String NAME_DOCUMENT = "#document";
  
  public static final String NAME_COMMENT = "#comment";
  
  public static final String NAME_TEXT = "#text";
  
  public static final String NAME_CDATA = "#cdata-section";
  
  public static final String NAME_DOCFRAGMENT = "#document-fragment";
  
  public static final String NAME_ATTDEF = "#attribute-definition";
  
  public static final String NAME_ATTLIST = "#attribute-definition-list";
  
  public static final String NAME_ELEMENT_DECL = "#element-declaration";
  
  public static final String NAME_PSEUDONODE = "#pseudo-node";
  
  Node parent;
  
  Node prevSibling;
  
  Node nextSibling;
  
  byte[] digest;
  
  TXDocument factory;
  
  private Object userData;
  
  public abstract Object clone();
  
  public Node cloneNode(boolean paramBoolean) { return (Node)clone(); }
  
  public abstract boolean equals(Node paramNode, boolean paramBoolean);
  
  public String getNodeValue() { return null; }
  
  public void setNodeValue(String paramString) { throw new TXDOMException((short)7, "setNodeValue(String) isn't supported in this class."); }
  
  public Node getParentNode() { return this.parent; }
  
  public Node getParentWithoutReference() {
    for (Node node = getParentNode(); node != null && node.getNodeType() == 5; node = node.getParentNode());
    return node;
  }
  
  public NodeList getChildNodes() { return TXNodeList.emptyNodeList; }
  
  public boolean hasChildNodes() { return false; }
  
  public Node getFirstChild() { return null; }
  
  public Node getFirstWithoutReference() { return null; }
  
  public Node getLastChild() { return null; }
  
  public Node getLastWithoutReference() { return null; }
  
  public Node getPreviousSibling() { return this.prevSibling; }
  
  public Node getPreviousWithoutReference() {
    Node node = getPreviousSibling();
    if (node == null) {
      Node node1 = getParentNode();
      if (node1 == null)
        return null; 
      if (node1.getNodeType() == 5)
        node = ((Child)node1).getPreviousWithoutReference(); 
    } else {
      while (node.getNodeType() == 5) {
        Node node1 = node.getLastChild();
        if (node1 == null) {
          node = ((Child)node).getPreviousWithoutReference();
          break;
        } 
        node = node1;
      } 
    } 
    return node;
  }
  
  public Node getNextSibling() { return this.nextSibling; }
  
  public Node getNextWithoutReference() {
    Node node = getNextSibling();
    if (node == null) {
      Node node1 = getParentNode();
      if (node1 == null)
        return null; 
      if (node1.getNodeType() == 5)
        node = ((Child)node1).getNextWithoutReference(); 
    } else {
      while (node.getNodeType() == 5) {
        Node node1 = node.getFirstChild();
        if (node1 == null) {
          node = ((Child)node).getNextWithoutReference();
          break;
        } 
        node = node1;
      } 
    } 
    return node;
  }
  
  public NamedNodeMap getAttributes() { return null; }
  
  public Node insertBefore(Node paramNode1, Node paramNode2) throws DOMException { throw new TXDOMException((short)3, "com.ibm.xml.parser.Child#insertBefore(): Can't insert any nodes to this."); }
  
  public Node replaceChild(Node paramNode1, Node paramNode2) throws DOMException { throw new TXDOMException((short)3, "com.ibm.xml.parser.Child#replaceChild(): Can't insert any nodes to this."); }
  
  public Node removeChild(Node paramNode) throws DOMException { throw new TXDOMException((short)8, "com.ibm.xml.parser.Child#removeChild(): Can't insert any nodes to this."); }
  
  public Node appendChild(Node paramNode) throws DOMException { throw new TXDOMException((short)3, "com.ibm.xml.parser.Child#appendChild(): Can't insert any nodes to this."); }
  
  public String getText() { return ""; }
  
  public TXElement searchAncestors(String paramString) { return searchAncestors(0, null, paramString); }
  
  public TXElement searchAncestors(int paramInt, String paramString1, String paramString2) {
    Child child = this;
    Node node;
    while ((node = child.getParentNode()) != null) {
      if (!(node instanceof TXElement))
        return null; 
      if (Match.matchName((Namespace)node, paramInt, paramString1, paramString2))
        return (TXElement)node; 
    } 
    return null;
  }
  
  public void toXMLString(Writer paramWriter, String paramString) throws IOException, LibraryException {
    try {
      ToXMLStringVisitor toXMLStringVisitor = new ToXMLStringVisitor(paramWriter, paramString);
      (new NonRecursivePreorderTreeTraversal(toXMLStringVisitor)).traverse(this);
      return;
    } catch (IOException iOException) {
      throw iOException;
    } catch (Exception exception) {
      throw new LibraryException("com.ibm.xml.parser.Child#toXMLString(): Unexpected Exception: " + exception.toString());
    } 
  }
  
  public void toXMLString(Writer paramWriter) throws IOException, LibraryException { toXMLString(paramWriter, null); }
  
  public void print(Writer paramWriter, String paramString) throws IOException, LibraryException { toXMLString(paramWriter, paramString); }
  
  public void print(Writer paramWriter) throws IOException, LibraryException { print(paramWriter, null); }
  
  public Document getOwnerDocument() { return this.factory; }
  
  public TXDocument getFactory() { return this.factory; }
  
  public void setFactory(TXDocument paramTXDocument) { this.factory = paramTXDocument; }
  
  public byte[] getDigest() throws LibraryException {
    if (this.digest == null) {
      checkFactory();
      try {
        MakeDigestVisitor makeDigestVisitor = new MakeDigestVisitor(getFactory().createMessageDigest());
        (new NonRecursivePreorderTreeTraversal(makeDigestVisitor)).traverse(this);
      } catch (Exception exception) {
        throw new LibraryException("com.ibm.xml.parser.Child#getDigest(): Unexpected Exception: " + exception.toString());
      } 
    } 
    return this.digest;
  }
  
  public void clearDigest() {
    if (this.digest != null) {
      this.digest = null;
      if (this.parent != null)
        ((Child)this.parent).clearDigest(); 
    } 
  }
  
  public XPointer makeXPointer() { return XPointer.makeXPointer(this); }
  
  void checkFactory() {
    if (this.factory == null) {
      if (TXDocument.s_instance == null)
        TXDocument.s_instance = new TXDocument(); 
      this.factory = TXDocument.s_instance;
    } 
  }
  
  void setParentNode(Node paramNode) { this.parent = paramNode; }
  
  void setPreviousSibling(Node paramNode) { this.prevSibling = paramNode; }
  
  void setNextSibling(Node paramNode) { this.nextSibling = paramNode; }
  
  byte[] getVisitorDigest() throws LibraryException { return this.digest; }
  
  void setVisitorDigest(byte[] paramArrayOfByte) { this.digest = paramArrayOfByte; }
  
  public void setUserData(Object paramObject) { this.userData = paramObject; }
  
  public Object getUserData() { return this.userData; }
  
  public abstract String getNodeName();
  
  public abstract short getNodeType();
  
  public abstract void acceptPre(Visitor paramVisitor) throws Exception;
  
  public abstract void acceptPost(Visitor paramVisitor) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\Child.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */