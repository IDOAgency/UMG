package com.ibm.xml.parser;

import java.util.BitSet;

public class CM2op extends CMNode {
  static final long serialVersionUID = 3303486725862458161L;
  
  int type;
  
  CMNode leftNode;
  
  CMNode rightNode;
  
  public CM2op(int paramInt, CMNode paramCMNode1, CMNode paramCMNode2) {
    this.type = paramInt;
    this.leftNode = paramCMNode1;
    this.rightNode = paramCMNode2;
  }
  
  public int getType() { return this.type; }
  
  public CMNode getLeft() { return this.leftNode; }
  
  public void setLeft(CMNode paramCMNode) { this.leftNode = paramCMNode; }
  
  public CMNode getRight() { return this.rightNode; }
  
  public void setRight(CMNode paramCMNode) { this.rightNode = paramCMNode; }
  
  public String toString() { return (this.leftNode instanceof CM2op && ((CM2op)this.leftNode).type == this.type) ? ("(" + ((CM2op)this.leftNode).toStringWithoutParen() + (char)this.type + this.rightNode.toString() + ")") : ("(" + this.leftNode.toString() + (char)this.type + this.rightNode.toString() + ")"); }
  
  String toStringWithoutParen() { return (this.leftNode instanceof CM2op && ((CM2op)this.leftNode).type == this.type) ? (String.valueOf(((CM2op)this.leftNode).toStringWithoutParen()) + (char)this.type + this.rightNode.toString()) : (String.valueOf(this.leftNode.toString()) + (char)this.type + this.rightNode.toString()); }
  
  CMNode cloneNode() { return new CM2op(this.type, this.leftNode.cloneNode(), this.rightNode.cloneNode()); }
  
  boolean nullable() {
    if (this.nullable == null)
      switch (this.type) {
        case 44:
          this.nullable = new Boolean(!(!this.leftNode.nullable() || !this.rightNode.nullable()));
          break;
        case 124:
          this.nullable = new Boolean(!(!this.leftNode.nullable() && !this.rightNode.nullable()));
          break;
      }  
    return this.nullable.booleanValue();
  }
  
  BitSet firstpos() {
    if (this.firstPos == null)
      if (this.type == 124) {
        this.firstPos = (BitSet)this.leftNode.firstpos().clone();
        this.firstPos.or(this.rightNode.firstpos());
      } else if (this.leftNode.nullable()) {
        this.firstPos = (BitSet)this.leftNode.firstpos().clone();
        this.firstPos.or(this.rightNode.firstpos());
      } else {
        this.firstPos = this.leftNode.firstpos();
      }  
    return this.firstPos;
  }
  
  BitSet lastpos() {
    if (this.lastPos == null)
      if (this.type == 124) {
        this.lastPos = (BitSet)this.leftNode.lastpos().clone();
        this.lastPos.or(this.rightNode.lastpos());
      } else if (this.rightNode.nullable()) {
        this.lastPos = (BitSet)this.leftNode.lastpos().clone();
        this.lastPos.or(this.rightNode.lastpos());
      } else {
        this.lastPos = this.rightNode.lastpos();
      }  
    return this.lastPos;
  }
  
  void prepare(int paramInt) {
    this.leftNode.prepare(paramInt);
    this.rightNode.prepare(paramInt);
  }
  
  void setFollowpos(BitSet[] paramArrayOfBitSet) {
    this.leftNode.setFollowpos(paramArrayOfBitSet);
    this.rightNode.setFollowpos(paramArrayOfBitSet);
    if (this.type != 124 && this.type == 44)
      for (byte b = 0; b < paramArrayOfBitSet.length; b++) {
        if (this.leftNode.lastpos().get(b))
          paramArrayOfBitSet[b].or(this.rightNode.firstpos()); 
      }  
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof CM2op))
      return false; 
    CM2op cM2op = (CM2op)paramObject;
    return (cM2op.getType() != getType()) ? false : (!(!cM2op.getLeft().equals(getLeft()) || !cM2op.getRight().equals(getRight())));
  }
  
  public int hashCode() { return getLeft().hashCode() + getRight().hashCode(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\CM2op.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */