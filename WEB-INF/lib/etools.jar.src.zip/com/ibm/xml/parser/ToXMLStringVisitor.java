package com.ibm.xml.parser;

import java.io.Writer;
import org.w3c.dom.Node;

public class ToXMLStringVisitor extends NOOPVisitor implements Visitor {
  protected Writer writer;
  
  protected String encoding;
  
  protected boolean isPrintNonSpecifiedAttributes = true;
  
  public ToXMLStringVisitor(Writer paramWriter, String paramString) {
    this.writer = paramWriter;
    this.encoding = paramString;
  }
  
  public ToXMLStringVisitor(Writer paramWriter) { this(paramWriter, null); }
  
  public void setPrintNonSpecifiedAttributes(boolean paramBoolean) { this.isPrintNonSpecifiedAttributes = paramBoolean; }
  
  public boolean getPrintNonSpecifiedAttributes() { return this.isPrintNonSpecifiedAttributes; }
  
  public void visitDocumentPre(TXDocument paramTXDocument) throws Exception {
    if (paramTXDocument.getVersion() != null) {
      this.writer.write("<?xml version=\"" + paramTXDocument.getVersion() + "\"");
      if (paramTXDocument.getEncoding() != null)
        this.writer.write(" encoding=\"" + paramTXDocument.getEncoding() + "\""); 
      if (paramTXDocument.getStandalone() != null)
        this.writer.write(" standalone=\"" + paramTXDocument.getStandalone() + "\""); 
      this.writer.write("?>");
    } 
  }
  
  public void visitDocumentPost(TXDocument paramTXDocument) throws Exception { this.writer.flush(); }
  
  public void visitElementPre(TXElement paramTXElement) throws Exception {
    this.writer.write("<" + paramTXElement.getTagName());
    TXAttribute[] arrayOfTXAttribute = paramTXElement.getAttributeArray();
    for (byte b = 0; b < arrayOfTXAttribute.length; b++) {
      try {
        TXAttribute tXAttribute = arrayOfTXAttribute[b];
        if (this.isPrintNonSpecifiedAttributes || tXAttribute.getSpecified())
          visitAttributePre(tXAttribute); 
      } catch (ToNextSiblingTraversalException toNextSiblingTraversalException) {}
    } 
    if (paramTXElement.hasChildNodes()) {
      this.writer.write(">");
      return;
    } 
    this.writer.write("/>");
  }
  
  public void visitElementPost(TXElement paramTXElement) throws Exception {
    if (paramTXElement.hasChildNodes())
      this.writer.write("</" + paramTXElement.getTagName() + ">"); 
  }
  
  public void visitAttributePre(TXAttribute paramTXAttribute) throws Exception {
    this.writer.write(" ");
    this.writer.write(paramTXAttribute.getName());
    this.writer.write("=\"");
    for (Node node = paramTXAttribute.getFirstChild(); node != null; node = node.getNextSibling()) {
      short s = node.getNodeType();
      if (s == 3) {
        this.writer.write(Util.backReference(node.getNodeValue(), "<&\"", this.encoding));
      } else if (s == 5) {
        this.writer.write("&");
        this.writer.write(node.getNodeName());
        this.writer.write(";");
      } 
    } 
    this.writer.write("\"");
    throw new ToNextSiblingTraversalException();
  }
  
  public void visitPIPre(TXPI paramTXPI) throws Exception {
    this.writer.write("<?" + paramTXPI.getNodeName());
    String str = paramTXPI.getData();
    if (paramTXPI.getData().length() > 0) {
      char c = str.charAt(0);
      if (c < '\000' || c >= '' || ((0x4 & XMLChar.flags[c]) == 0 && !false))
        this.writer.write(" "); 
    } 
    this.writer.write(String.valueOf(paramTXPI.getData()) + "?>");
  }
  
  public void visitCommentPre(TXComment paramTXComment) throws Exception { this.writer.write("<!--" + paramTXComment.getData() + "-->"); }
  
  public void visitTextPre(TXText paramTXText) throws Exception {
    if (paramTXText instanceof org.w3c.dom.CDATASection) {
      this.writer.write("<![CDATA[" + paramTXText.getData() + "]]>");
      return;
    } 
    this.writer.write(Util.backReference(paramTXText.getData(), this.encoding));
  }
  
  public void visitDTDPre(DTD paramDTD) throws Exception {
    this.writer.write("<!DOCTYPE " + paramDTD.getName());
    if (paramDTD.getExternalID() != null)
      this.writer.write(" " + paramDTD.getExternalID()); 
    if (paramDTD.isPrintInternalDTD() && paramDTD.getInternalSize() > 0) {
      this.writer.write(" [");
      return;
    } 
    throw new ToNextSiblingTraversalException();
  }
  
  public void visitDTDPost(DTD paramDTD) throws Exception {
    if (paramDTD.isPrintInternalDTD() && paramDTD.getInternalSize() > 0)
      this.writer.write("]"); 
    this.writer.write(">");
  }
  
  public void visitElementDeclPre(ElementDecl paramElementDecl) throws Exception { this.writer.write("<!ELEMENT " + paramElementDecl.getName() + " " + paramElementDecl.getXML4JContentModel() + ">"); }
  
  public void visitAttlistPre(Attlist paramAttlist) throws Exception {
    this.writer.write("<!ATTLIST " + paramAttlist.getName());
    int i = paramAttlist.size();
    if (i <= 0) {
      this.writer.write(" >");
      return;
    } 
    if (i == 1) {
      visitAttDefPre(paramAttlist.elementAt(0));
      this.writer.write(62);
      return;
    } 
    this.writer.write("\n");
    for (byte b = 0; b < i; b++) {
      Util.printSpace(this.writer, 4);
      visitAttDefPre(paramAttlist.elementAt(b));
      if (b == i - 1) {
        this.writer.write(">");
      } else {
        this.writer.write("\n");
      } 
    } 
  }
  
  public void visitAttDefPre(AttDef paramAttDef) throws Exception {
    this.writer.write(String.valueOf(' ') + paramAttDef.getName() + ' ');
    int i = paramAttDef.getDeclaredType();
    if (i != 10)
      this.writer.write(String.valueOf(AttDef.S_TYPESTR[paramAttDef.getDeclaredType()]) + ' '); 
    if (i == 9 || i == 10) {
      this.writer.write(String.valueOf('(') + paramAttDef.elementAt(0));
      for (byte b = 1; b < paramAttDef.size(); b++)
        this.writer.write(String.valueOf('|') + paramAttDef.elementAt(b)); 
      this.writer.write(") ");
    } 
    int j = paramAttDef.getDefaultType();
    if (j == 2) {
      this.writer.write("#REQUIRED");
      return;
    } 
    if (j == 3) {
      this.writer.write("#IMPLIED");
      return;
    } 
    if (j == 1) {
      this.writer.write("#FIXED \"");
      String str1 = paramAttDef.getDefaultStringValue();
      String str2 = this.encoding;
      this.writer.write((paramAttDef.getDefaultStringValue() == null) ? "(null)" : Util.backReference(str1, "&\"'%\r\n\t", str2));
      this.writer.write(34);
      return;
    } 
    if (j == -1) {
      this.writer.write(34);
      String str1 = paramAttDef.getDefaultStringValue();
      String str2 = this.encoding;
      this.writer.write((paramAttDef.getDefaultStringValue() == null) ? "(null)" : Util.backReference(str1, "&\"'%\r\n\t", str2));
      this.writer.write(34);
    } 
  }
  
  public void visitEntityDeclPre(EntityDecl paramEntityDecl) throws Exception {
    this.writer.write("<!ENTITY ");
    if (paramEntityDecl.isParameter())
      this.writer.write("% "); 
    this.writer.write(String.valueOf(paramEntityDecl.getNodeName()) + " ");
    if (paramEntityDecl.getValue() != null) {
      String str1 = paramEntityDecl.getValue();
      String str2 = this.encoding;
      this.writer.write("\"" + Util.backReference(str1, "&\"'%\r\n\t", str2) + "\">");
    } else {
      this.writer.write(paramEntityDecl.getExternalID().toString());
      if (paramEntityDecl.getNotationName() != null)
        this.writer.write(" NDATA " + paramEntityDecl.getNotationName()); 
      this.writer.write(">");
    } 
    throw new ToNextSiblingTraversalException();
  }
  
  public void visitNotationPre(TXNotation paramTXNotation) throws Exception { this.writer.write("<!NOTATION " + paramTXNotation.getNodeName() + " " + paramTXNotation.getExternalID() + ">"); }
  
  public void visitGeneralReferencePre(GeneralReference paramGeneralReference) throws Exception {
    this.writer.write(String.valueOf('&') + paramGeneralReference.getName() + ';');
    throw new ToNextSiblingTraversalException();
  }
  
  public void visitPseudoNodePre(PseudoNode paramPseudoNode) throws Exception { this.writer.write(paramPseudoNode.getData()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\ToXMLStringVisitor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */