package com.ibm.xml.parser;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;

public class EntityPool implements Serializable {
  static final long serialVersionUID = -8639077697333708869L;
  
  private Hashtable m_entity = new Hashtable();
  
  private Hashtable m_para = new Hashtable();
  
  public boolean add(EntityDecl paramEntityDecl) {
    String str = paramEntityDecl.getNodeName();
    if (paramEntityDecl.isParameter()) {
      if (this.m_para.containsKey(str))
        return false; 
      this.m_para.put(str, paramEntityDecl);
    } else {
      if (this.m_entity.containsKey(str))
        return false; 
      this.m_entity.put(str, paramEntityDecl);
    } 
    return true;
  }
  
  EntityDecl refer(String paramString) { return (EntityDecl)this.m_entity.get(paramString); }
  
  EntityDecl referPara(String paramString) { return (EntityDecl)this.m_para.get(paramString); }
  
  Enumeration elements() { return this.m_entity.elements(); }
  
  Enumeration parameterEntityElements() { return this.m_para.elements(); }
  
  Hashtable getEntityHash() { return this.m_entity; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\EntityPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */