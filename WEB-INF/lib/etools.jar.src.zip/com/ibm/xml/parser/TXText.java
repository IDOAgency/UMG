package com.ibm.xml.parser;

import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

public class TXText extends TXCharacterData implements Text {
  static final long serialVersionUID = -8266596319046593304L;
  
  boolean isIgnorableWhitespace = false;
  
  public TXText(String paramString) { this.data = paramString; }
  
  public Object clone() {
    checkFactory();
    TXText tXText = (TXText)this.factory.createTextNode(this.data);
    tXText.setFactory(getFactory());
    tXText.setIsIgnorableWhitespace(getIsIgnorableWhitespace());
    return tXText;
  }
  
  public boolean equals(Node paramNode, boolean paramBoolean) { return (paramNode == null) ? false : (!(paramNode instanceof Text) ? false : ((Text)paramNode).getData().equals(getData())); }
  
  public short getNodeType() { return 3; }
  
  public String getNodeName() { return "#text"; }
  
  public String getText() { return getData(); }
  
  public boolean getIsIgnorableWhitespace() { return this.isIgnorableWhitespace; }
  
  public void setIsIgnorableWhitespace(boolean paramBoolean) { this.isIgnorableWhitespace = paramBoolean; }
  
  public String getLanguage() { return (this.parent == null) ? null : ((this.parent instanceof TXElement) ? ((TXElement)this.parent).getLanguage() : ((this.parent instanceof GeneralReference) ? ((GeneralReference)this.parent).getLanguage() : null)); }
  
  public void splice(Element paramElement, int paramInt1, int paramInt2) throws IllegalArgumentException, RuntimeException {
    if (!(paramElement instanceof TXElement))
      throw new IllegalArgumentException("com.ibm.xml.parser.TXText#splice(): An instance of TXElement is required."); 
    String str1 = this.data.substring(paramInt1, paramInt2);
    String str2 = this.data.substring(paramInt1 + paramInt2);
    this.data = this.data.substring(0, paramInt1);
    clearDigest();
    Parent parent = (Parent)getParentNode();
    if (parent == null)
      throw new RuntimeException("com.ibm.xml.parser.TXText#splice(): This Text Node has no parent and can not be spliced."); 
    checkFactory();
    paramElement.insertBefore(this.factory.createTextNode(str1), null);
    parent.insertAfter(paramElement, this);
    if (str2.length() > 0)
      parent.insertAfter(this.factory.createTextNode(str2), this); 
  }
  
  public Text splitText(int paramInt) throws DOMException {
    if (paramInt < 0 || paramInt > this.data.length())
      throw new TXDOMException((short)1, "Out of bounds: " + paramInt + ", the length of data is " + this.data.length()); 
    checkFactory();
    Text text = this.factory.createTextNode(this.data.substring(paramInt));
    setData(substringData(0, paramInt));
    Parent parent = (Parent)getParentNode();
    if (parent == null)
      throw new RuntimeException("com.ibm.xml.parser.TXText#splitText(): This Text Node has no parent and can not be split."); 
    parent.insertAfter(text, this);
    return text;
  }
  
  public static String trim(String paramString) { return trim(paramString, true, true); }
  
  public static String trim(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    boolean bool1 = false;
    byte b1 = 0;
    while (b1 < i) {
      char c = arrayOfChar[b1];
      if (c < '\000' || c >= '' || ((0x4 & XMLChar.flags[c]) == 0 && !false)) {
        b1++;
        continue;
      } 
      break;
    } 
    byte b2 = b1;
    boolean bool2 = false;
    while (b1 < i) {
      char c = arrayOfChar[b1];
      char c1 = c;
      if (c1 >= '\000' && c1 < '' && ((0x4 & XMLChar.flags[c1]) != 0 || false)) {
        if (!bool2) {
          if (c != ' ')
            bool1 = true; 
          arrayOfChar[b2++] = ' ';
        } else {
          bool1 = true;
        } 
        bool2 = true;
      } else {
        arrayOfChar[b2++] = c;
        bool2 = false;
      } 
      b1++;
    } 
    if (paramBoolean2 && b2 >= 1 && arrayOfChar[b2 - 1] == ' ') {
      bool1 = true;
      b2--;
    } 
    byte b3 = 0;
    if (paramBoolean1 && b2 > 0 && arrayOfChar[0] == ' ') {
      bool1 = true;
      b3++;
    } 
    return bool1 ? new String(arrayOfChar, b3, b2 - b3) : paramString;
  }
  
  public static String makePrintable(String paramString) {
    StringBuffer stringBuffer = new StringBuffer(paramString.length() * 2);
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if (c == '\r') {
        stringBuffer.append("\\r");
      } else if (c == '\n') {
        stringBuffer.append("\\n");
      } else if (c == '\t') {
        stringBuffer.append("\\t");
      } else if (c == '\b') {
        stringBuffer.append("\\b");
      } else if (c == '\f') {
        stringBuffer.append("\\f");
      } else if (c == '"') {
        stringBuffer.append("\\\"");
      } else if (c == '\\') {
        stringBuffer.append("\\\\");
      } else {
        stringBuffer.append((char)c);
      } 
    } 
    return stringBuffer.toString();
  }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitTextPre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitTextPost(this); }
  
  static boolean isText(Object paramObject) { return !(paramObject instanceof TXCDATASection || !(paramObject instanceof TXText)); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TXText.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */