package com.ibm.xml.parser;

import org.w3c.dom.Node;

public class PseudoNode extends TXCharacterData {
  static final long serialVersionUID = 7400309181601885133L;
  
  public PseudoNode(String paramString) { this.data = paramString; }
  
  public Object clone() {
    PseudoNode pseudoNode = new PseudoNode(this.data);
    pseudoNode.setFactory(getFactory());
    return pseudoNode;
  }
  
  public short getNodeType() { return 23; }
  
  public String getNodeName() { return "#pseudo-node"; }
  
  public boolean equals(Node paramNode, boolean paramBoolean) { return (paramNode == null) ? false : (!(paramNode instanceof PseudoNode) ? false : this.data.equals(((PseudoNode)paramNode).getData())); }
  
  public String getText() { return this.data; }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitPseudoNodePre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitPseudoNodePost(this); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\PseudoNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */