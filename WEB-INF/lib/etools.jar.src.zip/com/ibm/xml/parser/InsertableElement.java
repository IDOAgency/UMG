package com.ibm.xml.parser;

public class InsertableElement {
  public String name;
  
  public boolean status = false;
  
  public int index = -1;
  
  public InsertableElement(String paramString) { this(paramString, false); }
  
  public InsertableElement(String paramString, boolean paramBoolean) {
    this.name = paramString;
    this.status = paramBoolean;
    this.index = -1;
  }
  
  public InsertableElement(int paramInt) {
    this.name = " *ERROR* ";
    this.status = true;
    this.index = paramInt;
  }
  
  public String toString() { return " *ERROR* ".equals(this.name) ? ("InsertableElement[\"" + this.name + "\", " + this.status + ", " + this.index + "]") : ("InsertableElement[\"" + this.name + "\", " + this.status + "]"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\InsertableElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */