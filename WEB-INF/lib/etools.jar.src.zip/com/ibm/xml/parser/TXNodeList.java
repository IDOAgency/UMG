package com.ibm.xml.parser;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Vector;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

class TXNodeList implements NodeList, Serializable {
  static final long serialVersionUID = 3392852660870983354L;
  
  Vector nodes = new Vector();
  
  static EmptyNodeListImpl emptyNodeList = new EmptyNodeListImpl();
  
  public int getLength() { return this.nodes.size(); }
  
  public Enumeration elements() { return this.nodes.elements(); }
  
  public Node item(int paramInt) { return (Node)this.nodes.elementAt(paramInt); }
  
  public int indexOf(Node paramNode) { return this.nodes.indexOf(paramNode); }
  
  public void replace(int paramInt, Node paramNode) throws DOMException {
    if (paramInt < 0 || this.nodes.size() <= paramInt)
      throw new TXDOMException((short)1, "com.ibm.xml.parser.TXNodeList#replace(): Wrong index: " + paramInt); 
    Child child1 = (Child)item(paramInt);
    Child child2 = (Child)child1.getPreviousSibling();
    Child child3 = (Child)child1.getNextSibling();
    this.nodes.setElementAt(paramNode, paramInt);
    Child child4 = (Child)paramNode;
    child4.setPreviousSibling(child2);
    if (child2 != null)
      child2.setNextSibling(child4); 
    child4.setNextSibling(child3);
    if (child3 != null)
      child3.setPreviousSibling(child4); 
    child1.setPreviousSibling(null);
    child1.setNextSibling(null);
    child1.setParentNode(null);
  }
  
  public void insert(int paramInt, Node paramNode) throws DOMException {
    if (paramInt < 0 || paramInt > this.nodes.size())
      throw new TXDOMException((short)1, "com.ibm.xml.parser.TXNodeList#insert(): Wrong index: " + paramInt); 
    Child child1 = (paramInt > 0) ? (Child)this.nodes.elementAt(paramInt - 1) : null;
    Child child2 = (this.nodes.size() > paramInt) ? (Child)this.nodes.elementAt(paramInt) : null;
    this.nodes.insertElementAt(paramNode, paramInt);
    Child child3 = (Child)paramNode;
    child3.setPreviousSibling(child1);
    if (child1 != null)
      child1.setNextSibling(child3); 
    child3.setNextSibling(child2);
    if (child2 != null)
      child2.setPreviousSibling(child3); 
  }
  
  public Node remove(int paramInt) {
    if (paramInt < 0 || this.nodes.size() <= paramInt)
      throw new TXDOMException((short)1, "com.ibm.xml.parser.TXNodeList#remove(): Wrong index: " + paramInt); 
    Child child1 = (Child)this.nodes.elementAt(paramInt);
    Child child2 = (Child)child1.getPreviousSibling();
    Child child3 = (Child)child1.getNextSibling();
    this.nodes.removeElementAt(paramInt);
    child1.setParentNode(null);
    child1.setPreviousSibling(null);
    child1.setNextSibling(null);
    if (child2 != null)
      child2.setNextSibling(child3); 
    if (child3 != null)
      child3.setPreviousSibling(child2); 
    return child1;
  }
  
  public void append(Node paramNode) { insert(this.nodes.size(), paramNode); }
  
  public void ensureCapacity(int paramInt) { this.nodes.ensureCapacity(paramInt); }
  
  public boolean equals(Object paramObject) { return equals(paramObject, true); }
  
  public boolean equals(Object paramObject, boolean paramBoolean) {
    if (paramObject == null)
      return false; 
    if (!(paramObject instanceof NodeList))
      return false; 
    NodeList nodeList = (NodeList)paramObject;
    if (nodeList.getLength() != getLength())
      return false; 
    for (byte b = 0; b < nodeList.getLength(); b++) {
      Node node = nodeList.item(b);
      if (!((Child)node).equals(item(b), paramBoolean))
        return false; 
    } 
    return true;
  }
  
  public int hashCode() { return 0; }
  
  static class EmptyNodeListImpl implements NodeList {
    public Node item(int param1Int) { throw new ArrayIndexOutOfBoundsException(); }
    
    public int getLength() { return 0; }
  }
  
  static class VectorNodeList implements NodeList {
    Vector data;
    
    VectorNodeList(Vector param1Vector) { this.data = param1Vector; }
    
    public Node item(int param1Int) { return (Node)this.data.elementAt(param1Int); }
    
    public int getLength() { return this.data.size(); }
  }
  
  static class ArrayNodeList implements NodeList {
    Node[] data;
    
    ArrayNodeList(Node[] param1ArrayOfNode) { this.data = param1ArrayOfNode; }
    
    public Node item(int param1Int) { return this.data[param1Int]; }
    
    public int getLength() { return this.data.length; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TXNodeList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */