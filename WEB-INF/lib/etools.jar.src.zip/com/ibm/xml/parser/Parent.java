package com.ibm.xml.parser;

import java.util.Enumeration;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public abstract class Parent extends Child {
  static final long serialVersionUID = -5379012622242611200L;
  
  TXNodeList children = new TXNodeList();
  
  public NodeList getChildNodes() { return this.children; }
  
  public boolean hasChildNodes() { return !(this.children.getLength() <= 0); }
  
  public Enumeration elements() { return this.children.elements(); }
  
  public Child[] getChildrenArray() {
    Child[] arrayOfChild = new Child[this.children.getLength()];
    this.children.nodes.copyInto(arrayOfChild);
    return arrayOfChild;
  }
  
  public Node getFirstChild() { return (this.children.getLength() > 0) ? this.children.item(0) : null; }
  
  public Node getFirstWithoutReference() {
    for (Node node = getFirstChild(); node != null && node.getNodeType() == 5; node = node1) {
      Node node1 = node.getFirstChild();
      if (node1 == null) {
        node = ((Child)node).getNextWithoutReference();
        break;
      } 
    } 
    return node;
  }
  
  public Node getLastChild() {
    int i = this.children.getLength();
    return (i > 0) ? this.children.item(i - 1) : null;
  }
  
  public Node getLastWithoutReference() {
    for (Node node = getLastChild(); node != null && node.getNodeType() == 5; node = node1) {
      Node node1 = node.getLastChild();
      if (node1 == null) {
        node = ((Child)node).getPreviousWithoutReference();
        break;
      } 
    } 
    return node;
  }
  
  protected abstract void checkChildType(Node paramNode) throws DOMException;
  
  protected void realInsert(Node paramNode, int paramInt) throws DOMException {
    if (paramNode.getParentNode() != null)
      paramNode.getParentNode().removeChild(paramNode); 
    checkChildType(paramNode);
    if (paramNode == this)
      throw new TXDOMException((short)3, "Can't have itself as child."); 
    TXDocument tXDocument = getFactory();
    if (tXDocument != null) {
      if (tXDocument.isCheckOwnerDocument() && tXDocument != paramNode.getOwnerDocument())
        throw new TXDOMException((short)4, "Specified child was created from a different document. The parent is \"" + getNodeName() + "\", the child is \"" + paramNode.getNodeName() + "\"."); 
      if (tXDocument.isCheckNodeLoop()) {
        Parent parent = this;
        Node node;
        while ((node = parent.getParentNode()) != null) {
          if (node == paramNode)
            throw new TXDOMException((short)3, "Can't have an ancestor as child"); 
        } 
      } 
    } 
    this.children.insert(paramInt, paramNode);
    ((Child)paramNode).setParentNode(this);
    clearDigest();
  }
  
  public void insert(Node paramNode, int paramInt) throws DOMException {
    if (paramNode instanceof org.w3c.dom.DocumentFragment) {
      Node node;
      while ((node = paramNode.getLastChild()) != null) {
        paramNode.removeChild(node);
        insert(node, paramInt);
      } 
      return;
    } 
    realInsert(paramNode, paramInt);
  }
  
  public Node insertBefore(Node paramNode1, Node paramNode2) throws DOMException {
    if (paramNode2 == null) {
      insert(paramNode1, this.children.getLength());
    } else {
      int i = this.children.indexOf(paramNode2);
      if (i < 0)
        throw new TXDOMException((short)8, "com.ibm.xml.parser.Parent#insertBefore(): Node " + paramNode2 + " is not found in the child list."); 
      insert(paramNode1, i);
    } 
    return paramNode1;
  }
  
  public Node insertAfter(Node paramNode1, Node paramNode2) throws DOMException {
    if (paramNode2 == null) {
      insert(paramNode1, 0);
    } else {
      insertBefore(paramNode1, paramNode2.getNextSibling());
    } 
    return paramNode1;
  }
  
  public Node insertFirst(Node paramNode) {
    insert(paramNode, 0);
    return paramNode;
  }
  
  public Node insertLast(Node paramNode) {
    insert(paramNode, this.children.getLength());
    return paramNode;
  }
  
  public void addElement(Child paramChild) {
    if (paramChild != null)
      insert(paramChild, this.children.getLength()); 
  }
  
  public Node appendChild(Node paramNode) {
    if (paramNode != null)
      insert(paramNode, this.children.getLength()); 
    return paramNode;
  }
  
  public Node replaceChild(Node paramNode1, Node paramNode2) throws DOMException {
    int i = this.children.indexOf(paramNode2);
    if (i < 0)
      throw new TXDOMException((short)8, "com.ibm.xml.parser.Parent#replaceChild(): Node " + paramNode2 + " is not found in the child list."); 
    if (paramNode1 == paramNode2)
      return paramNode1; 
    if (paramNode1.getParentNode() != null)
      paramNode1.getParentNode().removeChild(paramNode1); 
    Child child = (Child)paramNode1;
    this.children.replace(i, child);
    child.setParentNode(this);
    clearDigest();
    return paramNode2;
  }
  
  public Node removeChild(Node paramNode) {
    int i = this.children.indexOf(paramNode);
    if (i < 0)
      throw new TXDOMException((short)8, "com.ibm.xml.parser.Parent#removeChild(): Node " + paramNode + " is not found in the child list."); 
    this.children.remove(i);
    clearDigest();
    return paramNode;
  }
  
  protected void processAfterRemove(Node paramNode) throws DOMException {
    short s = paramNode.getNodeType();
    if (s == 1) {
      ((TXElement)paramNode).collectNamespaceAttributes(this);
      return;
    } 
    if (s == 5)
      ((GeneralReference)paramNode).collectNamespaceAttributes(this); 
  }
  
  public void expandEntityReferences() {
    for (Node node = getFirstChild(); node != null; node = node.getNextSibling()) {
      if (node instanceof Parent) {
        ((Parent)node).expandEntityReferences();
        if (node instanceof org.w3c.dom.EntityReference) {
          Node node1;
          while ((node1 = node.getLastChild()) != null) {
            node.removeChild(node1);
            insertAfter(node1, node);
          } 
          node1 = node.getNextSibling();
          removeChild(node);
          node = node1;
          continue;
        } 
      } 
    } 
  }
  
  public String getText() {
    int i;
    if (this.children == null || (i = this.children.getLength()) == 0)
      return ""; 
    if (i == 1)
      return ((Child)this.children.item(0)).getText(); 
    StringBuffer stringBuffer = new StringBuffer(128);
    synchronized (this.children) {
      for (byte b = 0; b < i; b++)
        stringBuffer.append(((Child)this.children.item(b)).getText()); 
    } 
    return stringBuffer.toString().intern();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\Parent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */