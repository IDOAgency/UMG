package com.ibm.xml.parser;

import java.io.Serializable;

public class ExternalID implements Serializable {
  static final long serialVersionUID = 4611817161873481189L;
  
  private static final int T_SYSTEM = 0;
  
  private static final int T_PUBLIC = 1;
  
  int type = 1;
  
  String publicID;
  
  String systemID;
  
  public ExternalID(String paramString) {
    this.type = 0;
    this.publicID = null;
    this.systemID = paramString;
  }
  
  public ExternalID(String paramString1, String paramString2) {
    this.type = 1;
    this.publicID = paramString1;
    this.systemID = paramString2;
    if (this.publicID == null)
      this.type = 0; 
  }
  
  public boolean isSystem() { return !(this.type != 0); }
  
  public boolean isPublic() { return !(this.type != 1); }
  
  public String getSystemLiteral() { return this.systemID; }
  
  public String getPubidLiteral() { return this.publicID; }
  
  public String toString() {
    String str;
    if (isSystem()) {
      str = "SYSTEM \"" + getSystemLiteral() + "\"";
    } else if (getSystemLiteral() != null) {
      str = "PUBLIC \"" + getPubidLiteral() + "\" \"" + getSystemLiteral() + "\"";
    } else {
      str = "PUBLIC \"" + getPubidLiteral() + "\"";
    } 
    return str;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == null)
      return false; 
    if (!(paramObject instanceof ExternalID))
      return false; 
    ExternalID externalID = (ExternalID)paramObject;
    return ((externalID.publicID != null || this.publicID != null) && (externalID.publicID == null || !externalID.publicID.equals(this.publicID))) ? false : (!((externalID.systemID != null || this.systemID != null) && (externalID.systemID == null || !externalID.systemID.equals(this.systemID))));
  }
  
  public int hashCode() {
    int i = 0;
    if (this.publicID != null)
      i = this.publicID.hashCode(); 
    if (this.systemID != null)
      i += this.systemID.hashCode(); 
    return i;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\ExternalID.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */