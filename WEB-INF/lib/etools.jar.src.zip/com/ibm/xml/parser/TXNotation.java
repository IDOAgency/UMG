package com.ibm.xml.parser;

import org.w3c.dom.Node;
import org.w3c.dom.Notation;

public class TXNotation extends Child {
  static final long serialVersionUID = -1546534879299424756L;
  
  String name;
  
  ExternalID externalID;
  
  public TXNotation(String paramString, ExternalID paramExternalID) {
    this.name = paramString;
    this.externalID = paramExternalID;
  }
  
  public Object clone() {
    checkFactory();
    TXNotation tXNotation = this.factory.createNotation(this.name, this.externalID);
    tXNotation.setFactory(getFactory());
    return tXNotation;
  }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (paramNode == null)
      return false; 
    if (!(paramNode instanceof TXNotation))
      return false; 
    TXNotation tXNotation = (TXNotation)paramNode;
    return !getName().equals(tXNotation.getName()) ? false : getExternalID().equals(tXNotation.getExternalID());
  }
  
  public short getNodeType() { return 12; }
  
  public String getNodeName() { return this.name; }
  
  public String getName() { return this.name; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getSystemId() { return this.externalID.getSystemLiteral(); }
  
  public String getPublicId() { return this.externalID.getPubidLiteral(); }
  
  public ExternalID getExternalID() { return this.externalID; }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitNotationPre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitNotationPost(this); }
  
  protected Notation getNotationImpl() { return new NotationImpl(this.name, this.externalID); }
  
  static class NotationImpl extends TXNotation implements Notation {
    NotationImpl(String param1String, ExternalID param1ExternalID) { super(param1String, param1ExternalID); }
    
    public Node getParentNode() { return null; }
    
    public Node cloneNode(boolean param1Boolean) {
      checkFactory();
      NotationImpl notationImpl = (NotationImpl)this.factory.createNotation(this.name, this.externalID).getNotationImpl();
      notationImpl.setFactory(getFactory());
      return notationImpl;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TXNotation.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */