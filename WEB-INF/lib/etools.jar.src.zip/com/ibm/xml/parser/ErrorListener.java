package com.ibm.xml.parser;

public interface ErrorListener {
  int error(String paramString1, int paramInt1, int paramInt2, Object paramObject, String paramString2);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\ErrorListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */