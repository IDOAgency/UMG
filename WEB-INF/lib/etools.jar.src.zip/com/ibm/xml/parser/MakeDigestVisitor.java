package com.ibm.xml.parser;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.security.MessageDigest;
import java.util.Hashtable;
import java.util.Vector;
import org.w3c.dom.Node;

public class MakeDigestVisitor extends NOOPVisitor implements Visitor {
  protected MessageDigest messageDigest;
  
  public MakeDigestVisitor(MessageDigest paramMessageDigest) { this.messageDigest = paramMessageDigest; }
  
  public void visitElementPre(TXElement paramTXElement) throws Exception {
    if (paramTXElement.getVisitorDigest() != null)
      throw new ToNextSiblingTraversalException(); 
  }
  
  public void visitElementPost(TXElement paramTXElement) throws Exception {
    if (paramTXElement.getVisitorDigest() == null)
      synchronized (paramTXElement) {
        try {
          ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
          DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
          dataOutputStream.writeInt(1);
          dataOutputStream.write(getExpandedName(paramTXElement).getBytes("UnicodeBigUnmarked"));
          dataOutputStream.write(0);
          dataOutputStream.write(0);
          if (paramTXElement.attributes == null) {
            dataOutputStream.writeInt(0);
          } else {
            int i = paramTXElement.attributes.getLength();
            byte b1 = 0;
            Hashtable hashtable = new Hashtable(i);
            String[] arrayOfString = new String[i];
            for (byte b2 = 0; b2 < i; b2++) {
              Node node = paramTXElement.attributes.item(b2);
              String str = node.getNodeName();
              if (!str.equals("xmlns") && !str.startsWith("xmlns:")) {
                String str1 = getExpandedName(node);
                hashtable.put(str1, str);
                arrayOfString[b1++] = str1;
              } 
            } 
            dataOutputStream.writeInt(b1);
            Util.heapSort(arrayOfString, b1);
            for (byte b3 = 0; b3 < b1; b3++) {
              this.messageDigest.reset();
              TXAttribute tXAttribute = (TXAttribute)paramTXElement.getAttributeNode((String)hashtable.get(arrayOfString[b3]));
              visitAttributePre(tXAttribute);
              dataOutputStream.write(tXAttribute.getVisitorDigest());
            } 
          } 
          Vector vector = new Vector();
          StringBuffer stringBuffer = new StringBuffer();
          for (Child child = (Child)paramTXElement.getFirstWithoutReference(); child != null; child = (Child)child.getNextWithoutReference()) {
            byte[] arrayOfByte = child.getVisitorDigest();
            if (child instanceof org.w3c.dom.Text) {
              stringBuffer.append(child.getNodeValue());
              while (child.getNextWithoutReference() != null && child.getNextWithoutReference() instanceof org.w3c.dom.Text) {
                child = (Child)child.getNextWithoutReference();
                arrayOfByte = child.getVisitorDigest();
                stringBuffer.append(child.getNodeValue());
              } 
              if (stringBuffer.length() > 0) {
                TXText tXText = new TXText(stringBuffer.toString());
                this.messageDigest.reset();
                visitTextPre(tXText);
                arrayOfByte = tXText.getVisitorDigest();
              } 
              stringBuffer.setLength(0);
            } 
            if (child.getNodeType() != 8)
              vector.addElement(arrayOfByte); 
          } 
          dataOutputStream.writeInt(vector.size());
          for (byte b = 0; b < vector.size(); b++)
            dataOutputStream.write((byte[])vector.elementAt(b)); 
          dataOutputStream.close();
          this.messageDigest.reset();
          paramTXElement.setVisitorDigest(this.messageDigest.digest(byteArrayOutputStream.toByteArray()));
        } catch (Exception exception) {
          throw new LibraryException("com.ibm.xml.parser.MakeDigestVisitor#visitElementPost(): " + exception.toString());
        } 
        return;
      }  
  }
  
  public void visitAttributePre(TXAttribute paramTXAttribute) throws Exception {
    if (paramTXAttribute.getVisitorDigest() == null) {
      String str = paramTXAttribute.getNodeName();
      if (str.equals("xmlns") || str.startsWith("xmlns:"))
        return; 
      synchronized (paramTXAttribute) {
        try {
          this.messageDigest.reset();
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)2);
          this.messageDigest.update(getExpandedName(paramTXAttribute).getBytes("UnicodeBigUnmarked"));
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)0);
          paramTXAttribute.setVisitorDigest(this.messageDigest.digest(paramTXAttribute.getValue().getBytes("UnicodeBigUnmarked")));
        } catch (Exception exception) {
          throw new LibraryException("com.ibm.xml.parser.MakeDigestVisitor#visitAttributePre(): " + exception.toString());
        } 
        return;
      } 
    } 
  }
  
  public void visitPIPre(TXPI paramTXPI) throws Exception {
    if (paramTXPI.getVisitorDigest() == null)
      synchronized (paramTXPI) {
        try {
          this.messageDigest.reset();
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)7);
          this.messageDigest.update(paramTXPI.getNodeName().getBytes("UnicodeBigUnmarked"));
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)0);
          paramTXPI.setVisitorDigest(this.messageDigest.digest(paramTXPI.getData().getBytes("UnicodeBigUnmarked")));
        } catch (Exception exception) {
          throw new LibraryException("com.ibm.xml.parser.MakeDigestVisitor#visitPIPre(): " + exception.toString());
        } 
        return;
      }  
  }
  
  public void visitCommentPre(TXComment paramTXComment) throws Exception {
    if (paramTXComment.getVisitorDigest() == null)
      synchronized (paramTXComment) {
        try {
          this.messageDigest.reset();
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)8);
          paramTXComment.setVisitorDigest(this.messageDigest.digest(paramTXComment.getData().getBytes("UnicodeBigUnmarked")));
        } catch (Exception exception) {
          throw new LibraryException("com.ibm.xml.parser.MakeDigestVisitor#visitCommentPre(): " + exception.toString());
        } 
        return;
      }  
  }
  
  public void visitTextPre(TXText paramTXText) throws Exception {
    if (paramTXText.getVisitorDigest() == null)
      synchronized (paramTXText) {
        try {
          this.messageDigest.reset();
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)0);
          this.messageDigest.update((byte)3);
          paramTXText.setVisitorDigest(this.messageDigest.digest(paramTXText.getData().getBytes("UnicodeBigUnmarked")));
        } catch (Exception exception) {
          throw new LibraryException("com.ibm.xml.parser.MakeDigestVisitor#visitTextPre(): " + exception.toString());
        } 
        return;
      }  
  }
  
  public void visitGeneralReferencePre(GeneralReference paramGeneralReference) throws Exception {}
  
  public static String getExpandedName(Node paramNode) {
    String str = null;
    if (paramNode.getNodeType() == 1) {
      TXDocument tXDocument = (TXDocument)paramNode.getOwnerDocument();
      synchronized (tXDocument) {
        String str1 = tXDocument.expandedNameSeparator;
        tXDocument.expandedNameSeparator = ":";
        str = ((TXElement)paramNode).createExpandedName();
        tXDocument.expandedNameSeparator = str1;
      } 
    } else if (paramNode.getNodeType() == 2) {
      String str1 = paramNode.getNodeName();
      int i = str1.indexOf(':');
      if (i < 0) {
        str = str1;
      } else {
        str = String.valueOf(((TXAttribute)paramNode).getNSName()) + ":" + ((TXAttribute)paramNode).getNSLocalName();
      } 
    } else {
      throw new LibraryException("com.ibm.xml.parser.MakeDigestVisitor#getExpandedName(): Unsupported node type: " + paramNode.getNodeType());
    } 
    if (str != null)
      str = str.intern(); 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\MakeDigestVisitor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */