package com.ibm.xml.parser;

public class EndTraversalException extends TreeTraversalException {
  public EndTraversalException() {}
  
  public EndTraversalException(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\EndTraversalException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */