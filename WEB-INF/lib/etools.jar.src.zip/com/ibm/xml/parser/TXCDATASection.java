package com.ibm.xml.parser;

import org.w3c.dom.CDATASection;
import org.w3c.dom.Node;

public class TXCDATASection extends TXText implements CDATASection {
  static final long serialVersionUID = 8068656725170937194L;
  
  public TXCDATASection(String paramString) { super(paramString); }
  
  public Object clone() {
    checkFactory();
    TXCDATASection tXCDATASection = (TXCDATASection)this.factory.createCDATASection(getText());
    tXCDATASection.setFactory(getFactory());
    return tXCDATASection;
  }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (paramNode == null)
      return false; 
    if (!(paramNode instanceof CDATASection))
      return false; 
    CDATASection cDATASection = (CDATASection)paramNode;
    return getData().equals(cDATASection.getData());
  }
  
  public short getNodeType() { return 4; }
  
  public String getNodeName() { return "#cdata-section"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TXCDATASection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */