package com.ibm.xml.parser;

import org.w3c.dom.DOMException;
import org.w3c.dom.EntityReference;
import org.w3c.dom.Node;

public class GeneralReference extends Parent implements EntityReference {
  static final long serialVersionUID = 3555190050476479048L;
  
  private String name;
  
  public GeneralReference(String paramString) { this.name = paramString; }
  
  public Object clone() { return cloneNode(true); }
  
  public Node cloneNode(boolean paramBoolean) {
    checkFactory();
    GeneralReference generalReference = (GeneralReference)this.factory.createEntityReference(getName());
    if (paramBoolean) {
      generalReference.children.ensureCapacity(this.children.getLength());
      for (byte b = 0; b < this.children.getLength(); b++)
        generalReference.appendChild(this.children.item(b).cloneNode(true)); 
    } 
    return generalReference;
  }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (paramNode == null)
      return false; 
    if (!(paramNode instanceof GeneralReference))
      return false; 
    GeneralReference generalReference = (GeneralReference)paramNode;
    return !generalReference.getName().equals(getName()) ? false : (!(paramBoolean && !generalReference.children.equals(this.children, paramBoolean)));
  }
  
  public short getNodeType() { return 5; }
  
  public String getNodeName() { return getName(); }
  
  public String getName() { return this.name; }
  
  public String getLanguage() { return (this.parent == null) ? null : ((this.parent instanceof TXElement) ? ((TXElement)this.parent).getLanguage() : ((this.parent instanceof GeneralReference) ? ((GeneralReference)this.parent).getLanguage() : null)); }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitGeneralReferencePre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitGeneralReferencePost(this); }
  
  protected void checkChildType(Node paramNode) throws DOMException {
    switch (paramNode.getNodeType()) {
      default:
        throw new TXDOMException((short)3, "Specified node type (" + paramNode.getNodeType() + ") can't be a child of EntityReference.");
      case 1:
      case 3:
      case 4:
      case 5:
      case 7:
      case 8:
      case 23:
        break;
    } 
  }
  
  public void collectNamespaceAttributes() { collectNamespaceAttributes(getParentNode()); }
  
  public void collectNamespaceAttributes(Node paramNode) throws DOMException {
    if (!getFactory().isProcessNamespace())
      return; 
    for (Node node = getFirstWithoutReference(); node != null; node = ((Child)node).getNextWithoutReference()) {
      if (node.getNodeType() == 1)
        ((TXElement)node).collectNamespaceAttributes(paramNode); 
    } 
  }
  
  public void removeOverlappedNamespaceAttributes() {
    if (!getFactory().isProcessNamespace())
      return; 
    for (Node node = getFirstWithoutReference(); node != null; node = ((Child)node).getNextWithoutReference()) {
      if (node.getNodeType() == 1)
        ((TXElement)node).removeOverlappedNamespaceAttributes(); 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\GeneralReference.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */