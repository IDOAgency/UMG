package com.ibm.xml.parser;

import java.util.Enumeration;
import java.util.Vector;
import org.w3c.dom.Node;

public class AttDef extends Child {
  static final long serialVersionUID = 3041229546206616963L;
  
  public static final int CDATA = 1;
  
  public static final int ID = 2;
  
  public static final int IDREF = 3;
  
  public static final int IDREFS = 4;
  
  public static final int ENTITY = 5;
  
  public static final int ENTITIES = 6;
  
  public static final int NMTOKEN = 7;
  
  public static final int NMTOKENS = 8;
  
  public static final int NOTATION = 9;
  
  public static final int NAME_TOKEN_GROUP = 10;
  
  public static final String[] S_TYPESTR = { 
      "*UNKNOWN*", "CDATA", "ID", "IDREF", "IDREFS", "ENTITY", "ENTITIES", "NMTOKEN", "NMTOKENS", "NOTATION", 
      "ENUMERATION" };
  
  public static final int FIXED = 1;
  
  public static final int REQUIRED = 2;
  
  public static final int IMPLIED = 3;
  
  public static final int NOFIXED = -1;
  
  public static final int UNKNOWN = 0;
  
  String name;
  
  int declaredValueType = 0;
  
  String value;
  
  Vector tokens;
  
  int defaultValueType = -1;
  
  public AttDef(String paramString) { this.name = paramString; }
  
  public Object clone() {
    checkFactory();
    AttDef attDef = this.factory.createAttDef(this.name);
    attDef.setFactory(getFactory());
    attDef.value = this.value;
    attDef.defaultValueType = this.defaultValueType;
    attDef.declaredValueType = this.declaredValueType;
    if (this.tokens != null)
      attDef.tokens = (Vector)this.tokens.clone(); 
    return attDef;
  }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (paramNode.getNodeType() != 22)
      return false; 
    AttDef attDef = (AttDef)paramNode;
    if (!attDef.getName().equals(getName()))
      return false; 
    if (attDef.getDefaultType() != this.defaultValueType)
      return false; 
    if (attDef.getDeclaredType() != this.declaredValueType)
      return false; 
    if ((attDef.getDefaultStringValue() != null || this.value != null) && (this.value == null || !this.value.equals(attDef.getDefaultStringValue())))
      return false; 
    if (attDef.size() == 0 && size() == 0)
      return true; 
    if (attDef.size() != size())
      return false; 
    for (byte b = 0; b < attDef.size(); b++) {
      String str = attDef.elementAt(b);
      if (!str.equals(elementAt(b)))
        return false; 
    } 
    return true;
  }
  
  public short getNodeType() { return 22; }
  
  public String getNodeName() { return "#attribute-definition"; }
  
  public String getName() { return this.name; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public int getDeclaredType() { return this.declaredValueType; }
  
  public void setDeclaredType(int paramInt) { this.declaredValueType = paramInt; }
  
  public String getDefaultStringValue() { return this.value; }
  
  public void setDefaultStringValue(String paramString) { this.value = TXAttribute.normalize(getDeclaredType(), paramString); }
  
  public boolean addElement(String paramString) {
    if (this.tokens == null)
      this.tokens = new Vector(); 
    if (this.tokens.indexOf(paramString) >= 0)
      return false; 
    this.tokens.addElement(paramString);
    return true;
  }
  
  public String elementAt(int paramInt) { return (this.tokens == null) ? null : (String)this.tokens.elementAt(paramInt); }
  
  public boolean contains(String paramString) { return (this.tokens == null) ? false : (!(this.tokens.indexOf(paramString) < 0)); }
  
  public int size() { return (this.tokens == null) ? 0 : this.tokens.size(); }
  
  public Enumeration elements() { return (this.tokens == null) ? null : this.tokens.elements(); }
  
  public int getDefaultType() { return this.defaultValueType; }
  
  public void setDefaultType(int paramInt) { this.defaultValueType = paramInt; }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitAttDefPre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitAttDefPost(this); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\AttDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */