package com.ibm.xml.parser;

import java.io.StringWriter;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;

public class TXAttribute extends Parent implements Attr, Namespace {
  static final long serialVersionUID = 710791704404680525L;
  
  String name;
  
  String value;
  
  int type = 0;
  
  String[] typedValue;
  
  boolean specified = false;
  
  public TXAttribute(String paramString1, String paramString2) {
    this.name = paramString1;
    this.value = paramString2;
    this.specified = true;
  }
  
  public Object clone() { return cloneNode(true); }
  
  public Node cloneNode(boolean paramBoolean) {
    checkFactory();
    TXAttribute tXAttribute = (TXAttribute)this.factory.createAttribute(this.name);
    tXAttribute.setFactory(getFactory());
    if (paramBoolean) {
      tXAttribute.children.ensureCapacity(this.children.getLength());
      for (byte b = 0; b < this.children.getLength(); b++)
        tXAttribute.insertBefore(this.children.item(b).cloneNode(true), null); 
    } 
    tXAttribute.setType(getType(), getTypedValue());
    tXAttribute.setSpecified(getSpecified());
    return tXAttribute;
  }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (paramNode == null)
      return false; 
    if (!(paramNode instanceof TXAttribute))
      return false; 
    TXAttribute tXAttribute = (TXAttribute)paramNode;
    return !tXAttribute.getName().equals(getName()) ? false : (!tXAttribute.getValue().equals(getValue()) ? false : (!(paramBoolean && !tXAttribute.children.equals(this.children, paramBoolean))));
  }
  
  public short getNodeType() { return 2; }
  
  public String getNodeName() { return this.name; }
  
  public String getName() { return this.name; }
  
  public String getValue() {
    if (this.value != null)
      return this.value; 
    this.value = getText();
    return this.value;
  }
  
  public String getNodeValue() { return getValue(); }
  
  public String toString() { return getValue(); }
  
  public void setValue(String paramString) { setNodeValue(paramString); }
  
  public void setNodeValue(String paramString) {
    this.value = paramString;
    if (paramString != null)
      synchronized (this.children) {
        while (getFirstChild() != null)
          removeChild(getFirstChild()); 
        checkFactory();
        appendChild(this.factory.createAttributeValue(paramString));
      }  
    clearDigest();
  }
  
  protected void realInsert(Node paramNode, int paramInt) throws LibraryException {
    if (!(paramNode instanceof org.w3c.dom.Text) && !(paramNode instanceof org.w3c.dom.EntityReference))
      throw new TXDOMException((short)3, "com.ibm.xml.parser.TXAttribute#realInsert(): Nodes except Text/EntityReference are not allowed as attribute children."); 
    super.realInsert(paramNode, paramInt);
    this.value = null;
  }
  
  public Node replaceChild(Node paramNode1, Node paramNode2) throws DOMException {
    if (!(paramNode1 instanceof org.w3c.dom.Text) && !(paramNode1 instanceof org.w3c.dom.EntityReference))
      throw new TXDOMException((short)3, "com.ibm.xml.parser.TXAttribute#realInsert(): Nodes except Text/EntityReference are not allowed as attribute children."); 
    this.value = null;
    return super.replaceChild(paramNode1, paramNode2);
  }
  
  public Node removeChild(Node paramNode) throws DOMException {
    this.value = null;
    return super.removeChild(paramNode);
  }
  
  public boolean getSpecified() { return this.specified; }
  
  public void setSpecified(boolean paramBoolean) { this.specified = paramBoolean; }
  
  public String getNSLocalName() { return TXElement.getLocalNameForQName(getNodeName()); }
  
  public String getNSName() {
    Node node = this.parent;
    if (node == null);
    return (getNodeName().indexOf(':') < 0) ? null : ((TXElement)node).getNamespaceForQName(getNodeName());
  }
  
  public String getUniversalName() { return (getNSName() == null) ? getNSLocalName() : (String.valueOf(getNSName()) + ":" + getNSLocalName()); }
  
  public String createExpandedName() {
    if ("xmlns".equals(getNodeName()))
      return "xmlns"; 
    String str = getNSName();
    return (str == null || str.length() == 0) ? (String.valueOf(((TXElement)this.parent).createExpandedName()) + (getFactory()).expandedNameSeparator + getNodeName()) : (String.valueOf(str) + (getFactory()).expandedNameSeparator + getNSLocalName());
  }
  
  public int getType() { return this.type; }
  
  public String[] getTypedValue() { return this.typedValue; }
  
  public void setType(int paramInt, String[] paramArrayOfString) {
    this.type = paramInt;
    this.typedValue = paramArrayOfString;
    this.value = normalize(paramInt, getValue());
  }
  
  public String toXMLString(String paramString) {
    String str = null;
    try {
      StringWriter stringWriter = new StringWriter();
      ToXMLStringVisitor toXMLStringVisitor = new ToXMLStringVisitor(stringWriter, paramString);
      (new NonRecursivePreorderTreeTraversal(toXMLStringVisitor)).traverse(this);
      str = stringWriter.toString();
    } catch (Exception exception) {}
    return str;
  }
  
  public String toXMLString() { return toXMLString(null); }
  
  public boolean equals(Object paramObject) { return (paramObject == null) ? false : ((paramObject instanceof Attr) ? getName().equals(((Attr)paramObject).getName()) : ((paramObject instanceof String) ? getName().equals((String)paramObject) : 0)); }
  
  public int hashCode() { return getName().hashCode(); }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitAttributePre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitAttributePost(this); }
  
  public Node getOwnerElement() { return this.parent; }
  
  public Node getParentNode() { return null; }
  
  public Node getPreviousSibling() { return null; }
  
  public Node getNextSibling() { return null; }
  
  static String normalize(int paramInt, String paramString) {
    if (paramInt == 0 || paramInt == 1)
      return paramString; 
    paramString = paramString.trim();
    StringBuffer stringBuffer = new StringBuffer(paramString.length());
    boolean bool = false;
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if (c == ' ') {
        if (!bool)
          stringBuffer.append(c); 
        bool = true;
      } else {
        bool = false;
        stringBuffer.append(c);
      } 
    } 
    return stringBuffer.toString();
  }
  
  protected void checkChildType(Node paramNode) throws DOMException {
    switch (paramNode.getNodeType()) {
      default:
        throw new TXDOMException((short)3, "Specified node type (" + paramNode.getNodeType() + ") can't be a child of Attribute.");
      case 3:
      case 5:
      case 23:
        break;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TXAttribute.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */