package com.ibm.xml.parser;

public interface Visitor {
  void visitDocumentFragmentPre(TXDocumentFragment paramTXDocumentFragment) throws Exception;
  
  void visitDocumentFragmentPost(TXDocumentFragment paramTXDocumentFragment) throws Exception;
  
  void visitDocumentPre(TXDocument paramTXDocument) throws Exception;
  
  void visitDocumentPost(TXDocument paramTXDocument) throws Exception;
  
  void visitElementPre(TXElement paramTXElement) throws Exception;
  
  void visitElementPost(TXElement paramTXElement) throws Exception;
  
  void visitAttributePre(TXAttribute paramTXAttribute) throws Exception;
  
  void visitAttributePost(TXAttribute paramTXAttribute) throws Exception;
  
  void visitPIPre(TXPI paramTXPI) throws Exception;
  
  void visitPIPost(TXPI paramTXPI) throws Exception;
  
  void visitCommentPre(TXComment paramTXComment) throws Exception;
  
  void visitCommentPost(TXComment paramTXComment) throws Exception;
  
  void visitTextPre(TXText paramTXText) throws Exception;
  
  void visitTextPost(TXText paramTXText) throws Exception;
  
  void visitDTDPre(DTD paramDTD) throws Exception;
  
  void visitDTDPost(DTD paramDTD) throws Exception;
  
  void visitElementDeclPre(ElementDecl paramElementDecl) throws Exception;
  
  void visitElementDeclPost(ElementDecl paramElementDecl) throws Exception;
  
  void visitAttlistPre(Attlist paramAttlist) throws Exception;
  
  void visitAttlistPost(Attlist paramAttlist) throws Exception;
  
  void visitAttDefPre(AttDef paramAttDef) throws Exception;
  
  void visitAttDefPost(AttDef paramAttDef) throws Exception;
  
  void visitEntityDeclPre(EntityDecl paramEntityDecl) throws Exception;
  
  void visitEntityDeclPost(EntityDecl paramEntityDecl) throws Exception;
  
  void visitNotationPre(TXNotation paramTXNotation) throws Exception;
  
  void visitNotationPost(TXNotation paramTXNotation) throws Exception;
  
  void visitGeneralReferencePre(GeneralReference paramGeneralReference) throws Exception;
  
  void visitGeneralReferencePost(GeneralReference paramGeneralReference) throws Exception;
  
  void visitPseudoNodePre(PseudoNode paramPseudoNode) throws Exception;
  
  void visitPseudoNodePost(PseudoNode paramPseudoNode) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\Visitor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */