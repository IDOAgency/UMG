package com.ibm.xml.parser;

public class NOOPVisitor implements Visitor {
  public void visitDocumentFragmentPre(TXDocumentFragment paramTXDocumentFragment) throws Exception {}
  
  public void visitDocumentFragmentPost(TXDocumentFragment paramTXDocumentFragment) throws Exception {}
  
  public void visitDocumentPre(TXDocument paramTXDocument) throws Exception {}
  
  public void visitDocumentPost(TXDocument paramTXDocument) throws Exception {}
  
  public void visitElementPre(TXElement paramTXElement) throws Exception {}
  
  public void visitElementPost(TXElement paramTXElement) throws Exception {}
  
  public void visitAttributePre(TXAttribute paramTXAttribute) throws Exception {}
  
  public void visitAttributePost(TXAttribute paramTXAttribute) throws Exception {}
  
  public void visitPIPre(TXPI paramTXPI) throws Exception {}
  
  public void visitPIPost(TXPI paramTXPI) throws Exception {}
  
  public void visitCommentPre(TXComment paramTXComment) throws Exception {}
  
  public void visitCommentPost(TXComment paramTXComment) throws Exception {}
  
  public void visitTextPre(TXText paramTXText) throws Exception {}
  
  public void visitTextPost(TXText paramTXText) throws Exception {}
  
  public void visitDTDPre(DTD paramDTD) throws Exception {}
  
  public void visitDTDPost(DTD paramDTD) throws Exception {}
  
  public void visitElementDeclPre(ElementDecl paramElementDecl) throws Exception {}
  
  public void visitElementDeclPost(ElementDecl paramElementDecl) throws Exception {}
  
  public void visitAttlistPre(Attlist paramAttlist) throws Exception {}
  
  public void visitAttlistPost(Attlist paramAttlist) throws Exception {}
  
  public void visitAttDefPre(AttDef paramAttDef) throws Exception {}
  
  public void visitAttDefPost(AttDef paramAttDef) throws Exception {}
  
  public void visitEntityDeclPre(EntityDecl paramEntityDecl) throws Exception {}
  
  public void visitEntityDeclPost(EntityDecl paramEntityDecl) throws Exception {}
  
  public void visitNotationPre(TXNotation paramTXNotation) throws Exception {}
  
  public void visitNotationPost(TXNotation paramTXNotation) throws Exception {}
  
  public void visitGeneralReferencePre(GeneralReference paramGeneralReference) throws Exception {}
  
  public void visitGeneralReferencePost(GeneralReference paramGeneralReference) throws Exception {}
  
  public void visitPseudoNodePre(PseudoNode paramPseudoNode) throws Exception {}
  
  public void visitPseudoNodePost(PseudoNode paramPseudoNode) throws Exception {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\NOOPVisitor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */