package com.ibm.xml.parser;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;
import java.util.Stack;
import java.util.StringTokenizer;

public class Stderr implements ErrorListener, StreamProducer {
  private static final boolean DEBUG_ENTITY_RESOLUTION = false;
  
  public static PrintWriter printer = new PrintWriter(System.err);
  
  protected String name;
  
  protected URL url;
  
  protected Stack stack = new Stack();
  
  protected Hashtable catalog;
  
  protected boolean isPrintWarning = true;
  
  protected String publicId;
  
  protected String systemId;
  
  public Stderr(String paramString) {
    this.name = paramString;
    try {
      this.url = new URL(this.name);
      this.systemId = this.url.toString();
      return;
    } catch (MalformedURLException malformedURLException) {
      try {
        this.url = file2URL(paramString);
        this.systemId = this.url.toString();
        return;
      } catch (MalformedURLException malformedURLException1) {
        throw new LibraryException("Stderr#Stderr(): Internal Error: " + malformedURLException);
      } catch (SecurityException securityException) {
        printer.println("Specify a complete URL");
        return;
      } 
    } 
  }
  
  public void setPrintWarning(boolean paramBoolean) { this.isPrintWarning = paramBoolean; }
  
  public static URL file2URL(String paramString) throws MalformedURLException {
    String str = (paramString = paramString.replace(File.separatorChar, '/')).valueOf(System.getProperty("user.dir").replace(File.separatorChar, '/')) + "/";
    if (str.charAt(0) != '/')
      str = "/" + str; 
    URL uRL = new URL("file", "", str);
    if (paramString.length() >= 2 && paramString.charAt(1) == ':') {
      char c = Character.toUpperCase(paramString.charAt(0));
      if (c >= 'A' && c <= 'Z')
        paramString = "file:///" + paramString; 
    } 
    return new URL(uRL, paramString);
  }
  
  public int error(String paramString1, int paramInt1, int paramInt2, Object paramObject, String paramString2) {
    if (paramString1 == null)
      paramString1 = this.name; 
    if (paramInt2 > 0)
      paramInt2--; 
    if (this.isPrintWarning || !(paramObject instanceof String) || !((String)paramObject).startsWith("W_"))
      printer.println(String.valueOf(paramString1) + ": " + paramInt1 + ", " + paramInt2 + ": " + paramString2); 
    printer.flush();
    return 1;
  }
  
  private String URI2URL(String paramString) throws IOException {
    if (paramString.length() > 4 && paramString.substring(0, 4).equalsIgnoreCase("urn:")) {
      String str = Util.normalizeURN(paramString);
      if (this.catalog != null && this.catalog.containsKey(str)) {
        paramString = (String)this.catalog.get(str);
      } else {
        throw new IOException("Can't resolve URN: " + paramString);
      } 
    } 
    return paramString;
  }
  
  public Source getInputStream(String paramString1, String paramString2, String paramString3) throws IOException {
    this.publicId = paramString2;
    if (paramString2 != null && this.catalog != null && this.catalog.containsKey(paramString2)) {
      String str = (String)this.catalog.get(paramString2);
      str = URI2URL(str);
      URL uRL1 = new URL(this.url, str);
      try {
        Source source = new Source(uRL1.openStream());
        this.stack.push(this.url);
        this.url = uRL1;
        this.systemId = str;
        return source;
      } catch (IOException iOException) {}
    } 
    paramString3 = URI2URL(paramString3);
    URL uRL = new URL(this.url, paramString3);
    this.stack.push(this.url);
    this.url = uRL;
    this.systemId = paramString3;
    return new Source(uRL.openStream());
  }
  
  public void closeInputStream(Source paramSource) {
    if (!this.stack.empty())
      this.url = (URL)this.stack.pop(); 
  }
  
  public void loadCatalog(Reader paramReader) throws IOException {
    if (this.catalog == null)
      this.catalog = new Hashtable(); 
    BufferedReader bufferedReader = new BufferedReader(paramReader);
    String str;
    while ((str = bufferedReader.readLine()) != null) {
      StringTokenizer stringTokenizer = new StringTokenizer(str, "\t");
      if (stringTokenizer.hasMoreTokens()) {
        String str1 = stringTokenizer.nextToken();
        if (stringTokenizer.hasMoreTokens()) {
          String str2 = stringTokenizer.nextToken();
          if (str1.length() > 4 && str1.substring(0, 4).equalsIgnoreCase("urn:")) {
            this.catalog.put(Util.normalizeURN(str1), str2);
            continue;
          } 
          this.catalog.put(str1, str2);
        } 
      } 
    } 
  }
  
  public String getPublicId() { return this.publicId; }
  
  public String getSystemId() { return this.systemId; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\Stderr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */