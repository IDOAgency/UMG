package com.ibm.xml.parser;

import org.w3c.dom.DOMException;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Node;

public class TXDocumentFragment extends Parent implements DocumentFragment {
  static final long serialVersionUID = 6444589823666718310L;
  
  public Object clone() { return cloneNode(true); }
  
  public Node cloneNode(boolean paramBoolean) {
    checkFactory();
    TXDocumentFragment tXDocumentFragment = (TXDocumentFragment)getOwnerDocument().createDocumentFragment();
    tXDocumentFragment.setFactory(getFactory());
    if (paramBoolean) {
      tXDocumentFragment.children.ensureCapacity(this.children.getLength());
      for (byte b = 0; b < this.children.getLength(); b++)
        tXDocumentFragment.appendChild(this.children.item(b).cloneNode(true)); 
    } 
    return tXDocumentFragment;
  }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (!(paramNode instanceof TXDocumentFragment))
      return false; 
    TXDocumentFragment tXDocumentFragment = (TXDocumentFragment)paramNode;
    return !(paramBoolean && !tXDocumentFragment.children.equals(this.children, paramBoolean));
  }
  
  public short getNodeType() { return 11; }
  
  public String getNodeName() { return "#document-fragment"; }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitDocumentFragmentPre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitDocumentFragmentPost(this); }
  
  protected void checkChildType(Node paramNode) throws DOMException {
    switch (paramNode.getNodeType()) {
      default:
        throw new TXDOMException((short)3, "Specified node type (" + paramNode.getNodeType() + ") can't be a child of DocumentFragment.");
      case 1:
      case 3:
      case 4:
      case 5:
      case 7:
      case 8:
      case 23:
        break;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TXDocumentFragment.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */