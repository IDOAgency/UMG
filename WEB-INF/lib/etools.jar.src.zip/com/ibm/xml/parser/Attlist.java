package com.ibm.xml.parser;

import java.util.Enumeration;
import java.util.Vector;
import org.w3c.dom.Node;

public class Attlist extends Child {
  static final long serialVersionUID = -8168631922182992992L;
  
  String name;
  
  Vector attDefs = new Vector();
  
  public Attlist(String paramString) { this.name = paramString; }
  
  public Object clone() {
    checkFactory();
    Attlist attlist = this.factory.createAttlist(this.name);
    attlist.setFactory(getFactory());
    attlist.attDefs.ensureCapacity(size());
    for (byte b = 0; b < size(); b++)
      attlist.addElement((AttDef)((AttDef)this.attDefs.elementAt(b)).clone()); 
    return attlist;
  }
  
  public boolean equals(Node paramNode, boolean paramBoolean) {
    if (paramNode.getNodeType() != getNodeType())
      return false; 
    Attlist attlist = (Attlist)paramNode;
    if (!attlist.getName().equals(getName()))
      return false; 
    if (attlist.size() != size())
      return false; 
    for (byte b = 0; b < attlist.size(); b++) {
      AttDef attDef = attlist.elementAt(b);
      if (!attDef.equals(elementAt(b), true))
        return false; 
    } 
    return true;
  }
  
  public short getNodeType() { return 21; }
  
  public String getNodeName() { return "#attribute-definition-list"; }
  
  public String getName() { return this.name; }
  
  public boolean addElement(AttDef paramAttDef) {
    if (contains(paramAttDef.getName()))
      return false; 
    this.attDefs.addElement(paramAttDef);
    paramAttDef.setParentNode(this);
    return true;
  }
  
  public AttDef elementAt(int paramInt) { return (AttDef)this.attDefs.elementAt(paramInt); }
  
  public AttDef getAttDef(String paramString) {
    for (byte b = 0; b < size(); b++) {
      AttDef attDef = elementAt(b);
      if (paramString.equals(attDef.getName()))
        return attDef; 
    } 
    return null;
  }
  
  public boolean contains(String paramString) { return !(getAttDef(paramString) == null); }
  
  public int size() { return this.attDefs.size(); }
  
  public Enumeration elements() { return this.attDefs.elements(); }
  
  public void acceptPre(Visitor paramVisitor) throws Exception { paramVisitor.visitAttlistPre(this); }
  
  public void acceptPost(Visitor paramVisitor) throws Exception { paramVisitor.visitAttlistPost(this); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\Attlist.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */