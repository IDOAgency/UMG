package com.ibm.xml.parser;

import java.io.Serializable;
import java.util.Vector;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

class TXAttributeList extends Vector implements NamedNodeMap, Cloneable, Serializable {
  static final long serialVersionUID = 8198968721269694477L;
  
  Element parentElement;
  
  public Object clone() {
    TXAttributeList tXAttributeList = new TXAttributeList();
    tXAttributeList.parentElement = this.parentElement;
    for (byte b = 0; b < getLength(); b++)
      tXAttributeList.setNamedItem((Attr)((TXAttribute)item(b)).clone()); 
    return tXAttributeList;
  }
  
  public int indexOf(String paramString) {
    for (byte b = 0; b < size(); b++) {
      TXAttribute tXAttribute = (TXAttribute)elementAt(b);
      if (tXAttribute.getName().equals(paramString))
        return b; 
    } 
    return -1;
  }
  
  public Node getNamedItem(String paramString) {
    int i = indexOf(paramString);
    return (i < 0) ? null : (Node)elementAt(i);
  }
  
  public Node setNamedItem(Node paramNode) throws DOMException {
    if (paramNode.getNodeType() != 2)
      throw new TXDOMException((short)3, "Not Attribute node"); 
    if (this.parentElement.getOwnerDocument() != paramNode.getOwnerDocument())
      throw new TXDOMException((short)4, "Specified child was created from a different document."); 
    TXAttribute tXAttribute = (TXAttribute)paramNode;
    Attr attr = null;
    int i = indexOf(tXAttribute.getNodeName());
    if (i < 0) {
      tXAttribute.setParentNode(this.parentElement);
      addElement(tXAttribute);
    } else {
      attr = (Attr)elementAt(i);
      setElementAt(tXAttribute, i);
      tXAttribute.setParentNode(this.parentElement);
    } 
    if (this.parentElement != null)
      ((Child)this.parentElement).clearDigest(); 
    return attr;
  }
  
  public Node removeNamedItem(String paramString) {
    int i = indexOf(paramString);
    if (i < 0)
      throw new TXDOMException((short)8, "Attribute `" + paramString + "' is not found."); 
    TXAttribute tXAttribute = (TXAttribute)elementAt(i);
    removeElementAt(i);
    tXAttribute.setParentNode(null);
    if (this.parentElement != null)
      ((Child)this.parentElement).clearDigest(); 
    return tXAttribute;
  }
  
  public void clear() { removeAllElements(); }
  
  public Node item(int paramInt) { return (paramInt < 0 || size() <= paramInt) ? null : (Node)elementAt(paramInt); }
  
  public int getLength() { return size(); }
  
  public void setParent(Element paramElement) {
    for (byte b = 0; b < getLength(); b++) {
      TXAttribute tXAttribute = (TXAttribute)item(b);
      tXAttribute.setParentNode(paramElement);
    } 
    this.parentElement = paramElement;
  }
  
  public TXAttribute[] makeArray() {
    TXAttribute[] arrayOfTXAttribute = new TXAttribute[size()];
    copyInto(arrayOfTXAttribute);
    return arrayOfTXAttribute;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\TXAttributeList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */