package com.ibm.xml.parser;

public interface Namespace {
  String getName();
  
  String getNSLocalName();
  
  String getNSName();
  
  String getUniversalName();
  
  String createExpandedName();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\Namespace.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */