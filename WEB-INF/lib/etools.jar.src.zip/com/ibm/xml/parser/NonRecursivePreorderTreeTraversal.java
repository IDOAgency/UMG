package com.ibm.xml.parser;

import org.w3c.dom.Node;

public class NonRecursivePreorderTreeTraversal extends TreeTraversal {
  public NonRecursivePreorderTreeTraversal(Visitor paramVisitor) { super(paramVisitor); }
  
  public void traverse(Node paramNode) throws Exception {
    Node node1 = paramNode;
    Node node2 = null;
    try {
      while (node1 != null) {
        try {
          ((Visitee)node1).acceptPre(getVisitor());
          node2 = node1.getFirstChild();
        } catch (ToNextSiblingTraversalException toNextSiblingTraversalException) {
          node2 = null;
        } 
        if (node2 == null)
          if (node1 != paramNode) {
            node2 = node1.getNextSibling();
            if (node2 != null)
              try {
                ((Visitee)node1).acceptPost(getVisitor());
              } catch (ToNextSiblingTraversalException toNextSiblingTraversalException) {} 
          } else {
            try {
              ((Visitee)node1).acceptPost(getVisitor());
              return;
            } catch (ToNextSiblingTraversalException toNextSiblingTraversalException) {
              return;
            } 
          }  
        while (node2 == null && node1 != null) {
          node2 = node1.getParentNode();
          try {
            ((Visitee)node1).acceptPost(getVisitor());
          } catch (ToNextSiblingTraversalException toNextSiblingTraversalException) {}
          node1 = node2;
          if (node1 != null) {
            if (node1 != paramNode) {
              node2 = node1.getNextSibling();
              if (node2 != null)
                try {
                  ((Visitee)node1).acceptPost(getVisitor());
                  continue;
                } catch (ToNextSiblingTraversalException toNextSiblingTraversalException) {
                  continue;
                }  
              continue;
            } 
            try {
              ((Visitee)node1).acceptPost(getVisitor());
              return;
            } catch (ToNextSiblingTraversalException toNextSiblingTraversalException) {
              return;
            } 
          } 
        } 
        node1 = node2;
      } 
      return;
    } catch (EndTraversalException endTraversalException) {
      return;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parser\NonRecursivePreorderTreeTraversal.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */