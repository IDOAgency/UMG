package com.ibm.xml.dom;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class ElementDefinitionImpl extends NodeImpl {
  protected NamedNodeMapImpl attributes;
  
  protected boolean syncAttrs;
  
  ElementDefinitionImpl(DocumentImpl paramDocumentImpl, int paramInt) {
    super(paramDocumentImpl, paramInt);
    this.syncAttrs = true;
  }
  
  public ElementDefinitionImpl(DocumentImpl paramDocumentImpl, String paramString) {
    super(paramDocumentImpl, paramString, null);
    this.attributes = new NamedNodeMapImpl(paramDocumentImpl, null);
  }
  
  public short getNodeType() { return -1; }
  
  public Node cloneNode(boolean paramBoolean) {
    ElementDefinitionImpl elementDefinitionImpl = (ElementDefinitionImpl)super.cloneNode(paramBoolean);
    elementDefinitionImpl.attributes = this.attributes.cloneMap();
    return elementDefinitionImpl;
  }
  
  public NamedNodeMap getAttributes() {
    if (this.syncAttrs)
      synchronizeAttributes(); 
    return this.attributes;
  }
  
  protected void synchronizeAttributes() {
    this.attributes = new NamedNodeMapImpl(this.ownerDocument, null);
    for (int i = this.ownerDocument.getFirstChild(this.fNodeIndex); i != -1; i = this.ownerDocument.getNextSibling(i)) {
      NodeImpl nodeImpl = this.ownerDocument.getNodeObject(i);
      this.attributes.setNamedItem(nodeImpl);
    } 
    this.syncAttrs = false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\ElementDefinitionImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */