package com.ibm.xml.dom;

import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;

public class ProcessingInstructionImpl extends NodeImpl implements ProcessingInstruction {
  ProcessingInstructionImpl(DocumentImpl paramDocumentImpl, int paramInt) { super(paramDocumentImpl, paramInt); }
  
  public ProcessingInstructionImpl(DocumentImpl paramDocumentImpl, String paramString1, String paramString2) { super(paramDocumentImpl, paramString1, paramString2); }
  
  public short getNodeType() { return 7; }
  
  public Node cloneNode(boolean paramBoolean) { return this.ownerDocument.createProcessingInstruction(this.name, this.value); }
  
  public String getTarget() {
    if (this.syncData)
      synchronizeData(); 
    return this.name;
  }
  
  public String getData() {
    if (this.syncData)
      synchronizeData(); 
    return this.value;
  }
  
  public void setData(String paramString) {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    if (this.syncData)
      synchronizeData(); 
    this.value = paramString;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\ProcessingInstructionImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */