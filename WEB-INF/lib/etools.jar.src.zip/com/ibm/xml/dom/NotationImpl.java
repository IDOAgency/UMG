package com.ibm.xml.dom;

import com.ibm.xml.framework.StringPool;
import org.w3c.dom.DOMException;
import org.w3c.dom.Notation;

public class NotationImpl extends NodeImpl implements Notation {
  protected String publicId;
  
  protected String systemId;
  
  NotationImpl(DocumentImpl paramDocumentImpl, int paramInt) { super(paramDocumentImpl, paramInt); }
  
  public NotationImpl(DocumentImpl paramDocumentImpl, String paramString) { super(paramDocumentImpl, paramString, null); }
  
  public short getNodeType() { return 12; }
  
  public void setNodeValue(String paramString) throws DOMException { throw new DOMExceptionImpl((short)7, null); }
  
  public String getPublicId() {
    if (this.syncData)
      synchronizeData(); 
    return this.publicId;
  }
  
  public String getSystemId() {
    if (this.syncData)
      synchronizeData(); 
    return this.systemId;
  }
  
  public void setPublicId(String paramString) throws DOMException {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    if (this.syncData)
      synchronizeData(); 
    this.publicId = paramString;
  }
  
  public void setSystemId(String paramString) throws DOMException {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    if (this.syncData)
      synchronizeData(); 
    this.systemId = paramString;
  }
  
  protected void synchronizeData() {
    StringPool stringPool = this.ownerDocument.fParserState.getStringPool();
    this.name = this.ownerDocument.getNodeName(this.fNodeIndex);
    int i = this.ownerDocument.getIntNodeValue(this.fNodeIndex);
    this.publicId = stringPool.toString(this.ownerDocument.getFirstChild(i));
    this.systemId = stringPool.toString(this.ownerDocument.getLastChild(i));
    this.syncData = false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\NotationImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */