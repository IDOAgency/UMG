package com.ibm.xml.dom;

import java.util.Vector;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DeepNodeListImpl implements NodeList {
  protected NodeImpl rootNode;
  
  protected String tagName;
  
  protected int changes;
  
  protected Vector nodes;
  
  protected DeepNodeListImpl(NodeImpl paramNodeImpl, String paramString) {
    this.rootNode = paramNodeImpl;
    this.tagName = paramString;
    this.nodes = new Vector();
  }
  
  public int getLength() {
    item(2147483647);
    return this.nodes.size();
  }
  
  public Node item(int paramInt) {
    Node node;
    if (this.rootNode.changes != this.changes) {
      this.nodes = new Vector();
      this.changes = this.rootNode.changes;
    } 
    if (paramInt < this.nodes.size())
      return (Node)this.nodes.elementAt(paramInt); 
    if (this.nodes.size() == 0) {
      node = this.rootNode;
    } else {
      node = (NodeImpl)this.nodes.lastElement();
    } 
    while (node != null && paramInt >= this.nodes.size()) {
      node = nextMatchingElementAfter(node);
      if (node != null)
        this.nodes.addElement(node); 
    } 
    return node;
  }
  
  private Node nextMatchingElementAfter(Node paramNode) {
    while (paramNode != null) {
      if (paramNode.hasChildNodes()) {
        paramNode = paramNode.getFirstChild();
      } else {
        Node node;
        if (paramNode != this.rootNode && (node = paramNode.getNextSibling()) != null) {
          paramNode = node;
        } else {
          node = null;
          while (paramNode != this.rootNode) {
            node = paramNode.getNextSibling();
            if (node == null) {
              paramNode = paramNode.getParentNode();
              continue;
            } 
            break;
          } 
          paramNode = node;
        } 
      } 
      if (paramNode != this.rootNode && paramNode != null && paramNode.getNodeType() == 1 && (this.tagName.equals("*") || ((ElementImpl)paramNode).getTagName().equals(this.tagName)))
        return paramNode; 
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\DeepNodeListImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */