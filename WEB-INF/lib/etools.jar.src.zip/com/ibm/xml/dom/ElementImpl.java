package com.ibm.xml.dom;

import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class ElementImpl extends NodeImpl implements Element {
  protected NamedNodeMapImpl attributes;
  
  ElementImpl(DocumentImpl paramDocumentImpl, int paramInt) {
    super(paramDocumentImpl, paramInt);
    setupDefaultAttributes(paramDocumentImpl);
    for (int i = paramDocumentImpl.getAttributeList(paramInt); i != -1; i = paramDocumentImpl.getNextSibling(i))
      setAttributeNode((Attr)paramDocumentImpl.getNodeObject(i)); 
  }
  
  public ElementImpl(DocumentImpl paramDocumentImpl, String paramString) {
    super(paramDocumentImpl, paramString, null);
    setupDefaultAttributes(paramDocumentImpl);
  }
  
  protected void setupDefaultAttributes(DocumentImpl paramDocumentImpl) {
    NamedNodeMapImpl namedNodeMapImpl = null;
    DocumentTypeImpl documentTypeImpl = (DocumentTypeImpl)paramDocumentImpl.getDoctype();
    if (documentTypeImpl != null) {
      ElementDefinitionImpl elementDefinitionImpl = (ElementDefinitionImpl)documentTypeImpl.getElements().getNamedItem(getNodeName());
      if (elementDefinitionImpl != null)
        namedNodeMapImpl = (NamedNodeMapImpl)elementDefinitionImpl.getAttributes(); 
    } 
    this.attributes = new NamedNodeMapImpl(paramDocumentImpl, namedNodeMapImpl);
  }
  
  public short getNodeType() { return 1; }
  
  public String getNodeValue() { return null; }
  
  public void setNodeValue(String paramString) throws DOMException { throw new DOMExceptionImpl((short)7, null); }
  
  public NamedNodeMap getAttributes() { return this.attributes; }
  
  public Node cloneNode(boolean paramBoolean) {
    ElementImpl elementImpl = (ElementImpl)super.cloneNode(paramBoolean);
    elementImpl.attributes = this.attributes.cloneMap();
    return elementImpl;
  }
  
  public String getValue() { return null; }
  
  public String getAttribute(String paramString) {
    Attr attr = (Attr)this.attributes.getNamedItem(paramString);
    return (attr == null) ? "" : attr.getValue();
  }
  
  public Attr getAttributeNode(String paramString) { return (Attr)this.attributes.getNamedItem(paramString); }
  
  public NodeList getElementsByTagName(String paramString) { return new DeepNodeListImpl(this, paramString); }
  
  public String getTagName() {
    if (this.syncData)
      synchronizeData(); 
    return this.name;
  }
  
  public void normalize() {
    for (Node node = getFirstChild(); node != null; node = node1) {
      Node node1 = node.getNextSibling();
      if (node1 != null && node.getNodeType() == 3 && node1.getNodeType() == 3) {
        ((Text)node).appendData(node1.getNodeValue());
        removeChild(node1);
        node1 = node;
      } else if (node.getNodeType() == 1) {
        ((Element)node).normalize();
      } 
    } 
  }
  
  public void removeAttribute(String paramString) throws DOMException {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    AttrImpl attrImpl = (AttrImpl)this.attributes.getNamedItem(paramString);
    if (attrImpl != null) {
      attrImpl.owned = false;
      this.attributes.removeNamedItem(paramString);
    } 
  }
  
  public Attr removeAttributeNode(Attr paramAttr) throws DOMException {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    AttrImpl attrImpl = (AttrImpl)this.attributes.getNamedItem(paramAttr.getName());
    if (attrImpl == paramAttr) {
      this.attributes.removeNamedItem(paramAttr.getName());
      attrImpl.owned = false;
      return attrImpl;
    } 
    throw new DOMExceptionImpl((short)8, null);
  }
  
  public void setAttribute(String paramString1, String paramString2) {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    AttrImpl attrImpl = (AttrImpl)getOwnerDocument().createAttribute(paramString1);
    attrImpl.setNodeValue(paramString2);
    this.attributes.setNamedItem(attrImpl);
    attrImpl.owned = true;
  }
  
  public Attr setAttributeNode(Attr paramAttr) throws DOMException {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    if (!(paramAttr instanceof AttrImpl))
      throw new DOMExceptionImpl((short)4, null); 
    AttrImpl attrImpl1 = (AttrImpl)paramAttr;
    AttrImpl attrImpl2 = (AttrImpl)this.attributes.getNamedItem(paramAttr.getName());
    this.attributes.setNamedItem(attrImpl1);
    attrImpl1.owned = true;
    return attrImpl2;
  }
  
  public void setReadOnly(boolean paramBoolean1, boolean paramBoolean2) {
    super.setReadOnly(paramBoolean1, paramBoolean2);
    this.attributes.setReadOnly(paramBoolean1, true);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\ElementImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */