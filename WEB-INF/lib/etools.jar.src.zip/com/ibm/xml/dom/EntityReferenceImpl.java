package com.ibm.xml.dom;

import org.w3c.dom.DOMException;
import org.w3c.dom.EntityReference;

public class EntityReferenceImpl extends NodeImpl implements EntityReference {
  protected int entityChanges = -1;
  
  protected boolean fEnableSynchronize = false;
  
  EntityReferenceImpl(DocumentImpl paramDocumentImpl, int paramInt) {
    super(paramDocumentImpl, paramInt);
    this.fEnableSynchronize = false;
  }
  
  public EntityReferenceImpl(DocumentImpl paramDocumentImpl, String paramString) {
    super(paramDocumentImpl, paramString, null);
    this.fEnableSynchronize = false;
  }
  
  public short getNodeType() { return 5; }
  
  public void setNodeValue(String paramString) throws DOMException { throw new DOMExceptionImpl((short)7, null); }
  
  public void setReadOnly(boolean paramBoolean1, boolean paramBoolean2) { super.setReadOnly(paramBoolean1, paramBoolean2); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\EntityReferenceImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */