package com.ibm.xml.dom;

import org.w3c.dom.DOMException;
import org.w3c.dom.DocumentFragment;

public class DocumentFragmentImpl extends NodeImpl implements DocumentFragment {
  DocumentFragmentImpl(DocumentImpl paramDocumentImpl, int paramInt) { super(paramDocumentImpl, paramInt); }
  
  public DocumentFragmentImpl(DocumentImpl paramDocumentImpl) { super(paramDocumentImpl, null, null); }
  
  public short getNodeType() { return 11; }
  
  public String getNodeName() { return "#document-fragment"; }
  
  public void setNodeValue(String paramString) throws DOMException { throw new DOMExceptionImpl((short)7, null); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\DocumentFragmentImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */