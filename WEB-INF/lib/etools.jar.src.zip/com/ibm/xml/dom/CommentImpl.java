package com.ibm.xml.dom;

import org.w3c.dom.Comment;
import org.w3c.dom.Node;

public class CommentImpl extends CharacterDataImpl implements Comment {
  CommentImpl(DocumentImpl paramDocumentImpl, int paramInt) { super(paramDocumentImpl, paramInt); }
  
  public CommentImpl(DocumentImpl paramDocumentImpl, String paramString) { super(paramDocumentImpl, paramString); }
  
  public short getNodeType() { return 8; }
  
  public String getNodeName() { return "#comment"; }
  
  public Node cloneNode(boolean paramBoolean) { return this.ownerDocument.createComment(getNodeValue()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\CommentImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */