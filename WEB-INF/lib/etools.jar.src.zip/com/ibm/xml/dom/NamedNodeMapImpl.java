package com.ibm.xml.dom;

import java.util.Enumeration;
import java.util.Vector;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class NamedNodeMapImpl implements NamedNodeMap {
  protected Vector nodes = new Vector();
  
  protected Document ownerDoc;
  
  protected NamedNodeMapImpl defaults;
  
  protected int changes;
  
  protected int lastDefaultsChanges = -1;
  
  protected boolean readOnly = false;
  
  protected int elementNode = -1;
  
  protected NamedNodeMapImpl(Document paramDocument, NamedNodeMapImpl paramNamedNodeMapImpl) {
    this.ownerDoc = paramDocument;
    this.defaults = paramNamedNodeMapImpl;
  }
  
  public int getLength() {
    reconcileDefaults();
    return (this.nodes != null) ? this.nodes.size() : 0;
  }
  
  public Node item(int paramInt) {
    reconcileDefaults();
    return (this.nodes != null && paramInt < this.nodes.size()) ? (Node)this.nodes.elementAt(paramInt) : null;
  }
  
  public Node getNamedItem(String paramString) {
    int i = findNamePoint(paramString);
    return (i < 0) ? null : (Node)this.nodes.elementAt(i);
  }
  
  public Node setNamedItem(Node paramNode) throws DOMException {
    if (paramNode.getOwnerDocument() != this.ownerDoc)
      throw new DOMExceptionImpl((short)4, null); 
    if (paramNode instanceof AttrImpl && ((AttrImpl)paramNode).owned)
      throw new DOMExceptionImpl((short)10, null); 
    int i = findNamePoint(paramNode.getNodeName());
    Node node = null;
    if (i >= 0) {
      node = (Node)this.nodes.elementAt(i);
      this.nodes.setElementAt(paramNode, i);
    } else {
      i = -1 - i;
      if (this.nodes == null)
        this.nodes = new Vector(); 
      this.nodes.insertElementAt(paramNode, i);
    } 
    this.changes++;
    return node;
  }
  
  public Node removeNamedItem(String paramString) {
    int i = findNamePoint(paramString);
    if (i < 0)
      throw new DOMExceptionImpl((short)8, null); 
    Node node1 = (Node)this.nodes.elementAt(i);
    Node node2;
    if (this.defaults != null && (node2 = this.defaults.getNamedItem(paramString)) != null) {
      this.nodes.setElementAt(node2, i);
    } else {
      this.nodes.removeElementAt(i);
    } 
    this.changes++;
    return node1;
  }
  
  public NamedNodeMapImpl cloneMap() {
    NamedNodeMapImpl namedNodeMapImpl = new NamedNodeMapImpl(this.ownerDoc, this.defaults);
    if (this.nodes != null) {
      namedNodeMapImpl.nodes = new Vector(this.nodes.size());
      for (byte b = 0; b < this.nodes.size(); b++)
        namedNodeMapImpl.nodes.addElement(((NodeImpl)this.nodes.elementAt(b)).cloneNode(true)); 
    } 
    namedNodeMapImpl.defaults = this.defaults;
    return namedNodeMapImpl;
  }
  
  void setReadOnly(boolean paramBoolean1, boolean paramBoolean2) {
    this.readOnly = paramBoolean1;
    if (paramBoolean2 && this.nodes != null) {
      Enumeration enumeration = this.nodes.elements();
      while (enumeration.hasMoreElements())
        ((NodeImpl)enumeration.nextElement()).setReadOnly(paramBoolean1, paramBoolean2); 
    } 
  }
  
  private int findNamePoint(String paramString) {
    reconcileDefaults();
    int i = 0;
    if (this.nodes != null) {
      int j = 0;
      int k = this.nodes.size() - 1;
      while (j <= k) {
        i = (j + k) / 2;
        int m = paramString.compareTo(((Node)this.nodes.elementAt(i)).getNodeName());
        if (m == 0)
          return i; 
        if (m < 0) {
          k = i - 1;
          continue;
        } 
        j = i + 1;
      } 
      if (j > i)
        i = j; 
    } 
    return -1 - i;
  }
  
  protected void reconcileDefaults() {
    if (this.defaults != null && this.lastDefaultsChanges != this.defaults.changes) {
      byte b1 = 0;
      byte b2 = 0;
      int i = this.nodes.size();
      int j = this.defaults.nodes.size();
      Attr attr1 = (i == 0) ? null : (Attr)this.nodes.elementAt(0);
      Attr attr2 = (j == 0) ? null : (Attr)this.defaults.nodes.elementAt(0);
      while (b1 < i && b2 < j) {
        attr1 = (Attr)this.nodes.elementAt(b1);
        attr2 = (Attr)this.defaults.nodes.elementAt(b2);
        int k = attr1.getNodeName().compareTo(attr2.getNodeName());
        if (k == 0 && !attr1.getSpecified()) {
          this.nodes.setElementAt(attr2, b1);
          b1++;
          b2++;
          continue;
        } 
        if (k > 0) {
          this.nodes.insertElementAt(attr2, b1);
          b1++;
          b2++;
          continue;
        } 
        if (!attr1.getSpecified()) {
          this.nodes.removeElementAt(b1);
          continue;
        } 
        b1++;
      } 
      while (b2 < j)
        this.nodes.addElement(this.defaults.nodes.elementAt(b2++)); 
      this.lastDefaultsChanges = this.defaults.changes;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\NamedNodeMapImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */