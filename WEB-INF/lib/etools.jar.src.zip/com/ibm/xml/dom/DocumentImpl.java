package com.ibm.xml.dom;

import com.ibm.xml.framework.AttrPool;
import com.ibm.xml.framework.EntityPool;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.StringPool;
import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.Entity;
import org.w3c.dom.EntityReference;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Notation;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;

public class DocumentImpl extends NodeImpl implements Document {
  private static final boolean DEBUG_PRINT_TABLES = false;
  
  protected static final int CHUNK_SHIFT = 11;
  
  protected static final int CHUNK_SIZE = 2048;
  
  protected static final int CHUNK_MASK = 2047;
  
  protected static final int INITIAL_CHUNK_COUNT = 32;
  
  protected int fNodeCount;
  
  protected byte[][] fNodeType;
  
  protected int[][] fNodeName;
  
  protected int[][] fNodeValue;
  
  protected int[][] fNodeParent;
  
  protected int[][] fNodeFirstChild;
  
  protected int[][] fNodeLastChild;
  
  protected int[][] fNodePrevSib;
  
  protected int[][] fNodeNextSib;
  
  protected DocumentTypeImpl docType;
  
  protected ElementImpl docElement;
  
  protected ParserState fParserState;
  
  protected StringPool fStringPool;
  
  public DocumentImpl() { super(null, null, null); }
  
  public DocumentImpl(ParserState paramParserState) {
    super(null, 0);
    this.fParserState = paramParserState;
    this.fStringPool = paramParserState.getStringPool();
  }
  
  public short getNodeType() { return 9; }
  
  public String getNodeName() { return "#document"; }
  
  public String getNodeValue() { return null; }
  
  public Node cloneNode(boolean paramBoolean) {
    DocumentImpl documentImpl = (this.fNodeIndex == 0) ? new DocumentImpl(this.fParserState) : new DocumentImpl();
    if (paramBoolean)
      for (NodeImpl nodeImpl = (NodeImpl)getFirstChild(); nodeImpl != null; nodeImpl = nodeImpl.nextSibling)
        documentImpl.appendChild(documentImpl.importNode(nodeImpl, true));  
    return documentImpl;
  }
  
  public Node insertBefore(Node paramNode1, Node paramNode2) throws DOMException {
    short s = paramNode1.getNodeType();
    if ((s == 1 && this.docElement != null) || (s == 10 && this.docType != null))
      throw new DOMExceptionImpl((short)3, null); 
    super.insertBefore(paramNode1, paramNode2);
    if (s == 1) {
      this.docElement = (ElementImpl)paramNode1;
    } else if (s == 10) {
      this.docType = (DocumentTypeImpl)paramNode1;
    } 
    return paramNode1;
  }
  
  public Node removeChild(Node paramNode) throws DOMException {
    super.removeChild(paramNode);
    short s = paramNode.getNodeType();
    if (s == 1) {
      this.docElement = null;
    } else if (s == 10) {
      this.docType = null;
    } 
    return paramNode;
  }
  
  public void setNodeValue(String paramString) throws DOMException { throw new DOMExceptionImpl((short)7, null); }
  
  public Attr createAttribute(String paramString) throws DOMException {
    if (!isXMLName(paramString))
      throw new DOMExceptionImpl((short)5, null); 
    return new AttrImpl(this, paramString);
  }
  
  public CDATASection createCDATASection(String paramString) throws DOMException { return new CDATASectionImpl(this, paramString); }
  
  public Comment createComment(String paramString) { return new CommentImpl(this, paramString); }
  
  public DocumentFragment createDocumentFragment() { return new DocumentFragmentImpl(this); }
  
  public Element createElement(String paramString) throws DOMException {
    if (!isXMLName(paramString))
      throw new DOMExceptionImpl((short)5, null); 
    return new ElementImpl(this, paramString);
  }
  
  public EntityReference createEntityReference(String paramString) throws DOMException {
    if (!isXMLName(paramString))
      throw new DOMExceptionImpl((short)5, null); 
    return new EntityReferenceImpl(this, paramString);
  }
  
  public ProcessingInstruction createProcessingInstruction(String paramString1, String paramString2) throws DOMException {
    if (!isXMLName(paramString1))
      throw new DOMExceptionImpl((short)5, null); 
    return new ProcessingInstructionImpl(this, paramString1, paramString2);
  }
  
  public Text createTextNode(String paramString) { return new TextImpl(this, paramString); }
  
  public DocumentType getDoctype() {
    if (this.syncChildren)
      synchronizeChildren(); 
    return this.docType;
  }
  
  public Element getDocumentElement() {
    if (this.syncChildren)
      synchronizeChildren(); 
    return this.docElement;
  }
  
  public NodeList getElementsByTagName(String paramString) { return new DeepNodeListImpl(this, paramString); }
  
  public DOMImplementation getImplementation() { return DOMImplementationImpl.singleton; }
  
  public DocumentType createDocumentType(String paramString) throws DOMException {
    if (!isXMLName(paramString))
      throw new DOMExceptionImpl((short)5, null); 
    return new DocumentTypeImpl(this, paramString);
  }
  
  public Entity createEntity(String paramString) throws DOMException { return new EntityImpl(this, paramString); }
  
  public Notation createNotation(String paramString) throws DOMException { return new NotationImpl(this, paramString); }
  
  public ElementDefinitionImpl createElementDefinition(String paramString) throws DOMException { return new ElementDefinitionImpl(this, paramString); }
  
  public Node importNode(Node paramNode, boolean paramBoolean) throws DOMException {
    NamedNodeMap namedNodeMap3;
    NotationImpl notationImpl;
    EntityImpl entityImpl;
    NamedNodeMap namedNodeMap2;
    NamedNodeMap namedNodeMap1;
    Notation notation;
    Element element;
    Entity entity;
    DocumentTypeImpl documentTypeImpl;
    NodeImpl nodeImpl = null;
    short s = paramNode.getNodeType();
    switch (s) {
      case 1:
        element = createElement(paramNode.getNodeName());
        namedNodeMap2 = paramNode.getAttributes();
        if (namedNodeMap2 != null)
          for (byte b = 0; b < namedNodeMap2.getLength(); b++)
            element.setAttributeNode((AttrImpl)importNode(namedNodeMap2.item(b), true));  
        nodeImpl = (NodeImpl)element;
        break;
      case 2:
        nodeImpl = (NodeImpl)createAttribute(paramNode.getNodeName());
        break;
      case 3:
        nodeImpl = (NodeImpl)createTextNode(paramNode.getNodeValue());
        break;
      case 4:
        nodeImpl = (NodeImpl)createCDATASection(paramNode.getNodeValue());
        break;
      case 5:
        nodeImpl = (NodeImpl)createEntityReference(paramNode.getNodeName());
        paramBoolean = false;
        break;
      case 6:
        entity = (Entity)paramNode;
        entityImpl = (EntityImpl)createEntity(paramNode.getNodeName());
        entityImpl.setPublicId(entity.getPublicId());
        entityImpl.setSystemId(entity.getSystemId());
        entityImpl.setNotationName(entity.getNotationName());
        nodeImpl = entityImpl;
        break;
      case 7:
        nodeImpl = (ProcessingInstructionImpl)createProcessingInstruction(paramNode.getNodeName(), paramNode.getNodeValue());
        break;
      case 8:
        nodeImpl = (NodeImpl)createComment(paramNode.getNodeValue());
        break;
      case 10:
        documentTypeImpl = (DocumentTypeImpl)createDocumentType(paramNode.getNodeName());
        namedNodeMap1 = ((DocumentType)paramNode).getEntities();
        namedNodeMap3 = documentTypeImpl.getEntities();
        if (namedNodeMap1 != null)
          for (byte b = 0; b < namedNodeMap1.getLength(); b++)
            namedNodeMap3.setNamedItem((EntityImpl)importNode(namedNodeMap1.item(b), true));  
        namedNodeMap1 = ((DocumentType)paramNode).getNotations();
        namedNodeMap3 = documentTypeImpl.getNotations();
        if (namedNodeMap1 != null)
          for (byte b = 0; b < namedNodeMap1.getLength(); b++)
            namedNodeMap3.setNamedItem((NotationImpl)importNode(namedNodeMap1.item(b), true));  
        nodeImpl = documentTypeImpl;
        break;
      case 11:
        nodeImpl = (NodeImpl)createDocumentFragment();
        break;
      case 12:
        notation = (Notation)paramNode;
        notationImpl = (NotationImpl)createNotation(paramNode.getNodeName());
        notationImpl.setPublicId(notation.getPublicId());
        notationImpl.setSystemId(notation.getSystemId());
        nodeImpl = notationImpl;
        break;
      default:
        throw new DOMExceptionImpl((short)3, null);
    } 
    if (paramBoolean)
      for (Node node = paramNode.getFirstChild(); node != null; node = node.getNextSibling())
        nodeImpl.appendChild(importNode(node, true));  
    return nodeImpl;
  }
  
  public int createDocument() { return createNode((short)9); }
  
  public int createDocumentType(int paramInt) {
    int i = createNode((short)10);
    int j = i >> 11;
    int k = i & 0x7FF;
    this.fNodeName[j][k] = paramInt;
    return i;
  }
  
  public int createNotation(int paramInt) {
    int i = createNode((short)12);
    int j = i >> 11;
    int k = i & 0x7FF;
    int m = createNode((short)3);
    int n = m >> 11;
    int i1 = m & 0x7FF;
    this.fNodeValue[j][k] = m;
    EntityPool entityPool = this.fParserState.getEntityPool();
    this.fNodeName[j][k] = entityPool.getNotationName(paramInt);
    this.fNodeFirstChild[n][i1] = entityPool.getPublicId(paramInt);
    this.fNodeLastChild[n][i1] = entityPool.getSystemId(paramInt);
    return i;
  }
  
  public int createEntity(int paramInt) {
    int i = createNode((short)6);
    int j = i >> 11;
    int k = i & 0x7FF;
    int m = createNode((short)3);
    int n = m >> 11;
    int i1 = m & 0x7FF;
    this.fNodeValue[j][k] = m;
    EntityPool entityPool = this.fParserState.getEntityPool();
    this.fNodeName[j][k] = entityPool.getEntityName(paramInt);
    this.fNodeFirstChild[n][i1] = entityPool.getPublicId(paramInt);
    this.fNodeLastChild[n][i1] = entityPool.getSystemId(paramInt);
    this.fNodePrevSib[n][i1] = entityPool.getNotationName(paramInt);
    return i;
  }
  
  public int createEntityReference(int paramInt) {
    int i = createNode((short)5);
    int j = i >> 11;
    int k = i & 0x7FF;
    int m = this.fParserState.getEntityPool().getEntityName(paramInt);
    this.fNodeName[j][k] = m;
    return i;
  }
  
  public int createElement(int paramInt1, int paramInt2) {
    int i = createNode((short)1);
    int j = i >> 11;
    int k = i & 0x7FF;
    this.fNodeName[j][k] = paramInt1;
    if (paramInt2 != -1) {
      AttrPool attrPool = this.fParserState.getAttrPool();
      int m = attrPool.getFirstAttr(paramInt2);
      int n = -1;
      int i1 = -1;
      int i2 = -1;
      for (int i3 = m; i3 != -1; i3 = attrPool.getNextAttr(i3)) {
        int i4 = createNode((short)2);
        int i5 = i4 >> 11;
        int i6 = i4 & 0x7FF;
        this.fNodeParent[i5][i6] = i;
        this.fNodeName[i5][i6] = attrPool.getAttrName(i3);
        this.fNodeValue[i5][i6] = attrPool.isSpecified(i3) ? 1 : 0;
        int i7 = createNode((short)3);
        int i8 = i7 >> 11;
        int i9 = i7 & 0x7FF;
        this.fNodeValue[i8][i9] = attrPool.getAttValue(i3);
        appendChild(i4, i7);
        if (i3 == m) {
          this.fNodeValue[j][k] = i4;
        } else {
          this.fNodeNextSib[i1][i2] = i4;
          this.fNodePrevSib[i5][i6] = n;
        } 
        n = i4;
        i1 = i5;
        i2 = i6;
      } 
    } 
    return i;
  }
  
  public int createAttribute(int paramInt1, int paramInt2, boolean paramBoolean) {
    int i = createNode((short)2);
    int j = i >> 11;
    int k = i & 0x7FF;
    this.fNodeName[j][k] = paramInt1;
    this.fNodeValue[j][k] = paramBoolean ? 1 : 0;
    int m = createTextNode(paramInt2, false);
    appendChild(i, m);
    return i;
  }
  
  public int createElementDefinition(int paramInt) {
    int i = createNode((short)-1);
    int j = i >> 11;
    int k = i & 0x7FF;
    this.fNodeName[j][k] = paramInt;
    return i;
  }
  
  public int createTextNode(int paramInt, boolean paramBoolean) {
    int i = createNode((short)3);
    int j = i >> 11;
    int k = i & 0x7FF;
    this.fNodeValue[j][k] = paramInt;
    this.fNodeFirstChild[j][k] = paramBoolean ? 1 : 0;
    return i;
  }
  
  public int createCDATASection(int paramInt) {
    int i = createNode((short)4);
    int j = i >> 11;
    int k = i & 0x7FF;
    this.fNodeValue[j][k] = paramInt;
    return i;
  }
  
  public int createProcessingInstruction(int paramInt1, int paramInt2) {
    int i = createNode((short)7);
    int j = i >> 11;
    int k = i & 0x7FF;
    this.fNodeName[j][k] = paramInt1;
    this.fNodeValue[j][k] = paramInt2;
    return i;
  }
  
  public int createComment(int paramInt) {
    int i = createNode((short)8);
    int j = i >> 11;
    int k = i & 0x7FF;
    this.fNodeValue[j][k] = paramInt;
    return i;
  }
  
  public void appendChild(int paramInt1, int paramInt2) {
    int i = paramInt1 >> 11;
    int j = paramInt1 & 0x7FF;
    int k = paramInt2 >> 11;
    int m = paramInt2 & 0x7FF;
    this.fNodeParent[k][m] = paramInt1;
    int n = this.fNodeLastChild[i][j];
    this.fNodePrevSib[k][m] = n;
    if (n == -1) {
      this.fNodeFirstChild[i][j] = paramInt2;
    } else {
      int i1 = n >> 11;
      int i2 = n & 0x7FF;
      this.fNodeNextSib[i1][i2] = paramInt2;
    } 
    this.fNodeLastChild[i][j] = paramInt2;
  }
  
  public void setAsFirstChild(int paramInt1, int paramInt2) {
    int i = paramInt1 >> 11;
    int j = paramInt1 & 0x7FF;
    int k = paramInt2 >> 11;
    int m = paramInt2 & 0x7FF;
    this.fNodeFirstChild[i][j] = paramInt2;
    int n = paramInt2;
    while (n != -1) {
      paramInt2 = n;
      n = this.fNodeNextSib[k][m];
      k = n >> 11;
      m = n & 0x7FF;
    } 
    this.fNodeLastChild[i][j] = paramInt2;
  }
  
  public int getParentNode(int paramInt) {
    if (paramInt == -1)
      return -1; 
    int i = paramInt >> 11;
    int j = paramInt & 0x7FF;
    return this.fNodeParent[i][j];
  }
  
  public int getFirstChild(int paramInt) {
    if (paramInt == -1)
      return -1; 
    int i = paramInt >> 11;
    int j = paramInt & 0x7FF;
    return this.fNodeFirstChild[i][j];
  }
  
  public int getLastChild(int paramInt) {
    if (paramInt == -1)
      return -1; 
    int i = paramInt >> 11;
    int j = paramInt & 0x7FF;
    int k = this.fNodeLastChild[i][j];
    if (k != -1 && this.fNodeType[i][j] == 3) {
      int m = this.fNodePrevSib[i][j];
      i = m >> 11;
      j = m & 0x7FF;
      if (m != -1 && this.fNodeType[i][j] == 3) {
        while (m != -1 && this.fNodeType[i][j] == 3) {
          paramInt = m;
          m = this.fNodePrevSib[i][j];
          i = m >> 11;
          j = m & 0x7FF;
        } 
        return paramInt;
      } 
    } 
    return k;
  }
  
  public int getPreviousSibling(int paramInt) {
    if (paramInt == -1)
      return -1; 
    int i = paramInt >> 11;
    int j = paramInt & 0x7FF;
    int k = this.fNodePrevSib[i][j];
    if (k != -1 && this.fNodeType[i][j] != 3) {
      i = k >> 11;
      j = k & 0x7FF;
      if (this.fNodeType[i][j] == 3) {
        while (k != -1 && this.fNodeType[i][j] == 3) {
          paramInt = k;
          k = this.fNodePrevSib[i][j];
          i = k >> 11;
          j = k & 0x7FF;
        } 
        return paramInt;
      } 
    } 
    return k;
  }
  
  public int getNextSibling(int paramInt) {
    if (paramInt == -1)
      return -1; 
    int i = paramInt >> 11;
    int j = paramInt & 0x7FF;
    paramInt = this.fNodeNextSib[i][j];
    while (paramInt != -1 && this.fNodeType[i][j] == 3) {
      paramInt = this.fNodeNextSib[i][j];
      i = paramInt >> 11;
      j = paramInt & 0x7FF;
    } 
    return paramInt;
  }
  
  public int getRealNextSibling(int paramInt) {
    if (paramInt == -1)
      return -1; 
    int i = paramInt >> 11;
    int j = paramInt & 0x7FF;
    return this.fNodeNextSib[i][j];
  }
  
  public int lookupElementDefinition(int paramInt) {
    if (this.fNodeCount > 1) {
      int i = -1;
      for (int j = getFirstChild(0); j != -1; j = getNextSibling(j)) {
        if (getNodeType(j) == 10) {
          i = j;
          break;
        } 
      } 
      for (int k = getFirstChild(i); k != -1; k = getNextSibling(k)) {
        if (getIntNodeName(k) == paramInt)
          return k; 
      } 
    } 
    return -1;
  }
  
  public int getAttributeList(int paramInt) {
    if (paramInt == -1)
      return -1; 
    int i = paramInt >> 11;
    int j = paramInt & 0x7FF;
    return this.fNodeValue[i][j];
  }
  
  public NodeImpl getNodeObject(int paramInt) {
    DocumentTypeImpl documentTypeImpl;
    EntityImpl entityImpl;
    ProcessingInstructionImpl processingInstructionImpl;
    ElementDefinitionImpl elementDefinitionImpl;
    CDATASectionImpl cDATASectionImpl;
    EntityReferenceImpl entityReferenceImpl;
    CommentImpl commentImpl;
    TextImpl textImpl;
    NotationImpl notationImpl;
    ElementImpl elementImpl;
    DocumentImpl documentImpl;
    if (paramInt == -1)
      return null; 
    int i = paramInt >> 11;
    int j = paramInt & 0x7FF;
    byte b = this.fNodeType[i][j];
    AttrImpl attrImpl = null;
    switch (b) {
      case 2:
        attrImpl = new AttrImpl(this, paramInt);
        break;
      case 4:
        cDATASectionImpl = new CDATASectionImpl(this, paramInt);
        break;
      case 8:
        commentImpl = new CommentImpl(this, paramInt);
        break;
      case 9:
        documentImpl = this;
        break;
      case 10:
        documentTypeImpl = new DocumentTypeImpl(this, paramInt);
        this.docType = (DocumentTypeImpl)documentTypeImpl;
        break;
      case 1:
        elementImpl = new ElementImpl(this, paramInt);
        if (this.docElement == null)
          this.docElement = (ElementImpl)elementImpl; 
        break;
      case 6:
        entityImpl = new EntityImpl(this, paramInt);
        break;
      case 5:
        entityReferenceImpl = new EntityReferenceImpl(this, paramInt);
        break;
      case 12:
        notationImpl = new NotationImpl(this, paramInt);
        break;
      case 7:
        processingInstructionImpl = new ProcessingInstructionImpl(this, paramInt);
        break;
      case 3:
        textImpl = new TextImpl(this, paramInt);
        break;
      case -1:
        elementDefinitionImpl = new ElementDefinitionImpl(this, paramInt);
        break;
    } 
    if (elementDefinitionImpl != null)
      return elementDefinitionImpl; 
    throw new IllegalArgumentException();
  }
  
  public String getNodeName(int paramInt) {
    if (paramInt == -1)
      return null; 
    int i = paramInt >> 11;
    int j = paramInt & 0x7FF;
    int k = this.fNodeName[i][j];
    return (k == -1) ? null : this.fStringPool.toString(k);
  }
  
  public String getNodeValue(int paramInt) {
    if (paramInt == -1)
      return null; 
    int i = paramInt >> 11;
    int j = paramInt & 0x7FF;
    int k = this.fNodeValue[i][j];
    return (k == -1) ? null : this.fStringPool.toString(k);
  }
  
  public int getIntNodeName(int paramInt) {
    if (paramInt == -1)
      return -1; 
    int i = paramInt >> 11;
    int j = paramInt & 0x7FF;
    return this.fNodeName[i][j];
  }
  
  public int getIntNodeValue(int paramInt) {
    if (paramInt == -1)
      return -1; 
    int i = paramInt >> 11;
    int j = paramInt & 0x7FF;
    return this.fNodeValue[i][j];
  }
  
  public short getNodeType(int paramInt) {
    if (paramInt == -1)
      return -1; 
    int i = paramInt >> 11;
    int j = paramInt & 0x7FF;
    return (short)this.fNodeType[i][j];
  }
  
  public static boolean isXMLName(String paramString) {
    char[] arrayOfChar = new char[paramString.length()];
    paramString.getChars(0, paramString.length(), arrayOfChar, 0);
    if (!Character.isLetter(arrayOfChar[0]) && "_:".indexOf(arrayOfChar[0]) == -1)
      return false; 
    for (byte b = 1; b < paramString.length(); b++) {
      char c = arrayOfChar[b];
      int i = Character.getType(c);
      if (!Character.isLetterOrDigit(c) && ".-_:".indexOf(c) == -1 && (i < 6 || i > 8 || (c >= '۝' && c <= '۞') || (c >= '⃝' && c <= '⃠') || c >= '゛') && (i != 4 || (c >= 'ː' && c <= 'ՙ') || (c >= 'ۥ' && c <= 'ۦ') || (c >= '゛' && c <= '゜')) && c != '·' && c != '·')
        return false; 
    } 
    return true;
  }
  
  public void print() {}
  
  void synchronizeChildren() {
    this.syncChildren = false;
    super.synchronizeChildren();
    for (NodeImpl nodeImpl = this.firstChild; nodeImpl != null; nodeImpl = nodeImpl.nextSibling) {
      short s = nodeImpl.getNodeType();
      if (s == 10) {
        this.docType = (DocumentTypeImpl)nodeImpl;
      } else if (s == 1) {
        this.docElement = (ElementImpl)nodeImpl;
      } 
    } 
  }
  
  protected boolean ensureCapacity(int paramInt1, int paramInt2) {
    if (this.fNodeType == null) {
      this.fNodeType = new byte[32][];
      this.fNodeName = new int[32][];
      this.fNodeValue = new int[32][];
      this.fNodeParent = new int[32][];
      this.fNodeFirstChild = new int[32][];
      this.fNodeLastChild = new int[32][];
      this.fNodePrevSib = new int[32][];
      this.fNodeNextSib = new int[32][];
    } 
    try {
      return !(this.fNodeType[paramInt1][paramInt2] == 0);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      byte[][] arrayOfByte = new byte[paramInt1 * 2][];
      System.arraycopy(this.fNodeType, 0, arrayOfByte, 0, paramInt1);
      this.fNodeType = arrayOfByte;
      int[][] arrayOfInt = new int[paramInt1 * 2][];
      System.arraycopy(this.fNodeName, 0, arrayOfInt, 0, paramInt1);
      this.fNodeName = arrayOfInt;
      arrayOfInt = new int[paramInt1 * 2][];
      System.arraycopy(this.fNodeValue, 0, arrayOfInt, 0, paramInt1);
      this.fNodeValue = arrayOfInt;
      arrayOfInt = new int[paramInt1 * 2][];
      System.arraycopy(this.fNodeParent, 0, arrayOfInt, 0, paramInt1);
      this.fNodeParent = arrayOfInt;
      arrayOfInt = new int[paramInt1 * 2][];
      System.arraycopy(this.fNodeFirstChild, 0, arrayOfInt, 0, paramInt1);
      this.fNodeFirstChild = arrayOfInt;
      arrayOfInt = new int[paramInt1 * 2][];
      System.arraycopy(this.fNodeLastChild, 0, arrayOfInt, 0, paramInt1);
      this.fNodeLastChild = arrayOfInt;
      arrayOfInt = new int[paramInt1 * 2][];
      System.arraycopy(this.fNodePrevSib, 0, arrayOfInt, 0, paramInt1);
      this.fNodePrevSib = arrayOfInt;
      arrayOfInt = new int[paramInt1 * 2][];
      System.arraycopy(this.fNodeNextSib, 0, arrayOfInt, 0, paramInt1);
      this.fNodeNextSib = arrayOfInt;
    } catch (NullPointerException nullPointerException) {}
    this.fNodeType[paramInt1] = new byte[2048];
    this.fNodeName[paramInt1] = new int[2048];
    this.fNodeValue[paramInt1] = new int[2048];
    this.fNodeParent[paramInt1] = new int[2048];
    this.fNodeFirstChild[paramInt1] = new int[2048];
    this.fNodeLastChild[paramInt1] = new int[2048];
    this.fNodePrevSib[paramInt1] = new int[2048];
    this.fNodeNextSib[paramInt1] = new int[2048];
    return true;
  }
  
  protected int createNode(short paramShort) {
    int i = this.fNodeCount >> 11;
    int j = this.fNodeCount & 0x7FF;
    ensureCapacity(i, j);
    this.fNodeType[i][j] = (byte)paramShort;
    this.fNodeName[i][j] = -1;
    this.fNodeValue[i][j] = -1;
    this.fNodeParent[i][j] = -1;
    this.fNodeFirstChild[i][j] = -1;
    this.fNodeLastChild[i][j] = -1;
    this.fNodePrevSib[i][j] = -1;
    this.fNodeNextSib[i][j] = -1;
    return this.fNodeCount++;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\DocumentImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */