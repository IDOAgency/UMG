package com.ibm.xml.dom;

import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;

public class AttrImpl extends NodeImpl implements Attr {
  protected boolean owned;
  
  protected boolean specified = true;
  
  AttrImpl(DocumentImpl paramDocumentImpl, int paramInt) {
    super(paramDocumentImpl, paramInt);
    this.specified = !(this.ownerDocument.getIntNodeValue(paramInt) != 1);
  }
  
  public AttrImpl(DocumentImpl paramDocumentImpl, String paramString) { super(paramDocumentImpl, paramString, null); }
  
  public short getNodeType() { return 2; }
  
  public void setNodeValue(String paramString) throws DOMException { setValue(paramString); }
  
  public String getNodeValue() { return getValue(); }
  
  public String getName() {
    if (this.syncData)
      synchronizeData(); 
    return this.name;
  }
  
  public void setValue(String paramString) throws DOMException {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    this.firstChild = null;
    this.lastChild = null;
    this.syncChildren = false;
    if (paramString != null)
      appendChild(this.ownerDocument.createTextNode(paramString)); 
    this.specified = true;
    changed();
  }
  
  public String getValue() {
    StringBuffer stringBuffer = new StringBuffer();
    for (Node node = getFirstChild(); node != null; node = node.getNextSibling())
      stringBuffer.append(node.getNodeValue()); 
    return stringBuffer.toString();
  }
  
  public boolean getSpecified() { return this.specified; }
  
  public void setSpecified(boolean paramBoolean) { this.specified = paramBoolean; }
  
  public String toString() { return String.valueOf(getName()) + "=" + "\"" + getValue() + "\""; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\AttrImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */