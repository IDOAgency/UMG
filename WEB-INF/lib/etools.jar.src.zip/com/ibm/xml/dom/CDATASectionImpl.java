package com.ibm.xml.dom;

import org.w3c.dom.CDATASection;
import org.w3c.dom.Node;

public class CDATASectionImpl extends TextImpl implements CDATASection {
  CDATASectionImpl(DocumentImpl paramDocumentImpl, int paramInt) { super(paramDocumentImpl, paramInt); }
  
  public CDATASectionImpl(DocumentImpl paramDocumentImpl, String paramString) { super(paramDocumentImpl, paramString); }
  
  public short getNodeType() { return 4; }
  
  public String getNodeName() { return "#cdata-section"; }
  
  public Node cloneNode(boolean paramBoolean) { return this.ownerDocument.createCDATASection(getNodeValue()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\CDATASectionImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */