package com.ibm.xml.dom;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public abstract class NodeImpl implements Node, NodeList, Cloneable {
  public static final short ELEMENT_DEFINITION_NODE = -1;
  
  protected String name;
  
  protected String value;
  
  protected boolean readOnly;
  
  protected DocumentImpl ownerDocument;
  
  protected NodeImpl parentNode;
  
  protected NodeImpl previousSibling;
  
  protected NodeImpl nextSibling;
  
  protected NodeImpl firstChild;
  
  protected NodeImpl lastChild;
  
  protected Object userData;
  
  int fNodeIndex = -1;
  
  boolean syncChildren;
  
  boolean syncData;
  
  int changes;
  
  protected static int[] kidOK = new int[13];
  
  NodeImpl(DocumentImpl paramDocumentImpl, int paramInt) {
    this.ownerDocument = (paramDocumentImpl != null) ? paramDocumentImpl : (DocumentImpl)this;
    this.fNodeIndex = paramInt;
    this.syncChildren = true;
    this.syncData = true;
  }
  
  protected NodeImpl(DocumentImpl paramDocumentImpl, String paramString1, String paramString2) {
    this.ownerDocument = (paramDocumentImpl != null) ? paramDocumentImpl : (DocumentImpl)this;
    this.name = paramString1;
    this.value = paramString2;
  }
  
  public abstract short getNodeType();
  
  public String getNodeName() {
    if (this.syncData)
      synchronizeData(); 
    return this.name;
  }
  
  public void setNodeValue(String paramString) {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    if (this.syncData)
      synchronizeData(); 
    this.value = paramString;
  }
  
  public String getNodeValue() {
    if (this.syncData)
      synchronizeData(); 
    return this.value;
  }
  
  public Node appendChild(Node paramNode) throws DOMException { return insertBefore(paramNode, null); }
  
  public Node cloneNode(boolean paramBoolean) {
    NodeImpl nodeImpl;
    try {
      nodeImpl = (NodeImpl)clone();
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      System.out.println("UNEXPECTED " + cloneNotSupportedException);
      return null;
    } 
    nodeImpl.readOnly = false;
    nodeImpl.parentNode = null;
    nodeImpl.previousSibling = null;
    nodeImpl.nextSibling = null;
    nodeImpl.firstChild = null;
    nodeImpl.lastChild = null;
    if (paramBoolean)
      for (NodeImpl nodeImpl1 = (NodeImpl)getFirstChild(); nodeImpl1 != null; nodeImpl1 = nodeImpl1.nextSibling)
        nodeImpl.appendChild(nodeImpl1.cloneNode(true));  
    return nodeImpl;
  }
  
  public Document getOwnerDocument() { return this.ownerDocument; }
  
  public Node getParentNode() { return this.parentNode; }
  
  public Node getNextSibling() { return this.nextSibling; }
  
  public Node getPreviousSibling() { return this.previousSibling; }
  
  public NamedNodeMap getAttributes() { return null; }
  
  public boolean hasChildNodes() {
    if (this.syncChildren)
      synchronizeChildren(); 
    return !(this.firstChild == null);
  }
  
  public NodeList getChildNodes() {
    if (this.syncChildren)
      synchronizeChildren(); 
    return this;
  }
  
  public Node getFirstChild() {
    if (this.syncChildren)
      synchronizeChildren(); 
    return this.firstChild;
  }
  
  public Node getLastChild() {
    if (this.syncChildren)
      synchronizeChildren(); 
    return this.lastChild;
  }
  
  public Node insertBefore(Node paramNode1, Node paramNode2) throws DOMException {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    if (!(paramNode1 instanceof NodeImpl) || (paramNode1.getOwnerDocument() != this.ownerDocument && (getNodeType() != 9 || paramNode1.getOwnerDocument() != (Document)this)))
      throw new DOMExceptionImpl((short)4, null); 
    if (this.syncChildren)
      synchronizeChildren(); 
    NodeImpl nodeImpl1 = (NodeImpl)paramNode1;
    boolean bool = true;
    for (NodeImpl nodeImpl2 = this.parentNode; bool && nodeImpl2 != null; nodeImpl2 = nodeImpl2.parentNode)
      bool = (nodeImpl1 == nodeImpl2) ? 0 : 1; 
    if (!bool)
      throw new DOMExceptionImpl((short)3, null); 
    if (paramNode2 != null && paramNode2.getParentNode() != this)
      throw new DOMExceptionImpl((short)8, null); 
    if (nodeImpl1.getNodeType() == 11) {
      for (Node node = nodeImpl1.getFirstChild(); node != null; node = node.getNextSibling()) {
        NodeImpl nodeImpl = this;
        if ((kidOK[nodeImpl.getNodeType()] & 1 << node.getNodeType()) == 0 && !false)
          throw new DOMExceptionImpl((short)3, null); 
      } 
      while (nodeImpl1.hasChildNodes())
        insertBefore(nodeImpl1.getFirstChild(), paramNode2); 
    } else {
      NodeImpl nodeImpl3 = this;
      NodeImpl nodeImpl4 = nodeImpl1;
      if ((kidOK[nodeImpl3.getNodeType()] & 1 << nodeImpl4.getNodeType()) == 0 && !false)
        throw new DOMExceptionImpl((short)3, null); 
      Node node = nodeImpl1.getParentNode();
      if (node != null)
        node.removeChild(nodeImpl1); 
      nodeImpl4 = (paramNode2 == null) ? this.lastChild : ((NodeImpl)paramNode2).previousSibling;
      nodeImpl1.parentNode = this;
      nodeImpl1.previousSibling = nodeImpl4;
      if (nodeImpl4 == null) {
        this.firstChild = nodeImpl1;
      } else {
        nodeImpl4.nextSibling = nodeImpl1;
      } 
      nodeImpl1.nextSibling = (NodeImpl)paramNode2;
      if (paramNode2 == null) {
        this.lastChild = nodeImpl1;
      } else {
        ((NodeImpl)paramNode2).previousSibling = nodeImpl1;
      } 
    } 
    changed();
    return nodeImpl1;
  }
  
  public Node removeChild(Node paramNode) throws DOMException {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    if (paramNode != null && paramNode.getParentNode() != this)
      throw new DOMExceptionImpl((short)8, null); 
    NodeImpl nodeImpl1 = (NodeImpl)paramNode;
    NodeImpl nodeImpl2 = nodeImpl1.previousSibling;
    NodeImpl nodeImpl3 = nodeImpl1.nextSibling;
    if (nodeImpl2 != null) {
      nodeImpl2.nextSibling = nodeImpl3;
    } else {
      this.firstChild = nodeImpl3;
    } 
    if (nodeImpl3 != null) {
      nodeImpl3.previousSibling = nodeImpl2;
    } else {
      this.lastChild = nodeImpl2;
    } 
    nodeImpl1.parentNode = null;
    nodeImpl1.nextSibling = null;
    nodeImpl1.previousSibling = null;
    changed();
    return nodeImpl1;
  }
  
  public Node replaceChild(Node paramNode1, Node paramNode2) throws DOMException {
    insertBefore(paramNode1, paramNode2);
    return removeChild(paramNode2);
  }
  
  public int getLength() {
    byte b = 0;
    for (NodeImpl nodeImpl = this.firstChild; nodeImpl != null; nodeImpl = nodeImpl.nextSibling)
      b++; 
    return b;
  }
  
  public Node item(int paramInt) {
    NodeImpl nodeImpl = this.firstChild;
    for (byte b = 0; b < paramInt && nodeImpl != null; b++)
      nodeImpl = nodeImpl.nextSibling; 
    return nodeImpl;
  }
  
  public void setReadOnly(boolean paramBoolean1, boolean paramBoolean2) {
    this.readOnly = paramBoolean1;
    if (paramBoolean2)
      for (NodeImpl nodeImpl = this.firstChild; nodeImpl != null; nodeImpl = nodeImpl.nextSibling) {
        if (!(nodeImpl instanceof org.w3c.dom.EntityReference))
          nodeImpl.setReadOnly(paramBoolean1, true); 
      }  
  }
  
  public void setUserData(Object paramObject) { this.userData = paramObject; }
  
  public Object getUserData() { return this.userData; }
  
  void synchronizeChildren() {
    NodeImpl nodeImpl = null;
    for (int i = this.ownerDocument.getFirstChild(this.fNodeIndex); i != -1; i = this.ownerDocument.getNextSibling(i)) {
      NodeImpl nodeImpl1 = this.ownerDocument.getNodeObject(i);
      if (nodeImpl == null) {
        this.firstChild = nodeImpl1;
      } else {
        nodeImpl.nextSibling = nodeImpl1;
      } 
      nodeImpl1.parentNode = this;
      nodeImpl1.previousSibling = nodeImpl;
      nodeImpl = nodeImpl1;
    } 
    if (nodeImpl != null)
      this.lastChild = nodeImpl; 
    this.syncChildren = false;
  }
  
  void synchronizeData() {
    this.name = this.ownerDocument.getNodeName(this.fNodeIndex);
    this.value = this.ownerDocument.getNodeValue(this.fNodeIndex);
    this.syncData = false;
  }
  
  void changed() {
    this.changes++;
    if (this.parentNode != null)
      this.parentNode.changed(); 
  }
  
  protected static boolean isKidOK(Node paramNode1, Node paramNode2) { return !((kidOK[paramNode1.getNodeType()] & 1 << paramNode2.getNodeType()) == 0); }
  
  public String toString() { return "[" + getNodeName() + ": " + getNodeValue() + "]"; }
  
  static  {
    kidOK[9] = 1410;
    kidOK[1] = 442;
    kidOK[5] = 442;
    kidOK[6] = 442;
    kidOK[11] = 442;
    kidOK[10] = 4160;
    kidOK[2] = 40;
    kidOK[12] = 0;
    kidOK[4] = 0;
    kidOK[3] = 0;
    kidOK[8] = 0;
    kidOK[7] = 0;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\NodeImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */