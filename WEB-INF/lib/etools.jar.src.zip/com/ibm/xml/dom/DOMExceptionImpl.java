package com.ibm.xml.dom;

import org.w3c.dom.DOMException;

public class DOMExceptionImpl extends DOMException {
  public DOMExceptionImpl(short paramShort, String paramString) { super(paramShort, paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\DOMExceptionImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */