package com.ibm.xml.dom;

import com.ibm.xml.framework.StringPool;
import org.w3c.dom.DOMException;
import org.w3c.dom.Entity;

public class EntityImpl extends NodeImpl implements Entity {
  protected String publicId;
  
  protected String systemId;
  
  protected String notationName;
  
  EntityImpl(DocumentImpl paramDocumentImpl, int paramInt) { super(paramDocumentImpl, paramInt); }
  
  public EntityImpl(DocumentImpl paramDocumentImpl, String paramString) { super(paramDocumentImpl, paramString, null); }
  
  public short getNodeType() { return 6; }
  
  public String getNodeValue() { return null; }
  
  public void setNodeValue(String paramString) throws DOMException { throw new DOMExceptionImpl((short)7, null); }
  
  public String getPublicId() {
    if (this.syncData)
      synchronizeData(); 
    return this.publicId;
  }
  
  public String getSystemId() {
    if (this.syncData)
      synchronizeData(); 
    return this.systemId;
  }
  
  public String getNotationName() {
    if (this.syncData)
      synchronizeData(); 
    return this.notationName;
  }
  
  public void setPublicId(String paramString) throws DOMException {
    if (this.syncData)
      synchronizeData(); 
    this.publicId = paramString;
  }
  
  public void setSystemId(String paramString) throws DOMException {
    if (this.syncData)
      synchronizeData(); 
    this.systemId = paramString;
  }
  
  public void setNotationName(String paramString) throws DOMException {
    if (this.syncData)
      synchronizeData(); 
    this.notationName = paramString;
  }
  
  protected void synchronizeData() {
    this.name = this.ownerDocument.getNodeName(this.fNodeIndex);
    StringPool stringPool = this.ownerDocument.fParserState.getStringPool();
    int i = this.ownerDocument.getIntNodeValue(this.fNodeIndex);
    this.publicId = stringPool.toString(this.ownerDocument.getFirstChild(i));
    this.systemId = stringPool.toString(this.ownerDocument.getLastChild(i));
    this.notationName = stringPool.toString(this.ownerDocument.getPreviousSibling(i));
    this.syncData = false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\EntityImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */