package com.ibm.xml.dom;

import org.w3c.dom.DOMException;
import org.w3c.dom.DocumentType;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class DocumentTypeImpl extends NodeImpl implements DocumentType {
  protected NamedNodeMapImpl entities;
  
  protected NamedNodeMapImpl notations;
  
  protected NamedNodeMapImpl elements;
  
  protected boolean syncInfo;
  
  DocumentTypeImpl(DocumentImpl paramDocumentImpl, int paramInt) {
    super(paramDocumentImpl, paramInt);
    this.syncChildren = false;
    this.syncInfo = true;
  }
  
  public DocumentTypeImpl(DocumentImpl paramDocumentImpl, String paramString) {
    super(paramDocumentImpl, paramString, null);
    this.entities = new NamedNodeMapImpl(paramDocumentImpl, null);
    this.notations = new NamedNodeMapImpl(paramDocumentImpl, null);
    this.elements = new NamedNodeMapImpl(paramDocumentImpl, null);
  }
  
  public short getNodeType() { return 10; }
  
  public void setNodeValue(String paramString) throws DOMException { throw new DOMExceptionImpl((short)7, null); }
  
  public Node cloneNode(boolean paramBoolean) {
    DocumentTypeImpl documentTypeImpl = (DocumentTypeImpl)super.cloneNode(paramBoolean);
    documentTypeImpl.entities = this.entities.cloneMap();
    documentTypeImpl.notations = this.notations.cloneMap();
    documentTypeImpl.elements = this.elements.cloneMap();
    return documentTypeImpl;
  }
  
  public Node appendChild(Node paramNode) { throw new DOMExceptionImpl((short)7, null); }
  
  public String getName() {
    if (this.syncData)
      synchronizeData(); 
    return this.name;
  }
  
  public NamedNodeMap getEntities() {
    if (this.syncInfo)
      synchronizeInfo(); 
    return this.entities;
  }
  
  public NamedNodeMap getNotations() {
    if (this.syncInfo)
      synchronizeInfo(); 
    return this.notations;
  }
  
  public void setReadOnly(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.syncInfo)
      synchronizeInfo(); 
    setReadOnly(paramBoolean1, paramBoolean2);
    this.elements.setReadOnly(paramBoolean1, true);
    this.entities.setReadOnly(paramBoolean1, true);
    this.notations.setReadOnly(paramBoolean1, true);
  }
  
  public NamedNodeMap getElements() {
    if (this.syncInfo)
      synchronizeInfo(); 
    return this.elements;
  }
  
  protected void synchronizeInfo() {
    this.entities = new NamedNodeMapImpl(this.ownerDocument, null);
    this.notations = new NamedNodeMapImpl(this.ownerDocument, null);
    this.elements = new NamedNodeMapImpl(this.ownerDocument, null);
    for (int i = this.ownerDocument.getFirstChild(this.fNodeIndex); i != -1; i = this.ownerDocument.getNextSibling(i)) {
      int j;
      NamedNodeMap namedNodeMap;
      NodeImpl nodeImpl = this.ownerDocument.getNodeObject(i);
      short s = nodeImpl.getNodeType();
      switch (s) {
        case 6:
          this.entities.setNamedItem(nodeImpl);
          break;
        case 12:
          this.notations.setNamedItem(nodeImpl);
          break;
        case -1:
          this.elements.setNamedItem(nodeImpl);
          namedNodeMap = nodeImpl.getAttributes();
          for (j = this.ownerDocument.getFirstChild(nodeImpl.fNodeIndex); j != -1; j = this.ownerDocument.getNextSibling(j)) {
            NodeImpl nodeImpl1 = this.ownerDocument.getNodeObject(j);
            namedNodeMap.setNamedItem(nodeImpl1);
          } 
          break;
        default:
          System.out.println("DocumentTypeImpl#synchronizeInfo: node.getNodeType() = " + nodeImpl.getNodeType() + ", class = " + nodeImpl.getClass().getName());
          break;
      } 
    } 
    this.syncInfo = false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\DocumentTypeImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */