package com.ibm.xml.dom;

import org.w3c.dom.CharacterData;
import org.w3c.dom.DOMException;

public abstract class CharacterDataImpl extends NodeImpl implements CharacterData {
  CharacterDataImpl(DocumentImpl paramDocumentImpl, int paramInt) { super(paramDocumentImpl, paramInt); }
  
  protected CharacterDataImpl(DocumentImpl paramDocumentImpl, String paramString) { super(paramDocumentImpl, null, paramString); }
  
  public abstract String getNodeName();
  
  public String getData() {
    if (this.syncData)
      synchronizeData(); 
    return this.value;
  }
  
  public int getLength() {
    if (this.syncData)
      synchronizeData(); 
    return this.value.length();
  }
  
  public void appendData(String paramString) {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    if (this.syncData)
      synchronizeData(); 
    this.value = String.valueOf(this.value) + paramString;
  }
  
  public void deleteData(int paramInt1, int paramInt2) throws DOMException {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    if (paramInt2 < 0)
      throw new DOMExceptionImpl((short)1, null); 
    if (this.syncData)
      synchronizeData(); 
    int i = Math.max(this.value.length() - paramInt2 - paramInt1, 0);
    try {
      this.value = String.valueOf(this.value.substring(0, paramInt1)) + ((i > 0) ? this.value.substring(paramInt1 + paramInt2, paramInt1 + paramInt2 + i) : "");
      return;
    } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
      throw new DOMExceptionImpl((short)1, null);
    } 
  }
  
  public void insertData(int paramInt, String paramString) throws DOMException {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    if (this.syncData)
      synchronizeData(); 
    try {
      this.value = (new StringBuffer(this.value)).insert(paramInt, paramString).toString();
      return;
    } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
      throw new DOMExceptionImpl((short)1, null);
    } 
  }
  
  public void replaceData(int paramInt1, int paramInt2, String paramString) throws DOMException {
    deleteData(paramInt1, paramInt2);
    insertData(paramInt1, paramString);
  }
  
  public void setData(String paramString) { setNodeValue(paramString); }
  
  public String substringData(int paramInt1, int paramInt2) throws DOMException {
    if (this.syncData)
      synchronizeData(); 
    int i = this.value.length();
    if (paramInt2 < 0 || paramInt1 < 0 || paramInt1 > i - 1)
      throw new DOMExceptionImpl((short)1, null); 
    int j = Math.min(paramInt1 + paramInt2, i);
    return this.value.substring(paramInt1, j);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\CharacterDataImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */