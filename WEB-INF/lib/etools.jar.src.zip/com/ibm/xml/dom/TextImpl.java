package com.ibm.xml.dom;

import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

public class TextImpl extends CharacterDataImpl implements Text {
  boolean isIgnorableWhitespace = false;
  
  TextImpl(DocumentImpl paramDocumentImpl, int paramInt) { super(paramDocumentImpl, paramInt); }
  
  public TextImpl(DocumentImpl paramDocumentImpl, String paramString) { super(paramDocumentImpl, paramString); }
  
  public short getNodeType() { return 3; }
  
  public String getNodeName() { return "#text"; }
  
  public boolean isIgnorableWhitespace() {
    if (this.syncChildren)
      synchronizeChildren(); 
    return this.isIgnorableWhitespace;
  }
  
  public void setIgnorableWhitespace(boolean paramBoolean) {
    if (this.syncChildren)
      synchronizeChildren(); 
    this.isIgnorableWhitespace = paramBoolean;
  }
  
  public Node cloneNode(boolean paramBoolean) { return this.ownerDocument.createTextNode(getNodeValue()); }
  
  public Text splitText(int paramInt) throws DOMException {
    if (this.readOnly)
      throw new DOMExceptionImpl((short)7, null); 
    if (this.syncData)
      synchronizeData(); 
    if (paramInt < 0 || paramInt > this.value.length() - 1)
      throw new DOMExceptionImpl((short)1, null); 
    Text text = this.ownerDocument.createTextNode(this.value.substring(paramInt));
    setNodeValue(this.value.substring(0, paramInt));
    if (this.parentNode != null)
      this.parentNode.insertBefore(text, this.nextSibling); 
    return text;
  }
  
  protected void synchronizeData() {
    this.value = this.ownerDocument.getNodeValue(this.fNodeIndex);
    int i = this.ownerDocument.getRealNextSibling(this.fNodeIndex);
    int j = this.ownerDocument.getParentNode(this.fNodeIndex);
    if (j != -1 && this.ownerDocument.getNodeType(j) == 1) {
      short s = this.ownerDocument.getNodeType(i);
      if (i != -1 && s == 3) {
        StringBuffer stringBuffer = new StringBuffer(this.value);
        while (i != -1 && s == 3) {
          stringBuffer.append(this.ownerDocument.getNodeValue(i));
          i = this.ownerDocument.getRealNextSibling(i);
          s = this.ownerDocument.getNodeType(i);
        } 
        this.value = stringBuffer.toString();
      } 
    } 
    this.syncData = false;
  }
  
  protected void synchronizeChildren() {
    this.isIgnorableWhitespace = !(this.ownerDocument.getFirstChild(this.fNodeIndex) != 1);
    this.syncChildren = false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\TextImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */