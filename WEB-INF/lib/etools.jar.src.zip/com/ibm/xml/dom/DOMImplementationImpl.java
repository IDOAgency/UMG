package com.ibm.xml.dom;

import org.w3c.dom.DOMImplementation;

public class DOMImplementationImpl implements DOMImplementation {
  static DOMImplementationImpl singleton = new DOMImplementationImpl();
  
  public boolean hasFeature(String paramString1, String paramString2) { return !(!paramString1.equalsIgnoreCase("XML") || !paramString2.equals("1.0")); }
  
  static DOMImplementation getDOMImplementation() { return singleton; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\dom\DOMImplementationImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */