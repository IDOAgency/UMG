package com.ibm.xml.internal;

import com.ibm.xml.framework.AttDef;
import com.ibm.xml.framework.Attr;
import com.ibm.xml.framework.AttrPool;
import com.ibm.xml.framework.ContentModel;
import com.ibm.xml.framework.ContentSpecNode;
import com.ibm.xml.framework.ElementDecl;
import com.ibm.xml.framework.ElementDeclPool;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLErrorHandler;
import com.ibm.xml.framework.XMLValidationHandler;
import java.util.Enumeration;
import java.util.Hashtable;

public final class DefaultElementDeclPool implements ElementDeclPool {
  private static final int CHUNK_SHIFT = 5;
  
  private static final int CHUNK_SIZE = 32;
  
  private static final int CHUNK_MASK = 31;
  
  private static final int INITIAL_CHUNK_COUNT = 32;
  
  private ParserState fParserState;
  
  private StringPool fStringPool;
  
  private AttrPool fAttrPool;
  
  private XMLErrorHandler fErrorHandler;
  
  private XMLValidationHandler fValidationHandler;
  
  private int fRootElement = -1;
  
  private Attr fAttr = new Attr();
  
  private int fElementCount;
  
  private int[][] fElementName = new int[32][];
  
  private byte[][] fContentSpecType = new byte[32][];
  
  private int[][] fContentSpec = new int[32][];
  
  private ContentModel[][] fContentModel = new ContentModel[32][];
  
  private int[][] fAttlistHead = new int[32][];
  
  private int[][] fAttlistTail = new int[32][];
  
  private int fNodeCount;
  
  private byte[][] fNodeType = new byte[32][];
  
  private int[][] fNodeValue = new int[32][];
  
  private int fAttDefCount;
  
  private int[][] fAttName = new int[32][];
  
  private byte[][] fAttType = new byte[32][];
  
  private int[][] fEnumeration = new int[32][];
  
  private byte[][] fAttDefaultType = new byte[32][];
  
  private int[][] fAttValue = new int[32][];
  
  private int[][] fNextAttDef = new int[32][];
  
  private static final int INITIAL_BUCKET_SIZE = 4;
  
  private static final int HASHTABLE_SIZE = 128;
  
  private int[][] fElementNameHashtable = new int[128][];
  
  private int fXMLSpace = -1;
  
  private int fDefault = -1;
  
  private int fPreserve = -1;
  
  private Hashtable fIdDefs;
  
  private Hashtable fIdRefs;
  
  private Object fNullValue;
  
  private int[] localpartcache = new int[8];
  
  private int[] nsnamecache = new int[8];
  
  public DefaultElementDeclPool(ParserState paramParserState) {
    this.fParserState = paramParserState;
    this.fStringPool = paramParserState.cacheStringPool();
    this.fAttrPool = paramParserState.cacheAttrPool();
    this.fErrorHandler = paramParserState.getErrorHandler();
    this.fValidationHandler = paramParserState.getValidationHandler();
  }
  
  public void reset(ParserState paramParserState) {
    this.fParserState = paramParserState;
    this.fStringPool = paramParserState.cacheStringPool();
    this.fAttrPool = paramParserState.cacheAttrPool();
    this.fErrorHandler = paramParserState.getErrorHandler();
    this.fValidationHandler = paramParserState.getValidationHandler();
    byte b1 = 0;
    byte b2 = 0;
    for (byte b3 = 0; b3 < this.fElementCount; b3++) {
      this.fContentModel[b1][b2] = null;
      if (++b2 == 32) {
        b1++;
        b2 = 0;
      } 
    } 
    for (byte b4 = 0; b4 < ''; b4++)
      this.fElementNameHashtable[b4] = null; 
    this.fRootElement = -1;
    this.fElementCount = 0;
    this.fNodeCount = 0;
    this.fAttDefCount = 0;
    this.fXMLSpace = -1;
    this.fDefault = -1;
    this.fPreserve = -1;
    if (this.fIdDefs != null)
      this.fIdDefs.clear(); 
    if (this.fIdRefs != null)
      this.fIdRefs.clear(); 
  }
  
  public ElementDeclPool resetOrCopy(ParserState paramParserState) { return new DefaultElementDeclPool(paramParserState); }
  
  public void setRootElement(int paramInt) { this.fRootElement = paramInt; }
  
  public int getRootElement() { return this.fRootElement; }
  
  private boolean ensureElementCapacity(int paramInt) {
    try {
      return !(this.fElementName[paramInt][0] != 0);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      byte[][] arrayOfByte = new byte[paramInt * 2][];
      System.arraycopy(this.fContentSpecType, 0, arrayOfByte, 0, paramInt);
      this.fContentSpecType = arrayOfByte;
      int[][] arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fElementName, 0, arrayOfInt, 0, paramInt);
      this.fElementName = arrayOfInt;
      arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fContentSpec, 0, arrayOfInt, 0, paramInt);
      this.fContentSpec = arrayOfInt;
      ContentModel[][] arrayOfContentModel = new ContentModel[paramInt * 2][];
      System.arraycopy(this.fContentModel, 0, arrayOfContentModel, 0, paramInt);
      this.fContentModel = arrayOfContentModel;
      arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fAttlistHead, 0, arrayOfInt, 0, paramInt);
      this.fAttlistHead = arrayOfInt;
      arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fAttlistTail, 0, arrayOfInt, 0, paramInt);
      this.fAttlistTail = arrayOfInt;
    } catch (NullPointerException nullPointerException) {}
    this.fElementName[paramInt] = new int[32];
    this.fContentSpecType[paramInt] = new byte[32];
    this.fContentSpec[paramInt] = new int[32];
    this.fContentModel[paramInt] = new ContentModel[32];
    this.fAttlistHead[paramInt] = new int[32];
    this.fAttlistTail[paramInt] = new int[32];
    return true;
  }
  
  public int getElement(int paramInt) {
    int i = paramInt % 128;
    int[] arrayOfInt = this.fElementNameHashtable[i];
    if (arrayOfInt != null) {
      boolean bool = true;
      for (byte b = 0; b < arrayOfInt[0]; b++) {
        if (arrayOfInt[bool] == paramInt)
          return arrayOfInt[bool + true]; 
        bool += true;
      } 
    } 
    return -1;
  }
  
  public int addElement(int paramInt) {
    int i = paramInt % 128;
    int[] arrayOfInt = this.fElementNameHashtable[i];
    if (arrayOfInt != null) {
      boolean bool = true;
      for (byte b = 0; b < arrayOfInt[0]; b++) {
        if (arrayOfInt[bool] == paramInt)
          return arrayOfInt[bool + true]; 
        bool += true;
      } 
    } 
    int j = this.fElementCount >> 5;
    int k = this.fElementCount & 0x1F;
    ensureElementCapacity(j);
    this.fElementName[j][k] = paramInt;
    this.fContentSpecType[j][k] = 0;
    this.fContentSpec[j][k] = -1;
    this.fContentModel[j][k] = null;
    this.fAttlistHead[j][k] = -1;
    this.fAttlistTail[j][k] = -1;
    if (arrayOfInt == null) {
      arrayOfInt = new int[9];
      arrayOfInt[0] = 1;
      arrayOfInt[1] = paramInt;
      arrayOfInt[2] = this.fElementCount;
      this.fElementNameHashtable[i] = arrayOfInt;
    } else {
      int m = arrayOfInt[0];
      int n = 1 + m * 2;
      if (n == arrayOfInt.length) {
        int i1 = m + 4;
        int[] arrayOfInt1 = new int[1 + i1 * 2];
        System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, n);
        arrayOfInt = arrayOfInt1;
        this.fElementNameHashtable[i] = arrayOfInt;
      } 
      arrayOfInt[n++] = paramInt;
      arrayOfInt[n++] = this.fElementCount;
      arrayOfInt[0] = ++m;
    } 
    return this.fElementCount++;
  }
  
  public int addElementDecl(ElementDecl paramElementDecl) {
    int i = paramElementDecl.elementName;
    int j = i % 128;
    int[] arrayOfInt = this.fElementNameHashtable[j];
    if (arrayOfInt != null) {
      boolean bool = true;
      for (byte b = 0; b < arrayOfInt[0]; b++) {
        if (arrayOfInt[bool] == i) {
          int n = arrayOfInt[bool + true];
          int i1 = n >> 5;
          int i2 = n & 0x1F;
          if (this.fContentSpecType[i1][i2] != 0)
            return -1; 
          this.fContentSpecType[i1][i2] = (byte)paramElementDecl.contentSpecType;
          this.fContentSpec[i1][i2] = paramElementDecl.contentSpec;
          this.fContentModel[i1][i2] = null;
          return n;
        } 
        bool += true;
      } 
    } 
    int k = this.fElementCount >> 5;
    int m = this.fElementCount & 0x1F;
    ensureElementCapacity(k);
    this.fElementName[k][m] = paramElementDecl.elementName;
    this.fContentSpecType[k][m] = (byte)paramElementDecl.contentSpecType;
    this.fContentSpec[k][m] = paramElementDecl.contentSpec;
    this.fContentModel[k][m] = null;
    this.fAttlistHead[k][m] = -1;
    this.fAttlistTail[k][m] = -1;
    if (arrayOfInt == null) {
      arrayOfInt = new int[9];
      arrayOfInt[0] = 1;
      arrayOfInt[1] = i;
      arrayOfInt[2] = this.fElementCount;
      this.fElementNameHashtable[j] = arrayOfInt;
    } else {
      int n = arrayOfInt[0];
      int i1 = 1 + n * 2;
      if (i1 == arrayOfInt.length) {
        int i2 = n + 4;
        int[] arrayOfInt1 = new int[1 + i2 * 2];
        System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, i1);
        arrayOfInt = arrayOfInt1;
        this.fElementNameHashtable[j] = arrayOfInt;
      } 
      arrayOfInt[i1++] = i;
      arrayOfInt[i1++] = this.fElementCount;
      arrayOfInt[0] = ++n;
    } 
    return this.fElementCount++;
  }
  
  public int getElementName(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fElementCount)
      return -1; 
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fElementName[i][j];
  }
  
  public int getContentSpecType(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fElementCount)
      return -1; 
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fContentSpecType[i][j];
  }
  
  public int getContentSpec(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fElementCount)
      return -1; 
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fContentSpec[i][j];
  }
  
  public String getContentSpecAsString(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fElementCount)
      return null; 
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    switch (this.fContentSpecType[i][j]) {
      case 1:
        return "EMPTY";
      case 2:
        return "ANY";
      case 3:
      case 4:
        return getContentSpecNodeAsString(this.fContentSpec[i][j]);
    } 
    return null;
  }
  
  public ContentModel getContentModel(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fElementCount)
      return null; 
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fContentModel[i][j];
  }
  
  public void setContentModel(int paramInt, ContentModel paramContentModel) {
    if (paramInt < 0 || paramInt >= this.fElementCount)
      return; 
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    this.fContentModel[i][j] = paramContentModel;
  }
  
  private boolean ensureNodeCapacity(int paramInt) {
    try {
      return !(this.fNodeType[paramInt][0] != 0);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      byte[][] arrayOfByte = new byte[paramInt * 2][];
      System.arraycopy(this.fNodeType, 0, arrayOfByte, 0, paramInt);
      this.fNodeType = arrayOfByte;
      int[][] arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fNodeValue, 0, arrayOfInt, 0, paramInt);
      this.fNodeValue = arrayOfInt;
    } catch (NullPointerException nullPointerException) {}
    this.fNodeType[paramInt] = new byte[32];
    this.fNodeValue[paramInt] = new int[32];
    return true;
  }
  
  public int addContentSpecNode(ContentSpecNode paramContentSpecNode) {
    int k;
    int i = this.fNodeCount >> 5;
    int j = this.fNodeCount & 0x1F;
    ensureNodeCapacity(i);
    switch (paramContentSpecNode.type) {
      case 0:
      case 1:
      case 2:
      case 3:
        this.fNodeType[i][j] = (byte)paramContentSpecNode.type;
        this.fNodeValue[i][j] = paramContentSpecNode.value;
        return this.fNodeCount++;
      case 4:
      case 5:
        this.fNodeType[i][j] = (byte)paramContentSpecNode.type;
        this.fNodeValue[i][j] = paramContentSpecNode.value;
        k = this.fNodeCount++;
        if (++j == 32) {
          ensureNodeCapacity(++i);
          j = 0;
        } 
        this.fNodeType[i][j] = (byte)(paramContentSpecNode.type | 0x40);
        this.fNodeValue[i][j] = paramContentSpecNode.otherValue;
        this.fNodeCount++;
        return k;
    } 
    return -1;
  }
  
  public void getContentSpecNode(int paramInt, ContentSpecNode paramContentSpecNode) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    paramContentSpecNode.type = this.fNodeType[i][j];
    paramContentSpecNode.value = this.fNodeValue[i][j];
    if (paramContentSpecNode.type == 4 || paramContentSpecNode.type == 5) {
      if (++j == 32) {
        i++;
        j = 0;
      } 
      paramContentSpecNode.otherValue = this.fNodeValue[i][j];
      return;
    } 
    paramContentSpecNode.otherValue = -1;
  }
  
  private void appendContentSpecNode(int paramInt, StringBuffer paramStringBuffer, boolean paramBoolean) {
    byte b2;
    int n;
    int m;
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    byte b1 = this.fNodeType[i][j];
    int k = this.fNodeValue[i][j];
    switch (b1) {
      case 0:
        paramStringBuffer.append((k == -1) ? "#PCDATA" : this.fStringPool.toString(k));
        return;
      case 1:
        appendContentSpecNode(k, paramStringBuffer, false);
        paramStringBuffer.append('?');
        return;
      case 2:
        appendContentSpecNode(k, paramStringBuffer, false);
        paramStringBuffer.append('*');
        return;
      case 3:
        appendContentSpecNode(k, paramStringBuffer, false);
        paramStringBuffer.append('+');
        return;
      case 4:
      case 5:
        if (!paramBoolean)
          paramStringBuffer.append('('); 
        m = k >> 5;
        n = k & 0x1F;
        b2 = this.fNodeType[m][n];
        appendContentSpecNode(k, paramStringBuffer, !(b2 != b1));
        paramStringBuffer.append((b1 == 4) ? 124 : 44);
        if (++j == 32) {
          i++;
          j = 0;
        } 
        appendContentSpecNode(this.fNodeValue[i][j], paramStringBuffer, false);
        if (!paramBoolean)
          paramStringBuffer.append(')'); 
        return;
    } 
  }
  
  public String getContentSpecNodeAsString(int paramInt) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    byte b = this.fNodeType[i][j];
    int k = this.fNodeValue[i][j];
    StringBuffer stringBuffer = new StringBuffer();
    switch (b) {
      case 0:
        stringBuffer.append("(" + ((k == -1) ? "#PCDATA" : this.fStringPool.toString(k)) + ")");
        return stringBuffer.toString();
      case 1:
        i = k >> 5;
        j = k & 0x1F;
        if (this.fNodeType[i][j] == 0) {
          k = this.fNodeValue[i][j];
          stringBuffer.append("(" + ((k == -1) ? "#PCDATA" : this.fStringPool.toString(k)) + ")?");
        } else {
          appendContentSpecNode(paramInt, stringBuffer, false);
        } 
        return stringBuffer.toString();
      case 2:
        i = k >> 5;
        j = k & 0x1F;
        if (this.fNodeType[i][j] == 0) {
          k = this.fNodeValue[i][j];
          stringBuffer.append("(" + ((k == -1) ? "#PCDATA" : this.fStringPool.toString(k)) + ")*");
        } else {
          appendContentSpecNode(paramInt, stringBuffer, false);
        } 
        return stringBuffer.toString();
      case 3:
        i = k >> 5;
        j = k & 0x1F;
        if (this.fNodeType[i][j] == 0) {
          k = this.fNodeValue[i][j];
          stringBuffer.append("(" + ((k == -1) ? "#PCDATA" : this.fStringPool.toString(k)) + ")+");
        } else {
          appendContentSpecNode(paramInt, stringBuffer, false);
        } 
        return stringBuffer.toString();
      case 4:
      case 5:
        appendContentSpecNode(paramInt, stringBuffer, false);
        return stringBuffer.toString();
    } 
    return null;
  }
  
  private boolean ensureAttrCapacity(int paramInt) {
    try {
      return !(this.fAttName[paramInt][0] != 0);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      byte[][] arrayOfByte = new byte[paramInt * 2][];
      System.arraycopy(this.fAttType, 0, arrayOfByte, 0, paramInt);
      this.fAttType = arrayOfByte;
      arrayOfByte = new byte[paramInt * 2][];
      System.arraycopy(this.fAttDefaultType, 0, arrayOfByte, 0, paramInt);
      this.fAttDefaultType = arrayOfByte;
      int[][] arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fAttName, 0, arrayOfInt, 0, paramInt);
      this.fAttName = arrayOfInt;
      arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fEnumeration, 0, arrayOfInt, 0, paramInt);
      this.fEnumeration = arrayOfInt;
      arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fAttValue, 0, arrayOfInt, 0, paramInt);
      this.fAttValue = arrayOfInt;
      arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fNextAttDef, 0, arrayOfInt, 0, paramInt);
      this.fNextAttDef = arrayOfInt;
    } catch (NullPointerException nullPointerException) {}
    this.fAttType[paramInt] = new byte[32];
    this.fAttDefaultType[paramInt] = new byte[32];
    this.fAttName[paramInt] = new int[32];
    this.fEnumeration[paramInt] = new int[32];
    this.fAttValue[paramInt] = new int[32];
    this.fNextAttDef[paramInt] = new int[32];
    return true;
  }
  
  public int addAttDef(int paramInt, AttDef paramAttDef) throws Exception {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    for (int k = this.fAttlistHead[i][j]; k != -1; k = this.fNextAttDef[i2][i3]) {
      int i2 = k >> 5;
      int i3 = k & 0x1F;
      if (this.fAttName[i2][i3] == paramAttDef.attName) {
        if (this.fParserState.getWarningOnDuplicateAttDef())
          this.fErrorHandler.error1(15, paramAttDef.attName); 
        return -1;
      } 
      if (paramAttDef.attType == 1 && this.fAttType[i2][i3] == 1) {
        this.fErrorHandler.error1(13, paramAttDef.attName);
        return -1;
      } 
    } 
    if (this.fXMLSpace == -1) {
      this.fXMLSpace = this.fStringPool.addSymbol("xml:space".intern());
      this.fDefault = this.fStringPool.addSymbol("default".intern());
      this.fPreserve = this.fStringPool.addSymbol("preserve".intern());
    } 
    if (paramAttDef.attName == this.fXMLSpace) {
      boolean bool = false;
      if (paramAttDef.attType == 9) {
        int i2 = paramAttDef.enumeration;
        if (i2 != -1)
          bool = (this.fStringPool.stringListLength(i2) != 2 || !this.fStringPool.stringInList(i2, this.fDefault) || !this.fStringPool.stringInList(i2, this.fPreserve)) ? 0 : 1; 
      } 
      if (!bool)
        this.fErrorHandler.error(14); 
    } 
    int m = this.fAttDefCount >> 5;
    int n = this.fAttDefCount & 0x1F;
    ensureAttrCapacity(m);
    this.fAttName[m][n] = paramAttDef.attName;
    this.fAttType[m][n] = (byte)paramAttDef.attType;
    this.fEnumeration[m][n] = paramAttDef.enumeration;
    this.fAttDefaultType[m][n] = (byte)paramAttDef.attDefaultType;
    this.fAttValue[m][n] = paramAttDef.attValue;
    int i1 = -1;
    if (paramAttDef.attValue != -1) {
      i1 = this.fAttlistHead[i][j];
      this.fAttlistHead[i][j] = this.fAttDefCount;
      if (i1 == -1)
        this.fAttlistTail[i][j] = this.fAttDefCount; 
    } else {
      i1 = this.fAttlistTail[i][j];
      this.fAttlistTail[i][j] = this.fAttDefCount;
      if (i1 == -1) {
        this.fAttlistHead[i][j] = this.fAttDefCount;
      } else {
        this.fNextAttDef[i1 >> 5][i1 & 0x1F] = this.fAttDefCount;
        i1 = -1;
      } 
    } 
    this.fNextAttDef[m][n] = i1;
    return this.fAttDefCount++;
  }
  
  public int getAttDef(int paramInt1, int paramInt2) {
    int i = 0;
    int j = 0;
    for (byte b = 0; b < this.fElementCount; b++) {
      if (this.fElementName[i][j] == paramInt1) {
        int k;
        for (k = this.fAttlistHead[i][j];; k = this.fNextAttDef[i][j]) {
          if (k == -1)
            return -1; 
          i = k >> 5;
          j = k & 0x1F;
          if (this.fAttName[i][j] == paramInt2)
            return k; 
        } 
      } 
      if (++j == 32) {
        i++;
        j = 0;
      } 
    } 
    return -1;
  }
  
  public int getAttName(int paramInt) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fAttName[i][j];
  }
  
  public int getAttValue(int paramInt) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fAttValue[i][j];
  }
  
  public int getAttType(int paramInt) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fAttType[i][j];
  }
  
  public int getAttDefaultType(int paramInt) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fAttDefaultType[i][j];
  }
  
  public int getEnumeration(int paramInt) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fEnumeration[i][j];
  }
  
  public int addDefaultAttributes(int paramInt1, AttrPool paramAttrPool, int paramInt2, int paramInt3) throws Exception {
    int i = paramInt1 >> 5;
    int j = paramInt1 & 0x1F;
    int k = this.fAttlistHead[i][j];
    int m = paramInt2;
    int n = paramInt3;
    while (k != -1) {
      int i1 = k >> 5;
      int i2 = k & 0x1F;
      byte b = this.fAttDefaultType[i1][i2];
      if (b != 3) {
        int i3 = this.fAttName[i1][i2];
        boolean bool = false;
        if (m != -1)
          for (int i4 = m; i4 <= n; i4++) {
            paramAttrPool.getAttrName(i4);
            if (paramAttrPool.getAttrName(i4) == i3) {
              if (b == 4 && paramAttrPool.getAttValue(i4) != this.fAttValue[i1][i2])
                this.fErrorHandler.error3(134, i3, this.fAttValue[i1][i2], paramAttrPool.getAttValue(i4)); 
              bool = true;
              break;
            } 
          }  
        if (!bool)
          if (b == 2) {
            this.fErrorHandler.error1(133, i3);
          } else {
            this.fAttr.attName = i3;
            this.fAttr.attType = this.fAttType[i1][i2];
            this.fAttr.attValue = this.fAttValue[i1][i2];
            this.fAttr.specified = false;
            paramInt3 = paramAttrPool.addAttr(this.fAttr, -1);
            if (paramInt2 == -1)
              paramInt2 = paramInt3; 
          }  
      } 
      k = this.fNextAttDef[i1][i2];
    } 
    if (paramInt3 != -1)
      paramAttrPool.setIsLastAttr(paramInt3); 
    return paramInt2;
  }
  
  public boolean addId(int paramInt1, int paramInt2) {
    Integer integer = new Integer(paramInt1);
    if (this.fIdDefs == null) {
      this.fIdDefs = new Hashtable();
    } else if (this.fIdDefs.containsKey(integer)) {
      return false;
    } 
    if (this.fNullValue == null)
      this.fNullValue = new Object(); 
    this.fIdDefs.put(integer, this.fNullValue);
    return true;
  }
  
  public void addIdRef(int paramInt1, int paramInt2) {
    Integer integer = new Integer(paramInt1);
    if (this.fIdDefs != null && this.fIdDefs.containsKey(integer))
      return; 
    if (this.fIdRefs == null) {
      this.fIdRefs = new Hashtable();
    } else if (this.fIdRefs.containsKey(integer)) {
      return;
    } 
    if (this.fNullValue == null)
      this.fNullValue = new Object(); 
    this.fIdRefs.put(integer, this.fNullValue);
  }
  
  public void checkIdRefs() throws Exception {
    if (this.fIdRefs == null)
      return; 
    Enumeration enumeration = this.fIdRefs.keys();
    while (enumeration.hasMoreElements()) {
      Integer integer = (Integer)enumeration.nextElement();
      if (this.fIdDefs == null || !this.fIdDefs.containsKey(integer))
        this.fErrorHandler.error1(84, integer.intValue()); 
    } 
  }
  
  public void checkNamespace(int paramInt1, int paramInt2) {
    if (paramInt2 != -1) {
      int k = paramInt2;
      int m = this.fAttrPool.getAttrName(k);
      String str1 = this.fStringPool.toString(m);
      int n = checkQName(paramInt1, str1);
      if (n != -1)
        this.fErrorHandler.error1(n, m); 
      int i1 = this.fAttrPool.getAttValue(k);
      String str2 = this.fStringPool.toString(i1);
      if (str2.length() == 0 && str1.startsWith("xmlns:"))
        this.fErrorHandler.error1(142, m); 
      if (this.localpartcache.length == 0) {
        int[] arrayOfInt = new int[0];
        System.arraycopy(this.localpartcache, 0, arrayOfInt, 0, 0);
        this.localpartcache = arrayOfInt;
        arrayOfInt = new int[0];
        System.arraycopy(this.nsnamecache, 0, arrayOfInt, 0, 0);
        this.nsnamecache = arrayOfInt;
      } 
      this.localpartcache[0] = getNSLocalName(str1, m);
      this.nsnamecache[0] = getNSName(paramInt1, str1);
      if (this.nsnamecache[0] != -1)
        for (int i2 = 0; !i2; i2++) {
          if (this.localpartcache[i2] == this.localpartcache[0]) {
            int i3 = this.nsnamecache[i2];
            if (i3 != -1 && i3 == this.nsnamecache[0])
              this.fErrorHandler.error4(144, m, this.nsnamecache[0], this.localpartcache[0], this.fAttrPool.getAttrName(paramInt2 + i2)); 
          } 
        }  
    } 
    int i = getElementName(paramInt1);
    String str = this.fStringPool.toString(i);
    int j = checkQName(paramInt1, str);
    if (j != -1)
      this.fErrorHandler.error1(j, i); 
  }
  
  public void checkDeclaredElements() throws Exception {
    if (this.fParserState.getValidationHandler() != null)
      for (byte b = 0; b < this.fElementCount; b++) {
        int i = getContentSpecType(b);
        if (i == 3 || i == 4) {
          byte b1 = b >> 5;
          byte b2 = b & 0x1F;
          int j = this.fContentSpec[b1][b2];
          checkDeclaredElements(b, j);
        } 
      }  
  }
  
  private void checkDeclaredElements(int paramInt1, int paramInt2) {
    int i = paramInt2 >> 5;
    int j = paramInt2 & 0x1F;
    byte b = this.fNodeType[i][j];
    int k = this.fNodeValue[i][j];
    switch (b) {
      case 0:
        if (k != -1 && getElement(k) == -1) {
          int m = paramInt1 >> 5;
          int n = paramInt1 & 0x1F;
          int i1 = this.fElementName[m][n];
          this.fErrorHandler.error2(165, i1, k);
          return;
        } 
        break;
      case 1:
      case 2:
      case 3:
        checkDeclaredElements(paramInt1, k);
        return;
      case 4:
      case 5:
        checkDeclaredElements(paramInt1, k);
        if (++j == 32) {
          i++;
          j = 0;
        } 
        checkDeclaredElements(paramInt1, this.fNodeValue[i][j]);
        return;
    } 
  }
  
  private int checkQName(int paramInt, String paramString) {
    int i = paramString.indexOf(':');
    if (i < 0)
      return -1; 
    paramString.substring(0, i);
    return (-1 == -1) ? 136 : ((paramString.indexOf(':', i + 1) >= 0) ? 135 : -1);
  }
  
  private int getNSLocalName(String paramString, int paramInt) {
    int i = paramString.indexOf(':');
    return (i < 0) ? paramInt : this.fStringPool.addSymbol(paramString.substring(i + 1));
  }
  
  private int getNSName(int paramInt, String paramString) {
    int i = paramString.indexOf(':');
    String str = (i < 0) ? "" : paramString.substring(0, i);
    return -1;
  }
  
  private int getNamespaceForPrefix(int paramInt, String paramString) { return -1; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\DefaultElementDeclPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */