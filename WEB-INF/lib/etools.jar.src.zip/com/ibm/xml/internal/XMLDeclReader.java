package com.ibm.xml.internal;

import com.ibm.xml.framework.ChunkyByteArray;
import com.ibm.xml.framework.ChunkyCharArray;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.ScanContentState;
import com.ibm.xml.framework.XMLReader;
import java.io.IOException;

final class XMLDeclReader extends XMLReader {
  private ChunkyByteArray fData;
  
  private ParserState fParserState;
  
  XMLDeclReader(ChunkyByteArray paramChunkyByteArray, ParserState paramParserState) {
    super(null, null, null);
    this.fData = paramChunkyByteArray;
    this.fParserState = paramParserState;
  }
  
  public boolean skippedChar(char paramChar) throws IOException {
    if (this.fData.byteAt(this.fCurrentOffset) != paramChar)
      return false; 
    this.fCurrentOffset++;
    return true;
  }
  
  public boolean lookingAtChar(char paramChar) throws IOException { return !(this.fData.byteAt(this.fCurrentOffset) != paramChar); }
  
  public boolean skippedSpace() throws IOException {
    byte b = this.fData.byteAt(this.fCurrentOffset) & 0xFF;
    if (b != 32 && b != 9 && b != 10 && b != 13)
      return false; 
    this.fCurrentOffset++;
    return true;
  }
  
  public int skipPastSpaces() throws IOException {
    while (true) {
      byte b = this.fData.byteAt(this.fCurrentOffset) & 0xFF;
      if (b != 32 && b != 9 && b != 10 && b != 13)
        return this.fCurrentOffset; 
      this.fCurrentOffset++;
    } 
  }
  
  public boolean skippedAlpha() throws IOException {
    byte b = this.fData.byteAt(this.fCurrentOffset) & 0xFF;
    if (b > 122 || XMLReader.fgAsciiAlphaChar[b] == 0)
      return false; 
    this.fCurrentOffset++;
    return true;
  }
  
  private boolean skippedAsciiCharWithFlag(byte paramByte) throws IOException {
    byte b = this.fData.byteAt(this.fCurrentOffset) & 0xFF;
    if ((b & 0x80) != 0 || (XMLReader.fgCharFlags[b] & paramByte) == 0)
      return false; 
    this.fCurrentOffset++;
    return true;
  }
  
  public boolean skippedVersionNum() throws IOException { return skippedAsciiCharWithFlag((byte)1); }
  
  public boolean skippedEncName() throws IOException { return skippedAsciiCharWithFlag((byte)2); }
  
  public boolean skippedString(char[] paramArrayOfChar) throws IOException {
    int i = this.fCurrentOffset;
    for (byte b = 0; b < paramArrayOfChar.length; b++) {
      if (this.fData.byteAt(i) != paramArrayOfChar[b])
        return false; 
      i++;
    } 
    this.fCurrentOffset = i;
    return true;
  }
  
  public int addString(int paramInt1, int paramInt2) {
    StringBuffer stringBuffer = new StringBuffer();
    for (int i = 0; i < paramInt2; i++)
      stringBuffer.append((char)this.fData.byteAt(paramInt1 + i)); 
    return this.fParserState.getStringPool().addString(stringBuffer.toString());
  }
  
  public int addSymbol(int paramInt1, int paramInt2) { return -1; }
  
  public void append(ChunkyCharArray paramChunkyCharArray, int paramInt1, int paramInt2) {}
  
  public int skipOneChar() throws IOException { throw new IOException(); }
  
  public int skipAsciiChar() throws IOException { throw new IOException(); }
  
  public int skipToChar(char paramChar) throws IOException { throw new IOException(); }
  
  public int skipPastChar(char paramChar) throws IOException { throw new IOException(); }
  
  public boolean skippedValidChar() throws IOException { throw new IOException(); }
  
  public boolean lookingAtValidChar() throws IOException { throw new IOException(); }
  
  public int skipInvalidChar(int paramInt) throws Exception { throw new IOException(); }
  
  public boolean lookingAtSpace() throws IOException { throw new IOException(); }
  
  public int skipDecimalDigit() throws IOException { throw new IOException(); }
  
  public int skipHexDigit() throws IOException { throw new IOException(); }
  
  public boolean skippedPubidChar() throws IOException { throw new IOException(); }
  
  public int scanName(char paramChar, int paramInt) throws IOException { throw new IOException(); }
  
  public int skipPastName(char paramChar) throws IOException { throw new IOException(); }
  
  public int skipPastNmtoken(char paramChar) throws IOException { throw new IOException(); }
  
  public int scanContent(ScanContentState paramScanContentState) throws Exception { throw new IOException(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\XMLDeclReader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */