package com.ibm.xml.internal;

import com.ibm.xml.framework.ChunkyByteArray;
import com.ibm.xml.framework.ChunkyCharArray;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.ScanContentState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.StringProducer;
import com.ibm.xml.framework.XMLDocumentHandler;
import com.ibm.xml.framework.XMLErrorHandler;
import com.ibm.xml.framework.XMLReader;
import java.io.IOException;

final class UCSReader extends XMLReader implements StringProducer {
  private static final boolean DEBUG_UTF16_BIG = false;
  
  static final int E_UCS4B = 0;
  
  static final int E_UCS4L = 1;
  
  static final int E_UCS2B = 2;
  
  static final int E_UCS2L = 3;
  
  static final int E_UCS2B_NOBOM = 4;
  
  static final int E_UCS2L_NOBOM = 5;
  
  private ChunkyByteArray fData;
  
  private int fEncoding = -1;
  
  private StringPool fStringPool;
  
  private XMLDocumentHandler fDocumentHandler;
  
  private XMLErrorHandler fErrorHandler;
  
  private int fBytesPerChar = -1;
  
  private boolean fBigEndian = true;
  
  private ChunkyCharArray fStringCharArray;
  
  private static char[] fCharacters = new char[256];
  
  private int fCharDataLength;
  
  UCSReader(ParserState paramParserState, String paramString1, String paramString2, ChunkyByteArray paramChunkyByteArray, int paramInt) throws IOException {
    super(paramParserState, paramString1, paramString2);
    this.fCurrentOffset = (paramInt == 2 || paramInt == 3) ? 2 : 0;
    this.fData = paramChunkyByteArray;
    this.fEncoding = paramInt;
    this.fStringPool = paramParserState.cacheStringPool();
    this.fDocumentHandler = paramParserState.getDocumentHandler();
    this.fErrorHandler = paramParserState.getErrorHandler();
    this.fBytesPerChar = (this.fEncoding == 0 || this.fEncoding == 1) ? 4 : 2;
    this.fBigEndian = !(this.fEncoding != 0 && this.fEncoding != 2 && this.fEncoding != 4);
  }
  
  private int getChar(int paramInt) {
    byte b1 = this.fData.byteAt(paramInt++) & 0xFF;
    if (b1 == 255 && this.fData.atEOF(paramInt))
      return -1; 
    byte b2 = this.fData.byteAt(paramInt++) & 0xFF;
    if (this.fBytesPerChar == 4) {
      byte b3 = this.fData.byteAt(paramInt++) & 0xFF;
      byte b4 = this.fData.byteAt(paramInt++) & 0xFF;
      return this.fBigEndian ? ((b1 << 24) + (b2 << 16) + (b3 << 8) + b4) : ((b4 << 24) + (b3 << 16) + (b2 << 8) + b1);
    } 
    return this.fBigEndian ? ((b1 << 8) + b2) : ((b2 << 8) + b1);
  }
  
  public int addString(int paramInt1, int paramInt2) { return (paramInt2 == 0) ? 0 : this.fStringPool.addString(this, paramInt1, paramInt2); }
  
  public int addSymbol(int paramInt1, int paramInt2) { return (paramInt2 == 0) ? 0 : this.fStringPool.addSymbol(this, paramInt1, paramInt2, getHashcode(paramInt1, paramInt2)); }
  
  public void append(ChunkyCharArray paramChunkyCharArray, int paramInt1, int paramInt2) {
    int i = paramInt1 + paramInt2;
    while (paramInt1 < i) {
      int j = getChar(paramInt1);
      paramChunkyCharArray.append((char)j);
      paramInt1 += this.fBytesPerChar;
    } 
  }
  
  public String toString(int paramInt1, int paramInt2) {
    if (this.fStringCharArray == null)
      this.fStringCharArray = new ChunkyCharArray(this.fStringPool); 
    int i = this.fStringCharArray.length();
    append(this.fStringCharArray, paramInt1, paramInt2);
    int j = this.fStringCharArray.length() - i;
    int k = this.fStringCharArray.addString(i, j);
    return this.fStringPool.toString(k);
  }
  
  private int getHashcode(int paramInt1, int paramInt2) {
    int i = paramInt1 + paramInt2;
    int j = 0;
    byte b = 0;
    while (paramInt1 < i) {
      int m = getChar(paramInt1);
      j = StringHasher.hashChar(j, b++, m);
      paramInt1 += this.fBytesPerChar;
    } 
    int k = j;
    k &= Integer.MAX_VALUE;
    return (k == 0) ? 1 : k;
  }
  
  public boolean equalsString(int paramInt1, int paramInt2, String paramString, int paramInt3) {
    int i = paramInt1 + paramInt2;
    int j = paramInt3;
    byte b = 0;
    while (paramInt1 < i) {
      if (j-- == 0)
        return false; 
      int k = getChar(paramInt1);
      if (k != paramString.charAt(b++))
        return false; 
      paramInt1 += this.fBytesPerChar;
    } 
    return !(j != 0);
  }
  
  private void appendCharData(int paramInt) {
    if (fCharacters.length == this.fCharDataLength) {
      char[] arrayOfChar = new char[fCharacters.length * 2];
      System.arraycopy(fCharacters, 0, arrayOfChar, 0, fCharacters.length);
      fCharacters = arrayOfChar;
    } 
    fCharacters[this.fCharDataLength++] = (char)paramInt;
  }
  
  public void callWSCharDataHandler(int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {
    int i = paramInt1 + paramInt2;
    while (paramInt1 < i) {
      int j = getChar(paramInt1);
      appendCharData(j);
      paramInt1 += this.fBytesPerChar;
    } 
    if (this.fDocumentHandler.sendCharDataAsCharArray()) {
      this.fDocumentHandler.ignorableWhitespace(fCharacters, 0, this.fCharDataLength, paramBoolean);
    } else {
      int j = this.fStringPool.addString(new String(fCharacters, 0, this.fCharDataLength));
      this.fDocumentHandler.ignorableWhitespace(j, paramBoolean);
    } 
    this.fCharDataLength = 0;
  }
  
  public void callCharDataHandler(int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {
    int i = paramInt1 + paramInt2;
    while (paramInt1 < i) {
      int j = getChar(paramInt1);
      appendCharData(j);
      paramInt1 += this.fBytesPerChar;
    } 
    if (this.fDocumentHandler.sendCharDataAsCharArray()) {
      this.fDocumentHandler.characters(fCharacters, 0, this.fCharDataLength, paramBoolean);
    } else {
      int j = this.fStringPool.addString(new String(fCharacters, 0, this.fCharDataLength));
      this.fDocumentHandler.characters(j, paramBoolean);
    } 
    this.fCharDataLength = 0;
  }
  
  public int skipOneChar() throws IOException {
    this.fCurrentOffset += this.fBytesPerChar;
    return this.fCurrentOffset;
  }
  
  public int skipAsciiChar() throws IOException {
    this.fCurrentOffset += this.fBytesPerChar;
    return this.fCurrentOffset;
  }
  
  public int skipToChar(char paramChar) throws IOException {
    while (true) {
      int i = getChar(this.fCurrentOffset);
      if (i == paramChar)
        return this.fCurrentOffset; 
      this.fCurrentOffset += this.fBytesPerChar;
    } 
  }
  
  public int skipPastChar(char paramChar) throws IOException {
    int i;
    do {
      i = getChar(this.fCurrentOffset);
      this.fCurrentOffset += this.fBytesPerChar;
    } while (i != paramChar);
    return this.fCurrentOffset;
  }
  
  public boolean skippedValidChar() throws IOException {
    int i = getChar(this.fCurrentOffset);
    this.fCurrentOffset += this.fBytesPerChar;
    if (i < 32) {
      if (i == 9) {
        this.fCharacterCounter++;
        return true;
      } 
      if (i == 10) {
        this.fLinefeedCounter++;
        this.fCharacterCounter = 1;
        return true;
      } 
      if (i == 13) {
        this.fCarriageReturnCounter++;
        this.fCharacterCounter = 1;
        return true;
      } 
      this.fCurrentOffset--;
      if (i == -1)
        this.fData.checkEOF(this.fCurrentOffset + 1); 
      return false;
    } 
    this.fCharacterCounter++;
    if (i <= 55295)
      return true; 
    if (i <= 57343) {
      this.fCurrentOffset++;
      return true;
    } 
    if (i <= 65533)
      return true; 
    this.fCharacterCounter--;
    this.fCurrentOffset -= this.fBytesPerChar;
    return false;
  }
  
  public boolean lookingAtValidChar() throws IOException {
    int i = getChar(this.fCurrentOffset);
    if (i < 32) {
      if (i == -1)
        this.fData.checkEOF(this.fCurrentOffset + 1); 
      return !(i != 9 && i != 10 && i != 13);
    } 
    return !(i > 55295 && (i < 57344 || (i > 65533 && (i < 65536 || i > 1114111))));
  }
  
  public int skipInvalidChar(int paramInt) {
    String str2;
    String str1;
    int i = getChar(this.fCurrentOffset);
    this.fCurrentOffset += this.fBytesPerChar;
    switch (paramInt) {
      case 63:
      case 85:
        str1 = Integer.toHexString(i);
        this.fErrorHandler.error1(paramInt, this.fStringPool.addString(str1));
        break;
      case 80:
      case 82:
      case 110:
        str1 = (new Character((char)i)).toString();
        this.fErrorHandler.error1(paramInt, this.fStringPool.addString(str1));
        break;
      case 43:
        str1 = (new Character((char)i)).toString();
        str2 = Integer.toHexString(i);
        this.fErrorHandler.error2(paramInt, this.fStringPool.addString(str1), this.fStringPool.addString(str2));
        break;
    } 
    return this.fCurrentOffset;
  }
  
  public boolean skippedChar(char paramChar) throws IOException {
    int i = getChar(this.fCurrentOffset);
    if (i == paramChar) {
      this.fCurrentOffset += this.fBytesPerChar;
      return true;
    } 
    return false;
  }
  
  public boolean lookingAtChar(char paramChar) throws IOException { return !(paramChar != getChar(this.fCurrentOffset)); }
  
  public boolean skippedSpace() throws IOException {
    int i = getChar(this.fCurrentOffset);
    if (i == 32 || i == 9 || i == 10 || i == 13) {
      this.fCurrentOffset += this.fBytesPerChar;
      return true;
    } 
    return false;
  }
  
  public boolean lookingAtSpace() throws IOException {
    int i = getChar(this.fCurrentOffset);
    return !(i != 32 && i != 9 && i != 10 && i != 13);
  }
  
  public int skipPastSpaces() throws IOException {
    while (true) {
      int i = getChar(this.fCurrentOffset);
      if (i == 32 || i == 9 || i == 10 || i == 13) {
        this.fCurrentOffset += this.fBytesPerChar;
        continue;
      } 
      break;
    } 
    return this.fCurrentOffset;
  }
  
  public int skipDecimalDigit() throws IOException {
    int i = getChar(this.fCurrentOffset);
    if (i < 48 || i > 57)
      return -1; 
    this.fCurrentOffset += this.fBytesPerChar;
    this.fCharacterCounter++;
    return i - 48;
  }
  
  public int skipHexDigit() throws IOException {
    int i = getChar(this.fCurrentOffset);
    if (i > 102 || XMLReader.fgAsciiXDigitChar[i] == 0)
      return -1; 
    this.fCurrentOffset += this.fBytesPerChar;
    this.fCharacterCounter++;
    return i - ((i < 65) ? 48 : (((i < 97) ? 65 : 97) - 10));
  }
  
  public boolean skippedAlpha() throws IOException {
    int i = getChar(this.fCurrentOffset);
    if (i <= 122 && XMLReader.fgAsciiAlphaChar[i] == 1) {
      this.fCurrentOffset += this.fBytesPerChar;
      this.fCharacterCounter++;
      return true;
    } 
    return false;
  }
  
  private boolean skippedCharWithFlag(byte paramByte) {
    int i = getChar(this.fCurrentOffset);
    if (i < 128 && (XMLReader.fgCharFlags[i] & paramByte) != 0) {
      this.fCurrentOffset += this.fBytesPerChar;
      this.fCharacterCounter++;
      return true;
    } 
    return false;
  }
  
  public final boolean skippedVersionNum() throws IOException { return skippedCharWithFlag((byte)1); }
  
  public final boolean skippedEncName() throws IOException { return skippedCharWithFlag((byte)2); }
  
  public final boolean skippedPubidChar() throws IOException {
    int i = getChar(this.fCurrentOffset);
    if (i < 128) {
      if ((XMLReader.fgCharFlags[i] & 0x4) != 0) {
        this.fCurrentOffset += this.fBytesPerChar;
        this.fCharacterCounter++;
        return true;
      } 
      if (i == 10) {
        this.fCurrentOffset += this.fBytesPerChar;
        this.fLinefeedCounter++;
        this.fCharacterCounter = 1;
        return true;
      } 
      if (i == 13) {
        this.fCurrentOffset += this.fBytesPerChar;
        this.fCarriageReturnCounter++;
        this.fCharacterCounter = 1;
        return true;
      } 
    } 
    return false;
  }
  
  public boolean skippedString(char[] paramArrayOfChar) throws IOException {
    int i = this.fCurrentOffset;
    for (byte b = 0; b < paramArrayOfChar.length; b++) {
      if (getChar(i) != paramArrayOfChar[b])
        return false; 
      i += this.fBytesPerChar;
    } 
    this.fCurrentOffset = i;
    this.fCharacterCounter += paramArrayOfChar.length;
    return true;
  }
  
  public int scanName(char paramChar, int paramInt) throws IOException {
    int i = this.fCurrentOffset;
    int j = skipPastName(paramChar) - i;
    if (j == 0)
      return -1; 
    byte b = (j == 0) ? 0 : this.fStringPool.addSymbol(this, i, j, getHashcode(i, j));
    return (paramInt == -1 || paramInt == b) ? b : -1;
  }
  
  public int skipPastName(char paramChar) throws IOException {
    int i = getChar(this.fCurrentOffset);
    if ((XMLReader.fgCharFlags[i] & 0x10) == 0)
      return this.fCurrentOffset; 
    do {
      this.fCurrentOffset += this.fBytesPerChar;
      this.fCharacterCounter++;
      i = getChar(this.fCurrentOffset);
      if (paramChar == i)
        return this.fCurrentOffset; 
    } while ((XMLReader.fgCharFlags[i] & 0x20) != 0);
    return this.fCurrentOffset;
  }
  
  public int skipPastNmtoken(char paramChar) throws IOException {
    for (int i = getChar(this.fCurrentOffset);; i = getChar(this.fCurrentOffset)) {
      if (paramChar == i)
        return this.fCurrentOffset; 
      if ((XMLReader.fgCharFlags[i] & 0x20) == 0)
        return this.fCurrentOffset; 
      this.fCurrentOffset += this.fBytesPerChar;
      this.fCharacterCounter++;
    } 
  }
  
  public int scanContent(ScanContentState paramScanContentState) throws Exception {
    int i = this.fCurrentOffset;
    int j = getChar(this.fCurrentOffset);
    this.fCurrentOffset += this.fBytesPerChar;
    if (j < 128) {
      if (j == -1) {
        this.fCurrentOffset -= this.fBytesPerChar;
        return 4;
      } 
      byte b = XMLReader.fgCharFlags[j];
      if ((b & 0x8) == 0 && j != 10 && j != 13) {
        if (j == 60) {
          this.fCharacterCounter++;
          return 1;
        } 
        if (j == 38) {
          this.fCharacterCounter++;
          return 2;
        } 
        if (j == 93) {
          if (getChar(this.fCurrentOffset) == 93 && getChar(this.fCurrentOffset + this.fBytesPerChar) == 62) {
            this.fCharacterCounter += 3;
            this.fCurrentOffset += 2 * this.fBytesPerChar;
            return 3;
          } 
        } else {
          this.fCurrentOffset -= this.fBytesPerChar;
          return 4;
        } 
      } else if (j == 32 || j == 9 || j == 10 || j == 13) {
        do {
          if (j == 10) {
            this.fLinefeedCounter++;
            this.fCharacterCounter = 1;
          } else if (j == 13) {
            this.fCarriageReturnCounter++;
            this.fCharacterCounter = 1;
          } else {
            this.fCharacterCounter++;
          } 
          j = getChar(this.fCurrentOffset);
          this.fCurrentOffset += this.fBytesPerChar;
        } while (j == 32 || j == 9 || j == 10 || j == 13);
        if (j < 128) {
          if (j == -1) {
            this.fCurrentOffset -= this.fBytesPerChar;
            if (this.fDocumentHandler != null)
              callWSCharDataHandler(i, this.fCurrentOffset - i, paramScanContentState.inCDSect); 
            return 28;
          } 
          b = XMLReader.fgCharFlags[j];
          if ((b & 0x8) == 0) {
            if (j == 60) {
              this.fCharacterCounter++;
              if (this.fDocumentHandler != null)
                callWSCharDataHandler(i, this.fCurrentOffset - this.fBytesPerChar - i, paramScanContentState.inCDSect); 
              return 25;
            } 
            if (j == 38) {
              this.fCharacterCounter++;
              if (this.fDocumentHandler != null)
                callWSCharDataHandler(i, this.fCurrentOffset - this.fBytesPerChar - i, paramScanContentState.inCDSect); 
              return 26;
            } 
            if (j == 93) {
              if (getChar(this.fCurrentOffset) == 93 && getChar(this.fCurrentOffset + this.fBytesPerChar) == 62) {
                if (this.fDocumentHandler != null)
                  callWSCharDataHandler(i, this.fCurrentOffset - this.fBytesPerChar - i, paramScanContentState.inCDSect); 
                this.fCharacterCounter += 3;
                this.fCurrentOffset += 2 * this.fBytesPerChar;
                return 27;
              } 
            } else {
              this.fCurrentOffset -= this.fBytesPerChar;
              if (this.fDocumentHandler != null)
                callWSCharDataHandler(i, this.fCurrentOffset - i, paramScanContentState.inCDSect); 
              return 28;
            } 
          } 
        } else if (j >= 55296 && j <= 57343) {
          this.fCurrentOffset += this.fBytesPerChar;
        } else if (j == 65534 || j == 65535) {
          this.fCurrentOffset -= this.fBytesPerChar;
          if (this.fDocumentHandler != null)
            callWSCharDataHandler(i, this.fCurrentOffset - i, paramScanContentState.inCDSect); 
          return 28;
        } 
      } 
    } else if (j >= 55296 && j <= 57343) {
      this.fCurrentOffset += this.fBytesPerChar;
    } else if (j == 65534 || j == 65535) {
      this.fCurrentOffset -= this.fBytesPerChar;
      return 4;
    } 
    this.fCharacterCounter++;
    while (true) {
      j = getChar(this.fCurrentOffset);
      this.fCurrentOffset += this.fBytesPerChar;
      if (j < 128 && j >= 0) {
        byte b = XMLReader.fgCharFlags[j];
        if ((b & 0x8) == 0) {
          if (j == 10) {
            this.fLinefeedCounter++;
            this.fCharacterCounter = 1;
            continue;
          } 
          if (j == 13) {
            this.fCarriageReturnCounter++;
            this.fCharacterCounter = 1;
            continue;
          } 
          break;
        } 
        this.fCharacterCounter++;
        continue;
      } 
      break;
    } 
    while (true) {
      if (j < 128) {
        if (j == -1) {
          this.fCurrentOffset -= this.fBytesPerChar;
          if (this.fDocumentHandler != null)
            callCharDataHandler(i, this.fCurrentOffset - i, paramScanContentState.inCDSect); 
          return 12;
        } 
        byte b = XMLReader.fgCharFlags[j];
        if ((b & 0x8) == 0) {
          if (j == 60) {
            this.fCharacterCounter++;
            if (this.fDocumentHandler != null)
              callCharDataHandler(i, this.fCurrentOffset - this.fBytesPerChar - i, paramScanContentState.inCDSect); 
            return 9;
          } 
          if (j == 38) {
            this.fCharacterCounter++;
            if (this.fDocumentHandler != null)
              callCharDataHandler(i, this.fCurrentOffset - this.fBytesPerChar - i, paramScanContentState.inCDSect); 
            return 10;
          } 
          if (j == 10) {
            this.fLinefeedCounter++;
            this.fCharacterCounter = 1;
          } else if (j == 13) {
            this.fCarriageReturnCounter++;
            this.fCharacterCounter = 1;
          } else if (j == 93) {
            if (getChar(this.fCurrentOffset) == 93 && getChar(this.fCurrentOffset + this.fBytesPerChar) == 62) {
              if (this.fDocumentHandler != null)
                callCharDataHandler(i, this.fCurrentOffset - this.fBytesPerChar - i, paramScanContentState.inCDSect); 
              this.fCharacterCounter += 3;
              this.fCurrentOffset += 2 * this.fBytesPerChar;
              return 11;
            } 
            this.fCharacterCounter++;
          } else {
            this.fCurrentOffset -= this.fBytesPerChar;
            if (this.fDocumentHandler != null)
              callCharDataHandler(i, this.fCurrentOffset - i, paramScanContentState.inCDSect); 
            return 12;
          } 
        } else {
          this.fCharacterCounter++;
        } 
      } else {
        if (j >= 55296 && j <= 57343) {
          this.fCharacterCounter++;
          this.fCurrentOffset += this.fBytesPerChar;
        } else if (j == 65534 || j == 65535) {
          this.fCurrentOffset -= this.fBytesPerChar;
          if (this.fDocumentHandler != null)
            callCharDataHandler(i, this.fCurrentOffset - i, paramScanContentState.inCDSect); 
          return 12;
        } 
        this.fCharacterCounter++;
      } 
      j = getChar(this.fCurrentOffset);
      this.fCurrentOffset += this.fBytesPerChar;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\UCSReader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */