package com.ibm.xml.internal;

import java.io.IOException;

public class InvalidEncodingException extends IOException {
  public InvalidEncodingException() {}
  
  public InvalidEncodingException(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\InvalidEncodingException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */