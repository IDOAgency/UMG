package com.ibm.xml.internal;

import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.StringProducer;

public final class DefaultStringPool implements StringPool {
  private static final int INITIAL_CHUNK_SHIFT = 5;
  
  private static final int INITIAL_CHUNK_SIZE = 32;
  
  private static final int CHUNK_SHIFT = 10;
  
  private static final int CHUNK_SIZE = 1024;
  
  private static final int CHUNK_MASK = 1023;
  
  private static final int INITIAL_CHUNK_COUNT = 32;
  
  private ParserState fParserState;
  
  private int fStringCount;
  
  private int fNullString;
  
  private int fStringFreeList = -1;
  
  private String[][] fString = new String[32][];
  
  private StringProducer[][] fStringProducer = new StringProducer[32][];
  
  private int[][] fOffset = new int[32][];
  
  private int[][] fLength = new int[32][];
  
  private int fStringListCount;
  
  private int fActiveStringList = -1;
  
  private int[][] fStringList = new int[32][];
  
  private static final int INITIAL_BUCKET_SIZE = 4;
  
  private static final int HASHTABLE_SIZE = 128;
  
  private int[][] fSymbolTable = new int[128][];
  
  public DefaultStringPool(ParserState paramParserState) {
    this.fParserState = paramParserState;
    this.fNullString = addSymbol("");
  }
  
  public void reset(ParserState paramParserState) {
    this.fParserState = paramParserState;
    byte b1 = 0;
    byte b2 = 0;
    for (byte b3 = 0; b3 < this.fStringCount; b3++) {
      this.fString[b1][b2] = null;
      this.fStringProducer[b1][b2] = null;
      if (++b2 == 'Ѐ') {
        b1++;
        b2 = 0;
      } 
    } 
    for (byte b4 = 0; b4 < ''; b4++)
      this.fSymbolTable[b4] = null; 
    this.fStringCount = 0;
    this.fStringFreeList = -1;
    this.fStringListCount = 0;
    this.fActiveStringList = -1;
    this.fNullString = addSymbol("");
  }
  
  public StringPool resetOrCopy(ParserState paramParserState) { return new DefaultStringPool(paramParserState); }
  
  private boolean ensureCapacity(int paramInt1, int paramInt2) {
    try {
      return !(this.fOffset[paramInt1][paramInt2] != 0);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      if (paramInt2 == 0) {
        String[][] arrayOfString = new String[paramInt1 * 2][];
        System.arraycopy(this.fString, 0, arrayOfString, 0, paramInt1);
        this.fString = arrayOfString;
        StringProducer[][] arrayOfStringProducer = new StringProducer[paramInt1 * 2][];
        System.arraycopy(this.fStringProducer, 0, arrayOfStringProducer, 0, paramInt1);
        this.fStringProducer = arrayOfStringProducer;
        int[][] arrayOfInt = new int[paramInt1 * 2][];
        System.arraycopy(this.fOffset, 0, arrayOfInt, 0, paramInt1);
        this.fOffset = arrayOfInt;
        arrayOfInt = new int[paramInt1 * 2][];
        System.arraycopy(this.fLength, 0, arrayOfInt, 0, paramInt1);
        this.fLength = arrayOfInt;
      } else {
        String[] arrayOfString = new String[paramInt2 * 2];
        System.arraycopy(this.fString[paramInt1], 0, arrayOfString, 0, paramInt2);
        this.fString[paramInt1] = arrayOfString;
        StringProducer[] arrayOfStringProducer = new StringProducer[paramInt2 * 2];
        System.arraycopy(this.fStringProducer[paramInt1], 0, arrayOfStringProducer, 0, paramInt2);
        this.fStringProducer[paramInt1] = arrayOfStringProducer;
        int[] arrayOfInt = new int[paramInt2 * 2];
        System.arraycopy(this.fOffset[paramInt1], 0, arrayOfInt, 0, paramInt2);
        this.fOffset[paramInt1] = arrayOfInt;
        arrayOfInt = new int[paramInt2 * 2];
        System.arraycopy(this.fLength[paramInt1], 0, arrayOfInt, 0, paramInt2);
        this.fLength[paramInt1] = arrayOfInt;
        return true;
      } 
    } catch (NullPointerException nullPointerException) {}
    this.fString[paramInt1] = new String[32];
    this.fStringProducer[paramInt1] = new StringProducer[32];
    this.fOffset[paramInt1] = new int[32];
    this.fLength[paramInt1] = new int[32];
    return true;
  }
  
  private void checkStringCount() {}
  
  public int addString(String paramString) {
    int k;
    int j;
    int i;
    if (this.fStringFreeList != -1) {
      k = this.fStringFreeList;
      i = k >> 10;
      j = k & 0x3FF;
      this.fStringFreeList = this.fOffset[i][j];
    } else {
      k = this.fStringCount++;
      i = k >> 10;
      j = k & 0x3FF;
      ensureCapacity(i, j);
    } 
    this.fString[i][j] = paramString;
    this.fStringProducer[i][j] = null;
    this.fOffset[i][j] = 0;
    this.fLength[i][j] = paramString.length();
    return k;
  }
  
  public int addString(StringProducer paramStringProducer, int paramInt1, int paramInt2) {
    int k;
    int j;
    int i;
    if (this.fStringFreeList != -1) {
      k = this.fStringFreeList;
      i = k >> 10;
      j = k & 0x3FF;
      this.fStringFreeList = this.fOffset[i][j];
    } else {
      k = this.fStringCount++;
      i = k >> 10;
      j = k & 0x3FF;
      ensureCapacity(i, j);
    } 
    this.fString[i][j] = null;
    this.fStringProducer[i][j] = paramStringProducer;
    this.fOffset[i][j] = paramInt1;
    this.fLength[i][j] = paramInt2;
    return k;
  }
  
  private void hashSymbol(int[] paramArrayOfInt, int paramInt1, int paramInt2, int paramInt3) {
    if (paramArrayOfInt == null) {
      paramArrayOfInt = new int[13];
      paramArrayOfInt[0] = 1;
      paramArrayOfInt[1] = paramInt1;
      paramArrayOfInt[2] = paramInt2;
      paramArrayOfInt[3] = paramInt3;
      int k = paramInt1 % 128;
      this.fSymbolTable[k] = paramArrayOfInt;
      return;
    } 
    int i = paramArrayOfInt[0];
    int j = 1 + i * 3;
    if (j == paramArrayOfInt.length) {
      int k = i + 4;
      int[] arrayOfInt = new int[1 + k * 3];
      System.arraycopy(paramArrayOfInt, 0, arrayOfInt, 0, j);
      paramArrayOfInt = arrayOfInt;
      int m = paramInt1 % 128;
      this.fSymbolTable[m] = paramArrayOfInt;
    } 
    paramArrayOfInt[j++] = paramInt1;
    paramArrayOfInt[j++] = paramInt2;
    paramArrayOfInt[j++] = paramInt3;
    paramArrayOfInt[0] = ++i;
  }
  
  public int addSymbol(String paramString) {
    int i1;
    int n;
    int m;
    int i = paramString.length();
    int j = StringHasher.hashString(paramString, i);
    int k = j % 128;
    int[] arrayOfInt = this.fSymbolTable[k];
    if (arrayOfInt != null) {
      m = 1;
      for (n = 0; n < arrayOfInt[0]; n++) {
        if (arrayOfInt[m] == j) {
          i1 = arrayOfInt[m + true];
          int i2 = arrayOfInt[m + 2];
          if (paramString.equals(this.fString[i1][i2]))
            return (i1 << 10) + i2; 
        } 
        m += true;
      } 
    } 
    if (this.fStringFreeList != -1) {
      i1 = this.fStringFreeList;
      m = i1 >> 10;
      n = i1 & 0x3FF;
      this.fStringFreeList = this.fOffset[m][n];
    } else {
      i1 = this.fStringCount++;
      m = i1 >> 10;
      n = i1 & 0x3FF;
      ensureCapacity(m, n);
    } 
    this.fString[m][n] = paramString;
    this.fStringProducer[m][n] = null;
    this.fOffset[m][n] = -1;
    this.fLength[m][n] = i;
    hashSymbol(arrayOfInt, j, m, n);
    return i1;
  }
  
  public int addSymbol(StringProducer paramStringProducer, int paramInt1, int paramInt2, int paramInt3) {
    int m;
    int k;
    int j;
    int i = paramInt3 % 128;
    int[] arrayOfInt = this.fSymbolTable[i];
    if (arrayOfInt != null) {
      j = 1;
      for (k = 0; k < arrayOfInt[0]; k++) {
        if (arrayOfInt[j] == paramInt3) {
          m = arrayOfInt[j + true];
          int n = arrayOfInt[j + 2];
          if (paramStringProducer.equalsString(paramInt1, paramInt2, this.fString[m][n], this.fLength[m][n]))
            return (m << 10) + n; 
        } 
        j += true;
      } 
    } 
    if (this.fStringFreeList != -1) {
      m = this.fStringFreeList;
      j = m >> 10;
      k = m & 0x3FF;
      this.fStringFreeList = this.fOffset[j][k];
    } else {
      m = this.fStringCount++;
      j = m >> 10;
      k = m & 0x3FF;
      ensureCapacity(j, k);
    } 
    String str = paramStringProducer.toString(paramInt1, paramInt2);
    this.fString[j][k] = str;
    this.fStringProducer[j][k] = null;
    this.fOffset[j][k] = -1;
    this.fLength[j][k] = str.length();
    hashSymbol(arrayOfInt, paramInt3, j, k);
    return m;
  }
  
  private boolean ensureListCapacity(int paramInt1, int paramInt2) {
    try {
      return !(this.fStringList[paramInt1][paramInt2] != 0);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      if (paramInt2 == 0) {
        int[][] arrayOfInt = new int[paramInt1 * 2][];
        System.arraycopy(this.fStringList, 0, arrayOfInt, 0, paramInt1);
        this.fStringList = arrayOfInt;
      } else {
        int[] arrayOfInt = new int[paramInt2 * 2];
        System.arraycopy(this.fStringList[paramInt1], 0, arrayOfInt, 0, paramInt2);
        this.fStringList[paramInt1] = arrayOfInt;
        return true;
      } 
    } catch (NullPointerException nullPointerException) {}
    this.fStringList[paramInt1] = new int[32];
    return true;
  }
  
  public int startStringList() {
    this.fActiveStringList = this.fStringListCount;
    return this.fStringListCount;
  }
  
  public boolean addStringToList(int paramInt1, int paramInt2) {
    if (paramInt2 == -1 || paramInt1 != this.fActiveStringList)
      return false; 
    int i = this.fStringListCount >> 10;
    int j = this.fStringListCount & 0x3FF;
    ensureListCapacity(i, j);
    this.fStringList[i][j] = paramInt2;
    this.fStringListCount++;
    return true;
  }
  
  public void finishStringList(int paramInt) {
    if (paramInt != this.fActiveStringList)
      return; 
    int i = this.fStringListCount >> 10;
    int j = this.fStringListCount & 0x3FF;
    ensureListCapacity(i, j);
    this.fStringList[i][j] = -1;
    this.fActiveStringList = -1;
  }
  
  public int stringListLength(int paramInt) {
    int i = paramInt >> 10;
    int j = paramInt & 0x3FF;
    byte b = 0;
    while (true) {
      if (this.fStringList[i][j] == -1)
        return b; 
      b++;
      if (++j == 1024) {
        i++;
        j = 0;
      } 
    } 
  }
  
  public boolean stringInList(int paramInt1, int paramInt2) {
    int i = paramInt1 >> 10;
    int j = paramInt1 & 0x3FF;
    while (true) {
      if (this.fStringList[i][j] == paramInt2)
        return true; 
      if (this.fStringList[i][j] == -1)
        return false; 
      if (++j == 1024) {
        i++;
        j = 0;
      } 
    } 
  }
  
  public int[] stringsInList(int paramInt) {
    int i = paramInt >> 10;
    int j = paramInt & 0x3FF;
    int[] arrayOfInt = new int[stringListLength(paramInt)];
    byte b = 0;
    while (true) {
      if (this.fStringList[i][j] == -1 || b >= arrayOfInt.length)
        return arrayOfInt; 
      arrayOfInt[b] = this.fStringList[i][j];
      b++;
      if (++j == 1024) {
        i++;
        j = 0;
      } 
    } 
  }
  
  private void releaseStringInternal(int paramInt1, int paramInt2) {
    this.fString[paramInt1][paramInt2] = null;
    this.fStringProducer[paramInt1][paramInt2] = null;
    this.fLength[paramInt1][paramInt2] = 0;
    this.fOffset[paramInt1][paramInt2] = this.fStringFreeList;
    int i = (paramInt1 << 10) + paramInt2;
    this.fStringFreeList = i;
  }
  
  public void releaseString(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fStringCount)
      return; 
    int i = paramInt >> 10;
    int j = paramInt & 0x3FF;
    if (this.fOffset[i][j] != -1)
      releaseStringInternal(i, j); 
  }
  
  public String toString(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fStringCount)
      return null; 
    int i = paramInt >> 10;
    int j = paramInt & 0x3FF;
    String str = this.fString[i][j];
    if (str != null)
      return str; 
    str = this.fStringProducer[i][j].toString(this.fOffset[i][j], this.fLength[i][j]);
    this.fString[i][j] = str;
    return str;
  }
  
  public String orphanString(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fStringCount)
      return null; 
    int i = paramInt >> 10;
    int j = paramInt & 0x3FF;
    String str = this.fString[i][j];
    if (str == null) {
      str = this.fStringProducer[i][j].toString(this.fOffset[i][j], this.fLength[i][j]);
      releaseStringInternal(i, j);
    } else if (this.fOffset[i][j] != -1) {
      releaseStringInternal(i, j);
    } 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\DefaultStringPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */