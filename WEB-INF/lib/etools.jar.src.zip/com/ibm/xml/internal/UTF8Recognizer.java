package com.ibm.xml.internal;

import com.ibm.xml.framework.ChunkyByteArray;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.XMLDeclRecognizer;
import com.ibm.xml.framework.XMLReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import org.xml.sax.InputSource;

public class UTF8Recognizer extends XMLDeclRecognizer {
  public XMLReader recognize(ParserState paramParserState, InputSource paramInputSource, ChunkyByteArray paramChunkyByteArray, boolean paramBoolean) throws Exception {
    UTF8CharReader uTF8CharReader = null;
    byte b = paramChunkyByteArray.byteAt(0);
    if (b == 60) {
      byte b1 = paramChunkyByteArray.byteAt(1);
      if (b1 == 63 && paramChunkyByteArray.byteAt(2) == 120 && paramChunkyByteArray.byteAt(3) == 109 && paramChunkyByteArray.byteAt(4) == 108) {
        byte b2 = paramChunkyByteArray.byteAt(5);
        if (b2 == 32 || b2 == 9 || b2 == 10 || b2 == 13) {
          int i = prescanXMLDeclOrTextDecl(new XMLDeclReader(paramChunkyByteArray, paramParserState), paramBoolean);
          if (i != -1) {
            String str1 = paramParserState.getStringPool().orphanString(i).toUpperCase();
            if ("ISO-10646-UCS-2".equals(str1))
              throw new UnsupportedEncodingException(str1); 
            if ("ISO-10646-UCS-4".equals(str1))
              throw new UnsupportedEncodingException(str1); 
            if ("UTF-16".equals(str1))
              throw new UnsupportedEncodingException(str1); 
            String str2 = MIME2Java.convert(str1);
            if (str2 == null)
              if (paramParserState.getAllowJavaEncodingName()) {
                str2 = str1;
              } else {
                throw new UnsupportedEncodingException(str1);
              }  
            try {
              paramChunkyByteArray.rewind();
              if ("UTF-8".equalsIgnoreCase(str2) || "UTF8".equalsIgnoreCase(str2)) {
                uTF8CharReader = new UTF8CharReader(paramParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), paramChunkyByteArray);
              } else {
                CharReader charReader = new CharReader(paramParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), new InputStreamReader(paramChunkyByteArray, str2));
              } 
            } catch (UnsupportedEncodingException unsupportedEncodingException) {
              throw unsupportedEncodingException;
            } catch (Exception exception) {
              exception.printStackTrace();
            } 
          } else {
            paramChunkyByteArray.rewind();
            uTF8CharReader = new UTF8CharReader(paramParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), paramChunkyByteArray);
          } 
        } 
      } 
    } 
    return uTF8CharReader;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\UTF8Recognizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */