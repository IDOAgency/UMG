package com.ibm.xml.internal;

public final class ErrorCode {
  public static final int E_EXCLAM0 = 0;
  
  public static final int E_ATTD0 = 2;
  
  public static final int E_ATTD2 = 4;
  
  public static final int E_ATTD3 = 5;
  
  public static final int E_ATTD4 = 6;
  
  public static final int E_ATTEQ0 = 8;
  
  public static final int E_ATTEQ1 = 9;
  
  public static final int W_ATTEQ2 = 10;
  
  public static final int E_ATTL0 = 11;
  
  public static final int V_ATTL2 = 13;
  
  public static final int W_ATTL1 = 14;
  
  public static final int W_ATTL2 = 15;
  
  public static final int E_ATTVAL0 = 16;
  
  public static final int E_ATTVAL1 = 17;
  
  public static final int E_CDATA0 = 18;
  
  public static final int E_CDATA1 = 19;
  
  public static final int E_COM0 = 20;
  
  public static final int E_COM1 = 21;
  
  public static final int E_COM2 = 22;
  
  public static final int E_COND0 = 23;
  
  public static final int E_COND1 = 24;
  
  public static final int E_COND3 = 25;
  
  public static final int V_CONT0 = 26;
  
  public static final int V_CONT1 = 27;
  
  public static final int E_CS1 = 29;
  
  public static final int E_CS2 = 30;
  
  public static final int E_CS3 = 31;
  
  public static final int E_CS5 = 33;
  
  public static final int E_CS6 = 34;
  
  public static final int E_CS9 = 37;
  
  public static final int E_CSa = 38;
  
  public static final int E_DOCTYPE0 = 39;
  
  public static final int E_DOCTYPE1 = 40;
  
  public static final int E_DOCTYPE2 = 41;
  
  public static final int E_DOCTYPE3 = 42;
  
  public static final int E_DTD0 = 43;
  
  public static final int E_DTD1 = 44;
  
  public static final int E_DTD2 = 45;
  
  public static final int E_DTD3 = 46;
  
  public static final int E_DTD4 = 47;
  
  public static final int E_ELEM0 = 48;
  
  public static final int E_ELEM1 = 49;
  
  public static final int E_ELEM2 = 50;
  
  public static final int V_ELEM3 = 51;
  
  public static final int E_ENC0 = 52;
  
  public static final int E_ENC1 = 53;
  
  public static final int E_ENC2 = 54;
  
  public static final int E_ENC3 = 55;
  
  public static final int E_ENC4 = 56;
  
  public static final int E_ENC5 = 57;
  
  public static final int E_ENC6 = 58;
  
  public static final int E_ENC7 = 59;
  
  public static final int E_ENTITY0 = 60;
  
  public static final int E_ENTITY1 = 61;
  
  public static final int E_ENTITY2 = 62;
  
  public static final int E_ENTITY3 = 63;
  
  public static final int E_ENTITY4 = 64;
  
  public static final int E_ENTITY5 = 65;
  
  public static final int W_ENTITY6 = 66;
  
  public static final int E_ENTITY7 = 67;
  
  public static final int V_ENTITY8 = 68;
  
  public static final int V_ENTITY9 = 69;
  
  public static final int E_ENTITYa = 70;
  
  public static final int E_ENUM0 = 71;
  
  public static final int E_ENUM1 = 72;
  
  public static final int E_ENUM2 = 73;
  
  public static final int E_ENUM3 = 74;
  
  public static final int E_ENUM5 = 76;
  
  public static final int E_EOF = 77;
  
  public static final int E_EXT0 = 78;
  
  public static final int E_EXT1 = 79;
  
  public static final int E_EXT2 = 80;
  
  public static final int E_EXT3 = 81;
  
  public static final int E_EXT4 = 82;
  
  public static final int E_EXT5 = 83;
  
  public static final int V_IDREF0 = 84;
  
  public static final int E_INVCHAR0 = 85;
  
  public static final int E_INVENC0 = 86;
  
  public static final int E_INVENC1 = 87;
  
  public static final int E_IO0 = 88;
  
  public static final int E_NAMES0 = 89;
  
  public static final int E_NMTOK0 = 90;
  
  public static final int E_NOT0 = 91;
  
  public static final int E_PEREF0 = 92;
  
  public static final int E_PEREF1 = 93;
  
  public static final int V_PEREF2 = 94;
  
  public static final int E_PEREF4 = 96;
  
  public static final int E_PEREF5 = 97;
  
  public static final int V_PEREF7 = 99;
  
  public static final int E_PEREF9 = 101;
  
  public static final int E_PI0 = 102;
  
  public static final int E_PI2 = 104;
  
  public static final int E_PI3 = 105;
  
  public static final int E_PI4 = 106;
  
  public static final int E_PI5 = 107;
  
  public static final int E_PI6 = 108;
  
  public static final int E_PI7 = 109;
  
  public static final int E_REFER0 = 110;
  
  public static final int E_REFER1 = 111;
  
  public static final int E_REFER2 = 112;
  
  public static final int E_REFER3 = 113;
  
  public static final int E_REFER4 = 114;
  
  public static final int E_SPACE = 115;
  
  public static final int E_STRUCT0 = 116;
  
  public static final int E_STRUCT1 = 117;
  
  public static final int E_STRUCT2 = 118;
  
  public static final int E_STRUCT3 = 119;
  
  public static final int W_STRUCT4 = 120;
  
  public static final int W_STRUCT5 = 121;
  
  public static final int E_TAG0 = 122;
  
  public static final int E_TAG1 = 123;
  
  public static final int E_TAG3 = 124;
  
  public static final int E_TAG4 = 125;
  
  public static final int V_TAG5 = 126;
  
  public static final int V_TAG6 = 127;
  
  public static final int V_TAG7 = 128;
  
  public static final int V_TAG8 = 129;
  
  public static final int V_TAG9 = 130;
  
  public static final int V_TAGa = 131;
  
  public static final int V_TAGb = 132;
  
  public static final int V_TAGc = 133;
  
  public static final int V_TAGd = 134;
  
  public static final int E_TAGe = 135;
  
  public static final int E_TAGf = 136;
  
  public static final int E_TAGg = 137;
  
  public static final int E_TAGh = 138;
  
  public static final int E_TAGi = 139;
  
  public static final int E_TAGj = 140;
  
  public static final int E_TAGk = 141;
  
  public static final int E_TAGl = 142;
  
  public static final int E_TAGn = 143;
  
  public static final int E_TAGm = 144;
  
  public static final int E_XML0 = 145;
  
  public static final int E_XML1 = 146;
  
  public static final int E_XML2 = 147;
  
  public static final int E_XML3 = 148;
  
  public static final int E_XML4 = 149;
  
  public static final int E_XML5 = 150;
  
  public static final int E_XML6 = 151;
  
  public static final int E_VAL_CST = 152;
  
  public static final int E_VAL_UST = 153;
  
  public static final int E_VAL_BST = 154;
  
  public static final int E_VAL_LST = 155;
  
  public static final int E_VAL_CMSI = 156;
  
  public static final int E_VAL_NIICM = 157;
  
  public static final int E_VAL_WCGHI = 158;
  
  public static final int E_VAL_NPCD = 159;
  
  public static final int E_VAL_NRE = 160;
  
  public static final int V_TAGo = 161;
  
  public static final int E_PEREFa = 162;
  
  public static final int E_NOT1 = 163;
  
  public static final int V_CONT2 = 164;
  
  public static final int W_DTD5 = 165;
  
  public static final int V_ELEM4 = 166;
  
  public static final int E_MAX_ERROR = 166;
  
  private static final String[] fgErrorKeys = { 
      "E_!0", "E_!1", "E_ATTD0", "E_ATTD1", "E_ATTD2", "E_ATTD3", "E_ATTD4", "E_ATTD5", "E_ATTEQ0", "E_ATTEQ1", 
      "W_ATTEQ2", "E_ATTL0", "E_ATTL1", "V_ATTL2", "W_ATTL1", "W_ATTL2", "E_ATTVAL0", "E_ATTVAL1", "E_CDATA0", "E_CDATA1", 
      "E_COM0", "E_COM1", "E_COM2", "E_COND0", "E_COND1", "E_COND3", "V_CONT0", "V_CONT1", "E_CS0", "E_CS1", 
      "E_CS2", "E_CS3", "E_CS4", "E_CS5", "E_CS6", "V_CS7", "E_CS8", "E_CS9", "E_CSa", "E_DOCTYPE0", 
      "E_DOCTYPE1", "E_DOCTYPE2", "E_DOCTYPE3", "E_DTD0", "E_DTD1", "E_DTD2", "E_DTD3", "E_DTD4", "E_ELEM0", "E_ELEM1", 
      "E_ELEM2", "V_ELEM3", "E_ENC0", "E_ENC1", "E_ENC2", "E_ENC3", "E_ENC4", "E_ENC5", "E_ENC6", "E_ENC7", 
      "E_ENTITY0", "E_ENTITY1", "E_ENTITY2", "E_ENTITY3", "E_ENTITY4", "E_ENTITY5", "W_ENTITY6", "E_ENTITY7", "V_ENTITY8", "V_ENTITY9", 
      "E_ENTITYa", "E_ENUM0", "E_ENUM1", "E_ENUM2", "E_ENUM3", "E_ENUM4", "E_ENUM5", "E_EOF", "E_EXT0", "E_EXT1", 
      "E_EXT2", "E_EXT3", "E_EXT4", "E_EXT5", "V_IDREF0", "E_INVCHAR0", "E_INVENC0", "E_INVENC1", "E_IO0", "E_NAMES0", 
      "E_NMTOK0", "E_NOT0", "E_PEREF0", "E_PEREF1", "V_PEREF2", "E_PEREF3", "E_PEREF4", "E_PEREF5", "E_PEREF6", "V_PEREF7", 
      "E_PEREF8", "E_PEREF9", "E_PI0", "E_PI1", "E_PI2", "E_PI3", "E_PI4", "E_PI5", "E_PI6", "E_PI7", 
      "E_REFER0", "E_REFER1", "E_REFER2", "E_REFER3", "E_REFER4", "E_SPACE", "E_STRUCT0", "E_STRUCT1", "E_STRUCT2", "E_STRUCT3", 
      "W_STRUCT4", "W_STRUCT5", "E_TAG0", "E_TAG1", "E_TAG3", "E_TAG4", "V_TAG5", "V_TAG6", "V_TAG7", "V_TAG8", 
      "V_TAG9", "V_TAGa", "V_TAGb", "V_TAGc", "V_TAGd", "E_TAGe", "E_TAGf", "E_TAGg", "E_TAGh", "E_TAGi", 
      "E_TAGj", "E_TAGk", "E_TAGl", "E_TAGn", "E_TAGm", "E_XML0", "E_XML1", "E_XML2", "E_XML3", "E_XML4", 
      "E_XML5", "E_XML6", "E_VAL_CST", "E_VAL_UST", "E_VAL_BST", "E_VAL_LST", "E_VAL_CMSI", "E_VAL_NIICM", "E_VAL_WCGHI", "E_VAL_NPCD", 
      "E_VAL_NRE", "V_TAGo", "E_PEREFa", "E_NOT1", "V_CONT2", "W_DTD5", "V_ELEM4", null };
  
  public static final String getErrorKey(int paramInt) { return (paramInt < 0 || paramInt > fgErrorKeys.length) ? null : fgErrorKeys[paramInt]; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\ErrorCode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */