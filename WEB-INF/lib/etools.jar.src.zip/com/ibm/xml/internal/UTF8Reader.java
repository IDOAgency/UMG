package com.ibm.xml.internal;

import com.ibm.xml.framework.ChunkyCharArray;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.ScanContentState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.StringProducer;
import com.ibm.xml.framework.XMLDocumentHandler;
import com.ibm.xml.framework.XMLErrorHandler;
import com.ibm.xml.framework.XMLReader;
import com.ibm.xml.framework.XMLScanner;
import java.io.InputStream;

final class UTF8Reader extends XMLReader {
  protected static final int CHUNK_SHIFT = 14;
  
  protected static final int CHUNK_SIZE = 16384;
  
  protected static final int CHUNK_MASK = 16383;
  
  protected char[] fCharacters = new char[256];
  
  protected int fCharDataLength;
  
  protected XMLScanner fScanner;
  
  protected StringPool fStringPool;
  
  protected XMLDocumentHandler fDocumentHandler;
  
  protected boolean fSendCharDataAsCharArray = false;
  
  protected XMLErrorHandler fErrorHandler;
  
  protected InputStream fInputStream;
  
  protected UTF8DataChunk fCurrentChunk;
  
  protected int fCurrentIndex;
  
  protected byte[] fMostRecentData;
  
  protected int fMostRecentByte;
  
  protected int fLength;
  
  protected boolean fCheckOverflow = false;
  
  protected byte[] fOverflow;
  
  protected int fOverflowOffset;
  
  protected int fOverflowEnd;
  
  protected boolean fSkipLinefeed = false;
  
  protected int fPartialMultiByteIn;
  
  protected byte[] fPartialMultiByteChar = new byte[4];
  
  protected boolean fPartialMultiByteResult = false;
  
  protected int fFastCopyCount;
  
  protected int fOutputOffset;
  
  protected int fPartialMultiByteOut;
  
  UTF8Reader(ParserState paramParserState, String paramString1, String paramString2, InputStream paramInputStream) throws Exception {
    super(paramParserState, paramString1, paramString2);
    this.fInputStream = paramInputStream;
    this.fScanner = paramParserState.getScanner();
    this.fStringPool = paramParserState.cacheStringPool();
    this.fDocumentHandler = paramParserState.getDocumentHandler();
    this.fSendCharDataAsCharArray = !(this.fDocumentHandler == null || !this.fDocumentHandler.sendCharDataAsCharArray());
    this.fErrorHandler = paramParserState.getErrorHandler();
    this.fCurrentChunk = new UTF8DataChunk(this, this.fStringPool, null);
    fillCurrentChunk();
  }
  
  public int addString(int paramInt1, int paramInt2) { return (paramInt2 == 0) ? 0 : this.fCurrentChunk.addString(paramInt1, paramInt2); }
  
  public int addSymbol(int paramInt1, int paramInt2) { return (paramInt2 == 0) ? 0 : this.fCurrentChunk.addSymbol(paramInt1, paramInt2, 0); }
  
  protected int addSymbol(int paramInt1, int paramInt2, int paramInt3) { return this.fCurrentChunk.addSymbol(paramInt1, paramInt2, paramInt3); }
  
  public void append(ChunkyCharArray paramChunkyCharArray, int paramInt1, int paramInt2) { this.fCurrentChunk.append(paramChunkyCharArray, paramInt1, paramInt2); }
  
  protected int slowLoadNextByte() throws Exception {
    if (this.fCurrentChunk.nextChunk() != null) {
      this.fCurrentChunk = this.fCurrentChunk.nextChunk();
      this.fCurrentIndex = 0;
      this.fMostRecentData = this.fCurrentChunk.toByteArray();
      return this.fMostRecentByte = this.fMostRecentData[this.fCurrentIndex] & 0xFF;
    } 
    this.fCurrentChunk = new UTF8DataChunk(this, this.fStringPool, this.fCurrentChunk);
    return fillCurrentChunk();
  }
  
  protected int loadNextByte() throws Exception {
    this.fCurrentOffset++;
    return (++this.fCurrentIndex == 16384) ? slowLoadNextByte() : (this.fMostRecentByte = this.fMostRecentData[this.fCurrentIndex] & 0xFF);
  }
  
  protected void checkEOF(int paramInt) {
    if (paramInt > this.fLength)
      throw new ArrayIndexOutOfBoundsException(); 
  }
  
  protected void skipOneCharStartingWithByte(int paramInt) {
    if ((0x80 & paramInt) == 0) {
      if (paramInt == 0) {
        int i = this.fCurrentOffset + 1;
        if (i > this.fLength)
          throw new ArrayIndexOutOfBoundsException(); 
        this.fCharacterCounter++;
        return;
      } 
      if (paramInt == 10) {
        this.fLinefeedCounter++;
        this.fCharacterCounter = 1;
        return;
      } 
      this.fCharacterCounter++;
      return;
    } 
    this.fCharacterCounter++;
    loadNextByte();
    if ((0xE0 & paramInt) == 192)
      return; 
    loadNextByte();
    if ((0xF0 & paramInt) == 224)
      return; 
    loadNextByte();
  }
  
  public int skipOneChar() throws Exception {
    int i = this.fMostRecentByte;
    skipOneCharStartingWithByte(i);
    loadNextByte();
    return this.fCurrentOffset;
  }
  
  public int skipAsciiChar() throws Exception {
    this.fCharacterCounter++;
    loadNextByte();
    return this.fCurrentOffset;
  }
  
  public int skipToChar(char paramChar) throws Exception {
    for (int i = this.fMostRecentByte;; i = loadNextByte()) {
      if (i == paramChar)
        return this.fCurrentOffset; 
      skipOneCharStartingWithByte(i);
    } 
  }
  
  public int skipPastChar(char paramChar) throws Exception {
    for (int i = this.fMostRecentByte;; i = loadNextByte()) {
      if (i == paramChar) {
        this.fCharacterCounter++;
        loadNextByte();
        return this.fCurrentOffset;
      } 
      skipOneCharStartingWithByte(i);
    } 
  }
  
  public boolean skippedValidChar() throws Exception {
    int i = this.fMostRecentByte;
    if ((0x80 & i) == 0) {
      if (i >= 32 || i == 9) {
        this.fCharacterCounter++;
        loadNextByte();
        return true;
      } 
      if (i == 10) {
        this.fLinefeedCounter++;
        this.fCharacterCounter = 1;
        loadNextByte();
        return true;
      } 
      if (i == 0) {
        int i1 = this.fCurrentOffset + 1;
        if (i1 > this.fLength)
          throw new ArrayIndexOutOfBoundsException(); 
      } 
      return false;
    } 
    UTF8DataChunk uTF8DataChunk = this.fCurrentChunk;
    int j = this.fCurrentIndex;
    int k = this.fCurrentOffset;
    int m = loadNextByte();
    if ((0xE0 & i) == 192) {
      this.fCharacterCounter++;
      loadNextByte();
      return true;
    } 
    int n = loadNextByte();
    if ((0xF0 & i) == 224) {
      if ((i != 237 || m < 160) && (i != 239 || m != 191 || n < 190)) {
        this.fCharacterCounter++;
        loadNextByte();
        return true;
      } 
      this.fCurrentChunk = uTF8DataChunk;
      this.fCurrentIndex = j;
      this.fCurrentOffset = k;
      this.fMostRecentData = uTF8DataChunk.toByteArray();
      this.fMostRecentByte = i;
      return false;
    } 
    loadNextByte();
    if (i <= 244 && (i != 244 || m < 144)) {
      this.fCharacterCounter++;
      loadNextByte();
      return true;
    } 
    this.fCurrentChunk = uTF8DataChunk;
    this.fCurrentIndex = j;
    this.fCurrentOffset = k;
    this.fMostRecentData = uTF8DataChunk.toByteArray();
    this.fMostRecentByte = i;
    return false;
  }
  
  public boolean lookingAtValidChar() throws Exception {
    int i = this.fMostRecentByte;
    if ((0x80 & i) == 0) {
      if (i >= 32 || i == 9 || i == 10)
        return true; 
      if (i == 0) {
        int i1 = this.fCurrentOffset + 1;
        if (i1 > this.fLength)
          throw new ArrayIndexOutOfBoundsException(); 
      } 
      return false;
    } 
    UTF8DataChunk uTF8DataChunk = this.fCurrentChunk;
    int j = this.fCurrentIndex;
    int k = this.fCurrentOffset;
    int m = loadNextByte();
    if ((0xE0 & i) == 192) {
      this.fCurrentChunk = uTF8DataChunk;
      this.fCurrentIndex = j;
      this.fCurrentOffset = k;
      this.fMostRecentData = uTF8DataChunk.toByteArray();
      this.fMostRecentByte = i;
      return true;
    } 
    int n = loadNextByte();
    if ((0xF0 & i) == 224) {
      this.fCurrentChunk = uTF8DataChunk;
      this.fCurrentIndex = j;
      this.fCurrentOffset = k;
      this.fMostRecentData = uTF8DataChunk.toByteArray();
      this.fMostRecentByte = i;
      return !((i == 237 && m >= 160) || (i == 239 && m == 191 && n >= 190));
    } 
    loadNextByte();
    this.fCurrentChunk = uTF8DataChunk;
    this.fCurrentIndex = j;
    this.fCurrentOffset = k;
    this.fMostRecentData = uTF8DataChunk.toByteArray();
    this.fMostRecentByte = i;
    return !(i > 244 || (i == 244 && m >= 144));
  }
  
  public int skipInvalidChar(int paramInt) throws Exception {
    String str2;
    String str1;
    int i;
    int j = this.fMostRecentByte;
    this.fCharacterCounter++;
    if ((j & 0x80) == 0) {
      i = j;
    } else {
      int k = loadNextByte();
      if ((0xE0 & j) == 192) {
        i = ((0x1F & j) << 6) + (0x3F & k);
      } else {
        int m = loadNextByte();
        if ((0xF0 & j) == 224) {
          i = ((0xF & j) << 12) + ((0x3F & k) << 6) + (0x3F & m);
        } else {
          int n = loadNextByte();
          i = ((0xF & j) << 18) + ((0x3F & k) << 12) + ((0x3F & m) << 6) + (0x3F & n);
        } 
      } 
    } 
    switch (paramInt) {
      case 63:
      case 85:
        str1 = Integer.toHexString(i);
        this.fErrorHandler.error1(paramInt, this.fStringPool.addString(str1));
        break;
      case 80:
      case 82:
      case 110:
        str1 = (new Character((char)i)).toString();
        this.fErrorHandler.error1(paramInt, this.fStringPool.addString(str1));
        break;
      case 43:
        str1 = (new Character((char)i)).toString();
        str2 = Integer.toHexString(i);
        this.fErrorHandler.error2(paramInt, this.fStringPool.addString(str1), this.fStringPool.addString(str2));
        break;
    } 
    loadNextByte();
    return this.fCurrentOffset;
  }
  
  public boolean skippedChar(char paramChar) throws Exception {
    int i = this.fMostRecentByte;
    if (i != paramChar)
      return false; 
    this.fCharacterCounter++;
    this.fCurrentOffset++;
    if (++this.fCurrentIndex == 16384) {
      slowLoadNextByte();
    } else {
      this.fMostRecentByte = this.fMostRecentData[this.fCurrentIndex] & 0xFF;
    } 
    return true;
  }
  
  public boolean lookingAtChar(char paramChar) throws Exception {
    int i = this.fMostRecentByte;
    return !(i != paramChar);
  }
  
  public boolean skippedSpace() throws Exception {
    int i = this.fMostRecentByte;
    if (i > 32)
      return false; 
    if (i == 32 || i == 9) {
      this.fCharacterCounter++;
    } else if (i == 10) {
      this.fLinefeedCounter++;
      this.fCharacterCounter = 1;
    } else {
      return false;
    } 
    this.fCurrentOffset++;
    if (++this.fCurrentIndex == 16384) {
      slowLoadNextByte();
    } else {
      this.fMostRecentByte = this.fMostRecentData[this.fCurrentIndex] & 0xFF;
    } 
    return true;
  }
  
  public boolean lookingAtSpace() throws Exception {
    int i = this.fMostRecentByte;
    return !(i != 32 && i != 9 && i != 10);
  }
  
  public int skipPastSpaces() throws Exception {
    for (int i = this.fMostRecentByte;; i = loadNextByte()) {
      if (i == 32 || i == 9) {
        this.fCharacterCounter++;
      } else if (i == 10) {
        this.fLinefeedCounter++;
        this.fCharacterCounter = 1;
      } else {
        return this.fCurrentOffset;
      } 
    } 
  }
  
  public int skipDecimalDigit() throws Exception {
    int i = this.fMostRecentByte;
    if (i < 48 || i > 57)
      return -1; 
    this.fCharacterCounter++;
    loadNextByte();
    return i - 48;
  }
  
  public int skipHexDigit() throws Exception {
    int i = this.fMostRecentByte;
    if (i > 102 || XMLReader.fgAsciiXDigitChar[i] == 0)
      return -1; 
    this.fCharacterCounter++;
    loadNextByte();
    return i - ((i < 65) ? 48 : (((i < 97) ? 65 : 97) - 10));
  }
  
  public boolean skippedAlpha() throws Exception {
    int i = this.fMostRecentByte;
    if (i > 122 || XMLReader.fgAsciiAlphaChar[i] == 0)
      return false; 
    this.fCharacterCounter++;
    loadNextByte();
    return true;
  }
  
  protected final boolean skippedAsciiCharWithFlag(byte paramByte) throws Exception {
    int i = this.fMostRecentByte;
    if ((i & 0x80) != 0 || (XMLReader.fgCharFlags[i] & paramByte) == 0)
      return false; 
    this.fCharacterCounter++;
    loadNextByte();
    return true;
  }
  
  public final boolean skippedVersionNum() throws Exception { return skippedAsciiCharWithFlag((byte)1); }
  
  public final boolean skippedEncName() throws Exception { return skippedAsciiCharWithFlag((byte)2); }
  
  public final boolean skippedPubidChar() throws Exception {
    int i = this.fMostRecentByte;
    if ((i & 0x80) != 0)
      return false; 
    if ((XMLReader.fgCharFlags[i] & 0x4) != 0) {
      this.fCharacterCounter++;
      loadNextByte();
      return true;
    } 
    if (i == 10) {
      this.fLinefeedCounter++;
      this.fCharacterCounter = 1;
      loadNextByte();
      return true;
    } 
    return false;
  }
  
  public boolean skippedString(char[] paramArrayOfChar) throws Exception {
    int i = paramArrayOfChar.length;
    byte[] arrayOfByte = this.fMostRecentData;
    int j = this.fCurrentIndex;
    if (j + i <= 16384) {
      for (byte b1 = 0; b1 < i; b1++) {
        if (arrayOfByte[j++] != paramArrayOfChar[b1])
          return false; 
      } 
      this.fCharacterCounter += i;
      this.fCurrentOffset += i;
      this.fCurrentIndex = j;
      if (j == 16384) {
        slowLoadNextByte();
      } else {
        this.fMostRecentByte = arrayOfByte[j] & 0xFF;
      } 
      return true;
    } 
    UTF8DataChunk uTF8DataChunk = this.fCurrentChunk;
    int k = this.fCurrentOffset;
    int m = j;
    byte b = 0;
    while (j < 16384) {
      if (arrayOfByte[j++] != paramArrayOfChar[b++])
        return false; 
    } 
    slowLoadNextByte();
    arrayOfByte = this.fMostRecentData;
    j = 0;
    while (b < i) {
      if (arrayOfByte[j++] != paramArrayOfChar[b++]) {
        this.fCurrentChunk = uTF8DataChunk;
        this.fCurrentIndex = m;
        this.fCurrentOffset = k;
        this.fMostRecentData = uTF8DataChunk.toByteArray();
        this.fMostRecentByte = this.fMostRecentData[m] & 0xFF;
        return false;
      } 
    } 
    this.fCharacterCounter += i;
    this.fCurrentOffset += i;
    this.fCurrentIndex = j;
    if (j == 16384) {
      slowLoadNextByte();
    } else {
      this.fMostRecentByte = arrayOfByte[j] & 0xFF;
    } 
    return true;
  }
  
  public int scanName(char paramChar, int paramInt) throws Exception {
    int k;
    int i = this.fCurrentOffset;
    byte[] arrayOfByte = this.fMostRecentData;
    int j = this.fMostRecentByte;
    if ((j & 0x80) == 0) {
      if (XMLReader.fgAsciiInitialNameChar[j] == 0)
        return -1; 
      k = j;
    } else {
      UTF8DataChunk uTF8DataChunk = this.fCurrentChunk;
      int i2 = this.fCurrentIndex;
      this.fCurrentOffset++;
      if (++this.fCurrentIndex == 16384) {
        this.fCurrentChunk = new UTF8DataChunk(this, this.fStringPool, this.fCurrentChunk);
        fillCurrentChunk();
        arrayOfByte = this.fMostRecentData;
      } 
      byte b1 = arrayOfByte[this.fCurrentIndex] & 0xFF;
      if ((0xE0 & j) == 192) {
        k = ((0x1F & j) << 6) + (0x3F & b1);
        if ((XMLReader.fgCharFlags[k] & 0x10) == 0) {
          this.fCurrentChunk = uTF8DataChunk;
          this.fCurrentIndex = i2;
          this.fCurrentOffset = i;
          this.fMostRecentData = uTF8DataChunk.toByteArray();
          this.fMostRecentByte = j;
          return -1;
        } 
      } else {
        this.fCurrentOffset++;
        if (++this.fCurrentIndex == 16384) {
          this.fCurrentChunk = new UTF8DataChunk(this, this.fStringPool, this.fCurrentChunk);
          fillCurrentChunk();
          arrayOfByte = this.fMostRecentData;
        } 
        byte b2 = arrayOfByte[this.fCurrentIndex] & 0xFF;
        if ((0xF0 & j) == 224) {
          if ((j == 237 && b1 >= 160) || (j == 239 && b1 == 191 && b2 >= 190)) {
            this.fCurrentChunk = uTF8DataChunk;
            this.fCurrentIndex = i2;
            this.fCurrentOffset = i;
            this.fMostRecentData = uTF8DataChunk.toByteArray();
            this.fMostRecentByte = j;
            return -1;
          } 
          k = ((0xF & j) << 12) + ((0x3F & b1) << 6) + (0x3F & b2);
          if ((XMLReader.fgCharFlags[k] & 0x10) == 0) {
            this.fCurrentChunk = uTF8DataChunk;
            this.fCurrentIndex = i2;
            this.fCurrentOffset = i;
            this.fMostRecentData = uTF8DataChunk.toByteArray();
            this.fMostRecentByte = j;
            return -1;
          } 
        } else {
          this.fCurrentChunk = uTF8DataChunk;
          this.fCurrentIndex = i2;
          this.fCurrentOffset = i;
          this.fMostRecentData = uTF8DataChunk.toByteArray();
          this.fMostRecentByte = j;
          return -1;
        } 
      } 
    } 
    int m = 0;
    byte b = 0;
    while (true) {
      m = StringHasher.hashChar(m, b++, k);
      this.fCharacterCounter++;
      this.fCurrentOffset++;
      if (++this.fCurrentIndex == 16384) {
        this.fCurrentChunk = new UTF8DataChunk(this, this.fStringPool, this.fCurrentChunk);
        fillCurrentChunk();
        arrayOfByte = this.fMostRecentData;
      } 
      j = arrayOfByte[this.fCurrentIndex] & 0xFF;
      if (paramChar != j) {
        if ((j & 0x80) == 0) {
          if (XMLReader.fgAsciiNameChar[j] != 0) {
            k = j;
            continue;
          } 
          break;
        } 
        UTF8DataChunk uTF8DataChunk = this.fCurrentChunk;
        int i2 = this.fCurrentOffset;
        int i3 = this.fCurrentIndex;
        this.fCurrentOffset++;
        if (++this.fCurrentIndex == 16384) {
          this.fCurrentChunk = new UTF8DataChunk(this, this.fStringPool, this.fCurrentChunk);
          fillCurrentChunk();
          arrayOfByte = this.fMostRecentData;
        } 
        byte b1 = arrayOfByte[this.fCurrentIndex] & 0xFF;
        if ((0xE0 & j) == 192) {
          k = ((0x1F & j) << 6) + (0x3F & b1);
          if ((XMLReader.fgCharFlags[k] & 0x20) == 0) {
            this.fCurrentChunk = uTF8DataChunk;
            this.fCurrentIndex = i3;
            this.fCurrentOffset = i2;
            this.fMostRecentData = uTF8DataChunk.toByteArray();
            break;
          } 
          continue;
        } 
        this.fCurrentOffset++;
        if (++this.fCurrentIndex == 16384) {
          this.fCurrentChunk = new UTF8DataChunk(this, this.fStringPool, this.fCurrentChunk);
          fillCurrentChunk();
          arrayOfByte = this.fMostRecentData;
        } 
        byte b2 = arrayOfByte[this.fCurrentIndex] & 0xFF;
        if ((0xF0 & j) == 224) {
          if ((j == 237 && b1 >= 160) || (j == 239 && b1 == 191 && b2 >= 190)) {
            this.fCurrentChunk = uTF8DataChunk;
            this.fCurrentIndex = i3;
            this.fCurrentOffset = i2;
            this.fMostRecentData = uTF8DataChunk.toByteArray();
            break;
          } 
          k = ((0xF & j) << 12) + ((0x3F & b1) << 6) + (0x3F & b2);
          if ((XMLReader.fgCharFlags[k] & 0x20) == 0) {
            this.fCurrentChunk = uTF8DataChunk;
            this.fCurrentIndex = i3;
            this.fCurrentOffset = i2;
            this.fMostRecentData = uTF8DataChunk.toByteArray();
            break;
          } 
          continue;
        } 
        this.fCurrentChunk = uTF8DataChunk;
        this.fCurrentIndex = i3;
        this.fCurrentOffset = i2;
        this.fMostRecentData = uTF8DataChunk.toByteArray();
      } 
      break;
    } 
    this.fMostRecentByte = j;
    int n = m;
    n &= Integer.MAX_VALUE;
    m = (n == 0) ? 1 : n;
    n = this.fCurrentOffset - i;
    int i1 = this.fCurrentChunk.addSymbol(i, n, m);
    return (paramInt == -1 || paramInt == i1) ? i1 : -1;
  }
  
  protected boolean skippedMultiByteCharWithFlag(int paramInt1, int paramInt2) throws Exception {
    UTF8DataChunk uTF8DataChunk = this.fCurrentChunk;
    int i = this.fCurrentOffset;
    int j = this.fCurrentIndex;
    int k = loadNextByte();
    if ((0xE0 & paramInt1) == 192) {
      if ((XMLReader.fgCharFlags[((0x1F & paramInt1) << 6) + (0x3F & k)] & paramInt2) == 0) {
        this.fCurrentChunk = uTF8DataChunk;
        this.fCurrentIndex = j;
        this.fCurrentOffset = i;
        this.fMostRecentData = uTF8DataChunk.toByteArray();
        this.fMostRecentByte = paramInt1;
        return false;
      } 
      return true;
    } 
    int m = loadNextByte();
    if ((0xF0 & paramInt1) == 224) {
      if ((paramInt1 == 237 && k >= 160) || (paramInt1 == 239 && k == 191 && m >= 190)) {
        this.fCurrentChunk = uTF8DataChunk;
        this.fCurrentIndex = j;
        this.fCurrentOffset = i;
        this.fMostRecentData = uTF8DataChunk.toByteArray();
        this.fMostRecentByte = paramInt1;
        return false;
      } 
      if ((XMLReader.fgCharFlags[((0xF & paramInt1) << 12) + ((0x3F & k) << 6) + (0x3F & m)] & paramInt2) == 0) {
        this.fCurrentChunk = uTF8DataChunk;
        this.fCurrentIndex = j;
        this.fCurrentOffset = i;
        this.fMostRecentData = uTF8DataChunk.toByteArray();
        this.fMostRecentByte = paramInt1;
        return false;
      } 
      return true;
    } 
    this.fCurrentChunk = uTF8DataChunk;
    this.fCurrentIndex = j;
    this.fCurrentOffset = i;
    this.fMostRecentData = uTF8DataChunk.toByteArray();
    this.fMostRecentByte = paramInt1;
    return false;
  }
  
  public int skipPastName(char paramChar) throws Exception {
    int i = this.fMostRecentByte;
    if ((i & 0x80) == 0) {
      if (XMLReader.fgAsciiInitialNameChar[i] == 0)
        return this.fCurrentOffset; 
    } else if (!skippedMultiByteCharWithFlag(i, 16)) {
      return this.fCurrentOffset;
    } 
    while (true) {
      this.fCharacterCounter++;
      i = loadNextByte();
      if (paramChar == i)
        return this.fCurrentOffset; 
      if ((i & 0x80) == 0) {
        if (XMLReader.fgAsciiNameChar[i] == 0)
          return this.fCurrentOffset; 
        continue;
      } 
      if (!skippedMultiByteCharWithFlag(i, 32))
        break; 
    } 
    return this.fCurrentOffset;
  }
  
  public int skipPastNmtoken(char paramChar) throws Exception {
    for (int i = this.fMostRecentByte;; i = loadNextByte()) {
      if (paramChar == i)
        return this.fCurrentOffset; 
      if ((i & 0x80) == 0) {
        if (XMLReader.fgAsciiNameChar[i] == 0)
          return this.fCurrentOffset; 
      } else if (!skippedMultiByteCharWithFlag(i, 32)) {
        return this.fCurrentOffset;
      } 
      this.fCharacterCounter++;
    } 
  }
  
  public int scanContent(ScanContentState paramScanContentState) throws Exception {
    this.fCurrentChunk.clearPreviousChunk();
    this.fCharDataLength = 0;
    int i = this.fCurrentOffset;
    int j = this.fMostRecentByte;
    if ((j & 0x80) == 0) {
      switch (XMLReader.fgAsciiWSCharData[j]) {
        case 0:
          this.fCharacterCounter++;
          this.fCurrentOffset++;
          if (++this.fCurrentIndex == 16384) {
            slowLoadNextByte();
          } else {
            this.fMostRecentByte = this.fMostRecentData[this.fCurrentIndex] & 0xFF;
          } 
          if (this.fSendCharDataAsCharArray)
            appendCharData(j); 
          break;
        case 1:
          this.fCharacterCounter++;
          this.fCurrentOffset++;
          if (++this.fCurrentIndex == 16384) {
            slowLoadNextByte();
          } else {
            this.fMostRecentByte = this.fMostRecentData[this.fCurrentIndex] & 0xFF;
          } 
          if (!paramScanContentState.inCDSect)
            return 1; 
          if (this.fSendCharDataAsCharArray)
            appendCharData(60); 
          break;
        case 2:
          this.fCharacterCounter++;
          this.fCurrentOffset++;
          if (++this.fCurrentIndex == 16384) {
            slowLoadNextByte();
          } else {
            this.fMostRecentByte = this.fMostRecentData[this.fCurrentIndex] & 0xFF;
          } 
          if (!paramScanContentState.inCDSect)
            return 2; 
          if (this.fSendCharDataAsCharArray)
            appendCharData(38); 
          break;
        case 3:
          this.fCharacterCounter++;
          j = loadNextByte();
          if (j != 93) {
            if (this.fSendCharDataAsCharArray)
              appendCharData(93); 
            break;
          } 
          if (this.fCurrentIndex + 1 == 16384) {
            UTF8DataChunk uTF8DataChunk = this.fCurrentChunk;
            int k = this.fCurrentIndex;
            int m = this.fCurrentOffset;
            if (loadNextByte() != 62) {
              this.fCurrentChunk = uTF8DataChunk;
              this.fCurrentIndex = k;
              this.fCurrentOffset = m;
              this.fMostRecentData = uTF8DataChunk.toByteArray();
              this.fMostRecentByte = 93;
              if (this.fSendCharDataAsCharArray)
                appendCharData(93); 
              break;
            } 
          } else {
            if (this.fMostRecentData[this.fCurrentIndex + 1] != 62) {
              if (this.fSendCharDataAsCharArray)
                appendCharData(93); 
              break;
            } 
            this.fCurrentIndex++;
            this.fCurrentOffset++;
          } 
          loadNextByte();
          this.fCharacterCounter += 2;
          if (paramScanContentState.inCDSect) {
            paramScanContentState.inCDSect = false;
            return scanContent(paramScanContentState);
          } 
          return 3;
        case 4:
          return 4;
        case 5:
          do {
            if (this.fSendCharDataAsCharArray)
              appendCharData(j); 
            if (j == 10) {
              this.fLinefeedCounter++;
              this.fCharacterCounter = 1;
            } else {
              this.fCharacterCounter++;
            } 
            this.fCurrentOffset++;
            if (++this.fCurrentIndex == 16384) {
              j = slowLoadNextByte();
            } else {
              j = this.fMostRecentByte = this.fMostRecentData[this.fCurrentIndex] & 0xFF;
            } 
          } while (j == 32 || j == 9 || j == 10);
          if ((j & 0x80) == 0) {
            int k;
            switch (XMLReader.fgAsciiCharData[j]) {
              case 0:
                this.fCharacterCounter++;
                this.fCurrentOffset++;
                if (++this.fCurrentIndex == 16384) {
                  slowLoadNextByte();
                } else {
                  this.fMostRecentByte = this.fMostRecentData[this.fCurrentIndex] & 0xFF;
                } 
                if (this.fSendCharDataAsCharArray)
                  appendCharData(j); 
                break;
              case 1:
                if (!paramScanContentState.inCDSect) {
                  if (this.fDocumentHandler != null)
                    callWSCharDataHandler(i, this.fCurrentOffset, false); 
                  this.fCharacterCounter++;
                  loadNextByte();
                  return 25;
                } 
                this.fCharacterCounter++;
                this.fCurrentOffset++;
                if (++this.fCurrentIndex == 16384) {
                  slowLoadNextByte();
                } else {
                  this.fMostRecentByte = this.fMostRecentData[this.fCurrentIndex] & 0xFF;
                } 
                if (this.fSendCharDataAsCharArray)
                  appendCharData(j); 
                break;
              case 2:
                if (!paramScanContentState.inCDSect) {
                  if (this.fDocumentHandler != null)
                    callWSCharDataHandler(i, this.fCurrentOffset, false); 
                  this.fCharacterCounter++;
                  loadNextByte();
                  return 26;
                } 
                this.fCharacterCounter++;
                this.fCurrentOffset++;
                if (++this.fCurrentIndex == 16384) {
                  slowLoadNextByte();
                } else {
                  this.fMostRecentByte = this.fMostRecentData[this.fCurrentIndex] & 0xFF;
                } 
                if (this.fSendCharDataAsCharArray)
                  appendCharData(j); 
                break;
              case 3:
                k = this.fCurrentOffset;
                j = loadNextByte();
                if (j != 93) {
                  this.fCharacterCounter++;
                  if (this.fSendCharDataAsCharArray)
                    appendCharData(93); 
                  break;
                } 
                if (this.fCurrentIndex + 1 == 16384) {
                  UTF8DataChunk uTF8DataChunk = this.fCurrentChunk;
                  int m = this.fCurrentIndex;
                  int n = this.fCurrentOffset;
                  if (loadNextByte() != 62) {
                    this.fCurrentChunk = uTF8DataChunk;
                    this.fCurrentIndex = m;
                    this.fCurrentOffset = n;
                    this.fMostRecentData = uTF8DataChunk.toByteArray();
                    this.fMostRecentByte = 93;
                    this.fCharacterCounter++;
                    if (this.fSendCharDataAsCharArray)
                      appendCharData(93); 
                    break;
                  } 
                } else {
                  if (this.fMostRecentData[this.fCurrentIndex + 1] != 62) {
                    this.fCharacterCounter++;
                    if (this.fSendCharDataAsCharArray)
                      appendCharData(93); 
                    break;
                  } 
                  this.fCurrentIndex++;
                  this.fCurrentOffset++;
                } 
                loadNextByte();
                if (this.fDocumentHandler != null)
                  callWSCharDataHandler(i, k, paramScanContentState.inCDSect); 
                this.fCharacterCounter += 3;
                if (paramScanContentState.inCDSect) {
                  paramScanContentState.inCDSect = false;
                  return scanContent(paramScanContentState);
                } 
                return 27;
              case 4:
                if (this.fDocumentHandler != null)
                  callWSCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
                return 28;
            } 
            break;
          } 
          if (this.fSendCharDataAsCharArray) {
            if (!copyMultiByteCharData(j)) {
              callWSCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect);
              return 28;
            } 
            break;
          } 
          if (!skipMultiByteCharData(j)) {
            if (this.fDocumentHandler != null)
              callWSCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
            return 28;
          } 
          break;
      } 
    } else if (!skipMultiByteCharData(j)) {
      return 4;
    } 
    if (this.fSendCharDataAsCharArray) {
      j = copyAsciiCharData();
    } else {
      j = skipAsciiCharData();
    } 
    while (true) {
      while ((j & 0x80) == 0) {
        int k;
        switch (XMLReader.fgAsciiCharData[j]) {
          case 0:
            this.fCharacterCounter++;
            if (this.fSendCharDataAsCharArray)
              appendCharData(j); 
            j = loadNextByte();
            break;
          case 1:
            if (!paramScanContentState.inCDSect) {
              if (this.fDocumentHandler != null)
                callCharDataHandler(i, this.fCurrentOffset, false); 
              this.fCharacterCounter++;
              this.fCurrentOffset++;
              if (++this.fCurrentIndex == 16384) {
                slowLoadNextByte();
              } else {
                this.fMostRecentByte = this.fMostRecentData[this.fCurrentIndex] & 0xFF;
              } 
              return 9;
            } 
            this.fCharacterCounter++;
            if (this.fSendCharDataAsCharArray)
              appendCharData(j); 
            j = loadNextByte();
            break;
          case 2:
            if (!paramScanContentState.inCDSect) {
              if (this.fDocumentHandler != null)
                callCharDataHandler(i, this.fCurrentOffset, false); 
              this.fCharacterCounter++;
              this.fCurrentOffset++;
              if (++this.fCurrentIndex == 16384) {
                slowLoadNextByte();
              } else {
                this.fMostRecentByte = this.fMostRecentData[this.fCurrentIndex] & 0xFF;
              } 
              return 10;
            } 
            this.fCharacterCounter++;
            if (this.fSendCharDataAsCharArray)
              appendCharData(j); 
            j = loadNextByte();
            break;
          case 3:
            k = this.fCurrentOffset;
            j = loadNextByte();
            if (j != 93) {
              this.fCharacterCounter++;
              if (this.fSendCharDataAsCharArray)
                appendCharData(93); 
              break;
            } 
            if (this.fCurrentIndex + 1 == 16384) {
              UTF8DataChunk uTF8DataChunk = this.fCurrentChunk;
              int m = this.fCurrentIndex;
              int n = this.fCurrentOffset;
              if (loadNextByte() != 62) {
                this.fCurrentChunk = uTF8DataChunk;
                this.fCurrentIndex = m;
                this.fCurrentOffset = n;
                this.fMostRecentData = uTF8DataChunk.toByteArray();
                this.fMostRecentByte = 93;
                this.fCharacterCounter++;
                if (this.fSendCharDataAsCharArray)
                  appendCharData(93); 
                break;
              } 
            } else {
              if (this.fMostRecentData[this.fCurrentIndex + 1] != 62) {
                this.fCharacterCounter++;
                if (this.fSendCharDataAsCharArray)
                  appendCharData(93); 
                break;
              } 
              this.fCurrentIndex++;
              this.fCurrentOffset++;
            } 
            loadNextByte();
            if (this.fDocumentHandler != null)
              callCharDataHandler(i, k, paramScanContentState.inCDSect); 
            this.fCharacterCounter += 3;
            if (paramScanContentState.inCDSect) {
              paramScanContentState.inCDSect = false;
              return scanContent(paramScanContentState);
            } 
            return 11;
          case 4:
            if (j == 10) {
              this.fLinefeedCounter++;
              this.fCharacterCounter = 1;
              j = loadNextByte();
              break;
            } 
            if (this.fDocumentHandler != null)
              callCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
            return 12;
        } 
      } 
      if (this.fSendCharDataAsCharArray) {
        if (!copyMultiByteCharData(j)) {
          callCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect);
          return 12;
        } 
      } else if (!skipMultiByteCharData(j)) {
        if (this.fDocumentHandler != null)
          callCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
        return 12;
      } 
      j = this.fMostRecentByte;
    } 
  }
  
  protected boolean copyMultiByteCharData(int paramInt) throws Exception {
    UTF8DataChunk uTF8DataChunk = this.fCurrentChunk;
    int i = this.fCurrentOffset;
    int j = this.fCurrentIndex;
    int k = loadNextByte();
    if ((0xE0 & paramInt) == 192) {
      int i2 = ((0x1F & paramInt) << 6) + (0x3F & k);
      appendCharData(i2);
      return true;
    } 
    int m = loadNextByte();
    if ((0xF0 & paramInt) == 224) {
      if ((paramInt == 237 && k >= 160) || (paramInt == 239 && k == 191 && m >= 190)) {
        this.fCurrentChunk = uTF8DataChunk;
        this.fCurrentIndex = j;
        this.fCurrentOffset = i;
        this.fMostRecentData = uTF8DataChunk.toByteArray();
        this.fMostRecentByte = paramInt;
        return false;
      } 
      int i2 = ((0xF & paramInt) << 12) + ((0x3F & k) << 6) + (0x3F & m);
      appendCharData(i2);
      return true;
    } 
    int n = loadNextByte();
    if (paramInt > 244 || (paramInt == 244 && k >= 144)) {
      this.fCurrentChunk = uTF8DataChunk;
      this.fCurrentIndex = j;
      this.fCurrentOffset = i;
      this.fMostRecentData = uTF8DataChunk.toByteArray();
      this.fMostRecentByte = paramInt;
      return false;
    } 
    int i1 = ((0xF & paramInt) << 18) + ((0x3F & k) << 12) + ((0x3F & m) << 6) + (0x3F & n);
    if (i1 < 65536) {
      appendCharData(i1);
    } else {
      appendCharData((i1 - 65536 >> 10) + 55296);
      appendCharData((i1 - 65536 & 0x3FF) + 56320);
    } 
    return true;
  }
  
  protected boolean skipMultiByteCharData(int paramInt) throws Exception {
    UTF8DataChunk uTF8DataChunk = this.fCurrentChunk;
    int i = this.fCurrentOffset;
    int j = this.fCurrentIndex;
    int k = loadNextByte();
    if ((0xE0 & paramInt) == 192)
      return true; 
    int m = loadNextByte();
    if ((0xF0 & paramInt) == 224) {
      if ((paramInt == 237 && k >= 160) || (paramInt == 239 && k == 191 && m >= 190)) {
        this.fCurrentChunk = uTF8DataChunk;
        this.fCurrentIndex = j;
        this.fCurrentOffset = i;
        this.fMostRecentData = uTF8DataChunk.toByteArray();
        this.fMostRecentByte = paramInt;
        return false;
      } 
      return true;
    } 
    loadNextByte();
    if (paramInt > 244 || (paramInt == 244 && k >= 144)) {
      this.fCurrentChunk = uTF8DataChunk;
      this.fCurrentIndex = j;
      this.fCurrentOffset = i;
      this.fMostRecentData = uTF8DataChunk.toByteArray();
      this.fMostRecentByte = paramInt;
      return false;
    } 
    return true;
  }
  
  protected int copyAsciiCharData() throws Exception {
    int i = this.fCharDataLength;
    int j = this.fCurrentIndex;
    int k = this.fCurrentOffset - j;
    while (true) {
      byte[] arrayOfByte = this.fMostRecentData;
      while (j < 16384) {
        int m = 16384;
        int n = this.fCharacters.length - 2 - i;
        int i1 = 16384 - j;
        if (n < i1)
          if (n < 64) {
            char[] arrayOfChar = new char[this.fCharacters.length * 2];
            System.arraycopy(this.fCharacters, 0, arrayOfChar, 0, this.fCharacters.length);
            this.fCharacters = arrayOfChar;
            n = this.fCharacters.length - 2 - i;
            if (n < i1)
              m = j + n; 
          } else {
            m = j + n;
          }  
        while (j < m) {
          byte b = arrayOfByte[j] & 0xFF;
          if ((b & 0x80) != 0) {
            this.fCurrentOffset = k + j;
            this.fCurrentIndex = j;
            this.fMostRecentByte = b;
            this.fCharDataLength = i;
            return b;
          } 
          if (XMLReader.fgAsciiCharData[b] != 0) {
            if (b != 10) {
              this.fCurrentOffset = k + j;
              this.fCurrentIndex = j;
              this.fMostRecentByte = b;
              this.fCharDataLength = i;
              return b;
            } 
            this.fLinefeedCounter++;
            this.fCharacterCounter = 1;
          } else {
            this.fCharacterCounter++;
          } 
          this.fCharacters[i++] = (char)b;
          j++;
        } 
      } 
      k += j;
      this.fCurrentChunk = new UTF8DataChunk(this, this.fStringPool, this.fCurrentChunk);
      fillCurrentChunk();
      j = 0;
    } 
  }
  
  protected int skipAsciiCharData() throws Exception {
    int i = this.fCurrentIndex;
    int j = this.fCurrentOffset - i;
    while (true) {
      byte[] arrayOfByte = this.fMostRecentData;
      while (i < 16384) {
        byte b = arrayOfByte[i] & 0xFF;
        if ((b & 0x80) != 0) {
          this.fCurrentOffset = j + i;
          this.fCurrentIndex = i;
          this.fMostRecentByte = b;
          return b;
        } 
        if (XMLReader.fgAsciiCharData[b] != 0) {
          if (b != 10) {
            this.fCurrentOffset = j + i;
            this.fCurrentIndex = i;
            this.fMostRecentByte = b;
            return b;
          } 
          this.fLinefeedCounter++;
          this.fCharacterCounter = 1;
        } else {
          this.fCharacterCounter++;
        } 
        i++;
      } 
      j += i;
      this.fCurrentChunk = new UTF8DataChunk(this, this.fStringPool, this.fCurrentChunk);
      fillCurrentChunk();
      i = 0;
    } 
  }
  
  protected void appendCharData(int paramInt) {
    if (this.fCharacters.length == this.fCharDataLength) {
      char[] arrayOfChar = new char[this.fCharacters.length * 2];
      System.arraycopy(this.fCharacters, 0, arrayOfChar, 0, this.fCharacters.length);
      this.fCharacters = arrayOfChar;
    } 
    this.fCharacters[this.fCharDataLength++] = (char)paramInt;
  }
  
  public void callCharDataHandler(int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {
    if (!this.fSendCharDataAsCharArray) {
      int i = paramInt2 - paramInt1;
      i = (i == 0) ? 0 : this.fCurrentChunk.addString(paramInt1, i);
      this.fDocumentHandler.characters(i, paramBoolean);
      return;
    } 
    this.fDocumentHandler.characters(this.fCharacters, 0, this.fCharDataLength, paramBoolean);
  }
  
  public void callWSCharDataHandler(int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {
    int i = this.fParserState.getScanner().getCurrentContentSpecType();
    if (i != 4) {
      callCharDataHandler(paramInt1, paramInt2, paramBoolean);
      return;
    } 
    if (!this.fSendCharDataAsCharArray) {
      int j = paramInt2 - paramInt1;
      j = (j == 0) ? 0 : this.fCurrentChunk.addString(paramInt1, j);
      this.fDocumentHandler.ignorableWhitespace(j, paramBoolean);
      return;
    } 
    this.fDocumentHandler.ignorableWhitespace(this.fCharacters, 0, this.fCharDataLength, paramBoolean);
  }
  
  protected int fillCurrentChunk() throws Exception {
    this.fOutputOffset = 0;
    if (this.fCheckOverflow) {
      if (this.fOverflowEnd < 16384) {
        if (this.fOverflowEnd > 0) {
          this.fMostRecentData = new byte[1 + this.fOverflowEnd - this.fOverflowOffset];
          copyNormalize(this.fOverflow, this.fOverflowOffset, this.fMostRecentData, this.fOutputOffset);
        } else {
          this.fMostRecentData = new byte[1];
        } 
        this.fMostRecentData[this.fOutputOffset] = 0;
        this.fOverflow = null;
        this.fLength += this.fOutputOffset;
        this.fCurrentIndex = 0;
        this.fCurrentChunk.setByteArray(this.fMostRecentData);
        return this.fMostRecentByte = this.fMostRecentData[0];
      } 
      this.fMostRecentData = new byte[16384];
      copyNormalize(this.fOverflow, this.fOverflowOffset, this.fMostRecentData, this.fOutputOffset);
      this.fCheckOverflow = false;
    } else {
      if (this.fOverflow == null)
        this.fOverflow = new byte[16384]; 
      this.fMostRecentData = null;
    } 
    while (true) {
      this.fOverflowOffset = 0;
      this.fOverflowEnd = 0;
      int i = 16384;
      int j = 0;
      do {
        j = this.fInputStream.read(this.fOverflow, this.fOverflowEnd, i);
        if (j == -1) {
          this.fInputStream.close();
          this.fInputStream = null;
          if (this.fMostRecentData == null) {
            this.fMostRecentData = new byte[1 + this.fOverflowEnd];
            copyNormalize(this.fOverflow, this.fOverflowOffset, this.fMostRecentData, this.fOutputOffset);
            this.fOverflow = null;
            this.fMostRecentData[this.fOutputOffset] = 0;
            break;
          } 
          boolean bool = copyNormalize(this.fOverflow, this.fOverflowOffset, this.fMostRecentData, this.fOutputOffset);
          if (bool) {
            if (this.fOverflowEnd == 16384) {
              this.fCheckOverflow = true;
              this.fOverflowOffset = 0;
              this.fOverflowEnd = 0;
              break;
            } 
            this.fOverflow = null;
            this.fMostRecentData[this.fOutputOffset] = 0;
            break;
          } 
          this.fCheckOverflow = true;
          break;
        } 
        if (j <= 0)
          continue; 
        this.fOverflowEnd += j;
        i -= j;
      } while (i > 0);
      if (j != -1) {
        if (this.fMostRecentData != null) {
          boolean bool = copyNormalize(this.fOverflow, this.fOverflowOffset, this.fMostRecentData, this.fOutputOffset);
          if (this.fOutputOffset == 16384) {
            if (!bool)
              this.fCheckOverflow = true; 
            break;
          } 
          continue;
        } 
        this.fMostRecentData = new byte[16384];
        copyNormalize(this.fOverflow, this.fOverflowOffset, this.fMostRecentData, this.fOutputOffset);
        if (this.fOutputOffset == 16384)
          break; 
        continue;
      } 
      break;
    } 
    this.fLength += this.fOutputOffset;
    this.fCurrentIndex = 0;
    this.fCurrentChunk.setByteArray(this.fMostRecentData);
    return this.fMostRecentByte = this.fMostRecentData[0];
  }
  
  protected boolean copyNormalize(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2) throws Exception {
    int i = this.fOverflowEnd;
    int j = paramArrayOfByte2.length;
    if (paramInt1 == i)
      return true; 
    byte b = paramArrayOfByte1[paramInt1];
    if (this.fSkipLinefeed) {
      this.fSkipLinefeed = false;
      if (b == 10) {
        if (++paramInt1 == i) {
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt2;
          return true;
        } 
        b = paramArrayOfByte1[paramInt1];
      } 
    } else if (this.fPartialMultiByteIn > 0) {
      if (!handlePartialMultiByteChar(b, paramArrayOfByte1, paramInt1, i, paramArrayOfByte2, paramInt2, j))
        return this.fPartialMultiByteResult; 
      paramInt1 = this.fOverflowOffset;
      paramInt2 = this.fOutputOffset;
      b = paramArrayOfByte1[paramInt1];
    } 
    while (paramInt2 < j) {
      int k = i - paramInt1;
      int m = j - paramInt2;
      if (k > m)
        k = m; 
      paramInt1++;
      while (true) {
        if (b != 13 && (b & 0x80) == 0) {
          while (true) {
            paramArrayOfByte2[paramInt2++] = b;
            if (--k != 0) {
              b = paramArrayOfByte1[paramInt1++];
              if (b == 13 || (b & 0x80) != 0)
                break; 
              continue;
            } 
            break;
          } 
          if (k == 0)
            break; 
          continue;
        } 
        if (b == 13) {
          paramArrayOfByte2[paramInt2++] = 10;
          if (paramInt1 == i) {
            this.fSkipLinefeed = true;
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt2;
            return true;
          } 
          b = paramArrayOfByte1[paramInt1];
          if (b == 10) {
            if (++paramInt1 == i) {
              this.fOverflowOffset = paramInt1;
              this.fOutputOffset = paramInt2;
              return true;
            } 
            b = paramArrayOfByte1[paramInt1];
          } 
          if (paramInt2 == j) {
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt2;
            return false;
          } 
        } else {
          if (!handleMultiByteChar(b, paramArrayOfByte1, paramInt1, i, paramArrayOfByte2, paramInt2, j))
            return this.fPartialMultiByteResult; 
          paramInt1 = this.fOverflowOffset;
          paramInt2 = this.fOutputOffset;
          b = paramArrayOfByte1[paramInt1];
        } 
        k = i - paramInt1;
        m = j - paramInt2;
        if (k > m)
          k = m; 
        paramInt1++;
      } 
      if (paramInt1 != i)
        continue; 
      break;
    } 
    boolean bool = !(paramInt1 != i);
    this.fOverflowOffset = paramInt1;
    this.fOutputOffset = paramInt2;
    return bool;
  }
  
  protected boolean exitNormalize(int paramInt1, int paramInt2, boolean paramBoolean) {
    this.fOverflowOffset = paramInt1;
    this.fOutputOffset = paramInt2;
    return paramBoolean;
  }
  
  protected void savePartialMultiByte(int paramInt1, int paramInt2, byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4) {
    this.fPartialMultiByteIn = paramInt1;
    this.fPartialMultiByteOut = paramInt2;
    this.fPartialMultiByteChar[--paramInt1] = paramByte1;
    this.fPartialMultiByteChar[--paramInt1] = paramByte2;
    this.fPartialMultiByteChar[--paramInt1] = paramByte3;
    this.fPartialMultiByteChar[--paramInt1] = paramByte4;
  }
  
  protected void savePartialMultiByte(int paramInt1, int paramInt2, byte paramByte1, byte paramByte2, byte paramByte3) {
    this.fPartialMultiByteIn = paramInt1;
    this.fPartialMultiByteOut = paramInt2;
    this.fPartialMultiByteChar[--paramInt1] = paramByte1;
    this.fPartialMultiByteChar[--paramInt1] = paramByte2;
    this.fPartialMultiByteChar[--paramInt1] = paramByte3;
  }
  
  protected void savePartialMultiByte(int paramInt1, int paramInt2, byte paramByte1, byte paramByte2) {
    this.fPartialMultiByteIn = paramInt1;
    this.fPartialMultiByteOut = paramInt2;
    this.fPartialMultiByteChar[--paramInt1] = paramByte1;
    this.fPartialMultiByteChar[--paramInt1] = paramByte2;
  }
  
  protected void savePartialMultiByte(int paramInt1, int paramInt2, byte paramByte) {
    this.fPartialMultiByteIn = paramInt1;
    this.fPartialMultiByteOut = paramInt2;
    this.fPartialMultiByteChar[--paramInt1] = paramByte;
  }
  
  protected boolean handleMultiByteChar(byte paramByte, byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, int paramInt4) throws Exception {
    if (paramInt1 == paramInt2) {
      byte b1 = 1;
      this.fPartialMultiByteIn = b1;
      this.fPartialMultiByteOut = 0;
      this.fPartialMultiByteChar[--b1] = paramByte;
      this.fOverflowOffset = paramInt1;
      this.fOutputOffset = paramInt3;
      this.fPartialMultiByteResult = true;
      return false;
    } 
    byte b = paramArrayOfByte1[paramInt1++];
    if ((b & 0xC0) != 128)
      this.fErrorHandler.error2(57, this.fStringPool.addString(Integer.toHexString(paramByte)), this.fStringPool.addString(Integer.toHexString(b))); 
    if ((paramByte & 0xE0) == 192) {
      paramArrayOfByte2[paramInt3++] = paramByte;
      if (paramInt3 == paramInt4) {
        savePartialMultiByte(2, 1, b, paramByte);
        boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
        this.fOverflowOffset = paramInt1;
        this.fOutputOffset = paramInt3;
        this.fPartialMultiByteResult = bool;
        return false;
      } 
      paramArrayOfByte2[paramInt3++] = b;
      if (paramInt1 == paramInt2 || paramInt3 == paramInt4) {
        boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
        this.fOverflowOffset = paramInt1;
        this.fOutputOffset = paramInt3;
        this.fPartialMultiByteResult = bool;
        return false;
      } 
    } else {
      if (paramInt1 == paramInt2) {
        savePartialMultiByte(2, 0, b, paramByte);
        this.fOverflowOffset = paramInt1;
        this.fOutputOffset = paramInt3;
        this.fPartialMultiByteResult = true;
        return false;
      } 
      byte b1 = paramArrayOfByte1[paramInt1++];
      if ((b1 & 0xC0) != 128)
        this.fErrorHandler.error3(58, this.fStringPool.addString(Integer.toHexString(paramByte)), this.fStringPool.addString(Integer.toHexString(b)), this.fStringPool.addString(Integer.toHexString(b1))); 
      if ((paramByte & 0xF0) == 224) {
        paramArrayOfByte2[paramInt3++] = paramByte;
        if (paramInt3 == paramInt4) {
          savePartialMultiByte(3, 1, b1, b, paramByte);
          boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = bool;
          return false;
        } 
        paramArrayOfByte2[paramInt3++] = b;
        if (paramInt3 == paramInt4) {
          savePartialMultiByte(3, 2, b1, b, paramByte);
          boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = bool;
          return false;
        } 
        paramArrayOfByte2[paramInt3++] = b1;
        if (paramInt1 == paramInt2 || paramInt3 == paramInt4) {
          boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = bool;
          return false;
        } 
      } else {
        if ((paramByte & 0xF8) != 240)
          this.fErrorHandler.error1(56, this.fStringPool.addString(Integer.toHexString(paramByte))); 
        if (paramInt1 == paramInt2) {
          savePartialMultiByte(3, 0, b1, b, paramByte);
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = true;
          return false;
        } 
        byte b2 = paramArrayOfByte1[paramInt1++];
        if ((b2 & 0xC0) != 128)
          this.fErrorHandler.error4(59, this.fStringPool.addString(Integer.toHexString(paramByte)), this.fStringPool.addString(Integer.toHexString(b)), this.fStringPool.addString(Integer.toHexString(b1)), this.fStringPool.addString(Integer.toHexString(b2))); 
        paramArrayOfByte2[paramInt3++] = paramByte;
        if (paramInt3 == paramInt4) {
          savePartialMultiByte(4, 1, b2, b1, b, paramByte);
          boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = bool;
          return false;
        } 
        paramArrayOfByte2[paramInt3++] = b;
        if (paramInt3 == paramInt4) {
          savePartialMultiByte(4, 2, b2, b1, b, paramByte);
          boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = bool;
          return false;
        } 
        paramArrayOfByte2[paramInt3++] = b1;
        if (paramInt3 == paramInt4) {
          savePartialMultiByte(4, 3, b2, b1, b, paramByte);
          boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = bool;
          return false;
        } 
        paramArrayOfByte2[paramInt3++] = b2;
        if (paramInt1 == paramInt2 || paramInt3 == paramInt4) {
          boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = bool;
          return false;
        } 
      } 
    } 
    this.fOverflowOffset = paramInt1;
    this.fOutputOffset = paramInt3;
    return true;
  }
  
  protected boolean handlePartialMultiByteChar(byte paramByte, byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, int paramInt4) throws Exception {
    if (paramInt3 == paramInt4) {
      boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
      this.fOverflowOffset = paramInt1;
      this.fOutputOffset = paramInt3;
      this.fPartialMultiByteResult = bool;
      return false;
    } 
    int i = this.fPartialMultiByteIn;
    int j = this.fPartialMultiByteOut;
    this.fPartialMultiByteIn = 0;
    this.fPartialMultiByteOut = 0;
    byte b1 = 0;
    byte b2 = 0;
    byte b3 = 0;
    byte b = 0;
    switch (i) {
      case 1:
        b1 = paramByte;
        break;
      case 2:
        b2 = paramByte;
        break;
      case 3:
        b3 = paramByte;
        break;
      case 4:
        b = paramByte;
        break;
    } 
    int k = i;
    switch (i) {
      case 4:
        b3 = this.fPartialMultiByteChar[--k];
      case 3:
        b2 = this.fPartialMultiByteChar[--k];
      case 2:
        b1 = this.fPartialMultiByteChar[--k];
      case 1:
        paramByte = this.fPartialMultiByteChar[--k];
        break;
    } 
    switch (i) {
      case 1:
        if ((b1 & 0xC0) != 128)
          this.fErrorHandler.error2(57, this.fStringPool.addString(Integer.toHexString(paramByte)), this.fStringPool.addString(Integer.toHexString(b1))); 
      case 2:
        if ((paramByte & 0xE0) == 192) {
          switch (j) {
            case 0:
              paramArrayOfByte2[paramInt3++] = paramByte;
              if (paramInt3 == paramInt4) {
                byte b4 = 2;
                this.fPartialMultiByteIn = b4;
                this.fPartialMultiByteOut = 1;
                this.fPartialMultiByteChar[--b4] = b1;
                this.fOverflowOffset = paramInt1;
                this.fOutputOffset = paramInt3;
                this.fPartialMultiByteResult = false;
                return false;
              } 
            case 1:
              paramArrayOfByte2[paramInt3++] = b1;
              if (paramInt3 == paramInt4) {
                this.fOverflowOffset = paramInt1;
                this.fOutputOffset = paramInt3;
                this.fPartialMultiByteResult = false;
                return false;
              } 
              break;
          } 
          if (i < 2 && ++paramInt1 == paramInt2) {
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt3;
            this.fPartialMultiByteResult = true;
            return false;
          } 
          break;
        } 
        if (i < 2) {
          if (++paramInt1 == paramInt2) {
            byte b4 = 2;
            this.fPartialMultiByteIn = b4;
            this.fPartialMultiByteOut = 0;
            this.fPartialMultiByteChar[--b4] = b1;
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt3;
            this.fPartialMultiByteResult = true;
            return false;
          } 
          b2 = paramArrayOfByte1[paramInt1];
        } 
        if ((b2 & 0xC0) != 128)
          this.fErrorHandler.error3(58, this.fStringPool.addString(Integer.toHexString(paramByte)), this.fStringPool.addString(Integer.toHexString(b1)), this.fStringPool.addString(Integer.toHexString(b2))); 
      case 3:
        if ((paramByte & 0xF0) == 224) {
          switch (j) {
            case 0:
              paramArrayOfByte2[paramInt3++] = paramByte;
              if (paramInt3 == paramInt4) {
                savePartialMultiByte(3, 1, b2, b1);
                this.fOverflowOffset = paramInt1;
                this.fOutputOffset = paramInt3;
                this.fPartialMultiByteResult = false;
                return false;
              } 
            case 1:
              paramArrayOfByte2[paramInt3++] = b1;
              if (paramInt3 == paramInt4) {
                savePartialMultiByte(3, 2, b2, b1);
                this.fOverflowOffset = paramInt1;
                this.fOutputOffset = paramInt3;
                this.fPartialMultiByteResult = false;
                return false;
              } 
            case 2:
              paramArrayOfByte2[paramInt3++] = b2;
              if (paramInt3 == paramInt4) {
                this.fOverflowOffset = paramInt1;
                this.fOutputOffset = paramInt3;
                this.fPartialMultiByteResult = false;
                return false;
              } 
              break;
          } 
          if (i < 3 && ++paramInt1 == paramInt2) {
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt3;
            this.fPartialMultiByteResult = true;
            return false;
          } 
          break;
        } 
        if (i < 3) {
          if ((paramByte & 0xF8) != 240)
            this.fErrorHandler.error1(56, this.fStringPool.addString(Integer.toHexString(paramByte))); 
          if (++paramInt1 == paramInt2) {
            savePartialMultiByte(3, 0, b2, b1);
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt3;
            this.fPartialMultiByteResult = true;
            return false;
          } 
          b3 = paramArrayOfByte1[paramInt1];
        } 
        if ((b3 & 0xC0) != 128)
          this.fErrorHandler.error4(59, this.fStringPool.addString(Integer.toHexString(paramByte)), this.fStringPool.addString(Integer.toHexString(b1)), this.fStringPool.addString(Integer.toHexString(b2)), this.fStringPool.addString(Integer.toHexString(b3))); 
      case 4:
        switch (j) {
          case 0:
            paramArrayOfByte2[paramInt3++] = paramByte;
            if (paramInt3 == paramInt4) {
              savePartialMultiByte(4, 1, b3, b2, b1);
              this.fOverflowOffset = paramInt1;
              this.fOutputOffset = paramInt3;
              this.fPartialMultiByteResult = false;
              return false;
            } 
          case 1:
            paramArrayOfByte2[paramInt3++] = b1;
            if (paramInt3 == paramInt4) {
              savePartialMultiByte(4, 2, b3, b2, b1);
              this.fOverflowOffset = paramInt1;
              this.fOutputOffset = paramInt3;
              this.fPartialMultiByteResult = false;
              return false;
            } 
          case 2:
            paramArrayOfByte2[paramInt3++] = b2;
            if (paramInt3 == paramInt4) {
              savePartialMultiByte(4, 3, b3, b2, b1);
              this.fOverflowOffset = paramInt1;
              this.fOutputOffset = paramInt3;
              this.fPartialMultiByteResult = false;
              return false;
            } 
          case 3:
            paramArrayOfByte2[paramInt3++] = b3;
            if (paramInt3 == paramInt4) {
              this.fOverflowOffset = paramInt1;
              this.fOutputOffset = paramInt3;
              this.fPartialMultiByteResult = false;
              return false;
            } 
            break;
        } 
        if (i < 4 && ++paramInt1 == paramInt2) {
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = true;
          return false;
        } 
        break;
    } 
    this.fOverflowOffset = paramInt1;
    this.fOutputOffset = paramInt3;
    return true;
  }
  
  protected class UTF8DataChunk implements StringProducer {
    private final UTF8Reader this$0;
    
    protected StringPool fStringPool;
    
    protected int fChunk;
    
    protected byte[] fData;
    
    protected UTF8DataChunk fPreviousChunk;
    
    protected UTF8DataChunk fNextChunk;
    
    protected UTF8DataChunk(UTF8Reader this$0, StringPool param1StringPool, UTF8DataChunk param1UTF8DataChunk) throws Exception {
      this.this$0 = this$0;
      this.this$0 = this$0;
      this.fStringPool = param1StringPool;
      this.fChunk = (param1UTF8DataChunk == null) ? 0 : (param1UTF8DataChunk.fChunk + 1);
      this.fPreviousChunk = param1UTF8DataChunk;
      if (param1UTF8DataChunk != null)
        param1UTF8DataChunk.fNextChunk = this; 
    }
    
    protected UTF8DataChunk(UTF8Reader this$0, UTF8DataChunk param1UTF8DataChunk) {
      this.this$0 = this$0;
      this.this$0 = this$0;
      this.fStringPool = param1UTF8DataChunk.fStringPool;
      this.fChunk = param1UTF8DataChunk.fChunk;
      this.fData = param1UTF8DataChunk.fData;
      this.fPreviousChunk = null;
      this.fNextChunk = null;
    }
    
    public UTF8DataChunk chunkFor(int param1Int) {
      int i = param1Int >> 14;
      for (UTF8DataChunk uTF8DataChunk = this; i != uTF8DataChunk.fChunk; uTF8DataChunk = uTF8DataChunk.fPreviousChunk);
      return uTF8DataChunk;
    }
    
    public byte[] toByteArray() { return this.fData; }
    
    public void setByteArray(byte[] param1ArrayOfByte) { this.fData = param1ArrayOfByte; }
    
    public UTF8DataChunk nextChunk() { return this.fNextChunk; }
    
    public void clearPreviousChunk() {
      if (this.fPreviousChunk != null) {
        this.fPreviousChunk.fNextChunk = null;
        this.fPreviousChunk = null;
      } 
    }
    
    public String toString(int param1Int1, int param1Int2) {
      StringBuffer stringBuffer = new StringBuffer(param1Int2);
      UTF8DataChunk uTF8DataChunk = this;
      int i = param1Int1 + param1Int2;
      int j = param1Int1 & 0x3FFF;
      byte[] arrayOfByte = this.fData;
      while (param1Int1 < i) {
        byte b1 = arrayOfByte[j++] & 0xFF;
        param1Int1++;
        if (j == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          j = 0;
        } 
        if ((b1 & 0x80) == 0) {
          stringBuffer.append((char)b1);
          continue;
        } 
        byte b2 = arrayOfByte[j++] & 0xFF;
        param1Int1++;
        if (j == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          j = 0;
        } 
        if ((0xE0 & b1) == 'À') {
          byte b = ((0x1F & b1) << 6) + (0x3F & b2);
          stringBuffer.append((char)b);
          continue;
        } 
        byte b3 = arrayOfByte[j++] & 0xFF;
        param1Int1++;
        if (j == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          j = 0;
        } 
        if ((0xF0 & b1) == 'à') {
          byte b = ((0xF & b1) << 12) + ((0x3F & b2) << 6) + (0x3F & b3);
          stringBuffer.append((char)b);
          continue;
        } 
        byte b4 = arrayOfByte[j++] & 0xFF;
        param1Int1++;
        if (j == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          j = 0;
        } 
        byte b5 = ((0xF & b1) << 18) + ((0x3F & b2) << 12) + ((0x3F & b3) << 6) + (0x3F & b4);
        if (b5 < 65536) {
          stringBuffer.append((char)b5);
          continue;
        } 
        stringBuffer.append((char)((b5 - 65536 >> 10) + 55296));
        stringBuffer.append((char)((b5 - 65536 & 0x3FF) + 56320));
      } 
      return stringBuffer.toString();
    }
    
    public boolean equalsString(int param1Int1, int param1Int2, String param1String, int param1Int3) {
      UTF8DataChunk uTF8DataChunk = this;
      int i = param1Int1 + param1Int2;
      int j = param1Int1 & 0x3FFF;
      byte[] arrayOfByte = this.fData;
      byte b = 0;
      while (param1Int1 < i) {
        if (b == param1Int3)
          return false; 
        byte b1 = arrayOfByte[j++] & 0xFF;
        param1Int1++;
        if (j == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          j = 0;
        } 
        if ((b1 & 0x80) == 0) {
          if (b1 != param1String.charAt(b++))
            return false; 
          continue;
        } 
        byte b2 = arrayOfByte[j++] & 0xFF;
        param1Int1++;
        if (j == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          j = 0;
        } 
        if ((0xE0 & b1) == 'À') {
          byte b6 = ((0x1F & b1) << 6) + (0x3F & b2);
          if (b6 != param1String.charAt(b++))
            return false; 
          continue;
        } 
        byte b3 = arrayOfByte[j++] & 0xFF;
        param1Int1++;
        if (j == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          j = 0;
        } 
        if ((0xF0 & b1) == 'à') {
          byte b6 = ((0xF & b1) << 12) + ((0x3F & b2) << 6) + (0x3F & b3);
          if (b6 != param1String.charAt(b++))
            return false; 
          continue;
        } 
        byte b4 = arrayOfByte[j++] & 0xFF;
        param1Int1++;
        if (j == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          j = 0;
        } 
        byte b5 = ((0xF & b1) << 18) + ((0x3F & b2) << 12) + ((0x3F & b3) << 6) + (0x3F & b4);
        if (b5 < 65536) {
          if (b5 != param1String.charAt(b++))
            return false; 
          continue;
        } 
        if ((b5 - 65536 >> 10) + 55296 != param1String.charAt(b++))
          return false; 
        if (b == param1Int3)
          return false; 
        if ((b5 - 65536 & 0x3FF) + 56320 != param1String.charAt(b++))
          return false; 
      } 
      return !(b != param1Int3);
    }
    
    protected UTF8DataChunk createClump(int param1Int) {
      UTF8DataChunk uTF8DataChunk1 = new UTF8DataChunk(this.this$0, this);
      UTF8DataChunk uTF8DataChunk2 = this.fNextChunk;
      UTF8DataChunk uTF8DataChunk3 = uTF8DataChunk1;
      do {
        UTF8DataChunk uTF8DataChunk = new UTF8DataChunk(this.this$0, uTF8DataChunk2);
        uTF8DataChunk3.fNextChunk = uTF8DataChunk;
        uTF8DataChunk2 = uTF8DataChunk2.fNextChunk;
        uTF8DataChunk3 = uTF8DataChunk;
      } while (uTF8DataChunk3.fChunk != param1Int);
      return uTF8DataChunk1;
    }
    
    public int addString(int param1Int1, int param1Int2) {
      int i = param1Int1 >> 14;
      if (i != this.fChunk) {
        if (this.fPreviousChunk != null)
          return this.fPreviousChunk.addString(param1Int1, param1Int2); 
        System.out.println("fPreviousChunk == null");
        return -1;
      } 
      int j = param1Int1 + param1Int2 - 1 >> 14;
      return (i == j) ? this.fStringPool.addString(this, param1Int1 & 0x3FFF, param1Int2) : this.fStringPool.addString(createClump(j), param1Int1 & 0x3FFF, param1Int2);
    }
    
    public int addSymbol(int param1Int1, int param1Int2, int param1Int3) {
      int i = param1Int1 >> 14;
      if (i != this.fChunk) {
        if (this.fPreviousChunk != null)
          return this.fPreviousChunk.addSymbol(param1Int1, param1Int2, param1Int3); 
        System.out.println("fPreviousChunk == null");
        return -1;
      } 
      int j = param1Int1 + param1Int2 - 1 >> 14;
      if (i == j) {
        if (param1Int3 == 0)
          param1Int3 = getHashcode(param1Int1, param1Int2); 
        return this.fStringPool.addSymbol(this, param1Int1 & 0x3FFF, param1Int2, param1Int3);
      } 
      if (param1Int3 == 0)
        param1Int3 = getHashcode(param1Int1, param1Int2); 
      return this.fStringPool.addSymbol(createClump(j), param1Int1 & 0x3FFF, param1Int2, param1Int3);
    }
    
    public void append(ChunkyCharArray param1ChunkyCharArray, int param1Int1, int param1Int2) {
      UTF8DataChunk uTF8DataChunk = chunkFor(param1Int1);
      int i = param1Int1 + param1Int2;
      int j = param1Int1 & 0x3FFF;
      byte[] arrayOfByte = this.fData;
      while (param1Int1 < i) {
        byte b1 = arrayOfByte[j++] & 0xFF;
        param1Int1++;
        if (j == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          j = 0;
        } 
        if ((b1 & 0x80) == 0) {
          param1ChunkyCharArray.append((char)b1);
          continue;
        } 
        byte b2 = arrayOfByte[j++] & 0xFF;
        param1Int1++;
        if (j == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          j = 0;
        } 
        if ((0xE0 & b1) == 'À') {
          byte b = ((0x1F & b1) << 6) + (0x3F & b2);
          param1ChunkyCharArray.append((char)b);
          continue;
        } 
        byte b3 = arrayOfByte[j++] & 0xFF;
        param1Int1++;
        if (j == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          j = 0;
        } 
        if ((0xF0 & b1) == 'à') {
          byte b = ((0xF & b1) << 12) + ((0x3F & b2) << 6) + (0x3F & b3);
          param1ChunkyCharArray.append((char)b);
          continue;
        } 
        byte b4 = arrayOfByte[j++] & 0xFF;
        param1Int1++;
        if (j == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          j = 0;
        } 
        byte b5 = ((0xF & b1) << 18) + ((0x3F & b2) << 12) + ((0x3F & b3) << 6) + (0x3F & b4);
        if (b5 < 65536) {
          param1ChunkyCharArray.append((char)b5);
          continue;
        } 
        param1ChunkyCharArray.append((char)((b5 - 65536 >> 10) + 55296));
        param1ChunkyCharArray.append((char)((b5 - 65536 & 0x3FF) + 56320));
      } 
    }
    
    protected int getHashcode(int param1Int1, int param1Int2) {
      UTF8DataChunk uTF8DataChunk = chunkFor(param1Int1);
      int i = param1Int1 + param1Int2;
      int j = 0;
      byte b = 0;
      int k = param1Int1 & 0x3FFF;
      byte[] arrayOfByte = uTF8DataChunk.fData;
      while (param1Int1 < i) {
        byte b1 = arrayOfByte[k++] & 0xFF;
        param1Int1++;
        if (k == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          k = 0;
        } 
        if ((b1 & 0x80) == 0) {
          j = StringHasher.hashChar(j, b++, b1);
          continue;
        } 
        byte b2 = arrayOfByte[k++] & 0xFF;
        param1Int1++;
        if (k == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          k = 0;
        } 
        if ((0xE0 & b1) == 'À') {
          byte b6 = ((0x1F & b1) << 6) + (0x3F & b2);
          j = StringHasher.hashChar(j, b++, b6);
          continue;
        } 
        byte b3 = arrayOfByte[k++] & 0xFF;
        param1Int1++;
        if (k == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          k = 0;
        } 
        if ((0xF0 & b1) == 'à') {
          byte b6 = ((0xF & b1) << 12) + ((0x3F & b2) << 6) + (0x3F & b3);
          j = StringHasher.hashChar(j, b++, b6);
          continue;
        } 
        byte b4 = arrayOfByte[k++] & 0xFF;
        param1Int1++;
        if (k == 16384) {
          uTF8DataChunk = uTF8DataChunk.fNextChunk;
          arrayOfByte = uTF8DataChunk.fData;
          k = 0;
        } 
        byte b5 = ((0xF & b1) << 18) + ((0x3F & b2) << 12) + ((0x3F & b3) << 6) + (0x3F & b4);
        if (b5 < 65536) {
          j = StringHasher.hashChar(j, b++, b5);
          continue;
        } 
        j = StringHasher.hashChar(j, b++, (b5 - 65536 >> 10) + 55296);
        j = StringHasher.hashChar(j, b++, (b5 - 65536 & 0x3FF) + 56320);
      } 
      int m = j;
      m &= Integer.MAX_VALUE;
      return (m == 0) ? 1 : m;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\UTF8Reader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */