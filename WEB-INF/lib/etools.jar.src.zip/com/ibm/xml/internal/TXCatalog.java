package com.ibm.xml.internal;

import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.StringPool;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.util.StringTokenizer;
import org.xml.sax.InputSource;

public class TXCatalog extends DefaultCatalog {
  private ParserState state;
  
  public TXCatalog(ParserState paramParserState) { this.state = paramParserState; }
  
  public void loadCatalog(InputSource paramInputSource) throws Exception {
    Reader reader = paramInputSource.getCharacterStream();
    if (reader == null) {
      InputStream inputStream = paramInputSource.getByteStream();
      if (inputStream != null) {
        reader = new InputStreamReader(inputStream);
      } else {
        StringPool stringPool = this.state.getStringPool();
        int i = stringPool.addString(paramInputSource.getSystemId());
        int j = this.state.getEntityHandler().expandSystemId(i);
        if (j != i)
          stringPool.releaseString(i); 
        String str = stringPool.orphanString(j);
        reader = new InputStreamReader((new URL(str)).openStream());
      } 
    } 
    if (reader != null) {
      BufferedReader bufferedReader = new BufferedReader(reader);
      String str;
      while ((str = bufferedReader.readLine()) != null) {
        StringTokenizer stringTokenizer = new StringTokenizer(str, "\t");
        String str1 = stringTokenizer.nextToken();
        if (str1 != null) {
          String str2 = stringTokenizer.nextToken();
          if (str2 != null)
            addPublicMapping(str1, str2); 
        } 
      } 
      bufferedReader.close();
    } 
  }
  
  protected ParserState getParserState() { return this.state; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\TXCatalog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */