package com.ibm.xml.internal;

abstract class CMNode {
  private int fType;
  
  private CMStateSet fFirstPos;
  
  private CMStateSet fFollowPos;
  
  private CMStateSet fLastPos;
  
  private int fMaxStates = -1;
  
  CMNode(int paramInt) throws CMException { this.fType = paramInt; }
  
  abstract boolean isNullable() throws CMException;
  
  final int type() { return this.fType; }
  
  final CMStateSet firstPos() throws CMException {
    if (this.fFirstPos == null) {
      this.fFirstPos = new CMStateSet(this.fMaxStates);
      calcFirstPos(this.fFirstPos);
    } 
    return this.fFirstPos;
  }
  
  final CMStateSet lastPos() throws CMException {
    if (this.fLastPos == null) {
      this.fLastPos = new CMStateSet(this.fMaxStates);
      calcLastPos(this.fLastPos);
    } 
    return this.fLastPos;
  }
  
  final void setFollowPos(CMStateSet paramCMStateSet) { this.fFollowPos = paramCMStateSet; }
  
  final void setMaxStates(int paramInt) throws CMException { this.fMaxStates = paramInt; }
  
  protected abstract void calcFirstPos(CMStateSet paramCMStateSet);
  
  protected abstract void calcLastPos(CMStateSet paramCMStateSet);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\CMNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */