package com.ibm.xml.internal;

import com.ibm.xml.framework.AttrPool;
import com.ibm.xml.framework.ContentModel;
import com.ibm.xml.framework.ContentSpecNode;
import com.ibm.xml.framework.ElementDeclPool;
import com.ibm.xml.framework.InsertableElementsInfo;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLErrorHandler;
import com.ibm.xml.framework.XMLValidationHandler;

public class DefaultValidationHandler implements XMLValidationHandler {
  private ElementDeclPool fDeclPool;
  
  private XMLErrorHandler fErrHandler;
  
  private AttrPool fAttrPool;
  
  private StringPool fStringPool;
  
  private ParserState fParserState;
  
  private static final boolean DEBUG_PRINT_ATTRIBUTES = false;
  
  private static final boolean DEBUG_PRINT_CONTENT = false;
  
  public DefaultValidationHandler(ParserState paramParserState) {
    this.fDeclPool = paramParserState.cacheElementDeclPool();
    this.fErrHandler = paramParserState.getErrorHandler();
    this.fAttrPool = paramParserState.cacheAttrPool();
    this.fStringPool = paramParserState.cacheStringPool();
    this.fParserState = paramParserState;
    (this.fDeclPool != null && this.fErrHandler != null && this.fAttrPool != null && this.fStringPool != null && this.fParserState != null) ? 0 : 1;
  }
  
  public void reset(ParserState paramParserState) {
    this.fDeclPool = paramParserState.cacheElementDeclPool();
    this.fErrHandler = paramParserState.getErrorHandler();
    this.fAttrPool = paramParserState.cacheAttrPool();
    this.fStringPool = paramParserState.cacheStringPool();
    this.fParserState = paramParserState;
  }
  
  public void checkRootElementName(int paramInt) throws Exception {
    int i = this.fDeclPool.getRootElement();
    if (i == -1)
      return; 
    int j = this.fDeclPool.getElementName(i);
    if (paramInt != j)
      this.fErrHandler.error2(126, j, paramInt); 
  }
  
  public void checkAttributes(int paramInt1, int paramInt2) throws Exception {
    if (this.fParserState.getCheckNamespace())
      this.fDeclPool.checkNamespace(paramInt1, paramInt2); 
  }
  
  public int checkContent(int paramInt1, int paramInt2, int[] paramArrayOfInt) throws Exception {
    int i = this.fDeclPool.getElementName(paramInt1);
    int j = this.fDeclPool.getContentSpecType(paramInt1);
    if (j == 1) {
      if (paramInt2 != 0)
        return 0; 
    } else if (j != 2) {
      if (j == 3 || j == 4) {
        ContentModel contentModel = null;
        try {
          contentModel = getContentModel(paramInt1);
          return contentModel.validateContent(paramInt2, paramArrayOfInt);
        } catch (CMException cMException) {
          cMException.send(this.fErrHandler);
        } 
      } else if (j == 0) {
        this.fErrHandler.error1(166, i);
      } else {
        this.fErrHandler.error(152);
      } 
    } 
    return -1;
  }
  
  public void checkIDRefNames() throws Exception { this.fDeclPool.checkIdRefs(); }
  
  public int whatCanGoHere(int paramInt, boolean paramBoolean, InsertableElementsInfo paramInsertableElementsInfo) throws Exception {
    if (paramInsertableElementsInfo.insertAt > paramInsertableElementsInfo.childCount || paramInsertableElementsInfo.curChildren == null || paramInsertableElementsInfo.childCount < 1 || paramInsertableElementsInfo.childCount > paramInsertableElementsInfo.curChildren.length)
      this.fErrHandler.error(158); 
    int i = 0;
    try {
      ContentModel contentModel = getContentModel(paramInt);
      i = contentModel.whatCanGoHere(paramBoolean, paramInsertableElementsInfo);
    } catch (CMException cMException) {
      cMException.send(this.fErrHandler);
    } 
    return i;
  }
  
  private final ContentModel createChildModel(int paramInt) throws CMException {
    ContentSpecNode contentSpecNode = new ContentSpecNode();
    this.fDeclPool.getContentSpecNode(this.fDeclPool.getContentSpec(paramInt), contentSpecNode);
    if (contentSpecNode.value == -1)
      throw new CMException(159); 
    if (contentSpecNode.type == 0)
      return new SimpleContentModel(contentSpecNode.value, -1, contentSpecNode.type); 
    if (contentSpecNode.type == 4 || contentSpecNode.type == 5) {
      ContentSpecNode contentSpecNode1 = new ContentSpecNode();
      ContentSpecNode contentSpecNode2 = new ContentSpecNode();
      this.fDeclPool.getContentSpecNode(contentSpecNode.value, contentSpecNode1);
      this.fDeclPool.getContentSpecNode(contentSpecNode.otherValue, contentSpecNode2);
      if (contentSpecNode1.type == 0 && contentSpecNode2.type == 0)
        return new SimpleContentModel(contentSpecNode1.value, contentSpecNode2.value, contentSpecNode.type); 
    } else if (contentSpecNode.type == 1 || contentSpecNode.type == 2 || contentSpecNode.type == 3) {
      ContentSpecNode contentSpecNode1 = new ContentSpecNode();
      this.fDeclPool.getContentSpecNode(contentSpecNode.value, contentSpecNode1);
      if (contentSpecNode1.type == 0)
        return new SimpleContentModel(contentSpecNode1.value, -1, contentSpecNode.type); 
    } else {
      throw new CMException(152);
    } 
    return new DFAContentModel(paramInt, this.fStringPool, this.fDeclPool);
  }
  
  ContentModel getContentModel(int paramInt) throws CMException {
    ContentModel contentModel = this.fDeclPool.getContentModel(paramInt);
    if (contentModel != null)
      return contentModel; 
    int i = this.fDeclPool.getContentSpecType(paramInt);
    if (i == 3) {
      contentModel = new MixedContentModel(this.fDeclPool, paramInt);
    } else if (i == 4) {
      contentModel = createChildModel(paramInt);
    } else {
      throw new CMException(152);
    } 
    this.fDeclPool.setContentModel(paramInt, contentModel);
    return contentModel;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\DefaultValidationHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */