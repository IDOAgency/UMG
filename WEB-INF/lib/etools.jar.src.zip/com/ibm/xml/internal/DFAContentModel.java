package com.ibm.xml.internal;

import com.ibm.xml.framework.ContentModel;
import com.ibm.xml.framework.ContentSpecNode;
import com.ibm.xml.framework.ElementDeclPool;
import com.ibm.xml.framework.InsertableElementsInfo;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLErrorHandler;

class DFAContentModel implements ContentModel {
  private static final String fEpsilonString = "<<CMNODE_EPSILON>>";
  
  private static final String fEOCString = "<<CMNODE_EOC>>";
  
  private static final boolean DEBUG_VALIDATE_CONTENT = false;
  
  private ElementDeclPool fDeclPool;
  
  private int fElementIndex;
  
  private int[] fElemMap;
  
  private int fElemMapSize;
  
  private int fEOCIndex;
  
  private int fEOCPos;
  
  private int fEpsilonIndex;
  
  private XMLErrorHandler fErrHandler;
  
  private boolean[] fFinalStateFlags;
  
  private CMStateSet[] fFollowList;
  
  private CMNode fHeadNode;
  
  private int fLeafCount;
  
  private CMLeaf[] fLeafList;
  
  private ContentSpecNode fSpecNode;
  
  private StringPool fStringPool;
  
  private int[][] fTransTable;
  
  private int fTransTableSize;
  
  private boolean fEmptyContentIsValid = false;
  
  public DFAContentModel(int paramInt, StringPool paramStringPool, ElementDeclPool paramElementDeclPool) throws CMException {
    this.fElementIndex = paramInt;
    this.fDeclPool = paramElementDeclPool;
    this.fStringPool = paramStringPool;
    this.fEpsilonIndex = this.fStringPool.addSymbol("<<CMNODE_EPSILON>>");
    this.fEOCIndex = this.fStringPool.addSymbol("<<CMNODE_EOC>>");
    this.fSpecNode = new ContentSpecNode();
    this.fDeclPool.getContentSpecNode(this.fDeclPool.getContentSpec(this.fElementIndex), this.fSpecNode);
    buildDFA();
  }
  
  public int validateContent(int paramInt, int[] paramArrayOfInt) throws CMException {
    if (paramInt == 0)
      return this.fEmptyContentIsValid ? -1 : 0; 
    int i = 0;
    for (byte b = 0; b < paramInt; b++) {
      int j = paramArrayOfInt[b];
      byte b1;
      for (b1 = 0; b1 < this.fElemMapSize && this.fElemMap[b1] != j; b1++);
      if (b1 == this.fElemMapSize)
        return b; 
      i = this.fTransTable[i][b1];
      if (i == -1)
        return b; 
    } 
    return !this.fFinalStateFlags[i] ? paramInt : -1;
  }
  
  public int whatCanGoHere(boolean paramBoolean, InsertableElementsInfo paramInsertableElementsInfo) throws CMException {
    int i = 0;
    for (byte b1 = 0; b1 < paramInsertableElementsInfo.insertAt; b1++) {
      int k = paramInsertableElementsInfo.curChildren[b1];
      byte b;
      for (b = 0; b < this.fElemMapSize && this.fElemMap[b] != k; b++);
      if (b == this.fElemMapSize)
        return b1; 
      i = this.fTransTable[i][b];
      if (i == -1)
        return b1; 
    } 
    int j = i;
    paramInsertableElementsInfo.canHoldPCData = false;
    paramInsertableElementsInfo.isValidEOC = this.fFinalStateFlags[j];
    paramInsertableElementsInfo.resultsCount = this.fElemMapSize;
    if (paramInsertableElementsInfo.results == null || paramInsertableElementsInfo.results.length < paramInsertableElementsInfo.resultsCount)
      paramInsertableElementsInfo.results = new boolean[paramInsertableElementsInfo.resultsCount]; 
    if (paramInsertableElementsInfo.possibleChildren == null || paramInsertableElementsInfo.possibleChildren.length < paramInsertableElementsInfo.resultsCount)
      paramInsertableElementsInfo.possibleChildren = new int[paramInsertableElementsInfo.resultsCount]; 
    for (byte b2 = 0; b2 < this.fElemMapSize; b2++) {
      paramInsertableElementsInfo.possibleChildren[b2] = this.fElemMap[b2];
      paramInsertableElementsInfo.results[b2] = !(this.fTransTable[j][b2] == -1);
    } 
    if (paramBoolean)
      for (byte b = 0; b < paramInsertableElementsInfo.resultsCount; b++) {
        if (paramInsertableElementsInfo.results[b]) {
          paramInsertableElementsInfo.curChildren[paramInsertableElementsInfo.insertAt] = paramInsertableElementsInfo.possibleChildren[b];
          if (validateContent(paramInsertableElementsInfo.childCount, paramInsertableElementsInfo.curChildren) != -1)
            paramInsertableElementsInfo.results[b] = false; 
        } 
      }  
    return -1;
  }
  
  private void buildDFA() throws CMException {
    ContentSpecNode contentSpecNode = new ContentSpecNode();
    CMLeaf cMLeaf = new CMLeaf(0, this.fEOCIndex);
    this.fHeadNode = new CMBinOp(5, buildSyntaxTree(this.fDeclPool.getContentSpec(this.fElementIndex), contentSpecNode), cMLeaf);
    this.fEOCPos = this.fLeafCount;
    cMLeaf.setPosition(this.fLeafCount++);
    this.fLeafList = new CMLeaf[this.fLeafCount];
    postTreeBuildInit(this.fHeadNode, 0);
    this.fFollowList = new CMStateSet[this.fLeafCount];
    for (byte b1 = 0; b1 < this.fLeafCount; b1++)
      this.fFollowList[b1] = new CMStateSet(this.fLeafCount); 
    calcFollowList(this.fHeadNode);
    this.fElemMap = new int[this.fLeafCount];
    this.fElemMapSize = 0;
    for (byte b2 = 0; b2 < this.fLeafCount; b2++) {
      int j = this.fLeafList[b2].getElemIndex();
      byte b;
      for (b = 0; b < this.fElemMapSize && this.fElemMap[b] != j; b++);
      if (b == this.fElemMapSize)
        this.fElemMap[this.fElemMapSize++] = j; 
    } 
    int i = this.fLeafCount * 4;
    CMStateSet[] arrayOfCMStateSet = new CMStateSet[i];
    this.fFinalStateFlags = new boolean[i];
    this.fTransTable = new int[i][];
    CMStateSet cMStateSet = this.fHeadNode.firstPos();
    byte b3 = 0;
    byte b4 = 0;
    this.fTransTable[b4] = makeDefStateList();
    arrayOfCMStateSet[b4] = cMStateSet;
    while (b3 < ++b4) {
      cMStateSet = arrayOfCMStateSet[b3];
      int[] arrayOfInt = this.fTransTable[b3];
      this.fFinalStateFlags[b3] = cMStateSet.getBit(this.fEOCPos);
      b3++;
      CMStateSet cMStateSet1 = null;
      for (byte b = 0; b < this.fElemMapSize; b++) {
        if (cMStateSet1 == null) {
          cMStateSet1 = new CMStateSet(this.fLeafCount);
        } else {
          cMStateSet1.zeroBits();
        } 
        for (byte b5 = 0; b5 < this.fLeafCount; b5++) {
          if (cMStateSet.getBit(b5) && this.fLeafList[b5].getElemIndex() == this.fElemMap[b])
            cMStateSet1.union(this.fFollowList[b5]); 
        } 
        if (!cMStateSet1.isEmpty()) {
          byte b6;
          for (b6 = 0; b6 < b4 && !arrayOfCMStateSet[b6].isSameSet(cMStateSet1); b6++);
          if (b6 == b4) {
            arrayOfCMStateSet[b4] = cMStateSet1;
            this.fTransTable[b4] = makeDefStateList();
            b4++;
            cMStateSet1 = null;
          } 
          arrayOfInt[b] = b6;
          if (b4 == i) {
            int j = (int)(i * 1.5D);
            CMStateSet[] arrayOfCMStateSet1 = new CMStateSet[j];
            boolean[] arrayOfBoolean = new boolean[j];
            int[][] arrayOfInt1 = new int[j][];
            for (byte b7 = 0; b7 < i; b7++) {
              arrayOfCMStateSet1[b7] = arrayOfCMStateSet[b7];
              arrayOfBoolean[b7] = this.fFinalStateFlags[b7];
              arrayOfInt1[b7] = this.fTransTable[b7];
            } 
            i = j;
            arrayOfCMStateSet = arrayOfCMStateSet1;
            this.fFinalStateFlags = arrayOfBoolean;
            this.fTransTable = arrayOfInt1;
          } 
        } 
      } 
    } 
    this.fEmptyContentIsValid = ((CMBinOp)this.fHeadNode).getLeft().isNullable();
    this.fHeadNode = null;
    this.fLeafList = null;
    this.fFollowList = null;
  }
  
  private final CMNode buildSyntaxTree(int paramInt, ContentSpecNode paramContentSpecNode) throws CMException {
    CMBinOp cMBinOp = null;
    this.fDeclPool.getContentSpecNode(paramInt, paramContentSpecNode);
    if (paramContentSpecNode.type == 0) {
      cMBinOp = new CMLeaf(paramContentSpecNode.type, paramContentSpecNode.value, this.fLeafCount++);
    } else {
      int i = paramContentSpecNode.value;
      int j = paramContentSpecNode.otherValue;
      if (paramContentSpecNode.type == 4 || paramContentSpecNode.type == 5) {
        CMBinOp cMBinOp1 = new CMBinOp(paramContentSpecNode.type, buildSyntaxTree(i, paramContentSpecNode), buildSyntaxTree(j, paramContentSpecNode));
      } else if (paramContentSpecNode.type == 2) {
        CMUniOp cMUniOp = new CMUniOp(paramContentSpecNode.type, buildSyntaxTree(i, paramContentSpecNode));
      } else if (paramContentSpecNode.type == 1) {
        CMBinOp cMBinOp1 = new CMBinOp(4, buildSyntaxTree(i, paramContentSpecNode), new CMLeaf(0, this.fEpsilonIndex));
      } else if (paramContentSpecNode.type == 3) {
        cMBinOp = new CMBinOp(5, buildSyntaxTree(i, paramContentSpecNode), new CMUniOp(2, buildSyntaxTree(i, paramContentSpecNode)));
      } else {
        throw new CMException(152);
      } 
    } 
    return cMBinOp;
  }
  
  private void calcFollowList(CMNode paramCMNode) throws CMException {
    if (paramCMNode.type() == 4) {
      calcFollowList(((CMBinOp)paramCMNode).getLeft());
      calcFollowList(((CMBinOp)paramCMNode).getRight());
      return;
    } 
    if (paramCMNode.type() == 5) {
      calcFollowList(((CMBinOp)paramCMNode).getLeft());
      calcFollowList(((CMBinOp)paramCMNode).getRight());
      CMStateSet cMStateSet1 = ((CMBinOp)paramCMNode).getLeft().lastPos();
      CMStateSet cMStateSet2 = ((CMBinOp)paramCMNode).getRight().firstPos();
      for (byte b = 0; b < this.fLeafCount; b++) {
        if (cMStateSet1.getBit(b))
          this.fFollowList[b].union(cMStateSet2); 
      } 
      return;
    } 
    if (paramCMNode.type() == 2) {
      calcFollowList(((CMUniOp)paramCMNode).getChild());
      CMStateSet cMStateSet1 = paramCMNode.firstPos();
      CMStateSet cMStateSet2 = paramCMNode.lastPos();
      for (byte b = 0; b < this.fLeafCount; b++) {
        if (cMStateSet2.getBit(b))
          this.fFollowList[b].union(cMStateSet1); 
      } 
      return;
    } 
    if (paramCMNode.type() == 3 || paramCMNode.type() == 1)
      throw new CMException(157); 
  }
  
  private void dumpTree(CMNode paramCMNode, int paramInt) throws CMException {
    for (byte b = 0; b < paramInt; b++)
      System.out.print("   "); 
    int i = paramCMNode.type();
    if (i == 4 || i == 5) {
      if (i == 4) {
        System.out.print("Choice Node ");
      } else {
        System.out.print("Seq Node ");
      } 
      if (paramCMNode.isNullable())
        System.out.print("Nullable "); 
      System.out.print("firstPos=");
      System.out.print(paramCMNode.firstPos().toString());
      System.out.print(" lastPos=");
      System.out.println(paramCMNode.lastPos().toString());
      dumpTree(((CMBinOp)paramCMNode).getLeft(), paramInt + 1);
      dumpTree(((CMBinOp)paramCMNode).getRight(), paramInt + 1);
      return;
    } 
    if (paramCMNode.type() == 2) {
      System.out.print("Rep Node ");
      if (paramCMNode.isNullable())
        System.out.print("Nullable "); 
      System.out.print("firstPos=");
      System.out.print(paramCMNode.firstPos().toString());
      System.out.print(" lastPos=");
      System.out.println(paramCMNode.lastPos().toString());
      dumpTree(((CMUniOp)paramCMNode).getChild(), paramInt + 1);
      return;
    } 
    if (paramCMNode.type() == 0) {
      System.out.print("Leaf: (pos=" + ((CMLeaf)paramCMNode).getPosition() + "), " + this.fStringPool.toString(((CMLeaf)paramCMNode).getElemIndex()) + "(elemIndex=" + ((CMLeaf)paramCMNode).getElemIndex() + ") ");
      if (paramCMNode.isNullable())
        System.out.print(" Nullable "); 
      System.out.print("firstPos=");
      System.out.print(paramCMNode.firstPos().toString());
      System.out.print(" lastPos=");
      System.out.println(paramCMNode.lastPos().toString());
      return;
    } 
    throw new CMException(157);
  }
  
  private int[] makeDefStateList() {
    int[] arrayOfInt = new int[this.fElemMapSize];
    for (byte b = 0; b < this.fElemMapSize; b++)
      arrayOfInt[b] = -1; 
    return arrayOfInt;
  }
  
  private int postTreeBuildInit(CMNode paramCMNode, int paramInt) throws CMException {
    paramCMNode.setMaxStates(this.fLeafCount);
    if (paramCMNode.type() == 4 || paramCMNode.type() == 5) {
      paramInt = postTreeBuildInit(((CMBinOp)paramCMNode).getLeft(), paramInt);
      paramInt = postTreeBuildInit(((CMBinOp)paramCMNode).getRight(), paramInt);
    } else if (paramCMNode.type() == 2) {
      paramInt = postTreeBuildInit(((CMUniOp)paramCMNode).getChild(), paramInt);
    } else if (paramCMNode.type() == 0) {
      if (((CMLeaf)paramCMNode).getElemIndex() != this.fEpsilonIndex)
        this.fLeafList[paramInt++] = (CMLeaf)paramCMNode; 
    } else {
      throw new CMException(157);
    } 
    return paramInt;
  }
  
  static  {
    "<<CMNODE_EPSILON>>".intern();
    "<<CMNODE_EOC>>".intern();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\DFAContentModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */