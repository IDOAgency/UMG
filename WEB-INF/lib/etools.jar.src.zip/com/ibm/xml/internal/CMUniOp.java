package com.ibm.xml.internal;

class CMUniOp extends CMNode {
  private CMNode fChild;
  
  CMUniOp(int paramInt, CMNode paramCMNode) throws CMException {
    super(paramInt);
    if (type() != 1 && type() != 2 && type() != 3)
      throw new CMException(153); 
    this.fChild = paramCMNode;
  }
  
  final CMNode getChild() { return this.fChild; }
  
  boolean isNullable() throws CMException {
    if (type() == 1 || type() == 3)
      throw new CMException(153); 
    return true;
  }
  
  protected void calcFirstPos(CMStateSet paramCMStateSet) throws CMException { paramCMStateSet.setTo(this.fChild.firstPos()); }
  
  protected void calcLastPos(CMStateSet paramCMStateSet) throws CMException { paramCMStateSet.setTo(this.fChild.lastPos()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\CMUniOp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */