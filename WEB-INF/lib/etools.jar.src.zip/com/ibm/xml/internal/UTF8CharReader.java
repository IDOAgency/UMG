package com.ibm.xml.internal;

import com.ibm.xml.framework.ChunkyCharArray;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.ScanContentState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.StringProducer;
import com.ibm.xml.framework.XMLDocumentHandler;
import com.ibm.xml.framework.XMLErrorHandler;
import com.ibm.xml.framework.XMLReader;
import com.ibm.xml.framework.XMLScanner;
import java.io.InputStream;

final class UTF8CharReader extends XMLReader {
  protected static final int CHUNK_SHIFT = 14;
  
  protected static final int CHUNK_SIZE = 16384;
  
  protected static final int CHUNK_MASK = 16383;
  
  protected XMLScanner fScanner;
  
  protected XMLDocumentHandler fDocumentHandler;
  
  protected XMLErrorHandler fErrorHandler;
  
  protected StringPool fStringPool;
  
  protected InputStream fInputStream;
  
  protected UTF8CharDataChunk fCurrentChunk;
  
  protected int fCurrentIndex;
  
  protected char[] fMostRecentData;
  
  protected int fMostRecentChar;
  
  protected int fLength;
  
  protected boolean fCheckOverflow = false;
  
  protected byte[] fOverflow;
  
  protected int fOverflowOffset;
  
  protected int fOverflowEnd;
  
  protected boolean fSkipLinefeed = false;
  
  protected int fPartialMultiByteIn;
  
  protected byte[] fPartialMultiByteChar = new byte[3];
  
  protected int fPartialSurrogatePair;
  
  protected boolean fPartialMultiByteResult = false;
  
  protected int fFastCopyCount;
  
  protected int fOutputOffset;
  
  UTF8CharReader(ParserState paramParserState, String paramString1, String paramString2, InputStream paramInputStream) throws Exception {
    super(paramParserState, paramString1, paramString2);
    this.fInputStream = paramInputStream;
    this.fScanner = paramParserState.getScanner();
    this.fStringPool = paramParserState.cacheStringPool();
    this.fDocumentHandler = paramParserState.getDocumentHandler();
    this.fErrorHandler = paramParserState.getErrorHandler();
    this.fCurrentChunk = new UTF8CharDataChunk(this, this.fStringPool, null);
    fillCurrentChunk();
  }
  
  public int addString(int paramInt1, int paramInt2) { return (paramInt2 == 0) ? 0 : this.fCurrentChunk.addString(paramInt1, paramInt2); }
  
  public int addSymbol(int paramInt1, int paramInt2) { return (paramInt2 == 0) ? 0 : this.fCurrentChunk.addSymbol(paramInt1, paramInt2, 0); }
  
  protected int addSymbol(int paramInt1, int paramInt2, int paramInt3) { return (paramInt2 == 0) ? 0 : this.fCurrentChunk.addSymbol(paramInt1, paramInt2, paramInt3); }
  
  public void append(ChunkyCharArray paramChunkyCharArray, int paramInt1, int paramInt2) { this.fCurrentChunk.append(paramChunkyCharArray, paramInt1, paramInt2); }
  
  protected int slowLoadNextChar() throws Exception {
    UTF8CharDataChunk uTF8CharDataChunk = this.fCurrentChunk;
    if (uTF8CharDataChunk.fNextChunk != null) {
      uTF8CharDataChunk = this.fCurrentChunk;
      this.fCurrentChunk = uTF8CharDataChunk.fNextChunk;
      this.fCurrentIndex = 0;
      uTF8CharDataChunk = this.fCurrentChunk;
      this.fMostRecentData = uTF8CharDataChunk.fData;
      return this.fMostRecentChar = this.fMostRecentData[this.fCurrentIndex] & 0xFFFF;
    } 
    this.fCurrentChunk = new UTF8CharDataChunk(this, this.fStringPool, this.fCurrentChunk);
    return fillCurrentChunk();
  }
  
  protected int loadNextChar() throws Exception {
    this.fCurrentOffset++;
    return (++this.fCurrentIndex == 16384) ? slowLoadNextChar() : (this.fMostRecentChar = this.fMostRecentData[this.fCurrentIndex] & 0xFFFF);
  }
  
  protected void checkEOF(int paramInt) {
    if (paramInt > this.fLength)
      throw new ArrayIndexOutOfBoundsException(); 
  }
  
  public int skipOneChar() throws Exception {
    int i = this.fMostRecentChar;
    if (i == 0) {
      int j = this.fCurrentOffset + 1;
      if (j > this.fLength)
        throw new ArrayIndexOutOfBoundsException(); 
      this.fCharacterCounter++;
    } else if (i == 10) {
      this.fLinefeedCounter++;
      this.fCharacterCounter = 1;
    } else if (i >= 55296 && i < 56320) {
      this.fCharacterCounter++;
      i = loadNextChar();
      if (i < 56320 || i >= 57344)
        return this.fCurrentOffset; 
    } else {
      this.fCharacterCounter++;
    } 
    loadNextChar();
    return this.fCurrentOffset;
  }
  
  public int skipAsciiChar() throws Exception {
    this.fCharacterCounter++;
    loadNextChar();
    return this.fCurrentOffset;
  }
  
  public int skipToChar(char paramChar) throws Exception {
    for (int i = this.fMostRecentChar;; i = loadNextChar()) {
      if (i == paramChar)
        return this.fCurrentOffset; 
      if (i == 0) {
        int j = this.fCurrentOffset + 1;
        if (j > this.fLength)
          throw new ArrayIndexOutOfBoundsException(); 
        this.fCharacterCounter++;
      } else if (i == 10) {
        this.fLinefeedCounter++;
        this.fCharacterCounter = 1;
      } else if (i >= 55296 && i < 56320) {
        this.fCharacterCounter++;
        i = loadNextChar();
        if (i < 56320 || i >= 57344)
          continue; 
      } else {
        this.fCharacterCounter++;
      } 
    } 
  }
  
  public int skipPastChar(char paramChar) throws Exception {
    for (int i = this.fMostRecentChar;; i = loadNextChar()) {
      if (i == paramChar) {
        this.fCharacterCounter++;
        loadNextChar();
        return this.fCurrentOffset;
      } 
      if (i == 0) {
        int j = this.fCurrentOffset + 1;
        if (j > this.fLength)
          throw new ArrayIndexOutOfBoundsException(); 
        this.fCharacterCounter++;
      } else if (i == 10) {
        this.fLinefeedCounter++;
        this.fCharacterCounter = 1;
      } else if (i >= 55296 && i < 56320) {
        this.fCharacterCounter++;
        i = loadNextChar();
        if (i < 56320 || i >= 57344)
          continue; 
      } else {
        this.fCharacterCounter++;
      } 
    } 
  }
  
  public boolean skippedValidChar() throws Exception {
    int i = this.fMostRecentChar;
    if (i < 55296) {
      if (i >= 32 || i == 9) {
        this.fCharacterCounter++;
        loadNextChar();
        return true;
      } 
      if (i == 10) {
        this.fLinefeedCounter++;
        this.fCharacterCounter = 1;
        loadNextChar();
        return true;
      } 
      if (i == 0) {
        int j = this.fCurrentOffset + 1;
        if (j > this.fLength)
          throw new ArrayIndexOutOfBoundsException(); 
      } 
      return false;
    } 
    if (i > 65533)
      return false; 
    if (i < 56320) {
      i = loadNextChar();
      if (i < 56320 || i >= 57344)
        return false; 
    } else if (i < 57344) {
      return false;
    } 
    this.fCharacterCounter++;
    loadNextChar();
    return true;
  }
  
  public boolean lookingAtValidChar() throws Exception {
    int i = this.fMostRecentChar;
    if (i < 32) {
      if (i == 0) {
        int j = this.fCurrentOffset + 1;
        if (j > this.fLength)
          throw new ArrayIndexOutOfBoundsException(); 
      } 
      return !(i != 9 && i != 10 && i != 13);
    } 
    return !(i > 65533);
  }
  
  public int skipInvalidChar(int paramInt) throws Exception {
    String str2;
    String str1;
    int i = this.fMostRecentChar;
    if (i == 10) {
      this.fLinefeedCounter++;
      this.fCharacterCounter = 1;
      loadNextChar();
    } else {
      this.fCharacterCounter++;
      if (i >= 55296 && i < 56320) {
        int j = loadNextChar();
        if (j >= 56320 && j < 57344) {
          i = (i - 55296 << 10) + j - 56320 + 65536;
          loadNextChar();
        } 
      } else {
        loadNextChar();
      } 
    } 
    switch (paramInt) {
      case 63:
      case 85:
        str1 = Integer.toHexString(i);
        this.fErrorHandler.error1(paramInt, this.fStringPool.addString(str1));
        break;
      case 80:
      case 82:
      case 110:
        str1 = (i < 65536) ? (new Character((char)i)).toString() : Integer.toHexString(i);
        this.fErrorHandler.error1(paramInt, this.fStringPool.addString(str1));
        break;
      case 43:
        str1 = (i < 65536) ? (new Character((char)i)).toString() : Integer.toHexString(i);
        str2 = Integer.toHexString(i);
        this.fErrorHandler.error2(paramInt, this.fStringPool.addString(str1), this.fStringPool.addString(str2));
        break;
    } 
    return this.fCurrentOffset;
  }
  
  public boolean skippedChar(char paramChar) throws Exception {
    int i = this.fMostRecentChar;
    if (i != paramChar) {
      if (i == 0) {
        int j = this.fCurrentOffset + 1;
        if (j > this.fLength)
          throw new ArrayIndexOutOfBoundsException(); 
      } 
      return false;
    } 
    this.fCharacterCounter++;
    this.fCurrentOffset++;
    if (++this.fCurrentIndex == 16384) {
      slowLoadNextChar();
    } else {
      this.fMostRecentChar = this.fMostRecentData[this.fCurrentIndex] & 0xFFFF;
    } 
    return true;
  }
  
  public boolean lookingAtChar(char paramChar) throws Exception {
    int i = this.fMostRecentChar;
    return !(i != paramChar);
  }
  
  public boolean skippedSpace() throws Exception {
    int i = this.fMostRecentChar;
    if (i > 32)
      return false; 
    if (i == 32 || i == 9) {
      this.fCharacterCounter++;
    } else if (i == 10) {
      this.fLinefeedCounter++;
      this.fCharacterCounter = 1;
    } else {
      if (i == 0) {
        int j = this.fCurrentOffset + 1;
        if (j > this.fLength)
          throw new ArrayIndexOutOfBoundsException(); 
      } 
      return false;
    } 
    this.fCurrentOffset++;
    if (++this.fCurrentIndex == 16384) {
      slowLoadNextChar();
    } else {
      this.fMostRecentChar = this.fMostRecentData[this.fCurrentIndex] & 0xFFFF;
    } 
    return true;
  }
  
  public boolean lookingAtSpace() throws Exception {
    int i = this.fMostRecentChar;
    return !(i != 32 && i != 9 && i != 10);
  }
  
  public int skipPastSpaces() throws Exception {
    int i = this.fMostRecentChar;
    int j = this.fCurrentOffset;
    while (true) {
      if (i == 32 || i == 9) {
        this.fCharacterCounter++;
      } else if (i == 10) {
        this.fLinefeedCounter++;
        this.fCharacterCounter = 1;
      } else {
        if (i == 0 && j == this.fCurrentOffset) {
          int k = this.fCurrentOffset + 1;
          if (k > this.fLength)
            throw new ArrayIndexOutOfBoundsException(); 
        } 
        return this.fCurrentOffset;
      } 
      i = loadNextChar();
    } 
  }
  
  public int skipDecimalDigit() throws Exception {
    int i = this.fMostRecentChar;
    if (i < 48 || i > 57)
      return -1; 
    this.fCharacterCounter++;
    loadNextChar();
    return i - 48;
  }
  
  public int skipHexDigit() throws Exception {
    int i = this.fMostRecentChar;
    if (i > 102 || XMLReader.fgAsciiXDigitChar[i] == 0)
      return -1; 
    this.fCharacterCounter++;
    loadNextChar();
    return i - ((i < 65) ? 48 : (((i < 97) ? 65 : 97) - 10));
  }
  
  public boolean skippedAlpha() throws Exception {
    int i = this.fMostRecentChar;
    if (i > 122 || XMLReader.fgAsciiAlphaChar[i] == 0)
      return false; 
    this.fCharacterCounter++;
    loadNextChar();
    return true;
  }
  
  protected boolean skippedAsciiCharWithFlag(byte paramByte) throws Exception {
    int i = this.fMostRecentChar;
    if (i >= 128 || (XMLReader.fgCharFlags[i] & paramByte) == 0)
      return false; 
    this.fCharacterCounter++;
    loadNextChar();
    return true;
  }
  
  public boolean skippedVersionNum() throws Exception { return skippedAsciiCharWithFlag((byte)1); }
  
  public boolean skippedEncName() throws Exception { return skippedAsciiCharWithFlag((byte)2); }
  
  public boolean skippedPubidChar() throws Exception {
    int i = this.fMostRecentChar;
    if (i >= 128)
      return false; 
    if ((XMLReader.fgCharFlags[i] & 0x4) != 0) {
      this.fCharacterCounter++;
      loadNextChar();
      return true;
    } 
    if (i == 10) {
      this.fLinefeedCounter++;
      this.fCharacterCounter = 1;
      loadNextChar();
      return true;
    } 
    return false;
  }
  
  public boolean skippedString(char[] paramArrayOfChar) throws Exception {
    int i = paramArrayOfChar.length;
    char[] arrayOfChar = this.fMostRecentData;
    int j = this.fCurrentIndex;
    if (j + i <= 16384) {
      for (byte b1 = 0; b1 < i; b1++) {
        if (arrayOfChar[j++] != paramArrayOfChar[b1])
          return false; 
      } 
      this.fCharacterCounter += i;
      this.fCurrentOffset += i;
      this.fCurrentIndex = j;
      if (j == 16384) {
        slowLoadNextChar();
      } else {
        this.fMostRecentChar = arrayOfChar[j] & 0xFFFF;
      } 
      return true;
    } 
    UTF8CharDataChunk uTF8CharDataChunk = this.fCurrentChunk;
    int k = this.fCurrentOffset;
    int m = j;
    byte b = 0;
    while (j < 16384) {
      if (arrayOfChar[j++] != paramArrayOfChar[b++])
        return false; 
    } 
    slowLoadNextChar();
    arrayOfChar = this.fMostRecentData;
    j = 0;
    while (b < i) {
      if (arrayOfChar[j++] != paramArrayOfChar[b++]) {
        this.fCurrentChunk = uTF8CharDataChunk;
        this.fCurrentIndex = m;
        this.fCurrentOffset = k;
        this.fMostRecentData = uTF8CharDataChunk.fData;
        this.fMostRecentChar = this.fMostRecentData[m] & 0xFFFF;
        return false;
      } 
    } 
    this.fCharacterCounter += i;
    this.fCurrentOffset += i;
    this.fCurrentIndex = j;
    if (j == 16384) {
      slowLoadNextChar();
    } else {
      this.fMostRecentChar = arrayOfChar[j] & 0xFFFF;
    } 
    return true;
  }
  
  public int scanName(char paramChar, int paramInt) throws Exception {
    int i = this.fMostRecentChar;
    if (i < 128) {
      if (XMLReader.fgAsciiInitialNameChar[i] == 0)
        return -1; 
    } else if ((XMLReader.fgCharFlags[i] & 0x10) == 0) {
      return -1;
    } 
    int j = this.fCurrentOffset;
    int k = this.fCurrentIndex;
    char[] arrayOfChar = this.fMostRecentData;
    if (++k == 16384) {
      this.fCurrentChunk = new UTF8CharDataChunk(this, this.fStringPool, this.fCurrentChunk);
      fillCurrentChunk();
      k = 0;
      arrayOfChar = this.fMostRecentData;
    } 
    this.fCharacterCounter++;
    this.fCurrentOffset++;
    int m = 0;
    byte b1 = 0;
    while (true) {
      m = StringHasher.hashChar(m, b1++, i);
      i = arrayOfChar[k] & 0xFFFF;
      if (paramChar == i || ((i < 128) ? (XMLReader.fgAsciiNameChar[i] == 0) : ((XMLReader.fgCharFlags[i] & 0x20) == 0)))
        break; 
      if (++k == 16384) {
        this.fCurrentChunk = new UTF8CharDataChunk(this, this.fStringPool, this.fCurrentChunk);
        fillCurrentChunk();
        k = 0;
        arrayOfChar = this.fMostRecentData;
      } 
      this.fCharacterCounter++;
      this.fCurrentOffset++;
    } 
    this.fCurrentIndex = k;
    this.fMostRecentChar = i;
    int n = m;
    n &= Integer.MAX_VALUE;
    m = (n == 0) ? 1 : n;
    n = this.fCurrentOffset - j;
    byte b2 = (n == 0) ? 0 : this.fCurrentChunk.addSymbol(j, n, m);
    return (paramInt == -1 || paramInt == b2) ? b2 : -1;
  }
  
  public int skipPastName(char paramChar) throws Exception {
    int i = this.fMostRecentChar;
    if (i < 128) {
      if (XMLReader.fgAsciiInitialNameChar[i] == 0)
        return this.fCurrentOffset; 
    } else if ((XMLReader.fgCharFlags[i] & 0x10) == 0) {
      return this.fCurrentOffset;
    } 
    while (true) {
      this.fCharacterCounter++;
      i = loadNextChar();
      if (paramChar == i)
        return this.fCurrentOffset; 
      if (i < 128) {
        if (XMLReader.fgAsciiNameChar[i] == 0)
          return this.fCurrentOffset; 
        continue;
      } 
      if ((XMLReader.fgCharFlags[i] & 0x20) == 0)
        break; 
    } 
    return this.fCurrentOffset;
  }
  
  public int skipPastNmtoken(char paramChar) throws Exception {
    for (int i = this.fMostRecentChar;; i = loadNextChar()) {
      if (paramChar == i)
        return this.fCurrentOffset; 
      if (i < 128) {
        if (XMLReader.fgAsciiNameChar[i] == 0)
          return this.fCurrentOffset; 
      } else if ((XMLReader.fgCharFlags[i] & 0x20) == 0) {
        return this.fCurrentOffset;
      } 
      this.fCharacterCounter++;
    } 
  }
  
  public int scanContent(ScanContentState paramScanContentState) throws Exception {
    UTF8CharDataChunk uTF8CharDataChunk = this.fCurrentChunk;
    if (uTF8CharDataChunk.fPreviousChunk != null) {
      uTF8CharDataChunk.fPreviousChunk.fNextChunk = null;
      uTF8CharDataChunk.fPreviousChunk = null;
    } 
    int i = this.fCurrentOffset;
    int j = this.fMostRecentChar;
    if (j < 128) {
      switch (XMLReader.fgAsciiWSCharData[j]) {
        case 0:
          this.fCharacterCounter++;
          this.fCurrentOffset++;
          if (++this.fCurrentIndex == 16384) {
            slowLoadNextChar();
            break;
          } 
          this.fMostRecentChar = this.fMostRecentData[this.fCurrentIndex] & 0xFFFF;
          break;
        case 1:
          this.fCharacterCounter++;
          this.fCurrentOffset++;
          if (++this.fCurrentIndex == 16384) {
            slowLoadNextChar();
          } else {
            this.fMostRecentChar = this.fMostRecentData[this.fCurrentIndex] & 0xFFFF;
          } 
          if (!paramScanContentState.inCDSect)
            return 1; 
          break;
        case 2:
          this.fCharacterCounter++;
          this.fCurrentOffset++;
          if (++this.fCurrentIndex == 16384) {
            slowLoadNextChar();
          } else {
            this.fMostRecentChar = this.fMostRecentData[this.fCurrentIndex] & 0xFFFF;
          } 
          if (!paramScanContentState.inCDSect)
            return 2; 
          break;
        case 3:
          this.fCharacterCounter++;
          j = loadNextChar();
          if (j == 93) {
            if (this.fCurrentIndex + 1 == 16384) {
              UTF8CharDataChunk uTF8CharDataChunk1 = this.fCurrentChunk;
              int k = this.fCurrentIndex;
              int m = this.fCurrentOffset;
              if (loadNextChar() != 62) {
                this.fCurrentChunk = uTF8CharDataChunk1;
                this.fCurrentIndex = k;
                this.fCurrentOffset = m;
                this.fMostRecentData = uTF8CharDataChunk1.fData;
                this.fMostRecentChar = 93;
                break;
              } 
            } else if (this.fMostRecentData[this.fCurrentIndex + 1] == '>') {
              this.fCurrentIndex++;
              this.fCurrentOffset++;
            } else {
              break;
            } 
            loadNextChar();
            this.fCharacterCounter += 2;
            if (paramScanContentState.inCDSect) {
              paramScanContentState.inCDSect = false;
              return scanContent(paramScanContentState);
            } 
            return 3;
          } 
          break;
        case 4:
          return 4;
        case 5:
          do {
            if (j == 10) {
              this.fLinefeedCounter++;
              this.fCharacterCounter = 1;
            } else {
              this.fCharacterCounter++;
            } 
            this.fCurrentOffset++;
            if (++this.fCurrentIndex == 16384) {
              j = slowLoadNextChar();
            } else {
              j = this.fMostRecentChar = this.fMostRecentData[this.fCurrentIndex] & 0xFFFF;
            } 
          } while (j == 32 || j == 9 || j == 10);
          if (j < 128) {
            int k;
            switch (XMLReader.fgAsciiCharData[j]) {
              case 0:
                this.fCharacterCounter++;
                this.fCurrentOffset++;
                if (++this.fCurrentIndex == 16384) {
                  slowLoadNextChar();
                  break;
                } 
                this.fMostRecentChar = this.fMostRecentData[this.fCurrentIndex] & 0xFFFF;
                break;
              case 1:
                if (!paramScanContentState.inCDSect) {
                  if (this.fDocumentHandler != null)
                    callWSCharDataHandler(i, this.fCurrentOffset, false); 
                  this.fCharacterCounter++;
                  loadNextChar();
                  return 25;
                } 
                this.fCharacterCounter++;
                this.fCurrentOffset++;
                if (++this.fCurrentIndex == 16384) {
                  slowLoadNextChar();
                  break;
                } 
                this.fMostRecentChar = this.fMostRecentData[this.fCurrentIndex] & 0xFFFF;
                break;
              case 2:
                if (!paramScanContentState.inCDSect) {
                  if (this.fDocumentHandler != null)
                    callWSCharDataHandler(i, this.fCurrentOffset, false); 
                  this.fCharacterCounter++;
                  loadNextChar();
                  return 26;
                } 
                this.fCharacterCounter++;
                loadNextChar();
                break;
              case 3:
                k = this.fCurrentOffset;
                j = loadNextChar();
                if (j != 93) {
                  this.fCharacterCounter++;
                  break;
                } 
                if (this.fCurrentIndex + 1 == 16384) {
                  UTF8CharDataChunk uTF8CharDataChunk1 = this.fCurrentChunk;
                  int m = this.fCurrentIndex;
                  int n = this.fCurrentOffset;
                  if (loadNextChar() != 62) {
                    this.fCurrentChunk = uTF8CharDataChunk1;
                    this.fCurrentIndex = m;
                    this.fCurrentOffset = n;
                    this.fMostRecentData = uTF8CharDataChunk1.fData;
                    this.fMostRecentChar = 93;
                    this.fCharacterCounter++;
                    break;
                  } 
                } else {
                  if (this.fMostRecentData[this.fCurrentIndex + 1] != '>') {
                    this.fCharacterCounter++;
                    break;
                  } 
                  this.fCurrentIndex++;
                  this.fCurrentOffset++;
                } 
                loadNextChar();
                if (this.fDocumentHandler != null)
                  callWSCharDataHandler(i, k, paramScanContentState.inCDSect); 
                this.fCharacterCounter += 3;
                if (paramScanContentState.inCDSect) {
                  paramScanContentState.inCDSect = false;
                  return scanContent(paramScanContentState);
                } 
                return 27;
              case 4:
                if (this.fDocumentHandler != null)
                  callWSCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
                return 28;
            } 
            break;
          } 
          if (!skipMultiByteCharData(j)) {
            if (this.fDocumentHandler != null)
              callWSCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
            return 28;
          } 
          break;
      } 
    } else if (!skipMultiByteCharData(j)) {
      return 4;
    } 
    for (j = skipAsciiCharData();; j = this.fMostRecentChar) {
      while (j < 128) {
        int k;
        switch (XMLReader.fgAsciiCharData[j]) {
          case 0:
            this.fCharacterCounter++;
            j = loadNextChar();
            break;
          case 1:
            if (!paramScanContentState.inCDSect) {
              if (this.fDocumentHandler != null)
                callCharDataHandler(i, this.fCurrentOffset, false); 
              this.fCharacterCounter++;
              this.fCurrentOffset++;
              if (++this.fCurrentIndex == 16384) {
                slowLoadNextChar();
              } else {
                this.fMostRecentChar = this.fMostRecentData[this.fCurrentIndex] & 0xFFFF;
              } 
              return 9;
            } 
            this.fCharacterCounter++;
            j = loadNextChar();
            break;
          case 2:
            if (!paramScanContentState.inCDSect) {
              if (this.fDocumentHandler != null)
                callCharDataHandler(i, this.fCurrentOffset, false); 
              this.fCharacterCounter++;
              loadNextChar();
              return 10;
            } 
            this.fCharacterCounter++;
            j = loadNextChar();
            break;
          case 3:
            k = this.fCurrentOffset;
            j = loadNextChar();
            if (j != 93) {
              this.fCharacterCounter++;
              break;
            } 
            if (this.fCurrentIndex + 1 == 16384) {
              UTF8CharDataChunk uTF8CharDataChunk1 = this.fCurrentChunk;
              int m = this.fCurrentIndex;
              int n = this.fCurrentOffset;
              if (loadNextChar() != 62) {
                this.fCurrentChunk = uTF8CharDataChunk1;
                this.fCurrentIndex = m;
                this.fCurrentOffset = n;
                this.fMostRecentData = uTF8CharDataChunk1.fData;
                this.fMostRecentChar = 93;
                this.fCharacterCounter++;
                break;
              } 
            } else {
              if (this.fMostRecentData[this.fCurrentIndex + 1] != '>') {
                this.fCharacterCounter++;
                break;
              } 
              this.fCurrentIndex++;
              this.fCurrentOffset++;
            } 
            loadNextChar();
            if (this.fDocumentHandler != null)
              callCharDataHandler(i, k, paramScanContentState.inCDSect); 
            this.fCharacterCounter += 3;
            if (paramScanContentState.inCDSect) {
              paramScanContentState.inCDSect = false;
              return scanContent(paramScanContentState);
            } 
            return 11;
          case 4:
            if (j == 10) {
              this.fLinefeedCounter++;
              this.fCharacterCounter = 1;
              j = loadNextChar();
              break;
            } 
            if (this.fDocumentHandler != null)
              callCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
            return 12;
        } 
      } 
      if (!skipMultiByteCharData(j)) {
        if (this.fDocumentHandler != null)
          callCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
        return 12;
      } 
    } 
  }
  
  protected boolean skipMultiByteCharData(int paramInt) throws Exception {
    if (paramInt > 65533)
      return false; 
    if (paramInt >= 901120 && paramInt < 57344)
      return false; 
    if (paramInt >= 884736 && paramInt < 56320) {
      paramInt = loadNextChar();
      if (paramInt < 901120 || paramInt >= 57344)
        return false; 
    } 
    loadNextChar();
    return true;
  }
  
  protected int skipAsciiCharData() throws Exception {
    int i = this.fCurrentIndex;
    int j = this.fCurrentOffset - i;
    while (true) {
      char[] arrayOfChar = this.fMostRecentData;
      while (i < 16384) {
        char c = arrayOfChar[i] & 0xFFFF;
        if (c >= '') {
          this.fCurrentOffset = j + i;
          this.fCurrentIndex = i;
          this.fMostRecentChar = c;
          return c;
        } 
        if (XMLReader.fgAsciiCharData[c] != 0) {
          if (c != '\n') {
            this.fCurrentOffset = j + i;
            this.fCurrentIndex = i;
            this.fMostRecentChar = c;
            return c;
          } 
          this.fLinefeedCounter++;
          this.fCharacterCounter = 1;
        } else {
          this.fCharacterCounter++;
        } 
        i++;
      } 
      j += i;
      this.fCurrentChunk = new UTF8CharDataChunk(this, this.fStringPool, this.fCurrentChunk);
      fillCurrentChunk();
      i = 0;
    } 
  }
  
  public void callCharDataHandler(int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {
    int i = paramInt2 - paramInt1;
    if (!this.fDocumentHandler.sendCharDataAsCharArray()) {
      byte b = (i == 0) ? 0 : this.fCurrentChunk.addString(paramInt1, i);
      this.fDocumentHandler.characters(b, paramBoolean);
      return;
    } 
    UTF8CharDataChunk uTF8CharDataChunk = this.fCurrentChunk.chunkFor(paramInt1);
    int j = paramInt1 & 0x3FFF;
    if (j + i <= 16384) {
      if (i != 0)
        this.fDocumentHandler.characters(uTF8CharDataChunk.fData, j, i, paramBoolean); 
      return;
    } 
    int k = i;
    int m = 16384 - j;
    this.fDocumentHandler.characters(uTF8CharDataChunk.fData, j, m, paramBoolean);
    k -= m;
    do {
      uTF8CharDataChunk = uTF8CharDataChunk.fNextChunk;
      if (uTF8CharDataChunk == null)
        System.out.println("dataChunk == null"); 
      m = (k <= 16384) ? k : 16384;
      this.fDocumentHandler.characters(uTF8CharDataChunk.fData, 0, m, paramBoolean);
      k -= m;
    } while (k > 0);
  }
  
  public void callWSCharDataHandler(int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {
    int i = this.fScanner.getCurrentContentSpecType();
    if (i != 4) {
      callCharDataHandler(paramInt1, paramInt2, paramBoolean);
      return;
    } 
    int j = paramInt2 - paramInt1;
    if (!this.fDocumentHandler.sendCharDataAsCharArray()) {
      byte b = (j == 0) ? 0 : this.fCurrentChunk.addString(paramInt1, j);
      this.fDocumentHandler.ignorableWhitespace(b, paramBoolean);
      return;
    } 
    UTF8CharDataChunk uTF8CharDataChunk = this.fCurrentChunk.chunkFor(paramInt1);
    int k = paramInt1 & 0x3FFF;
    if (k + j <= 16384) {
      if (j != 0)
        this.fDocumentHandler.ignorableWhitespace(uTF8CharDataChunk.fData, k, j, paramBoolean); 
      return;
    } 
    int m = j;
    int n = 16384 - k;
    this.fDocumentHandler.ignorableWhitespace(uTF8CharDataChunk.fData, k, n, paramBoolean);
    m -= n;
    do {
      uTF8CharDataChunk = uTF8CharDataChunk.fNextChunk;
      n = (m <= 16384) ? m : 16384;
      this.fDocumentHandler.ignorableWhitespace(uTF8CharDataChunk.fData, 0, n, paramBoolean);
      m -= n;
    } while (m > 0);
  }
  
  protected int fillCurrentChunk() throws Exception {
    this.fOutputOffset = 0;
    if (this.fCheckOverflow) {
      if (this.fOverflowEnd < 16384) {
        if (this.fOverflowEnd > 0) {
          this.fMostRecentData = new char[1 + this.fOverflowEnd - this.fOverflowOffset];
          copyNormalize(this.fOverflow, this.fOverflowOffset, this.fMostRecentData, this.fOutputOffset);
        } else {
          this.fMostRecentData = new char[1];
        } 
        this.fMostRecentData[this.fOutputOffset] = Character.MIN_VALUE;
        this.fOverflow = null;
        this.fLength += this.fOutputOffset;
        this.fCurrentIndex = 0;
        UTF8CharDataChunk uTF8CharDataChunk1 = this.fCurrentChunk;
        char[] arrayOfChar1 = this.fMostRecentData;
        uTF8CharDataChunk1.fData = arrayOfChar1;
        return this.fMostRecentChar = this.fMostRecentData[0];
      } 
      this.fMostRecentData = new char[16384];
      copyNormalize(this.fOverflow, this.fOverflowOffset, this.fMostRecentData, this.fOutputOffset);
      this.fCheckOverflow = false;
    } else {
      if (this.fOverflow == null)
        this.fOverflow = new byte[16384]; 
      this.fMostRecentData = null;
    } 
    while (true) {
      this.fOverflowOffset = 0;
      this.fOverflowEnd = 0;
      int i = 16384;
      int j = 0;
      do {
        j = this.fInputStream.read(this.fOverflow, this.fOverflowEnd, i);
        if (j == -1) {
          this.fInputStream.close();
          this.fInputStream = null;
          if (this.fMostRecentData == null) {
            this.fMostRecentData = new char[1 + this.fOverflowEnd];
            copyNormalize(this.fOverflow, this.fOverflowOffset, this.fMostRecentData, this.fOutputOffset);
            this.fOverflow = null;
            this.fMostRecentData[this.fOutputOffset] = Character.MIN_VALUE;
            break;
          } 
          boolean bool = copyNormalize(this.fOverflow, this.fOverflowOffset, this.fMostRecentData, this.fOutputOffset);
          if (bool) {
            if (this.fOverflowEnd == 16384) {
              this.fCheckOverflow = true;
              this.fOverflowOffset = 0;
              this.fOverflowEnd = 0;
              break;
            } 
            this.fOverflow = null;
            this.fMostRecentData[this.fOutputOffset] = Character.MIN_VALUE;
            break;
          } 
          this.fCheckOverflow = true;
          break;
        } 
        if (j <= 0)
          continue; 
        this.fOverflowEnd += j;
        i -= j;
      } while (i > 0);
      if (j != -1) {
        if (this.fMostRecentData != null) {
          boolean bool = copyNormalize(this.fOverflow, this.fOverflowOffset, this.fMostRecentData, this.fOutputOffset);
          if (this.fOutputOffset == 16384) {
            if (!bool)
              this.fCheckOverflow = true; 
            break;
          } 
          continue;
        } 
        this.fMostRecentData = new char[16384];
        copyNormalize(this.fOverflow, this.fOverflowOffset, this.fMostRecentData, this.fOutputOffset);
        if (this.fOutputOffset == 16384)
          break; 
        continue;
      } 
      break;
    } 
    this.fLength += this.fOutputOffset;
    this.fCurrentIndex = 0;
    UTF8CharDataChunk uTF8CharDataChunk = this.fCurrentChunk;
    char[] arrayOfChar = this.fMostRecentData;
    uTF8CharDataChunk.fData = arrayOfChar;
    return this.fMostRecentChar = this.fMostRecentData[0];
  }
  
  protected boolean copyNormalize(byte[] paramArrayOfByte, int paramInt1, char[] paramArrayOfChar, int paramInt2) throws Exception {
    int i = this.fOverflowEnd;
    int j = paramArrayOfChar.length;
    if (paramInt1 == i)
      return true; 
    byte b = paramArrayOfByte[paramInt1];
    if (this.fSkipLinefeed) {
      this.fSkipLinefeed = false;
      if (b == 10) {
        if (++paramInt1 == i) {
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt2;
          return true;
        } 
        b = paramArrayOfByte[paramInt1];
      } 
    } else if (this.fPartialMultiByteIn > 0) {
      if (!handlePartialMultiByteChar(b, paramArrayOfByte, paramInt1, i, paramArrayOfChar, paramInt2, j))
        return this.fPartialMultiByteResult; 
      paramInt1 = this.fOverflowOffset;
      paramInt2 = this.fOutputOffset;
      b = paramArrayOfByte[paramInt1];
    } 
    while (paramInt2 < j) {
      int k = i - paramInt1;
      int m = j - paramInt2;
      if (k > m)
        k = m; 
      paramInt1++;
      while (true) {
        if (b != 13 && (b & 0x80) == 0) {
          while (true) {
            paramArrayOfChar[paramInt2++] = (char)b;
            if (--k != 0) {
              b = paramArrayOfByte[paramInt1++];
              if (b == 13 || b < 0)
                break; 
              continue;
            } 
            break;
          } 
          if (k == 0)
            break; 
          continue;
        } 
        if (b == 13) {
          paramArrayOfChar[paramInt2++] = '\n';
          if (paramInt1 == i) {
            this.fSkipLinefeed = true;
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt2;
            return true;
          } 
          b = paramArrayOfByte[paramInt1];
          if (b == 10) {
            if (++paramInt1 == i) {
              this.fOverflowOffset = paramInt1;
              this.fOutputOffset = paramInt2;
              return true;
            } 
            b = paramArrayOfByte[paramInt1];
          } 
          if (paramInt2 == j) {
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt2;
            return false;
          } 
        } else {
          if (!handleMultiByteChar(b, paramArrayOfByte, paramInt1, i, paramArrayOfChar, paramInt2, j))
            return this.fPartialMultiByteResult; 
          paramInt1 = this.fOverflowOffset;
          paramInt2 = this.fOutputOffset;
          b = paramArrayOfByte[paramInt1];
        } 
        k = i - paramInt1;
        m = j - paramInt2;
        if (k > m)
          k = m; 
        paramInt1++;
      } 
      if (paramInt1 != i)
        continue; 
      break;
    } 
    boolean bool = !(paramInt1 != i);
    this.fOverflowOffset = paramInt1;
    this.fOutputOffset = paramInt2;
    return bool;
  }
  
  protected boolean exitNormalize(int paramInt1, int paramInt2, boolean paramBoolean) {
    this.fOverflowOffset = paramInt1;
    this.fOutputOffset = paramInt2;
    return paramBoolean;
  }
  
  protected void savePartialMultiByte(int paramInt, byte paramByte1, byte paramByte2, byte paramByte3) {
    this.fPartialMultiByteIn = paramInt;
    this.fPartialMultiByteChar[--paramInt] = paramByte1;
    this.fPartialMultiByteChar[--paramInt] = paramByte2;
    this.fPartialMultiByteChar[--paramInt] = paramByte3;
  }
  
  protected void savePartialMultiByte(int paramInt, byte paramByte1, byte paramByte2) {
    this.fPartialMultiByteIn = paramInt;
    this.fPartialMultiByteChar[--paramInt] = paramByte1;
    this.fPartialMultiByteChar[--paramInt] = paramByte2;
  }
  
  protected void savePartialMultiByte(int paramInt, byte paramByte) {
    this.fPartialMultiByteIn = paramInt;
    this.fPartialMultiByteChar[--paramInt] = paramByte;
  }
  
  protected boolean handleMultiByteChar(byte paramByte, byte[] paramArrayOfByte, int paramInt1, int paramInt2, char[] paramArrayOfChar, int paramInt3, int paramInt4) throws Exception {
    if (paramInt1 == paramInt2) {
      byte b1 = 1;
      this.fPartialMultiByteIn = b1;
      this.fPartialMultiByteChar[--b1] = paramByte;
      this.fOverflowOffset = paramInt1;
      this.fOutputOffset = paramInt3;
      this.fPartialMultiByteResult = true;
      return false;
    } 
    byte b = paramArrayOfByte[paramInt1++];
    if ((b & 0xC0) != 128)
      this.fErrorHandler.error2(57, this.fStringPool.addString(Integer.toHexString(paramByte)), this.fStringPool.addString(Integer.toHexString(b))); 
    if ((paramByte & 0xE0) == 192) {
      byte b1 = ((0x1F & paramByte) << 6) + (0x3F & b);
      paramArrayOfChar[paramInt3++] = (char)b1;
      if (paramInt1 == paramInt2 || paramInt3 == paramInt4) {
        boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
        this.fOverflowOffset = paramInt1;
        this.fOutputOffset = paramInt3;
        this.fPartialMultiByteResult = bool;
        return false;
      } 
    } else {
      if (paramInt1 == paramInt2) {
        savePartialMultiByte(2, b, paramByte);
        this.fOverflowOffset = paramInt1;
        this.fOutputOffset = paramInt3;
        this.fPartialMultiByteResult = true;
        return false;
      } 
      byte b1 = paramArrayOfByte[paramInt1++];
      if ((b1 & 0xC0) != 128)
        this.fErrorHandler.error3(58, this.fStringPool.addString(Integer.toHexString(paramByte)), this.fStringPool.addString(Integer.toHexString(b)), this.fStringPool.addString(Integer.toHexString(b1))); 
      if ((paramByte & 0xF0) == 224) {
        byte b2 = ((0xF & paramByte) << 12) + ((0x3F & b) << 6) + (0x3F & b1);
        paramArrayOfChar[paramInt3++] = (char)b2;
        if (paramInt1 == paramInt2 || paramInt3 == paramInt4) {
          boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = bool;
          return false;
        } 
      } else {
        if ((paramByte & 0xF8) != 240)
          this.fErrorHandler.error1(56, this.fStringPool.addString(Integer.toHexString(paramByte))); 
        if (paramInt1 == paramInt2) {
          savePartialMultiByte(3, b1, b, paramByte);
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = true;
          return false;
        } 
        byte b2 = paramArrayOfByte[paramInt1++];
        if ((b2 & 0xC0) != 128)
          this.fErrorHandler.error4(59, this.fStringPool.addString(Integer.toHexString(paramByte)), this.fStringPool.addString(Integer.toHexString(b)), this.fStringPool.addString(Integer.toHexString(b1)), this.fStringPool.addString(Integer.toHexString(b2))); 
        byte b3 = ((0xF & paramByte) << 18) + ((0x3F & b) << 12) + ((0x3F & b1) << 6) + (0x3F & b2);
        if (b3 >= 65536) {
          paramArrayOfChar[paramInt3++] = (char)((b3 - 65536 >> 10) + 55296);
          b3 = (b3 - 65536 & 0x3FF) + 56320;
          if (paramInt3 == paramInt4) {
            this.fPartialSurrogatePair = b3;
            boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt3;
            this.fPartialMultiByteResult = bool;
            return false;
          } 
        } 
        paramArrayOfChar[paramInt3++] = (char)b3;
        if (paramInt1 == paramInt2 || paramInt3 == paramInt4) {
          boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = bool;
          return false;
        } 
      } 
    } 
    this.fOverflowOffset = paramInt1;
    this.fOutputOffset = paramInt3;
    return true;
  }
  
  protected boolean handlePartialMultiByteChar(byte paramByte, byte[] paramArrayOfByte, int paramInt1, int paramInt2, char[] paramArrayOfChar, int paramInt3, int paramInt4) throws Exception {
    byte b3;
    if (paramInt3 == paramInt4) {
      boolean bool = (paramInt1 != paramInt2) ? 0 : 1;
      this.fOverflowOffset = paramInt1;
      this.fOutputOffset = paramInt3;
      this.fPartialMultiByteResult = bool;
      return false;
    } 
    if (this.fPartialMultiByteIn == 4) {
      paramArrayOfChar[paramInt3++] = (char)this.fPartialSurrogatePair;
      if (paramInt3 == paramInt4) {
        this.fOverflowOffset = paramInt1;
        this.fOutputOffset = paramInt3;
        this.fPartialMultiByteResult = false;
        return false;
      } 
      this.fOutputOffset = paramInt3;
      return true;
    } 
    int i = this.fPartialMultiByteIn;
    this.fPartialMultiByteIn = 0;
    byte b1 = 0;
    byte b2 = 0;
    byte b = 0;
    switch (i) {
      case 1:
        b1 = paramByte;
        break;
      case 2:
        b2 = paramByte;
        break;
      case 3:
        b = paramByte;
        break;
    } 
    int j = i;
    switch (i) {
      case 3:
        b2 = this.fPartialMultiByteChar[--j];
      case 2:
        b1 = this.fPartialMultiByteChar[--j];
      case 1:
        paramByte = this.fPartialMultiByteChar[--j];
        break;
    } 
    switch (i) {
      case 1:
        if ((b1 & 0xC0) != 128)
          this.fErrorHandler.error2(57, this.fStringPool.addString(Integer.toHexString(paramByte)), this.fStringPool.addString(Integer.toHexString(b1))); 
      case 2:
        if ((paramByte & 0xE0) == 192) {
          byte b4 = ((0x1F & paramByte) << 6) + (0x3F & b1);
          paramArrayOfChar[paramInt3++] = (char)b4;
          if (paramInt3 == paramInt4) {
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt3;
            this.fPartialMultiByteResult = false;
            return false;
          } 
          if (i < 2 && ++paramInt1 == paramInt2) {
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt3;
            this.fPartialMultiByteResult = true;
            return false;
          } 
          break;
        } 
        if (i < 2) {
          if (++paramInt1 == paramInt2) {
            byte b4 = 2;
            this.fPartialMultiByteIn = b4;
            this.fPartialMultiByteChar[--b4] = b1;
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt3;
            this.fPartialMultiByteResult = true;
            return false;
          } 
          b2 = paramArrayOfByte[paramInt1];
        } 
        if ((b2 & 0xC0) != 128)
          this.fErrorHandler.error3(58, this.fStringPool.addString(Integer.toHexString(paramByte)), this.fStringPool.addString(Integer.toHexString(b1)), this.fStringPool.addString(Integer.toHexString(b2))); 
      case 3:
        if ((paramByte & 0xF0) == 224) {
          byte b4 = ((0xF & paramByte) << 12) + ((0x3F & b1) << 6) + (0x3F & b2);
          paramArrayOfChar[paramInt3++] = (char)b4;
          if (paramInt3 == paramInt4) {
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt3;
            this.fPartialMultiByteResult = false;
            return false;
          } 
          if (i < 3 && ++paramInt1 == paramInt2) {
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt3;
            this.fPartialMultiByteResult = true;
            return false;
          } 
          break;
        } 
        if (i < 3) {
          if ((paramByte & 0xF8) != 240)
            this.fErrorHandler.error1(56, this.fStringPool.addString(Integer.toHexString(paramByte))); 
          if (++paramInt1 == paramInt2) {
            savePartialMultiByte(3, b2, b1);
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt3;
            this.fPartialMultiByteResult = true;
            return false;
          } 
          b = paramArrayOfByte[paramInt1];
        } 
        if ((b & 0xC0) != 128)
          this.fErrorHandler.error4(59, this.fStringPool.addString(Integer.toHexString(paramByte)), this.fStringPool.addString(Integer.toHexString(b1)), this.fStringPool.addString(Integer.toHexString(b2)), this.fStringPool.addString(Integer.toHexString(b))); 
        b3 = ((0xF & paramByte) << 18) + ((0x3F & b1) << 12) + ((0x3F & b2) << 6) + (0x3F & b);
        if (b3 >= 65536) {
          paramArrayOfChar[paramInt3++] = (char)((b3 - 65536 >> 10) + 55296);
          b3 = (b3 - 65536 & 0x3FF) + 56320;
          if (paramInt3 == paramInt4) {
            this.fPartialSurrogatePair = b3;
            this.fOverflowOffset = paramInt1;
            this.fOutputOffset = paramInt3;
            this.fPartialMultiByteResult = false;
            return false;
          } 
        } 
        paramArrayOfChar[paramInt3++] = (char)b3;
        if (paramInt3 == paramInt4) {
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = false;
          return false;
        } 
        if (++paramInt1 == paramInt2) {
          this.fOverflowOffset = paramInt1;
          this.fOutputOffset = paramInt3;
          this.fPartialMultiByteResult = true;
          return false;
        } 
        break;
    } 
    this.fOverflowOffset = paramInt1;
    this.fOutputOffset = paramInt3;
    return true;
  }
  
  protected final class UTF8CharDataChunk implements StringProducer {
    private final UTF8CharReader this$0;
    
    protected StringPool fInnerStringPool;
    
    protected int fChunk;
    
    protected char[] fData;
    
    protected UTF8CharDataChunk fPreviousChunk;
    
    protected UTF8CharDataChunk fNextChunk;
    
    public UTF8CharDataChunk(UTF8CharReader this$0, StringPool param1StringPool, UTF8CharDataChunk param1UTF8CharDataChunk) throws Exception {
      this.this$0 = this$0;
      this.this$0 = this$0;
      this.fInnerStringPool = param1StringPool;
      this.fChunk = (param1UTF8CharDataChunk == null) ? 0 : (param1UTF8CharDataChunk.fChunk + 1);
      this.fPreviousChunk = param1UTF8CharDataChunk;
      if (param1UTF8CharDataChunk != null)
        param1UTF8CharDataChunk.fNextChunk = this; 
    }
    
    protected UTF8CharDataChunk(UTF8CharReader this$0, UTF8CharDataChunk param1UTF8CharDataChunk) {
      this.this$0 = this$0;
      this.this$0 = this$0;
      this.fInnerStringPool = param1UTF8CharDataChunk.fInnerStringPool;
      this.fChunk = param1UTF8CharDataChunk.fChunk;
      this.fData = param1UTF8CharDataChunk.fData;
      this.fPreviousChunk = null;
      this.fNextChunk = null;
    }
    
    public UTF8CharDataChunk chunkFor(int param1Int) {
      int i = param1Int >> 14;
      for (UTF8CharDataChunk uTF8CharDataChunk = this; i != uTF8CharDataChunk.fChunk; uTF8CharDataChunk = uTF8CharDataChunk.fPreviousChunk);
      return uTF8CharDataChunk;
    }
    
    public char[] toCharArray() { return this.fData; }
    
    public void setCharArray(char[] param1ArrayOfChar) { this.fData = param1ArrayOfChar; }
    
    public UTF8CharDataChunk nextChunk() { return this.fNextChunk; }
    
    public void clearPreviousChunk() {
      if (this.fPreviousChunk != null) {
        this.fPreviousChunk.fNextChunk = null;
        this.fPreviousChunk = null;
      } 
    }
    
    public String toString(int param1Int1, int param1Int2) {
      if (param1Int1 + param1Int2 <= 16384)
        return new String(this.fData, param1Int1, param1Int2); 
      StringBuffer stringBuffer = new StringBuffer(param1Int2);
      int i = 16384 - param1Int1;
      stringBuffer.append(this.fData, param1Int1, i);
      param1Int2 -= i;
      UTF8CharDataChunk uTF8CharDataChunk = this.fNextChunk;
      do {
        i = (param1Int2 <= 16384) ? param1Int2 : 16384;
        stringBuffer.append(uTF8CharDataChunk.fData, 0, i);
        param1Int2 -= i;
        uTF8CharDataChunk = uTF8CharDataChunk.fNextChunk;
      } while (param1Int2 > 0);
      String str = stringBuffer.toString();
      stringBuffer = null;
      return str;
    }
    
    public boolean equalsString(int param1Int1, int param1Int2, String param1String, int param1Int3) {
      if (param1Int2 != param1Int3)
        return false; 
      if (param1Int1 + param1Int2 <= 16384) {
        for (byte b1 = 0; b1 < param1Int2; b1++) {
          if (this.fData[param1Int1++] != param1String.charAt(b1))
            return false; 
        } 
        return true;
      } 
      int i = 16384 - param1Int1;
      byte b = 0;
      while (b < i) {
        if (this.fData[param1Int1++] != param1String.charAt(b++))
          return false; 
      } 
      param1Int2 -= i;
      UTF8CharDataChunk uTF8CharDataChunk = this.fNextChunk;
      do {
        param1Int1 = 0;
        i = (param1Int2 <= 16384) ? param1Int2 : 16384;
        param1Int2 -= i;
        while (i-- > 0) {
          if (uTF8CharDataChunk.fData[param1Int1++] != param1String.charAt(b++))
            return false; 
        } 
        uTF8CharDataChunk = uTF8CharDataChunk.fNextChunk;
      } while (param1Int2 > 0);
      return true;
    }
    
    protected UTF8CharDataChunk createClump(int param1Int) {
      UTF8CharDataChunk uTF8CharDataChunk1 = new UTF8CharDataChunk(this.this$0, this);
      UTF8CharDataChunk uTF8CharDataChunk2 = this.fNextChunk;
      UTF8CharDataChunk uTF8CharDataChunk3 = uTF8CharDataChunk1;
      do {
        UTF8CharDataChunk uTF8CharDataChunk = new UTF8CharDataChunk(this.this$0, uTF8CharDataChunk2);
        uTF8CharDataChunk3.fNextChunk = uTF8CharDataChunk;
        uTF8CharDataChunk2 = uTF8CharDataChunk2.fNextChunk;
        uTF8CharDataChunk3 = uTF8CharDataChunk;
      } while (uTF8CharDataChunk3.fChunk != param1Int);
      return uTF8CharDataChunk1;
    }
    
    public int addString(int param1Int1, int param1Int2) {
      int i = param1Int1 >> 14;
      if (i != this.fChunk) {
        if (this.fPreviousChunk != null)
          return this.fPreviousChunk.addString(param1Int1, param1Int2); 
        System.out.println("fPreviousChunk == null");
        return -1;
      } 
      int j = param1Int1 + param1Int2 - 1 >> 14;
      return (i == j) ? this.fInnerStringPool.addString(this, param1Int1 & 0x3FFF, param1Int2) : this.fInnerStringPool.addString(createClump(j), param1Int1 & 0x3FFF, param1Int2);
    }
    
    public int addSymbol(int param1Int1, int param1Int2, int param1Int3) {
      int i = param1Int1 >> 14;
      if (i != this.fChunk) {
        if (this.fPreviousChunk != null)
          return this.fPreviousChunk.addSymbol(param1Int1, param1Int2, param1Int3); 
        System.out.println("fPreviousChunk == null");
        return -1;
      } 
      int j = param1Int1 + param1Int2 - 1 >> 14;
      int k = param1Int1 & 0x3FFF;
      if (i == j) {
        if (param1Int3 == 0) {
          for (byte b = 0; b < param1Int2; b++)
            param1Int3 = StringHasher.hashChar(param1Int3, b, this.fData[k++] & 0xFFFF); 
          int m = param1Int3;
          m &= Integer.MAX_VALUE;
          param1Int3 = (m == 0) ? 1 : m;
        } 
        return this.fInnerStringPool.addSymbol(this, param1Int1 & 0x3FFF, param1Int2, param1Int3);
      } 
      if (param1Int3 == 0) {
        byte b = 0;
        int m = param1Int2;
        int n = 16384 - k;
        while (k < 16384)
          param1Int3 = StringHasher.hashChar(param1Int3, b++, this.fData[k++] & 0xFFFF); 
        m -= n;
        UTF8CharDataChunk uTF8CharDataChunk = this.fNextChunk;
        do {
          k = 0;
          n = (m <= 16384) ? m : 16384;
          while (k < n)
            param1Int3 = StringHasher.hashChar(param1Int3, b++, uTF8CharDataChunk.fData[k++] & 0xFFFF); 
          m -= n;
          uTF8CharDataChunk = uTF8CharDataChunk.fNextChunk;
        } while (m > 0);
        int i1 = param1Int3;
        i1 &= Integer.MAX_VALUE;
        param1Int3 = (i1 == 0) ? 1 : i1;
      } 
      return this.fInnerStringPool.addSymbol(createClump(j), param1Int1 & 0x3FFF, param1Int2, param1Int3);
    }
    
    public void append(ChunkyCharArray param1ChunkyCharArray, int param1Int1, int param1Int2) {
      UTF8CharDataChunk uTF8CharDataChunk = chunkFor(param1Int1);
      int i = param1Int1 & 0x3FFF;
      int j = (i + param1Int2 <= 16384) ? param1Int2 : (16384 - i);
      while (true) {
        param1ChunkyCharArray.append(uTF8CharDataChunk.fData, i, j);
        param1Int2 -= j;
        if (param1Int2 != 0) {
          uTF8CharDataChunk = uTF8CharDataChunk.fNextChunk;
          i = 0;
          j = (param1Int2 <= 16384) ? param1Int2 : 16384;
          continue;
        } 
        break;
      } 
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\UTF8CharReader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */