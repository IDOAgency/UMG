package com.ibm.xml.internal;

import com.ibm.xml.framework.ContentModel;
import com.ibm.xml.framework.InsertableElementsInfo;

class SimpleContentModel implements ContentModel {
  int fFirstChild;
  
  int fSecondChild;
  
  int fOp;
  
  public SimpleContentModel(int paramInt1, int paramInt2, int paramInt3) {
    this.fFirstChild = paramInt1;
    this.fSecondChild = paramInt2;
    this.fOp = paramInt3;
  }
  
  public int validateContent(int paramInt, int[] paramArrayOfInt) throws Exception {
    byte b;
    switch (this.fOp) {
      case 0:
        return (paramInt == 0) ? 0 : ((paramArrayOfInt[0] != this.fFirstChild) ? 0 : ((paramInt > 1) ? 1 : -1));
      case 1:
        return (paramInt == 1 && paramArrayOfInt[0] != this.fFirstChild) ? 0 : ((paramInt > 1) ? 1 : -1);
      case 2:
        if (paramInt > 0)
          for (byte b1 = 0; b1 < paramInt; b1++) {
            if (paramArrayOfInt[b1] != this.fFirstChild)
              return b1; 
          }  
        return -1;
      case 3:
        if (paramInt == 0)
          return 0; 
        for (b = 0; b < paramInt; b++) {
          if (paramArrayOfInt[b] != this.fFirstChild)
            return b; 
        } 
        return -1;
      case 4:
        return (paramInt == 0) ? 0 : ((paramArrayOfInt[0] != this.fFirstChild && paramArrayOfInt[0] != this.fSecondChild) ? 0 : ((paramInt > 1) ? 1 : -1));
      case 5:
        return (paramInt < 2) ? paramInt : ((paramArrayOfInt[0] != this.fFirstChild) ? 0 : ((paramArrayOfInt[1] != this.fSecondChild) ? 1 : -1));
    } 
    throw new CMException(152);
  }
  
  public int whatCanGoHere(boolean paramBoolean, InsertableElementsInfo paramInsertableElementsInfo) throws Exception {
    for (int i = paramInsertableElementsInfo.insertAt; i < paramInsertableElementsInfo.childCount; i++)
      paramInsertableElementsInfo.curChildren[i] = paramInsertableElementsInfo.curChildren[i + 1]; 
    paramInsertableElementsInfo.childCount--;
    int j = validateContent(paramInsertableElementsInfo.childCount, paramInsertableElementsInfo.curChildren);
    if (j != -1 && j < paramInsertableElementsInfo.insertAt)
      return j; 
    paramInsertableElementsInfo.canHoldPCData = false;
    if (this.fOp == 0 || this.fOp == 1 || this.fOp == 2 || this.fOp == 3) {
      paramInsertableElementsInfo.resultsCount = 1;
    } else if (this.fOp == 4 || this.fOp == 5) {
      paramInsertableElementsInfo.resultsCount = 2;
    } else {
      throw new CMException(152);
    } 
    if (paramInsertableElementsInfo.results == null || paramInsertableElementsInfo.results.length < paramInsertableElementsInfo.resultsCount)
      paramInsertableElementsInfo.results = new boolean[paramInsertableElementsInfo.resultsCount]; 
    if (paramInsertableElementsInfo.possibleChildren == null || paramInsertableElementsInfo.possibleChildren.length < paramInsertableElementsInfo.resultsCount)
      paramInsertableElementsInfo.possibleChildren = new int[paramInsertableElementsInfo.resultsCount]; 
    paramInsertableElementsInfo.possibleChildren[0] = this.fFirstChild;
    paramInsertableElementsInfo.results[0] = false;
    if (paramInsertableElementsInfo.resultsCount == 2) {
      paramInsertableElementsInfo.possibleChildren[1] = this.fSecondChild;
      paramInsertableElementsInfo.results[1] = false;
    } 
    paramInsertableElementsInfo.isValidEOC = false;
    switch (this.fOp) {
      case 0:
      case 1:
        if (paramInsertableElementsInfo.childCount == 0) {
          paramInsertableElementsInfo.results[0] = true;
        } else if (paramInsertableElementsInfo.childCount > 0 && !paramBoolean && paramInsertableElementsInfo.insertAt == 0) {
          paramInsertableElementsInfo.results[0] = true;
        } 
        if (this.fOp == 0) {
          if (paramInsertableElementsInfo.insertAt == 0)
            paramInsertableElementsInfo.isValidEOC = true; 
        } else {
          paramInsertableElementsInfo.isValidEOC = true;
        } 
        return -1;
      case 2:
      case 3:
        paramInsertableElementsInfo.results[0] = true;
        if (this.fOp == 2 || paramInsertableElementsInfo.insertAt > 0)
          paramInsertableElementsInfo.isValidEOC = true; 
        return -1;
      case 4:
        if (paramInsertableElementsInfo.insertAt == 0 && !paramBoolean && paramInsertableElementsInfo.childCount == 0) {
          paramInsertableElementsInfo.results[0] = true;
          paramInsertableElementsInfo.results[1] = true;
        } 
        if (paramInsertableElementsInfo.insertAt == 1)
          paramInsertableElementsInfo.isValidEOC = true; 
        return -1;
      case 5:
        if (paramInsertableElementsInfo.insertAt == 0) {
          if (paramBoolean) {
            if (paramInsertableElementsInfo.childCount == 1)
              paramInsertableElementsInfo.results[0] = !(paramInsertableElementsInfo.curChildren[0] != this.fSecondChild); 
          } else {
            paramInsertableElementsInfo.results[0] = true;
          } 
        } else if (paramInsertableElementsInfo.insertAt == 1 && (!paramBoolean || paramInsertableElementsInfo.childCount == 1)) {
          paramInsertableElementsInfo.results[1] = true;
        } 
        if (paramInsertableElementsInfo.insertAt == 2)
          paramInsertableElementsInfo.isValidEOC = true; 
        return -1;
    } 
    throw new CMException(152);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\SimpleContentModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */