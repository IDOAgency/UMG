package com.ibm.xml.internal;

import com.ibm.xml.framework.AttDef;
import com.ibm.xml.framework.Attr;
import com.ibm.xml.framework.AttrPool;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLErrorHandler;
import org.xml.sax.AttributeList;

public final class DefaultAttrPool implements AttrPool, AttributeList {
  static final int CHUNK_SHIFT = 5;
  
  static final int CHUNK_SIZE = 32;
  
  static final int CHUNK_MASK = 31;
  
  static final int INITIAL_CHUNK_COUNT = 32;
  
  static final int ATTRFLAG_SPECIFIED = 64;
  
  static final int ATTRFLAG_LASTATTR = 128;
  
  private StringPool fStringPool;
  
  private XMLErrorHandler fErrorHandler;
  
  private int fAttlistIndex = -1;
  
  private int fAttlistLength;
  
  private int fAttrCount;
  
  private int[][] fAttName = new int[32][];
  
  private int[][] fAttValue = new int[32][];
  
  private byte[][] fAttTypeAndFlags = new byte[32][];
  
  public DefaultAttrPool(ParserState paramParserState) {
    this.fStringPool = paramParserState.cacheStringPool();
    this.fErrorHandler = paramParserState.getErrorHandler();
  }
  
  public void reset(ParserState paramParserState) {
    this.fStringPool = paramParserState.cacheStringPool();
    this.fErrorHandler = paramParserState.getErrorHandler();
    this.fAttlistIndex = -1;
    this.fAttlistLength = 0;
    this.fAttrCount = 0;
  }
  
  public AttrPool resetOrCopy(ParserState paramParserState) { return new DefaultAttrPool(paramParserState); }
  
  private boolean ensureCapacity(int paramInt1, int paramInt2) {
    try {
      return !(this.fAttName[paramInt1][paramInt2] == 0);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      int[][] arrayOfInt = new int[paramInt1 * 2][];
      System.arraycopy(this.fAttName, 0, arrayOfInt, 0, paramInt1);
      this.fAttName = arrayOfInt;
      arrayOfInt = new int[paramInt1 * 2][];
      System.arraycopy(this.fAttValue, 0, arrayOfInt, 0, paramInt1);
      this.fAttValue = arrayOfInt;
      byte[][] arrayOfByte = new byte[paramInt1 * 2][];
      System.arraycopy(this.fAttTypeAndFlags, 0, arrayOfByte, 0, paramInt1);
      this.fAttTypeAndFlags = arrayOfByte;
    } catch (NullPointerException nullPointerException) {}
    this.fAttName[paramInt1] = new int[32];
    this.fAttValue[paramInt1] = new int[32];
    this.fAttTypeAndFlags[paramInt1] = new byte[32];
    return true;
  }
  
  public int addAttr(Attr paramAttr, int paramInt) throws Exception {
    int j;
    int i;
    if (paramInt != -1) {
      i = paramInt >> 5;
      j = paramInt & 0x1F;
      while (paramInt < this.fAttrCount) {
        if (this.fAttName[i][j] == paramAttr.attName) {
          this.fErrorHandler.error1(9, paramAttr.attName);
          return -1;
        } 
        paramInt++;
        if (++j == 32) {
          i++;
          j = 0;
        } 
      } 
    } else {
      i = this.fAttrCount >> 5;
      j = this.fAttrCount & 0x1F;
    } 
    ensureCapacity(i, j);
    this.fAttName[i][j] = paramAttr.attName;
    this.fAttValue[i][j] = paramAttr.attValue;
    this.fAttTypeAndFlags[i][j] = (byte)((paramAttr.specified ? 64 : 0) | paramAttr.attType);
    return this.fAttrCount++;
  }
  
  public void setIsLastAttr(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fAttrCount)
      return; 
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    this.fAttTypeAndFlags[i][j] = (byte)(this.fAttTypeAndFlags[i][j] | 0x80);
  }
  
  public int getAttrName(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fAttrCount)
      return -1; 
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fAttName[i][j];
  }
  
  public int getAttType(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fAttrCount)
      return -1; 
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fAttTypeAndFlags[i][j] & 0x3F;
  }
  
  public int getAttValue(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fAttrCount)
      return -1; 
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fAttValue[i][j];
  }
  
  public boolean isSpecified(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fAttrCount)
      return true; 
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return !((this.fAttTypeAndFlags[i][j] & 0x40) == 0);
  }
  
  public boolean isLastAttr(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fAttrCount)
      return true; 
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return !((this.fAttTypeAndFlags[i][j] & 0x80) == 0);
  }
  
  public void releaseAttrList(int paramInt) {
    boolean bool;
    if (paramInt == -1)
      return; 
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    do {
      bool = ((this.fAttTypeAndFlags[i][j] & 0x80) == 0) ? 0 : 1;
      this.fAttName[i][j] = -1;
      if ((this.fAttTypeAndFlags[i][j] & 0x40) != 0)
        this.fStringPool.releaseString(this.fAttValue[i][j]); 
      this.fAttValue[i][j] = -1;
      if (++j != 32)
        continue; 
      i++;
      j = 0;
    } while (!bool);
    if (this.fAttrCount == (i << 5) + j) {
      this.fAttrCount = paramInt;
      return;
    } 
    System.out.println("AttrPool: unable to reclaim Attlist");
  }
  
  public AttributeList getAttributeList(int paramInt) {
    this.fAttlistIndex = paramInt;
    if (this.fAttlistIndex == -1) {
      this.fAttlistLength = 0;
    } else {
      int i = this.fAttlistIndex >> 5;
      int j = this.fAttlistIndex & 0x1F;
      this.fAttlistLength = 1;
      while ((this.fAttTypeAndFlags[i][j] & 0x80) == 0) {
        if (++j == 32) {
          i++;
          j = 0;
        } 
        this.fAttlistLength++;
      } 
    } 
    return this;
  }
  
  public int getLength() { return this.fAttlistLength; }
  
  public String getName(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fAttlistLength)
      return null; 
    int i = this.fAttlistIndex + paramInt >> 5;
    int j = this.fAttlistIndex + paramInt & 0x1F;
    return this.fStringPool.toString(this.fAttName[i][j]);
  }
  
  public String getType(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fAttlistLength)
      return null; 
    int i = this.fAttlistIndex + paramInt >> 5;
    int j = this.fAttlistIndex + paramInt & 0x1F;
    byte b = this.fAttTypeAndFlags[i][j] & 0x3F;
    if (b == 9)
      b = 6; 
    return AttDef.getAttTypeString(b);
  }
  
  public String getValue(int paramInt) {
    if (paramInt < 0 || paramInt >= this.fAttlistLength)
      return null; 
    int i = this.fAttlistIndex + paramInt >> 5;
    int j = this.fAttlistIndex + paramInt & 0x1F;
    return this.fStringPool.toString(this.fAttValue[i][j]);
  }
  
  public String getType(String paramString) {
    int i = this.fStringPool.addSymbol(paramString.intern());
    if (i == -1)
      return null; 
    int j = this.fAttlistIndex >> 5;
    int k = this.fAttlistIndex & 0x1F;
    for (byte b = 0; b < this.fAttlistLength; b++) {
      if (this.fAttName[j][k] == i) {
        byte b1 = this.fAttTypeAndFlags[j][k] & 0x3F;
        if (b1 == 9)
          b1 = 6; 
        return AttDef.getAttTypeString(b1);
      } 
      if (++k == 32) {
        j++;
        k = 0;
      } 
    } 
    return null;
  }
  
  public String getValue(String paramString) {
    int i = this.fStringPool.addSymbol(paramString.intern());
    if (i == -1)
      return null; 
    int j = this.fAttlistIndex >> 5;
    int k = this.fAttlistIndex & 0x1F;
    for (byte b = 0; b < this.fAttlistLength; b++) {
      if (this.fAttName[j][k] == i)
        return this.fStringPool.toString(this.fAttValue[j][k]); 
      if (++k == 32) {
        j++;
        k = 0;
      } 
    } 
    return null;
  }
  
  public int getFirstAttr(int paramInt) { return (paramInt < 0 || paramInt >= this.fAttrCount) ? -1 : paramInt; }
  
  public int getNextAttr(int paramInt) { return isLastAttr(paramInt) ? -1 : (paramInt + 1); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\DefaultAttrPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */