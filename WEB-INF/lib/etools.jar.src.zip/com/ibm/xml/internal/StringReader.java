package com.ibm.xml.internal;

import com.ibm.xml.framework.ChunkyCharArray;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.ScanContentState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLDocumentHandler;
import com.ibm.xml.framework.XMLErrorHandler;
import com.ibm.xml.framework.XMLReader;
import java.io.IOException;
import org.xml.sax.Locator;

final class StringReader extends XMLReader {
  private StringPool fStringPool;
  
  private XMLDocumentHandler fDocumentHandler;
  
  private XMLErrorHandler fErrorHandler;
  
  private String fData;
  
  private int fEndOffset;
  
  private boolean oweLeadingSpace = false;
  
  private boolean oweTrailingSpace = false;
  
  StringReader(ParserState paramParserState, boolean paramBoolean, Locator paramLocator, int paramInt) {
    super(paramParserState, paramLocator.getPublicId(), paramLocator.getSystemId());
    this.fLinefeedCounter = paramLocator.getLineNumber();
    this.fCharacterCounter = paramLocator.getColumnNumber();
    this.fStringPool = paramParserState.cacheStringPool();
    this.fDocumentHandler = paramParserState.getDocumentHandler();
    this.fErrorHandler = paramParserState.getErrorHandler();
    this.fData = this.fStringPool.toString(paramInt);
    this.fCurrentOffset = 0;
    this.fEndOffset = this.fData.length();
    if (paramBoolean) {
      this.oweLeadingSpace = true;
      this.oweTrailingSpace = true;
    } 
  }
  
  public void append(ChunkyCharArray paramChunkyCharArray, int paramInt1, int paramInt2) { paramChunkyCharArray.append(this.fData.substring(paramInt1, paramInt1 + paramInt2)); }
  
  public int addString(int paramInt1, int paramInt2) { return (paramInt2 == 0) ? 0 : this.fStringPool.addString(this.fData.substring(paramInt1, paramInt1 + paramInt2)); }
  
  public int addSymbol(int paramInt1, int paramInt2) { return (paramInt2 == 0) ? 0 : this.fStringPool.addSymbol(this.fData.substring(paramInt1, paramInt1 + paramInt2)); }
  
  public int skipOneChar() throws IOException {
    if (this.oweLeadingSpace) {
      this.oweLeadingSpace = false;
      return this.fCurrentOffset;
    } 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace) {
        this.oweTrailingSpace = false;
        return this.fCurrentOffset;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    return ++this.fCurrentOffset;
  }
  
  public int skipAsciiChar() throws IOException {
    if (this.oweLeadingSpace) {
      this.oweLeadingSpace = false;
      return this.fCurrentOffset;
    } 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace) {
        this.oweTrailingSpace = false;
        return this.fCurrentOffset;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    return ++this.fCurrentOffset;
  }
  
  public int skipToChar(char paramChar) throws IOException {
    if (this.oweLeadingSpace) {
      if (paramChar == ' ')
        return this.fCurrentOffset; 
      this.oweLeadingSpace = false;
    } 
    while (true) {
      if (this.fCurrentOffset >= this.fEndOffset) {
        if (this.oweTrailingSpace) {
          if (paramChar == ' ')
            return this.fCurrentOffset; 
          this.oweTrailingSpace = false;
        } 
        throw new ArrayIndexOutOfBoundsException();
      } 
      if (paramChar == this.fData.charAt(this.fCurrentOffset))
        return this.fCurrentOffset; 
      this.fCurrentOffset++;
    } 
  }
  
  public int skipPastChar(char paramChar) throws IOException {
    if (this.oweLeadingSpace) {
      this.oweLeadingSpace = false;
      if (paramChar == ' ')
        return this.fCurrentOffset; 
    } 
    while (true) {
      if (this.fCurrentOffset >= this.fEndOffset) {
        if (this.oweTrailingSpace) {
          this.oweTrailingSpace = false;
          if (paramChar == ' ')
            return this.fCurrentOffset; 
        } 
        throw new ArrayIndexOutOfBoundsException();
      } 
      if (paramChar == this.fData.charAt(this.fCurrentOffset))
        return ++this.fCurrentOffset; 
      this.fCurrentOffset++;
    } 
  }
  
  public boolean skippedValidChar() throws IOException {
    if (this.oweLeadingSpace) {
      this.oweLeadingSpace = false;
      return true;
    } 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace) {
        this.oweTrailingSpace = false;
        return true;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    char c = this.fData.charAt(this.fCurrentOffset++);
    if (c < ' ') {
      if (c == '\t' || c == '\n' || c == '\r')
        return true; 
      this.fCurrentOffset--;
      return false;
    } 
    if (c <= '퟿' || (c >= '' && (c <= '�' || (c >= 65536 && c <= 1114111))))
      return true; 
    this.fCurrentOffset--;
    return false;
  }
  
  public boolean lookingAtValidChar() throws IOException {
    if (this.oweLeadingSpace) {
      this.oweLeadingSpace = false;
      return true;
    } 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace) {
        this.oweTrailingSpace = false;
        return true;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    char c = this.fData.charAt(this.fCurrentOffset);
    return (c < ' ') ? (!(c != '\t' && c != '\n' && c != '\r')) : (!(c > '퟿' && (c < '' || (c > '�' && (c < 65536 || c > 1114111)))));
  }
  
  public int skipInvalidChar(int paramInt) throws Exception {
    String str2;
    String str1;
    char c;
    if (this.oweLeadingSpace) {
      this.oweLeadingSpace = false;
      c = ' ';
    } else if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace) {
        this.oweTrailingSpace = false;
        c = ' ';
      } else {
        throw new ArrayIndexOutOfBoundsException();
      } 
    } else {
      c = this.fData.charAt(this.fCurrentOffset++);
    } 
    switch (paramInt) {
      case 63:
      case 85:
        str1 = Integer.toHexString(c);
        this.fErrorHandler.error1(paramInt, this.fStringPool.addString(str1));
        break;
      case 80:
      case 82:
      case 110:
        str1 = (new Character((char)c)).toString();
        this.fErrorHandler.error1(paramInt, this.fStringPool.addString(str1));
        break;
      case 43:
        str1 = (new Character((char)c)).toString();
        str2 = Integer.toHexString(c);
        this.fErrorHandler.error2(paramInt, this.fStringPool.addString(str1), this.fStringPool.addString(str2));
        break;
    } 
    return this.fCurrentOffset;
  }
  
  public boolean skippedChar(char paramChar) throws IOException {
    if (this.oweLeadingSpace) {
      if (paramChar == ' ') {
        this.oweLeadingSpace = false;
        return true;
      } 
      return false;
    } 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace) {
        if (paramChar == ' ') {
          this.oweTrailingSpace = false;
          return true;
        } 
        return false;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    if (paramChar == this.fData.charAt(this.fCurrentOffset)) {
      this.fCurrentOffset++;
      return true;
    } 
    return false;
  }
  
  public boolean lookingAtChar(char paramChar) throws IOException {
    if (this.oweLeadingSpace)
      return !(paramChar != ' '); 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace)
        return !(paramChar != ' '); 
      throw new ArrayIndexOutOfBoundsException();
    } 
    return !(paramChar != this.fData.charAt(this.fCurrentOffset));
  }
  
  public boolean skippedSpace() throws IOException {
    if (this.oweLeadingSpace) {
      this.oweLeadingSpace = false;
      return true;
    } 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace) {
        this.oweTrailingSpace = false;
        return true;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    char c = this.fData.charAt(this.fCurrentOffset);
    if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
      this.fCurrentOffset++;
      return true;
    } 
    return false;
  }
  
  public boolean lookingAtSpace() throws IOException {
    if (this.oweLeadingSpace)
      return true; 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace)
        return true; 
      throw new ArrayIndexOutOfBoundsException();
    } 
    char c = this.fData.charAt(this.fCurrentOffset);
    return !(c != ' ' && c != '\t' && c != '\n' && c != '\r');
  }
  
  public int skipPastSpaces() throws IOException {
    if (this.oweLeadingSpace)
      this.oweLeadingSpace = false; 
    while (true) {
      if (this.fCurrentOffset >= this.fEndOffset) {
        if (this.oweTrailingSpace) {
          this.oweTrailingSpace = false;
          return this.fCurrentOffset;
        } 
        throw new ArrayIndexOutOfBoundsException();
      } 
      char c = this.fData.charAt(this.fCurrentOffset);
      if (c != ' ' && c != '\t' && c != '\n' && c != '\r')
        return this.fCurrentOffset; 
      this.fCurrentOffset++;
    } 
  }
  
  public int skipDecimalDigit() throws IOException {
    if (this.oweLeadingSpace)
      return -1; 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace)
        return -1; 
      throw new ArrayIndexOutOfBoundsException();
    } 
    char c = this.fData.charAt(this.fCurrentOffset);
    if (c < '0' || c > '9')
      return -1; 
    this.fCurrentOffset++;
    return c - '0';
  }
  
  public int skipHexDigit() throws IOException {
    if (this.oweLeadingSpace)
      return -1; 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace)
        return -1; 
      throw new ArrayIndexOutOfBoundsException();
    } 
    char c = this.fData.charAt(this.fCurrentOffset);
    if (c > 'f' || XMLReader.fgAsciiXDigitChar[c] == 0)
      return -1; 
    this.fCurrentOffset++;
    return c - ((c < 'A') ? '0' : (((c < 'a') ? 65 : 97) - 10));
  }
  
  public boolean skippedAlpha() throws IOException {
    if (this.oweLeadingSpace)
      return false; 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace)
        return false; 
      throw new ArrayIndexOutOfBoundsException();
    } 
    char c = this.fData.charAt(this.fCurrentOffset);
    if (c <= 'z' && XMLReader.fgAsciiAlphaChar[c] == 1) {
      this.fCurrentOffset++;
      return true;
    } 
    return false;
  }
  
  private boolean skippedCharWithFlag(byte paramByte) {
    if (this.oweLeadingSpace) {
      if ((XMLReader.fgCharFlags[32] & paramByte) != 0) {
        this.oweLeadingSpace = false;
        return true;
      } 
      return false;
    } 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace) {
        if ((XMLReader.fgCharFlags[32] & paramByte) != 0) {
          this.oweTrailingSpace = false;
          return true;
        } 
        return false;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    char c = this.fData.charAt(this.fCurrentOffset);
    if (c < '' && (XMLReader.fgCharFlags[c] & paramByte) != 0) {
      this.fCurrentOffset++;
      return true;
    } 
    return false;
  }
  
  public final boolean skippedVersionNum() throws IOException { return skippedCharWithFlag((byte)1); }
  
  public final boolean skippedEncName() throws IOException { return skippedCharWithFlag((byte)2); }
  
  public final boolean skippedPubidChar() throws IOException {
    if (this.oweLeadingSpace) {
      this.oweLeadingSpace = false;
      return true;
    } 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace) {
        this.oweTrailingSpace = false;
        return true;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    char c = this.fData.charAt(this.fCurrentOffset);
    if (c < '') {
      if ((XMLReader.fgCharFlags[c] & 0x4) != 0) {
        this.fCurrentOffset++;
        return true;
      } 
      if (c == '\n') {
        this.fCurrentOffset++;
        this.fLinefeedCounter++;
        return true;
      } 
      if (c == '\r') {
        this.fCurrentOffset++;
        this.fCarriageReturnCounter++;
        return true;
      } 
    } 
    return false;
  }
  
  public boolean skippedString(char[] paramArrayOfChar) throws IOException {
    if (this.oweLeadingSpace)
      return false; 
    int i = this.fCurrentOffset;
    for (byte b = 0; b < paramArrayOfChar.length; b++) {
      if (this.fCurrentOffset >= this.fEndOffset) {
        if (this.oweTrailingSpace)
          return false; 
        throw new ArrayIndexOutOfBoundsException();
      } 
      if (this.fData.charAt(i) != paramArrayOfChar[b])
        return false; 
      i++;
    } 
    this.fCurrentOffset = i;
    return true;
  }
  
  public int skipPastName(char paramChar) throws IOException {
    if (this.oweLeadingSpace)
      return this.fCurrentOffset; 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace)
        return this.fCurrentOffset; 
      throw new ArrayIndexOutOfBoundsException();
    } 
    char c = this.fData.charAt(this.fCurrentOffset);
    if ((XMLReader.fgCharFlags[c] & 0x10) == 0)
      return this.fCurrentOffset; 
    do {
      this.fCurrentOffset++;
      if (this.fCurrentOffset >= this.fEndOffset) {
        if (this.oweTrailingSpace)
          return this.fCurrentOffset; 
        throw new ArrayIndexOutOfBoundsException();
      } 
      c = this.fData.charAt(this.fCurrentOffset);
      if (paramChar == c)
        return this.fCurrentOffset; 
    } while ((XMLReader.fgCharFlags[c] & 0x20) != 0);
    return this.fCurrentOffset;
  }
  
  public int scanName(char paramChar, int paramInt) throws IOException {
    int i = this.fCurrentOffset;
    int j = skipPastName(paramChar) - i;
    if (j == 0)
      return -1; 
    int k = this.fStringPool.addSymbol(this.fData.substring(i, i + j));
    return (paramInt == -1 || paramInt == k) ? k : -1;
  }
  
  public int skipPastNmtoken(char paramChar) throws IOException {
    if (this.oweLeadingSpace)
      return this.fCurrentOffset; 
    if (this.fCurrentOffset >= this.fEndOffset) {
      if (this.oweTrailingSpace)
        return this.fCurrentOffset; 
      throw new ArrayIndexOutOfBoundsException();
    } 
    for (char c = this.fData.charAt(this.fCurrentOffset);; c = this.fData.charAt(this.fCurrentOffset)) {
      if (paramChar == c)
        return this.fCurrentOffset; 
      if ((XMLReader.fgCharFlags[c] & 0x20) == 0)
        return this.fCurrentOffset; 
      this.fCurrentOffset++;
      if (this.fCurrentOffset >= this.fEndOffset) {
        if (this.oweTrailingSpace)
          return this.fCurrentOffset; 
        throw new ArrayIndexOutOfBoundsException();
      } 
    } 
  }
  
  private void callCharDataHandler(int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {
    int i = paramInt2 - paramInt1;
    if (!this.fDocumentHandler.sendCharDataAsCharArray()) {
      byte b = (i == 0) ? 0 : this.fStringPool.addString(this.fData.substring(paramInt1, paramInt1 + i));
      this.fDocumentHandler.characters(b, paramBoolean);
      return;
    } 
    this.fDocumentHandler.characters(this.fData.toCharArray(), paramInt1, i, paramBoolean);
  }
  
  private void callWSCharDataHandler(int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {
    int i = this.fParserState.getScanner().getCurrentContentSpecType();
    if (i != 4) {
      callCharDataHandler(paramInt1, paramInt2, paramBoolean);
      return;
    } 
    int j = paramInt2 - paramInt1;
    if (!this.fDocumentHandler.sendCharDataAsCharArray()) {
      byte b = (j == 0) ? 0 : this.fStringPool.addString(this.fData.substring(paramInt1, paramInt1 + j));
      this.fDocumentHandler.ignorableWhitespace(b, paramBoolean);
      return;
    } 
    this.fDocumentHandler.ignorableWhitespace(this.fData.toCharArray(), paramInt1, j, paramBoolean);
  }
  
  public int scanContent(ScanContentState paramScanContentState) throws Exception {
    int i = this.fCurrentOffset;
    if (this.fCurrentOffset >= this.fEndOffset)
      throw new ArrayIndexOutOfBoundsException(); 
    char c = this.fData.charAt(this.fCurrentOffset++);
    if (c < '') {
      byte b = XMLReader.fgCharFlags[c];
      if ((b & 0x8) == 0 && c != '\n' && c != '\r') {
        if (c == '<') {
          if (!paramScanContentState.inCDSect)
            return 1; 
        } else if (c == '&') {
          if (!paramScanContentState.inCDSect)
            return 2; 
        } else if (c == ']') {
          if (this.fCurrentOffset + 2 <= this.fEndOffset && this.fData.charAt(this.fCurrentOffset) == ']' && this.fData.charAt(this.fCurrentOffset + 1) == '>') {
            this.fCurrentOffset += 2;
            if (!paramScanContentState.inCDSect)
              return 3; 
            paramScanContentState.inCDSect = false;
            return scanContent(paramScanContentState);
          } 
        } else {
          this.fCurrentOffset--;
          return 4;
        } 
      } else if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
        do {
          if (this.fCurrentOffset >= this.fEndOffset) {
            if (this.fDocumentHandler != null)
              callWSCharDataHandler(i, this.fEndOffset, paramScanContentState.inCDSect); 
            throw new ArrayIndexOutOfBoundsException();
          } 
          if (c == '\n') {
            this.fLinefeedCounter++;
          } else if (c == '\r') {
            this.fCarriageReturnCounter++;
          } 
          c = this.fData.charAt(this.fCurrentOffset++);
        } while (c == ' ' || c == '\t' || c == '\n' || c == '\r');
        if (c < '') {
          b = XMLReader.fgCharFlags[c];
          if ((b & 0x8) == 0)
            if (c == '<') {
              if (!paramScanContentState.inCDSect) {
                if (this.fDocumentHandler != null)
                  callWSCharDataHandler(i, this.fCurrentOffset - 1, paramScanContentState.inCDSect); 
                return 25;
              } 
            } else if (c == '&') {
              if (!paramScanContentState.inCDSect) {
                if (this.fDocumentHandler != null)
                  callWSCharDataHandler(i, this.fCurrentOffset - 1, paramScanContentState.inCDSect); 
                return 26;
              } 
            } else if (c == ']') {
              if (this.fCurrentOffset + 2 <= this.fEndOffset && this.fData.charAt(this.fCurrentOffset) == ']' && this.fData.charAt(this.fCurrentOffset + 1) == '>') {
                if (this.fDocumentHandler != null)
                  callWSCharDataHandler(i, this.fCurrentOffset - 1, paramScanContentState.inCDSect); 
                this.fCurrentOffset += 2;
                if (!paramScanContentState.inCDSect)
                  return 27; 
                paramScanContentState.inCDSect = false;
                return scanContent(paramScanContentState);
              } 
            } else {
              this.fCurrentOffset--;
              if (this.fDocumentHandler != null)
                callWSCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
              return 28;
            }  
        } else if (c == '￾' || c == Character.MAX_VALUE) {
          this.fCurrentOffset--;
          if (this.fDocumentHandler != null)
            callWSCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
          return 28;
        } 
      } 
    } else if (c == '￾' || c == Character.MAX_VALUE) {
      this.fCurrentOffset--;
      if (this.fDocumentHandler != null)
        callCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
      return 4;
    } 
    while (true) {
      if (this.fCurrentOffset >= this.fEndOffset) {
        if (this.fDocumentHandler != null)
          callCharDataHandler(i, this.fEndOffset, paramScanContentState.inCDSect); 
        throw new ArrayIndexOutOfBoundsException();
      } 
      c = this.fData.charAt(this.fCurrentOffset++);
      if (c < '') {
        byte b = XMLReader.fgCharFlags[c];
        if ((b & 0x8) == 0) {
          if (c == '\n') {
            this.fLinefeedCounter++;
            continue;
          } 
          if (c == '\r') {
            this.fCarriageReturnCounter++;
            continue;
          } 
          break;
        } 
        continue;
      } 
      break;
    } 
    while (true) {
      if (c < '') {
        byte b = XMLReader.fgCharFlags[c];
        if ((b & 0x8) == 0)
          if (c == '<') {
            if (!paramScanContentState.inCDSect) {
              if (this.fDocumentHandler != null)
                callCharDataHandler(i, this.fCurrentOffset - 1, paramScanContentState.inCDSect); 
              return 9;
            } 
          } else if (c == '&') {
            if (!paramScanContentState.inCDSect) {
              if (this.fDocumentHandler != null)
                callCharDataHandler(i, this.fCurrentOffset - 1, paramScanContentState.inCDSect); 
              return 10;
            } 
          } else if (c == '\n') {
            this.fLinefeedCounter++;
          } else if (c == '\r') {
            this.fCarriageReturnCounter++;
          } else if (c == ']') {
            if (this.fCurrentOffset + 2 <= this.fEndOffset && this.fData.charAt(this.fCurrentOffset) == ']' && this.fData.charAt(this.fCurrentOffset + 1) == '>') {
              if (this.fDocumentHandler != null)
                callCharDataHandler(i, this.fCurrentOffset - 1, paramScanContentState.inCDSect); 
              this.fCurrentOffset += 2;
              if (!paramScanContentState.inCDSect)
                return 11; 
              paramScanContentState.inCDSect = false;
              return scanContent(paramScanContentState);
            } 
          } else {
            this.fCurrentOffset--;
            if (this.fDocumentHandler != null)
              callCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
            return 12;
          }  
      } else if (c == '￾' || c == Character.MAX_VALUE) {
        this.fCurrentOffset--;
        if (this.fDocumentHandler != null)
          callCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
        return 12;
      } 
      if (this.fCurrentOffset >= this.fEndOffset) {
        if (this.fDocumentHandler != null)
          callCharDataHandler(i, this.fCurrentOffset, paramScanContentState.inCDSect); 
        throw new ArrayIndexOutOfBoundsException();
      } 
      c = this.fData.charAt(this.fCurrentOffset++);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\StringReader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */