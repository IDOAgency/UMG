package com.ibm.xml.internal;

import com.ibm.xml.framework.AttDef;
import com.ibm.xml.framework.Attr;
import com.ibm.xml.framework.AttrPool;
import com.ibm.xml.framework.ChunkyCharArray;
import com.ibm.xml.framework.ContentSpecNode;
import com.ibm.xml.framework.ElementDecl;
import com.ibm.xml.framework.ElementDeclPool;
import com.ibm.xml.framework.EntityDecl;
import com.ibm.xml.framework.EntityPool;
import com.ibm.xml.framework.NotationDecl;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.ScanContentState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLDocumentHandler;
import com.ibm.xml.framework.XMLDocumentTypeHandler;
import com.ibm.xml.framework.XMLEntityHandler;
import com.ibm.xml.framework.XMLErrorHandler;
import com.ibm.xml.framework.XMLReader;
import com.ibm.xml.framework.XMLScanner;
import com.ibm.xml.framework.XMLValidationHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;

public final class DefaultScanner implements XMLScanner, Locator {
  private static final boolean DEBUG_STOP = false;
  
  private static final boolean DEBUG_NMTOKEN_ENTITY = false;
  
  private static final int ST_NORMAL = 1;
  
  private static final int ST_INTERNAL_SUBSET = 2;
  
  private static final int ST_EXTERNAL_SUBSET = 3;
  
  private static final byte GENERAL_ENTITY_TYPE = 0;
  
  private static final byte PARAMETER_ENTITY_TYPE = 1;
  
  private static final char[] cdata_string = { 'C', 'D', 'A', 'T', 'A' };
  
  private static final char[] xml_string = { 'x', 'm', 'l' };
  
  private static final char[] version_string = { 'v', 'e', 'r', 's', 'i', 'o', 'n' };
  
  private static final char[] doctype_string = { 'D', 'O', 'C', 'T', 'Y', 'P', 'E' };
  
  private static final char[] standalone_string = { 's', 't', 'a', 'n', 'd', 'a', 'l', 'o', 'n', 'e' };
  
  private static final char[] yes_string = { 'y', 'e', 's' };
  
  private static final char[] no_string = { 'n', 'o' };
  
  private static final char[] element_string = { 'E', 'L', 'E', 'M', 'E', 'N', 'T' };
  
  private static final char[] empty_string = { 'E', 'M', 'P', 'T', 'Y' };
  
  private static final char[] any_string = { 'A', 'N', 'Y' };
  
  private static final char[] pcdata_string = { '#', 'P', 'C', 'D', 'A', 'T', 'A' };
  
  private static final char[] attlist_string = { 'A', 'T', 'T', 'L', 'I', 'S', 'T' };
  
  private static final char[] id_string = { 'I', 'D' };
  
  private static final char[] ref_string = { 'R', 'E', 'F' };
  
  private static final char[] entit_string = { 'E', 'N', 'T', 'I', 'T' };
  
  private static final char[] ies_string = { 'I', 'E', 'S' };
  
  private static final char[] nmtoken_string = { 'N', 'M', 'T', 'O', 'K', 'E', 'N' };
  
  private static final char[] notation_string = { 'N', 'O', 'T', 'A', 'T', 'I', 'O', 'N' };
  
  private static final char[] required_string = { '#', 'R', 'E', 'Q', 'U', 'I', 'R', 'E', 'D' };
  
  private static final char[] implied_string = { '#', 'I', 'M', 'P', 'L', 'I', 'E', 'D' };
  
  private static final char[] fixed_string = { '#', 'F', 'I', 'X', 'E', 'D' };
  
  private static final char[] include_string = { 'I', 'N', 'C', 'L', 'U', 'D', 'E' };
  
  private static final char[] ignore_string = { 'I', 'G', 'N', 'O', 'R', 'E' };
  
  private static final char[] entity_string = { 'E', 'N', 'T', 'I', 'T', 'Y' };
  
  private static final char[] system_string = { 'S', 'Y', 'S', 'T', 'E', 'M' };
  
  private static final char[] public_string = { 'P', 'U', 'B', 'L', 'I', 'C' };
  
  private static final char[] ndata_string = { 'N', 'D', 'A', 'T', 'A' };
  
  private static final char[] encoding_string = { 'e', 'n', 'c', 'o', 'd', 'i', 'n', 'g' };
  
  private static final boolean PRINT_EXCEPTION_STACK_TRACE = false;
  
  private ParserState fParserState;
  
  private int fScannerState = 1;
  
  private int fScannerMarkupDepth;
  
  private int fScannerParenDepth;
  
  private XMLReader fReader;
  
  private boolean fStandalone = false;
  
  private boolean fCalledStartDocument = false;
  
  private XMLDocumentHandler fDocumentHandler;
  
  private XMLDocumentTypeHandler fDocumentTypeHandler;
  
  private XMLValidationHandler fValidationHandler;
  
  private XMLEntityHandler fEntityHandler;
  
  private XMLErrorHandler fErrorHandler;
  
  private StringPool fStringPool;
  
  private AttrPool fAttrPool;
  
  private EntityPool fEntityPool;
  
  private ElementDeclPool fElementDeclPool;
  
  private ChunkyCharArray fLiteralData;
  
  private EntityPool fParameterEntityPool;
  
  private int fXMLSymbolIndex = -1;
  
  private Attr fAttr = new Attr();
  
  private int fAttValueIndex = -1;
  
  private char[] fCharRefData;
  
  private int fSystemLiteral = -1;
  
  private int fPubidLiteral = -1;
  
  private ElementDecl fElementDecl;
  
  private ContentSpecNode fContentSpecNode;
  
  private AttDef fAttDef;
  
  private NotationDecl fNotationDecl;
  
  private EntityDecl fEntityDecl;
  
  private XMLReader[] fReaderStack = new XMLReader[8];
  
  private InputSource[] fReaderSource = new InputSource[8];
  
  private int[] fReaderMarkupDepth = new int[8];
  
  private int[] fReaderParenDepth = new int[8];
  
  private int fReaderStackDepth;
  
  private int fActiveReaderLimit;
  
  private int[] fElementNameStack = new int[8];
  
  private int[] fElementChildCount = new int[8];
  
  private int[][] fElementChildren = new int[8][];
  
  private int fElementDepth = -1;
  
  private byte[] fEntityTypeStack;
  
  private int[] fEntityNameStack;
  
  private int fEntityStackDepth;
  
  private byte[] opStack;
  
  private int[] nodeIndexStack;
  
  private int[] prevNodeIndexStack;
  
  private boolean fStop = false;
  
  private static final boolean DEBUG_PAREN_DEPTH = false;
  
  private static final boolean DEBUG_MARKUP_DEPTH = false;
  
  public DefaultScanner(ParserState paramParserState) { this.fParserState = paramParserState; }
  
  public void reset(ParserState paramParserState) {
    this.fParserState = paramParserState;
    this.fStop = false;
    this.fCalledStartDocument = false;
  }
  
  public Locator getLocator() { return this; }
  
  public String getPublicId() { return (this.fReader == null) ? null : this.fReader.getSystemId(); }
  
  public String getSystemId() { return (this.fReader == null) ? null : this.fReader.getSystemId(); }
  
  public int getLineNumber() { return (this.fReader == null) ? -1 : this.fReader.getLineNumber(); }
  
  public int getColumnNumber() { return (this.fReader == null) ? -1 : this.fReader.getColumnNumber(); }
  
  private void emitError(int paramInt) throws Exception { this.fErrorHandler.error(paramInt); }
  
  private void emitError(int paramInt1, int paramInt2) throws Exception { this.fErrorHandler.error1(paramInt1, paramInt2); }
  
  private void emitError(int paramInt1, int paramInt2, int paramInt3) throws Exception { this.fErrorHandler.error2(paramInt1, paramInt2, paramInt3); }
  
  public void stop() { this.fStop = true; }
  
  public void scanDocument(InputSource paramInputSource) throws Exception {
    this.fDocumentHandler = this.fParserState.getDocumentHandler();
    this.fDocumentTypeHandler = this.fParserState.getDocumentTypeHandler();
    this.fEntityHandler = this.fParserState.getEntityHandler();
    this.fErrorHandler = this.fParserState.getErrorHandler();
    this.fValidationHandler = this.fParserState.getValidationHandler();
    this.fStringPool = this.fParserState.getStringPool();
    this.fAttrPool = this.fParserState.getAttrPool();
    this.fEntityPool = this.fParserState.getEntityPool();
    this.fElementDeclPool = this.fParserState.getElementDeclPool();
    this.fScannerState = 1;
    this.fLiteralData = new ChunkyCharArray(this.fStringPool);
    this.fParameterEntityPool = null;
    this.fXMLSymbolIndex = -1;
    this.fReader = this.fEntityHandler.createReader(paramInputSource, true);
    this.fEntityHandler.startInputSource(paramInputSource);
    try {
      scanProlog();
      if (this.fDocumentHandler != null && !this.fCalledStartDocument) {
        this.fDocumentHandler.startDocument(-1, -1, -1);
        this.fCalledStartDocument = true;
      } 
      this.fEntityPool.checkUnparsedEntities();
      int i = this.fReader.scanName('>', -1);
      if (i == -1) {
        this.fErrorHandler.error(122);
      } else {
        if (this.fValidationHandler != null)
          this.fValidationHandler.checkRootElementName(i); 
        if (scanElement(i)) {
          if (this.fElementDepth >= 0) {
            ScanContentState scanContentState = new ScanContentState();
            scanContentState.inCDSect = false;
            scanContentState.extParsedEnt = false;
            scanContentState.parseTextDecl = false;
            scanContentState.elementDepth = 0;
            scanContent(scanContentState);
            if (this.fValidationHandler != null)
              this.fValidationHandler.checkIDRefNames(); 
          } 
          scanMisc();
        } 
      } 
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      if (this.fElementDepth >= 0) {
        int i = this.fElementNameStack[this.fElementDepth];
        this.fErrorHandler.error1(124, i);
      } 
      if (this.fScannerMarkupDepth > 0)
        this.fErrorHandler.error(116); 
    } catch (StopException stopException) {
    
    } catch (Exception exception) {
      throw exception;
    } 
    if (this.fStop) {
      while (this.fReaderStackDepth > 0) {
        this.fReaderStack[--this.fReaderStackDepth] = null;
        this.fReaderSource[this.fReaderStackDepth] = null;
      } 
      return;
    } 
    if (this.fDocumentHandler != null)
      this.fDocumentHandler.endDocument(); 
    this.fEntityHandler.endInputSource(paramInputSource);
  }
  
  public void scanDTD(InputSource paramInputSource) throws Exception {
    this.fDocumentHandler = this.fParserState.getDocumentHandler();
    this.fDocumentTypeHandler = this.fParserState.getDocumentTypeHandler();
    this.fEntityHandler = this.fParserState.getEntityHandler();
    this.fErrorHandler = this.fParserState.getErrorHandler();
    this.fValidationHandler = this.fParserState.getValidationHandler();
    this.fStringPool = this.fParserState.getStringPool();
    this.fAttrPool = this.fParserState.getAttrPool();
    this.fEntityPool = this.fParserState.getEntityPool();
    this.fElementDeclPool = this.fParserState.getElementDeclPool();
    this.fScannerState = 1;
    this.fLiteralData = new ChunkyCharArray(this.fStringPool);
    this.fParameterEntityPool = null;
    this.fXMLSymbolIndex = -1;
    this.fScannerState = 2;
    this.fReader = this.fEntityHandler.createReader(paramInputSource, false);
    this.fEntityHandler.startInputSource(paramInputSource);
    if (this.fDocumentHandler != null && !this.fCalledStartDocument) {
      this.fDocumentHandler.startDocument(-1, -1, -1);
      this.fCalledStartDocument = true;
    } 
    int i = this.fStringPool.addSymbol("");
    this.fElementDeclPool.setRootElement(i);
    if (this.fDocumentTypeHandler != null)
      this.fDocumentTypeHandler.doctypeDecl(i); 
    if (this.fDocumentTypeHandler != null)
      this.fDocumentTypeHandler.startInternalSubset(); 
    try {
      scanExtSubsetDecl(false);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      if (this.fScannerMarkupDepth > 0)
        this.fErrorHandler.error(116); 
    } catch (StopException stopException) {
    
    } catch (Exception exception) {
      throw exception;
    } 
    if (this.fDocumentTypeHandler != null)
      this.fDocumentTypeHandler.endInternalSubset(); 
    if (this.fParserState.getValidationHandler() != null)
      this.fElementDeclPool.checkDeclaredElements(); 
    this.fEntityPool.checkUnparsedEntities();
    if (this.fStop) {
      while (this.fReaderStackDepth > 0) {
        this.fReaderStack[--this.fReaderStackDepth] = null;
        this.fReaderSource[this.fReaderStackDepth] = null;
      } 
      return;
    } 
    if (this.fDocumentHandler != null)
      this.fDocumentHandler.endDocument(); 
    this.fEntityHandler.endInputSource(paramInputSource);
  }
  
  private boolean scanEq() throws Exception {
    this.fReader.skipPastSpaces();
    if (this.fReader.skippedChar('=')) {
      this.fReader.skipPastSpaces();
      return true;
    } 
    return false;
  }
  
  private boolean scanComment(boolean paramBoolean) throws Exception {
    int i = this.fReader.currentOffset();
    boolean bool = false;
    while (true) {
      boolean bool1 = false;
      try {
        bool1 = this.fReader.lookingAtChar('-');
      } catch (ArrayIndexOutOfBoundsException null) {
        if (!((this.fEntityStackDepth == 0) ? 0 : this.fEntityNameStack[this.fEntityStackDepth - 1]))
          this.fErrorHandler.error(21); 
        throw arrayIndexOutOfBoundsException;
      } 
      if (bool1) {
        int j = this.fReader.currentOffset();
        int k = 0;
        int m = this.fReader.skipAsciiChar();
        byte b = 1;
        while (this.fReader.skippedChar('-')) {
          b++;
          k = j;
          j = m;
          m = this.fReader.currentOffset();
        } 
        if (b > 1) {
          if (this.fReader.skippedChar('>')) {
            if (!bool && b > 2) {
              this.fErrorHandler.error(21);
              bool = true;
            } 
            this.fScannerMarkupDepth--;
            if (paramBoolean && this.fDocumentHandler != null)
              this.fDocumentHandler.comment(this.fReader.addString(i, k - i)); 
            return !bool;
          } 
          if (!bool) {
            this.fErrorHandler.error(22);
            bool = true;
          } 
        } 
        continue;
      } 
      try {
        if (!this.fReader.skippedValidChar())
          this.fReader.skipInvalidChar(85); 
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        break;
      } 
    } 
    if (!((this.fEntityStackDepth == 0) ? 0 : this.fEntityNameStack[this.fEntityStackDepth - 1]))
      this.fErrorHandler.error(21); 
    throw arrayIndexOutOfBoundsException;
  }
  
  private void scanProlog() {
    for (boolean bool = true;; bool = false) {
      if (this.fReader.skippedChar('<')) {
        this.fScannerMarkupDepth++;
        if (this.fReader.skippedChar('?')) {
          int i = this.fReader.scanName(' ', -1);
          if (i == -1) {
            this.fErrorHandler.error(102);
            this.fReader.skipPastChar('>');
            this.fScannerMarkupDepth--;
          } else if ("xml".equals(this.fStringPool.toString(i))) {
            if (this.fReader.skippedSpace()) {
              if (bool) {
                scanXMLDecl();
              } else {
                this.fErrorHandler.error(117);
                this.fReader.skipPastChar('>');
                this.fScannerMarkupDepth--;
              } 
            } else {
              this.fErrorHandler.error(107);
              this.fReader.skipPastChar('>');
              this.fScannerMarkupDepth--;
            } 
          } else {
            if (this.fDocumentHandler != null && !this.fCalledStartDocument) {
              this.fDocumentHandler.startDocument(-1, -1, -1);
              this.fCalledStartDocument = true;
            } 
            scanPI(i, true);
          } 
        } else if (this.fReader.skippedChar('!')) {
          if (this.fDocumentHandler != null && !this.fCalledStartDocument) {
            this.fDocumentHandler.startDocument(-1, -1, -1);
            this.fCalledStartDocument = true;
          } 
          if (this.fReader.skippedChar('-')) {
            if (this.fReader.skippedChar('-')) {
              scanComment(true);
            } else {
              this.fErrorHandler.error(20);
              this.fReader.skipPastChar('>');
              this.fScannerMarkupDepth--;
            } 
          } else if (this.fReader.skippedString(doctype_string)) {
            scanDoctypeDecl();
          } else {
            this.fErrorHandler.error(39);
            this.fReader.skipPastChar('>');
            this.fScannerMarkupDepth--;
          } 
        } else {
          if (this.fDocumentHandler != null && !this.fCalledStartDocument) {
            this.fDocumentHandler.startDocument(-1, -1, -1);
            this.fCalledStartDocument = true;
          } 
          return;
        } 
      } else if (this.fReader.skippedSpace()) {
        this.fReader.skipPastSpaces();
      } else {
        this.fErrorHandler.error(116);
        this.fReader.skipToChar('<');
      } 
      if (this.fDocumentHandler != null && !this.fCalledStartDocument) {
        this.fDocumentHandler.startDocument(-1, -1, -1);
        this.fCalledStartDocument = true;
      } 
    } 
  }
  
  private void scanXMLDecl() { // Byte code:
    //   0: iconst_m1
    //   1: istore_1
    //   2: iconst_m1
    //   3: istore_2
    //   4: iconst_m1
    //   5: istore_3
    //   6: aload_0
    //   7: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   10: invokevirtual skipPastSpaces : ()I
    //   13: istore #4
    //   15: aload_0
    //   16: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   19: getstatic com/ibm/xml/internal/DefaultScanner.version_string : [C
    //   22: invokevirtual skippedString : ([C)Z
    //   25: ifne -> 61
    //   28: aload_0
    //   29: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   32: sipush #146
    //   35: invokeinterface error : (I)V
    //   40: aload_0
    //   41: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   44: bipush #62
    //   46: invokevirtual skipPastChar : (C)I
    //   49: pop
    //   50: aload_0
    //   51: dup
    //   52: getfield fScannerMarkupDepth : I
    //   55: iconst_1
    //   56: isub
    //   57: putfield fScannerMarkupDepth : I
    //   60: return
    //   61: aload_0
    //   62: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   65: invokevirtual currentOffset : ()I
    //   68: iload #4
    //   70: isub
    //   71: istore #5
    //   73: aload_0
    //   74: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   77: invokevirtual skipPastSpaces : ()I
    //   80: pop
    //   81: aload_0
    //   82: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   85: bipush #61
    //   87: invokevirtual skippedChar : (C)Z
    //   90: ifeq -> 105
    //   93: aload_0
    //   94: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   97: invokevirtual skipPastSpaces : ()I
    //   100: pop
    //   101: iconst_1
    //   102: ifne -> 152
    //   105: aload_0
    //   106: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   109: iload #4
    //   111: iload #5
    //   113: invokevirtual addString : (II)I
    //   116: istore #6
    //   118: aload_0
    //   119: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   122: bipush #8
    //   124: iload #6
    //   126: invokeinterface error1 : (II)V
    //   131: aload_0
    //   132: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   135: bipush #62
    //   137: invokevirtual skipPastChar : (C)I
    //   140: pop
    //   141: aload_0
    //   142: dup
    //   143: getfield fScannerMarkupDepth : I
    //   146: iconst_1
    //   147: isub
    //   148: putfield fScannerMarkupDepth : I
    //   151: return
    //   152: aload_0
    //   153: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   156: bipush #39
    //   158: invokevirtual skippedChar : (C)Z
    //   161: dup
    //   162: istore #6
    //   164: ifne -> 211
    //   167: aload_0
    //   168: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   171: bipush #34
    //   173: invokevirtual skippedChar : (C)Z
    //   176: ifne -> 211
    //   179: aload_0
    //   180: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   183: bipush #16
    //   185: invokeinterface error : (I)V
    //   190: aload_0
    //   191: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   194: bipush #62
    //   196: invokevirtual skipPastChar : (C)I
    //   199: pop
    //   200: aload_0
    //   201: dup
    //   202: getfield fScannerMarkupDepth : I
    //   205: iconst_1
    //   206: isub
    //   207: putfield fScannerMarkupDepth : I
    //   210: return
    //   211: aload_0
    //   212: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   215: invokevirtual currentOffset : ()I
    //   218: istore #7
    //   220: iload #6
    //   222: ifeq -> 230
    //   225: bipush #39
    //   227: goto -> 232
    //   230: bipush #34
    //   232: istore #8
    //   234: goto -> 364
    //   237: aload_0
    //   238: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   241: invokevirtual skippedVersionNum : ()Z
    //   244: ifne -> 364
    //   247: goto -> 258
    //   250: aload_0
    //   251: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   254: invokevirtual skipOneChar : ()I
    //   257: pop
    //   258: aload_0
    //   259: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   262: iload #8
    //   264: invokevirtual lookingAtChar : (C)Z
    //   267: ifne -> 282
    //   270: aload_0
    //   271: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   274: bipush #60
    //   276: invokevirtual lookingAtChar : (C)Z
    //   279: ifeq -> 250
    //   282: aload_0
    //   283: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   286: bipush #60
    //   288: invokevirtual lookingAtChar : (C)Z
    //   291: ifeq -> 308
    //   294: aload_0
    //   295: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   298: bipush #17
    //   300: invokeinterface error : (I)V
    //   305: goto -> 343
    //   308: aload_0
    //   309: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   312: iload #7
    //   314: aload_0
    //   315: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   318: invokevirtual currentOffset : ()I
    //   321: iload #7
    //   323: isub
    //   324: invokevirtual addString : (II)I
    //   327: istore #9
    //   329: aload_0
    //   330: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   333: sipush #151
    //   336: iload #9
    //   338: invokeinterface error1 : (II)V
    //   343: aload_0
    //   344: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   347: bipush #62
    //   349: invokevirtual skipPastChar : (C)I
    //   352: pop
    //   353: aload_0
    //   354: dup
    //   355: getfield fScannerMarkupDepth : I
    //   358: iconst_1
    //   359: isub
    //   360: putfield fScannerMarkupDepth : I
    //   363: return
    //   364: aload_0
    //   365: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   368: iload #8
    //   370: invokevirtual lookingAtChar : (C)Z
    //   373: ifeq -> 237
    //   376: aload_0
    //   377: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   380: iload #7
    //   382: aload_0
    //   383: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   386: invokevirtual currentOffset : ()I
    //   389: iload #7
    //   391: isub
    //   392: invokevirtual addString : (II)I
    //   395: istore_1
    //   396: aload_0
    //   397: getfield fStringPool : Lcom/ibm/xml/framework/StringPool;
    //   400: iload_1
    //   401: invokeinterface toString : (I)Ljava/lang/String;
    //   406: astore #9
    //   408: ldc '1.0'
    //   410: aload #9
    //   412: invokevirtual equals : (Ljava/lang/Object;)Z
    //   415: ifne -> 430
    //   418: aload_0
    //   419: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   422: sipush #149
    //   425: invokeinterface error : (I)V
    //   430: aload_0
    //   431: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   434: invokevirtual skipAsciiChar : ()I
    //   437: pop
    //   438: aload_0
    //   439: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   442: invokevirtual skippedSpace : ()Z
    //   445: ifne -> 573
    //   448: aload_0
    //   449: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   452: bipush #63
    //   454: invokevirtual skippedChar : (C)Z
    //   457: ifne -> 493
    //   460: aload_0
    //   461: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   464: sipush #145
    //   467: invokeinterface error : (I)V
    //   472: aload_0
    //   473: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   476: bipush #62
    //   478: invokevirtual skipPastChar : (C)I
    //   481: pop
    //   482: aload_0
    //   483: dup
    //   484: getfield fScannerMarkupDepth : I
    //   487: iconst_1
    //   488: isub
    //   489: putfield fScannerMarkupDepth : I
    //   492: return
    //   493: aload_0
    //   494: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   497: bipush #62
    //   499: invokevirtual skippedChar : (C)Z
    //   502: ifne -> 538
    //   505: aload_0
    //   506: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   509: sipush #145
    //   512: invokeinterface error : (I)V
    //   517: aload_0
    //   518: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   521: bipush #62
    //   523: invokevirtual skipPastChar : (C)I
    //   526: pop
    //   527: aload_0
    //   528: dup
    //   529: getfield fScannerMarkupDepth : I
    //   532: iconst_1
    //   533: isub
    //   534: putfield fScannerMarkupDepth : I
    //   537: return
    //   538: aload_0
    //   539: dup
    //   540: getfield fScannerMarkupDepth : I
    //   543: iconst_1
    //   544: isub
    //   545: putfield fScannerMarkupDepth : I
    //   548: aload_0
    //   549: getfield fDocumentHandler : Lcom/ibm/xml/framework/XMLDocumentHandler;
    //   552: ifnull -> 572
    //   555: aload_0
    //   556: getfield fDocumentHandler : Lcom/ibm/xml/framework/XMLDocumentHandler;
    //   559: iload_1
    //   560: iload_2
    //   561: iload_3
    //   562: invokeinterface startDocument : (III)V
    //   567: aload_0
    //   568: iconst_1
    //   569: putfield fCalledStartDocument : Z
    //   572: return
    //   573: aload_0
    //   574: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   577: invokevirtual skipPastSpaces : ()I
    //   580: istore #10
    //   582: aload_0
    //   583: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   586: getstatic com/ibm/xml/internal/DefaultScanner.encoding_string : [C
    //   589: invokevirtual skippedString : ([C)Z
    //   592: ifeq -> 1195
    //   595: aload_0
    //   596: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   599: invokevirtual currentOffset : ()I
    //   602: iload #10
    //   604: isub
    //   605: istore #11
    //   607: aload_0
    //   608: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   611: invokevirtual skipPastSpaces : ()I
    //   614: pop
    //   615: aload_0
    //   616: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   619: bipush #61
    //   621: invokevirtual skippedChar : (C)Z
    //   624: ifeq -> 639
    //   627: aload_0
    //   628: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   631: invokevirtual skipPastSpaces : ()I
    //   634: pop
    //   635: iconst_1
    //   636: ifne -> 686
    //   639: aload_0
    //   640: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   643: iload #10
    //   645: iload #11
    //   647: invokevirtual addString : (II)I
    //   650: istore #12
    //   652: aload_0
    //   653: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   656: bipush #8
    //   658: iload #12
    //   660: invokeinterface error1 : (II)V
    //   665: aload_0
    //   666: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   669: bipush #62
    //   671: invokevirtual skipPastChar : (C)I
    //   674: pop
    //   675: aload_0
    //   676: dup
    //   677: getfield fScannerMarkupDepth : I
    //   680: iconst_1
    //   681: isub
    //   682: putfield fScannerMarkupDepth : I
    //   685: return
    //   686: aload_0
    //   687: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   690: bipush #39
    //   692: invokevirtual skippedChar : (C)Z
    //   695: dup
    //   696: istore #6
    //   698: ifne -> 745
    //   701: aload_0
    //   702: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   705: bipush #34
    //   707: invokevirtual skippedChar : (C)Z
    //   710: ifne -> 745
    //   713: aload_0
    //   714: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   717: bipush #16
    //   719: invokeinterface error : (I)V
    //   724: aload_0
    //   725: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   728: bipush #62
    //   730: invokevirtual skipPastChar : (C)I
    //   733: pop
    //   734: aload_0
    //   735: dup
    //   736: getfield fScannerMarkupDepth : I
    //   739: iconst_1
    //   740: isub
    //   741: putfield fScannerMarkupDepth : I
    //   744: return
    //   745: aload_0
    //   746: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   749: invokevirtual currentOffset : ()I
    //   752: istore #7
    //   754: iload #6
    //   756: ifeq -> 764
    //   759: bipush #39
    //   761: goto -> 766
    //   764: bipush #34
    //   766: istore #8
    //   768: aload_0
    //   769: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   772: invokevirtual skippedAlpha : ()Z
    //   775: ifne -> 1020
    //   778: goto -> 789
    //   781: aload_0
    //   782: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   785: invokevirtual skipOneChar : ()I
    //   788: pop
    //   789: aload_0
    //   790: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   793: iload #8
    //   795: invokevirtual lookingAtChar : (C)Z
    //   798: ifne -> 813
    //   801: aload_0
    //   802: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   805: bipush #60
    //   807: invokevirtual lookingAtChar : (C)Z
    //   810: ifeq -> 781
    //   813: aload_0
    //   814: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   817: bipush #60
    //   819: invokevirtual lookingAtChar : (C)Z
    //   822: ifeq -> 839
    //   825: aload_0
    //   826: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   829: bipush #17
    //   831: invokeinterface error : (I)V
    //   836: goto -> 873
    //   839: aload_0
    //   840: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   843: iload #7
    //   845: aload_0
    //   846: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   849: invokevirtual currentOffset : ()I
    //   852: iload #7
    //   854: isub
    //   855: invokevirtual addString : (II)I
    //   858: istore #12
    //   860: aload_0
    //   861: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   864: bipush #106
    //   866: iload #12
    //   868: invokeinterface error1 : (II)V
    //   873: aload_0
    //   874: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   877: bipush #62
    //   879: invokevirtual skipPastChar : (C)I
    //   882: pop
    //   883: aload_0
    //   884: dup
    //   885: getfield fScannerMarkupDepth : I
    //   888: iconst_1
    //   889: isub
    //   890: putfield fScannerMarkupDepth : I
    //   893: return
    //   894: aload_0
    //   895: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   898: invokevirtual skippedEncName : ()Z
    //   901: ifne -> 1020
    //   904: goto -> 915
    //   907: aload_0
    //   908: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   911: invokevirtual skipOneChar : ()I
    //   914: pop
    //   915: aload_0
    //   916: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   919: iload #8
    //   921: invokevirtual lookingAtChar : (C)Z
    //   924: ifne -> 939
    //   927: aload_0
    //   928: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   931: bipush #60
    //   933: invokevirtual lookingAtChar : (C)Z
    //   936: ifeq -> 907
    //   939: aload_0
    //   940: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   943: bipush #60
    //   945: invokevirtual lookingAtChar : (C)Z
    //   948: ifeq -> 965
    //   951: aload_0
    //   952: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   955: bipush #17
    //   957: invokeinterface error : (I)V
    //   962: goto -> 999
    //   965: aload_0
    //   966: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   969: iload #7
    //   971: aload_0
    //   972: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   975: invokevirtual currentOffset : ()I
    //   978: iload #7
    //   980: isub
    //   981: invokevirtual addString : (II)I
    //   984: istore #12
    //   986: aload_0
    //   987: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   990: bipush #106
    //   992: iload #12
    //   994: invokeinterface error1 : (II)V
    //   999: aload_0
    //   1000: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1003: bipush #62
    //   1005: invokevirtual skipPastChar : (C)I
    //   1008: pop
    //   1009: aload_0
    //   1010: dup
    //   1011: getfield fScannerMarkupDepth : I
    //   1014: iconst_1
    //   1015: isub
    //   1016: putfield fScannerMarkupDepth : I
    //   1019: return
    //   1020: aload_0
    //   1021: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1024: iload #8
    //   1026: invokevirtual lookingAtChar : (C)Z
    //   1029: ifeq -> 894
    //   1032: aload_0
    //   1033: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1036: iload #7
    //   1038: aload_0
    //   1039: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1042: invokevirtual currentOffset : ()I
    //   1045: iload #7
    //   1047: isub
    //   1048: invokevirtual addString : (II)I
    //   1051: istore_2
    //   1052: aload_0
    //   1053: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1056: invokevirtual skipAsciiChar : ()I
    //   1059: pop
    //   1060: aload_0
    //   1061: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1064: invokevirtual skippedSpace : ()Z
    //   1067: ifne -> 1195
    //   1070: aload_0
    //   1071: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1074: bipush #63
    //   1076: invokevirtual skippedChar : (C)Z
    //   1079: ifne -> 1115
    //   1082: aload_0
    //   1083: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   1086: sipush #145
    //   1089: invokeinterface error : (I)V
    //   1094: aload_0
    //   1095: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1098: bipush #62
    //   1100: invokevirtual skipPastChar : (C)I
    //   1103: pop
    //   1104: aload_0
    //   1105: dup
    //   1106: getfield fScannerMarkupDepth : I
    //   1109: iconst_1
    //   1110: isub
    //   1111: putfield fScannerMarkupDepth : I
    //   1114: return
    //   1115: aload_0
    //   1116: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1119: bipush #62
    //   1121: invokevirtual skippedChar : (C)Z
    //   1124: ifne -> 1160
    //   1127: aload_0
    //   1128: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   1131: sipush #145
    //   1134: invokeinterface error : (I)V
    //   1139: aload_0
    //   1140: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1143: bipush #62
    //   1145: invokevirtual skipPastChar : (C)I
    //   1148: pop
    //   1149: aload_0
    //   1150: dup
    //   1151: getfield fScannerMarkupDepth : I
    //   1154: iconst_1
    //   1155: isub
    //   1156: putfield fScannerMarkupDepth : I
    //   1159: return
    //   1160: aload_0
    //   1161: dup
    //   1162: getfield fScannerMarkupDepth : I
    //   1165: iconst_1
    //   1166: isub
    //   1167: putfield fScannerMarkupDepth : I
    //   1170: aload_0
    //   1171: getfield fDocumentHandler : Lcom/ibm/xml/framework/XMLDocumentHandler;
    //   1174: ifnull -> 1194
    //   1177: aload_0
    //   1178: getfield fDocumentHandler : Lcom/ibm/xml/framework/XMLDocumentHandler;
    //   1181: iload_1
    //   1182: iload_2
    //   1183: iload_3
    //   1184: invokeinterface startDocument : (III)V
    //   1189: aload_0
    //   1190: iconst_1
    //   1191: putfield fCalledStartDocument : Z
    //   1194: return
    //   1195: aload_0
    //   1196: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1199: invokevirtual skipPastSpaces : ()I
    //   1202: istore #11
    //   1204: aload_0
    //   1205: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1208: getstatic com/ibm/xml/internal/DefaultScanner.standalone_string : [C
    //   1211: invokevirtual skippedString : ([C)Z
    //   1214: ifeq -> 1581
    //   1217: aload_0
    //   1218: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1221: invokevirtual currentOffset : ()I
    //   1224: iload #11
    //   1226: isub
    //   1227: istore #12
    //   1229: aload_0
    //   1230: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1233: invokevirtual skipPastSpaces : ()I
    //   1236: pop
    //   1237: aload_0
    //   1238: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1241: bipush #61
    //   1243: invokevirtual skippedChar : (C)Z
    //   1246: ifeq -> 1261
    //   1249: aload_0
    //   1250: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1253: invokevirtual skipPastSpaces : ()I
    //   1256: pop
    //   1257: iconst_1
    //   1258: ifne -> 1308
    //   1261: aload_0
    //   1262: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1265: iload #11
    //   1267: iload #12
    //   1269: invokevirtual addString : (II)I
    //   1272: istore #13
    //   1274: aload_0
    //   1275: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   1278: bipush #8
    //   1280: iload #13
    //   1282: invokeinterface error1 : (II)V
    //   1287: aload_0
    //   1288: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1291: bipush #62
    //   1293: invokevirtual skipPastChar : (C)I
    //   1296: pop
    //   1297: aload_0
    //   1298: dup
    //   1299: getfield fScannerMarkupDepth : I
    //   1302: iconst_1
    //   1303: isub
    //   1304: putfield fScannerMarkupDepth : I
    //   1307: return
    //   1308: aload_0
    //   1309: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1312: bipush #39
    //   1314: invokevirtual skippedChar : (C)Z
    //   1317: dup
    //   1318: istore #6
    //   1320: ifne -> 1367
    //   1323: aload_0
    //   1324: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1327: bipush #34
    //   1329: invokevirtual skippedChar : (C)Z
    //   1332: ifne -> 1367
    //   1335: aload_0
    //   1336: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   1339: bipush #16
    //   1341: invokeinterface error : (I)V
    //   1346: aload_0
    //   1347: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1350: bipush #62
    //   1352: invokevirtual skipPastChar : (C)I
    //   1355: pop
    //   1356: aload_0
    //   1357: dup
    //   1358: getfield fScannerMarkupDepth : I
    //   1361: iconst_1
    //   1362: isub
    //   1363: putfield fScannerMarkupDepth : I
    //   1366: return
    //   1367: aload_0
    //   1368: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1371: invokevirtual currentOffset : ()I
    //   1374: istore #7
    //   1376: iload #6
    //   1378: ifeq -> 1386
    //   1381: bipush #39
    //   1383: goto -> 1388
    //   1386: bipush #34
    //   1388: istore #8
    //   1390: aload_0
    //   1391: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1394: getstatic com/ibm/xml/internal/DefaultScanner.yes_string : [C
    //   1397: invokevirtual skippedString : ([C)Z
    //   1400: dup
    //   1401: istore #13
    //   1403: ifne -> 1419
    //   1406: aload_0
    //   1407: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1410: getstatic com/ibm/xml/internal/DefaultScanner.no_string : [C
    //   1413: invokevirtual skippedString : ([C)Z
    //   1416: ifeq -> 1442
    //   1419: aload_0
    //   1420: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1423: iload #8
    //   1425: invokevirtual lookingAtChar : (C)Z
    //   1428: ifne -> 1547
    //   1431: goto -> 1442
    //   1434: aload_0
    //   1435: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1438: invokevirtual skipOneChar : ()I
    //   1441: pop
    //   1442: aload_0
    //   1443: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1446: iload #8
    //   1448: invokevirtual lookingAtChar : (C)Z
    //   1451: ifne -> 1466
    //   1454: aload_0
    //   1455: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1458: bipush #60
    //   1460: invokevirtual lookingAtChar : (C)Z
    //   1463: ifeq -> 1434
    //   1466: aload_0
    //   1467: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1470: bipush #60
    //   1472: invokevirtual lookingAtChar : (C)Z
    //   1475: ifeq -> 1492
    //   1478: aload_0
    //   1479: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   1482: bipush #17
    //   1484: invokeinterface error : (I)V
    //   1489: goto -> 1526
    //   1492: aload_0
    //   1493: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1496: iload #7
    //   1498: aload_0
    //   1499: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1502: invokevirtual currentOffset : ()I
    //   1505: iload #7
    //   1507: isub
    //   1508: invokevirtual addString : (II)I
    //   1511: istore #14
    //   1513: aload_0
    //   1514: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   1517: bipush #106
    //   1519: iload #14
    //   1521: invokeinterface error1 : (II)V
    //   1526: aload_0
    //   1527: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1530: bipush #62
    //   1532: invokevirtual skipPastChar : (C)I
    //   1535: pop
    //   1536: aload_0
    //   1537: dup
    //   1538: getfield fScannerMarkupDepth : I
    //   1541: iconst_1
    //   1542: isub
    //   1543: putfield fScannerMarkupDepth : I
    //   1546: return
    //   1547: aload_0
    //   1548: iload #13
    //   1550: putfield fStandalone : Z
    //   1553: aload_0
    //   1554: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1557: iload #7
    //   1559: aload_0
    //   1560: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1563: invokevirtual currentOffset : ()I
    //   1566: iload #7
    //   1568: isub
    //   1569: invokevirtual addString : (II)I
    //   1572: istore_3
    //   1573: aload_0
    //   1574: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1577: invokevirtual skipAsciiChar : ()I
    //   1580: pop
    //   1581: aload_0
    //   1582: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1585: invokevirtual skipPastSpaces : ()I
    //   1588: pop
    //   1589: aload_0
    //   1590: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1593: bipush #63
    //   1595: invokevirtual skippedChar : (C)Z
    //   1598: ifne -> 1634
    //   1601: aload_0
    //   1602: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   1605: sipush #145
    //   1608: invokeinterface error : (I)V
    //   1613: aload_0
    //   1614: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1617: bipush #62
    //   1619: invokevirtual skipPastChar : (C)I
    //   1622: pop
    //   1623: aload_0
    //   1624: dup
    //   1625: getfield fScannerMarkupDepth : I
    //   1628: iconst_1
    //   1629: isub
    //   1630: putfield fScannerMarkupDepth : I
    //   1633: return
    //   1634: aload_0
    //   1635: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1638: bipush #62
    //   1640: invokevirtual skippedChar : (C)Z
    //   1643: ifne -> 1679
    //   1646: aload_0
    //   1647: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   1650: sipush #145
    //   1653: invokeinterface error : (I)V
    //   1658: aload_0
    //   1659: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1662: bipush #62
    //   1664: invokevirtual skipPastChar : (C)I
    //   1667: pop
    //   1668: aload_0
    //   1669: dup
    //   1670: getfield fScannerMarkupDepth : I
    //   1673: iconst_1
    //   1674: isub
    //   1675: putfield fScannerMarkupDepth : I
    //   1678: return
    //   1679: aload_0
    //   1680: dup
    //   1681: getfield fScannerMarkupDepth : I
    //   1684: iconst_1
    //   1685: isub
    //   1686: putfield fScannerMarkupDepth : I
    //   1689: aload_0
    //   1690: getfield fDocumentHandler : Lcom/ibm/xml/framework/XMLDocumentHandler;
    //   1693: ifnull -> 1713
    //   1696: aload_0
    //   1697: getfield fDocumentHandler : Lcom/ibm/xml/framework/XMLDocumentHandler;
    //   1700: iload_1
    //   1701: iload_2
    //   1702: iload_3
    //   1703: invokeinterface startDocument : (III)V
    //   1708: aload_0
    //   1709: iconst_1
    //   1710: putfield fCalledStartDocument : Z
    //   1713: return }
  
  private boolean scanElement(int paramInt) throws Exception {
    if (this.fStop)
      throw new StopException(this); 
    boolean bool = false;
    int i = -1;
    int j = -1;
    if (this.fReader.skippedSpace()) {
      this.fReader.skipPastSpaces();
      while (!(bool = this.fReader.skippedChar('>')) && !this.fReader.skippedChar('/')) {
        int m = this.fReader.scanName('=', -1);
        if (m == -1) {
          this.fErrorHandler.error(123);
          this.fReader.skipPastChar('>');
          this.fScannerMarkupDepth--;
          return false;
        } 
        this.fReader.skipPastSpaces();
        if (this.fReader.skippedChar('=')) {
          this.fReader.skipPastSpaces();
          if (true) {
            byte b;
            int n = this.fElementDeclPool.getAttDef(paramInt, m);
            boolean bool1 = false;
            if (n != -1) {
              b = this.fElementDeclPool.getAttType(n);
              bool1 = !(this.fElementDeclPool.getAttDefaultType(n) != 4);
            } else {
              if (this.fValidationHandler != null)
                this.fErrorHandler.error2(127, m, paramInt); 
              b = 0;
            } 
            if (!scanAttValue(paramInt, m, b, true, bool1)) {
              this.fReader.skipPastChar('>');
              this.fScannerMarkupDepth--;
              return false;
            } 
            this.fAttr.attName = m;
            this.fAttr.attType = b;
            this.fAttr.attValue = this.fAttValueIndex;
            this.fAttr.specified = true;
            int i1 = this.fAttrPool.addAttr(this.fAttr, i);
            if (i1 != -1) {
              j = i1;
              if (i == -1)
                i = i1; 
            } 
            continue;
          } 
        } 
        this.fErrorHandler.error1(8, m);
        this.fReader.skipPastChar('>');
        this.fScannerMarkupDepth--;
        return false;
      } 
    } else if (!(bool = this.fReader.skippedChar('>')) && !this.fReader.skippedChar('/')) {
      this.fErrorHandler.error(123);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return false;
    } 
    int k = this.fElementDeclPool.addElement(paramInt);
    i = this.fElementDeclPool.addDefaultAttributes(k, this.fAttrPool, i, j);
    if (this.fValidationHandler != null)
      this.fValidationHandler.checkAttributes(k, i); 
    if (this.fDocumentHandler != null) {
      this.fDocumentHandler.startElement(paramInt, i);
    } else {
      this.fAttrPool.releaseAttrList(i);
    } 
    if (!bool) {
      if (!this.fReader.skippedChar('>')) {
        this.fErrorHandler.error(123);
        this.fReader.skipPastChar('>');
        this.fScannerMarkupDepth--;
        return false;
      } 
      this.fScannerMarkupDepth--;
      pushElementName(paramInt);
      if (this.fDocumentHandler != null)
        this.fDocumentHandler.endElement(paramInt); 
      if (this.fValidationHandler != null) {
        int m = this.fElementChildCount[this.fElementDepth];
        int n = this.fValidationHandler.checkContent(k, m, this.fElementChildren[this.fElementDepth]);
        if (n != -1 || n == m) {
          String str = this.fElementDeclPool.getContentSpecAsString(k);
          byte b = (n == -1) ? 27 : 164;
          int i1 = this.fStringPool.addString(str);
          this.fErrorHandler.error2(b, paramInt, i1);
        } 
      } 
      if (this.fElementDepth < 0)
        throw new RuntimeException("Element stack underflow"); 
      this.fElementDepth--;
      return true;
    } 
    this.fScannerMarkupDepth--;
    pushElementName(paramInt);
    return true;
  }
  
  private void scanContent(ScanContentState paramScanContentState) throws Exception {
    while (true) {
      int i = this.fReader.scanContent(paramScanContentState);
      if ((i & 0x8) != 0) {
        if (this.fValidationHandler != null && (i & 0x10) == 0)
          charDataInContent(); 
        paramScanContentState.parseTextDecl = false;
      } 
      switch (i & 0x7) {
        case 1:
          this.fScannerMarkupDepth++;
          j = this.fReader.scanName('>', -1);
          if (j != -1) {
            scanElement(j);
            break;
          } 
          if (this.fReader.skippedChar('/')) {
            if (paramScanContentState.extParsedEnt && this.fElementDepth == paramScanContentState.elementDepth)
              this.fErrorHandler.error(137); 
            j = this.fElementNameStack[this.fElementDepth];
            int k = this.fReader.scanName('>', j);
            if (k == -1) {
              this.fErrorHandler.error1(124, j);
              this.fReader.skipPastChar('>');
              this.fScannerMarkupDepth--;
              break;
            } 
            if (!this.fReader.skippedChar('>')) {
              this.fReader.skipPastSpaces();
              if (!this.fReader.skippedChar('>'))
                this.fErrorHandler.error1(125, k); 
            } 
            this.fScannerMarkupDepth--;
            if (this.fDocumentHandler != null)
              this.fDocumentHandler.endElement(j); 
            if (this.fValidationHandler != null) {
              int m = this.fElementDeclPool.getElement(j);
              int n = this.fElementChildCount[this.fElementDepth];
              i = this.fValidationHandler.checkContent(m, n, this.fElementChildren[this.fElementDepth]);
              if (i != -1 || i == n) {
                String str = this.fElementDeclPool.getContentSpecAsString(m);
                byte b = (i == -1) ? 27 : 164;
                int i1 = this.fStringPool.addString(str);
                this.fErrorHandler.error2(b, j, i1);
              } 
            } 
            if (this.fElementDepth < 0)
              throw new RuntimeException("Element stack underflow"); 
            if (--this.fElementDepth < 0 && !false)
              return; 
            break;
          } 
          if (this.fReader.skippedChar('!')) {
            if (this.fReader.skippedChar('-')) {
              if (this.fReader.skippedChar('-')) {
                scanComment(true);
                break;
              } 
              this.fErrorHandler.error(20);
              this.fReader.skipPastChar('>');
              this.fScannerMarkupDepth--;
              break;
            } 
            if (this.fReader.skippedChar('[')) {
              if (this.fReader.skippedString(cdata_string)) {
                if (this.fReader.skippedChar('[')) {
                  paramScanContentState.inCDSect = true;
                  this.fScannerMarkupDepth--;
                  break;
                } 
                this.fErrorHandler.error(18);
                this.fReader.skipPastChar('>');
                this.fScannerMarkupDepth--;
                break;
              } 
              this.fErrorHandler.error(18);
              this.fReader.skipPastChar('>');
              this.fScannerMarkupDepth--;
              break;
            } 
            this.fErrorHandler.error(0);
            this.fReader.skipPastChar('>');
            this.fScannerMarkupDepth--;
            break;
          } 
          if (this.fReader.skippedChar('?')) {
            int k = this.fReader.scanName(' ', -1);
            if (k == -1) {
              this.fErrorHandler.error(102);
              this.fReader.skipPastChar('>');
              this.fScannerMarkupDepth--;
              break;
            } 
            if ("xml".equals(this.fStringPool.toString(k))) {
              if (this.fReader.skippedSpace()) {
                if (paramScanContentState.parseTextDecl) {
                  scanTextDecl();
                  break;
                } 
                this.fErrorHandler.error(117);
                this.fReader.skipPastChar('>');
                this.fScannerMarkupDepth--;
                break;
              } 
              this.fErrorHandler.error(107);
              this.fReader.skipPastChar('>');
              this.fScannerMarkupDepth--;
              break;
            } 
            scanPI(k, true);
            break;
          } 
          this.fErrorHandler.error(122);
          break;
        case 2:
          referenceInContent(this.fReader.currentOffset());
          break;
        case 3:
          this.fErrorHandler.error(140);
          break;
        case 4:
          try {
            this.fReader.lookingAtValidChar();
          } catch (ArrayIndexOutOfBoundsException j) {
            ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException;
            if (paramScanContentState.inCDSect)
              this.fErrorHandler.error(19); 
            throw arrayIndexOutOfBoundsException;
          } 
          this.fReader.skipInvalidChar(85);
          break;
      } 
      paramScanContentState.parseTextDecl = false;
    } 
  }
  
  private boolean scanAttValueCDATA(boolean paramBoolean1, boolean paramBoolean2) throws Exception {
    boolean bool;
    if (!(bool = this.fReader.skippedChar('\'')) && !this.fReader.skippedChar('"')) {
      this.fErrorHandler.error(16);
      return false;
    } 
    char c = bool ? '\'' : '"';
    int i = this.fReader.currentOffset();
    int j = i;
    int k = paramBoolean1 ? this.fLiteralData.length() : 0;
    byte b = 0;
    while (true) {
      boolean bool1 = false;
      boolean bool2 = false;
      if (!b) {
        while (true) {
          try {
            bool1 = this.fReader.skippedChar(c);
            break;
          } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            if (paramBoolean1 && i - j > 0)
              this.fReader.append(this.fLiteralData, j, i - j); 
            popReader();
            this.fEntityStackDepth--;
            i = this.fReader.currentOffset();
            j = i;
          } 
        } 
        if (bool1) {
          if (paramBoolean1) {
            int m = this.fLiteralData.length() - k;
            if (m == 0) {
              if (paramBoolean2) {
                this.fAttValueIndex = this.fReader.addSymbol(j, i - j);
              } else {
                this.fAttValueIndex = this.fReader.addString(j, i - j);
              } 
            } else {
              if (i - j > 0) {
                this.fReader.append(this.fLiteralData, j, i - j);
                m = this.fLiteralData.length() - k;
              } 
              if (paramBoolean2) {
                this.fAttValueIndex = this.fLiteralData.addSymbol(k, m);
              } else {
                this.fAttValueIndex = this.fLiteralData.addString(k, m);
              } 
            } 
          } 
          return true;
        } 
      } 
      try {
        bool1 = this.fReader.skippedChar(' ');
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        if (paramBoolean1 && i - j > 0)
          this.fReader.append(this.fLiteralData, j, i - j); 
        popReader();
        this.fEntityStackDepth--;
        b--;
        bool2 = true;
        i = this.fReader.currentOffset();
        j = i;
      } 
      if (!bool2) {
        if (bool1) {
          i = this.fReader.currentOffset();
          continue;
        } 
        if (this.fReader.skippedSpace()) {
          if (paramBoolean1) {
            if (i - j > 0)
              this.fReader.append(this.fLiteralData, j, i - j); 
            this.fLiteralData.append(' ');
          } 
          i = this.fReader.currentOffset();
          j = i;
          continue;
        } 
        if (this.fReader.skippedChar('&')) {
          if (paramBoolean1 && i - j > 0)
            this.fReader.append(this.fLiteralData, j, i - j); 
          if (this.fReader.skippedChar('#')) {
            int i3 = scanCharRef();
            if (i3 == -1) {
              while (b-- > 0) {
                popReader();
                this.fEntityStackDepth--;
              } 
              this.fReader.skipPastChar(c);
              return false;
            } 
            if (paramBoolean1)
              if (i3 < 65536) {
                this.fLiteralData.append((char)i3);
              } else {
                this.fLiteralData.append((char)((i3 - 65536 >> 10) + 55296));
                this.fLiteralData.append((char)((i3 - 65536 & 0x3FF) + 56320));
              }  
            i = this.fReader.currentOffset();
            j = i;
            continue;
          } 
          int m = this.fReader.currentOffset();
          int n = this.fReader.skipPastName(';') - m;
          if (n == 0) {
            this.fReader.skipInvalidChar(110);
            while (b-- > 0) {
              popReader();
              this.fEntityStackDepth--;
            } 
            this.fReader.skipPastChar(c);
            return false;
          } 
          if (!this.fReader.skippedChar(';')) {
            this.fErrorHandler.error(111);
            while (b-- > 0) {
              popReader();
              this.fEntityStackDepth--;
            } 
            this.fReader.skipPastChar(c);
            return false;
          } 
          int i1 = this.fReader.addSymbol(m, n);
          int i2 = this.fEntityPool.lookupEntity(i1);
          if (i2 < 0) {
            this.fErrorHandler.error1(60, i1);
            while (b-- > 0) {
              popReader();
              this.fEntityStackDepth--;
            } 
            this.fReader.skipPastChar(c);
            return false;
          } 
          if (this.fEntityPool.isExternal(i2)) {
            this.fErrorHandler.error1(67, i1);
            while (b-- > 0) {
              popReader();
              this.fEntityStackDepth--;
            } 
            this.fReader.skipPastChar(c);
            return false;
          } 
          if (!pushEntity((byte)0, i1)) {
            while (b-- > 0) {
              popReader();
              this.fEntityStackDepth--;
            } 
            this.fReader.skipPastChar(c);
            return false;
          } 
          StringReader stringReader = new StringReader(this.fParserState, false, this.fReader, this.fEntityPool.getEntityValue(i2));
          pushReader(stringReader, null);
          b++;
          i = this.fReader.currentOffset();
          j = i;
          continue;
        } 
        if (this.fReader.skippedChar('<')) {
          this.fErrorHandler.error(17);
          while (b-- > 0) {
            popReader();
            this.fEntityStackDepth--;
          } 
          this.fReader.skipPastChar(c);
          return false;
        } 
        if (!this.fReader.skippedValidChar()) {
          this.fReader.skipInvalidChar(85);
          while (b-- > 0) {
            popReader();
            this.fEntityStackDepth--;
          } 
          this.fReader.skipPastChar(c);
          return false;
        } 
        i = this.fReader.currentOffset();
      } 
    } 
  }
  
  private boolean scanNormalizedAttValue(char paramChar) throws Exception {
    byte b = 0;
    this.fLiteralData.length();
    while (true) {
      try {
        if (this.fReader.skippedChar('&')) {
          if (this.fReader.skippedChar('#')) {
            int i2 = scanCharRef();
            if (i2 == -1) {
              this.fReader.skipPastChar(paramChar);
              return false;
            } 
            if (i2 < 65536) {
              this.fLiteralData.append((char)i2);
              continue;
            } 
            this.fLiteralData.append((char)((i2 - 65536 >> 10) + 55296));
            this.fLiteralData.append((char)((i2 - 65536 & 0x3FF) + 56320));
            continue;
          } 
          int k = this.fReader.currentOffset();
          int m = this.fReader.skipPastName(';') - k;
          if (m == 0) {
            this.fReader.skipInvalidChar(110);
            this.fReader.skipPastChar(paramChar);
            return false;
          } 
          if (!this.fReader.skippedChar(';')) {
            this.fErrorHandler.error(111);
            this.fReader.skipPastChar(paramChar);
            return false;
          } 
          int n = this.fReader.addSymbol(k, m);
          int i1 = this.fEntityPool.lookupEntity(n);
          if (i1 < 0) {
            this.fErrorHandler.error1(60, n);
            this.fReader.skipPastChar(paramChar);
            return false;
          } 
          if (this.fEntityPool.isExternal(i1)) {
            this.fErrorHandler.error1(67, n);
            this.fReader.skipPastChar(paramChar);
            return false;
          } 
          if (!pushEntity((byte)0, n)) {
            this.fReader.skipPastChar(paramChar);
            return false;
          } 
          StringReader stringReader = new StringReader(this.fParserState, false, this.fReader, this.fEntityPool.getEntityValue(i1));
          pushReader(stringReader, null);
          b++;
          continue;
        } 
        if (this.fReader.skippedSpace()) {
          this.fReader.skipPastSpaces();
          this.fLiteralData.append(' ');
        } 
        if (this.fReader.lookingAtChar(paramChar)) {
          if (b == 0) {
            this.fReader.skipAsciiChar();
            this.fLiteralData.append(paramChar);
            return true;
          } 
          this.fReader.skipInvalidChar(85);
          while (b-- > 0) {
            popReader();
            this.fEntityStackDepth--;
          } 
          this.fReader.skipPastChar(paramChar);
          return false;
        } 
        int i = this.fReader.currentOffset();
        int j = this.fReader.skipOneChar() - i;
        this.fReader.append(this.fLiteralData, i, j);
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        b--;
        this.fEntityStackDepth--;
      } 
    } 
  }
  
  private boolean scanAttValue(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2) throws Exception {
    if (paramInt3 == 0)
      return scanAttValueCDATA(paramBoolean1, paramBoolean2); 
    boolean bool;
    if (!(bool = this.fReader.skippedChar('\'')) && !this.fReader.skippedChar('"')) {
      this.fErrorHandler.error(16);
      return false;
    } 
    char c = bool ? '\'' : '"';
    boolean bool1 = true;
    boolean bool2 = (paramInt3 == 3 || paramInt3 == 5 || paramInt3 == 7) ? 0 : 1;
    boolean bool3 = (paramInt3 == 6 || paramInt3 == 7 || paramInt3 == 9) ? 0 : 1;
    boolean bool4 = false;
    boolean bool5 = false;
    int i = this.fReader.skipPastSpaces();
    int j = this.fLiteralData.length();
    while (true) {
      int i2;
      int i1;
      int n;
      boolean bool6;
      int k = this.fReader.currentOffset();
      int m = (bool3 ? this.fReader.skipPastName(c) : this.fReader.skipPastNmtoken(c)) - k;
      if (m == 0) {
        if (bool4) {
          this.fReader.skipInvalidChar(85);
          popReader();
          return false;
        } 
        if (this.fReader.skippedChar(c)) {
          this.fErrorHandler.error1(142, paramInt2);
          return false;
        } 
        if (k - i > 0)
          this.fReader.append(this.fLiteralData, i, k - i); 
        i = -1;
        bool6 = this.fLiteralData.length();
        if (!scanNormalizedAttValue(c))
          return false; 
        n = this.fLiteralData.addString(bool6, this.fLiteralData.length() - bool6);
        StringReader stringReader = new StringReader(this.fParserState, false, this.fReader, n);
        pushReader(stringReader, null);
        bool4 = true;
        this.fLiteralData.setLength(bool6);
        k = this.fReader.skipPastSpaces();
        if (this.fReader.skippedChar(c)) {
          if (bool1) {
            this.fErrorHandler.error1(142, paramInt2);
            popReader();
            return false;
          } 
          if (paramBoolean2) {
            this.fAttValueIndex = this.fLiteralData.addSymbol(j, bool6 - j);
          } else {
            this.fAttValueIndex = this.fLiteralData.addString(j, bool6 - j);
          } 
          popReader();
          return true;
        } 
        m = (bool3 ? this.fReader.skipPastName(c) : this.fReader.skipPastNmtoken(c)) - k;
        if (m == 0) {
          this.fReader.skipInvalidChar(85);
          popReader();
          return false;
        } 
      } 
      if (bool4) {
        int i3 = this.fLiteralData.length();
        this.fReader.append(this.fLiteralData, k, m);
        i2 = this.fLiteralData.length();
        boolean bool7 = this.fReader.skippedSpace();
        if (bool7)
          this.fReader.skipPastSpaces(); 
        bool6 = this.fReader.skippedChar(c);
        if (bool6) {
          n = this.fLiteralData.addSymbol(i3, i2 - i3);
          if (bool1) {
            this.fAttValueIndex = n;
          } else if (paramBoolean2) {
            this.fAttValueIndex = this.fLiteralData.addSymbol(j, i2 - j);
          } else {
            this.fAttValueIndex = this.fLiteralData.addString(j, i2 - j);
          } 
          popReader();
        } else if (bool7) {
          if (bool2) {
            this.fReader.skipInvalidChar(85);
            popReader();
            return false;
          } 
          n = this.fLiteralData.addSymbol(i3, i2 - i3);
          this.fLiteralData.append(' ');
          k = this.fReader.currentOffset();
        } else {
          this.fReader.skipInvalidChar(85);
          popReader();
          return false;
        } 
      } else {
        boolean bool7 = false;
        i2 = this.fReader.skippedChar(' ');
        if (this.fReader.skippedSpace()) {
          this.fReader.skipPastSpaces();
          i2 = 1;
          bool7 = true;
        } 
        bool6 = this.fReader.skippedChar(c);
        if (bool6) {
          if (bool5) {
            int i3 = this.fLiteralData.length();
            this.fReader.append(this.fLiteralData, k, m);
            int i4 = this.fLiteralData.length();
            n = this.fLiteralData.addSymbol(i3, i4 - i3);
            if (paramBoolean2) {
              this.fAttValueIndex = this.fLiteralData.addSymbol(j, i4 - j);
            } else {
              this.fAttValueIndex = this.fLiteralData.addString(j, i4 - j);
            } 
          } else {
            n = this.fReader.addSymbol(k, m);
            if (bool1) {
              this.fAttValueIndex = n;
            } else if (paramBoolean2) {
              this.fAttValueIndex = this.fReader.addSymbol(i, k + m - i);
            } else {
              this.fAttValueIndex = this.fReader.addString(i, k + m - i);
            } 
          } 
        } else if (i2) {
          if (bool2 && !bool6) {
            this.fReader.skipInvalidChar(85);
            this.fReader.skipPastChar(c);
            return false;
          } 
          if (bool5) {
            int i3 = this.fLiteralData.length();
            this.fReader.append(this.fLiteralData, k, m);
            int i4 = this.fLiteralData.length();
            n = this.fLiteralData.addSymbol(i3, i4 - i3);
            this.fLiteralData.append(' ');
          } else if (bool7) {
            if (k - i > 0)
              this.fReader.append(this.fLiteralData, i, k - i); 
            i = -1;
            int i3 = this.fLiteralData.length();
            this.fReader.append(this.fLiteralData, k, m);
            int i4 = this.fLiteralData.length();
            n = this.fLiteralData.addSymbol(i3, i4 - i3);
            this.fLiteralData.append(' ');
            bool5 = true;
          } else {
            n = this.fReader.addSymbol(k, m);
          } 
        } else {
          if (k - i > 0)
            this.fReader.append(this.fLiteralData, i, k - i); 
          i = -1;
          int i3 = this.fLiteralData.length();
          this.fReader.append(this.fLiteralData, k, m);
          if (!scanNormalizedAttValue(c))
            return false; 
          int i4 = this.fLiteralData.addString(i3, this.fLiteralData.length() - i3);
          StringReader stringReader = new StringReader(this.fParserState, false, this.fReader, i4);
          pushReader(stringReader, null);
          bool4 = true;
          this.fLiteralData.setLength(i3);
          k = this.fReader.currentOffset();
          m = (bool3 ? this.fReader.skipPastName(c) : this.fReader.skipPastNmtoken(c)) - k;
          int i5 = this.fLiteralData.length();
          this.fReader.append(this.fLiteralData, k, m);
          int i6 = this.fLiteralData.length();
          i2 = this.fReader.skippedSpace();
          if (i2)
            this.fReader.skipPastSpaces(); 
          bool6 = this.fReader.skippedChar(c);
          if (bool6) {
            n = this.fLiteralData.addSymbol(i5, i6 - i5);
            if (bool1) {
              this.fAttValueIndex = n;
            } else if (paramBoolean2) {
              this.fAttValueIndex = this.fLiteralData.addSymbol(j, i6 - j);
            } else {
              this.fAttValueIndex = this.fLiteralData.addString(j, i6 - j);
            } 
            popReader();
          } else if (i2) {
            if (bool2) {
              this.fReader.skipInvalidChar(85);
              popReader();
              return false;
            } 
            n = this.fLiteralData.addSymbol(i5, i6 - i5);
            this.fLiteralData.append(' ');
            k = this.fReader.currentOffset();
          } else {
            this.fReader.skipInvalidChar(85);
            popReader();
            return false;
          } 
        } 
      } 
      switch (paramInt3) {
        case 1:
          if (this.fValidationHandler != null && !this.fElementDeclPool.addId(n, paramInt1)) {
            this.fErrorHandler.error1(129, n);
            return false;
          } 
          return true;
        case 2:
        case 3:
          if (paramInt1 != -1 && this.fValidationHandler != null)
            this.fElementDeclPool.addIdRef(n, paramInt1); 
          if (bool6)
            return true; 
          break;
        case 4:
        case 5:
          i1 = this.fEntityPool.lookupEntity(n);
          if (i1 == -1 || !this.fEntityPool.isUnparsed(i1)) {
            this.fErrorHandler.error1(131, n);
            if (!bool6)
              this.fReader.skipPastChar(c); 
            return false;
          } 
          if (bool6)
            return true; 
          break;
        case 6:
        case 7:
          if (bool6)
            return true; 
          break;
        case 8:
        case 9:
          if (paramInt1 == -1) {
            i2 = this.fAttDef.enumeration;
          } else {
            int i3 = this.fElementDeclPool.getAttDef(paramInt1, paramInt2);
            i2 = this.fElementDeclPool.getEnumeration(i3);
          } 
          if (!this.fStringPool.stringInList(i2, n)) {
            int[] arrayOfInt = this.fStringPool.stringsInList(i2);
            StringBuffer stringBuffer = new StringBuffer();
            int i3 = arrayOfInt.length;
            for (byte b = 0; b < i3; b++) {
              stringBuffer.append(this.fStringPool.toString(arrayOfInt[b]));
              if (b < i3 - 1)
                stringBuffer.append(","); 
            } 
            int i4 = this.fStringPool.addSymbol(stringBuffer.toString());
            this.fErrorHandler.error2(161, n, i4);
            return false;
          } 
          return true;
      } 
      bool1 = false;
    } 
  }
  
  private int referenceInEntityValue(int paramInt, boolean paramBoolean) throws Exception {
    if (this.fReader.skippedChar('#')) {
      int k = scanCharRef();
      if (k == -1)
        return this.fReader.currentOffset(); 
      if (paramBoolean)
        if (k < 65536) {
          this.fLiteralData.append((char)k);
        } else {
          this.fLiteralData.append((char)((k - 65536 >> 10) + 55296));
          this.fLiteralData.append((char)((k - 65536 & 0x3FF) + 56320));
        }  
      return this.fReader.currentOffset();
    } 
    int i = this.fReader.currentOffset();
    int j = this.fReader.skipPastName(';') - i;
    if (j == 0) {
      this.fReader.skipInvalidChar(110);
      return this.fReader.currentOffset();
    } 
    if (!this.fReader.skippedChar(';')) {
      this.fErrorHandler.error(111);
      return this.fReader.currentOffset();
    } 
    if (paramBoolean)
      this.fReader.append(this.fLiteralData, paramInt, this.fReader.currentOffset() - paramInt); 
    return this.fReader.currentOffset();
  }
  
  private boolean referenceInContent(int paramInt) throws Exception {
    if (this.fReader.skippedChar('#')) {
      int i2 = scanCharRef();
      if (i2 == -1)
        return false; 
      if (this.fDocumentHandler != null) {
        if (this.fCharRefData == null)
          this.fCharRefData = new char[2]; 
        byte b = (i2 < 65536) ? 1 : 2;
        if (b == 1) {
          this.fCharRefData[0] = (char)i2;
        } else {
          this.fCharRefData[0] = (char)((i2 - 65536 >> 10) + 55296);
          this.fCharRefData[1] = (char)((i2 - 65536 & 0x3FF) + 56320);
        } 
        if (!this.fDocumentHandler.sendCharDataAsCharArray()) {
          int i3 = this.fStringPool.addString(new String(this.fCharRefData, 0, b));
          this.fDocumentHandler.characters(i3, false);
        } else {
          this.fDocumentHandler.characters(this.fCharRefData, 0, b, false);
        } 
      } 
      return true;
    } 
    int i = this.fReader.currentOffset();
    int j = this.fReader.skipPastName(';') - i;
    if (j == 0) {
      this.fReader.skipInvalidChar(110);
      return false;
    } 
    if (!this.fReader.skippedChar(';')) {
      this.fErrorHandler.error(111);
      return false;
    } 
    int k = this.fReader.addSymbol(i, j);
    int m = this.fEntityPool.lookupEntity(k);
    if (m < 0) {
      this.fErrorHandler.error1(60, k);
      return false;
    } 
    if (this.fEntityPool.isUnparsed(m)) {
      this.fErrorHandler.error1(62, k);
      return false;
    } 
    if (!pushEntity((byte)0, k))
      return false; 
    if (this.fDocumentHandler != null)
      this.fDocumentHandler.startEntityReference(m); 
    XMLReader xMLReader = null;
    InputSource inputSource = null;
    if (this.fEntityPool.isExternal(m)) {
      int i2 = this.fEntityPool.getPublicId(m);
      int i3 = this.fEntityPool.getSystemId(m);
      i3 = this.fEntityHandler.expandSystemId(i3);
      inputSource = this.fEntityHandler.resolveEntity(i2, i3);
      if (inputSource == null) {
        inputSource = new InputSource(this.fStringPool.toString(i3));
        if (i2 != -1)
          inputSource.setPublicId(this.fStringPool.toString(i2)); 
      } 
      xMLReader = this.fEntityHandler.createReader(inputSource, false);
      this.fEntityHandler.startInputSource(inputSource);
    } else {
      xMLReader = new StringReader(this.fParserState, false, this.fReader, this.fEntityPool.getEntityValue(m));
    } 
    int n = pushReader(xMLReader, inputSource);
    int i1 = setActiveReaderLimit(n);
    try {
      ScanContentState scanContentState = new ScanContentState();
      scanContentState.inCDSect = false;
      scanContentState.extParsedEnt = true;
      scanContentState.parseTextDecl = this.fReader.lookingAtChar('<');
      scanContentState.elementDepth = this.fElementDepth;
      scanContent(scanContentState);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
    
    } catch (StopException stopException) {
      throw stopException;
    } catch (Exception exception) {
      throw exception;
    } 
    setActiveReaderLimit(i1);
    popReader();
    if (this.fDocumentHandler != null)
      this.fDocumentHandler.endEntityReference(m); 
    this.fEntityStackDepth--;
    return true;
  }
  
  private int scanCharRef() {
    boolean bool = this.fReader.skippedChar('x');
    int i = this.fReader.currentOffset();
    int j = 0;
    int k = 0;
    if (bool) {
      int n = this.fReader.skipHexDigit();
      if (n < 0) {
        if (this.fReader.skippedChar(';')) {
          this.fErrorHandler.error(112);
        } else {
          this.fReader.skipInvalidChar(110);
        } 
        return -1;
      } 
      k = n;
      while (true) {
        n = this.fReader.skipHexDigit();
        if (n >= 0) {
          k = (k << 4) + n;
          if (k > 1114111) {
            this.fReader.skipToChar(';');
            break;
          } 
          continue;
        } 
        break;
      } 
    } else {
      int n = this.fReader.skipDecimalDigit();
      if (n < 0) {
        if (this.fReader.skippedChar(';')) {
          this.fErrorHandler.error(112);
        } else {
          this.fReader.skipInvalidChar(110);
        } 
        return -1;
      } 
      k = n;
      while (true) {
        n = this.fReader.skipDecimalDigit();
        if (n >= 0) {
          k = k * 10 + n;
          if (k > 1114111) {
            this.fReader.skipToChar(';');
            break;
          } 
          continue;
        } 
        break;
      } 
    } 
    j = this.fReader.currentOffset() - i;
    if (!this.fReader.skippedChar(';')) {
      this.fErrorHandler.error(111);
      return -1;
    } 
    if (k < 32) {
      if (k == 9 || k == 10 || k == 13)
        return k; 
    } else if (k <= 55295 || (k >= 57344 && (k <= 65533 || (k >= 65536 && k <= 1114111)))) {
      return k;
    } 
    byte b = bool ? 113 : 114;
    int m = this.fReader.addString(i, j);
    this.fErrorHandler.error1(b, m);
    return -1;
  }
  
  private void scanMisc() {
    while (true) {
      while (this.fReader.skippedChar('<')) {
        this.fScannerMarkupDepth++;
        if (this.fReader.skippedChar('?')) {
          int i = this.fReader.scanName(' ', -1);
          if (i == -1) {
            this.fErrorHandler.error(102);
            this.fReader.skipPastChar('>');
            this.fScannerMarkupDepth--;
            continue;
          } 
          if ("xml".equals(this.fStringPool.toString(i))) {
            if (this.fReader.skippedSpace()) {
              this.fErrorHandler.error(117);
            } else {
              this.fErrorHandler.error(107);
            } 
            this.fReader.skipPastChar('>');
            this.fScannerMarkupDepth--;
            continue;
          } 
          scanPI(i, true);
          continue;
        } 
        if (this.fReader.skippedChar('!')) {
          if (this.fReader.skippedChar('-')) {
            if (this.fReader.skippedChar('-')) {
              scanComment(true);
              continue;
            } 
            this.fErrorHandler.error(20);
            this.fReader.skipPastChar('>');
            this.fScannerMarkupDepth--;
            continue;
          } 
          this.fErrorHandler.error(116);
          this.fReader.skipPastChar('>');
          this.fScannerMarkupDepth--;
          continue;
        } 
        this.fErrorHandler.error(116);
        this.fReader.skipToChar('<');
        this.fScannerMarkupDepth--;
      } 
      if (this.fReader.skippedSpace()) {
        this.fReader.skipPastSpaces();
        continue;
      } 
      if (!this.fReader.lookingAtValidChar()) {
        this.fReader.skipInvalidChar(85);
        continue;
      } 
      this.fErrorHandler.error(116);
      this.fReader.skipToChar('<');
    } 
  }
  
  private void scanPI(int paramInt, boolean paramBoolean) throws Exception {
    String str = this.fStringPool.toString(paramInt);
    if (str.length() == 3 && (str.charAt(0) == 'X' || str.charAt(0) == 'x') && (str.charAt(1) == 'M' || str.charAt(1) == 'm') && (str.charAt(2) == 'L' || str.charAt(2) == 'l')) {
      this.fErrorHandler.error(107);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    if (!this.fReader.skippedSpace()) {
      if (!this.fReader.skippedChar('?')) {
        this.fErrorHandler.error(105);
        this.fReader.skipPastChar('>');
        this.fScannerMarkupDepth--;
        return;
      } 
      if (!this.fReader.skippedChar('>')) {
        this.fErrorHandler.error(105);
        this.fReader.skipPastChar('>');
        this.fScannerMarkupDepth--;
        return;
      } 
      this.fScannerMarkupDepth--;
      if (paramBoolean && this.fDocumentHandler != null)
        this.fDocumentHandler.processingInstruction(paramInt, -1); 
      return;
    } 
    int i = this.fReader.skipPastSpaces();
    try {
      while (true) {
        while (!this.fReader.lookingAtChar('?')) {
          if (!this.fReader.skippedValidChar()) {
            this.fReader.skipInvalidChar(85);
            this.fReader.skipPastChar('>');
            this.fScannerMarkupDepth--;
            return;
          } 
        } 
        int j = this.fReader.currentOffset();
        this.fReader.skipAsciiChar();
        if (this.fReader.skippedChar('>')) {
          this.fScannerMarkupDepth--;
          if (paramBoolean && this.fDocumentHandler != null) {
            int k = -1;
            if (j != i)
              k = this.fReader.addString(i, j - i); 
            this.fDocumentHandler.processingInstruction(paramInt, k);
          } 
          return;
        } 
      } 
      this.fReader.skipInvalidChar(85);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      if (!((this.fEntityStackDepth == 0) ? 0 : this.fEntityNameStack[this.fEntityStackDepth - 1])) {
        this.fErrorHandler.error(105);
        throw arrayIndexOutOfBoundsException;
      } 
      return;
    } 
  }
  
  private void scanDoctypeDecl() {
    boolean bool1;
    if (!this.fReader.skippedSpace()) {
      this.fErrorHandler.error(115);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    this.fReader.skipPastSpaces();
    int i = this.fReader.scanName(' ', -1);
    if (i == -1) {
      this.fErrorHandler.error(40);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    int j = this.fElementDeclPool.addElement(i);
    this.fElementDeclPool.setRootElement(j);
    if (this.fDocumentTypeHandler != null)
      this.fDocumentTypeHandler.doctypeDecl(i); 
    boolean bool2 = false;
    int k = -1;
    int m = -1;
    if (this.fReader.skippedSpace()) {
      this.fReader.skipPastSpaces();
      if (!(bool1 = this.fReader.skippedChar('[')) && !this.fReader.lookingAtChar('>')) {
        bool2 = true;
        if (!scanExternalIDorPublicID(bool2, false)) {
          this.fReader.skipPastChar('>');
          this.fScannerMarkupDepth--;
          return;
        } 
        k = this.fPubidLiteral;
        m = this.fSystemLiteral;
        this.fReader.skipPastSpaces();
        bool1 = this.fReader.skippedChar('[');
      } 
    } else {
      bool1 = this.fReader.skippedChar('[');
    } 
    if (bool1) {
      if (!scanIntSubsetDecl()) {
        this.fReader.skipPastChar('>');
        this.fScannerMarkupDepth--;
        return;
      } 
      this.fReader.skipPastSpaces();
    } 
    if (!this.fReader.skippedChar('>')) {
      this.fErrorHandler.error(125);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    this.fScannerMarkupDepth--;
    if (bool2) {
      if (this.fDocumentTypeHandler != null)
        this.fDocumentTypeHandler.startExternalSubset(k, m); 
      int n = this.fScannerState;
      this.fScannerState = 3;
      m = this.fEntityHandler.expandSystemId(m);
      InputSource inputSource = this.fEntityHandler.resolveEntity(k, m);
      if (inputSource == null) {
        inputSource = new InputSource(this.fStringPool.toString(m));
        if (k != -1)
          inputSource.setPublicId(this.fStringPool.toString(k)); 
      } 
      XMLReader xMLReader = this.fEntityHandler.createReader(inputSource, false);
      this.fEntityHandler.startInputSource(inputSource);
      int i1 = pushReader(xMLReader, inputSource);
      int i2 = setActiveReaderLimit(i1);
      try {
        scanExtSubsetDecl(false);
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      
      } catch (StopException stopException) {
        throw stopException;
      } catch (Exception exception) {
        throw exception;
      } 
      setActiveReaderLimit(i2);
      popReader();
      this.fScannerState = n;
      if (this.fDocumentTypeHandler != null)
        this.fDocumentTypeHandler.endExternalSubset(); 
    } 
    if (this.fParserState.getValidationHandler() != null)
      this.fElementDeclPool.checkDeclaredElements(); 
  }
  
  private boolean scanIntSubsetDecl() throws Exception {
    if (this.fDocumentTypeHandler != null)
      this.fDocumentTypeHandler.startInternalSubset(); 
    boolean bool = true;
    int i = this.fScannerState;
    this.fScannerState = 2;
    while (!this.fReader.skippedChar(']')) {
      if (this.fReader.skippedChar('<')) {
        scanMarkupDecl(false);
        continue;
      } 
      if (this.fReader.skippedSpace()) {
        this.fReader.skipPastSpaces();
        continue;
      } 
      if (this.fReader.skippedChar('%')) {
        scanPEReference();
        continue;
      } 
      if (this.fReader.lookingAtChar('>')) {
        this.fReader.skipInvalidChar(43);
        return false;
      } 
      this.fReader.lookingAtValidChar();
      this.fReader.skipInvalidChar(43);
      bool = false;
      do {
        this.fReader.skipOneChar();
      } while (!this.fReader.lookingAtChar('%') && !this.fReader.lookingAtChar('<') && !this.fReader.lookingAtSpace() && !this.fReader.lookingAtChar(']'));
    } 
    this.fScannerState = i;
    if (this.fDocumentTypeHandler != null)
      this.fDocumentTypeHandler.endInternalSubset(); 
    return bool;
  }
  
  private void scanTextDecl() { // Byte code:
    //   0: aload_0
    //   1: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   4: invokevirtual skipPastSpaces : ()I
    //   7: istore_3
    //   8: aload_0
    //   9: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   12: getstatic com/ibm/xml/internal/DefaultScanner.version_string : [C
    //   15: invokevirtual skippedString : ([C)Z
    //   18: ifeq -> 443
    //   21: aload_0
    //   22: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   25: invokevirtual currentOffset : ()I
    //   28: iload_3
    //   29: isub
    //   30: istore #5
    //   32: aload_0
    //   33: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   36: invokevirtual skipPastSpaces : ()I
    //   39: pop
    //   40: aload_0
    //   41: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   44: bipush #61
    //   46: invokevirtual skippedChar : (C)Z
    //   49: ifeq -> 64
    //   52: aload_0
    //   53: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   56: invokevirtual skipPastSpaces : ()I
    //   59: pop
    //   60: iconst_1
    //   61: ifne -> 110
    //   64: aload_0
    //   65: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   68: iload_3
    //   69: iload #5
    //   71: invokevirtual addString : (II)I
    //   74: istore #6
    //   76: aload_0
    //   77: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   80: bipush #8
    //   82: iload #6
    //   84: invokeinterface error1 : (II)V
    //   89: aload_0
    //   90: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   93: bipush #62
    //   95: invokevirtual skipPastChar : (C)I
    //   98: pop
    //   99: aload_0
    //   100: dup
    //   101: getfield fScannerMarkupDepth : I
    //   104: iconst_1
    //   105: isub
    //   106: putfield fScannerMarkupDepth : I
    //   109: return
    //   110: aload_0
    //   111: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   114: bipush #39
    //   116: invokevirtual skippedChar : (C)Z
    //   119: dup
    //   120: istore_1
    //   121: ifne -> 168
    //   124: aload_0
    //   125: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   128: bipush #34
    //   130: invokevirtual skippedChar : (C)Z
    //   133: ifne -> 168
    //   136: aload_0
    //   137: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   140: bipush #16
    //   142: invokeinterface error : (I)V
    //   147: aload_0
    //   148: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   151: bipush #62
    //   153: invokevirtual skipPastChar : (C)I
    //   156: pop
    //   157: aload_0
    //   158: dup
    //   159: getfield fScannerMarkupDepth : I
    //   162: iconst_1
    //   163: isub
    //   164: putfield fScannerMarkupDepth : I
    //   167: return
    //   168: aload_0
    //   169: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   172: invokevirtual currentOffset : ()I
    //   175: istore #6
    //   177: iload_1
    //   178: ifeq -> 186
    //   181: bipush #39
    //   183: goto -> 188
    //   186: bipush #34
    //   188: istore_2
    //   189: goto -> 318
    //   192: aload_0
    //   193: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   196: invokevirtual skippedVersionNum : ()Z
    //   199: ifne -> 318
    //   202: goto -> 213
    //   205: aload_0
    //   206: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   209: invokevirtual skipOneChar : ()I
    //   212: pop
    //   213: aload_0
    //   214: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   217: iload_2
    //   218: invokevirtual lookingAtChar : (C)Z
    //   221: ifne -> 236
    //   224: aload_0
    //   225: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   228: bipush #60
    //   230: invokevirtual lookingAtChar : (C)Z
    //   233: ifeq -> 205
    //   236: aload_0
    //   237: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   240: bipush #60
    //   242: invokevirtual lookingAtChar : (C)Z
    //   245: ifeq -> 262
    //   248: aload_0
    //   249: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   252: bipush #17
    //   254: invokeinterface error : (I)V
    //   259: goto -> 297
    //   262: aload_0
    //   263: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   266: iload #6
    //   268: aload_0
    //   269: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   272: invokevirtual currentOffset : ()I
    //   275: iload #6
    //   277: isub
    //   278: invokevirtual addString : (II)I
    //   281: istore #7
    //   283: aload_0
    //   284: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   287: sipush #151
    //   290: iload #7
    //   292: invokeinterface error1 : (II)V
    //   297: aload_0
    //   298: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   301: bipush #62
    //   303: invokevirtual skipPastChar : (C)I
    //   306: pop
    //   307: aload_0
    //   308: dup
    //   309: getfield fScannerMarkupDepth : I
    //   312: iconst_1
    //   313: isub
    //   314: putfield fScannerMarkupDepth : I
    //   317: return
    //   318: aload_0
    //   319: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   322: iload_2
    //   323: invokevirtual lookingAtChar : (C)Z
    //   326: ifeq -> 192
    //   329: aload_0
    //   330: getfield fStringPool : Lcom/ibm/xml/framework/StringPool;
    //   333: aload_0
    //   334: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   337: iload #6
    //   339: aload_0
    //   340: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   343: invokevirtual currentOffset : ()I
    //   346: iload #6
    //   348: isub
    //   349: invokevirtual addString : (II)I
    //   352: invokeinterface orphanString : (I)Ljava/lang/String;
    //   357: astore #7
    //   359: ldc '1.0'
    //   361: aload #7
    //   363: invokevirtual equals : (Ljava/lang/Object;)Z
    //   366: ifne -> 381
    //   369: aload_0
    //   370: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   373: sipush #149
    //   376: invokeinterface error : (I)V
    //   381: aload_0
    //   382: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   385: invokevirtual skipAsciiChar : ()I
    //   388: pop
    //   389: aload_0
    //   390: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   393: invokevirtual skippedSpace : ()Z
    //   396: ifne -> 431
    //   399: aload_0
    //   400: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   403: bipush #115
    //   405: invokeinterface error : (I)V
    //   410: aload_0
    //   411: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   414: bipush #62
    //   416: invokevirtual skipPastChar : (C)I
    //   419: pop
    //   420: aload_0
    //   421: dup
    //   422: getfield fScannerMarkupDepth : I
    //   425: iconst_1
    //   426: isub
    //   427: putfield fScannerMarkupDepth : I
    //   430: return
    //   431: aload_0
    //   432: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   435: invokevirtual skipPastSpaces : ()I
    //   438: istore #4
    //   440: goto -> 446
    //   443: iload_3
    //   444: istore #4
    //   446: aload_0
    //   447: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   450: getstatic com/ibm/xml/internal/DefaultScanner.encoding_string : [C
    //   453: invokevirtual skippedString : ([C)Z
    //   456: ifne -> 491
    //   459: aload_0
    //   460: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   463: bipush #109
    //   465: invokeinterface error : (I)V
    //   470: aload_0
    //   471: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   474: bipush #62
    //   476: invokevirtual skipPastChar : (C)I
    //   479: pop
    //   480: aload_0
    //   481: dup
    //   482: getfield fScannerMarkupDepth : I
    //   485: iconst_1
    //   486: isub
    //   487: putfield fScannerMarkupDepth : I
    //   490: return
    //   491: aload_0
    //   492: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   495: invokevirtual currentOffset : ()I
    //   498: iload #4
    //   500: isub
    //   501: istore #5
    //   503: aload_0
    //   504: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   507: invokevirtual skipPastSpaces : ()I
    //   510: pop
    //   511: aload_0
    //   512: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   515: bipush #61
    //   517: invokevirtual skippedChar : (C)Z
    //   520: ifeq -> 535
    //   523: aload_0
    //   524: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   527: invokevirtual skipPastSpaces : ()I
    //   530: pop
    //   531: iconst_1
    //   532: ifne -> 582
    //   535: aload_0
    //   536: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   539: iload #4
    //   541: iload #5
    //   543: invokevirtual addString : (II)I
    //   546: istore #6
    //   548: aload_0
    //   549: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   552: bipush #8
    //   554: iload #6
    //   556: invokeinterface error1 : (II)V
    //   561: aload_0
    //   562: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   565: bipush #62
    //   567: invokevirtual skipPastChar : (C)I
    //   570: pop
    //   571: aload_0
    //   572: dup
    //   573: getfield fScannerMarkupDepth : I
    //   576: iconst_1
    //   577: isub
    //   578: putfield fScannerMarkupDepth : I
    //   581: return
    //   582: aload_0
    //   583: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   586: bipush #39
    //   588: invokevirtual skippedChar : (C)Z
    //   591: dup
    //   592: istore_1
    //   593: ifne -> 640
    //   596: aload_0
    //   597: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   600: bipush #34
    //   602: invokevirtual skippedChar : (C)Z
    //   605: ifne -> 640
    //   608: aload_0
    //   609: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   612: bipush #16
    //   614: invokeinterface error : (I)V
    //   619: aload_0
    //   620: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   623: bipush #62
    //   625: invokevirtual skipPastChar : (C)I
    //   628: pop
    //   629: aload_0
    //   630: dup
    //   631: getfield fScannerMarkupDepth : I
    //   634: iconst_1
    //   635: isub
    //   636: putfield fScannerMarkupDepth : I
    //   639: return
    //   640: aload_0
    //   641: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   644: invokevirtual currentOffset : ()I
    //   647: istore #6
    //   649: iload_1
    //   650: ifeq -> 658
    //   653: bipush #39
    //   655: goto -> 660
    //   658: bipush #34
    //   660: istore_2
    //   661: aload_0
    //   662: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   665: invokevirtual skippedAlpha : ()Z
    //   668: ifne -> 911
    //   671: goto -> 682
    //   674: aload_0
    //   675: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   678: invokevirtual skipOneChar : ()I
    //   681: pop
    //   682: aload_0
    //   683: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   686: iload_2
    //   687: invokevirtual lookingAtChar : (C)Z
    //   690: ifne -> 705
    //   693: aload_0
    //   694: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   697: bipush #60
    //   699: invokevirtual lookingAtChar : (C)Z
    //   702: ifeq -> 674
    //   705: aload_0
    //   706: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   709: bipush #60
    //   711: invokevirtual lookingAtChar : (C)Z
    //   714: ifeq -> 731
    //   717: aload_0
    //   718: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   721: bipush #17
    //   723: invokeinterface error : (I)V
    //   728: goto -> 765
    //   731: aload_0
    //   732: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   735: iload #6
    //   737: aload_0
    //   738: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   741: invokevirtual currentOffset : ()I
    //   744: iload #6
    //   746: isub
    //   747: invokevirtual addString : (II)I
    //   750: istore #7
    //   752: aload_0
    //   753: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   756: bipush #106
    //   758: iload #7
    //   760: invokeinterface error1 : (II)V
    //   765: aload_0
    //   766: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   769: bipush #62
    //   771: invokevirtual skipPastChar : (C)I
    //   774: pop
    //   775: aload_0
    //   776: dup
    //   777: getfield fScannerMarkupDepth : I
    //   780: iconst_1
    //   781: isub
    //   782: putfield fScannerMarkupDepth : I
    //   785: return
    //   786: aload_0
    //   787: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   790: invokevirtual skippedEncName : ()Z
    //   793: ifne -> 911
    //   796: goto -> 807
    //   799: aload_0
    //   800: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   803: invokevirtual skipOneChar : ()I
    //   806: pop
    //   807: aload_0
    //   808: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   811: iload_2
    //   812: invokevirtual lookingAtChar : (C)Z
    //   815: ifne -> 830
    //   818: aload_0
    //   819: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   822: bipush #60
    //   824: invokevirtual lookingAtChar : (C)Z
    //   827: ifeq -> 799
    //   830: aload_0
    //   831: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   834: bipush #60
    //   836: invokevirtual lookingAtChar : (C)Z
    //   839: ifeq -> 856
    //   842: aload_0
    //   843: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   846: bipush #17
    //   848: invokeinterface error : (I)V
    //   853: goto -> 890
    //   856: aload_0
    //   857: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   860: iload #6
    //   862: aload_0
    //   863: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   866: invokevirtual currentOffset : ()I
    //   869: iload #6
    //   871: isub
    //   872: invokevirtual addString : (II)I
    //   875: istore #7
    //   877: aload_0
    //   878: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   881: bipush #106
    //   883: iload #7
    //   885: invokeinterface error1 : (II)V
    //   890: aload_0
    //   891: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   894: bipush #62
    //   896: invokevirtual skipPastChar : (C)I
    //   899: pop
    //   900: aload_0
    //   901: dup
    //   902: getfield fScannerMarkupDepth : I
    //   905: iconst_1
    //   906: isub
    //   907: putfield fScannerMarkupDepth : I
    //   910: return
    //   911: aload_0
    //   912: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   915: iload_2
    //   916: invokevirtual lookingAtChar : (C)Z
    //   919: ifeq -> 786
    //   922: aload_0
    //   923: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   926: invokevirtual skipAsciiChar : ()I
    //   929: pop
    //   930: aload_0
    //   931: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   934: invokevirtual skipPastSpaces : ()I
    //   937: pop
    //   938: aload_0
    //   939: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   942: bipush #63
    //   944: invokevirtual skippedChar : (C)Z
    //   947: ifne -> 982
    //   950: aload_0
    //   951: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   954: bipush #105
    //   956: invokeinterface error : (I)V
    //   961: aload_0
    //   962: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   965: bipush #62
    //   967: invokevirtual skipPastChar : (C)I
    //   970: pop
    //   971: aload_0
    //   972: dup
    //   973: getfield fScannerMarkupDepth : I
    //   976: iconst_1
    //   977: isub
    //   978: putfield fScannerMarkupDepth : I
    //   981: return
    //   982: aload_0
    //   983: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   986: bipush #62
    //   988: invokevirtual skippedChar : (C)Z
    //   991: ifne -> 1026
    //   994: aload_0
    //   995: getfield fErrorHandler : Lcom/ibm/xml/framework/XMLErrorHandler;
    //   998: bipush #105
    //   1000: invokeinterface error : (I)V
    //   1005: aload_0
    //   1006: getfield fReader : Lcom/ibm/xml/framework/XMLReader;
    //   1009: bipush #62
    //   1011: invokevirtual skipPastChar : (C)I
    //   1014: pop
    //   1015: aload_0
    //   1016: dup
    //   1017: getfield fScannerMarkupDepth : I
    //   1020: iconst_1
    //   1021: isub
    //   1022: putfield fScannerMarkupDepth : I
    //   1025: return
    //   1026: aload_0
    //   1027: dup
    //   1028: getfield fScannerMarkupDepth : I
    //   1031: iconst_1
    //   1032: isub
    //   1033: putfield fScannerMarkupDepth : I
    //   1036: return }
  
  private void scanExtSubsetDecl(boolean paramBoolean) throws Exception {
    boolean bool = !paramBoolean;
    try {
      while (true) {
        if (checkSkippedChar('<', false)) {
          scanMarkupDecl(bool);
        } else if (checkSkippedSpace()) {
          checkSkipPastSpaces();
        } else if (checkSkippedChar('%', false)) {
          scanPEReference();
        } else {
          if (paramBoolean && checkSkippedChar(']', false)) {
            if (!checkSkippedChar(']', false)) {
              this.fErrorHandler.error(24);
              this.fReader.skipPastChar('>');
              this.fScannerMarkupDepth--;
              return;
            } 
            if (!checkSkippedChar('>', false)) {
              this.fErrorHandler.error(24);
              this.fReader.skipPastChar('>');
              this.fScannerMarkupDepth--;
              return;
            } 
            this.fScannerMarkupDepth--;
            return;
          } 
          if (!this.fReader.lookingAtValidChar()) {
            this.fReader.skipInvalidChar(85);
          } else {
            this.fErrorHandler.error(116);
          } 
          do {
            this.fReader.skipOneChar();
          } while (!this.fReader.lookingAtChar('%') && !this.fReader.lookingAtChar('<') && (!paramBoolean || !this.fReader.lookingAtChar(']')));
        } 
        bool = false;
      } 
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      if (paramBoolean)
        this.fErrorHandler.error(24); 
      throw arrayIndexOutOfBoundsException;
    } 
  }
  
  private boolean scanExternalID(boolean paramBoolean) throws Exception { return scanExternalIDorPublicID(paramBoolean, false); }
  
  private boolean scanExternalIDorPublicID(boolean paramBoolean) throws Exception { return scanExternalIDorPublicID(paramBoolean, true); }
  
  private boolean scanExternalIDorPublicID(boolean paramBoolean1, boolean paramBoolean2) throws Exception {
    this.fSystemLiteral = -1;
    this.fPubidLiteral = -1;
    int i = this.fReader.currentOffset();
    if (this.fReader.skippedString(system_string)) {
      if (!this.fReader.skippedSpace()) {
        this.fErrorHandler.error(115);
        return false;
      } 
      this.fReader.skipPastSpaces();
      return scanSystemLiteral(paramBoolean1);
    } 
    if (this.fReader.skippedString(public_string)) {
      if (!this.fReader.skippedSpace()) {
        this.fErrorHandler.error(115);
        return false;
      } 
      this.fReader.skipPastSpaces();
      if (!scanPubidLiteral(paramBoolean1))
        return false; 
      if (paramBoolean2) {
        if (!this.fReader.skippedSpace())
          return true; 
        this.fReader.skipPastSpaces();
        if (this.fReader.lookingAtChar('>'))
          return true; 
      } else {
        if (!this.fReader.skippedSpace()) {
          this.fErrorHandler.error(115);
          return false;
        } 
        this.fReader.skipPastSpaces();
      } 
      return scanSystemLiteral(paramBoolean1);
    } 
    int j = this.fReader.skipPastNmtoken(' ') - i;
    int k = this.fReader.addString(i, j);
    this.fErrorHandler.error1(41, k);
    return false;
  }
  
  private boolean scanSystemLiteral(boolean paramBoolean) throws Exception {
    boolean bool;
    if (!(bool = this.fReader.skippedChar('\'')) && !this.fReader.skippedChar('"')) {
      this.fErrorHandler.error(81);
      return false;
    } 
    int i = this.fReader.currentOffset();
    char c = bool ? '\'' : '"';
    while (!this.fReader.lookingAtChar(c)) {
      if (!this.fReader.skippedValidChar()) {
        this.fReader.skipInvalidChar(82);
        this.fReader.skipPastChar(c);
        return false;
      } 
    } 
    if (paramBoolean)
      this.fSystemLiteral = this.fReader.addString(i, this.fReader.currentOffset() - i); 
    this.fReader.skipAsciiChar();
    return true;
  }
  
  private boolean scanPubidLiteral(boolean paramBoolean) throws Exception {
    boolean bool;
    if (!(bool = this.fReader.skippedChar('\'')) && !this.fReader.skippedChar('"')) {
      this.fErrorHandler.error(79);
      return false;
    } 
    char c = bool ? '\'' : '"';
    int i = this.fReader.skipPastSpaces();
    int j = paramBoolean ? this.fLiteralData.length() : 0;
    int k = i;
    while (true) {
      if (this.fReader.skippedChar(c)) {
        if (paramBoolean && i - k > 0)
          this.fReader.append(this.fLiteralData, k, i - k); 
        break;
      } 
      if (this.fReader.skippedSpace()) {
        if (paramBoolean && i - k > 0)
          this.fReader.append(this.fLiteralData, k, i - k); 
        i = this.fReader.skipPastSpaces();
        k = i;
        if (!this.fReader.skippedChar(c)) {
          if (paramBoolean)
            this.fLiteralData.append(' '); 
        } else {
          break;
        } 
      } 
      if (!this.fReader.skippedPubidChar()) {
        this.fReader.skipInvalidChar(80);
        this.fReader.skipPastChar(c);
        return false;
      } 
      i = this.fReader.currentOffset();
    } 
    if (paramBoolean) {
      int m = this.fLiteralData.length() - j;
      this.fPubidLiteral = this.fLiteralData.addString(j, m);
    } 
    return true;
  }
  
  private void scanPEReference() {
    int i = this.fReader.currentOffset();
    int j = this.fReader.skipPastName(';') - i;
    if (j == 0) {
      this.fErrorHandler.error(92);
      return;
    } 
    if (!this.fReader.skippedChar(';')) {
      int i1 = this.fReader.addString(i, j);
      this.fErrorHandler.error1(93, i1);
      return;
    } 
    int k = this.fReader.addSymbol(i, j);
    byte b = (this.fParameterEntityPool == null) ? -1 : this.fParameterEntityPool.lookupEntity(k);
    if (b < 0) {
      this.fErrorHandler.error1(94, k);
      return;
    } 
    if (!pushEntity((byte)1, k))
      return; 
    XMLReader xMLReader = null;
    InputSource inputSource = null;
    if (this.fParameterEntityPool.isExternal(b)) {
      int i1 = this.fParameterEntityPool.getPublicId(b);
      int i2 = this.fParameterEntityPool.getSystemId(b);
      i2 = this.fEntityHandler.expandSystemId(i2);
      inputSource = this.fEntityHandler.resolveEntity(i1, i2);
      if (inputSource == null) {
        inputSource = new InputSource(this.fStringPool.toString(i2));
        if (i1 != -1)
          inputSource.setPublicId(this.fStringPool.toString(i1)); 
      } 
      xMLReader = this.fEntityHandler.createReader(inputSource, false);
      this.fEntityHandler.startInputSource(inputSource);
    } else {
      xMLReader = new StringReader(this.fParserState, true, this.fReader, this.fParameterEntityPool.getEntityValue(b));
    } 
    int m = pushReader(xMLReader, inputSource);
    int n = setActiveReaderLimit(m);
    try {
      scanExtSubsetDecl(false);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
    
    } catch (StopException stopException) {
      throw stopException;
    } catch (Exception exception) {
      throw exception;
    } 
    setActiveReaderLimit(n);
    popReader();
    this.fEntityStackDepth--;
  }
  
  private boolean copyPEReference() throws Exception {
    int i = this.fReader.currentOffset();
    int j = this.fReader.skipPastName(';') - i;
    if (j == 0) {
      this.fErrorHandler.error(92);
      return false;
    } 
    if (!this.fReader.skippedChar(';')) {
      int i4 = this.fReader.addString(i, j);
      this.fErrorHandler.error1(93, i4);
      return false;
    } 
    int k = this.fReader.addSymbol(i, j);
    byte b = (this.fParameterEntityPool == null) ? -1 : this.fParameterEntityPool.lookupEntity(k);
    if (b < 0) {
      this.fErrorHandler.error1(94, k);
      return false;
    } 
    if (!this.fParameterEntityPool.isExternal(b)) {
      this.fLiteralData.append(this.fStringPool.toString(this.fParameterEntityPool.getEntityValue(b)));
      return true;
    } 
    if (!pushEntity((byte)1, k))
      return false; 
    int m = this.fParameterEntityPool.getPublicId(b);
    int n = this.fParameterEntityPool.getSystemId(b);
    n = this.fEntityHandler.expandSystemId(n);
    InputSource inputSource = this.fEntityHandler.resolveEntity(m, n);
    if (inputSource == null) {
      inputSource = new InputSource(this.fStringPool.toString(n));
      if (m != -1)
        inputSource.setPublicId(this.fStringPool.toString(m)); 
    } 
    XMLReader xMLReader = this.fEntityHandler.createReader(inputSource, false);
    this.fEntityHandler.startInputSource(inputSource);
    int i1 = pushReader(xMLReader, inputSource);
    int i2 = setActiveReaderLimit(i1);
    int i3 = this.fReader.currentOffset();
    boolean bool = true;
    try {
      do {
      
      } while (this.fReader.skippedValidChar());
      this.fReader.skipInvalidChar(63);
      bool = false;
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
    
    } catch (StopException stopException) {
      throw stopException;
    } catch (Exception exception) {
      throw exception;
    } 
    if (bool)
      this.fReader.append(this.fLiteralData, i3, this.fReader.currentOffset() - i3); 
    setActiveReaderLimit(i2);
    popReader();
    this.fEntityStackDepth--;
    return bool;
  }
  
  private void expandPEReference() {
    int i = this.fReader.currentOffset();
    int j = this.fReader.skipPastName(';') - i;
    if (j == 0)
      this.fErrorHandler.error(92); 
    if (!this.fReader.skippedChar(';')) {
      int i2 = this.fReader.addString(i, j);
      this.fErrorHandler.error1(93, i2);
    } 
    int k = this.fReader.addSymbol(i, j);
    int m = this.fParameterEntityPool.lookupEntity(k);
    if (m < 0) {
      this.fErrorHandler.error1(94, k);
      return;
    } 
    if (!pushEntity((byte)1, k))
      return; 
    if (!this.fParameterEntityPool.isExternal(m)) {
      StringReader stringReader = new StringReader(this.fParserState, true, this.fReader, this.fParameterEntityPool.getEntityValue(m));
      pushReader(stringReader, null);
      return;
    } 
    int n = this.fParameterEntityPool.getPublicId(m);
    int i1 = this.fParameterEntityPool.getSystemId(m);
    i1 = this.fEntityHandler.expandSystemId(i1);
    InputSource inputSource = this.fEntityHandler.resolveEntity(n, i1);
    if (inputSource == null) {
      inputSource = new InputSource(this.fStringPool.toString(i1));
      if (n != -1)
        inputSource.setPublicId(this.fStringPool.toString(n)); 
    } 
    XMLReader xMLReader = this.fEntityHandler.createReader(inputSource, false);
    this.fEntityHandler.startInputSource(inputSource);
    pushReader(xMLReader, inputSource);
  }
  
  private boolean checkSkippedChar(char paramChar, boolean paramBoolean) throws Exception {
    while (true) {
      try {
        return this.fReader.skippedChar(paramChar);
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        if (paramBoolean)
          this.fReader.skipPastSpaces(); 
      } 
    } 
  }
  
  private boolean checkSkippedSpace() throws Exception {
    while (true) {
      try {
        return this.fReader.skippedSpace();
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
      } 
    } 
  }
  
  private int checkSkipPastSpaces() {
    while (true) {
      try {
        return this.fReader.skipPastSpaces();
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
      } 
    } 
  }
  
  private boolean checkForPEReference(boolean paramBoolean) throws Exception {
    boolean bool2;
    boolean bool1 = true;
    if (paramBoolean)
      try {
        bool1 = this.fReader.skippedSpace();
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        bool1 = this.fReader.skippedSpace();
        if (bool1) {
          this.fReader.skipPastSpaces();
        } else {
          System.err.println("ERROR#2 - need to check for this !!");
        } 
      }  
    while (true) {
      try {
        this.fReader.skipPastSpaces();
        break;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        if (!bool1)
          bool1 = this.fReader.skippedSpace(); 
      } 
    } 
    if (this.fScannerState != 3)
      return bool1; 
    while (true) {
      try {
        bool2 = this.fReader.skippedChar('%');
        break;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        if (!bool1)
          bool1 = this.fReader.skippedSpace(); 
        if (bool1)
          this.fReader.skipPastSpaces(); 
      } 
    } 
    if (!bool2)
      return bool1; 
    do {
      expandPEReference();
      while (true) {
        try {
          this.fReader.skipPastSpaces();
          break;
        } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
          popReader();
          this.fEntityStackDepth--;
        } 
      } 
      bool2 = checkSkippedChar('%', true);
    } while (bool2);
    return true;
  }
  
  private boolean checkForPEDecl() throws Exception {
    boolean bool2;
    boolean bool1 = checkSkippedSpace();
    if (bool1)
      while (true) {
        try {
          this.fReader.skipPastSpaces();
          break;
        } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
          popReader();
          this.fEntityStackDepth--;
          bool1 = this.fReader.skippedSpace();
          if (bool1) {
            this.fReader.skipPastSpaces();
            continue;
          } 
          System.err.println("ERROR#6 - need to check for this !!");
        } 
      }  
    while (true) {
      try {
        bool2 = this.fReader.skippedChar('%');
        break;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        bool1 = this.fReader.skippedSpace();
        if (bool1) {
          this.fReader.skipPastSpaces();
          continue;
        } 
        System.err.println("ERROR#7 - need to check for this !!");
      } 
    } 
    if (!bool2) {
      if (!bool1)
        this.fErrorHandler.error(115); 
      return false;
    } 
    if (this.fScannerState != 3 && !bool1) {
      this.fErrorHandler.error(115);
      return false;
    } 
    try {
      bool1 = this.fReader.skippedSpace();
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      popReader();
      this.fEntityStackDepth--;
      bool1 = this.fReader.skippedSpace();
      if (bool1) {
        this.fReader.skipPastSpaces();
      } else {
        System.err.println("ERROR#8 - need to check for this !!");
      } 
    } 
    if (bool1) {
      checkForPEReference(false);
      return true;
    } 
    if (this.fScannerState != 3) {
      this.fErrorHandler.error(115);
      return true;
    } 
    while (true) {
      try {
        bool2 = this.fReader.lookingAtChar('%');
        break;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        bool1 = this.fReader.skippedSpace();
        if (bool1) {
          this.fReader.skipPastSpaces();
          continue;
        } 
        System.err.println("ERROR#9 - need to check for this !!");
      } 
    } 
    if (bool2) {
      checkForPEReference(false);
      return true;
    } 
    boolean bool3 = false;
    while (true) {
      expandPEReference();
      while (true) {
        try {
          this.fReader.skipPastSpaces();
          break;
        } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
          popReader();
          this.fEntityStackDepth--;
          this.fReader.skipPastSpaces();
        } 
      } 
      bool2 = checkSkippedChar('%', true);
      if (!bool2)
        return bool3; 
      if (!bool3) {
        while (true) {
          try {
            bool1 = this.fReader.skippedSpace();
            break;
          } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            popReader();
            this.fEntityStackDepth--;
          } 
        } 
        if (bool1) {
          checkForPEReference(false);
          return true;
        } 
        while (true) {
          try {
            bool2 = this.fReader.skippedChar('%');
            break;
          } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            popReader();
            this.fEntityStackDepth--;
            bool1 = this.fReader.skippedSpace();
            if (bool1) {
              this.fReader.skipPastSpaces();
              continue;
            } 
            System.err.println("ERROR#10 - need to check for this !!");
          } 
        } 
        if (bool2)
          bool3 = true; 
      } 
    } 
  }
  
  private void scanMarkupDecl(boolean paramBoolean) throws Exception {
    this.fScannerMarkupDepth++;
    try {
      if (this.fReader.skippedChar('!')) {
        if (this.fReader.skippedChar('-')) {
          if (this.fReader.skippedChar('-')) {
            scanComment(false);
            return;
          } 
          this.fErrorHandler.error(20);
          this.fReader.skipPastChar('>');
          this.fScannerMarkupDepth--;
          return;
        } 
        if (this.fReader.skippedChar('[')) {
          if (this.fScannerState != 3)
            this.fErrorHandler.error(47); 
          checkForPEReference(false);
          if (this.fReader.skippedString(include_string)) {
            checkForPEReference(false);
            if (!checkSkippedChar('[', true)) {
              this.fErrorHandler.error(23);
              this.fReader.skipPastChar('>');
              this.fScannerMarkupDepth--;
              return;
            } 
            scanExtSubsetDecl(true);
            return;
          } 
          if (this.fReader.skippedString(ignore_string)) {
            checkForPEReference(false);
            if (!checkSkippedChar('[', true)) {
              this.fErrorHandler.error(23);
              this.fReader.skipPastChar('>');
              this.fScannerMarkupDepth--;
              return;
            } 
            scanIgnoreSectContents();
            return;
          } 
          this.fErrorHandler.error(23);
          this.fReader.skipPastChar('>');
          this.fScannerMarkupDepth--;
          return;
        } 
        if (this.fReader.skippedString(element_string)) {
          scanElementDecl();
          return;
        } 
        if (this.fReader.skippedString(attlist_string)) {
          scanAttlistDecl();
          return;
        } 
        if (this.fReader.skippedString(entity_string)) {
          scanEntityDecl();
          return;
        } 
        if (this.fReader.skippedString(notation_string)) {
          scanNotationDecl();
          return;
        } 
        this.fErrorHandler.error(46);
        this.fReader.skipPastChar('>');
        this.fScannerMarkupDepth--;
        return;
      } 
      if (this.fReader.skippedChar('?')) {
        int i = this.fReader.scanName(' ', -1);
        if (i == -1) {
          this.fErrorHandler.error(102);
          this.fReader.skipPastChar('>');
          this.fScannerMarkupDepth--;
          return;
        } 
        if ("xml".equals(this.fStringPool.toString(i))) {
          if (this.fReader.skippedSpace()) {
            if (paramBoolean) {
              scanTextDecl();
              return;
            } 
            this.fErrorHandler.error(117);
            this.fReader.skipPastChar('>');
            this.fScannerMarkupDepth--;
            return;
          } 
          this.fErrorHandler.error(107);
          this.fReader.skipPastChar('>');
          this.fScannerMarkupDepth--;
          return;
        } 
        scanPI(i, false);
        return;
      } 
      this.fErrorHandler.error(25);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      if (!((this.fEntityStackDepth == 0) ? 0 : this.fEntityNameStack[this.fEntityStackDepth - 1]))
        this.fScannerMarkupDepth--; 
      throw arrayIndexOutOfBoundsException;
    } 
  }
  
  private void scanIgnoreSectContents() {
    byte b = 0;
    try {
      while (true) {
        while (this.fReader.skippedChar('<')) {
          if (this.fReader.skippedChar('!') && this.fReader.skippedChar('['))
            b++; 
        } 
        if (this.fReader.skippedChar(']')) {
          if (this.fReader.skippedChar(']')) {
            do {
            
            } while (this.fReader.skippedChar(']'));
            if (this.fReader.skippedChar('>') && b-- == 0) {
              this.fScannerMarkupDepth--;
              return;
            } 
          } 
          continue;
        } 
        if (!this.fReader.skippedValidChar())
          this.fReader.skipInvalidChar(85); 
      } 
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      this.fErrorHandler.error(24);
      throw arrayIndexOutOfBoundsException;
    } 
  }
  
  private void scanElementDecl() {
    int j;
    if (this.fStop)
      throw new StopException(this); 
    if (!checkForPEReference(true)) {
      this.fErrorHandler.error(115);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    int i = this.fReader.currentOffset();
    while (true) {
      try {
        j = this.fReader.skipPastName(' ') - i;
        break;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        i = this.fReader.skipPastSpaces();
      } 
    } 
    if (j == 0) {
      this.fErrorHandler.error(48);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    if (this.fElementDecl == null)
      this.fElementDecl = new ElementDecl(); 
    this.fElementDecl.elementName = this.fReader.addSymbol(i, j);
    if (!checkForPEReference(true)) {
      this.fErrorHandler.error(115);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    if (!scanContentSpec()) {
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    checkForPEReference(false);
    if (!checkSkippedChar('>', true)) {
      this.fErrorHandler.error(50);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    this.fScannerMarkupDepth--;
    int k = this.fElementDeclPool.addElementDecl(this.fElementDecl);
    if (k == -1) {
      int m = this.fElementDecl.elementName;
      this.fErrorHandler.error1(51, m);
      return;
    } 
    if (this.fDocumentTypeHandler != null)
      this.fDocumentTypeHandler.elementDecl(k); 
  }
  
  private boolean scanContentSpec() throws Exception {
    if (this.fReader.skippedString(empty_string)) {
      this.fElementDecl.contentSpecType = 1;
      this.fElementDecl.contentSpec = -1;
      return true;
    } 
    if (this.fReader.skippedString(any_string)) {
      this.fElementDecl.contentSpecType = 2;
      this.fElementDecl.contentSpec = -1;
      return true;
    } 
    if (!this.fReader.skippedChar('(')) {
      this.fErrorHandler.error(49);
      return false;
    } 
    int i = this.fScannerParenDepth++;
    checkForPEReference(false);
    boolean bool1 = false;
    while (true) {
      try {
        bool1 = this.fReader.skippedString(pcdata_string);
        break;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        this.fReader.skipPastSpaces();
      } 
    } 
    if (this.fContentSpecNode == null)
      this.fContentSpecNode = new ContentSpecNode(); 
    this.fContentSpecNode.otherValue = -1;
    boolean bool2 = bool1 ? scanMixed() : scanChildren();
    if (!bool2) {
      this.fScannerParenDepth = i;
    } else if (this.fScannerParenDepth != i) {
      System.out.println("nesting depth mismatch");
    } 
    return bool2;
  }
  
  private boolean scanMixed() throws Exception {
    int i = -1;
    int j = -1;
    boolean bool = false;
    while (true) {
      int n;
      this.fContentSpecNode.type = 0;
      this.fContentSpecNode.value = i;
      int k = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
      checkForPEReference(false);
      if (!checkSkippedChar('|', true)) {
        if (!checkSkippedChar(')', true)) {
          this.fErrorHandler.error(31);
          return false;
        } 
        this.fScannerParenDepth--;
        if (j != -1) {
          this.fContentSpecNode.type = 4;
          this.fContentSpecNode.value = j;
          this.fContentSpecNode.otherValue = k;
          k = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
          this.fContentSpecNode.otherValue = -1;
        } 
        if (checkSkippedChar('*', false)) {
          this.fContentSpecNode.type = 2;
          this.fContentSpecNode.value = k;
          k = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
        } else if (bool) {
          int i1 = this.fStringPool.addString(this.fElementDeclPool.getContentSpecNodeAsString(k));
          this.fErrorHandler.error1(37, i1);
          return false;
        } 
        this.fElementDecl.contentSpecType = 3;
        this.fElementDecl.contentSpec = k;
        return true;
      } 
      if (j != -1) {
        this.fContentSpecNode.type = 4;
        this.fContentSpecNode.value = j;
        this.fContentSpecNode.otherValue = k;
        k = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
        this.fContentSpecNode.otherValue = -1;
      } 
      j = k;
      bool = true;
      checkForPEReference(false);
      int m = this.fReader.currentOffset();
      while (true) {
        try {
          n = this.fReader.skipPastName(')') - m;
          break;
        } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
          popReader();
          this.fEntityStackDepth--;
          m = this.fReader.skipPastSpaces();
        } 
      } 
      if (n == 0) {
        this.fErrorHandler.error(33);
        return false;
      } 
      i = this.fReader.addSymbol(m, n);
    } 
  }
  
  private boolean scanChildren() throws Exception {
    byte b = 1;
    initializeContentModelStack(b);
    while (true) {
      int j;
      while (checkSkippedChar('(', true)) {
        this.fScannerParenDepth++;
        checkForPEReference(false);
        initializeContentModelStack(++b);
      } 
      int i = this.fReader.currentOffset();
      while (true) {
        try {
          j = this.fReader.skipPastName(')') - i;
          break;
        } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
          popReader();
          this.fEntityStackDepth--;
          i = this.fReader.skipPastSpaces();
        } 
      } 
      if (j == 0) {
        if (this.fScannerState != 3 && this.fReader.lookingAtChar('%')) {
          this.fErrorHandler.error(96);
        } else {
          this.fErrorHandler.error(33);
        } 
        return false;
      } 
      int k = this.fReader.addSymbol(i, j);
      this.fContentSpecNode.type = 0;
      this.fContentSpecNode.value = k;
      this.nodeIndexStack[b] = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
      if (this.fReader.skippedChar('?')) {
        this.fContentSpecNode.type = 1;
        this.fContentSpecNode.value = this.nodeIndexStack[b];
        this.nodeIndexStack[b] = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
      } else if (this.fReader.skippedChar('*')) {
        this.fContentSpecNode.type = 2;
        this.fContentSpecNode.value = this.nodeIndexStack[b];
        this.nodeIndexStack[b] = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
      } else if (this.fReader.skippedChar('+')) {
        this.fContentSpecNode.type = 3;
        this.fContentSpecNode.value = this.nodeIndexStack[b];
        this.nodeIndexStack[b] = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
      } 
      while (true) {
        checkForPEReference(false);
        if (checkSkippedChar('|', true)) {
          if (this.prevNodeIndexStack[b] != -1) {
            this.fContentSpecNode.type = this.opStack[b];
            this.fContentSpecNode.value = this.prevNodeIndexStack[b];
            this.fContentSpecNode.otherValue = this.nodeIndexStack[b];
            this.nodeIndexStack[b] = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
            this.fContentSpecNode.otherValue = -1;
          } 
          this.prevNodeIndexStack[b] = this.nodeIndexStack[b];
          if (this.opStack[b] == 5) {
            int n = this.fStringPool.addString("|");
            int i1 = this.fStringPool.addString(",");
            this.fErrorHandler.error2(34, n, i1);
          } 
          this.opStack[b] = 4;
          break;
        } 
        if (checkSkippedChar(',', true)) {
          if (this.prevNodeIndexStack[b] != -1) {
            this.fContentSpecNode.type = this.opStack[b];
            this.fContentSpecNode.value = this.prevNodeIndexStack[b];
            this.fContentSpecNode.otherValue = this.nodeIndexStack[b];
            this.nodeIndexStack[b] = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
            this.fContentSpecNode.otherValue = -1;
          } 
          this.prevNodeIndexStack[b] = this.nodeIndexStack[b];
          if (this.opStack[b] == 4) {
            int n = this.fStringPool.addString(",");
            int i1 = this.fStringPool.addString("|");
            this.fErrorHandler.error2(34, n, i1);
          } 
          this.opStack[b] = 5;
          break;
        } 
        if (!checkSkippedChar(')', true))
          this.fErrorHandler.error(31); 
        this.fScannerParenDepth--;
        if (this.prevNodeIndexStack[b] != -1) {
          this.fContentSpecNode.type = this.opStack[b];
          this.fContentSpecNode.value = this.prevNodeIndexStack[b];
          this.fContentSpecNode.otherValue = this.nodeIndexStack[b];
          this.nodeIndexStack[b] = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
          this.fContentSpecNode.otherValue = -1;
        } 
        int m = this.nodeIndexStack[b--];
        this.nodeIndexStack[b] = m;
        if (this.fReader.skippedChar('?')) {
          this.fContentSpecNode.type = 1;
          this.fContentSpecNode.value = this.nodeIndexStack[b];
          this.nodeIndexStack[b] = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
        } else if (this.fReader.skippedChar('*')) {
          this.fContentSpecNode.type = 2;
          this.fContentSpecNode.value = this.nodeIndexStack[b];
          this.nodeIndexStack[b] = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
        } else if (this.fReader.skippedChar('+')) {
          this.fContentSpecNode.type = 3;
          this.fContentSpecNode.value = this.nodeIndexStack[b];
          this.nodeIndexStack[b] = this.fElementDeclPool.addContentSpecNode(this.fContentSpecNode);
        } 
        if (b == 0) {
          this.fElementDecl.contentSpecType = 4;
          this.fElementDecl.contentSpec = this.nodeIndexStack[0];
          return true;
        } 
      } 
      checkForPEReference(false);
    } 
  }
  
  private void scanAttlistDecl() {
    int j;
    if (!checkForPEReference(true)) {
      this.fErrorHandler.error(115);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    int i = this.fReader.currentOffset();
    while (true) {
      try {
        j = this.fReader.skipPastName(' ') - i;
        break;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        i = this.fReader.skipPastSpaces();
      } 
    } 
    if (j == 0) {
      this.fErrorHandler.error(11);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    int k = this.fReader.addSymbol(i, j);
    int m = this.fElementDeclPool.addElement(k);
    if (this.fAttDef == null)
      this.fAttDef = new AttDef(); 
    while (true) {
      boolean bool = checkForPEReference(true);
      while (true) {
        try {
          if (this.fReader.skippedChar('>')) {
            this.fScannerMarkupDepth--;
            return;
          } 
          break;
        } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
          popReader();
          this.fEntityStackDepth--;
          if (bool) {
            this.fReader.skippedSpace();
            continue;
          } 
          bool = this.fReader.skippedSpace();
          if (bool) {
            this.fReader.skipPastSpaces();
            continue;
          } 
          System.err.println("ERROR#11 - need to check for this !!");
        } 
      } 
      if (!bool)
        this.fErrorHandler.error(115); 
      if (!scanAttDef()) {
        this.fReader.skipPastChar('>');
        this.fScannerMarkupDepth--;
        return;
      } 
      int n = this.fElementDeclPool.addAttDef(m, this.fAttDef);
      if (n != -1 && this.fDocumentTypeHandler != null)
        this.fDocumentTypeHandler.attlistDecl(m, n); 
    } 
  }
  
  private boolean scanAttDef() throws Exception {
    int i = this.fReader.currentOffset();
    int j = 0;
    while (true) {
      try {
        j = this.fReader.skipPastName(' ') - i;
        break;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        i = this.fReader.skipPastSpaces();
      } 
    } 
    if (j == 0) {
      this.fErrorHandler.error(2);
      return false;
    } 
    this.fAttDef.attName = this.fReader.addSymbol(i, j);
    if (!checkForPEReference(true)) {
      this.fErrorHandler.error(115);
      return false;
    } 
    if (!scanAttType())
      return false; 
    if (!checkForPEReference(true)) {
      this.fErrorHandler.error(115);
      return false;
    } 
    return scanDefaultDecl();
  }
  
  private boolean scanAttType() throws Exception {
    this.fAttDef.enumeration = -1;
    while (true) {
      try {
        if (this.fReader.skippedString(cdata_string)) {
          this.fAttDef.attType = 0;
        } else if (this.fReader.skippedString(id_string)) {
          if (!this.fReader.skippedString(ref_string)) {
            this.fAttDef.attType = 1;
          } else if (!this.fReader.skippedChar('S')) {
            this.fAttDef.attType = 2;
          } else {
            this.fAttDef.attType = 3;
          } 
        } else if (this.fReader.skippedString(entit_string)) {
          if (this.fReader.skippedChar('Y')) {
            this.fAttDef.attType = 4;
          } else if (this.fReader.skippedString(ies_string)) {
            this.fAttDef.attType = 5;
          } else {
            this.fErrorHandler.error(4);
            this.fReader.skipPastNmtoken(' ');
          } 
        } else if (this.fReader.skippedString(nmtoken_string)) {
          if (this.fReader.skippedChar('S')) {
            this.fAttDef.attType = 7;
          } else {
            this.fAttDef.attType = 6;
          } 
        } else if (this.fReader.skippedString(notation_string)) {
          this.fAttDef.attType = 8;
          if (!scanEnumeration(true))
            return false; 
        } else if (this.fReader.skippedChar('(')) {
          this.fScannerParenDepth++;
          this.fAttDef.attType = 9;
          if (!scanEnumeration(false))
            return false; 
        } else {
          this.fErrorHandler.error(4);
          return false;
        } 
        return true;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        this.fReader.skipPastSpaces();
      } 
    } 
  }
  
  private boolean scanEnumeration(boolean paramBoolean) throws Exception {
    if (paramBoolean) {
      if (!checkForPEReference(true)) {
        this.fErrorHandler.error(115);
        return false;
      } 
      while (true) {
        try {
          if (!this.fReader.skippedChar('(')) {
            this.fErrorHandler.error(71);
            return false;
          } 
          break;
        } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
          popReader();
          this.fEntityStackDepth--;
          this.fReader.skipPastSpaces();
        } 
      } 
      this.fScannerParenDepth++;
    } 
    this.fAttDef.enumeration = this.fStringPool.startStringList();
    boolean bool = false;
    do {
      int j;
      checkForPEReference(false);
      int i = this.fReader.currentOffset();
      while (true) {
        try {
          if (paramBoolean) {
            int m = this.fReader.skipPastName(')') - i;
            break;
          } 
          j = this.fReader.skipPastNmtoken(')') - i;
          break;
        } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
          popReader();
          this.fEntityStackDepth--;
          i = this.fReader.skipPastSpaces();
        } 
      } 
      if (j == 0) {
        byte b = paramBoolean ? 72 : 73;
        this.fErrorHandler.error(b);
        this.fStringPool.finishStringList(this.fAttDef.enumeration);
        return false;
      } 
      int k = this.fReader.addSymbol(i, j);
      checkForPEReference(false);
      while (true) {
        try {
          bool = this.fReader.skippedChar('|');
          break;
        } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
          popReader();
          this.fEntityStackDepth--;
          this.fReader.skipPastSpaces();
        } 
      } 
      if (!bool) {
        while (true) {
          try {
            if (!this.fReader.skippedChar(')')) {
              this.fErrorHandler.error(74);
              this.fStringPool.finishStringList(this.fAttDef.enumeration);
              return false;
            } 
            break;
          } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            popReader();
            this.fEntityStackDepth--;
            this.fReader.skipPastSpaces();
          } 
        } 
        this.fScannerParenDepth--;
      } 
      this.fStringPool.addStringToList(this.fAttDef.enumeration, k);
    } while (bool);
    this.fStringPool.finishStringList(this.fAttDef.enumeration);
    return true;
  }
  
  private boolean scanDefaultDecl() throws Exception {
    if (this.fReader.skippedString(required_string)) {
      this.fAttDef.attDefaultType = 2;
      this.fAttDef.attValue = -1;
      return true;
    } 
    if (this.fReader.skippedString(implied_string)) {
      this.fAttDef.attDefaultType = 3;
      this.fAttDef.attValue = -1;
      return true;
    } 
    if (this.fReader.skippedString(fixed_string)) {
      this.fAttDef.attDefaultType = 4;
      if (!this.fReader.skippedSpace()) {
        this.fErrorHandler.error(115);
        return false;
      } 
      this.fReader.skipPastSpaces();
    } else {
      this.fAttDef.attDefaultType = 1;
    } 
    if (!scanAttValue(-1, -1, this.fAttDef.attType, true, !(this.fAttDef.attDefaultType != 4)))
      return false; 
    this.fAttDef.attValue = this.fAttValueIndex;
    return true;
  }
  
  private void scanNotationDecl() {
    int j;
    if (!checkForPEReference(true)) {
      this.fErrorHandler.error(115);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    int i = this.fReader.currentOffset();
    while (true) {
      try {
        j = this.fReader.skipPastName(' ') - i;
        break;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        i = this.fReader.skipPastSpaces();
      } 
    } 
    if (j == 0) {
      this.fErrorHandler.error(91);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    if (this.fNotationDecl == null)
      this.fNotationDecl = new NotationDecl(); 
    this.fNotationDecl.notationName = this.fReader.addSymbol(i, j);
    if (!checkForPEReference(true)) {
      this.fErrorHandler.error(115);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    if (!scanExternalIDorPublicID(true, true)) {
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    this.fNotationDecl.publicId = this.fPubidLiteral;
    this.fNotationDecl.systemId = this.fSystemLiteral;
    checkForPEReference(false);
    while (true) {
      try {
        if (!this.fReader.skippedChar('>')) {
          this.fErrorHandler.error(163);
          this.fReader.skipPastChar('>');
          this.fScannerMarkupDepth--;
          return;
        } 
        this.fScannerMarkupDepth--;
        break;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        this.fReader.skipPastSpaces();
      } 
    } 
    int k = this.fEntityPool.addNotationDecl(this.fNotationDecl);
    if (k != -1 && this.fDocumentTypeHandler != null)
      this.fDocumentTypeHandler.notationDecl(k); 
  }
  
  private void scanEntityDecl() {
    int j;
    boolean bool1 = checkForPEDecl();
    int i = this.fReader.currentOffset();
    while (true) {
      try {
        j = this.fReader.skipPastName(' ') - i;
        break;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        i = this.fReader.skipPastSpaces();
      } 
    } 
    if (j == 0) {
      this.fErrorHandler.error(61);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    int k = this.fReader.addSymbol(i, j);
    boolean bool2 = pushEntity(bool1 ? 1 : 0, k);
    if (!bool2) {
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      return;
    } 
    if (this.fEntityDecl == null)
      this.fEntityDecl = new EntityDecl(); 
    this.fEntityDecl.entityName = k;
    this.fEntityDecl.entityValue = -1;
    this.fEntityDecl.publicId = -1;
    this.fEntityDecl.systemId = -1;
    this.fEntityDecl.notationName = -1;
    if (!checkForPEReference(true)) {
      this.fErrorHandler.error(115);
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      this.fEntityStackDepth--;
      return;
    } 
    if (!(bool1 ? scanPEDef() : scanEntityDef())) {
      this.fReader.skipPastChar('>');
      this.fScannerMarkupDepth--;
      this.fEntityStackDepth--;
      return;
    } 
    checkForPEReference(false);
    while (true) {
      try {
        if (!this.fReader.skippedChar('>')) {
          this.fErrorHandler.error(64);
          this.fReader.skipPastChar('>');
          this.fScannerMarkupDepth--;
          this.fEntityStackDepth--;
          return;
        } 
        this.fScannerMarkupDepth--;
        break;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        popReader();
        this.fEntityStackDepth--;
        this.fReader.skipPastSpaces();
      } 
    } 
    this.fEntityStackDepth--;
    if (bool1) {
      if (this.fParameterEntityPool == null)
        this.fParameterEntityPool = new DefaultEntityPool(this.fParserState, false); 
      this.fParameterEntityPool.addEntityDecl(this.fEntityDecl);
      return;
    } 
    int m = this.fEntityPool.addEntityDecl(this.fEntityDecl);
    if (this.fDocumentTypeHandler != null) {
      if (this.fEntityDecl.entityValue == -1) {
        if (this.fEntityDecl.notationName == -1) {
          this.fDocumentTypeHandler.externalEntityDecl(m);
          return;
        } 
        this.fDocumentTypeHandler.unparsedEntityDecl(m);
        return;
      } 
      this.fDocumentTypeHandler.internalEntityDecl(m);
    } 
  }
  
  private boolean scanEntityDef() throws Exception {
    boolean bool;
    if ((bool = this.fReader.skippedChar('\'')) || this.fReader.skippedChar('"'))
      return scanEntityValue(bool); 
    if (!scanExternalIDorPublicID(true, false))
      return false; 
    this.fEntityDecl.publicId = this.fPubidLiteral;
    this.fEntityDecl.systemId = this.fSystemLiteral;
    if (!this.fReader.skippedSpace())
      return true; 
    this.fReader.skipPastSpaces();
    if (this.fReader.skippedString(ndata_string)) {
      if (!this.fReader.skippedSpace()) {
        this.fErrorHandler.error(115);
        return false;
      } 
      int i = this.fReader.skipPastSpaces();
      int j = this.fReader.skipPastName('>') - i;
      if (j == 0) {
        this.fErrorHandler.error(65);
        return false;
      } 
      this.fEntityDecl.notationName = this.fReader.addSymbol(i, j);
    } 
    return true;
  }
  
  private boolean scanPEDef() throws Exception {
    boolean bool;
    if ((bool = this.fReader.skippedChar('\'')) || this.fReader.skippedChar('"'))
      return scanEntityValue(bool); 
    if (!scanExternalIDorPublicID(true, false))
      return false; 
    this.fEntityDecl.publicId = this.fPubidLiteral;
    this.fEntityDecl.systemId = this.fSystemLiteral;
    return true;
  }
  
  private boolean scanEntityValue(boolean paramBoolean) throws Exception {
    int i = this.fReader.currentOffset();
    char c = paramBoolean ? '\'' : '"';
    int j = i;
    int k = this.fLiteralData.length();
    while (true) {
      if (this.fReader.skippedChar(c)) {
        if (i - j > 0)
          this.fReader.append(this.fLiteralData, j, i - j); 
        break;
      } 
      if (this.fReader.skippedChar('&')) {
        if (i - j > 0)
          this.fReader.append(this.fLiteralData, j, i - j); 
        i = referenceInEntityValue(i, true);
        j = i;
        continue;
      } 
      if (this.fReader.skippedChar('%')) {
        if (i - j > 0)
          this.fReader.append(this.fLiteralData, j, i - j); 
        if (!copyPEReference()) {
          this.fReader.skipToChar(c);
          return false;
        } 
        i = this.fReader.currentOffset();
        j = i;
        continue;
      } 
      if (!this.fReader.skippedValidChar()) {
        this.fReader.skipInvalidChar(63);
        this.fReader.skipToChar(c);
        return false;
      } 
      i = this.fReader.currentOffset();
    } 
    int m = this.fLiteralData.length() - k;
    this.fEntityDecl.entityValue = this.fLiteralData.addString(k, m);
    return true;
  }
  
  private void growReaderStack() {
    XMLReader[] arrayOfXMLReader = new XMLReader[this.fReaderStackDepth * 2];
    System.arraycopy(this.fReaderStack, 0, arrayOfXMLReader, 0, this.fReaderStackDepth);
    this.fReaderStack = arrayOfXMLReader;
    InputSource[] arrayOfInputSource = new InputSource[this.fReaderStackDepth * 2];
    System.arraycopy(this.fReaderSource, 0, arrayOfInputSource, 0, this.fReaderStackDepth);
    this.fReaderSource = arrayOfInputSource;
    int[] arrayOfInt = new int[this.fReaderStackDepth * 2];
    System.arraycopy(this.fReaderMarkupDepth, 0, arrayOfInt, 0, this.fReaderStackDepth);
    this.fReaderMarkupDepth = arrayOfInt;
    arrayOfInt = new int[this.fReaderStackDepth * 2];
    System.arraycopy(this.fReaderParenDepth, 0, arrayOfInt, 0, this.fReaderStackDepth);
    this.fReaderParenDepth = arrayOfInt;
  }
  
  private int pushReader(XMLReader paramXMLReader, InputSource paramInputSource) {
    if (this.fReaderStackDepth == this.fReaderStack.length)
      growReaderStack(); 
    this.fReaderStack[this.fReaderStackDepth] = this.fReader;
    this.fReaderSource[this.fReaderStackDepth] = paramInputSource;
    this.fReaderMarkupDepth[this.fReaderStackDepth] = this.fScannerMarkupDepth;
    this.fReaderParenDepth[this.fReaderStackDepth] = this.fScannerParenDepth;
    this.fReader = paramXMLReader;
    return ++this.fReaderStackDepth;
  }
  
  private void popReader() {
    if (this.fReaderStackDepth == this.fActiveReaderLimit)
      throw new ArrayIndexOutOfBoundsException(); 
    this.fReaderStackDepth--;
    byte b = (this.fEntityStackDepth == 0) ? 0 : this.fEntityNameStack[this.fEntityStackDepth - 1];
    if (b) {
      if (this.fScannerParenDepth != this.fReaderParenDepth[this.fReaderStackDepth])
        this.fErrorHandler.error1(99, b); 
      if (this.fScannerMarkupDepth != this.fReaderMarkupDepth[this.fReaderStackDepth])
        if (!((this.fEntityStackDepth == 0) ? 0 : this.fEntityTypeStack[this.fEntityStackDepth - 1])) {
          this.fErrorHandler.error(138);
        } else {
          this.fErrorHandler.error1(101, b);
        }  
    } 
    this.fReader = this.fReaderStack[this.fReaderStackDepth];
    InputSource inputSource = this.fReaderSource[this.fReaderStackDepth];
    if (inputSource != null) {
      this.fEntityHandler.endInputSource(inputSource);
      this.fReaderSource[this.fReaderStackDepth] = null;
    } 
  }
  
  private int setActiveReaderLimit(int paramInt) {
    int i = this.fActiveReaderLimit;
    this.fActiveReaderLimit = paramInt;
    return i;
  }
  
  private int increaseParenDepth() { return this.fScannerParenDepth++; }
  
  private int decreaseParenDepth() { return this.fScannerParenDepth--; }
  
  private int increaseMarkupDepth() { return this.fScannerMarkupDepth++; }
  
  private int decreaseMarkupDepth() { return this.fScannerMarkupDepth--; }
  
  private void pushElementName(int paramInt) throws Exception {
    if (this.fElementDepth >= 0) {
      int[] arrayOfInt = this.fElementChildren[this.fElementDepth];
      int i = this.fElementChildCount[this.fElementDepth];
      if (arrayOfInt == null) {
        arrayOfInt = this.fElementChildren[this.fElementDepth] = new int[8];
        i = 0;
      } else if (i == arrayOfInt.length) {
        int[] arrayOfInt1 = new int[i * 2];
        System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, i);
        arrayOfInt = this.fElementChildren[this.fElementDepth] = arrayOfInt1;
      } 
      arrayOfInt[i++] = paramInt;
      this.fElementChildCount[this.fElementDepth] = i;
    } 
    this.fElementDepth++;
    if (this.fElementDepth == this.fElementNameStack.length) {
      int[] arrayOfInt = new int[this.fElementDepth * 2];
      System.arraycopy(this.fElementNameStack, 0, arrayOfInt, 0, this.fElementDepth);
      this.fElementNameStack = arrayOfInt;
      arrayOfInt = new int[this.fElementDepth * 2];
      System.arraycopy(this.fElementChildCount, 0, arrayOfInt, 0, this.fElementDepth);
      this.fElementChildCount = arrayOfInt;
      int[][] arrayOfInt1 = new int[this.fElementDepth * 2][];
      System.arraycopy(this.fElementChildren, 0, arrayOfInt1, 0, this.fElementDepth);
      this.fElementChildren = arrayOfInt1;
    } 
    this.fElementNameStack[this.fElementDepth] = paramInt;
    this.fElementChildCount[this.fElementDepth] = 0;
  }
  
  private int elementStackDepth() { return this.fElementDepth; }
  
  private void charDataInContent() {
    int[] arrayOfInt = this.fElementChildren[this.fElementDepth];
    int i = this.fElementChildCount[this.fElementDepth];
    if (arrayOfInt == null) {
      arrayOfInt = this.fElementChildren[this.fElementDepth] = new int[8];
      i = 0;
    } else if (i == arrayOfInt.length) {
      int[] arrayOfInt1 = new int[i * 2];
      System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, i);
      arrayOfInt = this.fElementChildren[this.fElementDepth] = arrayOfInt1;
    } 
    arrayOfInt[i++] = -1;
    this.fElementChildCount[this.fElementDepth] = i;
  }
  
  public int getCurrentContentSpecType() { return this.fElementDeclPool.getContentSpecType(this.fElementDeclPool.getElement(this.fElementNameStack[this.fElementDepth])); }
  
  private int peekElementName() { return this.fElementNameStack[this.fElementDepth]; }
  
  private int peekChildCount() { return this.fElementChildCount[this.fElementDepth]; }
  
  private int[] peekChildren() { return this.fElementChildren[this.fElementDepth]; }
  
  private boolean popElementName() throws Exception {
    if (this.fElementDepth < 0)
      throw new RuntimeException("Element stack underflow"); 
    return !(--this.fElementDepth < 0);
  }
  
  private boolean pushEntity(byte paramByte, int paramInt) throws Exception {
    for (byte b = 0; b < this.fEntityStackDepth; b++) {
      if (this.fEntityNameStack[b] == paramInt && this.fEntityTypeStack[b] == paramByte) {
        char c = (paramByte == 0) ? 139 : 97;
        int i = entityReferencePath(paramByte, paramInt);
        this.fErrorHandler.error2(c, paramInt, i);
        return false;
      } 
    } 
    if (this.fEntityTypeStack == null) {
      this.fEntityTypeStack = new byte[8];
      this.fEntityNameStack = new int[8];
    } else if (this.fEntityStackDepth == this.fEntityTypeStack.length) {
      byte[] arrayOfByte = new byte[this.fEntityStackDepth * 2];
      System.arraycopy(this.fEntityTypeStack, 0, arrayOfByte, 0, this.fEntityStackDepth);
      this.fEntityTypeStack = arrayOfByte;
      int[] arrayOfInt = new int[this.fEntityStackDepth * 2];
      System.arraycopy(this.fEntityNameStack, 0, arrayOfInt, 0, this.fEntityStackDepth);
      this.fEntityNameStack = arrayOfInt;
    } 
    this.fEntityTypeStack[this.fEntityStackDepth] = paramByte;
    this.fEntityNameStack[this.fEntityStackDepth] = paramInt;
    this.fEntityStackDepth++;
    return true;
  }
  
  private int peekEntity() { return (this.fEntityStackDepth == 0) ? 0 : this.fEntityNameStack[this.fEntityStackDepth - 1]; }
  
  private int peekEntityType() { return (this.fEntityStackDepth == 0) ? 0 : this.fEntityTypeStack[this.fEntityStackDepth - 1]; }
  
  private int entityReferencePath(byte paramByte, int paramInt) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("(top-level)");
    for (byte b = 0; b < this.fEntityStackDepth; b++) {
      stringBuffer.append('-');
      stringBuffer.append((this.fEntityTypeStack[b] == 0) ? 38 : 37);
      stringBuffer.append(this.fStringPool.toString(this.fEntityNameStack[b]));
      stringBuffer.append(';');
    } 
    stringBuffer.append('-');
    stringBuffer.append((paramByte == 0) ? 38 : 37);
    stringBuffer.append(this.fStringPool.toString(paramInt));
    stringBuffer.append(';');
    return this.fStringPool.addString(stringBuffer.toString());
  }
  
  private void popEntity() { this.fEntityStackDepth--; }
  
  private void initializeContentModelStack(int paramInt) throws Exception {
    if (this.opStack == null) {
      this.opStack = new byte[8];
      this.nodeIndexStack = new int[8];
      this.prevNodeIndexStack = new int[8];
    } else if (paramInt == this.opStack.length) {
      byte[] arrayOfByte = new byte[paramInt * 2];
      System.arraycopy(this.opStack, 0, arrayOfByte, 0, paramInt);
      this.opStack = arrayOfByte;
      int[] arrayOfInt = new int[paramInt * 2];
      System.arraycopy(this.nodeIndexStack, 0, arrayOfInt, 0, paramInt);
      this.nodeIndexStack = arrayOfInt;
      arrayOfInt = new int[paramInt * 2];
      System.arraycopy(this.prevNodeIndexStack, 0, arrayOfInt, 0, paramInt);
      this.prevNodeIndexStack = arrayOfInt;
    } 
    this.opStack[paramInt] = 0;
    this.nodeIndexStack[paramInt] = -1;
    this.prevNodeIndexStack[paramInt] = -1;
  }
  
  private class StopException extends Exception {
    private final DefaultScanner this$0;
    
    public StopException(DefaultScanner this$0) {
      super("stopped at " + ((this$0.fReader == null) ? -1 : this$0.fReader.getLineNumber()) + ':' + ((this$0.fReader == null) ? -1 : this$0.fReader.getColumnNumber()) + " in " + ((this$0.fReader == null) ? null : this$0.fReader.getSystemId()));
      this.this$0 = this$0;
      this.this$0 = this$0;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\DefaultScanner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */