package com.ibm.xml.internal;

import com.ibm.xml.framework.EntityDecl;
import com.ibm.xml.framework.EntityPool;
import com.ibm.xml.framework.NotationDecl;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLErrorHandler;

public final class DefaultEntityPool implements EntityPool {
  private static final boolean DEBUG_530 = false;
  
  static final int CHUNK_SHIFT = 5;
  
  static final int CHUNK_SIZE = 32;
  
  static final int CHUNK_MASK = 31;
  
  static final int INITIAL_CHUNK_COUNT = 32;
  
  private ParserState fParserState;
  
  private StringPool fStringPool;
  
  private int fEntityCount;
  
  private int[][] fEntityName = new int[32][];
  
  private int[][] fEntityValue = new int[32][];
  
  private int[][] fPublicId = new int[32][];
  
  private int[][] fSystemId = new int[32][];
  
  private int[][] fNotationName = new int[32][];
  
  private int fNotationListHead = -1;
  
  private EntityDecl fInternalEntityDecl;
  
  public DefaultEntityPool(ParserState paramParserState, boolean paramBoolean) {
    this.fParserState = paramParserState;
    this.fStringPool = paramParserState.cacheStringPool();
    if (paramBoolean) {
      this.fInternalEntityDecl = new EntityDecl();
      createInternalEntity("lt", "&#60;");
      createInternalEntity("gt", ">");
      createInternalEntity("amp", "&#38;");
      createInternalEntity("apos", "'");
      createInternalEntity("quot", "\"");
    } 
  }
  
  public void reset(ParserState paramParserState) {
    this.fParserState = paramParserState;
    this.fStringPool = paramParserState.cacheStringPool();
    this.fEntityCount = 0;
    this.fNotationListHead = -1;
    if (this.fInternalEntityDecl != null) {
      createInternalEntity("lt", "&#60;");
      createInternalEntity("gt", ">");
      createInternalEntity("amp", "&#38;");
      createInternalEntity("apos", "'");
      createInternalEntity("quot", "\"");
    } 
  }
  
  public EntityPool resetOrCopy(ParserState paramParserState) { return new DefaultEntityPool(paramParserState, !(this.fInternalEntityDecl == null)); }
  
  private void createInternalEntity(String paramString1, String paramString2) {
    this.fInternalEntityDecl.entityName = this.fStringPool.addSymbol(paramString1);
    this.fInternalEntityDecl.entityValue = this.fStringPool.addString(paramString2);
    this.fInternalEntityDecl.publicId = -1;
    this.fInternalEntityDecl.systemId = -1;
    this.fInternalEntityDecl.notationName = -1;
    addEntityDecl(this.fInternalEntityDecl);
  }
  
  private boolean ensureCapacity(int paramInt) {
    try {
      return !(this.fEntityName[paramInt][0] != 0);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      int[][] arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fEntityName, 0, arrayOfInt, 0, paramInt);
      this.fEntityName = arrayOfInt;
      arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fEntityValue, 0, arrayOfInt, 0, paramInt);
      this.fEntityValue = arrayOfInt;
      arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fPublicId, 0, arrayOfInt, 0, paramInt);
      this.fPublicId = arrayOfInt;
      arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fSystemId, 0, arrayOfInt, 0, paramInt);
      this.fSystemId = arrayOfInt;
      arrayOfInt = new int[paramInt * 2][];
      System.arraycopy(this.fNotationName, 0, arrayOfInt, 0, paramInt);
      this.fNotationName = arrayOfInt;
    } catch (NullPointerException nullPointerException) {}
    this.fEntityName[paramInt] = new int[32];
    this.fEntityValue[paramInt] = new int[32];
    this.fPublicId[paramInt] = new int[32];
    this.fSystemId[paramInt] = new int[32];
    this.fNotationName[paramInt] = new int[32];
    return true;
  }
  
  public int addEntityDecl(EntityDecl paramEntityDecl) {
    int i = this.fEntityCount >> 5;
    int j = this.fEntityCount & 0x1F;
    ensureCapacity(i);
    this.fEntityName[i][j] = paramEntityDecl.entityName;
    this.fEntityValue[i][j] = paramEntityDecl.entityValue;
    this.fPublicId[i][j] = paramEntityDecl.publicId;
    this.fSystemId[i][j] = paramEntityDecl.systemId;
    this.fNotationName[i][j] = paramEntityDecl.notationName;
    return this.fEntityCount++;
  }
  
  public int addNotationDecl(NotationDecl paramNotationDecl) {
    for (int i = this.fNotationListHead; i != -1; i = this.fEntityValue[m][n]) {
      int m = i >> 5;
      int n = i & 0x1F;
      if (this.fNotationName[m][n] == paramNotationDecl.notationName)
        return -1; 
    } 
    int j = this.fEntityCount >> 5;
    int k = this.fEntityCount & 0x1F;
    ensureCapacity(j);
    this.fEntityName[j][k] = -1;
    this.fEntityValue[j][k] = this.fNotationListHead;
    this.fPublicId[j][k] = paramNotationDecl.publicId;
    this.fSystemId[j][k] = paramNotationDecl.systemId;
    this.fNotationName[j][k] = paramNotationDecl.notationName;
    this.fNotationListHead = this.fEntityCount++;
    return this.fNotationListHead;
  }
  
  public int lookupEntity(int paramInt) {
    byte b1 = 0;
    byte b2 = 0;
    for (byte b3 = 0; b3 < this.fEntityCount; b3++) {
      if (this.fEntityName[b1][b2] == paramInt)
        return b3; 
      if (++b2 == 32) {
        b1++;
        b2 = 0;
      } 
    } 
    return -1;
  }
  
  public boolean isExternal(int paramInt) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return !(this.fEntityValue[i][j] != -1);
  }
  
  public boolean isUnparsed(int paramInt) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return !(this.fNotationName[i][j] == -1);
  }
  
  public int getEntityName(int paramInt) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fEntityName[i][j];
  }
  
  public int getEntityValue(int paramInt) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fEntityValue[i][j];
  }
  
  public int getPublicId(int paramInt) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fPublicId[i][j];
  }
  
  public int getSystemId(int paramInt) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fSystemId[i][j];
  }
  
  public int lookupNotation(int paramInt) {
    for (int i = this.fNotationListHead; i != -1; i = this.fEntityValue[j][k]) {
      int j = i >> 5;
      int k = i & 0x1F;
      if (this.fNotationName[j][k] == paramInt)
        return i; 
    } 
    return -1;
  }
  
  public int getNotationName(int paramInt) {
    int i = paramInt >> 5;
    int j = paramInt & 0x1F;
    return this.fNotationName[i][j];
  }
  
  public void checkUnparsedEntities() throws Exception {
    XMLErrorHandler xMLErrorHandler = this.fParserState.getErrorHandler();
    for (byte b = 0; b < this.fEntityCount; b++) {
      byte b1 = b >> 5;
      byte b2 = b & 0x1F;
      if (this.fEntityName[b1][b2] != -1) {
        int i = this.fNotationName[b1][b2];
        if (i != -1 && lookupNotation(i) == -1)
          xMLErrorHandler.error1(68, i); 
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\DefaultEntityPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */