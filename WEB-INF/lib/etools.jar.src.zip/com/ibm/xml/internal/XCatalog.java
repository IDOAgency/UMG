package com.ibm.xml.internal;

import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.parsers.SAXParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import org.xml.sax.AttributeList;
import org.xml.sax.DocumentHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

public class XCatalog extends DefaultCatalog {
  public static final String XCATALOG_DTD_PUBLICID = "-//DTD XCatalog//EN";
  
  static final String DTD = "xcatalog.dtd";
  
  static final String XCATALOG = "XCatalog";
  
  static final String MAP = "Map";
  
  static final String PUBLICID = "PublicID";
  
  static final String HREF = "HRef";
  
  static final String DELEGATE = "Delegate";
  
  static final String EXTEND = "Extend";
  
  static final String BASE = "Base";
  
  static final String REMAP = "Remap";
  
  static final String SYSTEMID = "SystemID";
  
  private static final boolean DEBUG = false;
  
  private Hashtable delegate = new Hashtable();
  
  private Vector delegateOrder = new Vector();
  
  private ParserState state;
  
  public XCatalog(ParserState paramParserState) { this.state = paramParserState; }
  
  public void loadCatalog(InputSource paramInputSource) throws SAXException, IOException {}
  
  public InputSource resolveEntity(String paramString1, String paramString2) throws SAXException, IOException {
    if (paramString1 != null) {
      String str1 = getPublicMapping(paramString1);
      if (str1 != null) {
        InputSource inputSource = resolveEntity(null, str1);
        if (inputSource == null)
          inputSource = new InputSource(str1); 
        inputSource.setPublicId(paramString1);
        return inputSource;
      } 
      Enumeration enumeration = getDelegateCatalogKeys();
      while (enumeration.hasMoreElements()) {
        String str2 = (String)enumeration.nextElement();
        if (paramString1.startsWith(str2)) {
          XCatalog xCatalog = getDelegateCatalog(str2);
          InputSource inputSource = xCatalog.resolveEntity(paramString1, paramString2);
          if (inputSource != null)
            return inputSource; 
        } 
      } 
    } 
    String str = getSystemMapping(paramString2);
    if (str != null) {
      InputSource inputSource = new InputSource(str);
      inputSource.setPublicId(paramString1);
      return inputSource;
    } 
    return null;
  }
  
  public void addDelegateCatalog(String paramString, XCatalog paramXCatalog) {
    synchronized (this.delegate) {
      if (!this.delegate.containsKey(paramString)) {
        int i = this.delegateOrder.size();
        boolean bool = false;
        for (byte b = 0; b < i; b++) {
          String str = (String)this.delegateOrder.elementAt(b);
          if (paramString.startsWith(str) || paramString.compareTo(str) < 0) {
            this.delegateOrder.insertElementAt(paramString, b);
            bool = true;
            break;
          } 
        } 
        if (!bool)
          this.delegateOrder.addElement(paramString); 
      } 
      this.delegate.put(paramString, paramXCatalog);
      return;
    } 
  }
  
  public void removeDelegateCatalog(String paramString) {
    synchronized (this.delegate) {
      this.delegate.remove(paramString);
      this.delegateOrder.removeElement(paramString);
      return;
    } 
  }
  
  public Enumeration getDelegateCatalogKeys() { return this.delegateOrder.elements(); }
  
  public XCatalog getDelegateCatalog(String paramString) { return (XCatalog)this.delegate.get(paramString); }
  
  protected ParserState getParserState() { return this.state; }
  
  String expandSystemId(ParserState paramParserState, String paramString) {
    StringPool stringPool = paramParserState.getStringPool();
    int i = stringPool.addString(paramString);
    int j = paramParserState.getEntityHandler().expandSystemId(i);
    if (j != i)
      paramString = stringPool.orphanString(j); 
    stringPool.releaseString(i);
    return paramString;
  }
  
  boolean isURL(String paramString) {
    try {
      return true;
    } catch (MalformedURLException malformedURLException) {
      return false;
    } 
  }
  
  class Parser extends SAXParser implements DocumentHandler {
    private final XCatalog this$0;
    
    private String base;
    
    private ParserState state;
    
    public Parser(XCatalog this$0, InputSource param1InputSource) throws SAXException, IOException {
      this.this$0 = this$0;
      this.this$0 = this$0;
      this.state = this.this$0.getParserState();
      getEntityHandler().setEntityResolver(new Resolver(this));
      setDocumentHandler(this);
      setBase(param1InputSource.getSystemId());
      parse(param1InputSource);
    }
    
    protected void setBase(String param1String) {
      if (param1String == null)
        param1String = ""; 
      param1String = this.this$0.expandSystemId(getParserState(), param1String);
      int i = param1String.lastIndexOf('/');
      if (i != -1)
        param1String = param1String.substring(0, i + 1); 
      this.base = param1String;
    }
    
    public void processingInstruction(String param1String1, String param1String2) {}
    
    public void setDocumentLocator(Locator param1Locator) {}
    
    public void startDocument() {}
    
    public void endElement(String param1String) {}
    
    public void endDocument() {}
    
    public void characters(char[] param1ArrayOfChar, int param1Int1, int param1Int2) {}
    
    public void ignorableWhitespace(char[] param1ArrayOfChar, int param1Int1, int param1Int2) {}
    
    public void startElement(String param1String, AttributeList param1AttributeList) throws SAXException {
      try {
        if (param1String.equals("XCatalog"))
          return; 
        if (param1String.equals("Map")) {
          String str1 = param1AttributeList.getValue("PublicID");
          String str2 = param1AttributeList.getValue("HRef");
          if (!this.this$0.isURL(str2))
            str2 = String.valueOf(this.base) + str2; 
          this.this$0.addPublicMapping(str1, str2);
          return;
        } 
        if (param1String.equals("Delegate")) {
          String str1 = param1AttributeList.getValue("PublicID");
          String str2 = param1AttributeList.getValue("HRef");
          if (!this.this$0.isURL(str2))
            str2 = String.valueOf(this.base) + str2; 
          String str3 = this.this$0.expandSystemId(getParserState(), str2);
          XCatalog xCatalog = new XCatalog(this.state);
          xCatalog.loadCatalog(new InputSource(str3));
          this.this$0.addDelegateCatalog(str1, xCatalog);
          return;
        } 
        if (param1String.equals("Extend")) {
          String str1 = param1AttributeList.getValue("HRef");
          if (!this.this$0.isURL(str1))
            str1 = String.valueOf(this.base) + str1; 
          String str2 = this.this$0.expandSystemId(getParserState(), str1);
          this.this$0.loadCatalog(new InputSource(str2));
          return;
        } 
        if (param1String.equals("Base")) {
          String str = param1AttributeList.getValue("HRef");
          setBase(str);
          return;
        } 
        if (param1String.equals("Remap")) {
          String str1 = param1AttributeList.getValue("SystemID");
          String str2 = param1AttributeList.getValue("HRef");
          if (!this.this$0.isURL(str2))
            str2 = String.valueOf(this.base) + str2; 
          this.this$0.addSystemMapping(str1, str2);
          return;
        } 
      } catch (IOException iOException) {
        throw new SAXException(iOException);
      } 
    }
    
    class Resolver implements EntityResolver {
      private final XCatalog.Parser this$1;
      
      public InputSource resolveEntity(String param2String1, String param2String2) throws SAXException, IOException {
        if (param2String1 != null && param2String1.equals("-//DTD XCatalog//EN")) {
          InputSource inputSource = new InputSource();
          inputSource.setPublicId(param2String1);
          InputStream inputStream = getClass().getResourceAsStream("xcatalog.dtd");
          inputSource.setByteStream(inputStream);
          inputSource.setCharacterStream(new InputStreamReader(inputStream));
          return inputSource;
        } 
        return null;
      }
      
      Resolver(XCatalog.Parser this$0) {
        this.this$1 = this$0;
        this.this$1 = this$0;
      }
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\XCatalog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */