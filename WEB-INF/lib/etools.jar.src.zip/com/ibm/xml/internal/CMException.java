package com.ibm.xml.internal;

import com.ibm.xml.framework.XMLErrorHandler;

class CMException extends Exception {
  final int fUnused = -1000;
  
  private int fErrorCode;
  
  CMException(int paramInt) { this.fErrorCode = paramInt; }
  
  void send(XMLErrorHandler paramXMLErrorHandler) throws Exception { paramXMLErrorHandler.error(this.fErrorCode); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\CMException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */