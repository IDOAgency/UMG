package com.ibm.xml.internal;

import com.ibm.xml.framework.StringPool;

class CMLeaf extends CMNode {
  private int fElementIndex;
  
  private int fPosition = -1;
  
  CMLeaf(int paramInt1, int paramInt2, int paramInt3) throws CMException {
    super(paramInt1);
    if (type() != 0)
      throw new CMException(155); 
    this.fElementIndex = paramInt2;
    this.fPosition = paramInt3;
  }
  
  CMLeaf(int paramInt1, int paramInt2) throws CMException {
    super(paramInt1);
    if (type() != 0)
      throw new CMException(155); 
    this.fElementIndex = paramInt2;
  }
  
  final int getElemIndex() { return this.fElementIndex; }
  
  final int getPosition() { return this.fPosition; }
  
  final void setPosition(int paramInt) { this.fPosition = paramInt; }
  
  boolean isNullable() throws CMException { return !(this.fPosition != -1); }
  
  String toString(StringPool paramStringPool) {
    StringBuffer stringBuffer = new StringBuffer(paramStringPool.toString(this.fElementIndex));
    if (this.fPosition >= 0)
      stringBuffer.append(" (Pos:" + (new Integer(this.fPosition)).toString() + ")"); 
    return stringBuffer.toString();
  }
  
  protected void calcFirstPos(CMStateSet paramCMStateSet) throws CMException {
    if (this.fPosition == -1) {
      paramCMStateSet.zeroBits();
      return;
    } 
    paramCMStateSet.setBit(this.fPosition);
  }
  
  protected void calcLastPos(CMStateSet paramCMStateSet) throws CMException {
    if (this.fPosition == -1) {
      paramCMStateSet.zeroBits();
      return;
    } 
    paramCMStateSet.setBit(this.fPosition);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\CMLeaf.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */