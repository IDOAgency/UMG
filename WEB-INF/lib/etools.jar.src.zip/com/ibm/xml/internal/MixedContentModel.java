package com.ibm.xml.internal;

import com.ibm.xml.framework.ContentModel;
import com.ibm.xml.framework.ContentSpecNode;
import com.ibm.xml.framework.ElementDeclPool;
import com.ibm.xml.framework.InsertableElementsInfo;

class MixedContentModel implements ContentModel {
  private int fCount = 0;
  
  private int[] fChildren;
  
  public MixedContentModel(ElementDeclPool paramElementDeclPool, int paramInt) throws CMException {
    byte b1 = 64;
    int[] arrayOfInt = new int[b1];
    ContentSpecNode contentSpecNode = new ContentSpecNode();
    try {
      this.fCount = buildContentList(paramElementDeclPool.getContentSpec(paramInt), arrayOfInt, 0, contentSpecNode, paramElementDeclPool);
    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
      b1 *= 2;
      arrayOfInt = new int[b1];
      this.fCount = 0;
    } 
    this.fChildren = new int[this.fCount];
    for (byte b2 = 0; b2 < this.fCount; b2++)
      this.fChildren[b2] = arrayOfInt[b2]; 
  }
  
  public int validateContent(int paramInt, int[] paramArrayOfInt) throws Exception {
    for (byte b = 0; b < paramInt; b++) {
      int i = paramArrayOfInt[b];
      if (i != -1) {
        byte b1;
        for (b1 = 0; b1 < this.fCount && i != this.fChildren[b1]; b1++);
        if (b1 == this.fCount)
          return b; 
      } 
    } 
    return -1;
  }
  
  public int whatCanGoHere(boolean paramBoolean, InsertableElementsInfo paramInsertableElementsInfo) throws Exception {
    for (int i = paramInsertableElementsInfo.insertAt; i < paramInsertableElementsInfo.childCount; i++)
      paramInsertableElementsInfo.curChildren[i] = paramInsertableElementsInfo.curChildren[i + 1]; 
    paramInsertableElementsInfo.childCount--;
    int j = validateContent(paramInsertableElementsInfo.childCount, paramInsertableElementsInfo.curChildren);
    if (j != -1 && j < paramInsertableElementsInfo.insertAt)
      return j; 
    paramInsertableElementsInfo.canHoldPCData = true;
    paramInsertableElementsInfo.isValidEOC = true;
    paramInsertableElementsInfo.resultsCount = this.fCount;
    if (paramInsertableElementsInfo.results == null || paramInsertableElementsInfo.results.length < paramInsertableElementsInfo.resultsCount)
      paramInsertableElementsInfo.results = new boolean[paramInsertableElementsInfo.resultsCount]; 
    if (paramInsertableElementsInfo.possibleChildren == null || paramInsertableElementsInfo.possibleChildren.length < paramInsertableElementsInfo.resultsCount)
      paramInsertableElementsInfo.possibleChildren = new int[paramInsertableElementsInfo.resultsCount]; 
    boolean bool = true;
    if (paramBoolean && j < paramInsertableElementsInfo.childCount)
      bool = false; 
    for (byte b = 0; b < this.fCount; b++) {
      paramInsertableElementsInfo.possibleChildren[b] = this.fChildren[b];
      paramInsertableElementsInfo.results[b] = bool;
    } 
    return -1;
  }
  
  private final int buildContentList(int paramInt1, int[] paramArrayOfInt, int paramInt2, ContentSpecNode paramContentSpecNode, ElementDeclPool paramElementDeclPool) throws CMException {
    paramElementDeclPool.getContentSpecNode(paramInt1, paramContentSpecNode);
    if (paramContentSpecNode.type == 0) {
      paramArrayOfInt[paramInt2++] = paramContentSpecNode.value;
      return paramInt2;
    } 
    int i = paramContentSpecNode.value;
    int j = paramContentSpecNode.otherValue;
    if (paramContentSpecNode.type == 4 || paramContentSpecNode.type == 5) {
      paramInt2 = buildContentList(i, paramArrayOfInt, paramInt2, paramContentSpecNode, paramElementDeclPool);
      paramInt2 = buildContentList(j, paramArrayOfInt, paramInt2, paramContentSpecNode, paramElementDeclPool);
    } else if (paramContentSpecNode.type == 1 || paramContentSpecNode.type == 2 || paramContentSpecNode.type == 3) {
      paramInt2 = buildContentList(i, paramArrayOfInt, paramInt2, paramContentSpecNode, paramElementDeclPool);
    } else {
      throw new CMException(152);
    } 
    return paramInt2;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\MixedContentModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */