package com.ibm.xml.internal;

public final class StringHasher {
  public static int hashString(String paramString, int paramInt) {
    char c = Character.MIN_VALUE;
    for (byte b = 0; b < paramInt; b++) {
      byte b1 = c >> 24;
      c += c * 37 + b1 + paramString.charAt(b);
    } 
    int i = c;
    i &= Integer.MAX_VALUE;
    return (i == 0) ? 1 : i;
  }
  
  public static int hashChar(int paramInt1, int paramInt2, int paramInt3) {
    int i = paramInt1 >> 24;
    return paramInt1 * 37 + i + paramInt3;
  }
  
  public static int finishHash(int paramInt) {
    paramInt &= Integer.MAX_VALUE;
    return (paramInt == 0) ? 1 : paramInt;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\StringHasher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */