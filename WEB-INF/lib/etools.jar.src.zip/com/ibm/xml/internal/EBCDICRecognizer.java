package com.ibm.xml.internal;

import com.ibm.xml.framework.ChunkyByteArray;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.XMLDeclRecognizer;
import com.ibm.xml.framework.XMLReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import org.xml.sax.InputSource;

public class EBCDICRecognizer extends XMLDeclRecognizer {
  public XMLReader recognize(ParserState paramParserState, InputSource paramInputSource, ChunkyByteArray paramChunkyByteArray, boolean paramBoolean) throws Exception {
    XMLReader xMLReader = null;
    byte b1 = paramChunkyByteArray.byteAt(0);
    byte b2 = paramChunkyByteArray.byteAt(1);
    byte b3 = paramChunkyByteArray.byteAt(2);
    byte b4 = paramChunkyByteArray.byteAt(3);
    if (b1 != 76 || b2 != 111 || b3 != -89 || b4 != -108)
      return xMLReader; 
    CharReader charReader = new CharReader(paramParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), new InputStreamReader(paramChunkyByteArray, "CP037"));
    int i = prescanXMLDeclOrTextDecl(charReader, paramBoolean);
    if (i == -1) {
      paramChunkyByteArray.rewind();
      return new CharReader(paramParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), new InputStreamReader(paramChunkyByteArray, "UTF8"));
    } 
    String str1 = paramParserState.getStringPool().orphanString(i).toUpperCase();
    if ("ISO-10646-UCS-2".equals(str1))
      throw new UnsupportedEncodingException(str1); 
    if ("ISO-10646-UCS-4".equals(str1))
      throw new UnsupportedEncodingException(str1); 
    if ("UTF-16".equals(str1))
      throw new UnsupportedEncodingException(str1); 
    String str2 = MIME2Java.convert(str1);
    if (str2 == null)
      if (paramParserState.getAllowJavaEncodingName()) {
        str2 = str1;
      } else {
        throw new UnsupportedEncodingException(str1);
      }  
    try {
      paramChunkyByteArray.rewind();
      xMLReader = new CharReader(paramParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), new InputStreamReader(paramChunkyByteArray, str2));
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw unsupportedEncodingException;
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return xMLReader;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\EBCDICRecognizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */