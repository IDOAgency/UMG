package com.ibm.xml.internal;

class CMBinOp extends CMNode {
  private CMNode fLeftChild;
  
  private CMNode fRightChild;
  
  CMBinOp(int paramInt, CMNode paramCMNode1, CMNode paramCMNode2) throws CMException {
    super(paramInt);
    if (type() != 4 && type() != 5)
      throw new CMException(154); 
    this.fLeftChild = paramCMNode1;
    this.fRightChild = paramCMNode2;
  }
  
  final CMNode getLeft() { return this.fLeftChild; }
  
  final CMNode getRight() { return this.fRightChild; }
  
  boolean isNullable() throws CMException {
    if (type() == 4)
      return !(!this.fLeftChild.isNullable() && !this.fRightChild.isNullable()); 
    if (type() == 5)
      return !(!this.fLeftChild.isNullable() || !this.fRightChild.isNullable()); 
    throw new CMException(154);
  }
  
  protected void calcFirstPos(CMStateSet paramCMStateSet) throws CMException {
    if (type() == 4) {
      paramCMStateSet.setTo(this.fLeftChild.firstPos());
      paramCMStateSet.union(this.fRightChild.firstPos());
      return;
    } 
    if (type() == 5) {
      paramCMStateSet.setTo(this.fLeftChild.firstPos());
      if (this.fLeftChild.isNullable()) {
        paramCMStateSet.union(this.fRightChild.firstPos());
        return;
      } 
    } else {
      throw new CMException(154);
    } 
  }
  
  protected void calcLastPos(CMStateSet paramCMStateSet) throws CMException {
    if (type() == 4) {
      paramCMStateSet.setTo(this.fLeftChild.lastPos());
      paramCMStateSet.union(this.fRightChild.lastPos());
      return;
    } 
    if (type() == 5) {
      paramCMStateSet.setTo(this.fRightChild.lastPos());
      if (this.fRightChild.isNullable()) {
        paramCMStateSet.union(this.fLeftChild.lastPos());
        return;
      } 
    } else {
      throw new CMException(154);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\CMBinOp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */