package com.ibm.xml.internal;

import com.ibm.xml.framework.ChunkyByteArray;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLDeclRecognizer;
import com.ibm.xml.framework.XMLEntityHandler;
import com.ibm.xml.framework.XMLReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Stack;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;

public final class DefaultEntityHandler implements XMLEntityHandler {
  private static final boolean DEBUG = false;
  
  private Stack fRecognizers;
  
  private Stack fInputSourceStack;
  
  private ParserState fParserState;
  
  private EntityResolver fResolver;
  
  public DefaultEntityHandler(ParserState paramParserState) {
    this.fParserState = paramParserState;
    this.fInputSourceStack = new Stack();
    initializeRecognizers();
  }
  
  public void reset(ParserState paramParserState) {
    this.fParserState = paramParserState;
    this.fInputSourceStack.removeAllElements();
  }
  
  public void addRecognizer(XMLDeclRecognizer paramXMLDeclRecognizer) { this.fRecognizers.push(paramXMLDeclRecognizer); }
  
  public void setEntityResolver(EntityResolver paramEntityResolver) { this.fResolver = paramEntityResolver; }
  
  public EntityResolver getEntityResolver() { return this.fResolver; }
  
  public InputSource resolveEntity(int paramInt1, int paramInt2) throws Exception {
    EntityResolver entityResolver = this.fResolver;
    if (entityResolver != null) {
      StringPool stringPool = this.fParserState.getStringPool();
      String str1 = stringPool.toString(paramInt1);
      String str2 = stringPool.toString(paramInt2);
      return entityResolver.resolveEntity(str1, str2);
    } 
    return null;
  }
  
  public int expandSystemId(int paramInt) {
    if (paramInt != -1) {
      ParserState parserState = this.fParserState;
      StringPool stringPool = parserState.getStringPool();
      try {
        String str = stringPool.toString(paramInt);
        URL uRL = expandSystemId(str);
        if (uRL != null)
          return stringPool.addString(uRL.toString()); 
      } catch (Exception exception) {}
    } 
    return paramInt;
  }
  
  public XMLReader createReader(InputSource paramInputSource, boolean paramBoolean) throws Exception {
    if (paramInputSource.getCharacterStream() != null)
      return new CharReader(this.fParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), paramInputSource.getCharacterStream()); 
    if (paramInputSource.getEncoding() != null && paramInputSource.getByteStream() != null)
      return new CharReader(this.fParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), new InputStreamReader(paramInputSource.getByteStream(), paramInputSource.getEncoding())); 
    InputStream inputStream = paramInputSource.getByteStream();
    if (inputStream == null)
      try {
        String str = paramInputSource.getSystemId();
        if (str != null)
          try {
            ParserState parserState = this.fParserState;
            StringPool stringPool = parserState.getStringPool();
            int i = stringPool.addString(str);
            int j = parserState.getEntityHandler().expandSystemId(i);
            if (i != j) {
              str = stringPool.orphanString(j);
              paramInputSource.setSystemId(str);
            } 
            stringPool.releaseString(i);
          } catch (Exception exception) {} 
        URL uRL = new URL(str);
        inputStream = uRL.openStream();
      } catch (Exception exception) {
        throw exception;
      }  
    ChunkyByteArray chunkyByteArray = new ChunkyByteArray(inputStream);
    XMLReader xMLReader = callRecognizers(paramInputSource, paramBoolean, chunkyByteArray);
    if (xMLReader == null) {
      ParserState parserState = this.fParserState;
      if (true) {
        xMLReader = new UTF8CharReader(this.fParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), chunkyByteArray);
      } else {
        xMLReader = new UTF8Reader(this.fParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), chunkyByteArray);
      } 
    } 
    return xMLReader;
  }
  
  public void startInputSource(InputSource paramInputSource) { this.fInputSourceStack.push(paramInputSource); }
  
  public void endInputSource(InputSource paramInputSource) {
    InputSource inputSource = (InputSource)this.fInputSourceStack.pop();
    if (inputSource != paramInputSource)
      System.err.println("InputSource stack out-of-sync"); 
  }
  
  public URL expandSystemId(String paramString) throws Exception {
    String str;
    if (paramString == null)
      paramString = "/"; 
    try {
      str = new URL(paramString);
      if (str != null)
        return null; 
    } catch (MalformedURLException malformedURLException) {}
    paramString = fixURI(paramString);
    try {
      InputSource inputSource = (InputSource)this.fInputSourceStack.peek();
      str = inputSource.getSystemId();
    } catch (Exception exception) {
      str = null;
    } 
    URL uRL = null;
    if (str == null) {
      String str1;
      try {
        str1 = fixURI(System.getProperty("user.dir"));
      } catch (SecurityException securityException) {
        str1 = "";
      } 
      if (!str1.endsWith("/"))
        str1 = String.valueOf(str1) + "/"; 
      uRL = new URL("file", "", str1);
    } else {
      uRL = new URL(str);
    } 
    return new URL(uRL, paramString);
  }
  
  private void initializeRecognizers() {
    if (this.fRecognizers == null) {
      this.fRecognizers = new Stack();
      this.fRecognizers.push(new EBCDICRecognizer());
      this.fRecognizers.push(new UCSRecognizer());
      this.fRecognizers.push(new UTF8Recognizer());
    } 
  }
  
  private XMLReader callRecognizers(InputSource paramInputSource, boolean paramBoolean, ChunkyByteArray paramChunkyByteArray) throws Exception {
    for (int i = this.fRecognizers.size() - 1; i >= 0; i--) {
      XMLDeclRecognizer xMLDeclRecognizer = (XMLDeclRecognizer)this.fRecognizers.elementAt(i);
      XMLReader xMLReader = xMLDeclRecognizer.recognize(this.fParserState, paramInputSource, paramChunkyByteArray, paramBoolean);
      if (xMLReader != null)
        return xMLReader; 
    } 
    return null;
  }
  
  private static String fixURI(String paramString) {
    paramString = paramString.replace(File.separatorChar, '/');
    if (paramString.length() >= 2) {
      char c = paramString.charAt(1);
      if (c == ':') {
        char c1 = Character.toUpperCase(paramString.charAt(0));
        if (c1 >= 'A' && c1 <= 'Z')
          paramString = "/" + paramString; 
      } 
    } 
    return paramString;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\DefaultEntityHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */