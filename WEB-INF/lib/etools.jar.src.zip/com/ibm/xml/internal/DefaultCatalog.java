package com.ibm.xml.internal;

import com.ibm.xml.framework.Catalog;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class DefaultCatalog implements Catalog {
  private Hashtable publicMap = new Hashtable();
  
  private Hashtable systemMap = new Hashtable();
  
  public void addPublicMapping(String paramString1, String paramString2) { this.publicMap.put(paramString1, paramString2); }
  
  public void removePublicMapping(System paramSystem) { this.publicMap.remove(paramSystem); }
  
  public Enumeration getPublicMappingKeys() { return this.publicMap.keys(); }
  
  public String getPublicMapping(String paramString) { return (String)this.publicMap.get(paramString); }
  
  public void addSystemMapping(String paramString1, String paramString2) { this.systemMap.put(paramString1, paramString2); }
  
  public void removeSystemMapping(String paramString) { this.systemMap.remove(paramString); }
  
  public Enumeration getSystemMappingKeys() { return this.systemMap.keys(); }
  
  public String getSystemMapping(String paramString) { return (String)this.systemMap.get(paramString); }
  
  public InputSource resolveEntity(String paramString1, String paramString2) throws SAXException, IOException {
    if (paramString1 != null) {
      String str = getPublicMapping(paramString1);
      if (str != null)
        return new InputSource(str); 
    } 
    if (paramString2 != null) {
      String str = getSystemMapping(paramString2);
      if (str == null)
        str = paramString2; 
      return new InputSource(str);
    } 
    return null;
  }
  
  public void loadCatalog(InputSource paramInputSource) throws Exception { throw new Exception("loadCatalog not implemented"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\DefaultCatalog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */