package com.ibm.xml.internal;

import com.ibm.xml.framework.ChunkyByteArray;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.XMLDeclRecognizer;
import com.ibm.xml.framework.XMLReader;
import java.io.IOException;
import org.xml.sax.InputSource;

public class UCSRecognizer extends XMLDeclRecognizer {
  public XMLReader recognize(ParserState paramParserState, InputSource paramInputSource, ChunkyByteArray paramChunkyByteArray, boolean paramBoolean) throws IOException {
    UCSReader uCSReader = null;
    byte b = paramChunkyByteArray.byteAt(0);
    if (b == 0) {
      byte b1 = paramChunkyByteArray.byteAt(1);
      if (b1 == 0) {
        if (paramChunkyByteArray.byteAt(2) == 0 && paramChunkyByteArray.byteAt(3) == 60)
          uCSReader = new UCSReader(paramParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), paramChunkyByteArray, 0); 
      } else if (b1 == 60 && paramChunkyByteArray.byteAt(2) == 0 && paramChunkyByteArray.byteAt(3) == 63) {
        uCSReader = new UCSReader(paramParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), paramChunkyByteArray, 4);
      } 
    } else if (b == 60) {
      byte b1 = paramChunkyByteArray.byteAt(1);
      if (b1 == 0) {
        byte b2 = paramChunkyByteArray.byteAt(2);
        if (paramChunkyByteArray.byteAt(3) == 0)
          if (b2 == 0) {
            uCSReader = new UCSReader(paramParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), paramChunkyByteArray, 1);
          } else if (b2 == 63) {
            uCSReader = new UCSReader(paramParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), paramChunkyByteArray, 5);
          }  
      } 
    } else if (b == -2) {
      if (paramChunkyByteArray.byteAt(1) == -1)
        uCSReader = new UCSReader(paramParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), paramChunkyByteArray, 2); 
    } else if (b == -1 && paramChunkyByteArray.byteAt(1) == -2) {
      uCSReader = new UCSReader(paramParserState, paramInputSource.getPublicId(), paramInputSource.getSystemId(), paramChunkyByteArray, 3);
    } 
    return uCSReader;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\internal\UCSRecognizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */