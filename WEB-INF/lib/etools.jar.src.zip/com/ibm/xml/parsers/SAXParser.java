package com.ibm.xml.parsers;

import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLParser;
import org.xml.sax.DTDHandler;
import org.xml.sax.DocumentHandler;
import org.xml.sax.EntityResolver;

public class SAXParser extends XMLParser {
  private DTDHandler fDTDHandler;
  
  private DocumentHandler fDocumentHandler;
  
  public SAXParser() {
    getParserState().useDefaultStringPool();
    getParserState().useDefaultAttrPool();
    getParserState().useDefaultEntityPool();
    getParserState().useDefaultElementDeclPool();
  }
  
  public void setEntityResolver(EntityResolver paramEntityResolver) { getEntityHandler().setEntityResolver(paramEntityResolver); }
  
  public void setDTDHandler(DTDHandler paramDTDHandler) {
    this.fDTDHandler = paramDTDHandler;
    setDocumentTypeHandler((paramDTDHandler == null) ? null : this);
  }
  
  public void setDocumentHandler(DocumentHandler paramDocumentHandler) {
    this.fDocumentHandler = paramDocumentHandler;
    setDocumentHandler((paramDocumentHandler == null) ? null : this);
  }
  
  public void doctypeDecl(int paramInt) throws Exception {}
  
  public void startInternalSubset() {}
  
  public void endInternalSubset() {}
  
  public void startExternalSubset(int paramInt1, int paramInt2) throws Exception {}
  
  public void endExternalSubset() {}
  
  public void elementDecl(int paramInt) throws Exception {}
  
  public void attlistDecl(int paramInt1, int paramInt2) throws Exception {}
  
  public void internalEntityDecl(int paramInt) throws Exception {}
  
  public void externalEntityDecl(int paramInt) throws Exception {}
  
  public void unparsedEntityDecl(int paramInt) throws Exception {
    String str1 = getParserState().getStringPool().toString(getParserState().getEntityPool().getEntityName(paramInt));
    String str2 = getParserState().getStringPool().toString(getParserState().getEntityPool().getPublicId(paramInt));
    String str3 = getParserState().getStringPool().toString(getParserState().getEntityPool().getSystemId(paramInt));
    String str4 = getParserState().getStringPool().toString(getParserState().getEntityPool().getNotationName(paramInt));
    this.fDTDHandler.unparsedEntityDecl(str1, str2, str3, str4);
  }
  
  public void notationDecl(int paramInt) throws Exception {
    String str1 = getParserState().getStringPool().toString(getParserState().getEntityPool().getNotationName(paramInt));
    String str2 = getParserState().getStringPool().toString(getParserState().getEntityPool().getPublicId(paramInt));
    String str3 = getParserState().getStringPool().toString(getParserState().getEntityPool().getSystemId(paramInt));
    this.fDTDHandler.notationDecl(str1, str2, str3);
  }
  
  public boolean sendCharDataAsCharArray() { return true; }
  
  public void startDocument(int paramInt1, int paramInt2, int paramInt3) throws Exception {
    StringPool stringPool = getParserState().getStringPool();
    stringPool.orphanString(paramInt1);
    stringPool.orphanString(paramInt2);
    stringPool.orphanString(paramInt3);
    this.fDocumentHandler.setDocumentLocator(getLocator());
    this.fDocumentHandler.startDocument();
  }
  
  public void endDocument() { this.fDocumentHandler.endDocument(); }
  
  public void startElement(int paramInt1, int paramInt2) throws Exception {
    this.fDocumentHandler.startElement(getParserState().getStringPool().toString(paramInt1), getParserState().getAttrPool().getAttributeList(paramInt2));
    getParserState().getAttrPool().releaseAttrList(paramInt2);
  }
  
  public void endElement(int paramInt) throws Exception { this.fDocumentHandler.endElement(getParserState().getStringPool().toString(paramInt)); }
  
  public void startEntityReference(int paramInt) throws Exception {}
  
  public void endEntityReference(int paramInt) throws Exception {}
  
  public void characters(int paramInt, boolean paramBoolean) throws Exception {
    String str = getParserState().getStringPool().orphanString(paramInt);
    this.fDocumentHandler.characters(str.toCharArray(), 0, str.length());
  }
  
  public void ignorableWhitespace(int paramInt, boolean paramBoolean) throws Exception {
    String str = getParserState().getStringPool().orphanString(paramInt);
    this.fDocumentHandler.ignorableWhitespace(str.toCharArray(), 0, str.length());
  }
  
  public void processingInstruction(int paramInt1, int paramInt2) throws Exception { this.fDocumentHandler.processingInstruction(getParserState().getStringPool().orphanString(paramInt1), getParserState().getStringPool().orphanString(paramInt2)); }
  
  public void comment(int paramInt) throws Exception { getParserState().getStringPool().releaseString(paramInt); }
  
  public void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) throws Exception { this.fDocumentHandler.characters(paramArrayOfChar, paramInt1, paramInt2); }
  
  public void ignorableWhitespace(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) throws Exception { this.fDocumentHandler.ignorableWhitespace(paramArrayOfChar, paramInt1, paramInt2); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parsers\SAXParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */