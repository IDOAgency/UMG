package com.ibm.xml.parsers;

public class ValidatingParser extends NonValidatingParser {
  public ValidatingParser() { useDefaultValidationHandler(); }
  
  public void reset() {
    super.reset();
    getValidationHandler().reset(getParserState());
  }
  
  protected void resetOrCopy() {
    super.resetOrCopy();
    getValidationHandler().reset(getParserState());
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parsers\ValidatingParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */