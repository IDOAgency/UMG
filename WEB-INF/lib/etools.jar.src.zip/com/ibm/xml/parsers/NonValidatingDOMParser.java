package com.ibm.xml.parsers;

import com.ibm.xml.dom.AttrImpl;
import com.ibm.xml.dom.DocumentImpl;
import com.ibm.xml.dom.DocumentTypeImpl;
import com.ibm.xml.dom.ElementDefinitionImpl;
import com.ibm.xml.dom.EntityImpl;
import com.ibm.xml.dom.NodeImpl;
import com.ibm.xml.dom.TextImpl;
import com.ibm.xml.framework.AttrPool;
import com.ibm.xml.framework.ElementDeclPool;
import com.ibm.xml.framework.EntityPool;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLParser;
import java.util.Stack;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.Entity;
import org.w3c.dom.EntityReference;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Notation;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;
import org.xml.sax.AttributeList;

public class NonValidatingDOMParser extends XMLParser {
  public static final int FULL = 0;
  
  public static final int DEFERRED = 1;
  
  public static final String DEFERRED_DOCUMENT_CLASS = DocumentImpl.class.getName();
  
  private static final boolean DEBUG_ATTLIST_DECL = false;
  
  protected int fDocumentIndex = -1;
  
  protected int fDocumentTypeIndex = -1;
  
  protected int fCurrentNodeIndex = -1;
  
  protected DocumentType fDocumentType;
  
  protected Node fCurrentNode;
  
  protected Stack fNodeStack = new Stack();
  
  protected Document fDocument;
  
  protected DocumentImpl fDocumentImpl;
  
  protected boolean fExpandEntityReferences = false;
  
  protected int fNodeExpansion = 1;
  
  protected boolean fWithinElement = false;
  
  int fAmpIndex = -1;
  
  int fLtIndex = -1;
  
  int fGtIndex = -1;
  
  int fAposIndex = -1;
  
  int fQuotIndex = -1;
  
  protected AttrPool fAttrPool;
  
  protected ElementDeclPool fElementDeclPool;
  
  protected EntityPool fEntityPool;
  
  protected StringPool fStringPool;
  
  protected String fDocumentClass = DEFERRED_DOCUMENT_CLASS;
  
  private int[] nodestack = new int[16];
  
  private int stacktop;
  
  public NonValidatingDOMParser() {
    setDocumentHandler(this);
    setDocumentTypeHandler(this);
    this.fExpandEntityReferences = false;
    this.fNodeExpansion = 1;
    ParserState parserState = getParserState();
    parserState.useDefaultStringPool();
    parserState.useDefaultAttrPool();
    parserState.useDefaultEntityPool();
    parserState.useDefaultElementDeclPool();
    init(parserState);
  }
  
  public void reset() {
    super.reset();
    init(getParserState());
  }
  
  protected void resetOrCopy() {
    super.resetOrCopy();
    init(getParserState());
  }
  
  protected void init(ParserState paramParserState) {
    this.fDocumentType = null;
    this.fCurrentNode = null;
    this.fNodeStack.removeAllElements();
    this.fDocumentIndex = -1;
    this.fDocumentTypeIndex = -1;
    this.fCurrentNodeIndex = -1;
    this.fDocumentImpl = null;
    this.fDocument = null;
    this.fWithinElement = false;
    this.fAttrPool = paramParserState.getAttrPool();
    this.fElementDeclPool = paramParserState.getElementDeclPool();
    this.fEntityPool = paramParserState.getEntityPool();
    this.fStringPool = paramParserState.getStringPool();
    this.fAmpIndex = this.fStringPool.addSymbol("amp");
    this.fLtIndex = this.fStringPool.addSymbol("lt");
    this.fGtIndex = this.fStringPool.addSymbol("gt");
    this.fAposIndex = this.fStringPool.addSymbol("apos");
    this.fQuotIndex = this.fStringPool.addSymbol("quot");
  }
  
  protected void checkHandlers() { super.checkHandlers(); }
  
  public void setExpandEntityReferences(boolean paramBoolean) { this.fExpandEntityReferences = paramBoolean; }
  
  public boolean getExpandEntityReferences() { return this.fExpandEntityReferences; }
  
  public void setNodeExpansion(int paramInt) {
    if (paramInt != 0 && paramInt != 1) {
      this.fNodeExpansion = 1;
      return;
    } 
    this.fNodeExpansion = paramInt;
  }
  
  public int getNodeExpansion() { return this.fNodeExpansion; }
  
  public Node getCurrentNode() { return this.fCurrentNode; }
  
  public void doctypeDecl(int paramInt) {
    if (this.fNodeExpansion == 0) {
      if (this.fDocumentImpl != null) {
        String str = this.fStringPool.toString(paramInt);
        this.fDocumentType = this.fDocumentImpl.createDocumentType(str);
        this.fDocumentImpl.appendChild(this.fDocumentType);
        this.fCurrentNode = this.fDocumentType;
        return;
      } 
    } else if (this.fNodeExpansion == 1) {
      this.fDocumentTypeIndex = this.fDocumentImpl.createDocumentType(paramInt);
      this.fDocumentImpl.appendChild(this.fDocumentIndex, this.fDocumentTypeIndex);
      this.fCurrentNodeIndex = this.fDocumentTypeIndex;
    } 
  }
  
  public void startInternalSubset() {}
  
  public void endInternalSubset() {
    if (this.fNodeExpansion == 0) {
      this.fCurrentNode = this.fDocument;
      return;
    } 
    if (this.fNodeExpansion == 1)
      this.fCurrentNodeIndex = this.fDocumentIndex; 
  }
  
  public void startExternalSubset(int paramInt1, int paramInt2) throws Exception {
    if (this.fNodeExpansion == 0) {
      this.fCurrentNode = this.fDocumentType;
      return;
    } 
    if (this.fNodeExpansion == 1)
      this.fCurrentNodeIndex = this.fDocumentTypeIndex; 
  }
  
  public void endExternalSubset() {
    if (this.fNodeExpansion == 0) {
      this.fCurrentNode = this.fDocument;
      return;
    } 
    if (this.fNodeExpansion == 1)
      this.fCurrentNodeIndex = this.fDocumentIndex; 
  }
  
  public void elementDecl(int paramInt) {}
  
  public void attlistDecl(int paramInt1, int paramInt2) throws Exception {
    if (this.fNodeExpansion == 0) {
      if (this.fDocumentImpl != null) {
        int i = this.fElementDeclPool.getAttValue(paramInt2);
        if (i != -1) {
          int j = this.fElementDeclPool.getElementName(paramInt1);
          String str1 = this.fStringPool.toString(j);
          NamedNodeMap namedNodeMap = ((DocumentTypeImpl)this.fDocumentType).getElements();
          ElementDefinitionImpl elementDefinitionImpl = (ElementDefinitionImpl)namedNodeMap.getNamedItem(str1);
          if (elementDefinitionImpl == null) {
            elementDefinitionImpl = this.fDocumentImpl.createElementDefinition(str1);
            ((DocumentTypeImpl)this.fDocumentType).getElements().setNamedItem(elementDefinitionImpl);
          } 
          int k = this.fElementDeclPool.getAttName(paramInt2);
          String str2 = this.fStringPool.toString(k);
          String str3 = this.fStringPool.toString(i);
          AttrImpl attrImpl = (AttrImpl)this.fDocumentImpl.createAttribute(str2);
          attrImpl.setValue(str3);
          attrImpl.setSpecified(false);
          elementDefinitionImpl.getAttributes().setNamedItem(attrImpl);
          return;
        } 
      } 
    } else if (this.fNodeExpansion == 1) {
      int i = this.fElementDeclPool.getAttValue(paramInt2);
      if (i != -1) {
        int j = this.fElementDeclPool.getElementName(paramInt1);
        int k = this.fDocumentImpl.lookupElementDefinition(j);
        if (k == -1) {
          k = this.fDocumentImpl.createElementDefinition(j);
          this.fDocumentImpl.appendChild(this.fDocumentTypeIndex, k);
        } 
        int m = this.fElementDeclPool.getAttName(paramInt2);
        int n = this.fDocumentImpl.createAttribute(m, i, false);
        this.fDocumentImpl.appendChild(k, n);
      } 
    } 
  }
  
  public void internalEntityDecl(int paramInt) {
    int i = this.fEntityPool.getEntityName(paramInt);
    if (this.fNodeExpansion == 0) {
      if (this.fDocumentImpl != null) {
        if (this.fDocumentType == null)
          return; 
        Entity entity = this.fDocumentImpl.createEntity(this.fStringPool.toString(i));
        this.fDocumentType.getEntities().setNamedItem(entity);
        return;
      } 
    } else if (this.fNodeExpansion == 1) {
      if (this.fDocumentTypeIndex == -1)
        return; 
      int j = this.fDocumentImpl.createEntity(paramInt);
      this.fDocumentImpl.appendChild(this.fDocumentTypeIndex, j);
    } 
  }
  
  public void externalEntityDecl(int paramInt) {
    int i = this.fEntityPool.getEntityName(paramInt);
    int j = this.fEntityPool.getPublicId(paramInt);
    int k = this.fEntityPool.getSystemId(paramInt);
    if (this.fNodeExpansion == 0) {
      if (this.fDocumentImpl != null) {
        if (this.fDocumentType == null)
          return; 
        EntityImpl entityImpl = (EntityImpl)this.fDocumentImpl.createEntity(this.fStringPool.toString(i));
        entityImpl.setPublicId(this.fStringPool.toString(j));
        entityImpl.setSystemId(this.fStringPool.toString(k));
        this.fDocumentType.getEntities().setNamedItem(entityImpl);
        return;
      } 
    } else if (this.fNodeExpansion == 1) {
      if (this.fDocumentTypeIndex == -1)
        return; 
      int m = this.fDocumentImpl.createEntity(paramInt);
      this.fDocumentImpl.appendChild(this.fDocumentTypeIndex, m);
    } 
  }
  
  public void unparsedEntityDecl(int paramInt) {
    int i = this.fEntityPool.getEntityName(paramInt);
    int j = this.fEntityPool.getPublicId(paramInt);
    int k = this.fEntityPool.getSystemId(paramInt);
    int m = this.fEntityPool.getNotationName(paramInt);
    if (this.fNodeExpansion == 0) {
      if (this.fDocumentImpl != null) {
        if (this.fDocumentType == null)
          return; 
        EntityImpl entityImpl = (EntityImpl)this.fDocumentImpl.createEntity(this.fStringPool.toString(i));
        entityImpl.setPublicId(this.fStringPool.toString(j));
        entityImpl.setSystemId(this.fStringPool.toString(k));
        entityImpl.setNotationName(this.fStringPool.toString(m));
        this.fDocumentType.getEntities().setNamedItem(entityImpl);
        return;
      } 
    } else if (this.fNodeExpansion == 1) {
      if (this.fDocumentTypeIndex == -1)
        return; 
      int n = this.fDocumentImpl.createEntity(paramInt);
      this.fDocumentImpl.appendChild(this.fDocumentTypeIndex, n);
    } 
  }
  
  public void notationDecl(int paramInt) {
    int i = this.fEntityPool.getEntityName(paramInt);
    if (this.fNodeExpansion == 0) {
      if (this.fDocumentImpl != null) {
        if (this.fDocumentType == null)
          return; 
        Notation notation = this.fDocumentImpl.createNotation(this.fStringPool.toString(i));
        this.fDocumentType.getNotations().setNamedItem(notation);
        return;
      } 
    } else if (this.fNodeExpansion == 1) {
      if (this.fDocumentTypeIndex == -1)
        return; 
      int j = this.fDocumentImpl.createNotation(paramInt);
      this.fDocumentImpl.appendChild(this.fDocumentTypeIndex, j);
    } 
  }
  
  public void setDocumentClass(String paramString) {
    if (paramString == null)
      paramString = DEFERRED_DOCUMENT_CLASS; 
    this.fDocumentClass = paramString;
    if (!paramString.equals(DEFERRED_DOCUMENT_CLASS))
      setNodeExpansion(0); 
  }
  
  public Document getDocument() { return this.fDocument; }
  
  public void startDocument(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 != -1)
      this.fStringPool.orphanString(paramInt1); 
    if (paramInt2 != -1)
      this.fStringPool.orphanString(paramInt2); 
    if (paramInt3 != -1)
      this.fStringPool.orphanString(paramInt3); 
    if (this.fNodeExpansion == 0) {
      try {
        this.fDocument = (Document)Class.forName(this.fDocumentClass).newInstance();
        if (this.fDocument instanceof DocumentImpl)
          this.fDocumentImpl = (DocumentImpl)this.fDocument; 
      } catch (Exception exception) {}
      this.fCurrentNode = this.fDocument;
      return;
    } 
    if (this.fNodeExpansion == 1) {
      this.fDocumentImpl = new DocumentImpl(getParserState());
      this.fDocument = this.fDocumentImpl;
      this.fDocumentIndex = this.fDocumentImpl.createDocument();
      this.fCurrentNodeIndex = this.fDocumentIndex;
    } 
  }
  
  public void endDocument() {}
  
  public void startElement(int paramInt1, int paramInt2) throws Exception {
    if (this.fNodeExpansion == 0) {
      this.fNodeStack.push(this.fCurrentNode);
      String str = this.fStringPool.toString(paramInt1);
      AttributeList attributeList = this.fAttrPool.getAttributeList(paramInt2);
      Element element = this.fDocument.createElement(str);
      int i = attributeList.getLength();
      for (byte b = 0; b < i; b++)
        element.setAttribute(attributeList.getName(b), attributeList.getValue(b)); 
      this.fAttrPool.releaseAttrList(paramInt2);
      this.fCurrentNode.appendChild(element);
      this.fCurrentNode = element;
      this.fWithinElement = true;
      return;
    } 
    if (this.fNodeExpansion == 1) {
      push(this.fCurrentNodeIndex);
      int i = this.fDocumentImpl.createElement(paramInt1, paramInt2);
      this.fDocumentImpl.appendChild(this.fCurrentNodeIndex, i);
      this.fCurrentNodeIndex = i;
      this.fWithinElement = true;
    } 
  }
  
  public void endElement(int paramInt) {
    if (this.fNodeExpansion == 0) {
      this.fCurrentNode = (Node)this.fNodeStack.pop();
      this.fWithinElement = false;
      return;
    } 
    if (this.fNodeExpansion == 1) {
      this.fCurrentNodeIndex = this.nodestack[--this.stacktop];
      this.fWithinElement = false;
    } 
  }
  
  public void startEntityReference(int paramInt) {
    if (this.fExpandEntityReferences)
      return; 
    int i = this.fEntityPool.getEntityName(paramInt);
    if (i == this.fAmpIndex || i == this.fGtIndex || i == this.fLtIndex || i == this.fAposIndex || i == this.fQuotIndex)
      return; 
    if (this.fNodeExpansion == 0) {
      this.fNodeStack.push(this.fCurrentNode);
      EntityReference entityReference = this.fDocument.createEntityReference(this.fStringPool.toString(i));
      if (entityReference == null)
        return; 
      this.fNodeStack.push(entityReference);
      this.fCurrentNode.appendChild(entityReference);
      this.fCurrentNode = entityReference;
      return;
    } 
    if (this.fNodeExpansion == 1) {
      push(this.fCurrentNodeIndex);
      int j = this.fDocumentImpl.createEntityReference(paramInt);
      push(j);
      this.fDocumentImpl.appendChild(this.fCurrentNodeIndex, j);
      this.fCurrentNodeIndex = j;
    } 
  }
  
  public void endEntityReference(int paramInt) {
    if (this.fExpandEntityReferences)
      return; 
    int i = this.fEntityPool.getEntityName(paramInt);
    if (i == this.fAmpIndex || i == this.fGtIndex || i == this.fLtIndex || i == this.fAposIndex || i == this.fQuotIndex)
      return; 
    if (this.fNodeExpansion == 0) {
      if (this.fDocumentImpl != null) {
        NodeImpl nodeImpl = (NodeImpl)this.fNodeStack.pop();
        this.fCurrentNode = (NodeImpl)this.fNodeStack.pop();
        if (nodeImpl.getNodeType() != 5)
          return; 
        NamedNodeMap namedNodeMap = this.fDocumentType.getEntities();
        String str = this.fStringPool.toString(i);
        Node node = namedNodeMap.getNamedItem(str);
        if (node == null || node.hasChildNodes())
          return; 
        Entity entity = (Entity)node;
        if (nodeImpl.hasChildNodes()) {
          NodeList nodeList = nodeImpl.getChildNodes();
          int j = nodeList.getLength();
          for (byte b = 0; b < j; b++) {
            Node node1 = nodeList.item(b).cloneNode(true);
            entity.appendChild(node1);
          } 
          return;
        } 
      } 
    } else if (this.fNodeExpansion == 1) {
      String str = this.fStringPool.toString(i);
      int j = this.nodestack[--this.stacktop];
      this.fCurrentNodeIndex = this.nodestack[--this.stacktop];
      if (this.fDocumentImpl.getNodeType(j) != 5)
        return; 
      j = this.fDocumentImpl.getFirstChild(j);
      if (this.fDocumentTypeIndex != -1) {
        int k;
        for (k = this.fDocumentImpl.getFirstChild(this.fDocumentTypeIndex); k != -1 && (this.fDocumentImpl.getNodeType(k) != 6 || !this.fDocumentImpl.getNodeName(k).equals(str)); k = this.fDocumentImpl.getNextSibling(k));
        if (k != -1 && this.fDocumentImpl.getFirstChild(k) == -1)
          this.fDocumentImpl.setAsFirstChild(k, j); 
      } 
    } 
  }
  
  public void characters(int paramInt, boolean paramBoolean) throws Exception {
    if (this.fNodeExpansion == 0) {
      Text text = null;
      if (paramBoolean) {
        text = this.fDocument.createCDATASection(this.fStringPool.orphanString(paramInt));
      } else {
        if (this.fWithinElement && this.fCurrentNode.getNodeType() == 3 && this.fCurrentNode.getParentNode().getNodeType() == 1) {
          ((Text)this.fCurrentNode).appendData(this.fStringPool.orphanString(paramInt));
          return;
        } 
        text = this.fDocument.createTextNode(this.fStringPool.orphanString(paramInt));
      } 
      if (text == null)
        return; 
      this.fCurrentNode.appendChild(text);
      return;
    } 
    if (this.fNodeExpansion == 1) {
      int i = paramBoolean ? this.fDocumentImpl.createCDATASection(paramInt) : this.fDocumentImpl.createTextNode(paramInt, false);
      this.fDocumentImpl.appendChild(this.fCurrentNodeIndex, i);
    } 
  }
  
  public void ignorableWhitespace(int paramInt, boolean paramBoolean) throws Exception {
    if (this.fNodeExpansion == 0) {
      Text text = null;
      if (paramBoolean) {
        text = this.fDocument.createCDATASection(this.fStringPool.orphanString(paramInt));
      } else {
        text = this.fDocument.createTextNode(this.fStringPool.orphanString(paramInt));
      } 
      if (text == null)
        return; 
      if (this.fDocumentImpl != null)
        ((TextImpl)text).setIgnorableWhitespace(true); 
      this.fCurrentNode.appendChild(text);
      return;
    } 
    if (this.fNodeExpansion == 1) {
      int i = paramBoolean ? this.fDocumentImpl.createCDATASection(paramInt) : this.fDocumentImpl.createTextNode(paramInt, true);
      this.fDocumentImpl.appendChild(this.fCurrentNodeIndex, i);
    } 
  }
  
  public void processingInstruction(int paramInt1, int paramInt2) throws Exception {
    if (this.fNodeExpansion == 0) {
      String str1 = this.fStringPool.orphanString(paramInt1);
      String str2 = this.fStringPool.orphanString(paramInt2);
      ProcessingInstruction processingInstruction = this.fDocument.createProcessingInstruction(str1, str2);
      this.fCurrentNode.appendChild(processingInstruction);
      return;
    } 
    if (this.fNodeExpansion == 1) {
      int i = this.fDocumentImpl.createProcessingInstruction(paramInt1, paramInt2);
      this.fDocumentImpl.appendChild(this.fCurrentNodeIndex, i);
    } 
  }
  
  public void comment(int paramInt) {
    if (this.fNodeExpansion == 0) {
      Comment comment = this.fDocument.createComment(this.fStringPool.orphanString(paramInt));
      this.fCurrentNode.appendChild(comment);
      return;
    } 
    if (this.fNodeExpansion == 1) {
      int i = this.fDocumentImpl.createComment(paramInt);
      this.fDocumentImpl.appendChild(this.fCurrentNodeIndex, i);
    } 
  }
  
  public void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {}
  
  public void ignorableWhitespace(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {}
  
  private void push(int paramInt) {
    if (this.stacktop == this.nodestack.length) {
      int[] arrayOfInt = new int[this.stacktop * 2];
      System.arraycopy(this.nodestack, 0, arrayOfInt, 0, this.stacktop);
      this.nodestack = arrayOfInt;
    } 
    this.nodestack[this.stacktop++] = paramInt;
  }
  
  private int pop() { return this.nodestack[--this.stacktop]; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parsers\NonValidatingDOMParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */