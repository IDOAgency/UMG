package com.ibm.xml.parsers;

import com.ibm.xml.framework.ContentSpecNode;
import com.ibm.xml.framework.ElementDeclPool;
import com.ibm.xml.framework.EntityPool;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLParser;
import com.ibm.xml.parser.AttDef;
import com.ibm.xml.parser.Attlist;
import com.ibm.xml.parser.CM1op;
import com.ibm.xml.parser.CM2op;
import com.ibm.xml.parser.CMLeaf;
import com.ibm.xml.parser.CMNode;
import com.ibm.xml.parser.ContentModel;
import com.ibm.xml.parser.DTD;
import com.ibm.xml.parser.ElementDecl;
import com.ibm.xml.parser.EntityDecl;
import com.ibm.xml.parser.EntityPool;
import com.ibm.xml.parser.ExternalID;
import com.ibm.xml.parser.TXDocument;
import com.ibm.xml.parser.TXNotation;
import com.ibm.xml.parser.TXText;
import java.util.Stack;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.EntityReference;
import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;
import org.xml.sax.AttributeList;

public class NonValidatingTXDOMParser extends XMLParser {
  public static final boolean DEBUG = false;
  
  protected String fDocumentClass = "com.ibm.xml.parser.TXDocument";
  
  protected int fRootElementName = -1;
  
  protected TXDocument fDocument;
  
  protected DTD fDocumentType;
  
  protected EntityPool fEntityPool;
  
  protected Node fCurrentParent;
  
  protected Node fCurrentNode;
  
  protected Stack fNodeStack = new Stack();
  
  protected boolean fWithinElement = false;
  
  protected boolean fNormalizeTextNodes = true;
  
  protected boolean fExpandEntityReferences = false;
  
  int fAmpIndex = -1;
  
  int fLtIndex = -1;
  
  int fGtIndex = -1;
  
  int fAposIndex = -1;
  
  int fQuotIndex = -1;
  
  public NonValidatingTXDOMParser() {
    setDocumentHandler(this);
    setDocumentTypeHandler(this);
    getParserState().useDefaultStringPool();
    getParserState().useDefaultAttrPool();
    getParserState().useDefaultEntityPool();
    getParserState().useDefaultElementDeclPool();
    init();
  }
  
  public void reset() {
    super.reset();
    init();
  }
  
  protected void resetOrCopy() {
    super.resetOrCopy();
    init();
  }
  
  protected void init() {
    this.fRootElementName = -1;
    this.fDocument = null;
    this.fDocumentType = null;
    this.fCurrentParent = null;
    this.fCurrentNode = null;
    this.fNodeStack.removeAllElements();
    this.fWithinElement = false;
    this.fNormalizeTextNodes = true;
    this.fExpandEntityReferences = false;
    StringPool stringPool = getParserState().getStringPool();
    this.fAmpIndex = stringPool.addSymbol("amp");
    this.fLtIndex = stringPool.addSymbol("lt");
    this.fGtIndex = stringPool.addSymbol("gt");
    this.fAposIndex = stringPool.addSymbol("apos");
    this.fQuotIndex = stringPool.addSymbol("quot");
  }
  
  protected void checkHandlers() {
    super.checkHandlers();
    if (this.fDocument == null)
      this.fDocument = (TXDocument)Class.forName(this.fDocumentClass).newInstance(); 
  }
  
  private void initDTDEntityPool() {
    this.fEntityPool = new EntityPool();
    this.fEntityPool.add(this.fDocument.createEntityDecl("lt", "&#60;", false));
    this.fEntityPool.add(this.fDocument.createEntityDecl("gt", "&#62;", false));
    this.fEntityPool.add(this.fDocument.createEntityDecl("amp", "&#38;", false));
    this.fEntityPool.add(this.fDocument.createEntityDecl("apos", "&#39;", false));
    this.fEntityPool.add(this.fDocument.createEntityDecl("quot", "&#34;", false));
  }
  
  public void setNormalizeTextNodes(boolean paramBoolean) { this.fNormalizeTextNodes = paramBoolean; }
  
  public void setExpandEntityReferences(boolean paramBoolean) { this.fExpandEntityReferences = paramBoolean; }
  
  public boolean getExpandEntityReferences() { return this.fExpandEntityReferences; }
  
  public void doctypeDecl(int paramInt) throws Exception {
    this.fRootElementName = paramInt;
    StringPool stringPool = getParserState().getStringPool();
    String str = stringPool.toString(this.fRootElementName);
    this.fDocumentType = this.fDocument.createDTD(str, null);
    if (this.fDocumentType == null)
      return; 
    initDTDEntityPool();
    this.fDocumentType.setEntityPool(this.fEntityPool);
    this.fCurrentParent.appendChild(this.fDocumentType);
    this.fCurrentNode = this.fDocumentType;
  }
  
  public void startInternalSubset() {
    if (this.fDocumentType == null)
      return; 
    this.fDocumentType.setParsingExternal(false);
  }
  
  public void endInternalSubset() {}
  
  public void startExternalSubset(int paramInt1, int paramInt2) throws Exception {
    if (this.fDocumentType == null)
      return; 
    StringPool stringPool = getParserState().getStringPool();
    stringPool.toString(this.fRootElementName);
    if (paramInt1 != -1 && paramInt2 != -1) {
      this.fDocumentType.setExternalID(new ExternalID(stringPool.toString(paramInt1), stringPool.toString(paramInt2)));
    } else if (paramInt2 != -1) {
      this.fDocumentType.setExternalID(new ExternalID(stringPool.toString(paramInt2)));
    } 
    this.fDocumentType.setParsingExternal(true);
  }
  
  public void endExternalSubset() {
    if (this.fDocumentType == null)
      return; 
    this.fDocumentType.setParsingExternal(false);
  }
  
  public void elementDecl(int paramInt) throws Exception {
    int j;
    if (this.fDocumentType == null)
      return; 
    ElementDeclPool elementDeclPool = getParserState().getElementDeclPool();
    String str = getParserState().getStringPool().toString(elementDeclPool.getElementName(paramInt));
    int i = elementDeclPool.getContentSpecType(paramInt);
    ContentModel contentModel = null;
    ElementDecl elementDecl = null;
    switch (i) {
      case 1:
        contentModel = this.fDocument.createContentModel(1);
        break;
      case 2:
        contentModel = this.fDocument.createContentModel(2);
        break;
      case 3:
      case 4:
        j = elementDeclPool.getContentSpec(paramInt);
        contentModel = this.fDocument.createContentModel(buildCMNode(paramInt, j));
        break;
    } 
    if (contentModel != null) {
      elementDecl = this.fDocument.createElementDecl(str, contentModel);
      if (elementDecl == null)
        return; 
      this.fDocumentType.appendChild(elementDecl);
      this.fCurrentNode = elementDecl;
    } 
  }
  
  protected CMNode buildCMNode(int paramInt1, int paramInt2) {
    String str;
    StringPool stringPool = getParserState().getStringPool();
    ElementDeclPool elementDeclPool = getParserState().getElementDeclPool();
    ContentSpecNode contentSpecNode1 = new ContentSpecNode();
    ContentSpecNode contentSpecNode2 = new ContentSpecNode();
    elementDeclPool.getContentSpecNode(paramInt2, contentSpecNode1);
    int i = contentSpecNode1.type;
    int j = contentSpecNode1.value;
    switch (i) {
      case 0:
        str = (j == -1) ? "#PCDATA" : stringPool.toString(j);
        return new CMLeaf(str);
      case 1:
        elementDeclPool.getContentSpecNode(paramInt2, contentSpecNode2);
        return new CM1op(63, buildCMNode(paramInt1, contentSpecNode2.value));
      case 2:
        elementDeclPool.getContentSpecNode(paramInt2, contentSpecNode2);
        return new CM1op(42, buildCMNode(paramInt1, contentSpecNode2.value));
      case 3:
        elementDeclPool.getContentSpecNode(paramInt2, contentSpecNode2);
        return new CM1op(43, buildCMNode(paramInt1, contentSpecNode2.value));
      case 4:
        elementDeclPool.getContentSpecNode(paramInt2, contentSpecNode2);
        return new CM2op(124, buildCMNode(paramInt1, contentSpecNode2.value), buildCMNode(paramInt1, contentSpecNode2.otherValue));
      case 5:
        elementDeclPool.getContentSpecNode(paramInt2, contentSpecNode2);
        return new CM2op(44, buildCMNode(paramInt1, contentSpecNode2.value), buildCMNode(paramInt1, contentSpecNode2.otherValue));
    } 
    return null;
  }
  
  public void attlistDecl(int paramInt1, int paramInt2) throws Exception {
    if (this.fDocumentType == null)
      return; 
    StringPool stringPool = getParserState().getStringPool();
    ElementDeclPool elementDeclPool = getParserState().getElementDeclPool();
    int i = elementDeclPool.getElementName(paramInt1);
    stringPool.toString(i);
    Attlist attlist = this.fDocument.createAttlist(stringPool.toString(i));
    AttDef attDef = this.fDocument.createAttDef(stringPool.toString(elementDeclPool.getAttName(paramInt2)));
    if (attlist == null || attDef == null)
      return; 
    if (elementDeclPool.getAttType(paramInt2) < 9) {
      attDef.setDeclaredType(elementDeclPool.getAttType(paramInt2) + 1);
    } else if (elementDeclPool.getAttType(paramInt2) == 9) {
      attDef.setDeclaredType(10);
    } else {
      System.err.println("ERROR: UNKNOWN AttType:" + elementDeclPool.getAttType(paramInt2));
      return;
    } 
    if (((elementDeclPool.getAttType(paramInt2) != 9) ? 0 : 1) | ((elementDeclPool.getAttType(paramInt2) != 8) ? 0 : 1)) {
      int[] arrayOfInt = stringPool.stringsInList(elementDeclPool.getEnumeration(paramInt2));
      for (byte b = 0; b < arrayOfInt.length; b++)
        attDef.addElement(stringPool.toString(arrayOfInt[b])); 
    } 
    switch (elementDeclPool.getAttDefaultType(paramInt2)) {
      case 1:
        attDef.setDefaultType(-1);
        break;
      case 2:
        attDef.setDefaultType(2);
        break;
      case 3:
        attDef.setDefaultType(3);
        break;
      case 4:
        attDef.setDefaultType(1);
        break;
      default:
        attDef.setDefaultType(0);
        break;
    } 
    int j = elementDeclPool.getAttValue(paramInt2);
    if (j != -1)
      attDef.setDefaultStringValue(stringPool.toString(j)); 
    attlist.addElement(attDef);
    this.fDocumentType.appendChild(attlist);
    this.fCurrentNode = attlist;
  }
  
  public void internalEntityDecl(int paramInt) throws Exception {
    if (this.fDocumentType == null)
      return; 
    StringPool stringPool = getParserState().getStringPool();
    EntityPool entityPool = getParserState().getEntityPool();
    String str1 = stringPool.toString(entityPool.getEntityName(paramInt));
    String str2 = stringPool.toString(entityPool.getEntityValue(paramInt));
    EntityDecl entityDecl = this.fDocument.createEntityDecl(str1, str2, false);
    if (entityDecl == null)
      return; 
    Text text = this.fDocument.createTextNode(str2);
    if (text != null)
      entityDecl.appendChild(text); 
    this.fDocumentType.appendChild(entityDecl);
    this.fEntityPool.add(entityDecl);
    this.fCurrentNode = entityDecl;
  }
  
  public void externalEntityDecl(int paramInt) throws Exception {
    if (this.fDocumentType == null)
      return; 
    StringPool stringPool = getParserState().getStringPool();
    EntityPool entityPool = getParserState().getEntityPool();
    String str1 = stringPool.toString(entityPool.getEntityName(paramInt));
    String str2 = stringPool.toString(entityPool.getPublicId(paramInt));
    String str3 = stringPool.toString(entityPool.getSystemId(paramInt));
    EntityDecl entityDecl = this.fDocument.createEntityDecl(str1, new ExternalID(str2, str3), false, null);
    if (entityDecl == null)
      return; 
    this.fDocumentType.appendChild(entityDecl);
    this.fEntityPool.add(entityDecl);
    this.fCurrentNode = entityDecl;
  }
  
  public void unparsedEntityDecl(int paramInt) throws Exception {
    if (this.fDocumentType == null)
      return; 
    StringPool stringPool = getParserState().getStringPool();
    EntityPool entityPool = getParserState().getEntityPool();
    String str1 = stringPool.toString(entityPool.getEntityName(paramInt));
    String str2 = stringPool.toString(entityPool.getPublicId(paramInt));
    String str3 = stringPool.toString(entityPool.getSystemId(paramInt));
    String str4 = stringPool.toString(entityPool.getNotationName(paramInt));
    EntityDecl entityDecl = this.fDocument.createEntityDecl(str1, new ExternalID(str2, str3), false, str4);
    if (entityDecl == null)
      return; 
    this.fDocumentType.appendChild(entityDecl);
    this.fEntityPool.add(entityDecl);
    this.fCurrentNode = entityDecl;
  }
  
  public void notationDecl(int paramInt) throws Exception {
    if (this.fDocumentType == null)
      return; 
    StringPool stringPool = getParserState().getStringPool();
    EntityPool entityPool = getParserState().getEntityPool();
    String str1 = stringPool.toString(entityPool.getNotationName(paramInt));
    String str2 = stringPool.toString(entityPool.getPublicId(paramInt));
    String str3 = stringPool.toString(entityPool.getSystemId(paramInt));
    TXNotation tXNotation = this.fDocument.createNotation(str1, new ExternalID(str2, str3));
    if (tXNotation == null)
      return; 
    this.fDocumentType.appendChild(tXNotation);
    this.fCurrentNode = tXNotation;
  }
  
  public void setDocumentClass(String paramString) { this.fDocumentClass = paramString; }
  
  public Document getDocument() { return this.fDocument; }
  
  public void startDocument(int paramInt1, int paramInt2, int paramInt3) throws Exception {
    if (this.fDocument == null)
      return; 
    this.fCurrentParent = this.fDocument;
    this.fCurrentNode = this.fDocument;
    StringPool stringPool = getParserState().getStringPool();
    String str1 = stringPool.orphanString(paramInt1);
    String str2 = stringPool.orphanString(paramInt2);
    String str3 = stringPool.orphanString(paramInt3);
    if (str1 != null)
      this.fDocument.setVersion(str1); 
    if (str2 != null)
      this.fDocument.setEncoding(str2); 
    if (str3 != null)
      this.fDocument.setStandalone(str3); 
  }
  
  public void endDocument() {}
  
  public void startElement(int paramInt1, int paramInt2) throws Exception {
    String str = getParserState().getStringPool().toString(paramInt1);
    AttributeList attributeList = getParserState().getAttrPool().getAttributeList(paramInt2);
    Element element = this.fDocument.createElement(str);
    if (element == null)
      return; 
    int i = attributeList.getLength();
    for (byte b = 0; b < i; b++) {
      element.setAttribute(attributeList.getName(b), attributeList.getValue(b));
      if (this.fDocumentType != null && attributeList.getType(b).equals("ID"))
        this.fDocumentType.registID(element, attributeList.getValue(b)); 
    } 
    getParserState().getAttrPool().releaseAttrList(paramInt2);
    this.fCurrentParent.appendChild(element);
    this.fNodeStack.push(this.fCurrentParent);
    this.fCurrentParent = element;
    this.fCurrentNode = element;
    this.fWithinElement = true;
  }
  
  public void endElement(int paramInt) throws Exception {
    this.fCurrentParent = (Node)this.fNodeStack.pop();
    this.fCurrentNode = this.fCurrentParent;
    this.fWithinElement = false;
  }
  
  public void startEntityReference(int paramInt) throws Exception {
    if (this.fExpandEntityReferences)
      return; 
    EntityPool entityPool = getParserState().getEntityPool();
    int i = entityPool.getEntityName(paramInt);
    if (i == this.fAmpIndex || i == this.fGtIndex || i == this.fLtIndex || i == this.fAposIndex || i == this.fQuotIndex)
      return; 
    StringPool stringPool = getParserState().getStringPool();
    String str = stringPool.toString(entityPool.getEntityName(paramInt));
    EntityReference entityReference = this.fDocument.createEntityReference(str);
    if (entityReference == null)
      return; 
    this.fCurrentParent.appendChild(entityReference);
    this.fNodeStack.push(this.fCurrentParent);
    this.fCurrentParent = entityReference;
    this.fCurrentNode = entityReference;
  }
  
  public void endEntityReference(int paramInt) throws Exception {
    if (this.fExpandEntityReferences)
      return; 
    int i = getParserState().getEntityPool().getEntityName(paramInt);
    if (i == this.fAmpIndex || i == this.fGtIndex || i == this.fLtIndex || i == this.fAposIndex || i == this.fQuotIndex)
      return; 
    this.fCurrentParent = (Node)this.fNodeStack.pop();
    this.fCurrentNode = this.fCurrentParent;
  }
  
  public void characters(int paramInt, boolean paramBoolean) throws Exception {
    Text text = null;
    if (paramBoolean) {
      text = this.fDocument.createCDATASection(getParserState().getStringPool().orphanString(paramInt));
    } else {
      if (this.fNormalizeTextNodes && this.fWithinElement && this.fCurrentNode.getNodeType() == 3 && this.fCurrentNode.getParentNode().getNodeType() == 1) {
        ((Text)this.fCurrentNode).appendData(getParserState().getStringPool().orphanString(paramInt));
        return;
      } 
      text = this.fDocument.createTextNode(getParserState().getStringPool().orphanString(paramInt));
    } 
    if (text == null)
      return; 
    this.fCurrentParent.appendChild(text);
    this.fCurrentNode = text;
  }
  
  public void ignorableWhitespace(int paramInt, boolean paramBoolean) throws Exception {
    Text text = null;
    if (paramBoolean) {
      text = this.fDocument.createCDATASection(getParserState().getStringPool().orphanString(paramInt));
    } else {
      text = this.fDocument.createTextNode(getParserState().getStringPool().orphanString(paramInt));
    } 
    if (text == null)
      return; 
    ((TXText)text).setIsIgnorableWhitespace(true);
    this.fCurrentParent.appendChild(text);
    this.fCurrentNode = text;
  }
  
  public void processingInstruction(int paramInt1, int paramInt2) throws Exception {
    String str1 = getParserState().getStringPool().orphanString(paramInt1);
    String str2 = null;
    if (paramInt2 >= 0) {
      str2 = getParserState().getStringPool().orphanString(paramInt2);
    } else {
      str2 = "";
    } 
    ProcessingInstruction processingInstruction = this.fDocument.createProcessingInstruction(str1, str2);
    if (processingInstruction == null)
      return; 
    this.fCurrentParent.appendChild(processingInstruction);
    this.fCurrentNode = processingInstruction;
  }
  
  public void comment(int paramInt) throws Exception {
    Comment comment = this.fDocument.createComment(getParserState().getStringPool().orphanString(paramInt));
    if (comment == null)
      return; 
    this.fCurrentParent.appendChild(comment);
    this.fCurrentNode = comment;
  }
  
  public void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {
    Text text = null;
    if (paramBoolean) {
      text = this.fDocument.createCDATASection(new String(paramArrayOfChar, paramInt1, paramInt2));
    } else {
      if (this.fNormalizeTextNodes && this.fWithinElement && this.fCurrentNode.getNodeType() == 3 && this.fCurrentNode.getParentNode().getNodeType() == 1) {
        ((Text)this.fCurrentNode).appendData(new String(paramArrayOfChar, paramInt1, paramInt2));
        return;
      } 
      text = this.fDocument.createTextNode(new String(paramArrayOfChar, paramInt1, paramInt2));
    } 
    if (text == null)
      return; 
    this.fCurrentParent.appendChild(text);
    this.fCurrentNode = text;
  }
  
  public void ignorableWhitespace(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {
    Text text = null;
    if (paramBoolean) {
      text = this.fDocument.createCDATASection(new String(paramArrayOfChar, paramInt1, paramInt2));
    } else {
      text = this.fDocument.createTextNode(new String(paramArrayOfChar, paramInt1, paramInt2));
    } 
    if (text == null)
      return; 
    ((TXText)text).setIsIgnorableWhitespace(true);
    this.fCurrentParent.appendChild(text);
    this.fCurrentNode = text;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parsers\NonValidatingTXDOMParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */