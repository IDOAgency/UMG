package com.ibm.xml.parsers;

import com.ibm.xml.dom.TextImpl;
import com.ibm.xml.framework.ElementDeclPool;
import com.ibm.xml.framework.ParserState;
import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLValidationHandler;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class RevalidatingDOMParser extends DOMParser {
  private static final boolean DEBUG_VALIDATE = false;
  
  public final Node validate(Node paramNode) {
    if (paramNode.getNodeType() != 1)
      throw new IllegalArgumentException("Can't revalidate a non element"); 
    XMLValidationHandler xMLValidationHandler = getValidationHandler();
    ParserState parserState = getParserState();
    StringPool stringPool = parserState.getStringPool();
    ElementDeclPool elementDeclPool = parserState.getElementDeclPool();
    return recursiveValidate(paramNode, xMLValidationHandler, stringPool, elementDeclPool);
  }
  
  private final Node recursiveValidate(Node paramNode, XMLValidationHandler paramXMLValidationHandler, StringPool paramStringPool, ElementDeclPool paramElementDeclPool) {
    int[] arrayOfInt = new int[countChildren(paramNode)];
    Node[] arrayOfNode = new Node[arrayOfInt.length];
    int i = expandChildren(paramNode, arrayOfInt, arrayOfNode, 0, paramStringPool);
    int j = -1;
    int k = paramStringPool.addSymbol(paramNode.getNodeName());
    int m = paramElementDeclPool.getElement(k);
    try {
      j = paramXMLValidationHandler.checkContent(m, i, arrayOfInt);
    } catch (Exception exception) {}
    Node node = null;
    if (j != -1) {
      node = arrayOfNode[j];
      String str = paramElementDeclPool.getContentSpecAsString(m);
      int n = paramStringPool.addString(str);
      byte b = (j != i) ? 27 : 164;
      try {
        getParserState().getErrorHandler().error2(b, k, n);
      } catch (Exception exception) {}
    } else {
      for (byte b = 0; b < i; b++) {
        if (arrayOfInt[b] != -1) {
          Node node1 = arrayOfNode[b];
          if (node1 != null) {
            node1 = recursiveValidate(node1, paramXMLValidationHandler, paramStringPool, paramElementDeclPool);
            if (node1 != null) {
              node = node1;
              break;
            } 
          } 
        } 
      } 
    } 
    arrayOfInt = null;
    arrayOfNode = null;
    return node;
  }
  
  private final int expandChildren(Node paramNode, int[] paramArrayOfInt, Node[] paramArrayOfNode, int paramInt, StringPool paramStringPool) {
    if (paramNode.hasChildNodes()) {
      NodeList nodeList = paramNode.getChildNodes();
      int i = nodeList.getLength();
      for (byte b = 0; b < i; b++) {
        Node node = nodeList.item(b);
        short s = node.getNodeType();
        if (s == 1) {
          paramArrayOfInt[paramInt] = paramStringPool.addSymbol(node.getNodeName());
          paramArrayOfNode[paramInt] = node;
          paramInt++;
        } else if (s == 3) {
          if (!(node instanceof TextImpl) || !((TextImpl)node).isIgnorableWhitespace()) {
            paramArrayOfInt[paramInt] = -1;
            paramArrayOfNode[paramInt] = node;
            paramInt++;
          } 
        } else if (s == 5) {
          paramInt = expandChildren(node, paramArrayOfInt, paramArrayOfNode, paramInt, paramStringPool);
        } 
      } 
    } 
    return paramInt;
  }
  
  private final int countChildren(Node paramNode) {
    int i = 0;
    if (paramNode.hasChildNodes()) {
      NodeList nodeList = paramNode.getChildNodes();
      i += nodeList.getLength();
      for (int j = i - 1; j >= 0; j--) {
        Node node = nodeList.item(j);
        if (node.getNodeType() == 5)
          i += countChildren(node) - 1; 
      } 
    } 
    return i;
  }
  
  private static void print(Node paramNode, String paramString) {}
  
  private static String normalize(String paramString) { return null; }
  
  private static String type(int paramInt) { return null; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parsers\RevalidatingDOMParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */