package com.ibm.xml.parsers;

import com.ibm.xml.framework.StringPool;
import com.ibm.xml.framework.XMLParser;

public class NonValidatingParser extends XMLParser {
  public NonValidatingParser() {
    getParserState().useDefaultStringPool();
    getParserState().useDefaultAttrPool();
    getParserState().useDefaultEntityPool();
    getParserState().useDefaultElementDeclPool();
  }
  
  public void doctypeDecl(int paramInt) throws Exception {}
  
  public void startInternalSubset() {}
  
  public void endInternalSubset() {}
  
  public void startExternalSubset(int paramInt1, int paramInt2) throws Exception {}
  
  public void endExternalSubset() {}
  
  public void elementDecl(int paramInt) throws Exception {}
  
  public void attlistDecl(int paramInt1, int paramInt2) throws Exception {}
  
  public void internalEntityDecl(int paramInt) throws Exception {}
  
  public void externalEntityDecl(int paramInt) throws Exception {}
  
  public void unparsedEntityDecl(int paramInt) throws Exception {}
  
  public void notationDecl(int paramInt) throws Exception {}
  
  public void startDocument(int paramInt1, int paramInt2, int paramInt3) throws Exception {
    StringPool stringPool = getParserState().getStringPool();
    stringPool.orphanString(paramInt1);
    stringPool.orphanString(paramInt2);
    stringPool.orphanString(paramInt3);
  }
  
  public void endDocument() {}
  
  public void startElement(int paramInt1, int paramInt2) throws Exception { getParserState().getAttrPool().releaseAttrList(paramInt2); }
  
  public void endElement(int paramInt) throws Exception {}
  
  public void startEntityReference(int paramInt) throws Exception {}
  
  public void endEntityReference(int paramInt) throws Exception {}
  
  public void characters(int paramInt, boolean paramBoolean) throws Exception { getParserState().getStringPool().releaseString(paramInt); }
  
  public void ignorableWhitespace(int paramInt, boolean paramBoolean) throws Exception { getParserState().getStringPool().releaseString(paramInt); }
  
  public void processingInstruction(int paramInt1, int paramInt2) throws Exception {
    getParserState().getStringPool().releaseString(paramInt1);
    getParserState().getStringPool().releaseString(paramInt2);
  }
  
  public void comment(int paramInt) throws Exception { getParserState().getStringPool().releaseString(paramInt); }
  
  public void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {}
  
  public void ignorableWhitespace(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) throws Exception {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parsers\NonValidatingParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */