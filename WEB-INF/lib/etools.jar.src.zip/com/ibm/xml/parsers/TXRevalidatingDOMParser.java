package com.ibm.xml.parsers;

import com.ibm.xml.parser.DTD;
import com.ibm.xml.parser.TXDocument;
import com.ibm.xml.parser.TXElement;
import org.w3c.dom.Node;

public class TXRevalidatingDOMParser extends TXDOMParser {
  private Node errorElement;
  
  private static final boolean DEBUG_VALIDATE = false;
  
  public Node getErrorElement() { return this.errorElement; }
  
  public Node validate(Node paramNode) {
    if (paramNode.getNodeType() != 1 || !(paramNode instanceof TXElement))
      throw new IllegalArgumentException("Can't revalidate a non element"); 
    DTD dTD = ((TXDocument)paramNode.getOwnerDocument()).getDTD();
    return recursiveValidate((TXElement)paramNode, dTD);
  }
  
  private Node recursiveValidate(TXElement paramTXElement, DTD paramDTD) {
    Node node = paramDTD.validate(paramTXElement);
    if (node != null)
      this.errorElement = (node.getNodeType() == 2) ? paramTXElement : null; 
    if (node == null && paramTXElement.hasChildNodes())
      for (Node node1 = paramTXElement.getFirstChild(); node1 != null; node1 = node1.getNextSibling()) {
        if (node1.getNodeType() == 1) {
          node = recursiveValidate((TXElement)node1, paramDTD);
          if (node != null) {
            this.errorElement = (node.getNodeType() == 2) ? node1 : null;
            break;
          } 
        } 
      }  
    return node;
  }
  
  private static void print(Node paramNode, String paramString) {}
  
  private static String normalize(String paramString) { return null; }
  
  private static String type(int paramInt) { return null; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\parsers\TXRevalidatingDOMParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */