package com.ibm.xml.framework;

public interface XMLDocumentTypeHandler {
  void doctypeDecl(int paramInt) throws Exception;
  
  void startInternalSubset() throws Exception;
  
  void endInternalSubset() throws Exception;
  
  void startExternalSubset(int paramInt1, int paramInt2) throws Exception;
  
  void endExternalSubset() throws Exception;
  
  void elementDecl(int paramInt) throws Exception;
  
  void attlistDecl(int paramInt1, int paramInt2) throws Exception;
  
  void internalEntityDecl(int paramInt) throws Exception;
  
  void externalEntityDecl(int paramInt) throws Exception;
  
  void unparsedEntityDecl(int paramInt) throws Exception;
  
  void notationDecl(int paramInt) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\XMLDocumentTypeHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */