package com.ibm.xml.framework;

public final class ElementDecl {
  public static final int CONTENTSPEC_UNKNOWN = 0;
  
  public static final int CONTENTSPEC_EMPTY = 1;
  
  public static final int CONTENTSPEC_ANY = 2;
  
  public static final int CONTENTSPEC_MIXED = 3;
  
  public static final int CONTENTSPEC_CHILDREN = 4;
  
  public int elementName;
  
  public int contentSpecType;
  
  public int contentSpec;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\ElementDecl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */