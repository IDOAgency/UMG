package com.ibm.xml.framework;

public interface StringPool {
  void reset(ParserState paramParserState);
  
  StringPool resetOrCopy(ParserState paramParserState);
  
  int addString(String paramString);
  
  int addString(StringProducer paramStringProducer, int paramInt1, int paramInt2);
  
  int addSymbol(String paramString);
  
  int addSymbol(StringProducer paramStringProducer, int paramInt1, int paramInt2, int paramInt3);
  
  int startStringList();
  
  boolean addStringToList(int paramInt1, int paramInt2);
  
  void finishStringList(int paramInt);
  
  int stringListLength(int paramInt);
  
  boolean stringInList(int paramInt1, int paramInt2);
  
  int[] stringsInList(int paramInt);
  
  void releaseString(int paramInt);
  
  String toString(int paramInt);
  
  String orphanString(int paramInt);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\StringPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */