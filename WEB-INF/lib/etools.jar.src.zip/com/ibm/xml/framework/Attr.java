package com.ibm.xml.framework;

public final class Attr {
  public int attName;
  
  public int attType;
  
  public int attValue;
  
  public boolean specified;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\Attr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */