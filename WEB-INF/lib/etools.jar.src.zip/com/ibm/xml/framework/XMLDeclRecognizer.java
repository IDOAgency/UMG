package com.ibm.xml.framework;

import org.xml.sax.InputSource;

public abstract class XMLDeclRecognizer {
  private static final char[] xml_string = { 'x', 'm', 'l' };
  
  private static final char[] version_string = { 'v', 'e', 'r', 's', 'i', 'o', 'n' };
  
  private static final char[] encoding_string = { 'e', 'n', 'c', 'o', 'd', 'i', 'n', 'g' };
  
  public abstract XMLReader recognize(ParserState paramParserState, InputSource paramInputSource, ChunkyByteArray paramChunkyByteArray, boolean paramBoolean) throws Exception;
  
  protected final int prescanXMLDeclOrTextDecl(XMLReader paramXMLReader, boolean paramBoolean) throws Exception {
    if (!paramXMLReader.skippedChar('<'))
      return -1; 
    if (!paramXMLReader.skippedChar('?'))
      return -1; 
    if (!paramXMLReader.skippedString(xml_string))
      return -1; 
    paramXMLReader.skipPastSpaces();
    if (paramXMLReader.skippedString(version_string)) {
      paramXMLReader.skipPastSpaces();
      if (!paramXMLReader.skippedChar('='))
        return -1; 
      paramXMLReader.skipPastSpaces();
      boolean bool1;
      if (!(bool1 = paramXMLReader.skippedChar('\'')) && !paramXMLReader.skippedChar('"'))
        return -1; 
      char c1 = bool1 ? '\'' : '"';
      while (!paramXMLReader.skippedChar(c1)) {
        if (!paramXMLReader.skippedVersionNum())
          return -1; 
      } 
      if (!paramXMLReader.skippedSpace())
        return -1; 
      paramXMLReader.skipPastSpaces();
    } else if (paramBoolean) {
      return -1;
    } 
    if (!paramXMLReader.skippedString(encoding_string))
      return -1; 
    paramXMLReader.skipPastSpaces();
    if (!paramXMLReader.skippedChar('='))
      return -1; 
    paramXMLReader.skipPastSpaces();
    boolean bool;
    if (!(bool = paramXMLReader.skippedChar('\'')) && !paramXMLReader.skippedChar('"'))
      return -1; 
    int i = paramXMLReader.fCurrentOffset;
    char c = bool ? '\'' : '"';
    if (!paramXMLReader.skippedAlpha())
      return -1; 
    while (!paramXMLReader.lookingAtChar(c)) {
      if (!paramXMLReader.skippedEncName())
        return -1; 
    } 
    return paramXMLReader.addString(i, paramXMLReader.fCurrentOffset - i);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\XMLDeclRecognizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */