package com.ibm.xml.framework;

import com.ibm.xml.internal.DefaultEntityHandler;
import com.ibm.xml.internal.DefaultScanner;
import com.ibm.xml.internal.DefaultValidationHandler;
import com.ibm.xml.internal.ErrorCode;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;
import org.xml.sax.DTDHandler;
import org.xml.sax.DocumentHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.Parser;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public abstract class XMLParser implements Parser, XMLDocumentTypeHandler, XMLDocumentHandler, XMLErrorHandler {
  private ParserState fParserState = new ParserState(this);
  
  protected XMLScanner fScanner = new DefaultScanner(this.fParserState);
  
  private XMLEntityHandler fEntityHandler = new DefaultEntityHandler(this.fParserState);
  
  private ErrorHandler fSAXErrorHandler;
  
  private Locale fLocale;
  
  private ResourceBundle fResourceBundle;
  
  private boolean fAllowJavaEncodingName = false;
  
  private boolean fWarningOnDuplicateAttDef = false;
  
  private boolean fCheckNamespace = false;
  
  private boolean fContinueAfterFatalError = false;
  
  protected boolean fParseInProgress = false;
  
  protected boolean fNeedReset = false;
  
  private XMLDocumentHandler fDocHandler;
  
  private XMLDocumentTypeHandler fDocTypeHandler;
  
  private XMLValidationHandler fValidationHandler;
  
  public void reset() {
    this.fParserState.reset();
    this.fScanner.reset(this.fParserState);
    this.fEntityHandler.reset(this.fParserState);
    this.fNeedReset = false;
  }
  
  protected void resetOrCopy() {
    ParserState parserState = this.fParserState;
    this.fParserState = new ParserState(parserState);
    this.fScanner.reset(this.fParserState);
    this.fEntityHandler.reset(this.fParserState);
    this.fNeedReset = false;
  }
  
  protected void checkHandlers() {}
  
  public ParserState getParserState() { return this.fParserState; }
  
  public XMLScanner getScanner() { return this.fScanner; }
  
  protected Locator getLocator() { return this.fScanner.getLocator(); }
  
  public void setAllowJavaEncodingName(boolean paramBoolean) { this.fAllowJavaEncodingName = paramBoolean; }
  
  public boolean getAllowJavaEncodingName() { return this.fAllowJavaEncodingName; }
  
  public void setWarningOnDuplicateAttDef(boolean paramBoolean) { this.fWarningOnDuplicateAttDef = paramBoolean; }
  
  public boolean getWarningOnDuplicateAttDef() { return this.fWarningOnDuplicateAttDef; }
  
  public void setCheckNamespace(boolean paramBoolean) { this.fCheckNamespace = paramBoolean; }
  
  public boolean getCheckNamespace() { return this.fCheckNamespace; }
  
  public void setContinueAfterFatalError(boolean paramBoolean) { this.fContinueAfterFatalError = paramBoolean; }
  
  public boolean getContinueAfterFatalError() { return this.fContinueAfterFatalError; }
  
  protected void setDocumentHandler(XMLDocumentHandler paramXMLDocumentHandler) { this.fDocHandler = paramXMLDocumentHandler; }
  
  public XMLDocumentHandler getDocumentHandler() { return this.fDocHandler; }
  
  protected void setDocumentTypeHandler(XMLDocumentTypeHandler paramXMLDocumentTypeHandler) { this.fDocTypeHandler = paramXMLDocumentTypeHandler; }
  
  public XMLDocumentTypeHandler getDocumentTypeHandler() { return this.fDocTypeHandler; }
  
  protected void setEntityHandler(XMLEntityHandler paramXMLEntityHandler) { this.fEntityHandler = paramXMLEntityHandler; }
  
  public XMLEntityHandler getEntityHandler() { return this.fEntityHandler; }
  
  public XMLErrorHandler getErrorHandler() { return this; }
  
  protected void setValidationHandler(XMLValidationHandler paramXMLValidationHandler) { this.fValidationHandler = paramXMLValidationHandler; }
  
  public XMLValidationHandler getValidationHandler() { return this.fValidationHandler; }
  
  protected void useDefaultValidationHandler() { this.fValidationHandler = new DefaultValidationHandler(this.fParserState); }
  
  public void loadCatalog(InputSource paramInputSource) throws Exception {
    XMLEntityHandler xMLEntityHandler = getEntityHandler();
    if (xMLEntityHandler != null) {
      EntityResolver entityResolver = xMLEntityHandler.getEntityResolver();
      if (entityResolver != null) {
        if (entityResolver instanceof Catalog) {
          ((Catalog)entityResolver).loadCatalog(paramInputSource);
          return;
        } 
        throw new Exception("EntityResolver is not a Catalog");
      } 
      throw new Exception("Catalog not installed");
    } 
    throw new Exception("XMLEntityHandler not installed");
  }
  
  public final void setLocale(Locale paramLocale) throws SAXException {
    if (this.fParseInProgress)
      throw new SAXException("setLocale may not be called while parsing"); 
    if (this.fLocale != paramLocale) {
      this.fLocale = paramLocale;
      this.fResourceBundle = null;
    } 
  }
  
  public void setEntityResolver(EntityResolver paramEntityResolver) {
    if (this.fEntityHandler != null)
      this.fEntityHandler.setEntityResolver(paramEntityResolver); 
  }
  
  public void setDTDHandler(DTDHandler paramDTDHandler) {}
  
  public void setDocumentHandler(DocumentHandler paramDocumentHandler) {}
  
  public void setErrorHandler(ErrorHandler paramErrorHandler) { this.fSAXErrorHandler = paramErrorHandler; }
  
  public final void parse(InputSource paramInputSource) throws Exception {
    if (this.fParseInProgress)
      throw new SAXException("parse may not be called while parsing"); 
    if (this.fNeedReset)
      resetOrCopy(); 
    try {
      checkHandlers();
      this.fParseInProgress = true;
      this.fNeedReset = true;
      this.fScanner.scanDocument(paramInputSource);
      this.fParseInProgress = false;
      return;
    } catch (SAXException sAXException) {
      this.fParseInProgress = false;
      throw sAXException;
    } catch (IOException iOException) {
      this.fParseInProgress = false;
      throw iOException;
    } catch (Exception exception) {
      this.fParseInProgress = false;
      throw new SAXException(exception);
    } 
  }
  
  public final void parse(String paramString) throws SAXException, IOException {
    InputSource inputSource = new InputSource(paramString);
    parse(inputSource);
    try {
      Reader reader = inputSource.getCharacterStream();
      if (reader != null) {
        reader.close();
        return;
      } 
      InputStream inputStream = inputSource.getByteStream();
      if (inputStream != null) {
        inputStream.close();
        return;
      } 
    } catch (IOException iOException) {}
  }
  
  public boolean sendCharDataAsCharArray() { return false; }
  
  protected boolean errorHandlingEnabled() { return !(this.fSAXErrorHandler == null); }
  
  protected void handleError(String paramString1, String paramString2) throws Exception {
    SAXParseException sAXParseException = new SAXParseException(paramString2, getLocator());
    if (this.fSAXErrorHandler == null) {
      if (isFatal(paramString1))
        throw sAXParseException; 
      return;
    } 
    if (isWarning(paramString1)) {
      this.fSAXErrorHandler.warning(sAXParseException);
      return;
    } 
    if (isFatal(paramString1)) {
      this.fSAXErrorHandler.fatalError(sAXParseException);
      return;
    } 
    this.fSAXErrorHandler.error(sAXParseException);
  }
  
  protected final String getErrorMsgString(String paramString, Object[] paramArrayOfObject) {
    if (this.fResourceBundle == null)
      if (this.fLocale == null) {
        this.fResourceBundle = ResourceBundle.getBundle("com.ibm.xml.internal.msg.Message");
      } else {
        this.fResourceBundle = ResourceBundle.getBundle("com.ibm.xml.internal.msg.Message", this.fLocale);
      }  
    String str = this.fResourceBundle.getString(paramString);
    if (paramArrayOfObject != null)
      str = MessageFormat.format(str, paramArrayOfObject); 
    return str;
  }
  
  protected final boolean isWarning(String paramString) { return paramString.startsWith("W_"); }
  
  protected final boolean isFatal(String paramString) { return paramString.startsWith("E_"); }
  
  public final void error(int paramInt) throws Exception {
    if (!errorHandlingEnabled())
      return; 
    String str1 = ErrorCode.getErrorKey(paramInt);
    String str2 = getErrorMsgString(str1, null);
    handleError(str1, str2);
  }
  
  public final void error1(int paramInt1, int paramInt2) throws Exception {
    String str1 = ErrorCode.getErrorKey(paramInt1);
    if (!errorHandlingEnabled() && !isFatal(str1)) {
      this.fParserState.getStringPool().releaseString(paramInt2);
      return;
    } 
    String[] arrayOfString = new String[1];
    arrayOfString[0] = this.fParserState.getStringPool().orphanString(paramInt2);
    String str2 = getErrorMsgString(str1, arrayOfString);
    handleError(str1, str2);
  }
  
  public final void error2(int paramInt1, int paramInt2, int paramInt3) throws Exception {
    String str1 = ErrorCode.getErrorKey(paramInt1);
    if (!errorHandlingEnabled() && !isFatal(str1)) {
      this.fParserState.getStringPool().releaseString(paramInt2);
      this.fParserState.getStringPool().releaseString(paramInt3);
      return;
    } 
    String[] arrayOfString = new String[2];
    arrayOfString[0] = this.fParserState.getStringPool().orphanString(paramInt2);
    arrayOfString[1] = this.fParserState.getStringPool().orphanString(paramInt3);
    String str2 = getErrorMsgString(str1, arrayOfString);
    handleError(str1, str2);
  }
  
  public final void error3(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws Exception {
    String str1 = ErrorCode.getErrorKey(paramInt1);
    if (!errorHandlingEnabled() && !isFatal(str1)) {
      this.fParserState.getStringPool().releaseString(paramInt2);
      this.fParserState.getStringPool().releaseString(paramInt3);
      this.fParserState.getStringPool().releaseString(paramInt4);
      return;
    } 
    String[] arrayOfString = new String[3];
    arrayOfString[0] = this.fParserState.getStringPool().orphanString(paramInt2);
    arrayOfString[1] = this.fParserState.getStringPool().orphanString(paramInt3);
    arrayOfString[2] = this.fParserState.getStringPool().orphanString(paramInt4);
    String str2 = getErrorMsgString(str1, arrayOfString);
    handleError(str1, str2);
  }
  
  public final void error4(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws Exception {
    String str1 = ErrorCode.getErrorKey(paramInt1);
    if (!errorHandlingEnabled() && (getContinueAfterFatalError() || !isFatal(str1))) {
      this.fParserState.getStringPool().releaseString(paramInt2);
      this.fParserState.getStringPool().releaseString(paramInt3);
      this.fParserState.getStringPool().releaseString(paramInt4);
      this.fParserState.getStringPool().releaseString(paramInt5);
      return;
    } 
    String[] arrayOfString = new String[4];
    arrayOfString[0] = this.fParserState.getStringPool().orphanString(paramInt2);
    arrayOfString[1] = this.fParserState.getStringPool().orphanString(paramInt3);
    arrayOfString[2] = this.fParserState.getStringPool().orphanString(paramInt4);
    arrayOfString[3] = this.fParserState.getStringPool().orphanString(paramInt5);
    String str2 = getErrorMsgString(str1, arrayOfString);
    handleError(str1, str2);
  }
  
  public abstract void doctypeDecl(int paramInt) throws Exception;
  
  public abstract void startInternalSubset();
  
  public abstract void endInternalSubset();
  
  public abstract void startExternalSubset(int paramInt1, int paramInt2) throws Exception;
  
  public abstract void endExternalSubset();
  
  public abstract void elementDecl(int paramInt) throws Exception;
  
  public abstract void attlistDecl(int paramInt1, int paramInt2) throws Exception;
  
  public abstract void internalEntityDecl(int paramInt) throws Exception;
  
  public abstract void externalEntityDecl(int paramInt) throws Exception;
  
  public abstract void unparsedEntityDecl(int paramInt) throws Exception;
  
  public abstract void notationDecl(int paramInt) throws Exception;
  
  public abstract void startDocument(int paramInt1, int paramInt2, int paramInt3) throws Exception;
  
  public abstract void endDocument();
  
  public abstract void startElement(int paramInt1, int paramInt2) throws Exception;
  
  public abstract void endElement(int paramInt) throws Exception;
  
  public abstract void startEntityReference(int paramInt) throws Exception;
  
  public abstract void endEntityReference(int paramInt) throws Exception;
  
  public abstract void characters(int paramInt, boolean paramBoolean) throws Exception;
  
  public abstract void ignorableWhitespace(int paramInt, boolean paramBoolean) throws Exception;
  
  public abstract void processingInstruction(int paramInt1, int paramInt2) throws Exception;
  
  public abstract void comment(int paramInt) throws Exception;
  
  public abstract void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) throws Exception;
  
  public abstract void ignorableWhitespace(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\XMLParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */