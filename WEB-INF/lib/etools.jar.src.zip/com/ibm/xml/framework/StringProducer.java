package com.ibm.xml.framework;

public interface StringProducer {
  String toString(int paramInt1, int paramInt2);
  
  boolean equalsString(int paramInt1, int paramInt2, String paramString, int paramInt3);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\StringProducer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */