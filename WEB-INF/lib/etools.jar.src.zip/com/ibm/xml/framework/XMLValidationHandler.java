package com.ibm.xml.framework;

public interface XMLValidationHandler {
  void reset(ParserState paramParserState);
  
  void checkRootElementName(int paramInt) throws Exception;
  
  void checkAttributes(int paramInt1, int paramInt2) throws Exception;
  
  int checkContent(int paramInt1, int paramInt2, int[] paramArrayOfInt) throws Exception;
  
  void checkIDRefNames() throws Exception;
  
  int whatCanGoHere(int paramInt, boolean paramBoolean, InsertableElementsInfo paramInsertableElementsInfo) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\XMLValidationHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */