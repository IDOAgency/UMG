package com.ibm.xml.framework;

public interface ContentModel {
  int validateContent(int paramInt, int[] paramArrayOfInt) throws Exception;
  
  int whatCanGoHere(boolean paramBoolean, InsertableElementsInfo paramInsertableElementsInfo) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\ContentModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */