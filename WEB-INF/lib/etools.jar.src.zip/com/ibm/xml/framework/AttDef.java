package com.ibm.xml.framework;

public final class AttDef {
  public static final int CDATA = 0;
  
  public static final int ID = 1;
  
  public static final int IDREF = 2;
  
  public static final int IDREFS = 3;
  
  public static final int ENTITY = 4;
  
  public static final int ENTITIES = 5;
  
  public static final int NMTOKEN = 6;
  
  public static final int NMTOKENS = 7;
  
  public static final int NOTATION = 8;
  
  public static final int ENUMERATION = 9;
  
  private static final String[] fgAttTypeString = { "CDATA", "ID", "IDREF", "IDREFS", "ENTITY", "ENTITIES", "NMTOKEN", "NMTOKENS", "NOTATION", "ENUMERATION" };
  
  public static final int DEFAULT = 1;
  
  public static final int REQUIRED = 2;
  
  public static final int IMPLIED = 3;
  
  public static final int FIXED = 4;
  
  public int attName;
  
  public int attType;
  
  public int enumeration;
  
  public int attDefaultType;
  
  public int attValue;
  
  public static final String getAttTypeString(int paramInt) {
    try {
      return fgAttTypeString[paramInt];
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      return null;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\AttDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */