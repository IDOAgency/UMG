package com.ibm.xml.framework;

import com.ibm.xml.internal.StringHasher;

public final class ChunkyCharArray {
  protected static final int INITIAL_CHUNK_SHIFT = 7;
  
  protected static final int INITIAL_CHUNK_SIZE = 128;
  
  protected static final int CHUNK_SHIFT = 14;
  
  protected static final int CHUNK_SIZE = 16384;
  
  protected static final int CHUNK_MASK = 16383;
  
  protected CharArrayChunk fCurrentChunk;
  
  protected int fLength;
  
  public ChunkyCharArray(StringPool paramStringPool) { this.fCurrentChunk = new CharArrayChunk(this, paramStringPool, null); }
  
  public int length() { return this.fLength; }
  
  public void setLength(int paramInt) { this.fCurrentChunk.setLength(paramInt); }
  
  public void append(char paramChar) { this.fCurrentChunk.append(paramChar); }
  
  public void append(String paramString) {
    int i = paramString.length();
    for (byte b = 0; b < i; b++)
      this.fCurrentChunk.append(paramString.charAt(b)); 
  }
  
  public void append(char[] paramArrayOfChar, int paramInt1, int paramInt2) {
    while (paramInt2-- > 0)
      this.fCurrentChunk.append(paramArrayOfChar[paramInt1++]); 
  }
  
  public void append(ChunkyCharArray paramChunkyCharArray, int paramInt1, int paramInt2) { this.fCurrentChunk.append(paramChunkyCharArray, paramInt1, paramInt2); }
  
  public int addString(int paramInt1, int paramInt2) { return (paramInt2 == 0) ? 0 : this.fCurrentChunk.addString(paramInt1, paramInt2); }
  
  public int addSymbol(int paramInt1, int paramInt2) { return (paramInt2 == 0) ? 0 : this.fCurrentChunk.addSymbol(paramInt1, paramInt2); }
  
  protected final class CharArrayChunk implements StringProducer {
    private final ChunkyCharArray this$0;
    
    protected StringPool fStringPool;
    
    protected int fChunk;
    
    protected int fCurrentIndex;
    
    protected char[] fData;
    
    protected CharArrayChunk fPreviousChunk;
    
    protected CharArrayChunk fNextChunk;
    
    public CharArrayChunk(ChunkyCharArray this$0, StringPool param1StringPool, CharArrayChunk param1CharArrayChunk) {
      this.this$0 = this$0;
      this.this$0 = this$0;
      this.fChunk = -1;
      this.fStringPool = param1StringPool;
      this.fChunk = (param1CharArrayChunk == null) ? 0 : (param1CharArrayChunk.fChunk + 1);
      this.fPreviousChunk = param1CharArrayChunk;
      if (param1CharArrayChunk != null)
        param1CharArrayChunk.fNextChunk = this; 
    }
    
    protected CharArrayChunk(ChunkyCharArray this$0, CharArrayChunk param1CharArrayChunk) {
      this.this$0 = this$0;
      this.this$0 = this$0;
      this.fChunk = -1;
      this.fStringPool = param1CharArrayChunk.fStringPool;
      this.fChunk = param1CharArrayChunk.fChunk;
      this.fData = param1CharArrayChunk.fData;
      this.fPreviousChunk = null;
      this.fNextChunk = null;
    }
    
    protected CharArrayChunk chunkFor(int param1Int) {
      int i = param1Int >> 14;
      for (CharArrayChunk charArrayChunk = this; i != charArrayChunk.fChunk; charArrayChunk = charArrayChunk.fPreviousChunk);
      return charArrayChunk;
    }
    
    public void setLength(int param1Int) {
      this.this$0.fLength = param1Int;
      this.this$0.fCurrentChunk = chunkFor(param1Int);
      this.fCurrentIndex = param1Int & 0x3FFF;
    }
    
    public void append(char param1Char) {
      try {
        this.fData[this.fCurrentIndex] = param1Char;
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        if (this.fCurrentIndex == 16384) {
          this.this$0.fCurrentChunk = new CharArrayChunk(this.this$0, this.fStringPool, this);
          this.this$0.fCurrentChunk.append(param1Char);
          return;
        } 
        char[] arrayOfChar = new char[this.fCurrentIndex * 2];
        System.arraycopy(this.fData, 0, arrayOfChar, 0, this.fCurrentIndex);
        this.fData = arrayOfChar;
        this.fData[this.fCurrentIndex] = param1Char;
      } catch (NullPointerException nullPointerException) {
        this.fData = new char[128];
        this.fData[this.fCurrentIndex] = param1Char;
      } 
      this.this$0.fLength++;
      this.fCurrentIndex++;
    }
    
    public void append(ChunkyCharArray param1ChunkyCharArray, int param1Int1, int param1Int2) {
      CharArrayChunk charArrayChunk = chunkFor(param1Int1);
      int i = param1Int1 & 0x3FFF;
      if (i + param1Int2 <= 16384) {
        char[] arrayOfChar1 = charArrayChunk.fData;
        int n = i;
        int i1 = param1Int2;
        while (i1-- > 0)
          param1ChunkyCharArray.fCurrentChunk.append(arrayOfChar1[n++]); 
        return;
      } 
      int j = 16384 - i;
      char[] arrayOfChar = charArrayChunk.fData;
      int k = i;
      int m = j;
      while (m-- > 0)
        param1ChunkyCharArray.fCurrentChunk.append(arrayOfChar[k++]); 
      param1Int2 -= j;
      do {
        charArrayChunk = charArrayChunk.fNextChunk;
        j = (param1Int2 <= 16384) ? param1Int2 : 16384;
        arrayOfChar = charArrayChunk.fData;
        k = 0;
        m = j;
        while (m-- > 0)
          param1ChunkyCharArray.fCurrentChunk.append(arrayOfChar[k++]); 
        param1Int2 -= j;
      } while (param1Int2 > 0);
    }
    
    protected CharArrayChunk createClump(int param1Int) {
      CharArrayChunk charArrayChunk1 = new CharArrayChunk(this.this$0, this);
      CharArrayChunk charArrayChunk2 = this.fNextChunk;
      CharArrayChunk charArrayChunk3 = charArrayChunk1;
      do {
        CharArrayChunk charArrayChunk = new CharArrayChunk(this.this$0, charArrayChunk2);
        charArrayChunk3.fNextChunk = charArrayChunk;
        charArrayChunk2 = charArrayChunk2.fNextChunk;
        charArrayChunk3 = charArrayChunk;
      } while (charArrayChunk3.fChunk != param1Int);
      return charArrayChunk1;
    }
    
    public int addString(int param1Int1, int param1Int2) {
      int i = param1Int1 >> 14;
      if (i != this.fChunk) {
        if (this.fPreviousChunk != null)
          return this.fPreviousChunk.addString(param1Int1, param1Int2); 
        System.out.println("fPreviousChunk == null");
        return -1;
      } 
      int j = param1Int1 + param1Int2 - 1 >> 14;
      if (i == j)
        return this.fStringPool.addString(this, param1Int1 & 0x3FFF, param1Int2); 
      if (this.fNextChunk == null)
        System.out.println("fNextChunk == null"); 
      return this.fStringPool.addString(createClump(j), param1Int1 & 0x3FFF, param1Int2);
    }
    
    public int addSymbol(int param1Int1, int param1Int2) {
      int i = param1Int1 >> 14;
      if (i != this.fChunk) {
        if (this.fPreviousChunk != null)
          return this.fPreviousChunk.addSymbol(param1Int1, param1Int2); 
        System.out.println("fPreviousChunk == null");
        return -1;
      } 
      int j = param1Int1 + param1Int2 - 1 >> 14;
      int k = param1Int1 & 0x3FFF;
      if (i == j) {
        int i3 = 0;
        for (byte b1 = 0; b1 < param1Int2; b1++)
          i3 = StringHasher.hashChar(i3, b1, this.fData[k++] & 0xFFFF); 
        int i4 = i3;
        i4 &= Integer.MAX_VALUE;
        i3 = (i4 == 0) ? 1 : i4;
        return this.fStringPool.addSymbol(this, param1Int1 & 0x3FFF, param1Int2, i3);
      } 
      int m = 0;
      byte b = 0;
      int n = param1Int2;
      int i1 = 16384 - k;
      while (k < 16384)
        m = StringHasher.hashChar(m, b++, this.fData[k++] & 0xFFFF); 
      n -= i1;
      CharArrayChunk charArrayChunk = this.fNextChunk;
      do {
        k = 0;
        i1 = (n <= 16384) ? n : 16384;
        while (k < i1)
          m = StringHasher.hashChar(m, b++, charArrayChunk.fData[k++] & 0xFFFF); 
        n -= i1;
        charArrayChunk = charArrayChunk.fNextChunk;
      } while (n > 0);
      int i2 = m;
      i2 &= Integer.MAX_VALUE;
      m = (i2 == 0) ? 1 : i2;
      return this.fStringPool.addSymbol(createClump(j), param1Int1 & 0x3FFF, param1Int2, m);
    }
    
    public String toString(int param1Int1, int param1Int2) {
      if (param1Int1 + param1Int2 <= 16384)
        return new String(this.fData, param1Int1, param1Int2); 
      StringBuffer stringBuffer = new StringBuffer(param1Int2);
      int i = 16384 - param1Int1;
      stringBuffer.append(this.fData, param1Int1, i);
      param1Int2 -= i;
      CharArrayChunk charArrayChunk = this.fNextChunk;
      do {
        i = (param1Int2 <= 16384) ? param1Int2 : 16384;
        stringBuffer.append(charArrayChunk.fData, 0, i);
        param1Int2 -= i;
        charArrayChunk = charArrayChunk.fNextChunk;
      } while (param1Int2 > 0);
      String str = stringBuffer.toString();
      stringBuffer = null;
      return str;
    }
    
    public boolean equalsString(int param1Int1, int param1Int2, String param1String, int param1Int3) {
      if (param1Int2 != param1Int3)
        return false; 
      if (param1Int1 + param1Int2 <= 16384) {
        for (byte b1 = 0; b1 < param1Int2; b1++) {
          if (this.fData[param1Int1++] != param1String.charAt(b1))
            return false; 
        } 
        return true;
      } 
      int i = 16384 - param1Int1;
      byte b = 0;
      while (b < i) {
        if (this.fData[param1Int1++] != param1String.charAt(b++))
          return false; 
      } 
      param1Int2 -= i;
      CharArrayChunk charArrayChunk = this.fNextChunk;
      do {
        param1Int1 = 0;
        i = (param1Int2 <= 16384) ? param1Int2 : 16384;
        param1Int2 -= i;
        while (i-- > 0) {
          if (charArrayChunk.fData[param1Int1++] != param1String.charAt(b++))
            return false; 
        } 
        charArrayChunk = charArrayChunk.fNextChunk;
      } while (param1Int2 > 0);
      return true;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\ChunkyCharArray.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */