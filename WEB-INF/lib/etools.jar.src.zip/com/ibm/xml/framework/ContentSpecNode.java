package com.ibm.xml.framework;

public final class ContentSpecNode {
  public static final int NODE_LEAF = 0;
  
  public static final int NODE_ZERO_OR_ONE = 1;
  
  public static final int NODE_ZERO_OR_MORE = 2;
  
  public static final int NODE_ONE_OR_MORE = 3;
  
  public static final int NODE_CHOICE = 4;
  
  public static final int NODE_SEQ = 5;
  
  public int type;
  
  public int value;
  
  public int otherValue;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\ContentSpecNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */