package com.ibm.xml.framework;

import com.ibm.xml.internal.DefaultAttrPool;
import com.ibm.xml.internal.DefaultElementDeclPool;
import com.ibm.xml.internal.DefaultEntityPool;
import com.ibm.xml.internal.DefaultStringPool;

public final class ParserState {
  private static final boolean USE_CHAR_READER_FOR_UTF8 = true;
  
  private XMLParser fParser;
  
  private StringPool fStringPool;
  
  private AttrPool fAttrPool;
  
  private EntityPool fEntityPool;
  
  private ElementDeclPool fElementDeclPool;
  
  ParserState(XMLParser paramXMLParser) { this.fParser = paramXMLParser; }
  
  ParserState(ParserState paramParserState) {
    this.fParser = paramParserState.fParser;
    this.fStringPool = paramParserState.fStringPool.resetOrCopy(this);
    this.fAttrPool = paramParserState.fAttrPool.resetOrCopy(this);
    this.fEntityPool = paramParserState.fEntityPool.resetOrCopy(this);
    this.fElementDeclPool = paramParserState.fElementDeclPool.resetOrCopy(this);
  }
  
  void reset() {
    this.fStringPool.reset(this);
    this.fAttrPool.reset(this);
    this.fEntityPool.reset(this);
    this.fElementDeclPool.reset(this);
  }
  
  ParserState resetOrCopy() { return new ParserState(this); }
  
  public XMLScanner getScanner() { return this.fParser.getScanner(); }
  
  public boolean getAllowJavaEncodingName() { return this.fParser.getAllowJavaEncodingName(); }
  
  public boolean getWarningOnDuplicateAttDef() { return this.fParser.getWarningOnDuplicateAttDef(); }
  
  public boolean getCheckNamespace() { return this.fParser.getCheckNamespace(); }
  
  public boolean getUseCharReaderForUTF8() { return true; }
  
  public XMLDocumentHandler getDocumentHandler() { return this.fParser.getDocumentHandler(); }
  
  public XMLDocumentTypeHandler getDocumentTypeHandler() { return this.fParser.getDocumentTypeHandler(); }
  
  public XMLEntityHandler getEntityHandler() { return this.fParser.getEntityHandler(); }
  
  public XMLErrorHandler getErrorHandler() { return this.fParser.getErrorHandler(); }
  
  public XMLValidationHandler getValidationHandler() { return this.fParser.getValidationHandler(); }
  
  public StringPool cacheStringPool() { return this.fStringPool; }
  
  public StringPool getStringPool() { return this.fStringPool; }
  
  public void setStringPool(StringPool paramStringPool) { this.fStringPool = paramStringPool; }
  
  public void useDefaultStringPool() { this.fStringPool = new DefaultStringPool(this); }
  
  public AttrPool cacheAttrPool() { return this.fAttrPool; }
  
  public AttrPool getAttrPool() { return this.fAttrPool; }
  
  public void setAttrPool(AttrPool paramAttrPool) { this.fAttrPool = paramAttrPool; }
  
  public void useDefaultAttrPool() { this.fAttrPool = new DefaultAttrPool(this); }
  
  public EntityPool getEntityPool() { return this.fEntityPool; }
  
  public void setEntityPool(EntityPool paramEntityPool) { this.fEntityPool = paramEntityPool; }
  
  public void useDefaultEntityPool() { this.fEntityPool = new DefaultEntityPool(this, true); }
  
  public ElementDeclPool cacheElementDeclPool() { return this.fElementDeclPool; }
  
  public ElementDeclPool getElementDeclPool() { return this.fElementDeclPool; }
  
  public void setElementDeclPool(ElementDeclPool paramElementDeclPool) { this.fElementDeclPool = paramElementDeclPool; }
  
  public void useDefaultElementDeclPool() { this.fElementDeclPool = new DefaultElementDeclPool(this); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\ParserState.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */