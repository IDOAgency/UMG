package com.ibm.xml.framework;

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;

public interface XMLEntityHandler {
  void reset(ParserState paramParserState);
  
  void addRecognizer(XMLDeclRecognizer paramXMLDeclRecognizer);
  
  void setEntityResolver(EntityResolver paramEntityResolver);
  
  EntityResolver getEntityResolver();
  
  InputSource resolveEntity(int paramInt1, int paramInt2) throws Exception;
  
  int expandSystemId(int paramInt);
  
  XMLReader createReader(InputSource paramInputSource, boolean paramBoolean) throws Exception;
  
  void startInputSource(InputSource paramInputSource);
  
  void endInputSource(InputSource paramInputSource);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\XMLEntityHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */