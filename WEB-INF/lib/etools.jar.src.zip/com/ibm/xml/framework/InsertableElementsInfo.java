package com.ibm.xml.framework;

public class InsertableElementsInfo {
  public boolean canHoldPCData;
  
  public int childCount;
  
  public int[] curChildren;
  
  public boolean isValidEOC;
  
  public int insertAt;
  
  public int[] possibleChildren;
  
  public boolean[] results;
  
  public int resultsCount;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\InsertableElementsInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */