package com.ibm.xml.framework;

import org.xml.sax.AttributeList;

public interface AttrPool {
  void reset(ParserState paramParserState);
  
  AttrPool resetOrCopy(ParserState paramParserState);
  
  int addAttr(Attr paramAttr, int paramInt) throws Exception;
  
  void setIsLastAttr(int paramInt);
  
  int getAttrName(int paramInt);
  
  int getAttType(int paramInt);
  
  int getAttValue(int paramInt);
  
  boolean isSpecified(int paramInt);
  
  boolean isLastAttr(int paramInt);
  
  void releaseAttrList(int paramInt);
  
  AttributeList getAttributeList(int paramInt);
  
  int getFirstAttr(int paramInt);
  
  int getNextAttr(int paramInt);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\AttrPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */