package com.ibm.xml.framework;

public final class EntityDecl {
  public int entityName;
  
  public int entityValue;
  
  public int publicId;
  
  public int systemId;
  
  public int notationName;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\EntityDecl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */