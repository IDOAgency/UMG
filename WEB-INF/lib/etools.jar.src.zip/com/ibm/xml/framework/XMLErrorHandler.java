package com.ibm.xml.framework;

public interface XMLErrorHandler {
  void error(int paramInt) throws Exception;
  
  void error1(int paramInt1, int paramInt2) throws Exception;
  
  void error2(int paramInt1, int paramInt2, int paramInt3) throws Exception;
  
  void error3(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws Exception;
  
  void error4(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\XMLErrorHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */