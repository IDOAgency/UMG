package com.ibm.xml.framework;

import java.io.IOException;
import java.io.InputStream;

public final class ChunkyByteArray extends InputStream {
  private static final int CHUNK_SHIFT = 14;
  
  private static final int CHUNK_SIZE = 16384;
  
  private static final int CHUNK_MASK = 16383;
  
  private static final int INITIAL_CHUNK_COUNT = 64;
  
  private InputStream fInputStream;
  
  private byte[][] fData = new byte[64][];
  
  private int fLength;
  
  private int fOffset;
  
  public ChunkyByteArray(InputStream paramInputStream) throws IOException {
    this.fInputStream = paramInputStream;
    fill();
  }
  
  public int read() throws IOException {
    if (this.fData == null)
      return (this.fInputStream == null) ? -1 : this.fInputStream.read(); 
    byte b = this.fData[0][this.fOffset];
    if (++this.fOffset == this.fLength) {
      this.fData = null;
      if (this.fLength < 16384)
        this.fInputStream = null; 
    } 
    return b;
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
    int i = this.fLength - this.fOffset;
    if (i == 0)
      return (this.fInputStream == null) ? -1 : this.fInputStream.read(paramArrayOfByte, paramInt1, paramInt2); 
    if (paramInt2 <= 0)
      return 0; 
    byte[] arrayOfByte = this.fData[0];
    if (paramInt2 >= i) {
      paramInt2 = i;
      if (this.fLength < 16384)
        this.fInputStream = null; 
    } 
    if (paramArrayOfByte == null) {
      this.fOffset += paramInt2;
      return paramInt2;
    } 
    int j = paramInt1 + paramInt2;
    do {
      paramArrayOfByte[paramInt1++] = arrayOfByte[this.fOffset++];
    } while (paramInt1 < j);
    return paramInt2;
  }
  
  public void rewind() { this.fOffset = 0; }
  
  private void fill() {
    int i = this.fLength >> 14;
    byte[] arrayOfByte = new byte[16384];
    this.fData[i] = arrayOfByte;
    int j = 0;
    int k = 16384;
    int m = 0;
    do {
      m = this.fInputStream.read(arrayOfByte, j, k);
      if (m == -1) {
        arrayOfByte[j] = -1;
        this.fInputStream.close();
        this.fInputStream = null;
        return;
      } 
      if (m <= 0)
        continue; 
      this.fLength += m;
      j += m;
      k -= m;
    } while (k > 0);
  }
  
  public byte byteAt(int paramInt) {
    int i = paramInt >> 14;
    int j = paramInt & 0x3FFF;
    try {
      return this.fData[i][j];
    } catch (NullPointerException nullPointerException) {
      try {
        if (j == 0) {
          fill();
          return this.fData[i][j];
        } 
        return 0;
      } catch (IOException iOException) {
        return 0;
      } 
    } 
  }
  
  public boolean atEOF(int paramInt) { return !(paramInt <= this.fLength); }
  
  public void checkEOF(int paramInt) {
    if (paramInt > this.fLength)
      throw new ArrayIndexOutOfBoundsException(); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\ChunkyByteArray.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */