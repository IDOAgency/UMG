package com.ibm.xml.framework;

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;

public interface Catalog extends EntityResolver {
  void loadCatalog(InputSource paramInputSource) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\Catalog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */