package com.ibm.xml.framework;

public interface EntityPool {
  void reset(ParserState paramParserState);
  
  EntityPool resetOrCopy(ParserState paramParserState);
  
  int addEntityDecl(EntityDecl paramEntityDecl);
  
  int addNotationDecl(NotationDecl paramNotationDecl);
  
  int lookupEntity(int paramInt);
  
  boolean isExternal(int paramInt);
  
  boolean isUnparsed(int paramInt);
  
  int getEntityName(int paramInt);
  
  int getEntityValue(int paramInt);
  
  int getPublicId(int paramInt);
  
  int getSystemId(int paramInt);
  
  int getNotationName(int paramInt);
  
  int lookupNotation(int paramInt);
  
  void checkUnparsedEntities() throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\EntityPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */