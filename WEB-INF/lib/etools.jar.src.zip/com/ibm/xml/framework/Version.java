package com.ibm.xml.framework;

public class Version {
  public static String fVersion = "XML4J 2.0.9";
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\Version.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */