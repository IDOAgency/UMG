package com.ibm.xml.framework;

public interface ElementDeclPool {
  void reset(ParserState paramParserState);
  
  ElementDeclPool resetOrCopy(ParserState paramParserState);
  
  void setRootElement(int paramInt);
  
  int getRootElement();
  
  int getElement(int paramInt);
  
  int addElement(int paramInt);
  
  int addElementDecl(ElementDecl paramElementDecl);
  
  int getElementName(int paramInt);
  
  int getContentSpecType(int paramInt);
  
  int getContentSpec(int paramInt);
  
  String getContentSpecAsString(int paramInt);
  
  ContentModel getContentModel(int paramInt);
  
  void setContentModel(int paramInt, ContentModel paramContentModel);
  
  int addContentSpecNode(ContentSpecNode paramContentSpecNode);
  
  void getContentSpecNode(int paramInt, ContentSpecNode paramContentSpecNode);
  
  String getContentSpecNodeAsString(int paramInt);
  
  int addAttDef(int paramInt, AttDef paramAttDef) throws Exception;
  
  int getAttDef(int paramInt1, int paramInt2);
  
  int getAttName(int paramInt);
  
  int getAttValue(int paramInt);
  
  int getAttType(int paramInt);
  
  int getAttDefaultType(int paramInt);
  
  int getEnumeration(int paramInt);
  
  int addDefaultAttributes(int paramInt1, AttrPool paramAttrPool, int paramInt2, int paramInt3) throws Exception;
  
  boolean addId(int paramInt1, int paramInt2);
  
  void addIdRef(int paramInt1, int paramInt2);
  
  void checkIdRefs() throws Exception;
  
  void checkNamespace(int paramInt1, int paramInt2);
  
  void checkDeclaredElements() throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\ElementDeclPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */