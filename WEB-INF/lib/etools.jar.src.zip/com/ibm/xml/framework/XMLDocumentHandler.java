package com.ibm.xml.framework;

public interface XMLDocumentHandler {
  boolean sendCharDataAsCharArray();
  
  void startDocument(int paramInt1, int paramInt2, int paramInt3) throws Exception;
  
  void endDocument() throws Exception;
  
  void startElement(int paramInt1, int paramInt2) throws Exception;
  
  void endElement(int paramInt) throws Exception;
  
  void startEntityReference(int paramInt) throws Exception;
  
  void endEntityReference(int paramInt) throws Exception;
  
  void characters(int paramInt, boolean paramBoolean) throws Exception;
  
  void ignorableWhitespace(int paramInt, boolean paramBoolean) throws Exception;
  
  void processingInstruction(int paramInt1, int paramInt2) throws Exception;
  
  void comment(int paramInt) throws Exception;
  
  void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) throws Exception;
  
  void ignorableWhitespace(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\XMLDocumentHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */