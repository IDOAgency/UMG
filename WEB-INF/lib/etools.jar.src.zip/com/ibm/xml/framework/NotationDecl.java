package com.ibm.xml.framework;

public final class NotationDecl {
  public int notationName;
  
  public int publicId;
  
  public int systemId;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\NotationDecl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */