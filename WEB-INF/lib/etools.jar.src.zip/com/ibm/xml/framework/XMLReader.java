package com.ibm.xml.framework;

import org.xml.sax.Locator;

public abstract class XMLReader implements Locator {
  public static final int CHARDATA_RESULT_MARKUP = 1;
  
  public static final int CHARDATA_RESULT_REFERENCE = 2;
  
  public static final int CHARDATA_RESULT_CDEND = 3;
  
  public static final int CHARDATA_RESULT_INVALID_CHAR = 4;
  
  public static final int CHARDATA_RESULT_STATE_MASK = 7;
  
  public static final int CHARDATA_RESULT_CHARDATA = 8;
  
  public static final int CHARDATA_RESULT_ALL_SPACE = 16;
  
  protected ParserState fParserState;
  
  protected String fPublicId;
  
  protected String fSystemId;
  
  protected int fCarriageReturnCounter = 1;
  
  protected int fLinefeedCounter = 1;
  
  protected int fCharacterCounter = 1;
  
  protected int fCurrentOffset;
  
  protected static final byte[] fgAsciiXDigitChar = { 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
  
  protected static final byte[] fgAsciiAlphaChar = { 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1 };
  
  protected static final byte[] fgAsciiInitialNameChar = { 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1 };
  
  protected static final byte[] fgAsciiNameChar = { 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
      1 };
  
  protected static final byte[] fgAsciiCharData = { 
      4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
      4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
      4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
      4, 2, 1, 3 };
  
  protected static final byte[] fgAsciiWSCharData = { 
      4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 
      5, 4, 4, 5, 4, 4, 4, 4, 4, 4, 
      4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
      4, 4, 5, 2, 1, 3 };
  
  protected static final byte E_VersionNumFlag = 1;
  
  protected static final byte E_EncNameFlag = 2;
  
  protected static final byte E_PubidCharFlag = 4;
  
  protected static final byte E_CharDataFlag = 8;
  
  protected static final byte E_InitialNameCharFlag = 16;
  
  protected static final byte E_NameCharFlag = 32;
  
  protected static byte[] fgCharFlags = null;
  
  private static final char[] fgVersionNumRanges = { '-', '.', '0', ':', 'A', 'F', 'a', 'f', '_' };
  
  private static final char[] fgEncNameRanges = { '-', '.', '0', '9', 'A', 'Z', 'a', 'z', '_' };
  
  private static final char[] fgPubidCharRanges = { 
      ' ', '!', '#', '%', '\'', ';', '?', 'Z', 'a', 'z', 
      '=', '_' };
  
  private static final char[] fgCharDataRanges = { 
      ' ', '%', '\'', ';', '=', '\\', '^', '퟿', '', '�', 
      '\t' };
  
  private static final char[] fgInitialNameCharRanges = { 
      'A', 'Z', 'a', 'z', 'À', 'Ö', 'Ø', 'ö', 'ø', 'ı', 
      'Ĵ', 'ľ', 'Ł', 'ň', 'Ŋ', 'ž', 'ƀ', 'ǃ', 'Ǎ', 'ǰ', 
      'Ǵ', 'ǵ', 'Ǻ', 'ȗ', 'ɐ', 'ʨ', 'ʻ', 'ˁ', 'Έ', 'Ί', 
      'Ύ', 'Ρ', 'Σ', 'ώ', 'ϐ', 'ϖ', 'Ϣ', 'ϳ', 'Ё', 'Ќ', 
      'Ў', 'я', 'ё', 'ќ', 'ў', 'ҁ', 'Ґ', 'ӄ', 'Ӈ', 'ӈ', 
      'Ӌ', 'ӌ', 'Ӑ', 'ӫ', 'Ӯ', 'ӵ', 'Ӹ', 'ӹ', 'Ա', 'Ֆ', 
      'ա', 'ֆ', 'א', 'ת', 'װ', 'ײ', 'ء', 'غ', 'ف', 'ي', 
      'ٱ', 'ڷ', 'ں', 'ھ', 'ۀ', 'ێ', 'ې', 'ۓ', 'ۥ', 'ۦ', 
      'अ', 'ह', 'क़', 'ॡ', 'অ', 'ঌ', 'এ', 'ঐ', 'ও', 'ন', 
      'প', 'র', 'শ', 'হ', 'ড়', 'ঢ়', 'য়', 'ৡ', 'ৰ', 'ৱ', 
      'ਅ', 'ਊ', 'ਏ', 'ਐ', 'ਓ', 'ਨ', 'ਪ', 'ਰ', 'ਲ', 'ਲ਼', 
      'ਵ', 'ਸ਼', 'ਸ', 'ਹ', 'ਖ਼', 'ੜ', 'ੲ', 'ੴ', 'અ', 'ઋ', 
      'એ', 'ઑ', 'ઓ', 'ન', 'પ', 'ર', 'લ', 'ળ', 'વ', 'હ', 
      'ଅ', 'ଌ', 'ଏ', 'ଐ', 'ଓ', 'ନ', 'ପ', 'ର', 'ଲ', 'ଳ', 
      'ଶ', 'ହ', 'ଡ଼', 'ଢ଼', 'ୟ', 'ୡ', 'அ', 'ஊ', 'எ', 'ஐ', 
      'ஒ', 'க', 'ங', 'ச', 'ஞ', 'ட', 'ண', 'த', 'ந', 'ப', 
      'ம', 'வ', 'ஷ', 'ஹ', 'అ', 'ఌ', 'ఎ', 'ఐ', 'ఒ', 'న', 
      'ప', 'ళ', 'వ', 'హ', 'ౠ', 'ౡ', 'ಅ', 'ಌ', 'ಎ', 'ಐ', 
      'ಒ', 'ನ', 'ಪ', 'ಳ', 'ವ', 'ಹ', 'ೠ', 'ೡ', 'അ', 'ഌ', 
      'എ', 'ഐ', 'ഒ', 'ന', 'പ', 'ഹ', 'ൠ', 'ൡ', 'ก', 'ฮ', 
      'า', 'ำ', 'เ', 'ๅ', 'ກ', 'ຂ', 'ງ', 'ຈ', 'ດ', 'ທ', 
      'ນ', 'ຟ', 'ມ', 'ຣ', 'ສ', 'ຫ', 'ອ', 'ຮ', 'າ', 'ຳ', 
      'ເ', 'ໄ', 'ཀ', 'ཇ', 'ཉ', 'ཀྵ', 'Ⴀ', 'Ⴥ', 'ა', 'ჶ', 
      'ᄂ', 'ᄃ', 'ᄅ', 'ᄇ', 'ᄋ', 'ᄌ', 'ᄎ', 'ᄒ', 'ᅔ', 'ᅕ', 
      'ᅟ', 'ᅡ', 'ᅭ', 'ᅮ', 'ᅲ', 'ᅳ', 'ᆮ', 'ᆯ', 'ᆷ', 'ᆸ', 
      'ᆼ', 'ᇂ', 'Ḁ', 'ẛ', 'Ạ', 'ỹ', 'ἀ', 'ἕ', 'Ἐ', 'Ἕ', 
      'ἠ', 'ὅ', 'Ὀ', 'Ὅ', 'ὐ', 'ὗ', 'Ὗ', 'ώ', 'ᾀ', 'ᾴ', 
      'ᾶ', 'ᾼ', 'ῂ', 'ῄ', 'ῆ', 'ῌ', 'ῐ', 'ΐ', 'ῖ', 'Ί', 
      'ῠ', 'Ῥ', 'ῲ', 'ῴ', 'ῶ', 'ῼ', 'K', 'Å', 'ↀ', 'ↂ', 
      'ぁ', 'ゔ', 'ァ', 'ヺ', 'ㄅ', 'ㄬ', '가', '힣', '〡', '〩', 
      '一', '龥', ':', '_', 'Ά', 'Ό', 'Ϛ', 'Ϝ', 'Ϟ', 'Ϡ', 
      'ՙ', 'ە', 'ऽ', 'ল', 'ਫ਼', 'ઍ', 'ઽ', 'ૠ', 'ଽ', 'ஜ', 
      'ೞ', 'ะ', 'ຄ', 'ຊ', 'ຍ', 'ລ', 'ວ', 'ະ', 'ຽ', 'ᄀ', 
      'ᄉ', 'ᄼ', 'ᄾ', 'ᅀ', 'ᅌ', 'ᅎ', 'ᅐ', 'ᅙ', 'ᅣ', 'ᅥ', 
      'ᅧ', 'ᅩ', 'ᅵ', 'ᆞ', 'ᆨ', 'ᆫ', 'ᆺ', 'ᇫ', 'ᇰ', 'ᇹ', 
      'Ὑ', 'Ὓ', 'Ὕ', 'ι', 'Ω', '℮', '〇' };
  
  private static final char[] fgNameCharRanges = { 
      '-', '.', '̀', 'ͅ', '͠', '͡', '҃', '҆', '֑', '֡', 
      '֣', 'ֹ', 'ֻ', 'ֽ', 'ׁ', 'ׂ', 'ً', 'ْ', 'ۖ', 'ۜ', 
      '۝', '۟', '۠', 'ۤ', 'ۧ', 'ۨ', '۪', 'ۭ', 'ँ', 'ः', 
      'ा', 'ौ', '॑', '॔', 'ॢ', 'ॣ', 'ঁ', 'ঃ', 'ী', 'ৄ', 
      'ে', 'ৈ', 'ো', '্', 'ৢ', 'ৣ', 'ੀ', 'ੂ', 'ੇ', 'ੈ', 
      'ੋ', '੍', 'ੰ', 'ੱ', 'ઁ', 'ઃ', 'ા', 'ૅ', 'ે', 'ૉ', 
      'ો', '્', 'ଁ', 'ଃ', 'ା', 'ୃ', 'େ', 'ୈ', 'ୋ', '୍', 
      'ୖ', 'ୗ', 'ஂ', 'ஃ', 'ா', 'ூ', 'ெ', 'ை', 'ொ', '்', 
      'ఁ', 'ః', 'ా', 'ౄ', 'ె', 'ై', 'ొ', '్', 'ౕ', 'ౖ', 
      'ಂ', 'ಃ', 'ಾ', 'ೄ', 'ೆ', 'ೈ', 'ೊ', '್', 'ೕ', 'ೖ', 
      'ം', 'ഃ', 'ാ', 'ൃ', 'െ', 'ൈ', 'ൊ', '്', 'ิ', 'ฺ', 
      '็', '๎', 'ິ', 'ູ', 'ົ', 'ຼ', '່', 'ໍ', '༘', '༙', 
      'ཱ', '྄', '྆', 'ྋ', 'ྐ', 'ྕ', 'ྙ', 'ྭ', 'ྱ', 'ྷ', 
      '⃐', '⃜', '〪', '〯', '0', '9', '٠', '٩', '۰', '۹', 
      '०', '९', '০', '৯', '੦', '੯', '૦', '૯', '୦', '୯', 
      '௧', '௯', '౦', '౯', '೦', '೯', '൦', '൯', '๐', '๙', 
      '໐', '໙', '༠', '༩', '〱', '〵', 'ゝ', 'ゞ', 'ー', 'ヾ', 
      'ֿ', 'ׄ', 'ٰ', '़', '्', '়', 'া', 'ি', 'ৗ', 'ਂ', 
      '਼', 'ਾ', 'ਿ', '઼', '଼', 'ௗ', 'ൗ', 'ั', 'ັ', '༵', 
      '༷', '༹', '༾', '༿', 'ྗ', 'ྐྵ', '⃡', '゙', '゚', '·', 
      'ː', 'ˑ', '·', 'ـ', 'ๆ', 'ໆ', '々' };
  
  protected XMLReader(ParserState paramParserState, String paramString1, String paramString2) {
    this.fParserState = paramParserState;
    this.fPublicId = paramString1;
    this.fSystemId = paramString2;
    initCharFlags();
  }
  
  public String getPublicId() { return this.fPublicId; }
  
  public String getSystemId() { return this.fSystemId; }
  
  public int getLineNumber() { return (this.fLinefeedCounter > 1) ? this.fLinefeedCounter : this.fCarriageReturnCounter; }
  
  public int getColumnNumber() { return this.fCharacterCounter; }
  
  public abstract int addString(int paramInt1, int paramInt2);
  
  public abstract int addSymbol(int paramInt1, int paramInt2);
  
  public abstract void append(ChunkyCharArray paramChunkyCharArray, int paramInt1, int paramInt2);
  
  public abstract int skipOneChar();
  
  public abstract int skipAsciiChar();
  
  public abstract int skipToChar(char paramChar) throws Exception;
  
  public abstract int skipPastChar(char paramChar) throws Exception;
  
  public abstract boolean skippedValidChar() throws Exception;
  
  public abstract boolean lookingAtValidChar() throws Exception;
  
  public abstract int skipInvalidChar(int paramInt) throws Exception;
  
  public abstract boolean skippedChar(char paramChar) throws Exception;
  
  public abstract boolean lookingAtChar(char paramChar) throws Exception;
  
  public abstract boolean skippedSpace() throws Exception;
  
  public abstract boolean lookingAtSpace() throws Exception;
  
  public abstract int skipPastSpaces();
  
  public abstract int skipDecimalDigit();
  
  public abstract int skipHexDigit();
  
  public abstract boolean skippedAlpha() throws Exception;
  
  public abstract boolean skippedVersionNum() throws Exception;
  
  public abstract boolean skippedEncName() throws Exception;
  
  public abstract boolean skippedPubidChar() throws Exception;
  
  public abstract boolean skippedString(char[] paramArrayOfChar) throws Exception;
  
  public abstract int scanName(char paramChar, int paramInt) throws Exception;
  
  public abstract int skipPastName(char paramChar) throws Exception;
  
  public abstract int skipPastNmtoken(char paramChar) throws Exception;
  
  public abstract int scanContent(ScanContentState paramScanContentState) throws Exception;
  
  public final int currentOffset() { return this.fCurrentOffset; }
  
  private static void initCharFlags() {
    if (fgCharFlags == null) {
      fgCharFlags = new byte[65536];
      setFlagForRange(fgVersionNumRanges, (byte)1);
      setFlagForRange(fgEncNameRanges, (byte)2);
      setFlagForRange(fgPubidCharRanges, (byte)4);
      setFlagForRange(fgCharDataRanges, (byte)8);
      setFlagForRange(fgInitialNameCharRanges, (byte)48);
      setFlagForRange(fgNameCharRanges, (byte)32);
    } 
  }
  
  private static void setFlagForRange(char[] paramArrayOfChar, byte paramByte) {
    byte b;
    char c;
    for (b = 0; (c = paramArrayOfChar[b]) != '\000'; b += true) {
      char c1 = paramArrayOfChar[b + true];
      while (c <= c1)
        fgCharFlags[c++] = (byte)(fgCharFlags[c++] | paramByte); 
    } 
    while ((c = paramArrayOfChar[++b]) != '\000') {
      fgCharFlags[c] = (byte)(fgCharFlags[c] | paramByte);
      b++;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\framework\XMLReader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */