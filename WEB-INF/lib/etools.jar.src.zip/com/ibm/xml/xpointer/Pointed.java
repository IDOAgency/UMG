package com.ibm.xml.xpointer;

import java.util.Vector;
import org.w3c.dom.Node;

public class Pointed extends Vector {
  static final long serialVersionUID = -188837514608910653L;
  
  public static final int T_NODE = 0;
  
  public static final int T_STRINGINNODE = 1;
  
  public static final int T_STRING = 2;
  
  public boolean add(Node paramNode, String paramString, int paramInt1, int paramInt2) {
    Item item = new Item(paramNode, paramString, paramInt1, paramInt2);
    int i = indexOf(item);
    if (i >= 0)
      return false; 
    addElement(item);
    return true;
  }
  
  public boolean add(Node paramNode) { return add(paramNode, null, 0, 0); }
  
  public boolean add(String paramString) { return add(null, paramString, 0, 0); }
  
  public Item item(int paramInt) throws ArrayIndexOutOfBoundsException { return (Item)elementAt(paramInt); }
  
  public static class Item {
    public int type = -1;
    
    public Node node;
    
    public String string;
    
    int offset = -1;
    
    int length = -1;
    
    public Item(Node param1Node, String param1String, int param1Int1, int param1Int2) {
      this.node = param1Node;
      this.string = param1String;
      if (param1Node == null) {
        this.type = 2;
        return;
      } 
      if (param1String == null) {
        this.type = 0;
        return;
      } 
      this.type = 1;
      this.offset = param1Int1;
      this.length = param1Int2;
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object == null || !(param1Object instanceof Item))
        return false; 
      Item item = (Item)param1Object;
      if (this.type != item.type)
        return false; 
      switch (this.type) {
        case 0:
          return !(this.node != item.node);
        case 1:
          return !(this.node != item.node || this.offset != item.offset || this.length != item.length);
        case 2:
          return this.string.equals(item.string);
      } 
      return false;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\xpointer\Pointed.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */