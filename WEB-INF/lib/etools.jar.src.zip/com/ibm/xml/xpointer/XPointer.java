package com.ibm.xml.xpointer;

import com.ibm.xml.parser.AttDef;
import com.ibm.xml.parser.Child;
import com.ibm.xml.parser.DTD;
import com.ibm.xml.parser.LibraryException;
import com.ibm.xml.parser.Parent;
import com.ibm.xml.parser.TXDocument;
import com.ibm.xml.parser.TXElement;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.Vector;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class XPointer implements Serializable {
  static final long serialVersionUID = 5186377505549567985L;
  
  public static final String S_ALL = "all";
  
  public static final String S_END = "end";
  
  public static final int NT_NONE = 0;
  
  public static final int NT_NAME = 1;
  
  public static final int NT_ELEMENT = 2;
  
  public static final int NT_PI = 3;
  
  public static final int NT_COMMENT = 4;
  
  public static final int NT_TEXT = 5;
  
  public static final int NT_CDATA = 6;
  
  public static final int NT_ALL = 7;
  
  public static final String[] nodetypes = { null, null, "#element", "#pi", "#comment", "#text", "#cdata", "#all" };
  
  public static final String S_ELEMENT = "element";
  
  public static final String S_PI = "pi";
  
  public static final String S_COMMENT = "comment";
  
  public static final String S_TEXT = "text";
  
  public static final String S_CDATA = "cdata";
  
  public static final String S_NIMPLIED = "#IMPLIED";
  
  public static final String S_IMPLIED = "IMPLIED";
  
  public static final String[] literals = { 
      null, "root", "origin", "id", "html", "child", "descendant", "ancestor", "preceding", "psibling", 
      "following", "fsibling", "span", "attr", "string" };
  
  public static final int ST_NONE = -1;
  
  public static final int ST_ROOT = 1;
  
  public static final int ST_ORIGIN = 2;
  
  public static final int ST_ID = 3;
  
  public static final int ST_HTML = 4;
  
  public static final int ST_CHILD = 5;
  
  public static final int ST_DESCENDANT = 6;
  
  public static final int ST_ANCESTOR = 7;
  
  public static final int ST_PRECEDING = 8;
  
  public static final int ST_PSIBLING = 9;
  
  public static final int ST_FOLLOWING = 10;
  
  public static final int ST_FSIBLING = 11;
  
  public static final int ST_SPAN = 12;
  
  public static final int ST_ATTR = 13;
  
  public static final int ST_STRING = 14;
  
  public static final int T_IMPLIED = 0;
  
  public static final int T_ANY = 1;
  
  public static final int T_NAME = 2;
  
  public static final int T_EXACT = 3;
  
  AbsTerm absTerm;
  
  Vector otherTerms;
  
  String string;
  
  private int previous = -1;
  
  public XPointer(AbsTerm paramAbsTerm, Vector paramVector) {
    this.absTerm = paramAbsTerm;
    this.otherTerms = (paramVector == null) ? new Vector() : paramVector;
  }
  
  public AbsTerm getAbsTerm() { return this.absTerm; }
  
  public void setAbsTerm(AbsTerm paramAbsTerm) {
    this.absTerm = paramAbsTerm;
    this.string = null;
  }
  
  public Vector getOtherTermsVector() { return this.otherTerms; }
  
  public void appendOtherTerm(OtherTerm paramOtherTerm) {
    if (this.otherTerms == null)
      this.otherTerms = new Vector(); 
    this.otherTerms.addElement(paramOtherTerm);
    this.string = null;
  }
  
  public void insertOtherTerm(OtherTerm paramOtherTerm) {
    if (this.otherTerms == null)
      this.otherTerms = new Vector(); 
    this.otherTerms.insertElementAt(paramOtherTerm, 0);
    this.string = null;
  }
  
  public OtherTerm removeLastOtherTerm() {
    OtherTerm otherTerm = null;
    synchronized (this.otherTerms) {
      int i = this.otherTerms.size();
      if (i > 0) {
        otherTerm = (OtherTerm)this.otherTerms.elementAt(i - 1);
        this.otherTerms.removeElementAt(i - 1);
      } 
    } 
    this.string = null;
    return otherTerm;
  }
  
  public String toString() {
    if (this.string != null)
      return this.string; 
    StringBuffer stringBuffer = new StringBuffer(100);
    if (this.absTerm != null) {
      stringBuffer.append(this.absTerm.toString());
      if (this.otherTerms.size() > 0)
        stringBuffer.append("."); 
    } 
    byte b = 0;
    Enumeration enumeration = this.otherTerms.elements();
    while (enumeration.hasMoreElements()) {
      if (b)
        stringBuffer.append("."); 
      b++;
      stringBuffer.append(enumeration.nextElement().toString());
    } 
    return this.string = stringBuffer.toString();
  }
  
  public Pointed point(Document paramDocument) {
    Element element = paramDocument.getDocumentElement();
    if (this.absTerm != null && this.absTerm.getType() != 1) {
      if (this.absTerm.getType() == 2 || this.absTerm.getType() == 4)
        return new Pointed(); 
      DTD dTD = ((TXDocument)paramDocument).getDTD();
      if (dTD == null)
        return new Pointed(); 
      element = dTD.checkID(this.absTerm.getParameter());
      if (element == null)
        return new Pointed(); 
    } 
    return point(element);
  }
  
  public Pointed point(Node paramNode) {
    Pointed pointed = new Pointed();
    pointed.add(paramNode);
    this.previous = -1;
    Enumeration enumeration = this.otherTerms.elements();
    while (enumeration.hasMoreElements()) {
      Object object = enumeration.nextElement();
      Pointed pointed1 = new Pointed();
      Enumeration enumeration1 = pointed.elements();
      while (enumeration1.hasMoreElements()) {
        Pointed.Item item = (Pointed.Item)enumeration1.nextElement();
        if (item.node != null)
          point(pointed1, object, (Child)item.node); 
      } 
      pointed = pointed1;
    } 
    return pointed;
  }
  
  public static XPointer makeXPointer(Child paramChild) {
    if (paramChild.getNodeType() == 9)
      return null; 
    if (paramChild.getNodeType() == 5)
      return null; 
    Child child = paramChild;
    while (child.getNodeType() != 9) {
      child = (Child)child.getParentNode();
      if (child == null)
        return null; 
    } 
    TXDocument tXDocument = (TXDocument)child;
    if (paramChild.getParentNode() == tXDocument)
      return new XPointer(new AbsTerm(1, null), null); 
    DTD dTD = tXDocument.getDTD();
    if (dTD != null) {
      Child child1 = (paramChild.getNodeType() != 1) ? (Child)paramChild.getParentWithoutReference() : paramChild;
      do {
        TXElement tXElement1 = (TXElement)child1;
        Enumeration enumeration = tXElement1.attributeElements();
        while (enumeration.hasMoreElements()) {
          Attr attr = (Attr)enumeration.nextElement();
          AttDef attDef = dTD.getAttributeDeclaration(tXElement1.getNodeName(), attr.getName());
          if (attDef != null && attDef.getDeclaredType() == 2) {
            XPointer xPointer1 = new XPointer(new AbsTerm(3, attr.getValue()), null);
            if (tXElement1 != paramChild) {
              child = paramChild;
              RelTerm relTerm1 = null;
              do {
                xPointer1.insertOtherTerm(relTerm1 = makeRelTerm(child));
                child = (Child)child.getParentWithoutReference();
              } while (child != tXElement1);
              relTerm1.setType(5);
            } 
            return xPointer1;
          } 
        } 
        child1 = (Child)child1.getParentWithoutReference();
      } while (!(child1 instanceof TXDocument));
    } 
    TXElement tXElement = (TXElement)tXDocument.getDocumentElement();
    XPointer xPointer = new XPointer(new AbsTerm(1, null), null);
    child = paramChild;
    RelTerm relTerm = null;
    do {
      xPointer.insertOtherTerm(relTerm = makeRelTerm(child));
      child = (Child)child.getParentWithoutReference();
    } while (child != tXElement);
    relTerm.setType(5);
    return xPointer;
  }
  
  private void point(Pointed paramPointed, Object paramObject, Child paramChild) {
    if (paramObject instanceof RelTerm) {
      Child child;
      Vector vector;
      RelTerm relTerm = (RelTerm)paramObject;
      int i = relTerm.getType();
      if (i == -1) {
        if (this.previous == -1)
          return; 
        i = this.previous;
      } 
      int j = relTerm.getInstance();
      if (j == 0)
        return; 
      switch (i) {
        case 5:
          if (relTerm.isAll()) {
            for (Child child1 = (Child)paramChild.getFirstWithoutReference(); child1 != null; child1 = (Child)child1.getNextWithoutReference()) {
              if (relTerm.match(child1))
                paramPointed.add(child1); 
            } 
            break;
          } 
          if (j > 0) {
            for (Child child1 = (Child)paramChild.getFirstWithoutReference(); child1 != null; child1 = (Child)child1.getNextWithoutReference()) {
              if (relTerm.match(child1) && --j == 0) {
                paramPointed.add(child1);
                break;
              } 
            } 
            break;
          } 
          for (child = (Child)paramChild.getLastWithoutReference(); child != null; child = (Child)child.getPreviousWithoutReference()) {
            if (relTerm.match(child) && ++j == 0) {
              paramPointed.add(child);
              break;
            } 
          } 
          break;
        case 6:
          if (!(paramChild instanceof Element))
            return; 
          vector = new Vector();
          addMatchingNodes(vector, (Element)paramChild, relTerm);
          if (relTerm.isAll()) {
            for (byte b = 0; b < vector.size(); b++)
              paramPointed.add((Node)vector.elementAt(b)); 
            break;
          } 
          if (j > 0) {
            if (j <= vector.size())
              paramPointed.add((Node)vector.elementAt(j - 1)); 
            break;
          } 
          if (j + vector.size() >= 0)
            paramPointed.add((Node)vector.elementAt(j + vector.size())); 
          break;
        case 7:
          vector = new Vector();
          while (paramChild.getParentWithoutReference() instanceof Element) {
            paramChild = (Child)paramChild.getParentWithoutReference();
            if (relTerm.match(paramChild))
              vector.addElement(paramChild); 
          } 
          if (relTerm.isAll()) {
            for (byte b = 0; b < vector.size(); b++)
              paramPointed.add((Node)vector.elementAt(b)); 
            break;
          } 
          if (j > 0) {
            if (j <= vector.size())
              paramPointed.add((Node)vector.elementAt(j - 1)); 
            break;
          } 
          if (j + vector.size() >= 0)
            paramPointed.add((Node)vector.elementAt(j + vector.size())); 
          break;
        case 8:
          vector = new Vector();
          while (paramChild.getPreviousWithoutReference() != null || paramChild.getParentWithoutReference() instanceof Element) {
            if (paramChild.getPreviousWithoutReference() == null) {
              paramChild = (Child)paramChild.getParentWithoutReference();
            } else {
              paramChild = (Child)paramChild.getPreviousWithoutReference();
            } 
            if (relTerm.match(paramChild))
              vector.addElement(paramChild); 
          } 
          if (relTerm.isAll()) {
            for (byte b = 0; b < vector.size(); b++)
              paramPointed.add((Node)vector.elementAt(b)); 
            break;
          } 
          if (j > 0) {
            if (j <= vector.size())
              paramPointed.add((Node)vector.elementAt(j - 1)); 
            break;
          } 
          if (j + vector.size() >= 0)
            paramPointed.add((Node)vector.elementAt(j + vector.size())); 
          break;
        case 10:
          vector = new Vector();
          while (paramChild.getNextWithoutReference() != null || paramChild.getParentWithoutReference() instanceof Element) {
            if (paramChild.getNextWithoutReference() == null) {
              paramChild = (Child)paramChild.getParentWithoutReference();
            } else {
              paramChild = (Child)paramChild.getNextWithoutReference();
            } 
            if (relTerm.match(paramChild))
              vector.addElement(paramChild); 
          } 
          if (relTerm.isAll()) {
            for (byte b = 0; b < vector.size(); b++)
              paramPointed.add((Node)vector.elementAt(b)); 
            break;
          } 
          if (j > 0) {
            if (j <= vector.size())
              paramPointed.add((Node)vector.elementAt(j - 1)); 
            break;
          } 
          if (j + vector.size() >= 0)
            paramPointed.add((Node)vector.elementAt(j + vector.size())); 
          break;
        case 9:
          if (relTerm.isAll()) {
            while ((paramChild = (Child)paramChild.getPreviousWithoutReference()) != null) {
              if (relTerm.match(paramChild))
                paramPointed.add(paramChild); 
            } 
            break;
          } 
          if (j > 0) {
            while ((paramChild = (Child)paramChild.getPreviousWithoutReference()) != null) {
              if (relTerm.match(paramChild) && --j == 0) {
                paramPointed.add(paramChild);
                break;
              } 
            } 
            break;
          } 
          j = Math.abs(j);
          for (child = (Child)((Child)paramChild.getParentWithoutReference()).getFirstWithoutReference(); child != null; child = (Child)child.getNextWithoutReference()) {
            if (relTerm.match(child) && ++j == 0) {
              paramPointed.add(child);
              break;
            } 
          } 
          break;
        case 11:
          if (relTerm.isAll()) {
            while ((paramChild = (Child)paramChild.getNextWithoutReference()) != null) {
              if (relTerm.match(paramChild))
                paramPointed.add(paramChild); 
            } 
            break;
          } 
          if (j > 0) {
            while ((paramChild = (Child)paramChild.getNextWithoutReference()) != null) {
              if (relTerm.match(paramChild) && --j == 0) {
                paramPointed.add(paramChild);
                break;
              } 
            } 
            break;
          } 
          j = Math.abs(j);
          for (child = (Child)((Child)paramChild.getParentWithoutReference()).getLastWithoutReference(); child != null; child = (Child)child.getPreviousWithoutReference()) {
            if (relTerm.match(child) && ++j == 0) {
              paramPointed.add(child);
              break;
            } 
          } 
          break;
      } 
      this.previous = i;
      return;
    } 
    if (paramObject instanceof StringTerm) {
      this.previous = -1;
      return;
    } 
    if (paramObject instanceof SpanTerm) {
      this.previous = -1;
      return;
    } 
    if (paramObject instanceof AttrTerm) {
      this.previous = -1;
      if (paramChild instanceof Element) {
        Attr attr = ((Element)paramChild).getAttributeNode(((AttrTerm)paramObject).getName());
        if (attr != null) {
          paramPointed.add(attr.getValue());
          return;
        } 
      } 
    } else {
      throw new LibraryException("com.ibm.xml.xpointer.XPointer#point(): Internal Error: unknown OtherTerm.");
    } 
  }
  
  private static void addMatchingNodes(Vector paramVector, Element paramElement, RelTerm paramRelTerm) {
    for (Node node = ((Child)paramElement).getFirstWithoutReference(); node != null; node = ((Child)node).getNextWithoutReference()) {
      if (paramRelTerm.match(node))
        paramVector.addElement(node); 
      if (node instanceof Element)
        addMatchingNodes(paramVector, (Element)node, paramRelTerm); 
    } 
  }
  
  private static RelTerm makeRelTerm(Child paramChild) throws LibraryException, IllegalArgumentException {
    Node node;
    String str;
    Parent parent = (Parent)paramChild.getParentWithoutReference();
    short s = paramChild.getNodeType();
    byte b = 1;
    switch (s) {
      case 1:
        str = paramChild.getNodeName();
        for (node = parent.getFirstWithoutReference(); node != null; node = ((Child)node).getNextWithoutReference()) {
          if (node.getNodeType() == s && node.getNodeName().equals(str)) {
            if (node == paramChild)
              return new RelTerm(-1, b, str); 
            b++;
          } 
        } 
        throw new LibraryException("com.ibm.xml.xpointer.XPointer#makeRelTerm(): Specified child isn't a child of specified element.");
      case 4:
        for (node = parent.getFirstWithoutReference(); node != null; node = ((Child)node).getNextWithoutReference()) {
          if (node.getNodeType() == s) {
            if (node == paramChild)
              return new RelTerm(-1, b, 6); 
            b++;
          } 
        } 
        throw new LibraryException("com.ibm.xml.xpointer.XPointer#makeRelTerm(): Specified child isn't a child of specified element.");
      case 3:
        for (node = parent.getFirstWithoutReference(); node != null; node = ((Child)node).getNextWithoutReference()) {
          if (node.getNodeType() == s) {
            if (node == paramChild)
              return new RelTerm(-1, b, 5); 
            b++;
          } 
        } 
        throw new LibraryException("com.ibm.xml.xpointer.XPointer#makeRelTerm(): Specified child isn't a child of specified element.");
      case 7:
      case 8:
        for (node = parent.getFirstWithoutReference(); node != null; node = ((Child)node).getNextWithoutReference()) {
          if (node.getNodeType() == s) {
            if (node == paramChild)
              return new RelTerm(-1, b, (s == 8) ? 4 : 3); 
            b++;
          } 
        } 
        throw new LibraryException("com.ibm.xml.xpointer.XPointer#makeRelTerm(): Specified child isn't a child of specified element.");
    } 
    throw new IllegalArgumentException("com.ibm.xml.xpointer.XPointer#makeRelTerm():");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\xpointer\XPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */