package com.ibm.xml.xpointer;

import com.ibm.xml.parser.TXElement;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.Vector;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class RelTerm implements OtherTerm, Serializable {
  static final long serialVersionUID = -742339128434233398L;
  
  int keywordType = -1;
  
  boolean isAll = false;
  
  int instance = -1;
  
  int nodeType = -1;
  
  String elementName;
  
  Vector attributes;
  
  public RelTerm(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, String paramString, Vector paramVector) {
    this.keywordType = paramInt1;
    this.isAll = paramBoolean;
    this.instance = paramInt2;
    this.nodeType = paramInt3;
    this.elementName = paramString;
    this.attributes = paramVector;
  }
  
  public RelTerm(int paramInt1, int paramInt2, int paramInt3) { this(paramInt1, false, paramInt2, paramInt3, null, new Vector()); }
  
  public RelTerm(int paramInt1, boolean paramBoolean, int paramInt2) { this(paramInt1, true, -1, paramInt2, null, new Vector()); }
  
  public RelTerm(int paramInt1, int paramInt2, String paramString) { this(paramInt1, false, paramInt2, 1, paramString, new Vector()); }
  
  public RelTerm(int paramInt, String paramString) { this(paramInt, true, -1, 1, paramString, new Vector()); }
  
  public RelTerm(int paramInt1, int paramInt2) { this(paramInt1, false, paramInt2, -1, null, new Vector()); }
  
  public RelTerm(int paramInt) { this(paramInt, true, -1, -1, null, new Vector()); }
  
  public int getType() { return this.keywordType; }
  
  public void setType(int paramInt) { this.keywordType = paramInt; }
  
  public String getTypeName() { return (this.keywordType == -1) ? null : XPointer.literals[this.keywordType]; }
  
  public boolean isAll() { return this.isAll; }
  
  public int getInstance() { return this.instance; }
  
  public int getNodeType() { return this.nodeType; }
  
  public String getElementName() { return this.elementName; }
  
  public Vector getAttributesVector() { return this.attributes; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer(48);
    if (this.keywordType != -1)
      stringBuffer.append(XPointer.literals[this.keywordType]); 
    stringBuffer.append("(");
    if (this.isAll) {
      stringBuffer.append("all");
    } else {
      stringBuffer.append(this.instance);
    } 
    if (this.nodeType != 0) {
      stringBuffer.append(",");
      stringBuffer.append((this.nodeType == 1) ? this.elementName : XPointer.nodetypes[this.nodeType]);
      Enumeration enumeration = this.attributes.elements();
      while (enumeration.hasMoreElements())
        stringBuffer.append(enumeration.nextElement().toString()); 
    } 
    stringBuffer.append(")");
    return stringBuffer.toString();
  }
  
  public boolean match(Node paramNode) {
    boolean bool = false;
    switch (this.nodeType) {
      case 1:
        if (paramNode instanceof Element)
          bool = ((Element)paramNode).getTagName().equals(this.elementName); 
        break;
      case 0:
      case 2:
        bool = paramNode instanceof Element;
        break;
      case 3:
        bool = paramNode instanceof org.w3c.dom.ProcessingInstruction;
        break;
      case 4:
        bool = paramNode instanceof org.w3c.dom.Comment;
        break;
      case 5:
        bool = paramNode instanceof org.w3c.dom.Text;
        break;
      case 6:
        bool = paramNode instanceof org.w3c.dom.CDATASection;
        break;
      case 7:
        bool = true;
        break;
    } 
    if (!bool)
      return bool; 
    if (this.attributes.size() == 0)
      return true; 
    if (!(paramNode instanceof Element))
      return false; 
    Element element = (Element)paramNode;
    Enumeration enumeration = this.attributes.elements();
    while (enumeration.hasMoreElements()) {
      RelTermAttribute relTermAttribute = (RelTermAttribute)enumeration.nextElement();
      String str = relTermAttribute.getName();
      if (str.equals("*")) {
        Enumeration enumeration2 = ((TXElement)element).attributeElements();
        switch (relTermAttribute.getValueType()) {
          case 0:
            if (enumeration2.hasMoreElements())
              return false; 
            continue;
          case 1:
            if (!enumeration2.hasMoreElements())
              return false; 
            continue;
          case 2:
            bool = false;
            while (enumeration2.hasMoreElements()) {
              if (((Attr)enumeration2.nextElement()).getValue().equalsIgnoreCase(relTermAttribute.getValue())) {
                bool = true;
                break;
              } 
            } 
            if (!bool)
              return false; 
            continue;
          case 3:
            bool = false;
            while (enumeration2.hasMoreElements()) {
              if (((Attr)enumeration2.nextElement()).getValue().equals(relTermAttribute.getValue())) {
                bool = true;
                break;
              } 
            } 
            if (!bool)
              return false; 
            continue;
        } 
        continue;
      } 
      Enumeration enumeration1 = ((TXElement)element).attributeElements();
      Attr attr = null;
      while (enumeration1.hasMoreElements()) {
        Attr attr1 = (Attr)enumeration1.nextElement();
        if (attr1.getName().equals(str)) {
          attr = attr1;
          break;
        } 
      } 
      switch (relTermAttribute.getValueType()) {
        case 0:
          bool = !(attr != null);
          break;
        case 1:
          bool = !(attr == null);
          break;
        case 2:
          bool = !(attr == null || !attr.getValue().equalsIgnoreCase(relTermAttribute.getValue()));
          break;
        case 3:
          bool = !(attr == null || !attr.getValue().equals(relTermAttribute.getValue()));
          break;
      } 
      if (!bool)
        return false; 
    } 
    return bool;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\xpointer\RelTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */