package com.ibm.xml.xpointer;

import java.io.Serializable;

public class SpanTerm implements OtherTerm, Serializable {
  static final long serialVersionUID = 48993678655481497L;
  
  XPointer xbegin;
  
  XPointer xend;
  
  public SpanTerm(XPointer paramXPointer1, XPointer paramXPointer2) {
    this.xbegin = paramXPointer1;
    this.xend = paramXPointer2;
  }
  
  public XPointer getBeginning() { return this.xbegin; }
  
  public XPointer getEnd() { return this.xend; }
  
  public String toString() { return "span(" + this.xbegin + "," + this.xend + ")"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\xpointer\SpanTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */