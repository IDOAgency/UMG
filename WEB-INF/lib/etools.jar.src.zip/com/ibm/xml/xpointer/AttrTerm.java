package com.ibm.xml.xpointer;

public class AttrTerm implements OtherTerm {
  String name;
  
  public AttrTerm(String paramString) { this.name = paramString; }
  
  public String getName() { return this.name; }
  
  public String toString() { return "attr(" + this.name + ")"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\xpointer\AttrTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */