package com.ibm.xml.xpointer;

import com.ibm.xml.parser.XMLChar;
import java.util.Hashtable;
import java.util.Vector;

public class XPointerParser {
  static Hashtable s_keys = new Hashtable(14);
  
  String xpointer;
  
  int index;
  
  public XPointer parse(String paramString) throws XPointerParseException { return parse(paramString, 0); }
  
  public XPointer parse(String paramString, int paramInt) throws XPointerParseException {
    AbsTerm absTerm = null;
    Vector vector = new Vector();
    this.xpointer = paramString;
    this.index = paramInt;
    byte b = 0;
    boolean bool = false;
    while (this.index < this.xpointer.length() && !bool) {
      Integer integer;
      String str1;
      switch (b) {
        case false:
          str1 = getName();
          if (str1 == null)
            throw new XPointerParseException("Syntax error: [ROOT] Expect a name."); 
          integer = (Integer)s_keys.get(str1);
          if (integer == null) {
            String str = "Syntax error: [ROOT] Unexpected name: " + str1;
            throw new XPointerParseException(str);
          } 
          switch (integer.intValue()) {
            case 1:
            case 2:
            case 3:
            case 4:
              absTerm = parseAbsTerm(integer.intValue());
              break;
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
              vector.addElement(parseOtherTerm(integer.intValue(), str1));
              break;
            default:
              bool = true;
              throw new XPointerParseException("Internal Error: [ROOT]");
          } 
          b = 1;
          continue;
        case true:
          if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != '.') {
            bool = true;
            continue;
          } 
          if (this.index < this.xpointer.length())
            this.xpointer.charAt(this.index++); 
          if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) == '(') {
            vector.addElement(parseOtherTerm(-1, null));
            continue;
          } 
          str1 = getName();
          if (str1 == null)
            throw new XPointerParseException("Syntax error: [ROOT] Expect a name."); 
          integer = (Integer)s_keys.get(str1);
          if (integer == null) {
            String str = "Syntax error: [ROOT] Unexpected name: " + str1;
            throw new XPointerParseException(str);
          } 
          switch (integer.intValue()) {
            case 1:
            case 2:
            case 3:
            case 4:
              bool = true;
              str2 = "Syntax error: [ROOT] Unexpected name: " + str1;
              throw new XPointerParseException(str2);
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
              vector.addElement(parseOtherTerm(integer.intValue(), str1));
              continue;
          } 
          bool = true;
          throw new XPointerParseException("Internal Error: [ROOT]");
      } 
      bool = true;
      String str2 = "Internal Error: [ROOT] Invalid state: " + b;
      throw new XPointerParseException(str2);
    } 
    this.xpointer = this.xpointer.substring(paramInt, this.index);
    return new XPointer(absTerm, vector);
  }
  
  public String toString() { return this.xpointer; }
  
  public static void main(String[] paramArrayOfString) {
    if (paramArrayOfString.length != 1) {
      System.err.println("Require 1 argument.");
      System.exit(1);
    } 
    try {
      XPointer xPointer = (new XPointerParser()).parse(paramArrayOfString[0]);
      System.out.println("PARSED and RESTRUCTED: " + xPointer.toString());
      return;
    } catch (XPointerParseException xPointerParseException) {
      xPointerParseException.printStackTrace();
      return;
    } 
  }
  
  AbsTerm parseAbsTerm(int paramInt) throws XPointerParseException {
    String str = null;
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != '(') {
      String str1 = "Syntax error: expect `(': " + left();
      throw new XPointerParseException(str1);
    } 
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    if (paramInt == 3) {
      String str1 = getName();
      if (str1 == null) {
        String str2 = "Syntax error: expect ID name: " + left();
        throw new XPointerParseException(str2);
      } 
      str = str1;
    } else if (paramInt == 4) {
      str = getSkipLit();
    } 
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != ')')
      throw new XPointerParseException("Syntax error: expect `)'"); 
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    return new AbsTerm(paramInt, str);
  }
  
  RelTerm parseRelTerm(int paramInt) throws XPointerParseException {
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != '(') {
      String str = "Syntax error: expect `(': " + left();
      throw new XPointerParseException(str);
    } 
    boolean bool = false;
    int i = -1;
    String str1 = null;
    byte b = 0;
    Vector vector = new Vector();
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    String str2 = getName();
    if (str2 != null && "all".equals(str2)) {
      bool = true;
    } else {
      if (str2 != null) {
        String str = "Syntax error: [relterm] expect a name or number: " + str2;
        throw new XPointerParseException(str);
      } 
      i = getDigit();
    } 
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) == ',') {
      if (this.index < this.xpointer.length())
        this.xpointer.charAt(this.index++); 
      if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) == '#') {
        if (this.index < this.xpointer.length())
          this.xpointer.charAt(this.index++); 
        str2 = getName();
        if (str2 != null)
          if (str2.equals("element")) {
            b = 2;
          } else if (str2.equals("pi")) {
            b = 3;
          } else if (str2.equals("comment")) {
            b = 4;
          } else if (str2.equals("text")) {
            b = 5;
          } else if (str2.equals("cdata")) {
            b = 6;
          } else if (str2.equals("all")) {
            b = 7;
          }  
      } else {
        str1 = getName();
        b = 1;
      } 
      if (b == 0) {
        String str = "Syntax error: [relterm] expect a name/#element/#pi/#comment/#text/#cdata/#all: #" + str2;
        throw new XPointerParseException(str);
      } 
      while (this.index < this.xpointer.length() && ((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != ')' && ((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) == ',')
        vector.addElement(parseAttribute()); 
    } 
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != ')') {
      String str = "Syntax error: [relterm] expect `)': " + left();
      throw new XPointerParseException(str);
    } 
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    return new RelTerm(paramInt, bool, i, b, str1, vector);
  }
  
  RelTermAttribute parseAttribute() throws XPointerParseException {
    String str1;
    byte b = -1;
    String str2 = null;
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) == '*') {
      str1 = "*";
      if (this.index < this.xpointer.length())
        this.xpointer.charAt(this.index++); 
    } else {
      str1 = getName();
      if (str1 == null) {
        String str = "Syntax error: expect `*' or Name: " + left();
        throw new XPointerParseException(str);
      } 
    } 
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != ',') {
      String str = "Syntax error: expect `,': " + left();
      throw new XPointerParseException(str);
    } 
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) == '*') {
      if (this.index < this.xpointer.length())
        this.xpointer.charAt(this.index++); 
      b = 1;
      str2 = "*";
    } else if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) == '#') {
      if (this.index < this.xpointer.length())
        this.xpointer.charAt(this.index++); 
      String str = getName();
      if (str == null || !"IMPLIED".equals(str)) {
        String str3 = "Syntax error: [relterm] expect `#IMPLIED': " + left();
        throw new XPointerParseException(str3);
      } 
      b = 0;
      str2 = "#IMPLIED";
    } else if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) == '"' || ((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) == '\'') {
      b = 3;
      str2 = getSkipLit();
    } else {
      b = 2;
      str2 = getName();
      if (str2 == null) {
        String str = "Syntax error: [relterm] expect a name: " + left();
        throw new XPointerParseException(str);
      } 
    } 
    return new RelTermAttribute(str1, b, str2);
  }
  
  StringTerm parseStringTerm() throws XPointerParseException {
    boolean bool1 = false;
    int i = -1;
    String str1 = null;
    boolean bool2 = false;
    boolean bool3 = false;
    int j = -1;
    int k = -1;
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != '(') {
      String str = "Syntax error: [string] expect `(': " + left();
      throw new XPointerParseException(str);
    } 
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    String str2 = getName();
    if (str2.equals("all")) {
      bool1 = true;
    } else {
      i = getDigit();
    } 
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != ',') {
      String str = "Syntax error: [string] expect `,':" + left();
      throw new XPointerParseException(str);
    } 
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    str1 = getSkipLit();
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) == ',') {
      if (this.index < this.xpointer.length())
        this.xpointer.charAt(this.index++); 
      bool2 = true;
      str2 = getName();
      if (str2.equals("end")) {
        bool3 = true;
      } else {
        j = getDigit();
      } 
      if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) == ',') {
        if (this.index < this.xpointer.length())
          this.xpointer.charAt(this.index++); 
        k = getNaturalNumber();
      } 
    } 
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != ')') {
      String str = "Syntax error: [string] expect `)':" + left();
      throw new XPointerParseException(str);
    } 
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    return new StringTerm(bool1, i, str1, bool2, bool3, j, k);
  }
  
  AttrTerm parseAttrTerm() throws XPointerParseException {
    String str = null;
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != '(') {
      String str1 = "Syntax error: [attr] expect `(': " + left();
      throw new XPointerParseException(str1);
    } 
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    str = getName();
    if (str == null) {
      String str1 = "Syntax error: [attr] expect a name: " + left();
      throw new XPointerParseException(str1);
    } 
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != ')') {
      String str1 = "Syntax error: [attr] expect `)': " + left();
      throw new XPointerParseException(str1);
    } 
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    return new AttrTerm(str);
  }
  
  SpanTerm parseSpanTerm() throws XPointerParseException {
    XPointer xPointer1 = null;
    XPointer xPointer2 = null;
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != '(') {
      String str = "Syntax error: [span] expect `(': " + left();
      throw new XPointerParseException(str);
    } 
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    XPointerParser xPointerParser = new XPointerParser();
    xPointer1 = xPointerParser.parse(this.xpointer, this.index);
    this.index += xPointerParser.xpointer.length();
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != ',') {
      String str = "Syntax error: [span] expect ',': " + left();
      throw new XPointerParseException(str);
    } 
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    xPointer2 = xPointerParser.parse(this.xpointer, this.index);
    this.index += xPointerParser.xpointer.length();
    if (((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1) != ')') {
      String str = "Syntax error: [span] expect ')': " + left();
      throw new XPointerParseException(str);
    } 
    if (this.index < this.xpointer.length())
      this.xpointer.charAt(this.index++); 
    return new SpanTerm(xPointer1, xPointer2);
  }
  
  static String makeSkipLit(String paramString) { return (paramString.indexOf('"') >= 0) ? ("'" + paramString + "'") : ("\"" + paramString + "\""); }
  
  String left() { return this.xpointer.substring(this.index); }
  
  private OtherTerm parseOtherTerm(int paramInt, String paramString) throws XPointerParseException {
    AttrTerm attrTerm;
    SpanTerm spanTerm;
    StringTerm stringTerm;
    RelTerm relTerm = null;
    switch (paramInt) {
      case -1:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
        relTerm = parseRelTerm(paramInt);
        break;
      case 12:
        spanTerm = parseSpanTerm();
        break;
      case 13:
        attrTerm = parseAttrTerm();
        break;
      case 14:
        stringTerm = parseStringTerm();
        break;
    } 
    return stringTerm;
  }
  
  private final boolean in() { return !(this.index >= this.xpointer.length()); }
  
  private final int next() { return (this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1; }
  
  private final int get() { return (this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index++) : -1; }
  
  private void error(String paramString) throws XPointerParseException { throw new XPointerParseException(paramString); }
  
  private String getName() {
    char c = (this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1;
    if (XMLChar.isLetter((char)c) || c == '_' || c == ':') {
      StringBuffer stringBuffer = new StringBuffer(32);
      do {
        stringBuffer.append((char)((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index++) : -1));
      } while (this.index < this.xpointer.length() && XMLChar.isNameChar((char)((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1)));
      return stringBuffer.toString();
    } 
    return null;
  }
  
  private String getSkipLit() {
    StringBuffer stringBuffer = new StringBuffer(32);
    char c = (this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1;
    if (c == '"' || c == '\'') {
      if (this.index < this.xpointer.length())
        this.xpointer.charAt(this.index++); 
      while (this.index < this.xpointer.length() && c != ((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1))
        stringBuffer.append((char)((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index++) : -1)); 
      if (this.index >= this.xpointer.length())
        throw new XPointerParseException("Unexpected end."); 
      if (this.index < this.xpointer.length())
        this.xpointer.charAt(this.index++); 
    } else {
      String str = "Syntax error: expect \" or ': " + left();
      throw new XPointerParseException(str);
    } 
    return stringBuffer.toString();
  }
  
  private int getDigit() {
    char c = (this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1;
    int i = 1;
    if (c == '-') {
      i = -1;
      if (this.index < this.xpointer.length())
        this.xpointer.charAt(this.index++); 
    } else if (c == '+') {
      i = 1;
      if (this.index < this.xpointer.length())
        this.xpointer.charAt(this.index++); 
    } 
    int j = 0;
    if (this.index < this.xpointer.length())
      if (Character.isDigit((char)(c = (this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1))) {
        if (this.index < this.xpointer.length())
          this.xpointer.charAt(this.index++); 
        for (j = Character.getNumericValue((char)c); this.index < this.xpointer.length() && Character.isDigit((char)((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1)); j = j * 10 + Character.getNumericValue((char)((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index++) : -1)));
        return j * i;
      }  
    String str = "Syntax error: expect digits: " + left();
    throw new XPointerParseException(str);
  }
  
  private int getNaturalNumber() {
    int i = 0;
    if (this.index >= this.xpointer.length() || !Character.isDigit((char)((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1))) {
      String str = "Syntax error: expect digits: " + left();
      throw new XPointerParseException(str);
    } 
    for (i = Character.getNumericValue((char)((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index++) : -1)); this.index < this.xpointer.length() && Character.isDigit((char)((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index) : -1)); i = i * 10 + Character.getNumericValue((char)((this.index < this.xpointer.length()) ? this.xpointer.charAt(this.index++) : -1)));
    return i;
  }
  
  static  {
    s_keys.put(XPointer.literals[1], new Integer(1));
    s_keys.put(XPointer.literals[2], new Integer(2));
    s_keys.put(XPointer.literals[3], new Integer(3));
    s_keys.put(XPointer.literals[4], new Integer(4));
    s_keys.put(XPointer.literals[5], new Integer(5));
    s_keys.put(XPointer.literals[6], new Integer(6));
    s_keys.put(XPointer.literals[7], new Integer(7));
    s_keys.put(XPointer.literals[8], new Integer(8));
    s_keys.put(XPointer.literals[9], new Integer(9));
    s_keys.put(XPointer.literals[10], new Integer(10));
    s_keys.put(XPointer.literals[11], new Integer(11));
    s_keys.put(XPointer.literals[12], new Integer(12));
    s_keys.put(XPointer.literals[13], new Integer(13));
    s_keys.put(XPointer.literals[14], new Integer(14));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\xpointer\XPointerParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */