package com.ibm.xml.xpointer;

import java.io.Serializable;

public class RelTermAttribute implements Serializable {
  static final long serialVersionUID = 1475177589880703773L;
  
  String attr;
  
  int valueType = -1;
  
  String value;
  
  public RelTermAttribute(String paramString1, int paramInt, String paramString2) {
    this.valueType = paramInt;
    this.attr = paramString1;
    this.value = paramString2;
  }
  
  public String getName() { return this.attr; }
  
  public int getValueType() { return this.valueType; }
  
  public String getValue() { return this.value; }
  
  public String toString() { return "," + this.attr + "," + ((this.valueType == 3) ? XPointerParser.makeSkipLit(this.value) : this.value); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\xpointer\RelTermAttribute.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */