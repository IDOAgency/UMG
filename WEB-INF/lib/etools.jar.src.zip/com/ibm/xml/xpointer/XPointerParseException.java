package com.ibm.xml.xpointer;

public class XPointerParseException extends Exception {
  static final long serialVersionUID = 4944492811721482978L;
  
  public XPointerParseException(String paramString) { super(paramString); }
  
  public XPointerParseException() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\xpointer\XPointerParseException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */