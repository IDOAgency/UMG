package com.ibm.xml.xpointer;

import java.io.Serializable;

public class StringTerm implements OtherTerm, Serializable {
  static final long serialVersionUID = -5213912898288372011L;
  
  boolean isAll = false;
  
  int instance = -1;
  
  String string;
  
  boolean isPosition = false;
  
  boolean isEnd = false;
  
  int position = -1;
  
  int length = -1;
  
  public StringTerm(boolean paramBoolean1, int paramInt1, String paramString, boolean paramBoolean2, boolean paramBoolean3, int paramInt2, int paramInt3) {
    this.isAll = paramBoolean1;
    this.instance = paramInt1;
    this.string = paramString;
    this.isPosition = paramBoolean2;
    this.isEnd = paramBoolean3;
    this.position = paramInt2;
    this.length = paramInt3;
  }
  
  public StringTerm(int paramInt1, String paramString, int paramInt2) { this(false, paramInt1, paramString, false, false, paramInt2, 0); }
  
  public StringTerm(String paramString, int paramInt) { this(true, -1, paramString, false, false, paramInt, 0); }
  
  public StringTerm(int paramInt, String paramString, boolean paramBoolean) { this(false, paramInt, paramString, false, paramBoolean, 1, 0); }
  
  public StringTerm(String paramString, boolean paramBoolean) { this(true, -1, paramString, false, paramBoolean, 1, 0); }
  
  public StringTerm(int paramInt, String paramString) { this(false, paramInt, paramString, false, false, 1, 0); }
  
  public StringTerm(String paramString) { this(true, -1, paramString, false, false, 1, 0); }
  
  public boolean isAll() { return this.isAll; }
  
  public int getInstance() { return this.instance; }
  
  public String getString() { return this.string; }
  
  public boolean hasPosition() { return this.isPosition; }
  
  public boolean isEnd() { return this.isEnd; }
  
  public int getPosition() { return this.position; }
  
  public int getLength() { return this.length; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(XPointer.literals[14]);
    stringBuffer.append("(");
    stringBuffer.append(this.isAll ? "all" : Integer.toString(this.instance));
    stringBuffer.append(",");
    stringBuffer.append(XPointerParser.makeSkipLit(this.string));
    if (this.isPosition) {
      stringBuffer.append(",");
      stringBuffer.append(this.isEnd ? "end" : Integer.toString(this.position));
      if (this.length >= 0) {
        stringBuffer.append(",");
        stringBuffer.append(Integer.toString(this.length));
      } 
    } 
    stringBuffer.append(")");
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\xpointer\StringTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */