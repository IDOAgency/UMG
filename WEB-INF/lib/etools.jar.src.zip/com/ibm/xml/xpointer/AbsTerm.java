package com.ibm.xml.xpointer;

import java.io.Serializable;

public class AbsTerm implements Serializable {
  static final long serialVersionUID = -668186084615794705L;
  
  int type = -1;
  
  String param;
  
  public AbsTerm(int paramInt, String paramString) {
    this.type = paramInt;
    this.param = paramString;
  }
  
  public AbsTerm(int paramInt) { this(paramInt, null); }
  
  public int getType() { return this.type; }
  
  public String getTypeName() { return XPointer.literals[this.type]; }
  
  public String getParameter() { return this.param; }
  
  public String toString() {
    String str = "";
    if (this.type == 3) {
      str = this.param;
    } else if (this.type == 4) {
      str = XPointerParser.makeSkipLit(this.param);
    } 
    return String.valueOf(XPointer.literals[this.type]) + "(" + str + ")";
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\ibm\xml\xpointer\AbsTerm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */