package com.sun.activation.viewers;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;

public class ImageViewerCanvas extends Canvas {
  private Image canvas_image;
  
  public void setImage(Image paramImage) {
    this.canvas_image = paramImage;
    invalidate();
    repaint();
  }
  
  public Dimension getPreferredSize() {
    Dimension dimension = null;
    if (this.canvas_image == null) {
      dimension = new Dimension(200, 200);
    } else {
      dimension = new Dimension(this.canvas_image.getWidth(this), 
          this.canvas_image.getHeight(this));
    } 
    return dimension;
  }
  
  public void paint(Graphics paramGraphics) {
    if (this.canvas_image != null)
      paramGraphics.drawImage(this.canvas_image, 0, 0, this); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\activation\viewers\ImageViewerCanvas.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */