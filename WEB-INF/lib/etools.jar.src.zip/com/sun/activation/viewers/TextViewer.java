/*    */ package com.sun.activation.viewers;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import java.awt.GridLayout;
/*    */ import java.awt.Panel;
/*    */ import java.awt.TextArea;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import javax.activation.CommandObject;
/*    */ import javax.activation.DataHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextViewer
/*    */   extends Panel
/*    */   implements CommandObject
/*    */ {
/*    */   private TextArea text_area;
/*    */   private File text_file;
/*    */   private String text_buffer;
/*    */   private DataHandler _dh;
/*    */   private boolean DEBUG;
/*    */   
/*    */   public TextViewer() {
/* 39 */     this.DEBUG = false;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 44 */     setLayout(new GridLayout(1, 1));
/*    */     
/* 46 */     this.text_area = new TextArea("", 24, 80, 
/* 47 */         1);
/* 48 */     this.text_area.setEditable(false);
/*    */     
/* 50 */     add(this.text_area);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCommandContext(String paramString, DataHandler paramDataHandler) throws IOException {
/* 55 */     this._dh = paramDataHandler;
/* 56 */     setInputStream(this._dh.getInputStream());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setInputStream(InputStream paramInputStream) throws IOException {
/* 66 */     int i = 0;
/*    */     
/* 68 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 69 */     byte[] arrayOfByte = new byte[1024];
/*    */     
/* 71 */     while ((i = paramInputStream.read(arrayOfByte)) > 0) {
/* 72 */       byteArrayOutputStream.write(arrayOfByte, 0, i);
/*    */     }
/* 74 */     paramInputStream.close();
/*    */ 
/*    */ 
/*    */     
/* 78 */     this.text_buffer = byteArrayOutputStream.toString();
/*    */ 
/*    */     
/* 81 */     this.text_area.setText(this.text_buffer);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addNotify() {
/* 86 */     super.addNotify();
/* 87 */     invalidate();
/*    */   }
/*    */ 
/*    */   
/* 91 */   public Dimension getPreferredSize() { return this.text_area.getMinimumSize(24, 80); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\activation\viewers\TextViewer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */