package com.sun.activation.viewers;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.TextArea;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import javax.activation.CommandObject;
import javax.activation.DataHandler;

public class TextViewer extends Panel implements CommandObject {
  private TextArea text_area;
  
  private File text_file;
  
  private String text_buffer;
  
  private DataHandler _dh;
  
  private boolean DEBUG;
  
  public TextViewer() {
    this.DEBUG = false;
    setLayout(new GridLayout(1, 1));
    this.text_area = new TextArea("", 24, 80, 
        1);
    this.text_area.setEditable(false);
    add(this.text_area);
  }
  
  public void setCommandContext(String paramString, DataHandler paramDataHandler) throws IOException {
    this._dh = paramDataHandler;
    setInputStream(this._dh.getInputStream());
  }
  
  public void setInputStream(InputStream paramInputStream) throws IOException {
    int i = 0;
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    byte[] arrayOfByte = new byte[1024];
    while ((i = paramInputStream.read(arrayOfByte)) > 0)
      byteArrayOutputStream.write(arrayOfByte, 0, i); 
    paramInputStream.close();
    this.text_buffer = byteArrayOutputStream.toString();
    this.text_area.setText(this.text_buffer);
  }
  
  public void addNotify() {
    super.addNotify();
    invalidate();
  }
  
  public Dimension getPreferredSize() { return this.text_area.getMinimumSize(24, 80); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\activation\viewers\TextViewer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */