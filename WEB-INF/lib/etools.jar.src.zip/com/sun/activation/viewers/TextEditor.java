/*     */ package com.sun.activation.viewers;
/*     */ 
/*     */ import java.awt.Button;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Panel;
/*     */ import java.awt.TextArea;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.activation.CommandObject;
/*     */ import javax.activation.DataHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextEditor
/*     */   extends Panel
/*     */   implements CommandObject, ActionListener
/*     */ {
/*     */   private TextArea text_area;
/*     */   private GridBagLayout panel_gb;
/*     */   private Panel button_panel;
/*     */   private Button save_button;
/*     */   private File text_file;
/*     */   private String text_buffer;
/*     */   private InputStream data_ins;
/*     */   private FileInputStream fis;
/*     */   private DataHandler _dh;
/*     */   private boolean DEBUG;
/*     */   
/*     */   public TextEditor() {
/*  45 */     this.DEBUG = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  50 */     this.panel_gb = new GridBagLayout();
/*  51 */     setLayout(this.panel_gb);
/*     */     
/*  53 */     this.button_panel = new Panel();
/*     */     
/*  55 */     this.button_panel.setLayout(new FlowLayout());
/*  56 */     this.save_button = new Button("SAVE");
/*  57 */     this.button_panel.add(this.save_button);
/*  58 */     addGridComponent(this, 
/*  59 */         this.button_panel, 
/*  60 */         this.panel_gb, 
/*  61 */         0, 0, 
/*  62 */         1, 1, 
/*  63 */         1, 0);
/*     */ 
/*     */     
/*  66 */     this.text_area = new TextArea("This is text", 24, 80, 
/*  67 */         1);
/*     */     
/*  69 */     this.text_area.setEditable(true);
/*     */     
/*  71 */     addGridComponent(this, 
/*  72 */         this.text_area, 
/*  73 */         this.panel_gb, 
/*  74 */         0, 1, 
/*  75 */         1, 2, 
/*  76 */         1, 1);
/*     */ 
/*     */     
/*  79 */     this.save_button.addActionListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addGridComponent(Container paramContainer, Component paramComponent, GridBagLayout paramGridBagLayout, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  96 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*  97 */     gridBagConstraints.gridx = paramInt1;
/*  98 */     gridBagConstraints.gridy = paramInt2;
/*  99 */     gridBagConstraints.gridwidth = paramInt3;
/* 100 */     gridBagConstraints.gridheight = paramInt4;
/* 101 */     gridBagConstraints.fill = 1;
/* 102 */     gridBagConstraints.weighty = paramInt6;
/* 103 */     gridBagConstraints.weightx = paramInt5;
/* 104 */     gridBagConstraints.anchor = 10;
/* 105 */     paramGridBagLayout.setConstraints(paramComponent, gridBagConstraints);
/* 106 */     paramContainer.add(paramComponent);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCommandContext(String paramString, DataHandler paramDataHandler) throws IOException {
/* 111 */     this._dh = paramDataHandler;
/* 112 */     setInputStream(this._dh.getInputStream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInputStream(InputStream paramInputStream) throws IOException {
/* 123 */     byte[] arrayOfByte = new byte[1024];
/* 124 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 125 */     int i = 0;
/*     */ 
/*     */     
/* 128 */     while ((i = paramInputStream.read(arrayOfByte)) > 0)
/* 129 */       byteArrayOutputStream.write(arrayOfByte, 0, i); 
/* 130 */     paramInputStream.close();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     this.text_buffer = byteArrayOutputStream.toString();
/*     */ 
/*     */     
/* 138 */     this.text_area.setText(this.text_buffer);
/*     */   }
/*     */   
/*     */   private void performSaveOperation() {
/* 142 */     OutputStream outputStream = null;
/*     */     try {
/* 144 */       outputStream = this._dh.getOutputStream();
/* 145 */     } catch (Exception exception) {}
/*     */     
/* 147 */     String str = this.text_area.getText();
/*     */ 
/*     */     
/* 150 */     if (outputStream == null) {
/* 151 */       System.out.println("Invalid outputstream in TextEditor!");
/* 152 */       System.out.println("not saving!");
/*     */     } 
/*     */     
/*     */     try {
/* 156 */       outputStream.write(str.getBytes());
/* 157 */       outputStream.flush();
/* 158 */       outputStream.close(); return;
/* 159 */     } catch (IOException iOException) {
/*     */       
/* 161 */       System.out.println("TextEditor Save Operation failed with: " + iOException);
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addNotify() {
/* 167 */     super.addNotify();
/* 168 */     invalidate();
/*     */   }
/*     */ 
/*     */   
/* 172 */   public Dimension getPreferredSize() { return this.text_area.getMinimumSize(24, 80); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent paramActionEvent) {
/* 177 */     if (paramActionEvent.getSource() == this.save_button)
/*     */     {
/*     */       
/* 180 */       performSaveOperation();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\activation\viewers\TextEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */