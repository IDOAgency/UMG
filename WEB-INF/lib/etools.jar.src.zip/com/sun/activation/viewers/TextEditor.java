package com.sun.activation.viewers;

import java.awt.Button;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.activation.CommandObject;
import javax.activation.DataHandler;

public class TextEditor extends Panel implements CommandObject, ActionListener {
  private TextArea text_area;
  
  private GridBagLayout panel_gb;
  
  private Panel button_panel;
  
  private Button save_button;
  
  private File text_file;
  
  private String text_buffer;
  
  private InputStream data_ins;
  
  private FileInputStream fis;
  
  private DataHandler _dh;
  
  private boolean DEBUG;
  
  public TextEditor() {
    this.DEBUG = false;
    this.panel_gb = new GridBagLayout();
    setLayout(this.panel_gb);
    this.button_panel = new Panel();
    this.button_panel.setLayout(new FlowLayout());
    this.save_button = new Button("SAVE");
    this.button_panel.add(this.save_button);
    addGridComponent(this, 
        this.button_panel, 
        this.panel_gb, 
        0, 0, 
        1, 1, 
        1, 0);
    this.text_area = new TextArea("This is text", 24, 80, 
        1);
    this.text_area.setEditable(true);
    addGridComponent(this, 
        this.text_area, 
        this.panel_gb, 
        0, 1, 
        1, 2, 
        1, 1);
    this.save_button.addActionListener(this);
  }
  
  private void addGridComponent(Container paramContainer, Component paramComponent, GridBagLayout paramGridBagLayout, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridx = paramInt1;
    gridBagConstraints.gridy = paramInt2;
    gridBagConstraints.gridwidth = paramInt3;
    gridBagConstraints.gridheight = paramInt4;
    gridBagConstraints.fill = 1;
    gridBagConstraints.weighty = paramInt6;
    gridBagConstraints.weightx = paramInt5;
    gridBagConstraints.anchor = 10;
    paramGridBagLayout.setConstraints(paramComponent, gridBagConstraints);
    paramContainer.add(paramComponent);
  }
  
  public void setCommandContext(String paramString, DataHandler paramDataHandler) throws IOException {
    this._dh = paramDataHandler;
    setInputStream(this._dh.getInputStream());
  }
  
  public void setInputStream(InputStream paramInputStream) throws IOException {
    byte[] arrayOfByte = new byte[1024];
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    int i = 0;
    while ((i = paramInputStream.read(arrayOfByte)) > 0)
      byteArrayOutputStream.write(arrayOfByte, 0, i); 
    paramInputStream.close();
    this.text_buffer = byteArrayOutputStream.toString();
    this.text_area.setText(this.text_buffer);
  }
  
  private void performSaveOperation() {
    OutputStream outputStream = null;
    try {
      outputStream = this._dh.getOutputStream();
    } catch (Exception exception) {}
    String str = this.text_area.getText();
    if (outputStream == null) {
      System.out.println("Invalid outputstream in TextEditor!");
      System.out.println("not saving!");
    } 
    try {
      outputStream.write(str.getBytes());
      outputStream.flush();
      outputStream.close();
      return;
    } catch (IOException iOException) {
      System.out.println("TextEditor Save Operation failed with: " + iOException);
      return;
    } 
  }
  
  public void addNotify() {
    super.addNotify();
    invalidate();
  }
  
  public Dimension getPreferredSize() { return this.text_area.getMinimumSize(24, 80); }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    if (paramActionEvent.getSource() == this.save_button)
      performSaveOperation(); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\activation\viewers\TextEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */