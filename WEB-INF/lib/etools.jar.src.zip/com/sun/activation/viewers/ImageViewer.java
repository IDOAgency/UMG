/*     */ package com.sun.activation.viewers;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Image;
/*     */ import java.awt.MediaTracker;
/*     */ import java.awt.Panel;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.activation.CommandObject;
/*     */ import javax.activation.DataHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageViewer
/*     */   extends Panel
/*     */   implements CommandObject
/*     */ {
/*     */   private ImageViewerCanvas canvas;
/*     */   private Image image;
/*     */   private DataHandler _dh;
/*     */   private boolean DEBUG;
/*     */   
/*     */   public ImageViewer() {
/*  39 */     this.DEBUG = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  46 */     this.canvas = new ImageViewerCanvas();
/*  47 */     add(this.canvas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCommandContext(String paramString, DataHandler paramDataHandler) throws IOException {
/*  54 */     this._dh = paramDataHandler;
/*  55 */     setInputStream(this._dh.getInputStream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setInputStream(InputStream paramInputStream) throws IOException {
/*  64 */     MediaTracker mediaTracker = new MediaTracker(this);
/*  65 */     int i = 0;
/*  66 */     byte[] arrayOfByte = new byte[1024];
/*  67 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/*  69 */     while ((i = paramInputStream.read(arrayOfByte)) > 0)
/*  70 */       byteArrayOutputStream.write(arrayOfByte, 0, i); 
/*  71 */     paramInputStream.close();
/*     */ 
/*     */     
/*  74 */     this.image = getToolkit().createImage(byteArrayOutputStream.toByteArray());
/*     */     
/*  76 */     mediaTracker.addImage(this.image, 0);
/*     */     
/*     */     try {
/*  79 */       mediaTracker.waitForID(0);
/*  80 */       mediaTracker.waitForAll();
/*  81 */       if (mediaTracker.statusID(0, true) != 8) {
/*  82 */         System.out.println("Error occured in image loading = " + 
/*  83 */             mediaTracker.getErrorsID(0));
/*     */       
/*     */       }
/*     */     
/*     */     }
/*  88 */     catch (InterruptedException interruptedException) {
/*  89 */       throw new IOException("Error reading image data");
/*     */     } 
/*     */     
/*  92 */     this.canvas.setImage(this.image);
/*  93 */     if (this.DEBUG) {
/*  94 */       System.out.println("calling invalidate");
/*     */     }
/*     */   }
/*     */   
/*     */   public void addNotify() {
/*  99 */     super.addNotify();
/* 100 */     invalidate();
/* 101 */     validate();
/* 102 */     doLayout();
/*     */   }
/*     */ 
/*     */   
/* 106 */   public Dimension getPreferredSize() { return this.canvas.getPreferredSize(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\activation\viewers\ImageViewer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */