package com.sun.activation.viewers;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Panel;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.activation.CommandObject;
import javax.activation.DataHandler;

public class ImageViewer extends Panel implements CommandObject {
  private ImageViewerCanvas canvas;
  
  private Image image;
  
  private DataHandler _dh;
  
  private boolean DEBUG;
  
  public ImageViewer() {
    this.DEBUG = false;
    this.canvas = new ImageViewerCanvas();
    add(this.canvas);
  }
  
  public void setCommandContext(String paramString, DataHandler paramDataHandler) throws IOException {
    this._dh = paramDataHandler;
    setInputStream(this._dh.getInputStream());
  }
  
  private void setInputStream(InputStream paramInputStream) throws IOException {
    MediaTracker mediaTracker = new MediaTracker(this);
    int i = 0;
    byte[] arrayOfByte = new byte[1024];
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    while ((i = paramInputStream.read(arrayOfByte)) > 0)
      byteArrayOutputStream.write(arrayOfByte, 0, i); 
    paramInputStream.close();
    this.image = getToolkit().createImage(byteArrayOutputStream.toByteArray());
    mediaTracker.addImage(this.image, 0);
    try {
      mediaTracker.waitForID(0);
      mediaTracker.waitForAll();
      if (mediaTracker.statusID(0, true) != 8)
        System.out.println("Error occured in image loading = " + 
            mediaTracker.getErrorsID(0)); 
    } catch (InterruptedException interruptedException) {
      throw new IOException("Error reading image data");
    } 
    this.canvas.setImage(this.image);
    if (this.DEBUG)
      System.out.println("calling invalidate"); 
  }
  
  public void addNotify() {
    super.addNotify();
    invalidate();
    validate();
    doLayout();
  }
  
  public Dimension getPreferredSize() { return this.canvas.getPreferredSize(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\activation\viewers\ImageViewer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */