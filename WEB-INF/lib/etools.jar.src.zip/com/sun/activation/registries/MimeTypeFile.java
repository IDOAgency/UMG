/*     */ package com.sun.activation.registries;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimeTypeFile
/*     */ {
/*     */   private String fname;
/*  29 */   private Hashtable type_hash = new Hashtable();
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean DEBUG;
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeTypeFile(String paramString) throws IOException {
/*  38 */     File file = null;
/*  39 */     FileReader fileReader = null;
/*     */     
/*  41 */     this.fname = paramString;
/*     */     
/*  43 */     file = new File(this.fname);
/*     */     
/*  45 */     fileReader = new FileReader(file);
/*     */     
/*     */     try {
/*  48 */       parse(new BufferedReader(fileReader)); return;
/*     */     } finally {
/*     */       try {
/*  51 */         fileReader.close();
/*  52 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public MimeTypeFile(InputStream paramInputStream) throws IOException { parse(new BufferedReader(new InputStreamReader(paramInputStream, "iso-8859-1"))); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeTypeFile() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public MimeTypeEntry getMimeTypeEntry(String paramString) { return (MimeTypeEntry)this.type_hash.get(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMIMETypeString(String paramString) {
/*  79 */     MimeTypeEntry mimeTypeEntry = getMimeTypeEntry(paramString);
/*     */     
/*  81 */     if (mimeTypeEntry != null) {
/*  82 */       return mimeTypeEntry.getMIMEType();
/*     */     }
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendToRegistry(String paramString) throws IOException { try {
/* 104 */       parse(new BufferedReader(new StringReader(paramString))); return;
/* 105 */     } catch (IOException iOException) {
/*     */       return;
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parse(BufferedReader paramBufferedReader) throws IOException {
/* 114 */     String str1 = null, str2 = null;
/*     */     
/* 116 */     while ((str1 = paramBufferedReader.readLine()) != null) {
/* 117 */       if (str2 == null) {
/* 118 */         str2 = str1;
/*     */       } else {
/* 120 */         str2 = String.valueOf(str2) + str1;
/* 121 */       }  int i = str2.length();
/* 122 */       if (str2.length() > 0 && str2.charAt(i - 1) == '\\') {
/* 123 */         str2 = str2.substring(0, i - 1);
/*     */         continue;
/*     */       } 
/* 126 */       parseEntry(str2);
/* 127 */       str2 = null;
/*     */     } 
/* 129 */     if (str2 != null) {
/* 130 */       parseEntry(str2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseEntry(String paramString) throws IOException {
/* 137 */     String str1 = null;
/* 138 */     String str2 = null;
/* 139 */     paramString = paramString.trim();
/*     */     
/* 141 */     if (paramString.length() == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 145 */     if (paramString.charAt(0) == '#') {
/*     */       return;
/*     */     }
/*     */     
/* 149 */     if (paramString.indexOf('=') > 0) {
/*     */       
/* 151 */       LineTokenizer lineTokenizer = new LineTokenizer(paramString);
/* 152 */       while (lineTokenizer.hasMoreTokens()) {
/* 153 */         String str3 = lineTokenizer.nextToken();
/* 154 */         String str4 = null;
/* 155 */         if (lineTokenizer.hasMoreTokens() && lineTokenizer.nextToken().equals("=") && 
/* 156 */           lineTokenizer.hasMoreTokens())
/* 157 */           str4 = lineTokenizer.nextToken(); 
/* 158 */         if (str4 == null) {
/* 159 */           System.err.println("Bad .mime.types entry: " + paramString);
/*     */           return;
/*     */         } 
/* 162 */         if (str3.equals("type")) {
/* 163 */           str1 = str4; continue;
/* 164 */         }  if (str3.equals("exts")) {
/* 165 */           StringTokenizer stringTokenizer1 = new StringTokenizer(str4, ",");
/* 166 */           while (stringTokenizer1.hasMoreTokens()) {
/* 167 */             str2 = stringTokenizer1.nextToken();
/* 168 */             MimeTypeEntry mimeTypeEntry = 
/* 169 */               new MimeTypeEntry(str1, str2);
/* 170 */             this.type_hash.put(str2, mimeTypeEntry);
/* 171 */             if (DEBUG) {
/* 172 */               System.out.println("Added: " + mimeTypeEntry.toString());
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       return;
/*     */     } 
/* 179 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString);
/* 180 */     int i = stringTokenizer.countTokens();
/*     */     
/* 182 */     if (i == 0) {
/*     */       return;
/*     */     }
/* 185 */     str1 = stringTokenizer.nextToken();
/*     */     
/* 187 */     while (stringTokenizer.hasMoreTokens()) {
/* 188 */       MimeTypeEntry mimeTypeEntry = null;
/*     */       
/* 190 */       str2 = stringTokenizer.nextToken();
/* 191 */       mimeTypeEntry = new MimeTypeEntry(str1, str2);
/* 192 */       this.type_hash.put(str2, mimeTypeEntry);
/* 193 */       if (DEBUG) {
/* 194 */         System.out.println("Added: " + mimeTypeEntry.toString());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws Exception {
/* 201 */     DEBUG = true;
/* 202 */     MimeTypeFile mimeTypeFile = new MimeTypeFile(paramArrayOfString[0]);
/* 203 */     System.out.println("ext " + paramArrayOfString[1] + " type " + 
/* 204 */         mimeTypeFile.getMIMETypeString(paramArrayOfString[1]));
/* 205 */     System.exit(0);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\activation\registries\MimeTypeFile.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */