package com.sun.activation.registries;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.Hashtable;
import java.util.StringTokenizer;

public class MimeTypeFile {
  private String fname;
  
  private Hashtable type_hash = new Hashtable();
  
  private static boolean DEBUG;
  
  public MimeTypeFile(String paramString) throws IOException {
    File file = null;
    FileReader fileReader = null;
    this.fname = paramString;
    file = new File(this.fname);
    fileReader = new FileReader(file);
    try {
      parse(new BufferedReader(fileReader));
      return;
    } finally {
      try {
        fileReader.close();
      } catch (IOException iOException) {}
    } 
  }
  
  public MimeTypeFile(InputStream paramInputStream) throws IOException { parse(new BufferedReader(new InputStreamReader(paramInputStream, "iso-8859-1"))); }
  
  public MimeTypeFile() {}
  
  public MimeTypeEntry getMimeTypeEntry(String paramString) { return (MimeTypeEntry)this.type_hash.get(paramString); }
  
  public String getMIMETypeString(String paramString) {
    MimeTypeEntry mimeTypeEntry = getMimeTypeEntry(paramString);
    if (mimeTypeEntry != null)
      return mimeTypeEntry.getMIMEType(); 
    return null;
  }
  
  public void appendToRegistry(String paramString) throws IOException { try {
      parse(new BufferedReader(new StringReader(paramString)));
      return;
    } catch (IOException iOException) {
      return;
    }  }
  
  private void parse(BufferedReader paramBufferedReader) throws IOException {
    String str1 = null, str2 = null;
    while ((str1 = paramBufferedReader.readLine()) != null) {
      if (str2 == null) {
        str2 = str1;
      } else {
        str2 = String.valueOf(str2) + str1;
      } 
      int i = str2.length();
      if (str2.length() > 0 && str2.charAt(i - 1) == '\\') {
        str2 = str2.substring(0, i - 1);
        continue;
      } 
      parseEntry(str2);
      str2 = null;
    } 
    if (str2 != null)
      parseEntry(str2); 
  }
  
  private void parseEntry(String paramString) throws IOException {
    String str1 = null;
    String str2 = null;
    paramString = paramString.trim();
    if (paramString.length() == 0)
      return; 
    if (paramString.charAt(0) == '#')
      return; 
    if (paramString.indexOf('=') > 0) {
      LineTokenizer lineTokenizer = new LineTokenizer(paramString);
      while (lineTokenizer.hasMoreTokens()) {
        String str3 = lineTokenizer.nextToken();
        String str4 = null;
        if (lineTokenizer.hasMoreTokens() && lineTokenizer.nextToken().equals("=") && 
          lineTokenizer.hasMoreTokens())
          str4 = lineTokenizer.nextToken(); 
        if (str4 == null) {
          System.err.println("Bad .mime.types entry: " + paramString);
          return;
        } 
        if (str3.equals("type")) {
          str1 = str4;
          continue;
        } 
        if (str3.equals("exts")) {
          StringTokenizer stringTokenizer1 = new StringTokenizer(str4, ",");
          while (stringTokenizer1.hasMoreTokens()) {
            str2 = stringTokenizer1.nextToken();
            MimeTypeEntry mimeTypeEntry = 
              new MimeTypeEntry(str1, str2);
            this.type_hash.put(str2, mimeTypeEntry);
            if (DEBUG)
              System.out.println("Added: " + mimeTypeEntry.toString()); 
          } 
        } 
      } 
      return;
    } 
    StringTokenizer stringTokenizer = new StringTokenizer(paramString);
    int i = stringTokenizer.countTokens();
    if (i == 0)
      return; 
    str1 = stringTokenizer.nextToken();
    while (stringTokenizer.hasMoreTokens()) {
      MimeTypeEntry mimeTypeEntry = null;
      str2 = stringTokenizer.nextToken();
      mimeTypeEntry = new MimeTypeEntry(str1, str2);
      this.type_hash.put(str2, mimeTypeEntry);
      if (DEBUG)
        System.out.println("Added: " + mimeTypeEntry.toString()); 
    } 
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    DEBUG = true;
    MimeTypeFile mimeTypeFile = new MimeTypeFile(paramArrayOfString[0]);
    System.out.println("ext " + paramArrayOfString[1] + " type " + 
        mimeTypeFile.getMIMETypeString(paramArrayOfString[1]));
    System.exit(0);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\activation\registries\MimeTypeFile.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */