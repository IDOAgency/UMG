/*     */ package com.sun.activation.registries;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MailcapTokenizer
/*     */ {
/*     */   public static final int UNKNOWN_TOKEN = 0;
/*     */   public static final int START_TOKEN = 1;
/*     */   public static final int STRING_TOKEN = 2;
/*     */   public static final int EOI_TOKEN = 5;
/*     */   public static final int SLASH_TOKEN = 47;
/*     */   public static final int SEMICOLON_TOKEN = 59;
/*     */   public static final int EQUALS_TOKEN = 61;
/*     */   private String data;
/*     */   private int dataIndex;
/*     */   private int dataLength;
/*     */   private int currentToken;
/*     */   private String currentTokenValue;
/*     */   private boolean isAutoquoting;
/*     */   private char autoquoteChar;
/*     */   
/*     */   public MailcapTokenizer(String paramString) {
/*  25 */     this.data = paramString;
/*  26 */     this.dataIndex = 0;
/*  27 */     this.dataLength = paramString.length();
/*     */     
/*  29 */     this.currentToken = 1;
/*  30 */     this.currentTokenValue = "";
/*     */     
/*  32 */     this.isAutoquoting = false;
/*  33 */     this.autoquoteChar = ';';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public void setIsAutoquoting(boolean paramBoolean) { this.isAutoquoting = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public void setAutoquoteChar(char paramChar) { this.autoquoteChar = paramChar; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public int getCurrentToken() { return this.currentToken; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String nameForToken(int paramInt) {
/*  73 */     String str = "really unknown";
/*     */     
/*  75 */     switch (paramInt) {
/*     */       
/*     */       case 0:
/*  78 */         str = "unknown";
/*     */         break;
/*     */       case 1:
/*  81 */         str = "start";
/*     */         break;
/*     */       case 2:
/*  84 */         str = "string";
/*     */         break;
/*     */       case 5:
/*  87 */         str = "EOI";
/*     */         break;
/*     */       case 47:
/*  90 */         str = "'/'";
/*     */         break;
/*     */       case 59:
/*  93 */         str = "';'";
/*     */         break;
/*     */       case 61:
/*  96 */         str = "'='";
/*     */         break;
/*     */     } 
/*     */     
/* 100 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public String getCurrentTokenValue() { return this.currentTokenValue; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nextToken() {
/* 120 */     if (this.dataIndex < this.dataLength) {
/*     */ 
/*     */       
/* 123 */       while (this.dataIndex < this.dataLength && isWhiteSpaceChar(this.data.charAt(this.dataIndex)))
/*     */       {
/* 125 */         this.dataIndex++;
/*     */       }
/*     */       
/* 128 */       if (this.dataIndex < this.dataLength)
/*     */       {
/*     */         
/* 131 */         char c = this.data.charAt(this.dataIndex);
/* 132 */         if (this.isAutoquoting)
/*     */         {
/* 134 */           if (!isAutoquoteSpecialChar(c))
/*     */           {
/* 136 */             processAutoquoteToken();
/*     */           }
/* 138 */           else if (c == ';' || c == '=')
/*     */           {
/* 140 */             this.currentToken = c;
/* 141 */             this.currentTokenValue = (new Character(c)).toString();
/* 142 */             this.dataIndex++;
/*     */           }
/*     */           else
/*     */           {
/* 146 */             this.currentToken = 0;
/* 147 */             this.currentTokenValue = (new Character(c)).toString();
/* 148 */             this.dataIndex++;
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 153 */         else if (isStringTokenChar(c))
/*     */         {
/* 155 */           processStringToken();
/*     */         }
/* 157 */         else if (c == '/' || c == ';' || c == '=')
/*     */         {
/* 159 */           this.currentToken = c;
/* 160 */           this.currentTokenValue = (new Character(c)).toString();
/* 161 */           this.dataIndex++;
/*     */         }
/*     */         else
/*     */         {
/* 165 */           this.currentToken = 0;
/* 166 */           this.currentTokenValue = (new Character(c)).toString();
/* 167 */           this.dataIndex++;
/*     */         }
/*     */       
/*     */       }
/*     */       else
/*     */       {
/* 173 */         this.currentToken = 5;
/* 174 */         this.currentTokenValue = null;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 179 */       this.currentToken = 5;
/* 180 */       this.currentTokenValue = null;
/*     */     } 
/*     */     
/* 183 */     return this.currentToken;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void processStringToken() {
/* 189 */     int i = this.dataIndex;
/*     */ 
/*     */     
/* 192 */     while (this.dataIndex < this.dataLength && isStringTokenChar(this.data.charAt(this.dataIndex)))
/*     */     {
/* 194 */       this.dataIndex++;
/*     */     }
/*     */     
/* 197 */     this.currentToken = 2;
/* 198 */     this.currentTokenValue = this.data.substring(i, this.dataIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void processAutoquoteToken() {
/* 204 */     int i = this.dataIndex;
/*     */ 
/*     */     
/* 207 */     boolean bool = false;
/* 208 */     while (this.dataIndex < this.dataLength && !bool) {
/*     */       
/* 210 */       char c = this.data.charAt(this.dataIndex);
/* 211 */       if (c != this.autoquoteChar) {
/*     */         
/* 213 */         this.dataIndex++;
/*     */         
/*     */         continue;
/*     */       } 
/* 217 */       bool = true;
/*     */     } 
/*     */ 
/*     */     
/* 221 */     this.currentToken = 2;
/* 222 */     this.currentTokenValue = fixEscapeSequences(this.data.substring(i, this.dataIndex));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSpecialChar(char paramChar) {
/* 227 */     boolean bool = false;
/*     */     
/* 229 */     switch (paramChar) {
/*     */       
/*     */       case '"':
/*     */       case '(':
/*     */       case ')':
/*     */       case ',':
/*     */       case '/':
/*     */       case ':':
/*     */       case ';':
/*     */       case '<':
/*     */       case '=':
/*     */       case '>':
/*     */       case '?':
/*     */       case '@':
/*     */       case '[':
/*     */       case '\\':
/*     */       case ']':
/* 246 */         bool = true;
/*     */         break;
/*     */     } 
/*     */     
/* 250 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isAutoquoteSpecialChar(char paramChar) {
/* 255 */     boolean bool = false;
/*     */     
/* 257 */     switch (paramChar) {
/*     */       
/*     */       case ';':
/*     */       case '=':
/* 261 */         bool = true;
/*     */         break;
/*     */     } 
/*     */     
/* 265 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 270 */   public static boolean isControlChar(char paramChar) { return Character.isISOControl(paramChar); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 275 */   public static boolean isWhiteSpaceChar(char paramChar) { return Character.isWhitespace(paramChar); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 280 */   public static boolean isStringTokenChar(char paramChar) { return !(isSpecialChar(paramChar) || isControlChar(paramChar) || isWhiteSpaceChar(paramChar)); }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String fixEscapeSequences(String paramString) {
/* 285 */     int i = paramString.length();
/* 286 */     StringBuffer stringBuffer = new StringBuffer();
/* 287 */     stringBuffer.ensureCapacity(i);
/*     */     
/* 289 */     for (byte b = 0; b < i; b++) {
/*     */       
/* 291 */       char c = paramString.charAt(b);
/* 292 */       if (c != '\\') {
/*     */         
/* 294 */         stringBuffer.append(c);
/*     */ 
/*     */       
/*     */       }
/* 298 */       else if (b < i - 1) {
/*     */         
/* 300 */         char c1 = paramString.charAt(b + 1);
/* 301 */         stringBuffer.append(c1);
/*     */ 
/*     */         
/* 304 */         b++;
/*     */       }
/*     */       else {
/*     */         
/* 308 */         stringBuffer.append(c);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 313 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 326 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*     */       
/* 328 */       MailcapTokenizer mailcapTokenizer = new MailcapTokenizer(paramArrayOfString[b]);
/*     */       
/* 330 */       System.out.println("Original: |" + paramArrayOfString[b] + "|");
/*     */       
/* 332 */       int i = mailcapTokenizer.nextToken();
/* 333 */       while (i != 5) {
/*     */         
/* 335 */         switch (i) {
/*     */           
/*     */           case 0:
/* 338 */             System.out.println("  Unknown Token:           |" + mailcapTokenizer.getCurrentTokenValue() + "|");
/*     */             break;
/*     */           case 1:
/* 341 */             System.out.println("  Start Token:             |" + mailcapTokenizer.getCurrentTokenValue() + "|");
/*     */             break;
/*     */           case 2:
/* 344 */             System.out.println("  String Token:            |" + mailcapTokenizer.getCurrentTokenValue() + "|");
/*     */             break;
/*     */           case 5:
/* 347 */             System.out.println("  EOI Token:               |" + mailcapTokenizer.getCurrentTokenValue() + "|");
/*     */             break;
/*     */           case 47:
/* 350 */             System.out.println("  Slash Token:             |" + mailcapTokenizer.getCurrentTokenValue() + "|");
/*     */             break;
/*     */           case 59:
/* 353 */             System.out.println("  Semicolon Token:         |" + mailcapTokenizer.getCurrentTokenValue() + "|");
/*     */             break;
/*     */           case 61:
/* 356 */             System.out.println("  Equals Token:            |" + mailcapTokenizer.getCurrentTokenValue() + "|");
/*     */             break;
/*     */           default:
/* 359 */             System.out.println("  Really Unknown Token:    |" + mailcapTokenizer.getCurrentTokenValue() + "|");
/*     */             break;
/*     */         } 
/*     */         
/* 363 */         i = mailcapTokenizer.nextToken();
/*     */       } 
/*     */       
/* 366 */       System.out.println("");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\activation\registries\MailcapTokenizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */