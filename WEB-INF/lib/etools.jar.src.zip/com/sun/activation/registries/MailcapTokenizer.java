package com.sun.activation.registries;

public class MailcapTokenizer {
  public static final int UNKNOWN_TOKEN = 0;
  
  public static final int START_TOKEN = 1;
  
  public static final int STRING_TOKEN = 2;
  
  public static final int EOI_TOKEN = 5;
  
  public static final int SLASH_TOKEN = 47;
  
  public static final int SEMICOLON_TOKEN = 59;
  
  public static final int EQUALS_TOKEN = 61;
  
  private String data;
  
  private int dataIndex;
  
  private int dataLength;
  
  private int currentToken;
  
  private String currentTokenValue;
  
  private boolean isAutoquoting;
  
  private char autoquoteChar;
  
  public MailcapTokenizer(String paramString) {
    this.data = paramString;
    this.dataIndex = 0;
    this.dataLength = paramString.length();
    this.currentToken = 1;
    this.currentTokenValue = "";
    this.isAutoquoting = false;
    this.autoquoteChar = ';';
  }
  
  public void setIsAutoquoting(boolean paramBoolean) { this.isAutoquoting = paramBoolean; }
  
  public void setAutoquoteChar(char paramChar) { this.autoquoteChar = paramChar; }
  
  public int getCurrentToken() { return this.currentToken; }
  
  public static String nameForToken(int paramInt) {
    String str = "really unknown";
    switch (paramInt) {
      case 0:
        str = "unknown";
        break;
      case 1:
        str = "start";
        break;
      case 2:
        str = "string";
        break;
      case 5:
        str = "EOI";
        break;
      case 47:
        str = "'/'";
        break;
      case 59:
        str = "';'";
        break;
      case 61:
        str = "'='";
        break;
    } 
    return str;
  }
  
  public String getCurrentTokenValue() { return this.currentTokenValue; }
  
  public int nextToken() {
    if (this.dataIndex < this.dataLength) {
      while (this.dataIndex < this.dataLength && isWhiteSpaceChar(this.data.charAt(this.dataIndex)))
        this.dataIndex++; 
      if (this.dataIndex < this.dataLength) {
        char c = this.data.charAt(this.dataIndex);
        if (this.isAutoquoting) {
          if (!isAutoquoteSpecialChar(c)) {
            processAutoquoteToken();
          } else if (c == ';' || c == '=') {
            this.currentToken = c;
            this.currentTokenValue = (new Character(c)).toString();
            this.dataIndex++;
          } else {
            this.currentToken = 0;
            this.currentTokenValue = (new Character(c)).toString();
            this.dataIndex++;
          } 
        } else if (isStringTokenChar(c)) {
          processStringToken();
        } else if (c == '/' || c == ';' || c == '=') {
          this.currentToken = c;
          this.currentTokenValue = (new Character(c)).toString();
          this.dataIndex++;
        } else {
          this.currentToken = 0;
          this.currentTokenValue = (new Character(c)).toString();
          this.dataIndex++;
        } 
      } else {
        this.currentToken = 5;
        this.currentTokenValue = null;
      } 
    } else {
      this.currentToken = 5;
      this.currentTokenValue = null;
    } 
    return this.currentToken;
  }
  
  private void processStringToken() {
    int i = this.dataIndex;
    while (this.dataIndex < this.dataLength && isStringTokenChar(this.data.charAt(this.dataIndex)))
      this.dataIndex++; 
    this.currentToken = 2;
    this.currentTokenValue = this.data.substring(i, this.dataIndex);
  }
  
  private void processAutoquoteToken() {
    int i = this.dataIndex;
    boolean bool = false;
    while (this.dataIndex < this.dataLength && !bool) {
      char c = this.data.charAt(this.dataIndex);
      if (c != this.autoquoteChar) {
        this.dataIndex++;
        continue;
      } 
      bool = true;
    } 
    this.currentToken = 2;
    this.currentTokenValue = fixEscapeSequences(this.data.substring(i, this.dataIndex));
  }
  
  public static boolean isSpecialChar(char paramChar) {
    boolean bool = false;
    switch (paramChar) {
      case '"':
      case '(':
      case ')':
      case ',':
      case '/':
      case ':':
      case ';':
      case '<':
      case '=':
      case '>':
      case '?':
      case '@':
      case '[':
      case '\\':
      case ']':
        bool = true;
        break;
    } 
    return bool;
  }
  
  public static boolean isAutoquoteSpecialChar(char paramChar) {
    boolean bool = false;
    switch (paramChar) {
      case ';':
      case '=':
        bool = true;
        break;
    } 
    return bool;
  }
  
  public static boolean isControlChar(char paramChar) { return Character.isISOControl(paramChar); }
  
  public static boolean isWhiteSpaceChar(char paramChar) { return Character.isWhitespace(paramChar); }
  
  public static boolean isStringTokenChar(char paramChar) { return !(isSpecialChar(paramChar) || isControlChar(paramChar) || isWhiteSpaceChar(paramChar)); }
  
  private static String fixEscapeSequences(String paramString) {
    int i = paramString.length();
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.ensureCapacity(i);
    for (byte b = 0; b < i; b++) {
      char c = paramString.charAt(b);
      if (c != '\\') {
        stringBuffer.append(c);
      } else if (b < i - 1) {
        char c1 = paramString.charAt(b + 1);
        stringBuffer.append(c1);
        b++;
      } else {
        stringBuffer.append(c);
      } 
    } 
    return stringBuffer.toString();
  }
  
  public static void main(String[] paramArrayOfString) {
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      MailcapTokenizer mailcapTokenizer = new MailcapTokenizer(paramArrayOfString[b]);
      System.out.println("Original: |" + paramArrayOfString[b] + "|");
      int i = mailcapTokenizer.nextToken();
      while (i != 5) {
        switch (i) {
          case 0:
            System.out.println("  Unknown Token:           |" + mailcapTokenizer.getCurrentTokenValue() + "|");
            break;
          case 1:
            System.out.println("  Start Token:             |" + mailcapTokenizer.getCurrentTokenValue() + "|");
            break;
          case 2:
            System.out.println("  String Token:            |" + mailcapTokenizer.getCurrentTokenValue() + "|");
            break;
          case 5:
            System.out.println("  EOI Token:               |" + mailcapTokenizer.getCurrentTokenValue() + "|");
            break;
          case 47:
            System.out.println("  Slash Token:             |" + mailcapTokenizer.getCurrentTokenValue() + "|");
            break;
          case 59:
            System.out.println("  Semicolon Token:         |" + mailcapTokenizer.getCurrentTokenValue() + "|");
            break;
          case 61:
            System.out.println("  Equals Token:            |" + mailcapTokenizer.getCurrentTokenValue() + "|");
            break;
          default:
            System.out.println("  Really Unknown Token:    |" + mailcapTokenizer.getCurrentTokenValue() + "|");
            break;
        } 
        i = mailcapTokenizer.nextToken();
      } 
      System.out.println("");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\activation\registries\MailcapTokenizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */