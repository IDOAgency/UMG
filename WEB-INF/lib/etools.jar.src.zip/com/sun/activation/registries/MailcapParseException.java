package com.sun.activation.registries;

public class MailcapParseException extends Exception {
  public MailcapParseException() {}
  
  public MailcapParseException(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\activation\registries\MailcapParseException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */