/*     */ package com.sun.activation.registries;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MailcapFile
/*     */ {
/*     */   private Hashtable type_hash;
/*     */   private static boolean debug;
/*     */   
/*     */   static  {
/*     */     try {
/*  34 */       debug = Boolean.getBoolean("javax.activation.debug"); return;
/*  35 */     } catch (Throwable throwable) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapFile(String paramString) throws IOException {
/*  46 */     if (debug)
/*  47 */       System.out.println("new MailcapFile: file " + paramString); 
/*  48 */     FileReader fileReader = null;
/*  49 */     fileReader = new FileReader(paramString);
/*  50 */     this.type_hash = createMailcapHash(fileReader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapFile(InputStream paramInputStream) throws IOException {
/*  59 */     if (debug)
/*  60 */       System.out.println("new MailcapFile: InputStream"); 
/*  61 */     this.type_hash = createMailcapHash(new InputStreamReader(paramInputStream, "iso-8859-1"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapFile() {
/*  68 */     if (debug) {
/*  69 */       System.out.println("new MailcapFile: default");
/*     */     }
/*  71 */     this.type_hash = new Hashtable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public MailcapEntry getMailcapEntry(String paramString) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getMailcapList(String paramString) {
/* 100 */     Hashtable hashtable1 = null;
/* 101 */     Hashtable hashtable2 = null;
/*     */ 
/*     */     
/* 104 */     hashtable1 = (Hashtable)this.type_hash.get(paramString);
/*     */ 
/*     */     
/* 107 */     int i = paramString.indexOf('/');
/* 108 */     String str = String.valueOf(paramString.substring(0, i + 1)) + "*";
/* 109 */     hashtable2 = (Hashtable)this.type_hash.get(str);
/*     */     
/* 111 */     if (hashtable2 != null)
/* 112 */       if (hashtable1 != null) {
/* 113 */         hashtable1 = mergeResults(hashtable1, hashtable2);
/*     */       } else {
/* 115 */         hashtable1 = hashtable2;
/*     */       }  
/* 117 */     return hashtable1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Hashtable mergeResults(Hashtable paramHashtable1, Hashtable paramHashtable2) {
/* 127 */     Enumeration enumeration = paramHashtable2.keys();
/* 128 */     Hashtable hashtable = (Hashtable)paramHashtable1.clone();
/*     */ 
/*     */     
/* 131 */     while (enumeration.hasMoreElements()) {
/* 132 */       String str = (String)enumeration.nextElement();
/* 133 */       Vector vector1 = (Vector)hashtable.get(str);
/* 134 */       if (vector1 == null) {
/* 135 */         hashtable.put(str, paramHashtable2.get(str));
/*     */         continue;
/*     */       } 
/* 138 */       Vector vector2 = (Vector)paramHashtable2.get(str);
/* 139 */       Enumeration enumeration1 = vector2.elements();
/* 140 */       vector1 = (Vector)vector1.clone();
/* 141 */       hashtable.put(str, vector1);
/* 142 */       while (enumeration1.hasMoreElements()) {
/* 143 */         vector1.addElement(enumeration1.nextElement());
/*     */       }
/*     */     } 
/*     */     
/* 147 */     return hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendToMailcap(String paramString) throws IOException {
/* 161 */     if (debug)
/* 162 */       System.out.println("appendToMailcap: " + paramString); 
/*     */     try {
/* 164 */       parse(new StringReader(paramString), this.type_hash); return;
/* 165 */     } catch (IOException iOException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Hashtable createMailcapHash(Reader paramReader) throws IOException {
/* 174 */     Hashtable hashtable = new Hashtable();
/*     */     
/* 176 */     parse(paramReader, hashtable);
/*     */     
/* 178 */     return hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parse(Reader paramReader, Hashtable paramHashtable) throws IOException {
/* 185 */     BufferedReader bufferedReader = new BufferedReader(paramReader);
/* 186 */     String str1 = null;
/* 187 */     String str2 = null;
/*     */     
/* 189 */     while ((str1 = bufferedReader.readLine()) != null) {
/*     */ 
/*     */       
/* 192 */       str1 = str1.trim();
/*     */       
/*     */       try {
/* 195 */         if (str1.charAt(0) != '#')
/*     */         {
/* 197 */           if (str1.charAt(str1.length() - 1) == '\\') {
/* 198 */             if (str2 != null) {
/* 199 */               str2 = String.valueOf(str2) + str1.substring(0, str1.length() - 1); continue;
/*     */             } 
/* 201 */             str2 = str1.substring(0, str1.length() - 1); continue;
/* 202 */           }  if (str2 != null) {
/*     */             
/* 204 */             str2 = String.valueOf(str2) + str1;
/*     */             
/*     */             try {
/* 207 */               parseLine(str2, paramHashtable);
/* 208 */             } catch (MailcapParseException mailcapParseException) {}
/*     */ 
/*     */             
/* 211 */             str2 = null;
/*     */             
/*     */             continue;
/*     */           } 
/*     */           try {
/* 216 */             parseLine(str1, paramHashtable);
/*     */           }
/* 218 */           catch (MailcapParseException mailcapParseException) {}
/*     */         }
/*     */       
/*     */       }
/* 222 */       catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void parseLine(String paramString, Hashtable paramHashtable) throws MailcapParseException, IOException {
/* 234 */     MailcapTokenizer mailcapTokenizer = new MailcapTokenizer(paramString);
/* 235 */     mailcapTokenizer.setIsAutoquoting(false);
/* 236 */     String str1 = "";
/* 237 */     String str2 = "*";
/* 238 */     String str3 = "";
/*     */     
/* 240 */     if (debug) {
/* 241 */       System.out.println("parse: " + paramString);
/*     */     }
/* 243 */     int i = mailcapTokenizer.nextToken();
/* 244 */     str3 = str3.concat(mailcapTokenizer.getCurrentTokenValue());
/* 245 */     if (i != 2) {
/* 246 */       reportParseError(2, i, 
/* 247 */           mailcapTokenizer.getCurrentTokenValue());
/*     */     }
/* 249 */     str1 = mailcapTokenizer.getCurrentTokenValue().toLowerCase();
/*     */ 
/*     */ 
/*     */     
/* 253 */     i = mailcapTokenizer.nextToken();
/* 254 */     str3 = str3.concat(mailcapTokenizer.getCurrentTokenValue());
/* 255 */     if (i != 47 && 
/* 256 */       i != 59) {
/* 257 */       reportParseError(47, 
/* 258 */           59, i, 
/* 259 */           mailcapTokenizer.getCurrentTokenValue());
/*     */     }
/*     */ 
/*     */     
/* 263 */     if (i == 47) {
/*     */       
/* 265 */       i = mailcapTokenizer.nextToken();
/* 266 */       str3 = str3.concat(mailcapTokenizer.getCurrentTokenValue());
/* 267 */       if (i != 2) {
/* 268 */         reportParseError(2, 
/* 269 */             i, mailcapTokenizer.getCurrentTokenValue());
/*     */       }
/* 271 */       str2 = mailcapTokenizer.getCurrentTokenValue().toLowerCase();
/*     */ 
/*     */       
/* 274 */       i = mailcapTokenizer.nextToken();
/* 275 */       str3 = str3.concat(mailcapTokenizer.getCurrentTokenValue());
/*     */     } 
/*     */     
/* 278 */     if (debug) {
/* 279 */       System.out.println("  Type: " + str1 + "/" + str2);
/*     */     }
/* 281 */     Hashtable hashtable = 
/* 282 */       (Hashtable)paramHashtable.get(String.valueOf(str1) + "/" + str2);
/* 283 */     if (hashtable == null) {
/* 284 */       hashtable = new Hashtable();
/* 285 */       paramHashtable.put(String.valueOf(str1) + "/" + str2, hashtable);
/*     */     } 
/*     */ 
/*     */     
/* 289 */     if (i != 59) {
/* 290 */       reportParseError(59, 
/* 291 */           i, mailcapTokenizer.getCurrentTokenValue());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 296 */     mailcapTokenizer.setIsAutoquoting(true);
/* 297 */     i = mailcapTokenizer.nextToken();
/* 298 */     mailcapTokenizer.setIsAutoquoting(false);
/* 299 */     str3 = str3.concat(mailcapTokenizer.getCurrentTokenValue());
/* 300 */     if (i != 2 && 
/* 301 */       i != 59)
/*     */     {
/* 303 */       reportParseError(2, 
/* 304 */           59, i, 
/* 305 */           mailcapTokenizer.getCurrentTokenValue());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 310 */     if (i != 59) {
/* 311 */       i = mailcapTokenizer.nextToken();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 316 */     if (i == 59) {
/*     */       
/*     */       do
/*     */       {
/*     */         
/* 321 */         i = mailcapTokenizer.nextToken();
/* 322 */         if (i != 2) {
/* 323 */           reportParseError(2, 
/* 324 */               i, mailcapTokenizer.getCurrentTokenValue());
/*     */         }
/* 326 */         String str4 = 
/* 327 */           mailcapTokenizer.getCurrentTokenValue().toLowerCase();
/*     */ 
/*     */         
/* 330 */         i = mailcapTokenizer.nextToken();
/* 331 */         if (i != 61 && 
/* 332 */           i != 59 && 
/* 333 */           i != 5) {
/* 334 */           reportParseError(61, 
/* 335 */               59, 
/* 336 */               5, 
/* 337 */               i, mailcapTokenizer.getCurrentTokenValue());
/*     */         }
/*     */ 
/*     */         
/* 341 */         if (i != 61) {
/*     */           continue;
/*     */         }
/*     */         
/* 345 */         mailcapTokenizer.setIsAutoquoting(true);
/* 346 */         i = mailcapTokenizer.nextToken();
/* 347 */         mailcapTokenizer.setIsAutoquoting(false);
/* 348 */         if (i != 2) {
/* 349 */           reportParseError(2, 
/* 350 */               i, mailcapTokenizer.getCurrentTokenValue());
/*     */         }
/* 352 */         String str5 = 
/* 353 */           mailcapTokenizer.getCurrentTokenValue();
/*     */ 
/*     */         
/* 356 */         if (str4.startsWith("x-java-")) {
/* 357 */           String str = str4.substring(7);
/*     */ 
/*     */ 
/*     */           
/* 361 */           if (debug)
/* 362 */             System.out.println("    Command: " + str + 
/* 363 */                 ", Class: " + str5); 
/* 364 */           Vector vector = 
/* 365 */             (Vector)hashtable.get(str);
/* 366 */           if (vector == null) {
/* 367 */             vector = new Vector();
/* 368 */             hashtable.put(str, vector);
/*     */           } 
/*     */           
/* 371 */           vector.insertElementAt(str5, 0);
/*     */         } 
/*     */ 
/*     */         
/* 375 */         i = mailcapTokenizer.nextToken();
/*     */       }
/* 377 */       while (i == 59); return;
/* 378 */     }  if (i != 5) {
/* 379 */       reportParseError(5, 
/* 380 */           59, 
/* 381 */           i, mailcapTokenizer.getCurrentTokenValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected static void reportParseError(int paramInt1, int paramInt2, String paramString) throws MailcapParseException {
/* 387 */     throw new MailcapParseException("Encountered a " + 
/* 388 */         MailcapTokenizer.nameForToken(paramInt2) + " token (" + 
/* 389 */         paramString + ") while expecting a " + 
/* 390 */         MailcapTokenizer.nameForToken(paramInt1) + " token.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void reportParseError(int paramInt1, int paramInt2, int paramInt3, String paramString) throws MailcapParseException {
/* 396 */     throw new MailcapParseException("Encountered a " + 
/* 397 */         MailcapTokenizer.nameForToken(paramInt3) + " token (" + 
/* 398 */         paramString + ") while expecting a " + 
/* 399 */         MailcapTokenizer.nameForToken(paramInt1) + " or a " + 
/* 400 */         MailcapTokenizer.nameForToken(paramInt2) + " token.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void reportParseError(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString) throws MailcapParseException {
/* 406 */     if (debug)
/* 407 */       System.out.println("PARSE ERROR: Encountered a " + 
/* 408 */           MailcapTokenizer.nameForToken(paramInt4) + " token (" + 
/* 409 */           paramString + ") while expecting a " + 
/* 410 */           MailcapTokenizer.nameForToken(paramInt1) + ", a " + 
/* 411 */           MailcapTokenizer.nameForToken(paramInt2) + ", or a " + 
/* 412 */           MailcapTokenizer.nameForToken(paramInt3) + " token."); 
/* 413 */     throw new MailcapParseException("Encountered a " + 
/* 414 */         MailcapTokenizer.nameForToken(paramInt4) + " token (" + 
/* 415 */         paramString + ") while expecting a " + 
/* 416 */         MailcapTokenizer.nameForToken(paramInt1) + ", a " + 
/* 417 */         MailcapTokenizer.nameForToken(paramInt2) + ", or a " + 
/* 418 */         MailcapTokenizer.nameForToken(paramInt3) + " token.");
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\activation\registries\MailcapFile.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */