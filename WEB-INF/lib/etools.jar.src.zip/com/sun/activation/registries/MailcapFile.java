package com.sun.activation.registries;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class MailcapFile {
  private Hashtable type_hash;
  
  private static boolean debug;
  
  static  {
    try {
      debug = Boolean.getBoolean("javax.activation.debug");
      return;
    } catch (Throwable throwable) {
      return;
    } 
  }
  
  public MailcapFile(String paramString) throws IOException {
    if (debug)
      System.out.println("new MailcapFile: file " + paramString); 
    FileReader fileReader = null;
    fileReader = new FileReader(paramString);
    this.type_hash = createMailcapHash(fileReader);
  }
  
  public MailcapFile(InputStream paramInputStream) throws IOException {
    if (debug)
      System.out.println("new MailcapFile: InputStream"); 
    this.type_hash = createMailcapHash(new InputStreamReader(paramInputStream, "iso-8859-1"));
  }
  
  public MailcapFile() {
    if (debug)
      System.out.println("new MailcapFile: default"); 
    this.type_hash = new Hashtable();
  }
  
  public MailcapEntry getMailcapEntry(String paramString) { return null; }
  
  public Hashtable getMailcapList(String paramString) {
    Hashtable hashtable1 = null;
    Hashtable hashtable2 = null;
    hashtable1 = (Hashtable)this.type_hash.get(paramString);
    int i = paramString.indexOf('/');
    String str = String.valueOf(paramString.substring(0, i + 1)) + "*";
    hashtable2 = (Hashtable)this.type_hash.get(str);
    if (hashtable2 != null)
      if (hashtable1 != null) {
        hashtable1 = mergeResults(hashtable1, hashtable2);
      } else {
        hashtable1 = hashtable2;
      }  
    return hashtable1;
  }
  
  private Hashtable mergeResults(Hashtable paramHashtable1, Hashtable paramHashtable2) {
    Enumeration enumeration = paramHashtable2.keys();
    Hashtable hashtable = (Hashtable)paramHashtable1.clone();
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      Vector vector1 = (Vector)hashtable.get(str);
      if (vector1 == null) {
        hashtable.put(str, paramHashtable2.get(str));
        continue;
      } 
      Vector vector2 = (Vector)paramHashtable2.get(str);
      Enumeration enumeration1 = vector2.elements();
      vector1 = (Vector)vector1.clone();
      hashtable.put(str, vector1);
      while (enumeration1.hasMoreElements())
        vector1.addElement(enumeration1.nextElement()); 
    } 
    return hashtable;
  }
  
  public void appendToMailcap(String paramString) throws IOException {
    if (debug)
      System.out.println("appendToMailcap: " + paramString); 
    try {
      parse(new StringReader(paramString), this.type_hash);
      return;
    } catch (IOException iOException) {
      return;
    } 
  }
  
  private Hashtable createMailcapHash(Reader paramReader) throws IOException {
    Hashtable hashtable = new Hashtable();
    parse(paramReader, hashtable);
    return hashtable;
  }
  
  private void parse(Reader paramReader, Hashtable paramHashtable) throws IOException {
    BufferedReader bufferedReader = new BufferedReader(paramReader);
    String str1 = null;
    String str2 = null;
    while ((str1 = bufferedReader.readLine()) != null) {
      str1 = str1.trim();
      try {
        if (str1.charAt(0) != '#') {
          if (str1.charAt(str1.length() - 1) == '\\') {
            if (str2 != null) {
              str2 = String.valueOf(str2) + str1.substring(0, str1.length() - 1);
              continue;
            } 
            str2 = str1.substring(0, str1.length() - 1);
            continue;
          } 
          if (str2 != null) {
            str2 = String.valueOf(str2) + str1;
            try {
              parseLine(str2, paramHashtable);
            } catch (MailcapParseException mailcapParseException) {}
            str2 = null;
            continue;
          } 
          try {
            parseLine(str1, paramHashtable);
          } catch (MailcapParseException mailcapParseException) {}
        } 
      } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {}
    } 
  }
  
  protected static void parseLine(String paramString, Hashtable paramHashtable) throws MailcapParseException, IOException {
    MailcapTokenizer mailcapTokenizer = new MailcapTokenizer(paramString);
    mailcapTokenizer.setIsAutoquoting(false);
    String str1 = "";
    String str2 = "*";
    String str3 = "";
    if (debug)
      System.out.println("parse: " + paramString); 
    int i = mailcapTokenizer.nextToken();
    str3 = str3.concat(mailcapTokenizer.getCurrentTokenValue());
    if (i != 2)
      reportParseError(2, i, 
          mailcapTokenizer.getCurrentTokenValue()); 
    str1 = mailcapTokenizer.getCurrentTokenValue().toLowerCase();
    i = mailcapTokenizer.nextToken();
    str3 = str3.concat(mailcapTokenizer.getCurrentTokenValue());
    if (i != 47 && 
      i != 59)
      reportParseError(47, 
          59, i, 
          mailcapTokenizer.getCurrentTokenValue()); 
    if (i == 47) {
      i = mailcapTokenizer.nextToken();
      str3 = str3.concat(mailcapTokenizer.getCurrentTokenValue());
      if (i != 2)
        reportParseError(2, 
            i, mailcapTokenizer.getCurrentTokenValue()); 
      str2 = mailcapTokenizer.getCurrentTokenValue().toLowerCase();
      i = mailcapTokenizer.nextToken();
      str3 = str3.concat(mailcapTokenizer.getCurrentTokenValue());
    } 
    if (debug)
      System.out.println("  Type: " + str1 + "/" + str2); 
    Hashtable hashtable = 
      (Hashtable)paramHashtable.get(String.valueOf(str1) + "/" + str2);
    if (hashtable == null) {
      hashtable = new Hashtable();
      paramHashtable.put(String.valueOf(str1) + "/" + str2, hashtable);
    } 
    if (i != 59)
      reportParseError(59, 
          i, mailcapTokenizer.getCurrentTokenValue()); 
    mailcapTokenizer.setIsAutoquoting(true);
    i = mailcapTokenizer.nextToken();
    mailcapTokenizer.setIsAutoquoting(false);
    str3 = str3.concat(mailcapTokenizer.getCurrentTokenValue());
    if (i != 2 && 
      i != 59)
      reportParseError(2, 
          59, i, 
          mailcapTokenizer.getCurrentTokenValue()); 
    if (i != 59)
      i = mailcapTokenizer.nextToken(); 
    if (i == 59) {
      do {
        i = mailcapTokenizer.nextToken();
        if (i != 2)
          reportParseError(2, 
              i, mailcapTokenizer.getCurrentTokenValue()); 
        String str4 = 
          mailcapTokenizer.getCurrentTokenValue().toLowerCase();
        i = mailcapTokenizer.nextToken();
        if (i != 61 && 
          i != 59 && 
          i != 5)
          reportParseError(61, 
              59, 
              5, 
              i, mailcapTokenizer.getCurrentTokenValue()); 
        if (i != 61)
          continue; 
        mailcapTokenizer.setIsAutoquoting(true);
        i = mailcapTokenizer.nextToken();
        mailcapTokenizer.setIsAutoquoting(false);
        if (i != 2)
          reportParseError(2, 
              i, mailcapTokenizer.getCurrentTokenValue()); 
        String str5 = 
          mailcapTokenizer.getCurrentTokenValue();
        if (str4.startsWith("x-java-")) {
          String str = str4.substring(7);
          if (debug)
            System.out.println("    Command: " + str + 
                ", Class: " + str5); 
          Vector vector = 
            (Vector)hashtable.get(str);
          if (vector == null) {
            vector = new Vector();
            hashtable.put(str, vector);
          } 
          vector.insertElementAt(str5, 0);
        } 
        i = mailcapTokenizer.nextToken();
      } while (i == 59);
      return;
    } 
    if (i != 5)
      reportParseError(5, 
          59, 
          i, mailcapTokenizer.getCurrentTokenValue()); 
  }
  
  protected static void reportParseError(int paramInt1, int paramInt2, String paramString) throws MailcapParseException {
    throw new MailcapParseException("Encountered a " + 
        MailcapTokenizer.nameForToken(paramInt2) + " token (" + 
        paramString + ") while expecting a " + 
        MailcapTokenizer.nameForToken(paramInt1) + " token.");
  }
  
  protected static void reportParseError(int paramInt1, int paramInt2, int paramInt3, String paramString) throws MailcapParseException {
    throw new MailcapParseException("Encountered a " + 
        MailcapTokenizer.nameForToken(paramInt3) + " token (" + 
        paramString + ") while expecting a " + 
        MailcapTokenizer.nameForToken(paramInt1) + " or a " + 
        MailcapTokenizer.nameForToken(paramInt2) + " token.");
  }
  
  protected static void reportParseError(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString) throws MailcapParseException {
    if (debug)
      System.out.println("PARSE ERROR: Encountered a " + 
          MailcapTokenizer.nameForToken(paramInt4) + " token (" + 
          paramString + ") while expecting a " + 
          MailcapTokenizer.nameForToken(paramInt1) + ", a " + 
          MailcapTokenizer.nameForToken(paramInt2) + ", or a " + 
          MailcapTokenizer.nameForToken(paramInt3) + " token."); 
    throw new MailcapParseException("Encountered a " + 
        MailcapTokenizer.nameForToken(paramInt4) + " token (" + 
        paramString + ") while expecting a " + 
        MailcapTokenizer.nameForToken(paramInt1) + ", a " + 
        MailcapTokenizer.nameForToken(paramInt2) + ", or a " + 
        MailcapTokenizer.nameForToken(paramInt3) + " token.");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\activation\registries\MailcapFile.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */