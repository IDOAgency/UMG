package com.sun.activation.registries;

public class MailcapEntry {
  private String Mailcap;
  
  private String Executable;
  
  public MailcapEntry(String paramString1, String paramString2) {
    this.Mailcap = new String(paramString1);
    this.Executable = new String(paramString2);
  }
  
  public String getMailcap() { return this.Mailcap; }
  
  public String getExecutable() { return this.Executable; }
  
  public String toString() {
    return new String("MailcapEntry: " + this.Mailcap + 
        ", " + this.Executable);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\activation\registries\MailcapEntry.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */