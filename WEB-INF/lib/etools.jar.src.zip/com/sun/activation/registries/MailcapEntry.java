/*    */ package com.sun.activation.registries;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MailcapEntry
/*    */ {
/*    */   private String Mailcap;
/*    */   private String Executable;
/*    */   
/*    */   public MailcapEntry(String paramString1, String paramString2) {
/* 32 */     this.Mailcap = new String(paramString1);
/* 33 */     this.Executable = new String(paramString2);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 38 */   public String getMailcap() { return this.Mailcap; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   public String getExecutable() { return this.Executable; }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 48 */     return new String("MailcapEntry: " + this.Mailcap + 
/* 49 */         ", " + this.Executable);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\activation\registries\MailcapEntry.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */