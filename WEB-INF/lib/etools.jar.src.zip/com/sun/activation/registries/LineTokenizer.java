/*     */ package com.sun.activation.registries;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LineTokenizer
/*     */ {
/*     */   private int currentPosition;
/*     */   private int maxPosition;
/*     */   private String str;
/*     */   private Vector stack;
/*     */   private static final String singles = "=";
/*     */   
/*     */   public LineTokenizer(String paramString) {
/* 213 */     this.stack = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     this.currentPosition = 0;
/* 224 */     this.str = paramString;
/* 225 */     this.maxPosition = paramString.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void skipWhiteSpace() {
/* 232 */     while (this.currentPosition < this.maxPosition && 
/* 233 */       Character.isWhitespace(this.str.charAt(this.currentPosition))) {
/* 234 */       this.currentPosition++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasMoreTokens() {
/* 245 */     if (this.stack.size() > 0)
/* 246 */       return true; 
/* 247 */     skipWhiteSpace();
/* 248 */     return !(this.currentPosition >= this.maxPosition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextToken() {
/* 259 */     int i = this.stack.size();
/* 260 */     if (i > 0) {
/* 261 */       String str1 = (String)this.stack.elementAt(i - 1);
/* 262 */       this.stack.removeElementAt(i - 1);
/* 263 */       return str1;
/*     */     } 
/* 265 */     skipWhiteSpace();
/*     */     
/* 267 */     if (this.currentPosition >= this.maxPosition) {
/* 268 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/* 271 */     int j = this.currentPosition;
/* 272 */     char c = this.str.charAt(j);
/* 273 */     if (c == '"') {
/* 274 */       this.currentPosition++;
/* 275 */       boolean bool = false;
/* 276 */       while (this.currentPosition < this.maxPosition) {
/* 277 */         c = this.str.charAt(this.currentPosition++);
/* 278 */         if (c == '\\') {
/* 279 */           this.currentPosition++;
/* 280 */           bool = true; continue;
/* 281 */         }  if (c == '"') {
/*     */           String str1;
/*     */           
/* 284 */           if (bool) {
/* 285 */             StringBuffer stringBuffer = new StringBuffer();
/* 286 */             for (int k = j + 1; k < this.currentPosition - 1; k++) {
/* 287 */               c = this.str.charAt(k);
/* 288 */               if (c != '\\')
/* 289 */                 stringBuffer.append(c); 
/*     */             } 
/* 291 */             str1 = stringBuffer.toString();
/*     */           } else {
/* 293 */             str1 = this.str.substring(j + 1, this.currentPosition - 1);
/* 294 */           }  return str1;
/*     */         } 
/*     */       } 
/* 297 */     } else if ("=".indexOf(c) >= 0) {
/* 298 */       this.currentPosition++;
/*     */     } else {
/* 300 */       while (this.currentPosition < this.maxPosition && 
/* 301 */         "=".indexOf(this.str.charAt(this.currentPosition)) < 0 && 
/* 302 */         !Character.isWhitespace(this.str.charAt(this.currentPosition))) {
/* 303 */         this.currentPosition++;
/*     */       }
/*     */     } 
/* 306 */     return this.str.substring(j, this.currentPosition);
/*     */   }
/*     */ 
/*     */   
/* 310 */   public void pushToken(String paramString) { this.stack.addElement(paramString); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\activation\registries\LineTokenizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */