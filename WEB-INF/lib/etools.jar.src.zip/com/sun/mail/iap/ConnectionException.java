package com.sun.mail.iap;

public class ConnectionException extends ProtocolException {
  public ConnectionException() {}
  
  public ConnectionException(String paramString) { super(paramString); }
  
  public ConnectionException(Response paramResponse) { super(paramResponse); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\ConnectionException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */