/*     */ package com.sun.mail.iap;
/*     */ 
/*     */ import com.sun.mail.util.ASCIIUtility;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResponseInputStream
/*     */   extends BufferedInputStream
/*     */ {
/*     */   private static final int increment = 256;
/*     */   private byte[] buffer;
/*     */   private int sz;
/*     */   private int idx;
/*     */   
/*  36 */   public ResponseInputStream(InputStream paramInputStream) { super(paramInputStream, 2048); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArray readResponse() throws IOException {
/*  45 */     this.buffer = new byte[128];
/*  46 */     this.idx = 0;
/*  47 */     this.sz = 128;
/*  48 */     read0();
/*  49 */     return new ByteArray(this.buffer, 0, this.idx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void read0() throws IOException {
/*  60 */     byte b = 0;
/*  61 */     boolean bool = false;
/*     */ 
/*     */     
/*  64 */     while (!bool) {
/*  65 */       if ((b = (this.pos >= this.count) ? (byte)read() : this.buf[this.pos++]) == -1)
/*  66 */         break;  switch (b) {
/*     */         case 10:
/*  68 */           if (this.idx > 0 && this.buffer[this.idx - 1] == 13)
/*  69 */             bool = true;  break;
/*     */       } 
/*  71 */       if (this.idx >= this.sz)
/*  72 */         growBuffer(256); 
/*  73 */       this.buffer[this.idx++] = b;
/*     */     } 
/*     */ 
/*     */     
/*  77 */     if (b == -1) {
/*  78 */       throw new IOException();
/*     */     }
/*     */ 
/*     */     
/*  82 */     if (this.idx >= 5 && this.buffer[this.idx - 3] == 125) {
/*     */       int i;
/*     */       
/*  85 */       for (i = this.idx - 4; i >= 0 && 
/*  86 */         this.buffer[i] != 123; i--);
/*     */ 
/*     */       
/*  89 */       if (i < 0) {
/*     */         return;
/*     */       }
/*  92 */       int j = 0;
/*     */       
/*     */       try {
/*  95 */         j = ASCIIUtility.parseInt(this.buffer, i + 1, this.idx - 3);
/*  96 */       } catch (NumberFormatException numberFormatException) {
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/* 101 */       if (j > 0) {
/* 102 */         int k = this.sz - this.idx;
/* 103 */         if (j > k)
/*     */         {
/* 105 */           growBuffer((j - k < 256) ? 
/* 106 */               256 : (j - k));
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 111 */         while (j > 0) {
/* 112 */           int m = read(this.buffer, this.idx, j);
/* 113 */           j -= m;
/* 114 */           this.idx += m;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 121 */       read0();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void growBuffer(int paramInt) {
/* 129 */     byte[] arrayOfByte = new byte[this.sz + paramInt];
/* 130 */     if (this.buffer != null)
/* 131 */       System.arraycopy(this.buffer, 0, arrayOfByte, 0, this.idx); 
/* 132 */     this.buffer = arrayOfByte;
/* 133 */     this.sz += paramInt;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\ResponseInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */