package com.sun.mail.iap;

import com.sun.mail.util.ASCIIUtility;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

public class ResponseInputStream extends BufferedInputStream {
  private static final int increment = 256;
  
  private byte[] buffer;
  
  private int sz;
  
  private int idx;
  
  public ResponseInputStream(InputStream paramInputStream) { super(paramInputStream, 2048); }
  
  public ByteArray readResponse() throws IOException {
    this.buffer = new byte[128];
    this.idx = 0;
    this.sz = 128;
    read0();
    return new ByteArray(this.buffer, 0, this.idx);
  }
  
  private void read0() throws IOException {
    byte b = 0;
    boolean bool = false;
    while (!bool) {
      if ((b = (this.pos >= this.count) ? (byte)read() : this.buf[this.pos++]) == -1)
        break; 
      switch (b) {
        case 10:
          if (this.idx > 0 && this.buffer[this.idx - 1] == 13)
            bool = true; 
          break;
      } 
      if (this.idx >= this.sz)
        growBuffer(256); 
      this.buffer[this.idx++] = b;
    } 
    if (b == -1)
      throw new IOException(); 
    if (this.idx >= 5 && this.buffer[this.idx - 3] == 125) {
      int i;
      for (i = this.idx - 4; i >= 0 && 
        this.buffer[i] != 123; i--);
      if (i < 0)
        return; 
      int j = 0;
      try {
        j = ASCIIUtility.parseInt(this.buffer, i + 1, this.idx - 3);
      } catch (NumberFormatException numberFormatException) {
        return;
      } 
      if (j > 0) {
        int k = this.sz - this.idx;
        if (j > k)
          growBuffer((j - k < 256) ? 
              256 : (j - k)); 
        while (j > 0) {
          int m = read(this.buffer, this.idx, j);
          j -= m;
          this.idx += m;
        } 
      } 
      read0();
    } 
  }
  
  private void growBuffer(int paramInt) {
    byte[] arrayOfByte = new byte[this.sz + paramInt];
    if (this.buffer != null)
      System.arraycopy(this.buffer, 0, arrayOfByte, 0, this.idx); 
    this.buffer = arrayOfByte;
    this.sz += paramInt;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\ResponseInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */