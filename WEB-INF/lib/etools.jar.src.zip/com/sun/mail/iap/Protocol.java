/*     */ package com.sun.mail.iap;
/*     */ 
/*     */ import com.sun.mail.util.SocketFetcher;
/*     */ import com.sun.mail.util.TraceInputStream;
/*     */ import com.sun.mail.util.TraceOutputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.Socket;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Protocol
/*     */ {
/*     */   protected String host;
/*     */   private Socket socket;
/*     */   private TraceInputStream traceInput;
/*     */   private ResponseInputStream input;
/*     */   private TraceOutputStream traceOutput;
/*     */   private DataOutputStream output;
/*     */   private int tagCounter;
/*     */   private Vector handlers;
/*     */   
/*     */   public Protocol(String paramString1, int paramInt, boolean paramBoolean, Properties paramProperties, String paramString2) throws IOException, ProtocolException {
/*  51 */     this.host = paramString1;
/*     */     
/*  53 */     if (paramProperties == null) {
/*  54 */       this.socket = SocketFetcher.getSocket(paramString1, paramInt, null, null, null);
/*     */     } else {
/*  56 */       this.socket = SocketFetcher.getSocket(paramString1, paramInt, 
/*  57 */           paramProperties.getProperty(String.valueOf(paramString2) + ".socketFactory.class", null), 
/*  58 */           paramProperties.getProperty(String.valueOf(paramString2) + ".socketFactory.fallback", null), 
/*  59 */           paramProperties.getProperty(String.valueOf(paramString2) + ".socketFactory.port", null));
/*     */       
/*  61 */       String str = paramProperties.getProperty(String.valueOf(paramString2) + ".timeout");
/*  62 */       if (str != null) {
/*  63 */         this.socket.setSoTimeout(Integer.parseInt(str));
/*     */       }
/*     */     } 
/*  66 */     this.traceInput = new TraceInputStream(this.socket.getInputStream(), 
/*  67 */         System.out);
/*  68 */     this.traceInput.setTrace(paramBoolean);
/*  69 */     this.input = new ResponseInputStream(this.traceInput);
/*     */     
/*  71 */     this.traceOutput = new TraceOutputStream(this.socket.getOutputStream(), 
/*  72 */         System.out);
/*  73 */     this.traceOutput.setTrace(paramBoolean);
/*  74 */     this.output = new DataOutputStream(
/*  75 */         new BufferedOutputStream(this.traceOutput));
/*     */ 
/*     */     
/*  78 */     processGreeting(readResponse());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addResponseHandler(ResponseHandler paramResponseHandler) {
/*  85 */     if (this.handlers == null)
/*  86 */       this.handlers = new Vector(); 
/*  87 */     this.handlers.addElement(paramResponseHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeResponseHandler(ResponseHandler paramResponseHandler) {
/*  94 */     if (this.handlers != null) {
/*  95 */       this.handlers.removeElement(paramResponseHandler);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyResponseHandlers(Response[] paramArrayOfResponse) {
/* 102 */     if (this.handlers == null) {
/*     */       return;
/*     */     }
/* 105 */     int i = this.handlers.size();
/* 106 */     for (byte b = 0; b < paramArrayOfResponse.length; b++) {
/* 107 */       Response response = paramArrayOfResponse[b];
/*     */ 
/*     */       
/* 110 */       if (response != null && response.isUnTagged())
/*     */       {
/*     */ 
/*     */         
/* 114 */         for (byte b1 = 0; b1 < i; b1++)
/* 115 */           ((ResponseHandler)this.handlers.elementAt(b1)).handleResponse(response);  } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void processGreeting(Response paramResponse) throws ProtocolException {
/* 120 */     if (paramResponse.isBYE()) {
/* 121 */       throw new ConnectionException(paramResponse);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   protected ResponseInputStream getInputStream() { return this.input; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   protected OutputStream getOutputStream() { return this.output; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   protected boolean supportsNonSyncLiterals() { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   public Response readResponse() throws IOException, ProtocolException { return new Response(this); }
/*     */ 
/*     */   
/* 151 */   private static final byte[] CRLF = { 13, 10 };
/*     */ 
/*     */   
/*     */   public String writeCommand(String paramString, Argument paramArgument) throws IOException, ProtocolException {
/* 155 */     String str = "A" + Integer.toString(this.tagCounter++, 10);
/*     */     
/* 157 */     this.output.writeBytes(String.valueOf(str) + " " + paramString);
/*     */     
/* 159 */     if (paramArgument != null) {
/* 160 */       this.output.write(32);
/* 161 */       paramArgument.write(this);
/*     */     } 
/*     */     
/* 164 */     this.output.write(CRLF);
/* 165 */     this.output.flush();
/* 166 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Response[] command(String paramString, Argument paramArgument) {
/* 179 */     Vector vector = new Vector();
/* 180 */     boolean bool = false;
/* 181 */     String str = null;
/* 182 */     Response response = null;
/*     */ 
/*     */     
/*     */     try {
/* 186 */       str = writeCommand(paramString, paramArgument);
/* 187 */     } catch (Exception exception) {
/*     */       
/* 189 */       vector.addElement(Response.ByeResponse);
/* 190 */       bool = true;
/*     */     } 
/*     */     
/* 193 */     while (!bool) {
/*     */       try {
/* 195 */         response = readResponse();
/* 196 */       } catch (IOException iOException) {
/*     */         
/* 198 */         response = Response.ByeResponse;
/* 199 */       } catch (ProtocolException protocolException) {
/*     */         continue;
/*     */       } 
/*     */       
/* 203 */       vector.addElement(response);
/*     */       
/* 205 */       if (response.isBYE()) {
/* 206 */         bool = true;
/*     */       }
/*     */       
/* 209 */       if (response.isTagged() && response.getTag().equals(str)) {
/* 210 */         bool = true;
/*     */       }
/*     */     } 
/* 213 */     Response[] arrayOfResponse = new Response[vector.size()];
/* 214 */     vector.copyInto(arrayOfResponse);
/* 215 */     return arrayOfResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleResult(Response paramResponse) throws ProtocolException {
/* 222 */     if (paramResponse.isOK())
/*     */       return; 
/* 224 */     if (paramResponse.isNO())
/* 225 */       throw new CommandFailedException(paramResponse); 
/* 226 */     if (paramResponse.isBAD())
/* 227 */       throw new BadCommandException(paramResponse); 
/* 228 */     if (paramResponse.isBYE()) {
/* 229 */       disconnect();
/* 230 */       throw new ConnectionException(paramResponse);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void simpleCommand(String paramString, Argument paramArgument) throws ProtocolException {
/* 241 */     Response[] arrayOfResponse = command(paramString, paramArgument);
/*     */ 
/*     */     
/* 244 */     notifyResponseHandlers(arrayOfResponse);
/*     */ 
/*     */     
/* 247 */     handleResult(arrayOfResponse[arrayOfResponse.length - 1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void disconnect() {
/* 254 */     if (this.socket != null) {
/*     */       try {
/* 256 */         this.socket.close();
/* 257 */       } catch (IOException iOException) {}
/* 258 */       this.socket = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finalize() {
/* 266 */     super.finalize();
/* 267 */     disconnect();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\Protocol.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */