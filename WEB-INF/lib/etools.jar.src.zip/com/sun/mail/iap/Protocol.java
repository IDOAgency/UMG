package com.sun.mail.iap;

import com.sun.mail.util.SocketFetcher;
import com.sun.mail.util.TraceInputStream;
import com.sun.mail.util.TraceOutputStream;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Properties;
import java.util.Vector;

public class Protocol {
  protected String host;
  
  private Socket socket;
  
  private TraceInputStream traceInput;
  
  private ResponseInputStream input;
  
  private TraceOutputStream traceOutput;
  
  private DataOutputStream output;
  
  private int tagCounter;
  
  private Vector handlers;
  
  public Protocol(String paramString1, int paramInt, boolean paramBoolean, Properties paramProperties, String paramString2) throws IOException, ProtocolException {
    this.host = paramString1;
    if (paramProperties == null) {
      this.socket = SocketFetcher.getSocket(paramString1, paramInt, null, null, null);
    } else {
      this.socket = SocketFetcher.getSocket(paramString1, paramInt, 
          paramProperties.getProperty(String.valueOf(paramString2) + ".socketFactory.class", null), 
          paramProperties.getProperty(String.valueOf(paramString2) + ".socketFactory.fallback", null), 
          paramProperties.getProperty(String.valueOf(paramString2) + ".socketFactory.port", null));
      String str = paramProperties.getProperty(String.valueOf(paramString2) + ".timeout");
      if (str != null)
        this.socket.setSoTimeout(Integer.parseInt(str)); 
    } 
    this.traceInput = new TraceInputStream(this.socket.getInputStream(), 
        System.out);
    this.traceInput.setTrace(paramBoolean);
    this.input = new ResponseInputStream(this.traceInput);
    this.traceOutput = new TraceOutputStream(this.socket.getOutputStream(), 
        System.out);
    this.traceOutput.setTrace(paramBoolean);
    this.output = new DataOutputStream(
        new BufferedOutputStream(this.traceOutput));
    processGreeting(readResponse());
  }
  
  public void addResponseHandler(ResponseHandler paramResponseHandler) {
    if (this.handlers == null)
      this.handlers = new Vector(); 
    this.handlers.addElement(paramResponseHandler);
  }
  
  public void removeResponseHandler(ResponseHandler paramResponseHandler) {
    if (this.handlers != null)
      this.handlers.removeElement(paramResponseHandler); 
  }
  
  protected void notifyResponseHandlers(Response[] paramArrayOfResponse) {
    if (this.handlers == null)
      return; 
    int i = this.handlers.size();
    for (byte b = 0; b < paramArrayOfResponse.length; b++) {
      Response response = paramArrayOfResponse[b];
      if (response != null && response.isUnTagged())
        for (byte b1 = 0; b1 < i; b1++)
          ((ResponseHandler)this.handlers.elementAt(b1)).handleResponse(response);  
    } 
  }
  
  protected void processGreeting(Response paramResponse) throws ProtocolException {
    if (paramResponse.isBYE())
      throw new ConnectionException(paramResponse); 
  }
  
  protected ResponseInputStream getInputStream() { return this.input; }
  
  protected OutputStream getOutputStream() { return this.output; }
  
  protected boolean supportsNonSyncLiterals() { return false; }
  
  public Response readResponse() throws IOException, ProtocolException { return new Response(this); }
  
  private static final byte[] CRLF = { 13, 10 };
  
  public String writeCommand(String paramString, Argument paramArgument) throws IOException, ProtocolException {
    String str = "A" + Integer.toString(this.tagCounter++, 10);
    this.output.writeBytes(String.valueOf(str) + " " + paramString);
    if (paramArgument != null) {
      this.output.write(32);
      paramArgument.write(this);
    } 
    this.output.write(CRLF);
    this.output.flush();
    return str;
  }
  
  public Response[] command(String paramString, Argument paramArgument) {
    Vector vector = new Vector();
    boolean bool = false;
    String str = null;
    Response response = null;
    try {
      str = writeCommand(paramString, paramArgument);
    } catch (Exception exception) {
      vector.addElement(Response.ByeResponse);
      bool = true;
    } 
    while (!bool) {
      try {
        response = readResponse();
      } catch (IOException iOException) {
        response = Response.ByeResponse;
      } catch (ProtocolException protocolException) {
        continue;
      } 
      vector.addElement(response);
      if (response.isBYE())
        bool = true; 
      if (response.isTagged() && response.getTag().equals(str))
        bool = true; 
    } 
    Response[] arrayOfResponse = new Response[vector.size()];
    vector.copyInto(arrayOfResponse);
    return arrayOfResponse;
  }
  
  protected void handleResult(Response paramResponse) throws ProtocolException {
    if (paramResponse.isOK())
      return; 
    if (paramResponse.isNO())
      throw new CommandFailedException(paramResponse); 
    if (paramResponse.isBAD())
      throw new BadCommandException(paramResponse); 
    if (paramResponse.isBYE()) {
      disconnect();
      throw new ConnectionException(paramResponse);
    } 
  }
  
  protected void simpleCommand(String paramString, Argument paramArgument) throws ProtocolException {
    Response[] arrayOfResponse = command(paramString, paramArgument);
    notifyResponseHandlers(arrayOfResponse);
    handleResult(arrayOfResponse[arrayOfResponse.length - 1]);
  }
  
  protected void disconnect() {
    if (this.socket != null) {
      try {
        this.socket.close();
      } catch (IOException iOException) {}
      this.socket = null;
    } 
  }
  
  protected void finalize() {
    super.finalize();
    disconnect();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\Protocol.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */