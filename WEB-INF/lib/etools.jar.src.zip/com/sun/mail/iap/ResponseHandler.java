package com.sun.mail.iap;

public interface ResponseHandler {
  void handleResponse(Response paramResponse);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\ResponseHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */