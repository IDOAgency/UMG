/*    */ package com.sun.mail.iap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandFailedException
/*    */   extends ProtocolException
/*    */ {
/*    */   public CommandFailedException() {}
/*    */   
/* 28 */   public CommandFailedException(String paramString) { super(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   public CommandFailedException(Response paramResponse) { super(paramResponse); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\CommandFailedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */