package com.sun.mail.iap;

public class CommandFailedException extends ProtocolException {
  public CommandFailedException() {}
  
  public CommandFailedException(String paramString) { super(paramString); }
  
  public CommandFailedException(Response paramResponse) { super(paramResponse); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\CommandFailedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */