/*     */ package com.sun.mail.iap;
/*     */ 
/*     */ import com.sun.mail.util.ASCIIUtility;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Response
/*     */ {
/*     */   protected int index;
/*     */   protected int size;
/*     */   protected byte[] buffer;
/*     */   protected int type;
/*     */   protected String tag;
/*     */   private static final int increment = 100;
/*     */   public static final int TAG_MASK = 3;
/*     */   public static final int CONTINUATION = 1;
/*     */   public static final int TAGGED = 2;
/*     */   public static final int UNTAGGED = 3;
/*     */   public static final int TYPE_MASK = 28;
/*     */   public static final int OK = 4;
/*     */   public static final int NO = 8;
/*     */   public static final int BAD = 10;
/*     */   public static final int BYE = 16;
/*  46 */   public static Response ByeResponse = new Response("* BYE Connection down");
/*     */   
/*     */   public Response(String paramString) {
/*  49 */     this.buffer = ASCIIUtility.getBytes(paramString);
/*  50 */     this.size = this.buffer.length;
/*  51 */     parse();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Response(Protocol paramProtocol) throws IOException, ProtocolException {
/*  61 */     ByteArray byteArray = paramProtocol.getInputStream().readResponse();
/*  62 */     this.buffer = byteArray.getBytes();
/*  63 */     this.size = byteArray.getCount() - 2;
/*     */     
/*  65 */     parse();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Response(Response paramResponse) {
/*  72 */     this.index = paramResponse.index;
/*  73 */     this.size = paramResponse.size;
/*  74 */     this.buffer = paramResponse.buffer;
/*  75 */     this.type = paramResponse.type;
/*  76 */     this.tag = paramResponse.tag;
/*     */   }
/*     */   
/*     */   private void parse() {
/*  80 */     this.index = 0;
/*     */     
/*  82 */     if (this.buffer[this.index] == 43) {
/*  83 */       this.type |= 0x1;
/*  84 */       this.index++; return;
/*     */     } 
/*  86 */     if (this.buffer[this.index] == 42) {
/*  87 */       this.type |= 0x3;
/*  88 */       this.index++;
/*     */     } else {
/*  90 */       this.type |= 0x2;
/*  91 */       this.tag = readAtom();
/*     */     } 
/*     */     
/*  94 */     int i = this.index;
/*  95 */     String str = readAtom();
/*  96 */     if (str.equalsIgnoreCase("OK")) {
/*  97 */       this.type |= 0x4; return;
/*  98 */     }  if (str.equalsIgnoreCase("NO")) {
/*  99 */       this.type |= 0x8; return;
/* 100 */     }  if (str.equalsIgnoreCase("BAD")) {
/* 101 */       this.type |= 0xA; return;
/* 102 */     }  if (str.equalsIgnoreCase("BYE")) {
/* 103 */       this.type |= 0x10; return;
/*     */     } 
/* 105 */     this.index = i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void skipSpaces() {
/* 111 */     while (this.index < this.size && this.buffer[this.index] == 32) {
/* 112 */       this.index++;
/*     */     }
/*     */   }
/*     */   
/* 116 */   public void skip(int paramInt) { this.index += paramInt; }
/*     */ 
/*     */ 
/*     */   
/* 120 */   public byte peekByte() { return this.buffer[this.index]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public byte readByte() { return this.buffer[this.index++]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readAtom() {
/* 137 */     skipSpaces();
/*     */     
/* 139 */     if (this.index >= this.size) {
/* 140 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     int i = this.index; byte b;
/* 147 */     while (this.index < this.size && (b = this.buffer[this.index]) > 32 && 
/* 148 */       b != 40 && b != 41 && b != 37 && b != 42 && 
/* 149 */       b != 34 && b != 92 && b != Byte.MAX_VALUE) {
/* 150 */       this.index++;
/*     */     }
/* 152 */     return ASCIIUtility.toString(this.buffer, i, this.index);
/*     */   }
/*     */   
/*     */   public String[] readStringList() {
/* 156 */     skipSpaces();
/*     */     
/* 158 */     if (this.buffer[this.index] != 40)
/* 159 */       return null; 
/* 160 */     this.index++;
/*     */     
/* 162 */     Vector vector = new Vector();
/*     */     do {
/* 164 */       vector.addElement(readString());
/* 165 */     } while (this.buffer[this.index++] != 41);
/*     */     
/* 167 */     int i = vector.size();
/* 168 */     if (i > 0) {
/* 169 */       String[] arrayOfString = new String[i];
/* 170 */       vector.copyInto(arrayOfString);
/* 171 */       return arrayOfString;
/*     */     } 
/* 173 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readNumber() {
/* 185 */     skipSpaces();
/*     */     
/* 187 */     int i = this.index;
/* 188 */     while (this.index < this.size && Character.isDigit((char)this.buffer[this.index])) {
/* 189 */       this.index++;
/*     */     }
/* 191 */     if (this.index > i) {
/*     */       try {
/* 193 */         return ASCIIUtility.parseInt(this.buffer, i, this.index);
/* 194 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */     
/* 197 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long readLong() {
/* 209 */     skipSpaces();
/*     */     
/* 211 */     int i = this.index;
/* 212 */     while (this.index < this.size && Character.isDigit((char)this.buffer[this.index])) {
/* 213 */       this.index++;
/*     */     }
/* 215 */     if (this.index > i) {
/*     */       try {
/* 217 */         return ASCIIUtility.parseLong(this.buffer, i, this.index);
/* 218 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */     
/* 221 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 233 */   public String readString() { return (String)parseString(false, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayInputStream readBytes() {
/* 245 */     ByteArray byteArray = readByteArray();
/* 246 */     if (byteArray != null) {
/* 247 */       return byteArray.toByteArrayInputStream();
/*     */     }
/* 249 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 261 */   public ByteArray readByteArray() { return (ByteArray)parseString(false, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 276 */   public String readAtomString() { return (String)parseString(true, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object parseString(boolean paramBoolean1, boolean paramBoolean2) {
/* 288 */     skipSpaces();
/*     */     
/* 290 */     byte b = this.buffer[this.index];
/* 291 */     if (b == 34) {
/*     */       
/* 293 */       int i = ++this.index;
/* 294 */       int j = this.index;
/*     */       
/* 296 */       while ((b = this.buffer[this.index]) != 34) {
/* 297 */         if (b == 92)
/* 298 */           this.index++; 
/* 299 */         if (this.index != j)
/*     */         {
/*     */           
/* 302 */           this.buffer[j] = this.buffer[this.index];
/*     */         }
/* 304 */         j++;
/* 305 */         this.index++;
/*     */       } 
/* 307 */       this.index++;
/*     */       
/* 309 */       if (paramBoolean2) {
/* 310 */         return ASCIIUtility.toString(this.buffer, i, j);
/*     */       }
/* 312 */       return new ByteArray(this.buffer, i, j - i);
/* 313 */     }  if (b == 123) {
/* 314 */       int i = ++this.index;
/*     */       
/* 316 */       while (this.buffer[this.index] != 125) {
/* 317 */         this.index++;
/*     */       }
/* 319 */       int j = 0;
/*     */       try {
/* 321 */         j = ASCIIUtility.parseInt(this.buffer, i, this.index);
/* 322 */       } catch (NumberFormatException numberFormatException) {
/*     */         
/* 324 */         return null;
/*     */       } 
/*     */       
/* 327 */       i = this.index + 3;
/* 328 */       this.index = i + j;
/*     */       
/* 330 */       if (paramBoolean2) {
/* 331 */         return ASCIIUtility.toString(this.buffer, i, i + j);
/*     */       }
/* 333 */       return new ByteArray(this.buffer, i, j);
/* 334 */     }  if (paramBoolean1) {
/* 335 */       int i = this.index;
/*     */       
/* 337 */       String str = readAtom();
/* 338 */       if (paramBoolean2) {
/* 339 */         return str;
/*     */       }
/* 341 */       return new ByteArray(this.buffer, i, this.index);
/* 342 */     }  if (b == 78 || b == 110) {
/* 343 */       this.index += 3;
/* 344 */       return null;
/*     */     } 
/* 346 */     return null;
/*     */   }
/*     */ 
/*     */   
/* 350 */   public int getType() { return this.type; }
/*     */ 
/*     */ 
/*     */   
/* 354 */   public boolean isContinuation() { return !((this.type & 0x3) != 1); }
/*     */ 
/*     */ 
/*     */   
/* 358 */   public boolean isTagged() { return !((this.type & 0x3) != 2); }
/*     */ 
/*     */ 
/*     */   
/* 362 */   public boolean isUnTagged() { return !((this.type & 0x3) != 3); }
/*     */ 
/*     */ 
/*     */   
/* 366 */   public boolean isOK() { return !((this.type & 0x1C) != 4); }
/*     */ 
/*     */ 
/*     */   
/* 370 */   public boolean isNO() { return !((this.type & 0x1C) != 8); }
/*     */ 
/*     */ 
/*     */   
/* 374 */   public boolean isBAD() { return !((this.type & 0x1C) != 10); }
/*     */ 
/*     */ 
/*     */   
/* 378 */   public boolean isBYE() { return !((this.type & 0x1C) != 16); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 386 */   public String getTag() { return this.tag; }
/*     */ 
/*     */ 
/*     */   
/* 390 */   public String toString() { return ASCIIUtility.toString(this.buffer, 0, this.size); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\Response.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */