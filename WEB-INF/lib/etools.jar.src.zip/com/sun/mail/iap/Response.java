package com.sun.mail.iap;

import com.sun.mail.util.ASCIIUtility;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Vector;

public class Response {
  protected int index;
  
  protected int size;
  
  protected byte[] buffer;
  
  protected int type;
  
  protected String tag;
  
  private static final int increment = 100;
  
  public static final int TAG_MASK = 3;
  
  public static final int CONTINUATION = 1;
  
  public static final int TAGGED = 2;
  
  public static final int UNTAGGED = 3;
  
  public static final int TYPE_MASK = 28;
  
  public static final int OK = 4;
  
  public static final int NO = 8;
  
  public static final int BAD = 10;
  
  public static final int BYE = 16;
  
  public static Response ByeResponse = new Response("* BYE Connection down");
  
  public Response(String paramString) {
    this.buffer = ASCIIUtility.getBytes(paramString);
    this.size = this.buffer.length;
    parse();
  }
  
  public Response(Protocol paramProtocol) throws IOException, ProtocolException {
    ByteArray byteArray = paramProtocol.getInputStream().readResponse();
    this.buffer = byteArray.getBytes();
    this.size = byteArray.getCount() - 2;
    parse();
  }
  
  public Response(Response paramResponse) {
    this.index = paramResponse.index;
    this.size = paramResponse.size;
    this.buffer = paramResponse.buffer;
    this.type = paramResponse.type;
    this.tag = paramResponse.tag;
  }
  
  private void parse() {
    this.index = 0;
    if (this.buffer[this.index] == 43) {
      this.type |= 0x1;
      this.index++;
      return;
    } 
    if (this.buffer[this.index] == 42) {
      this.type |= 0x3;
      this.index++;
    } else {
      this.type |= 0x2;
      this.tag = readAtom();
    } 
    int i = this.index;
    String str = readAtom();
    if (str.equalsIgnoreCase("OK")) {
      this.type |= 0x4;
      return;
    } 
    if (str.equalsIgnoreCase("NO")) {
      this.type |= 0x8;
      return;
    } 
    if (str.equalsIgnoreCase("BAD")) {
      this.type |= 0xA;
      return;
    } 
    if (str.equalsIgnoreCase("BYE")) {
      this.type |= 0x10;
      return;
    } 
    this.index = i;
  }
  
  public void skipSpaces() {
    while (this.index < this.size && this.buffer[this.index] == 32)
      this.index++; 
  }
  
  public void skip(int paramInt) { this.index += paramInt; }
  
  public byte peekByte() { return this.buffer[this.index]; }
  
  public byte readByte() { return this.buffer[this.index++]; }
  
  public String readAtom() {
    skipSpaces();
    if (this.index >= this.size)
      return null; 
    int i = this.index;
    byte b;
    while (this.index < this.size && (b = this.buffer[this.index]) > 32 && 
      b != 40 && b != 41 && b != 37 && b != 42 && 
      b != 34 && b != 92 && b != Byte.MAX_VALUE)
      this.index++; 
    return ASCIIUtility.toString(this.buffer, i, this.index);
  }
  
  public String[] readStringList() {
    skipSpaces();
    if (this.buffer[this.index] != 40)
      return null; 
    this.index++;
    Vector vector = new Vector();
    do {
      vector.addElement(readString());
    } while (this.buffer[this.index++] != 41);
    int i = vector.size();
    if (i > 0) {
      String[] arrayOfString = new String[i];
      vector.copyInto(arrayOfString);
      return arrayOfString;
    } 
    return null;
  }
  
  public int readNumber() {
    skipSpaces();
    int i = this.index;
    while (this.index < this.size && Character.isDigit((char)this.buffer[this.index]))
      this.index++; 
    if (this.index > i)
      try {
        return ASCIIUtility.parseInt(this.buffer, i, this.index);
      } catch (NumberFormatException numberFormatException) {} 
    return -1;
  }
  
  public long readLong() {
    skipSpaces();
    int i = this.index;
    while (this.index < this.size && Character.isDigit((char)this.buffer[this.index]))
      this.index++; 
    if (this.index > i)
      try {
        return ASCIIUtility.parseLong(this.buffer, i, this.index);
      } catch (NumberFormatException numberFormatException) {} 
    return -1L;
  }
  
  public String readString() { return (String)parseString(false, true); }
  
  public ByteArrayInputStream readBytes() {
    ByteArray byteArray = readByteArray();
    if (byteArray != null)
      return byteArray.toByteArrayInputStream(); 
    return null;
  }
  
  public ByteArray readByteArray() { return (ByteArray)parseString(false, false); }
  
  public String readAtomString() { return (String)parseString(true, true); }
  
  private Object parseString(boolean paramBoolean1, boolean paramBoolean2) {
    skipSpaces();
    byte b = this.buffer[this.index];
    if (b == 34) {
      int i = ++this.index;
      int j = this.index;
      while ((b = this.buffer[this.index]) != 34) {
        if (b == 92)
          this.index++; 
        if (this.index != j)
          this.buffer[j] = this.buffer[this.index]; 
        j++;
        this.index++;
      } 
      this.index++;
      if (paramBoolean2)
        return ASCIIUtility.toString(this.buffer, i, j); 
      return new ByteArray(this.buffer, i, j - i);
    } 
    if (b == 123) {
      int i = ++this.index;
      while (this.buffer[this.index] != 125)
        this.index++; 
      int j = 0;
      try {
        j = ASCIIUtility.parseInt(this.buffer, i, this.index);
      } catch (NumberFormatException numberFormatException) {
        return null;
      } 
      i = this.index + 3;
      this.index = i + j;
      if (paramBoolean2)
        return ASCIIUtility.toString(this.buffer, i, i + j); 
      return new ByteArray(this.buffer, i, j);
    } 
    if (paramBoolean1) {
      int i = this.index;
      String str = readAtom();
      if (paramBoolean2)
        return str; 
      return new ByteArray(this.buffer, i, this.index);
    } 
    if (b == 78 || b == 110) {
      this.index += 3;
      return null;
    } 
    return null;
  }
  
  public int getType() { return this.type; }
  
  public boolean isContinuation() { return !((this.type & 0x3) != 1); }
  
  public boolean isTagged() { return !((this.type & 0x3) != 2); }
  
  public boolean isUnTagged() { return !((this.type & 0x3) != 3); }
  
  public boolean isOK() { return !((this.type & 0x1C) != 4); }
  
  public boolean isNO() { return !((this.type & 0x1C) != 8); }
  
  public boolean isBAD() { return !((this.type & 0x1C) != 10); }
  
  public boolean isBYE() { return !((this.type & 0x1C) != 16); }
  
  public String getTag() { return this.tag; }
  
  public String toString() { return ASCIIUtility.toString(this.buffer, 0, this.size); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\Response.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */