/*     */ package com.sun.mail.iap;
/*     */ 
/*     */ import com.sun.mail.util.ASCIIUtility;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Argument
/*     */ {
/*  26 */   protected Vector items = new Vector(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void append(Argument paramArgument) {
/*  35 */     this.items.ensureCapacity(this.items.size() + paramArgument.items.size());
/*  36 */     for (byte b = 0; b < paramArgument.items.size(); b++) {
/*  37 */       this.items.addElement(paramArgument.items.elementAt(b));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public void writeString(String paramString) { this.items.addElement(new AString(ASCIIUtility.getBytes(paramString))); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeString(String paramString1, String paramString2) throws UnsupportedEncodingException {
/*  59 */     if (paramString2 == null) {
/*  60 */       writeString(paramString1); return;
/*     */     } 
/*  62 */     this.items.addElement(new AString(paramString1.getBytes(paramString2)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public void writeBytes(byte[] paramArrayOfByte) { this.items.addElement(paramArrayOfByte); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public void writeBytes(ByteArrayOutputStream paramByteArrayOutputStream) { this.items.addElement(paramByteArrayOutputStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public void writeAtom(String paramString) { this.items.addElement(new Atom(paramString)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public void writeNumber(int paramInt) { this.items.addElement(new Integer(paramInt)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public void writeArgument(Argument paramArgument) { this.items.addElement(paramArgument); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(Protocol paramProtocol) throws IOException, ProtocolException {
/* 112 */     int i = (this.items != null) ? this.items.size() : 0;
/* 113 */     DataOutputStream dataOutputStream = (DataOutputStream)paramProtocol.getOutputStream();
/*     */     
/* 115 */     for (byte b = 0; b < i; b++) {
/* 116 */       if (b) {
/* 117 */         dataOutputStream.write(32);
/*     */       }
/* 119 */       Object object = this.items.elementAt(b);
/* 120 */       if (object instanceof Atom) {
/* 121 */         dataOutputStream.writeBytes(((Atom)object).string);
/* 122 */       } else if (object instanceof Integer) {
/* 123 */         dataOutputStream.writeBytes(((Integer)object).toString());
/* 124 */       } else if (object instanceof AString) {
/* 125 */         astring(((AString)object).bytes, paramProtocol);
/* 126 */       } else if (object instanceof byte[]) {
/* 127 */         literal((byte[])object, paramProtocol);
/* 128 */       } else if (object instanceof ByteArrayOutputStream) {
/* 129 */         literal((ByteArrayOutputStream)object, paramProtocol);
/* 130 */       } else if (object instanceof Argument) {
/* 131 */         dataOutputStream.write(40);
/* 132 */         ((Argument)object).write(paramProtocol);
/* 133 */         dataOutputStream.write(41);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void astring(byte[] paramArrayOfByte, Protocol paramProtocol) throws IOException, ProtocolException {
/* 143 */     DataOutputStream dataOutputStream = (DataOutputStream)paramProtocol.getOutputStream();
/* 144 */     int i = paramArrayOfByte.length;
/*     */ 
/*     */     
/* 147 */     if (i > 1024) {
/* 148 */       literal(paramArrayOfByte, paramProtocol);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 153 */     boolean bool1 = (i == 0) ? 1 : 0;
/* 154 */     boolean bool2 = false;
/*     */ 
/*     */     
/* 157 */     for (byte b = 0; b < i; b++) {
/* 158 */       byte b1 = paramArrayOfByte[b];
/* 159 */       if (b1 == 0 || b1 == 13 || b1 == 10 || (b1 & 0xFF) > Byte.MAX_VALUE) {
/*     */         
/* 161 */         literal(paramArrayOfByte, paramProtocol);
/*     */         return;
/*     */       } 
/* 164 */       if (b1 == 42 || b1 == 37 || b1 == 40 || b1 == 41 || b1 == 123 || 
/* 165 */         b1 == 34 || b1 == 92 || (b1 & 0xFF) <= 32) {
/* 166 */         bool1 = true;
/* 167 */         if (b1 == 34 || b1 == 92) {
/* 168 */           bool2 = true;
/*     */         }
/*     */       } 
/*     */     } 
/* 172 */     if (bool1) {
/* 173 */       dataOutputStream.write(34);
/*     */     }
/* 175 */     if (bool2) {
/*     */       
/* 177 */       for (byte b1 = 0; b1 < i; b1++) {
/* 178 */         byte b2 = paramArrayOfByte[b1];
/* 179 */         if (b2 == 34 || b2 == 92)
/* 180 */           dataOutputStream.write(92); 
/* 181 */         dataOutputStream.write(b2);
/*     */       } 
/*     */     } else {
/* 184 */       dataOutputStream.write(paramArrayOfByte);
/*     */     } 
/*     */     
/* 187 */     if (bool1) {
/* 188 */       dataOutputStream.write(34);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void literal(byte[] paramArrayOfByte, Protocol paramProtocol) throws IOException, ProtocolException {
/* 196 */     DataOutputStream dataOutputStream = (DataOutputStream)paramProtocol.getOutputStream();
/* 197 */     boolean bool = paramProtocol.supportsNonSyncLiterals();
/*     */     
/* 199 */     dataOutputStream.write(123);
/* 200 */     dataOutputStream.writeBytes(Integer.toString(paramArrayOfByte.length));
/* 201 */     if (bool) {
/* 202 */       dataOutputStream.writeBytes("+}\r\n");
/*     */     } else {
/* 204 */       dataOutputStream.writeBytes("}\r\n");
/* 205 */     }  dataOutputStream.flush();
/*     */ 
/*     */ 
/*     */     
/* 209 */     if (!bool) {
/*     */       Response response; do {
/* 211 */         response = paramProtocol.readResponse();
/* 212 */       } while (!response.isContinuation());
/*     */     } 
/*     */ 
/*     */     
/* 216 */     dataOutputStream.write(paramArrayOfByte);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void literal(ByteArrayOutputStream paramByteArrayOutputStream, Protocol paramProtocol) throws IOException, ProtocolException {
/* 224 */     DataOutputStream dataOutputStream = (DataOutputStream)paramProtocol.getOutputStream();
/* 225 */     boolean bool = paramProtocol.supportsNonSyncLiterals();
/*     */     
/* 227 */     dataOutputStream.write(123);
/* 228 */     dataOutputStream.writeBytes(Integer.toString(paramByteArrayOutputStream.size()));
/* 229 */     if (bool) {
/* 230 */       dataOutputStream.writeBytes("+}\r\n");
/*     */     } else {
/* 232 */       dataOutputStream.writeBytes("}\r\n");
/* 233 */     }  dataOutputStream.flush();
/*     */ 
/*     */ 
/*     */     
/* 237 */     if (!bool) {
/*     */       Response response; do {
/* 239 */         response = paramProtocol.readResponse();
/* 240 */       } while (!response.isContinuation());
/*     */     } 
/*     */ 
/*     */     
/* 244 */     paramByteArrayOutputStream.writeTo(dataOutputStream);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\Argument.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */