package com.sun.mail.iap;

import com.sun.mail.util.ASCIIUtility;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Vector;

public class Argument {
  protected Vector items = new Vector(1);
  
  public void append(Argument paramArgument) {
    this.items.ensureCapacity(this.items.size() + paramArgument.items.size());
    for (byte b = 0; b < paramArgument.items.size(); b++)
      this.items.addElement(paramArgument.items.elementAt(b)); 
  }
  
  public void writeString(String paramString) { this.items.addElement(new AString(ASCIIUtility.getBytes(paramString))); }
  
  public void writeString(String paramString1, String paramString2) throws UnsupportedEncodingException {
    if (paramString2 == null) {
      writeString(paramString1);
      return;
    } 
    this.items.addElement(new AString(paramString1.getBytes(paramString2)));
  }
  
  public void writeBytes(byte[] paramArrayOfByte) { this.items.addElement(paramArrayOfByte); }
  
  public void writeBytes(ByteArrayOutputStream paramByteArrayOutputStream) { this.items.addElement(paramByteArrayOutputStream); }
  
  public void writeAtom(String paramString) { this.items.addElement(new Atom(paramString)); }
  
  public void writeNumber(int paramInt) { this.items.addElement(new Integer(paramInt)); }
  
  public void writeArgument(Argument paramArgument) { this.items.addElement(paramArgument); }
  
  public void write(Protocol paramProtocol) throws IOException, ProtocolException {
    int i = (this.items != null) ? this.items.size() : 0;
    DataOutputStream dataOutputStream = (DataOutputStream)paramProtocol.getOutputStream();
    for (byte b = 0; b < i; b++) {
      if (b)
        dataOutputStream.write(32); 
      Object object = this.items.elementAt(b);
      if (object instanceof Atom) {
        dataOutputStream.writeBytes(((Atom)object).string);
      } else if (object instanceof Integer) {
        dataOutputStream.writeBytes(((Integer)object).toString());
      } else if (object instanceof AString) {
        astring(((AString)object).bytes, paramProtocol);
      } else if (object instanceof byte[]) {
        literal((byte[])object, paramProtocol);
      } else if (object instanceof ByteArrayOutputStream) {
        literal((ByteArrayOutputStream)object, paramProtocol);
      } else if (object instanceof Argument) {
        dataOutputStream.write(40);
        ((Argument)object).write(paramProtocol);
        dataOutputStream.write(41);
      } 
    } 
  }
  
  private void astring(byte[] paramArrayOfByte, Protocol paramProtocol) throws IOException, ProtocolException {
    DataOutputStream dataOutputStream = (DataOutputStream)paramProtocol.getOutputStream();
    int i = paramArrayOfByte.length;
    if (i > 1024) {
      literal(paramArrayOfByte, paramProtocol);
      return;
    } 
    boolean bool1 = (i == 0) ? 1 : 0;
    boolean bool2 = false;
    for (byte b = 0; b < i; b++) {
      byte b1 = paramArrayOfByte[b];
      if (b1 == 0 || b1 == 13 || b1 == 10 || (b1 & 0xFF) > Byte.MAX_VALUE) {
        literal(paramArrayOfByte, paramProtocol);
        return;
      } 
      if (b1 == 42 || b1 == 37 || b1 == 40 || b1 == 41 || b1 == 123 || 
        b1 == 34 || b1 == 92 || (b1 & 0xFF) <= 32) {
        bool1 = true;
        if (b1 == 34 || b1 == 92)
          bool2 = true; 
      } 
    } 
    if (bool1)
      dataOutputStream.write(34); 
    if (bool2) {
      for (byte b1 = 0; b1 < i; b1++) {
        byte b2 = paramArrayOfByte[b1];
        if (b2 == 34 || b2 == 92)
          dataOutputStream.write(92); 
        dataOutputStream.write(b2);
      } 
    } else {
      dataOutputStream.write(paramArrayOfByte);
    } 
    if (bool1)
      dataOutputStream.write(34); 
  }
  
  private void literal(byte[] paramArrayOfByte, Protocol paramProtocol) throws IOException, ProtocolException {
    DataOutputStream dataOutputStream = (DataOutputStream)paramProtocol.getOutputStream();
    boolean bool = paramProtocol.supportsNonSyncLiterals();
    dataOutputStream.write(123);
    dataOutputStream.writeBytes(Integer.toString(paramArrayOfByte.length));
    if (bool) {
      dataOutputStream.writeBytes("+}\r\n");
    } else {
      dataOutputStream.writeBytes("}\r\n");
    } 
    dataOutputStream.flush();
    if (!bool) {
      Response response;
      do {
        response = paramProtocol.readResponse();
      } while (!response.isContinuation());
    } 
    dataOutputStream.write(paramArrayOfByte);
  }
  
  private void literal(ByteArrayOutputStream paramByteArrayOutputStream, Protocol paramProtocol) throws IOException, ProtocolException {
    DataOutputStream dataOutputStream = (DataOutputStream)paramProtocol.getOutputStream();
    boolean bool = paramProtocol.supportsNonSyncLiterals();
    dataOutputStream.write(123);
    dataOutputStream.writeBytes(Integer.toString(paramByteArrayOutputStream.size()));
    if (bool) {
      dataOutputStream.writeBytes("+}\r\n");
    } else {
      dataOutputStream.writeBytes("}\r\n");
    } 
    dataOutputStream.flush();
    if (!bool) {
      Response response;
      do {
        response = paramProtocol.readResponse();
      } while (!response.isContinuation());
    } 
    paramByteArrayOutputStream.writeTo(dataOutputStream);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\Argument.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */