package com.sun.mail.iap;

class Atom {
  String string;
  
  Atom(String paramString) { this.string = paramString; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\Atom.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */