/*    */ package com.sun.mail.iap;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteArray
/*    */ {
/*    */   private byte[] bytes;
/*    */   private int start;
/*    */   private int count;
/*    */   
/*    */   public ByteArray(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
/* 29 */     this.bytes = paramArrayOfByte;
/* 30 */     this.start = paramInt1;
/* 31 */     this.count = paramInt2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   public byte[] getBytes() { return this.bytes; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   public int getStart() { return this.start; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public int getCount() { return this.count; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 60 */   public ByteArrayInputStream toByteArrayInputStream() { return new ByteArrayInputStream(this.bytes, this.start, this.count); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\ByteArray.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */