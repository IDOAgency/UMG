package com.sun.mail.iap;

class AString {
  byte[] bytes;
  
  AString(byte[] paramArrayOfByte) { this.bytes = paramArrayOfByte; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\AString.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */