/*    */ package com.sun.mail.iap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProtocolException
/*    */   extends Exception
/*    */ {
/*    */   private Response response;
/*    */   
/*    */   public ProtocolException() {}
/*    */   
/* 29 */   public ProtocolException(String paramString) { super(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ProtocolException(Response paramResponse) {
/* 36 */     super(paramResponse.toString());
/* 37 */     this.response = paramResponse;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   public Response getResponse() { return this.response; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\ProtocolException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */