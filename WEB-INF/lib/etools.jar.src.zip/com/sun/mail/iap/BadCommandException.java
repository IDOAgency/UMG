package com.sun.mail.iap;

public class BadCommandException extends ProtocolException {
  public BadCommandException() {}
  
  public BadCommandException(String paramString) { super(paramString); }
  
  public BadCommandException(Response paramResponse) { super(paramResponse); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\iap\BadCommandException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */