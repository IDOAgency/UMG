/*    */ package com.sun.mail.smtp;
/*    */ 
/*    */ import com.sun.mail.util.CRLFOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SMTPOutputStream
/*    */   extends CRLFOutputStream
/*    */ {
/* 24 */   public SMTPOutputStream(OutputStream paramOutputStream) { super(paramOutputStream); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(int paramInt) throws IOException {
/* 30 */     if ((this.lastb == 10 || this.lastb == -1) && paramInt == 46) {
/* 31 */       this.out.write(46);
/*    */     }
/*    */     
/* 34 */     super.write(paramInt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/* 41 */     byte b = (this.lastb == -1) ? 10 : this.lastb;
/* 42 */     int i = paramInt1;
/*    */     
/* 44 */     paramInt2 += paramInt1;
/* 45 */     for (int j = paramInt1; j < paramInt2; j++) {
/* 46 */       if (b == 10 && paramArrayOfByte[j] == 46) {
/* 47 */         super.write(paramArrayOfByte, i, j - i);
/* 48 */         this.out.write(46);
/* 49 */         i = j;
/*    */       } 
/* 51 */       b = paramArrayOfByte[j];
/*    */     } 
/* 53 */     if (paramInt2 - i > 0)
/* 54 */       super.write(paramArrayOfByte, i, paramInt2 - i); 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\smtp\SMTPOutputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */