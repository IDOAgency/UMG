package com.sun.mail.smtp;

import com.sun.mail.util.CRLFOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class SMTPOutputStream extends CRLFOutputStream {
  public SMTPOutputStream(OutputStream paramOutputStream) { super(paramOutputStream); }
  
  public void write(int paramInt) throws IOException {
    if ((this.lastb == 10 || this.lastb == -1) && paramInt == 46)
      this.out.write(46); 
    super.write(paramInt);
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
    byte b = (this.lastb == -1) ? 10 : this.lastb;
    int i = paramInt1;
    paramInt2 += paramInt1;
    for (int j = paramInt1; j < paramInt2; j++) {
      if (b == 10 && paramArrayOfByte[j] == 46) {
        super.write(paramArrayOfByte, i, j - i);
        this.out.write(46);
        i = j;
      } 
      b = paramArrayOfByte[j];
    } 
    if (paramInt2 - i > 0)
      super.write(paramArrayOfByte, i, paramInt2 - i); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\smtp\SMTPOutputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */