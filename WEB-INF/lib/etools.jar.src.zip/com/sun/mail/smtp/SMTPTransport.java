/*     */ package com.sun.mail.smtp;
/*     */ 
/*     */ import com.sun.mail.util.ASCIIUtility;
/*     */ import com.sun.mail.util.LineInputStream;
/*     */ import com.sun.mail.util.SocketFetcher;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import javax.mail.Address;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.SendFailedException;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Transport;
/*     */ import javax.mail.URLName;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SMTPTransport
/*     */   extends Transport
/*     */ {
/*     */   private MimeMessage message;
/*     */   private Address[] addresses;
/*     */   private Address[] validSentAddr;
/*     */   private Address[] validUnsentAddr;
/*     */   private Address[] invalidAddr;
/*  44 */   private static final String[] ignoreList = { "Bcc", "Content-Length" };
/*     */ 
/*     */   
/*  47 */   private String name = "smtp";
/*     */   private BufferedInputStream serverInput;
/*     */   
/*     */   public SMTPTransport(Session paramSession, URLName paramURLName) {
/*  51 */     super(paramSession, paramURLName);
/*     */     
/*  53 */     if (paramURLName != null) {
/*  54 */       this.name = paramURLName.getProtocol();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private LineInputStream lineInputStream;
/*     */ 
/*     */   
/*     */   private OutputStream serverOutput;
/*     */ 
/*     */   
/*     */   private String lastServerResponse;
/*     */ 
/*     */   
/*     */   private Socket serverSocket;
/*     */   
/*     */   private static String localHostName;
/*     */ 
/*     */   
/*     */   protected boolean protocolConnect(String paramString1, int paramInt, String paramString2, String paramString3) throws MessagingException {
/*  75 */     if (paramInt == -1) {
/*  76 */       String str = this.session.getProperty("mail." + this.name + ".port");
/*  77 */       if (str != null) {
/*  78 */         paramInt = Integer.parseInt(str);
/*     */       } else {
/*  80 */         paramInt = 25;
/*     */       } 
/*     */     } 
/*     */     
/*  84 */     if (paramString1 == null || paramString1.length() == 0) {
/*  85 */       paramString1 = "localhost";
/*     */     }
/*     */     
/*  88 */     boolean bool = false;
/*     */     
/*     */     try {
/*  91 */       bool = openServer(paramString1, paramInt);
/*  92 */       if (bool)
/*  93 */         helo(); 
/*  94 */     } catch (UnknownHostException unknownHostException) {
/*  95 */       throw new MessagingException("Unknown SMTP host: " + paramString1, unknownHostException);
/*  96 */     } catch (IOException iOException) {
/*  97 */       throw new MessagingException("Could not connect to SMTP host: " + 
/*  98 */           paramString1 + ", port: " + paramInt, iOException);
/*     */     } 
/*     */     
/* 101 */     if (!bool) {
/* 102 */       if (this.debug)
/* 103 */         System.out.println("DEBUG: SMTPTransport could not connect to host \"" + 
/* 104 */             paramString1 + "\", port: " + paramInt + 
/* 105 */             "\n"); 
/* 106 */       throw new MessagingException("Could not connect to SMTP host: " + 
/* 107 */           paramString1 + ", port: " + paramInt);
/*     */     } 
/* 109 */     if (this.debug) {
/* 110 */       System.out.println("DEBUG: SMTPTransport connected to host \"" + 
/* 111 */           paramString1 + "\", port: " + paramInt + "\n");
/*     */     }
/*     */ 
/*     */     
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendMessage(Message paramMessage, Address[] paramArrayOfAddress) throws MessagingException, SendFailedException {
/* 148 */     checkConnected();
/*     */ 
/*     */ 
/*     */     
/* 152 */     if (!(paramMessage instanceof MimeMessage)) {
/* 153 */       if (this.debug)
/* 154 */         System.out.println("DEBUG: Can only send RFC822 msgs"); 
/* 155 */       throw new MessagingException("SMTP can only send RFC822 messages");
/*     */     } 
/* 157 */     for (byte b = 0; b < paramArrayOfAddress.length; b++) {
/* 158 */       if (!(paramArrayOfAddress[b] instanceof InternetAddress)) {
/* 159 */         throw new MessagingException(String.valueOf(paramArrayOfAddress[b]) + 
/* 160 */             " is not an InternetAddress");
/*     */       }
/*     */     } 
/*     */     
/* 164 */     this.message = (MimeMessage)paramMessage;
/* 165 */     this.addresses = paramArrayOfAddress;
/*     */     
/*     */     try {
/* 168 */       mailFrom();
/* 169 */       rcptTo();
/* 170 */       this.message.writeTo(data(), ignoreList);
/* 171 */       finishData();
/* 172 */       notifyTransportListeners(1, 
/* 173 */           this.validSentAddr, this.validUnsentAddr, 
/* 174 */           this.invalidAddr, this.message);
/* 175 */     } catch (IOException iOException) {
/* 176 */       if (this.debug) {
/* 177 */         iOException.printStackTrace();
/*     */       }
/*     */ 
/*     */       
/* 181 */       try { this.serverSocket.close(); }
/* 182 */       catch (IOException iOException1) {  }
/*     */       finally
/* 184 */       { this.serverSocket = null;
/*     */         try {
/* 186 */           close();
/* 187 */         } catch (MessagingException messagingException) {} }
/*     */       
/* 189 */       notifyTransportListeners(2, 
/* 190 */           this.validSentAddr, this.validUnsentAddr, 
/* 191 */           this.invalidAddr, this.message);
/*     */       
/* 193 */       throw new MessagingException("IOException while sending message", 
/* 194 */           iOException);
/*     */     } finally {
/*     */       
/* 197 */       this.validSentAddr = this.validUnsentAddr = this.invalidAddr = null;
/* 198 */       this.addresses = null;
/* 199 */       this.message = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws MessagingException {
/* 205 */     if (!super.isConnected()) {
/*     */       return;
/*     */     }
/*     */     try {
/* 209 */       if (this.serverSocket != null)
/* 210 */         sendCommand("quit");  return;
/*     */     } finally {
/*     */       try {
/* 213 */         if (this.serverSocket != null)
/* 214 */           this.serverSocket.close(); 
/* 215 */       } catch (IOException iOException) {
/* 216 */         throw new MessagingException("Server Close Failed", iOException);
/*     */       } finally {
/* 218 */         this.serverSocket = null;
/* 219 */         this.serverOutput = null;
/* 220 */         this.serverInput = null;
/* 221 */         this.lineInputStream = null;
/* 222 */         super.close();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConnected() {
/* 232 */     if (!super.isConnected())
/*     */     {
/* 234 */       return false;
/*     */     }
/*     */     try {
/* 237 */       sendCommand("NOOP");
/* 238 */       int i = readServerResponse();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 246 */       if (i >= 0) {
/* 247 */         return true;
/*     */       }
/* 249 */       setConnected(false);
/* 250 */       notifyConnectionListeners(3);
/* 251 */       return false;
/*     */     }
/* 253 */     catch (Exception exception) {
/* 254 */       setConnected(false);
/* 255 */       notifyConnectionListeners(3);
/* 256 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void finalize() throws MessagingException {
/* 261 */     if (this.serverSocket != null)
/* 262 */       close(); 
/* 263 */     super.finalize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void helo() throws MessagingException {
/*     */     try {
/* 279 */       if (localHostName == null || localHostName.length() <= 0) {
/* 280 */         localHostName = InetAddress.getLocalHost().getHostName();
/*     */       }
/* 282 */       issueCommand("helo " + localHostName, 250); return;
/* 283 */     } catch (UnknownHostException unknownHostException) {
/* 284 */       issueCommand("helo", 250);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mailFrom() throws MessagingException {
/* 295 */     String str = this.session.getProperty("mail." + this.name + ".user");
/* 296 */     if (str == null || str.length() <= 0) {
/*     */       InternetAddress internetAddress;
/*     */       Address[] arrayOfAddress;
/* 299 */       if (this.message != null && (arrayOfAddress = this.message.getFrom()) != null && 
/* 300 */         arrayOfAddress.length > 0) {
/* 301 */         internetAddress = arrayOfAddress[0];
/*     */       } else {
/* 303 */         internetAddress = InternetAddress.getLocalAddress(this.session);
/*     */       } 
/* 305 */       if (internetAddress != null) {
/* 306 */         str = ((InternetAddress)internetAddress).getAddress();
/*     */       } else {
/* 308 */         throw new MessagingException(
/* 309 */             "can't determine local email address");
/*     */       } 
/*     */     } 
/* 312 */     issueCommand("mail from: " + normalizeAddress(str), 250);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void rcptTo() throws MessagingException {
/* 334 */     Vector vector1 = new Vector();
/* 335 */     Vector vector2 = new Vector();
/* 336 */     int i = -1;
/* 337 */     SendFailedException sendFailedException = null;
/* 338 */     boolean bool = false;
/* 339 */     this.validSentAddr = this.validUnsentAddr = this.invalidAddr = null;
/*     */ 
/*     */     
/* 342 */     for (byte b = 0; b < this.addresses.length; b++) {
/*     */       String str;
/*     */       SendFailedException sendFailedException2, sendFailedException1;
/* 345 */       sendCommand("rcpt to: " + 
/* 346 */           normalizeAddress(((InternetAddress)this.addresses[b]).getAddress()));
/*     */       
/* 348 */       i = readServerResponse();
/* 349 */       switch (i) { case 250:
/*     */         case 251:
/* 351 */           vector1.addElement(this.addresses[b]); break;
/*     */         case 501: case 503:
/*     */         case 550:
/*     */         case 551:
/*     */         case 553:
/* 356 */           bool = true;
/* 357 */           vector2.addElement(this.addresses[b]);
/*     */           
/* 359 */           sendFailedException1 = 
/* 360 */             new SendFailedException(this.lastServerResponse);
/* 361 */           if (sendFailedException == null) {
/* 362 */             sendFailedException = sendFailedException1; break;
/*     */           } 
/* 364 */           sendFailedException.setNextException(sendFailedException1); break;
/*     */         case 450:
/*     */         case 451:
/*     */         case 452:
/*     */         case 552:
/* 369 */           bool = true;
/* 370 */           vector1.addElement(this.addresses[b]);
/*     */           
/* 372 */           sendFailedException2 = 
/* 373 */             new SendFailedException(this.lastServerResponse);
/* 374 */           if (sendFailedException == null) {
/* 375 */             sendFailedException = sendFailedException2; break;
/*     */           } 
/* 377 */           sendFailedException.setNextException(sendFailedException2);
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 382 */           str = this.lastServerResponse;
/* 383 */           issueCommand("rset", 250);
/* 384 */           throw new SendFailedException(str); }
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 389 */     if (bool) {
/*     */       
/* 391 */       this.invalidAddr = new Address[vector2.size()];
/* 392 */       vector2.copyInto(this.invalidAddr);
/*     */ 
/*     */       
/* 395 */       this.validUnsentAddr = new Address[vector1.size()];
/* 396 */       vector1.copyInto(this.validUnsentAddr);
/*     */     } else {
/* 398 */       this.validSentAddr = this.addresses;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 403 */     if (this.debug) {
/* 404 */       if (this.validSentAddr != null && this.validSentAddr.length > 0) {
/* 405 */         System.out.println("Verified Addresses");
/* 406 */         for (byte b1 = 0; b1 < this.validSentAddr.length; b1++) {
/* 407 */           System.out.println("  " + this.validSentAddr[b1]);
/*     */         }
/*     */       } 
/* 410 */       if (this.validUnsentAddr != null && this.validUnsentAddr.length > 0) {
/* 411 */         System.out.println("Valid Unsent Addresses");
/* 412 */         for (byte b1 = 0; b1 < this.validUnsentAddr.length; b1++) {
/* 413 */           System.out.println("  " + this.validUnsentAddr[b1]);
/*     */         }
/*     */       } 
/* 416 */       if (this.invalidAddr != null && this.invalidAddr.length > 0) {
/* 417 */         System.out.println("Invalid Addresses");
/* 418 */         for (byte b1 = 0; b1 < this.invalidAddr.length; b1++) {
/* 419 */           System.out.println("  " + this.invalidAddr[b1]);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 425 */     if (bool) {
/* 426 */       if (this.debug) {
/* 427 */         System.out.println("DEBUG SMTPTransport: Sending failed because of invalid destination addresses");
/*     */       }
/* 429 */       notifyTransportListeners(2, 
/* 430 */           this.validSentAddr, this.validUnsentAddr, 
/* 431 */           this.invalidAddr, this.message);
/*     */ 
/*     */       
/*     */       try {
/* 435 */         issueCommand("rset", 250);
/* 436 */       } catch (MessagingException messagingException) {
/*     */         
/*     */         try {
/* 439 */           close();
/* 440 */         } catch (MessagingException messagingException1) {
/*     */           
/* 442 */           if (this.debug) {
/* 443 */             messagingException1.printStackTrace();
/*     */           }
/*     */         } 
/*     */       } 
/* 447 */       throw new SendFailedException("Invalid Addresses", sendFailedException, 
/* 448 */           this.validSentAddr, 
/* 449 */           this.validUnsentAddr, this.invalidAddr);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private OutputStream data() throws MessagingException {
/* 458 */     issueCommand("data", 354);
/* 459 */     return new SMTPOutputStream(this.serverOutput);
/*     */   }
/*     */ 
/*     */   
/* 463 */   private void finishData() throws MessagingException { issueCommand("\r\n.", 250); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean openServer(String paramString, int paramInt) throws IOException, UnknownHostException {
/* 471 */     if (this.debug) {
/* 472 */       System.out.println("\nDEBUG: SMTPTransport trying to connect to host \"" + 
/*     */           
/* 474 */           paramString + "\", port " + paramInt + "\n");
/*     */     }
/* 476 */     Properties properties = this.session.getProperties();
/*     */     
/* 478 */     this.serverSocket = SocketFetcher.getSocket(paramString, paramInt, 
/* 479 */         properties.getProperty("mail." + this.name + ".socketFactory.class", null), 
/* 480 */         properties.getProperty("mail." + this.name + ".socketFactory.fallback", null), 
/* 481 */         properties.getProperty("mail." + this.name + ".socketFactory.port", null));
/*     */     
/* 483 */     this.serverOutput = new BufferedOutputStream(this.serverSocket.getOutputStream());
/* 484 */     this.serverInput = new BufferedInputStream(this.serverSocket.getInputStream());
/* 485 */     this.lineInputStream = new LineInputStream(this.serverInput);
/*     */     
/* 487 */     if (readServerResponse() != 220) {
/*     */       try {
/* 489 */         close();
/* 490 */       } catch (MessagingException messagingException) {
/* 491 */         this.serverSocket.close();
/* 492 */         this.serverSocket = null;
/*     */       } 
/* 494 */       return false;
/*     */     } 
/* 496 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void issueCommand(String paramString, int paramInt) throws MessagingException {
/* 502 */     sendCommand(paramString);
/*     */ 
/*     */ 
/*     */     
/* 506 */     if (readServerResponse() != paramInt) {
/* 507 */       throw new MessagingException(this.lastServerResponse);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void sendCommand(String paramString) throws MessagingException {
/* 515 */     if (this.debug) {
/* 516 */       System.out.println("DEBUG SMTP SENT: " + paramString);
/*     */     }
/* 518 */     paramString = String.valueOf(paramString) + "\r\n";
/* 519 */     byte[] arrayOfByte = ASCIIUtility.getBytes(paramString);
/*     */     try {
/* 521 */       this.serverOutput.write(arrayOfByte);
/* 522 */       this.serverOutput.flush(); return;
/* 523 */     } catch (IOException iOException) {
/* 524 */       throw new MessagingException("Can't send command to SMTP host", iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int readServerResponse() {
/* 534 */     String str = "";
/* 535 */     int i = 0;
/* 536 */     StringBuffer stringBuffer = new StringBuffer(100);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 541 */       String str1 = null;
/*     */       
/*     */       do {
/* 544 */         str1 = this.lineInputStream.readLine();
/* 545 */         if (str1 == null)
/* 546 */           return -1; 
/* 547 */         stringBuffer.append(str1);
/* 548 */         stringBuffer.append("\n");
/* 549 */       } while (isNotLastLine(str1));
/*     */       
/* 551 */       str = stringBuffer.toString();
/* 552 */     } catch (IOException iOException) {
/*     */       
/* 554 */       i = -1;
/*     */     } 
/*     */ 
/*     */     
/* 558 */     if (this.debug) {
/* 559 */       System.out.println("DEBUG SMTP RCVD: " + str);
/*     */     }
/*     */     
/* 562 */     if (i != -1 && str != null && 
/* 563 */       str.length() >= 3) {
/*     */       try {
/* 565 */         i = Integer.parseInt(str.substring(0, 3));
/* 566 */       } catch (NumberFormatException numberFormatException) {
/*     */         try {
/* 568 */           close();
/* 569 */         } catch (MessagingException messagingException) {
/*     */           
/* 571 */           if (this.debug)
/* 572 */             messagingException.printStackTrace(); 
/*     */         } 
/* 574 */         i = -1;
/* 575 */       } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
/*     */         
/*     */         try {
/* 578 */           close();
/* 579 */         } catch (MessagingException messagingException) {
/*     */           
/* 581 */           if (this.debug)
/* 582 */             messagingException.printStackTrace(); 
/*     */         } 
/* 584 */         i = -1;
/*     */       } 
/*     */     } else {
/* 587 */       i = -1;
/*     */     } 
/*     */     
/* 590 */     this.lastServerResponse = str;
/* 591 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkConnected() throws MessagingException {
/* 599 */     if (!super.isConnected()) {
/* 600 */       throw new IllegalStateException("Not connected");
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isNotLastLine(String paramString) {
/* 605 */     if (paramString != null && paramString.length() > 4) {
/* 606 */       return !(paramString.charAt(3) != '-');
/*     */     }
/* 608 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String normalizeAddress(String paramString) {
/* 614 */     if (!paramString.startsWith("<") && !paramString.endsWith(">")) {
/* 615 */       return "<" + paramString + ">";
/*     */     }
/* 617 */     return paramString;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\smtp\SMTPTransport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */