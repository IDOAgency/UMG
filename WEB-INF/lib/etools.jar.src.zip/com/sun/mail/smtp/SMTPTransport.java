package com.sun.mail.smtp;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.LineInputStream;
import com.sun.mail.util.SocketFetcher;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;
import java.util.Vector;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.SendFailedException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.URLName;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SMTPTransport extends Transport {
  private MimeMessage message;
  
  private Address[] addresses;
  
  private Address[] validSentAddr;
  
  private Address[] validUnsentAddr;
  
  private Address[] invalidAddr;
  
  private static final String[] ignoreList = { "Bcc", "Content-Length" };
  
  private String name = "smtp";
  
  private BufferedInputStream serverInput;
  
  private LineInputStream lineInputStream;
  
  private OutputStream serverOutput;
  
  private String lastServerResponse;
  
  private Socket serverSocket;
  
  private static String localHostName;
  
  public SMTPTransport(Session paramSession, URLName paramURLName) {
    super(paramSession, paramURLName);
    if (paramURLName != null)
      this.name = paramURLName.getProtocol(); 
  }
  
  protected boolean protocolConnect(String paramString1, int paramInt, String paramString2, String paramString3) throws MessagingException {
    if (paramInt == -1) {
      String str = this.session.getProperty("mail." + this.name + ".port");
      if (str != null) {
        paramInt = Integer.parseInt(str);
      } else {
        paramInt = 25;
      } 
    } 
    if (paramString1 == null || paramString1.length() == 0)
      paramString1 = "localhost"; 
    boolean bool = false;
    try {
      bool = openServer(paramString1, paramInt);
      if (bool)
        helo(); 
    } catch (UnknownHostException unknownHostException) {
      throw new MessagingException("Unknown SMTP host: " + paramString1, unknownHostException);
    } catch (IOException iOException) {
      throw new MessagingException("Could not connect to SMTP host: " + 
          paramString1 + ", port: " + paramInt, iOException);
    } 
    if (!bool) {
      if (this.debug)
        System.out.println("DEBUG: SMTPTransport could not connect to host \"" + 
            paramString1 + "\", port: " + paramInt + 
            "\n"); 
      throw new MessagingException("Could not connect to SMTP host: " + 
          paramString1 + ", port: " + paramInt);
    } 
    if (this.debug)
      System.out.println("DEBUG: SMTPTransport connected to host \"" + 
          paramString1 + "\", port: " + paramInt + "\n"); 
    return true;
  }
  
  public void sendMessage(Message paramMessage, Address[] paramArrayOfAddress) throws MessagingException, SendFailedException {
    checkConnected();
    if (!(paramMessage instanceof MimeMessage)) {
      if (this.debug)
        System.out.println("DEBUG: Can only send RFC822 msgs"); 
      throw new MessagingException("SMTP can only send RFC822 messages");
    } 
    for (byte b = 0; b < paramArrayOfAddress.length; b++) {
      if (!(paramArrayOfAddress[b] instanceof InternetAddress))
        throw new MessagingException(String.valueOf(paramArrayOfAddress[b]) + 
            " is not an InternetAddress"); 
    } 
    this.message = (MimeMessage)paramMessage;
    this.addresses = paramArrayOfAddress;
    try {
      mailFrom();
      rcptTo();
      this.message.writeTo(data(), ignoreList);
      finishData();
      notifyTransportListeners(1, 
          this.validSentAddr, this.validUnsentAddr, 
          this.invalidAddr, this.message);
    } catch (IOException iOException) {
      if (this.debug)
        iOException.printStackTrace(); 
      try {
        this.serverSocket.close();
      } catch (IOException iOException1) {
      
      } finally {
        this.serverSocket = null;
        try {
          close();
        } catch (MessagingException messagingException) {}
      } 
      notifyTransportListeners(2, 
          this.validSentAddr, this.validUnsentAddr, 
          this.invalidAddr, this.message);
      throw new MessagingException("IOException while sending message", 
          iOException);
    } finally {
      this.validSentAddr = this.validUnsentAddr = this.invalidAddr = null;
      this.addresses = null;
      this.message = null;
    } 
  }
  
  public void close() throws MessagingException {
    if (!super.isConnected())
      return; 
    try {
      if (this.serverSocket != null)
        sendCommand("quit"); 
      return;
    } finally {
      try {
        if (this.serverSocket != null)
          this.serverSocket.close(); 
      } catch (IOException iOException) {
        throw new MessagingException("Server Close Failed", iOException);
      } finally {
        this.serverSocket = null;
        this.serverOutput = null;
        this.serverInput = null;
        this.lineInputStream = null;
        super.close();
      } 
    } 
  }
  
  public boolean isConnected() {
    if (!super.isConnected())
      return false; 
    try {
      sendCommand("NOOP");
      int i = readServerResponse();
      if (i >= 0)
        return true; 
      setConnected(false);
      notifyConnectionListeners(3);
      return false;
    } catch (Exception exception) {
      setConnected(false);
      notifyConnectionListeners(3);
      return false;
    } 
  }
  
  protected void finalize() throws MessagingException {
    if (this.serverSocket != null)
      close(); 
    super.finalize();
  }
  
  private void helo() throws MessagingException {
    try {
      if (localHostName == null || localHostName.length() <= 0)
        localHostName = InetAddress.getLocalHost().getHostName(); 
      issueCommand("helo " + localHostName, 250);
      return;
    } catch (UnknownHostException unknownHostException) {
      issueCommand("helo", 250);
      return;
    } 
  }
  
  private void mailFrom() throws MessagingException {
    String str = this.session.getProperty("mail." + this.name + ".user");
    if (str == null || str.length() <= 0) {
      InternetAddress internetAddress;
      Address[] arrayOfAddress;
      if (this.message != null && (arrayOfAddress = this.message.getFrom()) != null && 
        arrayOfAddress.length > 0) {
        internetAddress = arrayOfAddress[0];
      } else {
        internetAddress = InternetAddress.getLocalAddress(this.session);
      } 
      if (internetAddress != null) {
        str = ((InternetAddress)internetAddress).getAddress();
      } else {
        throw new MessagingException(
            "can't determine local email address");
      } 
    } 
    issueCommand("mail from: " + normalizeAddress(str), 250);
  }
  
  private void rcptTo() throws MessagingException {
    Vector vector1 = new Vector();
    Vector vector2 = new Vector();
    int i = -1;
    SendFailedException sendFailedException = null;
    boolean bool = false;
    this.validSentAddr = this.validUnsentAddr = this.invalidAddr = null;
    for (byte b = 0; b < this.addresses.length; b++) {
      String str;
      SendFailedException sendFailedException2, sendFailedException1;
      sendCommand("rcpt to: " + 
          normalizeAddress(((InternetAddress)this.addresses[b]).getAddress()));
      i = readServerResponse();
      switch (i) {
        case 250:
        case 251:
          vector1.addElement(this.addresses[b]);
          break;
        case 501:
        case 503:
        case 550:
        case 551:
        case 553:
          bool = true;
          vector2.addElement(this.addresses[b]);
          sendFailedException1 = 
            new SendFailedException(this.lastServerResponse);
          if (sendFailedException == null) {
            sendFailedException = sendFailedException1;
            break;
          } 
          sendFailedException.setNextException(sendFailedException1);
          break;
        case 450:
        case 451:
        case 452:
        case 552:
          bool = true;
          vector1.addElement(this.addresses[b]);
          sendFailedException2 = 
            new SendFailedException(this.lastServerResponse);
          if (sendFailedException == null) {
            sendFailedException = sendFailedException2;
            break;
          } 
          sendFailedException.setNextException(sendFailedException2);
          break;
        default:
          str = this.lastServerResponse;
          issueCommand("rset", 250);
          throw new SendFailedException(str);
      } 
    } 
    if (bool) {
      this.invalidAddr = new Address[vector2.size()];
      vector2.copyInto(this.invalidAddr);
      this.validUnsentAddr = new Address[vector1.size()];
      vector1.copyInto(this.validUnsentAddr);
    } else {
      this.validSentAddr = this.addresses;
    } 
    if (this.debug) {
      if (this.validSentAddr != null && this.validSentAddr.length > 0) {
        System.out.println("Verified Addresses");
        for (byte b1 = 0; b1 < this.validSentAddr.length; b1++)
          System.out.println("  " + this.validSentAddr[b1]); 
      } 
      if (this.validUnsentAddr != null && this.validUnsentAddr.length > 0) {
        System.out.println("Valid Unsent Addresses");
        for (byte b1 = 0; b1 < this.validUnsentAddr.length; b1++)
          System.out.println("  " + this.validUnsentAddr[b1]); 
      } 
      if (this.invalidAddr != null && this.invalidAddr.length > 0) {
        System.out.println("Invalid Addresses");
        for (byte b1 = 0; b1 < this.invalidAddr.length; b1++)
          System.out.println("  " + this.invalidAddr[b1]); 
      } 
    } 
    if (bool) {
      if (this.debug)
        System.out.println("DEBUG SMTPTransport: Sending failed because of invalid destination addresses"); 
      notifyTransportListeners(2, 
          this.validSentAddr, this.validUnsentAddr, 
          this.invalidAddr, this.message);
      try {
        issueCommand("rset", 250);
      } catch (MessagingException messagingException) {
        try {
          close();
        } catch (MessagingException messagingException1) {
          if (this.debug)
            messagingException1.printStackTrace(); 
        } 
      } 
      throw new SendFailedException("Invalid Addresses", sendFailedException, 
          this.validSentAddr, 
          this.validUnsentAddr, this.invalidAddr);
    } 
  }
  
  private OutputStream data() throws MessagingException {
    issueCommand("data", 354);
    return new SMTPOutputStream(this.serverOutput);
  }
  
  private void finishData() throws MessagingException { issueCommand("\r\n.", 250); }
  
  private boolean openServer(String paramString, int paramInt) throws IOException, UnknownHostException {
    if (this.debug)
      System.out.println("\nDEBUG: SMTPTransport trying to connect to host \"" + 
          
          paramString + "\", port " + paramInt + "\n"); 
    Properties properties = this.session.getProperties();
    this.serverSocket = SocketFetcher.getSocket(paramString, paramInt, 
        properties.getProperty("mail." + this.name + ".socketFactory.class", null), 
        properties.getProperty("mail." + this.name + ".socketFactory.fallback", null), 
        properties.getProperty("mail." + this.name + ".socketFactory.port", null));
    this.serverOutput = new BufferedOutputStream(this.serverSocket.getOutputStream());
    this.serverInput = new BufferedInputStream(this.serverSocket.getInputStream());
    this.lineInputStream = new LineInputStream(this.serverInput);
    if (readServerResponse() != 220) {
      try {
        close();
      } catch (MessagingException messagingException) {
        this.serverSocket.close();
        this.serverSocket = null;
      } 
      return false;
    } 
    return true;
  }
  
  private void issueCommand(String paramString, int paramInt) throws MessagingException {
    sendCommand(paramString);
    if (readServerResponse() != paramInt)
      throw new MessagingException(this.lastServerResponse); 
  }
  
  private void sendCommand(String paramString) throws MessagingException {
    if (this.debug)
      System.out.println("DEBUG SMTP SENT: " + paramString); 
    paramString = String.valueOf(paramString) + "\r\n";
    byte[] arrayOfByte = ASCIIUtility.getBytes(paramString);
    try {
      this.serverOutput.write(arrayOfByte);
      this.serverOutput.flush();
      return;
    } catch (IOException iOException) {
      throw new MessagingException("Can't send command to SMTP host", iOException);
    } 
  }
  
  private int readServerResponse() {
    String str = "";
    int i = 0;
    StringBuffer stringBuffer = new StringBuffer(100);
    try {
      String str1 = null;
      do {
        str1 = this.lineInputStream.readLine();
        if (str1 == null)
          return -1; 
        stringBuffer.append(str1);
        stringBuffer.append("\n");
      } while (isNotLastLine(str1));
      str = stringBuffer.toString();
    } catch (IOException iOException) {
      i = -1;
    } 
    if (this.debug)
      System.out.println("DEBUG SMTP RCVD: " + str); 
    if (i != -1 && str != null && 
      str.length() >= 3) {
      try {
        i = Integer.parseInt(str.substring(0, 3));
      } catch (NumberFormatException numberFormatException) {
        try {
          close();
        } catch (MessagingException messagingException) {
          if (this.debug)
            messagingException.printStackTrace(); 
        } 
        i = -1;
      } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
        try {
          close();
        } catch (MessagingException messagingException) {
          if (this.debug)
            messagingException.printStackTrace(); 
        } 
        i = -1;
      } 
    } else {
      i = -1;
    } 
    this.lastServerResponse = str;
    return i;
  }
  
  private void checkConnected() throws MessagingException {
    if (!super.isConnected())
      throw new IllegalStateException("Not connected"); 
  }
  
  private boolean isNotLastLine(String paramString) {
    if (paramString != null && paramString.length() > 4)
      return !(paramString.charAt(3) != '-'); 
    return false;
  }
  
  private String normalizeAddress(String paramString) {
    if (!paramString.startsWith("<") && !paramString.endsWith(">"))
      return "<" + paramString + ">"; 
    return paramString;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\smtp\SMTPTransport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */