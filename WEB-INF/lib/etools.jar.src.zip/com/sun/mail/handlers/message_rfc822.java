/*     */ package com.sun.mail.handlers;
/*     */ 
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import javax.activation.ActivationDataFlavor;
/*     */ import javax.activation.DataContentHandler;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.MessageAware;
/*     */ import javax.mail.MessageContext;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class message_rfc822
/*     */   implements DataContentHandler
/*     */ {
/*  37 */   ActivationDataFlavor ourDataFlavor = new ActivationDataFlavor(Message.class, 
/*     */       
/*  39 */       "message/rfc822", 
/*  40 */       "Message");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public DataFlavor[] getTransferDataFlavors() { return new DataFlavor[] { this.ourDataFlavor }; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource) {
/*  58 */     if (this.ourDataFlavor.equals(paramDataFlavor)) {
/*  59 */       return getContent(paramDataSource);
/*     */     }
/*     */ 
/*     */     
/*  63 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getContent(DataSource paramDataSource) {
/*     */     try {
/*     */       Session session;
/*  73 */       if (paramDataSource instanceof MessageAware) {
/*  74 */         MessageContext messageContext = ((MessageAware)paramDataSource).getMessageContext();
/*  75 */         session = messageContext.getSession();
/*     */       } else {
/*  77 */         session = Session.getDefaultInstance(null, null);
/*  78 */       }  return new MimeMessage(session, paramDataSource.getInputStream());
/*  79 */     } catch (IOException iOException) {
/*  80 */       iOException.printStackTrace();
/*  81 */     } catch (MessagingException messagingException) {
/*  82 */       messagingException.printStackTrace();
/*     */     } 
/*     */     
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream) throws IOException {
/*  96 */     if (paramObject instanceof Message) {
/*  97 */       Message message = (Message)paramObject;
/*     */       try {
/*  99 */         message.writeTo(paramOutputStream); return;
/* 100 */       } catch (MessagingException messagingException) {
/* 101 */         throw new IOException(messagingException.toString());
/*     */       } 
/*     */     } 
/*     */     
/* 105 */     throw new IOException("unsupported object");
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\handlers\message_rfc822.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */