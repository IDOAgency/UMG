package com.sun.mail.handlers;

import java.awt.datatransfer.DataFlavor;
import java.io.IOException;
import java.io.OutputStream;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.Message;
import javax.mail.MessageAware;
import javax.mail.MessageContext;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;

public class message_rfc822 implements DataContentHandler {
  ActivationDataFlavor ourDataFlavor = new ActivationDataFlavor(Message.class, 
      
      "message/rfc822", 
      "Message");
  
  public DataFlavor[] getTransferDataFlavors() { return new DataFlavor[] { this.ourDataFlavor }; }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource) {
    if (this.ourDataFlavor.equals(paramDataFlavor))
      return getContent(paramDataSource); 
    return null;
  }
  
  public Object getContent(DataSource paramDataSource) {
    try {
      Session session;
      if (paramDataSource instanceof MessageAware) {
        MessageContext messageContext = ((MessageAware)paramDataSource).getMessageContext();
        session = messageContext.getSession();
      } else {
        session = Session.getDefaultInstance(null, null);
      } 
      return new MimeMessage(session, paramDataSource.getInputStream());
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } catch (MessagingException messagingException) {
      messagingException.printStackTrace();
    } 
    return null;
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream) throws IOException {
    if (paramObject instanceof Message) {
      Message message = (Message)paramObject;
      try {
        message.writeTo(paramOutputStream);
        return;
      } catch (MessagingException messagingException) {
        throw new IOException(messagingException.toString());
      } 
    } 
    throw new IOException("unsupported object");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\handlers\message_rfc822.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */