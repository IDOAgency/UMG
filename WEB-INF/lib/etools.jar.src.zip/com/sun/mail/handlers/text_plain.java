package com.sun.mail.handlers;

import java.awt.datatransfer.DataFlavor;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeUtility;

public class text_plain implements DataContentHandler {
  private static ActivationDataFlavor myDF = new ActivationDataFlavor(String.class, 
      
      "text/plain", 
      "Text String");
  
  public DataFlavor[] getTransferDataFlavors() { return new DataFlavor[] { myDF }; }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource) throws IOException {
    if (myDF.equals(paramDataFlavor))
      return getContent(paramDataSource); 
    return null;
  }
  
  public Object getContent(DataSource paramDataSource) throws IOException {
    String str = null;
    InputStreamReader inputStreamReader = null;
    try {
      str = getCharset(paramDataSource.getContentType());
      inputStreamReader = new InputStreamReader(paramDataSource.getInputStream(), str);
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new UnsupportedEncodingException(str);
    } 
    int i = 0;
    char[] arrayOfChar = new char[1024];
    int j;
    while ((j = inputStreamReader.read(arrayOfChar, i, 1024)) != -1) {
      i += j;
      char[] arrayOfChar1 = new char[i + 1024];
      System.arraycopy(arrayOfChar, 0, arrayOfChar1, 0, i);
      arrayOfChar = arrayOfChar1;
    } 
    return new String(arrayOfChar, 0, i);
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream) throws IOException {
    if (!(paramObject instanceof String))
      throw new IOException(
          "\"text/plain\" DataContentHandler requires String object, was given object of type " + 
          paramObject.getClass().toString()); 
    String str1 = null;
    OutputStreamWriter outputStreamWriter = null;
    try {
      str1 = getCharset(paramString);
      outputStreamWriter = new OutputStreamWriter(paramOutputStream, str1);
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new UnsupportedEncodingException(str1);
    } 
    String str2 = (String)paramObject;
    outputStreamWriter.write(str2, 0, str2.length());
    outputStreamWriter.flush();
  }
  
  private String getCharset(String paramString) {
    try {
      ContentType contentType = new ContentType(paramString);
      String str = contentType.getParameter("charset");
      if (str == null)
        str = "us-ascii"; 
      return MimeUtility.javaCharset(str);
    } catch (Exception exception) {
      return null;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\handlers\text_plain.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */