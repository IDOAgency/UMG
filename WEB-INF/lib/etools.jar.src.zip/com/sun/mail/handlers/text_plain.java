/*     */ package com.sun.mail.handlers;
/*     */ 
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.activation.ActivationDataFlavor;
/*     */ import javax.activation.DataContentHandler;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class text_plain
/*     */   implements DataContentHandler
/*     */ {
/*  33 */   private static ActivationDataFlavor myDF = new ActivationDataFlavor(String.class, 
/*     */       
/*  35 */       "text/plain", 
/*  36 */       "Text String");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   public DataFlavor[] getTransferDataFlavors() { return new DataFlavor[] { myDF }; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource) throws IOException {
/*  58 */     if (myDF.equals(paramDataFlavor)) {
/*  59 */       return getContent(paramDataSource);
/*     */     }
/*  61 */     return null;
/*     */   }
/*     */   
/*     */   public Object getContent(DataSource paramDataSource) throws IOException {
/*  65 */     String str = null;
/*  66 */     InputStreamReader inputStreamReader = null;
/*     */     
/*     */     try {
/*  69 */       str = getCharset(paramDataSource.getContentType());
/*  70 */       inputStreamReader = new InputStreamReader(paramDataSource.getInputStream(), str);
/*  71 */     } catch (IllegalArgumentException illegalArgumentException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  79 */       throw new UnsupportedEncodingException(str);
/*     */     } 
/*     */     
/*  82 */     int i = 0;
/*     */     
/*  84 */     char[] arrayOfChar = new char[1024];
/*     */     int j;
/*  86 */     while ((j = inputStreamReader.read(arrayOfChar, i, 1024)) != -1) {
/*  87 */       i += j;
/*  88 */       char[] arrayOfChar1 = new char[i + 1024];
/*  89 */       System.arraycopy(arrayOfChar, 0, arrayOfChar1, 0, i);
/*  90 */       arrayOfChar = arrayOfChar1;
/*     */     } 
/*  92 */     return new String(arrayOfChar, 0, i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream) throws IOException {
/* 100 */     if (!(paramObject instanceof String)) {
/* 101 */       throw new IOException(
/* 102 */           "\"text/plain\" DataContentHandler requires String object, was given object of type " + 
/* 103 */           paramObject.getClass().toString());
/*     */     }
/* 105 */     String str1 = null;
/* 106 */     OutputStreamWriter outputStreamWriter = null;
/*     */     
/*     */     try {
/* 109 */       str1 = getCharset(paramString);
/* 110 */       outputStreamWriter = new OutputStreamWriter(paramOutputStream, str1);
/* 111 */     } catch (IllegalArgumentException illegalArgumentException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 119 */       throw new UnsupportedEncodingException(str1);
/*     */     } 
/*     */     
/* 122 */     String str2 = (String)paramObject;
/* 123 */     outputStreamWriter.write(str2, 0, str2.length());
/* 124 */     outputStreamWriter.flush();
/*     */   }
/*     */   
/*     */   private String getCharset(String paramString) {
/*     */     try {
/* 129 */       ContentType contentType = new ContentType(paramString);
/* 130 */       String str = contentType.getParameter("charset");
/* 131 */       if (str == null)
/*     */       {
/* 133 */         str = "us-ascii"; } 
/* 134 */       return MimeUtility.javaCharset(str);
/* 135 */     } catch (Exception exception) {
/* 136 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\handlers\text_plain.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */