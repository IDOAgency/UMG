/*    */ package com.sun.mail.handlers;
/*    */ 
/*    */ import java.awt.datatransfer.DataFlavor;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import javax.activation.ActivationDataFlavor;
/*    */ import javax.activation.DataContentHandler;
/*    */ import javax.activation.DataSource;
/*    */ import javax.mail.MessagingException;
/*    */ import javax.mail.internet.MimeMultipart;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class multipart_mixed
/*    */   implements DataContentHandler
/*    */ {
/* 30 */   private ActivationDataFlavor myDF = new ActivationDataFlavor(MimeMultipart.class, 
/*    */       
/* 32 */       "multipart/mixed", 
/* 33 */       "Multipart");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public DataFlavor[] getTransferDataFlavors() { return new DataFlavor[] { this.myDF }; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource) {
/* 54 */     if (this.myDF.equals(paramDataFlavor)) {
/* 55 */       return getContent(paramDataSource);
/*    */     }
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getContent(DataSource paramDataSource) {
/*    */     try {
/* 65 */       return new MimeMultipart(paramDataSource);
/* 66 */     } catch (MessagingException messagingException) {
/* 67 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream) throws IOException {
/* 76 */     if (paramObject instanceof MimeMultipart)
/*    */       try {
/* 78 */         ((MimeMultipart)paramObject).writeTo(paramOutputStream); return;
/* 79 */       } catch (MessagingException messagingException) {
/* 80 */         throw new IOException(messagingException.toString());
/*    */       }  
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\handlers\multipart_mixed.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */