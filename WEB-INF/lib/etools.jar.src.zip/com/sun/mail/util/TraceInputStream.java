package com.sun.mail.util;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class TraceInputStream extends FilterInputStream {
  private boolean trace;
  
  private OutputStream traceOut;
  
  public TraceInputStream(InputStream paramInputStream, OutputStream paramOutputStream) {
    super(paramInputStream);
    this.traceOut = paramOutputStream;
  }
  
  public void setTrace(boolean paramBoolean) { this.trace = paramBoolean; }
  
  public int read() throws IOException {
    int i = this.in.read();
    if (this.trace && i != -1)
      this.traceOut.write(i); 
    return i;
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
    int i = this.in.read(paramArrayOfByte, paramInt1, paramInt2);
    if (this.trace && i != -1)
      this.traceOut.write(paramArrayOfByte, paramInt1, i); 
    return i;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\TraceInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */