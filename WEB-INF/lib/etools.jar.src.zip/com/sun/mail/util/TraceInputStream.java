/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.FilterInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TraceInputStream
/*    */   extends FilterInputStream
/*    */ {
/*    */   private boolean trace;
/*    */   private OutputStream traceOut;
/*    */   
/*    */   public TraceInputStream(InputStream paramInputStream, OutputStream paramOutputStream) {
/* 33 */     super(paramInputStream);
/* 34 */     this.traceOut = paramOutputStream;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   public void setTrace(boolean paramBoolean) { this.trace = paramBoolean; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int read() throws IOException {
/* 51 */     int i = this.in.read();
/* 52 */     if (this.trace && i != -1)
/* 53 */       this.traceOut.write(i); 
/* 54 */     return i;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/* 64 */     int i = this.in.read(paramArrayOfByte, paramInt1, paramInt2);
/* 65 */     if (this.trace && i != -1)
/* 66 */       this.traceOut.write(paramArrayOfByte, paramInt1, i); 
/* 67 */     return i;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\TraceInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */