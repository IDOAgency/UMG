/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.mail.MessagingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LineOutputStream
/*    */   extends FilterOutputStream
/*    */ {
/* 28 */   private static byte[] newline = new byte[2]; static  {
/* 29 */     newline[0] = 13;
/* 30 */     newline[1] = 10;
/*    */   }
/*    */ 
/*    */   
/* 34 */   public LineOutputStream(OutputStream paramOutputStream) { super(paramOutputStream); }
/*    */ 
/*    */   
/*    */   public void writeln(String paramString) throws MessagingException {
/*    */     try {
/* 39 */       byte[] arrayOfByte = ASCIIUtility.getBytes(paramString);
/* 40 */       this.out.write(arrayOfByte);
/* 41 */       this.out.write(newline); return;
/* 42 */     } catch (Exception exception) {
/* 43 */       throw new MessagingException("IOException", exception);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void writeln() throws MessagingException {
/*    */     try {
/* 49 */       this.out.write(newline); return;
/* 50 */     } catch (Exception exception) {
/* 51 */       throw new MessagingException("IOException", exception);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\LineOutputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */