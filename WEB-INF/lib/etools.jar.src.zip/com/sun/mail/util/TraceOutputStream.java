package com.sun.mail.util;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class TraceOutputStream extends FilterOutputStream {
  private boolean trace;
  
  private OutputStream traceOut;
  
  public TraceOutputStream(OutputStream paramOutputStream1, OutputStream paramOutputStream2) {
    super(paramOutputStream1);
    this.traceOut = paramOutputStream2;
  }
  
  public void setTrace(boolean paramBoolean) { this.trace = paramBoolean; }
  
  public void write(int paramInt) throws IOException {
    if (this.trace)
      this.traceOut.write(paramInt); 
    this.out.write(paramInt);
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
    if (this.trace)
      this.traceOut.write(paramArrayOfByte, paramInt1, paramInt2); 
    this.out.write(paramArrayOfByte, paramInt1, paramInt2);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\TraceOutputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */