/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QPDecoderStream
/*     */   extends FilterInputStream
/*     */ {
/*  22 */   protected byte[] ba = new byte[2];
/*     */ 
/*     */ 
/*     */   
/*     */   protected int spaces;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  31 */   public QPDecoderStream(InputStream paramInputStream) { super(new PushbackInputStream(paramInputStream, 2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*  47 */     if (this.spaces > 0) {
/*     */       
/*  49 */       this.spaces--;
/*  50 */       return 32;
/*     */     } 
/*     */     
/*  53 */     int i = this.in.read();
/*     */     
/*  55 */     if (i == 32) {
/*     */       
/*  57 */       while ((i = this.in.read()) == 32) {
/*  58 */         this.spaces++;
/*     */       }
/*  60 */       if (i == 13 || i == 10 || i == -1) {
/*     */ 
/*     */         
/*  63 */         this.spaces = 0;
/*     */       } else {
/*     */         
/*  66 */         ((PushbackInputStream)this.in).unread(i);
/*  67 */         i = 32;
/*     */       } 
/*  69 */       return i;
/*     */     } 
/*  71 */     if (i == 61) {
/*     */       
/*  73 */       int j = this.in.read();
/*     */       
/*  75 */       if (j == 10)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  81 */         return read(); } 
/*  82 */       if (j == 13) {
/*     */         
/*  84 */         int k = this.in.read();
/*  85 */         if (k != 10)
/*     */         {
/*     */ 
/*     */           
/*  89 */           ((PushbackInputStream)this.in).unread(k); } 
/*  90 */         return read();
/*  91 */       }  if (j == -1)
/*     */       {
/*  93 */         return -1;
/*     */       }
/*  95 */       this.ba[0] = (byte)j;
/*  96 */       this.ba[1] = (byte)this.in.read();
/*     */       try {
/*  98 */         return ASCIIUtility.parseInt(this.ba, 0, 2, 16);
/*  99 */       } catch (NumberFormatException numberFormatException) {
/* 100 */         System.err.println(
/* 101 */             "Illegal characters in QP encoded stream: " + 
/* 102 */             ASCIIUtility.toString(this.ba, 0, 2));
/*     */ 
/*     */         
/* 105 */         ((PushbackInputStream)this.in).unread(this.ba);
/* 106 */         return i;
/*     */       } 
/*     */     } 
/*     */     
/* 110 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/*     */     byte b;
/*     */     
/* 130 */     try { for (b = 0; b < paramInt2; b++) {
/* 131 */         int i; if ((i = read()) == -1) {
/* 132 */           if (!b)
/* 133 */             b = -1; 
/*     */           break;
/*     */         } 
/* 136 */         paramArrayOfByte[paramInt1 + b] = (byte)i;
/*     */       }  }
/* 138 */     catch (IOException iOException) { b = -1; }
/* 139 */      return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public boolean markSupported() { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   public int available() throws IOException { return this.in.available(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\QPDecoderStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */