/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UUEncoderStream
/*     */   extends FilterOutputStream
/*     */ {
/*     */   private byte[] buffer;
/*     */   private int bufsize;
/*     */   private boolean wrotePrefix = false;
/*     */   protected String name;
/*     */   protected int mode;
/*     */   
/*  34 */   public UUEncoderStream(OutputStream paramOutputStream) { this(paramOutputStream, "encoder.buf", 644); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   public UUEncoderStream(OutputStream paramOutputStream, String paramString) { this(paramOutputStream, paramString, 644); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UUEncoderStream(OutputStream paramOutputStream, String paramString, int paramInt) {
/*  53 */     super(paramOutputStream);
/*  54 */     this.name = paramString;
/*  55 */     this.mode = paramInt;
/*  56 */     this.buffer = new byte[45];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNameMode(String paramString, int paramInt) {
/*  65 */     this.name = paramString;
/*  66 */     this.mode = paramInt;
/*     */   }
/*     */   
/*     */   public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/*  70 */     for (int i = 0; i < paramInt2; i++) {
/*  71 */       write(paramArrayOfByte[paramInt1 + i]);
/*     */     }
/*     */   }
/*     */   
/*  75 */   public void write(byte[] paramArrayOfByte) throws IOException { write(paramArrayOfByte, 0, paramArrayOfByte.length); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int paramInt) throws IOException {
/*  83 */     this.buffer[this.bufsize++] = (byte)paramInt;
/*  84 */     if (this.bufsize == 45) {
/*  85 */       writePrefix();
/*  86 */       encode();
/*  87 */       this.bufsize = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/*  92 */     if (this.bufsize > 0) {
/*  93 */       writePrefix();
/*  94 */       encode();
/*     */     } 
/*  96 */     writeSuffix();
/*  97 */     this.out.flush();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 101 */     flush();
/* 102 */     this.out.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writePrefix() throws IOException {
/* 109 */     if (!this.wrotePrefix) {
/* 110 */       PrintStream printStream = new PrintStream(this.out);
/* 111 */       printStream.println("begin " + this.mode + " " + this.name);
/* 112 */       printStream.flush();
/* 113 */       this.wrotePrefix = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeSuffix() throws IOException {
/* 122 */     PrintStream printStream = new PrintStream(this.out);
/* 123 */     printStream.println(" \nend");
/* 124 */     printStream.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void encode() throws IOException {
/* 139 */     byte b = 0;
/*     */ 
/*     */     
/* 142 */     this.out.write((this.bufsize & 0x3F) + 32);
/*     */     
/* 144 */     while (b < this.bufsize) {
/* 145 */       boolean bool2, bool1; byte b1 = this.buffer[b++];
/* 146 */       if (b < this.bufsize) {
/* 147 */         bool1 = this.buffer[b++];
/* 148 */         if (b < this.bufsize) {
/* 149 */           bool2 = this.buffer[b++];
/*     */         } else {
/* 151 */           bool2 = true;
/*     */         } 
/*     */       } else {
/* 154 */         bool1 = true;
/* 155 */         bool2 = true;
/*     */       } 
/*     */       
/* 158 */       byte b2 = b1 >>> 2 & 0x3F;
/* 159 */       byte b3 = b1 << 4 & 0x30 | bool1 >>> 4 & 0xF;
/* 160 */       byte b4 = bool1 << 2 & 0x3C | bool2 >>> 6 & 0x3;
/* 161 */       byte b5 = bool2 & 0x3F;
/* 162 */       this.out.write(b2 + 32);
/* 163 */       this.out.write(b3 + 32);
/* 164 */       this.out.write(b4 + 32);
/* 165 */       this.out.write(b5 + 32);
/*     */     } 
/*     */     
/* 168 */     this.out.write(10);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\UUEncoderStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */