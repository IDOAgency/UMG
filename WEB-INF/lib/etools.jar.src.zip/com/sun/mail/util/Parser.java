/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Parser
/*     */ {
/*     */   int index;
/*     */   char[] orig;
/*     */   
/* 400 */   public Parser(char[] paramArrayOfChar) { this.orig = paramArrayOfChar; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skipUntilNumber() throws ParseException {
/*     */     try {
/*     */       while (true) {
/* 412 */         switch (this.orig[this.index]) {
/*     */           case '0':
/*     */           case '1':
/*     */           case '2':
/*     */           case '3':
/*     */           case '4':
/*     */           case '5':
/*     */           case '6':
/*     */           case '7':
/*     */           case '8':
/*     */           case '9':
/*     */             return;
/*     */         } 
/*     */         
/* 426 */         this.index++;
/*     */       }
/*     */     
/*     */     }
/* 430 */     catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
/* 431 */       throw new ParseException("No Number Found", this.index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skipWhiteSpace() throws ParseException {
/* 439 */     int i = this.orig.length;
/* 440 */     while (this.index < i) {
/* 441 */       switch (this.orig[this.index]) {
/*     */         case '\t':
/*     */         case ' ':
/* 444 */           this.index++;
/*     */           continue;
/*     */       } 
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int peekChar() throws ParseException {
/* 459 */     if (this.index < this.orig.length) {
/* 460 */       return this.orig[this.index];
/*     */     }
/* 462 */     throw new ParseException("No more characters", this.index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skipChar(char paramChar) throws ParseException {
/* 470 */     if (this.index < this.orig.length) {
/* 471 */       if (this.orig[this.index] == paramChar) {
/* 472 */         this.index++; return;
/*     */       } 
/* 474 */       throw new ParseException("Wrong char", this.index);
/*     */     } 
/*     */     
/* 477 */     throw new ParseException("No more characters", this.index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean skipIfChar(char paramChar) throws ParseException {
/* 486 */     if (this.index < this.orig.length) {
/* 487 */       if (this.orig[this.index] == paramChar) {
/* 488 */         this.index++;
/* 489 */         return true;
/*     */       } 
/* 491 */       return false;
/*     */     } 
/*     */     
/* 494 */     throw new ParseException("No more characters", this.index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int parseNumber() throws ParseException {
/* 505 */     int i = this.orig.length;
/* 506 */     boolean bool = false;
/* 507 */     byte b = 0;
/*     */     
/* 509 */     while (this.index < i) {
/* 510 */       switch (this.orig[this.index]) {
/*     */         case '0':
/* 512 */           b *= 10;
/* 513 */           bool = true;
/*     */           break;
/*     */         
/*     */         case '1':
/* 517 */           b = b * 10 + 1;
/* 518 */           bool = true;
/*     */           break;
/*     */         
/*     */         case '2':
/* 522 */           b = b * 10 + 2;
/* 523 */           bool = true;
/*     */           break;
/*     */         
/*     */         case '3':
/* 527 */           b = b * 10 + 3;
/* 528 */           bool = true;
/*     */           break;
/*     */         
/*     */         case '4':
/* 532 */           b = b * 10 + 4;
/* 533 */           bool = true;
/*     */           break;
/*     */         
/*     */         case '5':
/* 537 */           b = b * 10 + 5;
/* 538 */           bool = true;
/*     */           break;
/*     */         
/*     */         case '6':
/* 542 */           b = b * 10 + 6;
/* 543 */           bool = true;
/*     */           break;
/*     */         
/*     */         case '7':
/* 547 */           b = b * 10 + 7;
/* 548 */           bool = true;
/*     */           break;
/*     */         
/*     */         case '8':
/* 552 */           b = b * 10 + 8;
/* 553 */           bool = true;
/*     */           break;
/*     */         
/*     */         case '9':
/* 557 */           b = b * 10 + 9;
/* 558 */           bool = true;
/*     */           break;
/*     */         
/*     */         default:
/* 562 */           if (bool) {
/* 563 */             return b;
/*     */           }
/* 565 */           throw new ParseException("No Number found", this.index);
/*     */       } 
/*     */       
/* 568 */       this.index++;
/*     */     } 
/*     */ 
/*     */     
/* 572 */     if (bool) {
/* 573 */       return b;
/*     */     }
/*     */     
/* 576 */     throw new ParseException("No Number found", this.index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int parseMonth() throws ParseException {
/*     */     try {
/*     */       char c;
/* 589 */       switch (this.orig[this.index++]) {
/*     */         
/*     */         case 'J':
/*     */         case 'j':
/* 593 */           switch (this.orig[this.index++]) {
/*     */             case 'A':
/*     */             case 'a':
/* 596 */               c = this.orig[this.index++];
/* 597 */               if (c == 'N' || c == 'n') {
/* 598 */                 return 0;
/*     */               }
/*     */               break;
/*     */             
/*     */             case 'U':
/*     */             case 'u':
/* 604 */               c = this.orig[this.index++];
/* 605 */               if (c == 'N' || c == 'n')
/* 606 */                 return 5; 
/* 607 */               if (c == 'L' || c == 'l') {
/* 608 */                 return 6;
/*     */               }
/*     */               break;
/*     */           } 
/*     */           
/*     */           break;
/*     */         case 'F':
/*     */         case 'f':
/* 616 */           c = this.orig[this.index++];
/* 617 */           if (c == 'E' || c == 'e') {
/* 618 */             c = this.orig[this.index++];
/* 619 */             if (c == 'B' || c == 'b') {
/* 620 */               return 1;
/*     */             }
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'M':
/*     */         case 'm':
/* 627 */           c = this.orig[this.index++];
/* 628 */           if (c == 'A' || c == 'a') {
/* 629 */             c = this.orig[this.index++];
/* 630 */             if (c == 'R' || c == 'r')
/* 631 */               return 2; 
/* 632 */             if (c == 'Y' || c == 'y') {
/* 633 */               return 4;
/*     */             }
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'A':
/*     */         case 'a':
/* 640 */           c = this.orig[this.index++];
/* 641 */           if (c == 'P' || c == 'p') {
/* 642 */             c = this.orig[this.index++];
/* 643 */             if (c == 'R' || c == 'r')
/* 644 */               return 3;  break;
/*     */           } 
/* 646 */           if (c == 'U' || c == 'u') {
/* 647 */             c = this.orig[this.index++];
/* 648 */             if (c == 'G' || c == 'g') {
/* 649 */               return 7;
/*     */             }
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'S':
/*     */         case 's':
/* 656 */           c = this.orig[this.index++];
/* 657 */           if (c == 'E' || c == 'e') {
/* 658 */             c = this.orig[this.index++];
/* 659 */             if (c == 'P' || c == 'p') {
/* 660 */               return 8;
/*     */             }
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'O':
/*     */         case 'o':
/* 667 */           c = this.orig[this.index++];
/* 668 */           if (c == 'C' || c == 'c') {
/* 669 */             c = this.orig[this.index++];
/* 670 */             if (c == 'T' || c == 't') {
/* 671 */               return 9;
/*     */             }
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'N':
/*     */         case 'n':
/* 678 */           c = this.orig[this.index++];
/* 679 */           if (c == 'O' || c == 'o') {
/* 680 */             c = this.orig[this.index++];
/* 681 */             if (c == 'V' || c == 'v') {
/* 682 */               return 10;
/*     */             }
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'D':
/*     */         case 'd':
/* 689 */           c = this.orig[this.index++];
/* 690 */           if (c == 'E' || c == 'e') {
/* 691 */             c = this.orig[this.index++];
/* 692 */             if (c == 'C' || c == 'c') {
/* 693 */               return 11;
/*     */             }
/*     */           } 
/*     */           break;
/*     */       } 
/* 698 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
/*     */ 
/*     */     
/* 701 */     throw new ParseException("Bad Month", this.index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int parseTimeZone() throws ParseException {
/* 710 */     if (this.index >= this.orig.length) {
/* 711 */       throw new ParseException("No more characters", this.index);
/*     */     }
/* 713 */     char c = this.orig[this.index];
/* 714 */     if (c == '+' || c == '-') {
/* 715 */       return parseNumericTimeZone();
/*     */     }
/* 717 */     return parseAlphaTimeZone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int parseNumericTimeZone() throws ParseException {
/* 733 */     boolean bool = false;
/* 734 */     char c = this.orig[this.index++];
/* 735 */     if (c == '+') {
/* 736 */       bool = true;
/* 737 */     } else if (c != '-') {
/* 738 */       throw new ParseException("Bad Numeric TimeZone", this.index);
/*     */     } 
/*     */     
/* 741 */     int i = parseNumber();
/* 742 */     int j = i / 100 * 60 + i % 100;
/* 743 */     if (bool) {
/* 744 */       return -j;
/*     */     }
/* 746 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int parseAlphaTimeZone() throws ParseException {
/* 756 */     char c = Character.MIN_VALUE;
/* 757 */     boolean bool = false;
/*     */     
/*     */     try {
/*     */       char c1;
/* 761 */       switch (this.orig[this.index++]) {
/*     */         case 'U':
/*     */         case 'u':
/* 764 */           c1 = this.orig[this.index++];
/* 765 */           if (c1 == 'T' || c1 == 't') {
/* 766 */             c = Character.MIN_VALUE;
/*     */             break;
/*     */           } 
/* 769 */           throw new ParseException("Bad Alpha TimeZone", this.index);
/*     */         
/*     */         case 'G':
/*     */         case 'g':
/* 773 */           c1 = this.orig[this.index++];
/* 774 */           if (c1 == 'M' || c1 == 'm') {
/* 775 */             c1 = this.orig[this.index++];
/* 776 */             if (c1 == 'T' || c1 == 't') {
/* 777 */               c = Character.MIN_VALUE;
/*     */               break;
/*     */             } 
/*     */           } 
/* 781 */           throw new ParseException("Bad Alpha TimeZone", this.index);
/*     */         
/*     */         case 'E':
/*     */         case 'e':
/* 785 */           c = 'Ĭ';
/* 786 */           bool = true;
/*     */           break;
/*     */         
/*     */         case 'C':
/*     */         case 'c':
/* 791 */           c = 'Ũ';
/* 792 */           bool = true;
/*     */           break;
/*     */         
/*     */         case 'M':
/*     */         case 'm':
/* 797 */           c = 'Ƥ';
/* 798 */           bool = true;
/*     */           break;
/*     */         
/*     */         case 'P':
/*     */         case 'p':
/* 803 */           c = 'Ǡ';
/* 804 */           bool = true;
/*     */           break;
/*     */         
/*     */         default:
/* 808 */           throw new ParseException("Bad Alpha TimeZone", this.index);
/*     */       } 
/* 810 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
/* 811 */       throw new ParseException("Bad Alpha TimeZone", this.index);
/*     */     } 
/*     */     
/* 814 */     if (bool) {
/* 815 */       char c1 = this.orig[this.index++];
/* 816 */       if (c1 == 'S' || c1 == 's') {
/* 817 */         c1 = this.orig[this.index++];
/* 818 */         if (c1 != 'T' && c1 != 't') {
/* 819 */           throw new ParseException("Bad Alpha TimeZone", this.index);
/*     */         }
/* 821 */       } else if (c1 == 'D' || c1 == 'd') {
/* 822 */         c1 = this.orig[this.index++];
/* 823 */         if (c1 == 'T' || c1 != 't') {
/*     */           
/* 825 */           c -= '<';
/*     */         } else {
/* 827 */           throw new ParseException("Bad Alpha TimeZone", this.index);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 832 */     return c;
/*     */   }
/*     */ 
/*     */   
/* 836 */   int getIndex() throws ParseException { return this.index; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\Parser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */