package com.sun.mail.util;

import java.text.ParseException;

class Parser {
  int index;
  
  char[] orig;
  
  public Parser(char[] paramArrayOfChar) { this.orig = paramArrayOfChar; }
  
  public void skipUntilNumber() throws ParseException {
    try {
      while (true) {
        switch (this.orig[this.index]) {
          case '0':
          case '1':
          case '2':
          case '3':
          case '4':
          case '5':
          case '6':
          case '7':
          case '8':
          case '9':
            return;
        } 
        this.index++;
      } 
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      throw new ParseException("No Number Found", this.index);
    } 
  }
  
  public void skipWhiteSpace() throws ParseException {
    int i = this.orig.length;
    while (this.index < i) {
      switch (this.orig[this.index]) {
        case '\t':
        case ' ':
          this.index++;
          continue;
      } 
      return;
    } 
  }
  
  public int peekChar() throws ParseException {
    if (this.index < this.orig.length)
      return this.orig[this.index]; 
    throw new ParseException("No more characters", this.index);
  }
  
  public void skipChar(char paramChar) throws ParseException {
    if (this.index < this.orig.length) {
      if (this.orig[this.index] == paramChar) {
        this.index++;
        return;
      } 
      throw new ParseException("Wrong char", this.index);
    } 
    throw new ParseException("No more characters", this.index);
  }
  
  public boolean skipIfChar(char paramChar) throws ParseException {
    if (this.index < this.orig.length) {
      if (this.orig[this.index] == paramChar) {
        this.index++;
        return true;
      } 
      return false;
    } 
    throw new ParseException("No more characters", this.index);
  }
  
  public int parseNumber() throws ParseException {
    int i = this.orig.length;
    boolean bool = false;
    byte b = 0;
    while (this.index < i) {
      switch (this.orig[this.index]) {
        case '0':
          b *= 10;
          bool = true;
          break;
        case '1':
          b = b * 10 + 1;
          bool = true;
          break;
        case '2':
          b = b * 10 + 2;
          bool = true;
          break;
        case '3':
          b = b * 10 + 3;
          bool = true;
          break;
        case '4':
          b = b * 10 + 4;
          bool = true;
          break;
        case '5':
          b = b * 10 + 5;
          bool = true;
          break;
        case '6':
          b = b * 10 + 6;
          bool = true;
          break;
        case '7':
          b = b * 10 + 7;
          bool = true;
          break;
        case '8':
          b = b * 10 + 8;
          bool = true;
          break;
        case '9':
          b = b * 10 + 9;
          bool = true;
          break;
        default:
          if (bool)
            return b; 
          throw new ParseException("No Number found", this.index);
      } 
      this.index++;
    } 
    if (bool)
      return b; 
    throw new ParseException("No Number found", this.index);
  }
  
  public int parseMonth() throws ParseException {
    try {
      char c;
      switch (this.orig[this.index++]) {
        case 'J':
        case 'j':
          switch (this.orig[this.index++]) {
            case 'A':
            case 'a':
              c = this.orig[this.index++];
              if (c == 'N' || c == 'n')
                return 0; 
              break;
            case 'U':
            case 'u':
              c = this.orig[this.index++];
              if (c == 'N' || c == 'n')
                return 5; 
              if (c == 'L' || c == 'l')
                return 6; 
              break;
          } 
          break;
        case 'F':
        case 'f':
          c = this.orig[this.index++];
          if (c == 'E' || c == 'e') {
            c = this.orig[this.index++];
            if (c == 'B' || c == 'b')
              return 1; 
          } 
          break;
        case 'M':
        case 'm':
          c = this.orig[this.index++];
          if (c == 'A' || c == 'a') {
            c = this.orig[this.index++];
            if (c == 'R' || c == 'r')
              return 2; 
            if (c == 'Y' || c == 'y')
              return 4; 
          } 
          break;
        case 'A':
        case 'a':
          c = this.orig[this.index++];
          if (c == 'P' || c == 'p') {
            c = this.orig[this.index++];
            if (c == 'R' || c == 'r')
              return 3; 
            break;
          } 
          if (c == 'U' || c == 'u') {
            c = this.orig[this.index++];
            if (c == 'G' || c == 'g')
              return 7; 
          } 
          break;
        case 'S':
        case 's':
          c = this.orig[this.index++];
          if (c == 'E' || c == 'e') {
            c = this.orig[this.index++];
            if (c == 'P' || c == 'p')
              return 8; 
          } 
          break;
        case 'O':
        case 'o':
          c = this.orig[this.index++];
          if (c == 'C' || c == 'c') {
            c = this.orig[this.index++];
            if (c == 'T' || c == 't')
              return 9; 
          } 
          break;
        case 'N':
        case 'n':
          c = this.orig[this.index++];
          if (c == 'O' || c == 'o') {
            c = this.orig[this.index++];
            if (c == 'V' || c == 'v')
              return 10; 
          } 
          break;
        case 'D':
        case 'd':
          c = this.orig[this.index++];
          if (c == 'E' || c == 'e') {
            c = this.orig[this.index++];
            if (c == 'C' || c == 'c')
              return 11; 
          } 
          break;
      } 
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
    throw new ParseException("Bad Month", this.index);
  }
  
  public int parseTimeZone() throws ParseException {
    if (this.index >= this.orig.length)
      throw new ParseException("No more characters", this.index); 
    char c = this.orig[this.index];
    if (c == '+' || c == '-')
      return parseNumericTimeZone(); 
    return parseAlphaTimeZone();
  }
  
  public int parseNumericTimeZone() throws ParseException {
    boolean bool = false;
    char c = this.orig[this.index++];
    if (c == '+') {
      bool = true;
    } else if (c != '-') {
      throw new ParseException("Bad Numeric TimeZone", this.index);
    } 
    int i = parseNumber();
    int j = i / 100 * 60 + i % 100;
    if (bool)
      return -j; 
    return j;
  }
  
  public int parseAlphaTimeZone() throws ParseException {
    char c = Character.MIN_VALUE;
    boolean bool = false;
    try {
      char c1;
      switch (this.orig[this.index++]) {
        case 'U':
        case 'u':
          c1 = this.orig[this.index++];
          if (c1 == 'T' || c1 == 't') {
            c = Character.MIN_VALUE;
            break;
          } 
          throw new ParseException("Bad Alpha TimeZone", this.index);
        case 'G':
        case 'g':
          c1 = this.orig[this.index++];
          if (c1 == 'M' || c1 == 'm') {
            c1 = this.orig[this.index++];
            if (c1 == 'T' || c1 == 't') {
              c = Character.MIN_VALUE;
              break;
            } 
          } 
          throw new ParseException("Bad Alpha TimeZone", this.index);
        case 'E':
        case 'e':
          c = 'Ĭ';
          bool = true;
          break;
        case 'C':
        case 'c':
          c = 'Ũ';
          bool = true;
          break;
        case 'M':
        case 'm':
          c = 'Ƥ';
          bool = true;
          break;
        case 'P':
        case 'p':
          c = 'Ǡ';
          bool = true;
          break;
        default:
          throw new ParseException("Bad Alpha TimeZone", this.index);
      } 
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      throw new ParseException("Bad Alpha TimeZone", this.index);
    } 
    if (bool) {
      char c1 = this.orig[this.index++];
      if (c1 == 'S' || c1 == 's') {
        c1 = this.orig[this.index++];
        if (c1 != 'T' && c1 != 't')
          throw new ParseException("Bad Alpha TimeZone", this.index); 
      } else if (c1 == 'D' || c1 == 'd') {
        c1 = this.orig[this.index++];
        if (c1 == 'T' || c1 != 't') {
          c -= '<';
        } else {
          throw new ParseException("Bad Alpha TimeZone", this.index);
        } 
      } 
    } 
    return c;
  }
  
  int getIndex() throws ParseException { return this.index; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\Parser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */