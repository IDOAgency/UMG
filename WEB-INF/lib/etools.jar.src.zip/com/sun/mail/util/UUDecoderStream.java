/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UUDecoderStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   private String name;
/*     */   private int mode;
/*     */   private byte[] buffer;
/*     */   private int bufsize;
/*     */   private int index;
/*     */   private boolean gotPrefix = false;
/*     */   private byte[] decode_buffer;
/*     */   
/*     */   public UUDecoderStream(InputStream paramInputStream) {
/*  35 */     super(paramInputStream);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     this.decode_buffer = new byte[60];
/*     */     if (!(paramInputStream instanceof PushbackInputStream))
/*     */       paramInputStream = new PushbackInputStream(paramInputStream); 
/*     */     this.buffer = new byte[45]; } private void decode() throws IOException {
/* 159 */     this.bufsize = 0;
/* 160 */     int i = this.in.read();
/* 161 */     if (i == -1) {
/* 162 */       throw new IOException("Short buffer error");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     i = i - 32 & 0x3F;
/*     */ 
/*     */     
/* 172 */     int j = (i * 8 + 5) / 6, k = 0; int m;
/* 173 */     while ((m = this.in.read(this.decode_buffer, k, j)) != j) {
/* 174 */       if (m == -1)
/* 175 */         throw new IOException("Error in encoded stream"); 
/* 176 */       j -= m;
/* 177 */       k += m;
/*     */     } 
/*     */     
/* 180 */     int n = 0;
/*     */ 
/*     */ 
/*     */     
/* 184 */     while (this.bufsize < i) {
/*     */       
/* 186 */       byte b1 = (byte)(this.decode_buffer[n++] - 32 & 0x3F);
/* 187 */       byte b2 = (byte)(this.decode_buffer[n++] - 32 & 0x3F);
/* 188 */       this.buffer[this.bufsize++] = (byte)(b1 << 2 & 0xFC | b2 >>> 4 & 0x3);
/*     */       
/* 190 */       b1 = b2;
/* 191 */       b2 = (byte)(this.decode_buffer[n++] - 32 & 0x3F);
/* 192 */       this.buffer[this.bufsize++] = (byte)(b1 << 4 & 0xF0 | b2 >>> 2 & 0xF);
/*     */       
/* 194 */       b1 = b2;
/* 195 */       b2 = (byte)(this.decode_buffer[n++] - 32 & 0x3F);
/* 196 */       this.buffer[this.bufsize++] = (byte)(b1 << 6 & 0xC0 | b2 & 0x3F);
/*     */     } 
/* 198 */     this.bufsize = i;
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/*     */     
/* 204 */     } while ((n = this.in.read()) != 10 && n != 13);
/*     */     
/* 206 */     if (n == 13 && (
/* 207 */       n = this.in.read()) != 10)
/* 208 */       ((PushbackInputStream)this.in).unread(n); 
/*     */   }
/*     */   
/*     */   public int read() throws IOException {
/*     */     if (this.index >= this.bufsize) {
/*     */       readPrefix();
/*     */       decode();
/*     */       if (this.bufsize == 0) {
/*     */         readSuffix();
/*     */         return -1;
/*     */       } 
/*     */       this.index = 0;
/*     */     } 
/*     */     return this.buffer[this.index++] & 0xFF;
/*     */   }
/*     */   
/*     */   public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/*     */     byte b;
/*     */     try {
/*     */       for (b = 0; b < paramInt2; b++) {
/*     */         int i;
/*     */         if ((i = read()) == -1) {
/*     */           if (!b)
/*     */             b = -1; 
/*     */           break;
/*     */         } 
/*     */         paramArrayOfByte[paramInt1 + b] = (byte)i;
/*     */       } 
/*     */     } catch (IOException iOException) {
/*     */       b = -1;
/*     */     } 
/*     */     return b;
/*     */   }
/*     */   
/*     */   public boolean markSupported() { return false; }
/*     */   
/*     */   public int available() throws IOException { return this.in.available() * 3 / 4 + this.bufsize - this.index; }
/*     */   
/*     */   public String getName() throws IOException {
/*     */     readPrefix();
/*     */     return this.name;
/*     */   }
/*     */   
/*     */   public int getMode() throws IOException {
/*     */     readPrefix();
/*     */     return this.mode;
/*     */   }
/*     */   
/*     */   private void readPrefix() throws IOException {
/*     */     String str;
/*     */     if (this.gotPrefix)
/*     */       return; 
/*     */     DataInputStream dataInputStream = new DataInputStream(this.in);
/*     */     do {
/*     */       str = dataInputStream.readLine();
/*     */       if (str == null)
/*     */         throw new IOException("UUDecoder error: No Begin"); 
/*     */     } while (!str.regionMatches(true, 0, "begin", 0, 5));
/*     */     this.mode = Integer.parseInt(str.substring(6, 9));
/*     */     this.name = str.substring(10);
/*     */     this.gotPrefix = true;
/*     */   }
/*     */   
/*     */   private void readSuffix() throws IOException {
/*     */     DataInputStream dataInputStream = new DataInputStream(this.in);
/*     */     String str = dataInputStream.readLine();
/*     */     if (str == null || !str.regionMatches(true, 0, "end", 0, 3))
/*     */       throw new IOException("Missing End"); 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\UUDecoderStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */