/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QDecoderStream
/*    */   extends QPDecoderStream
/*    */ {
/* 26 */   public QDecoderStream(InputStream paramInputStream) { super(paramInputStream); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int read() throws IOException {
/* 42 */     int i = this.in.read();
/*    */     
/* 44 */     if (i == 95)
/* 45 */       return 32; 
/* 46 */     if (i == 61) {
/*    */       
/* 48 */       this.ba[0] = (byte)this.in.read();
/* 49 */       this.ba[1] = (byte)this.in.read();
/*    */       
/*    */       try {
/* 52 */         return ASCIIUtility.parseInt(this.ba, 0, 2, 16);
/* 53 */       } catch (NumberFormatException numberFormatException) {
/* 54 */         throw new IOException("Error in QP stream " + numberFormatException.getMessage());
/*    */       } 
/*    */     } 
/* 57 */     return i;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\QDecoderStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */