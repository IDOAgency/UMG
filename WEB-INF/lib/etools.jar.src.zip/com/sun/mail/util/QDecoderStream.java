package com.sun.mail.util;

import java.io.IOException;
import java.io.InputStream;

public class QDecoderStream extends QPDecoderStream {
  public QDecoderStream(InputStream paramInputStream) { super(paramInputStream); }
  
  public int read() throws IOException {
    int i = this.in.read();
    if (i == 95)
      return 32; 
    if (i == 61) {
      this.ba[0] = (byte)this.in.read();
      this.ba[1] = (byte)this.in.read();
      try {
        return ASCIIUtility.parseInt(this.ba, 0, 2, 16);
      } catch (NumberFormatException numberFormatException) {
        throw new IOException("Error in QP stream " + numberFormatException.getMessage());
      } 
    } 
    return i;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\QDecoderStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */