/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.FilterInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.PushbackInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LineInputStream
/*    */   extends FilterInputStream
/*    */ {
/*    */   private char[] lineBuffer;
/*    */   
/* 30 */   public LineInputStream(InputStream paramInputStream) { super(paramInputStream); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String readLine() throws IOException {
/* 43 */     InputStream inputStream = this.in;
/* 44 */     char[] arrayOfChar = this.lineBuffer;
/*    */     
/* 46 */     if (arrayOfChar == null) {
/* 47 */       arrayOfChar = this.lineBuffer = new char[128];
/*    */     }
/*    */     
/* 50 */     int j = arrayOfChar.length;
/* 51 */     int k = 0;
/*    */     int i;
/* 53 */     while ((i = inputStream.read()) != -1 && 
/* 54 */       i != 10) {
/*    */       
/* 56 */       if (i == 13) {
/*    */         
/* 58 */         int m = inputStream.read();
/* 59 */         if (m != 10) {
/*    */           
/* 61 */           if (!(inputStream instanceof PushbackInputStream))
/* 62 */             inputStream = this.in = new PushbackInputStream(inputStream); 
/* 63 */           ((PushbackInputStream)inputStream).unread(m);
/*    */         } 
/*    */ 
/*    */         
/*    */         break;
/*    */       } 
/*    */       
/* 70 */       if (--j < 0) {
/* 71 */         arrayOfChar = new char[k + ''];
/* 72 */         j = arrayOfChar.length - k - 1;
/* 73 */         System.arraycopy(this.lineBuffer, 0, arrayOfChar, 0, k);
/* 74 */         this.lineBuffer = arrayOfChar;
/*    */       } 
/* 76 */       arrayOfChar[k++] = (char)i;
/*    */     } 
/*    */     
/* 79 */     if (i == -1 && k == 0) {
/* 80 */       return null;
/*    */     }
/* 82 */     return String.copyValueOf(arrayOfChar, 0, k);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\LineInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */