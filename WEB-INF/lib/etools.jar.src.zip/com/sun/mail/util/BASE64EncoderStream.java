/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BASE64EncoderStream
/*     */   extends FilterOutputStream
/*     */ {
/*     */   private byte[] buffer;
/*     */   private int bufsize;
/*     */   private int count;
/*     */   private int bytesPerLine;
/*     */   
/*     */   public BASE64EncoderStream(OutputStream paramOutputStream, int paramInt) {
/*  34 */     super(paramOutputStream);
/*  35 */     this.buffer = new byte[3];
/*  36 */     this.bytesPerLine = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public BASE64EncoderStream(OutputStream paramOutputStream) { this(paramOutputStream, 76); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/*  59 */     for (int i = 0; i < paramInt2; i++) {
/*  60 */       write(paramArrayOfByte[paramInt1 + i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public void write(byte[] paramArrayOfByte) throws IOException { write(paramArrayOfByte, 0, paramArrayOfByte.length); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int paramInt) throws IOException {
/*  78 */     this.buffer[this.bufsize++] = (byte)paramInt;
/*  79 */     if (this.bufsize == 3) {
/*  80 */       encode();
/*  81 */       this.bufsize = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/*  91 */     if (this.bufsize > 0) {
/*  92 */       encode();
/*  93 */       this.bufsize = 0;
/*     */     } 
/*  95 */     this.out.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 103 */     flush();
/* 104 */     this.out.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private static final char[] pem_array = { 
/* 109 */       'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 
/* 110 */       'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 
/* 111 */       'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 
/* 112 */       'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 
/* 113 */       'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 
/* 114 */       'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
/* 115 */       'w', 'x', 'y', 'z', '0', '1', '2', '3', 
/* 116 */       '4', '5', '6', '7', '8', '9', '+', '/' };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void encode() throws IOException {
/* 122 */     if (this.count + 4 > this.bytesPerLine) {
/* 123 */       this.out.write(13);
/* 124 */       this.out.write(10);
/* 125 */       this.count = 0;
/*     */     } 
/*     */ 
/*     */     
/* 129 */     if (this.bufsize == 1) {
/* 130 */       byte b = this.buffer[0];
/* 131 */       boolean bool1 = false;
/* 132 */       boolean bool2 = false;
/* 133 */       this.out.write(pem_array[b >>> 2 & 0x3F]);
/* 134 */       this.out.write(pem_array[(b << 4 & 0x30) + (bool1 >>> 4 & 0xF)]);
/* 135 */       this.out.write(61);
/* 136 */       this.out.write(61);
/* 137 */     } else if (this.bufsize == 2) {
/* 138 */       byte b1 = this.buffer[0];
/* 139 */       byte b2 = this.buffer[1];
/* 140 */       boolean bool = false;
/* 141 */       this.out.write(pem_array[b1 >>> 2 & 0x3F]);
/* 142 */       this.out.write(pem_array[(b1 << 4 & 0x30) + (b2 >>> 4 & 0xF)]);
/* 143 */       this.out.write(pem_array[(b2 << 2 & 0x3C) + (bool >>> 6 & 0x3)]);
/* 144 */       this.out.write(61);
/*     */     } else {
/* 146 */       byte b1 = this.buffer[0];
/* 147 */       byte b2 = this.buffer[1];
/* 148 */       byte b3 = this.buffer[2];
/* 149 */       this.out.write(pem_array[b1 >>> 2 & 0x3F]);
/* 150 */       this.out.write(pem_array[(b1 << 4 & 0x30) + (b2 >>> 4 & 0xF)]);
/* 151 */       this.out.write(pem_array[(b2 << 2 & 0x3C) + (b3 >>> 6 & 0x3)]);
/* 152 */       this.out.write(pem_array[b3 & 0x3F]);
/*     */     } 
/*     */ 
/*     */     
/* 156 */     this.count += 4;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\BASE64EncoderStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */