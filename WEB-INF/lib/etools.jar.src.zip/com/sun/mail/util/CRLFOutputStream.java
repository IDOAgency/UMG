package com.sun.mail.util;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class CRLFOutputStream extends FilterOutputStream {
  protected int lastb = -1;
  
  protected static byte[] newline = new byte[2];
  
  static  {
    newline[0] = 13;
    newline[1] = 10;
  }
  
  public CRLFOutputStream(OutputStream paramOutputStream) { super(paramOutputStream); }
  
  public void write(int paramInt) throws IOException {
    if (paramInt == 13) {
      this.out.write(newline);
    } else if (paramInt == 10) {
      if (this.lastb != 13)
        this.out.write(newline); 
    } else {
      this.out.write(paramInt);
    } 
    this.lastb = paramInt;
  }
  
  public void write(byte[] paramArrayOfByte) throws IOException { write(paramArrayOfByte, 0, paramArrayOfByte.length); }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
    int i = paramInt1;
    paramInt2 += paramInt1;
    for (int j = i; j < paramInt2; j++) {
      if (paramArrayOfByte[j] == 13) {
        this.out.write(paramArrayOfByte, i, j - i);
        this.out.write(newline);
        i = j + 1;
      } else if (paramArrayOfByte[j] == 10) {
        if (this.lastb != 13) {
          this.out.write(paramArrayOfByte, i, j - i);
          this.out.write(newline);
        } 
        i = j + 1;
      } 
      this.lastb = paramArrayOfByte[j];
    } 
    if (paramInt2 - i > 0)
      this.out.write(paramArrayOfByte, i, paramInt2 - i); 
  }
  
  public void writeln() throws IOException { this.out.write(newline); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\CRLFOutputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */