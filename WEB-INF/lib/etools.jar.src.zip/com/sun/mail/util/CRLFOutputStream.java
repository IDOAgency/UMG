/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CRLFOutputStream
/*    */   extends FilterOutputStream
/*    */ {
/* 20 */   protected int lastb = -1;
/*    */ 
/*    */   
/* 23 */   protected static byte[] newline = new byte[2]; static  {
/* 24 */     newline[0] = 13;
/* 25 */     newline[1] = 10;
/*    */   }
/*    */ 
/*    */   
/* 29 */   public CRLFOutputStream(OutputStream paramOutputStream) { super(paramOutputStream); }
/*    */ 
/*    */   
/*    */   public void write(int paramInt) throws IOException {
/* 33 */     if (paramInt == 13) {
/* 34 */       this.out.write(newline);
/* 35 */     } else if (paramInt == 10) {
/* 36 */       if (this.lastb != 13)
/* 37 */         this.out.write(newline); 
/*    */     } else {
/* 39 */       this.out.write(paramInt);
/*    */     } 
/* 41 */     this.lastb = paramInt;
/*    */   }
/*    */ 
/*    */   
/* 45 */   public void write(byte[] paramArrayOfByte) throws IOException { write(paramArrayOfByte, 0, paramArrayOfByte.length); }
/*    */ 
/*    */   
/*    */   public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/* 49 */     int i = paramInt1;
/*    */     
/* 51 */     paramInt2 += paramInt1;
/* 52 */     for (int j = i; j < paramInt2; j++) {
/* 53 */       if (paramArrayOfByte[j] == 13) {
/* 54 */         this.out.write(paramArrayOfByte, i, j - i);
/* 55 */         this.out.write(newline);
/* 56 */         i = j + 1;
/* 57 */       } else if (paramArrayOfByte[j] == 10) {
/* 58 */         if (this.lastb != 13) {
/* 59 */           this.out.write(paramArrayOfByte, i, j - i);
/* 60 */           this.out.write(newline);
/*    */         } 
/* 62 */         i = j + 1;
/*    */       } 
/* 64 */       this.lastb = paramArrayOfByte[j];
/*    */     } 
/* 66 */     if (paramInt2 - i > 0) {
/* 67 */       this.out.write(paramArrayOfByte, i, paramInt2 - i);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 74 */   public void writeln() throws IOException { this.out.write(newline); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\CRLFOutputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */