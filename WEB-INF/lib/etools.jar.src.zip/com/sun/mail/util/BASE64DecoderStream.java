/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BASE64DecoderStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   private byte[] buffer;
/*     */   private int bufsize;
/*     */   private int index;
/*     */   
/*     */   public BASE64DecoderStream(InputStream paramInputStream) {
/*  31 */     super(paramInputStream);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     this.decode_buffer = new byte[4];
/*     */     this.buffer = new byte[3]; } private void decode() throws IOException { int i;
/* 135 */     this.bufsize = 0;
/*     */ 
/*     */     
/*     */     do {
/* 139 */       i = this.in.read();
/* 140 */       if (i == -1) {
/*     */         return;
/*     */       }
/*     */     }
/* 144 */     while (i == 10 || i == 13);
/* 145 */     this.decode_buffer[0] = (byte)i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     int j = 3, k = 1; int m;
/* 152 */     while ((m = this.in.read(this.decode_buffer, k, j)) != j) {
/*     */ 
/*     */       
/* 155 */       if (m == -1)
/* 156 */         throw new IOException("Error in encoded stream"); 
/* 157 */       j -= m;
/* 158 */       k += m;
/*     */     } 
/*     */ 
/*     */     
/* 162 */     byte b1 = pem_convert_array[this.decode_buffer[0] & 0xFF];
/* 163 */     byte b2 = pem_convert_array[this.decode_buffer[1] & 0xFF];
/*     */     
/* 165 */     this.buffer[this.bufsize++] = (byte)(b1 << 2 & 0xFC | b2 >>> 4 & 0x3);
/*     */     
/* 167 */     if (this.decode_buffer[2] == 61)
/*     */       return; 
/* 169 */     b1 = b2;
/* 170 */     b2 = pem_convert_array[this.decode_buffer[2] & 0xFF];
/*     */     
/* 172 */     this.buffer[this.bufsize++] = (byte)(b1 << 4 & 0xF0 | b2 >>> 2 & 0xF);
/*     */     
/* 174 */     if (this.decode_buffer[3] == 61)
/*     */       return; 
/* 176 */     b1 = b2;
/* 177 */     b2 = pem_convert_array[this.decode_buffer[3] & 0xFF];
/*     */     
/* 179 */     this.buffer[this.bufsize++] = (byte)(b1 << 6 & 0xC0 | b2 & 0x3F); }
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*     */     if (this.index >= this.bufsize) {
/*     */       decode();
/*     */       if (this.bufsize == 0)
/*     */         return -1; 
/*     */       this.index = 0;
/*     */     } 
/*     */     return this.buffer[this.index++] & 0xFF;
/*     */   }
/*     */   
/*     */   public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/*     */     byte b;
/*     */     try {
/*     */       for (b = 0; b < paramInt2; b++) {
/*     */         int i;
/*     */         if ((i = read()) == -1) {
/*     */           if (!b)
/*     */             b = -1; 
/*     */           break;
/*     */         } 
/*     */         paramArrayOfByte[paramInt1 + b] = (byte)i;
/*     */       } 
/*     */     } catch (IOException iOException) {
/*     */       b = -1;
/*     */     } 
/*     */     return b;
/*     */   }
/*     */   
/*     */   public boolean markSupported() { return false; }
/*     */   
/*     */   public int available() throws IOException { return this.in.available() * 3 / 4 + this.bufsize - this.index; }
/*     */   
/*     */   private static final char[] pem_array = { 
/*     */       'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 
/*     */       'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 
/*     */       'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 
/*     */       'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 
/*     */       'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 
/*     */       'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', 
/*     */       '8', '9', '+', '/' };
/*     */   private static final byte[] pem_convert_array = new byte[256];
/*     */   private byte[] decode_buffer;
/*     */   
/*     */   static  {
/*     */     for (byte b1 = 0; b1 < 'ÿ'; b1++)
/*     */       pem_convert_array[b1] = -1; 
/*     */     for (byte b2 = 0; b2 < pem_array.length; b2++)
/*     */       pem_convert_array[pem_array[b2]] = (byte)b2; 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\BASE64DecoderStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */