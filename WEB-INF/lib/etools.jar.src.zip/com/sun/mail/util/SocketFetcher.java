package com.sun.mail.util;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.Socket;

public class SocketFetcher {
  public static Socket getSocket(String paramString1, int paramInt, String paramString2, String paramString3, String paramString4) throws IOException {
    Socket socket = null;
    boolean bool = (paramString3 != null && paramString3.equalsIgnoreCase("false")) ? 0 : 1;
    int i = -1;
    if (paramString4 != null)
      try {
        i = Integer.parseInt(paramString4);
      } catch (NumberFormatException numberFormatException) {
        i = -1;
      }  
    if (paramString2 == null || paramString2.length() <= 0) {
      socket = new Socket(paramString1, paramInt);
    } else {
      try {
        Class clazz = Class.forName(paramString2);
        Method method1 = clazz.getMethod("getDefault", 
            new Class[0]);
        Object object = method1.invoke(new Object(), new Object[0]);
        Class[] arrayOfClass = { String.class, 
            int.class };
        Method method2 = 
          clazz.getMethod("createSocket", arrayOfClass);
        Integer integer = new Integer((i != -1) ? i : paramInt);
        Object[] arrayOfObject = { paramString1, integer };
        socket = (Socket)method2.invoke(object, arrayOfObject);
      } catch (Exception exception) {
        if (bool) {
          socket = new Socket(paramString1, paramInt);
        } else {
          throw new IOException("Couldn't connect using \"" + 
              paramString2 + 
              "\" socket factory to host, port: " + 
              paramString1 + ", " + i);
        } 
      } 
    } 
    return socket;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\SocketFetcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */