/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.net.Socket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SocketFetcher
/*    */ {
/*    */   public static Socket getSocket(String paramString1, int paramInt, String paramString2, String paramString3, String paramString4) throws IOException {
/* 46 */     Socket socket = null;
/*    */     
/* 48 */     boolean bool = (paramString3 != null && paramString3.equalsIgnoreCase("false")) ? 0 : 1;
/*    */     
/* 50 */     int i = -1;
/* 51 */     if (paramString4 != null) {
/*    */       try {
/* 53 */         i = Integer.parseInt(paramString4);
/* 54 */       } catch (NumberFormatException numberFormatException) {
/* 55 */         i = -1;
/*    */       } 
/*    */     }
/*    */     
/* 59 */     if (paramString2 == null || paramString2.length() <= 0) {
/*    */       
/* 61 */       socket = new Socket(paramString1, paramInt);
/*    */     } else {
/*    */       
/*    */       try {
/* 65 */         Class clazz = Class.forName(paramString2);
/*    */         
/* 67 */         Method method1 = clazz.getMethod("getDefault", 
/* 68 */             new Class[0]);
/* 69 */         Object object = method1.invoke(new Object(), new Object[0]);
/*    */         
/* 71 */         Class[] arrayOfClass = { String.class, 
/* 72 */             int.class };
/* 73 */         Method method2 = 
/* 74 */           clazz.getMethod("createSocket", arrayOfClass);
/*    */         
/* 76 */         Integer integer = new Integer((i != -1) ? i : paramInt);
/* 77 */         Object[] arrayOfObject = { paramString1, integer };
/* 78 */         socket = (Socket)method2.invoke(object, arrayOfObject);
/* 79 */       } catch (Exception exception) {
/* 80 */         if (bool) {
/* 81 */           socket = new Socket(paramString1, paramInt);
/*    */         } else {
/* 83 */           throw new IOException("Couldn't connect using \"" + 
/* 84 */               paramString2 + 
/* 85 */               "\" socket factory to host, port: " + 
/* 86 */               paramString1 + ", " + i);
/*    */         } 
/*    */       } 
/*    */     } 
/* 90 */     return socket;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\SocketFetcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */