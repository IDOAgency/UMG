/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QPEncoderStream
/*     */   extends FilterOutputStream
/*     */ {
/*     */   private int count;
/*     */   private int bytesPerLine;
/*     */   private boolean gotSpace = false;
/*     */   private boolean gotCR = false;
/*     */   
/*     */   public QPEncoderStream(OutputStream paramOutputStream, int paramInt) {
/*  35 */     super(paramOutputStream);
/*     */ 
/*     */     
/*  38 */     this.bytesPerLine = paramInt - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public QPEncoderStream(OutputStream paramOutputStream) { this(paramOutputStream, 76); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/*  61 */     for (int i = 0; i < paramInt2; i++) {
/*  62 */       write(paramArrayOfByte[paramInt1 + i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public void write(byte[] paramArrayOfByte) throws IOException { write(paramArrayOfByte, 0, paramArrayOfByte.length); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int paramInt) throws IOException {
/*  80 */     paramInt &= 0xFF;
/*  81 */     if (this.gotSpace) {
/*  82 */       if (paramInt == 13 || paramInt == 10) {
/*     */         
/*  84 */         output(32, true);
/*     */       } else {
/*  86 */         output(32, false);
/*  87 */       }  this.gotSpace = false;
/*     */     } 
/*     */     
/*  90 */     if (paramInt == 32) {
/*  91 */       this.gotSpace = true; return;
/*  92 */     }  if (paramInt == 13) {
/*  93 */       this.gotCR = true;
/*  94 */       outputCRLF(); return;
/*  95 */     }  if (paramInt == 10) {
/*  96 */       if (this.gotCR) {
/*     */ 
/*     */         
/*  99 */         this.gotCR = false; return;
/*     */       } 
/* 101 */       outputCRLF(); return;
/* 102 */     }  if (paramInt < 32 || paramInt >= 127 || paramInt == 61) {
/*     */       
/* 104 */       output(paramInt, true); return;
/*     */     } 
/* 106 */     output(paramInt, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public void flush() throws IOException { this.out.flush(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public void close() throws IOException { this.out.close(); }
/*     */ 
/*     */   
/*     */   private void outputCRLF() throws IOException {
/* 127 */     this.out.write(13);
/* 128 */     this.out.write(10);
/* 129 */     this.count = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final char[] hex = { 
/* 134 */       '0', '1', '2', '3', '4', '5', '6', '7', 
/* 135 */       '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */ 
/*     */   
/*     */   protected void output(int paramInt, boolean paramBoolean) throws IOException {
/* 139 */     if (paramBoolean) {
/* 140 */       if (this.count += 3 > this.bytesPerLine) {
/* 141 */         this.out.write(61);
/* 142 */         this.out.write(13);
/* 143 */         this.out.write(10);
/* 144 */         this.count = 3;
/*     */       } 
/* 146 */       this.out.write(61);
/* 147 */       this.out.write(hex[paramInt >> 4]);
/* 148 */       this.out.write(hex[paramInt & 0xF]); return;
/*     */     } 
/* 150 */     if (++this.count > this.bytesPerLine) {
/* 151 */       this.out.write(61);
/* 152 */       this.out.write(13);
/* 153 */       this.out.write(10);
/* 154 */       this.count = 1;
/*     */     } 
/* 156 */     this.out.write(paramInt);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\QPEncoderStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */