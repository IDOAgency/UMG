/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASCIIUtility
/*     */ {
/*     */   public static int parseInt(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3) throws NumberFormatException {
/*  41 */     if (paramArrayOfByte == null) {
/*  42 */       throw new NumberFormatException("null");
/*     */     }
/*  44 */     int i = 0;
/*  45 */     boolean bool = false;
/*  46 */     int j = paramInt1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     if (paramInt2 > 0) {
/*  52 */       int k; if (paramArrayOfByte[j] == 45) {
/*  53 */         bool = true;
/*  54 */         k = Integer.MIN_VALUE;
/*  55 */         j++;
/*     */       } else {
/*  57 */         k = -2147483647;
/*     */       } 
/*  59 */       int m = k / paramInt3;
/*  60 */       if (j < paramInt2) {
/*  61 */         int n = Character.digit((char)paramArrayOfByte[j++], paramInt3);
/*  62 */         if (n < 0) {
/*  63 */           throw new NumberFormatException(
/*  64 */               "illegal number: " + toString(paramArrayOfByte, paramInt1, paramInt2));
/*     */         }
/*     */         
/*  67 */         i = -n;
/*     */       } 
/*     */       
/*  70 */       while (j < paramInt2) {
/*     */         
/*  72 */         int n = Character.digit((char)paramArrayOfByte[j++], paramInt3);
/*  73 */         if (n < 0) {
/*  74 */           throw new NumberFormatException("illegal number");
/*     */         }
/*  76 */         if (i < m) {
/*  77 */           throw new NumberFormatException("illegal number");
/*     */         }
/*  79 */         i *= paramInt3;
/*  80 */         if (i < k + n) {
/*  81 */           throw new NumberFormatException("illegal number");
/*     */         }
/*  83 */         i -= n;
/*     */       } 
/*     */     } else {
/*  86 */       throw new NumberFormatException("illegal number");
/*     */     } 
/*  88 */     if (bool) {
/*  89 */       if (j > 1) {
/*  90 */         return i;
/*     */       }
/*  92 */       throw new NumberFormatException("illegal number");
/*     */     } 
/*     */     
/*  95 */     return -i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public static int parseInt(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws NumberFormatException { return parseInt(paramArrayOfByte, paramInt1, paramInt2, 10); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long parseLong(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3) throws NumberFormatException {
/* 118 */     if (paramArrayOfByte == null) {
/* 119 */       throw new NumberFormatException("null");
/*     */     }
/* 121 */     long l = 0L;
/* 122 */     boolean bool = false;
/* 123 */     int i = paramInt1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     if (paramInt2 > 0) {
/* 129 */       long l1; if (paramArrayOfByte[i] == 45) {
/* 130 */         bool = true;
/* 131 */         l1 = Float.MIN_VALUE;
/* 132 */         i++;
/*     */       } else {
/* 134 */         l1 = -9223372036854775807L;
/*     */       } 
/* 136 */       long l2 = l1 / paramInt3;
/* 137 */       if (i < paramInt2) {
/* 138 */         int j = Character.digit((char)paramArrayOfByte[i++], paramInt3);
/* 139 */         if (j < 0) {
/* 140 */           throw new NumberFormatException(
/* 141 */               "illegal number: " + toString(paramArrayOfByte, paramInt1, paramInt2));
/*     */         }
/*     */         
/* 144 */         l = -j;
/*     */       } 
/*     */       
/* 147 */       while (i < paramInt2) {
/*     */         
/* 149 */         int j = Character.digit((char)paramArrayOfByte[i++], paramInt3);
/* 150 */         if (j < 0) {
/* 151 */           throw new NumberFormatException("illegal number");
/*     */         }
/* 153 */         if (l < l2) {
/* 154 */           throw new NumberFormatException("illegal number");
/*     */         }
/* 156 */         l *= paramInt3;
/* 157 */         if (l < l1 + j) {
/* 158 */           throw new NumberFormatException("illegal number");
/*     */         }
/* 160 */         l -= j;
/*     */       } 
/*     */     } else {
/* 163 */       throw new NumberFormatException("illegal number");
/*     */     } 
/* 165 */     if (bool) {
/* 166 */       if (i > 1) {
/* 167 */         return l;
/*     */       }
/* 169 */       throw new NumberFormatException("illegal number");
/*     */     } 
/*     */     
/* 172 */     return -l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 183 */   public static long parseLong(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws NumberFormatException { return parseLong(paramArrayOfByte, paramInt1, paramInt2, 10); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
/* 192 */     int i = paramInt2 - paramInt1;
/* 193 */     char[] arrayOfChar = new char[i]; byte b;
/*     */     int j;
/* 195 */     for (b = 0, j = paramInt1; b < i;) {
/* 196 */       arrayOfChar[b++] = (char)paramArrayOfByte[j++];
/*     */     }
/* 198 */     return new String(arrayOfChar);
/*     */   }
/*     */   
/*     */   public static String toString(ByteArrayInputStream paramByteArrayInputStream) {
/* 202 */     int i = paramByteArrayInputStream.available();
/* 203 */     char[] arrayOfChar = new char[i];
/* 204 */     byte[] arrayOfByte = new byte[i];
/*     */     
/* 206 */     paramByteArrayInputStream.read(arrayOfByte, 0, i);
/* 207 */     for (byte b = 0; b < i;) {
/* 208 */       arrayOfChar[b] = (char)arrayOfByte[b++];
/*     */     }
/* 210 */     return new String(arrayOfChar);
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] getBytes(String paramString) {
/* 215 */     char[] arrayOfChar = paramString.toCharArray();
/* 216 */     int i = arrayOfChar.length;
/* 217 */     byte[] arrayOfByte = new byte[i];
/*     */     
/* 219 */     for (byte b = 0; b < i;)
/* 220 */       arrayOfByte[b] = (byte)arrayOfChar[b++]; 
/* 221 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] getBytes(InputStream paramInputStream) throws IOException {
/*     */     byte[] arrayOfByte;
/* 227 */     int i = 1024;
/*     */ 
/*     */ 
/*     */     
/* 231 */     if (paramInputStream instanceof ByteArrayInputStream) {
/* 232 */       i = paramInputStream.available();
/* 233 */       arrayOfByte = new byte[i];
/* 234 */       int j = paramInputStream.read(arrayOfByte, 0, i);
/*     */     } else {
/*     */       
/* 237 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 238 */       arrayOfByte = new byte[i]; int j;
/* 239 */       while ((j = paramInputStream.read(arrayOfByte, 0, i)) != -1)
/* 240 */         byteArrayOutputStream.write(arrayOfByte, 0, j); 
/* 241 */       arrayOfByte = byteArrayOutputStream.toByteArray();
/*     */     } 
/* 243 */     return arrayOfByte;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\ASCIIUtility.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */