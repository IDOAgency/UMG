package com.sun.mail.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class ASCIIUtility {
  public static int parseInt(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3) throws NumberFormatException {
    if (paramArrayOfByte == null)
      throw new NumberFormatException("null"); 
    int i = 0;
    boolean bool = false;
    int j = paramInt1;
    if (paramInt2 > 0) {
      int k;
      if (paramArrayOfByte[j] == 45) {
        bool = true;
        k = Integer.MIN_VALUE;
        j++;
      } else {
        k = -2147483647;
      } 
      int m = k / paramInt3;
      if (j < paramInt2) {
        int n = Character.digit((char)paramArrayOfByte[j++], paramInt3);
        if (n < 0)
          throw new NumberFormatException(
              "illegal number: " + toString(paramArrayOfByte, paramInt1, paramInt2)); 
        i = -n;
      } 
      while (j < paramInt2) {
        int n = Character.digit((char)paramArrayOfByte[j++], paramInt3);
        if (n < 0)
          throw new NumberFormatException("illegal number"); 
        if (i < m)
          throw new NumberFormatException("illegal number"); 
        i *= paramInt3;
        if (i < k + n)
          throw new NumberFormatException("illegal number"); 
        i -= n;
      } 
    } else {
      throw new NumberFormatException("illegal number");
    } 
    if (bool) {
      if (j > 1)
        return i; 
      throw new NumberFormatException("illegal number");
    } 
    return -i;
  }
  
  public static int parseInt(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws NumberFormatException { return parseInt(paramArrayOfByte, paramInt1, paramInt2, 10); }
  
  public static long parseLong(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3) throws NumberFormatException {
    if (paramArrayOfByte == null)
      throw new NumberFormatException("null"); 
    long l = 0L;
    boolean bool = false;
    int i = paramInt1;
    if (paramInt2 > 0) {
      long l1;
      if (paramArrayOfByte[i] == 45) {
        bool = true;
        l1 = Float.MIN_VALUE;
        i++;
      } else {
        l1 = -9223372036854775807L;
      } 
      long l2 = l1 / paramInt3;
      if (i < paramInt2) {
        int j = Character.digit((char)paramArrayOfByte[i++], paramInt3);
        if (j < 0)
          throw new NumberFormatException(
              "illegal number: " + toString(paramArrayOfByte, paramInt1, paramInt2)); 
        l = -j;
      } 
      while (i < paramInt2) {
        int j = Character.digit((char)paramArrayOfByte[i++], paramInt3);
        if (j < 0)
          throw new NumberFormatException("illegal number"); 
        if (l < l2)
          throw new NumberFormatException("illegal number"); 
        l *= paramInt3;
        if (l < l1 + j)
          throw new NumberFormatException("illegal number"); 
        l -= j;
      } 
    } else {
      throw new NumberFormatException("illegal number");
    } 
    if (bool) {
      if (i > 1)
        return l; 
      throw new NumberFormatException("illegal number");
    } 
    return -l;
  }
  
  public static long parseLong(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws NumberFormatException { return parseLong(paramArrayOfByte, paramInt1, paramInt2, 10); }
  
  public static String toString(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    int i = paramInt2 - paramInt1;
    char[] arrayOfChar = new char[i];
    byte b;
    int j;
    for (b = 0, j = paramInt1; b < i;)
      arrayOfChar[b++] = (char)paramArrayOfByte[j++]; 
    return new String(arrayOfChar);
  }
  
  public static String toString(ByteArrayInputStream paramByteArrayInputStream) {
    int i = paramByteArrayInputStream.available();
    char[] arrayOfChar = new char[i];
    byte[] arrayOfByte = new byte[i];
    paramByteArrayInputStream.read(arrayOfByte, 0, i);
    for (byte b = 0; b < i;)
      arrayOfChar[b] = (char)arrayOfByte[b++]; 
    return new String(arrayOfChar);
  }
  
  public static byte[] getBytes(String paramString) {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    byte[] arrayOfByte = new byte[i];
    for (byte b = 0; b < i;)
      arrayOfByte[b] = (byte)arrayOfChar[b++]; 
    return arrayOfByte;
  }
  
  public static byte[] getBytes(InputStream paramInputStream) throws IOException {
    byte[] arrayOfByte;
    int i = 1024;
    if (paramInputStream instanceof ByteArrayInputStream) {
      i = paramInputStream.available();
      arrayOfByte = new byte[i];
      int j = paramInputStream.read(arrayOfByte, 0, i);
    } else {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      arrayOfByte = new byte[i];
      int j;
      while ((j = paramInputStream.read(arrayOfByte, 0, i)) != -1)
        byteArrayOutputStream.write(arrayOfByte, 0, j); 
      arrayOfByte = byteArrayOutputStream.toByteArray();
    } 
    return arrayOfByte;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\ASCIIUtility.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */