/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BEncoderStream
/*    */   extends BASE64EncoderStream
/*    */ {
/* 27 */   public BEncoderStream(OutputStream paramOutputStream) { super(paramOutputStream, 2147483647); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   public static int encodedLength(byte[] paramArrayOfByte) { return (paramArrayOfByte.length + 2) / 3 * 4; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\BEncoderStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */