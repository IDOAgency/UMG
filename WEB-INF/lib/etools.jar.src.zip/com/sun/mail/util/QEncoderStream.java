/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QEncoderStream
/*    */   extends QPEncoderStream
/*    */ {
/*    */   private String specials;
/* 22 */   private static String WORD_SPECIALS = "=_?\"#$%&'(),.:;<>@[\\]^`{|}~";
/* 23 */   private static String TEXT_SPECIALS = "=_?";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public QEncoderStream(OutputStream paramOutputStream, boolean paramBoolean) {
/* 32 */     super(paramOutputStream, 2147483647);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 39 */     this.specials = paramBoolean ? WORD_SPECIALS : TEXT_SPECIALS;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(int paramInt) throws IOException {
/* 48 */     paramInt &= 0xFF;
/* 49 */     if (paramInt == 32) {
/* 50 */       output(95, false); return;
/* 51 */     }  if (paramInt < 32 || paramInt >= 127 || this.specials.indexOf(paramInt) >= 0) {
/*    */       
/* 53 */       output(paramInt, true); return;
/*    */     } 
/* 55 */     output(paramInt, false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int encodedLength(byte[] paramArrayOfByte, boolean paramBoolean) {
/* 62 */     byte b1 = 0;
/* 63 */     String str = paramBoolean ? WORD_SPECIALS : TEXT_SPECIALS;
/* 64 */     for (byte b2 = 0; b2 < paramArrayOfByte.length; b2++) {
/* 65 */       byte b = paramArrayOfByte[b2] & 0xFF;
/* 66 */       if (b < 32 || b >= Byte.MAX_VALUE || str.indexOf(b) >= 0) {
/*    */         
/* 68 */         b1 += true;
/*    */       } else {
/* 70 */         b1++;
/*    */       } 
/* 72 */     }  return b1;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\QEncoderStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */