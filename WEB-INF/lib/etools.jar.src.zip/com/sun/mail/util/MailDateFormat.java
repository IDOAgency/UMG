package com.sun.mail.util;

import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

public class MailDateFormat extends SimpleDateFormat {
  static boolean debug;
  
  public MailDateFormat() { super("EEE, d MMM yyyy HH:mm:ss 'XXXXX' (z)", Locale.US); }
  
  public StringBuffer format(Date paramDate, StringBuffer paramStringBuffer, FieldPosition paramFieldPosition) {
    int i = paramStringBuffer.length();
    super.format(paramDate, paramStringBuffer, paramFieldPosition);
    int j = 0;
    for (j = i + 25; paramStringBuffer.charAt(j) != 'X'; j++);
    this.calendar.clear();
    this.calendar.setTime(paramDate);
    int k = this.calendar.get(7);
    int m = this.calendar.get(5);
    int n = this.calendar.get(2);
    int i1 = this.calendar.get(1);
    this.calendar.get(11);
    this.calendar.get(12);
    this.calendar.get(13);
    TimeZone timeZone = this.calendar.getTimeZone();
    int i2 = timeZone.getOffset(this.calendar.get(0), 
        i1, n, m, k, 
        this.calendar.get(14));
    if (i2 < 0) {
      paramStringBuffer.setCharAt(j++, '-');
      i2 = -i2;
    } else {
      paramStringBuffer.setCharAt(j++, '+');
    } 
    int i3 = i2 / 60 / 1000;
    int i4 = i3 / 60;
    int i5 = i3 % 60;
    paramStringBuffer.setCharAt(j++, Character.forDigit(i4 / 10, 10));
    paramStringBuffer.setCharAt(j++, Character.forDigit(i4 % 10, 10));
    paramStringBuffer.setCharAt(j++, Character.forDigit(i5 / 10, 10));
    paramStringBuffer.setCharAt(j++, Character.forDigit(i5 % 10, 10));
    return paramStringBuffer;
  }
  
  public Date parse(String paramString, ParsePosition paramParsePosition) { return parseDate(paramString.toCharArray(), paramParsePosition); }
  
  private static Date parseDate(char[] paramArrayOfChar, ParsePosition paramParsePosition) {
    try {
      int i = -1;
      int j = -1;
      int k = -1;
      int m = 0;
      int n = 0;
      int i1 = 0;
      int i2 = 0;
      Parser parser = new Parser(paramArrayOfChar);
      parser.skipUntilNumber();
      i = parser.parseNumber();
      if (!parser.skipIfChar('-'))
        parser.skipWhiteSpace(); 
      j = parser.parseMonth();
      if (!parser.skipIfChar('-'))
        parser.skipWhiteSpace(); 
      k = parser.parseNumber();
      if (k < 50) {
        k += 2000;
      } else if (k < 100) {
        k += 1900;
      } 
      parser.skipWhiteSpace();
      m = parser.parseNumber();
      parser.skipChar(':');
      n = parser.parseNumber();
      if (parser.skipIfChar(':'))
        i1 = parser.parseNumber(); 
      try {
        parser.skipWhiteSpace();
        i2 = parser.parseTimeZone();
      } catch (ParseException parseException) {
        if (debug)
          System.out.println("No timezone? : '" + paramArrayOfChar + "'"); 
      } 
      paramParsePosition.setIndex(parser.getIndex());
      return ourUTC(k, j, i, m, n, i1, i2);
    } catch (Exception exception) {
      if (debug) {
        System.out.println("Bad date: '" + paramArrayOfChar + "'");
        exception.printStackTrace();
      } 
      paramParsePosition.setIndex(1);
      return null;
    } 
  }
  
  private static TimeZone tz = TimeZone.getTimeZone("GMT");
  
  private static Calendar cal = new GregorianCalendar(tz);
  
  private static Date ourUTC(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7) {
    cal.clear();
    cal.set(1, paramInt1);
    cal.set(2, paramInt2);
    cal.set(5, paramInt3);
    cal.set(11, paramInt4);
    cal.set(12, paramInt5 + paramInt7);
    cal.set(13, paramInt6);
    return cal.getTime();
  }
  
  public void setCalendar(Calendar paramCalendar) { throw new RuntimeException("Method setCalendar() shouldn't be called"); }
  
  public void setNumberFormat(NumberFormat paramNumberFormat) { throw new RuntimeException("Method setCalendar() shouldn't be called"); }
  
  public static void main(String[] paramArrayOfString) {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\MailDateFormat.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */