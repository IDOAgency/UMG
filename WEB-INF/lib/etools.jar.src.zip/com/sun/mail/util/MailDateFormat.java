/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.text.FieldPosition;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MailDateFormat
/*     */   extends SimpleDateFormat
/*     */ {
/*     */   static boolean debug;
/*     */   
/* 107 */   public MailDateFormat() { super("EEE, d MMM yyyy HH:mm:ss 'XXXXX' (z)", Locale.US); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer format(Date paramDate, StringBuffer paramStringBuffer, FieldPosition paramFieldPosition) {
/* 125 */     int i = paramStringBuffer.length();
/* 126 */     super.format(paramDate, paramStringBuffer, paramFieldPosition);
/* 127 */     int j = 0;
/*     */ 
/*     */     
/* 130 */     for (j = i + 25; paramStringBuffer.charAt(j) != 'X'; j++);
/*     */ 
/*     */     
/* 133 */     this.calendar.clear();
/* 134 */     this.calendar.setTime(paramDate);
/* 135 */     int k = this.calendar.get(7);
/* 136 */     int m = this.calendar.get(5);
/* 137 */     int n = this.calendar.get(2);
/* 138 */     int i1 = this.calendar.get(1);
/* 139 */     this.calendar.get(11);
/* 140 */     this.calendar.get(12);
/* 141 */     this.calendar.get(13);
/* 142 */     TimeZone timeZone = this.calendar.getTimeZone();
/* 143 */     int i2 = timeZone.getOffset(this.calendar.get(0), 
/* 144 */         i1, n, m, k, 
/* 145 */         this.calendar.get(14));
/*     */     
/* 147 */     if (i2 < 0) {
/* 148 */       paramStringBuffer.setCharAt(j++, '-');
/* 149 */       i2 = -i2;
/*     */     } else {
/* 151 */       paramStringBuffer.setCharAt(j++, '+');
/*     */     } 
/* 153 */     int i3 = i2 / 60 / 1000;
/* 154 */     int i4 = i3 / 60;
/* 155 */     int i5 = i3 % 60;
/*     */     
/* 157 */     paramStringBuffer.setCharAt(j++, Character.forDigit(i4 / 10, 10));
/* 158 */     paramStringBuffer.setCharAt(j++, Character.forDigit(i4 % 10, 10));
/* 159 */     paramStringBuffer.setCharAt(j++, Character.forDigit(i5 / 10, 10));
/* 160 */     paramStringBuffer.setCharAt(j++, Character.forDigit(i5 % 10, 10));
/*     */ 
/*     */     
/* 163 */     return paramStringBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   public Date parse(String paramString, ParsePosition paramParsePosition) { return parseDate(paramString.toCharArray(), paramParsePosition); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Date parseDate(char[] paramArrayOfChar, ParsePosition paramParsePosition) {
/*     */     try {
/* 220 */       int i = -1;
/* 221 */       int j = -1;
/* 222 */       int k = -1;
/* 223 */       int m = 0;
/* 224 */       int n = 0;
/* 225 */       int i1 = 0;
/* 226 */       int i2 = 0;
/*     */ 
/*     */       
/* 229 */       Parser parser = new Parser(paramArrayOfChar);
/*     */ 
/*     */       
/* 232 */       parser.skipUntilNumber();
/* 233 */       i = parser.parseNumber();
/*     */       
/* 235 */       if (!parser.skipIfChar('-')) {
/* 236 */         parser.skipWhiteSpace();
/*     */       }
/*     */ 
/*     */       
/* 240 */       j = parser.parseMonth();
/* 241 */       if (!parser.skipIfChar('-')) {
/* 242 */         parser.skipWhiteSpace();
/*     */       }
/*     */ 
/*     */       
/* 246 */       k = parser.parseNumber();
/* 247 */       if (k < 50) {
/* 248 */         k += 2000;
/* 249 */       } else if (k < 100) {
/* 250 */         k += 1900;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 256 */       parser.skipWhiteSpace();
/* 257 */       m = parser.parseNumber();
/*     */ 
/*     */       
/* 260 */       parser.skipChar(':');
/* 261 */       n = parser.parseNumber();
/*     */ 
/*     */       
/* 264 */       if (parser.skipIfChar(':')) {
/* 265 */         i1 = parser.parseNumber();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 271 */         parser.skipWhiteSpace();
/* 272 */         i2 = parser.parseTimeZone();
/* 273 */       } catch (ParseException parseException) {
/* 274 */         if (debug) {
/* 275 */           System.out.println("No timezone? : '" + paramArrayOfChar + "'");
/*     */         }
/*     */       } 
/*     */       
/* 279 */       paramParsePosition.setIndex(parser.getIndex());
/* 280 */       return ourUTC(k, j, i, m, n, i1, i2);
/*     */     
/*     */     }
/* 283 */     catch (Exception exception) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 289 */       if (debug) {
/* 290 */         System.out.println("Bad date: '" + paramArrayOfChar + "'");
/* 291 */         exception.printStackTrace();
/*     */       } 
/* 293 */       paramParsePosition.setIndex(1);
/* 294 */       return null;
/*     */     } 
/*     */   }
/*     */   
/* 298 */   private static TimeZone tz = TimeZone.getTimeZone("GMT");
/* 299 */   private static Calendar cal = new GregorianCalendar(tz);
/*     */ 
/*     */ 
/*     */   
/*     */   private static Date ourUTC(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7) {
/* 304 */     cal.clear();
/* 305 */     cal.set(1, paramInt1);
/* 306 */     cal.set(2, paramInt2);
/* 307 */     cal.set(5, paramInt3);
/* 308 */     cal.set(11, paramInt4);
/* 309 */     cal.set(12, paramInt5 + paramInt7);
/* 310 */     cal.set(13, paramInt6);
/*     */     
/* 312 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 320 */   public void setCalendar(Calendar paramCalendar) { throw new RuntimeException("Method setCalendar() shouldn't be called"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 325 */   public void setNumberFormat(NumberFormat paramNumberFormat) { throw new RuntimeException("Method setCalendar() shouldn't be called"); }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mai\\util\MailDateFormat.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */