package com.sun.mail.imap;

import com.sun.mail.iap.CommandFailedException;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import com.sun.mail.iap.ResponseHandler;
import com.sun.mail.imap.protocol.IMAPProtocol;
import java.io.IOException;
import java.util.Vector;
import javax.mail.Folder;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.URLName;
import javax.mail.event.ConnectionEvent;
import javax.mail.event.ConnectionListener;

public class IMAPStore extends Store implements ConnectionListener, ResponseHandler {
  private String name = "imap";
  
  private IMAPProtocol protocol;
  
  private int blksize = 16384;
  
  private int port = 143;
  
  private String host;
  
  private String user;
  
  private String password;
  
  private Vector folders;
  
  public IMAPStore(Session paramSession, URLName paramURLName) {
    super(paramSession, paramURLName);
    if (paramURLName != null)
      this.name = paramURLName.getProtocol(); 
    String str = paramSession.getProperty("mail." + this.name + ".partialfetch");
    if (str != null && str.equalsIgnoreCase("false")) {
      this.blksize = -1;
      return;
    } 
    if ((str = paramSession.getProperty("mail." + this.name + ".fetchsize")) != null)
      this.blksize = Integer.parseInt(str); 
  }
  
  protected boolean protocolConnect(String paramString1, int paramInt, String paramString2, String paramString3) throws MessagingException {
    if (paramString1 == null || paramString3 == null || paramString2 == null)
      return false; 
    if (paramInt != -1) {
      this.port = paramInt;
    } else {
      String str = this.session.getProperty("mail." + this.name + ".port");
      if (str != null)
        this.port = Integer.parseInt(str); 
    } 
    if (this.port == -1)
      this.port = 143; 
    try {
      if (this.protocol == null)
        this.protocol = new IMAPProtocol(this.name, paramString1, this.port, 
            this.session.getDebug(), 
            this.session.getProperties()); 
      login(this.protocol, paramString2, paramString3);
      this.protocol.addResponseHandler(this);
      this.host = paramString1;
      this.user = paramString2;
      this.password = paramString3;
      return true;
    } catch (CommandFailedException commandFailedException) {
      this.protocol.disconnect();
      this.protocol = null;
      return false;
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } catch (IOException iOException) {
      throw new MessagingException(iOException.getMessage(), iOException);
    } 
  }
  
  private void login(IMAPProtocol paramIMAPProtocol, String paramString1, String paramString2) throws ProtocolException {
    if (paramIMAPProtocol.hasCapability("AUTH-LOGIN") || 
      paramIMAPProtocol.hasCapability("AUTH=LOGIN")) {
      paramIMAPProtocol.authlogin(paramString1, paramString2);
      return;
    } 
    paramIMAPProtocol.login(paramString1, paramString2);
  }
  
  IMAPProtocol getProtocol(IMAPFolder paramIMAPFolder) throws MessagingException {
    IMAPProtocol iMAPProtocol = null;
    try {
      iMAPProtocol = new IMAPProtocol(this.name, this.host, this.port, 
          this.session.getDebug(), 
          this.session.getProperties());
      login(iMAPProtocol, this.user, this.password);
    } catch (Exception exception) {
      if (iMAPProtocol != null)
        try {
          iMAPProtocol.logout();
        } catch (Exception exception1) {} 
      iMAPProtocol = null;
    } 
    if (iMAPProtocol == null)
      throw new MessagingException("connection failure"); 
    if (paramIMAPFolder != null)
      synchronized (this) {
        if (this.folders == null)
          this.folders = new Vector(); 
        this.folders.addElement(paramIMAPFolder);
        paramIMAPFolder.addConnectionListener(this);
      }  
    return iMAPProtocol;
  }
  
  IMAPProtocol getProtocol() { return this.protocol; }
  
  int getFetchBlockSize() { return this.blksize; }
  
  public boolean isConnected() {
    if (!super.isConnected())
      return false; 
    try {
      this.protocol.noop();
    } catch (ProtocolException protocolException) {}
    return super.isConnected();
  }
  
  public void close() throws MessagingException {
    if (!super.isConnected())
      return; 
    try {
      this.protocol.logout();
      return;
    } catch (ProtocolException protocolException) {
      cleanup();
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
  }
  
  protected void finalize() throws MessagingException {
    super.finalize();
    close();
  }
  
  private void cleanup() throws MessagingException {
    if (this.folders != null) {
      byte b;
      int i;
      for (b = 0, i = this.folders.size(); b < i; b++) {
        IMAPFolder iMAPFolder = (IMAPFolder)this.folders.elementAt(b);
        iMAPFolder.removeConnectionListener(this);
        try {
          iMAPFolder.close(false);
        } catch (MessagingException messagingException) {}
      } 
      this.folders = null;
    } 
    this.protocol = null;
    try {
      super.close();
      return;
    } catch (MessagingException messagingException) {
      return;
    } 
  }
  
  public Folder getDefaultFolder() throws MessagingException {
    checkConnected();
    return new DefaultFolder(this);
  }
  
  public Folder getFolder(String paramString) throws MessagingException {
    checkConnected();
    return new IMAPFolder(paramString, '￿', this);
  }
  
  public Folder getFolder(URLName paramURLName) throws MessagingException {
    checkConnected();
    return new IMAPFolder(paramURLName.getFile(), 
        '￿', 
        this);
  }
  
  private void checkConnected() throws MessagingException {
    if (!super.isConnected())
      throw new IllegalStateException("Not connected"); 
  }
  
  public void opened(ConnectionEvent paramConnectionEvent) {}
  
  public void disconnected(ConnectionEvent paramConnectionEvent) {}
  
  public void closed(ConnectionEvent paramConnectionEvent) {
    if (this.folders != null)
      this.folders.removeElement(paramConnectionEvent.getSource()); 
  }
  
  public void handleResponse(Response paramResponse) {
    if (paramResponse.isBYE()) {
      if (super.isConnected())
        cleanup(); 
      return;
    } 
    if (paramResponse.isOK()) {
      String str = paramResponse.toString();
      if (str.indexOf("ALERT") != -1) {
        notifyStoreListeners(1, str);
        return;
      } 
      notifyStoreListeners(2, str);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\IMAPStore.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */