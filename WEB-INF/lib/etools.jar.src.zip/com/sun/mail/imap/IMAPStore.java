/*     */ package com.sun.mail.imap;
/*     */ 
/*     */ import com.sun.mail.iap.CommandFailedException;
/*     */ import com.sun.mail.iap.ProtocolException;
/*     */ import com.sun.mail.iap.Response;
/*     */ import com.sun.mail.iap.ResponseHandler;
/*     */ import com.sun.mail.imap.protocol.IMAPProtocol;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import javax.mail.Folder;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Store;
/*     */ import javax.mail.URLName;
/*     */ import javax.mail.event.ConnectionEvent;
/*     */ import javax.mail.event.ConnectionListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IMAPStore
/*     */   extends Store
/*     */   implements ConnectionListener, ResponseHandler
/*     */ {
/*  49 */   private String name = "imap";
/*     */   private IMAPProtocol protocol;
/*  51 */   private int blksize = 16384;
/*     */ 
/*     */ 
/*     */   
/*  55 */   private int port = 143;
/*     */ 
/*     */   
/*     */   private String host;
/*     */ 
/*     */   
/*     */   private String user;
/*     */   
/*     */   private String password;
/*     */   
/*     */   private Vector folders;
/*     */ 
/*     */   
/*     */   public IMAPStore(Session paramSession, URLName paramURLName) {
/*  69 */     super(paramSession, paramURLName);
/*     */ 
/*     */     
/*  72 */     if (paramURLName != null) {
/*  73 */       this.name = paramURLName.getProtocol();
/*     */     }
/*  75 */     String str = paramSession.getProperty("mail." + this.name + ".partialfetch");
/*     */     
/*  77 */     if (str != null && str.equalsIgnoreCase("false")) {
/*     */       
/*  79 */       this.blksize = -1; return;
/*     */     } 
/*  81 */     if ((str = paramSession.getProperty("mail." + this.name + ".fetchsize")) != null)
/*     */     {
/*     */       
/*  84 */       this.blksize = Integer.parseInt(str);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean protocolConnect(String paramString1, int paramInt, String paramString2, String paramString3) throws MessagingException {
/*  96 */     if (paramString1 == null || paramString3 == null || paramString2 == null) {
/*  97 */       return false;
/*     */     }
/*     */     
/* 100 */     if (paramInt != -1) {
/* 101 */       this.port = paramInt;
/*     */     } else {
/* 103 */       String str = this.session.getProperty("mail." + this.name + ".port");
/* 104 */       if (str != null) {
/* 105 */         this.port = Integer.parseInt(str);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 110 */     if (this.port == -1) {
/* 111 */       this.port = 143;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 116 */       if (this.protocol == null) {
/* 117 */         this.protocol = new IMAPProtocol(this.name, paramString1, this.port, 
/* 118 */             this.session.getDebug(), 
/* 119 */             this.session.getProperties());
/*     */       }
/* 121 */       login(this.protocol, paramString2, paramString3);
/* 122 */       this.protocol.addResponseHandler(this);
/*     */       
/* 124 */       this.host = paramString1;
/* 125 */       this.user = paramString2;
/* 126 */       this.password = paramString3;
/* 127 */       return true;
/* 128 */     } catch (CommandFailedException commandFailedException) {
/*     */       
/* 130 */       this.protocol.disconnect();
/* 131 */       this.protocol = null;
/* 132 */       return false;
/* 133 */     } catch (ProtocolException protocolException) {
/* 134 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/* 135 */     } catch (IOException iOException) {
/* 136 */       throw new MessagingException(iOException.getMessage(), iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void login(IMAPProtocol paramIMAPProtocol, String paramString1, String paramString2) throws ProtocolException {
/* 142 */     if (paramIMAPProtocol.hasCapability("AUTH-LOGIN") || 
/* 143 */       paramIMAPProtocol.hasCapability("AUTH=LOGIN")) {
/* 144 */       paramIMAPProtocol.authlogin(paramString1, paramString2); return;
/*     */     } 
/* 146 */     paramIMAPProtocol.login(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IMAPProtocol getProtocol(IMAPFolder paramIMAPFolder) throws MessagingException {
/* 156 */     IMAPProtocol iMAPProtocol = null;
/*     */ 
/*     */     
/*     */     try {
/* 160 */       iMAPProtocol = new IMAPProtocol(this.name, this.host, this.port, 
/* 161 */           this.session.getDebug(), 
/* 162 */           this.session.getProperties());
/*     */ 
/*     */       
/* 165 */       login(iMAPProtocol, this.user, this.password);
/* 166 */     } catch (Exception exception) {
/* 167 */       if (iMAPProtocol != null)
/*     */         try {
/* 169 */           iMAPProtocol.logout();
/* 170 */         } catch (Exception exception1) {} 
/* 171 */       iMAPProtocol = null;
/*     */     } 
/*     */     
/* 174 */     if (iMAPProtocol == null) {
/* 175 */       throw new MessagingException("connection failure");
/*     */     }
/*     */     
/* 178 */     if (paramIMAPFolder != null) {
/* 179 */       synchronized (this) {
/* 180 */         if (this.folders == null)
/* 181 */           this.folders = new Vector(); 
/* 182 */         this.folders.addElement(paramIMAPFolder);
/*     */ 
/*     */         
/* 185 */         paramIMAPFolder.addConnectionListener(this);
/*     */       } 
/*     */     }
/*     */     
/* 189 */     return iMAPProtocol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 196 */   IMAPProtocol getProtocol() { return this.protocol; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   int getFetchBlockSize() { return this.blksize; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConnected() {
/* 211 */     if (!super.isConnected())
/*     */     {
/*     */       
/* 214 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 232 */       this.protocol.noop();
/* 233 */     } catch (ProtocolException protocolException) {}
/*     */     
/* 235 */     return super.isConnected();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws MessagingException {
/* 242 */     if (!super.isConnected()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 259 */       this.protocol.logout(); return;
/* 260 */     } catch (ProtocolException protocolException) {
/*     */       
/* 262 */       cleanup();
/* 263 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void finalize() throws MessagingException {
/* 268 */     super.finalize();
/* 269 */     close();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void cleanup() throws MessagingException {
/* 275 */     if (this.folders != null) {
/* 276 */       byte b; int i; for (b = 0, i = this.folders.size(); b < i; b++) {
/* 277 */         IMAPFolder iMAPFolder = (IMAPFolder)this.folders.elementAt(b);
/*     */         
/* 279 */         iMAPFolder.removeConnectionListener(this);
/*     */         try {
/* 281 */           iMAPFolder.close(false);
/* 282 */         } catch (MessagingException messagingException) {}
/*     */       } 
/*     */ 
/*     */       
/* 286 */       this.folders = null;
/*     */     } 
/*     */     
/* 289 */     this.protocol = null;
/*     */ 
/*     */     
/*     */     try {
/* 293 */       super.close(); return;
/* 294 */     } catch (MessagingException messagingException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Folder getDefaultFolder() throws MessagingException {
/* 302 */     checkConnected();
/* 303 */     return new DefaultFolder(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Folder getFolder(String paramString) throws MessagingException {
/* 310 */     checkConnected();
/* 311 */     return new IMAPFolder(paramString, '￿', this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Folder getFolder(URLName paramURLName) throws MessagingException {
/* 318 */     checkConnected();
/* 319 */     return new IMAPFolder(paramURLName.getFile(), 
/* 320 */         '￿', 
/* 321 */         this);
/*     */   }
/*     */   
/*     */   private void checkConnected() throws MessagingException {
/* 325 */     if (!super.isConnected()) {
/* 326 */       throw new IllegalStateException("Not connected");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void opened(ConnectionEvent paramConnectionEvent) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnected(ConnectionEvent paramConnectionEvent) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void closed(ConnectionEvent paramConnectionEvent) {
/* 341 */     if (this.folders != null) {
/* 342 */       this.folders.removeElement(paramConnectionEvent.getSource());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleResponse(Response paramResponse) {
/* 349 */     if (paramResponse.isBYE()) {
/*     */       
/* 351 */       if (super.isConnected())
/* 352 */         cleanup(); 
/*     */       return;
/*     */     } 
/* 355 */     if (paramResponse.isOK()) {
/*     */       
/* 357 */       String str = paramResponse.toString();
/* 358 */       if (str.indexOf("ALERT") != -1) {
/* 359 */         notifyStoreListeners(1, str); return;
/*     */       } 
/* 361 */       notifyStoreListeners(2, str);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\IMAPStore.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */