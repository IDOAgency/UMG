package com.sun.mail.imap;

import com.sun.mail.iap.CommandFailedException;
import com.sun.mail.iap.ConnectionException;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import com.sun.mail.imap.protocol.BODY;
import com.sun.mail.imap.protocol.BODYSTRUCTURE;
import com.sun.mail.imap.protocol.ENVELOPE;
import com.sun.mail.imap.protocol.FetchResponse;
import com.sun.mail.imap.protocol.IMAPProtocol;
import com.sun.mail.imap.protocol.INTERNALDATE;
import com.sun.mail.imap.protocol.Item;
import com.sun.mail.imap.protocol.MessageSet;
import com.sun.mail.imap.protocol.RFC822DATA;
import com.sun.mail.imap.protocol.RFC822SIZE;
import com.sun.mail.imap.protocol.UID;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.activation.DataHandler;
import javax.mail.Address;
import javax.mail.FetchProfile;
import javax.mail.Flags;
import javax.mail.FolderClosedException;
import javax.mail.IllegalWriteException;
import javax.mail.Message;
import javax.mail.MessageRemovedException;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.UIDFolder;
import javax.mail.internet.ContentType;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;

public class IMAPMessage extends MimeMessage {
  protected BODYSTRUCTURE bs;
  
  protected ENVELOPE envelope;
  
  private Date receivedDate;
  
  private int size = -1;
  
  private int seqnum;
  
  private long uid = -1L;
  
  protected String sectionId;
  
  private String type;
  
  private String subject;
  
  private String description;
  
  private boolean headersLoaded = false;
  
  private Hashtable loadedHeaders;
  
  private static String EnvelopeCmd = "ENVELOPE INTERNALDATE RFC822.SIZE";
  
  protected IMAPMessage(IMAPFolder paramIMAPFolder, int paramInt1, int paramInt2) {
    super(paramIMAPFolder, paramInt1);
    this.seqnum = paramInt2;
    this.flags = null;
  }
  
  protected IMAPMessage(Session paramSession) { super(paramSession); }
  
  protected IMAPProtocol getProtocol() throws FolderClosedException {
    IMAPProtocol iMAPProtocol = ((IMAPFolder)this.folder).protocol;
    if (iMAPProtocol == null)
      throw new FolderClosedException(this.folder); 
    return iMAPProtocol;
  }
  
  protected Object getMessageCacheLock() { return ((IMAPFolder)this.folder).messageCacheLock; }
  
  protected int getSequenceNumber() { return this.seqnum; }
  
  protected void setSequenceNumber(int paramInt) { this.seqnum = paramInt; }
  
  protected void setMessageNumber(int paramInt) { super.setMessageNumber(paramInt); }
  
  protected long getUID() { return this.uid; }
  
  protected void setUID(long paramLong) { this.uid = paramLong; }
  
  protected void setExpunged(boolean paramBoolean) {
    super.setExpunged(paramBoolean);
    this.seqnum = -1;
  }
  
  protected void checkExpunged() throws MessageRemovedException {
    if (this.expunged)
      throw new MessageRemovedException(); 
  }
  
  protected int getFetchBlockSize() { return ((IMAPStore)this.folder.getStore()).getFetchBlockSize(); }
  
  public Address[] getFrom() throws MessagingException {
    checkExpunged();
    loadEnvelope();
    return this.envelope.from;
  }
  
  public void setFrom(Address paramAddress) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public void addFrom(Address[] paramArrayOfAddress) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public Address[] getRecipients(Message.RecipientType paramRecipientType) throws MessagingException {
    checkExpunged();
    loadEnvelope();
    if (paramRecipientType == Message.RecipientType.TO)
      return this.envelope.to; 
    if (paramRecipientType == Message.RecipientType.CC)
      return this.envelope.cc; 
    if (paramRecipientType == Message.RecipientType.BCC)
      return this.envelope.bcc; 
    return super.getRecipients(paramRecipientType);
  }
  
  public void setRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public void addRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public Address[] getReplyTo() throws MessagingException {
    checkExpunged();
    loadEnvelope();
    return this.envelope.replyTo;
  }
  
  public void setReplyTo(Address[] paramArrayOfAddress) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public String getSubject() throws MessagingException {
    checkExpunged();
    if (this.subject != null)
      return this.subject; 
    loadEnvelope();
    if (this.envelope.subject == null)
      return null; 
    try {
      this.subject = MimeUtility.decodeText(this.envelope.subject);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      this.subject = this.envelope.subject;
    } 
    return this.subject;
  }
  
  public void setSubject(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public Date getSentDate() throws MessagingException {
    checkExpunged();
    loadEnvelope();
    return this.envelope.date;
  }
  
  public void setSentDate(Date paramDate) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public Date getReceivedDate() throws MessagingException {
    checkExpunged();
    loadEnvelope();
    return this.receivedDate;
  }
  
  public int getSize() {
    checkExpunged();
    loadEnvelope();
    return this.size;
  }
  
  public int getLineCount() {
    checkExpunged();
    loadBODYSTRUCTURE();
    return this.bs.lines;
  }
  
  public String getContentType() throws MessagingException {
    checkExpunged();
    if (this.type == null) {
      loadBODYSTRUCTURE();
      ContentType contentType = new ContentType(this.bs.type, this.bs.subtype, this.bs.cParams);
      this.type = contentType.toString();
    } 
    return this.type;
  }
  
  public String getDisposition() throws MessagingException {
    checkExpunged();
    loadBODYSTRUCTURE();
    return this.bs.disposition;
  }
  
  public void setDisposition(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public String getEncoding() throws MessagingException {
    checkExpunged();
    loadBODYSTRUCTURE();
    return this.bs.encoding;
  }
  
  public String getContentID() throws MessagingException {
    checkExpunged();
    loadBODYSTRUCTURE();
    return this.bs.id;
  }
  
  public void setContentID(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public String getContentMD5() throws MessagingException {
    checkExpunged();
    loadBODYSTRUCTURE();
    return this.bs.md5;
  }
  
  public void setContentMD5(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public String getDescription() throws MessagingException {
    checkExpunged();
    if (this.description != null)
      return this.description; 
    loadBODYSTRUCTURE();
    if (this.bs.description == null)
      return null; 
    try {
      this.description = MimeUtility.decodeText(this.bs.description);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      this.description = this.bs.description;
    } 
    return this.description;
  }
  
  public void setDescription(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public String getMessageID() throws MessagingException {
    checkExpunged();
    loadEnvelope();
    return this.envelope.messageId;
  }
  
  public String getFileName() throws MessagingException {
    checkExpunged();
    String str = null;
    loadBODYSTRUCTURE();
    if (this.bs.dParams != null)
      str = this.bs.dParams.get("filename"); 
    if (str == null && this.bs.cParams != null)
      str = this.bs.cParams.get("name"); 
    return str;
  }
  
  public void setFileName(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  protected InputStream getContentStream() throws MessagingException {
    IMAPProtocol iMAPProtocol = getProtocol();
    if (iMAPProtocol.isREV1() && getFetchBlockSize() != -1)
      return new IMAPInputStream(this, toSection("TEXT"), 
          (this.bs != null) ? this.bs.size : -1); 
    ByteArrayInputStream byteArrayInputStream = null;
    synchronized (getMessageCacheLock()) {
      checkExpunged();
      try {
        RFC822DATA rFC822DATA = iMAPProtocol.fetchRFC822(getSequenceNumber(), "TEXT");
        if (rFC822DATA != null)
          byteArrayInputStream = rFC822DATA.getByteArrayInputStream(); 
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(this.folder, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
    } 
    if (byteArrayInputStream == null)
      throw new MessagingException("No content"); 
    return byteArrayInputStream;
  }
  
  public DataHandler getDataHandler() throws MessagingException {
    checkExpunged();
    if (this.dh == null) {
      loadBODYSTRUCTURE();
      if (this.type == null) {
        ContentType contentType = new ContentType(this.bs.type, this.bs.subtype, 
            this.bs.cParams);
        this.type = contentType.toString();
      } 
      if (this.bs.isMulti()) {
        this.dh = new DataHandler(
            new IMAPMultipartDataSource(this, this.bs.bodies, 
              this.sectionId, this));
      } else if (this.bs.isNested() && getProtocol().isREV1()) {
        this.dh = new DataHandler(
            new IMAPNestedMessage(this, 
              this.bs.bodies[0], 
              this.bs.envelope, 
              (this.sectionId == null) ? "1" : (String.valueOf(this.sectionId) + ".1")), 
            this.type);
      } 
    } 
    return super.getDataHandler();
  }
  
  public void setDataHandler(DataHandler paramDataHandler) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public void writeTo(OutputStream paramOutputStream) throws IOException, MessagingException {
    IMAPProtocol iMAPProtocol = getProtocol();
    ByteArrayInputStream byteArrayInputStream = null;
    synchronized (getMessageCacheLock()) {
      checkExpunged();
      try {
        if (iMAPProtocol.isREV1()) {
          BODY bODY = iMAPProtocol.fetchBody(getSequenceNumber(), this.sectionId);
          if (bODY != null)
            byteArrayInputStream = bODY.getByteArrayInputStream(); 
        } else {
          RFC822DATA rFC822DATA = iMAPProtocol.fetchRFC822(getSequenceNumber(), null);
          if (rFC822DATA != null)
            byteArrayInputStream = rFC822DATA.getByteArrayInputStream(); 
        } 
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(this.folder, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
    } 
    if (byteArrayInputStream == null)
      throw new MessagingException("No content"); 
    byte[] arrayOfByte = new byte[1024];
    int i;
    while ((i = byteArrayInputStream.read(arrayOfByte)) != -1)
      paramOutputStream.write(arrayOfByte, 0, i); 
  }
  
  public String[] getHeader(String paramString) throws MessagingException {
    checkExpunged();
    if (isHeaderLoaded(paramString))
      return this.headers.getHeader(paramString); 
    IMAPProtocol iMAPProtocol = getProtocol();
    ByteArrayInputStream byteArrayInputStream = null;
    synchronized (getMessageCacheLock()) {
      checkExpunged();
      try {
        if (iMAPProtocol.isREV1()) {
          BODY bODY = iMAPProtocol.peekBody(getSequenceNumber(), 
              toSection("HEADER.FIELDS (" + paramString + ")"));
          if (bODY != null)
            byteArrayInputStream = bODY.getByteArrayInputStream(); 
        } else {
          RFC822DATA rFC822DATA = iMAPProtocol.fetchRFC822(getSequenceNumber(), 
              "HEADER.LINES (" + paramString + ")");
          if (rFC822DATA != null)
            byteArrayInputStream = rFC822DATA.getByteArrayInputStream(); 
        } 
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(this.folder, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
    } 
    if (this.headers == null)
      this.headers = new InternetHeaders(); 
    this.headers.load(byteArrayInputStream);
    setHeaderLoaded(paramString);
    return this.headers.getHeader(paramString);
  }
  
  public String getHeader(String paramString1, String paramString2) throws MessagingException {
    checkExpunged();
    if (getHeader(paramString1) == null)
      return null; 
    return this.headers.getHeader(paramString1, paramString2);
  }
  
  public void setHeader(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public void addHeader(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public void removeHeader(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public Enumeration getAllHeaders() throws MessagingException {
    checkExpunged();
    loadHeaders();
    return super.getAllHeaders();
  }
  
  public Enumeration getMatchingHeaders(String[] paramArrayOfString) throws MessagingException {
    checkExpunged();
    loadHeaders();
    return super.getMatchingHeaders(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaders(String[] paramArrayOfString) throws MessagingException {
    checkExpunged();
    loadHeaders();
    return super.getNonMatchingHeaders(paramArrayOfString);
  }
  
  public void addHeaderLine(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
  
  public Enumeration getAllHeaderLines() throws MessagingException {
    checkExpunged();
    loadHeaders();
    return super.getAllHeaderLines();
  }
  
  public Enumeration getMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException {
    checkExpunged();
    loadHeaders();
    return super.getMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException {
    checkExpunged();
    loadHeaders();
    return super.getNonMatchingHeaderLines(paramArrayOfString);
  }
  
  public Flags getFlags() throws MessagingException {
    checkExpunged();
    loadFlags();
    return super.getFlags();
  }
  
  public boolean isSet(Flags.Flag paramFlag) throws MessagingException {
    checkExpunged();
    loadFlags();
    return super.isSet(paramFlag);
  }
  
  public void setFlags(Flags paramFlags, boolean paramBoolean) throws MessagingException {
    synchronized (getMessageCacheLock()) {
      checkExpunged();
      try {
        getProtocol().storeFlags(getSequenceNumber(), paramFlags, paramBoolean);
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(this.folder, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
      return;
    } 
  }
  
  static void fetch(IMAPFolder paramIMAPFolder, Message[] paramArrayOfMessage, FetchProfile paramFetchProfile) throws MessagingException {
    private class $FetchProfileCondition implements Utility.Condition {
      private boolean needEnvelope = false;
      
      private boolean needFlags = false;
      
      private boolean needBodyStructure = false;
      
      private boolean needUID = false;
      
      private String[] hdrs;
      
      public $FetchProfileCondition(IMAPMessage this$0) {
        if (this$0.contains(FetchProfile.Item.ENVELOPE))
          this.needEnvelope = true; 
        if (this$0.contains(FetchProfile.Item.FLAGS))
          this.needFlags = true; 
        if (this$0.contains(FetchProfile.Item.CONTENT_INFO))
          this.needBodyStructure = true; 
        if (this$0.contains(UIDFolder.FetchProfileItem.UID))
          this.needUID = true; 
        this.hdrs = this$0.getHeaderNames();
      }
      
      public boolean test(IMAPMessage param1IMAPMessage) {
        if (this.needEnvelope && param1IMAPMessage._getEnvelope() == null)
          return true; 
        if (this.needFlags && param1IMAPMessage._getFlags() == null)
          return true; 
        if (this.needBodyStructure && param1IMAPMessage._getBodyStructure() == null)
          return true; 
        if (this.needUID && param1IMAPMessage.getUID() == -1L)
          return true; 
        for (byte b = 0; b < this.hdrs.length; b++) {
          if (!param1IMAPMessage.isHeaderLoaded(this.hdrs[b]))
            return true; 
        } 
        return false;
      }
    };
    StringBuffer stringBuffer = new StringBuffer();
    boolean bool = true;
    if (paramFetchProfile.contains(FetchProfile.Item.ENVELOPE)) {
      stringBuffer.append(EnvelopeCmd);
      bool = false;
    } 
    if (paramFetchProfile.contains(FetchProfile.Item.FLAGS)) {
      stringBuffer.append(bool ? "FLAGS" : " FLAGS");
      bool = false;
    } 
    if (paramFetchProfile.contains(FetchProfile.Item.CONTENT_INFO)) {
      stringBuffer.append(bool ? "BODYSTRUCTURE" : " BODYSTRUCTURE");
      bool = false;
    } 
    if (paramFetchProfile.contains(UIDFolder.FetchProfileItem.UID)) {
      stringBuffer.append(bool ? "UID" : " UID");
      bool = false;
    } 
    String[] arrayOfString = paramFetchProfile.getHeaderNames();
    if (arrayOfString.length > 0) {
      if (!bool)
        stringBuffer.append(" "); 
      stringBuffer.append(craftHeaderCmd(paramIMAPFolder.protocol, arrayOfString));
    } 
    $FetchProfileCondition $FetchProfileCondition = new $FetchProfileCondition(paramFetchProfile);
    synchronized (paramIMAPFolder.messageCacheLock) {
      MessageSet[] arrayOfMessageSet = Utility.toMessageSet(paramArrayOfMessage, $FetchProfileCondition);
      if (arrayOfMessageSet == null)
        return; 
      Response[] arrayOfResponse = null;
      Vector vector = new Vector();
      try {
        arrayOfResponse = paramIMAPFolder.protocol.fetch(arrayOfMessageSet, stringBuffer.toString());
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(paramIMAPFolder, connectionException.getMessage());
      } catch (CommandFailedException commandFailedException) {
      
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
      if (arrayOfResponse == null)
        return; 
      for (byte b = 0; b < arrayOfResponse.length; b++) {
        if (arrayOfResponse[b] != null)
          if (!(arrayOfResponse[b] instanceof FetchResponse)) {
            vector.addElement(arrayOfResponse[b]);
          } else {
            FetchResponse fetchResponse = (FetchResponse)arrayOfResponse[b];
            IMAPMessage iMAPMessage = paramIMAPFolder.getMessageBySeqNumber(fetchResponse.getNumber());
            int j = fetchResponse.getItemCount();
            boolean bool1 = false;
            for (byte b1 = 0; b1 < j; b1++) {
              Item item = fetchResponse.getItem(b1);
              if (item instanceof Flags) {
                if (!paramFetchProfile.contains(FetchProfile.Item.FLAGS) || 
                  iMAPMessage == null) {
                  bool1 = true;
                } else {
                  iMAPMessage.flags = (Flags)item;
                } 
              } else if (item instanceof ENVELOPE) {
                iMAPMessage.envelope = (ENVELOPE)item;
              } else if (item instanceof INTERNALDATE) {
                iMAPMessage.receivedDate = ((INTERNALDATE)item).getDate();
              } else if (item instanceof RFC822SIZE) {
                iMAPMessage.size = ((RFC822SIZE)item).size;
              } else if (item instanceof BODYSTRUCTURE) {
                iMAPMessage.bs = (BODYSTRUCTURE)item;
              } else if (item instanceof UID) {
                UID uID = (UID)item;
                iMAPMessage.uid = uID.uid;
                if (paramIMAPFolder.uidTable == null)
                  paramIMAPFolder.uidTable = new Hashtable(); 
                paramIMAPFolder.uidTable.put(new Long(uID.uid), iMAPMessage);
              } else if (item instanceof RFC822DATA || 
                item instanceof BODY) {
                ByteArrayInputStream byteArrayInputStream;
                if (item instanceof RFC822DATA) {
                  byteArrayInputStream = (
                    (RFC822DATA)item).getByteArrayInputStream();
                } else {
                  byteArrayInputStream = (
                    (BODY)item).getByteArrayInputStream();
                } 
                if (iMAPMessage.headers == null)
                  iMAPMessage.headers = new InternetHeaders(); 
                iMAPMessage.headers.load(byteArrayInputStream);
                for (byte b2 = 0; b2 < arrayOfString.length; b2++)
                  iMAPMessage.setHeaderLoaded(arrayOfString[b2]); 
              } 
            } 
            if (bool1)
              vector.addElement(fetchResponse); 
          }  
      } 
      int i = vector.size();
      if (i != 0) {
        Response[] arrayOfResponse1 = new Response[i];
        vector.copyInto(arrayOfResponse1);
        paramIMAPFolder.handleResponses(arrayOfResponse1);
      } 
      return;
    } 
  }
  
  private void loadEnvelope() throws MessageRemovedException {
    if (this.envelope != null)
      return; 
    IMAPProtocol iMAPProtocol = getProtocol();
    Response[] arrayOfResponse = null;
    synchronized (getMessageCacheLock()) {
      checkExpunged();
      int i = getSequenceNumber();
      try {
        arrayOfResponse = iMAPProtocol.fetch(i, EnvelopeCmd);
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(this.folder, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
      if (arrayOfResponse == null)
        return; 
      for (byte b = 0; b < arrayOfResponse.length; b++) {
        if (arrayOfResponse[b] != null && 
          arrayOfResponse[b] instanceof FetchResponse && (
          (FetchResponse)arrayOfResponse[b]).getNumber() == i) {
          FetchResponse fetchResponse = (FetchResponse)arrayOfResponse[b];
          int j = fetchResponse.getItemCount();
          for (byte b1 = 0; b1 < j; b1++) {
            Item item = fetchResponse.getItem(b1);
            if (item instanceof ENVELOPE) {
              this.envelope = (ENVELOPE)item;
            } else if (item instanceof INTERNALDATE) {
              this.receivedDate = ((INTERNALDATE)item).getDate();
            } else if (item instanceof RFC822SIZE) {
              this.size = ((RFC822SIZE)item).size;
            } 
          } 
        } 
      } 
      ((IMAPFolder)this.folder).handleResponses(arrayOfResponse);
      return;
    } 
  }
  
  private static String craftHeaderCmd(IMAPProtocol paramIMAPProtocol, String[] paramArrayOfString) {
    StringBuffer stringBuffer;
    if (paramIMAPProtocol.isREV1()) {
      stringBuffer = new StringBuffer("BODY.PEEK[HEADER.FIELDS (");
    } else {
      stringBuffer = new StringBuffer("RFC822.HEADER.LINES (");
    } 
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      if (b)
        stringBuffer.append(" "); 
      stringBuffer.append(paramArrayOfString[b]);
    } 
    if (paramIMAPProtocol.isREV1()) {
      stringBuffer.append(")]");
    } else {
      stringBuffer.append(")");
    } 
    return stringBuffer.toString();
  }
  
  private void loadBODYSTRUCTURE() throws MessageRemovedException {
    if (this.bs != null)
      return; 
    synchronized (getMessageCacheLock()) {
      checkExpunged();
      try {
        this.bs = getProtocol().fetchBodyStructure(getSequenceNumber());
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(this.folder, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
      return;
    } 
  }
  
  private void loadHeaders() throws MessageRemovedException {
    if (this.headersLoaded)
      return; 
    IMAPProtocol iMAPProtocol = getProtocol();
    ByteArrayInputStream byteArrayInputStream = null;
    synchronized (getMessageCacheLock()) {
      checkExpunged();
      try {
        if (iMAPProtocol.isREV1()) {
          BODY bODY = iMAPProtocol.peekBody(getSequenceNumber(), 
              toSection("HEADER"));
          if (bODY != null)
            byteArrayInputStream = bODY.getByteArrayInputStream(); 
        } else {
          RFC822DATA rFC822DATA = iMAPProtocol.fetchRFC822(getSequenceNumber(), 
              "HEADER");
          if (rFC822DATA != null)
            byteArrayInputStream = rFC822DATA.getByteArrayInputStream(); 
        } 
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(this.folder, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
    } 
    if (byteArrayInputStream == null)
      throw new MessagingException("Cannot load header"); 
    this.headers = new InternetHeaders(byteArrayInputStream);
    this.headersLoaded = true;
  }
  
  private void loadFlags() throws MessageRemovedException {
    if (this.flags != null)
      return; 
    synchronized (getMessageCacheLock()) {
      checkExpunged();
      try {
        this.flags = getProtocol().fetchFlags(getSequenceNumber());
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(this.folder, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
      return;
    } 
  }
  
  private boolean isHeaderLoaded(String paramString) {
    if (this.headersLoaded)
      return true; 
    return (this.loadedHeaders != null) ? 
      this.loadedHeaders.containsKey(paramString.toUpperCase()) : 0;
  }
  
  private void setHeaderLoaded(String paramString) throws MessagingException {
    if (this.loadedHeaders == null)
      this.loadedHeaders = new Hashtable(1); 
    this.loadedHeaders.put(paramString.toUpperCase(), paramString);
  }
  
  private String toSection(String paramString) {
    if (this.sectionId == null)
      return paramString; 
    return String.valueOf(this.sectionId) + "." + paramString;
  }
  
  void _setFlags(Flags paramFlags) { this.flags = paramFlags; }
  
  Flags _getFlags() throws MessagingException { return this.flags; }
  
  ENVELOPE _getEnvelope() { return this.envelope; }
  
  BODYSTRUCTURE _getBodyStructure() { return this.bs; }
  
  Session _getSession() { return this.session; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\IMAPMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */