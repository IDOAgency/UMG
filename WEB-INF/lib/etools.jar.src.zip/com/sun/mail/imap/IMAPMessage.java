/*      */ package com.sun.mail.imap;
/*      */ 
/*      */ import com.sun.mail.iap.CommandFailedException;
/*      */ import com.sun.mail.iap.ConnectionException;
/*      */ import com.sun.mail.iap.ProtocolException;
/*      */ import com.sun.mail.iap.Response;
/*      */ import com.sun.mail.imap.protocol.BODY;
/*      */ import com.sun.mail.imap.protocol.BODYSTRUCTURE;
/*      */ import com.sun.mail.imap.protocol.ENVELOPE;
/*      */ import com.sun.mail.imap.protocol.FetchResponse;
/*      */ import com.sun.mail.imap.protocol.IMAPProtocol;
/*      */ import com.sun.mail.imap.protocol.INTERNALDATE;
/*      */ import com.sun.mail.imap.protocol.Item;
/*      */ import com.sun.mail.imap.protocol.MessageSet;
/*      */ import com.sun.mail.imap.protocol.RFC822DATA;
/*      */ import com.sun.mail.imap.protocol.RFC822SIZE;
/*      */ import com.sun.mail.imap.protocol.UID;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ import javax.activation.DataHandler;
/*      */ import javax.mail.Address;
/*      */ import javax.mail.FetchProfile;
/*      */ import javax.mail.Flags;
/*      */ import javax.mail.FolderClosedException;
/*      */ import javax.mail.IllegalWriteException;
/*      */ import javax.mail.Message;
/*      */ import javax.mail.MessageRemovedException;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.Session;
/*      */ import javax.mail.UIDFolder;
/*      */ import javax.mail.internet.ContentType;
/*      */ import javax.mail.internet.InternetHeaders;
/*      */ import javax.mail.internet.MimeMessage;
/*      */ import javax.mail.internet.MimeUtility;
/*      */ 
/*      */ public class IMAPMessage extends MimeMessage {
/*   44 */   private int size = -1;
/*      */   protected BODYSTRUCTURE bs;
/*      */   protected ENVELOPE envelope;
/*      */   private Date receivedDate;
/*      */   private int seqnum;
/*   49 */   private long uid = -1L;
/*      */ 
/*      */ 
/*      */   
/*      */   protected String sectionId;
/*      */ 
/*      */ 
/*      */   
/*      */   private String type;
/*      */ 
/*      */ 
/*      */   
/*      */   private String subject;
/*      */ 
/*      */ 
/*      */   
/*      */   private String description;
/*      */ 
/*      */   
/*      */   private boolean headersLoaded = false;
/*      */ 
/*      */   
/*      */   private Hashtable loadedHeaders;
/*      */ 
/*      */   
/*   74 */   private static String EnvelopeCmd = "ENVELOPE INTERNALDATE RFC822.SIZE";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IMAPMessage(IMAPFolder paramIMAPFolder, int paramInt1, int paramInt2) {
/*   80 */     super(paramIMAPFolder, paramInt1);
/*   81 */     this.seqnum = paramInt2;
/*   82 */     this.flags = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   89 */   protected IMAPMessage(Session paramSession) { super(paramSession); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IMAPProtocol getProtocol() throws FolderClosedException {
/*   98 */     IMAPProtocol iMAPProtocol = ((IMAPFolder)this.folder).protocol;
/*   99 */     if (iMAPProtocol == null) {
/*  100 */       throw new FolderClosedException(this.folder);
/*      */     }
/*  102 */     return iMAPProtocol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  110 */   protected Object getMessageCacheLock() { return ((IMAPFolder)this.folder).messageCacheLock; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  120 */   protected int getSequenceNumber() { return this.seqnum; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  130 */   protected void setSequenceNumber(int paramInt) { this.seqnum = paramInt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   protected void setMessageNumber(int paramInt) { super.setMessageNumber(paramInt); }
/*      */ 
/*      */ 
/*      */   
/*  142 */   protected long getUID() { return this.uid; }
/*      */ 
/*      */ 
/*      */   
/*  146 */   protected void setUID(long paramLong) { this.uid = paramLong; }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setExpunged(boolean paramBoolean) {
/*  151 */     super.setExpunged(paramBoolean);
/*  152 */     this.seqnum = -1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void checkExpunged() throws MessageRemovedException {
/*  157 */     if (this.expunged) {
/*  158 */       throw new MessageRemovedException();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*  163 */   protected int getFetchBlockSize() { return ((IMAPStore)this.folder.getStore()).getFetchBlockSize(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Address[] getFrom() throws MessagingException {
/*  170 */     checkExpunged();
/*  171 */     loadEnvelope();
/*  172 */     return this.envelope.from;
/*      */   }
/*      */ 
/*      */   
/*  176 */   public void setFrom(Address paramAddress) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */   
/*  180 */   public void addFrom(Address[] paramArrayOfAddress) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Address[] getRecipients(Message.RecipientType paramRecipientType) throws MessagingException {
/*  188 */     checkExpunged();
/*  189 */     loadEnvelope();
/*      */     
/*  191 */     if (paramRecipientType == Message.RecipientType.TO)
/*  192 */       return this.envelope.to; 
/*  193 */     if (paramRecipientType == Message.RecipientType.CC)
/*  194 */       return this.envelope.cc; 
/*  195 */     if (paramRecipientType == Message.RecipientType.BCC) {
/*  196 */       return this.envelope.bcc;
/*      */     }
/*  198 */     return super.getRecipients(paramRecipientType);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  203 */   public void setRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  208 */   public void addRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Address[] getReplyTo() throws MessagingException {
/*  215 */     checkExpunged();
/*  216 */     loadEnvelope();
/*  217 */     return this.envelope.replyTo;
/*      */   }
/*      */ 
/*      */   
/*  221 */   public void setReplyTo(Address[] paramArrayOfAddress) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSubject() throws MessagingException {
/*  228 */     checkExpunged();
/*      */     
/*  230 */     if (this.subject != null) {
/*  231 */       return this.subject;
/*      */     }
/*  233 */     loadEnvelope();
/*  234 */     if (this.envelope.subject == null) {
/*  235 */       return null;
/*      */     }
/*      */     
/*      */     try {
/*  239 */       this.subject = MimeUtility.decodeText(this.envelope.subject);
/*  240 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*  241 */       this.subject = this.envelope.subject;
/*      */     } 
/*      */     
/*  244 */     return this.subject;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  249 */   public void setSubject(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getSentDate() throws MessagingException {
/*  256 */     checkExpunged();
/*  257 */     loadEnvelope();
/*  258 */     return this.envelope.date;
/*      */   }
/*      */ 
/*      */   
/*  262 */   public void setSentDate(Date paramDate) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getReceivedDate() throws MessagingException {
/*  269 */     checkExpunged();
/*  270 */     loadEnvelope();
/*  271 */     return this.receivedDate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSize() {
/*  281 */     checkExpunged();
/*  282 */     loadEnvelope();
/*  283 */     return this.size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLineCount() {
/*  294 */     checkExpunged();
/*  295 */     loadBODYSTRUCTURE();
/*  296 */     return this.bs.lines;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContentType() throws MessagingException {
/*  306 */     checkExpunged();
/*      */ 
/*      */     
/*  309 */     if (this.type == null) {
/*  310 */       loadBODYSTRUCTURE();
/*      */       
/*  312 */       ContentType contentType = new ContentType(this.bs.type, this.bs.subtype, this.bs.cParams);
/*  313 */       this.type = contentType.toString();
/*      */     } 
/*  315 */     return this.type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDisposition() throws MessagingException {
/*  322 */     checkExpunged();
/*  323 */     loadBODYSTRUCTURE();
/*  324 */     return this.bs.disposition;
/*      */   }
/*      */ 
/*      */   
/*  328 */   public void setDisposition(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getEncoding() throws MessagingException {
/*  335 */     checkExpunged();
/*  336 */     loadBODYSTRUCTURE();
/*  337 */     return this.bs.encoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContentID() throws MessagingException {
/*  344 */     checkExpunged();
/*  345 */     loadBODYSTRUCTURE();
/*  346 */     return this.bs.id;
/*      */   }
/*      */ 
/*      */   
/*  350 */   public void setContentID(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContentMD5() throws MessagingException {
/*  357 */     checkExpunged();
/*  358 */     loadBODYSTRUCTURE();
/*  359 */     return this.bs.md5;
/*      */   }
/*      */ 
/*      */   
/*  363 */   public void setContentMD5(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDescription() throws MessagingException {
/*  370 */     checkExpunged();
/*      */     
/*  372 */     if (this.description != null) {
/*  373 */       return this.description;
/*      */     }
/*  375 */     loadBODYSTRUCTURE();
/*  376 */     if (this.bs.description == null) {
/*  377 */       return null;
/*      */     }
/*      */     try {
/*  380 */       this.description = MimeUtility.decodeText(this.bs.description);
/*  381 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*  382 */       this.description = this.bs.description;
/*      */     } 
/*      */     
/*  385 */     return this.description;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  390 */   public void setDescription(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getMessageID() throws MessagingException {
/*  397 */     checkExpunged();
/*  398 */     loadEnvelope();
/*  399 */     return this.envelope.messageId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFileName() throws MessagingException {
/*  408 */     checkExpunged();
/*      */     
/*  410 */     String str = null;
/*  411 */     loadBODYSTRUCTURE();
/*      */     
/*  413 */     if (this.bs.dParams != null)
/*  414 */       str = this.bs.dParams.get("filename"); 
/*  415 */     if (str == null && this.bs.cParams != null)
/*  416 */       str = this.bs.cParams.get("name"); 
/*  417 */     return str;
/*      */   }
/*      */ 
/*      */   
/*  421 */   public void setFileName(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputStream getContentStream() throws MessagingException {
/*  432 */     IMAPProtocol iMAPProtocol = getProtocol();
/*  433 */     if (iMAPProtocol.isREV1() && getFetchBlockSize() != -1) {
/*  434 */       return new IMAPInputStream(this, toSection("TEXT"), 
/*  435 */           (this.bs != null) ? this.bs.size : -1);
/*      */     }
/*      */     
/*  438 */     ByteArrayInputStream byteArrayInputStream = null;
/*      */ 
/*      */     
/*  441 */     synchronized (getMessageCacheLock()) {
/*      */ 
/*      */ 
/*      */       
/*  445 */       checkExpunged();
/*      */       
/*      */       try {
/*  448 */         RFC822DATA rFC822DATA = iMAPProtocol.fetchRFC822(getSequenceNumber(), "TEXT");
/*  449 */         if (rFC822DATA != null)
/*  450 */           byteArrayInputStream = rFC822DATA.getByteArrayInputStream(); 
/*  451 */       } catch (ConnectionException connectionException) {
/*  452 */         throw new FolderClosedException(this.folder, connectionException.getMessage());
/*  453 */       } catch (ProtocolException protocolException) {
/*  454 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */     } 
/*      */     
/*  458 */     if (byteArrayInputStream == null) {
/*  459 */       throw new MessagingException("No content");
/*      */     }
/*  461 */     return byteArrayInputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DataHandler getDataHandler() throws MessagingException {
/*  469 */     checkExpunged();
/*      */     
/*  471 */     if (this.dh == null) {
/*  472 */       loadBODYSTRUCTURE();
/*  473 */       if (this.type == null) {
/*      */         
/*  475 */         ContentType contentType = new ContentType(this.bs.type, this.bs.subtype, 
/*  476 */             this.bs.cParams);
/*  477 */         this.type = contentType.toString();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  483 */       if (this.bs.isMulti()) {
/*  484 */         this.dh = new DataHandler(
/*  485 */             new IMAPMultipartDataSource(this, this.bs.bodies, 
/*  486 */               this.sectionId, this));
/*      */       }
/*  488 */       else if (this.bs.isNested() && getProtocol().isREV1()) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  493 */         this.dh = new DataHandler(
/*  494 */             new IMAPNestedMessage(this, 
/*  495 */               this.bs.bodies[0], 
/*  496 */               this.bs.envelope, 
/*  497 */               (this.sectionId == null) ? "1" : (String.valueOf(this.sectionId) + ".1")), 
/*  498 */             this.type);
/*      */       } 
/*      */     } 
/*      */     
/*  502 */     return super.getDataHandler();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  507 */   public void setDataHandler(DataHandler paramDataHandler) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeTo(OutputStream paramOutputStream) throws IOException, MessagingException {
/*  515 */     IMAPProtocol iMAPProtocol = getProtocol();
/*  516 */     ByteArrayInputStream byteArrayInputStream = null;
/*      */ 
/*      */     
/*  519 */     synchronized (getMessageCacheLock()) {
/*  520 */       checkExpunged();
/*      */       
/*      */       try {
/*  523 */         if (iMAPProtocol.isREV1()) {
/*  524 */           BODY bODY = iMAPProtocol.fetchBody(getSequenceNumber(), this.sectionId);
/*  525 */           if (bODY != null)
/*  526 */             byteArrayInputStream = bODY.getByteArrayInputStream(); 
/*      */         } else {
/*  528 */           RFC822DATA rFC822DATA = iMAPProtocol.fetchRFC822(getSequenceNumber(), null);
/*  529 */           if (rFC822DATA != null)
/*  530 */             byteArrayInputStream = rFC822DATA.getByteArrayInputStream(); 
/*      */         } 
/*  532 */       } catch (ConnectionException connectionException) {
/*  533 */         throw new FolderClosedException(this.folder, connectionException.getMessage());
/*  534 */       } catch (ProtocolException protocolException) {
/*  535 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */     } 
/*      */     
/*  539 */     if (byteArrayInputStream == null) {
/*  540 */       throw new MessagingException("No content");
/*      */     }
/*      */     
/*  543 */     byte[] arrayOfByte = new byte[1024];
/*      */     int i;
/*  545 */     while ((i = byteArrayInputStream.read(arrayOfByte)) != -1) {
/*  546 */       paramOutputStream.write(arrayOfByte, 0, i);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getHeader(String paramString) throws MessagingException {
/*  553 */     checkExpunged();
/*      */     
/*  555 */     if (isHeaderLoaded(paramString)) {
/*  556 */       return this.headers.getHeader(paramString);
/*      */     }
/*      */     
/*  559 */     IMAPProtocol iMAPProtocol = getProtocol();
/*  560 */     ByteArrayInputStream byteArrayInputStream = null;
/*      */ 
/*      */     
/*  563 */     synchronized (getMessageCacheLock()) {
/*      */ 
/*      */ 
/*      */       
/*  567 */       checkExpunged();
/*      */       
/*      */       try {
/*  570 */         if (iMAPProtocol.isREV1()) {
/*  571 */           BODY bODY = iMAPProtocol.peekBody(getSequenceNumber(), 
/*  572 */               toSection("HEADER.FIELDS (" + paramString + ")"));
/*      */           
/*  574 */           if (bODY != null)
/*  575 */             byteArrayInputStream = bODY.getByteArrayInputStream(); 
/*      */         } else {
/*  577 */           RFC822DATA rFC822DATA = iMAPProtocol.fetchRFC822(getSequenceNumber(), 
/*  578 */               "HEADER.LINES (" + paramString + ")");
/*  579 */           if (rFC822DATA != null)
/*  580 */             byteArrayInputStream = rFC822DATA.getByteArrayInputStream(); 
/*      */         } 
/*  582 */       } catch (ConnectionException connectionException) {
/*  583 */         throw new FolderClosedException(this.folder, connectionException.getMessage());
/*  584 */       } catch (ProtocolException protocolException) {
/*  585 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */     } 
/*      */     
/*  589 */     if (this.headers == null)
/*  590 */       this.headers = new InternetHeaders(); 
/*  591 */     this.headers.load(byteArrayInputStream);
/*  592 */     setHeaderLoaded(paramString);
/*      */     
/*  594 */     return this.headers.getHeader(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getHeader(String paramString1, String paramString2) throws MessagingException {
/*  602 */     checkExpunged();
/*      */ 
/*      */     
/*  605 */     if (getHeader(paramString1) == null)
/*  606 */       return null; 
/*  607 */     return this.headers.getHeader(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  612 */   public void setHeader(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  617 */   public void addHeader(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  622 */   public void removeHeader(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration getAllHeaders() throws MessagingException {
/*  629 */     checkExpunged();
/*  630 */     loadHeaders();
/*  631 */     return super.getAllHeaders();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration getMatchingHeaders(String[] paramArrayOfString) throws MessagingException {
/*  639 */     checkExpunged();
/*  640 */     loadHeaders();
/*  641 */     return super.getMatchingHeaders(paramArrayOfString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration getNonMatchingHeaders(String[] paramArrayOfString) throws MessagingException {
/*  649 */     checkExpunged();
/*  650 */     loadHeaders();
/*  651 */     return super.getNonMatchingHeaders(paramArrayOfString);
/*      */   }
/*      */ 
/*      */   
/*  655 */   public void addHeaderLine(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPMessage is read-only"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration getAllHeaderLines() throws MessagingException {
/*  662 */     checkExpunged();
/*  663 */     loadHeaders();
/*  664 */     return super.getAllHeaderLines();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration getMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException {
/*  672 */     checkExpunged();
/*  673 */     loadHeaders();
/*  674 */     return super.getMatchingHeaderLines(paramArrayOfString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException {
/*  682 */     checkExpunged();
/*  683 */     loadHeaders();
/*  684 */     return super.getNonMatchingHeaderLines(paramArrayOfString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flags getFlags() throws MessagingException {
/*  691 */     checkExpunged();
/*  692 */     loadFlags();
/*  693 */     return super.getFlags();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSet(Flags.Flag paramFlag) throws MessagingException {
/*  701 */     checkExpunged();
/*  702 */     loadFlags();
/*  703 */     return super.isSet(paramFlag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFlags(Flags paramFlags, boolean paramBoolean) throws MessagingException {
/*  712 */     synchronized (getMessageCacheLock()) {
/*  713 */       checkExpunged();
/*      */       
/*      */       try {
/*  716 */         getProtocol().storeFlags(getSequenceNumber(), paramFlags, paramBoolean);
/*  717 */       } catch (ConnectionException connectionException) {
/*  718 */         throw new FolderClosedException(this.folder, connectionException.getMessage());
/*  719 */       } catch (ProtocolException protocolException) {
/*  720 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void fetch(IMAPFolder paramIMAPFolder, Message[] paramArrayOfMessage, FetchProfile paramFetchProfile) throws MessagingException {
/*      */     private class $FetchProfileCondition
/*      */       implements Utility.Condition
/*      */     {
/*      */       private boolean needEnvelope = false;
/*      */ 
/*      */       
/*      */       private boolean needFlags = false;
/*      */       
/*      */       private boolean needBodyStructure = false;
/*      */       
/*      */       private boolean needUID = false;
/*      */       
/*      */       private String[] hdrs;
/*      */ 
/*      */       
/*      */       public $FetchProfileCondition(IMAPMessage this$0) {
/*  745 */         if (this$0.contains(FetchProfile.Item.ENVELOPE))
/*  746 */           this.needEnvelope = true; 
/*  747 */         if (this$0.contains(FetchProfile.Item.FLAGS))
/*  748 */           this.needFlags = true; 
/*  749 */         if (this$0.contains(FetchProfile.Item.CONTENT_INFO))
/*  750 */           this.needBodyStructure = true; 
/*  751 */         if (this$0.contains(UIDFolder.FetchProfileItem.UID))
/*  752 */           this.needUID = true; 
/*  753 */         this.hdrs = this$0.getHeaderNames();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean test(IMAPMessage param1IMAPMessage) {
/*  758 */         if (this.needEnvelope && param1IMAPMessage._getEnvelope() == null)
/*  759 */           return true; 
/*  760 */         if (this.needFlags && param1IMAPMessage._getFlags() == null)
/*  761 */           return true; 
/*  762 */         if (this.needBodyStructure && param1IMAPMessage._getBodyStructure() == null)
/*  763 */           return true; 
/*  764 */         if (this.needUID && param1IMAPMessage.getUID() == -1L) {
/*  765 */           return true;
/*      */         }
/*      */         
/*  768 */         for (byte b = 0; b < this.hdrs.length; b++) {
/*  769 */           if (!param1IMAPMessage.isHeaderLoaded(this.hdrs[b])) {
/*  770 */             return true;
/*      */           }
/*      */         } 
/*  773 */         return false;
/*      */       }
/*      */     };
/*      */     
/*  777 */     StringBuffer stringBuffer = new StringBuffer();
/*  778 */     boolean bool = true;
/*      */     
/*  780 */     if (paramFetchProfile.contains(FetchProfile.Item.ENVELOPE)) {
/*  781 */       stringBuffer.append(EnvelopeCmd);
/*  782 */       bool = false;
/*      */     } 
/*  784 */     if (paramFetchProfile.contains(FetchProfile.Item.FLAGS)) {
/*  785 */       stringBuffer.append(bool ? "FLAGS" : " FLAGS");
/*  786 */       bool = false;
/*      */     } 
/*  788 */     if (paramFetchProfile.contains(FetchProfile.Item.CONTENT_INFO)) {
/*  789 */       stringBuffer.append(bool ? "BODYSTRUCTURE" : " BODYSTRUCTURE");
/*  790 */       bool = false;
/*      */     } 
/*  792 */     if (paramFetchProfile.contains(UIDFolder.FetchProfileItem.UID)) {
/*  793 */       stringBuffer.append(bool ? "UID" : " UID");
/*  794 */       bool = false;
/*      */     } 
/*      */     
/*  797 */     String[] arrayOfString = paramFetchProfile.getHeaderNames();
/*  798 */     if (arrayOfString.length > 0) {
/*  799 */       if (!bool)
/*  800 */         stringBuffer.append(" "); 
/*  801 */       stringBuffer.append(craftHeaderCmd(paramIMAPFolder.protocol, arrayOfString));
/*      */     } 
/*      */     
/*  804 */     $FetchProfileCondition $FetchProfileCondition = new $FetchProfileCondition(paramFetchProfile);
/*      */ 
/*      */     
/*  807 */     synchronized (paramIMAPFolder.messageCacheLock) {
/*      */ 
/*      */ 
/*      */       
/*  811 */       MessageSet[] arrayOfMessageSet = Utility.toMessageSet(paramArrayOfMessage, $FetchProfileCondition);
/*      */       
/*  813 */       if (arrayOfMessageSet == null) {
/*      */         return;
/*      */       }
/*      */       
/*  817 */       Response[] arrayOfResponse = null;
/*  818 */       Vector vector = new Vector();
/*      */       
/*      */       try {
/*  821 */         arrayOfResponse = paramIMAPFolder.protocol.fetch(arrayOfMessageSet, stringBuffer.toString());
/*  822 */       } catch (ConnectionException connectionException) {
/*  823 */         throw new FolderClosedException(paramIMAPFolder, connectionException.getMessage());
/*  824 */       } catch (CommandFailedException commandFailedException) {
/*      */       
/*  826 */       } catch (ProtocolException protocolException) {
/*  827 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */       
/*  830 */       if (arrayOfResponse == null) {
/*      */         return;
/*      */       }
/*  833 */       for (byte b = 0; b < arrayOfResponse.length; b++) {
/*  834 */         if (arrayOfResponse[b] != null)
/*      */         {
/*  836 */           if (!(arrayOfResponse[b] instanceof FetchResponse)) {
/*  837 */             vector.addElement(arrayOfResponse[b]);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  842 */             FetchResponse fetchResponse = (FetchResponse)arrayOfResponse[b];
/*      */             
/*  844 */             IMAPMessage iMAPMessage = paramIMAPFolder.getMessageBySeqNumber(fetchResponse.getNumber());
/*      */             
/*  846 */             int j = fetchResponse.getItemCount();
/*  847 */             boolean bool1 = false;
/*      */             
/*  849 */             for (byte b1 = 0; b1 < j; b1++) {
/*  850 */               Item item = fetchResponse.getItem(b1);
/*      */ 
/*      */               
/*  853 */               if (item instanceof Flags) {
/*  854 */                 if (!paramFetchProfile.contains(FetchProfile.Item.FLAGS) || 
/*  855 */                   iMAPMessage == null) {
/*      */                   
/*  857 */                   bool1 = true;
/*      */                 } else {
/*  859 */                   iMAPMessage.flags = (Flags)item;
/*      */                 }
/*      */               
/*      */               }
/*  863 */               else if (item instanceof ENVELOPE) {
/*  864 */                 iMAPMessage.envelope = (ENVELOPE)item;
/*  865 */               } else if (item instanceof INTERNALDATE) {
/*  866 */                 iMAPMessage.receivedDate = ((INTERNALDATE)item).getDate();
/*  867 */               } else if (item instanceof RFC822SIZE) {
/*  868 */                 iMAPMessage.size = ((RFC822SIZE)item).size;
/*      */               
/*      */               }
/*  871 */               else if (item instanceof BODYSTRUCTURE) {
/*  872 */                 iMAPMessage.bs = (BODYSTRUCTURE)item;
/*      */               }
/*  874 */               else if (item instanceof UID) {
/*  875 */                 UID uID = (UID)item;
/*  876 */                 iMAPMessage.uid = uID.uid;
/*      */                 
/*  878 */                 if (paramIMAPFolder.uidTable == null)
/*  879 */                   paramIMAPFolder.uidTable = new Hashtable(); 
/*  880 */                 paramIMAPFolder.uidTable.put(new Long(uID.uid), iMAPMessage);
/*      */ 
/*      */               
/*      */               }
/*  884 */               else if (item instanceof RFC822DATA || 
/*  885 */                 item instanceof BODY) {
/*      */                 ByteArrayInputStream byteArrayInputStream;
/*  887 */                 if (item instanceof RFC822DATA) {
/*  888 */                   byteArrayInputStream = (
/*  889 */                     (RFC822DATA)item).getByteArrayInputStream();
/*      */                 } else {
/*  891 */                   byteArrayInputStream = (
/*  892 */                     (BODY)item).getByteArrayInputStream();
/*      */                 } 
/*      */                 
/*  895 */                 if (iMAPMessage.headers == null)
/*  896 */                   iMAPMessage.headers = new InternetHeaders(); 
/*  897 */                 iMAPMessage.headers.load(byteArrayInputStream);
/*      */ 
/*      */                 
/*  900 */                 for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
/*  901 */                   iMAPMessage.setHeaderLoaded(arrayOfString[b2]);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */ 
/*      */             
/*  907 */             if (bool1)
/*  908 */               vector.addElement(fetchResponse); 
/*      */           } 
/*      */         }
/*      */       } 
/*  912 */       int i = vector.size();
/*  913 */       if (i != 0) {
/*  914 */         Response[] arrayOfResponse1 = new Response[i];
/*  915 */         vector.copyInto(arrayOfResponse1);
/*  916 */         paramIMAPFolder.handleResponses(arrayOfResponse1);
/*      */       } 
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadEnvelope() throws MessageRemovedException {
/*  926 */     if (this.envelope != null) {
/*      */       return;
/*      */     }
/*  929 */     IMAPProtocol iMAPProtocol = getProtocol();
/*  930 */     Response[] arrayOfResponse = null;
/*      */ 
/*      */     
/*  933 */     synchronized (getMessageCacheLock()) {
/*      */       
/*  935 */       checkExpunged();
/*      */       
/*  937 */       int i = getSequenceNumber();
/*      */       try {
/*  939 */         arrayOfResponse = iMAPProtocol.fetch(i, EnvelopeCmd);
/*  940 */       } catch (ConnectionException connectionException) {
/*  941 */         throw new FolderClosedException(this.folder, connectionException.getMessage());
/*  942 */       } catch (ProtocolException protocolException) {
/*  943 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */       
/*  946 */       if (arrayOfResponse == null) {
/*      */         return;
/*      */       }
/*  949 */       for (byte b = 0; b < arrayOfResponse.length; b++) {
/*      */ 
/*      */         
/*  952 */         if (arrayOfResponse[b] != null && 
/*  953 */           arrayOfResponse[b] instanceof FetchResponse && (
/*  954 */           (FetchResponse)arrayOfResponse[b]).getNumber() == i) {
/*      */ 
/*      */           
/*  957 */           FetchResponse fetchResponse = (FetchResponse)arrayOfResponse[b];
/*      */ 
/*      */           
/*  960 */           int j = fetchResponse.getItemCount();
/*  961 */           for (byte b1 = 0; b1 < j; b1++) {
/*  962 */             Item item = fetchResponse.getItem(b1);
/*      */             
/*  964 */             if (item instanceof ENVELOPE) {
/*  965 */               this.envelope = (ENVELOPE)item;
/*  966 */             } else if (item instanceof INTERNALDATE) {
/*  967 */               this.receivedDate = ((INTERNALDATE)item).getDate();
/*  968 */             } else if (item instanceof RFC822SIZE) {
/*  969 */               this.size = ((RFC822SIZE)item).size;
/*      */             } 
/*      */           } 
/*      */         } 
/*  973 */       }  ((IMAPFolder)this.folder).handleResponses(arrayOfResponse);
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static String craftHeaderCmd(IMAPProtocol paramIMAPProtocol, String[] paramArrayOfString) {
/*      */     StringBuffer stringBuffer;
/*  981 */     if (paramIMAPProtocol.isREV1()) {
/*  982 */       stringBuffer = new StringBuffer("BODY.PEEK[HEADER.FIELDS (");
/*      */     } else {
/*  984 */       stringBuffer = new StringBuffer("RFC822.HEADER.LINES (");
/*      */     } 
/*  986 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*  987 */       if (b)
/*  988 */         stringBuffer.append(" "); 
/*  989 */       stringBuffer.append(paramArrayOfString[b]);
/*      */     } 
/*      */     
/*  992 */     if (paramIMAPProtocol.isREV1()) {
/*  993 */       stringBuffer.append(")]");
/*      */     } else {
/*  995 */       stringBuffer.append(")");
/*      */     } 
/*  997 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadBODYSTRUCTURE() throws MessageRemovedException {
/* 1005 */     if (this.bs != null) {
/*      */       return;
/*      */     }
/*      */     
/* 1009 */     synchronized (getMessageCacheLock()) {
/*      */ 
/*      */       
/* 1012 */       checkExpunged();
/*      */       
/*      */       try {
/* 1015 */         this.bs = getProtocol().fetchBodyStructure(getSequenceNumber());
/* 1016 */       } catch (ConnectionException connectionException) {
/* 1017 */         throw new FolderClosedException(this.folder, connectionException.getMessage());
/* 1018 */       } catch (ProtocolException protocolException) {
/* 1019 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadHeaders() throws MessageRemovedException {
/* 1028 */     if (this.headersLoaded) {
/*      */       return;
/*      */     }
/* 1031 */     IMAPProtocol iMAPProtocol = getProtocol();
/* 1032 */     ByteArrayInputStream byteArrayInputStream = null;
/*      */ 
/*      */     
/* 1035 */     synchronized (getMessageCacheLock()) {
/*      */ 
/*      */ 
/*      */       
/* 1039 */       checkExpunged();
/*      */       
/*      */       try {
/* 1042 */         if (iMAPProtocol.isREV1()) {
/* 1043 */           BODY bODY = iMAPProtocol.peekBody(getSequenceNumber(), 
/* 1044 */               toSection("HEADER"));
/* 1045 */           if (bODY != null)
/* 1046 */             byteArrayInputStream = bODY.getByteArrayInputStream(); 
/*      */         } else {
/* 1048 */           RFC822DATA rFC822DATA = iMAPProtocol.fetchRFC822(getSequenceNumber(), 
/* 1049 */               "HEADER");
/* 1050 */           if (rFC822DATA != null)
/* 1051 */             byteArrayInputStream = rFC822DATA.getByteArrayInputStream(); 
/*      */         } 
/* 1053 */       } catch (ConnectionException connectionException) {
/* 1054 */         throw new FolderClosedException(this.folder, connectionException.getMessage());
/* 1055 */       } catch (ProtocolException protocolException) {
/* 1056 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */     } 
/*      */     
/* 1060 */     if (byteArrayInputStream == null)
/* 1061 */       throw new MessagingException("Cannot load header"); 
/* 1062 */     this.headers = new InternetHeaders(byteArrayInputStream);
/* 1063 */     this.headersLoaded = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadFlags() throws MessageRemovedException {
/* 1070 */     if (this.flags != null) {
/*      */       return;
/*      */     }
/*      */     
/* 1074 */     synchronized (getMessageCacheLock()) {
/*      */ 
/*      */ 
/*      */       
/* 1078 */       checkExpunged();
/*      */       
/*      */       try {
/* 1081 */         this.flags = getProtocol().fetchFlags(getSequenceNumber());
/* 1082 */       } catch (ConnectionException connectionException) {
/* 1083 */         throw new FolderClosedException(this.folder, connectionException.getMessage());
/* 1084 */       } catch (ProtocolException protocolException) {
/* 1085 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isHeaderLoaded(String paramString) {
/* 1094 */     if (this.headersLoaded) {
/* 1095 */       return true;
/*      */     }
/* 1097 */     return (this.loadedHeaders != null) ? 
/* 1098 */       this.loadedHeaders.containsKey(paramString.toUpperCase()) : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setHeaderLoaded(String paramString) throws MessagingException {
/* 1105 */     if (this.loadedHeaders == null)
/* 1106 */       this.loadedHeaders = new Hashtable(1); 
/* 1107 */     this.loadedHeaders.put(paramString.toUpperCase(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String toSection(String paramString) {
/* 1115 */     if (this.sectionId == null) {
/* 1116 */       return paramString;
/*      */     }
/* 1118 */     return String.valueOf(this.sectionId) + "." + paramString;
/*      */   }
/*      */ 
/*      */   
/* 1122 */   void _setFlags(Flags paramFlags) { this.flags = paramFlags; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1131 */   Flags _getFlags() throws MessagingException { return this.flags; }
/*      */ 
/*      */ 
/*      */   
/* 1135 */   ENVELOPE _getEnvelope() { return this.envelope; }
/*      */ 
/*      */ 
/*      */   
/* 1139 */   BODYSTRUCTURE _getBodyStructure() { return this.bs; }
/*      */ 
/*      */ 
/*      */   
/* 1143 */   Session _getSession() { return this.session; }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\IMAPMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */