/*     */ package com.sun.mail.imap;
/*     */ 
/*     */ import com.sun.mail.iap.ConnectionException;
/*     */ import com.sun.mail.iap.ProtocolException;
/*     */ import com.sun.mail.imap.protocol.BODY;
/*     */ import com.sun.mail.imap.protocol.BODYSTRUCTURE;
/*     */ import com.sun.mail.imap.protocol.IMAPProtocol;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Enumeration;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.mail.FolderClosedException;
/*     */ import javax.mail.IllegalWriteException;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Multipart;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.InternetHeaders;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IMAPBodyPart
/*     */   extends MimeBodyPart
/*     */ {
/*     */   private IMAPMessage message;
/*     */   private BODYSTRUCTURE bs;
/*     */   private String sectionId;
/*     */   private String type;
/*     */   private String description;
/*     */   private boolean headersLoaded;
/*     */   
/*     */   protected IMAPBodyPart(BODYSTRUCTURE paramBODYSTRUCTURE, String paramString, IMAPMessage paramIMAPMessage) {
/*  37 */     this.headersLoaded = false;
/*     */ 
/*     */ 
/*     */     
/*  41 */     this.bs = paramBODYSTRUCTURE;
/*  42 */     this.sectionId = paramString;
/*  43 */     this.message = paramIMAPMessage;
/*     */     
/*  45 */     ContentType contentType = new ContentType(paramBODYSTRUCTURE.type, paramBODYSTRUCTURE.subtype, paramBODYSTRUCTURE.cParams);
/*  46 */     this.type = contentType.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateHeaders() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public int getSize() throws MessagingException { return this.bs.size; }
/*     */ 
/*     */ 
/*     */   
/*  63 */   public int getLineCount() throws MessagingException { return this.bs.lines; }
/*     */ 
/*     */ 
/*     */   
/*  67 */   public String getContentType() throws MessagingException { return this.type; }
/*     */ 
/*     */ 
/*     */   
/*  71 */   public String getDisposition() throws MessagingException { return this.bs.disposition; }
/*     */ 
/*     */ 
/*     */   
/*  75 */   public void setDisposition(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
/*     */ 
/*     */ 
/*     */   
/*  79 */   public String getEncoding() throws MessagingException { return this.bs.encoding; }
/*     */ 
/*     */ 
/*     */   
/*  83 */   public String getContentID() throws MessagingException { return this.bs.id; }
/*     */ 
/*     */ 
/*     */   
/*  87 */   public String getContentMD5() throws MessagingException { return this.bs.md5; }
/*     */ 
/*     */ 
/*     */   
/*  91 */   public void setContentMD5(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
/*     */ 
/*     */   
/*     */   public String getDescription() throws MessagingException {
/*  95 */     if (this.description != null) {
/*  96 */       return this.description;
/*     */     }
/*  98 */     if (this.bs.description == null) {
/*  99 */       return null;
/*     */     }
/*     */     try {
/* 102 */       this.description = MimeUtility.decodeText(this.bs.description);
/* 103 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 104 */       this.description = this.bs.description;
/*     */     } 
/*     */     
/* 107 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 112 */   public void setDescription(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
/*     */ 
/*     */   
/*     */   public String getFileName() throws MessagingException {
/* 116 */     String str = null;
/* 117 */     if (this.bs.dParams != null)
/* 118 */       str = this.bs.dParams.get("filename"); 
/* 119 */     if (str == null && this.bs.cParams != null)
/* 120 */       str = this.bs.cParams.get("name"); 
/* 121 */     return str;
/*     */   }
/*     */ 
/*     */   
/* 125 */   public void setFileName(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
/*     */ 
/*     */   
/*     */   protected InputStream getContentStream() throws MessagingException {
/* 129 */     IMAPProtocol iMAPProtocol = this.message.getProtocol();
/* 130 */     if (iMAPProtocol.isREV1() && this.message.getFetchBlockSize() != -1) {
/* 131 */       return new IMAPInputStream(this.message, this.sectionId, this.bs.size);
/*     */     }
/*     */     
/* 134 */     ByteArrayInputStream byteArrayInputStream = null;
/*     */ 
/*     */     
/* 137 */     synchronized (this.message.getMessageCacheLock()) {
/*     */ 
/*     */       
/* 140 */       this.message.checkExpunged();
/*     */       
/* 142 */       int i = this.message.getSequenceNumber();
/*     */       try {
/* 144 */         BODY bODY = iMAPProtocol.fetchBody(i, this.sectionId);
/* 145 */         if (bODY != null)
/* 146 */           byteArrayInputStream = bODY.getByteArrayInputStream(); 
/* 147 */       } catch (ConnectionException connectionException) {
/* 148 */         throw new FolderClosedException(
/* 149 */             this.message.getFolder(), connectionException.getMessage());
/* 150 */       } catch (ProtocolException protocolException) {
/* 151 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*     */       } 
/*     */     } 
/*     */     
/* 155 */     if (byteArrayInputStream == null) {
/* 156 */       throw new MessagingException("No content");
/*     */     }
/* 158 */     return byteArrayInputStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public DataHandler getDataHandler() throws MessagingException {
/* 163 */     if (this.dh == null) {
/* 164 */       if (this.bs.isMulti()) {
/* 165 */         this.dh = new DataHandler(
/* 166 */             new IMAPMultipartDataSource(
/* 167 */               this, this.bs.bodies, this.sectionId, this.message));
/*     */       }
/* 169 */       else if (this.bs.isNested() && this.message.getProtocol().isREV1()) {
/* 170 */         this.dh = new DataHandler(
/* 171 */             new IMAPNestedMessage(this.message, 
/* 172 */               this.bs.bodies[0], 
/* 173 */               this.bs.envelope, 
/* 174 */               this.sectionId), 
/* 175 */             this.type);
/*     */       } 
/*     */     }
/*     */     
/* 179 */     return super.getDataHandler();
/*     */   }
/*     */ 
/*     */   
/* 183 */   public void setDataHandler(DataHandler paramDataHandler) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
/*     */ 
/*     */ 
/*     */   
/* 187 */   public void setContent(Object paramObject, String paramString) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
/*     */ 
/*     */ 
/*     */   
/* 191 */   public void setContent(Multipart paramMultipart) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
/*     */ 
/*     */   
/*     */   public String[] getHeader(String paramString) throws MessagingException {
/* 195 */     loadHeaders();
/* 196 */     return super.getHeader(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 201 */   public void setHeader(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 206 */   public void addHeader(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
/*     */ 
/*     */ 
/*     */   
/* 210 */   public void removeHeader(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
/*     */ 
/*     */   
/*     */   public Enumeration getAllHeaders() throws MessagingException {
/* 214 */     loadHeaders();
/* 215 */     return super.getAllHeaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration getMatchingHeaders(String[] paramArrayOfString) throws MessagingException {
/* 220 */     loadHeaders();
/* 221 */     return super.getMatchingHeaders(paramArrayOfString);
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration getNonMatchingHeaders(String[] paramArrayOfString) throws MessagingException {
/* 226 */     loadHeaders();
/* 227 */     return super.getNonMatchingHeaders(paramArrayOfString);
/*     */   }
/*     */ 
/*     */   
/* 231 */   public void addHeaderLine(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
/*     */ 
/*     */   
/*     */   public Enumeration getAllHeaderLines() throws MessagingException {
/* 235 */     loadHeaders();
/* 236 */     return super.getAllHeaderLines();
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration getMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException {
/* 241 */     loadHeaders();
/* 242 */     return super.getMatchingHeaderLines(paramArrayOfString);
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException {
/* 247 */     loadHeaders();
/* 248 */     return super.getNonMatchingHeaderLines(paramArrayOfString);
/*     */   }
/*     */   
/*     */   private void loadHeaders() {
/* 252 */     if (this.headersLoaded) {
/*     */       return;
/*     */     }
/* 255 */     if (this.headers == null) {
/* 256 */       this.headers = new InternetHeaders();
/*     */     }
/*     */     
/* 259 */     IMAPProtocol iMAPProtocol = this.message.getProtocol();
/* 260 */     if (iMAPProtocol.isREV1()) {
/* 261 */       BODY bODY = null;
/*     */ 
/*     */       
/* 264 */       synchronized (this.message.getMessageCacheLock()) {
/*     */ 
/*     */         
/* 267 */         this.message.checkExpunged();
/*     */         
/* 269 */         int i = this.message.getSequenceNumber();
/*     */         try {
/* 271 */           bODY = iMAPProtocol.peekBody(i, String.valueOf(this.sectionId) + ".MIME");
/* 272 */         } catch (ConnectionException connectionException) {
/* 273 */           throw new FolderClosedException(
/* 274 */               this.message.getFolder(), connectionException.getMessage());
/* 275 */         } catch (ProtocolException protocolException) {
/* 276 */           throw new MessagingException(protocolException.getMessage(), protocolException);
/*     */         } 
/*     */       } 
/*     */       
/* 280 */       if (bODY == null) {
/* 281 */         throw new MessagingException("Failed to fetch headers");
/*     */       }
/* 283 */       ByteArrayInputStream byteArrayInputStream = bODY.getByteArrayInputStream();
/* 284 */       if (byteArrayInputStream == null) {
/* 285 */         throw new MessagingException("Failed to fetch headers");
/*     */       }
/* 287 */       this.headers.load(byteArrayInputStream);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 295 */       this.headers.addHeader("Content-Type", this.type);
/*     */       
/* 297 */       this.headers.addHeader("Content-Transfer-Encoding", this.bs.encoding);
/*     */       
/* 299 */       if (this.bs.description != null) {
/* 300 */         this.headers.addHeader("Content-Description", this.bs.description);
/*     */       }
/* 302 */       if (this.bs.id != null) {
/* 303 */         this.headers.addHeader("Content-ID", this.bs.id);
/*     */       }
/* 305 */       if (this.bs.md5 != null)
/* 306 */         this.headers.addHeader("Content-MD5", this.bs.md5); 
/*     */     } 
/* 308 */     this.headersLoaded = true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\IMAPBodyPart.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */