package com.sun.mail.imap;

import com.sun.mail.iap.ConnectionException;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.imap.protocol.BODY;
import com.sun.mail.imap.protocol.BODYSTRUCTURE;
import com.sun.mail.imap.protocol.IMAPProtocol;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import javax.activation.DataHandler;
import javax.mail.FolderClosedException;
import javax.mail.IllegalWriteException;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.ContentType;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeUtility;

public class IMAPBodyPart extends MimeBodyPart {
  private IMAPMessage message;
  
  private BODYSTRUCTURE bs;
  
  private String sectionId;
  
  private String type;
  
  private String description;
  
  private boolean headersLoaded;
  
  protected IMAPBodyPart(BODYSTRUCTURE paramBODYSTRUCTURE, String paramString, IMAPMessage paramIMAPMessage) {
    this.headersLoaded = false;
    this.bs = paramBODYSTRUCTURE;
    this.sectionId = paramString;
    this.message = paramIMAPMessage;
    ContentType contentType = new ContentType(paramBODYSTRUCTURE.type, paramBODYSTRUCTURE.subtype, paramBODYSTRUCTURE.cParams);
    this.type = contentType.toString();
  }
  
  protected void updateHeaders() {}
  
  public int getSize() throws MessagingException { return this.bs.size; }
  
  public int getLineCount() throws MessagingException { return this.bs.lines; }
  
  public String getContentType() throws MessagingException { return this.type; }
  
  public String getDisposition() throws MessagingException { return this.bs.disposition; }
  
  public void setDisposition(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
  
  public String getEncoding() throws MessagingException { return this.bs.encoding; }
  
  public String getContentID() throws MessagingException { return this.bs.id; }
  
  public String getContentMD5() throws MessagingException { return this.bs.md5; }
  
  public void setContentMD5(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
  
  public String getDescription() throws MessagingException {
    if (this.description != null)
      return this.description; 
    if (this.bs.description == null)
      return null; 
    try {
      this.description = MimeUtility.decodeText(this.bs.description);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      this.description = this.bs.description;
    } 
    return this.description;
  }
  
  public void setDescription(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
  
  public String getFileName() throws MessagingException {
    String str = null;
    if (this.bs.dParams != null)
      str = this.bs.dParams.get("filename"); 
    if (str == null && this.bs.cParams != null)
      str = this.bs.cParams.get("name"); 
    return str;
  }
  
  public void setFileName(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
  
  protected InputStream getContentStream() throws MessagingException {
    IMAPProtocol iMAPProtocol = this.message.getProtocol();
    if (iMAPProtocol.isREV1() && this.message.getFetchBlockSize() != -1)
      return new IMAPInputStream(this.message, this.sectionId, this.bs.size); 
    ByteArrayInputStream byteArrayInputStream = null;
    synchronized (this.message.getMessageCacheLock()) {
      this.message.checkExpunged();
      int i = this.message.getSequenceNumber();
      try {
        BODY bODY = iMAPProtocol.fetchBody(i, this.sectionId);
        if (bODY != null)
          byteArrayInputStream = bODY.getByteArrayInputStream(); 
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(
            this.message.getFolder(), connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
    } 
    if (byteArrayInputStream == null)
      throw new MessagingException("No content"); 
    return byteArrayInputStream;
  }
  
  public DataHandler getDataHandler() throws MessagingException {
    if (this.dh == null)
      if (this.bs.isMulti()) {
        this.dh = new DataHandler(
            new IMAPMultipartDataSource(
              this, this.bs.bodies, this.sectionId, this.message));
      } else if (this.bs.isNested() && this.message.getProtocol().isREV1()) {
        this.dh = new DataHandler(
            new IMAPNestedMessage(this.message, 
              this.bs.bodies[0], 
              this.bs.envelope, 
              this.sectionId), 
            this.type);
      }  
    return super.getDataHandler();
  }
  
  public void setDataHandler(DataHandler paramDataHandler) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
  
  public void setContent(Object paramObject, String paramString) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
  
  public void setContent(Multipart paramMultipart) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
  
  public String[] getHeader(String paramString) throws MessagingException {
    loadHeaders();
    return super.getHeader(paramString);
  }
  
  public void setHeader(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
  
  public void addHeader(String paramString1, String paramString2) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
  
  public void removeHeader(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
  
  public Enumeration getAllHeaders() throws MessagingException {
    loadHeaders();
    return super.getAllHeaders();
  }
  
  public Enumeration getMatchingHeaders(String[] paramArrayOfString) throws MessagingException {
    loadHeaders();
    return super.getMatchingHeaders(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaders(String[] paramArrayOfString) throws MessagingException {
    loadHeaders();
    return super.getNonMatchingHeaders(paramArrayOfString);
  }
  
  public void addHeaderLine(String paramString) throws MessagingException { throw new IllegalWriteException("IMAPBodyPart is read-only"); }
  
  public Enumeration getAllHeaderLines() throws MessagingException {
    loadHeaders();
    return super.getAllHeaderLines();
  }
  
  public Enumeration getMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException {
    loadHeaders();
    return super.getMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString) throws MessagingException {
    loadHeaders();
    return super.getNonMatchingHeaderLines(paramArrayOfString);
  }
  
  private void loadHeaders() {
    if (this.headersLoaded)
      return; 
    if (this.headers == null)
      this.headers = new InternetHeaders(); 
    IMAPProtocol iMAPProtocol = this.message.getProtocol();
    if (iMAPProtocol.isREV1()) {
      BODY bODY = null;
      synchronized (this.message.getMessageCacheLock()) {
        this.message.checkExpunged();
        int i = this.message.getSequenceNumber();
        try {
          bODY = iMAPProtocol.peekBody(i, String.valueOf(this.sectionId) + ".MIME");
        } catch (ConnectionException connectionException) {
          throw new FolderClosedException(
              this.message.getFolder(), connectionException.getMessage());
        } catch (ProtocolException protocolException) {
          throw new MessagingException(protocolException.getMessage(), protocolException);
        } 
      } 
      if (bODY == null)
        throw new MessagingException("Failed to fetch headers"); 
      ByteArrayInputStream byteArrayInputStream = bODY.getByteArrayInputStream();
      if (byteArrayInputStream == null)
        throw new MessagingException("Failed to fetch headers"); 
      this.headers.load(byteArrayInputStream);
    } else {
      this.headers.addHeader("Content-Type", this.type);
      this.headers.addHeader("Content-Transfer-Encoding", this.bs.encoding);
      if (this.bs.description != null)
        this.headers.addHeader("Content-Description", this.bs.description); 
      if (this.bs.id != null)
        this.headers.addHeader("Content-ID", this.bs.id); 
      if (this.bs.md5 != null)
        this.headers.addHeader("Content-MD5", this.bs.md5); 
    } 
    this.headersLoaded = true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\IMAPBodyPart.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */