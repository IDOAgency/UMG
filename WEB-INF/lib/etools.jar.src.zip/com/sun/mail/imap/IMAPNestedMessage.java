package com.sun.mail.imap;

import com.sun.mail.imap.protocol.BODYSTRUCTURE;
import com.sun.mail.imap.protocol.ENVELOPE;
import com.sun.mail.imap.protocol.IMAPProtocol;
import javax.mail.Flags;
import javax.mail.FolderClosedException;
import javax.mail.MessageRemovedException;
import javax.mail.MessagingException;
import javax.mail.MethodNotSupportedException;

public class IMAPNestedMessage extends IMAPMessage {
  private IMAPMessage msg;
  
  IMAPNestedMessage(IMAPMessage paramIMAPMessage, BODYSTRUCTURE paramBODYSTRUCTURE, ENVELOPE paramENVELOPE, String paramString) {
    super(paramIMAPMessage._getSession());
    this.msg = paramIMAPMessage;
    this.bs = paramBODYSTRUCTURE;
    this.envelope = paramENVELOPE;
    this.sectionId = paramString;
  }
  
  protected IMAPProtocol getProtocol() throws FolderClosedException { return this.msg.getProtocol(); }
  
  protected Object getMessageCacheLock() { return this.msg.getMessageCacheLock(); }
  
  protected int getSequenceNumber() { return this.msg.getSequenceNumber(); }
  
  protected void checkExpunged() throws MessageRemovedException { this.msg.checkExpunged(); }
  
  public boolean isExpunged() { return this.msg.isExpunged(); }
  
  protected int getFetchBlockSize() { return this.msg.getFetchBlockSize(); }
  
  public int getSize() { return this.bs.size; }
  
  public void setFlags(Flags paramFlags, boolean paramBoolean) throws MessagingException {
    throw new MethodNotSupportedException(
        "Cannot set flags on this nested message");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\IMAPNestedMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */