/*    */ package com.sun.mail.imap;
/*    */ 
/*    */ import com.sun.mail.imap.protocol.BODYSTRUCTURE;
/*    */ import com.sun.mail.imap.protocol.ENVELOPE;
/*    */ import com.sun.mail.imap.protocol.IMAPProtocol;
/*    */ import javax.mail.Flags;
/*    */ import javax.mail.FolderClosedException;
/*    */ import javax.mail.MessageRemovedException;
/*    */ import javax.mail.MessagingException;
/*    */ import javax.mail.MethodNotSupportedException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IMAPNestedMessage
/*    */   extends IMAPMessage
/*    */ {
/*    */   private IMAPMessage msg;
/*    */   
/*    */   IMAPNestedMessage(IMAPMessage paramIMAPMessage, BODYSTRUCTURE paramBODYSTRUCTURE, ENVELOPE paramENVELOPE, String paramString) {
/* 30 */     super(paramIMAPMessage._getSession());
/* 31 */     this.msg = paramIMAPMessage;
/* 32 */     this.bs = paramBODYSTRUCTURE;
/* 33 */     this.envelope = paramENVELOPE;
/* 34 */     this.sectionId = paramString;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   protected IMAPProtocol getProtocol() throws FolderClosedException { return this.msg.getProtocol(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   protected Object getMessageCacheLock() { return this.msg.getMessageCacheLock(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   protected int getSequenceNumber() { return this.msg.getSequenceNumber(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 66 */   protected void checkExpunged() throws MessageRemovedException { this.msg.checkExpunged(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 74 */   public boolean isExpunged() { return this.msg.isExpunged(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 81 */   protected int getFetchBlockSize() { return this.msg.getFetchBlockSize(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 89 */   public int getSize() { return this.bs.size; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setFlags(Flags paramFlags, boolean paramBoolean) throws MessagingException {
/* 98 */     throw new MethodNotSupportedException(
/* 99 */         "Cannot set flags on this nested message");
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\IMAPNestedMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */