/*    */ package com.sun.mail.imap;
/*    */ 
/*    */ import com.sun.mail.imap.protocol.MessageSet;
/*    */ import java.util.Vector;
/*    */ import javax.mail.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Utility
/*    */ {
/*    */   public static MessageSet[] toMessageSet(Message[] paramArrayOfMessage, Condition paramCondition) {
/* 41 */     Vector vector = new Vector(1);
/*    */ 
/*    */ 
/*    */     
/* 45 */     for (byte b = 0; b < paramArrayOfMessage.length; b++) {
/* 46 */       IMAPMessage iMAPMessage = (IMAPMessage)paramArrayOfMessage[b];
/* 47 */       if (!iMAPMessage.isExpunged()) {
/*    */ 
/*    */         
/* 50 */         int i = iMAPMessage.getSequenceNumber();
/*    */         
/* 52 */         if (paramCondition == null || paramCondition.test(iMAPMessage)) {
/*    */ 
/*    */           
/* 55 */           MessageSet messageSet = new MessageSet();
/* 56 */           messageSet.start = i;
/*    */ 
/*    */           
/* 59 */           for (; ++b < paramArrayOfMessage.length; b++) {
/*    */             
/* 61 */             iMAPMessage = (IMAPMessage)paramArrayOfMessage[b];
/*    */             
/* 63 */             if (!iMAPMessage.isExpunged()) {
/*    */               
/* 65 */               int j = iMAPMessage.getSequenceNumber();
/*    */ 
/*    */               
/* 68 */               if (paramCondition == null || paramCondition.test(iMAPMessage))
/*    */               {
/*    */                 
/* 71 */                 if (j == i + 1) {
/* 72 */                   i = j;
/*    */                 
/*    */                 }
/*    */                 else {
/*    */                   
/* 77 */                   b--; break;
/*    */                 }  } 
/*    */             } 
/*    */           } 
/* 81 */           messageSet.end = i;
/* 82 */           vector.addElement(messageSet);
/*    */         } 
/*    */       } 
/* 85 */     }  if (vector.isEmpty()) {
/* 86 */       return null;
/*    */     }
/* 88 */     MessageSet[] arrayOfMessageSet = new MessageSet[vector.size()];
/* 89 */     vector.copyInto(arrayOfMessageSet);
/* 90 */     return arrayOfMessageSet;
/*    */   }
/*    */   
/*    */   public static interface Condition {
/*    */     boolean test(IMAPMessage param1IMAPMessage);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\Utility.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */