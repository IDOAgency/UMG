package com.sun.mail.imap;

import com.sun.mail.imap.protocol.MessageSet;
import java.util.Vector;
import javax.mail.Message;

public final class Utility {
  public static MessageSet[] toMessageSet(Message[] paramArrayOfMessage, Condition paramCondition) {
    Vector vector = new Vector(1);
    for (byte b = 0; b < paramArrayOfMessage.length; b++) {
      IMAPMessage iMAPMessage = (IMAPMessage)paramArrayOfMessage[b];
      if (!iMAPMessage.isExpunged()) {
        int i = iMAPMessage.getSequenceNumber();
        if (paramCondition == null || paramCondition.test(iMAPMessage)) {
          MessageSet messageSet = new MessageSet();
          messageSet.start = i;
          for (; ++b < paramArrayOfMessage.length; b++) {
            iMAPMessage = (IMAPMessage)paramArrayOfMessage[b];
            if (!iMAPMessage.isExpunged()) {
              int j = iMAPMessage.getSequenceNumber();
              if (paramCondition == null || paramCondition.test(iMAPMessage))
                if (j == i + 1) {
                  i = j;
                } else {
                  b--;
                  break;
                }  
            } 
          } 
          messageSet.end = i;
          vector.addElement(messageSet);
        } 
      } 
    } 
    if (vector.isEmpty())
      return null; 
    MessageSet[] arrayOfMessageSet = new MessageSet[vector.size()];
    vector.copyInto(arrayOfMessageSet);
    return arrayOfMessageSet;
  }
  
  public static interface Condition {
    boolean test(IMAPMessage param1IMAPMessage);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\Utility.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */