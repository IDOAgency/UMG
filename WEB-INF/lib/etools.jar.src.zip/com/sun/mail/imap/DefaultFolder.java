package com.sun.mail.imap;

import com.sun.mail.iap.CommandFailedException;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.imap.protocol.ListInfo;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.MethodNotSupportedException;

public class DefaultFolder extends IMAPFolder {
  protected DefaultFolder(IMAPStore paramIMAPStore) {
    super("", '￿', paramIMAPStore);
    this.exists = true;
    this.type = 2;
  }
  
  public String getName() { return this.fullName; }
  
  public Folder getParent() { return null; }
  
  public Folder[] list(String paramString) throws MessagingException {
    ListInfo[] arrayOfListInfo = null;
    try {
      arrayOfListInfo = storeProtocol().list("", paramString);
    } catch (CommandFailedException commandFailedException) {
    
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
    if (arrayOfListInfo == null)
      return null; 
    IMAPFolder[] arrayOfIMAPFolder = new IMAPFolder[arrayOfListInfo.length];
    for (byte b = 0; b < arrayOfIMAPFolder.length; b++)
      arrayOfIMAPFolder[b] = new IMAPFolder(arrayOfListInfo[b], (IMAPStore)this.store); 
    return arrayOfIMAPFolder;
  }
  
  public Folder[] listSubscribed(String paramString) throws MessagingException {
    ListInfo[] arrayOfListInfo = null;
    try {
      arrayOfListInfo = storeProtocol().lsub("", paramString);
    } catch (CommandFailedException commandFailedException) {
    
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
    if (arrayOfListInfo == null)
      return null; 
    IMAPFolder[] arrayOfIMAPFolder = new IMAPFolder[arrayOfListInfo.length];
    for (byte b = 0; b < arrayOfIMAPFolder.length; b++)
      arrayOfIMAPFolder[b] = new IMAPFolder(arrayOfListInfo[b], (IMAPStore)this.store); 
    return arrayOfIMAPFolder;
  }
  
  public boolean hasNewMessages() throws MessagingException { return false; }
  
  public Folder getFolder(String paramString) throws MessagingException { return new IMAPFolder(paramString, '￿', (IMAPStore)this.store); }
  
  public boolean delete(boolean paramBoolean) throws MessagingException { throw new MethodNotSupportedException("Cannot delete Default Folder"); }
  
  public boolean renameTo(Folder paramFolder) throws MessagingException { throw new MethodNotSupportedException("Cannot rename Default Folder"); }
  
  public void appendMessages(Message[] paramArrayOfMessage) throws MessagingException { throw new MethodNotSupportedException("Cannot append to Default Folder"); }
  
  public Message[] expunge() throws MessagingException { throw new MethodNotSupportedException("Cannot expunge Default Folder"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\DefaultFolder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */