/*     */ package com.sun.mail.imap;
/*     */ 
/*     */ import com.sun.mail.iap.CommandFailedException;
/*     */ import com.sun.mail.iap.ProtocolException;
/*     */ import com.sun.mail.imap.protocol.ListInfo;
/*     */ import javax.mail.Folder;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.MethodNotSupportedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultFolder
/*     */   extends IMAPFolder
/*     */ {
/*     */   protected DefaultFolder(IMAPStore paramIMAPStore) {
/*  26 */     super("", '￿', paramIMAPStore);
/*  27 */     this.exists = true;
/*  28 */     this.type = 2;
/*     */   }
/*     */ 
/*     */   
/*  32 */   public String getName() { return this.fullName; }
/*     */ 
/*     */ 
/*     */   
/*  36 */   public Folder getParent() { return null; }
/*     */ 
/*     */   
/*     */   public Folder[] list(String paramString) throws MessagingException {
/*  40 */     ListInfo[] arrayOfListInfo = null;
/*     */     
/*     */     try {
/*  43 */       arrayOfListInfo = storeProtocol().list("", paramString);
/*  44 */     } catch (CommandFailedException commandFailedException) {
/*     */     
/*  46 */     } catch (ProtocolException protocolException) {
/*  47 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*     */     } 
/*     */     
/*  50 */     if (arrayOfListInfo == null) {
/*  51 */       return null;
/*     */     }
/*  53 */     IMAPFolder[] arrayOfIMAPFolder = new IMAPFolder[arrayOfListInfo.length];
/*  54 */     for (byte b = 0; b < arrayOfIMAPFolder.length; b++)
/*  55 */       arrayOfIMAPFolder[b] = new IMAPFolder(arrayOfListInfo[b], (IMAPStore)this.store); 
/*  56 */     return arrayOfIMAPFolder;
/*     */   }
/*     */   
/*     */   public Folder[] listSubscribed(String paramString) throws MessagingException {
/*  60 */     ListInfo[] arrayOfListInfo = null;
/*     */     
/*     */     try {
/*  63 */       arrayOfListInfo = storeProtocol().lsub("", paramString);
/*  64 */     } catch (CommandFailedException commandFailedException) {
/*     */     
/*  66 */     } catch (ProtocolException protocolException) {
/*  67 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*     */     } 
/*     */     
/*  70 */     if (arrayOfListInfo == null) {
/*  71 */       return null;
/*     */     }
/*  73 */     IMAPFolder[] arrayOfIMAPFolder = new IMAPFolder[arrayOfListInfo.length];
/*  74 */     for (byte b = 0; b < arrayOfIMAPFolder.length; b++)
/*  75 */       arrayOfIMAPFolder[b] = new IMAPFolder(arrayOfListInfo[b], (IMAPStore)this.store); 
/*  76 */     return arrayOfIMAPFolder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  81 */   public boolean hasNewMessages() throws MessagingException { return false; }
/*     */ 
/*     */ 
/*     */   
/*  85 */   public Folder getFolder(String paramString) throws MessagingException { return new IMAPFolder(paramString, '￿', (IMAPStore)this.store); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public boolean delete(boolean paramBoolean) throws MessagingException { throw new MethodNotSupportedException("Cannot delete Default Folder"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public boolean renameTo(Folder paramFolder) throws MessagingException { throw new MethodNotSupportedException("Cannot rename Default Folder"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public void appendMessages(Message[] paramArrayOfMessage) throws MessagingException { throw new MethodNotSupportedException("Cannot append to Default Folder"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public Message[] expunge() throws MessagingException { throw new MethodNotSupportedException("Cannot expunge Default Folder"); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\DefaultFolder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */