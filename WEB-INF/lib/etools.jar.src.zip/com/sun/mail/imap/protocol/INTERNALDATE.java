/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ import com.sun.mail.util.MailDateFormat;
/*    */ import java.text.FieldPosition;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.Locale;
/*    */ import java.util.TimeZone;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class INTERNALDATE
/*    */   implements Item
/*    */ {
/*    */   public static char[] name = { 
/* 30 */       'I', 'N', 'T', 'E', 'R', 'N', 'A', 'L', 'D', 'A', 'T', 'E' };
/*    */   
/*    */   public int msgno;
/*    */   
/*    */   protected Date date;
/* 35 */   private static MailDateFormat mailDateFormat = new MailDateFormat();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public INTERNALDATE(FetchResponse paramFetchResponse) throws ParsingException {
/* 41 */     this.msgno = paramFetchResponse.getNumber();
/* 42 */     paramFetchResponse.skipSpaces();
/* 43 */     String str = paramFetchResponse.readString();
/*    */     try {
/* 45 */       this.date = mailDateFormat.parse(str); return;
/* 46 */     } catch (ParseException parseException) {
/* 47 */       throw new ParsingException("INTERNALDATE parse error");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/* 52 */   public Date getDate() { return this.date; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 60 */   private static SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss ", Locale.US);
/*    */   
/*    */   private static String tz_offset;
/*    */   
/*    */   static  {
/* 65 */     TimeZone timeZone = TimeZone.getDefault();
/* 66 */     int i = timeZone.getRawOffset();
/* 67 */     StringBuffer stringBuffer = new StringBuffer();
/* 68 */     if (i < 0) {
/* 69 */       stringBuffer.append('-');
/* 70 */       i = -i;
/*    */     } else {
/* 72 */       stringBuffer.append('+');
/*    */     } 
/* 74 */     int j = i / 60 / 1000;
/* 75 */     int k = j / 60;
/* 76 */     int m = j % 60;
/*    */     
/* 78 */     stringBuffer.append(Character.forDigit(k / 10, 10));
/* 79 */     stringBuffer.append(Character.forDigit(k % 10, 10));
/* 80 */     stringBuffer.append(Character.forDigit(m / 10, 10));
/* 81 */     stringBuffer.append(Character.forDigit(m % 10, 10));
/*    */     
/* 83 */     tz_offset = stringBuffer.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String format(Date paramDate) {
/* 90 */     StringBuffer stringBuffer = new StringBuffer();
/* 91 */     df.format(paramDate, stringBuffer, new FieldPosition(0));
/* 92 */     stringBuffer.append(tz_offset);
/* 93 */     return stringBuffer.toString();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\INTERNALDATE.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */