/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ByteArray;
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ import java.io.ByteArrayInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RFC822DATA
/*    */   implements Item
/*    */ {
/* 23 */   public static char[] name = { 'R', 'F', 'C', '8', '2', '2' };
/*    */ 
/*    */   
/*    */   public int msgno;
/*    */   
/*    */   public ByteArray data;
/*    */ 
/*    */   
/*    */   public RFC822DATA(FetchResponse paramFetchResponse) throws ParsingException {
/* 32 */     this.msgno = paramFetchResponse.getNumber();
/* 33 */     paramFetchResponse.skipSpaces();
/* 34 */     this.data = paramFetchResponse.readByteArray();
/*    */   }
/*    */ 
/*    */   
/* 38 */   public ByteArray getByteArray() { return this.data; }
/*    */ 
/*    */   
/*    */   public ByteArrayInputStream getByteArrayInputStream() {
/* 42 */     if (this.data != null) {
/* 43 */       return this.data.toByteArrayInputStream();
/*    */     }
/* 45 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\RFC822DATA.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */