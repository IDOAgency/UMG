package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ByteArray;
import com.sun.mail.iap.ParsingException;
import java.io.ByteArrayInputStream;

public class RFC822DATA implements Item {
  public static char[] name = { 'R', 'F', 'C', '8', '2', '2' };
  
  public int msgno;
  
  public ByteArray data;
  
  public RFC822DATA(FetchResponse paramFetchResponse) throws ParsingException {
    this.msgno = paramFetchResponse.getNumber();
    paramFetchResponse.skipSpaces();
    this.data = paramFetchResponse.readByteArray();
  }
  
  public ByteArray getByteArray() { return this.data; }
  
  public ByteArrayInputStream getByteArrayInputStream() {
    if (this.data != null)
      return this.data.toByteArrayInputStream(); 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\RFC822DATA.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */