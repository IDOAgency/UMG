/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import com.sun.mail.iap.Argument;
/*     */ import java.io.IOException;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import javax.mail.Flags;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.search.AddressTerm;
/*     */ import javax.mail.search.AndTerm;
/*     */ import javax.mail.search.BodyTerm;
/*     */ import javax.mail.search.DateTerm;
/*     */ import javax.mail.search.FlagTerm;
/*     */ import javax.mail.search.FromStringTerm;
/*     */ import javax.mail.search.FromTerm;
/*     */ import javax.mail.search.HeaderTerm;
/*     */ import javax.mail.search.MessageIDTerm;
/*     */ import javax.mail.search.NotTerm;
/*     */ import javax.mail.search.OrTerm;
/*     */ import javax.mail.search.ReceivedDateTerm;
/*     */ import javax.mail.search.RecipientStringTerm;
/*     */ import javax.mail.search.RecipientTerm;
/*     */ import javax.mail.search.SearchException;
/*     */ import javax.mail.search.SearchTerm;
/*     */ import javax.mail.search.SentDateTerm;
/*     */ import javax.mail.search.SizeTerm;
/*     */ import javax.mail.search.StringTerm;
/*     */ import javax.mail.search.SubjectTerm;
/*     */ 
/*     */ class SearchSequence {
/*     */   static Argument generateSequence(SearchTerm paramSearchTerm, String paramString) throws SearchException, IOException {
/*  33 */     if (paramSearchTerm instanceof AndTerm)
/*  34 */       return and((AndTerm)paramSearchTerm, paramString); 
/*  35 */     if (paramSearchTerm instanceof OrTerm)
/*  36 */       return or((OrTerm)paramSearchTerm, paramString); 
/*  37 */     if (paramSearchTerm instanceof NotTerm)
/*  38 */       return not((NotTerm)paramSearchTerm, paramString); 
/*  39 */     if (paramSearchTerm instanceof HeaderTerm)
/*  40 */       return header((HeaderTerm)paramSearchTerm, paramString); 
/*  41 */     if (paramSearchTerm instanceof FlagTerm)
/*  42 */       return flag((FlagTerm)paramSearchTerm); 
/*  43 */     if (paramSearchTerm instanceof FromTerm) {
/*  44 */       FromTerm fromTerm = (FromTerm)paramSearchTerm;
/*  45 */       return from(fromTerm.getAddress().toString(), paramString);
/*     */     } 
/*  47 */     if (paramSearchTerm instanceof FromStringTerm) {
/*  48 */       FromStringTerm fromStringTerm = (FromStringTerm)paramSearchTerm;
/*  49 */       return from(fromStringTerm.getPattern(), paramString);
/*     */     } 
/*  51 */     if (paramSearchTerm instanceof RecipientTerm) {
/*  52 */       RecipientTerm recipientTerm = (RecipientTerm)paramSearchTerm;
/*  53 */       return recipient(recipientTerm.getRecipientType(), 
/*  54 */           recipientTerm.getAddress().toString(), 
/*  55 */           paramString);
/*     */     } 
/*  57 */     if (paramSearchTerm instanceof RecipientStringTerm) {
/*  58 */       RecipientStringTerm recipientStringTerm = (RecipientStringTerm)paramSearchTerm;
/*  59 */       return recipient(recipientStringTerm.getRecipientType(), 
/*  60 */           recipientStringTerm.getPattern(), 
/*  61 */           paramString);
/*     */     } 
/*  63 */     if (paramSearchTerm instanceof SubjectTerm)
/*  64 */       return subject((SubjectTerm)paramSearchTerm, paramString); 
/*  65 */     if (paramSearchTerm instanceof BodyTerm)
/*  66 */       return body((BodyTerm)paramSearchTerm, paramString); 
/*  67 */     if (paramSearchTerm instanceof SizeTerm)
/*  68 */       return size((SizeTerm)paramSearchTerm); 
/*  69 */     if (paramSearchTerm instanceof SentDateTerm)
/*  70 */       return sentdate((SentDateTerm)paramSearchTerm); 
/*  71 */     if (paramSearchTerm instanceof ReceivedDateTerm)
/*  72 */       return receiveddate((ReceivedDateTerm)paramSearchTerm); 
/*  73 */     if (paramSearchTerm instanceof MessageIDTerm) {
/*  74 */       return messageid((MessageIDTerm)paramSearchTerm, paramString);
/*     */     }
/*  76 */     throw new SearchException("Search too complex");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isAscii(SearchTerm paramSearchTerm) {
/*  84 */     if (paramSearchTerm instanceof AndTerm || paramSearchTerm instanceof OrTerm)
/*     */     { SearchTerm[] arrayOfSearchTerm;
/*  86 */       if (paramSearchTerm instanceof AndTerm) {
/*  87 */         arrayOfSearchTerm = ((AndTerm)paramSearchTerm).getTerms();
/*     */       } else {
/*  89 */         arrayOfSearchTerm = ((OrTerm)paramSearchTerm).getTerms();
/*     */       } 
/*  91 */       for (byte b = 0; b < arrayOfSearchTerm.length; b++)
/*  92 */       { if (!isAscii(arrayOfSearchTerm[b]))
/*  93 */           return false;  }  }
/*  94 */     else { if (paramSearchTerm instanceof NotTerm)
/*  95 */         return isAscii(((NotTerm)paramSearchTerm).getTerm()); 
/*  96 */       if (paramSearchTerm instanceof StringTerm)
/*  97 */         return isAscii(((StringTerm)paramSearchTerm).getPattern()); 
/*  98 */       if (paramSearchTerm instanceof AddressTerm) {
/*  99 */         return isAscii(((AddressTerm)paramSearchTerm).getAddress().toString());
/*     */       } }
/*     */     
/* 102 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean isAscii(String paramString) {
/* 106 */     int i = paramString.length();
/*     */     
/* 108 */     for (byte b = 0; b < i; b++) {
/* 109 */       if (paramString.charAt(b) > '')
/* 110 */         return false; 
/*     */     } 
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Argument and(AndTerm paramAndTerm, String paramString) throws SearchException, IOException {
/* 118 */     SearchTerm[] arrayOfSearchTerm = paramAndTerm.getTerms();
/*     */     
/* 120 */     Argument argument = generateSequence(arrayOfSearchTerm[0], paramString);
/*     */     
/* 122 */     for (byte b = 1; b < arrayOfSearchTerm.length; b++)
/* 123 */       argument.append(generateSequence(arrayOfSearchTerm[b], paramString)); 
/* 124 */     return argument;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Argument or(OrTerm paramOrTerm, String paramString) throws SearchException, IOException {
/* 129 */     SearchTerm[] arrayOfSearchTerm = paramOrTerm.getTerms();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     if (arrayOfSearchTerm.length > 2) {
/* 136 */       OrTerm orTerm = arrayOfSearchTerm[0];
/*     */ 
/*     */       
/* 139 */       for (byte b = 1; b < arrayOfSearchTerm.length; b++) {
/* 140 */         orTerm = new OrTerm(orTerm, arrayOfSearchTerm[b]);
/*     */       }
/* 142 */       paramOrTerm = (OrTerm)orTerm;
/*     */       
/* 144 */       arrayOfSearchTerm = paramOrTerm.getTerms();
/*     */     } 
/*     */ 
/*     */     
/* 148 */     Argument argument = new Argument();
/*     */ 
/*     */     
/* 151 */     argument.writeAtom("OR");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     if (arrayOfSearchTerm[0] instanceof AndTerm || arrayOfSearchTerm[0] instanceof FlagTerm) {
/* 159 */       argument.writeArgument(generateSequence(arrayOfSearchTerm[0], paramString));
/*     */     } else {
/* 161 */       argument.append(generateSequence(arrayOfSearchTerm[0], paramString));
/*     */     } 
/*     */     
/* 164 */     if (arrayOfSearchTerm[1] instanceof AndTerm || arrayOfSearchTerm[1] instanceof FlagTerm) {
/* 165 */       argument.writeArgument(generateSequence(arrayOfSearchTerm[1], paramString));
/*     */     } else {
/* 167 */       argument.append(generateSequence(arrayOfSearchTerm[1], paramString));
/*     */     } 
/* 169 */     return argument;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Argument not(NotTerm paramNotTerm, String paramString) throws SearchException, IOException {
/* 174 */     Argument argument = new Argument();
/*     */ 
/*     */     
/* 177 */     argument.writeAtom("NOT");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     SearchTerm searchTerm = paramNotTerm.getTerm();
/* 185 */     if (searchTerm instanceof AndTerm || searchTerm instanceof FlagTerm) {
/* 186 */       argument.writeArgument(generateSequence(searchTerm, paramString));
/*     */     } else {
/* 188 */       argument.append(generateSequence(searchTerm, paramString));
/*     */     } 
/* 190 */     return argument;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Argument header(HeaderTerm paramHeaderTerm, String paramString) throws SearchException, IOException {
/* 195 */     Argument argument = new Argument();
/* 196 */     argument.writeAtom("HEADER");
/* 197 */     argument.writeString(paramHeaderTerm.getHeaderName());
/* 198 */     argument.writeString(paramHeaderTerm.getPattern(), paramString);
/* 199 */     return argument;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Argument messageid(MessageIDTerm paramMessageIDTerm, String paramString) throws SearchException, IOException {
/* 204 */     Argument argument = new Argument();
/* 205 */     argument.writeAtom("HEADER");
/* 206 */     argument.writeString("Message-ID");
/*     */     
/* 208 */     argument.writeString(paramMessageIDTerm.getPattern(), paramString);
/* 209 */     return argument;
/*     */   }
/*     */   
/*     */   private static Argument flag(FlagTerm paramFlagTerm) throws SearchException {
/* 213 */     boolean bool = paramFlagTerm.getTestSet();
/*     */     
/* 215 */     Argument argument = new Argument();
/*     */     
/* 217 */     Flags flags = paramFlagTerm.getFlags();
/* 218 */     Flags.Flag[] arrayOfFlag = flags.getSystemFlags();
/* 219 */     String[] arrayOfString = flags.getUserFlags();
/* 220 */     if (arrayOfFlag.length == 0 && arrayOfString.length == 0) {
/* 221 */       throw new SearchException("Invalid FlagTerm");
/*     */     }
/* 223 */     for (byte b1 = 0; b1 < arrayOfFlag.length; b1++) {
/* 224 */       if (arrayOfFlag[b1] == Flags.Flag.DELETED) {
/* 225 */         argument.writeAtom(bool ? "DELETED" : "UNDELETED");
/* 226 */       } else if (arrayOfFlag[b1] == Flags.Flag.ANSWERED) {
/* 227 */         argument.writeAtom(bool ? "ANSWERED" : "UNANSWERED");
/* 228 */       } else if (arrayOfFlag[b1] == Flags.Flag.DRAFT) {
/* 229 */         argument.writeAtom(bool ? "DRAFT" : "UNDRAFT");
/* 230 */       } else if (arrayOfFlag[b1] == Flags.Flag.FLAGGED) {
/* 231 */         argument.writeAtom(bool ? "FLAGGED" : "UNFLAGGED");
/* 232 */       } else if (arrayOfFlag[b1] == Flags.Flag.RECENT) {
/* 233 */         argument.writeAtom(bool ? "RECENT" : "OLD");
/* 234 */       } else if (arrayOfFlag[b1] == Flags.Flag.SEEN) {
/* 235 */         argument.writeAtom(bool ? "SEEN" : "UNSEEN");
/*     */       } 
/*     */     } 
/* 238 */     for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
/* 239 */       argument.writeAtom(bool ? "KEYWORD" : "UNKEYWORD");
/* 240 */       argument.writeAtom(arrayOfString[b2]);
/*     */     } 
/*     */     
/* 243 */     return argument;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Argument from(String paramString1, String paramString2) throws SearchException, IOException {
/* 248 */     Argument argument = new Argument();
/* 249 */     argument.writeAtom("FROM");
/* 250 */     argument.writeString(paramString1, paramString2);
/* 251 */     return argument;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Argument recipient(Message.RecipientType paramRecipientType, String paramString1, String paramString2) throws SearchException, IOException {
/* 257 */     Argument argument = new Argument();
/*     */     
/* 259 */     if (paramRecipientType == Message.RecipientType.TO) {
/* 260 */       argument.writeAtom("TO");
/* 261 */     } else if (paramRecipientType == Message.RecipientType.CC) {
/* 262 */       argument.writeAtom("CC");
/* 263 */     } else if (paramRecipientType == Message.RecipientType.BCC) {
/* 264 */       argument.writeAtom("BCC");
/*     */     } else {
/* 266 */       throw new SearchException("Illegal Recipient type");
/*     */     } 
/* 268 */     argument.writeString(paramString1, paramString2);
/* 269 */     return argument;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Argument subject(SubjectTerm paramSubjectTerm, String paramString) throws SearchException, IOException {
/* 274 */     Argument argument = new Argument();
/*     */     
/* 276 */     argument.writeAtom("SUBJECT");
/* 277 */     argument.writeString(paramSubjectTerm.getPattern(), paramString);
/* 278 */     return argument;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Argument body(BodyTerm paramBodyTerm, String paramString) throws SearchException, IOException {
/* 283 */     Argument argument = new Argument();
/*     */     
/* 285 */     argument.writeAtom("BODY");
/* 286 */     argument.writeString(paramBodyTerm.getPattern(), paramString);
/* 287 */     return argument;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Argument size(SizeTerm paramSizeTerm) throws SearchException {
/* 292 */     Argument argument = new Argument();
/*     */     
/* 294 */     switch (paramSizeTerm.getComparison()) {
/*     */       case 5:
/* 296 */         argument.writeAtom("LARGER");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 306 */         argument.writeNumber(paramSizeTerm.getNumber());
/* 307 */         return argument;case 2: argument.writeAtom("SMALLER"); argument.writeNumber(paramSizeTerm.getNumber()); return argument;
/*     */     } 
/*     */     throw new SearchException("Cannot handle Comparison");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] monthTable = { 
/* 322 */       "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
/* 323 */       "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
/*     */ 
/*     */ 
/*     */   
/* 327 */   private static Calendar cal = new GregorianCalendar();
/*     */   
/*     */   private static String toIMAPDate(Date paramDate) {
/* 330 */     StringBuffer stringBuffer = new StringBuffer();
/* 331 */     cal.setTime(paramDate);
/*     */     
/* 333 */     stringBuffer.append(cal.get(5)).append("-");
/* 334 */     stringBuffer.append(monthTable[cal.get(2)]).append('-');
/* 335 */     stringBuffer.append(cal.get(1));
/*     */     
/* 337 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static Argument sentdate(DateTerm paramDateTerm) throws SearchException {
/* 342 */     Argument argument = new Argument();
/* 343 */     String str = toIMAPDate(paramDateTerm.getDate());
/*     */     
/* 345 */     switch (paramDateTerm.getComparison()) {
/*     */       case 5:
/* 347 */         argument.writeAtom("SENTSINCE " + str);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 368 */         return argument;case 3: argument.writeAtom("SENTON " + str); return argument;case 2: argument.writeAtom("SENTBEFORE " + str); return argument;case 6: argument.writeAtom("OR SENTSINCE " + str + " SENTON " + str); return argument;case 1: argument.writeAtom("OR SENTBEFORE " + str + " SENTON " + str); return argument;case 4: argument.writeAtom("NOT SENTON " + str); return argument;
/*     */     } 
/*     */     throw new SearchException("Cannot handle Date Comparison");
/*     */   }
/*     */   private static Argument receiveddate(DateTerm paramDateTerm) throws SearchException {
/* 373 */     Argument argument = new Argument();
/* 374 */     String str = toIMAPDate(paramDateTerm.getDate());
/*     */     
/* 376 */     switch (paramDateTerm.getComparison()) {
/*     */       case 5:
/* 378 */         argument.writeAtom("SINCE " + str);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 399 */         return argument;case 3: argument.writeAtom("ON " + str); return argument;case 2: argument.writeAtom("BEFORE " + str); return argument;case 6: argument.writeAtom("OR SINCE " + str + " ON " + str); return argument;case 1: argument.writeAtom("OR BEFORE " + str + " ON " + str); return argument;case 4: argument.writeAtom("NOT ON " + str); return argument;
/*     */     } 
/*     */     throw new SearchException("Cannot handle Date Comparison");
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\SearchSequence.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */