package com.sun.mail.imap.protocol;

import com.sun.mail.iap.Argument;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.mail.Flags;
import javax.mail.Message;
import javax.mail.search.AddressTerm;
import javax.mail.search.AndTerm;
import javax.mail.search.BodyTerm;
import javax.mail.search.DateTerm;
import javax.mail.search.FlagTerm;
import javax.mail.search.FromStringTerm;
import javax.mail.search.FromTerm;
import javax.mail.search.HeaderTerm;
import javax.mail.search.MessageIDTerm;
import javax.mail.search.NotTerm;
import javax.mail.search.OrTerm;
import javax.mail.search.ReceivedDateTerm;
import javax.mail.search.RecipientStringTerm;
import javax.mail.search.RecipientTerm;
import javax.mail.search.SearchException;
import javax.mail.search.SearchTerm;
import javax.mail.search.SentDateTerm;
import javax.mail.search.SizeTerm;
import javax.mail.search.StringTerm;
import javax.mail.search.SubjectTerm;

class SearchSequence {
  static Argument generateSequence(SearchTerm paramSearchTerm, String paramString) throws SearchException, IOException {
    if (paramSearchTerm instanceof AndTerm)
      return and((AndTerm)paramSearchTerm, paramString); 
    if (paramSearchTerm instanceof OrTerm)
      return or((OrTerm)paramSearchTerm, paramString); 
    if (paramSearchTerm instanceof NotTerm)
      return not((NotTerm)paramSearchTerm, paramString); 
    if (paramSearchTerm instanceof HeaderTerm)
      return header((HeaderTerm)paramSearchTerm, paramString); 
    if (paramSearchTerm instanceof FlagTerm)
      return flag((FlagTerm)paramSearchTerm); 
    if (paramSearchTerm instanceof FromTerm) {
      FromTerm fromTerm = (FromTerm)paramSearchTerm;
      return from(fromTerm.getAddress().toString(), paramString);
    } 
    if (paramSearchTerm instanceof FromStringTerm) {
      FromStringTerm fromStringTerm = (FromStringTerm)paramSearchTerm;
      return from(fromStringTerm.getPattern(), paramString);
    } 
    if (paramSearchTerm instanceof RecipientTerm) {
      RecipientTerm recipientTerm = (RecipientTerm)paramSearchTerm;
      return recipient(recipientTerm.getRecipientType(), 
          recipientTerm.getAddress().toString(), 
          paramString);
    } 
    if (paramSearchTerm instanceof RecipientStringTerm) {
      RecipientStringTerm recipientStringTerm = (RecipientStringTerm)paramSearchTerm;
      return recipient(recipientStringTerm.getRecipientType(), 
          recipientStringTerm.getPattern(), 
          paramString);
    } 
    if (paramSearchTerm instanceof SubjectTerm)
      return subject((SubjectTerm)paramSearchTerm, paramString); 
    if (paramSearchTerm instanceof BodyTerm)
      return body((BodyTerm)paramSearchTerm, paramString); 
    if (paramSearchTerm instanceof SizeTerm)
      return size((SizeTerm)paramSearchTerm); 
    if (paramSearchTerm instanceof SentDateTerm)
      return sentdate((SentDateTerm)paramSearchTerm); 
    if (paramSearchTerm instanceof ReceivedDateTerm)
      return receiveddate((ReceivedDateTerm)paramSearchTerm); 
    if (paramSearchTerm instanceof MessageIDTerm)
      return messageid((MessageIDTerm)paramSearchTerm, paramString); 
    throw new SearchException("Search too complex");
  }
  
  static boolean isAscii(SearchTerm paramSearchTerm) {
    if (paramSearchTerm instanceof AndTerm || paramSearchTerm instanceof OrTerm) {
      SearchTerm[] arrayOfSearchTerm;
      if (paramSearchTerm instanceof AndTerm) {
        arrayOfSearchTerm = ((AndTerm)paramSearchTerm).getTerms();
      } else {
        arrayOfSearchTerm = ((OrTerm)paramSearchTerm).getTerms();
      } 
      for (byte b = 0; b < arrayOfSearchTerm.length; b++) {
        if (!isAscii(arrayOfSearchTerm[b]))
          return false; 
      } 
    } else {
      if (paramSearchTerm instanceof NotTerm)
        return isAscii(((NotTerm)paramSearchTerm).getTerm()); 
      if (paramSearchTerm instanceof StringTerm)
        return isAscii(((StringTerm)paramSearchTerm).getPattern()); 
      if (paramSearchTerm instanceof AddressTerm)
        return isAscii(((AddressTerm)paramSearchTerm).getAddress().toString()); 
    } 
    return true;
  }
  
  private static boolean isAscii(String paramString) {
    int i = paramString.length();
    for (byte b = 0; b < i; b++) {
      if (paramString.charAt(b) > '')
        return false; 
    } 
    return true;
  }
  
  private static Argument and(AndTerm paramAndTerm, String paramString) throws SearchException, IOException {
    SearchTerm[] arrayOfSearchTerm = paramAndTerm.getTerms();
    Argument argument = generateSequence(arrayOfSearchTerm[0], paramString);
    for (byte b = 1; b < arrayOfSearchTerm.length; b++)
      argument.append(generateSequence(arrayOfSearchTerm[b], paramString)); 
    return argument;
  }
  
  private static Argument or(OrTerm paramOrTerm, String paramString) throws SearchException, IOException {
    SearchTerm[] arrayOfSearchTerm = paramOrTerm.getTerms();
    if (arrayOfSearchTerm.length > 2) {
      OrTerm orTerm = arrayOfSearchTerm[0];
      for (byte b = 1; b < arrayOfSearchTerm.length; b++)
        orTerm = new OrTerm(orTerm, arrayOfSearchTerm[b]); 
      paramOrTerm = (OrTerm)orTerm;
      arrayOfSearchTerm = paramOrTerm.getTerms();
    } 
    Argument argument = new Argument();
    argument.writeAtom("OR");
    if (arrayOfSearchTerm[0] instanceof AndTerm || arrayOfSearchTerm[0] instanceof FlagTerm) {
      argument.writeArgument(generateSequence(arrayOfSearchTerm[0], paramString));
    } else {
      argument.append(generateSequence(arrayOfSearchTerm[0], paramString));
    } 
    if (arrayOfSearchTerm[1] instanceof AndTerm || arrayOfSearchTerm[1] instanceof FlagTerm) {
      argument.writeArgument(generateSequence(arrayOfSearchTerm[1], paramString));
    } else {
      argument.append(generateSequence(arrayOfSearchTerm[1], paramString));
    } 
    return argument;
  }
  
  private static Argument not(NotTerm paramNotTerm, String paramString) throws SearchException, IOException {
    Argument argument = new Argument();
    argument.writeAtom("NOT");
    SearchTerm searchTerm = paramNotTerm.getTerm();
    if (searchTerm instanceof AndTerm || searchTerm instanceof FlagTerm) {
      argument.writeArgument(generateSequence(searchTerm, paramString));
    } else {
      argument.append(generateSequence(searchTerm, paramString));
    } 
    return argument;
  }
  
  private static Argument header(HeaderTerm paramHeaderTerm, String paramString) throws SearchException, IOException {
    Argument argument = new Argument();
    argument.writeAtom("HEADER");
    argument.writeString(paramHeaderTerm.getHeaderName());
    argument.writeString(paramHeaderTerm.getPattern(), paramString);
    return argument;
  }
  
  private static Argument messageid(MessageIDTerm paramMessageIDTerm, String paramString) throws SearchException, IOException {
    Argument argument = new Argument();
    argument.writeAtom("HEADER");
    argument.writeString("Message-ID");
    argument.writeString(paramMessageIDTerm.getPattern(), paramString);
    return argument;
  }
  
  private static Argument flag(FlagTerm paramFlagTerm) throws SearchException {
    boolean bool = paramFlagTerm.getTestSet();
    Argument argument = new Argument();
    Flags flags = paramFlagTerm.getFlags();
    Flags.Flag[] arrayOfFlag = flags.getSystemFlags();
    String[] arrayOfString = flags.getUserFlags();
    if (arrayOfFlag.length == 0 && arrayOfString.length == 0)
      throw new SearchException("Invalid FlagTerm"); 
    for (byte b1 = 0; b1 < arrayOfFlag.length; b1++) {
      if (arrayOfFlag[b1] == Flags.Flag.DELETED) {
        argument.writeAtom(bool ? "DELETED" : "UNDELETED");
      } else if (arrayOfFlag[b1] == Flags.Flag.ANSWERED) {
        argument.writeAtom(bool ? "ANSWERED" : "UNANSWERED");
      } else if (arrayOfFlag[b1] == Flags.Flag.DRAFT) {
        argument.writeAtom(bool ? "DRAFT" : "UNDRAFT");
      } else if (arrayOfFlag[b1] == Flags.Flag.FLAGGED) {
        argument.writeAtom(bool ? "FLAGGED" : "UNFLAGGED");
      } else if (arrayOfFlag[b1] == Flags.Flag.RECENT) {
        argument.writeAtom(bool ? "RECENT" : "OLD");
      } else if (arrayOfFlag[b1] == Flags.Flag.SEEN) {
        argument.writeAtom(bool ? "SEEN" : "UNSEEN");
      } 
    } 
    for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
      argument.writeAtom(bool ? "KEYWORD" : "UNKEYWORD");
      argument.writeAtom(arrayOfString[b2]);
    } 
    return argument;
  }
  
  private static Argument from(String paramString1, String paramString2) throws SearchException, IOException {
    Argument argument = new Argument();
    argument.writeAtom("FROM");
    argument.writeString(paramString1, paramString2);
    return argument;
  }
  
  private static Argument recipient(Message.RecipientType paramRecipientType, String paramString1, String paramString2) throws SearchException, IOException {
    Argument argument = new Argument();
    if (paramRecipientType == Message.RecipientType.TO) {
      argument.writeAtom("TO");
    } else if (paramRecipientType == Message.RecipientType.CC) {
      argument.writeAtom("CC");
    } else if (paramRecipientType == Message.RecipientType.BCC) {
      argument.writeAtom("BCC");
    } else {
      throw new SearchException("Illegal Recipient type");
    } 
    argument.writeString(paramString1, paramString2);
    return argument;
  }
  
  private static Argument subject(SubjectTerm paramSubjectTerm, String paramString) throws SearchException, IOException {
    Argument argument = new Argument();
    argument.writeAtom("SUBJECT");
    argument.writeString(paramSubjectTerm.getPattern(), paramString);
    return argument;
  }
  
  private static Argument body(BodyTerm paramBodyTerm, String paramString) throws SearchException, IOException {
    Argument argument = new Argument();
    argument.writeAtom("BODY");
    argument.writeString(paramBodyTerm.getPattern(), paramString);
    return argument;
  }
  
  private static Argument size(SizeTerm paramSizeTerm) throws SearchException {
    Argument argument = new Argument();
    switch (paramSizeTerm.getComparison()) {
      case 5:
        argument.writeAtom("LARGER");
        argument.writeNumber(paramSizeTerm.getNumber());
        return argument;
      case 2:
        argument.writeAtom("SMALLER");
        argument.writeNumber(paramSizeTerm.getNumber());
        return argument;
    } 
    throw new SearchException("Cannot handle Comparison");
  }
  
  private static String[] monthTable = { 
      "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
      "Jul", "Aug", "Sep", "Oct", 
      "Nov", "Dec" };
  
  private static Calendar cal = new GregorianCalendar();
  
  private static String toIMAPDate(Date paramDate) {
    StringBuffer stringBuffer = new StringBuffer();
    cal.setTime(paramDate);
    stringBuffer.append(cal.get(5)).append("-");
    stringBuffer.append(monthTable[cal.get(2)]).append('-');
    stringBuffer.append(cal.get(1));
    return stringBuffer.toString();
  }
  
  private static Argument sentdate(DateTerm paramDateTerm) throws SearchException {
    Argument argument = new Argument();
    String str = toIMAPDate(paramDateTerm.getDate());
    switch (paramDateTerm.getComparison()) {
      case 5:
        argument.writeAtom("SENTSINCE " + str);
        return argument;
      case 3:
        argument.writeAtom("SENTON " + str);
        return argument;
      case 2:
        argument.writeAtom("SENTBEFORE " + str);
        return argument;
      case 6:
        argument.writeAtom("OR SENTSINCE " + str + " SENTON " + str);
        return argument;
      case 1:
        argument.writeAtom("OR SENTBEFORE " + str + " SENTON " + str);
        return argument;
      case 4:
        argument.writeAtom("NOT SENTON " + str);
        return argument;
    } 
    throw new SearchException("Cannot handle Date Comparison");
  }
  
  private static Argument receiveddate(DateTerm paramDateTerm) throws SearchException {
    Argument argument = new Argument();
    String str = toIMAPDate(paramDateTerm.getDate());
    switch (paramDateTerm.getComparison()) {
      case 5:
        argument.writeAtom("SINCE " + str);
        return argument;
      case 3:
        argument.writeAtom("ON " + str);
        return argument;
      case 2:
        argument.writeAtom("BEFORE " + str);
        return argument;
      case 6:
        argument.writeAtom("OR SINCE " + str + " ON " + str);
        return argument;
      case 1:
        argument.writeAtom("OR BEFORE " + str + " ON " + str);
        return argument;
      case 4:
        argument.writeAtom("NOT ON " + str);
        return argument;
    } 
    throw new SearchException("Cannot handle Date Comparison");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\SearchSequence.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */