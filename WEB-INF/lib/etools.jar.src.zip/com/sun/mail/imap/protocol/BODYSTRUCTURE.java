/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import com.sun.mail.iap.ParsingException;
/*     */ import com.sun.mail.iap.Response;
/*     */ import java.util.Vector;
/*     */ import javax.mail.internet.ParameterList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BODYSTRUCTURE
/*     */   implements Item
/*     */ {
/*     */   public static char[] name = { 
/*  23 */       'B', 'O', 'D', 'Y', 'S', 'T', 'R', 'U', 'C', 'T', 'U', 'R', 'E' };
/*     */   
/*     */   public int msgno;
/*     */   
/*     */   public String type;
/*     */   
/*     */   public String subtype;
/*     */   public String encoding;
/*     */   public int lines;
/*     */   public int size;
/*     */   public String disposition;
/*     */   public String id;
/*     */   public String description;
/*     */   public String md5;
/*     */   public String attachment;
/*     */   public ParameterList cParams;
/*     */   public ParameterList dParams;
/*     */   public String[] language;
/*     */   public BODYSTRUCTURE[] bodies;
/*     */   public ENVELOPE envelope;
/*  43 */   private static int SINGLE = 1;
/*  44 */   private static int MULTI = 2;
/*  45 */   private static int NESTED = 3;
/*     */   public BODYSTRUCTURE(FetchResponse paramFetchResponse) throws ParsingException {
/*     */     this.lines = -1;
/*     */     this.size = -1;
/*  49 */     this.msgno = paramFetchResponse.getNumber();
/*     */     
/*  51 */     paramFetchResponse.skipSpaces();
/*     */     
/*  53 */     if (paramFetchResponse.readByte() != 40) {
/*  54 */       throw new ParsingException("BODYSTRUCTURE parse error");
/*     */     }
/*  56 */     if (paramFetchResponse.peekByte() == 40) {
/*  57 */       this.type = "multipart";
/*  58 */       this.processedType = MULTI;
/*  59 */       Vector vector = new Vector(1);
/*     */       
/*     */       do {
/*  62 */         vector.addElement(new BODYSTRUCTURE(paramFetchResponse));
/*  63 */       } while (paramFetchResponse.peekByte() == 40);
/*     */ 
/*     */       
/*  66 */       this.bodies = new BODYSTRUCTURE[vector.size()];
/*  67 */       vector.copyInto(this.bodies);
/*     */       
/*  69 */       this.subtype = paramFetchResponse.readString();
/*     */       
/*  71 */       if (paramFetchResponse.readByte() == 41) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*  77 */       this.cParams = parseParameters(paramFetchResponse);
/*  78 */       if (paramFetchResponse.readByte() == 41) {
/*     */         return;
/*     */       }
/*     */       
/*  82 */       byte b1 = paramFetchResponse.readByte();
/*  83 */       if (b1 == 40) {
/*  84 */         this.disposition = paramFetchResponse.readString();
/*  85 */         this.dParams = parseParameters(paramFetchResponse);
/*  86 */         if (paramFetchResponse.readByte() != 41)
/*  87 */           throw new ParsingException("BODYSTRUCTURE parse error"); 
/*  88 */       } else if (b1 == 78 || b1 == 110) {
/*  89 */         paramFetchResponse.skip(2);
/*     */       } 
/*     */       
/*  92 */       if (paramFetchResponse.peekByte() == 40) {
/*  93 */         this.language = paramFetchResponse.readStringList();
/*     */       } else {
/*  95 */         String str = paramFetchResponse.readString();
/*  96 */         if (str != null) {
/*  97 */           String[] arrayOfString = { str };
/*  98 */           this.language = arrayOfString;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 103 */       while (paramFetchResponse.readByte() == 32)
/* 104 */         parseBodyExtension(paramFetchResponse); 
/*     */       return;
/*     */     } 
/* 107 */     this.type = paramFetchResponse.readString();
/* 108 */     this.processedType = SINGLE;
/* 109 */     this.subtype = paramFetchResponse.readString();
/* 110 */     this.cParams = parseParameters(paramFetchResponse);
/* 111 */     this.id = paramFetchResponse.readString();
/* 112 */     this.description = paramFetchResponse.readString();
/* 113 */     this.encoding = paramFetchResponse.readString();
/* 114 */     this.size = paramFetchResponse.readNumber();
/*     */ 
/*     */     
/* 117 */     if (this.type.equalsIgnoreCase("text")) {
/* 118 */       this.lines = paramFetchResponse.readNumber();
/* 119 */     } else if (this.type.equalsIgnoreCase("message") && 
/* 120 */       this.subtype.equalsIgnoreCase("rfc822")) {
/*     */       
/* 122 */       this.processedType = NESTED;
/* 123 */       this.envelope = new ENVELOPE(paramFetchResponse);
/* 124 */       BODYSTRUCTURE[] arrayOfBODYSTRUCTURE = { new BODYSTRUCTURE(paramFetchResponse) };
/* 125 */       this.bodies = arrayOfBODYSTRUCTURE;
/* 126 */       this.lines = paramFetchResponse.readNumber();
/*     */     } 
/*     */     
/* 129 */     if (paramFetchResponse.readByte() == 41) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 135 */     this.md5 = paramFetchResponse.readString();
/* 136 */     if (paramFetchResponse.readByte() == 41) {
/*     */       return;
/*     */     }
/*     */     
/* 140 */     byte b = paramFetchResponse.readByte();
/* 141 */     if (b == 40) {
/* 142 */       this.disposition = paramFetchResponse.readString();
/* 143 */       this.dParams = parseParameters(paramFetchResponse);
/* 144 */       if (paramFetchResponse.readByte() != 41)
/* 145 */         throw new ParsingException("BODYSTRUCTURE parse error"); 
/* 146 */     } else if (b == 78 || b == 110) {
/* 147 */       paramFetchResponse.skip(2);
/*     */     } 
/* 149 */     if (paramFetchResponse.readByte() == 41) {
/*     */       return;
/*     */     }
/*     */     
/* 153 */     if (paramFetchResponse.peekByte() == 40) {
/* 154 */       this.language = paramFetchResponse.readStringList();
/*     */     } else {
/* 156 */       String str = paramFetchResponse.readString();
/* 157 */       if (str != null) {
/* 158 */         String[] arrayOfString = { str };
/* 159 */         this.language = arrayOfString;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 164 */     while (paramFetchResponse.readByte() == 32)
/* 165 */       parseBodyExtension(paramFetchResponse); 
/*     */   }
/*     */   
/*     */   private int processedType;
/*     */   
/* 170 */   public boolean isMulti() { return !(this.processedType != MULTI); }
/*     */ 
/*     */ 
/*     */   
/* 174 */   public boolean isSingle() { return !(this.processedType != SINGLE); }
/*     */ 
/*     */ 
/*     */   
/* 178 */   public boolean isNested() { return !(this.processedType != NESTED); }
/*     */ 
/*     */ 
/*     */   
/*     */   private ParameterList parseParameters(Response paramResponse) throws ParsingException {
/* 183 */     paramResponse.skipSpaces();
/*     */     
/* 185 */     ParameterList parameterList = null;
/* 186 */     byte b = paramResponse.readByte();
/* 187 */     if (b == 40) {
/* 188 */       parameterList = new ParameterList();
/*     */       do {
/* 190 */         String str1 = paramResponse.readString();
/* 191 */         String str2 = paramResponse.readString();
/* 192 */         parameterList.set(str1, str2);
/* 193 */       } while (paramResponse.readByte() != 41);
/* 194 */     } else if (b == 78 || b == 110) {
/* 195 */       paramResponse.skip(2);
/*     */     } else {
/* 197 */       throw new ParsingException("Parameter list parse error");
/*     */     } 
/* 199 */     return parameterList;
/*     */   }
/*     */   
/*     */   private void parseBodyExtension(Response paramResponse) throws ParsingException {
/* 203 */     paramResponse.skipSpaces();
/*     */     
/* 205 */     byte b = paramResponse.peekByte();
/* 206 */     if (b == 40) {
/* 207 */       paramResponse.skip(1);
/*     */       do {
/* 209 */         parseBodyExtension(paramResponse);
/* 210 */       } while (paramResponse.readByte() != 41); return;
/* 211 */     }  if (Character.isDigit((char)b)) {
/* 212 */       paramResponse.readNumber(); return;
/*     */     } 
/* 214 */     paramResponse.readString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\BODYSTRUCTURE.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */