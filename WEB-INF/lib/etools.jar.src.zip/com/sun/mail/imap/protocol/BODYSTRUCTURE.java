package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;
import com.sun.mail.iap.Response;
import java.util.Vector;
import javax.mail.internet.ParameterList;

public class BODYSTRUCTURE implements Item {
  public static char[] name = { 
      'B', 'O', 'D', 'Y', 'S', 'T', 'R', 'U', 'C', 'T', 
      'U', 'R', 'E' };
  
  public int msgno;
  
  public String type;
  
  public String subtype;
  
  public String encoding;
  
  public int lines;
  
  public int size;
  
  public String disposition;
  
  public String id;
  
  public String description;
  
  public String md5;
  
  public String attachment;
  
  public ParameterList cParams;
  
  public ParameterList dParams;
  
  public String[] language;
  
  public BODYSTRUCTURE[] bodies;
  
  public ENVELOPE envelope;
  
  private static int SINGLE = 1;
  
  private static int MULTI = 2;
  
  private static int NESTED = 3;
  
  private int processedType;
  
  public BODYSTRUCTURE(FetchResponse paramFetchResponse) throws ParsingException {
    this.lines = -1;
    this.size = -1;
    this.msgno = paramFetchResponse.getNumber();
    paramFetchResponse.skipSpaces();
    if (paramFetchResponse.readByte() != 40)
      throw new ParsingException("BODYSTRUCTURE parse error"); 
    if (paramFetchResponse.peekByte() == 40) {
      this.type = "multipart";
      this.processedType = MULTI;
      Vector vector = new Vector(1);
      do {
        vector.addElement(new BODYSTRUCTURE(paramFetchResponse));
      } while (paramFetchResponse.peekByte() == 40);
      this.bodies = new BODYSTRUCTURE[vector.size()];
      vector.copyInto(this.bodies);
      this.subtype = paramFetchResponse.readString();
      if (paramFetchResponse.readByte() == 41)
        return; 
      this.cParams = parseParameters(paramFetchResponse);
      if (paramFetchResponse.readByte() == 41)
        return; 
      byte b1 = paramFetchResponse.readByte();
      if (b1 == 40) {
        this.disposition = paramFetchResponse.readString();
        this.dParams = parseParameters(paramFetchResponse);
        if (paramFetchResponse.readByte() != 41)
          throw new ParsingException("BODYSTRUCTURE parse error"); 
      } else if (b1 == 78 || b1 == 110) {
        paramFetchResponse.skip(2);
      } 
      if (paramFetchResponse.peekByte() == 40) {
        this.language = paramFetchResponse.readStringList();
      } else {
        String str = paramFetchResponse.readString();
        if (str != null) {
          String[] arrayOfString = { str };
          this.language = arrayOfString;
        } 
      } 
      while (paramFetchResponse.readByte() == 32)
        parseBodyExtension(paramFetchResponse); 
      return;
    } 
    this.type = paramFetchResponse.readString();
    this.processedType = SINGLE;
    this.subtype = paramFetchResponse.readString();
    this.cParams = parseParameters(paramFetchResponse);
    this.id = paramFetchResponse.readString();
    this.description = paramFetchResponse.readString();
    this.encoding = paramFetchResponse.readString();
    this.size = paramFetchResponse.readNumber();
    if (this.type.equalsIgnoreCase("text")) {
      this.lines = paramFetchResponse.readNumber();
    } else if (this.type.equalsIgnoreCase("message") && 
      this.subtype.equalsIgnoreCase("rfc822")) {
      this.processedType = NESTED;
      this.envelope = new ENVELOPE(paramFetchResponse);
      BODYSTRUCTURE[] arrayOfBODYSTRUCTURE = { new BODYSTRUCTURE(paramFetchResponse) };
      this.bodies = arrayOfBODYSTRUCTURE;
      this.lines = paramFetchResponse.readNumber();
    } 
    if (paramFetchResponse.readByte() == 41)
      return; 
    this.md5 = paramFetchResponse.readString();
    if (paramFetchResponse.readByte() == 41)
      return; 
    byte b = paramFetchResponse.readByte();
    if (b == 40) {
      this.disposition = paramFetchResponse.readString();
      this.dParams = parseParameters(paramFetchResponse);
      if (paramFetchResponse.readByte() != 41)
        throw new ParsingException("BODYSTRUCTURE parse error"); 
    } else if (b == 78 || b == 110) {
      paramFetchResponse.skip(2);
    } 
    if (paramFetchResponse.readByte() == 41)
      return; 
    if (paramFetchResponse.peekByte() == 40) {
      this.language = paramFetchResponse.readStringList();
    } else {
      String str = paramFetchResponse.readString();
      if (str != null) {
        String[] arrayOfString = { str };
        this.language = arrayOfString;
      } 
    } 
    while (paramFetchResponse.readByte() == 32)
      parseBodyExtension(paramFetchResponse); 
  }
  
  public boolean isMulti() { return !(this.processedType != MULTI); }
  
  public boolean isSingle() { return !(this.processedType != SINGLE); }
  
  public boolean isNested() { return !(this.processedType != NESTED); }
  
  private ParameterList parseParameters(Response paramResponse) throws ParsingException {
    paramResponse.skipSpaces();
    ParameterList parameterList = null;
    byte b = paramResponse.readByte();
    if (b == 40) {
      parameterList = new ParameterList();
      do {
        String str1 = paramResponse.readString();
        String str2 = paramResponse.readString();
        parameterList.set(str1, str2);
      } while (paramResponse.readByte() != 41);
    } else if (b == 78 || b == 110) {
      paramResponse.skip(2);
    } else {
      throw new ParsingException("Parameter list parse error");
    } 
    return parameterList;
  }
  
  private void parseBodyExtension(Response paramResponse) throws ParsingException {
    paramResponse.skipSpaces();
    byte b = paramResponse.peekByte();
    if (b == 40) {
      paramResponse.skip(1);
      do {
        parseBodyExtension(paramResponse);
      } while (paramResponse.readByte() != 41);
      return;
    } 
    if (Character.isDigit((char)b)) {
      paramResponse.readNumber();
      return;
    } 
    paramResponse.readString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\BODYSTRUCTURE.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */