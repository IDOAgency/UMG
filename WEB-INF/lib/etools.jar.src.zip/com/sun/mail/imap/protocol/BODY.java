package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ByteArray;
import com.sun.mail.iap.ParsingException;
import java.io.ByteArrayInputStream;

public class BODY implements Item {
  public static char[] name = { 'B', 'O', 'D', 'Y' };
  
  public int msgno;
  
  public ByteArray data;
  
  public String section;
  
  public int origin;
  
  public BODY(FetchResponse paramFetchResponse) throws ParsingException {
    this.msgno = paramFetchResponse.getNumber();
    paramFetchResponse.skipSpaces();
    do {
    
    } while (paramFetchResponse.readByte() != 93);
    if (paramFetchResponse.readByte() == 60) {
      this.origin = paramFetchResponse.readNumber();
      paramFetchResponse.skip(1);
    } 
    this.data = paramFetchResponse.readByteArray();
  }
  
  public ByteArray getByteArray() { return this.data; }
  
  public ByteArrayInputStream getByteArrayInputStream() {
    if (this.data != null)
      return this.data.toByteArrayInputStream(); 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\BODY.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */