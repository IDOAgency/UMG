/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ByteArray;
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ import java.io.ByteArrayInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BODY
/*    */   implements Item
/*    */ {
/* 23 */   public static char[] name = { 'B', 'O', 'D', 'Y' };
/*    */   
/*    */   public int msgno;
/*    */   
/*    */   public ByteArray data;
/*    */   
/*    */   public String section;
/*    */   
/*    */   public int origin;
/*    */   
/*    */   public BODY(FetchResponse paramFetchResponse) throws ParsingException {
/* 34 */     this.msgno = paramFetchResponse.getNumber();
/*    */     
/* 36 */     paramFetchResponse.skipSpaces(); do {
/*    */     
/* 38 */     } while (paramFetchResponse.readByte() != 93);
/*    */ 
/*    */     
/* 41 */     if (paramFetchResponse.readByte() == 60) {
/* 42 */       this.origin = paramFetchResponse.readNumber();
/* 43 */       paramFetchResponse.skip(1);
/*    */     } 
/*    */     
/* 46 */     this.data = paramFetchResponse.readByteArray();
/*    */   }
/*    */ 
/*    */   
/* 50 */   public ByteArray getByteArray() { return this.data; }
/*    */ 
/*    */   
/*    */   public ByteArrayInputStream getByteArrayInputStream() {
/* 54 */     if (this.data != null) {
/* 55 */       return this.data.toByteArrayInputStream();
/*    */     }
/* 57 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\BODY.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */