package com.sun.mail.imap.protocol;

import com.sun.mail.iap.Protocol;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import com.sun.mail.util.ASCIIUtility;
import java.io.IOException;
import java.util.Vector;

public class IMAPResponse extends Response {
  private String key;
  
  private int number;
  
  public IMAPResponse(Protocol paramProtocol) throws IOException, ProtocolException {
    super(paramProtocol);
    if (isUnTagged() && !isOK() && !isNO() && !isBAD() && !isBYE()) {
      this.key = readAtom();
      try {
        this.number = Integer.parseInt(this.key);
        this.key = readAtom();
        return;
      } catch (NumberFormatException numberFormatException) {
        return;
      } 
    } 
  }
  
  public IMAPResponse(IMAPResponse paramIMAPResponse) {
    super(paramIMAPResponse);
    this.key = paramIMAPResponse.key;
    this.number = paramIMAPResponse.number;
  }
  
  public String[] readSimpleList() {
    skipSpaces();
    if (this.buffer[this.index] != 40)
      return null; 
    this.index++;
    Vector vector = new Vector();
    int i;
    for (i = this.index; this.buffer[this.index] != 41; this.index++) {
      if (this.buffer[this.index] == 32) {
        vector.addElement(ASCIIUtility.toString(this.buffer, i, this.index));
        i = this.index + 1;
      } 
    } 
    if (this.index > i)
      vector.addElement(ASCIIUtility.toString(this.buffer, i, this.index)); 
    this.index++;
    int j = vector.size();
    if (j > 0) {
      String[] arrayOfString = new String[j];
      vector.copyInto(arrayOfString);
      return arrayOfString;
    } 
    return null;
  }
  
  public String getKey() { return this.key; }
  
  public boolean keyEquals(String paramString) {
    if (this.key != null && this.key.equalsIgnoreCase(paramString))
      return true; 
    return false;
  }
  
  public int getNumber() { return this.number; }
  
  public static IMAPResponse readResponse(Protocol paramProtocol) throws IOException, ProtocolException {
    IMAPResponse iMAPResponse = new IMAPResponse(paramProtocol);
    if (iMAPResponse.keyEquals("FETCH"))
      iMAPResponse = new FetchResponse(iMAPResponse); 
    return iMAPResponse;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\IMAPResponse.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */