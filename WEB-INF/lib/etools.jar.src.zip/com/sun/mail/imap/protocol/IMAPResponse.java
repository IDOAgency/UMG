/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import com.sun.mail.iap.Protocol;
/*     */ import com.sun.mail.iap.ProtocolException;
/*     */ import com.sun.mail.iap.Response;
/*     */ import com.sun.mail.util.ASCIIUtility;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IMAPResponse
/*     */   extends Response
/*     */ {
/*     */   private String key;
/*     */   private int number;
/*     */   
/*     */   public IMAPResponse(Protocol paramProtocol) throws IOException, ProtocolException {
/*  28 */     super(paramProtocol);
/*     */ 
/*     */     
/*  31 */     if (isUnTagged() && !isOK() && !isNO() && !isBAD() && !isBYE()) {
/*  32 */       this.key = readAtom();
/*     */ 
/*     */       
/*     */       try {
/*  36 */         this.number = Integer.parseInt(this.key);
/*  37 */         this.key = readAtom(); return;
/*  38 */       } catch (NumberFormatException numberFormatException) {
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public IMAPResponse(IMAPResponse paramIMAPResponse) {
/*  46 */     super(paramIMAPResponse);
/*  47 */     this.key = paramIMAPResponse.key;
/*  48 */     this.number = paramIMAPResponse.number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] readSimpleList() {
/*  58 */     skipSpaces();
/*     */     
/*  60 */     if (this.buffer[this.index] != 40)
/*  61 */       return null; 
/*  62 */     this.index++;
/*     */     
/*  64 */     Vector vector = new Vector();
/*     */     int i;
/*  66 */     for (i = this.index; this.buffer[this.index] != 41; this.index++) {
/*  67 */       if (this.buffer[this.index] == 32) {
/*  68 */         vector.addElement(ASCIIUtility.toString(this.buffer, i, this.index));
/*  69 */         i = this.index + 1;
/*     */       } 
/*     */     } 
/*  72 */     if (this.index > i)
/*  73 */       vector.addElement(ASCIIUtility.toString(this.buffer, i, this.index)); 
/*  74 */     this.index++;
/*     */     
/*  76 */     int j = vector.size();
/*  77 */     if (j > 0) {
/*  78 */       String[] arrayOfString = new String[j];
/*  79 */       vector.copyInto(arrayOfString);
/*  80 */       return arrayOfString;
/*     */     } 
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */   
/*  86 */   public String getKey() { return this.key; }
/*     */ 
/*     */   
/*     */   public boolean keyEquals(String paramString) {
/*  90 */     if (this.key != null && this.key.equalsIgnoreCase(paramString)) {
/*  91 */       return true;
/*     */     }
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   
/*  97 */   public int getNumber() { return this.number; }
/*     */ 
/*     */ 
/*     */   
/*     */   public static IMAPResponse readResponse(Protocol paramProtocol) throws IOException, ProtocolException {
/* 102 */     IMAPResponse iMAPResponse = new IMAPResponse(paramProtocol);
/* 103 */     if (iMAPResponse.keyEquals("FETCH"))
/* 104 */       iMAPResponse = new FetchResponse(iMAPResponse); 
/* 105 */     return iMAPResponse;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\IMAPResponse.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */