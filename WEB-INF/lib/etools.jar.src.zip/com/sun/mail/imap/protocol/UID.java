/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UID
/*    */   implements Item
/*    */ {
/* 21 */   public static final char[] name = { 'U', 'I', 'D' };
/*    */ 
/*    */   
/*    */   public int msgno;
/*    */   
/*    */   public long uid;
/*    */ 
/*    */   
/*    */   public UID(FetchResponse paramFetchResponse) throws ParsingException {
/* 30 */     this.msgno = paramFetchResponse.getNumber();
/* 31 */     paramFetchResponse.skipSpaces();
/* 32 */     this.uid = paramFetchResponse.readLong();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\UID.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */