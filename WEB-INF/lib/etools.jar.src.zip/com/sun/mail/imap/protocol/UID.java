package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;

public class UID implements Item {
  public static final char[] name = { 'U', 'I', 'D' };
  
  public int msgno;
  
  public long uid;
  
  public UID(FetchResponse paramFetchResponse) throws ParsingException {
    this.msgno = paramFetchResponse.getNumber();
    paramFetchResponse.skipSpaces();
    this.uid = paramFetchResponse.readLong();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\UID.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */