package com.sun.mail.imap.protocol;

import java.util.Vector;

public class MessageSet {
  public int start;
  
  public int end;
  
  public MessageSet() {}
  
  public MessageSet(int paramInt1, int paramInt2) {
    this.start = paramInt1;
    this.end = paramInt2;
  }
  
  public int size() { return this.end - this.start + 1; }
  
  public static MessageSet[] createMessageSets(int[] paramArrayOfInt) {
    Vector vector = new Vector();
    for (byte b = 0; b < paramArrayOfInt.length; b++) {
      MessageSet messageSet = new MessageSet();
      messageSet.start = paramArrayOfInt[b];
      byte b1;
      for (b1 = b + true; b1 < paramArrayOfInt.length && 
        paramArrayOfInt[b1] == paramArrayOfInt[b1 - true] + 1; b1++);
      messageSet.end = paramArrayOfInt[b1 - 1];
      vector.addElement(messageSet);
      b = b1 - 1;
    } 
    MessageSet[] arrayOfMessageSet = new MessageSet[vector.size()];
    vector.copyInto(arrayOfMessageSet);
    return arrayOfMessageSet;
  }
  
  public static String toString(MessageSet[] paramArrayOfMessageSet) {
    if (paramArrayOfMessageSet == null || paramArrayOfMessageSet.length == 0)
      return null; 
    byte b = 0;
    StringBuffer stringBuffer = new StringBuffer();
    int i = paramArrayOfMessageSet.length;
    while (true) {
      int j = (paramArrayOfMessageSet[b]).start;
      int k = (paramArrayOfMessageSet[b]).end;
      if (k > j) {
        stringBuffer.append(j).append(':').append(k);
      } else {
        stringBuffer.append(j);
      } 
      b++;
      if (b >= i)
        break; 
      stringBuffer.append(',');
    } 
    return stringBuffer.toString();
  }
  
  public static int size(MessageSet[] paramArrayOfMessageSet) {
    int i = 0;
    if (paramArrayOfMessageSet == null)
      return 0; 
    for (byte b = 0; b < paramArrayOfMessageSet.length; b++)
      i += paramArrayOfMessageSet[b].size(); 
    return i;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\MessageSet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */