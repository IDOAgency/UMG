/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageSet
/*     */ {
/*     */   public int start;
/*     */   public int end;
/*     */   
/*     */   public MessageSet() {}
/*     */   
/*     */   public MessageSet(int paramInt1, int paramInt2) {
/*  22 */     this.start = paramInt1;
/*  23 */     this.end = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  30 */   public int size() { return this.end - this.start + 1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MessageSet[] createMessageSets(int[] paramArrayOfInt) {
/*  37 */     Vector vector = new Vector();
/*     */ 
/*     */     
/*  40 */     for (byte b = 0; b < paramArrayOfInt.length; b++) {
/*  41 */       MessageSet messageSet = new MessageSet();
/*  42 */       messageSet.start = paramArrayOfInt[b];
/*     */       
/*     */       byte b1;
/*  45 */       for (b1 = b + true; b1 < paramArrayOfInt.length && 
/*  46 */         paramArrayOfInt[b1] == paramArrayOfInt[b1 - true] + 1; b1++);
/*     */ 
/*     */       
/*  49 */       messageSet.end = paramArrayOfInt[b1 - 1];
/*  50 */       vector.addElement(messageSet);
/*  51 */       b = b1 - 1;
/*     */     } 
/*  53 */     MessageSet[] arrayOfMessageSet = new MessageSet[vector.size()];
/*  54 */     vector.copyInto(arrayOfMessageSet);
/*  55 */     return arrayOfMessageSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(MessageSet[] paramArrayOfMessageSet) {
/*  62 */     if (paramArrayOfMessageSet == null || paramArrayOfMessageSet.length == 0) {
/*  63 */       return null;
/*     */     }
/*  65 */     byte b = 0;
/*  66 */     StringBuffer stringBuffer = new StringBuffer();
/*  67 */     int i = paramArrayOfMessageSet.length;
/*     */ 
/*     */     
/*     */     while (true) {
/*  71 */       int j = (paramArrayOfMessageSet[b]).start;
/*  72 */       int k = (paramArrayOfMessageSet[b]).end;
/*     */       
/*  74 */       if (k > j) {
/*  75 */         stringBuffer.append(j).append(':').append(k);
/*     */       } else {
/*  77 */         stringBuffer.append(j);
/*     */       } 
/*  79 */       b++;
/*  80 */       if (b >= i) {
/*     */         break;
/*     */       }
/*  83 */       stringBuffer.append(',');
/*     */     } 
/*  85 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int size(MessageSet[] paramArrayOfMessageSet) {
/*  93 */     int i = 0;
/*     */     
/*  95 */     if (paramArrayOfMessageSet == null) {
/*  96 */       return 0;
/*     */     }
/*  98 */     for (byte b = 0; b < paramArrayOfMessageSet.length; b++) {
/*  99 */       i += paramArrayOfMessageSet[b].size();
/*     */     }
/* 101 */     return i;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\MessageSet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */