/*      */ package com.sun.mail.imap.protocol;
/*      */ 
/*      */ import com.sun.mail.iap.Argument;
/*      */ import com.sun.mail.iap.BadCommandException;
/*      */ import com.sun.mail.iap.CommandFailedException;
/*      */ import com.sun.mail.iap.Protocol;
/*      */ import com.sun.mail.iap.ProtocolException;
/*      */ import com.sun.mail.iap.Response;
/*      */ import com.sun.mail.util.ASCIIUtility;
/*      */ import com.sun.mail.util.BASE64EncoderStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.util.Date;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.Vector;
/*      */ import javax.mail.Flags;
/*      */ import javax.mail.internet.MimeUtility;
/*      */ import javax.mail.search.SearchException;
/*      */ import javax.mail.search.SearchTerm;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class IMAPProtocol
/*      */   extends Protocol
/*      */ {
/*      */   private int state;
/*      */   private boolean rev1 = false;
/*      */   private Hashtable capabilities;
/*      */   private String[] searchCharsets;
/*      */   
/*      */   public IMAPProtocol(String paramString1, String paramString2, int paramInt, boolean paramBoolean, Properties paramProperties) throws IOException, ProtocolException {
/*   48 */     super(paramString2, paramInt, paramBoolean, paramProperties, "mail." + paramString1);
/*      */ 
/*      */     
/*   51 */     Response[] arrayOfResponse = command("CAPABILITY", null);
/*      */     
/*   53 */     if (!arrayOfResponse[arrayOfResponse.length - 1].isOK()) {
/*   54 */       throw new ProtocolException(arrayOfResponse[arrayOfResponse.length - 1].toString());
/*      */     }
/*   56 */     this.capabilities = new Hashtable(5); byte b; int i;
/*   57 */     for (b = 0, i = arrayOfResponse.length; b < i; b++) {
/*   58 */       if (arrayOfResponse[b] instanceof IMAPResponse) {
/*      */ 
/*      */         
/*   61 */         IMAPResponse iMAPResponse = (IMAPResponse)arrayOfResponse[b];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*   67 */         if (iMAPResponse.keyEquals("CAPABILITY")) {
/*      */           String str;
/*   69 */           while ((str = iMAPResponse.readAtom()) != null)
/*   70 */             this.capabilities.put(str.toLowerCase(), str); 
/*      */         } 
/*      */       } 
/*      */     } 
/*   74 */     if (hasCapability("IMAP4rev1")) {
/*   75 */       this.rev1 = true;
/*      */     }
/*   77 */     this.searchCharsets = new String[2];
/*   78 */     this.searchCharsets[0] = "UTF-8";
/*   79 */     this.searchCharsets[1] = MimeUtility.mimeCharset(
/*   80 */         MimeUtility.getDefaultJavaCharset());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   88 */   public boolean isREV1() { return this.rev1; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   95 */   public Response readResponse() throws IOException, ProtocolException { return IMAPResponse.readResponse(this); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  104 */   public boolean hasCapability(String paramString) { return this.capabilities.containsKey(paramString.toLowerCase()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  114 */   public void disconnect() { super.disconnect(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  123 */   public void noop() { simpleCommand("NOOP", null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logout() {
/*  132 */     Response[] arrayOfResponse = command("LOGOUT", null);
/*      */ 
/*      */ 
/*      */     
/*  136 */     notifyResponseHandlers(arrayOfResponse);
/*  137 */     disconnect();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void login(String paramString1, String paramString2) throws ProtocolException {
/*  146 */     Argument argument = new Argument();
/*  147 */     argument.writeString(paramString1);
/*  148 */     argument.writeString(paramString2);
/*      */     
/*  150 */     simpleCommand("LOGIN", argument);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void authlogin(String paramString1, String paramString2) throws ProtocolException {
/*  159 */     Vector vector = new Vector();
/*  160 */     String str = null;
/*  161 */     Response response = null;
/*  162 */     boolean bool1 = false;
/*      */     
/*      */     try {
/*  165 */       str = writeCommand("AUTHENTICATE LOGIN", null);
/*  166 */     } catch (Exception exception) {
/*      */       
/*  168 */       response = Response.ByeResponse;
/*  169 */       bool1 = true;
/*      */     } 
/*      */     
/*  172 */     OutputStream outputStream = getOutputStream();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  190 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*  191 */     BASE64EncoderStream bASE64EncoderStream = new BASE64EncoderStream(byteArrayOutputStream, 2147483647);
/*  192 */     byte[] arrayOfByte = { 13, 10 };
/*  193 */     boolean bool2 = true;
/*      */     
/*  195 */     while (!bool1) {
/*      */       try {
/*  197 */         response = readResponse();
/*  198 */         if (response.isContinuation()) {
/*      */           String str1;
/*      */           
/*  201 */           if (bool2) {
/*  202 */             str1 = paramString1;
/*  203 */             bool2 = false;
/*      */           } else {
/*  205 */             str1 = paramString2;
/*      */           } 
/*      */           
/*  208 */           bASE64EncoderStream.write(ASCIIUtility.getBytes(str1));
/*  209 */           bASE64EncoderStream.flush();
/*      */           
/*  211 */           byteArrayOutputStream.write(arrayOfByte);
/*  212 */           outputStream.write(byteArrayOutputStream.toByteArray());
/*  213 */           outputStream.flush();
/*  214 */           byteArrayOutputStream.reset(); continue;
/*  215 */         }  if (response.isTagged() && response.getTag().equals(str)) {
/*      */           
/*  217 */           bool1 = true; continue;
/*  218 */         }  if (response.isBYE()) {
/*  219 */           bool1 = true; continue;
/*      */         } 
/*  221 */         vector.addElement(response);
/*  222 */       } catch (Exception exception) {
/*      */         
/*  224 */         response = Response.ByeResponse;
/*  225 */         bool1 = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  235 */     Response[] arrayOfResponse = new Response[vector.size()];
/*  236 */     vector.copyInto(arrayOfResponse);
/*  237 */     notifyResponseHandlers(arrayOfResponse);
/*      */ 
/*      */     
/*  240 */     handleResult(response);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MailboxInfo select(String paramString) throws ProtocolException {
/*  250 */     paramString = BASE64MailboxEncoder.encode(paramString);
/*      */     
/*  252 */     Argument argument = new Argument();
/*  253 */     argument.writeString(paramString);
/*      */     
/*  255 */     Response[] arrayOfResponse = command("SELECT", argument);
/*      */ 
/*      */ 
/*      */     
/*  259 */     MailboxInfo mailboxInfo = new MailboxInfo(arrayOfResponse);
/*      */ 
/*      */     
/*  262 */     notifyResponseHandlers(arrayOfResponse);
/*      */     
/*  264 */     Response response = arrayOfResponse[arrayOfResponse.length - 1];
/*      */     
/*  266 */     if (response.isOK()) {
/*  267 */       if (response.toString().indexOf("READ-ONLY") != -1) {
/*  268 */         mailboxInfo.mode = 1;
/*      */       } else {
/*  270 */         mailboxInfo.mode = 2;
/*      */       } 
/*      */     }
/*  273 */     handleResult(response);
/*  274 */     return mailboxInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MailboxInfo examine(String paramString) throws ProtocolException {
/*  284 */     paramString = BASE64MailboxEncoder.encode(paramString);
/*      */     
/*  286 */     Argument argument = new Argument();
/*  287 */     argument.writeString(paramString);
/*      */     
/*  289 */     Response[] arrayOfResponse = command("EXAMINE", argument);
/*      */ 
/*      */ 
/*      */     
/*  293 */     MailboxInfo mailboxInfo = new MailboxInfo(arrayOfResponse);
/*  294 */     mailboxInfo.mode = 1;
/*      */ 
/*      */     
/*  297 */     notifyResponseHandlers(arrayOfResponse);
/*      */     
/*  299 */     handleResult(arrayOfResponse[arrayOfResponse.length - 1]);
/*  300 */     return mailboxInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Status status(String paramString, String[] paramArrayOfString) throws ProtocolException {
/*  310 */     if (!isREV1() && !hasCapability("IMAP4SUNVERSION"))
/*      */     {
/*      */       
/*  313 */       throw new BadCommandException("STATUS not supported");
/*      */     }
/*      */     
/*  316 */     paramString = BASE64MailboxEncoder.encode(paramString);
/*      */     
/*  318 */     Argument argument1 = new Argument();
/*  319 */     argument1.writeString(paramString);
/*      */     
/*  321 */     Argument argument2 = new Argument();
/*  322 */     if (paramArrayOfString == null)
/*  323 */       paramArrayOfString = Status.standardItems;  byte b;
/*      */     int i;
/*  325 */     for (b = 0, i = paramArrayOfString.length; b < i; b++)
/*  326 */       argument2.writeAtom(paramArrayOfString[b]); 
/*  327 */     argument1.writeArgument(argument2);
/*      */     
/*  329 */     Response[] arrayOfResponse = command("STATUS", argument1);
/*      */     
/*  331 */     Status status = null;
/*  332 */     Response response = arrayOfResponse[arrayOfResponse.length - 1];
/*      */ 
/*      */     
/*  335 */     if (response.isOK()) {
/*  336 */       byte b1; int j; for (b1 = 0, j = arrayOfResponse.length; b1 < j; b1++) {
/*  337 */         if (arrayOfResponse[b1] instanceof IMAPResponse) {
/*      */ 
/*      */           
/*  340 */           IMAPResponse iMAPResponse = (IMAPResponse)arrayOfResponse[b1];
/*  341 */           if (iMAPResponse.keyEquals("STATUS")) {
/*  342 */             if (status == null) {
/*  343 */               status = new Status(iMAPResponse);
/*      */             } else {
/*  345 */               Status.add(status, new Status(iMAPResponse));
/*  346 */             }  arrayOfResponse[b1] = null;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  352 */     notifyResponseHandlers(arrayOfResponse);
/*  353 */     handleResult(response);
/*  354 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void create(String paramString) throws ProtocolException {
/*  364 */     paramString = BASE64MailboxEncoder.encode(paramString);
/*      */     
/*  366 */     Argument argument = new Argument();
/*  367 */     argument.writeString(paramString);
/*      */     
/*  369 */     simpleCommand("CREATE", argument);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void delete(String paramString) throws ProtocolException {
/*  379 */     paramString = BASE64MailboxEncoder.encode(paramString);
/*      */     
/*  381 */     Argument argument = new Argument();
/*  382 */     argument.writeString(paramString);
/*      */     
/*  384 */     simpleCommand("DELETE", argument);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rename(String paramString1, String paramString2) throws ProtocolException {
/*  394 */     paramString1 = BASE64MailboxEncoder.encode(paramString1);
/*  395 */     paramString2 = BASE64MailboxEncoder.encode(paramString2);
/*      */     
/*  397 */     Argument argument = new Argument();
/*  398 */     argument.writeString(paramString1);
/*  399 */     argument.writeString(paramString2);
/*      */     
/*  401 */     simpleCommand("RENAME", argument);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void subscribe(String paramString) throws ProtocolException {
/*  410 */     Argument argument = new Argument();
/*      */     
/*  412 */     paramString = BASE64MailboxEncoder.encode(paramString);
/*  413 */     argument.writeString(paramString);
/*      */     
/*  415 */     simpleCommand("SUBSCRIBE", argument);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsubscribe(String paramString) throws ProtocolException {
/*  424 */     Argument argument = new Argument();
/*      */     
/*  426 */     paramString = BASE64MailboxEncoder.encode(paramString);
/*  427 */     argument.writeString(paramString);
/*      */     
/*  429 */     simpleCommand("UNSUBSCRIBE", argument);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  439 */   public ListInfo[] list(String paramString1, String paramString2) throws ProtocolException { return doList("LIST", paramString1, paramString2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  449 */   public ListInfo[] lsub(String paramString1, String paramString2) throws ProtocolException { return doList("LSUB", paramString1, paramString2); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ListInfo[] doList(String paramString1, String paramString2, String paramString3) throws ProtocolException {
/*  455 */     paramString2 = BASE64MailboxEncoder.encode(paramString2);
/*  456 */     paramString3 = BASE64MailboxEncoder.encode(paramString3);
/*      */     
/*  458 */     Argument argument = new Argument();
/*  459 */     argument.writeString(paramString2);
/*  460 */     argument.writeString(paramString3);
/*      */     
/*  462 */     Response[] arrayOfResponse = command(paramString1, argument);
/*      */     
/*  464 */     ListInfo[] arrayOfListInfo = null;
/*  465 */     Response response = arrayOfResponse[arrayOfResponse.length - 1];
/*      */     
/*  467 */     if (response.isOK()) {
/*  468 */       Vector vector = new Vector(1); byte b; int i;
/*  469 */       for (b = 0, i = arrayOfResponse.length; b < i; b++) {
/*  470 */         if (arrayOfResponse[b] instanceof IMAPResponse) {
/*      */ 
/*      */           
/*  473 */           IMAPResponse iMAPResponse = (IMAPResponse)arrayOfResponse[b];
/*  474 */           if (iMAPResponse.keyEquals(paramString1)) {
/*  475 */             vector.addElement(new ListInfo(iMAPResponse));
/*  476 */             arrayOfResponse[b] = null;
/*      */           } 
/*      */         } 
/*  479 */       }  if (vector.size() > 0) {
/*  480 */         arrayOfListInfo = new ListInfo[vector.size()];
/*  481 */         vector.copyInto(arrayOfListInfo);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  486 */     notifyResponseHandlers(arrayOfResponse);
/*  487 */     handleResult(response);
/*  488 */     return arrayOfListInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void append(String paramString, Date paramDate, ByteArrayOutputStream paramByteArrayOutputStream) throws ProtocolException {
/*  499 */     paramString = BASE64MailboxEncoder.encode(paramString);
/*      */     
/*  501 */     Argument argument = new Argument();
/*  502 */     argument.writeString(paramString);
/*      */     
/*  504 */     if (paramDate != null) {
/*  505 */       argument.writeString(INTERNALDATE.format(paramDate));
/*      */     }
/*  507 */     argument.writeBytes(paramByteArrayOutputStream);
/*      */     
/*  509 */     simpleCommand("APPEND", argument);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  518 */   public void check() { simpleCommand("CHECK", null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  527 */   public void close() { simpleCommand("CLOSE", null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  536 */   public void expunge() { simpleCommand("EXPUNGE", null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BODYSTRUCTURE fetchBodyStructure(int paramInt) throws ProtocolException {
/*  544 */     Response[] arrayOfResponse = fetch(paramInt, "BODYSTRUCTURE");
/*  545 */     notifyResponseHandlers(arrayOfResponse);
/*      */     
/*  547 */     Response response = arrayOfResponse[arrayOfResponse.length - 1];
/*  548 */     if (response.isOK()) {
/*  549 */       return (BODYSTRUCTURE)FetchResponse.getItem(arrayOfResponse, paramInt, BODYSTRUCTURE.class);
/*      */     }
/*  551 */     if (response.isNO()) {
/*  552 */       return null;
/*      */     }
/*  554 */     handleResult(response);
/*  555 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  561 */   public BODY peekBody(int paramInt, String paramString) throws ProtocolException { return fetchBody(paramInt, paramString, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  566 */   public BODY fetchBody(int paramInt, String paramString) throws ProtocolException { return fetchBody(paramInt, paramString, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BODY fetchBody(int paramInt, String paramString, boolean paramBoolean) throws ProtocolException {
/*      */     Response[] arrayOfResponse;
/*  573 */     if (paramBoolean) {
/*  574 */       arrayOfResponse = fetch(paramInt, 
/*  575 */           "BODY.PEEK[" + ((paramString == null) ? "]" : (String.valueOf(paramString) + "]")));
/*      */     } else {
/*  577 */       arrayOfResponse = fetch(paramInt, 
/*  578 */           "BODY[" + ((paramString == null) ? "]" : (String.valueOf(paramString) + "]")));
/*      */     } 
/*  580 */     notifyResponseHandlers(arrayOfResponse);
/*      */     
/*  582 */     Response response = arrayOfResponse[arrayOfResponse.length - 1];
/*  583 */     if (response.isOK())
/*  584 */       return (BODY)FetchResponse.getItem(arrayOfResponse, paramInt, BODY.class); 
/*  585 */     if (response.isNO()) {
/*  586 */       return null;
/*      */     }
/*  588 */     handleResult(response);
/*  589 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BODY fetchBody(int paramInt1, String paramString, int paramInt2, int paramInt3) throws ProtocolException {
/*  595 */     Response[] arrayOfResponse = fetch(
/*  596 */         paramInt1, 
/*  597 */         "BODY[" + ((paramString == null) ? "]<" : (String.valueOf(paramString) + "]<")) + 
/*  598 */         String.valueOf(paramInt2) + "." + 
/*  599 */         String.valueOf(paramInt3) + ">");
/*      */ 
/*      */     
/*  602 */     notifyResponseHandlers(arrayOfResponse);
/*      */     
/*  604 */     Response response = arrayOfResponse[arrayOfResponse.length - 1];
/*  605 */     if (response.isOK())
/*  606 */       return (BODY)FetchResponse.getItem(arrayOfResponse, paramInt1, BODY.class); 
/*  607 */     if (response.isNO()) {
/*  608 */       return null;
/*      */     }
/*  610 */     handleResult(response);
/*  611 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RFC822DATA fetchRFC822(int paramInt, String paramString) throws ProtocolException {
/*  622 */     Response[] arrayOfResponse = fetch(paramInt, 
/*  623 */         (paramString == null) ? "RFC822" : ("RFC822." + paramString));
/*      */ 
/*      */ 
/*      */     
/*  627 */     notifyResponseHandlers(arrayOfResponse);
/*      */     
/*  629 */     Response response = arrayOfResponse[arrayOfResponse.length - 1];
/*  630 */     if (response.isOK()) {
/*  631 */       return (RFC822DATA)FetchResponse.getItem(arrayOfResponse, paramInt, RFC822DATA.class);
/*      */     }
/*  633 */     if (response.isNO()) {
/*  634 */       return null;
/*      */     }
/*  636 */     handleResult(response);
/*  637 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flags fetchFlags(int paramInt) throws ProtocolException {
/*  645 */     Flags flags = null;
/*  646 */     Response[] arrayOfResponse = fetch(paramInt, "FLAGS");
/*      */     byte b;
/*      */     int i;
/*  649 */     for (b = 0, i = arrayOfResponse.length; b < i; b++) {
/*  650 */       if (arrayOfResponse[b] != null && 
/*  651 */         arrayOfResponse[b] instanceof FetchResponse && (
/*  652 */         (FetchResponse)arrayOfResponse[b]).getNumber() == paramInt) {
/*      */ 
/*      */         
/*  655 */         FetchResponse fetchResponse = (FetchResponse)arrayOfResponse[b];
/*  656 */         if ((flags = (Flags)fetchResponse.getItem(Flags.class)) != null) {
/*  657 */           arrayOfResponse[b] = null;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*  663 */     notifyResponseHandlers(arrayOfResponse);
/*  664 */     return flags;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UID fetchUID(int paramInt) throws ProtocolException {
/*  671 */     Response[] arrayOfResponse = fetch(paramInt, "UID");
/*      */ 
/*      */     
/*  674 */     notifyResponseHandlers(arrayOfResponse);
/*      */     
/*  676 */     Response response = arrayOfResponse[arrayOfResponse.length - 1];
/*  677 */     if (response.isOK())
/*  678 */       return (UID)FetchResponse.getItem(arrayOfResponse, paramInt, UID.class); 
/*  679 */     if (response.isNO()) {
/*  680 */       return null;
/*      */     }
/*  682 */     handleResult(response);
/*  683 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UID fetchSequenceNumber(long paramLong) throws ProtocolException {
/*  693 */     UID uID = null;
/*  694 */     Response[] arrayOfResponse = fetch(String.valueOf(paramLong), "UID", true); byte b;
/*      */     int i;
/*  696 */     for (b = 0, i = arrayOfResponse.length; b < i; b++) {
/*  697 */       if (arrayOfResponse[b] != null && arrayOfResponse[b] instanceof FetchResponse) {
/*      */ 
/*      */         
/*  700 */         FetchResponse fetchResponse = (FetchResponse)arrayOfResponse[b];
/*  701 */         if ((uID = (UID)fetchResponse.getItem(UID.class)) != null) {
/*  702 */           if (uID.uid == paramLong) {
/*      */             break;
/*      */           }
/*  705 */           uID = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*  709 */     notifyResponseHandlers(arrayOfResponse);
/*  710 */     handleResult(arrayOfResponse[arrayOfResponse.length - 1]);
/*  711 */     return uID;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UID[] fetchSequenceNumbers(long paramLong1, long paramLong2) throws ProtocolException {
/*  721 */     Response[] arrayOfResponse = fetch(String.valueOf(String.valueOf(paramLong1)) + ":" + (
/*  722 */         (paramLong2 == -1L) ? "*" : 
/*  723 */         String.valueOf(paramLong2)), 
/*  724 */         "UID", true);
/*      */ 
/*      */     
/*  727 */     Vector vector = new Vector(); byte b; int i;
/*  728 */     for (b = 0, i = arrayOfResponse.length; b < i; b++) {
/*  729 */       if (arrayOfResponse[b] != null && arrayOfResponse[b] instanceof FetchResponse) {
/*      */ 
/*      */         
/*  732 */         FetchResponse fetchResponse = (FetchResponse)arrayOfResponse[b]; UID uID;
/*  733 */         if ((uID = (UID)fetchResponse.getItem(UID.class)) != null)
/*  734 */           vector.addElement(uID); 
/*      */       } 
/*      */     } 
/*  737 */     notifyResponseHandlers(arrayOfResponse);
/*  738 */     handleResult(arrayOfResponse[arrayOfResponse.length - 1]);
/*      */     
/*  740 */     UID[] arrayOfUID = new UID[vector.size()];
/*  741 */     vector.copyInto(arrayOfUID);
/*  742 */     return arrayOfUID;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UID[] fetchSequenceNumbers(long[] paramArrayOfLong) throws ProtocolException {
/*  751 */     StringBuffer stringBuffer = new StringBuffer();
/*  752 */     for (byte b1 = 0; b1 < paramArrayOfLong.length; b1++) {
/*  753 */       if (b1)
/*  754 */         stringBuffer.append(","); 
/*  755 */       stringBuffer.append(String.valueOf(paramArrayOfLong[b1]));
/*      */     } 
/*      */     
/*  758 */     Response[] arrayOfResponse = fetch(stringBuffer.toString(), "UID", true);
/*      */ 
/*      */     
/*  761 */     Vector vector = new Vector(); byte b2; int i;
/*  762 */     for (b2 = 0, i = arrayOfResponse.length; b2 < i; b2++) {
/*  763 */       if (arrayOfResponse[b2] != null && arrayOfResponse[b2] instanceof FetchResponse) {
/*      */ 
/*      */         
/*  766 */         FetchResponse fetchResponse = (FetchResponse)arrayOfResponse[b2]; UID uID;
/*  767 */         if ((uID = (UID)fetchResponse.getItem(UID.class)) != null)
/*  768 */           vector.addElement(uID); 
/*      */       } 
/*      */     } 
/*  771 */     notifyResponseHandlers(arrayOfResponse);
/*  772 */     handleResult(arrayOfResponse[arrayOfResponse.length - 1]);
/*      */     
/*  774 */     UID[] arrayOfUID = new UID[vector.size()];
/*  775 */     vector.copyInto(arrayOfUID);
/*  776 */     return arrayOfUID;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  781 */   public Response[] fetch(MessageSet[] paramArrayOfMessageSet, String paramString) throws ProtocolException { return fetch(MessageSet.toString(paramArrayOfMessageSet), paramString, false); }
/*      */ 
/*      */ 
/*      */   
/*      */   public Response[] fetch(int paramInt1, int paramInt2, String paramString) throws ProtocolException {
/*  786 */     return fetch(String.valueOf(String.valueOf(paramInt1)) + ":" + String.valueOf(paramInt2), 
/*  787 */         paramString, false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  792 */   public Response[] fetch(int paramInt, String paramString) throws ProtocolException { return fetch(String.valueOf(paramInt), paramString, false); }
/*      */ 
/*      */ 
/*      */   
/*      */   private Response[] fetch(String paramString1, String paramString2, boolean paramBoolean) throws ProtocolException {
/*  797 */     if (paramBoolean) {
/*  798 */       return command("UID FETCH " + paramString1 + " (" + paramString2 + ")", null);
/*      */     }
/*  800 */     return command("FETCH " + paramString1 + " (" + paramString2 + ")", null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  805 */   public void copy(MessageSet[] paramArrayOfMessageSet, String paramString) throws ProtocolException { copy(MessageSet.toString(paramArrayOfMessageSet), paramString); }
/*      */ 
/*      */ 
/*      */   
/*      */   public void copy(int paramInt1, int paramInt2, String paramString) throws ProtocolException {
/*  810 */     copy(String.valueOf(String.valueOf(paramInt1)) + ":" + String.valueOf(paramInt2), 
/*  811 */         paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void copy(String paramString1, String paramString2) throws ProtocolException {
/*  817 */     paramString2 = BASE64MailboxEncoder.encode(paramString2);
/*      */     
/*  819 */     Argument argument = new Argument();
/*  820 */     argument.writeAtom(paramString1);
/*  821 */     argument.writeString(paramString2);
/*      */     
/*  823 */     simpleCommand("COPY", argument);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  828 */   public void storeFlags(MessageSet[] paramArrayOfMessageSet, Flags paramFlags, boolean paramBoolean) throws ProtocolException { storeFlags(MessageSet.toString(paramArrayOfMessageSet), paramFlags, paramBoolean); }
/*      */ 
/*      */ 
/*      */   
/*      */   public void storeFlags(int paramInt1, int paramInt2, Flags paramFlags, boolean paramBoolean) throws ProtocolException {
/*  833 */     storeFlags(String.valueOf(String.valueOf(paramInt1)) + ":" + String.valueOf(paramInt2), 
/*  834 */         paramFlags, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  842 */   public void storeFlags(int paramInt, Flags paramFlags, boolean paramBoolean) throws ProtocolException { storeFlags(String.valueOf(paramInt), paramFlags, paramBoolean); }
/*      */ 
/*      */   
/*      */   private void storeFlags(String paramString, Flags paramFlags, boolean paramBoolean) throws ProtocolException {
/*      */     Response[] arrayOfResponse;
/*  847 */     StringBuffer stringBuffer = new StringBuffer();
/*  848 */     Flags.Flag[] arrayOfFlag = paramFlags.getSystemFlags();
/*      */ 
/*      */     
/*  851 */     boolean bool = true;
/*  852 */     for (byte b1 = 0; b1 < arrayOfFlag.length; b1++) {
/*      */       String str;
/*  854 */       Flags.Flag flag = arrayOfFlag[b1];
/*  855 */       if (flag == Flags.Flag.ANSWERED) {
/*  856 */         str = "\\Answered";
/*  857 */       } else if (flag == Flags.Flag.DELETED) {
/*  858 */         str = "\\Deleted";
/*  859 */       } else if (flag == Flags.Flag.DRAFT) {
/*  860 */         str = "\\Draft";
/*  861 */       } else if (flag == Flags.Flag.FLAGGED) {
/*  862 */         str = "\\Flagged";
/*  863 */       } else if (flag == Flags.Flag.RECENT) {
/*  864 */         str = "\\Recent";
/*  865 */       } else if (flag == Flags.Flag.SEEN) {
/*  866 */         str = "\\Seen";
/*      */       } else {
/*      */         continue;
/*  869 */       }  if (bool) {
/*  870 */         bool = false;
/*      */       } else {
/*  872 */         stringBuffer.append(' ');
/*  873 */       }  stringBuffer.append(str);
/*      */       continue;
/*      */     } 
/*  876 */     String[] arrayOfString = paramFlags.getUserFlags();
/*  877 */     for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
/*  878 */       if (bool) {
/*  879 */         bool = false;
/*      */       } else {
/*  881 */         stringBuffer.append(' ');
/*  882 */       }  stringBuffer.append(arrayOfString[b2]);
/*      */     } 
/*      */ 
/*      */     
/*  886 */     if (paramBoolean) {
/*  887 */       arrayOfResponse = command("STORE " + paramString + " +FLAGS" + 
/*  888 */           " (" + stringBuffer.toString() + ")", null);
/*      */     } else {
/*  890 */       arrayOfResponse = command("STORE " + paramString + " -FLAGS" + 
/*  891 */           " (" + stringBuffer.toString() + ")", null);
/*      */     } 
/*      */     
/*  894 */     notifyResponseHandlers(arrayOfResponse);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  908 */   public int[] search(MessageSet[] paramArrayOfMessageSet, SearchTerm paramSearchTerm) throws ProtocolException, SearchException { return search(MessageSet.toString(paramArrayOfMessageSet), paramSearchTerm); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  921 */   public int[] search(SearchTerm paramSearchTerm) throws ProtocolException, SearchException { return search("ALL", paramSearchTerm); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] search(String paramString, SearchTerm paramSearchTerm) throws ProtocolException, SearchException {
/*  931 */     if (SearchSequence.isAscii(paramSearchTerm)) {
/*      */       try {
/*  933 */         return issueSearch(paramString, paramSearchTerm, null);
/*  934 */       } catch (IOException iOException) {}
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  945 */     for (byte b = 0; b < this.searchCharsets.length; b++) {
/*  946 */       if (this.searchCharsets[b] != null) {
/*      */         
/*      */         try {
/*      */           
/*  950 */           return issueSearch(paramString, paramSearchTerm, this.searchCharsets[b]);
/*  951 */         } catch (CommandFailedException commandFailedException) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  957 */           this.searchCharsets[b] = null;
/*      */         }
/*  959 */         catch (IOException iOException) {
/*      */ 
/*      */         
/*  962 */         } catch (ProtocolException protocolException) {
/*  963 */           throw protocolException;
/*  964 */         } catch (SearchException searchException) {
/*  965 */           throw searchException;
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  970 */     throw new SearchException("Search failed");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] issueSearch(String paramString1, SearchTerm paramSearchTerm, String paramString2) throws ProtocolException, SearchException, IOException {
/*      */     Response[] arrayOfResponse;
/*  983 */     Argument argument = SearchSequence.generateSequence(paramSearchTerm, 
/*  984 */         (paramString2 == null) ? null : 
/*  985 */         MimeUtility.javaCharset(paramString2));
/*      */     
/*  987 */     argument.writeAtom(paramString1);
/*      */ 
/*      */ 
/*      */     
/*  991 */     if (paramString2 == null) {
/*  992 */       arrayOfResponse = command("SEARCH", argument);
/*      */     } else {
/*  994 */       arrayOfResponse = command("SEARCH CHARSET " + paramString2, argument);
/*      */     } 
/*  996 */     Response response = arrayOfResponse[arrayOfResponse.length - 1];
/*  997 */     int[] arrayOfInt = null;
/*      */ 
/*      */     
/* 1000 */     if (response.isOK()) {
/* 1001 */       Vector vector = new Vector(); byte b1;
/*      */       int i;
/* 1003 */       for (b1 = 0, i = arrayOfResponse.length; b1 < i; b1++) {
/* 1004 */         if (arrayOfResponse[b1] instanceof IMAPResponse) {
/*      */ 
/*      */           
/* 1007 */           IMAPResponse iMAPResponse = (IMAPResponse)arrayOfResponse[b1];
/*      */           
/* 1009 */           if (iMAPResponse.keyEquals("SEARCH")) {
/* 1010 */             int k; while ((k = iMAPResponse.readNumber()) != -1)
/* 1011 */               vector.addElement(new Integer(k)); 
/* 1012 */             arrayOfResponse[b1] = null;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1017 */       int j = vector.size();
/* 1018 */       arrayOfInt = new int[j];
/* 1019 */       for (byte b2 = 0; b2 < j; b2++) {
/* 1020 */         arrayOfInt[b2] = ((Integer)vector.elementAt(b2)).intValue();
/*      */       }
/*      */     } 
/*      */     
/* 1024 */     notifyResponseHandlers(arrayOfResponse);
/* 1025 */     handleResult(response);
/* 1026 */     return arrayOfInt;
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\IMAPProtocol.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */