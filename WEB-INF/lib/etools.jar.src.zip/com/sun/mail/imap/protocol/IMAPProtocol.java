package com.sun.mail.imap.protocol;

import com.sun.mail.iap.Argument;
import com.sun.mail.iap.BadCommandException;
import com.sun.mail.iap.CommandFailedException;
import com.sun.mail.iap.Protocol;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.BASE64EncoderStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;
import javax.mail.Flags;
import javax.mail.internet.MimeUtility;
import javax.mail.search.SearchException;
import javax.mail.search.SearchTerm;

public class IMAPProtocol extends Protocol {
  private int state;
  
  private boolean rev1 = false;
  
  private Hashtable capabilities;
  
  private String[] searchCharsets;
  
  public IMAPProtocol(String paramString1, String paramString2, int paramInt, boolean paramBoolean, Properties paramProperties) throws IOException, ProtocolException {
    super(paramString2, paramInt, paramBoolean, paramProperties, "mail." + paramString1);
    Response[] arrayOfResponse = command("CAPABILITY", null);
    if (!arrayOfResponse[arrayOfResponse.length - 1].isOK())
      throw new ProtocolException(arrayOfResponse[arrayOfResponse.length - 1].toString()); 
    this.capabilities = new Hashtable(5);
    byte b;
    int i;
    for (b = 0, i = arrayOfResponse.length; b < i; b++) {
      if (arrayOfResponse[b] instanceof IMAPResponse) {
        IMAPResponse iMAPResponse = (IMAPResponse)arrayOfResponse[b];
        if (iMAPResponse.keyEquals("CAPABILITY")) {
          String str;
          while ((str = iMAPResponse.readAtom()) != null)
            this.capabilities.put(str.toLowerCase(), str); 
        } 
      } 
    } 
    if (hasCapability("IMAP4rev1"))
      this.rev1 = true; 
    this.searchCharsets = new String[2];
    this.searchCharsets[0] = "UTF-8";
    this.searchCharsets[1] = MimeUtility.mimeCharset(
        MimeUtility.getDefaultJavaCharset());
  }
  
  public boolean isREV1() { return this.rev1; }
  
  public Response readResponse() throws IOException, ProtocolException { return IMAPResponse.readResponse(this); }
  
  public boolean hasCapability(String paramString) { return this.capabilities.containsKey(paramString.toLowerCase()); }
  
  public void disconnect() { super.disconnect(); }
  
  public void noop() { simpleCommand("NOOP", null); }
  
  public void logout() {
    Response[] arrayOfResponse = command("LOGOUT", null);
    notifyResponseHandlers(arrayOfResponse);
    disconnect();
  }
  
  public void login(String paramString1, String paramString2) throws ProtocolException {
    Argument argument = new Argument();
    argument.writeString(paramString1);
    argument.writeString(paramString2);
    simpleCommand("LOGIN", argument);
  }
  
  public void authlogin(String paramString1, String paramString2) throws ProtocolException {
    Vector vector = new Vector();
    String str = null;
    Response response = null;
    boolean bool1 = false;
    try {
      str = writeCommand("AUTHENTICATE LOGIN", null);
    } catch (Exception exception) {
      response = Response.ByeResponse;
      bool1 = true;
    } 
    OutputStream outputStream = getOutputStream();
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    BASE64EncoderStream bASE64EncoderStream = new BASE64EncoderStream(byteArrayOutputStream, 2147483647);
    byte[] arrayOfByte = { 13, 10 };
    boolean bool2 = true;
    while (!bool1) {
      try {
        response = readResponse();
        if (response.isContinuation()) {
          String str1;
          if (bool2) {
            str1 = paramString1;
            bool2 = false;
          } else {
            str1 = paramString2;
          } 
          bASE64EncoderStream.write(ASCIIUtility.getBytes(str1));
          bASE64EncoderStream.flush();
          byteArrayOutputStream.write(arrayOfByte);
          outputStream.write(byteArrayOutputStream.toByteArray());
          outputStream.flush();
          byteArrayOutputStream.reset();
          continue;
        } 
        if (response.isTagged() && response.getTag().equals(str)) {
          bool1 = true;
          continue;
        } 
        if (response.isBYE()) {
          bool1 = true;
          continue;
        } 
        vector.addElement(response);
      } catch (Exception exception) {
        response = Response.ByeResponse;
        bool1 = true;
      } 
    } 
    Response[] arrayOfResponse = new Response[vector.size()];
    vector.copyInto(arrayOfResponse);
    notifyResponseHandlers(arrayOfResponse);
    handleResult(response);
  }
  
  public MailboxInfo select(String paramString) throws ProtocolException {
    paramString = BASE64MailboxEncoder.encode(paramString);
    Argument argument = new Argument();
    argument.writeString(paramString);
    Response[] arrayOfResponse = command("SELECT", argument);
    MailboxInfo mailboxInfo = new MailboxInfo(arrayOfResponse);
    notifyResponseHandlers(arrayOfResponse);
    Response response = arrayOfResponse[arrayOfResponse.length - 1];
    if (response.isOK())
      if (response.toString().indexOf("READ-ONLY") != -1) {
        mailboxInfo.mode = 1;
      } else {
        mailboxInfo.mode = 2;
      }  
    handleResult(response);
    return mailboxInfo;
  }
  
  public MailboxInfo examine(String paramString) throws ProtocolException {
    paramString = BASE64MailboxEncoder.encode(paramString);
    Argument argument = new Argument();
    argument.writeString(paramString);
    Response[] arrayOfResponse = command("EXAMINE", argument);
    MailboxInfo mailboxInfo = new MailboxInfo(arrayOfResponse);
    mailboxInfo.mode = 1;
    notifyResponseHandlers(arrayOfResponse);
    handleResult(arrayOfResponse[arrayOfResponse.length - 1]);
    return mailboxInfo;
  }
  
  public Status status(String paramString, String[] paramArrayOfString) throws ProtocolException {
    if (!isREV1() && !hasCapability("IMAP4SUNVERSION"))
      throw new BadCommandException("STATUS not supported"); 
    paramString = BASE64MailboxEncoder.encode(paramString);
    Argument argument1 = new Argument();
    argument1.writeString(paramString);
    Argument argument2 = new Argument();
    if (paramArrayOfString == null)
      paramArrayOfString = Status.standardItems; 
    byte b;
    int i;
    for (b = 0, i = paramArrayOfString.length; b < i; b++)
      argument2.writeAtom(paramArrayOfString[b]); 
    argument1.writeArgument(argument2);
    Response[] arrayOfResponse = command("STATUS", argument1);
    Status status = null;
    Response response = arrayOfResponse[arrayOfResponse.length - 1];
    if (response.isOK()) {
      byte b1;
      int j;
      for (b1 = 0, j = arrayOfResponse.length; b1 < j; b1++) {
        if (arrayOfResponse[b1] instanceof IMAPResponse) {
          IMAPResponse iMAPResponse = (IMAPResponse)arrayOfResponse[b1];
          if (iMAPResponse.keyEquals("STATUS")) {
            if (status == null) {
              status = new Status(iMAPResponse);
            } else {
              Status.add(status, new Status(iMAPResponse));
            } 
            arrayOfResponse[b1] = null;
          } 
        } 
      } 
    } 
    notifyResponseHandlers(arrayOfResponse);
    handleResult(response);
    return status;
  }
  
  public void create(String paramString) throws ProtocolException {
    paramString = BASE64MailboxEncoder.encode(paramString);
    Argument argument = new Argument();
    argument.writeString(paramString);
    simpleCommand("CREATE", argument);
  }
  
  public void delete(String paramString) throws ProtocolException {
    paramString = BASE64MailboxEncoder.encode(paramString);
    Argument argument = new Argument();
    argument.writeString(paramString);
    simpleCommand("DELETE", argument);
  }
  
  public void rename(String paramString1, String paramString2) throws ProtocolException {
    paramString1 = BASE64MailboxEncoder.encode(paramString1);
    paramString2 = BASE64MailboxEncoder.encode(paramString2);
    Argument argument = new Argument();
    argument.writeString(paramString1);
    argument.writeString(paramString2);
    simpleCommand("RENAME", argument);
  }
  
  public void subscribe(String paramString) throws ProtocolException {
    Argument argument = new Argument();
    paramString = BASE64MailboxEncoder.encode(paramString);
    argument.writeString(paramString);
    simpleCommand("SUBSCRIBE", argument);
  }
  
  public void unsubscribe(String paramString) throws ProtocolException {
    Argument argument = new Argument();
    paramString = BASE64MailboxEncoder.encode(paramString);
    argument.writeString(paramString);
    simpleCommand("UNSUBSCRIBE", argument);
  }
  
  public ListInfo[] list(String paramString1, String paramString2) throws ProtocolException { return doList("LIST", paramString1, paramString2); }
  
  public ListInfo[] lsub(String paramString1, String paramString2) throws ProtocolException { return doList("LSUB", paramString1, paramString2); }
  
  private ListInfo[] doList(String paramString1, String paramString2, String paramString3) throws ProtocolException {
    paramString2 = BASE64MailboxEncoder.encode(paramString2);
    paramString3 = BASE64MailboxEncoder.encode(paramString3);
    Argument argument = new Argument();
    argument.writeString(paramString2);
    argument.writeString(paramString3);
    Response[] arrayOfResponse = command(paramString1, argument);
    ListInfo[] arrayOfListInfo = null;
    Response response = arrayOfResponse[arrayOfResponse.length - 1];
    if (response.isOK()) {
      Vector vector = new Vector(1);
      byte b;
      int i;
      for (b = 0, i = arrayOfResponse.length; b < i; b++) {
        if (arrayOfResponse[b] instanceof IMAPResponse) {
          IMAPResponse iMAPResponse = (IMAPResponse)arrayOfResponse[b];
          if (iMAPResponse.keyEquals(paramString1)) {
            vector.addElement(new ListInfo(iMAPResponse));
            arrayOfResponse[b] = null;
          } 
        } 
      } 
      if (vector.size() > 0) {
        arrayOfListInfo = new ListInfo[vector.size()];
        vector.copyInto(arrayOfListInfo);
      } 
    } 
    notifyResponseHandlers(arrayOfResponse);
    handleResult(response);
    return arrayOfListInfo;
  }
  
  public void append(String paramString, Date paramDate, ByteArrayOutputStream paramByteArrayOutputStream) throws ProtocolException {
    paramString = BASE64MailboxEncoder.encode(paramString);
    Argument argument = new Argument();
    argument.writeString(paramString);
    if (paramDate != null)
      argument.writeString(INTERNALDATE.format(paramDate)); 
    argument.writeBytes(paramByteArrayOutputStream);
    simpleCommand("APPEND", argument);
  }
  
  public void check() { simpleCommand("CHECK", null); }
  
  public void close() { simpleCommand("CLOSE", null); }
  
  public void expunge() { simpleCommand("EXPUNGE", null); }
  
  public BODYSTRUCTURE fetchBodyStructure(int paramInt) throws ProtocolException {
    Response[] arrayOfResponse = fetch(paramInt, "BODYSTRUCTURE");
    notifyResponseHandlers(arrayOfResponse);
    Response response = arrayOfResponse[arrayOfResponse.length - 1];
    if (response.isOK())
      return (BODYSTRUCTURE)FetchResponse.getItem(arrayOfResponse, paramInt, BODYSTRUCTURE.class); 
    if (response.isNO())
      return null; 
    handleResult(response);
    return null;
  }
  
  public BODY peekBody(int paramInt, String paramString) throws ProtocolException { return fetchBody(paramInt, paramString, true); }
  
  public BODY fetchBody(int paramInt, String paramString) throws ProtocolException { return fetchBody(paramInt, paramString, false); }
  
  private BODY fetchBody(int paramInt, String paramString, boolean paramBoolean) throws ProtocolException {
    Response[] arrayOfResponse;
    if (paramBoolean) {
      arrayOfResponse = fetch(paramInt, 
          "BODY.PEEK[" + ((paramString == null) ? "]" : (String.valueOf(paramString) + "]")));
    } else {
      arrayOfResponse = fetch(paramInt, 
          "BODY[" + ((paramString == null) ? "]" : (String.valueOf(paramString) + "]")));
    } 
    notifyResponseHandlers(arrayOfResponse);
    Response response = arrayOfResponse[arrayOfResponse.length - 1];
    if (response.isOK())
      return (BODY)FetchResponse.getItem(arrayOfResponse, paramInt, BODY.class); 
    if (response.isNO())
      return null; 
    handleResult(response);
    return null;
  }
  
  public BODY fetchBody(int paramInt1, String paramString, int paramInt2, int paramInt3) throws ProtocolException {
    Response[] arrayOfResponse = fetch(
        paramInt1, 
        "BODY[" + ((paramString == null) ? "]<" : (String.valueOf(paramString) + "]<")) + 
        String.valueOf(paramInt2) + "." + 
        String.valueOf(paramInt3) + ">");
    notifyResponseHandlers(arrayOfResponse);
    Response response = arrayOfResponse[arrayOfResponse.length - 1];
    if (response.isOK())
      return (BODY)FetchResponse.getItem(arrayOfResponse, paramInt1, BODY.class); 
    if (response.isNO())
      return null; 
    handleResult(response);
    return null;
  }
  
  public RFC822DATA fetchRFC822(int paramInt, String paramString) throws ProtocolException {
    Response[] arrayOfResponse = fetch(paramInt, 
        (paramString == null) ? "RFC822" : ("RFC822." + paramString));
    notifyResponseHandlers(arrayOfResponse);
    Response response = arrayOfResponse[arrayOfResponse.length - 1];
    if (response.isOK())
      return (RFC822DATA)FetchResponse.getItem(arrayOfResponse, paramInt, RFC822DATA.class); 
    if (response.isNO())
      return null; 
    handleResult(response);
    return null;
  }
  
  public Flags fetchFlags(int paramInt) throws ProtocolException {
    Flags flags = null;
    Response[] arrayOfResponse = fetch(paramInt, "FLAGS");
    byte b;
    int i;
    for (b = 0, i = arrayOfResponse.length; b < i; b++) {
      if (arrayOfResponse[b] != null && 
        arrayOfResponse[b] instanceof FetchResponse && (
        (FetchResponse)arrayOfResponse[b]).getNumber() == paramInt) {
        FetchResponse fetchResponse = (FetchResponse)arrayOfResponse[b];
        if ((flags = (Flags)fetchResponse.getItem(Flags.class)) != null) {
          arrayOfResponse[b] = null;
          break;
        } 
      } 
    } 
    notifyResponseHandlers(arrayOfResponse);
    return flags;
  }
  
  public UID fetchUID(int paramInt) throws ProtocolException {
    Response[] arrayOfResponse = fetch(paramInt, "UID");
    notifyResponseHandlers(arrayOfResponse);
    Response response = arrayOfResponse[arrayOfResponse.length - 1];
    if (response.isOK())
      return (UID)FetchResponse.getItem(arrayOfResponse, paramInt, UID.class); 
    if (response.isNO())
      return null; 
    handleResult(response);
    return null;
  }
  
  public UID fetchSequenceNumber(long paramLong) throws ProtocolException {
    UID uID = null;
    Response[] arrayOfResponse = fetch(String.valueOf(paramLong), "UID", true);
    byte b;
    int i;
    for (b = 0, i = arrayOfResponse.length; b < i; b++) {
      if (arrayOfResponse[b] != null && arrayOfResponse[b] instanceof FetchResponse) {
        FetchResponse fetchResponse = (FetchResponse)arrayOfResponse[b];
        if ((uID = (UID)fetchResponse.getItem(UID.class)) != null) {
          if (uID.uid == paramLong)
            break; 
          uID = null;
        } 
      } 
    } 
    notifyResponseHandlers(arrayOfResponse);
    handleResult(arrayOfResponse[arrayOfResponse.length - 1]);
    return uID;
  }
  
  public UID[] fetchSequenceNumbers(long paramLong1, long paramLong2) throws ProtocolException {
    Response[] arrayOfResponse = fetch(String.valueOf(String.valueOf(paramLong1)) + ":" + (
        (paramLong2 == -1L) ? "*" : 
        String.valueOf(paramLong2)), 
        "UID", true);
    Vector vector = new Vector();
    byte b;
    int i;
    for (b = 0, i = arrayOfResponse.length; b < i; b++) {
      if (arrayOfResponse[b] != null && arrayOfResponse[b] instanceof FetchResponse) {
        FetchResponse fetchResponse = (FetchResponse)arrayOfResponse[b];
        UID uID;
        if ((uID = (UID)fetchResponse.getItem(UID.class)) != null)
          vector.addElement(uID); 
      } 
    } 
    notifyResponseHandlers(arrayOfResponse);
    handleResult(arrayOfResponse[arrayOfResponse.length - 1]);
    UID[] arrayOfUID = new UID[vector.size()];
    vector.copyInto(arrayOfUID);
    return arrayOfUID;
  }
  
  public UID[] fetchSequenceNumbers(long[] paramArrayOfLong) throws ProtocolException {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b1 = 0; b1 < paramArrayOfLong.length; b1++) {
      if (b1)
        stringBuffer.append(","); 
      stringBuffer.append(String.valueOf(paramArrayOfLong[b1]));
    } 
    Response[] arrayOfResponse = fetch(stringBuffer.toString(), "UID", true);
    Vector vector = new Vector();
    byte b2;
    int i;
    for (b2 = 0, i = arrayOfResponse.length; b2 < i; b2++) {
      if (arrayOfResponse[b2] != null && arrayOfResponse[b2] instanceof FetchResponse) {
        FetchResponse fetchResponse = (FetchResponse)arrayOfResponse[b2];
        UID uID;
        if ((uID = (UID)fetchResponse.getItem(UID.class)) != null)
          vector.addElement(uID); 
      } 
    } 
    notifyResponseHandlers(arrayOfResponse);
    handleResult(arrayOfResponse[arrayOfResponse.length - 1]);
    UID[] arrayOfUID = new UID[vector.size()];
    vector.copyInto(arrayOfUID);
    return arrayOfUID;
  }
  
  public Response[] fetch(MessageSet[] paramArrayOfMessageSet, String paramString) throws ProtocolException { return fetch(MessageSet.toString(paramArrayOfMessageSet), paramString, false); }
  
  public Response[] fetch(int paramInt1, int paramInt2, String paramString) throws ProtocolException {
    return fetch(String.valueOf(String.valueOf(paramInt1)) + ":" + String.valueOf(paramInt2), 
        paramString, false);
  }
  
  public Response[] fetch(int paramInt, String paramString) throws ProtocolException { return fetch(String.valueOf(paramInt), paramString, false); }
  
  private Response[] fetch(String paramString1, String paramString2, boolean paramBoolean) throws ProtocolException {
    if (paramBoolean)
      return command("UID FETCH " + paramString1 + " (" + paramString2 + ")", null); 
    return command("FETCH " + paramString1 + " (" + paramString2 + ")", null);
  }
  
  public void copy(MessageSet[] paramArrayOfMessageSet, String paramString) throws ProtocolException { copy(MessageSet.toString(paramArrayOfMessageSet), paramString); }
  
  public void copy(int paramInt1, int paramInt2, String paramString) throws ProtocolException {
    copy(String.valueOf(String.valueOf(paramInt1)) + ":" + String.valueOf(paramInt2), 
        paramString);
  }
  
  private void copy(String paramString1, String paramString2) throws ProtocolException {
    paramString2 = BASE64MailboxEncoder.encode(paramString2);
    Argument argument = new Argument();
    argument.writeAtom(paramString1);
    argument.writeString(paramString2);
    simpleCommand("COPY", argument);
  }
  
  public void storeFlags(MessageSet[] paramArrayOfMessageSet, Flags paramFlags, boolean paramBoolean) throws ProtocolException { storeFlags(MessageSet.toString(paramArrayOfMessageSet), paramFlags, paramBoolean); }
  
  public void storeFlags(int paramInt1, int paramInt2, Flags paramFlags, boolean paramBoolean) throws ProtocolException {
    storeFlags(String.valueOf(String.valueOf(paramInt1)) + ":" + String.valueOf(paramInt2), 
        paramFlags, paramBoolean);
  }
  
  public void storeFlags(int paramInt, Flags paramFlags, boolean paramBoolean) throws ProtocolException { storeFlags(String.valueOf(paramInt), paramFlags, paramBoolean); }
  
  private void storeFlags(String paramString, Flags paramFlags, boolean paramBoolean) throws ProtocolException {
    Response[] arrayOfResponse;
    StringBuffer stringBuffer = new StringBuffer();
    Flags.Flag[] arrayOfFlag = paramFlags.getSystemFlags();
    boolean bool = true;
    for (byte b1 = 0; b1 < arrayOfFlag.length; b1++) {
      String str;
      Flags.Flag flag = arrayOfFlag[b1];
      if (flag == Flags.Flag.ANSWERED) {
        str = "\\Answered";
      } else if (flag == Flags.Flag.DELETED) {
        str = "\\Deleted";
      } else if (flag == Flags.Flag.DRAFT) {
        str = "\\Draft";
      } else if (flag == Flags.Flag.FLAGGED) {
        str = "\\Flagged";
      } else if (flag == Flags.Flag.RECENT) {
        str = "\\Recent";
      } else if (flag == Flags.Flag.SEEN) {
        str = "\\Seen";
      } else {
        continue;
      } 
      if (bool) {
        bool = false;
      } else {
        stringBuffer.append(' ');
      } 
      stringBuffer.append(str);
      continue;
    } 
    String[] arrayOfString = paramFlags.getUserFlags();
    for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
      if (bool) {
        bool = false;
      } else {
        stringBuffer.append(' ');
      } 
      stringBuffer.append(arrayOfString[b2]);
    } 
    if (paramBoolean) {
      arrayOfResponse = command("STORE " + paramString + " +FLAGS" + 
          " (" + stringBuffer.toString() + ")", null);
    } else {
      arrayOfResponse = command("STORE " + paramString + " -FLAGS" + 
          " (" + stringBuffer.toString() + ")", null);
    } 
    notifyResponseHandlers(arrayOfResponse);
  }
  
  public int[] search(MessageSet[] paramArrayOfMessageSet, SearchTerm paramSearchTerm) throws ProtocolException, SearchException { return search(MessageSet.toString(paramArrayOfMessageSet), paramSearchTerm); }
  
  public int[] search(SearchTerm paramSearchTerm) throws ProtocolException, SearchException { return search("ALL", paramSearchTerm); }
  
  private int[] search(String paramString, SearchTerm paramSearchTerm) throws ProtocolException, SearchException {
    if (SearchSequence.isAscii(paramSearchTerm))
      try {
        return issueSearch(paramString, paramSearchTerm, null);
      } catch (IOException iOException) {} 
    for (byte b = 0; b < this.searchCharsets.length; b++) {
      if (this.searchCharsets[b] != null)
        try {
          return issueSearch(paramString, paramSearchTerm, this.searchCharsets[b]);
        } catch (CommandFailedException commandFailedException) {
          this.searchCharsets[b] = null;
        } catch (IOException iOException) {
        
        } catch (ProtocolException protocolException) {
          throw protocolException;
        } catch (SearchException searchException) {
          throw searchException;
        }  
    } 
    throw new SearchException("Search failed");
  }
  
  private int[] issueSearch(String paramString1, SearchTerm paramSearchTerm, String paramString2) throws ProtocolException, SearchException, IOException {
    Response[] arrayOfResponse;
    Argument argument = SearchSequence.generateSequence(paramSearchTerm, 
        (paramString2 == null) ? null : 
        MimeUtility.javaCharset(paramString2));
    argument.writeAtom(paramString1);
    if (paramString2 == null) {
      arrayOfResponse = command("SEARCH", argument);
    } else {
      arrayOfResponse = command("SEARCH CHARSET " + paramString2, argument);
    } 
    Response response = arrayOfResponse[arrayOfResponse.length - 1];
    int[] arrayOfInt = null;
    if (response.isOK()) {
      Vector vector = new Vector();
      byte b1;
      int i;
      for (b1 = 0, i = arrayOfResponse.length; b1 < i; b1++) {
        if (arrayOfResponse[b1] instanceof IMAPResponse) {
          IMAPResponse iMAPResponse = (IMAPResponse)arrayOfResponse[b1];
          if (iMAPResponse.keyEquals("SEARCH")) {
            int k;
            while ((k = iMAPResponse.readNumber()) != -1)
              vector.addElement(new Integer(k)); 
            arrayOfResponse[b1] = null;
          } 
        } 
      } 
      int j = vector.size();
      arrayOfInt = new int[j];
      for (byte b2 = 0; b2 < j; b2++)
        arrayOfInt[b2] = ((Integer)vector.elementAt(b2)).intValue(); 
    } 
    notifyResponseHandlers(arrayOfResponse);
    handleResult(response);
    return arrayOfInt;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\IMAPProtocol.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */