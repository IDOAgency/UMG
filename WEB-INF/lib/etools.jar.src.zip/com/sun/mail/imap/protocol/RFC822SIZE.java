/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RFC822SIZE
/*    */   implements Item
/*    */ {
/*    */   public static char[] name = { 
/* 21 */       'R', 'F', 'C', '8', '2', '2', '.', 'S', 'I', 'Z', 'E' };
/*    */ 
/*    */   
/*    */   public int msgno;
/*    */ 
/*    */   
/*    */   public int size;
/*    */ 
/*    */   
/*    */   public RFC822SIZE(FetchResponse paramFetchResponse) throws ParsingException {
/* 31 */     this.msgno = paramFetchResponse.getNumber();
/* 32 */     paramFetchResponse.skipSpaces();
/* 33 */     this.size = paramFetchResponse.readNumber();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\RFC822SIZE.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */