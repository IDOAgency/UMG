/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ import javax.mail.Flags;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FLAGS
/*    */   extends Flags
/*    */   implements Item
/*    */ {
/* 23 */   public static char[] name = { 'F', 'L', 'A', 'G', 'S' };
/*    */ 
/*    */   
/*    */   public int msgno;
/*    */ 
/*    */   
/*    */   public FLAGS(IMAPResponse paramIMAPResponse) throws ParsingException {
/* 30 */     this.msgno = paramIMAPResponse.getNumber();
/*    */     
/* 32 */     paramIMAPResponse.skipSpaces();
/* 33 */     String[] arrayOfString = paramIMAPResponse.readSimpleList();
/* 34 */     if (arrayOfString != null)
/* 35 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 36 */         String str = arrayOfString[b];
/* 37 */         if (str.length() >= 2 && str.charAt(0) == '\\') {
/* 38 */           switch (Character.toUpperCase(str.charAt(1))) {
/*    */             case 'S':
/* 40 */               add(Flags.Flag.SEEN);
/*    */               break;
/*    */             case 'R':
/* 43 */               add(Flags.Flag.RECENT);
/*    */               break;
/*    */             case 'D':
/* 46 */               if (str.length() >= 3) {
/* 47 */                 char c = str.charAt(2);
/* 48 */                 if (c == 'e' || c == 'E') {
/* 49 */                   add(Flags.Flag.DELETED); break;
/* 50 */                 }  if (c == 'r' || c == 'R')
/* 51 */                   add(Flags.Flag.DRAFT);  break;
/*    */               } 
/* 53 */               add(str);
/*    */               break;
/*    */             case 'A':
/* 56 */               add(Flags.Flag.ANSWERED);
/*    */               break;
/*    */             case 'F':
/* 59 */               add(Flags.Flag.FLAGGED);
/*    */               break;
/*    */             case '*':
/* 62 */               add(Flags.Flag.USER);
/*    */               break;
/*    */             default:
/* 65 */               add(str);
/*    */               break;
/*    */           } 
/*    */         } else {
/* 69 */           add(str);
/*    */         } 
/*    */       }  
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\FLAGS.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */