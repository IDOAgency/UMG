/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ import com.sun.mail.iap.Response;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Status
/*    */ {
/*    */   public String mbox;
/*    */   public int total;
/*    */   public int recent;
/*    */   public long uidnext;
/*    */   public long uidvalidity;
/*    */   public int unseen;
/* 28 */   public static String[] standardItems = { "MESSAGES", "RECENT", "UNSEEN", "UIDNEXT", "UIDVALIDITY" }; public Status(Response paramResponse) throws ParsingException { this.total = -1; this.recent = -1; this.uidnext = -1L;
/*    */     this.uidvalidity = -1L;
/*    */     this.unseen = -1;
/* 31 */     this.mbox = paramResponse.readAtomString();
/* 32 */     paramResponse.skipSpaces();
/* 33 */     if (paramResponse.readByte() != 40) {
/* 34 */       throw new ParsingException("parse error in STATUS");
/*    */     }
/*    */     do {
/* 37 */       String str = paramResponse.readAtom();
/* 38 */       if (str.equalsIgnoreCase("MESSAGES"))
/* 39 */       { this.total = paramResponse.readNumber(); }
/* 40 */       else if (str.equalsIgnoreCase("RECENT"))
/* 41 */       { this.recent = paramResponse.readNumber(); }
/* 42 */       else if (str.equalsIgnoreCase("UIDNEXT"))
/* 43 */       { this.uidnext = paramResponse.readLong(); }
/* 44 */       else if (str.equalsIgnoreCase("UIDVALIDITY"))
/* 45 */       { this.uidvalidity = paramResponse.readLong(); }
/* 46 */       else if (str.equalsIgnoreCase("UNSEEN"))
/* 47 */       { this.unseen = paramResponse.readNumber(); } 
/* 48 */     } while (paramResponse.readByte() != 41); }
/*    */ 
/*    */   
/*    */   public static void add(Status paramStatus1, Status paramStatus2) {
/* 52 */     if (paramStatus2.total != -1)
/* 53 */       paramStatus1.total = paramStatus2.total; 
/* 54 */     if (paramStatus2.recent != -1)
/* 55 */       paramStatus1.recent = paramStatus2.recent; 
/* 56 */     if (paramStatus2.uidnext != -1L)
/* 57 */       paramStatus1.uidnext = paramStatus2.uidnext; 
/* 58 */     if (paramStatus2.uidvalidity != -1L)
/* 59 */       paramStatus1.uidvalidity = paramStatus2.uidvalidity; 
/* 60 */     if (paramStatus2.unseen != -1)
/* 61 */       paramStatus1.unseen = paramStatus2.unseen; 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\Status.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */