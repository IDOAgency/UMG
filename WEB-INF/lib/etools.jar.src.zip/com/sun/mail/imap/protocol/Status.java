package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;
import com.sun.mail.iap.Response;

public class Status {
  public String mbox;
  
  public int total;
  
  public int recent;
  
  public long uidnext;
  
  public long uidvalidity;
  
  public int unseen;
  
  public static String[] standardItems = { "MESSAGES", "RECENT", "UNSEEN", "UIDNEXT", "UIDVALIDITY" };
  
  public Status(Response paramResponse) throws ParsingException {
    this.total = -1;
    this.recent = -1;
    this.uidnext = -1L;
    this.uidvalidity = -1L;
    this.unseen = -1;
    this.mbox = paramResponse.readAtomString();
    paramResponse.skipSpaces();
    if (paramResponse.readByte() != 40)
      throw new ParsingException("parse error in STATUS"); 
    do {
      String str = paramResponse.readAtom();
      if (str.equalsIgnoreCase("MESSAGES")) {
        this.total = paramResponse.readNumber();
      } else if (str.equalsIgnoreCase("RECENT")) {
        this.recent = paramResponse.readNumber();
      } else if (str.equalsIgnoreCase("UIDNEXT")) {
        this.uidnext = paramResponse.readLong();
      } else if (str.equalsIgnoreCase("UIDVALIDITY")) {
        this.uidvalidity = paramResponse.readLong();
      } else if (str.equalsIgnoreCase("UNSEEN")) {
        this.unseen = paramResponse.readNumber();
      } 
    } while (paramResponse.readByte() != 41);
  }
  
  public static void add(Status paramStatus1, Status paramStatus2) {
    if (paramStatus2.total != -1)
      paramStatus1.total = paramStatus2.total; 
    if (paramStatus2.recent != -1)
      paramStatus1.recent = paramStatus2.recent; 
    if (paramStatus2.uidnext != -1L)
      paramStatus1.uidnext = paramStatus2.uidnext; 
    if (paramStatus2.uidvalidity != -1L)
      paramStatus1.uidvalidity = paramStatus2.uidvalidity; 
    if (paramStatus2.unseen != -1)
      paramStatus1.unseen = paramStatus2.unseen; 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\Status.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */