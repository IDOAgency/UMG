package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;
import com.sun.mail.iap.Protocol;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import java.io.IOException;
import java.util.Vector;

public class FetchResponse extends IMAPResponse {
  private Item[] items;
  
  public FetchResponse(Protocol paramProtocol) throws IOException, ProtocolException {
    super(paramProtocol);
    parse();
  }
  
  public FetchResponse(IMAPResponse paramIMAPResponse) throws IOException, ProtocolException {
    super(paramIMAPResponse);
    parse();
  }
  
  public int getItemCount() { return this.items.length; }
  
  public Item getItem(int paramInt) { return this.items[paramInt]; }
  
  public Item getItem(Class paramClass) {
    for (byte b = 0; b < this.items.length; b++) {
      if (paramClass.isInstance(this.items[b]))
        return this.items[b]; 
    } 
    return null;
  }
  
  public static Item getItem(Response[] paramArrayOfResponse, int paramInt, Class paramClass) {
    if (paramArrayOfResponse == null)
      return null; 
    for (byte b = 0; b < paramArrayOfResponse.length; b++) {
      if (paramArrayOfResponse[b] != null && 
        paramArrayOfResponse[b] instanceof FetchResponse && (
        (FetchResponse)paramArrayOfResponse[b]).getNumber() == paramInt) {
        FetchResponse fetchResponse = (FetchResponse)paramArrayOfResponse[b];
        for (byte b1 = 0; b1 < fetchResponse.items.length; b1++) {
          if (paramClass.isInstance(fetchResponse.items[b1]))
            return fetchResponse.items[b1]; 
        } 
      } 
    } 
    return null;
  }
  
  private static final char[] HEADER = { '.', 'H', 'E', 'A', 'D', 'E', 'R' };
  
  private static final char[] TEXT = { '.', 'T', 'E', 'X', 'T' };
  
  private void parse() throws ParsingException {
    skipSpaces();
    if (this.buffer[this.index] != 40)
      throw new ParsingException("error in FETCH parsing"); 
    Vector vector = new Vector();
    ENVELOPE eNVELOPE = null;
    do {
      UID uID;
      this.index++;
      switch (this.buffer[this.index]) {
        case 69:
          if (match(ENVELOPE.name)) {
            this.index += ENVELOPE.name.length;
            eNVELOPE = new ENVELOPE(this);
          } 
          break;
        case 70:
          if (match(FLAGS.name)) {
            this.index += FLAGS.name.length;
            uID = new FLAGS(this);
          } 
          break;
        case 73:
          if (match(INTERNALDATE.name)) {
            this.index += INTERNALDATE.name.length;
            uID = new INTERNALDATE(this);
          } 
          break;
        case 66:
          if (match(BODY.name)) {
            if (this.buffer[this.index + 4] == 91) {
              this.index += BODY.name.length;
              BODY bODY = new BODY(this);
              break;
            } 
            if (match(BODYSTRUCTURE.name)) {
              this.index += BODYSTRUCTURE.name.length;
            } else {
              this.index += BODY.name.length;
            } 
            uID = new BODYSTRUCTURE(this);
          } 
          break;
        case 82:
          if (match(RFC822SIZE.name)) {
            this.index += RFC822SIZE.name.length;
            uID = new RFC822SIZE(this);
            break;
          } 
          if (match(RFC822DATA.name)) {
            this.index += RFC822DATA.name.length;
            if (match(HEADER)) {
              this.index += HEADER.length;
            } else if (match(TEXT)) {
              this.index += TEXT.length;
            } 
            uID = new RFC822DATA(this);
          } 
          break;
        case 85:
          if (match(UID.name)) {
            this.index += UID.name.length;
            uID = new UID(this);
          } 
          break;
      } 
      if (uID == null)
        continue; 
      vector.addElement(uID);
    } while (this.buffer[this.index] != 41);
    this.index++;
    this.items = new Item[vector.size()];
    vector.copyInto(this.items);
  }
  
  private boolean match(char[] paramArrayOfChar) {
    int i = paramArrayOfChar.length;
    byte b;
    int j;
    for (b = 0, j = this.index; b < i;) {
      if (Character.toUpperCase((char)this.buffer[j++]) != paramArrayOfChar[b++])
        return false; 
    } 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\FetchResponse.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */