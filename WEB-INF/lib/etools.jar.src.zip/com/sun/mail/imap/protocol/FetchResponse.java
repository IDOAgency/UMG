/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import com.sun.mail.iap.ParsingException;
/*     */ import com.sun.mail.iap.Protocol;
/*     */ import com.sun.mail.iap.ProtocolException;
/*     */ import com.sun.mail.iap.Response;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FetchResponse
/*     */   extends IMAPResponse
/*     */ {
/*     */   private Item[] items;
/*     */   
/*     */   public FetchResponse(Protocol paramProtocol) throws IOException, ProtocolException {
/*  28 */     super(paramProtocol);
/*  29 */     parse();
/*     */   }
/*     */ 
/*     */   
/*     */   public FetchResponse(IMAPResponse paramIMAPResponse) throws IOException, ProtocolException {
/*  34 */     super(paramIMAPResponse);
/*  35 */     parse();
/*     */   }
/*     */ 
/*     */   
/*  39 */   public int getItemCount() { return this.items.length; }
/*     */ 
/*     */ 
/*     */   
/*  43 */   public Item getItem(int paramInt) { return this.items[paramInt]; }
/*     */ 
/*     */   
/*     */   public Item getItem(Class paramClass) {
/*  47 */     for (byte b = 0; b < this.items.length; b++) {
/*  48 */       if (paramClass.isInstance(this.items[b])) {
/*  49 */         return this.items[b];
/*     */       }
/*     */     } 
/*  52 */     return null;
/*     */   }
/*     */   
/*     */   public static Item getItem(Response[] paramArrayOfResponse, int paramInt, Class paramClass) {
/*  56 */     if (paramArrayOfResponse == null) {
/*  57 */       return null;
/*     */     }
/*  59 */     for (byte b = 0; b < paramArrayOfResponse.length; b++) {
/*     */       
/*  61 */       if (paramArrayOfResponse[b] != null && 
/*  62 */         paramArrayOfResponse[b] instanceof FetchResponse && (
/*  63 */         (FetchResponse)paramArrayOfResponse[b]).getNumber() == paramInt) {
/*     */ 
/*     */         
/*  66 */         FetchResponse fetchResponse = (FetchResponse)paramArrayOfResponse[b];
/*  67 */         for (byte b1 = 0; b1 < fetchResponse.items.length; b1++) {
/*  68 */           if (paramClass.isInstance(fetchResponse.items[b1]))
/*  69 */             return fetchResponse.items[b1]; 
/*     */         } 
/*     */       } 
/*     */     } 
/*  73 */     return null;
/*     */   }
/*     */   
/*  76 */   private static final char[] HEADER = { '.', 'H', 'E', 'A', 'D', 'E', 'R' };
/*  77 */   private static final char[] TEXT = { '.', 'T', 'E', 'X', 'T' };
/*     */ 
/*     */   
/*     */   private void parse() throws ParsingException {
/*  81 */     skipSpaces();
/*  82 */     if (this.buffer[this.index] != 40) {
/*  83 */       throw new ParsingException("error in FETCH parsing");
/*     */     }
/*  85 */     Vector vector = new Vector();
/*  86 */     ENVELOPE eNVELOPE = null; do {
/*     */       UID uID;
/*  88 */       this.index++;
/*     */       
/*  90 */       switch (this.buffer[this.index]) {
/*     */         case 69:
/*  92 */           if (match(ENVELOPE.name)) {
/*  93 */             this.index += ENVELOPE.name.length;
/*  94 */             eNVELOPE = new ENVELOPE(this);
/*     */           } 
/*     */           break;
/*     */         case 70:
/*  98 */           if (match(FLAGS.name)) {
/*  99 */             this.index += FLAGS.name.length;
/* 100 */             uID = new FLAGS(this);
/*     */           } 
/*     */           break;
/*     */         case 73:
/* 104 */           if (match(INTERNALDATE.name)) {
/* 105 */             this.index += INTERNALDATE.name.length;
/* 106 */             uID = new INTERNALDATE(this);
/*     */           } 
/*     */           break;
/*     */         case 66:
/* 110 */           if (match(BODY.name)) {
/* 111 */             if (this.buffer[this.index + 4] == 91) {
/* 112 */               this.index += BODY.name.length;
/* 113 */               BODY bODY = new BODY(this);
/*     */               break;
/*     */             } 
/* 116 */             if (match(BODYSTRUCTURE.name)) {
/* 117 */               this.index += BODYSTRUCTURE.name.length;
/*     */             } else {
/* 119 */               this.index += BODY.name.length;
/* 120 */             }  uID = new BODYSTRUCTURE(this);
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 82:
/* 125 */           if (match(RFC822SIZE.name)) {
/* 126 */             this.index += RFC822SIZE.name.length;
/* 127 */             uID = new RFC822SIZE(this);
/*     */             break;
/*     */           } 
/* 130 */           if (match(RFC822DATA.name)) {
/* 131 */             this.index += RFC822DATA.name.length;
/* 132 */             if (match(HEADER)) {
/* 133 */               this.index += HEADER.length;
/* 134 */             } else if (match(TEXT)) {
/* 135 */               this.index += TEXT.length;
/* 136 */             }  uID = new RFC822DATA(this);
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 85:
/* 141 */           if (match(UID.name)) {
/* 142 */             this.index += UID.name.length;
/* 143 */             uID = new UID(this);
/*     */           } 
/*     */           break;
/*     */       } 
/*     */       
/* 148 */       if (uID == null)
/* 149 */         continue;  vector.addElement(uID);
/* 150 */     } while (this.buffer[this.index] != 41);
/*     */     
/* 152 */     this.index++;
/* 153 */     this.items = new Item[vector.size()];
/* 154 */     vector.copyInto(this.items);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean match(char[] paramArrayOfChar) {
/* 161 */     int i = paramArrayOfChar.length; byte b; int j;
/* 162 */     for (b = 0, j = this.index; b < i;) {
/*     */ 
/*     */       
/* 165 */       if (Character.toUpperCase((char)this.buffer[j++]) != paramArrayOfChar[b++])
/* 166 */         return false; 
/* 167 */     }  return true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\FetchResponse.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */