package com.sun.mail.imap.protocol;

import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.Writer;

public class BASE64MailboxEncoder {
  protected byte[] buffer;
  
  protected int bufsize;
  
  protected boolean started;
  
  protected Writer out;
  
  public static String encode(String paramString) {
    BASE64MailboxEncoder bASE64MailboxEncoder = null;
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    boolean bool = false;
    CharArrayWriter charArrayWriter = new CharArrayWriter(i);
    for (byte b = 0; b < i; b++) {
      char c = arrayOfChar[b];
      if (c >= ' ' && c <= '~') {
        if (bASE64MailboxEncoder != null)
          bASE64MailboxEncoder.flush(); 
        if (c == '&') {
          bool = true;
          charArrayWriter.write(38);
          charArrayWriter.write(45);
        } else {
          charArrayWriter.write(c);
        } 
      } else {
        if (bASE64MailboxEncoder == null) {
          bASE64MailboxEncoder = new BASE64MailboxEncoder(charArrayWriter);
          bool = true;
        } 
        bASE64MailboxEncoder.write(c);
      } 
    } 
    if (bASE64MailboxEncoder != null)
      bASE64MailboxEncoder.flush(); 
    if (bool)
      return charArrayWriter.toString(); 
    return paramString;
  }
  
  public BASE64MailboxEncoder(Writer paramWriter) {
    this.buffer = new byte[4];
    this.started = false;
    this.out = paramWriter;
  }
  
  public void write(int paramInt) {
    try {
      if (!this.started) {
        this.started = true;
        this.out.write(38);
      } 
      this.buffer[this.bufsize++] = (byte)(paramInt >> 8);
      this.buffer[this.bufsize++] = (byte)(paramInt & 0xFF);
      if (this.bufsize >= 3) {
        encode();
        this.bufsize -= 3;
        return;
      } 
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
  }
  
  public void flush() {
    try {
      if (this.bufsize > 0) {
        encode();
        this.bufsize = 0;
      } 
      if (this.started) {
        this.out.write(45);
        this.started = false;
        return;
      } 
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
  }
  
  protected void encode() {
    if (this.bufsize == 1) {
      byte b = this.buffer[0];
      boolean bool1 = false;
      boolean bool2 = false;
      this.out.write(pem_array[b >>> 2 & 0x3F]);
      this.out.write(pem_array[(b << 4 & 0x30) + (bool1 >>> 4 & 0xF)]);
      return;
    } 
    if (this.bufsize == 2) {
      byte b4 = this.buffer[0];
      byte b5 = this.buffer[1];
      boolean bool = false;
      this.out.write(pem_array[b4 >>> 2 & 0x3F]);
      this.out.write(pem_array[(b4 << 4 & 0x30) + (b5 >>> 4 & 0xF)]);
      this.out.write(pem_array[(b5 << 2 & 0x3C) + (bool >>> 6 & 0x3)]);
      return;
    } 
    byte b1 = this.buffer[0];
    byte b2 = this.buffer[1];
    byte b3 = this.buffer[2];
    this.out.write(pem_array[b1 >>> 2 & 0x3F]);
    this.out.write(pem_array[(b1 << 4 & 0x30) + (b2 >>> 4 & 0xF)]);
    this.out.write(pem_array[(b2 << 2 & 0x3C) + (b3 >>> 6 & 0x3)]);
    this.out.write(pem_array[b3 & 0x3F]);
    if (this.bufsize == 4)
      this.buffer[0] = this.buffer[3]; 
  }
  
  private static final char[] pem_array = { 
      'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 
      'I', 'J', 
      'K', 'L', 'M', 'N', 'O', 'P', 
      'Q', 'R', 'S', 'T', 
      'U', 'V', 'W', 'X', 
      'Y', 'Z', 'a', 'b', 'c', 'd', 
      'e', 'f', 
      'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 
      'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
      'w', 'x', 
      'y', 'z', '0', '1', '2', '3', 
      '4', '5', '6', '7', 
      '8', '9', '+', ',' };
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\BASE64MailboxEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */