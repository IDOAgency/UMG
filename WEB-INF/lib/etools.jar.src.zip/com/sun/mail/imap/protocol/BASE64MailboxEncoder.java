/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import java.io.CharArrayWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BASE64MailboxEncoder
/*     */ {
/*     */   protected byte[] buffer;
/*     */   protected int bufsize;
/*     */   protected boolean started;
/*     */   protected Writer out;
/*     */   
/*     */   public static String encode(String paramString) {
/*  84 */     BASE64MailboxEncoder bASE64MailboxEncoder = null;
/*  85 */     char[] arrayOfChar = paramString.toCharArray();
/*  86 */     int i = arrayOfChar.length;
/*  87 */     boolean bool = false;
/*  88 */     CharArrayWriter charArrayWriter = new CharArrayWriter(i);
/*     */ 
/*     */     
/*  91 */     for (byte b = 0; b < i; b++) {
/*  92 */       char c = arrayOfChar[b];
/*     */ 
/*     */ 
/*     */       
/*  96 */       if (c >= ' ' && c <= '~') {
/*  97 */         if (bASE64MailboxEncoder != null) {
/*  98 */           bASE64MailboxEncoder.flush();
/*     */         }
/*     */         
/* 101 */         if (c == '&') {
/* 102 */           bool = true;
/* 103 */           charArrayWriter.write(38);
/* 104 */           charArrayWriter.write(45);
/*     */         } else {
/* 106 */           charArrayWriter.write(c);
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 115 */         if (bASE64MailboxEncoder == null) {
/* 116 */           bASE64MailboxEncoder = new BASE64MailboxEncoder(charArrayWriter);
/* 117 */           bool = true;
/*     */         } 
/*     */         
/* 120 */         bASE64MailboxEncoder.write(c);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 125 */     if (bASE64MailboxEncoder != null) {
/* 126 */       bASE64MailboxEncoder.flush();
/*     */     }
/*     */     
/* 129 */     if (bool) {
/* 130 */       return charArrayWriter.toString();
/*     */     }
/* 132 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BASE64MailboxEncoder(Writer paramWriter) {
/*     */     this.buffer = new byte[4];
/*     */     this.started = false;
/* 141 */     this.out = paramWriter;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int paramInt) {
/*     */     try {
/* 147 */       if (!this.started) {
/* 148 */         this.started = true;
/* 149 */         this.out.write(38);
/*     */       } 
/*     */ 
/*     */       
/* 153 */       this.buffer[this.bufsize++] = (byte)(paramInt >> 8);
/* 154 */       this.buffer[this.bufsize++] = (byte)(paramInt & 0xFF);
/*     */       
/* 156 */       if (this.bufsize >= 3) {
/* 157 */         encode();
/* 158 */         this.bufsize -= 3; return;
/*     */       } 
/* 160 */     } catch (IOException iOException) {
/* 161 */       iOException.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {
/*     */     try {
/* 169 */       if (this.bufsize > 0) {
/* 170 */         encode();
/* 171 */         this.bufsize = 0;
/*     */       } 
/*     */ 
/*     */       
/* 175 */       if (this.started) {
/* 176 */         this.out.write(45);
/* 177 */         this.started = false; return;
/*     */       } 
/* 179 */     } catch (IOException iOException) {
/* 180 */       iOException.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encode() {
/* 187 */     if (this.bufsize == 1) {
/* 188 */       byte b = this.buffer[0];
/* 189 */       boolean bool1 = false;
/* 190 */       boolean bool2 = false;
/* 191 */       this.out.write(pem_array[b >>> 2 & 0x3F]);
/* 192 */       this.out.write(pem_array[(b << 4 & 0x30) + (bool1 >>> 4 & 0xF)]); return;
/*     */     } 
/* 194 */     if (this.bufsize == 2) {
/* 195 */       byte b4 = this.buffer[0];
/* 196 */       byte b5 = this.buffer[1];
/* 197 */       boolean bool = false;
/* 198 */       this.out.write(pem_array[b4 >>> 2 & 0x3F]);
/* 199 */       this.out.write(pem_array[(b4 << 4 & 0x30) + (b5 >>> 4 & 0xF)]);
/* 200 */       this.out.write(pem_array[(b5 << 2 & 0x3C) + (bool >>> 6 & 0x3)]);
/*     */       return;
/*     */     } 
/* 203 */     byte b1 = this.buffer[0];
/* 204 */     byte b2 = this.buffer[1];
/* 205 */     byte b3 = this.buffer[2];
/* 206 */     this.out.write(pem_array[b1 >>> 2 & 0x3F]);
/* 207 */     this.out.write(pem_array[(b1 << 4 & 0x30) + (b2 >>> 4 & 0xF)]);
/* 208 */     this.out.write(pem_array[(b2 << 2 & 0x3C) + (b3 >>> 6 & 0x3)]);
/* 209 */     this.out.write(pem_array[b3 & 0x3F]);
/*     */ 
/*     */     
/* 212 */     if (this.bufsize == 4) {
/* 213 */       this.buffer[0] = this.buffer[3];
/*     */     }
/*     */   }
/*     */   
/*     */   private static final char[] pem_array = { 
/* 218 */       'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 
/* 219 */       'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 
/* 220 */       'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 
/* 221 */       'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 
/* 222 */       'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 
/* 223 */       'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
/* 224 */       'w', 'x', 'y', 'z', '0', '1', '2', '3', 
/* 225 */       '4', '5', '6', '7', '8', '9', '+', ',' };
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\BASE64MailboxEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */