/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import java.text.CharacterIterator;
/*     */ import java.text.StringCharacterIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BASE64MailboxDecoder
/*     */ {
/*     */   public static String decode(String paramString) {
/*  24 */     if (paramString == null || paramString.length() == 0) {
/*  25 */       return paramString;
/*     */     }
/*  27 */     boolean bool = false;
/*  28 */     int i = 0;
/*     */     
/*  30 */     char[] arrayOfChar = new char[paramString.length()];
/*  31 */     StringCharacterIterator stringCharacterIterator = new StringCharacterIterator(paramString);
/*     */     
/*  33 */     for (char c = stringCharacterIterator.first(); c != Character.MAX_VALUE; 
/*  34 */       c = stringCharacterIterator.next()) {
/*     */       
/*  36 */       if (c == '&') {
/*  37 */         bool = true;
/*  38 */         i = base64decode(arrayOfChar, i, stringCharacterIterator);
/*     */       } else {
/*  40 */         arrayOfChar[i++] = c;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  45 */     if (bool) {
/*  46 */       return new String(arrayOfChar, 0, i);
/*     */     }
/*  48 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int base64decode(char[] paramArrayOfChar, int paramInt, CharacterIterator paramCharacterIterator) {
/*  55 */     boolean bool = true;
/*  56 */     byte b = -1;
/*  57 */     char c = Character.MIN_VALUE;
/*     */ 
/*     */     
/*     */     while (true) {
/*  61 */       byte b1 = (byte)paramCharacterIterator.next();
/*  62 */       if (b1 != -1) {
/*  63 */         if (b1 == 45) {
/*  64 */           if (bool)
/*     */           {
/*  66 */             paramArrayOfChar[paramInt++] = '&';
/*     */           }
/*     */           
/*     */           break;
/*     */         } 
/*  71 */         bool = false;
/*     */ 
/*     */         
/*  74 */         byte b2 = (byte)paramCharacterIterator.next();
/*  75 */         if (b2 == -1 || b2 == 45) {
/*     */           break;
/*     */         }
/*     */         
/*  79 */         byte b3 = pem_convert_array[b1 & 0xFF];
/*  80 */         byte b4 = pem_convert_array[b2 & 0xFF];
/*     */         
/*  82 */         byte b5 = (byte)(b3 << 2 & 0xFC | b4 >>> 4 & 0x3);
/*     */ 
/*     */         
/*  85 */         if (b != -1) {
/*  86 */           paramArrayOfChar[paramInt++] = (char)(b << 8 | b5 & 0xFF);
/*  87 */           b = -1;
/*     */         } else {
/*  89 */           b = b5 & 0xFF;
/*     */         } 
/*     */         
/*  92 */         byte b6 = (byte)paramCharacterIterator.next();
/*  93 */         if (b6 == 61)
/*     */           continue; 
/*  95 */         if (b6 == -1 || b6 == 45) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 100 */         b3 = b4;
/* 101 */         b4 = pem_convert_array[b6 & 0xFF];
/* 102 */         b5 = (byte)(b3 << 4 & 0xF0 | b4 >>> 2 & 0xF);
/*     */ 
/*     */         
/* 105 */         if (b != -1) {
/* 106 */           paramArrayOfChar[paramInt++] = (char)(b << 8 | b5 & 0xFF);
/* 107 */           b = -1;
/*     */         } else {
/* 109 */           b = b5 & 0xFF;
/*     */         } 
/*     */         
/* 112 */         byte b7 = (byte)paramCharacterIterator.next();
/* 113 */         if (b7 == 61)
/*     */           continue; 
/* 115 */         if (b7 == -1 || b7 == 45) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 120 */         b3 = b4;
/* 121 */         b4 = pem_convert_array[b7 & 0xFF];
/* 122 */         b5 = (byte)(b3 << 6 & 0xC0 | b4 & 0x3F);
/*     */ 
/*     */         
/* 125 */         if (b != -1) {
/* 126 */           c = (char)(b << 8 | b5 & 0xFF);
/* 127 */           paramArrayOfChar[paramInt++] = (char)(b << 8 | b5 & 0xFF);
/* 128 */           b = -1; continue;
/*     */         } 
/* 130 */         b = b5 & 0xFF; continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 134 */     return paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final char[] pem_array = { 
/* 144 */       'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 
/* 145 */       'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 
/* 146 */       'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 
/* 147 */       'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 
/* 148 */       'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 
/* 149 */       'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
/* 150 */       'w', 'x', 'y', 'z', '0', '1', '2', '3', 
/* 151 */       '4', '5', '6', '7', '8', '9', '+', ',' };
/*     */ 
/*     */   
/* 154 */   protected static final byte[] pem_convert_array = new byte[256];
/*     */   
/*     */   static  {
/* 157 */     for (byte b1 = 0; b1 < 'ÿ'; b1++)
/* 158 */       pem_convert_array[b1] = -1; 
/* 159 */     for (byte b2 = 0; b2 < pem_array.length; b2++)
/* 160 */       pem_convert_array[pem_array[b2]] = (byte)b2; 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\BASE64MailboxDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */