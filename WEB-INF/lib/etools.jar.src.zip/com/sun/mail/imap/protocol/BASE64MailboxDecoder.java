package com.sun.mail.imap.protocol;

import java.text.CharacterIterator;
import java.text.StringCharacterIterator;

public class BASE64MailboxDecoder {
  public static String decode(String paramString) {
    if (paramString == null || paramString.length() == 0)
      return paramString; 
    boolean bool = false;
    int i = 0;
    char[] arrayOfChar = new char[paramString.length()];
    StringCharacterIterator stringCharacterIterator = new StringCharacterIterator(paramString);
    for (char c = stringCharacterIterator.first(); c != Character.MAX_VALUE; 
      c = stringCharacterIterator.next()) {
      if (c == '&') {
        bool = true;
        i = base64decode(arrayOfChar, i, stringCharacterIterator);
      } else {
        arrayOfChar[i++] = c;
      } 
    } 
    if (bool)
      return new String(arrayOfChar, 0, i); 
    return paramString;
  }
  
  protected static int base64decode(char[] paramArrayOfChar, int paramInt, CharacterIterator paramCharacterIterator) {
    boolean bool = true;
    byte b = -1;
    char c = Character.MIN_VALUE;
    while (true) {
      byte b1 = (byte)paramCharacterIterator.next();
      if (b1 != -1) {
        if (b1 == 45) {
          if (bool)
            paramArrayOfChar[paramInt++] = '&'; 
          break;
        } 
        bool = false;
        byte b2 = (byte)paramCharacterIterator.next();
        if (b2 == -1 || b2 == 45)
          break; 
        byte b3 = pem_convert_array[b1 & 0xFF];
        byte b4 = pem_convert_array[b2 & 0xFF];
        byte b5 = (byte)(b3 << 2 & 0xFC | b4 >>> 4 & 0x3);
        if (b != -1) {
          paramArrayOfChar[paramInt++] = (char)(b << 8 | b5 & 0xFF);
          b = -1;
        } else {
          b = b5 & 0xFF;
        } 
        byte b6 = (byte)paramCharacterIterator.next();
        if (b6 == 61)
          continue; 
        if (b6 == -1 || b6 == 45)
          break; 
        b3 = b4;
        b4 = pem_convert_array[b6 & 0xFF];
        b5 = (byte)(b3 << 4 & 0xF0 | b4 >>> 2 & 0xF);
        if (b != -1) {
          paramArrayOfChar[paramInt++] = (char)(b << 8 | b5 & 0xFF);
          b = -1;
        } else {
          b = b5 & 0xFF;
        } 
        byte b7 = (byte)paramCharacterIterator.next();
        if (b7 == 61)
          continue; 
        if (b7 == -1 || b7 == 45)
          break; 
        b3 = b4;
        b4 = pem_convert_array[b7 & 0xFF];
        b5 = (byte)(b3 << 6 & 0xC0 | b4 & 0x3F);
        if (b != -1) {
          c = (char)(b << 8 | b5 & 0xFF);
          paramArrayOfChar[paramInt++] = (char)(b << 8 | b5 & 0xFF);
          b = -1;
          continue;
        } 
        b = b5 & 0xFF;
        continue;
      } 
      break;
    } 
    return paramInt;
  }
  
  protected static final char[] pem_array = { 
      'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 
      'I', 'J', 
      'K', 'L', 'M', 'N', 'O', 'P', 
      'Q', 'R', 'S', 'T', 
      'U', 'V', 'W', 'X', 
      'Y', 'Z', 'a', 'b', 'c', 'd', 
      'e', 'f', 
      'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 
      'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
      'w', 'x', 
      'y', 'z', '0', '1', '2', '3', 
      '4', '5', '6', '7', 
      '8', '9', '+', ',' };
  
  protected static final byte[] pem_convert_array = new byte[256];
  
  static  {
    for (byte b1 = 0; b1 < 'ÿ'; b1++)
      pem_convert_array[b1] = -1; 
    for (byte b2 = 0; b2 < pem_array.length; b2++)
      pem_convert_array[pem_array[b2]] = (byte)b2; 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\BASE64MailboxDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */