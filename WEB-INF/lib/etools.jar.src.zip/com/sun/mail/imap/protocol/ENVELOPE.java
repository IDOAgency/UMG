package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;
import com.sun.mail.iap.Response;
import com.sun.mail.util.MailDateFormat;
import java.util.Date;
import java.util.Vector;
import javax.mail.internet.InternetAddress;

public class ENVELOPE implements Item {
  public static char[] name = { 'E', 'N', 'V', 'E', 'L', 'O', 'P', 'E' };
  
  public int msgno;
  
  public Date date;
  
  public String subject;
  
  public InternetAddress[] from;
  
  public InternetAddress[] sender;
  
  public InternetAddress[] replyTo;
  
  public InternetAddress[] to;
  
  public InternetAddress[] cc;
  
  public InternetAddress[] bcc;
  
  public String inReplyTo;
  
  public String messageId;
  
  private static MailDateFormat mailDateFormat = new MailDateFormat();
  
  public ENVELOPE(FetchResponse paramFetchResponse) throws ParsingException {
    this.msgno = paramFetchResponse.getNumber();
    paramFetchResponse.skipSpaces();
    if (paramFetchResponse.readByte() != 40)
      throw new ParsingException("ENVELOPE parse error"); 
    String str = paramFetchResponse.readString();
    if (str != null)
      try {
        this.date = mailDateFormat.parse(str);
      } catch (Exception exception) {} 
    this.subject = paramFetchResponse.readString();
    this.from = parseAddressList(paramFetchResponse);
    this.sender = parseAddressList(paramFetchResponse);
    this.replyTo = parseAddressList(paramFetchResponse);
    this.to = parseAddressList(paramFetchResponse);
    this.cc = parseAddressList(paramFetchResponse);
    this.bcc = parseAddressList(paramFetchResponse);
    this.inReplyTo = paramFetchResponse.readString();
    this.messageId = paramFetchResponse.readString();
    if (paramFetchResponse.readByte() != 41)
      throw new ParsingException("ENVELOPE parse error"); 
  }
  
  private InternetAddress[] parseAddressList(Response paramResponse) throws ParsingException {
    paramResponse.skipSpaces();
    byte b = paramResponse.readByte();
    if (b == 40) {
      Vector vector = new Vector();
      do {
        vector.addElement(new IMAPAddress(paramResponse));
      } while (paramResponse.peekByte() != 41);
      paramResponse.skip(1);
      InternetAddress[] arrayOfInternetAddress = new InternetAddress[vector.size()];
      vector.copyInto(arrayOfInternetAddress);
      return arrayOfInternetAddress;
    } 
    if (b == 78 || b == 110) {
      paramResponse.skip(2);
      return null;
    } 
    throw new ParsingException("ADDRESS parse error");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\ENVELOPE.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */