/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import com.sun.mail.iap.ParsingException;
/*     */ import com.sun.mail.iap.Response;
/*     */ import com.sun.mail.util.MailDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Vector;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ENVELOPE
/*     */   implements Item
/*     */ {
/*  30 */   public static char[] name = { 'E', 'N', 'V', 'E', 'L', 'O', 'P', 'E' };
/*     */   
/*     */   public int msgno;
/*     */   
/*     */   public Date date;
/*     */   
/*     */   public String subject;
/*     */   public InternetAddress[] from;
/*     */   public InternetAddress[] sender;
/*     */   public InternetAddress[] replyTo;
/*     */   public InternetAddress[] to;
/*     */   public InternetAddress[] cc;
/*     */   public InternetAddress[] bcc;
/*     */   public String inReplyTo;
/*     */   public String messageId;
/*  45 */   private static MailDateFormat mailDateFormat = new MailDateFormat();
/*     */   
/*     */   public ENVELOPE(FetchResponse paramFetchResponse) throws ParsingException {
/*  48 */     this.msgno = paramFetchResponse.getNumber();
/*     */     
/*  50 */     paramFetchResponse.skipSpaces();
/*     */     
/*  52 */     if (paramFetchResponse.readByte() != 40) {
/*  53 */       throw new ParsingException("ENVELOPE parse error");
/*     */     }
/*  55 */     String str = paramFetchResponse.readString();
/*  56 */     if (str != null) {
/*     */       try {
/*  58 */         this.date = mailDateFormat.parse(str);
/*  59 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.subject = paramFetchResponse.readString();
/*  68 */     this.from = parseAddressList(paramFetchResponse);
/*  69 */     this.sender = parseAddressList(paramFetchResponse);
/*  70 */     this.replyTo = parseAddressList(paramFetchResponse);
/*  71 */     this.to = parseAddressList(paramFetchResponse);
/*  72 */     this.cc = parseAddressList(paramFetchResponse);
/*  73 */     this.bcc = parseAddressList(paramFetchResponse);
/*  74 */     this.inReplyTo = paramFetchResponse.readString();
/*  75 */     this.messageId = paramFetchResponse.readString();
/*     */     
/*  77 */     if (paramFetchResponse.readByte() != 41) {
/*  78 */       throw new ParsingException("ENVELOPE parse error");
/*     */     }
/*     */   }
/*     */   
/*     */   private InternetAddress[] parseAddressList(Response paramResponse) throws ParsingException {
/*  83 */     paramResponse.skipSpaces();
/*     */     
/*  85 */     byte b = paramResponse.readByte();
/*  86 */     if (b == 40) {
/*  87 */       Vector vector = new Vector();
/*     */       
/*     */       do {
/*  90 */         vector.addElement(new IMAPAddress(paramResponse));
/*  91 */       } while (paramResponse.peekByte() != 41);
/*     */ 
/*     */       
/*  94 */       paramResponse.skip(1);
/*     */       
/*  96 */       InternetAddress[] arrayOfInternetAddress = new InternetAddress[vector.size()];
/*  97 */       vector.copyInto(arrayOfInternetAddress);
/*  98 */       return arrayOfInternetAddress;
/*  99 */     }  if (b == 78 || b == 110) {
/* 100 */       paramResponse.skip(2);
/* 101 */       return null;
/*     */     } 
/* 103 */     throw new ParsingException("ADDRESS parse error");
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\ENVELOPE.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */