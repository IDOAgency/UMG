package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;

public class ListInfo {
  public String name;
  
  public char separator = '/';
  
  public boolean hasInferiors = true;
  
  public boolean canOpen = true;
  
  public int changeState = 3;
  
  public static final int CHANGED = 1;
  
  public static final int UNCHANGED = 2;
  
  public static final int INDETERMINATE = 3;
  
  public ListInfo(IMAPResponse paramIMAPResponse) throws ParsingException {
    String[] arrayOfString = paramIMAPResponse.readSimpleList();
    if (arrayOfString != null)
      for (byte b = 0; b < arrayOfString.length; b++) {
        if (arrayOfString[b].equalsIgnoreCase("\\Marked")) {
          this.changeState = 1;
        } else if (arrayOfString[b].equalsIgnoreCase("\\Unmarked")) {
          this.changeState = 2;
        } else if (arrayOfString[b].equalsIgnoreCase("\\Noselect")) {
          this.canOpen = false;
        } else if (arrayOfString[b].equalsIgnoreCase("\\Noinferiors")) {
          this.hasInferiors = false;
        } 
      }  
    paramIMAPResponse.skipSpaces();
    if (paramIMAPResponse.readByte() == 34) {
      if ((this.separator = (char)paramIMAPResponse.readByte()) == '\\')
        this.separator = (char)paramIMAPResponse.readByte(); 
      paramIMAPResponse.skip(1);
    } else {
      paramIMAPResponse.skip(2);
    } 
    paramIMAPResponse.skipSpaces();
    this.name = paramIMAPResponse.readAtomString();
    this.name = BASE64MailboxDecoder.decode(this.name);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\ListInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */