/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ListInfo
/*    */ {
/*    */   public String name;
/* 21 */   public char separator = '/';
/*    */   public boolean hasInferiors = true;
/*    */   public boolean canOpen = true;
/* 24 */   public int changeState = 3;
/*    */   
/*    */   public static final int CHANGED = 1;
/*    */   public static final int UNCHANGED = 2;
/*    */   public static final int INDETERMINATE = 3;
/*    */   
/*    */   public ListInfo(IMAPResponse paramIMAPResponse) throws ParsingException {
/* 31 */     String[] arrayOfString = paramIMAPResponse.readSimpleList();
/*    */     
/* 33 */     if (arrayOfString != null)
/*    */     {
/* 35 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 36 */         if (arrayOfString[b].equalsIgnoreCase("\\Marked")) {
/* 37 */           this.changeState = 1;
/* 38 */         } else if (arrayOfString[b].equalsIgnoreCase("\\Unmarked")) {
/* 39 */           this.changeState = 2;
/* 40 */         } else if (arrayOfString[b].equalsIgnoreCase("\\Noselect")) {
/* 41 */           this.canOpen = false;
/* 42 */         } else if (arrayOfString[b].equalsIgnoreCase("\\Noinferiors")) {
/* 43 */           this.hasInferiors = false;
/*    */         } 
/*    */       } 
/*    */     }
/* 47 */     paramIMAPResponse.skipSpaces();
/* 48 */     if (paramIMAPResponse.readByte() == 34) {
/* 49 */       if ((this.separator = (char)paramIMAPResponse.readByte()) == '\\')
/*    */       {
/* 51 */         this.separator = (char)paramIMAPResponse.readByte(); } 
/* 52 */       paramIMAPResponse.skip(1);
/*    */     } else {
/* 54 */       paramIMAPResponse.skip(2);
/*    */     } 
/* 56 */     paramIMAPResponse.skipSpaces();
/* 57 */     this.name = paramIMAPResponse.readAtomString();
/*    */ 
/*    */     
/* 60 */     this.name = BASE64MailboxDecoder.decode(this.name);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\ListInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */