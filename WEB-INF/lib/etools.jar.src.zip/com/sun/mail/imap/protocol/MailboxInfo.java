package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;
import com.sun.mail.iap.Response;
import javax.mail.Flags;

public class MailboxInfo {
  public Flags availableFlags;
  
  public Flags permanentFlags;
  
  public int total = -1;
  
  public int recent = -1;
  
  public int first = -1;
  
  public int uidvalidity = -1;
  
  public int mode;
  
  public MailboxInfo(Response[] paramArrayOfResponse) throws ParsingException {
    for (byte b = 0; b < paramArrayOfResponse.length; b++) {
      if (paramArrayOfResponse[b] != null && paramArrayOfResponse[b] instanceof IMAPResponse) {
        IMAPResponse iMAPResponse = (IMAPResponse)paramArrayOfResponse[b];
        if (iMAPResponse.keyEquals("EXISTS")) {
          this.total = iMAPResponse.getNumber();
          paramArrayOfResponse[b] = null;
        } else if (iMAPResponse.keyEquals("RECENT")) {
          this.recent = iMAPResponse.getNumber();
          paramArrayOfResponse[b] = null;
        } else if (iMAPResponse.keyEquals("FLAGS")) {
          this.availableFlags = new FLAGS(iMAPResponse);
          paramArrayOfResponse[b] = null;
        } else if (iMAPResponse.isUnTagged() && iMAPResponse.isOK()) {
          iMAPResponse.skipSpaces();
          if (iMAPResponse.readByte() == 91) {
            String str = iMAPResponse.readAtom();
            if (str.equalsIgnoreCase("UNSEEN")) {
              this.first = iMAPResponse.readNumber();
            } else if (str.equalsIgnoreCase("UIDVALIDITY")) {
              this.uidvalidity = iMAPResponse.readNumber();
            } else if (str.equalsIgnoreCase("PERMANENTFLAGS")) {
              this.permanentFlags = new FLAGS(iMAPResponse);
            } 
            paramArrayOfResponse[b] = null;
          } 
        } 
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\MailboxInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */