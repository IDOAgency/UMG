/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ import com.sun.mail.iap.Response;
/*    */ import javax.mail.Flags;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MailboxInfo
/*    */ {
/*    */   public Flags availableFlags;
/*    */   public Flags permanentFlags;
/* 23 */   public int total = -1;
/* 24 */   public int recent = -1;
/* 25 */   public int first = -1;
/* 26 */   public int uidvalidity = -1;
/*    */   public int mode;
/*    */   
/*    */   public MailboxInfo(Response[] paramArrayOfResponse) throws ParsingException {
/* 30 */     for (byte b = 0; b < paramArrayOfResponse.length; b++) {
/* 31 */       if (paramArrayOfResponse[b] != null && paramArrayOfResponse[b] instanceof IMAPResponse) {
/*    */ 
/*    */         
/* 34 */         IMAPResponse iMAPResponse = (IMAPResponse)paramArrayOfResponse[b];
/*    */         
/* 36 */         if (iMAPResponse.keyEquals("EXISTS")) {
/* 37 */           this.total = iMAPResponse.getNumber();
/* 38 */           paramArrayOfResponse[b] = null;
/*    */         }
/* 40 */         else if (iMAPResponse.keyEquals("RECENT")) {
/* 41 */           this.recent = iMAPResponse.getNumber();
/* 42 */           paramArrayOfResponse[b] = null;
/*    */         }
/* 44 */         else if (iMAPResponse.keyEquals("FLAGS")) {
/* 45 */           this.availableFlags = new FLAGS(iMAPResponse);
/* 46 */           paramArrayOfResponse[b] = null;
/*    */         }
/* 48 */         else if (iMAPResponse.isUnTagged() && iMAPResponse.isOK()) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */           
/* 54 */           iMAPResponse.skipSpaces();
/*    */           
/* 56 */           if (iMAPResponse.readByte() == 91) {
/*    */ 
/*    */             
/* 59 */             String str = iMAPResponse.readAtom();
/* 60 */             if (str.equalsIgnoreCase("UNSEEN")) {
/* 61 */               this.first = iMAPResponse.readNumber();
/* 62 */             } else if (str.equalsIgnoreCase("UIDVALIDITY")) {
/* 63 */               this.uidvalidity = iMAPResponse.readNumber();
/* 64 */             } else if (str.equalsIgnoreCase("PERMANENTFLAGS")) {
/* 65 */               this.permanentFlags = new FLAGS(iMAPResponse);
/*    */             } 
/* 67 */             paramArrayOfResponse[b] = null;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\protocol\MailboxInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */