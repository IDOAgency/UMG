/*    */ package com.sun.mail.imap;
/*    */ 
/*    */ import com.sun.mail.imap.protocol.BODYSTRUCTURE;
/*    */ import java.util.Vector;
/*    */ import javax.mail.BodyPart;
/*    */ import javax.mail.MessagingException;
/*    */ import javax.mail.MultipartDataSource;
/*    */ import javax.mail.internet.MimePart;
/*    */ import javax.mail.internet.MimePartDataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IMAPMultipartDataSource
/*    */   extends MimePartDataSource
/*    */   implements MultipartDataSource
/*    */ {
/*    */   private Vector parts;
/*    */   
/*    */   protected IMAPMultipartDataSource(MimePart paramMimePart, BODYSTRUCTURE[] paramArrayOfBODYSTRUCTURE, String paramString, IMAPMessage paramIMAPMessage) {
/* 34 */     super(paramMimePart);
/*    */     
/* 36 */     this.parts = new Vector(paramArrayOfBODYSTRUCTURE.length);
/* 37 */     for (byte b = 0; b < paramArrayOfBODYSTRUCTURE.length; b++) {
/* 38 */       this.parts.addElement(
/* 39 */           new IMAPBodyPart(paramArrayOfBODYSTRUCTURE[b], 
/* 40 */             (paramString == null) ? 
/* 41 */             Integer.toString(b + true) : (
/* 42 */             String.valueOf(paramString) + "." + Integer.toString(b + true)), 
/* 43 */             paramIMAPMessage));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/* 48 */   public int getCount() { return this.parts.size(); }
/*    */ 
/*    */ 
/*    */   
/* 52 */   public BodyPart getBodyPart(int paramInt) throws MessagingException { return (BodyPart)this.parts.elementAt(paramInt); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\IMAPMultipartDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */