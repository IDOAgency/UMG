/*     */ package com.sun.mail.imap;
/*     */ 
/*     */ import com.sun.mail.iap.ByteArray;
/*     */ import com.sun.mail.iap.ProtocolException;
/*     */ import com.sun.mail.imap.protocol.BODY;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.mail.FolderClosedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IMAPInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private IMAPMessage msg;
/*     */   private String section;
/*     */   private int pos;
/*     */   private int blksize;
/*     */   private int max;
/*     */   private byte[] buf;
/*     */   private int bufcount;
/*     */   private int bufpos;
/*     */   
/*     */   public IMAPInputStream(IMAPMessage paramIMAPMessage, String paramString, int paramInt) {
/*  38 */     this.msg = paramIMAPMessage;
/*  39 */     this.section = paramString;
/*  40 */     this.max = paramInt;
/*  41 */     this.pos = 0;
/*  42 */     this.blksize = paramIMAPMessage.getFetchBlockSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fill() throws IOException {
/*  53 */     if (this.max != -1 && this.pos >= this.max) {
/*     */       return;
/*     */     }
/*  56 */     BODY bODY = null;
/*     */ 
/*     */     
/*  59 */     synchronized (this.msg.getMessageCacheLock()) {
/*     */ 
/*     */       
/*  62 */       if (this.msg.isExpunged()) {
/*  63 */         throw new IOException("No content for expunged message");
/*     */       }
/*  65 */       int j = this.msg.getSequenceNumber();
/*     */       try {
/*  67 */         bODY = this.msg.getProtocol().fetchBody(j, this.section, this.pos, this.blksize);
/*  68 */       } catch (ProtocolException protocolException) {
/*  69 */         throw new IOException(protocolException.getMessage());
/*  70 */       } catch (FolderClosedException folderClosedException) {
/*  71 */         throw new IOException(folderClosedException.getMessage());
/*     */       } 
/*     */     } 
/*     */     
/*     */     ByteArray byteArray;
/*  76 */     if (bODY == null || (byteArray = bODY.getByteArray()) == null) {
/*  77 */       throw new IOException("No content");
/*     */     }
/*     */     
/*  80 */     this.buf = byteArray.getBytes();
/*  81 */     this.bufpos = byteArray.getStart();
/*  82 */     int i = byteArray.getCount();
/*     */     
/*  84 */     this.bufcount = this.bufpos + i;
/*  85 */     this.pos += i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*  93 */     if (this.bufpos >= this.bufcount) {
/*  94 */       fill();
/*  95 */       if (this.bufpos >= this.bufcount)
/*  96 */         return -1; 
/*     */     } 
/*  98 */     return this.buf[this.bufpos++] & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/* 118 */     int i = this.bufcount - this.bufpos;
/* 119 */     if (i <= 0) {
/* 120 */       fill();
/* 121 */       i = this.bufcount - this.bufpos;
/* 122 */       if (i <= 0)
/* 123 */         return -1; 
/*     */     } 
/* 125 */     int j = (i < paramInt2) ? i : paramInt2;
/* 126 */     System.arraycopy(this.buf, this.bufpos, paramArrayOfByte, paramInt1, j);
/* 127 */     this.bufpos += j;
/* 128 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public int read(byte[] paramArrayOfByte) throws IOException { return read(paramArrayOfByte, 0, paramArrayOfByte.length); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public int available() throws IOException { return this.bufcount - this.bufpos; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\IMAPInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */