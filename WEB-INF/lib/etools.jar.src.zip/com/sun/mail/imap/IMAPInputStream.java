package com.sun.mail.imap;

import com.sun.mail.iap.ByteArray;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.imap.protocol.BODY;
import java.io.IOException;
import java.io.InputStream;
import javax.mail.FolderClosedException;

public class IMAPInputStream extends InputStream {
  private IMAPMessage msg;
  
  private String section;
  
  private int pos;
  
  private int blksize;
  
  private int max;
  
  private byte[] buf;
  
  private int bufcount;
  
  private int bufpos;
  
  public IMAPInputStream(IMAPMessage paramIMAPMessage, String paramString, int paramInt) {
    this.msg = paramIMAPMessage;
    this.section = paramString;
    this.max = paramInt;
    this.pos = 0;
    this.blksize = paramIMAPMessage.getFetchBlockSize();
  }
  
  private void fill() throws IOException {
    if (this.max != -1 && this.pos >= this.max)
      return; 
    BODY bODY = null;
    synchronized (this.msg.getMessageCacheLock()) {
      if (this.msg.isExpunged())
        throw new IOException("No content for expunged message"); 
      int j = this.msg.getSequenceNumber();
      try {
        bODY = this.msg.getProtocol().fetchBody(j, this.section, this.pos, this.blksize);
      } catch (ProtocolException protocolException) {
        throw new IOException(protocolException.getMessage());
      } catch (FolderClosedException folderClosedException) {
        throw new IOException(folderClosedException.getMessage());
      } 
    } 
    ByteArray byteArray;
    if (bODY == null || (byteArray = bODY.getByteArray()) == null)
      throw new IOException("No content"); 
    this.buf = byteArray.getBytes();
    this.bufpos = byteArray.getStart();
    int i = byteArray.getCount();
    this.bufcount = this.bufpos + i;
    this.pos += i;
  }
  
  public int read() throws IOException {
    if (this.bufpos >= this.bufcount) {
      fill();
      if (this.bufpos >= this.bufcount)
        return -1; 
    } 
    return this.buf[this.bufpos++] & 0xFF;
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
    int i = this.bufcount - this.bufpos;
    if (i <= 0) {
      fill();
      i = this.bufcount - this.bufpos;
      if (i <= 0)
        return -1; 
    } 
    int j = (i < paramInt2) ? i : paramInt2;
    System.arraycopy(this.buf, this.bufpos, paramArrayOfByte, paramInt1, j);
    this.bufpos += j;
    return j;
  }
  
  public int read(byte[] paramArrayOfByte) throws IOException { return read(paramArrayOfByte, 0, paramArrayOfByte.length); }
  
  public int available() throws IOException { return this.bufcount - this.bufpos; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\IMAPInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */