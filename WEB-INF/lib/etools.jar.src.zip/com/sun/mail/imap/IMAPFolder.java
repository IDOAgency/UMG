package com.sun.mail.imap;

import com.sun.mail.iap.BadCommandException;
import com.sun.mail.iap.CommandFailedException;
import com.sun.mail.iap.ConnectionException;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import com.sun.mail.iap.ResponseHandler;
import com.sun.mail.imap.protocol.FetchResponse;
import com.sun.mail.imap.protocol.IMAPProtocol;
import com.sun.mail.imap.protocol.IMAPResponse;
import com.sun.mail.imap.protocol.ListInfo;
import com.sun.mail.imap.protocol.MailboxInfo;
import com.sun.mail.imap.protocol.Status;
import com.sun.mail.imap.protocol.UID;
import com.sun.mail.util.CRLFOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Hashtable;
import java.util.NoSuchElementException;
import java.util.Vector;
import javax.mail.FetchProfile;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.FolderClosedException;
import javax.mail.FolderNotFoundException;
import javax.mail.Message;
import javax.mail.MessageRemovedException;
import javax.mail.MessagingException;
import javax.mail.StoreClosedException;
import javax.mail.UIDFolder;
import javax.mail.search.FlagTerm;
import javax.mail.search.SearchException;
import javax.mail.search.SearchTerm;

public class IMAPFolder extends Folder implements UIDFolder, ResponseHandler {
  protected String fullName;
  
  protected String name;
  
  protected int type;
  
  protected char separator;
  
  protected Flags availableFlags;
  
  protected Flags permanentFlags;
  
  protected boolean exists = false;
  
  protected IMAPProtocol protocol;
  
  protected Vector messageCache;
  
  protected Object messageCacheLock;
  
  protected Hashtable uidTable;
  
  protected static final char UNKNOWN_SEPARATOR = '￿';
  
  private boolean opened = false;
  
  private boolean reallyClosed = true;
  
  private int total = -1;
  
  private int recent = -1;
  
  private int realTotal = -1;
  
  private int uidvalidity = -1;
  
  private boolean doExpungeNotification = true;
  
  protected IMAPFolder(String paramString, char paramChar, IMAPStore paramIMAPStore) {
    super(paramIMAPStore);
    this.fullName = paramString;
    this.separator = paramChar;
    this.messageCacheLock = new Object();
  }
  
  protected IMAPFolder(ListInfo paramListInfo, IMAPStore paramIMAPStore) {
    this(paramListInfo.name, paramListInfo.separator, paramIMAPStore);
    if (paramListInfo.hasInferiors)
      this.type |= 0x2; 
    if (paramListInfo.canOpen)
      this.type |= 0x1; 
    this.exists = true;
  }
  
  private void checkExists() throws MessagingException {
    if (!this.exists && !exists())
      throw new FolderNotFoundException(
          String.valueOf(this.fullName) + " not found", this); 
  }
  
  private void checkClosed() throws MessagingException {
    if (this.opened)
      throw new IllegalStateException(
          "This operation is not allowed on an open folder"); 
  }
  
  private void checkOpened() throws MessagingException {
    if (!this.opened) {
      if (this.reallyClosed)
        throw new IllegalStateException(
            "This operation is not allowed on a closed folder"); 
      throw new FolderClosedException(this, 
          "Lost folder connection to server");
    } 
  }
  
  private void checkRange(int paramInt) throws MessagingException {
    if (paramInt < 1)
      throw new IndexOutOfBoundsException(); 
    if (paramInt <= this.total)
      return; 
    synchronized (this.messageCacheLock) {
      try {
        this.protocol.noop();
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(this, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
    } 
    if (paramInt > this.total)
      throw new IndexOutOfBoundsException(); 
  }
  
  private void checkFlags(Flags paramFlags) throws MessagingException {
    if (this.mode != 2)
      throw new IllegalStateException(
          "Cannot change flags on READ_ONLY folder: " + this.fullName); 
    if (!this.availableFlags.contains(paramFlags))
      throw new MessagingException(
          "These flags are not supported by this implementation"); 
  }
  
  public String getName() {
    if (this.name == null)
      try {
        this.name = this.fullName.substring(
            this.fullName.lastIndexOf(getSeparator()) + 1);
      } catch (MessagingException messagingException) {} 
    return this.name;
  }
  
  public String getFullName() { return this.fullName; }
  
  public Folder getParent() throws MessagingException {
    char c = getSeparator();
    int i;
    if ((i = this.fullName.lastIndexOf(c)) != -1)
      return new IMAPFolder(this.fullName.substring(0, i), 
          c, (IMAPStore)this.store); 
    return new DefaultFolder((IMAPStore)this.store);
  }
  
  public boolean exists() throws MessagingException {
    ListInfo[] arrayOfListInfo = null;
    try {
      arrayOfListInfo = storeProtocol().list("", this.fullName);
    } catch (ConnectionException connectionException) {
      throw new StoreClosedException(this.store, connectionException.getMessage());
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
    if (arrayOfListInfo != null) {
      this.fullName = (arrayOfListInfo[0]).name;
      this.separator = (arrayOfListInfo[0]).separator;
      if ((arrayOfListInfo[0]).hasInferiors)
        this.type |= 0x2; 
      if ((arrayOfListInfo[0]).canOpen)
        this.type |= 0x1; 
      this.exists = true;
    } else {
      this.exists = false;
    } 
    return this.exists;
  }
  
  public Folder[] list(String paramString) throws MessagingException { return doList(paramString, false); }
  
  public Folder[] listSubscribed(String paramString) throws MessagingException { return doList(paramString, true); }
  
  private Folder[] doList(String paramString, boolean paramBoolean) throws MessagingException {
    checkExists();
    if (!isDirectory())
      return new Folder[0]; 
    ListInfo[] arrayOfListInfo = null;
    char c = getSeparator();
    try {
      if (paramBoolean) {
        arrayOfListInfo = storeProtocol().lsub("", String.valueOf(this.fullName) + c + paramString);
      } else {
        arrayOfListInfo = storeProtocol().list("", String.valueOf(this.fullName) + c + paramString);
      } 
    } catch (CommandFailedException commandFailedException) {
    
    } catch (ConnectionException connectionException) {
      throw new StoreClosedException(this.store, connectionException.getMessage());
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
    if (arrayOfListInfo == null)
      return new Folder[0]; 
    int i = 0;
    if ((arrayOfListInfo[0]).name.equals(String.valueOf(this.fullName) + c))
      i = 1; 
    IMAPFolder[] arrayOfIMAPFolder = new IMAPFolder[arrayOfListInfo.length - i];
    for (int j = i; j < arrayOfListInfo.length; j++)
      arrayOfIMAPFolder[j - i] = new IMAPFolder(arrayOfListInfo[j], (IMAPStore)this.store); 
    return arrayOfIMAPFolder;
  }
  
  public char getSeparator() throws MessagingException {
    if (this.separator == Character.MAX_VALUE) {
      ListInfo[] arrayOfListInfo = null;
      try {
        IMAPProtocol iMAPProtocol = storeProtocol();
        if (iMAPProtocol.isREV1()) {
          arrayOfListInfo = iMAPProtocol.list(this.fullName, "");
        } else {
          arrayOfListInfo = iMAPProtocol.list("", this.fullName);
        } 
      } catch (ConnectionException connectionException) {
        throw new StoreClosedException(this.store, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
      if (arrayOfListInfo != null) {
        this.separator = (arrayOfListInfo[0]).separator;
      } else {
        this.separator = '/';
      } 
    } 
    return this.separator;
  }
  
  public int getType() throws MessagingException {
    checkExists();
    return this.type;
  }
  
  public boolean isSubscribed() throws MessagingException {
    ListInfo[] arrayOfListInfo = null;
    try {
      arrayOfListInfo = storeProtocol().lsub("", this.fullName);
    } catch (ProtocolException protocolException) {}
    if (arrayOfListInfo != null)
      return true; 
    return false;
  }
  
  public void setSubscribed(boolean paramBoolean) throws MessagingException {
    checkExists();
    try {
      if (paramBoolean) {
        storeProtocol().subscribe(this.fullName);
        return;
      } 
      storeProtocol().unsubscribe(this.fullName);
      return;
    } catch (CommandFailedException commandFailedException) {
      return;
    } catch (ConnectionException connectionException) {
      throw new StoreClosedException(this.store, connectionException.getMessage());
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
  }
  
  public boolean create(int paramInt) throws MessagingException {
    try {
      if ((paramInt & true) == 0) {
        storeProtocol().create(String.valueOf(this.fullName) + getSeparator());
      } else {
        storeProtocol().create(this.fullName);
        if ((paramInt & 0x2) != 0) {
          ListInfo[] arrayOfListInfo = storeProtocol().list("", this.fullName);
          if (arrayOfListInfo != null && !(arrayOfListInfo[0]).hasInferiors) {
            storeProtocol().delete(this.fullName);
            throw new MessagingException("Unsupported type");
          } 
        } 
      } 
    } catch (CommandFailedException commandFailedException) {
      return false;
    } catch (ConnectionException connectionException) {
      throw new StoreClosedException(this.store, connectionException.getMessage());
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
    this.exists = true;
    this.type = paramInt;
    notifyFolderListeners(1);
    return true;
  }
  
  public boolean hasNewMessages() throws MessagingException {
    checkExists();
    if (this.opened)
      return (this.recent > 0); 
    try {
      ListInfo[] arrayOfListInfo = storeProtocol().list("", this.fullName);
      if (arrayOfListInfo != null) {
        if ((arrayOfListInfo[0]).changeState == 1)
          return true; 
        if ((arrayOfListInfo[0]).changeState == 2)
          return false; 
      } 
      Status status = storeProtocol().status(this.fullName, null);
      if (status.recent > 0)
        return true; 
      return false;
    } catch (BadCommandException badCommandException) {
      return false;
    } catch (ConnectionException connectionException) {
      throw new StoreClosedException(this.store, connectionException.getMessage());
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
  }
  
  public Folder getFolder(String paramString) throws MessagingException {
    if (this.exists && !isDirectory())
      throw new MessagingException("Cannot contain subfolders"); 
    char c = getSeparator();
    return new IMAPFolder(String.valueOf(this.fullName) + c + paramString, c, (IMAPStore)this.store);
  }
  
  public boolean delete(boolean paramBoolean) throws MessagingException {
    checkClosed();
    if (paramBoolean) {
      Folder[] arrayOfFolder = list();
      for (byte b = 0; b < arrayOfFolder.length; b++)
        arrayOfFolder[b].delete(paramBoolean); 
    } 
    try {
      storeProtocol().delete(this.fullName);
      this.exists = false;
      notifyFolderListeners(2);
      return true;
    } catch (CommandFailedException commandFailedException) {
      return false;
    } catch (ConnectionException connectionException) {
      throw new StoreClosedException(this.store, connectionException.getMessage());
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
  }
  
  public boolean renameTo(Folder paramFolder) throws MessagingException {
    checkClosed();
    if (paramFolder.getStore() != this.store)
      throw new MessagingException("Can't rename across Stores"); 
    try {
      storeProtocol().rename(this.fullName, paramFolder.getFullName());
    } catch (CommandFailedException commandFailedException) {
      return false;
    } catch (ConnectionException connectionException) {
      throw new StoreClosedException(this.store, connectionException.getMessage());
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
    notifyFolderRenamedListeners(paramFolder);
    return true;
  }
  
  public void open(int paramInt) throws MessagingException {
    checkExists();
    checkClosed();
    if ((this.type & true) == 0)
      throw new MessagingException("folder cannot contain messages"); 
    MailboxInfo mailboxInfo = null;
    this.protocol = ((IMAPStore)this.store).getProtocol(this);
    synchronized (this.messageCacheLock) {
      try {
        if (paramInt == 1) {
          mailboxInfo = this.protocol.examine(this.fullName);
        } else {
          mailboxInfo = this.protocol.select(this.fullName);
        } 
      } catch (ProtocolException protocolException) {
        openFailure(protocolException.getMessage(), protocolException);
      } 
      if (mailboxInfo.mode != paramInt)
        openFailure("Cannot open in desired mode", null); 
      this.opened = true;
      this.reallyClosed = false;
      this.mode = mailboxInfo.mode;
      this.availableFlags = mailboxInfo.availableFlags;
      this.permanentFlags = mailboxInfo.permanentFlags;
      this.total = this.realTotal = mailboxInfo.total;
      this.recent = mailboxInfo.recent;
      this.uidvalidity = mailboxInfo.uidvalidity;
      this.protocol.addResponseHandler(this);
      this.messageCache = new Vector(this.total);
      for (byte b = 0; b < this.total; b++)
        this.messageCache.addElement(new IMAPMessage(this, b + true, b + true)); 
    } 
    notifyConnectionListeners(1);
  }
  
  public void fetch(Message[] paramArrayOfMessage, FetchProfile paramFetchProfile) throws MessagingException {
    checkOpened();
    IMAPMessage.fetch(this, paramArrayOfMessage, paramFetchProfile);
  }
  
  public void setFlags(Message[] paramArrayOfMessage, Flags paramFlags, boolean paramBoolean) throws MessagingException {
    checkOpened();
    checkFlags(paramFlags);
    if (paramArrayOfMessage.length == 0)
      return; 
    synchronized (this.messageCacheLock) {
      try {
        this.protocol.storeFlags(Utility.toMessageSet(paramArrayOfMessage, null), 
            paramFlags, paramBoolean);
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(this, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
      return;
    } 
  }
  
  private void openFailure(String paramString, Exception paramException) throws MessagingException {
    synchronized (this.messageCacheLock) {
      try {
        this.protocol.logout();
      } catch (ProtocolException protocolException) {}
    } 
    this.protocol = null;
    if (paramException != null)
      throw new MessagingException(paramString, paramException); 
    throw new MessagingException(paramString);
  }
  
  public void close(boolean paramBoolean) throws MessagingException {
    synchronized (this.messageCacheLock) {
      this.reallyClosed = true;
      if (!this.opened)
        return; 
      try {
        if (paramBoolean)
          this.protocol.close(); 
        this.protocol.logout();
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } finally {
        cleanup();
      } 
      return;
    } 
  }
  
  private void cleanup() throws MessagingException {
    this.protocol = null;
    this.messageCache = null;
    this.exists = false;
    this.opened = false;
    notifyConnectionListeners(3);
  }
  
  public boolean isOpen() throws MessagingException {
    if (this.opened)
      synchronized (this.messageCacheLock) {
        if (!this.opened)
          return false; 
        try {
          this.protocol.noop();
        } catch (ProtocolException protocolException) {}
      }  
    return this.opened;
  }
  
  public Flags getPermanentFlags() { return this.permanentFlags; }
  
  public int getMessageCount() throws MessagingException {
    checkExists();
    if (!this.opened)
      try {
        Status status = storeProtocol().status(this.fullName, null);
        return status.total;
      } catch (BadCommandException badCommandException) {
        try {
          MailboxInfo mailboxInfo = storeProtocol().examine(this.fullName);
          storeProtocol().close();
          return mailboxInfo.total;
        } catch (ProtocolException protocolException) {
          throw new MessagingException(protocolException.getMessage(), protocolException);
        } 
      } catch (ConnectionException connectionException) {
        throw new StoreClosedException(this.store, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      }  
    synchronized (this.messageCacheLock) {
      this.protocol.noop();
      storeProtocol().noop();
      return this.total;
    } 
  }
  
  public int getNewMessageCount() throws MessagingException {
    checkExists();
    if (!this.opened)
      try {
        Status status = storeProtocol().status(this.fullName, null);
        return status.recent;
      } catch (BadCommandException badCommandException) {
        try {
          MailboxInfo mailboxInfo = storeProtocol().examine(this.fullName);
          storeProtocol().close();
          return mailboxInfo.recent;
        } catch (ProtocolException protocolException) {
          throw new MessagingException(protocolException.getMessage(), protocolException);
        } 
      } catch (ConnectionException connectionException) {
        throw new StoreClosedException(this.store, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      }  
    synchronized (this.messageCacheLock) {
      this.protocol.noop();
      storeProtocol().noop();
      return this.recent;
    } 
  }
  
  public int getUnreadMessageCount() throws MessagingException {
    checkExists();
    if (!this.opened)
      try {
        Status status = storeProtocol().status(this.fullName, null);
        return status.unseen;
      } catch (BadCommandException badCommandException) {
        return -1;
      } catch (ConnectionException connectionException) {
        throw new StoreClosedException(this.store, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      }  
    Flags flags = new Flags();
    flags.add(Flags.Flag.SEEN);
    try {
      synchronized (this.messageCacheLock) {
        int[] arrayOfInt = this.protocol.search(new FlagTerm(flags, false));
        return arrayOfInt.length;
      } 
    } catch (ConnectionException connectionException) {
      throw new FolderClosedException(this, connectionException.getMessage());
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
  }
  
  public Message getMessage(int paramInt) throws MessagingException {
    checkOpened();
    checkRange(paramInt);
    return (Message)this.messageCache.elementAt(paramInt - 1);
  }
  
  public void appendMessages(Message[] paramArrayOfMessage) throws MessagingException {
    checkExists();
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    CRLFOutputStream cRLFOutputStream = new CRLFOutputStream(byteArrayOutputStream);
    IMAPProtocol iMAPProtocol = storeProtocol();
    for (byte b = 0; b < paramArrayOfMessage.length; b++) {
      Message message = paramArrayOfMessage[b];
      try {
        message.writeTo(cRLFOutputStream);
      } catch (IOException iOException) {
        throw new MessagingException(
            "IOException while appending messages", iOException);
      } catch (MessageRemovedException messageRemovedException) {}
      synchronized (this.messageCacheLock) {
        try {
          Date date = message.getReceivedDate();
          if (date == null)
            date = message.getSentDate(); 
          iMAPProtocol.append(this.fullName, date, byteArrayOutputStream);
        } catch (ConnectionException connectionException) {
          throw new StoreClosedException(this.store, connectionException.getMessage());
        } catch (ProtocolException protocolException) {
          throw new MessagingException(protocolException.getMessage(), protocolException);
        } 
      } 
      byteArrayOutputStream.reset();
    } 
  }
  
  public void copyMessages(Message[] paramArrayOfMessage, Folder paramFolder) throws MessagingException {
    checkOpened();
    if (paramArrayOfMessage.length == 0)
      return; 
    if (paramFolder.getStore() == this.store)
      synchronized (this.messageCacheLock) {
        try {
          this.protocol.copy(Utility.toMessageSet(paramArrayOfMessage, null), 
              paramFolder.getFullName());
        } catch (CommandFailedException commandFailedException) {
          if (commandFailedException.getMessage().indexOf("TRYCREATE") != -1)
            throw new FolderNotFoundException(
                String.valueOf(paramFolder.getFullName()) + " does not exist", 
                paramFolder); 
          throw new MessagingException(commandFailedException.getMessage(), commandFailedException);
        } catch (ConnectionException connectionException) {
          throw new FolderClosedException(this, connectionException.getMessage());
        } catch (ProtocolException protocolException) {
          throw new MessagingException(protocolException.getMessage(), protocolException);
        } 
        return;
      }  
    super.copyMessages(paramArrayOfMessage, paramFolder);
  }
  
  public Message[] expunge() throws MessagingException {
    checkOpened();
    Vector vector = new Vector();
    synchronized (this.messageCacheLock) {
      this.doExpungeNotification = false;
      try {
        this.protocol.expunge();
      } catch (CommandFailedException commandFailedException) {
      
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(this, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } finally {
        this.doExpungeNotification = true;
      } 
      for (byte b = 0; b < this.messageCache.size(); ) {
        IMAPMessage iMAPMessage = (IMAPMessage)this.messageCache.elementAt(b);
        if (iMAPMessage.isExpunged()) {
          vector.addElement(iMAPMessage);
          this.messageCache.removeElementAt(b);
          if (this.uidTable != null) {
            long l = iMAPMessage.getUID();
            if (l != -1L)
              this.uidTable.remove(new Long(l)); 
          } 
          continue;
        } 
        iMAPMessage.setMessageNumber(iMAPMessage.getSequenceNumber());
        b++;
      } 
    } 
    this.total = this.messageCache.size();
    Message[] arrayOfMessage = new Message[vector.size()];
    vector.copyInto(arrayOfMessage);
    if (arrayOfMessage.length > 0)
      notifyMessageRemovedListeners(true, arrayOfMessage); 
    return arrayOfMessage;
  }
  
  public Message[] search(SearchTerm paramSearchTerm) throws MessagingException {
    checkOpened();
    try {
      IMAPMessage[] arrayOfIMAPMessage = null;
      synchronized (this.messageCacheLock) {
        int[] arrayOfInt = this.protocol.search(paramSearchTerm);
        if (arrayOfInt != null) {
          arrayOfIMAPMessage = new IMAPMessage[arrayOfInt.length];
          for (byte b = 0; b < arrayOfInt.length; b++)
            arrayOfIMAPMessage[b] = getMessageBySeqNumber(arrayOfInt[b]); 
        } 
      } 
      return arrayOfIMAPMessage;
    } catch (CommandFailedException commandFailedException) {
      return super.search(paramSearchTerm);
    } catch (SearchException searchException) {
      return super.search(paramSearchTerm);
    } catch (ConnectionException connectionException) {
      throw new FolderClosedException(this, connectionException.getMessage());
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
  }
  
  public Message[] search(SearchTerm paramSearchTerm, Message[] paramArrayOfMessage) throws MessagingException {
    checkOpened();
    if (paramArrayOfMessage.length == 0)
      return paramArrayOfMessage; 
    try {
      IMAPMessage[] arrayOfIMAPMessage = null;
      synchronized (this.messageCacheLock) {
        int[] arrayOfInt = this.protocol.search(
            Utility.toMessageSet(paramArrayOfMessage, null), 
            paramSearchTerm);
        if (arrayOfInt != null) {
          arrayOfIMAPMessage = new IMAPMessage[arrayOfInt.length];
          for (byte b = 0; b < arrayOfInt.length; b++)
            arrayOfIMAPMessage[b] = getMessageBySeqNumber(arrayOfInt[b]); 
        } 
      } 
      return arrayOfIMAPMessage;
    } catch (CommandFailedException commandFailedException) {
      return super.search(paramSearchTerm, paramArrayOfMessage);
    } catch (SearchException searchException) {
      return super.search(paramSearchTerm, paramArrayOfMessage);
    } catch (ConnectionException connectionException) {
      throw new FolderClosedException(this, connectionException.getMessage());
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
  }
  
  public long getUIDValidity() throws MessagingException {
    if (this.opened)
      return this.uidvalidity; 
    try {
      String[] arrayOfString = { "UIDVALIDITY" };
      Status status = storeProtocol().status(this.fullName, arrayOfString);
      return status.uidvalidity;
    } catch (BadCommandException badCommandException) {
      throw new MessagingException("Cannot obtain UIDValidity", badCommandException);
    } catch (ConnectionException connectionException) {
      throw new StoreClosedException(this.store, connectionException.getMessage());
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
  }
  
  public Message getMessageByUID(long paramLong) throws MessagingException {
    checkOpened();
    Long long = new Long(paramLong);
    IMAPMessage iMAPMessage = null;
    if (this.uidTable != null) {
      iMAPMessage = (IMAPMessage)this.uidTable.get(long);
      if (iMAPMessage != null)
        return iMAPMessage; 
    } else {
      this.uidTable = new Hashtable();
    } 
    try {
      synchronized (this.messageCacheLock) {
        UID uID = this.protocol.fetchSequenceNumber(paramLong);
        if (uID != null) {
          iMAPMessage = (IMAPMessage)this.messageCache.elementAt(uID.msgno - 1);
          iMAPMessage.setUID(uID.uid);
          this.uidTable.put(long, iMAPMessage);
        } 
      } 
    } catch (ConnectionException connectionException) {
      throw new FolderClosedException(this, connectionException.getMessage());
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
    return iMAPMessage;
  }
  
  public Message[] getMessagesByUID(long paramLong1, long paramLong2) throws MessagingException {
    Message[] arrayOfMessage;
    checkOpened();
    if (this.uidTable == null)
      this.uidTable = new Hashtable(); 
    try {
      synchronized (this.messageCacheLock) {
        UID[] arrayOfUID = this.protocol.fetchSequenceNumbers(paramLong1, paramLong2);
        arrayOfMessage = new Message[arrayOfUID.length];
        for (byte b = 0; b < arrayOfUID.length; b++) {
          IMAPMessage iMAPMessage = (IMAPMessage)this.messageCache.elementAt((arrayOfUID[b]).msgno - 1);
          iMAPMessage.setUID((arrayOfUID[b]).uid);
          arrayOfMessage[b] = iMAPMessage;
          this.uidTable.put(new Long((arrayOfUID[b]).uid), iMAPMessage);
        } 
      } 
    } catch (ConnectionException connectionException) {
      throw new FolderClosedException(this, connectionException.getMessage());
    } catch (ProtocolException protocolException) {
      throw new MessagingException(protocolException.getMessage(), protocolException);
    } 
    return arrayOfMessage;
  }
  
  public Message[] getMessagesByUID(long[] paramArrayOfLong) throws MessagingException {
    checkOpened();
    long[] arrayOfLong = paramArrayOfLong;
    if (this.uidTable != null) {
      Vector vector = new Vector();
      for (byte b1 = 0; b1 < paramArrayOfLong.length; b1++) {
        Long long;
        if (!this.uidTable.containsKey(long = new Long(paramArrayOfLong[b1])))
          vector.addElement(long); 
      } 
      int i = vector.size();
      arrayOfLong = new long[i];
      for (byte b2 = 0; b2 < i; b2++)
        arrayOfLong[b2] = ((Long)vector.elementAt(b2)).longValue(); 
    } else {
      this.uidTable = new Hashtable();
    } 
    if (arrayOfLong.length > 0)
      try {
        synchronized (this.messageCacheLock) {
          UID[] arrayOfUID = this.protocol.fetchSequenceNumbers(arrayOfLong);
          for (byte b1 = 0; b1 < arrayOfUID.length; b1++) {
            IMAPMessage iMAPMessage = (IMAPMessage)this.messageCache.elementAt((arrayOfUID[b1]).msgno - 1);
            iMAPMessage.setUID((arrayOfUID[b1]).uid);
            this.uidTable.put(new Long((arrayOfUID[b1]).uid), iMAPMessage);
          } 
        } 
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(this, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      }  
    Message[] arrayOfMessage = new Message[paramArrayOfLong.length];
    for (byte b = 0; b < paramArrayOfLong.length; b++)
      arrayOfMessage[b] = (Message)this.uidTable.get(new Long(paramArrayOfLong[b])); 
    return arrayOfMessage;
  }
  
  public long getUID(Message paramMessage) throws MessagingException {
    if (paramMessage.getFolder() != this)
      throw new NoSuchElementException(
          "Message does not belong to this folder"); 
    checkOpened();
    IMAPMessage iMAPMessage = (IMAPMessage)paramMessage;
    long l;
    if ((l = iMAPMessage.getUID()) != -1L)
      return l; 
    UID uID = null;
    synchronized (this.messageCacheLock) {
      iMAPMessage.checkExpunged();
      try {
        uID = this.protocol.fetchUID(iMAPMessage.getSequenceNumber());
      } catch (ConnectionException connectionException) {
        throw new FolderClosedException(this, connectionException.getMessage());
      } catch (ProtocolException protocolException) {
        throw new MessagingException(protocolException.getMessage(), protocolException);
      } 
    } 
    if (uID != null) {
      l = uID.uid;
      iMAPMessage.setUID(l);
      if (this.uidTable == null)
        this.uidTable = new Hashtable(); 
      this.uidTable.put(new Long(l), iMAPMessage);
    } 
    return l;
  }
  
  public void handleResponse(Response paramResponse) {
    if (paramResponse.isBYE()) {
      if (this.opened)
        cleanup(); 
      return;
    } 
    if (paramResponse.isOK()) {
      ((IMAPStore)this.store).handleResponse(paramResponse);
      return;
    } 
    if (!(paramResponse instanceof IMAPResponse)) {
      System.out.println("UNEXPECTED RESPONSE : " + paramResponse.toString());
      System.out.println("CONTACT javamail@sun.com");
      return;
    } 
    IMAPResponse iMAPResponse = (IMAPResponse)paramResponse;
    if (iMAPResponse.keyEquals("EXISTS")) {
      int i = iMAPResponse.getNumber();
      if (i <= this.realTotal)
        return; 
      int j = i - this.realTotal;
      Message[] arrayOfMessage = new Message[j];
      for (byte b = 0; b < j; b++) {
        IMAPMessage iMAPMessage = new IMAPMessage(this, ++this.total, ++this.realTotal);
        arrayOfMessage[b] = iMAPMessage;
        this.messageCache.addElement(iMAPMessage);
      } 
      notifyMessageAddedListeners(arrayOfMessage);
      return;
    } 
    if (iMAPResponse.keyEquals("EXPUNGE")) {
      IMAPMessage iMAPMessage = getMessageBySeqNumber(iMAPResponse.getNumber());
      iMAPMessage.setExpunged(true);
      for (int i = iMAPMessage.getMessageNumber(); i < this.total; i++) {
        IMAPMessage iMAPMessage1 = (IMAPMessage)this.messageCache.elementAt(i);
        if (!iMAPMessage1.isExpunged())
          iMAPMessage1.setSequenceNumber(iMAPMessage1.getSequenceNumber() - 1); 
      } 
      this.realTotal--;
      if (this.doExpungeNotification) {
        Message[] arrayOfMessage = { iMAPMessage };
        notifyMessageRemovedListeners(false, arrayOfMessage);
        return;
      } 
    } else if (iMAPResponse.keyEquals("FETCH")) {
      FetchResponse fetchResponse = (FetchResponse)iMAPResponse;
      Flags flags = (Flags)fetchResponse.getItem(Flags.class);
      if (flags != null) {
        IMAPMessage iMAPMessage = getMessageBySeqNumber(fetchResponse.getNumber());
        iMAPMessage._setFlags(flags);
        notifyMessageChangedListeners(
            1, iMAPMessage);
        return;
      } 
    } else if (iMAPResponse.keyEquals("RECENT")) {
      this.recent = iMAPResponse.getNumber();
    } 
  }
  
  void handleResponses(Response[] paramArrayOfResponse) {
    for (byte b = 0; b < paramArrayOfResponse.length; b++) {
      if (paramArrayOfResponse[b] != null)
        handleResponse(paramArrayOfResponse[b]); 
    } 
  }
  
  IMAPProtocol storeProtocol() { return ((IMAPStore)this.store).getProtocol(); }
  
  IMAPMessage getMessageBySeqNumber(int paramInt) {
    for (int i = paramInt - 1; i < this.total; i++) {
      IMAPMessage iMAPMessage = (IMAPMessage)this.messageCache.elementAt(i);
      if (iMAPMessage.getSequenceNumber() == paramInt)
        return iMAPMessage; 
    } 
    return null;
  }
  
  private boolean isDirectory() throws MessagingException { return !((this.type & 0x2) == 0); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\IMAPFolder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */