/*      */ package com.sun.mail.imap;
/*      */ 
/*      */ import com.sun.mail.iap.BadCommandException;
/*      */ import com.sun.mail.iap.CommandFailedException;
/*      */ import com.sun.mail.iap.ConnectionException;
/*      */ import com.sun.mail.iap.ProtocolException;
/*      */ import com.sun.mail.iap.Response;
/*      */ import com.sun.mail.iap.ResponseHandler;
/*      */ import com.sun.mail.imap.protocol.FetchResponse;
/*      */ import com.sun.mail.imap.protocol.IMAPProtocol;
/*      */ import com.sun.mail.imap.protocol.IMAPResponse;
/*      */ import com.sun.mail.imap.protocol.ListInfo;
/*      */ import com.sun.mail.imap.protocol.MailboxInfo;
/*      */ import com.sun.mail.imap.protocol.Status;
/*      */ import com.sun.mail.imap.protocol.UID;
/*      */ import com.sun.mail.util.CRLFOutputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.util.Date;
/*      */ import java.util.Hashtable;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Vector;
/*      */ import javax.mail.FetchProfile;
/*      */ import javax.mail.Flags;
/*      */ import javax.mail.Folder;
/*      */ import javax.mail.FolderClosedException;
/*      */ import javax.mail.FolderNotFoundException;
/*      */ import javax.mail.Message;
/*      */ import javax.mail.MessageRemovedException;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.StoreClosedException;
/*      */ import javax.mail.UIDFolder;
/*      */ import javax.mail.search.FlagTerm;
/*      */ import javax.mail.search.SearchException;
/*      */ import javax.mail.search.SearchTerm;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class IMAPFolder
/*      */   extends Folder
/*      */   implements UIDFolder, ResponseHandler
/*      */ {
/*      */   protected String fullName;
/*      */   protected String name;
/*      */   protected int type;
/*      */   protected char separator;
/*      */   protected Flags availableFlags;
/*      */   protected Flags permanentFlags;
/*      */   protected boolean exists = false;
/*      */   protected IMAPProtocol protocol;
/*      */   protected Vector messageCache;
/*      */   protected Object messageCacheLock;
/*      */   protected Hashtable uidTable;
/*      */   protected static final char UNKNOWN_SEPARATOR = '￿';
/*      */   private boolean opened = false;
/*      */   private boolean reallyClosed = true;
/*  113 */   private int total = -1;
/*      */   
/*  115 */   private int recent = -1;
/*  116 */   private int realTotal = -1;
/*      */   
/*  118 */   private int uidvalidity = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean doExpungeNotification = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IMAPFolder(String paramString, char paramChar, IMAPStore paramIMAPStore) {
/*  130 */     super(paramIMAPStore);
/*  131 */     this.fullName = paramString;
/*  132 */     this.separator = paramChar;
/*  133 */     this.messageCacheLock = new Object();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IMAPFolder(ListInfo paramListInfo, IMAPStore paramIMAPStore) {
/*  140 */     this(paramListInfo.name, paramListInfo.separator, paramIMAPStore);
/*      */     
/*  142 */     if (paramListInfo.hasInferiors)
/*  143 */       this.type |= 0x2; 
/*  144 */     if (paramListInfo.canOpen)
/*  145 */       this.type |= 0x1; 
/*  146 */     this.exists = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkExists() throws MessagingException {
/*  156 */     if (!this.exists && !exists()) {
/*  157 */       throw new FolderNotFoundException(
/*  158 */           String.valueOf(this.fullName) + " not found", this);
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkClosed() throws MessagingException {
/*  163 */     if (this.opened) {
/*  164 */       throw new IllegalStateException(
/*  165 */           "This operation is not allowed on an open folder");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkOpened() throws MessagingException {
/*  171 */     if (!this.opened) {
/*  172 */       if (this.reallyClosed) {
/*  173 */         throw new IllegalStateException(
/*  174 */             "This operation is not allowed on a closed folder");
/*      */       }
/*      */       
/*  177 */       throw new FolderClosedException(this, 
/*  178 */           "Lost folder connection to server");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkRange(int paramInt) throws MessagingException {
/*  189 */     if (paramInt < 1) {
/*  190 */       throw new IndexOutOfBoundsException();
/*      */     }
/*  192 */     if (paramInt <= this.total) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  198 */     synchronized (this.messageCacheLock) {
/*      */       try {
/*  200 */         this.protocol.noop();
/*  201 */       } catch (ConnectionException connectionException) {
/*      */         
/*  203 */         throw new FolderClosedException(this, connectionException.getMessage());
/*  204 */       } catch (ProtocolException protocolException) {
/*  205 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */     } 
/*      */     
/*  209 */     if (paramInt > this.total) {
/*  210 */       throw new IndexOutOfBoundsException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkFlags(Flags paramFlags) throws MessagingException {
/*  217 */     if (this.mode != 2) {
/*  218 */       throw new IllegalStateException(
/*  219 */           "Cannot change flags on READ_ONLY folder: " + this.fullName);
/*      */     }
/*  221 */     if (!this.availableFlags.contains(paramFlags)) {
/*  222 */       throw new MessagingException(
/*  223 */           "These flags are not supported by this implementation");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  234 */     if (this.name == null) {
/*      */       try {
/*  236 */         this.name = this.fullName.substring(
/*  237 */             this.fullName.lastIndexOf(getSeparator()) + 1);
/*      */       }
/*  239 */       catch (MessagingException messagingException) {}
/*      */     }
/*  241 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  248 */   public String getFullName() { return this.fullName; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Folder getParent() throws MessagingException {
/*  255 */     char c = getSeparator();
/*      */     int i;
/*  257 */     if ((i = this.fullName.lastIndexOf(c)) != -1) {
/*  258 */       return new IMAPFolder(this.fullName.substring(0, i), 
/*  259 */           c, (IMAPStore)this.store);
/*      */     }
/*  261 */     return new DefaultFolder((IMAPStore)this.store);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean exists() throws MessagingException {
/*  269 */     ListInfo[] arrayOfListInfo = null;
/*      */     
/*      */     try {
/*  272 */       arrayOfListInfo = storeProtocol().list("", this.fullName);
/*  273 */     } catch (ConnectionException connectionException) {
/*      */       
/*  275 */       throw new StoreClosedException(this.store, connectionException.getMessage());
/*  276 */     } catch (ProtocolException protocolException) {
/*  277 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */     } 
/*      */     
/*  280 */     if (arrayOfListInfo != null) {
/*  281 */       this.fullName = (arrayOfListInfo[0]).name;
/*  282 */       this.separator = (arrayOfListInfo[0]).separator;
/*  283 */       if ((arrayOfListInfo[0]).hasInferiors)
/*  284 */         this.type |= 0x2; 
/*  285 */       if ((arrayOfListInfo[0]).canOpen)
/*  286 */         this.type |= 0x1; 
/*  287 */       this.exists = true;
/*      */     } else {
/*  289 */       this.exists = false;
/*      */     } 
/*  291 */     return this.exists;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  298 */   public Folder[] list(String paramString) throws MessagingException { return doList(paramString, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  305 */   public Folder[] listSubscribed(String paramString) throws MessagingException { return doList(paramString, true); }
/*      */ 
/*      */ 
/*      */   
/*      */   private Folder[] doList(String paramString, boolean paramBoolean) throws MessagingException {
/*  310 */     checkExists();
/*      */     
/*  312 */     if (!isDirectory()) {
/*  313 */       return new Folder[0];
/*      */     }
/*  315 */     ListInfo[] arrayOfListInfo = null;
/*  316 */     char c = getSeparator();
/*      */     
/*      */     try {
/*  319 */       if (paramBoolean)
/*  320 */       { arrayOfListInfo = storeProtocol().lsub("", String.valueOf(this.fullName) + c + paramString); }
/*      */       else
/*  322 */       { arrayOfListInfo = storeProtocol().list("", String.valueOf(this.fullName) + c + paramString); } 
/*  323 */     } catch (CommandFailedException commandFailedException) {
/*      */ 
/*      */     
/*  326 */     } catch (ConnectionException connectionException) {
/*      */       
/*  328 */       throw new StoreClosedException(this.store, connectionException.getMessage());
/*  329 */     } catch (ProtocolException protocolException) {
/*  330 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */     } 
/*      */     
/*  333 */     if (arrayOfListInfo == null) {
/*  334 */       return new Folder[0];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  347 */     int i = 0;
/*      */     
/*  349 */     if ((arrayOfListInfo[0]).name.equals(String.valueOf(this.fullName) + c)) {
/*  350 */       i = 1;
/*      */     }
/*  352 */     IMAPFolder[] arrayOfIMAPFolder = new IMAPFolder[arrayOfListInfo.length - i];
/*  353 */     for (int j = i; j < arrayOfListInfo.length; j++)
/*  354 */       arrayOfIMAPFolder[j - i] = new IMAPFolder(arrayOfListInfo[j], (IMAPStore)this.store); 
/*  355 */     return arrayOfIMAPFolder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char getSeparator() throws MessagingException {
/*  362 */     if (this.separator == Character.MAX_VALUE) {
/*  363 */       ListInfo[] arrayOfListInfo = null;
/*      */       
/*      */       try {
/*  366 */         IMAPProtocol iMAPProtocol = storeProtocol();
/*      */ 
/*      */         
/*  369 */         if (iMAPProtocol.isREV1())
/*  370 */         { arrayOfListInfo = iMAPProtocol.list(this.fullName, ""); }
/*      */         else
/*      */         
/*  373 */         { arrayOfListInfo = iMAPProtocol.list("", this.fullName); } 
/*  374 */       } catch (ConnectionException connectionException) {
/*      */         
/*  376 */         throw new StoreClosedException(this.store, connectionException.getMessage());
/*  377 */       } catch (ProtocolException protocolException) {
/*  378 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */       
/*  381 */       if (arrayOfListInfo != null) {
/*  382 */         this.separator = (arrayOfListInfo[0]).separator;
/*      */       } else {
/*  384 */         this.separator = '/';
/*      */       } 
/*  386 */     }  return this.separator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getType() throws MessagingException {
/*  393 */     checkExists();
/*  394 */     return this.type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSubscribed() throws MessagingException {
/*  403 */     ListInfo[] arrayOfListInfo = null;
/*      */     
/*      */     try {
/*  406 */       arrayOfListInfo = storeProtocol().lsub("", this.fullName);
/*  407 */     } catch (ProtocolException protocolException) {}
/*      */     
/*  409 */     if (arrayOfListInfo != null) {
/*  410 */       return true;
/*      */     }
/*  412 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubscribed(boolean paramBoolean) throws MessagingException {
/*  420 */     checkExists();
/*      */     
/*      */     try {
/*  423 */       if (paramBoolean) {
/*  424 */         storeProtocol().subscribe(this.fullName); return;
/*      */       } 
/*  426 */       storeProtocol().unsubscribe(this.fullName); return;
/*  427 */     } catch (CommandFailedException commandFailedException) {
/*      */       return;
/*  429 */     } catch (ConnectionException connectionException) {
/*  430 */       throw new StoreClosedException(this.store, connectionException.getMessage());
/*  431 */     } catch (ProtocolException protocolException) {
/*  432 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean create(int paramInt) throws MessagingException {
/*      */     try {
/*  441 */       if ((paramInt & true) == 0) {
/*  442 */         storeProtocol().create(String.valueOf(this.fullName) + getSeparator());
/*      */       } else {
/*  444 */         storeProtocol().create(this.fullName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  450 */         if ((paramInt & 0x2) != 0) {
/*      */ 
/*      */           
/*  453 */           ListInfo[] arrayOfListInfo = storeProtocol().list("", this.fullName);
/*  454 */           if (arrayOfListInfo != null && !(arrayOfListInfo[0]).hasInferiors) {
/*      */             
/*  456 */             storeProtocol().delete(this.fullName);
/*  457 */             throw new MessagingException("Unsupported type");
/*      */           } 
/*      */         } 
/*      */       } 
/*  461 */     } catch (CommandFailedException commandFailedException) {
/*  462 */       return false;
/*      */     }
/*  464 */     catch (ConnectionException connectionException) {
/*  465 */       throw new StoreClosedException(this.store, connectionException.getMessage());
/*  466 */     } catch (ProtocolException protocolException) {
/*  467 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */     } 
/*      */     
/*  470 */     this.exists = true;
/*  471 */     this.type = paramInt;
/*      */     
/*  473 */     notifyFolderListeners(1);
/*  474 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasNewMessages() throws MessagingException {
/*  481 */     checkExists();
/*      */     
/*  483 */     if (this.opened) {
/*  484 */       return (this.recent > 0);
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  489 */       ListInfo[] arrayOfListInfo = storeProtocol().list("", this.fullName);
/*  490 */       if (arrayOfListInfo != null) {
/*  491 */         if ((arrayOfListInfo[0]).changeState == 1)
/*  492 */           return true; 
/*  493 */         if ((arrayOfListInfo[0]).changeState == 2) {
/*  494 */           return false;
/*      */         }
/*      */       } 
/*      */       
/*  498 */       Status status = storeProtocol().status(this.fullName, null);
/*  499 */       if (status.recent > 0) {
/*  500 */         return true;
/*      */       }
/*  502 */       return false;
/*  503 */     } catch (BadCommandException badCommandException) {
/*      */       
/*  505 */       return false;
/*  506 */     } catch (ConnectionException connectionException) {
/*  507 */       throw new StoreClosedException(this.store, connectionException.getMessage());
/*  508 */     } catch (ProtocolException protocolException) {
/*  509 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Folder getFolder(String paramString) throws MessagingException {
/*  523 */     if (this.exists && !isDirectory()) {
/*  524 */       throw new MessagingException("Cannot contain subfolders");
/*      */     }
/*  526 */     char c = getSeparator();
/*  527 */     return new IMAPFolder(String.valueOf(this.fullName) + c + paramString, c, (IMAPStore)this.store);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean delete(boolean paramBoolean) throws MessagingException {
/*  535 */     checkClosed();
/*      */     
/*  537 */     if (paramBoolean) {
/*      */       
/*  539 */       Folder[] arrayOfFolder = list();
/*  540 */       for (byte b = 0; b < arrayOfFolder.length; b++) {
/*  541 */         arrayOfFolder[b].delete(paramBoolean);
/*      */       }
/*      */     } 
/*      */     
/*      */     try {
/*  546 */       storeProtocol().delete(this.fullName);
/*      */ 
/*      */       
/*  549 */       this.exists = false;
/*      */ 
/*      */       
/*  552 */       notifyFolderListeners(2);
/*      */       
/*  554 */       return true;
/*  555 */     } catch (CommandFailedException commandFailedException) {
/*      */       
/*  557 */       return false;
/*  558 */     } catch (ConnectionException connectionException) {
/*  559 */       throw new StoreClosedException(this.store, connectionException.getMessage());
/*  560 */     } catch (ProtocolException protocolException) {
/*  561 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean renameTo(Folder paramFolder) throws MessagingException {
/*  569 */     checkClosed();
/*  570 */     if (paramFolder.getStore() != this.store) {
/*  571 */       throw new MessagingException("Can't rename across Stores");
/*      */     }
/*      */     try {
/*  574 */       storeProtocol().rename(this.fullName, paramFolder.getFullName());
/*  575 */     } catch (CommandFailedException commandFailedException) {
/*  576 */       return false;
/*  577 */     } catch (ConnectionException connectionException) {
/*  578 */       throw new StoreClosedException(this.store, connectionException.getMessage());
/*  579 */     } catch (ProtocolException protocolException) {
/*  580 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */     } 
/*      */     
/*  583 */     notifyFolderRenamedListeners(paramFolder);
/*  584 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void open(int paramInt) throws MessagingException {
/*  591 */     checkExists();
/*  592 */     checkClosed();
/*      */     
/*  594 */     if ((this.type & true) == 0) {
/*  595 */       throw new MessagingException("folder cannot contain messages");
/*      */     }
/*  597 */     MailboxInfo mailboxInfo = null;
/*      */     
/*  599 */     this.protocol = ((IMAPStore)this.store).getProtocol(this);
/*      */     
/*  601 */     synchronized (this.messageCacheLock) {
/*      */       
/*      */       try {
/*  604 */         if (paramInt == 1)
/*  605 */         { mailboxInfo = this.protocol.examine(this.fullName); }
/*      */         else
/*  607 */         { mailboxInfo = this.protocol.select(this.fullName); } 
/*  608 */       } catch (ProtocolException protocolException) {
/*  609 */         openFailure(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */       
/*  612 */       if (mailboxInfo.mode != paramInt) {
/*  613 */         openFailure("Cannot open in desired mode", null);
/*      */       }
/*      */       
/*  616 */       this.opened = true;
/*  617 */       this.reallyClosed = false;
/*  618 */       this.mode = mailboxInfo.mode;
/*  619 */       this.availableFlags = mailboxInfo.availableFlags;
/*  620 */       this.permanentFlags = mailboxInfo.permanentFlags;
/*  621 */       this.total = this.realTotal = mailboxInfo.total;
/*  622 */       this.recent = mailboxInfo.recent;
/*  623 */       this.uidvalidity = mailboxInfo.uidvalidity;
/*      */       
/*  625 */       this.protocol.addResponseHandler(this);
/*      */ 
/*      */       
/*  628 */       this.messageCache = new Vector(this.total);
/*      */       
/*  630 */       for (byte b = 0; b < this.total; b++) {
/*  631 */         this.messageCache.addElement(new IMAPMessage(this, b + true, b + true));
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  636 */     notifyConnectionListeners(1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fetch(Message[] paramArrayOfMessage, FetchProfile paramFetchProfile) throws MessagingException {
/*  644 */     checkOpened();
/*  645 */     IMAPMessage.fetch(this, paramArrayOfMessage, paramFetchProfile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFlags(Message[] paramArrayOfMessage, Flags paramFlags, boolean paramBoolean) throws MessagingException {
/*  653 */     checkOpened();
/*  654 */     checkFlags(paramFlags);
/*      */     
/*  656 */     if (paramArrayOfMessage.length == 0) {
/*      */       return;
/*      */     }
/*  659 */     synchronized (this.messageCacheLock) {
/*      */       try {
/*  661 */         this.protocol.storeFlags(Utility.toMessageSet(paramArrayOfMessage, null), 
/*  662 */             paramFlags, paramBoolean);
/*  663 */       } catch (ConnectionException connectionException) {
/*  664 */         throw new FolderClosedException(this, connectionException.getMessage());
/*  665 */       } catch (ProtocolException protocolException) {
/*  666 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void openFailure(String paramString, Exception paramException) throws MessagingException {
/*  674 */     synchronized (this.messageCacheLock) {
/*      */       try {
/*  676 */         this.protocol.logout();
/*  677 */       } catch (ProtocolException protocolException) {}
/*      */     } 
/*      */     
/*  680 */     this.protocol = null;
/*  681 */     if (paramException != null) {
/*  682 */       throw new MessagingException(paramString, paramException);
/*      */     }
/*  684 */     throw new MessagingException(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close(boolean paramBoolean) throws MessagingException {
/*  691 */     synchronized (this.messageCacheLock) {
/*  692 */       this.reallyClosed = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  698 */       if (!this.opened) {
/*      */         return;
/*      */       }
/*      */       try {
/*  702 */         if (paramBoolean)
/*  703 */           this.protocol.close(); 
/*  704 */         this.protocol.logout();
/*  705 */       } catch (ProtocolException protocolException) {
/*  706 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } finally {
/*      */         
/*  709 */         cleanup();
/*      */       } 
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void cleanup() throws MessagingException {
/*  720 */     this.protocol = null;
/*  721 */     this.messageCache = null;
/*  722 */     this.exists = false;
/*  723 */     this.opened = false;
/*  724 */     notifyConnectionListeners(3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOpen() throws MessagingException {
/*  731 */     if (this.opened)
/*      */     {
/*  733 */       synchronized (this.messageCacheLock) {
/*  734 */         if (!this.opened)
/*      */         {
/*      */           
/*  737 */           return false;
/*      */         }
/*      */         try {
/*  740 */           this.protocol.noop();
/*  741 */         } catch (ProtocolException protocolException) {}
/*      */       } 
/*      */     }
/*      */     
/*  745 */     return this.opened;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  752 */   public Flags getPermanentFlags() { return this.permanentFlags; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMessageCount() throws MessagingException {
/*  759 */     checkExists();
/*  760 */     if (!this.opened) {
/*      */       
/*      */       try {
/*      */         
/*  764 */         Status status = storeProtocol().status(this.fullName, null);
/*  765 */         return status.total;
/*  766 */       } catch (BadCommandException badCommandException) {
/*      */ 
/*      */         
/*      */         try {
/*  770 */           MailboxInfo mailboxInfo = storeProtocol().examine(this.fullName);
/*  771 */           storeProtocol().close();
/*  772 */           return mailboxInfo.total;
/*  773 */         } catch (ProtocolException protocolException) {
/*      */           
/*  775 */           throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */         } 
/*  777 */       } catch (ConnectionException connectionException) {
/*  778 */         throw new StoreClosedException(this.store, connectionException.getMessage());
/*  779 */       } catch (ProtocolException protocolException) {
/*  780 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  785 */     synchronized (this.messageCacheLock) {
/*      */ 
/*      */       
/*  788 */       this.protocol.noop();
/*  789 */       storeProtocol().noop();
/*  790 */       return this.total;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNewMessageCount() throws MessagingException {
/*  804 */     checkExists();
/*  805 */     if (!this.opened) {
/*      */       
/*      */       try {
/*      */         
/*  809 */         Status status = storeProtocol().status(this.fullName, null);
/*  810 */         return status.recent;
/*  811 */       } catch (BadCommandException badCommandException) {
/*      */ 
/*      */         
/*      */         try {
/*  815 */           MailboxInfo mailboxInfo = storeProtocol().examine(this.fullName);
/*  816 */           storeProtocol().close();
/*  817 */           return mailboxInfo.recent;
/*  818 */         } catch (ProtocolException protocolException) {
/*      */           
/*  820 */           throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */         } 
/*  822 */       } catch (ConnectionException connectionException) {
/*  823 */         throw new StoreClosedException(this.store, connectionException.getMessage());
/*  824 */       } catch (ProtocolException protocolException) {
/*  825 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  830 */     synchronized (this.messageCacheLock) {
/*      */ 
/*      */       
/*  833 */       this.protocol.noop();
/*  834 */       storeProtocol().noop();
/*  835 */       return this.recent;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUnreadMessageCount() throws MessagingException {
/*  849 */     checkExists();
/*  850 */     if (!this.opened) {
/*      */       
/*      */       try {
/*      */         
/*  854 */         Status status = storeProtocol().status(this.fullName, null);
/*  855 */         return status.unseen;
/*  856 */       } catch (BadCommandException badCommandException) {
/*      */ 
/*      */ 
/*      */         
/*  860 */         return -1;
/*  861 */       } catch (ConnectionException connectionException) {
/*  862 */         throw new StoreClosedException(this.store, connectionException.getMessage());
/*  863 */       } catch (ProtocolException protocolException) {
/*  864 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  870 */     Flags flags = new Flags();
/*  871 */     flags.add(Flags.Flag.SEEN);
/*      */     try {
/*  873 */       synchronized (this.messageCacheLock) {
/*  874 */         int[] arrayOfInt = this.protocol.search(new FlagTerm(flags, false));
/*  875 */         return arrayOfInt.length;
/*      */       } 
/*  877 */     } catch (ConnectionException connectionException) {
/*  878 */       throw new FolderClosedException(this, connectionException.getMessage());
/*  879 */     } catch (ProtocolException protocolException) {
/*      */       
/*  881 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Message getMessage(int paramInt) throws MessagingException {
/*  890 */     checkOpened();
/*  891 */     checkRange(paramInt);
/*      */     
/*  893 */     return (Message)this.messageCache.elementAt(paramInt - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void appendMessages(Message[] paramArrayOfMessage) throws MessagingException {
/*  900 */     checkExists();
/*      */     
/*  902 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*  903 */     CRLFOutputStream cRLFOutputStream = new CRLFOutputStream(byteArrayOutputStream);
/*  904 */     IMAPProtocol iMAPProtocol = storeProtocol();
/*      */     
/*  906 */     for (byte b = 0; b < paramArrayOfMessage.length; b++) {
/*  907 */       Message message = paramArrayOfMessage[b];
/*      */       
/*      */       try {
/*  910 */         message.writeTo(cRLFOutputStream);
/*  911 */       } catch (IOException iOException) {
/*  912 */         throw new MessagingException(
/*  913 */             "IOException while appending messages", iOException);
/*  914 */       } catch (MessageRemovedException messageRemovedException) {}
/*      */ 
/*      */ 
/*      */       
/*  918 */       synchronized (this.messageCacheLock) {
/*      */         try {
/*  920 */           Date date = message.getReceivedDate();
/*  921 */           if (date == null)
/*  922 */             date = message.getSentDate(); 
/*  923 */           iMAPProtocol.append(this.fullName, date, byteArrayOutputStream);
/*  924 */         } catch (ConnectionException connectionException) {
/*  925 */           throw new StoreClosedException(this.store, connectionException.getMessage());
/*  926 */         } catch (ProtocolException protocolException) {
/*  927 */           throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */         } 
/*      */       } 
/*      */       
/*  931 */       byteArrayOutputStream.reset();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyMessages(Message[] paramArrayOfMessage, Folder paramFolder) throws MessagingException {
/*  941 */     checkOpened();
/*      */     
/*  943 */     if (paramArrayOfMessage.length == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  947 */     if (paramFolder.getStore() == this.store)
/*  948 */       synchronized (this.messageCacheLock) {
/*      */         try {
/*  950 */           this.protocol.copy(Utility.toMessageSet(paramArrayOfMessage, null), 
/*  951 */               paramFolder.getFullName());
/*  952 */         } catch (CommandFailedException commandFailedException) {
/*  953 */           if (commandFailedException.getMessage().indexOf("TRYCREATE") != -1) {
/*  954 */             throw new FolderNotFoundException(
/*  955 */                 String.valueOf(paramFolder.getFullName()) + " does not exist", 
/*  956 */                 paramFolder);
/*      */           }
/*      */           
/*  959 */           throw new MessagingException(commandFailedException.getMessage(), commandFailedException);
/*  960 */         } catch (ConnectionException connectionException) {
/*  961 */           throw new FolderClosedException(this, connectionException.getMessage());
/*  962 */         } catch (ProtocolException protocolException) {
/*  963 */           throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */         } 
/*      */         return;
/*      */       }  
/*  967 */     super.copyMessages(paramArrayOfMessage, paramFolder);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Message[] expunge() throws MessagingException {
/*  974 */     checkOpened();
/*      */     
/*  976 */     Vector vector = new Vector();
/*      */     
/*  978 */     synchronized (this.messageCacheLock) {
/*  979 */       this.doExpungeNotification = false;
/*      */       try {
/*  981 */         this.protocol.expunge();
/*  982 */       } catch (CommandFailedException commandFailedException) {
/*      */ 
/*      */       
/*      */       }
/*  986 */       catch (ConnectionException connectionException) {
/*  987 */         throw new FolderClosedException(this, connectionException.getMessage());
/*  988 */       } catch (ProtocolException protocolException) {
/*      */         
/*  990 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } finally {
/*  992 */         this.doExpungeNotification = true;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  997 */       for (byte b = 0; b < this.messageCache.size(); ) {
/*  998 */         IMAPMessage iMAPMessage = (IMAPMessage)this.messageCache.elementAt(b);
/*  999 */         if (iMAPMessage.isExpunged()) {
/* 1000 */           vector.addElement(iMAPMessage);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1010 */           this.messageCache.removeElementAt(b);
/*      */ 
/*      */           
/* 1013 */           if (this.uidTable != null) {
/* 1014 */             long l = iMAPMessage.getUID();
/* 1015 */             if (l != -1L) {
/* 1016 */               this.uidTable.remove(new Long(l));
/*      */             }
/*      */           } 
/*      */           
/*      */           continue;
/*      */         } 
/* 1022 */         iMAPMessage.setMessageNumber(iMAPMessage.getSequenceNumber());
/* 1023 */         b++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1029 */     this.total = this.messageCache.size();
/*      */ 
/*      */     
/* 1032 */     Message[] arrayOfMessage = new Message[vector.size()];
/* 1033 */     vector.copyInto(arrayOfMessage);
/* 1034 */     if (arrayOfMessage.length > 0)
/* 1035 */       notifyMessageRemovedListeners(true, arrayOfMessage); 
/* 1036 */     return arrayOfMessage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Message[] search(SearchTerm paramSearchTerm) throws MessagingException {
/* 1043 */     checkOpened();
/*      */     
/*      */     try {
/* 1046 */       IMAPMessage[] arrayOfIMAPMessage = null;
/*      */       
/* 1048 */       synchronized (this.messageCacheLock) {
/* 1049 */         int[] arrayOfInt = this.protocol.search(paramSearchTerm);
/* 1050 */         if (arrayOfInt != null) {
/* 1051 */           arrayOfIMAPMessage = new IMAPMessage[arrayOfInt.length];
/*      */           
/* 1053 */           for (byte b = 0; b < arrayOfInt.length; b++)
/* 1054 */             arrayOfIMAPMessage[b] = getMessageBySeqNumber(arrayOfInt[b]); 
/*      */         } 
/*      */       } 
/* 1057 */       return arrayOfIMAPMessage;
/*      */     }
/* 1059 */     catch (CommandFailedException commandFailedException) {
/*      */       
/* 1061 */       return super.search(paramSearchTerm);
/* 1062 */     } catch (SearchException searchException) {
/*      */       
/* 1064 */       return super.search(paramSearchTerm);
/* 1065 */     } catch (ConnectionException connectionException) {
/* 1066 */       throw new FolderClosedException(this, connectionException.getMessage());
/* 1067 */     } catch (ProtocolException protocolException) {
/*      */       
/* 1069 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Message[] search(SearchTerm paramSearchTerm, Message[] paramArrayOfMessage) throws MessagingException {
/* 1080 */     checkOpened();
/*      */     
/* 1082 */     if (paramArrayOfMessage.length == 0)
/*      */     {
/* 1084 */       return paramArrayOfMessage;
/*      */     }
/*      */     try {
/* 1087 */       IMAPMessage[] arrayOfIMAPMessage = null;
/*      */       
/* 1089 */       synchronized (this.messageCacheLock) {
/* 1090 */         int[] arrayOfInt = this.protocol.search(
/* 1091 */             Utility.toMessageSet(paramArrayOfMessage, null), 
/* 1092 */             paramSearchTerm);
/*      */         
/* 1094 */         if (arrayOfInt != null) {
/* 1095 */           arrayOfIMAPMessage = new IMAPMessage[arrayOfInt.length];
/* 1096 */           for (byte b = 0; b < arrayOfInt.length; b++)
/* 1097 */             arrayOfIMAPMessage[b] = getMessageBySeqNumber(arrayOfInt[b]); 
/*      */         } 
/*      */       } 
/* 1100 */       return arrayOfIMAPMessage;
/*      */     }
/* 1102 */     catch (CommandFailedException commandFailedException) {
/*      */       
/* 1104 */       return super.search(paramSearchTerm, paramArrayOfMessage);
/* 1105 */     } catch (SearchException searchException) {
/*      */       
/* 1107 */       return super.search(paramSearchTerm, paramArrayOfMessage);
/* 1108 */     } catch (ConnectionException connectionException) {
/* 1109 */       throw new FolderClosedException(this, connectionException.getMessage());
/* 1110 */     } catch (ProtocolException protocolException) {
/*      */       
/* 1112 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getUIDValidity() throws MessagingException {
/* 1124 */     if (this.opened) {
/* 1125 */       return this.uidvalidity;
/*      */     }
/*      */     try {
/* 1128 */       String[] arrayOfString = { "UIDVALIDITY" };
/* 1129 */       Status status = storeProtocol().status(this.fullName, arrayOfString);
/* 1130 */       return status.uidvalidity;
/* 1131 */     } catch (BadCommandException badCommandException) {
/*      */       
/* 1133 */       throw new MessagingException("Cannot obtain UIDValidity", badCommandException);
/* 1134 */     } catch (ConnectionException connectionException) {
/* 1135 */       throw new StoreClosedException(this.store, connectionException.getMessage());
/* 1136 */     } catch (ProtocolException protocolException) {
/* 1137 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Message getMessageByUID(long paramLong) throws MessagingException {
/* 1147 */     checkOpened();
/*      */     
/* 1149 */     Long long = new Long(paramLong);
/* 1150 */     IMAPMessage iMAPMessage = null;
/*      */     
/* 1152 */     if (this.uidTable != null) {
/*      */       
/* 1154 */       iMAPMessage = (IMAPMessage)this.uidTable.get(long);
/* 1155 */       if (iMAPMessage != null)
/* 1156 */         return iMAPMessage; 
/*      */     } else {
/* 1158 */       this.uidTable = new Hashtable();
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/* 1163 */       synchronized (this.messageCacheLock) {
/*      */         
/* 1165 */         UID uID = this.protocol.fetchSequenceNumber(paramLong);
/*      */         
/* 1167 */         if (uID != null) {
/* 1168 */           iMAPMessage = (IMAPMessage)this.messageCache.elementAt(uID.msgno - 1);
/* 1169 */           iMAPMessage.setUID(uID.uid);
/*      */           
/* 1171 */           this.uidTable.put(long, iMAPMessage);
/*      */         } 
/*      */       } 
/* 1174 */     } catch (ConnectionException connectionException) {
/* 1175 */       throw new FolderClosedException(this, connectionException.getMessage());
/* 1176 */     } catch (ProtocolException protocolException) {
/* 1177 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */     } 
/*      */     
/* 1180 */     return iMAPMessage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Message[] getMessagesByUID(long paramLong1, long paramLong2) throws MessagingException {
/*      */     Message[] arrayOfMessage;
/* 1190 */     checkOpened();
/*      */     
/* 1192 */     if (this.uidTable == null) {
/* 1193 */       this.uidTable = new Hashtable();
/*      */     }
/*      */     
/*      */     try {
/* 1197 */       synchronized (this.messageCacheLock) {
/*      */         
/* 1199 */         UID[] arrayOfUID = this.protocol.fetchSequenceNumbers(paramLong1, paramLong2);
/*      */         
/* 1201 */         arrayOfMessage = new Message[arrayOfUID.length];
/*      */ 
/*      */         
/* 1204 */         for (byte b = 0; b < arrayOfUID.length; b++) {
/* 1205 */           IMAPMessage iMAPMessage = (IMAPMessage)this.messageCache.elementAt((arrayOfUID[b]).msgno - 1);
/* 1206 */           iMAPMessage.setUID((arrayOfUID[b]).uid);
/* 1207 */           arrayOfMessage[b] = iMAPMessage;
/* 1208 */           this.uidTable.put(new Long((arrayOfUID[b]).uid), iMAPMessage);
/*      */         } 
/*      */       } 
/* 1211 */     } catch (ConnectionException connectionException) {
/* 1212 */       throw new FolderClosedException(this, connectionException.getMessage());
/* 1213 */     } catch (ProtocolException protocolException) {
/* 1214 */       throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */     } 
/*      */     
/* 1217 */     return arrayOfMessage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Message[] getMessagesByUID(long[] paramArrayOfLong) throws MessagingException {
/* 1229 */     checkOpened();
/* 1230 */     long[] arrayOfLong = paramArrayOfLong;
/*      */     
/* 1232 */     if (this.uidTable != null) {
/* 1233 */       Vector vector = new Vector();
/*      */       
/* 1235 */       for (byte b1 = 0; b1 < paramArrayOfLong.length; b1++) {
/* 1236 */         Long long; if (!this.uidTable.containsKey(long = new Long(paramArrayOfLong[b1])))
/*      */         {
/* 1238 */           vector.addElement(long);
/*      */         }
/*      */       } 
/* 1241 */       int i = vector.size();
/* 1242 */       arrayOfLong = new long[i];
/* 1243 */       for (byte b2 = 0; b2 < i; b2++)
/* 1244 */         arrayOfLong[b2] = ((Long)vector.elementAt(b2)).longValue(); 
/*      */     } else {
/* 1246 */       this.uidTable = new Hashtable();
/*      */     } 
/* 1248 */     if (arrayOfLong.length > 0) {
/*      */       try {
/* 1250 */         synchronized (this.messageCacheLock) {
/*      */           
/* 1252 */           UID[] arrayOfUID = this.protocol.fetchSequenceNumbers(arrayOfLong);
/*      */           
/* 1254 */           for (byte b1 = 0; b1 < arrayOfUID.length; b1++) {
/* 1255 */             IMAPMessage iMAPMessage = (IMAPMessage)this.messageCache.elementAt((arrayOfUID[b1]).msgno - 1);
/* 1256 */             iMAPMessage.setUID((arrayOfUID[b1]).uid);
/* 1257 */             this.uidTable.put(new Long((arrayOfUID[b1]).uid), iMAPMessage);
/*      */           } 
/*      */         } 
/* 1260 */       } catch (ConnectionException connectionException) {
/* 1261 */         throw new FolderClosedException(this, connectionException.getMessage());
/* 1262 */       } catch (ProtocolException protocolException) {
/* 1263 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1268 */     Message[] arrayOfMessage = new Message[paramArrayOfLong.length];
/* 1269 */     for (byte b = 0; b < paramArrayOfLong.length; b++)
/* 1270 */       arrayOfMessage[b] = (Message)this.uidTable.get(new Long(paramArrayOfLong[b])); 
/* 1271 */     return arrayOfMessage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getUID(Message paramMessage) throws MessagingException {
/* 1279 */     if (paramMessage.getFolder() != this) {
/* 1280 */       throw new NoSuchElementException(
/* 1281 */           "Message does not belong to this folder");
/*      */     }
/* 1283 */     checkOpened();
/*      */     
/* 1285 */     IMAPMessage iMAPMessage = (IMAPMessage)paramMessage;
/*      */     
/*      */     long l;
/* 1288 */     if ((l = iMAPMessage.getUID()) != -1L) {
/* 1289 */       return l;
/*      */     }
/* 1291 */     UID uID = null;
/* 1292 */     synchronized (this.messageCacheLock) {
/* 1293 */       iMAPMessage.checkExpunged();
/*      */       try {
/* 1295 */         uID = this.protocol.fetchUID(iMAPMessage.getSequenceNumber());
/* 1296 */       } catch (ConnectionException connectionException) {
/* 1297 */         throw new FolderClosedException(this, connectionException.getMessage());
/* 1298 */       } catch (ProtocolException protocolException) {
/* 1299 */         throw new MessagingException(protocolException.getMessage(), protocolException);
/*      */       } 
/*      */     } 
/*      */     
/* 1303 */     if (uID != null) {
/* 1304 */       l = uID.uid;
/* 1305 */       iMAPMessage.setUID(l);
/*      */ 
/*      */       
/* 1308 */       if (this.uidTable == null)
/* 1309 */         this.uidTable = new Hashtable(); 
/* 1310 */       this.uidTable.put(new Long(l), iMAPMessage);
/*      */     } 
/*      */     
/* 1313 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleResponse(Response paramResponse) {
/* 1332 */     if (paramResponse.isBYE()) {
/* 1333 */       if (this.opened)
/* 1334 */         cleanup(); 
/*      */       return;
/*      */     } 
/* 1337 */     if (paramResponse.isOK()) {
/*      */       
/* 1339 */       ((IMAPStore)this.store).handleResponse(paramResponse);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1344 */     if (!(paramResponse instanceof IMAPResponse)) {
/*      */       
/* 1346 */       System.out.println("UNEXPECTED RESPONSE : " + paramResponse.toString());
/* 1347 */       System.out.println("CONTACT javamail@sun.com");
/*      */       
/*      */       return;
/*      */     } 
/* 1351 */     IMAPResponse iMAPResponse = (IMAPResponse)paramResponse;
/*      */     
/* 1353 */     if (iMAPResponse.keyEquals("EXISTS")) {
/* 1354 */       int i = iMAPResponse.getNumber();
/* 1355 */       if (i <= this.realTotal) {
/*      */         return;
/*      */       }
/*      */       
/* 1359 */       int j = i - this.realTotal;
/* 1360 */       Message[] arrayOfMessage = new Message[j];
/*      */ 
/*      */       
/* 1363 */       for (byte b = 0; b < j; b++) {
/*      */ 
/*      */         
/* 1366 */         IMAPMessage iMAPMessage = new IMAPMessage(this, ++this.total, ++this.realTotal);
/* 1367 */         arrayOfMessage[b] = iMAPMessage;
/* 1368 */         this.messageCache.addElement(iMAPMessage);
/*      */       } 
/*      */ 
/*      */       
/* 1372 */       notifyMessageAddedListeners(arrayOfMessage); return;
/*      */     } 
/* 1374 */     if (iMAPResponse.keyEquals("EXPUNGE")) {
/*      */ 
/*      */       
/* 1377 */       IMAPMessage iMAPMessage = getMessageBySeqNumber(iMAPResponse.getNumber());
/* 1378 */       iMAPMessage.setExpunged(true);
/*      */ 
/*      */ 
/*      */       
/* 1382 */       for (int i = iMAPMessage.getMessageNumber(); i < this.total; i++) {
/*      */ 
/*      */         
/* 1385 */         IMAPMessage iMAPMessage1 = (IMAPMessage)this.messageCache.elementAt(i);
/* 1386 */         if (!iMAPMessage1.isExpunged())
/*      */         {
/*      */ 
/*      */           
/* 1390 */           iMAPMessage1.setSequenceNumber(iMAPMessage1.getSequenceNumber() - 1);
/*      */         }
/*      */       } 
/*      */       
/* 1394 */       this.realTotal--;
/*      */       
/* 1396 */       if (this.doExpungeNotification) {
/*      */         
/* 1398 */         Message[] arrayOfMessage = { iMAPMessage };
/* 1399 */         notifyMessageRemovedListeners(false, arrayOfMessage);
/*      */         return;
/*      */       } 
/* 1402 */     } else if (iMAPResponse.keyEquals("FETCH")) {
/*      */ 
/*      */       
/* 1405 */       FetchResponse fetchResponse = (FetchResponse)iMAPResponse;
/*      */       
/* 1407 */       Flags flags = (Flags)fetchResponse.getItem(Flags.class);
/*      */       
/* 1409 */       if (flags != null) {
/* 1410 */         IMAPMessage iMAPMessage = getMessageBySeqNumber(fetchResponse.getNumber());
/* 1411 */         iMAPMessage._setFlags(flags);
/*      */         
/* 1413 */         notifyMessageChangedListeners(
/* 1414 */             1, iMAPMessage);
/*      */         return;
/*      */       } 
/* 1417 */     } else if (iMAPResponse.keyEquals("RECENT")) {
/*      */       
/* 1419 */       this.recent = iMAPResponse.getNumber();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleResponses(Response[] paramArrayOfResponse) {
/* 1430 */     for (byte b = 0; b < paramArrayOfResponse.length; b++) {
/* 1431 */       if (paramArrayOfResponse[b] != null) {
/* 1432 */         handleResponse(paramArrayOfResponse[b]);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1440 */   IMAPProtocol storeProtocol() { return ((IMAPStore)this.store).getProtocol(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   IMAPMessage getMessageBySeqNumber(int paramInt) {
/* 1455 */     for (int i = paramInt - 1; i < this.total; i++) {
/* 1456 */       IMAPMessage iMAPMessage = (IMAPMessage)this.messageCache.elementAt(i);
/* 1457 */       if (iMAPMessage.getSequenceNumber() == paramInt)
/* 1458 */         return iMAPMessage; 
/*      */     } 
/* 1460 */     return null;
/*      */   }
/*      */ 
/*      */   
/* 1464 */   private boolean isDirectory() throws MessagingException { return !((this.type & 0x2) == 0); }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\sun\mail\imap\IMAPFolder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */