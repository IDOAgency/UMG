package com.oroinc.text.regex;

public class MalformedPatternException extends Exception {
  public MalformedPatternException() {}
  
  public MalformedPatternException(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\MalformedPatternException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */