package com.oroinc.text.regex;

public interface MatchResult {
  int length();
  
  int groups();
  
  String group(int paramInt);
  
  int begin(int paramInt);
  
  int end(int paramInt);
  
  int beginOffset(int paramInt);
  
  int endOffset(int paramInt);
  
  String toString();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\MatchResult.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */