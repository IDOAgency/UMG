package com.oroinc.text.regex;

import java.util.Vector;

public class Perl5Substitution extends StringSubstitution {
  public static final int INTERPOLATE_ALL = 0;
  
  public static final int INTERPOLATE_NONE = -1;
  
  int _numInterpolations;
  
  Vector _substitutions;
  
  String _lastInterpolation;
  
  static Vector _parseSubs(String paramString) {
    Vector vector = new Vector(5);
    StringBuffer stringBuffer1 = new StringBuffer(5);
    StringBuffer stringBuffer2 = new StringBuffer(10);
    char[] arrayOfChar = paramString.toCharArray();
    byte b = 0;
    boolean bool1 = false;
    boolean bool2 = false;
    while (b < arrayOfChar.length) {
      if (bool1 && Character.isDigit(arrayOfChar[b])) {
        stringBuffer1.append(arrayOfChar[b]);
        if (stringBuffer2.length() > 0) {
          vector.addElement(stringBuffer2.toString());
          stringBuffer2.setLength(0);
        } 
      } else {
        if (bool1) {
          try {
            vector.addElement(new Integer(stringBuffer1.toString()));
            bool2 = true;
          } catch (NumberFormatException numberFormatException) {
            vector.addElement(stringBuffer1.toString());
          } 
          stringBuffer1.setLength(0);
          bool1 = false;
        } 
        if (arrayOfChar[b] == '$' && b + true < arrayOfChar.length && arrayOfChar[b + true] != '0' && Character.isDigit(arrayOfChar[b + true])) {
          bool1 = true;
        } else {
          stringBuffer2.append(arrayOfChar[b]);
        } 
      } 
      b++;
    } 
    if (bool1) {
      try {
        vector.addElement(new Integer(stringBuffer1.toString()));
        bool2 = true;
      } catch (NumberFormatException numberFormatException) {
        vector.addElement(stringBuffer1.toString());
      } 
    } else if (stringBuffer2.length() > 0) {
      vector.addElement(stringBuffer2.toString());
    } 
    return bool2 ? vector : null;
  }
  
  String _finalInterpolatedSub(MatchResult paramMatchResult) {
    StringBuffer stringBuffer = new StringBuffer(10);
    _calcSub(stringBuffer, paramMatchResult);
    return stringBuffer.toString();
  }
  
  void _calcSub(StringBuffer paramStringBuffer, MatchResult paramMatchResult) {
    int i = this._substitutions.size();
    for (byte b = 0; b < i; b++) {
      Object object = this._substitutions.elementAt(b);
      if (object instanceof String) {
        paramStringBuffer.append(object);
      } else {
        Integer integer = (Integer)object;
        int j = integer.intValue();
        if (j > 0 && j < paramMatchResult.groups()) {
          String str = paramMatchResult.group(j);
          if (str != null)
            paramStringBuffer.append(str); 
        } else {
          paramStringBuffer.append('$');
          paramStringBuffer.append(j);
        } 
      } 
    } 
  }
  
  public Perl5Substitution() { this("", 0); }
  
  public Perl5Substitution(String paramString) { this(paramString, 0); }
  
  public Perl5Substitution(String paramString, int paramInt) { setSubstitution(paramString, paramInt); }
  
  public void setSubstitution(String paramString) { setSubstitution(paramString, 0); }
  
  public void setSubstitution(String paramString, int paramInt) {
    super.setSubstitution(paramString);
    this._numInterpolations = paramInt;
    if (paramInt != -1 && paramString.indexOf('$') != -1) {
      this._substitutions = _parseSubs(paramString);
    } else {
      this._substitutions = null;
    } 
    this._lastInterpolation = null;
  }
  
  public void appendSubstitution(StringBuffer paramStringBuffer, MatchResult paramMatchResult, int paramInt, String paramString, PatternMatcher paramPatternMatcher, Pattern paramPattern) {
    if (this._substitutions == null) {
      super.appendSubstitution(paramStringBuffer, paramMatchResult, paramInt, paramString, paramPatternMatcher, paramPattern);
      return;
    } 
    if (this._numInterpolations < 1 || paramInt < this._numInterpolations) {
      _calcSub(paramStringBuffer, paramMatchResult);
      return;
    } 
    if (paramInt == this._numInterpolations)
      this._lastInterpolation = _finalInterpolatedSub(paramMatchResult); 
    paramStringBuffer.append(this._lastInterpolation);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\Perl5Substitution.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */