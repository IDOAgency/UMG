package com.oroinc.text.regex;

public interface Substitution {
  void appendSubstitution(StringBuffer paramStringBuffer, MatchResult paramMatchResult, int paramInt, String paramString, PatternMatcher paramPatternMatcher, Pattern paramPattern);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\Substitution.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */