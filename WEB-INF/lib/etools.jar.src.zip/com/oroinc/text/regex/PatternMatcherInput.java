package com.oroinc.text.regex;

public final class PatternMatcherInput {
  String _originalStringInput;
  
  char[] _originalCharInput;
  
  char[] _originalBuffer;
  
  char[] _toLowerBuffer;
  
  int _beginOffset;
  
  int _endOffset;
  
  int _currentOffset;
  
  int _matchBeginOffset = -1;
  
  int _matchEndOffset = -1;
  
  public PatternMatcherInput(String paramString, int paramInt1, int paramInt2) { setInput(paramString, paramInt1, paramInt2); }
  
  public PatternMatcherInput(String paramString) { this(paramString, 0, paramString.length()); }
  
  public PatternMatcherInput(char[] paramArrayOfChar, int paramInt1, int paramInt2) { setInput(paramArrayOfChar, paramInt1, paramInt2); }
  
  public PatternMatcherInput(char[] paramArrayOfChar) { this(paramArrayOfChar, 0, paramArrayOfChar.length); }
  
  public int length() { return this._endOffset - this._beginOffset; }
  
  public void setInput(String paramString, int paramInt1, int paramInt2) {
    this._originalStringInput = paramString;
    this._originalCharInput = null;
    this._toLowerBuffer = null;
    this._originalBuffer = paramString.toCharArray();
    this._currentOffset = paramInt1;
    this._matchBeginOffset = -1;
    this._matchEndOffset = -1;
    this._beginOffset = paramInt1;
    int i = this._beginOffset + paramInt2;
    this._endOffset = i;
  }
  
  public void setInput(String paramString) { setInput(paramString, 0, paramString.length()); }
  
  public void setInput(char[] paramArrayOfChar, int paramInt1, int paramInt2) {
    this._originalStringInput = null;
    this._toLowerBuffer = null;
    this._originalBuffer = this._originalCharInput = paramArrayOfChar;
    this._currentOffset = paramInt1;
    this._matchBeginOffset = -1;
    this._matchEndOffset = -1;
    this._beginOffset = paramInt1;
    int i = this._beginOffset + paramInt2;
    this._endOffset = i;
  }
  
  public void setInput(char[] paramArrayOfChar) { setInput(paramArrayOfChar, 0, paramArrayOfChar.length); }
  
  public char charAt(int paramInt) { return this._originalBuffer[this._beginOffset + paramInt]; }
  
  public String substring(int paramInt1, int paramInt2) { return new String(this._originalBuffer, this._beginOffset + paramInt1, paramInt2 - paramInt1); }
  
  public String substring(int paramInt) {
    paramInt += this._beginOffset;
    return new String(this._originalBuffer, paramInt, this._endOffset - paramInt);
  }
  
  public Object getInput() { return (this._originalStringInput == null) ? this._originalCharInput : this._originalStringInput; }
  
  public char[] getBuffer() { return this._originalBuffer; }
  
  public boolean endOfInput() { return !(this._currentOffset < this._endOffset); }
  
  public int getBeginOffset() { return this._beginOffset; }
  
  public int getEndOffset() { return this._endOffset; }
  
  public int getCurrentOffset() { return this._currentOffset; }
  
  public void setBeginOffset(int paramInt) { this._beginOffset = paramInt; }
  
  public void setEndOffset(int paramInt) { this._endOffset = paramInt; }
  
  public void setCurrentOffset(int paramInt) {
    this._currentOffset = paramInt;
    this._matchBeginOffset = -1;
    this._matchEndOffset = -1;
  }
  
  public String toString() { return new String(this._originalBuffer, this._beginOffset, this._endOffset - this._beginOffset); }
  
  public String preMatch() { return new String(this._originalBuffer, this._beginOffset, this._matchBeginOffset - this._beginOffset); }
  
  public String postMatch() { return new String(this._originalBuffer, this._matchEndOffset, this._endOffset - this._matchEndOffset); }
  
  public String match() { return new String(this._originalBuffer, this._matchBeginOffset, this._matchEndOffset - this._matchBeginOffset); }
  
  public void setMatchOffsets(int paramInt1, int paramInt2) {
    this._matchBeginOffset = paramInt1;
    this._matchEndOffset = paramInt2;
  }
  
  public int getMatchBeginOffset() { return this._matchBeginOffset; }
  
  public int getMatchEndOffset() { return this._matchEndOffset; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\PatternMatcherInput.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */