package com.oroinc.text.regex;

final class Perl5MatchResult implements MatchResult {
  int _matchBeginOffset;
  
  int[] _beginGroupOffset;
  
  int[] _endGroupOffset;
  
  String _match;
  
  Perl5MatchResult(int paramInt) {
    this._beginGroupOffset = new int[paramInt];
    this._endGroupOffset = new int[paramInt];
  }
  
  public int length() { return this._match.length(); }
  
  public int groups() { return this._beginGroupOffset.length; }
  
  public String group(int paramInt) {
    if (paramInt < this._beginGroupOffset.length) {
      int i = this._beginGroupOffset[paramInt];
      int j = this._endGroupOffset[paramInt];
      int k = this._match.length();
      if (i >= 0 && j >= 0) {
        if (i < k && j <= k)
          return this._match.substring(i, j); 
        if (i <= j)
          return new String(""); 
      } 
    } 
    return null;
  }
  
  public int begin(int paramInt) {
    if (paramInt < this._beginGroupOffset.length) {
      int i = this._beginGroupOffset[paramInt];
      int j = this._endGroupOffset[paramInt];
      if (i >= 0 && j >= 0)
        return i; 
    } 
    return -1;
  }
  
  public int end(int paramInt) {
    if (paramInt < this._beginGroupOffset.length) {
      int i = this._beginGroupOffset[paramInt];
      int j = this._endGroupOffset[paramInt];
      if (i >= 0 && j >= 0)
        return j; 
    } 
    return -1;
  }
  
  public int beginOffset(int paramInt) {
    if (paramInt < this._beginGroupOffset.length) {
      int i = this._beginGroupOffset[paramInt];
      int j = this._endGroupOffset[paramInt];
      if (i >= 0 && j >= 0)
        return this._matchBeginOffset + i; 
    } 
    return -1;
  }
  
  public int endOffset(int paramInt) {
    if (paramInt < this._endGroupOffset.length) {
      int i = this._beginGroupOffset[paramInt];
      int j = this._endGroupOffset[paramInt];
      if (i >= 0 && j >= 0)
        return this._matchBeginOffset + j; 
    } 
    return -1;
  }
  
  public String toString() { return group(0); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\Perl5MatchResult.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */