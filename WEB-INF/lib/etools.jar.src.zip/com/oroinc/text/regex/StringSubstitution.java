package com.oroinc.text.regex;

public class StringSubstitution implements Substitution {
  int _subLength;
  
  String _substitution;
  
  public StringSubstitution() { this(""); }
  
  public StringSubstitution(String paramString) { setSubstitution(paramString); }
  
  public void setSubstitution(String paramString) {
    this._substitution = paramString;
    this._subLength = paramString.length();
  }
  
  public String getSubstitution() { return this._substitution; }
  
  public String toString() { return getSubstitution(); }
  
  public void appendSubstitution(StringBuffer paramStringBuffer, MatchResult paramMatchResult, int paramInt, String paramString, PatternMatcher paramPatternMatcher, Pattern paramPattern) {
    if (this._subLength == 0)
      return; 
    paramStringBuffer.append(this._substitution);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\StringSubstitution.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */