package com.oroinc.text.regex;

final class CharStringPointer {
  static final char END_OF_STRING = '￿';
  
  int _offset;
  
  char[] _array;
  
  CharStringPointer(char[] paramArrayOfChar, int paramInt) {
    this._array = paramArrayOfChar;
    this._offset = paramInt;
  }
  
  CharStringPointer(char[] paramArrayOfChar) { this(paramArrayOfChar, 0); }
  
  char _getValue() {
    int i = this._offset;
    return (i < this._array.length && i >= 0) ? this._array[i] : Character.MAX_VALUE;
  }
  
  char _getValue(int paramInt) { return (paramInt < this._array.length && paramInt >= 0) ? this._array[paramInt] : Character.MAX_VALUE; }
  
  char _getValueRelative(int paramInt) {
    int i = this._offset + paramInt;
    return (i < this._array.length && i >= 0) ? this._array[i] : Character.MAX_VALUE;
  }
  
  int _getLength() { return this._array.length; }
  
  int _getOffset() { return this._offset; }
  
  void _setOffset(int paramInt) { this._offset = paramInt; }
  
  boolean _isAtEnd() { return !(this._offset < this._array.length); }
  
  char _increment(int paramInt) {
    this._offset += paramInt;
    if (this._offset >= this._array.length) {
      this._offset = this._array.length;
      return Character.MAX_VALUE;
    } 
    return this._array[this._offset];
  }
  
  char _increment() { return _increment(1); }
  
  char _decrement(int paramInt) {
    this._offset -= paramInt;
    if (this._offset < 0)
      this._offset = 0; 
    return this._array[this._offset];
  }
  
  char _decrement() { return _decrement(1); }
  
  char _postIncrement() {
    int i = this._offset;
    char c = (i < this._array.length && i >= 0) ? this._array[i] : Character.MAX_VALUE;
    _increment(1);
    return c;
  }
  
  char _postDecrement() {
    int i = this._offset;
    char c = (i < this._array.length && i >= 0) ? this._array[i] : Character.MAX_VALUE;
    _decrement(1);
    return c;
  }
  
  String _toString(int paramInt) { return new String(this._array, paramInt, this._array.length - paramInt); }
  
  public String toString() { return new String(this._array, 0, this._array.length); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\CharStringPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */