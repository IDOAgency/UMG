package com.oroinc.text.regex;

public interface PatternCompiler {
  Pattern compile(String paramString) throws MalformedPatternException;
  
  Pattern compile(String paramString, int paramInt) throws MalformedPatternException;
  
  Pattern compile(char[] paramArrayOfChar) throws MalformedPatternException;
  
  Pattern compile(char[] paramArrayOfChar, int paramInt) throws MalformedPatternException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\PatternCompiler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */