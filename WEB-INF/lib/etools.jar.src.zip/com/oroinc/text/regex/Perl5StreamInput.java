package com.oroinc.text.regex;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public final class Perl5StreamInput {
  private static final int __DEFAULT_BUFFER_INCREMENT = 4096;
  
  private int __bufferIncrement;
  
  private Reader __input;
  
  boolean _endOfStream;
  
  boolean _tentativeEOS;
  
  int _bufferSize;
  
  int _streamOffset;
  
  int _bufferOffset;
  
  int _matchEndOffset;
  
  char[] _buffer;
  
  char[] _originalBuffer;
  
  public Perl5StreamInput(Reader paramReader, int paramInt) {
    this.__input = paramReader;
    this.__bufferIncrement = paramInt;
    this._endOfStream = false;
    this._tentativeEOS = false;
    this._bufferSize = this._bufferOffset = this._streamOffset = 0;
    this._originalBuffer = this._buffer = new char[paramInt];
    this._matchEndOffset = -1;
  }
  
  public Perl5StreamInput(Reader paramReader) { this(paramReader, 4096); }
  
  public Perl5StreamInput(InputStream paramInputStream, int paramInt) { this(new InputStreamReader(paramInputStream), paramInt); }
  
  public Perl5StreamInput(InputStream paramInputStream) { this(new InputStreamReader(paramInputStream), 4096); }
  
  private void __fillBuffer(int paramInt1, int paramInt2) {
    paramInt2 += paramInt1;
    while (paramInt1 < paramInt2) {
      char c = this._originalBuffer[paramInt1];
      this._buffer[paramInt1] = Character.isUpperCase(c) ? Character.toLowerCase(c) : c;
      paramInt1++;
    } 
  }
  
  void _setMatchEndOffset(int paramInt) { this._matchEndOffset = paramInt; }
  
  int _getMatchEndOffset() { return this._matchEndOffset; }
  
  void _reallocate(int paramInt, boolean paramBoolean) throws IOException {
    if (this._endOfStream)
      return; 
    if (this._tentativeEOS) {
      this._tentativeEOS = false;
      this._endOfStream = true;
      return;
    } 
    int i = this._bufferSize - paramInt;
    if (i < 0)
      throw new IOException("Non-negative offset assertion violation.\nPlease report this error to bugs@oroinc.com\n"); 
    char[] arrayOfChar = new char[i + this.__bufferIncrement];
    int j = this.__input.read(arrayOfChar, i, this.__bufferIncrement);
    if (j <= 0) {
      this._endOfStream = true;
      if (j == 0)
        throw new IOException("read from input Reader returned 0 chars."); 
    } else {
      this._streamOffset += paramInt;
      this._bufferSize = i + j;
      while (this._bufferSize < arrayOfChar.length) {
        int k = this.__input.read(arrayOfChar, this._bufferSize, arrayOfChar.length - this._bufferSize);
        if (k == 0)
          throw new IOException("read from input Reader returned 0 chars."); 
        if (k < 0) {
          this._tentativeEOS = true;
          break;
        } 
        this._bufferSize += k;
        j += k;
      } 
      System.arraycopy(this._originalBuffer, paramInt, arrayOfChar, 0, i);
      this._originalBuffer = arrayOfChar;
      if (paramBoolean) {
        arrayOfChar = new char[i + this.__bufferIncrement];
        System.arraycopy(this._buffer, paramInt, arrayOfChar, 0, i);
        this._buffer = arrayOfChar;
        __fillBuffer(i, j);
        return;
      } 
      this._buffer = this._originalBuffer;
    } 
  }
  
  boolean _read(boolean paramBoolean) throws IOException {
    this._streamOffset += this._bufferSize;
    int i = this._bufferSize = this.__input.read(this._originalBuffer);
    if (this._bufferSize > 0) {
      while (this._bufferSize < this._originalBuffer.length) {
        i = this.__input.read(this._originalBuffer, this._bufferSize, this._originalBuffer.length - this._bufferSize);
        if (i == 0)
          throw new IOException("read from input Reader returned 0 chars."); 
        if (i >= 0) {
          this._bufferSize += i;
          continue;
        } 
        break;
      } 
    } else {
      this._endOfStream = true;
    } 
    if (!this._endOfStream && paramBoolean) {
      this._buffer = new char[this._originalBuffer.length];
      __fillBuffer(0, this._bufferSize);
    } 
    return !this._endOfStream;
  }
  
  public boolean endOfStream() { return this._endOfStream; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\Perl5StreamInput.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */