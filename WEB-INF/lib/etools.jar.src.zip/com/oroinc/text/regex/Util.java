package com.oroinc.text.regex;

import java.util.Vector;

public final class Util {
  public static final int SUBSTITUTE_ALL = -1;
  
  public static final int SPLIT_ALL = 0;
  
  public static final int INTERPOLATE_ALL = 0;
  
  public static final int INTERPOLATE_NONE = -1;
  
  public static Vector split(PatternMatcher paramPatternMatcher, Pattern paramPattern, String paramString, int paramInt) {
    Vector vector = new Vector(20);
    PatternMatcherInput patternMatcherInput = new PatternMatcherInput(paramString);
    int i;
    for (i = 0; --paramInt != 0 && paramPatternMatcher.contains(patternMatcherInput, paramPattern); i = matchResult.endOffset(0)) {
      MatchResult matchResult = paramPatternMatcher.getMatch();
      vector.addElement(paramString.substring(i, matchResult.beginOffset(0)));
    } 
    vector.addElement(paramString.substring(i, paramString.length()));
    return vector;
  }
  
  public static Vector split(PatternMatcher paramPatternMatcher, Pattern paramPattern, String paramString) { return split(paramPatternMatcher, paramPattern, paramString, 0); }
  
  public static String substitute(PatternMatcher paramPatternMatcher, Pattern paramPattern, Substitution paramSubstitution, String paramString, int paramInt) {
    StringBuffer stringBuffer = new StringBuffer(paramString.length());
    PatternMatcherInput patternMatcherInput = new PatternMatcherInput(paramString);
    int i;
    byte b;
    for (i = b = 0; paramInt != 0 && paramPatternMatcher.contains(patternMatcherInput, paramPattern); i = matchResult.endOffset(0)) {
      paramInt--;
      b++;
      MatchResult matchResult = paramPatternMatcher.getMatch();
      stringBuffer.append(paramString.substring(i, matchResult.beginOffset(0)));
      paramSubstitution.appendSubstitution(stringBuffer, matchResult, b, paramString, paramPatternMatcher, paramPattern);
    } 
    if (b == 0)
      return paramString; 
    stringBuffer.append(paramString.substring(i, paramString.length()));
    return stringBuffer.toString();
  }
  
  public static String substitute(PatternMatcher paramPatternMatcher, Pattern paramPattern, Substitution paramSubstitution, String paramString) { return substitute(paramPatternMatcher, paramPattern, paramSubstitution, paramString, 1); }
  
  public static String substitute(PatternMatcher paramPatternMatcher, Pattern paramPattern, String paramString1, String paramString2, int paramInt1, int paramInt2) { return substitute(paramPatternMatcher, paramPattern, new Perl5Substitution(paramString1, paramInt2), paramString2, paramInt1); }
  
  public static String substitute(PatternMatcher paramPatternMatcher, Pattern paramPattern, String paramString1, String paramString2, int paramInt) { return substitute(paramPatternMatcher, paramPattern, new Perl5Substitution(paramString1, 0), paramString2, paramInt); }
  
  public static String substitute(PatternMatcher paramPatternMatcher, Pattern paramPattern, String paramString1, String paramString2) { return substitute(paramPatternMatcher, paramPattern, new Perl5Substitution(paramString1, 0), paramString2, 1); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\Util.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */