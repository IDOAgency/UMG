package com.oroinc.text.regex;

final class OpCode {
  static final char _END = '\000';
  
  static final char _BOL = '\001';
  
  static final char _MBOL = '\002';
  
  static final char _SBOL = '\003';
  
  static final char _EOL = '\004';
  
  static final char _MEOL = '\005';
  
  static final char _SEOL = '\006';
  
  static final char _ANY = '\007';
  
  static final char _SANY = '\b';
  
  static final char _ANYOF = '\t';
  
  static final char _CURLY = '\n';
  
  static final char _CURLYX = '\013';
  
  static final char _BRANCH = '\f';
  
  static final char _BACK = '\r';
  
  static final char _EXACTLY = '\016';
  
  static final char _NOTHING = '\017';
  
  static final char _STAR = '\020';
  
  static final char _PLUS = '\021';
  
  static final char _ALNUM = '\022';
  
  static final char _NALNUM = '\023';
  
  static final char _BOUND = '\024';
  
  static final char _NBOUND = '\025';
  
  static final char _SPACE = '\026';
  
  static final char _NSPACE = '\027';
  
  static final char _DIGIT = '\030';
  
  static final char _NDIGIT = '\031';
  
  static final char _REF = '\032';
  
  static final char _OPEN = '\033';
  
  static final char _CLOSE = '\034';
  
  static final char _MINMOD = '\035';
  
  static final char _GBOL = '\036';
  
  static final char _IFMATCH = '\037';
  
  static final char _UNLESSM = ' ';
  
  static final char _SUCCEED = '!';
  
  static final char _WHILEM = '"';
  
  static final int[] _operandLength = { 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      2, 2, 1, 1, 1 };
  
  static final char[] _opType = { 
      Character.MIN_VALUE, '\001', '\001', '\001', '\004', '\004', '\004', '\007', '\007', '\t', 
      '\n', '\n', '\f', '\r', '\016', '\017', '\020', '\021', '\022', '\023', 
      '\024', '\025', '\026', '\027', '\030', '\031', '\032', '\033', '\034', '\035', 
      '\001', '\f', '\f', '"' };
  
  static final char[] _opLengthVaries = { '\f', '\r', '\020', '\021', '\n', '\013', '\032', '"' };
  
  static final char[] _opLengthOne = { '\007', '\b', '\t', '\022', '\023', '\026', '\027', '\030', '\031' };
  
  static final int _NULL_OFFSET = -1;
  
  static final char _NULL_POINTER = '\000';
  
  static final int _getNextOffset(char[] paramArrayOfChar, int paramInt) { return paramArrayOfChar[paramInt + 1]; }
  
  static final char _getArg1(char[] paramArrayOfChar, int paramInt) { return paramArrayOfChar[paramInt + 2]; }
  
  static final char _getArg2(char[] paramArrayOfChar, int paramInt) { return paramArrayOfChar[paramInt + 3]; }
  
  static final int _getOperand(int paramInt) { return paramInt + 2; }
  
  static final boolean _isInArray(char paramChar, char[] paramArrayOfChar, int paramInt) {
    while (paramInt < paramArrayOfChar.length) {
      if (paramChar == paramArrayOfChar[paramInt++])
        return true; 
    } 
    return false;
  }
  
  static final int _getNextOperator(int paramInt) { return paramInt + 2; }
  
  static final int _getPrevOperator(int paramInt) { return paramInt - 2; }
  
  static final int _getNext(char[] paramArrayOfChar, int paramInt) {
    if (paramArrayOfChar == null)
      return -1; 
    char c = paramArrayOfChar[paramInt + 1];
    return (c == '\000') ? -1 : ((paramArrayOfChar[paramInt] == '\r') ? (paramInt - c) : (paramInt + c));
  }
  
  static final boolean _isWordCharacter(char paramChar) { return !((paramChar < 'a' || paramChar > 'z') && (paramChar < 'A' || paramChar > 'Z') && (paramChar < '0' || paramChar > '9') && paramChar != '_'); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\OpCode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */