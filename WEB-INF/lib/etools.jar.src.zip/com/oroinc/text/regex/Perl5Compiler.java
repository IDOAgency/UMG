package com.oroinc.text.regex;

public final class Perl5Compiler implements PatternCompiler {
  private static final int __WORSTCASE = 0;
  
  private static final int __NONNULL = 1;
  
  private static final int __SIMPLE = 2;
  
  private static final int __SPSTART = 4;
  
  private static final int __TRYAGAIN = 8;
  
  private static final char __CASE_INSENSITIVE = '\001';
  
  private static final char __GLOBAL = '\002';
  
  private static final char __KEEP = '\004';
  
  private static final char __MULTILINE = '\b';
  
  private static final char __SINGLELINE = '\020';
  
  private static final char __EXTENDED = ' ';
  
  private static final char __READ_ONLY = '耀';
  
  private static final String __META_CHARS = "^$.[()|?+*\\";
  
  private static final String __HEX_DIGIT = "0123456789abcdef0123456789ABCDEFx";
  
  private CharStringPointer __input;
  
  private boolean __sawBackreference;
  
  private char[] __modifierFlags = new char[1];
  
  private int __numParentheses;
  
  private int __programSize;
  
  private int __cost;
  
  private char[] __program;
  
  public static final int DEFAULT_MASK = 0;
  
  public static final int CASE_INSENSITIVE_MASK = 1;
  
  public static final int MULTILINE_MASK = 8;
  
  public static final int SINGLELINE_MASK = 16;
  
  public static final int EXTENDED_MASK = 32;
  
  public static final int READ_ONLY_MASK = 32768;
  
  public static final String quotemeta(char[] paramArrayOfChar) {
    StringBuffer stringBuffer = new StringBuffer(2 * paramArrayOfChar.length);
    for (byte b = 0; b < paramArrayOfChar.length; b++) {
      if (!OpCode._isWordCharacter(paramArrayOfChar[b]))
        stringBuffer.append('\\'); 
      stringBuffer.append(paramArrayOfChar[b]);
    } 
    return stringBuffer.toString();
  }
  
  public static final String quotemeta(String paramString) { return quotemeta(paramString.toCharArray()); }
  
  static boolean _isSimpleRepetitionOp(char paramChar) { return !(paramChar != '*' && paramChar != '+' && paramChar != '?'); }
  
  static boolean _isComplexRepetitionOp(char[] paramArrayOfChar, int paramInt) { return (paramInt < paramArrayOfChar.length && paramInt >= 0) ? (!(paramArrayOfChar[paramInt] != '*' && paramArrayOfChar[paramInt] != '+' && paramArrayOfChar[paramInt] != '?' && (paramArrayOfChar[paramInt] != '{' || !_parseRepetition(paramArrayOfChar, paramInt)))) : false; }
  
  static boolean _parseRepetition(char[] paramArrayOfChar, int paramInt) {
    if (paramArrayOfChar[paramInt] != '{')
      return false; 
    if (++paramInt >= paramArrayOfChar.length || !Character.isDigit(paramArrayOfChar[paramInt]))
      return false; 
    while (paramInt < paramArrayOfChar.length && Character.isDigit(paramArrayOfChar[paramInt]))
      paramInt++; 
    if (paramInt < paramArrayOfChar.length && paramArrayOfChar[paramInt] == ',')
      paramInt++; 
    while (paramInt < paramArrayOfChar.length && Character.isDigit(paramArrayOfChar[paramInt]))
      paramInt++; 
    return !(paramInt >= paramArrayOfChar.length || paramArrayOfChar[paramInt] != '}');
  }
  
  static int _parseHex(char[] paramArrayOfChar, int paramInt1, int paramInt2, int[] paramArrayOfInt) {
    int i = 0;
    paramArrayOfInt[0] = 0;
    int j;
    while (paramInt1 < paramArrayOfChar.length && paramInt2-- > 0 && (j = "0123456789abcdef0123456789ABCDEFx".indexOf(paramArrayOfChar[paramInt1])) != -1) {
      i <<= 4;
      i |= j & 0xF;
      paramInt1++;
      paramArrayOfInt[0] = paramArrayOfInt[0] + 1;
    } 
    return i;
  }
  
  static int _parseOctal(char[] paramArrayOfChar, int paramInt1, int paramInt2, int[] paramArrayOfInt) {
    char c = Character.MIN_VALUE;
    paramArrayOfInt[0] = 0;
    while (paramInt1 < paramArrayOfChar.length && paramInt2 > 0 && paramArrayOfChar[paramInt1] >= '0' && paramArrayOfChar[paramInt1] <= '7') {
      c <<= 3;
      c |= paramArrayOfChar[paramInt1] - '0';
      paramInt2--;
      paramInt1++;
      paramArrayOfInt[0] = paramArrayOfInt[0] + 1;
    } 
    return c;
  }
  
  static void _setModifierFlag(char[] paramArrayOfChar, char paramChar) {
    switch (paramChar) {
      case 'i':
        paramArrayOfChar[0] = (char)(paramArrayOfChar[0] | true);
        return;
      case 'g':
        paramArrayOfChar[0] = (char)(paramArrayOfChar[0] | 0x2);
        return;
      case 'o':
        paramArrayOfChar[0] = (char)(paramArrayOfChar[0] | 0x4);
        return;
      case 'm':
        paramArrayOfChar[0] = (char)(paramArrayOfChar[0] | 0x8);
        return;
      case 's':
        paramArrayOfChar[0] = (char)(paramArrayOfChar[0] | 0x10);
        return;
      case 'x':
        paramArrayOfChar[0] = (char)(paramArrayOfChar[0] | 0x20);
        return;
    } 
  }
  
  void _emitCode(char paramChar) {
    if (this.__program != null)
      this.__program[this.__programSize] = paramChar; 
    this.__programSize++;
  }
  
  int _emitNode(char paramChar) {
    int i = this.__programSize;
    if (this.__program == null) {
      this.__programSize += 2;
    } else {
      this.__program[this.__programSize++] = paramChar;
      this.__program[this.__programSize++] = Character.MIN_VALUE;
    } 
    return i;
  }
  
  int _emitArgNode(char paramChar1, char paramChar2) {
    int i = this.__programSize;
    if (this.__program == null) {
      this.__programSize += 3;
    } else {
      this.__program[this.__programSize++] = paramChar1;
      this.__program[this.__programSize++] = Character.MIN_VALUE;
      this.__program[this.__programSize++] = paramChar2;
    } 
    return i;
  }
  
  void _programInsertOperator(char paramChar, int paramInt) {
    byte b = (OpCode._opType[paramChar] == '\n') ? 2 : 0;
    if (this.__program == null) {
      this.__programSize += 2 + b;
      return;
    } 
    int i = this.__programSize;
    this.__programSize += 2 + b;
    int j = this.__programSize;
    while (i > paramInt)
      this.__program[--j] = this.__program[--i]; 
    this.__program[paramInt++] = paramChar;
    this.__program[paramInt++] = Character.MIN_VALUE;
    while (b-- > 0)
      this.__program[paramInt++] = Character.MIN_VALUE; 
  }
  
  void _programAddTail(int paramInt1, int paramInt2) {
    int j;
    if (this.__program == null || paramInt1 == -1)
      return; 
    int i = paramInt1;
    while (true) {
      int k = OpCode._getNext(this.__program, i);
      if (k != -1) {
        i = k;
        continue;
      } 
      break;
    } 
    if (this.__program[i] == '\r') {
      j = i - paramInt2;
    } else {
      j = paramInt2 - i;
    } 
    this.__program[i + 1] = (char)j;
  }
  
  void _programAddOperatorTail(int paramInt1, int paramInt2) {
    if (this.__program == null || paramInt1 == -1 || OpCode._opType[this.__program[paramInt1]] != '\f')
      return; 
    _programAddTail(OpCode._getNextOperator(paramInt1), paramInt2);
  }
  
  char _getNextChar() {
    char c = this.__input._postIncrement();
    while (true) {
      char c1 = this.__input._getValue();
      if (c1 == '(' && this.__input._getValueRelative(1) == '?' && this.__input._getValueRelative(2) == '#') {
        while (c1 != Character.MAX_VALUE && c1 != ')')
          c1 = this.__input._increment(); 
        this.__input._increment();
        continue;
      } 
      if ((this.__modifierFlags[0] & 0x20) != '\000') {
        if (Character.isWhitespace(c1)) {
          this.__input._increment();
          continue;
        } 
        if (c1 == '#') {
          while (c1 != Character.MAX_VALUE && c1 != '\n')
            c1 = this.__input._increment(); 
          this.__input._increment();
          continue;
        } 
      } 
      break;
    } 
    return c;
  }
  
  int _parseAlternation(int[] paramArrayOfInt) throws MalformedPatternException {
    byte b = 0;
    paramArrayOfInt[0] = 0;
    int j = _emitNode('\f');
    int i = -1;
    if (this.__input._getOffset() == 0) {
      this.__input._setOffset(-1);
      _getNextChar();
    } else {
      this.__input._decrement();
      _getNextChar();
    } 
    for (char c = this.__input._getValue(); c != Character.MAX_VALUE && c != '|' && c != ')'; c = this.__input._getValue()) {
      b &= 0xFFFFFFF7;
      int k = _parseBranch(paramArrayOfInt);
      if (k == -1) {
        if ((b & 0x8) != 0) {
          c = this.__input._getValue();
          continue;
        } 
        return -1;
      } 
      paramArrayOfInt[0] = paramArrayOfInt[0] | b & true;
      if (i == -1) {
        paramArrayOfInt[0] = paramArrayOfInt[0] | b & 0x4;
      } else {
        this.__cost++;
        _programAddTail(i, k);
      } 
      i = k;
    } 
    if (i == -1)
      _emitNode('\017'); 
    return j;
  }
  
  int _parseAtom(int[] paramArrayOfInt) throws MalformedPatternException {
    int[] arrayOfInt = new int[1];
    paramArrayOfInt[0] = 0;
    boolean bool = false;
    int i = -1;
    while (true) {
      StringBuffer stringBuffer;
      int j;
      char c = this.__input._getValue();
      switch (c) {
        case '^':
          _getNextChar();
          if ((this.__modifierFlags[0] & 0x8) != '\000') {
            i = _emitNode('\002');
            break;
          } 
          if ((this.__modifierFlags[0] & 0x10) != '\000') {
            i = _emitNode('\003');
            break;
          } 
          i = _emitNode('\001');
          break;
        case '$':
          _getNextChar();
          if ((this.__modifierFlags[0] & 0x8) != '\000') {
            i = _emitNode('\005');
            break;
          } 
          if ((this.__modifierFlags[0] & 0x10) != '\000') {
            i = _emitNode('\006');
            break;
          } 
          i = _emitNode('\004');
          break;
        case '.':
          _getNextChar();
          if ((this.__modifierFlags[0] & 0x10) != '\000') {
            i = _emitNode('\b');
          } else {
            i = _emitNode('\007');
          } 
          this.__cost++;
          paramArrayOfInt[0] = paramArrayOfInt[0] | 0x3;
          break;
        case '[':
          this.__input._increment();
          i = _parseCharacterClass();
          paramArrayOfInt[0] = paramArrayOfInt[0] | 0x3;
          break;
        case '(':
          _getNextChar();
          i = _parseExpression(true, arrayOfInt);
          if (i == -1) {
            if ((arrayOfInt[0] & 0x8) == 0)
              return -1; 
            continue;
          } 
          paramArrayOfInt[0] = paramArrayOfInt[0] | arrayOfInt[0] & 0x5;
          break;
        case ')':
        case '|':
          if ((arrayOfInt[0] & 0x8) != 0) {
            paramArrayOfInt[0] = paramArrayOfInt[0] | 0x8;
            return -1;
          } 
          throw new MalformedPatternException("Error in expression at " + this.__input._toString(this.__input._getOffset()));
        case '*':
        case '+':
        case '?':
          throw new MalformedPatternException("?+* follows nothing in expression");
        case '\\':
          c = this.__input._increment();
          switch (c) {
            case 'A':
              i = _emitNode('\003');
              paramArrayOfInt[0] = paramArrayOfInt[0] | 0x2;
              _getNextChar();
              break;
            case 'G':
              i = _emitNode('\036');
              paramArrayOfInt[0] = paramArrayOfInt[0] | 0x2;
              _getNextChar();
              break;
            case 'Z':
              i = _emitNode('\006');
              paramArrayOfInt[0] = paramArrayOfInt[0] | 0x2;
              _getNextChar();
              break;
            case 'w':
              i = _emitNode('\022');
              paramArrayOfInt[0] = paramArrayOfInt[0] | 0x3;
              _getNextChar();
              break;
            case 'W':
              i = _emitNode('\023');
              paramArrayOfInt[0] = paramArrayOfInt[0] | 0x3;
              _getNextChar();
              break;
            case 'b':
              i = _emitNode('\024');
              paramArrayOfInt[0] = paramArrayOfInt[0] | 0x2;
              _getNextChar();
              break;
            case 'B':
              i = _emitNode('\025');
              paramArrayOfInt[0] = paramArrayOfInt[0] | 0x2;
              _getNextChar();
              break;
            case 's':
              i = _emitNode('\026');
              paramArrayOfInt[0] = paramArrayOfInt[0] | 0x3;
              _getNextChar();
              break;
            case 'S':
              i = _emitNode('\027');
              paramArrayOfInt[0] = paramArrayOfInt[0] | 0x3;
              _getNextChar();
              break;
            case 'd':
              i = _emitNode('\030');
              paramArrayOfInt[0] = paramArrayOfInt[0] | 0x3;
              _getNextChar();
              break;
            case 'D':
              i = _emitNode('\031');
              paramArrayOfInt[0] = paramArrayOfInt[0] | 0x3;
              _getNextChar();
              break;
            case '0':
            case 'a':
            case 'c':
            case 'e':
            case 'f':
            case 'n':
            case 'r':
            case 't':
            case 'x':
              bool = true;
              break;
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
              stringBuffer = new StringBuffer(10);
              j = 0;
              for (c = this.__input._getValueRelative(j); Character.isDigit(c); c = this.__input._getValueRelative(++j))
                stringBuffer.append(c); 
              try {
                j = Integer.parseInt(stringBuffer.toString());
              } catch (NumberFormatException numberFormatException) {
                throw new MalformedPatternException("Unexpected number format exception.  Please report this bug.NumberFormatException message: " + numberFormatException.getMessage());
              } 
              if (j > 9 && j >= this.__numParentheses) {
                bool = true;
                break;
              } 
              if (j >= this.__numParentheses)
                throw new MalformedPatternException("Invalid backreference: \\" + j); 
              this.__sawBackreference = true;
              i = _emitArgNode('\032', (char)j);
              paramArrayOfInt[0] = paramArrayOfInt[0] | true;
              for (c = this.__input._getValue(); Character.isDigit(c); c = this.__input._increment());
              this.__input._decrement();
              _getNextChar();
              break;
            case '\000':
            case '￿':
              if (this.__input._isAtEnd())
                throw new MalformedPatternException("Trailing \\ in expression."); 
              break;
          } 
          bool = true;
          break;
        case '#':
          if ((this.__modifierFlags[0] & 0x20) != '\000') {
            while (!this.__input._isAtEnd() && this.__input._getValue() != '\n')
              this.__input._increment(); 
            if (this.__input._isAtEnd())
              break; 
            continue;
          } 
          break;
      } 
      this.__input._increment();
      bool = true;
      break;
    } 
    if (bool) {
      i = _emitNode('\016');
      if (this.__program != null)
        this.__program[this.__programSize] = Character.MAX_VALUE; 
      this.__programSize++;
      byte b = 0;
      int j = this.__input._getOffset() - 1;
      int k = this.__input._getLength();
      while (b < 127 && j < k) {
        boolean bool1;
        int[] arrayOfInt1;
        char c2;
        int m = j;
        char c1 = this.__input._getValue(j);
        switch (c1) {
          case '\\':
            c1 = this.__input._getValue(++j);
            switch (c1) {
              case 'A':
              case 'B':
              case 'D':
              case 'G':
              case 'S':
              case 'W':
              case 'Z':
              case 'b':
              case 'd':
              case 's':
              case 'w':
                j--;
                break;
              case 'n':
                c2 = '\n';
                j++;
                break;
              case 'r':
                c2 = '\r';
                j++;
                break;
              case 't':
                c2 = '\t';
                j++;
                break;
              case 'f':
                c2 = '\f';
                j++;
                break;
              case 'e':
                c2 = '\033';
                j++;
                break;
              case 'a':
                c2 = '\007';
                j++;
                break;
              case 'x':
                arrayOfInt1 = new int[1];
                c2 = (char)_parseHex(this.__input._array, ++j, 2, arrayOfInt1);
                j += arrayOfInt1[0];
                break;
              case 'c':
                j++;
                c2 = this.__input._getValue(++j);
                if (Character.isLowerCase(c2))
                  c2 = Character.toUpperCase(c2); 
                c2 = (char)(c2 ^ 0x40);
                break;
              case '0':
              case '1':
              case '2':
              case '3':
              case '4':
              case '5':
              case '6':
              case '7':
              case '8':
              case '9':
                bool1 = false;
                c1 = this.__input._getValue(j);
                if (c1 == '0')
                  bool1 = true; 
                c1 = this.__input._getValue(j + 1);
                if (Character.isDigit(c1)) {
                  StringBuffer stringBuffer = new StringBuffer(10);
                  int n = j;
                  for (c1 = this.__input._getValue(n); Character.isDigit(c1); c1 = this.__input._getValue(++n))
                    stringBuffer.append(c1); 
                  try {
                    n = Integer.parseInt(stringBuffer.toString());
                  } catch (NumberFormatException numberFormatException) {
                    throw new MalformedPatternException("Unexpected number format exception.  Please report this bug.NumberFormatException message: " + numberFormatException.getMessage());
                  } 
                  if (!bool1)
                    bool1 = (n < this.__numParentheses) ? 0 : 1; 
                } 
                if (bool1) {
                  arrayOfInt1 = new int[1];
                  c2 = (char)_parseOctal(this.__input._array, j, 3, arrayOfInt1);
                  j += arrayOfInt1[0];
                  break;
                } 
                j--;
                break;
              case '\000':
              case '￿':
                if (j >= k)
                  throw new MalformedPatternException("Trailing \\ in expression."); 
              default:
                c2 = this.__input._getValue(j++);
                break;
            } 
            if ((this.__modifierFlags[0] & true) != '\000' && Character.isUpperCase(c2))
              c2 = Character.toLowerCase(c2); 
            if (j < k && _isComplexRepetitionOp(this.__input._array, j)) {
              if (b) {
                j = m;
                break;
              } 
              b++;
              if (this.__program != null)
                this.__program[this.__programSize] = c2; 
              this.__programSize++;
              break;
            } 
            if (this.__program != null)
              this.__program[this.__programSize] = c2; 
            this.__programSize++;
            b++;
            break;
          case '#':
            if ((this.__modifierFlags[0] & 0x20) != '\000')
              while (j < k && this.__input._getValue(j) != '\n')
                j++;  
          case '\t':
          case '\n':
          case '\013':
          case '\f':
          case '\r':
          case ' ':
          
          case '$':
          case '(':
          case ')':
          case '.':
          case '[':
          case '^':
          case '|':
            break;
        } 
      } 
      this.__input._setOffset(j - 1);
      _getNextChar();
      if (b < 0)
        throw new MalformedPatternException("Unexpected compilation failure.  Please report this bug!"); 
      if (b > 0)
        paramArrayOfInt[0] = paramArrayOfInt[0] | true; 
      if (b == 1)
        paramArrayOfInt[0] = paramArrayOfInt[0] | 0x2; 
      if (this.__program != null)
        this.__program[OpCode._getOperand(i)] = (char)b; 
      if (this.__program != null)
        this.__program[this.__programSize] = Character.MAX_VALUE; 
      this.__programSize++;
    } 
    return i;
  }
  
  void _setCharacterClassBits(char[] paramArrayOfChar, int paramInt, char paramChar1, char paramChar2) {
    if (this.__program == null || paramChar2 >= 'Ā')
      return; 
    paramChar2 = (char)(paramChar2 & 0xFFFF);
    if (paramChar1 == '\000') {
      paramArrayOfChar[paramInt + (paramChar2 >> '\004')] = (char)(paramArrayOfChar[paramInt + (paramChar2 >> '\004')] | '\001' << (paramChar2 & 0xF));
      return;
    } 
    paramArrayOfChar[paramInt + (paramChar2 >> '\004')] = (char)(paramArrayOfChar[paramInt + (paramChar2 >> '\004')] & ('\001' << (paramChar2 & 0xF) ^ 0xFFFFFFFF));
  }
  
  int _parseCharacterClass() throws MalformedPatternException {
    char c2;
    boolean bool2;
    boolean bool1 = false;
    char c3 = Character.MAX_VALUE;
    int[] arrayOfInt = new int[1];
    int i = _emitNode('\t');
    if (this.__input._getValue() == '^') {
      this.__cost++;
      this.__input._increment();
      c2 = Character.MIN_VALUE;
    } else {
      c2 = Character.MAX_VALUE;
    } 
    int j = this.__programSize;
    char c1;
    for (c1 = Character.MIN_VALUE; c1 < '\020'; c1 = (char)(c1 + true)) {
      if (this.__program != null)
        this.__program[this.__programSize] = c2; 
      this.__programSize++;
    } 
    c1 = this.__input._getValue();
    if (c1 == ']' || c1 == '-') {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    while ((!this.__input._isAtEnd() && (c1 = this.__input._getValue()) != ']') || bool2) {
      bool2 = false;
      this.__input._increment();
      if (c1 == '\\') {
        c1 = this.__input._postIncrement();
        switch (c1) {
          case 'w':
            for (c1 = Character.MIN_VALUE; c1 < 'Ā'; c1 = (char)(c1 + '\001')) {
              if (OpCode._isWordCharacter(c1))
                _setCharacterClassBits(this.__program, j, c2, c1); 
            } 
            c3 = Character.MAX_VALUE;
            continue;
          case 'W':
            for (c1 = Character.MIN_VALUE; c1 < 'Ā'; c1 = (char)(c1 + '\001')) {
              if (!OpCode._isWordCharacter(c1))
                _setCharacterClassBits(this.__program, j, c2, c1); 
            } 
            c3 = Character.MAX_VALUE;
            continue;
          case 's':
            for (c1 = Character.MIN_VALUE; c1 < 'Ā'; c1 = (char)(c1 + '\001')) {
              if (Character.isWhitespace(c1))
                _setCharacterClassBits(this.__program, j, c2, c1); 
            } 
            c3 = Character.MAX_VALUE;
            continue;
          case 'S':
            for (c1 = Character.MIN_VALUE; c1 < 'Ā'; c1 = (char)(c1 + '\001')) {
              if (!Character.isWhitespace(c1))
                _setCharacterClassBits(this.__program, j, c2, c1); 
            } 
            c3 = Character.MAX_VALUE;
            continue;
          case 'd':
            for (c1 = '0'; c1 <= '9'; c1 = (char)(c1 + '\001'))
              _setCharacterClassBits(this.__program, j, c2, c1); 
            c3 = Character.MAX_VALUE;
            continue;
          case 'D':
            for (c1 = Character.MIN_VALUE; c1 < '0'; c1 = (char)(c1 + '\001'))
              _setCharacterClassBits(this.__program, j, c2, c1); 
            for (c1 = ':'; c1 < 'Ā'; c1 = (char)(c1 + '\001'))
              _setCharacterClassBits(this.__program, j, c2, c1); 
            c3 = Character.MAX_VALUE;
            continue;
          case 'n':
            c1 = '\n';
            break;
          case 'r':
            c1 = '\r';
            break;
          case 't':
            c1 = '\t';
            break;
          case 'f':
            c1 = '\f';
            break;
          case 'b':
            c1 = '\b';
            break;
          case 'e':
            c1 = '\033';
            break;
          case 'a':
            c1 = '\007';
            break;
          case 'x':
            c1 = (char)_parseHex(this.__input._array, this.__input._getOffset(), 2, arrayOfInt);
            this.__input._increment(arrayOfInt[0]);
            break;
          case 'c':
            c1 = this.__input._postIncrement();
            if (Character.isLowerCase(c1))
              c1 = Character.toUpperCase(c1); 
            c1 = (char)(c1 ^ 0x40);
            break;
          case '0':
          case '1':
          case '2':
          case '3':
          case '4':
          case '5':
          case '6':
          case '7':
          case '8':
          case '9':
            c1 = (char)_parseOctal(this.__input._array, this.__input._getOffset() - 1, 3, arrayOfInt);
            this.__input._increment(arrayOfInt[0] - 1);
            break;
        } 
      } 
      if (bool1) {
        if (c3 > c1)
          throw new MalformedPatternException("Invalid [] range in expression."); 
        bool1 = false;
      } else {
        c3 = c1;
        if (this.__input._getValue() == '-' && this.__input._getOffset() + 1 < this.__input._getLength() && this.__input._getValueRelative(1) != ']') {
          this.__input._increment();
          bool1 = true;
          continue;
        } 
      } 
      while (c3 <= c1) {
        _setCharacterClassBits(this.__program, j, c2, c3);
        if ((this.__modifierFlags[0] & true) != '\000' && Character.isUpperCase(c3))
          _setCharacterClassBits(this.__program, j, c2, Character.toLowerCase(c3)); 
        c3 = (char)(c3 + '\001');
      } 
      c3 = c1;
    } 
    if (this.__input._getValue() != ']')
      throw new MalformedPatternException("Unmatched [] in expression."); 
    _getNextChar();
    return i;
  }
  
  int _parseBranch(int[] paramArrayOfInt) throws MalformedPatternException {
    boolean bool1 = false;
    boolean bool2 = false;
    int[] arrayOfInt = new int[1];
    int j = 0;
    int k = 65535;
    int i = _parseAtom(arrayOfInt);
    if (i == -1) {
      if ((arrayOfInt[0] & 0x8) != 0)
        paramArrayOfInt[0] = paramArrayOfInt[0] | 0x8; 
      return -1;
    } 
    char c = this.__input._getValue();
    if (c == '(' && this.__input._getValueRelative(1) == '?' && this.__input._getValueRelative(2) == '#') {
      while (c != Character.MAX_VALUE && c != ')')
        c = this.__input._increment(); 
      if (c != Character.MAX_VALUE) {
        _getNextChar();
        c = this.__input._getValue();
      } 
    } 
    if (c == '{' && _parseRepetition(this.__input._array, this.__input._getOffset())) {
      int m = this.__input._getOffset() + 1;
      int n = this.__input._getLength();
      int i1 = n;
      char c1;
      for (c1 = this.__input._getValue(m); Character.isDigit(c1) || c1 == ','; c1 = this.__input._getValue(++m)) {
        if (c1 == ',')
          if (i1 == n) {
            i1 = m;
          } else {
            break;
          }  
      } 
      if (c1 == '}') {
        StringBuffer stringBuffer = new StringBuffer(10);
        if (i1 == n)
          i1 = m; 
        this.__input._increment();
        int i2 = this.__input._getOffset();
        for (c1 = this.__input._getValue(i2); Character.isDigit(c1); c1 = this.__input._getValue(++i2))
          stringBuffer.append(c1); 
        try {
          j = Integer.parseInt(stringBuffer.toString());
        } catch (NumberFormatException numberFormatException) {
          throw new MalformedPatternException("Unexpected number format exception.  Please report this bug.NumberFormatException message: " + numberFormatException.getMessage());
        } 
        c1 = this.__input._getValue(i1);
        if (c1 == ',') {
          i1++;
        } else {
          i1 = this.__input._getOffset();
        } 
        i2 = i1;
        stringBuffer = new StringBuffer(10);
        for (c1 = this.__input._getValue(i2); Character.isDigit(c1); c1 = this.__input._getValue(++i2))
          stringBuffer.append(c1); 
        try {
          if (i2 != i1)
            k = Integer.parseInt(stringBuffer.toString()); 
        } catch (NumberFormatException numberFormatException) {
          throw new MalformedPatternException("Unexpected number format exception.  Please report this bug.NumberFormatException message: " + numberFormatException.getMessage());
        } 
        if (k == 0 && this.__input._getValue(i1) != '0')
          k = 65535; 
        this.__input._setOffset(m);
        _getNextChar();
        bool1 = true;
        bool2 = true;
      } 
    } 
    if (!bool1) {
      bool2 = false;
      if (c != '*' && c != '+' && c != '?') {
        paramArrayOfInt[0] = arrayOfInt[0];
        return i;
      } 
      _getNextChar();
      paramArrayOfInt[0] = (c != '+') ? 4 : 1;
      if (c == '*' && (arrayOfInt[0] & 0x2) != 0) {
        _programInsertOperator('\020', i);
        this.__cost += 4;
      } else if (c == '*') {
        j = 0;
        bool2 = true;
      } else if (c == '+' && (arrayOfInt[0] & 0x2) != 0) {
        _programInsertOperator('\021', i);
        this.__cost += 3;
      } else if (c == '+') {
        j = 1;
        bool2 = true;
      } else if (c == '?') {
        j = 0;
        k = 1;
        bool2 = true;
      } 
    } 
    if (bool2) {
      if ((arrayOfInt[0] & 0x2) != 0) {
        this.__cost += (2 + this.__cost) / 2;
        _programInsertOperator('\n', i);
      } else {
        this.__cost += 4 + this.__cost;
        _programAddTail(i, _emitNode('"'));
        _programInsertOperator('\013', i);
        _programAddTail(i, _emitNode('\017'));
      } 
      if (j > 0)
        paramArrayOfInt[0] = 1; 
      if (k != 0 && k < j)
        throw new MalformedPatternException("Invalid interval {" + j + "," + k + "}"); 
      if (this.__program != null) {
        this.__program[i + 2] = (char)j;
        this.__program[i + 3] = (char)k;
      } 
    } 
    if (this.__input._getValue() == '?') {
      _getNextChar();
      _programInsertOperator('\035', i);
      _programAddTail(i, i + 2);
    } 
    if (_isComplexRepetitionOp(this.__input._array, this.__input._getOffset()))
      throw new MalformedPatternException("Nested repetitions *?+ in expression"); 
    return i;
  }
  
  int _parseExpression(boolean paramBoolean, int[] paramArrayOfInt) throws MalformedPatternException {
    int m;
    boolean bool;
    int i = -1;
    int j = 0;
    int[] arrayOfInt = new int[1];
    paramArrayOfInt[0] = 1;
    if (paramBoolean) {
      bool = true;
      if (this.__input._getValue() == '?') {
        this.__input._increment();
        char c = this.__input._postIncrement();
        bool = c;
        switch (c) {
          case '#':
            for (c = this.__input._getValue(); c != Character.MAX_VALUE && c != ')'; c = this.__input._increment());
            if (c != ')')
              throw new MalformedPatternException("Sequence (?#... not terminated"); 
            _getNextChar();
            paramArrayOfInt[0] = 8;
            return -1;
          default:
            this.__input._decrement();
            for (c = this.__input._getValue(); c != Character.MAX_VALUE && "iogmsx".indexOf(c) != -1; c = this.__input._increment())
              _setModifierFlag(this.__modifierFlags, c); 
            if (c != ')')
              throw new MalformedPatternException("Sequence (?" + c + "...) not recognized"); 
            _getNextChar();
            paramArrayOfInt[0] = 8;
            return -1;
          case '!':
          case ':':
          case '=':
            break;
        } 
      } else {
        j = this.__numParentheses;
        this.__numParentheses++;
        i = _emitArgNode('\033', (char)j);
      } 
    } else {
      bool = false;
    } 
    int k = _parseAlternation(arrayOfInt);
    if (k == -1)
      return -1; 
    if (i != -1) {
      _programAddTail(i, k);
    } else {
      i = k;
    } 
    if ((arrayOfInt[0] & true) == 0)
      paramArrayOfInt[0] = paramArrayOfInt[0] & 0xFFFFFFFE; 
    paramArrayOfInt[0] = paramArrayOfInt[0] | arrayOfInt[0] & 0x4;
    while (this.__input._getValue() == '|') {
      _getNextChar();
      k = _parseAlternation(arrayOfInt);
      if (k == -1)
        return -1; 
      _programAddTail(i, k);
      if ((arrayOfInt[0] & true) == 0)
        paramArrayOfInt[0] = paramArrayOfInt[0] & 0xFFFFFFFE; 
      paramArrayOfInt[0] = paramArrayOfInt[0] | arrayOfInt[0] & 0x4;
    } 
    switch (bool) {
      case true:
        m = _emitNode('\017');
        break;
      case true:
        m = _emitArgNode('\034', (char)j);
        break;
      case true:
      case true:
        m = _emitNode('!');
        paramArrayOfInt[0] = paramArrayOfInt[0] & 0xFFFFFFFE;
        break;
      default:
        m = _emitNode(false);
        break;
    } 
    _programAddTail(i, m);
    for (k = i; k != -1; k = OpCode._getNext(this.__program, k))
      _programAddOperatorTail(k, m); 
    if (bool == 61) {
      _programInsertOperator('\037', i);
      _programAddTail(i, _emitNode('\017'));
    } else if (bool == 33) {
      _programInsertOperator(' ', i);
      _programAddTail(i, _emitNode('\017'));
    } 
    if (bool && (this.__input._isAtEnd() || _getNextChar() != ')'))
      throw new MalformedPatternException("Unmatched parentheses."); 
    if (!bool && !this.__input._isAtEnd()) {
      if (this.__input._getValue() == ')')
        throw new MalformedPatternException("Unmatched parentheses."); 
      throw new MalformedPatternException("Unreached characters at end of expression.  Please report this bug!");
    } 
    return i;
  }
  
  public Pattern compile(char[] paramArrayOfChar, int paramInt) throws MalformedPatternException {
    int[] arrayOfInt = new int[1];
    boolean bool1 = false;
    boolean bool2 = false;
    char c = Character.MIN_VALUE;
    this.__input = new CharStringPointer(paramArrayOfChar);
    int i = paramInt & true;
    this.__modifierFlags[0] = (char)paramInt;
    this.__sawBackreference = false;
    this.__numParentheses = 1;
    this.__programSize = 0;
    this.__cost = 0;
    this.__program = null;
    if (this.__program != null)
      this.__program[this.__programSize] = Character.MIN_VALUE; 
    this.__programSize++;
    if (_parseExpression(false, arrayOfInt) == -1)
      throw new MalformedPatternException("Unknown compilation error."); 
    if (this.__programSize >= 65534)
      throw new MalformedPatternException("Expression is too large."); 
    this.__program = new char[this.__programSize];
    Perl5Pattern perl5Pattern = new Perl5Pattern();
    perl5Pattern._program = this.__program;
    perl5Pattern._expression = new String(paramArrayOfChar);
    this.__input._setOffset(0);
    this.__numParentheses = 1;
    this.__programSize = 0;
    this.__cost = 0;
    if (this.__program != null)
      this.__program[this.__programSize] = Character.MIN_VALUE; 
    this.__programSize++;
    if (_parseExpression(false, arrayOfInt) == -1)
      throw new MalformedPatternException("Unknown compilation error."); 
    i = this.__modifierFlags[0] & true;
    perl5Pattern._isExpensive = !(this.__cost < 10);
    perl5Pattern._startClassOffset = -1;
    perl5Pattern._anchor = 0;
    perl5Pattern._back = -1;
    perl5Pattern._options = paramInt;
    perl5Pattern._startString = null;
    perl5Pattern._mustString = null;
    String str1 = null;
    String str2 = null;
    int j = 1;
    if (this.__program[OpCode._getNext(this.__program, j)] == '\000') {
      int k = j = OpCode._getNextOperator(j);
      char c1;
      for (c1 = this.__program[k]; (c1 == '\033' && (bool1 = true)) || (c1 == '\f' && this.__program[OpCode._getNext(this.__program, k)] != '\f') || c1 == '\021' || c1 == '\035' || (OpCode._opType[c1] == '\n' && OpCode._getArg1(this.__program, k) > '\000'); c1 = this.__program[k]) {
        if (c1 == '\021') {
          bool2 = true;
        } else {
          k += OpCode._operandLength[c1];
        } 
        k = OpCode._getNextOperator(k);
      } 
      boolean bool = true;
      while (bool) {
        bool = false;
        c1 = this.__program[k];
        if (c1 == '\016') {
          str2 = new String(this.__program, OpCode._getOperand(k + 1), this.__program[OpCode._getOperand(k)]);
          continue;
        } 
        if (OpCode._isInArray(c1, OpCode._opLengthOne, 2)) {
          perl5Pattern._startClassOffset = k;
          continue;
        } 
        if (c1 == '\024' || c1 == '\025') {
          perl5Pattern._startClassOffset = k;
          continue;
        } 
        if (OpCode._opType[c1] == '\001') {
          perl5Pattern._anchor = 1;
          k = OpCode._getNextOperator(k);
          bool = true;
          continue;
        } 
        if (c1 == '\020' && OpCode._opType[this.__program[OpCode._getNextOperator(k)]] == '\007' && (perl5Pattern._anchor & true) != 0) {
          perl5Pattern._anchor = 5;
          k = OpCode._getNextOperator(k);
          bool = true;
        } 
      } 
      if (bool2 && (!bool1 || !this.__sawBackreference))
        perl5Pattern._anchor |= 0x2; 
      StringBuffer stringBuffer1 = new StringBuffer();
      StringBuffer stringBuffer2 = new StringBuffer();
      int m = 0;
      c = Character.MIN_VALUE;
      int n = 0;
      int i1 = 0;
      int i2 = 0;
      while (j > 0 && (c1 = this.__program[j]) != '\000') {
        if (c1 == '\f') {
          if (this.__program[OpCode._getNext(this.__program, j)] == '\f') {
            n = -30000;
            while (this.__program[j] == '\f')
              j = OpCode._getNext(this.__program, j); 
            continue;
          } 
          j = OpCode._getNextOperator(j);
          continue;
        } 
        if (c1 == ' ') {
          n = -30000;
          j = OpCode._getNext(this.__program, j);
          continue;
        } 
        if (c1 == '\016') {
          k = j;
          int i3;
          while (this.__program[i3 = OpCode._getNext(this.__program, j)] == '\034')
            j = i3; 
          c += this.__program[OpCode._getOperand(k)];
          i3 = this.__program[OpCode._getOperand(k)];
          if (n - i1 == m) {
            stringBuffer1.append(new String(this.__program, OpCode._getOperand(k) + 1, i3));
            m += i3;
            n += i3;
            k = OpCode._getNext(this.__program, j);
          } else if (i3 >= m + ((n >= 0) ? 1 : 0)) {
            m = i3;
            stringBuffer1 = new StringBuffer(new String(this.__program, OpCode._getOperand(k) + 1, i3));
            i1 = n;
            n += m;
            k = OpCode._getNext(this.__program, j);
          } else {
            n += i3;
          } 
        } else if (OpCode._isInArray(c1, OpCode._opLengthVaries, 0)) {
          n = -30000;
          m = 0;
          if (stringBuffer1.length() > stringBuffer2.length()) {
            stringBuffer2 = stringBuffer1;
            i2 = i1;
          } 
          stringBuffer1 = new StringBuffer();
          if (c1 == '\021' && OpCode._isInArray(this.__program[OpCode._getNextOperator(j)], OpCode._opLengthOne, 0)) {
            c++;
          } else if (OpCode._opType[c1] == '\n' && OpCode._isInArray(this.__program[OpCode._getNextOperator(j) + 2], OpCode._opLengthOne, 0)) {
            c += OpCode._getArg1(this.__program, j);
          } 
        } else if (OpCode._isInArray(c1, OpCode._opLengthOne, 0)) {
          n++;
          c++;
          m = 0;
          if (stringBuffer1.length() > stringBuffer2.length()) {
            stringBuffer2 = stringBuffer1;
            i2 = i1;
          } 
          stringBuffer1 = new StringBuffer();
        } 
        j = OpCode._getNext(this.__program, j);
      } 
      if (stringBuffer1.length() + ((OpCode._opType[this.__program[k]] == '\004') ? 1 : 0) > stringBuffer2.length()) {
        stringBuffer2 = stringBuffer1;
        i2 = i1;
      } else {
        stringBuffer1 = new StringBuffer();
      } 
      if (stringBuffer2.length() > 0 && str2 == null) {
        str1 = stringBuffer2.toString();
        if (i2 < 0)
          i2 = -1; 
        perl5Pattern._back = i2;
      } else {
        stringBuffer2 = null;
      } 
    } 
    perl5Pattern._isCaseInsensitive = !((i & true) == 0);
    perl5Pattern._numParentheses = this.__numParentheses - 1;
    perl5Pattern._minLength = c;
    if (str1 != null) {
      perl5Pattern._mustString = str1.toCharArray();
      perl5Pattern._mustUtility = 100;
    } 
    if (str2 != null)
      perl5Pattern._startString = str2.toCharArray(); 
    return perl5Pattern;
  }
  
  public Pattern compile(char[] paramArrayOfChar) throws MalformedPatternException { return compile(paramArrayOfChar, 0); }
  
  public Pattern compile(String paramString) throws MalformedPatternException { return compile(paramString.toCharArray(), 0); }
  
  public Pattern compile(String paramString, int paramInt) throws MalformedPatternException { return compile(paramString.toCharArray(), paramInt); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\Perl5Compiler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */