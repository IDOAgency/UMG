package com.oroinc.text.regex;

public interface PatternMatcher {
  boolean matchesPrefix(char[] paramArrayOfChar, Pattern paramPattern, int paramInt);
  
  boolean matchesPrefix(String paramString, Pattern paramPattern);
  
  boolean matchesPrefix(char[] paramArrayOfChar, Pattern paramPattern);
  
  boolean matchesPrefix(PatternMatcherInput paramPatternMatcherInput, Pattern paramPattern);
  
  boolean matches(String paramString, Pattern paramPattern);
  
  boolean matches(char[] paramArrayOfChar, Pattern paramPattern);
  
  boolean matches(PatternMatcherInput paramPatternMatcherInput, Pattern paramPattern);
  
  boolean contains(String paramString, Pattern paramPattern);
  
  boolean contains(char[] paramArrayOfChar, Pattern paramPattern);
  
  boolean contains(PatternMatcherInput paramPatternMatcherInput, Pattern paramPattern);
  
  MatchResult getMatch();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\PatternMatcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */