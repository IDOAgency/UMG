package com.oroinc.text.regex;

import java.io.IOException;
import java.util.Stack;

public final class Perl5Matcher implements PatternMatcher {
  private static final char __EOS = '￿';
  
  private static final int __INITIAL_NUM_OFFSETS = 20;
  
  private boolean __multiline = true;
  
  private boolean __lastSuccess = false;
  
  private char __previousChar;
  
  private char[] __input;
  
  private char[] __originalInput;
  
  private Perl5Repetition __currentRep;
  
  private int __numParentheses;
  
  private int __bol;
  
  private int __eol;
  
  private int __currentOffset;
  
  private int __endOffset;
  
  private char[] __program;
  
  private int __expSize;
  
  private int __inputOffset;
  
  private int __lastParen;
  
  private int[] __beginMatchOffsets;
  
  private int[] __endMatchOffsets;
  
  private Stack __stack = new Stack();
  
  private Perl5MatchResult __lastMatchResult;
  
  private static final int __DEFAULT_LAST_MATCH_END_OFFSET = -100;
  
  private int __lastMatchInputEndOffset = -100;
  
  static boolean _compare(char[] paramArrayOfChar1, int paramInt1, char[] paramArrayOfChar2, int paramInt2, int paramInt3) {
    byte b = 0;
    while (b < paramInt3) {
      if (paramInt1 >= paramArrayOfChar1.length)
        return false; 
      if (paramInt2 >= paramArrayOfChar2.length)
        return false; 
      if (paramArrayOfChar1[paramInt1] != paramArrayOfChar2[paramInt2])
        return false; 
      b++;
      paramInt1++;
      paramInt2++;
    } 
    return true;
  }
  
  static int _findFirst(char[] paramArrayOfChar1, int paramInt1, int paramInt2, char[] paramArrayOfChar2) {
    if (paramArrayOfChar1.length == 0)
      return paramInt2; 
    char c = paramArrayOfChar2[0];
    while (paramInt1 < paramInt2) {
      if (c == paramArrayOfChar1[paramInt1]) {
        int i = paramInt1;
        byte b = 0;
        while (paramInt1 < paramInt2 && b < paramArrayOfChar2.length && paramArrayOfChar2[b] == paramArrayOfChar1[paramInt1]) {
          b++;
          paramInt1++;
        } 
        paramInt1 = i;
        if (b < paramArrayOfChar2.length)
          continue; 
        break;
      } 
      continue;
      paramInt1++;
    } 
    return paramInt1;
  }
  
  void _pushState(int paramInt) {
    int[] arrayOfInt;
    int i = 3 * (this.__expSize - paramInt);
    if (i <= 0) {
      arrayOfInt = new int[3];
    } else {
      arrayOfInt = new int[i + 3];
    } 
    arrayOfInt[0] = this.__expSize;
    arrayOfInt[1] = this.__lastParen;
    arrayOfInt[2] = this.__inputOffset;
    int j = this.__expSize;
    while (j > paramInt) {
      arrayOfInt[i] = this.__endMatchOffsets[j];
      arrayOfInt[i + 1] = this.__beginMatchOffsets[j];
      arrayOfInt[i + 2] = j;
      j -= 3;
      i -= 3;
    } 
    this.__stack.push(arrayOfInt);
  }
  
  void _popState() {
    int[] arrayOfInt = (int[])this.__stack.pop();
    this.__expSize = arrayOfInt[0];
    this.__lastParen = arrayOfInt[1];
    this.__inputOffset = arrayOfInt[2];
    for (byte b = 3; b < arrayOfInt.length; b += 3) {
      int j = arrayOfInt[b + 2];
      this.__beginMatchOffsets[j] = arrayOfInt[b + 1];
      if (j <= this.__lastParen)
        this.__endMatchOffsets[j] = arrayOfInt[b]; 
    } 
    for (int i = this.__lastParen + 1; i <= this.__numParentheses; i++) {
      if (i > this.__expSize)
        this.__beginMatchOffsets[i] = -1; 
      this.__endMatchOffsets[i] = -1;
    } 
  }
  
  private void __initInterpreterGlobals(Perl5Pattern paramPerl5Pattern, char[] paramArrayOfChar, int paramInt1, int paramInt2) {
    this.__input = paramArrayOfChar;
    this.__endOffset = paramInt2;
    this.__currentRep = new Perl5Repetition();
    this.__currentRep._numInstances = 0;
    this.__currentRep._lastRepetition = null;
    this.__program = paramPerl5Pattern._program;
    this.__stack.setSize(0);
    if (paramInt1 == 0) {
      this.__previousChar = '\n';
    } else {
      this.__previousChar = paramArrayOfChar[paramInt1 - 1];
      if (!this.__multiline && this.__previousChar == '\n')
        this.__previousChar = Character.MIN_VALUE; 
    } 
    this.__numParentheses = paramPerl5Pattern._numParentheses;
    this.__currentOffset = paramInt1;
    this.__bol = paramInt1;
    this.__eol = paramInt2;
    paramInt2 = this.__numParentheses + 1;
    if (this.__beginMatchOffsets == null || paramInt2 > this.__beginMatchOffsets.length) {
      if (paramInt2 < 20)
        paramInt2 = 20; 
      this.__beginMatchOffsets = new int[paramInt2];
      this.__endMatchOffsets = new int[paramInt2];
    } 
  }
  
  void __setLastMatchResult() {
    this.__lastMatchResult = new Perl5MatchResult(this.__numParentheses + 1);
    if (this.__endMatchOffsets[0] > this.__originalInput.length)
      throw new ArrayIndexOutOfBoundsException(); 
    this.__lastMatchResult._match = new String(this.__originalInput, this.__beginMatchOffsets[0], this.__endMatchOffsets[0] - this.__beginMatchOffsets[0]);
    this.__lastMatchResult._matchBeginOffset = this.__beginMatchOffsets[0];
    while (this.__numParentheses >= 0) {
      int i = this.__beginMatchOffsets[this.__numParentheses];
      if (i >= 0) {
        this.__lastMatchResult._beginGroupOffset[this.__numParentheses] = i - this.__lastMatchResult._matchBeginOffset;
      } else {
        this.__lastMatchResult._beginGroupOffset[this.__numParentheses] = -1;
      } 
      i = this.__endMatchOffsets[this.__numParentheses];
      if (i >= 0) {
        this.__lastMatchResult._endGroupOffset[this.__numParentheses] = i - this.__lastMatchResult._matchBeginOffset;
      } else {
        this.__lastMatchResult._endGroupOffset[this.__numParentheses] = -1;
      } 
      this.__numParentheses--;
    } 
    this.__originalInput = null;
  }
  
  boolean _interpret(Perl5Pattern paramPerl5Pattern, char[] paramArrayOfChar, int paramInt1, int paramInt2) { // Byte code:
    //   0: iconst_0
    //   1: istore #6
    //   3: iconst_0
    //   4: istore #7
    //   6: aload_0
    //   7: aload_1
    //   8: aload_2
    //   9: iload_3
    //   10: iload #4
    //   12: invokespecial __initInterpreterGlobals : (Lcom/oroinc/text/regex/Perl5Pattern;[CII)V
    //   15: iconst_0
    //   16: istore #5
    //   18: aload_1
    //   19: getfield _mustString : [C
    //   22: astore #10
    //   24: aload #10
    //   26: ifnull -> 209
    //   29: aload_1
    //   30: getfield _anchor : I
    //   33: iconst_1
    //   34: iand
    //   35: ifeq -> 52
    //   38: aload_0
    //   39: getfield __multiline : Z
    //   42: ifeq -> 209
    //   45: aload_1
    //   46: getfield _back : I
    //   49: iflt -> 209
    //   52: aload_0
    //   53: aload_0
    //   54: getfield __input : [C
    //   57: aload_0
    //   58: getfield __currentOffset : I
    //   61: iload #4
    //   63: aload #10
    //   65: invokestatic _findFirst : ([CII[C)I
    //   68: putfield __currentOffset : I
    //   71: aload_0
    //   72: getfield __currentOffset : I
    //   75: iload #4
    //   77: if_icmplt -> 106
    //   80: aload_1
    //   81: getfield _options : I
    //   84: ldc 32768
    //   86: iand
    //   87: ifne -> 100
    //   90: aload_1
    //   91: dup
    //   92: getfield _mustUtility : I
    //   95: iconst_1
    //   96: iadd
    //   97: putfield _mustUtility : I
    //   100: iconst_0
    //   101: istore #5
    //   103: goto -> 1566
    //   106: aload_1
    //   107: getfield _back : I
    //   110: iflt -> 152
    //   113: aload_0
    //   114: dup
    //   115: getfield __currentOffset : I
    //   118: aload_1
    //   119: getfield _back : I
    //   122: isub
    //   123: putfield __currentOffset : I
    //   126: aload_0
    //   127: getfield __currentOffset : I
    //   130: iload_3
    //   131: if_icmpge -> 139
    //   134: aload_0
    //   135: iload_3
    //   136: putfield __currentOffset : I
    //   139: aload_1
    //   140: getfield _back : I
    //   143: aload #10
    //   145: arraylength
    //   146: iadd
    //   147: istore #6
    //   149: goto -> 209
    //   152: aload_1
    //   153: getfield _isExpensive : Z
    //   156: ifne -> 199
    //   159: aload_1
    //   160: getfield _options : I
    //   163: ldc 32768
    //   165: iand
    //   166: ifne -> 199
    //   169: aload_1
    //   170: dup
    //   171: getfield _mustUtility : I
    //   174: iconst_1
    //   175: isub
    //   176: dup_x1
    //   177: putfield _mustUtility : I
    //   180: ifge -> 199
    //   183: aload_1
    //   184: aconst_null
    //   185: dup_x1
    //   186: putfield _mustString : [C
    //   189: astore #10
    //   191: aload_0
    //   192: iload_3
    //   193: putfield __currentOffset : I
    //   196: goto -> 209
    //   199: aload_0
    //   200: iload_3
    //   201: putfield __currentOffset : I
    //   204: aload #10
    //   206: arraylength
    //   207: istore #6
    //   209: aload_1
    //   210: getfield _anchor : I
    //   213: iconst_1
    //   214: iand
    //   215: ifeq -> 348
    //   218: aload_0
    //   219: aload_1
    //   220: iload_3
    //   221: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   224: ifeq -> 233
    //   227: iconst_1
    //   228: istore #5
    //   230: goto -> 1566
    //   233: aload_0
    //   234: getfield __multiline : Z
    //   237: ifne -> 249
    //   240: aload_1
    //   241: getfield _anchor : I
    //   244: iconst_4
    //   245: iand
    //   246: ifeq -> 1566
    //   249: iload #6
    //   251: ifle -> 260
    //   254: iload #6
    //   256: iconst_1
    //   257: isub
    //   258: istore #7
    //   260: iload #4
    //   262: iload #7
    //   264: isub
    //   265: istore #4
    //   267: aload_0
    //   268: getfield __currentOffset : I
    //   271: iload_3
    //   272: if_icmple -> 336
    //   275: aload_0
    //   276: dup
    //   277: getfield __currentOffset : I
    //   280: iconst_1
    //   281: isub
    //   282: putfield __currentOffset : I
    //   285: goto -> 336
    //   288: aload_0
    //   289: getfield __input : [C
    //   292: aload_0
    //   293: dup
    //   294: getfield __currentOffset : I
    //   297: dup_x1
    //   298: iconst_1
    //   299: iadd
    //   300: putfield __currentOffset : I
    //   303: caload
    //   304: bipush #10
    //   306: if_icmpne -> 336
    //   309: aload_0
    //   310: getfield __currentOffset : I
    //   313: iload #4
    //   315: if_icmpge -> 336
    //   318: aload_0
    //   319: aload_1
    //   320: aload_0
    //   321: getfield __currentOffset : I
    //   324: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   327: ifeq -> 336
    //   330: iconst_1
    //   331: istore #5
    //   333: goto -> 1566
    //   336: aload_0
    //   337: getfield __currentOffset : I
    //   340: iload #4
    //   342: if_icmplt -> 288
    //   345: goto -> 1566
    //   348: aload_1
    //   349: getfield _startString : [C
    //   352: ifnull -> 535
    //   355: aload_1
    //   356: getfield _startString : [C
    //   359: astore #10
    //   361: aload_1
    //   362: getfield _anchor : I
    //   365: iconst_2
    //   366: iand
    //   367: ifeq -> 507
    //   370: aload #10
    //   372: iconst_0
    //   373: caload
    //   374: istore #9
    //   376: goto -> 467
    //   379: iload #9
    //   381: aload_0
    //   382: getfield __input : [C
    //   385: aload_0
    //   386: getfield __currentOffset : I
    //   389: caload
    //   390: if_icmpne -> 457
    //   393: aload_0
    //   394: aload_1
    //   395: aload_0
    //   396: getfield __currentOffset : I
    //   399: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   402: ifeq -> 411
    //   405: iconst_1
    //   406: istore #5
    //   408: goto -> 1566
    //   411: aload_0
    //   412: dup
    //   413: getfield __currentOffset : I
    //   416: iconst_1
    //   417: iadd
    //   418: putfield __currentOffset : I
    //   421: goto -> 434
    //   424: aload_0
    //   425: dup
    //   426: getfield __currentOffset : I
    //   429: iconst_1
    //   430: iadd
    //   431: putfield __currentOffset : I
    //   434: aload_0
    //   435: getfield __currentOffset : I
    //   438: iload #4
    //   440: if_icmpge -> 457
    //   443: aload_0
    //   444: getfield __input : [C
    //   447: aload_0
    //   448: getfield __currentOffset : I
    //   451: caload
    //   452: iload #9
    //   454: if_icmpeq -> 424
    //   457: aload_0
    //   458: dup
    //   459: getfield __currentOffset : I
    //   462: iconst_1
    //   463: iadd
    //   464: putfield __currentOffset : I
    //   467: aload_0
    //   468: getfield __currentOffset : I
    //   471: iload #4
    //   473: if_icmplt -> 379
    //   476: goto -> 1566
    //   479: aload_0
    //   480: aload_1
    //   481: aload_0
    //   482: getfield __currentOffset : I
    //   485: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   488: ifeq -> 497
    //   491: iconst_1
    //   492: istore #5
    //   494: goto -> 1566
    //   497: aload_0
    //   498: dup
    //   499: getfield __currentOffset : I
    //   502: iconst_1
    //   503: iadd
    //   504: putfield __currentOffset : I
    //   507: aload_0
    //   508: aload_0
    //   509: getfield __input : [C
    //   512: aload_0
    //   513: getfield __currentOffset : I
    //   516: iload #4
    //   518: aload #10
    //   520: invokestatic _findFirst : ([CII[C)I
    //   523: dup_x1
    //   524: putfield __currentOffset : I
    //   527: iload #4
    //   529: if_icmplt -> 479
    //   532: goto -> 1566
    //   535: aload_1
    //   536: getfield _startClassOffset : I
    //   539: dup
    //   540: istore #8
    //   542: iconst_m1
    //   543: if_icmpeq -> 1514
    //   546: aload_1
    //   547: getfield _anchor : I
    //   550: iconst_2
    //   551: iand
    //   552: ifeq -> 559
    //   555: iconst_0
    //   556: goto -> 560
    //   559: iconst_1
    //   560: istore #11
    //   562: iload #6
    //   564: ifle -> 573
    //   567: iload #6
    //   569: iconst_1
    //   570: isub
    //   571: istore #7
    //   573: iload #4
    //   575: iload #7
    //   577: isub
    //   578: istore #4
    //   580: iconst_1
    //   581: istore #12
    //   583: aload_0
    //   584: getfield __program : [C
    //   587: iload #8
    //   589: caload
    //   590: lookupswitch default -> 1566, 9 -> 672, 18 -> 1148, 19 -> 1222, 20 -> 779, 21 -> 931, 22 -> 1292, 23 -> 1362, 24 -> 1432, 25 -> 1502
    //   672: iload #8
    //   674: invokestatic _getOperand : (I)I
    //   677: istore #8
    //   679: goto -> 767
    //   682: aload_0
    //   683: getfield __input : [C
    //   686: aload_0
    //   687: getfield __currentOffset : I
    //   690: caload
    //   691: istore #9
    //   693: iload #9
    //   695: sipush #256
    //   698: if_icmpge -> 754
    //   701: aload_0
    //   702: getfield __program : [C
    //   705: iload #8
    //   707: iload #9
    //   709: iconst_4
    //   710: ishr
    //   711: iadd
    //   712: caload
    //   713: iconst_1
    //   714: iload #9
    //   716: bipush #15
    //   718: iand
    //   719: ishl
    //   720: iand
    //   721: ifne -> 754
    //   724: iload #12
    //   726: ifeq -> 747
    //   729: aload_0
    //   730: aload_1
    //   731: aload_0
    //   732: getfield __currentOffset : I
    //   735: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   738: ifeq -> 747
    //   741: iconst_1
    //   742: istore #5
    //   744: goto -> 1566
    //   747: iload #11
    //   749: istore #12
    //   751: goto -> 757
    //   754: iconst_1
    //   755: istore #12
    //   757: aload_0
    //   758: dup
    //   759: getfield __currentOffset : I
    //   762: iconst_1
    //   763: iadd
    //   764: putfield __currentOffset : I
    //   767: aload_0
    //   768: getfield __currentOffset : I
    //   771: iload #4
    //   773: if_icmplt -> 682
    //   776: goto -> 1566
    //   779: iload #6
    //   781: ifle -> 790
    //   784: iinc #7, 1
    //   787: iinc #4, -1
    //   790: aload_0
    //   791: getfield __currentOffset : I
    //   794: iload_3
    //   795: if_icmpeq -> 821
    //   798: aload_0
    //   799: getfield __input : [C
    //   802: aload_0
    //   803: getfield __currentOffset : I
    //   806: iconst_1
    //   807: isub
    //   808: caload
    //   809: istore #9
    //   811: iload #9
    //   813: invokestatic _isWordCharacter : (C)Z
    //   816: istore #12
    //   818: goto -> 894
    //   821: aload_0
    //   822: getfield __previousChar : C
    //   825: invokestatic _isWordCharacter : (C)Z
    //   828: istore #12
    //   830: goto -> 894
    //   833: aload_0
    //   834: getfield __input : [C
    //   837: aload_0
    //   838: getfield __currentOffset : I
    //   841: caload
    //   842: istore #9
    //   844: iload #12
    //   846: iload #9
    //   848: invokestatic _isWordCharacter : (C)Z
    //   851: if_icmpeq -> 884
    //   854: iload #12
    //   856: ifeq -> 863
    //   859: iconst_0
    //   860: goto -> 864
    //   863: iconst_1
    //   864: istore #12
    //   866: aload_0
    //   867: aload_1
    //   868: aload_0
    //   869: getfield __currentOffset : I
    //   872: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   875: ifeq -> 884
    //   878: iconst_1
    //   879: istore #5
    //   881: goto -> 1566
    //   884: aload_0
    //   885: dup
    //   886: getfield __currentOffset : I
    //   889: iconst_1
    //   890: iadd
    //   891: putfield __currentOffset : I
    //   894: aload_0
    //   895: getfield __currentOffset : I
    //   898: iload #4
    //   900: if_icmplt -> 833
    //   903: iload #6
    //   905: ifgt -> 913
    //   908: iload #12
    //   910: ifeq -> 1566
    //   913: aload_0
    //   914: aload_1
    //   915: aload_0
    //   916: getfield __currentOffset : I
    //   919: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   922: ifeq -> 1566
    //   925: iconst_1
    //   926: istore #5
    //   928: goto -> 1566
    //   931: iload #6
    //   933: ifle -> 942
    //   936: iinc #7, 1
    //   939: iinc #4, -1
    //   942: aload_0
    //   943: getfield __currentOffset : I
    //   946: iload_3
    //   947: if_icmpeq -> 973
    //   950: aload_0
    //   951: getfield __input : [C
    //   954: aload_0
    //   955: getfield __currentOffset : I
    //   958: iconst_1
    //   959: isub
    //   960: caload
    //   961: istore #9
    //   963: iload #9
    //   965: invokestatic _isWordCharacter : (C)Z
    //   968: istore #12
    //   970: goto -> 1049
    //   973: aload_0
    //   974: getfield __previousChar : C
    //   977: invokestatic _isWordCharacter : (C)Z
    //   980: istore #12
    //   982: goto -> 1049
    //   985: aload_0
    //   986: getfield __input : [C
    //   989: aload_0
    //   990: getfield __currentOffset : I
    //   993: caload
    //   994: istore #9
    //   996: iload #12
    //   998: iload #9
    //   1000: invokestatic _isWordCharacter : (C)Z
    //   1003: if_icmpeq -> 1021
    //   1006: iload #12
    //   1008: ifeq -> 1015
    //   1011: iconst_0
    //   1012: goto -> 1016
    //   1015: iconst_1
    //   1016: istore #12
    //   1018: goto -> 1039
    //   1021: aload_0
    //   1022: aload_1
    //   1023: aload_0
    //   1024: getfield __currentOffset : I
    //   1027: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   1030: ifeq -> 1039
    //   1033: iconst_1
    //   1034: istore #5
    //   1036: goto -> 1566
    //   1039: aload_0
    //   1040: dup
    //   1041: getfield __currentOffset : I
    //   1044: iconst_1
    //   1045: iadd
    //   1046: putfield __currentOffset : I
    //   1049: aload_0
    //   1050: getfield __currentOffset : I
    //   1053: iload #4
    //   1055: if_icmplt -> 985
    //   1058: iload #6
    //   1060: ifgt -> 1068
    //   1063: iload #12
    //   1065: ifne -> 1566
    //   1068: aload_0
    //   1069: aload_1
    //   1070: aload_0
    //   1071: getfield __currentOffset : I
    //   1074: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   1077: ifeq -> 1566
    //   1080: iconst_1
    //   1081: istore #5
    //   1083: goto -> 1566
    //   1086: aload_0
    //   1087: getfield __input : [C
    //   1090: aload_0
    //   1091: getfield __currentOffset : I
    //   1094: caload
    //   1095: istore #9
    //   1097: iload #9
    //   1099: invokestatic _isWordCharacter : (C)Z
    //   1102: ifeq -> 1135
    //   1105: iload #12
    //   1107: ifeq -> 1128
    //   1110: aload_0
    //   1111: aload_1
    //   1112: aload_0
    //   1113: getfield __currentOffset : I
    //   1116: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   1119: ifeq -> 1128
    //   1122: iconst_1
    //   1123: istore #5
    //   1125: goto -> 1566
    //   1128: iload #11
    //   1130: istore #12
    //   1132: goto -> 1138
    //   1135: iconst_1
    //   1136: istore #12
    //   1138: aload_0
    //   1139: dup
    //   1140: getfield __currentOffset : I
    //   1143: iconst_1
    //   1144: iadd
    //   1145: putfield __currentOffset : I
    //   1148: aload_0
    //   1149: getfield __currentOffset : I
    //   1152: iload #4
    //   1154: if_icmplt -> 1086
    //   1157: goto -> 1566
    //   1160: aload_0
    //   1161: getfield __input : [C
    //   1164: aload_0
    //   1165: getfield __currentOffset : I
    //   1168: caload
    //   1169: istore #9
    //   1171: iload #9
    //   1173: invokestatic _isWordCharacter : (C)Z
    //   1176: ifne -> 1209
    //   1179: iload #12
    //   1181: ifeq -> 1202
    //   1184: aload_0
    //   1185: aload_1
    //   1186: aload_0
    //   1187: getfield __currentOffset : I
    //   1190: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   1193: ifeq -> 1202
    //   1196: iconst_1
    //   1197: istore #5
    //   1199: goto -> 1566
    //   1202: iload #11
    //   1204: istore #12
    //   1206: goto -> 1212
    //   1209: iconst_1
    //   1210: istore #12
    //   1212: aload_0
    //   1213: dup
    //   1214: getfield __currentOffset : I
    //   1217: iconst_1
    //   1218: iadd
    //   1219: putfield __currentOffset : I
    //   1222: aload_0
    //   1223: getfield __currentOffset : I
    //   1226: iload #4
    //   1228: if_icmplt -> 1160
    //   1231: goto -> 1566
    //   1234: aload_0
    //   1235: getfield __input : [C
    //   1238: aload_0
    //   1239: getfield __currentOffset : I
    //   1242: caload
    //   1243: invokestatic isWhitespace : (C)Z
    //   1246: ifeq -> 1279
    //   1249: iload #12
    //   1251: ifeq -> 1272
    //   1254: aload_0
    //   1255: aload_1
    //   1256: aload_0
    //   1257: getfield __currentOffset : I
    //   1260: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   1263: ifeq -> 1272
    //   1266: iconst_1
    //   1267: istore #5
    //   1269: goto -> 1566
    //   1272: iload #11
    //   1274: istore #12
    //   1276: goto -> 1282
    //   1279: iconst_1
    //   1280: istore #12
    //   1282: aload_0
    //   1283: dup
    //   1284: getfield __currentOffset : I
    //   1287: iconst_1
    //   1288: iadd
    //   1289: putfield __currentOffset : I
    //   1292: aload_0
    //   1293: getfield __currentOffset : I
    //   1296: iload #4
    //   1298: if_icmplt -> 1234
    //   1301: goto -> 1566
    //   1304: aload_0
    //   1305: getfield __input : [C
    //   1308: aload_0
    //   1309: getfield __currentOffset : I
    //   1312: caload
    //   1313: invokestatic isWhitespace : (C)Z
    //   1316: ifne -> 1349
    //   1319: iload #12
    //   1321: ifeq -> 1342
    //   1324: aload_0
    //   1325: aload_1
    //   1326: aload_0
    //   1327: getfield __currentOffset : I
    //   1330: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   1333: ifeq -> 1342
    //   1336: iconst_1
    //   1337: istore #5
    //   1339: goto -> 1566
    //   1342: iload #11
    //   1344: istore #12
    //   1346: goto -> 1352
    //   1349: iconst_1
    //   1350: istore #12
    //   1352: aload_0
    //   1353: dup
    //   1354: getfield __currentOffset : I
    //   1357: iconst_1
    //   1358: iadd
    //   1359: putfield __currentOffset : I
    //   1362: aload_0
    //   1363: getfield __currentOffset : I
    //   1366: iload #4
    //   1368: if_icmplt -> 1304
    //   1371: goto -> 1566
    //   1374: aload_0
    //   1375: getfield __input : [C
    //   1378: aload_0
    //   1379: getfield __currentOffset : I
    //   1382: caload
    //   1383: invokestatic isDigit : (C)Z
    //   1386: ifeq -> 1419
    //   1389: iload #12
    //   1391: ifeq -> 1412
    //   1394: aload_0
    //   1395: aload_1
    //   1396: aload_0
    //   1397: getfield __currentOffset : I
    //   1400: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   1403: ifeq -> 1412
    //   1406: iconst_1
    //   1407: istore #5
    //   1409: goto -> 1566
    //   1412: iload #11
    //   1414: istore #12
    //   1416: goto -> 1422
    //   1419: iconst_1
    //   1420: istore #12
    //   1422: aload_0
    //   1423: dup
    //   1424: getfield __currentOffset : I
    //   1427: iconst_1
    //   1428: iadd
    //   1429: putfield __currentOffset : I
    //   1432: aload_0
    //   1433: getfield __currentOffset : I
    //   1436: iload #4
    //   1438: if_icmplt -> 1374
    //   1441: goto -> 1566
    //   1444: aload_0
    //   1445: getfield __input : [C
    //   1448: aload_0
    //   1449: getfield __currentOffset : I
    //   1452: caload
    //   1453: invokestatic isDigit : (C)Z
    //   1456: ifne -> 1489
    //   1459: iload #12
    //   1461: ifeq -> 1482
    //   1464: aload_0
    //   1465: aload_1
    //   1466: aload_0
    //   1467: getfield __currentOffset : I
    //   1470: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   1473: ifeq -> 1482
    //   1476: iconst_1
    //   1477: istore #5
    //   1479: goto -> 1566
    //   1482: iload #11
    //   1484: istore #12
    //   1486: goto -> 1492
    //   1489: iconst_1
    //   1490: istore #12
    //   1492: aload_0
    //   1493: dup
    //   1494: getfield __currentOffset : I
    //   1497: iconst_1
    //   1498: iadd
    //   1499: putfield __currentOffset : I
    //   1502: aload_0
    //   1503: getfield __currentOffset : I
    //   1506: iload #4
    //   1508: if_icmplt -> 1444
    //   1511: goto -> 1566
    //   1514: iload #6
    //   1516: ifle -> 1525
    //   1519: iload #6
    //   1521: iconst_1
    //   1522: isub
    //   1523: istore #7
    //   1525: iload #4
    //   1527: iload #7
    //   1529: isub
    //   1530: istore #4
    //   1532: aload_0
    //   1533: aload_1
    //   1534: aload_0
    //   1535: getfield __currentOffset : I
    //   1538: invokevirtual _tryExpression : (Lcom/oroinc/text/regex/Perl5Pattern;I)Z
    //   1541: ifeq -> 1550
    //   1544: iconst_1
    //   1545: istore #5
    //   1547: goto -> 1566
    //   1550: aload_0
    //   1551: dup
    //   1552: getfield __currentOffset : I
    //   1555: dup_x1
    //   1556: iconst_1
    //   1557: iadd
    //   1558: putfield __currentOffset : I
    //   1561: iload #4
    //   1563: if_icmplt -> 1532
    //   1566: aload_0
    //   1567: iload #5
    //   1569: putfield __lastSuccess : Z
    //   1572: aload_0
    //   1573: aconst_null
    //   1574: putfield __lastMatchResult : Lcom/oroinc/text/regex/Perl5MatchResult;
    //   1577: iload #5
    //   1579: ireturn }
  
  boolean _tryExpression(Perl5Pattern paramPerl5Pattern, int paramInt) {
    this.__inputOffset = paramInt;
    this.__lastParen = 0;
    this.__expSize = 0;
    if (this.__numParentheses > 0)
      for (byte b = 0; b <= this.__numParentheses; b++) {
        this.__beginMatchOffsets[b] = -1;
        this.__endMatchOffsets[b] = -1;
      }  
    if (_match(1)) {
      this.__beginMatchOffsets[0] = paramInt;
      this.__endMatchOffsets[0] = this.__inputOffset;
      return true;
    } 
    return false;
  }
  
  int _repeat(int paramInt1, int paramInt2) {
    char c;
    int i = this.__inputOffset;
    int j = this.__eol;
    if (paramInt2 != 65535 && paramInt2 < j - i)
      j = i + paramInt2; 
    int k = OpCode._getOperand(paramInt1);
    switch (this.__program[paramInt1]) {
      case '\007':
        while (i < j && this.__input[i] != '\n')
          i++; 
        break;
      case '\b':
        i = j;
        break;
      case '\016':
        while (i < j && this.__program[++k] == this.__input[i])
          i++; 
        break;
      case '\t':
        if (i < j && (c = this.__input[i]) < 'Ā')
          while ((this.__program[k + (c >> '\004')] & '\001' << (c & 0xF)) == '\000' && ++i < j)
            c = this.__input[i];  
        break;
      case '\022':
        while (i < j && OpCode._isWordCharacter(this.__input[i]))
          i++; 
        break;
      case '\023':
        while (i < j && !OpCode._isWordCharacter(this.__input[i]))
          i++; 
        break;
      case '\026':
        while (i < j && Character.isWhitespace(this.__input[i]))
          i++; 
        break;
      case '\027':
        while (i < j && !Character.isWhitespace(this.__input[i]))
          i++; 
        break;
      case '\030':
        while (i < j && Character.isDigit(this.__input[i]))
          i++; 
        break;
      case '\031':
        while (i < j && !Character.isDigit(this.__input[i]))
          i++; 
        break;
    } 
    int m = i - this.__inputOffset;
    this.__inputOffset = i;
    return m;
  }
  
  boolean _match(int paramInt) {
    boolean bool = true;
    boolean bool1 = false;
    int j = this.__inputOffset;
    bool = (j >= this.__endOffset) ? 0 : 1;
    char c = bool ? this.__input[j] : Character.MAX_VALUE;
    int i = paramInt;
    int k = this.__program.length;
    while (i < k) {
      int i3;
      boolean bool3;
      boolean bool2;
      Perl5Repetition perl5Repetition;
      char c3;
      int i2;
      char c2;
      int i1;
      int n;
      int m = OpCode._getNext(this.__program, i);
      char c1;
      switch (c1 = this.__program[i]) {
        case '\001':
        case '\002':
          if (bool || j < this.__eol) {
            if (this.__input[j - 1] != '\n') {
            
            } else {
              break;
            } 
          } else {
            return false;
          } 
          if (!((j == this.__bol) ? (this.__previousChar == '\n') : "JD-Core does not support Kotlin"))
            return false; 
          break;
        case '\003':
          if (j != this.__bol || this.__previousChar != '\n')
            return false; 
          break;
        case '\036':
          if (j != this.__bol)
            return true; 
          break;
        case '\004':
          if ((bool || j < this.__eol) && c != '\n')
            return false; 
          if (!this.__multiline && this.__eol - j > 1)
            return false; 
          break;
        case '\005':
          if ((bool || j < this.__eol) && c != '\n')
            return false; 
          break;
        case '\006':
          if ((bool || j < this.__eol) && c != '\n')
            return false; 
          if (this.__eol - j > 1)
            return false; 
          break;
        case '\b':
          if (!bool && j >= this.__eol)
            return false; 
          bool = (++j >= this.__endOffset) ? 0 : 1;
          c = bool ? this.__input[j] : Character.MAX_VALUE;
          break;
        case '\007':
          if ((!bool && j >= this.__eol) || c == '\n')
            return false; 
          bool = (++j >= this.__endOffset) ? 0 : 1;
          c = bool ? this.__input[j] : Character.MAX_VALUE;
          break;
        case '\016':
          n = OpCode._getOperand(i);
          c2 = this.__program[n++];
          if (this.__program[n] != c)
            return false; 
          if (this.__eol - j < c2)
            return false; 
          if (c2 > '\001' && !_compare(this.__program, n, this.__input, j, c2))
            return false; 
          j += c2;
          bool = (j >= this.__endOffset) ? 0 : 1;
          c = bool ? this.__input[j] : Character.MAX_VALUE;
          break;
        case '\t':
          n = OpCode._getOperand(i);
          if (c == Character.MAX_VALUE && bool)
            c = this.__input[j]; 
          if (c >= 'Ā' || (this.__program[n + (c >> '\004')] & '\001' << (c & 0xF)) != '\000')
            return false; 
          if (!bool && j >= this.__eol)
            return false; 
          bool = (++j >= this.__endOffset) ? 0 : 1;
          c = bool ? this.__input[j] : Character.MAX_VALUE;
          break;
        case '\022':
          if (!bool)
            return false; 
          if (!OpCode._isWordCharacter(c))
            return false; 
          bool = (++j >= this.__endOffset) ? 0 : 1;
          c = bool ? this.__input[j] : Character.MAX_VALUE;
          break;
        case '\023':
          if (!bool && j >= this.__eol)
            return false; 
          if (OpCode._isWordCharacter(c))
            return false; 
          bool = (++j >= this.__endOffset) ? 0 : 1;
          c = bool ? this.__input[j] : Character.MAX_VALUE;
          break;
        case '\024':
        case '\025':
          if (j == this.__bol) {
            bool2 = OpCode._isWordCharacter(this.__previousChar);
          } else {
            bool2 = OpCode._isWordCharacter(this.__input[j - 1]);
          } 
          bool3 = OpCode._isWordCharacter(c);
          if (((bool2 != bool3) ? 0 : 1) == ((this.__program[i] != '\024') ? 0 : 1))
            return false; 
          break;
        case '\026':
          if (!bool && j >= this.__eol)
            return false; 
          if (!Character.isWhitespace(c))
            return false; 
          bool = (++j >= this.__endOffset) ? 0 : 1;
          c = bool ? this.__input[j] : Character.MAX_VALUE;
          break;
        case '\027':
          if (!bool)
            return false; 
          if (Character.isWhitespace(c))
            return false; 
          bool = (++j >= this.__endOffset) ? 0 : 1;
          c = bool ? this.__input[j] : Character.MAX_VALUE;
          break;
        case '\030':
          if (!Character.isDigit(c))
            return false; 
          bool = (++j >= this.__endOffset) ? 0 : 1;
          c = bool ? this.__input[j] : Character.MAX_VALUE;
          break;
        case '\031':
          if (!bool && j >= this.__eol)
            return false; 
          if (Character.isDigit(c))
            return false; 
          bool = (++j >= this.__endOffset) ? 0 : 1;
          c = bool ? this.__input[j] : Character.MAX_VALUE;
          break;
        case '\032':
          c3 = OpCode._getArg1(this.__program, i);
          n = this.__beginMatchOffsets[c3];
          if (n == -1)
            return false; 
          if (this.__endMatchOffsets[c3] == -1)
            return false; 
          if (n != this.__endMatchOffsets[c3]) {
            if (this.__input[n] != c)
              return false; 
            int i4 = this.__endMatchOffsets[c3] - n;
            if (j + i4 > this.__eol)
              return false; 
            if (i4 > 1 && !_compare(this.__input, n, this.__input, j, i4))
              return false; 
            j += i4;
            bool = (j >= this.__endOffset) ? 0 : 1;
            c = bool ? this.__input[j] : Character.MAX_VALUE;
          } 
          break;
        case '\033':
          c3 = OpCode._getArg1(this.__program, i);
          this.__beginMatchOffsets[c3] = j;
          if (c3 > this.__expSize)
            this.__expSize = c3; 
          break;
        case '\034':
          c3 = OpCode._getArg1(this.__program, i);
          this.__endMatchOffsets[c3] = j;
          if (c3 > this.__lastParen)
            this.__lastParen = c3; 
          break;
        case '\013':
          perl5Repetition = new Perl5Repetition();
          perl5Repetition._lastRepetition = this.__currentRep;
          this.__currentRep = perl5Repetition;
          perl5Repetition._parenFloor = this.__lastParen;
          perl5Repetition._numInstances = -1;
          perl5Repetition._min = OpCode._getArg1(this.__program, i);
          perl5Repetition._max = OpCode._getArg2(this.__program, i);
          perl5Repetition._scan = OpCode._getNextOperator(i) + 2;
          perl5Repetition._next = m;
          perl5Repetition._minMod = bool1;
          perl5Repetition._lastLocation = -1;
          this.__inputOffset = j;
          bool1 = _match(OpCode._getPrevOperator(m));
          this.__currentRep = perl5Repetition._lastRepetition;
          return bool1;
        case '"':
          perl5Repetition = this.__currentRep;
          i2 = perl5Repetition._numInstances + 1;
          this.__inputOffset = j;
          if (j == perl5Repetition._lastLocation) {
            this.__currentRep = perl5Repetition._lastRepetition;
            int i4 = this.__currentRep._numInstances;
            if (_match(perl5Repetition._next))
              return true; 
            this.__currentRep._numInstances = i4;
            this.__currentRep = perl5Repetition;
            return false;
          } 
          if (i2 < perl5Repetition._min) {
            perl5Repetition._numInstances = i2;
            perl5Repetition._lastLocation = j;
            if (_match(perl5Repetition._scan))
              return true; 
            perl5Repetition._numInstances = i2 - 1;
            return false;
          } 
          if (perl5Repetition._minMod) {
            this.__currentRep = perl5Repetition._lastRepetition;
            int i4 = this.__currentRep._numInstances;
            if (_match(perl5Repetition._next))
              return true; 
            this.__currentRep._numInstances = i4;
            this.__currentRep = perl5Repetition;
            if (i2 >= perl5Repetition._max)
              return false; 
            this.__inputOffset = j;
            perl5Repetition._numInstances = i2;
            perl5Repetition._lastLocation = j;
            if (_match(perl5Repetition._scan))
              return true; 
            perl5Repetition._numInstances = i2 - 1;
            return false;
          } 
          if (i2 < perl5Repetition._max) {
            _pushState(perl5Repetition._parenFloor);
            perl5Repetition._numInstances = i2;
            perl5Repetition._lastLocation = j;
            if (_match(perl5Repetition._scan))
              return true; 
            _popState();
            this.__inputOffset = j;
          } 
          this.__currentRep = perl5Repetition._lastRepetition;
          i1 = this.__currentRep._numInstances;
          if (_match(perl5Repetition._next))
            return true; 
          perl5Repetition._numInstances = i1;
          this.__currentRep = perl5Repetition;
          perl5Repetition._numInstances = i2 - 1;
          return false;
        case '\f':
          if (this.__program[m] != '\f') {
            m = OpCode._getNextOperator(i);
            break;
          } 
          i3 = this.__lastParen;
          do {
            this.__inputOffset = j;
            if (_match(OpCode._getNextOperator(i)))
              return true; 
            for (i2 = this.__lastParen; i2 > i3; i2--)
              this.__endMatchOffsets[i2] = -1; 
            this.__lastParen = i2;
            i = OpCode._getNext(this.__program, i);
          } while (i != -1 && this.__program[i] == '\f');
          return false;
        case '\035':
          bool1 = true;
          break;
        case '\n':
        case '\020':
        case '\021':
          if (c1 == '\n') {
            i1 = OpCode._getArg1(this.__program, i);
            i2 = OpCode._getArg2(this.__program, i);
            i = OpCode._getNextOperator(i) + 2;
          } else if (c1 == '\020') {
            i1 = 0;
            i2 = 65535;
            i = OpCode._getNextOperator(i);
          } else {
            i1 = 1;
            i2 = 65535;
            i = OpCode._getNextOperator(i);
          } 
          if (this.__program[m] == '\016') {
            c = this.__program[OpCode._getOperand(m) + 1];
            n = 0;
          } else {
            c = Character.MAX_VALUE;
            n = -1000;
          } 
          this.__inputOffset = j;
          if (bool1) {
            bool1 = false;
            if (i1 > 0 && _repeat(i, i1) < i1)
              return false; 
            while (i2 >= i1 || (i2 == 65535 && i1 > 0)) {
              if ((n == -1000 || this.__inputOffset >= this.__endOffset || this.__input[this.__inputOffset] == c) && _match(m))
                return true; 
              this.__inputOffset = j + i1;
              if (_repeat(i, 1) != 0) {
                this.__inputOffset = j + ++i1;
                continue;
              } 
              return false;
            } 
          } else {
            i2 = _repeat(i, i2);
            if (i1 < i2 && OpCode._opType[this.__program[m]] == '\004' && (!this.__multiline || this.__program[m] == '\006'))
              i1 = i2; 
            while (i2 >= i1) {
              if ((n == -1000 || this.__inputOffset >= this.__endOffset || this.__input[this.__inputOffset] == c) && _match(m))
                return true; 
              this.__inputOffset = j + --i2;
            } 
          } 
          return false;
        case '\000':
        case '!':
          this.__inputOffset = j;
          return !(this.__inputOffset == this.__lastMatchInputEndOffset);
        case '\037':
          this.__inputOffset = j;
          i = OpCode._getNextOperator(i);
          if (!_match(i))
            return false; 
          break;
        case ' ':
          this.__inputOffset = j;
          i = OpCode._getNextOperator(i);
          if (_match(i))
            return false; 
          break;
      } 
      i = m;
    } 
    return false;
  }
  
  public void setMultiline(boolean paramBoolean) { this.__multiline = paramBoolean; }
  
  public boolean isMultiline() { return this.__multiline; }
  
  char[] _toLower(char[] paramArrayOfChar) {
    char[] arrayOfChar = new char[paramArrayOfChar.length];
    System.arraycopy(paramArrayOfChar, 0, arrayOfChar, 0, paramArrayOfChar.length);
    paramArrayOfChar = arrayOfChar;
    for (byte b = 0; b < paramArrayOfChar.length; b++) {
      if (Character.isUpperCase(paramArrayOfChar[b]))
        paramArrayOfChar[b] = Character.toLowerCase(paramArrayOfChar[b]); 
    } 
    return paramArrayOfChar;
  }
  
  public boolean matchesPrefix(char[] paramArrayOfChar, Pattern paramPattern, int paramInt) {
    Perl5Pattern perl5Pattern = (Perl5Pattern)paramPattern;
    this.__originalInput = paramArrayOfChar;
    if (perl5Pattern._isCaseInsensitive)
      paramArrayOfChar = _toLower(paramArrayOfChar); 
    __initInterpreterGlobals(perl5Pattern, paramArrayOfChar, paramInt, paramArrayOfChar.length);
    this.__lastSuccess = _tryExpression(perl5Pattern, paramInt);
    this.__lastMatchResult = null;
    return this.__lastSuccess;
  }
  
  public boolean matchesPrefix(char[] paramArrayOfChar, Pattern paramPattern) { return matchesPrefix(paramArrayOfChar, paramPattern, 0); }
  
  public boolean matchesPrefix(String paramString, Pattern paramPattern) { return matchesPrefix(paramString.toCharArray(), paramPattern, 0); }
  
  public boolean matchesPrefix(PatternMatcherInput paramPatternMatcherInput, Pattern paramPattern) {
    char[] arrayOfChar;
    Perl5Pattern perl5Pattern = (Perl5Pattern)paramPattern;
    this.__originalInput = paramPatternMatcherInput._originalBuffer;
    if (perl5Pattern._isCaseInsensitive) {
      if (paramPatternMatcherInput._toLowerBuffer == null)
        paramPatternMatcherInput._toLowerBuffer = _toLower(this.__originalInput); 
      arrayOfChar = paramPatternMatcherInput._toLowerBuffer;
    } else {
      arrayOfChar = this.__originalInput;
    } 
    __initInterpreterGlobals(perl5Pattern, arrayOfChar, paramPatternMatcherInput._currentOffset, paramPatternMatcherInput._endOffset);
    this.__lastSuccess = _tryExpression(perl5Pattern, paramPatternMatcherInput._currentOffset);
    this.__lastMatchResult = null;
    return this.__lastSuccess;
  }
  
  public boolean matches(char[] paramArrayOfChar, Pattern paramPattern) {
    Perl5Pattern perl5Pattern = (Perl5Pattern)paramPattern;
    this.__originalInput = paramArrayOfChar;
    if (perl5Pattern._isCaseInsensitive)
      paramArrayOfChar = _toLower(paramArrayOfChar); 
    __initInterpreterGlobals(perl5Pattern, paramArrayOfChar, 0, paramArrayOfChar.length);
    this.__lastSuccess = !(!_tryExpression(perl5Pattern, 0) || this.__endMatchOffsets[0] != paramArrayOfChar.length);
    this.__lastMatchResult = null;
    return this.__lastSuccess;
  }
  
  public boolean matches(String paramString, Pattern paramPattern) { return matches(paramString.toCharArray(), paramPattern); }
  
  public boolean matches(PatternMatcherInput paramPatternMatcherInput, Pattern paramPattern) {
    char[] arrayOfChar;
    Perl5Pattern perl5Pattern = (Perl5Pattern)paramPattern;
    this.__originalInput = paramPatternMatcherInput._originalBuffer;
    if (perl5Pattern._isCaseInsensitive) {
      if (paramPatternMatcherInput._toLowerBuffer == null)
        paramPatternMatcherInput._toLowerBuffer = _toLower(this.__originalInput); 
      arrayOfChar = paramPatternMatcherInput._toLowerBuffer;
    } else {
      arrayOfChar = this.__originalInput;
    } 
    __initInterpreterGlobals(perl5Pattern, arrayOfChar, paramPatternMatcherInput._beginOffset, paramPatternMatcherInput._endOffset);
    this.__lastMatchResult = null;
    if (_tryExpression(perl5Pattern, paramPatternMatcherInput._beginOffset) && (this.__endMatchOffsets[0] == paramPatternMatcherInput._endOffset || paramPatternMatcherInput.length() == 0 || paramPatternMatcherInput._beginOffset == paramPatternMatcherInput._endOffset)) {
      this.__lastSuccess = true;
      return true;
    } 
    this.__lastSuccess = false;
    return false;
  }
  
  public boolean contains(String paramString, Pattern paramPattern) { return contains(paramString.toCharArray(), paramPattern); }
  
  public boolean contains(char[] paramArrayOfChar, Pattern paramPattern) {
    Perl5Pattern perl5Pattern = (Perl5Pattern)paramPattern;
    this.__originalInput = paramArrayOfChar;
    if (perl5Pattern._isCaseInsensitive)
      paramArrayOfChar = _toLower(paramArrayOfChar); 
    return _interpret(perl5Pattern, paramArrayOfChar, 0, paramArrayOfChar.length);
  }
  
  public boolean contains(PatternMatcherInput paramPatternMatcherInput, Pattern paramPattern) {
    char[] arrayOfChar;
    if (paramPatternMatcherInput._currentOffset > paramPatternMatcherInput._endOffset)
      return false; 
    Perl5Pattern perl5Pattern = (Perl5Pattern)paramPattern;
    this.__originalInput = paramPatternMatcherInput._originalBuffer;
    this.__originalInput = paramPatternMatcherInput._originalBuffer;
    if (perl5Pattern._isCaseInsensitive) {
      if (paramPatternMatcherInput._toLowerBuffer == null)
        paramPatternMatcherInput._toLowerBuffer = _toLower(this.__originalInput); 
      arrayOfChar = paramPatternMatcherInput._toLowerBuffer;
    } else {
      arrayOfChar = this.__originalInput;
    } 
    this.__lastMatchInputEndOffset = paramPatternMatcherInput.getMatchEndOffset();
    boolean bool = _interpret(perl5Pattern, arrayOfChar, paramPatternMatcherInput._currentOffset, paramPatternMatcherInput._endOffset);
    if (bool) {
      paramPatternMatcherInput.setCurrentOffset(this.__endMatchOffsets[0]);
      paramPatternMatcherInput.setMatchOffsets(this.__beginMatchOffsets[0], this.__endMatchOffsets[0]);
    } else {
      paramPatternMatcherInput.setCurrentOffset(paramPatternMatcherInput._endOffset + 1);
    } 
    this.__lastMatchInputEndOffset = -100;
    return bool;
  }
  
  public boolean contains(Perl5StreamInput paramPerl5StreamInput, Perl5Pattern paramPerl5Pattern) throws IOException {
    boolean bool = false;
    this.__lastMatchInputEndOffset = paramPerl5StreamInput._getMatchEndOffset();
    if (paramPerl5StreamInput._streamOffset == 0 && paramPerl5StreamInput._bufferSize == 0) {
      if (!paramPerl5StreamInput._read(paramPerl5Pattern._isCaseInsensitive)) {
        this.__lastMatchInputEndOffset = -100;
        return false;
      } 
    } else if (paramPerl5StreamInput._bufferOffset >= paramPerl5StreamInput._bufferSize) {
      this.__lastMatchInputEndOffset -= paramPerl5StreamInput._bufferSize;
      paramPerl5StreamInput._reallocate(paramPerl5StreamInput._bufferSize, paramPerl5Pattern._isCaseInsensitive);
      paramPerl5StreamInput._bufferOffset = 0;
    } 
    if (paramPerl5StreamInput._endOfStream) {
      this.__lastMatchInputEndOffset = -100;
      return false;
    } 
    int i = Integer.MAX_VALUE;
    while (true) {
      if (paramPerl5StreamInput._bufferSize < paramPerl5StreamInput._buffer.length)
        i = paramPerl5StreamInput._bufferSize; 
      try {
        this.__originalInput = paramPerl5StreamInput._originalBuffer;
        bool = _interpret(paramPerl5Pattern, paramPerl5StreamInput._buffer, paramPerl5StreamInput._bufferOffset, i);
      } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        if (this.__currentOffset > paramPerl5StreamInput._bufferSize) {
          paramPerl5StreamInput._reallocate(paramPerl5StreamInput._bufferOffset, paramPerl5Pattern._isCaseInsensitive);
        } else {
          paramPerl5StreamInput._reallocate(this.__currentOffset, paramPerl5Pattern._isCaseInsensitive);
          this.__lastMatchInputEndOffset -= this.__currentOffset;
        } 
        if (paramPerl5StreamInput._endOfStream)
          if (i == Integer.MAX_VALUE) {
            i = paramPerl5StreamInput._bufferSize;
          } else {
            break;
          }  
        paramPerl5StreamInput._bufferOffset = 0;
        continue;
      } 
      if (bool) {
        paramPerl5StreamInput._bufferOffset = this.__endMatchOffsets[0];
        paramPerl5StreamInput._setMatchEndOffset(this.__endMatchOffsets[0]);
        __setLastMatchResult();
        this.__lastMatchResult._matchBeginOffset = paramPerl5StreamInput._streamOffset + this.__currentOffset;
        break;
      } 
      paramPerl5StreamInput._reallocate(paramPerl5StreamInput._bufferSize, paramPerl5Pattern._isCaseInsensitive);
      paramPerl5StreamInput._bufferOffset = 0;
      if (paramPerl5StreamInput._endOfStream)
        break; 
    } 
    this.__lastMatchInputEndOffset = -100;
    return bool;
  }
  
  public MatchResult getMatch() {
    if (!this.__lastSuccess)
      return null; 
    if (this.__lastMatchResult == null)
      __setLastMatchResult(); 
    return this.__lastMatchResult;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\Perl5Matcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */