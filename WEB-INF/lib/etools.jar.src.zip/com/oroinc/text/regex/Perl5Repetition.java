package com.oroinc.text.regex;

class Perl5Repetition {
  int _parenFloor;
  
  int _numInstances;
  
  int _min;
  
  int _max;
  
  boolean _minMod;
  
  int _scan;
  
  int _next;
  
  int _lastLocation;
  
  Perl5Repetition _lastRepetition;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\Perl5Repetition.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */