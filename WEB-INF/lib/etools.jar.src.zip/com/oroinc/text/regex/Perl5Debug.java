package com.oroinc.text.regex;

public final class Perl5Debug {
  public static String printProgram(Perl5Pattern paramPerl5Pattern) {
    char c = '\033';
    char[] arrayOfChar = paramPerl5Pattern._program;
    int i = 1;
    StringBuffer stringBuffer = new StringBuffer();
    while (c != Character.MIN_VALUE) {
      c = arrayOfChar[i];
      stringBuffer.append(i);
      _printOperator(arrayOfChar, i, stringBuffer);
      int j = OpCode._getNext(arrayOfChar, i);
      i += OpCode._operandLength[c];
      stringBuffer.append("(" + j + ")");
      i += 2;
      if (c == '\t') {
        i += 16;
      } else if (c == '\016') {
        i++;
        stringBuffer.append(" <");
        while (arrayOfChar[i] != Character.MAX_VALUE) {
          stringBuffer.append(arrayOfChar[i]);
          i++;
        } 
        stringBuffer.append(">");
        i++;
      } 
      stringBuffer.append('\n');
    } 
    if (paramPerl5Pattern._startString != null)
      stringBuffer.append("start `" + new String(paramPerl5Pattern._startString) + "' "); 
    if (paramPerl5Pattern._startClassOffset != -1) {
      stringBuffer.append("stclass `");
      _printOperator(arrayOfChar, paramPerl5Pattern._startClassOffset, stringBuffer);
      stringBuffer.append("' ");
    } 
    if ((paramPerl5Pattern._anchor & true) != 0)
      stringBuffer.append("anchored "); 
    if ((paramPerl5Pattern._anchor & 0x2) != 0)
      stringBuffer.append("plus "); 
    if ((paramPerl5Pattern._anchor & 0x4) != 0)
      stringBuffer.append("implicit "); 
    if (paramPerl5Pattern._mustString != null)
      stringBuffer.append("must have \"" + new String(paramPerl5Pattern._mustString) + "\" back " + paramPerl5Pattern._back + " "); 
    stringBuffer.append("minlen " + paramPerl5Pattern._minLength + '\n');
    return stringBuffer.toString();
  }
  
  static void _printOperator(char[] paramArrayOfChar, int paramInt, StringBuffer paramStringBuffer) {
    String str = null;
    paramStringBuffer.append(":");
    switch (paramArrayOfChar[paramInt]) {
      case '\001':
        str = "BOL";
        break;
      case '\002':
        str = "MBOL";
        break;
      case '\003':
        str = "SBOL";
        break;
      case '\004':
        str = "EOL";
        break;
      case '\005':
        str = "MEOL";
        break;
      case '\007':
        str = "ANY";
        break;
      case '\b':
        str = "SANY";
        break;
      case '\t':
        str = "ANYOF";
        break;
      case '\f':
        str = "BRANCH";
        break;
      case '\016':
        str = "EXACTLY";
        break;
      case '\017':
        str = "NOTHING";
        break;
      case '\r':
        str = "BACK";
        break;
      case '\000':
        str = "END";
        break;
      case '\022':
        str = "ALNUM";
        break;
      case '\023':
        str = "NALNUM";
        break;
      case '\024':
        str = "BOUND";
        break;
      case '\025':
        str = "NBOUND";
        break;
      case '\026':
        str = "SPACE";
        break;
      case '\027':
        str = "NSPACE";
        break;
      case '\030':
        str = "DIGIT";
        break;
      case '\031':
        str = "NDIGIT";
        break;
      case '\n':
        paramStringBuffer.append("CURLY {");
        paramStringBuffer.append(OpCode._getArg1(paramArrayOfChar, paramInt));
        paramStringBuffer.append(',');
        paramStringBuffer.append(OpCode._getArg2(paramArrayOfChar, paramInt));
        paramStringBuffer.append('}');
        break;
      case '\013':
        paramStringBuffer.append("CURLYX {");
        paramStringBuffer.append(OpCode._getArg1(paramArrayOfChar, paramInt));
        paramStringBuffer.append(',');
        paramStringBuffer.append(OpCode._getArg2(paramArrayOfChar, paramInt));
        paramStringBuffer.append('}');
        break;
      case '\032':
        paramStringBuffer.append("REF");
        paramStringBuffer.append(OpCode._getArg1(paramArrayOfChar, paramInt));
        break;
      case '\033':
        paramStringBuffer.append("OPEN");
        paramStringBuffer.append(OpCode._getArg1(paramArrayOfChar, paramInt));
        break;
      case '\034':
        paramStringBuffer.append("CLOSE");
        paramStringBuffer.append(OpCode._getArg1(paramArrayOfChar, paramInt));
        break;
      case '\020':
        str = "STAR";
        break;
      case '\021':
        str = "PLUS";
        break;
      case '\035':
        str = "MINMOD";
        break;
      case '\036':
        str = "GBOL";
        break;
      case ' ':
        str = "UNLESSM";
        break;
      case '\037':
        str = "IFMATCH";
        break;
      case '!':
        str = "SUCCEED";
        break;
      case '"':
        str = "WHILEM";
        break;
      default:
        paramStringBuffer.append("Operator is unrecognized.  Faulty expression code!");
        break;
    } 
    if (str != null)
      paramStringBuffer.append(str); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\Perl5Debug.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */