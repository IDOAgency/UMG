package com.oroinc.text.regex;

import java.io.Serializable;

public final class Perl5Pattern implements Pattern, Serializable, Cloneable {
  static final int _OPT_ANCH = 1;
  
  static final int _OPT_SKIP = 2;
  
  static final int _OPT_IMPLICIT = 4;
  
  String _expression;
  
  char[] _program;
  
  int _mustUtility;
  
  int _back;
  
  int _minLength;
  
  int _numParentheses;
  
  boolean _isCaseInsensitive;
  
  boolean _isExpensive;
  
  int _startClassOffset;
  
  int _anchor;
  
  int _options;
  
  char[] _mustString;
  
  char[] _startString;
  
  public String getPattern() { return this._expression; }
  
  public int getOptions() { return this._options; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\etools.jar!\com\oroinc\text\regex\Perl5Pattern.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */