/*     */ package javax.xml.soap;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FactoryFinder
/*     */ {
/*     */   private static Object newInstance(String factoryClassName) throws SOAPException {
/*  40 */     ClassLoader classloader = null;
/*     */     try {
/*  42 */       classloader = Thread.currentThread().getContextClassLoader();
/*  43 */     } catch (Exception exception) {
/*  44 */       throw new SOAPException(exception.toString(), exception);
/*     */     } 
/*     */     
/*     */     try {
/*  48 */       Class factory = null;
/*  49 */       if (classloader == null) {
/*  50 */         factory = Class.forName(factoryClassName);
/*     */       } else {
/*     */         try {
/*  53 */           factory = classloader.loadClass(factoryClassName);
/*  54 */         } catch (ClassNotFoundException cnfe) {}
/*     */       } 
/*  56 */       if (factory == null) {
/*  57 */         classloader = FactoryFinder.class.getClassLoader();
/*  58 */         factory = classloader.loadClass(factoryClassName);
/*     */       } 
/*  60 */       return factory.newInstance();
/*  61 */     } catch (ClassNotFoundException classnotfoundexception) {
/*  62 */       throw new SOAPException("Provider " + factoryClassName + " not found", classnotfoundexception);
/*  63 */     } catch (Exception exception) {
/*  64 */       throw new SOAPException("Provider " + factoryClassName + " could not be instantiated: " + exception, exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object find(String factoryPropertyName, String defaultFactoryClassName) throws SOAPException {
/*     */     try {
/*  79 */       String factoryClassName = System.getProperty(factoryPropertyName);
/*  80 */       if (factoryClassName != null) {
/*  81 */         return newInstance(factoryClassName);
/*     */       }
/*  83 */     } catch (SecurityException securityexception) {}
/*     */     
/*     */     try {
/*  86 */       String propertiesFileName = System.getProperty("java.home") + File.separator + "lib" + File.separator + "jaxm.properties";
/*     */ 
/*     */       
/*  89 */       File file = new File(propertiesFileName);
/*  90 */       if (file.exists()) {
/*  91 */         FileInputStream fileInput = new FileInputStream(file);
/*  92 */         Properties properties = new Properties();
/*  93 */         properties.load(fileInput);
/*  94 */         fileInput.close();
/*  95 */         String factoryClassName = properties.getProperty(factoryPropertyName);
/*  96 */         return newInstance(factoryClassName);
/*     */       } 
/*  98 */     } catch (Exception exception1) {}
/*     */     
/* 100 */     String factoryResource = "META-INF/services/" + factoryPropertyName;
/*     */     
/*     */     try {
/* 103 */       InputStream inputstream = getResource(factoryResource);
/* 104 */       if (inputstream != null) {
/* 105 */         BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(inputstream, "UTF-8"));
/* 106 */         String factoryClassName = bufferedreader.readLine();
/* 107 */         bufferedreader.close();
/* 108 */         if (factoryClassName != null && !"".equals(factoryClassName)) {
/* 109 */           return newInstance(factoryClassName);
/*     */         }
/*     */       } 
/* 112 */     } catch (Exception exception2) {}
/*     */     
/* 114 */     if (defaultFactoryClassName == null) {
/* 115 */       throw new SOAPException("Provider for " + factoryPropertyName + " cannot be found", null);
/*     */     }
/* 117 */     return newInstance(defaultFactoryClassName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static InputStream getResource(String factoryResource) {
/*     */     InputStream inputstream;
/* 136 */     ClassLoader classloader = null;
/*     */     try {
/* 138 */       classloader = Thread.currentThread().getContextClassLoader();
/* 139 */     } catch (SecurityException securityexception) {}
/*     */ 
/*     */     
/* 142 */     if (classloader == null) {
/* 143 */       inputstream = ClassLoader.getSystemResourceAsStream(factoryResource);
/*     */     } else {
/* 145 */       inputstream = classloader.getResourceAsStream(factoryResource);
/*     */     } 
/*     */     
/* 148 */     if (inputstream == null) {
/* 149 */       inputstream = FactoryFinder.class.getClassLoader().getResourceAsStream(factoryResource);
/*     */     }
/* 151 */     return inputstream;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\FactoryFinder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */