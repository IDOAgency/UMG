package javax.xml.soap;

import java.io.IOException;
import java.io.InputStream;

public abstract class MessageFactory {
  private static final String DEFAULT_MESSAGE_FACTORY = "org.apache.axis.soap.MessageFactoryImpl";
  
  private static final String MESSAGE_FACTORY_PROPERTY = "javax.xml.soap.MessageFactory";
  
  public static MessageFactory newInstance() throws SOAPException {
    try {
      return (MessageFactory)FactoryFinder.find("javax.xml.soap.MessageFactory", "org.apache.axis.soap.MessageFactoryImpl");
    } catch (Exception exception) {
      throw new SOAPException("Unable to create message factory for SOAP: " + exception.getMessage());
    } 
  }
  
  public abstract SOAPMessage createMessage() throws SOAPException;
  
  public abstract SOAPMessage createMessage(MimeHeaders paramMimeHeaders, InputStream paramInputStream) throws IOException, SOAPException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\MessageFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */