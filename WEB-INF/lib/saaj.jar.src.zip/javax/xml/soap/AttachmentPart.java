package javax.xml.soap;

import java.util.Iterator;
import javax.activation.DataHandler;

public abstract class AttachmentPart {
  public abstract int getSize() throws SOAPException;
  
  public abstract void clearContent();
  
  public abstract Object getContent() throws SOAPException;
  
  public abstract void setContent(Object paramObject, String paramString);
  
  public abstract DataHandler getDataHandler() throws SOAPException;
  
  public abstract void setDataHandler(DataHandler paramDataHandler);
  
  public String getContentId() {
    String[] as = getMimeHeader("Content-Id");
    if (as != null && as.length > 0)
      return as[0]; 
    return null;
  }
  
  public String getContentLocation() {
    String[] as = getMimeHeader("Content-Location");
    if (as != null && as.length > 0)
      return as[0]; 
    return null;
  }
  
  public String getContentType() {
    String[] as = getMimeHeader("Content-Type");
    if (as != null && as.length > 0)
      return as[0]; 
    return null;
  }
  
  public void setContentId(String contentId) { setMimeHeader("Content-Id", contentId); }
  
  public void setContentLocation(String contentLocation) { setMimeHeader("Content-Location", contentLocation); }
  
  public void setContentType(String contentType) { setMimeHeader("Content-Type", contentType); }
  
  public abstract void removeMimeHeader(String paramString);
  
  public abstract void removeAllMimeHeaders();
  
  public abstract String[] getMimeHeader(String paramString);
  
  public abstract void setMimeHeader(String paramString1, String paramString2);
  
  public abstract void addMimeHeader(String paramString1, String paramString2);
  
  public abstract Iterator getAllMimeHeaders();
  
  public abstract Iterator getMatchingMimeHeaders(String[] paramArrayOfString);
  
  public abstract Iterator getNonMatchingMimeHeaders(String[] paramArrayOfString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\AttachmentPart.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */