package javax.xml.soap;

public class MimeHeader {
  private String name;
  
  private String value;
  
  public MimeHeader(String name, String value) {
    this.name = name;
    this.value = value;
  }
  
  public String getName() { return this.name; }
  
  public String getValue() { return this.value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\MimeHeader.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */