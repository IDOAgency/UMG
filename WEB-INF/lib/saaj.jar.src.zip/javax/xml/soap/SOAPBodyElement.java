package javax.xml.soap;

public interface SOAPBodyElement extends SOAPElement {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\SOAPBodyElement.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */