package javax.xml.soap;

public interface SOAPHeaderElement extends SOAPElement {
  void setActor(String paramString);
  
  String getActor();
  
  void setMustUnderstand(boolean paramBoolean);
  
  boolean getMustUnderstand();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\SOAPHeaderElement.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */