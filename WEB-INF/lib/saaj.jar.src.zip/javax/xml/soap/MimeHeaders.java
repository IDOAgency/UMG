package javax.xml.soap;

import java.util.Iterator;
import java.util.Vector;

public class MimeHeaders {
  class MatchingIterator implements Iterator {
    private boolean match;
    
    private Iterator iterator;
    
    private String[] names;
    
    private Object nextHeader;
    
    private final MimeHeaders this$0;
    
    private Object nextMatch() {
      label22: while (this.iterator.hasNext()) {
        MimeHeader mimeheader = (MimeHeader)this.iterator.next();
        if (this.names == null)
          return this.match ? null : mimeheader; 
        for (int i = 0; i < this.names.length; ) {
          if (!mimeheader.getName().equalsIgnoreCase(this.names[i])) {
            i++;
            continue;
          } 
          if (this.match)
            return mimeheader; 
          continue label22;
        } 
        if (!this.match)
          return mimeheader; 
      } 
      return null;
    }
    
    public boolean hasNext() {
      if (this.nextHeader == null)
        this.nextHeader = nextMatch(); 
      return (this.nextHeader != null);
    }
    
    public Object next() {
      if (this.nextHeader != null) {
        Object obj = this.nextHeader;
        this.nextHeader = null;
        return obj;
      } 
      if (hasNext())
        return this.nextHeader; 
      return null;
    }
    
    public void remove() { this.iterator.remove(); }
    
    MatchingIterator(MimeHeaders this$0, String[] as, boolean flag) {
      this.this$0 = this$0;
      this.match = flag;
      this.names = as;
      this.iterator = this$0.headers.iterator();
    }
  }
  
  private Vector headers = new Vector();
  
  public String[] getHeader(String name) {
    Vector vector = new Vector();
    for (int i = 0; i < this.headers.size(); i++) {
      MimeHeader mimeheader = (MimeHeader)this.headers.elementAt(i);
      if (mimeheader.getName().equalsIgnoreCase(name) && mimeheader.getValue() != null)
        vector.addElement(mimeheader.getValue()); 
    } 
    if (vector.size() == 0)
      return null; 
    String[] as = new String[vector.size()];
    vector.copyInto(as);
    return as;
  }
  
  public void setHeader(String name, String value) {
    boolean flag = false;
    if (name == null || name.equals(""))
      throw new IllegalArgumentException("Illegal MimeHeader name"); 
    for (int i = 0; i < this.headers.size(); i++) {
      MimeHeader mimeheader = (MimeHeader)this.headers.elementAt(i);
      if (mimeheader.getName().equalsIgnoreCase(name))
        if (!flag) {
          this.headers.setElementAt(new MimeHeader(mimeheader.getName(), value), i);
          flag = true;
        } else {
          this.headers.removeElementAt(i--);
        }  
    } 
    if (!flag)
      addHeader(name, value); 
  }
  
  public void addHeader(String name, String value) {
    if (name == null || name.equals(""))
      throw new IllegalArgumentException("Illegal MimeHeader name"); 
    int i = this.headers.size();
    for (int j = i - 1; j >= 0; j--) {
      MimeHeader mimeheader = (MimeHeader)this.headers.elementAt(j);
      if (mimeheader.getName().equalsIgnoreCase(name)) {
        this.headers.insertElementAt(new MimeHeader(name, value), j + 1);
        return;
      } 
    } 
    this.headers.addElement(new MimeHeader(name, value));
  }
  
  public void removeHeader(String name) {
    for (int i = 0; i < this.headers.size(); i++) {
      MimeHeader mimeheader = (MimeHeader)this.headers.elementAt(i);
      if (mimeheader.getName().equalsIgnoreCase(name))
        this.headers.removeElementAt(i--); 
    } 
  }
  
  public void removeAllHeaders() { this.headers.removeAllElements(); }
  
  public Iterator getAllHeaders() { return this.headers.iterator(); }
  
  public Iterator getMatchingHeaders(String[] names) { return new MatchingIterator(this, names, true); }
  
  public Iterator getNonMatchingHeaders(String[] names) { return new MatchingIterator(this, names, false); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\MimeHeaders.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */