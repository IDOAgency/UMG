/*     */ package javax.xml.soap;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimeHeaders
/*     */ {
/*     */   class MatchingIterator
/*     */     implements Iterator
/*     */   {
/*     */     private boolean match;
/*     */     private Iterator iterator;
/*     */     private String[] names;
/*     */     private Object nextHeader;
/*     */     private final MimeHeaders this$0;
/*     */     
/*     */     private Object nextMatch() {
/*  41 */       label22: while (this.iterator.hasNext()) {
/*  42 */         MimeHeader mimeheader = (MimeHeader)this.iterator.next();
/*     */         
/*  44 */         if (this.names == null) {
/*  45 */           return this.match ? null : mimeheader;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*  50 */         for (int i = 0; i < this.names.length; ) {
/*  51 */           if (!mimeheader.getName().equalsIgnoreCase(this.names[i])) {
/*     */             i++;
/*     */             continue;
/*     */           } 
/*  55 */           if (this.match) {
/*  56 */             return mimeheader;
/*     */           }
/*     */           
/*     */           continue label22;
/*     */         } 
/*     */         
/*  62 */         if (!this.match) {
/*  63 */           return mimeheader;
/*     */         }
/*     */       } 
/*     */       
/*  67 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/*  72 */       if (this.nextHeader == null) {
/*  73 */         this.nextHeader = nextMatch();
/*     */       }
/*     */       
/*  76 */       return (this.nextHeader != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object next() {
/*  81 */       if (this.nextHeader != null) {
/*  82 */         Object obj = this.nextHeader;
/*     */         
/*  84 */         this.nextHeader = null;
/*     */         
/*  86 */         return obj;
/*     */       } 
/*     */       
/*  89 */       if (hasNext()) {
/*  90 */         return this.nextHeader;
/*     */       }
/*  92 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  97 */     public void remove() { this.iterator.remove(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MatchingIterator(MimeHeaders this$0, String[] as, boolean flag) {
/* 108 */       this.this$0 = this$0;
/*     */       
/* 110 */       this.match = flag;
/* 111 */       this.names = as;
/* 112 */       this.iterator = this$0.headers.iterator();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   private Vector headers = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getHeader(String name) {
/* 136 */     Vector vector = new Vector();
/*     */     
/* 138 */     for (int i = 0; i < this.headers.size(); i++) {
/* 139 */       MimeHeader mimeheader = (MimeHeader)this.headers.elementAt(i);
/*     */       
/* 141 */       if (mimeheader.getName().equalsIgnoreCase(name) && mimeheader.getValue() != null)
/*     */       {
/* 143 */         vector.addElement(mimeheader.getValue());
/*     */       }
/*     */     } 
/*     */     
/* 147 */     if (vector.size() == 0) {
/* 148 */       return null;
/*     */     }
/* 150 */     String[] as = new String[vector.size()];
/*     */     
/* 152 */     vector.copyInto(as);
/*     */     
/* 154 */     return as;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeader(String name, String value) {
/* 177 */     boolean flag = false;
/*     */     
/* 179 */     if (name == null || name.equals("")) {
/* 180 */       throw new IllegalArgumentException("Illegal MimeHeader name");
/*     */     }
/*     */ 
/*     */     
/* 184 */     for (int i = 0; i < this.headers.size(); i++) {
/* 185 */       MimeHeader mimeheader = (MimeHeader)this.headers.elementAt(i);
/*     */       
/* 187 */       if (mimeheader.getName().equalsIgnoreCase(name)) {
/* 188 */         if (!flag) {
/* 189 */           this.headers.setElementAt(new MimeHeader(mimeheader.getName(), value), i);
/*     */ 
/*     */           
/* 192 */           flag = true;
/*     */         } else {
/* 194 */           this.headers.removeElementAt(i--);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 199 */     if (!flag) {
/* 200 */       addHeader(name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addHeader(String name, String value) {
/* 221 */     if (name == null || name.equals("")) {
/* 222 */       throw new IllegalArgumentException("Illegal MimeHeader name");
/*     */     }
/*     */ 
/*     */     
/* 226 */     int i = this.headers.size();
/*     */     
/* 228 */     for (int j = i - 1; j >= 0; j--) {
/* 229 */       MimeHeader mimeheader = (MimeHeader)this.headers.elementAt(j);
/*     */       
/* 231 */       if (mimeheader.getName().equalsIgnoreCase(name)) {
/* 232 */         this.headers.insertElementAt(new MimeHeader(name, value), j + 1);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 238 */     this.headers.addElement(new MimeHeader(name, value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeHeader(String name) {
/* 249 */     for (int i = 0; i < this.headers.size(); i++) {
/* 250 */       MimeHeader mimeheader = (MimeHeader)this.headers.elementAt(i);
/*     */       
/* 252 */       if (mimeheader.getName().equalsIgnoreCase(name)) {
/* 253 */         this.headers.removeElementAt(i--);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 263 */   public void removeAllHeaders() { this.headers.removeAllElements(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 274 */   public Iterator getAllHeaders() { return this.headers.iterator(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 287 */   public Iterator getMatchingHeaders(String[] names) { return new MatchingIterator(this, names, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   public Iterator getNonMatchingHeaders(String[] names) { return new MatchingIterator(this, names, false); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\MimeHeaders.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */