package javax.xml.soap;

public interface SOAPFaultElement extends SOAPElement {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\SOAPFaultElement.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */