package javax.xml.soap;

import java.util.Locale;

public interface SOAPFault extends SOAPBodyElement {
  void setFaultCode(String paramString) throws SOAPException;
  
  String getFaultCode();
  
  void setFaultActor(String paramString) throws SOAPException;
  
  String getFaultActor();
  
  void setFaultString(String paramString) throws SOAPException;
  
  String getFaultString();
  
  Detail getDetail();
  
  Detail addDetail();
  
  void setFaultCode(Name paramName) throws SOAPException;
  
  Name getFaultCodeAsName();
  
  void setFaultString(String paramString, Locale paramLocale) throws SOAPException;
  
  Locale getFaultStringLocale();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\SOAPFault.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */