package javax.xml.soap;

public interface Name {
  String getLocalName();
  
  String getQualifiedName();
  
  String getPrefix();
  
  String getURI();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\Name.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */