package javax.xml.soap;

import java.util.Iterator;
import javax.xml.transform.Source;
import org.w3c.dom.Document;

public abstract class SOAPPart implements Document {
  public abstract SOAPEnvelope getEnvelope() throws SOAPException;
  
  public String getContentId() {
    String[] as = getMimeHeader("Content-Id");
    if (as != null && as.length > 0)
      return as[0]; 
    return null;
  }
  
  public String getContentLocation() {
    String[] as = getMimeHeader("Content-Location");
    if (as != null && as.length > 0)
      return as[0]; 
    return null;
  }
  
  public void setContentId(String contentId) { setMimeHeader("Content-Id", contentId); }
  
  public void setContentLocation(String contentLocation) { setMimeHeader("Content-Location", contentLocation); }
  
  public abstract void removeMimeHeader(String paramString);
  
  public abstract void removeAllMimeHeaders();
  
  public abstract String[] getMimeHeader(String paramString);
  
  public abstract void setMimeHeader(String paramString1, String paramString2);
  
  public abstract void addMimeHeader(String paramString1, String paramString2);
  
  public abstract Iterator getAllMimeHeaders();
  
  public abstract Iterator getMatchingMimeHeaders(String[] paramArrayOfString);
  
  public abstract Iterator getNonMatchingMimeHeaders(String[] paramArrayOfString);
  
  public abstract void setContent(Source paramSource) throws SOAPException;
  
  public abstract Source getContent() throws SOAPException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\SOAPPart.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */