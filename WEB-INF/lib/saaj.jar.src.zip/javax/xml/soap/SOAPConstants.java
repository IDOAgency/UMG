package javax.xml.soap;

public interface SOAPConstants {
  public static final String URI_NS_SOAP_ENVELOPE = "http://schemas.xmlsoap.org/soap/envelope/";
  
  public static final String URI_NS_SOAP_ENCODING = "http://schemas.xmlsoap.org/soap/encoding/";
  
  public static final String URI_SOAP_ACTOR_NEXT = "http://schemas.xmlsoap.org/soap/actor/next";
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\SOAPConstants.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */