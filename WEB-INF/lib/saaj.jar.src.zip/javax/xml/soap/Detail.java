package javax.xml.soap;

import java.util.Iterator;

public interface Detail extends SOAPFaultElement {
  DetailEntry addDetailEntry(Name paramName) throws SOAPException;
  
  Iterator getDetailEntries();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\Detail.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */