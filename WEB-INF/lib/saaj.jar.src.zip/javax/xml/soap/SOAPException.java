/*     */ package javax.xml.soap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPException
/*     */   extends Exception
/*     */ {
/*     */   private Throwable cause;
/*     */   
/*  41 */   public SOAPException() { this.cause = null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPException(String reason) {
/*  53 */     super(reason);
/*     */     
/*  55 */     this.cause = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPException(String reason, Throwable cause) {
/*  71 */     super(reason);
/*     */     
/*  73 */     initCause(cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPException(Throwable cause) {
/*  86 */     super(cause.toString());
/*     */     
/*  88 */     initCause(cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 107 */     String s = super.getMessage();
/*     */     
/* 109 */     if (s == null && this.cause != null) {
/* 110 */       return this.cause.getMessage();
/*     */     }
/* 112 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public Throwable getCause() { return this.cause; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable initCause(Throwable cause) {
/* 163 */     if (this.cause != null) {
/* 164 */       throw new IllegalStateException("Can't override cause");
/*     */     }
/*     */     
/* 167 */     if (cause == this) {
/* 168 */       throw new IllegalArgumentException("Self-causation not permitted");
/*     */     }
/* 170 */     this.cause = cause;
/*     */     
/* 172 */     return this;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\SOAPException.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */