package javax.xml.soap;

public class SOAPException extends Exception {
  private Throwable cause;
  
  public SOAPException() { this.cause = null; }
  
  public SOAPException(String reason) {
    super(reason);
    this.cause = null;
  }
  
  public SOAPException(String reason, Throwable cause) {
    super(reason);
    initCause(cause);
  }
  
  public SOAPException(Throwable cause) {
    super(cause.toString());
    initCause(cause);
  }
  
  public String getMessage() {
    String s = super.getMessage();
    if (s == null && this.cause != null)
      return this.cause.getMessage(); 
    return s;
  }
  
  public Throwable getCause() { return this.cause; }
  
  public Throwable initCause(Throwable cause) {
    if (this.cause != null)
      throw new IllegalStateException("Can't override cause"); 
    if (cause == this)
      throw new IllegalArgumentException("Self-causation not permitted"); 
    this.cause = cause;
    return this;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\SOAPException.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */