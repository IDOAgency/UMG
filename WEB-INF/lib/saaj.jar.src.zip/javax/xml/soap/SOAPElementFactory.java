package javax.xml.soap;

public class SOAPElementFactory {
  private SOAPFactory sf;
  
  private SOAPElementFactory(SOAPFactory soapfactory) { this.sf = soapfactory; }
  
  public SOAPElement create(Name name) throws SOAPException { return this.sf.createElement(name); }
  
  public SOAPElement create(String localName) throws SOAPException { return this.sf.createElement(localName); }
  
  public SOAPElement create(String localName, String prefix, String uri) throws SOAPException { return this.sf.createElement(localName, prefix, uri); }
  
  public static SOAPElementFactory newInstance() throws SOAPException {
    try {
      return new SOAPElementFactory(SOAPFactory.newInstance());
    } catch (Exception exception) {
      throw new SOAPException("Unable to create SOAP Element Factory: " + exception.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\saaj.jar!\javax\xml\soap\SOAPElementFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */