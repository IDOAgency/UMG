/*    */ package inetsoft.report;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Margin
/*    */   implements Serializable
/*    */ {
/*    */   public double top;
/*    */   public double left;
/*    */   public double bottom;
/*    */   public double right;
/*    */   
/* 28 */   public Margin() { this(0.0D, 0.0D, 0.0D, 0.0D); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Margin(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 39 */     this.top = paramDouble1;
/* 40 */     this.left = paramDouble2;
/* 41 */     this.bottom = paramDouble3;
/* 42 */     this.right = paramDouble4;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 49 */   public Margin(Margin paramMargin) { this(paramMargin.top, paramMargin.left, paramMargin.bottom, paramMargin.right); }
/*    */ 
/*    */ 
/*    */   
/* 53 */   public String toString() { return "Margin[" + this.top + "," + this.left + "," + this.bottom + "," + this.right + "]"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Margin.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */