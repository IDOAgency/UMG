package inetsoft.report;

import inetsoft.report.lens.AttributeTableLens;
import inetsoft.report.painter.PresenterPainter;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.text.Format;

public abstract class SummaryTableLens extends AttributeTableLens {
  private TableLens table;
  
  public abstract Object getSummary(int paramInt1, int paramInt2, int paramInt3);
  
  public SummaryTableLens() {}
  
  public SummaryTableLens(TableLens paramTableLens) {
    super(paramTableLens);
    this.table = paramTableLens;
  }
  
  public TableLens getTable() { return this.table; }
  
  public void setTable(TableLens paramTableLens) {
    this.table = paramTableLens;
    super.setTable(paramTableLens);
  }
  
  public Object render(Object paramObject, int paramInt) {
    if (paramObject != null) {
      Presenter presenter = getPresenter(paramInt);
      if (presenter != null && presenter.isPresenterOf(paramObject.getClass()))
        return new PresenterPainter(paramObject, presenter); 
      Format format = getFormat(paramInt);
      if (format != null)
        try {
          return format.format(paramObject);
        } catch (Exception exception) {} 
    } 
    return paramObject;
  }
  
  public int getSummaryHeight() { return 20; }
  
  public Color getSummaryRowBorderColor(int paramInt) { return this.table.getRowBorderColor(this.table.getRowCount() - 1, paramInt); }
  
  public Color getSummaryColBorderColor(int paramInt) { return this.table.getColBorderColor(this.table.getRowCount() - 1, paramInt); }
  
  public int getSummaryRowBorder(int paramInt) { return this.table.getRowBorder(this.table.getRowCount() - 1, paramInt); }
  
  public int getSummaryColBorder(int paramInt) { return this.table.getColBorder(this.table.getRowCount() - 1, paramInt); }
  
  public Insets getSummaryInsets(int paramInt) { return this.table.getInsets(this.table.getRowCount() - 1, paramInt); }
  
  public Dimension getSummarySpan(int paramInt) { return null; }
  
  public int getSummaryAlignment(int paramInt) { return this.table.getAlignment(this.table.getRowCount() - 1, paramInt); }
  
  public Font getSummaryFont(int paramInt) { return this.table.getFont(this.table.getRowCount() - 1, paramInt); }
  
  public boolean isSummaryLineWrap(int paramInt) { return this.table.isLineWrap(this.table.getRowCount() - 1, paramInt); }
  
  public Color getSummaryForeground(int paramInt) { return this.table.getForeground(this.table.getRowCount() - 1, paramInt); }
  
  public Color getSummaryBackground(int paramInt) { return this.table.getBackground(this.table.getRowCount() - 1, paramInt); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\SummaryTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */