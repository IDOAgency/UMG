/*     */ package inetsoft.report;
/*     */ 
/*     */ import inetsoft.report.lens.AttributeTableLens;
/*     */ import inetsoft.report.painter.PresenterPainter;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import java.text.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SummaryTableLens
/*     */   extends AttributeTableLens
/*     */ {
/*     */   private TableLens table;
/*     */   
/*     */   public abstract Object getSummary(int paramInt1, int paramInt2, int paramInt3);
/*     */   
/*     */   public SummaryTableLens() {}
/*     */   
/*     */   public SummaryTableLens(TableLens paramTableLens) {
/*  55 */     super(paramTableLens);
/*  56 */     this.table = paramTableLens;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public TableLens getTable() { return this.table; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTable(TableLens paramTableLens) {
/*  72 */     this.table = paramTableLens;
/*  73 */     super.setTable(paramTableLens);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object render(Object paramObject, int paramInt) {
/*  83 */     if (paramObject != null) {
/*  84 */       Presenter presenter = getPresenter(paramInt);
/*  85 */       if (presenter != null && presenter.isPresenterOf(paramObject.getClass())) {
/*  86 */         return new PresenterPainter(paramObject, presenter);
/*     */       }
/*     */       
/*  89 */       Format format = getFormat(paramInt);
/*  90 */       if (format != null) {
/*  91 */         try { return format.format(paramObject); } catch (Exception exception) {}
/*     */       }
/*     */     } 
/*     */     
/*  95 */     return paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public int getSummaryHeight() { return 20; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public Color getSummaryRowBorderColor(int paramInt) { return this.table.getRowBorderColor(this.table.getRowCount() - 1, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public Color getSummaryColBorderColor(int paramInt) { return this.table.getColBorderColor(this.table.getRowCount() - 1, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public int getSummaryRowBorder(int paramInt) { return this.table.getRowBorder(this.table.getRowCount() - 1, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   public int getSummaryColBorder(int paramInt) { return this.table.getColBorder(this.table.getRowCount() - 1, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 153 */   public Insets getSummaryInsets(int paramInt) { return this.table.getInsets(this.table.getRowCount() - 1, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public Dimension getSummarySpan(int paramInt) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   public int getSummaryAlignment(int paramInt) { return this.table.getAlignment(this.table.getRowCount() - 1, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 186 */   public Font getSummaryFont(int paramInt) { return this.table.getFont(this.table.getRowCount() - 1, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   public boolean isSummaryLineWrap(int paramInt) { return this.table.isLineWrap(this.table.getRowCount() - 1, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 209 */   public Color getSummaryForeground(int paramInt) { return this.table.getForeground(this.table.getRowCount() - 1, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 220 */   public Color getSummaryBackground(int paramInt) { return this.table.getBackground(this.table.getRowCount() - 1, paramInt); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\SummaryTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */