package inetsoft.report;

import java.awt.Color;
import java.awt.Font;

public interface FormLens extends StyleConstants, Cloneable {
  int getFieldCount();
  
  int getFieldPerRow();
  
  int getWidth(int paramInt);
  
  Font getLabelFont(int paramInt);
  
  Color getLabelForeground(int paramInt);
  
  Color getLabelBackground(int paramInt);
  
  Font getFont(int paramInt);
  
  Color getForeground(int paramInt);
  
  Color getBackground(int paramInt);
  
  Object getField(int paramInt);
  
  Object getLabel(int paramInt);
  
  int getUnderline();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\FormLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */