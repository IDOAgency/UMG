package inetsoft.report.script;

import inetsoft.report.Position;
import inetsoft.report.ReportElement;
import inetsoft.report.SectionElement;
import inetsoft.report.Size;
import inetsoft.report.StyleFont;
import inetsoft.report.TOC;
import inetsoft.report.TableLens;
import inetsoft.report.filter.AverageFormula;
import inetsoft.report.filter.CountFormula;
import inetsoft.report.filter.DistinctCountFormula;
import inetsoft.report.filter.Formula;
import inetsoft.report.filter.GroupFilter;
import inetsoft.report.filter.MaxFormula;
import inetsoft.report.filter.MinFormula;
import inetsoft.report.filter.ProductFormula;
import inetsoft.report.filter.StandardDeviationFormula;
import inetsoft.report.filter.SumFormula;
import inetsoft.report.internal.BaseElement;
import inetsoft.report.internal.SectionInfo;
import inetsoft.report.internal.Util;
import java.awt.Color;
import java.awt.Insets;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Hashtable;
import org.mozilla.javascript.FunctionObject;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.Wrapper;

public class ElementScriptable implements Scriptable {
  private Scriptable parent;
  
  private Scriptable prototype;
  
  private ReportElement element;
  
  private Hashtable propmap;
  
  public ElementScriptable() {
    this.propmap = new Hashtable();
    addProperty("alignment", "getAlignment", "setAlignment", int.class, ReportElement.class);
    addProperty("indent", "getIndent", "setIndent", double.class, ReportElement.class);
    addProperty("font", "getFont", "setFont", java.awt.Font.class, ReportElement.class);
    addProperty("foreground", "getForeground", "setForeground", Color.class, ReportElement.class);
    addProperty("background", "getBackground", "setBackground", Color.class, ReportElement.class);
    addProperty("spacing", "getSpacing", "setSpacing", int.class, ReportElement.class);
    addProperty("visible", "isVisible", "setVisible", boolean.class, ReportElement.class);
    addProperty("keepWithNext", "isKeepWithNext", "setKeepWithNext", boolean.class, ReportElement.class);
  }
  
  public void setElement(ReportElement paramReportElement) {
    this.element = paramReportElement;
    Object object = ((BaseElement)paramReportElement).getUserObject();
    if (object instanceof SectionInfo) {
      try {
        SectionInfo sectionInfo = (SectionInfo)object;
        addProperty("sectionID", sectionInfo.id);
        addProperty("sectionRow", new Integer(sectionInfo.row));
        addProperty("sectionType", sectionInfo.type);
        addProperty("sectionLevel", new Integer(sectionInfo.level));
        Class[] arrayOfClass = { String.class, String.class };
        FunctionObject functionObject = new FunctionObject("sum", getClass().getMethod("sum", arrayOfClass), this);
        addProperty("sum", functionObject);
        functionObject = new FunctionObject("average", getClass().getMethod("average", arrayOfClass), this);
        addProperty("average", functionObject);
        functionObject = new FunctionObject("count", getClass().getMethod("count", arrayOfClass), this);
        addProperty("count", functionObject);
        functionObject = new FunctionObject("countDistinct", getClass().getMethod("countDistinct", arrayOfClass), this);
        addProperty("countDistinct", functionObject);
        functionObject = new FunctionObject("max", getClass().getMethod("max", arrayOfClass), this);
        addProperty("max", functionObject);
        functionObject = new FunctionObject("min", getClass().getMethod("min", arrayOfClass), this);
        addProperty("min", functionObject);
        functionObject = new FunctionObject("product", getClass().getMethod("product", arrayOfClass), this);
        addProperty("product", functionObject);
        functionObject = new FunctionObject("standardDeviation", getClass().getMethod("standardDeviation", arrayOfClass), this);
        addProperty("standardDeviation", functionObject);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } else {
      removeProperty("sectionID");
      removeProperty("sectionRow");
      removeProperty("sectionType");
      removeProperty("sectionLevel");
      removeProperty("sum");
      removeProperty("average");
      removeProperty("count");
      removeProperty("countDistinct");
      removeProperty("max");
      removeProperty("min");
      removeProperty("product");
      removeProperty("standardDeviation");
    } 
  }
  
  public ReportElement getElement() { return this.element; }
  
  public double sum(String paramString1, String paramString2) { return summarize(paramString1, paramString2, "sum", new SumFormula()); }
  
  public double average(String paramString1, String paramString2) { return summarize(paramString1, paramString2, "average", new AverageFormula()); }
  
  public double count(String paramString1, String paramString2) { return summarize(paramString1, paramString2, "count", new CountFormula()); }
  
  public double countDistinct(String paramString1, String paramString2) { return summarize(paramString1, paramString2, "distinct count", new DistinctCountFormula()); }
  
  public double max(String paramString1, String paramString2) { return summarize(paramString1, paramString2, "max", new MaxFormula()); }
  
  public double min(String paramString1, String paramString2) { return summarize(paramString1, paramString2, "min", new MinFormula()); }
  
  public double product(String paramString1, String paramString2) { return summarize(paramString1, paramString2, "product", new ProductFormula()); }
  
  public double standardDeviation(String paramString1, String paramString2) { return summarize(paramString1, paramString2, "standard deviation", new StandardDeviationFormula()); }
  
  private double summarize(String paramString1, String paramString2, String paramString3, Formula paramFormula) {
    Object object1 = ((BaseElement)this.element).getUserObject();
    if (!(object1 instanceof SectionInfo)) {
      System.err.println("Summary function on non-group element ignored: " + paramString3 + "('" + paramString1 + "', '" + paramString2 + "')");
      return 0.0D;
    } 
    SectionInfo sectionInfo = (SectionInfo)object1;
    String str = sectionInfo.id;
    int i = sectionInfo.row;
    Object object2 = sectionInfo.type;
    int j = sectionInfo.level;
    SectionElement sectionElement = (SectionElement)((BaseElement)this.element).getStyleSheet().getElement(str);
    if (sectionElement == null) {
      System.err.println("Section not found: " + str);
      return 0.0D;
    } 
    TableLens tableLens = (sectionElement != null) ? sectionElement.getTable() : null;
    GroupFilter groupFilter = (tableLens instanceof GroupFilter) ? (GroupFilter)tableLens : null;
    if (tableLens == null) {
      System.err.println("Summary function on non-table section ignored: " + paramString3 + "('" + paramString1 + "', '" + paramString2 + "')");
      return 0.0D;
    } 
    if (tableLens.getRowCount() <= 1)
      return 0.0D; 
    byte b1 = -1;
    for (byte b2 = 0; b2 < tableLens.getColCount(); b2++) {
      Object object = tableLens.getObject(0, b2);
      if (object != null && object.equals(paramString1)) {
        b1 = b2;
        break;
      } 
    } 
    if (b1 < 0) {
      System.err.println("Summary column not found, ignored: " + paramString3 + "('" + paramString1 + "', '" + paramString2 + "')");
      return 0.0D;
    } 
    int k = j;
    if (paramString2 != null && paramString2.length() > 0) {
      for (byte b = 0; b < tableLens.getColCount(); b++) {
        Object object = tableLens.getObject(0, b);
        if (object != null && object.equals(paramString2)) {
          k = b + 1;
          break;
        } 
      } 
      if (k < 0) {
        System.err.println("Group column not found, ignored: " + paramString3 + "('" + paramString1 + "', '" + paramString2 + "')");
        return 0.0D;
      } 
    } 
    paramFormula.reset();
    for (int m = i - 1; m > 0; m--) {
      if (groupFilter == null || !groupFilter.isSummaryRow(m)) {
        paramFormula.addValue(tableLens.getObject(m, b1));
        if (groupFilter != null) {
          int n = groupFilter.getGroupLevel(m);
          if (n >= 0 && n < k)
            break; 
        } 
      } 
    } 
    Object object3 = paramFormula.getResult();
    return (object3 instanceof Number) ? ((Number)object3).doubleValue() : 0.0D;
  }
  
  public String getClassName() { return "ReportElement"; }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    if (paramString.startsWith("section")) {
      Object object1 = ((BaseElement)this.element).getUserObject();
      if (object1 instanceof SectionInfo) {
        SectionInfo sectionInfo = (SectionInfo)object1;
        if (paramString.equals("sectionID"))
          return sectionInfo.id; 
        if (paramString.equals("sectionRow"))
          return new Integer(sectionInfo.row); 
        if (paramString.equals("sectionType"))
          return sectionInfo.type; 
        if (paramString.equals("sectionLevel"))
          return new Integer(sectionInfo.level); 
      } 
    } 
    Object object = null;
    try {
      ((BaseElement)this.element).evaluate();
      object = this.propmap.get(paramString);
      if (object instanceof PropertyDescriptor) {
        PropertyDescriptor propertyDescriptor = (PropertyDescriptor)object;
        return propertyDescriptor.getter.invoke(this.element, new Object[0]);
      } 
      if (object != null)
        return object; 
    } catch (Exception exception) {
      System.err.println("Get property failed: " + paramString);
      exception.printStackTrace();
    } 
    return Scriptable.NOT_FOUND;
  }
  
  public Object get(int paramInt, Scriptable paramScriptable) { return Scriptable.NOT_FOUND; }
  
  public boolean has(String paramString, Scriptable paramScriptable) { return (this.propmap.get(paramString) != null); }
  
  public boolean has(int paramInt, Scriptable paramScriptable) { return false; }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
    try {
      Object object = this.propmap.get(paramString);
      if (object instanceof PropertyDescriptor) {
        PropertyDescriptor propertyDescriptor = (PropertyDescriptor)object;
        propertyDescriptor.setter.invoke(this.element, new Object[] { propertyDescriptor.convert(paramObject) });
      } else if (object != null) {
        this.propmap.put(paramString, object);
      } 
    } catch (Exception exception) {
      System.err.println("Set property failed: " + paramString);
      exception.printStackTrace();
    } 
  }
  
  public void delete() {
    this.parent = this.prototype = null;
    this.element = null;
  }
  
  public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {}
  
  public void delete(String paramString) {}
  
  public void delete(int paramInt) {}
  
  public Scriptable getPrototype() { return this.prototype; }
  
  public void setPrototype(Scriptable paramScriptable) { this.prototype = paramScriptable; }
  
  public Scriptable getParentScope() { return this.parent; }
  
  public void setParentScope(Scriptable paramScriptable) { this.parent = paramScriptable; }
  
  public Object[] getIds() {
    Object[] arrayOfObject = new Object[this.propmap.size()];
    Enumeration enumeration = this.propmap.keys();
    for (byte b = 0; enumeration.hasMoreElements(); b++)
      arrayOfObject[b] = enumeration.nextElement(); 
    return arrayOfObject;
  }
  
  public Object getDefaultValue(Class paramClass) { return this.element.toString(); }
  
  public boolean hasInstance(Scriptable paramScriptable) { return false; }
  
  protected void addProperty(String paramString1, String paramString2, String paramString3, Class paramClass1, Class paramClass2) {
    try {
      Method method1 = paramClass2.getMethod(paramString2, new Class[0]);
      Method method2 = paramClass2.getMethod(paramString3, new Class[] { paramClass1 });
      this.propmap.put(paramString1, new PropertyDescriptor(this, method1, method2, paramClass1));
    } catch (Throwable throwable) {
      throwable.printStackTrace();
    } 
  }
  
  protected void addProperty(String paramString, Object paramObject) { this.propmap.put(paramString, paramObject); }
  
  protected void removeProperty(String paramString) { this.propmap.remove(paramString); }
  
  class PropertyDescriptor {
    public Method getter;
    
    public Method setter;
    
    public Class type;
    
    static Class array$D;
    
    static Class array$I;
    
    private final ElementScriptable this$0;
    
    public PropertyDescriptor(ElementScriptable this$0, Method param1Method1, Method param1Method2, Class param1Class) {
      this.this$0 = this$0;
      this.getter = param1Method1;
      this.setter = param1Method2;
      this.type = param1Class;
    }
    
    public Object convert(Object param1Object) {
      if (param1Object == null)
        return null; 
      if (param1Object instanceof Wrapper)
        param1Object = ((Wrapper)param1Object).unwrap(); 
      Class clazz = param1Object.getClass();
      if (this.type.isAssignableFrom(clazz))
        return param1Object; 
      if (this.type == String.class)
        return param1Object.toString(); 
      if (this.type == Color.class)
        return new Color(Integer.parseInt(param1Object.toString())); 
      if (this.type == java.awt.Font.class)
        return StyleFont.decode(param1Object.toString()); 
      if (this.type == Insets.class) {
        double[] arrayOfDouble = this.this$0.splitN(param1Object);
        return new Insets((int)arrayOfDouble[0], (int)arrayOfDouble[1], (int)arrayOfDouble[2], (int)arrayOfDouble[3]);
      } 
      if (this.type == Position.class) {
        double[] arrayOfDouble = this.this$0.splitN(param1Object);
        return new Position((int)arrayOfDouble[0], (int)arrayOfDouble[1]);
      } 
      if (this.type == Size.class) {
        double[] arrayOfDouble = this.this$0.splitN(param1Object);
        return new Size((int)arrayOfDouble[0], (int)arrayOfDouble[1]);
      } 
      if (this.type == TOC.class) {
        if (param1Object.equals("DEFAULT"))
          return TOC.DEFAULT; 
        if (param1Object.equals("CLASSIC"))
          return TOC.CLASSIC; 
        if (param1Object.equals("DISTINCTIVE"))
          return TOC.DISTINCTIVE; 
        if (param1Object.equals("FANCY"))
          return TOC.FANCY; 
        if (param1Object.equals("MODERN"))
          return TOC.MODERN; 
        if (param1Object.equals("FORMAL"))
          return TOC.FORMAL; 
        if (param1Object.equals("SIMPLE"))
          return TOC.SIMPLE; 
        return TOC.DEFAULT;
      } 
      if (this.type == boolean.class)
        return Boolean.valueOf(param1Object.toString()); 
      if (this.type == double.class)
        return Double.valueOf(param1Object.toString()); 
      if (this.type == ((array$D == null) ? (array$D = class$("[D")) : array$D))
        return this.this$0.splitN(param1Object); 
      if (this.type == int.class)
        return Integer.valueOf(param1Object.toString()); 
      if (this.type == ((array$I == null) ? (array$I = class$("[I")) : array$I)) {
        double[] arrayOfDouble = this.this$0.splitN(param1Object);
        int[] arrayOfInt = new int[arrayOfDouble.length];
        for (byte b = 0; b < arrayOfDouble.length; b++)
          arrayOfInt[b] = (int)arrayOfDouble[b]; 
        return arrayOfInt;
      } 
      return param1Object;
    }
  }
  
  double[] splitN(Object paramObject) {
    String[] arrayOfString = null;
    if (paramObject instanceof NativeArray) {
      NativeArray nativeArray = (NativeArray)paramObject;
      Object[] arrayOfObject = new Object[(int)nativeArray.jsGet_length()];
      for (byte b1 = 0; b1 < arrayOfObject.length; b1++)
        arrayOfObject[b1] = nativeArray.get(b1, nativeArray); 
      arrayOfString = arrayOfObject;
    } else if (paramObject.getClass().isArray()) {
      arrayOfString = paramObject;
    } else {
      arrayOfString = Util.split(paramObject.toString(), ',');
    } 
    double[] arrayOfDouble = new double[Array.getLength(arrayOfString)];
    for (byte b = 0; b < arrayOfDouble.length; b++) {
      Object object = Array.get(arrayOfString, b);
      try {
        arrayOfDouble[b] = (object instanceof Number) ? ((Number)object).doubleValue() : Double.valueOf(object.toString()).doubleValue();
      } catch (Throwable throwable) {}
    } 
    return arrayOfDouble;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\ElementScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */