package inetsoft.report.script;

public class NewlineScriptable extends ElementScriptable {
  public NewlineScriptable() { addProperty("count", "getCount", "setCount", int.class, inetsoft.report.NewlineElement.class); }
  
  public String getClassName() { return "NewlineElement"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\NewlineScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */