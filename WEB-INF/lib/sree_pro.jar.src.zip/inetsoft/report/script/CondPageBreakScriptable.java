package inetsoft.report.script;

public class CondPageBreakScriptable extends ElementScriptable {
  public CondPageBreakScriptable() { addProperty("condHeight", "getCondHeight", "setCondHeight", double.class, inetsoft.report.CondPageBreakElement.class); }
  
  public String getClassName() { return "CondPageBreakElement"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\CondPageBreakScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */