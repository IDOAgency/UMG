package inetsoft.report.script;

public class TextBoxScriptable extends PainterScriptable {
  public TextBoxScriptable() {
    addProperty("border", "getBorder", "setBorder", int.class, inetsoft.report.TextBoxElement.class);
    addProperty("shape", "getShape", "setShape", int.class, inetsoft.report.TextBoxElement.class);
    addProperty("justify", "isJustify", "setJustify", boolean.class, inetsoft.report.TextBoxElement.class);
    addProperty("text", "getText", "setText", String.class, inetsoft.report.TextBoxElement.class);
    addProperty("textAlignment", "getTextAlignment", "setTextAlignment", int.class, inetsoft.report.TextBoxElement.class);
    addProperty("padding", "getPadding", "setPadding", java.awt.Insets.class, inetsoft.report.TextBoxElement.class);
    addProperty("borders", "getBorders", "setBorders", java.awt.Insets.class, inetsoft.report.TextBoxElement.class);
  }
  
  public String getClassName() { return "TextBoxElement"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\TextBoxScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */