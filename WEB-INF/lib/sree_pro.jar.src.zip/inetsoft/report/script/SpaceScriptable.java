package inetsoft.report.script;

public class SpaceScriptable extends ElementScriptable {
  public SpaceScriptable() { addProperty("space", "getSpace", "setSpace", int.class, inetsoft.report.SpaceElement.class); }
  
  public String getClassName() { return "SpaceElement"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\SpaceScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */