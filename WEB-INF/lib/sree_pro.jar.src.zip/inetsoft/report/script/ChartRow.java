/*     */ package inetsoft.report.script;
/*     */ 
/*     */ import inetsoft.report.ChartLens;
/*     */ import inetsoft.report.lens.DefaultChartLens;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChartRow
/*     */   extends ScriptableObject
/*     */ {
/*     */   Scriptable prototype;
/*     */   ChartLens chart;
/*     */   int row;
/*     */   int length;
/*     */   
/*     */   public ChartRow(ChartLens paramChartLens, int paramInt) {
/*  28 */     this.chart = paramChartLens;
/*  29 */     this.row = paramInt;
/*  30 */     this.length = paramChartLens.getDatasetSize();
/*     */   }
/*     */ 
/*     */   
/*  34 */   public String getClassName() { return "ChartRow"; }
/*     */ 
/*     */ 
/*     */   
/*  38 */   public boolean has(String paramString, Scriptable paramScriptable) { return (paramString.equals("length") || super.has(paramString, paramScriptable)); }
/*     */ 
/*     */ 
/*     */   
/*  42 */   public boolean has(int paramInt, Scriptable paramScriptable) { return (0 <= paramInt && paramInt < this.length); }
/*     */ 
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/*  46 */     if (paramString.equals("length")) {
/*  47 */       return new Integer(this.length);
/*     */     }
/*     */     
/*  50 */     return super.get(paramString, paramScriptable);
/*     */   }
/*     */   
/*     */   public Object get(int paramInt, Scriptable paramScriptable) {
/*  54 */     if (0 <= paramInt && paramInt < this.length) {
/*  55 */       return this.chart.getData(this.row, paramInt);
/*     */     }
/*     */     
/*  58 */     return Undefined.instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
/*  63 */     if (!paramString.equals("length")) {
/*  64 */       super.put(paramString, paramScriptable, paramObject);
/*     */     }
/*     */   }
/*     */   
/*     */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
/*  69 */     if (this.chart instanceof DefaultChartLens && paramInt < this.length && paramObject instanceof Number)
/*     */     {
/*  71 */       ((DefaultChartLens)this.chart).setData(this.row, paramInt, (Number)paramObject);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getDefaultValue(Class paramClass) {
/*  76 */     if (paramClass == ScriptRuntime.BooleanClass)
/*  77 */       return Boolean.TRUE; 
/*  78 */     if (paramClass == ScriptRuntime.NumberClass)
/*  79 */       return ScriptRuntime.NaNobj; 
/*  80 */     return this;
/*     */   }
/*     */   
/*     */   public Object[] getIds() {
/*  84 */     Object[] arrayOfObject = new Object[this.length];
/*  85 */     int i = this.length;
/*  86 */     while (--i >= 0)
/*  87 */       arrayOfObject[i] = new Integer(i); 
/*  88 */     return arrayOfObject;
/*     */   }
/*     */ 
/*     */   
/*  92 */   public boolean hasInstance(Scriptable paramScriptable) { return false; }
/*     */ 
/*     */   
/*     */   public Scriptable getPrototype() {
/*  96 */     if (this.prototype == null) {
/*  97 */       this.prototype = ScriptableObject.getClassPrototype(getParentScope(), "Array");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 102 */     return this.prototype;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\ChartRow.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */