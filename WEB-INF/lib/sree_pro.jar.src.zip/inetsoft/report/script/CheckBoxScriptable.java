package inetsoft.report.script;

public class CheckBoxScriptable extends FieldScriptable {
  public CheckBoxScriptable() {
    addProperty("text", "getText", "setText", String.class, inetsoft.report.CheckBoxElement.class);
    addProperty("selected", "isSelected", "setSelected", boolean.class, inetsoft.report.CheckBoxElement.class);
  }
  
  public String getClassName() { return "CheckBoxElement"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\CheckBoxScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */