package inetsoft.report.script;

public class ChoiceScriptable extends FieldScriptable {
  static Class array$Ljava$lang$Object;
  
  public ChoiceScriptable() {
    addProperty("choices", "getChoices", "setChoices", (array$Ljava$lang$Object == null) ? (array$Ljava$lang$Object = class$("[Ljava.lang.Object;")) : array$Ljava$lang$Object, inetsoft.report.ChoiceElement.class);
    addProperty("selectedItem", "getSelectedItem", "setSelectedItem", Object.class, inetsoft.report.ChoiceElement.class);
  }
  
  public String getClassName() { return "ChoiceElement"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\ChoiceScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */