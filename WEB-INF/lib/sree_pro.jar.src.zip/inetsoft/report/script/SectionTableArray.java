package inetsoft.report.script;

import inetsoft.report.SectionElement;
import inetsoft.report.TableLens;

public class SectionTableArray extends TableArray {
  SectionScriptable section;
  
  public SectionTableArray(SectionScriptable paramSectionScriptable) {
    super(null);
    this.section = paramSectionScriptable;
  }
  
  public String getClassName() { return "Table"; }
  
  protected TableLens getTable() {
    if (this.section != null)
      return ((SectionElement)this.section.getElement()).getTable(); 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\SectionTableArray.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */