/*    */ package inetsoft.report.script;
/*    */ 
/*    */ import inetsoft.report.SectionElement;
/*    */ import inetsoft.report.TableLens;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SectionTableArray
/*    */   extends TableArray
/*    */ {
/*    */   SectionScriptable section;
/*    */   
/*    */   public SectionTableArray(SectionScriptable paramSectionScriptable) {
/* 27 */     super(null);
/* 28 */     this.section = paramSectionScriptable;
/*    */   }
/*    */ 
/*    */   
/* 32 */   public String getClassName() { return "Table"; }
/*    */ 
/*    */   
/*    */   protected TableLens getTable() {
/* 36 */     if (this.section != null) {
/* 37 */       return ((SectionElement)this.section.getElement()).getTable();
/*    */     }
/*    */     
/* 40 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\SectionTableArray.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */