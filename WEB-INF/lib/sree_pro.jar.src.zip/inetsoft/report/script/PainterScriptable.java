/*    */ package inetsoft.report.script;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PainterScriptable
/*    */   extends ElementScriptable
/*    */ {
/*    */   public PainterScriptable() {
/* 35 */     addProperty("margin", "getMargin", "setMargin", java.awt.Insets.class, inetsoft.report.PainterElement.class);
/*    */     
/* 37 */     addProperty("size", "getSize", "setSize", inetsoft.report.Size.class, inetsoft.report.PainterElement.class);
/*    */     
/* 39 */     addProperty("wrapping", "getWrapping", "setWrapping", int.class, inetsoft.report.PainterElement.class);
/*    */     
/* 41 */     addProperty("layout", "getLayout", "setLayout", int.class, inetsoft.report.PainterElement.class);
/*    */     
/* 43 */     addProperty("anchor", "getAnchor", "setAnchor", inetsoft.report.Position.class, inetsoft.report.PainterElement.class);
/*    */   }
/*    */   
/*    */   public String getClassName() { return "PainterElement"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\PainterScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */