package inetsoft.report.script;

public class ButtonScriptable extends FieldScriptable {
  public ButtonScriptable() { addProperty("text", "getText", "setText", String.class, inetsoft.report.ButtonElement.class); }
  
  public String getClassName() { return "ButtonElement"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\ButtonScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */