package inetsoft.report.script;

import org.mozilla.javascript.Scriptable;

public interface ScriptExt {
  void initGlobalScope(Scriptable paramScriptable);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\ScriptExt.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */