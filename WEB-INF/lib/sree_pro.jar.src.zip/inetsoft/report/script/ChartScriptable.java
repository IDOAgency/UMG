/*    */ package inetsoft.report.script;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChartScriptable
/*    */   extends PainterScriptable
/*    */ {
/*    */   public ChartScriptable() {
/* 34 */     addProperty("chart", "getChart", "setChart", inetsoft.report.ChartLens.class, inetsoft.report.ChartElement.class);
/*    */     
/* 36 */     addProperty("chartDescriptor", "getChartDescriptor", "setChartDescriptor", inetsoft.report.ChartDescriptor.class, inetsoft.report.ChartElement.class);
/*    */ 
/*    */     
/* 39 */     addProperty("dataset", new ChartArray(this));
/*    */   }
/*    */   
/*    */   public String getClassName() { return "ChartElement"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\ChartScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */