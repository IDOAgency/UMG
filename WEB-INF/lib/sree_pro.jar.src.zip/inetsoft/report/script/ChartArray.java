/*     */ package inetsoft.report.script;
/*     */ 
/*     */ import inetsoft.report.ChartElement;
/*     */ import inetsoft.report.ChartLens;
/*     */ import java.util.Vector;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChartArray
/*     */   extends ScriptableObject
/*     */ {
/*     */   Scriptable prototype;
/*     */   ChartScriptable chart;
/*     */   Vector rows;
/*     */   
/*     */   public ChartArray(ChartScriptable paramChartScriptable) {
/* 129 */     this.rows = new Vector();
/*     */     this.chart = paramChartScriptable;
/*     */   }
/*     */   
/*     */   public String getClassName() { return "Chart"; }
/*     */   
/*     */   public boolean has(String paramString, Scriptable paramScriptable) { return (paramString.equals("length") || super.has(paramString, paramScriptable)); }
/*     */   
/*     */   public boolean has(int paramInt, Scriptable paramScriptable) { return (getChart() != null && 0 <= paramInt && paramInt < getChart().getDatasetCount()); }
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/*     */     if (paramString.equals("length")) {
/*     */       ChartLens chartLens = getChart();
/*     */       return new Integer((chartLens == null) ? 0 : chartLens.getDatasetCount());
/*     */     } 
/*     */     return super.get(paramString, paramScriptable);
/*     */   }
/*     */   
/*     */   public Object get(int paramInt, Scriptable paramScriptable) {
/*     */     ChartLens chartLens = getChart();
/*     */     if (chartLens != null && 0 <= paramInt && paramInt < chartLens.getDatasetCount()) {
/*     */       ChartRow chartRow = (paramInt < this.rows.size()) ? (ChartRow)this.rows.elementAt(paramInt) : null;
/*     */       if (chartRow == null) {
/*     */         if (this.rows.size() < paramInt + 1)
/*     */           this.rows.setSize(paramInt + 1); 
/*     */         this.rows.setElementAt(chartRow = new ChartRow(getChart(), paramInt), paramInt);
/*     */       } 
/*     */       return chartRow;
/*     */     } 
/*     */     return Undefined.instance;
/*     */   }
/*     */   
/*     */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
/*     */     if (!paramString.equals("length"))
/*     */       super.put(paramString, paramScriptable, paramObject); 
/*     */   }
/*     */   
/*     */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {}
/*     */   
/*     */   public Object getDefaultValue(Class paramClass) {
/*     */     if (paramClass == ScriptRuntime.BooleanClass)
/*     */       return Boolean.TRUE; 
/*     */     if (paramClass == ScriptRuntime.NumberClass)
/*     */       return ScriptRuntime.NaNobj; 
/*     */     return this;
/*     */   }
/*     */   
/*     */   public Object[] getIds() {
/*     */     ChartLens chartLens = getChart();
/*     */     boolean bool = (chartLens == null) ? 0 : chartLens.getDatasetCount();
/*     */     Object[] arrayOfObject = new Object[bool];
/*     */     byte b = bool;
/*     */     while (--b >= 0)
/*     */       arrayOfObject[b] = new Integer(b); 
/*     */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   public boolean hasInstance(Scriptable paramScriptable) { return false; }
/*     */   
/*     */   public Scriptable getPrototype() {
/*     */     if (this.prototype == null)
/*     */       this.prototype = ScriptableObject.getClassPrototype(getParentScope(), "Array"); 
/*     */     return this.prototype;
/*     */   }
/*     */   
/*     */   protected ChartLens getChart() {
/*     */     if (this.chart != null)
/*     */       return ((ChartElement)this.chart.getElement()).getChart(); 
/*     */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\ChartArray.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */