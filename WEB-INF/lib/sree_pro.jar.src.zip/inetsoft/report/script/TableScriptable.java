/*    */ package inetsoft.report.script;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TableScriptable
/*    */   extends ElementScriptable
/*    */ {
/*    */   static Class array$I;
/*    */   
/*    */   public TableScriptable() {
/* 34 */     addProperty("fixedWidths", "getFixedWidths", "setFixedWidths", (array$I == null) ? (array$I = class$("[I")) : array$I, inetsoft.report.TableElement.class);
/*    */     
/* 36 */     addProperty("layout", "getLayout", "setLayout", int.class, inetsoft.report.TableElement.class);
/*    */     
/* 38 */     addProperty("orphanControl", "isOrphanControl", "setOrphanControl", boolean.class, inetsoft.report.TableElement.class);
/*    */     
/* 40 */     addProperty("padding", "getPadding", "setPadding", java.awt.Insets.class, inetsoft.report.TableElement.class);
/*    */     
/* 42 */     addProperty("table", new TableArray(this));
/* 43 */     addProperty("tableAdvance", "getTableAdvance", "setTableAdvance", int.class, inetsoft.report.TableElement.class);
/*    */     
/* 45 */     addProperty("tableWidth", "getTableWidth", "setTableWidth", double.class, inetsoft.report.TableElement.class);
/*    */     
/* 47 */     addProperty("tableLens", "getTable", "setTable", inetsoft.report.TableLens.class, inetsoft.report.TableElement.class);
/*    */   }
/*    */   
/*    */   public String getClassName() { return "TableElement"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\TableScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */