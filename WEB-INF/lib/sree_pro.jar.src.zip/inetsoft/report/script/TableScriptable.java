package inetsoft.report.script;

public class TableScriptable extends ElementScriptable {
  static Class array$I;
  
  public TableScriptable() {
    addProperty("fixedWidths", "getFixedWidths", "setFixedWidths", (array$I == null) ? (array$I = class$("[I")) : array$I, inetsoft.report.TableElement.class);
    addProperty("layout", "getLayout", "setLayout", int.class, inetsoft.report.TableElement.class);
    addProperty("orphanControl", "isOrphanControl", "setOrphanControl", boolean.class, inetsoft.report.TableElement.class);
    addProperty("padding", "getPadding", "setPadding", java.awt.Insets.class, inetsoft.report.TableElement.class);
    addProperty("table", new TableArray(this));
    addProperty("tableAdvance", "getTableAdvance", "setTableAdvance", int.class, inetsoft.report.TableElement.class);
    addProperty("tableWidth", "getTableWidth", "setTableWidth", double.class, inetsoft.report.TableElement.class);
    addProperty("tableLens", "getTable", "setTable", inetsoft.report.TableLens.class, inetsoft.report.TableElement.class);
  }
  
  public String getClassName() { return "TableElement"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\TableScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */