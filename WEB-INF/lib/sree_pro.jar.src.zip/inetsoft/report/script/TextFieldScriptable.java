package inetsoft.report.script;

public class TextFieldScriptable extends FieldScriptable {
  public TextFieldScriptable() {
    addProperty("text", "getText", "setText", String.class, inetsoft.report.TextFieldElement.class);
    addProperty("cols", "getCols", "setCols", int.class, inetsoft.report.TextFieldElement.class);
  }
  
  public String getClassName() { return "TextFieldElement"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\TextFieldScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */