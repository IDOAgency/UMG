/*     */ package inetsoft.report.script;
/*     */ 
/*     */ import inetsoft.report.FixedContainer;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.SectionBand;
/*     */ import inetsoft.report.SectionElement;
/*     */ import inetsoft.report.SectionLens;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.uql.VariableTable;
/*     */ import java.io.StringReader;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Vector;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.NativeJavaPackage;
/*     */ import org.mozilla.javascript.Script;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.Wrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScriptEngine
/*     */ {
/*     */   public void init(StyleSheet paramStyleSheet) throws Exception {
/*  45 */     this.report = paramStyleSheet;
/*  46 */     this.cx = Context.enter();
/*  47 */     initScope();
/*     */     
/*  49 */     this.topscope = this.cx.newObject(globalscope);
/*  50 */     this.topscope.setPrototype(globalscope);
/*     */     
/*  52 */     this.rscope = this.cx.newObject(this.topscope);
/*  53 */     this.rscope.setParentScope(this.topscope);
/*  54 */     this.topscope.put("report", this.topscope, this.rscope);
/*     */     
/*  56 */     this.topscope.put("stylesheet", this.topscope, paramStyleSheet);
/*     */ 
/*     */     
/*  59 */     addElements(this.rscope, paramStyleSheet.getAllElements());
/*  60 */     addElements(this.rscope, paramStyleSheet.getAllHeaderElements());
/*  61 */     addElements(this.rscope, paramStyleSheet.getAllFooterElements());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initScope() {
/*  68 */     if (globalscope == null) {
/*  69 */       Context context = Context.enter();
/*  70 */       globalscope = (ScriptableObject)context.initStandardObjects(null);
/*     */       
/*  72 */       Scriptable scriptable = context.newObject(globalscope);
/*  73 */       scriptable.setParentScope(globalscope);
/*     */ 
/*     */ 
/*     */       
/*  77 */       addFields(scriptable, inetsoft.report.StyleConstants.class);
/*  78 */       addFields(scriptable, StyleSheet.class);
/*  79 */       addFields(scriptable, inetsoft.report.TableLens.class);
/*     */ 
/*     */       
/*  82 */       globalscope.put("StyleReport", globalscope, scriptable);
/*     */ 
/*     */       
/*  85 */       globalscope.put("inetsoft", globalscope, new NativeJavaPackage("inetsoft"));
/*     */ 
/*     */ 
/*     */       
/*  89 */       scriptable = context.newObject(globalscope);
/*  90 */       scriptable.setParentScope(globalscope);
/*  91 */       addFields(scriptable, inetsoft.report.TOC.class);
/*  92 */       globalscope.put("TOC", globalscope, scriptable);
/*     */       
/*  94 */       for (byte b = 0; b < exts.size(); b++) {
/*  95 */         ((ScriptExt)exts.elementAt(b)).initGlobalScope(globalscope);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public static void addScriptExt(ScriptExt paramScriptExt) { exts.addElement(paramScriptExt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Script compile(String paramString) throws Exception {
/* 111 */     this.cx = Context.enter();
/* 112 */     return this.cx.compileReader(this.rscope, new StringReader(paramString), "<cmd", 1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object evaluate(String paramString) throws Exception {
/* 119 */     this.cx = Context.enter();
/* 120 */     Object object = this.cx.evaluateString(this.rscope, paramString, "<cmd>", 1, null);
/* 121 */     return unwrap(object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object exec(Script paramScript, Scriptable paramScriptable) throws Exception {
/* 131 */     this.cx = Context.enter();
/* 132 */     Object object = paramScript.exec(this.cx, (paramScriptable == null) ? this.rscope : paramScriptable);
/* 133 */     return unwrap(object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable getScriptable(String paramString, Scriptable paramScriptable) {
/* 143 */     paramScriptable = (paramScriptable == null) ? this.rscope : paramScriptable;
/*     */     
/* 145 */     if (paramString == null) {
/* 146 */       return paramScriptable;
/*     */     }
/*     */     
/* 149 */     Object object = paramScriptable.get(toIdentifier(paramString), paramScriptable);
/* 150 */     return (object == Scriptable.NOT_FOUND) ? null : (Scriptable)object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable newScope(FixedContainer paramFixedContainer) throws Exception {
/* 157 */     this.cx = Context.enter();
/* 158 */     Scriptable scriptable = this.cx.newObject(this.rscope);
/*     */     
/* 160 */     for (byte b = 0; b < paramFixedContainer.getElementCount(); b++) {
/* 161 */       addElement(scriptable, paramFixedContainer.getElement(b));
/*     */     }
/*     */     
/* 164 */     scriptable.setParentScope(this.rscope);
/* 165 */     return scriptable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String paramString, Object paramObject) {
/* 174 */     Scriptable scriptable = getScriptable(null, null);
/*     */     
/* 176 */     if (paramObject instanceof VariableTable) {
/* 177 */       scriptable.put(paramString, scriptable, new VariableScriptable((VariableTable)paramObject));
/*     */     } else {
/*     */       
/* 180 */       scriptable.put(paramString, scriptable, paramObject);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void finalize() {
/* 185 */     delete(this.rscope);
/* 186 */     delete(this.topscope);
/* 187 */     this.topscope = null;
/* 188 */     this.rscope = null;
/* 189 */     Context.exit();
/* 190 */     this.cx = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addElements(Scriptable paramScriptable, Vector paramVector) {
/* 198 */     for (byte b = 0; b < paramVector.size(); b++) {
/* 199 */       Object object = paramVector.elementAt(b);
/*     */       
/* 201 */       if (object instanceof Vector) {
/* 202 */         Vector vector = (Vector)object;
/*     */         
/* 204 */         for (byte b1 = 0; b1 < vector.size(); b1++) {
/* 205 */           ReportElement reportElement = (ReportElement)vector.elementAt(b1);
/* 206 */           addElement(paramScriptable, reportElement);
/*     */         }
/*     */       
/* 209 */       } else if (object instanceof FixedContainer) {
/* 210 */         addElements(paramScriptable, (FixedContainer)object);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addElements(Scriptable paramScriptable, SectionLens paramSectionLens) {
/*     */     SectionBand sectionBand;
/* 221 */     if ((sectionBand = paramSectionLens.getSectionHeader()) != null) {
/* 222 */       addElements(paramScriptable, sectionBand);
/*     */     }
/*     */     
/* 225 */     if ((sectionBand = paramSectionLens.getSectionFooter()) != null) {
/* 226 */       addElements(paramScriptable, sectionBand);
/*     */     }
/*     */     
/* 229 */     Object object = paramSectionLens.getSectionContent();
/* 230 */     if (object instanceof SectionLens) {
/* 231 */       addElements(paramScriptable, (SectionLens)object);
/*     */     }
/* 233 */     else if (object instanceof SectionBand) {
/* 234 */       addElements(paramScriptable, (SectionBand)object);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addElements(Scriptable paramScriptable, FixedContainer paramFixedContainer) {
/* 242 */     for (byte b = 0; b < paramFixedContainer.getElementCount(); b++) {
/* 243 */       ReportElement reportElement = paramFixedContainer.getElement(b);
/* 244 */       addElement(paramScriptable, reportElement);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addElement(Scriptable paramScriptable, ReportElement paramReportElement) {
/* 252 */     ElementScriptable elementScriptable = null;
/*     */     
/* 254 */     if (paramReportElement instanceof inetsoft.report.CheckBoxElement) {
/* 255 */       elementScriptable = new CheckBoxScriptable();
/*     */     }
/* 257 */     else if (paramReportElement instanceof inetsoft.report.ChoiceElement) {
/* 258 */       ChoiceScriptable choiceScriptable = new ChoiceScriptable();
/*     */     }
/* 260 */     else if (paramReportElement instanceof inetsoft.report.ImageButtonElement) {
/* 261 */       ImageButtonScriptable imageButtonScriptable = new ImageButtonScriptable();
/*     */     }
/* 263 */     else if (paramReportElement instanceof inetsoft.report.TextAreaElement) {
/* 264 */       TextAreaScriptable textAreaScriptable = new TextAreaScriptable();
/*     */     }
/* 266 */     else if (paramReportElement instanceof inetsoft.report.TextFieldElement) {
/* 267 */       TextFieldScriptable textFieldScriptable = new TextFieldScriptable();
/*     */     }
/* 269 */     else if (paramReportElement instanceof inetsoft.report.ButtonElement) {
/* 270 */       ButtonScriptable buttonScriptable = new ButtonScriptable();
/*     */     }
/* 272 */     else if (paramReportElement instanceof inetsoft.report.ChartElement) {
/* 273 */       ChartScriptable chartScriptable = new ChartScriptable();
/*     */     }
/* 275 */     else if (paramReportElement instanceof inetsoft.report.TextBoxElement) {
/* 276 */       TextBoxScriptable textBoxScriptable = new TextBoxScriptable();
/*     */     }
/* 278 */     else if (paramReportElement instanceof inetsoft.report.HeadingElement) {
/* 279 */       HeadingScriptable headingScriptable = new HeadingScriptable();
/*     */     }
/* 281 */     else if (paramReportElement instanceof inetsoft.report.TextElement) {
/* 282 */       TextScriptable textScriptable = new TextScriptable();
/*     */     }
/* 284 */     else if (paramReportElement instanceof inetsoft.report.CondPageBreakElement) {
/* 285 */       CondPageBreakScriptable condPageBreakScriptable = new CondPageBreakScriptable();
/*     */     }
/* 287 */     else if (paramReportElement instanceof inetsoft.report.FormElement) {
/* 288 */       FormScriptable formScriptable = new FormScriptable();
/*     */     }
/* 290 */     else if (paramReportElement instanceof inetsoft.report.NewlineElement) {
/* 291 */       NewlineScriptable newlineScriptable = new NewlineScriptable();
/*     */     }
/* 293 */     else if (paramReportElement instanceof SectionElement) {
/* 294 */       SectionScriptable sectionScriptable = new SectionScriptable();
/* 295 */       addElements(paramScriptable, ((SectionElement)paramReportElement).getSection());
/*     */     }
/* 297 */     else if (paramReportElement instanceof inetsoft.report.SeparatorElement) {
/* 298 */       SeparatorScriptable separatorScriptable = new SeparatorScriptable();
/*     */     }
/* 300 */     else if (paramReportElement instanceof inetsoft.report.SpaceElement) {
/* 301 */       SpaceScriptable spaceScriptable = new SpaceScriptable();
/*     */     }
/* 303 */     else if (paramReportElement instanceof inetsoft.report.TOCElement) {
/* 304 */       TOCScriptable tOCScriptable = new TOCScriptable();
/*     */     }
/* 306 */     else if (paramReportElement instanceof inetsoft.report.TabElement) {
/* 307 */       TabScriptable tabScriptable = new TabScriptable();
/*     */     }
/* 309 */     else if (paramReportElement instanceof inetsoft.report.TableElement) {
/* 310 */       TableScriptable tableScriptable = new TableScriptable();
/*     */     }
/* 312 */     else if (paramReportElement instanceof inetsoft.report.PainterElement) {
/* 313 */       PainterScriptable painterScriptable = new PainterScriptable();
/*     */     } else {
/*     */       
/* 316 */       elementScriptable = new ElementScriptable();
/*     */     } 
/*     */     
/* 319 */     elementScriptable.setElement(paramReportElement);
/* 320 */     elementScriptable.setParentScope(paramScriptable);
/*     */     
/* 322 */     paramScriptable.put(toIdentifier(paramReportElement.getID()), paramScriptable, elementScriptable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addFields(Scriptable paramScriptable, Class paramClass) throws Exception {
/* 329 */     Field[] arrayOfField = paramClass.getFields();
/*     */     
/* 331 */     for (byte b = 0; b < arrayOfField.length; b++) {
/* 332 */       int i = arrayOfField[b].getModifiers();
/*     */       
/* 334 */       if (Modifier.isPublic(i) && Modifier.isStatic(i) && Modifier.isFinal(i))
/*     */       {
/* 336 */         paramScriptable.put(arrayOfField[b].getName(), paramScriptable, arrayOfField[b].get(null));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 345 */   private String toIdentifier(String paramString) { return paramString.replace(' ', '_'); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void delete(Scriptable paramScriptable) {
/* 354 */     if (paramScriptable instanceof ElementScriptable) {
/* 355 */       ((ElementScriptable)paramScriptable).delete();
/*     */       
/*     */       return;
/*     */     } 
/* 359 */     Object[] arrayOfObject = paramScriptable.getIds();
/* 360 */     for (byte b = 0; b < arrayOfObject.length; b++) {
/* 361 */       Object object = null;
/*     */       
/* 363 */       if (arrayOfObject[b] instanceof Integer) {
/* 364 */         int i = ((Integer)arrayOfObject[b]).intValue();
/* 365 */         object = paramScriptable.get(i, paramScriptable);
/*     */         
/* 367 */         if (object instanceof Scriptable) {
/* 368 */           paramScriptable.delete(i);
/* 369 */           delete((Scriptable)object);
/*     */         }
/*     */       
/* 372 */       } else if (arrayOfObject[b] instanceof String) {
/* 373 */         object = paramScriptable.get((String)arrayOfObject[b], paramScriptable);
/*     */         
/* 375 */         if (object instanceof Scriptable) {
/* 376 */           paramScriptable.delete((String)arrayOfObject[b]);
/* 377 */           delete((Scriptable)object);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object unwrap(Object paramObject) {
/* 387 */     if (paramObject instanceof Wrapper) {
/* 388 */       return ((Wrapper)paramObject).unwrap();
/*     */     }
/*     */     
/* 391 */     return paramObject;
/*     */   }
/*     */   
/* 394 */   Context cx = null;
/* 395 */   Scriptable topscope = null;
/* 396 */   Scriptable rscope = null;
/* 397 */   StyleSheet report = null;
/* 398 */   static ScriptableObject globalscope = null;
/* 399 */   static Vector exts = new Vector();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\ScriptEngine.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */