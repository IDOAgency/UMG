package inetsoft.report.script;

import inetsoft.report.FixedContainer;
import inetsoft.report.ReportElement;
import inetsoft.report.SectionBand;
import inetsoft.report.SectionElement;
import inetsoft.report.SectionLens;
import inetsoft.report.StyleSheet;
import inetsoft.uql.VariableTable;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Vector;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.NativeJavaPackage;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Wrapper;

public class ScriptEngine {
  public void init(StyleSheet paramStyleSheet) throws Exception {
    this.report = paramStyleSheet;
    this.cx = Context.enter();
    initScope();
    this.topscope = this.cx.newObject(globalscope);
    this.topscope.setPrototype(globalscope);
    this.rscope = this.cx.newObject(this.topscope);
    this.rscope.setParentScope(this.topscope);
    this.topscope.put("report", this.topscope, this.rscope);
    this.topscope.put("stylesheet", this.topscope, paramStyleSheet);
    addElements(this.rscope, paramStyleSheet.getAllElements());
    addElements(this.rscope, paramStyleSheet.getAllHeaderElements());
    addElements(this.rscope, paramStyleSheet.getAllFooterElements());
  }
  
  public static void initScope() {
    if (globalscope == null) {
      Context context = Context.enter();
      globalscope = (ScriptableObject)context.initStandardObjects(null);
      Scriptable scriptable = context.newObject(globalscope);
      scriptable.setParentScope(globalscope);
      addFields(scriptable, inetsoft.report.StyleConstants.class);
      addFields(scriptable, StyleSheet.class);
      addFields(scriptable, inetsoft.report.TableLens.class);
      globalscope.put("StyleReport", globalscope, scriptable);
      globalscope.put("inetsoft", globalscope, new NativeJavaPackage("inetsoft"));
      scriptable = context.newObject(globalscope);
      scriptable.setParentScope(globalscope);
      addFields(scriptable, inetsoft.report.TOC.class);
      globalscope.put("TOC", globalscope, scriptable);
      for (byte b = 0; b < exts.size(); b++)
        ((ScriptExt)exts.elementAt(b)).initGlobalScope(globalscope); 
    } 
  }
  
  public static void addScriptExt(ScriptExt paramScriptExt) { exts.addElement(paramScriptExt); }
  
  public Script compile(String paramString) throws Exception {
    this.cx = Context.enter();
    return this.cx.compileReader(this.rscope, new StringReader(paramString), "<cmd", 1, null);
  }
  
  public Object evaluate(String paramString) throws Exception {
    this.cx = Context.enter();
    Object object = this.cx.evaluateString(this.rscope, paramString, "<cmd>", 1, null);
    return unwrap(object);
  }
  
  public Object exec(Script paramScript, Scriptable paramScriptable) throws Exception {
    this.cx = Context.enter();
    Object object = paramScript.exec(this.cx, (paramScriptable == null) ? this.rscope : paramScriptable);
    return unwrap(object);
  }
  
  public Scriptable getScriptable(String paramString, Scriptable paramScriptable) {
    paramScriptable = (paramScriptable == null) ? this.rscope : paramScriptable;
    if (paramString == null)
      return paramScriptable; 
    Object object = paramScriptable.get(toIdentifier(paramString), paramScriptable);
    return (object == Scriptable.NOT_FOUND) ? null : (Scriptable)object;
  }
  
  public Scriptable newScope(FixedContainer paramFixedContainer) throws Exception {
    this.cx = Context.enter();
    Scriptable scriptable = this.cx.newObject(this.rscope);
    for (byte b = 0; b < paramFixedContainer.getElementCount(); b++)
      addElement(scriptable, paramFixedContainer.getElement(b)); 
    scriptable.setParentScope(this.rscope);
    return scriptable;
  }
  
  public void put(String paramString, Object paramObject) {
    Scriptable scriptable = getScriptable(null, null);
    if (paramObject instanceof VariableTable) {
      scriptable.put(paramString, scriptable, new VariableScriptable((VariableTable)paramObject));
    } else {
      scriptable.put(paramString, scriptable, paramObject);
    } 
  }
  
  public void finalize() {
    delete(this.rscope);
    delete(this.topscope);
    this.topscope = null;
    this.rscope = null;
    Context.exit();
    this.cx = null;
  }
  
  private void addElements(Scriptable paramScriptable, Vector paramVector) {
    for (byte b = 0; b < paramVector.size(); b++) {
      Object object = paramVector.elementAt(b);
      if (object instanceof Vector) {
        Vector vector = (Vector)object;
        for (byte b1 = 0; b1 < vector.size(); b1++) {
          ReportElement reportElement = (ReportElement)vector.elementAt(b1);
          addElement(paramScriptable, reportElement);
        } 
      } else if (object instanceof FixedContainer) {
        addElements(paramScriptable, (FixedContainer)object);
      } 
    } 
  }
  
  private void addElements(Scriptable paramScriptable, SectionLens paramSectionLens) {
    SectionBand sectionBand;
    if ((sectionBand = paramSectionLens.getSectionHeader()) != null)
      addElements(paramScriptable, sectionBand); 
    if ((sectionBand = paramSectionLens.getSectionFooter()) != null)
      addElements(paramScriptable, sectionBand); 
    Object object = paramSectionLens.getSectionContent();
    if (object instanceof SectionLens) {
      addElements(paramScriptable, (SectionLens)object);
    } else if (object instanceof SectionBand) {
      addElements(paramScriptable, (SectionBand)object);
    } 
  }
  
  private void addElements(Scriptable paramScriptable, FixedContainer paramFixedContainer) {
    for (byte b = 0; b < paramFixedContainer.getElementCount(); b++) {
      ReportElement reportElement = paramFixedContainer.getElement(b);
      addElement(paramScriptable, reportElement);
    } 
  }
  
  private void addElement(Scriptable paramScriptable, ReportElement paramReportElement) {
    ElementScriptable elementScriptable = null;
    if (paramReportElement instanceof inetsoft.report.CheckBoxElement) {
      elementScriptable = new CheckBoxScriptable();
    } else if (paramReportElement instanceof inetsoft.report.ChoiceElement) {
      ChoiceScriptable choiceScriptable = new ChoiceScriptable();
    } else if (paramReportElement instanceof inetsoft.report.ImageButtonElement) {
      ImageButtonScriptable imageButtonScriptable = new ImageButtonScriptable();
    } else if (paramReportElement instanceof inetsoft.report.TextAreaElement) {
      TextAreaScriptable textAreaScriptable = new TextAreaScriptable();
    } else if (paramReportElement instanceof inetsoft.report.TextFieldElement) {
      TextFieldScriptable textFieldScriptable = new TextFieldScriptable();
    } else if (paramReportElement instanceof inetsoft.report.ButtonElement) {
      ButtonScriptable buttonScriptable = new ButtonScriptable();
    } else if (paramReportElement instanceof inetsoft.report.ChartElement) {
      ChartScriptable chartScriptable = new ChartScriptable();
    } else if (paramReportElement instanceof inetsoft.report.TextBoxElement) {
      TextBoxScriptable textBoxScriptable = new TextBoxScriptable();
    } else if (paramReportElement instanceof inetsoft.report.HeadingElement) {
      HeadingScriptable headingScriptable = new HeadingScriptable();
    } else if (paramReportElement instanceof inetsoft.report.TextElement) {
      TextScriptable textScriptable = new TextScriptable();
    } else if (paramReportElement instanceof inetsoft.report.CondPageBreakElement) {
      CondPageBreakScriptable condPageBreakScriptable = new CondPageBreakScriptable();
    } else if (paramReportElement instanceof inetsoft.report.FormElement) {
      FormScriptable formScriptable = new FormScriptable();
    } else if (paramReportElement instanceof inetsoft.report.NewlineElement) {
      NewlineScriptable newlineScriptable = new NewlineScriptable();
    } else if (paramReportElement instanceof SectionElement) {
      SectionScriptable sectionScriptable = new SectionScriptable();
      addElements(paramScriptable, ((SectionElement)paramReportElement).getSection());
    } else if (paramReportElement instanceof inetsoft.report.SeparatorElement) {
      SeparatorScriptable separatorScriptable = new SeparatorScriptable();
    } else if (paramReportElement instanceof inetsoft.report.SpaceElement) {
      SpaceScriptable spaceScriptable = new SpaceScriptable();
    } else if (paramReportElement instanceof inetsoft.report.TOCElement) {
      TOCScriptable tOCScriptable = new TOCScriptable();
    } else if (paramReportElement instanceof inetsoft.report.TabElement) {
      TabScriptable tabScriptable = new TabScriptable();
    } else if (paramReportElement instanceof inetsoft.report.TableElement) {
      TableScriptable tableScriptable = new TableScriptable();
    } else if (paramReportElement instanceof inetsoft.report.PainterElement) {
      PainterScriptable painterScriptable = new PainterScriptable();
    } else {
      elementScriptable = new ElementScriptable();
    } 
    elementScriptable.setElement(paramReportElement);
    elementScriptable.setParentScope(paramScriptable);
    paramScriptable.put(toIdentifier(paramReportElement.getID()), paramScriptable, elementScriptable);
  }
  
  private static void addFields(Scriptable paramScriptable, Class paramClass) throws Exception {
    Field[] arrayOfField = paramClass.getFields();
    for (byte b = 0; b < arrayOfField.length; b++) {
      int i = arrayOfField[b].getModifiers();
      if (Modifier.isPublic(i) && Modifier.isStatic(i) && Modifier.isFinal(i))
        paramScriptable.put(arrayOfField[b].getName(), paramScriptable, arrayOfField[b].get(null)); 
    } 
  }
  
  private String toIdentifier(String paramString) { return paramString.replace(' ', '_'); }
  
  private void delete(Scriptable paramScriptable) {
    if (paramScriptable instanceof ElementScriptable) {
      ((ElementScriptable)paramScriptable).delete();
      return;
    } 
    Object[] arrayOfObject = paramScriptable.getIds();
    for (byte b = 0; b < arrayOfObject.length; b++) {
      Object object = null;
      if (arrayOfObject[b] instanceof Integer) {
        int i = ((Integer)arrayOfObject[b]).intValue();
        object = paramScriptable.get(i, paramScriptable);
        if (object instanceof Scriptable) {
          paramScriptable.delete(i);
          delete((Scriptable)object);
        } 
      } else if (arrayOfObject[b] instanceof String) {
        object = paramScriptable.get((String)arrayOfObject[b], paramScriptable);
        if (object instanceof Scriptable) {
          paramScriptable.delete((String)arrayOfObject[b]);
          delete((Scriptable)object);
        } 
      } 
    } 
  }
  
  public static Object unwrap(Object paramObject) {
    if (paramObject instanceof Wrapper)
      return ((Wrapper)paramObject).unwrap(); 
    return paramObject;
  }
  
  Context cx = null;
  
  Scriptable topscope = null;
  
  Scriptable rscope = null;
  
  StyleSheet report = null;
  
  static ScriptableObject globalscope = null;
  
  static Vector exts = new Vector();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\ScriptEngine.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */