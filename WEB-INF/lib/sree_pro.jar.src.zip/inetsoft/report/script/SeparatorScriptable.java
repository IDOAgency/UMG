/*    */ package inetsoft.report.script;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SeparatorScriptable
/*    */   extends ElementScriptable
/*    */ {
/*    */   public SeparatorScriptable() {
/* 34 */     addProperty("style", "getStyle", "setStyle", int.class, inetsoft.report.SeparatorElement.class);
/*    */     
/* 36 */     addProperty("separatorAdvance", "getSeparatorAdvance", "setSeparatorAdvance", int.class, inetsoft.report.SeparatorElement.class);
/*    */   }
/*    */   
/*    */   public String getClassName() { return "SeparatorElement"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\SeparatorScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */