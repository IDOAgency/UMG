/*    */ package inetsoft.report.script;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextAreaScriptable
/*    */   extends FieldScriptable
/*    */ {
/*    */   public TextAreaScriptable() {
/* 36 */     addProperty("text", "getText", "setText", String.class, inetsoft.report.TextAreaElement.class);
/*    */     
/* 38 */     addProperty("cols", "getCols", "setCols", int.class, inetsoft.report.TextAreaElement.class);
/*    */     
/* 40 */     addProperty("rows", "getRows", "setRows", int.class, inetsoft.report.TextAreaElement.class);
/*    */   }
/*    */   
/*    */   public String getClassName() { return "TextAreaElement"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\TextAreaScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */