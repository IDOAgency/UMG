/*     */ package inetsoft.report.script;
/*     */ 
/*     */ import inetsoft.report.TableElement;
/*     */ import inetsoft.report.TableLens;
/*     */ import java.util.Vector;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableArray
/*     */   extends ScriptableObject
/*     */ {
/*     */   Scriptable prototype;
/*     */   TableScriptable table;
/*     */   Vector rows;
/*     */   
/*     */   public TableArray(TableScriptable paramTableScriptable) {
/* 129 */     this.rows = new Vector();
/*     */     this.table = paramTableScriptable;
/*     */   }
/*     */   
/*     */   public String getClassName() { return "Table"; }
/*     */   
/*     */   public boolean has(String paramString, Scriptable paramScriptable) { return (paramString.equals("length") || super.has(paramString, paramScriptable)); }
/*     */   
/*     */   public boolean has(int paramInt, Scriptable paramScriptable) { return (getTable() != null && 0 <= paramInt && paramInt < getTable().getRowCount()); }
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/*     */     if (paramString.equals("length")) {
/*     */       TableLens tableLens = getTable();
/*     */       return new Integer((tableLens == null) ? 0 : tableLens.getRowCount());
/*     */     } 
/*     */     return super.get(paramString, paramScriptable);
/*     */   }
/*     */   
/*     */   public Object get(int paramInt, Scriptable paramScriptable) {
/*     */     TableLens tableLens = getTable();
/*     */     if (tableLens != null && 0 <= paramInt && paramInt < tableLens.getRowCount()) {
/*     */       TableRow tableRow = (paramInt < this.rows.size()) ? (TableRow)this.rows.elementAt(paramInt) : null;
/*     */       if (tableRow == null) {
/*     */         if (this.rows.size() < paramInt + 1)
/*     */           this.rows.setSize(paramInt + 1); 
/*     */         this.rows.setElementAt(tableRow = new TableRow(getTable(), paramInt), paramInt);
/*     */       } 
/*     */       return tableRow;
/*     */     } 
/*     */     return Undefined.instance;
/*     */   }
/*     */   
/*     */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
/*     */     if (!paramString.equals("length"))
/*     */       super.put(paramString, paramScriptable, paramObject); 
/*     */   }
/*     */   
/*     */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {}
/*     */   
/*     */   public Object getDefaultValue(Class paramClass) {
/*     */     if (paramClass == ScriptRuntime.BooleanClass)
/*     */       return Boolean.TRUE; 
/*     */     if (paramClass == ScriptRuntime.NumberClass)
/*     */       return ScriptRuntime.NaNobj; 
/*     */     return this;
/*     */   }
/*     */   
/*     */   public Object[] getIds() {
/*     */     TableLens tableLens = getTable();
/*     */     boolean bool = (tableLens == null) ? 0 : tableLens.getRowCount();
/*     */     Object[] arrayOfObject = new Object[bool];
/*     */     byte b = bool;
/*     */     while (--b >= 0)
/*     */       arrayOfObject[b] = new Integer(b); 
/*     */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   public boolean hasInstance(Scriptable paramScriptable) { return false; }
/*     */   
/*     */   public Scriptable getPrototype() {
/*     */     if (this.prototype == null)
/*     */       this.prototype = ScriptableObject.getClassPrototype(getParentScope(), "Array"); 
/*     */     return this.prototype;
/*     */   }
/*     */   
/*     */   protected TableLens getTable() {
/*     */     if (this.table != null)
/*     */       return ((TableElement)this.table.getElement()).getTable(); 
/*     */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\TableArray.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */