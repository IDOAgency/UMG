package inetsoft.report.script;

import inetsoft.uql.VariableTable;
import java.util.Enumeration;
import java.util.Vector;
import org.mozilla.javascript.Scriptable;

public class VariableScriptable implements Scriptable {
  private Scriptable parent;
  
  private Scriptable prototype;
  
  private VariableTable vars;
  
  public VariableScriptable(VariableTable paramVariableTable) { this.vars = paramVariableTable; }
  
  public String getClassName() { return "Variable"; }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    try {
      Object object = this.vars.get(paramString);
      if (object != null)
        return object; 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return Scriptable.NOT_FOUND;
  }
  
  public Object get(int paramInt, Scriptable paramScriptable) { return Scriptable.NOT_FOUND; }
  
  public boolean has(String paramString, Scriptable paramScriptable) {
    try {
      return (this.vars.get(paramString) != null);
    } catch (Exception exception) {
      return false;
    } 
  }
  
  public boolean has(int paramInt, Scriptable paramScriptable) { return false; }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) { this.vars.put(paramString, ScriptEngine.unwrap(paramObject)); }
  
  public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {}
  
  public void delete(String paramString) { this.vars.remove(paramString); }
  
  public void delete(int paramInt) {}
  
  public Scriptable getPrototype() { return this.prototype; }
  
  public void setPrototype(Scriptable paramScriptable) { this.prototype = paramScriptable; }
  
  public Scriptable getParentScope() { return this.parent; }
  
  public void setParentScope(Scriptable paramScriptable) { this.parent = paramScriptable; }
  
  public Object[] getIds() {
    Vector vector = new Vector();
    Enumeration enumeration = this.vars.keys();
    for (byte b = 0; enumeration.hasMoreElements(); b++)
      vector.addElement(enumeration.nextElement()); 
    Object[] arrayOfObject = new Object[vector.size()];
    vector.copyInto(arrayOfObject);
    return arrayOfObject;
  }
  
  public Object getDefaultValue(Class paramClass) { return this.vars.toString(); }
  
  public boolean hasInstance(Scriptable paramScriptable) { return false; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\VariableScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */