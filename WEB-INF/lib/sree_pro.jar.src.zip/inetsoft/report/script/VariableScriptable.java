/*     */ package inetsoft.report.script;
/*     */ 
/*     */ import inetsoft.uql.VariableTable;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariableScriptable
/*     */   implements Scriptable
/*     */ {
/*     */   private Scriptable parent;
/*     */   private Scriptable prototype;
/*     */   private VariableTable vars;
/*     */   
/*  30 */   public VariableScriptable(VariableTable paramVariableTable) { this.vars = paramVariableTable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  37 */   public String getClassName() { return "Variable"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/*     */     try {
/*  45 */       Object object = this.vars.get(paramString);
/*  46 */       if (object != null) {
/*  47 */         return object;
/*     */       }
/*     */     } catch (Exception exception) {
/*  50 */       exception.printStackTrace();
/*     */     } 
/*     */     
/*  53 */     return Scriptable.NOT_FOUND;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public Object get(int paramInt, Scriptable paramScriptable) { return Scriptable.NOT_FOUND; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean has(String paramString, Scriptable paramScriptable) {
/*     */     try {
/*  68 */       return (this.vars.get(paramString) != null);
/*  69 */     } catch (Exception exception) {
/*     */ 
/*     */       
/*  72 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public boolean has(int paramInt, Scriptable paramScriptable) { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) { this.vars.put(paramString, ScriptEngine.unwrap(paramObject)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public void delete(String paramString) { this.vars.remove(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(int paramInt) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public Scriptable getPrototype() { return this.prototype; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public void setPrototype(Scriptable paramScriptable) { this.prototype = paramScriptable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public Scriptable getParentScope() { return this.parent; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public void setParentScope(Scriptable paramScriptable) { this.parent = paramScriptable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getIds() {
/* 140 */     Vector vector = new Vector();
/* 141 */     Enumeration enumeration = this.vars.keys();
/* 142 */     for (byte b = 0; enumeration.hasMoreElements(); b++) {
/* 143 */       vector.addElement(enumeration.nextElement());
/*     */     }
/*     */     
/* 146 */     Object[] arrayOfObject = new Object[vector.size()];
/* 147 */     vector.copyInto(arrayOfObject);
/* 148 */     return arrayOfObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public Object getDefaultValue(Class paramClass) { return this.vars.toString(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   public boolean hasInstance(Scriptable paramScriptable) { return false; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\VariableScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */