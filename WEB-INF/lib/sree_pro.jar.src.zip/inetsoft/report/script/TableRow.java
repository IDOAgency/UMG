/*     */ package inetsoft.report.script;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.lens.DefaultTableLens;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableRow
/*     */   extends ScriptableObject
/*     */ {
/*     */   Scriptable prototype;
/*     */   TableLens table;
/*     */   int row;
/*     */   int length;
/*     */   
/*     */   public TableRow(TableLens paramTableLens, int paramInt) {
/*  28 */     this.table = paramTableLens;
/*  29 */     this.row = paramInt;
/*  30 */     this.length = paramTableLens.getColCount();
/*     */   }
/*     */ 
/*     */   
/*  34 */   public String getClassName() { return "TableRow"; }
/*     */ 
/*     */ 
/*     */   
/*  38 */   public boolean has(String paramString, Scriptable paramScriptable) { return (paramString.equals("length") || super.has(paramString, paramScriptable)); }
/*     */ 
/*     */ 
/*     */   
/*  42 */   public boolean has(int paramInt, Scriptable paramScriptable) { return (0 <= paramInt && paramInt < this.length); }
/*     */ 
/*     */   
/*     */   public Object get(String paramString, Scriptable paramScriptable) {
/*  46 */     if (paramString.equals("length")) {
/*  47 */       return new Integer(this.length);
/*     */     }
/*     */     
/*  50 */     return super.get(paramString, paramScriptable);
/*     */   }
/*     */   
/*     */   public Object get(int paramInt, Scriptable paramScriptable) {
/*  54 */     if (0 <= paramInt && paramInt < this.length) {
/*  55 */       return this.table.getObject(this.row, paramInt);
/*     */     }
/*     */     
/*  58 */     return Undefined.instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
/*  63 */     if (!paramString.equals("length")) {
/*  64 */       super.put(paramString, paramScriptable, paramObject);
/*     */     }
/*     */   }
/*     */   
/*     */   public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
/*  69 */     if (this.table instanceof DefaultTableLens && paramInt < this.length) {
/*  70 */       ((DefaultTableLens)this.table).setObject(this.row, paramInt, paramObject);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getDefaultValue(Class paramClass) {
/*  75 */     if (paramClass == ScriptRuntime.BooleanClass)
/*  76 */       return Boolean.TRUE; 
/*  77 */     if (paramClass == ScriptRuntime.NumberClass)
/*  78 */       return ScriptRuntime.NaNobj; 
/*  79 */     return this;
/*     */   }
/*     */   
/*     */   public Object[] getIds() {
/*  83 */     Object[] arrayOfObject = new Object[this.length];
/*  84 */     int i = this.length;
/*  85 */     while (--i >= 0)
/*  86 */       arrayOfObject[i] = new Integer(i); 
/*  87 */     return arrayOfObject;
/*     */   }
/*     */ 
/*     */   
/*  91 */   public boolean hasInstance(Scriptable paramScriptable) { return false; }
/*     */ 
/*     */   
/*     */   public Scriptable getPrototype() {
/*  95 */     if (this.prototype == null) {
/*  96 */       this.prototype = ScriptableObject.getClassPrototype(getParentScope(), "Array");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 101 */     return this.prototype;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\TableRow.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */