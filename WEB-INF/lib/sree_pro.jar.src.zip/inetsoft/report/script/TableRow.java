package inetsoft.report.script;

import inetsoft.report.TableLens;
import inetsoft.report.lens.DefaultTableLens;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Undefined;

public class TableRow extends ScriptableObject {
  Scriptable prototype;
  
  TableLens table;
  
  int row;
  
  int length;
  
  public TableRow(TableLens paramTableLens, int paramInt) {
    this.table = paramTableLens;
    this.row = paramInt;
    this.length = paramTableLens.getColCount();
  }
  
  public String getClassName() { return "TableRow"; }
  
  public boolean has(String paramString, Scriptable paramScriptable) { return (paramString.equals("length") || super.has(paramString, paramScriptable)); }
  
  public boolean has(int paramInt, Scriptable paramScriptable) { return (0 <= paramInt && paramInt < this.length); }
  
  public Object get(String paramString, Scriptable paramScriptable) {
    if (paramString.equals("length"))
      return new Integer(this.length); 
    return super.get(paramString, paramScriptable);
  }
  
  public Object get(int paramInt, Scriptable paramScriptable) {
    if (0 <= paramInt && paramInt < this.length)
      return this.table.getObject(this.row, paramInt); 
    return Undefined.instance;
  }
  
  public void put(String paramString, Scriptable paramScriptable, Object paramObject) {
    if (!paramString.equals("length"))
      super.put(paramString, paramScriptable, paramObject); 
  }
  
  public void put(int paramInt, Scriptable paramScriptable, Object paramObject) {
    if (this.table instanceof DefaultTableLens && paramInt < this.length)
      ((DefaultTableLens)this.table).setObject(this.row, paramInt, paramObject); 
  }
  
  public Object getDefaultValue(Class paramClass) {
    if (paramClass == ScriptRuntime.BooleanClass)
      return Boolean.TRUE; 
    if (paramClass == ScriptRuntime.NumberClass)
      return ScriptRuntime.NaNobj; 
    return this;
  }
  
  public Object[] getIds() {
    Object[] arrayOfObject = new Object[this.length];
    int i = this.length;
    while (--i >= 0)
      arrayOfObject[i] = new Integer(i); 
    return arrayOfObject;
  }
  
  public boolean hasInstance(Scriptable paramScriptable) { return false; }
  
  public Scriptable getPrototype() {
    if (this.prototype == null)
      this.prototype = ScriptableObject.getClassPrototype(getParentScope(), "Array"); 
    return this.prototype;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\TableRow.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */