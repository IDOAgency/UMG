/*    */ package inetsoft.report.script;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TOCScriptable
/*    */   extends ElementScriptable
/*    */ {
/* 34 */   public TOCScriptable() { addProperty("toc", "getTOC", "setTOC", inetsoft.report.TOC.class, inetsoft.report.TOCElement.class); }
/*    */   
/*    */   public String getClassName() { return "TOCElement"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\TOCScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */