package inetsoft.report.script;

public class FormScriptable extends TableScriptable {
  public String getClassName() { return "FormElement"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\FormScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */