package inetsoft.report.script;

public class HeadingScriptable extends TextScriptable {
  public HeadingScriptable() { addProperty("level", "getLevel", "setLevel", int.class, inetsoft.report.HeadingElement.class); }
  
  public String getClassName() { return "HeadingElement"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\script\HeadingScriptable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */