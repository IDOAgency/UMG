package inetsoft.report;

import java.io.Serializable;

public interface TextLens extends Serializable, Cloneable {
  String getText();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\TextLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */