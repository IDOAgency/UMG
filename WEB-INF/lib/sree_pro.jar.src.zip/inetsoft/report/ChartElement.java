package inetsoft.report;

public interface ChartElement extends PainterElement {
  ChartLens getChart();
  
  void setChart(ChartLens paramChartLens);
  
  ChartDescriptor getChartDescriptor();
  
  void setChartDescriptor(ChartDescriptor paramChartDescriptor);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\ChartElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */