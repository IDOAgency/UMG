package inetsoft.report;

import java.awt.Insets;

public interface PainterElement extends ReportElement {
  Painter getPainter();
  
  void setPainter(Painter paramPainter);
  
  Insets getMargin();
  
  void setMargin(Insets paramInsets);
  
  void setSize(Size paramSize);
  
  Size getSize();
  
  void setWrapping(int paramInt);
  
  int getWrapping();
  
  void setLayout(int paramInt);
  
  int getLayout();
  
  Position getAnchor();
  
  void setAnchor(Position paramPosition);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\PainterElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */