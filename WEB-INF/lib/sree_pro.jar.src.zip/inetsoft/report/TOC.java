/*     */ package inetsoft.report;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TOC
/*     */   implements Serializable
/*     */ {
/*  38 */   public static void setBaseFont(Font paramFont) { defFn = paramFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static Font getBaseFont() { return defFn; }
/*     */ 
/*     */   
/*  49 */   private static Font defFn = new Font("Serif", 0, 10);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final TOC DEFAULT = new Default();
/*     */ 
/*     */ 
/*     */   
/*  58 */   public static final TOC CLASSIC = new Classic();
/*     */ 
/*     */ 
/*     */   
/*  62 */   public static final TOC DISTINCTIVE = new Distinctive();
/*     */ 
/*     */ 
/*     */   
/*  66 */   public static final TOC FANCY = new Fancy();
/*     */ 
/*     */ 
/*     */   
/*  70 */   public static final TOC MODERN = new Modern();
/*     */ 
/*     */ 
/*     */   
/*  74 */   public static final TOC FORMAL = new Formal();
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final TOC SIMPLE = new Simple();
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Default
/*     */     extends TOC
/*     */   {
/*  85 */     public double getIndent(int param1Int) { return (param1Int - 1) * 0.1D; }
/*     */ 
/*     */ 
/*     */     
/*  89 */     public int getLeader(int param1Int) { return 4113; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Classic
/*     */     extends TOC
/*     */   {
/*  98 */     public double getIndent(int param1Int) { return (param1Int > 2) ? ((param1Int - 2) * 0.1D) : 0.0D; }
/*     */ 
/*     */ 
/*     */     
/* 102 */     public Font getFont(int param1Int) { return new Font(defFn.getName(), (param1Int < 3) ? 1 : 0, (param1Int == 1) ? (defFn.getSize() + 2) : defFn.getSize()); }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Distinctive
/*     */     extends TOC
/*     */   {
/* 112 */     public double getIndent(int param1Int) { return (param1Int - 1) * 0.1D; }
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int) {
/* 116 */       switch (param1Int) {
/*     */         case 1:
/* 118 */           return new Font(defFn.getName(), 3, defFn.getSize() + 2);
/*     */         
/*     */         case 2:
/* 121 */           return new Font(defFn.getName(), 1, defFn.getSize() + 1);
/*     */       } 
/*     */       
/* 124 */       return defFn;
/*     */     }
/*     */ 
/*     */     
/* 128 */     public int getLeader(int param1Int) { return 4097; }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Fancy
/*     */     extends TOC
/*     */   {
/*     */     public Font getFont(int param1Int) {
/* 137 */       switch (param1Int) {
/*     */         case 1:
/* 139 */           return new Font(defFn.getName(), 1, defFn.getSize() + 2);
/*     */         
/*     */         case 2:
/* 142 */           return new Font(defFn.getName(), 1, defFn.getSize() + 1);
/*     */       } 
/*     */       
/* 145 */       return defFn;
/*     */     }
/*     */ 
/*     */     
/* 149 */     public int getSeparator(int param1Int) { return (param1Int == 1) ? 4097 : 0; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Modern
/*     */     extends TOC
/*     */   {
/* 158 */     public int getAlignment(int param1Int) { return 2; }
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int) {
/* 162 */       switch (param1Int) {
/*     */         case 1:
/* 164 */           return new Font(defFn.getName(), 2, defFn.getSize() + 2);
/*     */         
/*     */         case 2:
/* 167 */           return new Font(defFn.getName(), 2, defFn.getSize() + 1);
/*     */       } 
/*     */       
/* 170 */       return defFn;
/*     */     }
/*     */ 
/*     */     
/* 174 */     public int getSeparator(int param1Int) { return (param1Int == 1) ? 8195 : 0; }
/*     */ 
/*     */ 
/*     */     
/* 178 */     public boolean isPageNumberRight() { return false; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Formal
/*     */     extends TOC
/*     */   {
/* 187 */     public double getIndent(int param1Int) { return (param1Int - 1) * 0.1D; }
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int) {
/* 191 */       switch (param1Int) {
/*     */         case 1:
/* 193 */           return new Font(defFn.getName(), 1, defFn.getSize() + 2);
/*     */         
/*     */         case 2:
/* 196 */           return new Font(defFn.getName(), 1, defFn.getSize() + 1);
/*     */       } 
/*     */       
/* 199 */       return defFn;
/*     */     }
/*     */ 
/*     */     
/* 203 */     public int getLeader(int param1Int) { return 4113; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Simple
/*     */     extends TOC
/*     */   {
/* 212 */     public double getIndent(int param1Int) { return (param1Int - 1) * 0.1D; }
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int) {
/* 216 */       switch (param1Int) {
/*     */         case 1:
/* 218 */           return new Font(defFn.getName(), 1, defFn.getSize() + 2);
/*     */         
/*     */         case 2:
/* 221 */           return new Font(defFn.getName(), 2, defFn.getSize() + 1);
/*     */       } 
/*     */       
/* 224 */       return defFn;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 234 */   public double getIndent(int paramInt) { return 0.0D; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 243 */   public int getAlignment(int paramInt) { return 1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 252 */   public Font getFont(int paramInt) { return defFn; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 263 */   public int getSeparator(int paramInt) { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 273 */   public int getLeader(int paramInt) { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 281 */   public boolean isPageNumberRight() { return true; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\TOC.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */