package inetsoft.report;

import java.awt.Font;
import java.io.Serializable;

public abstract class TOC implements Serializable {
  public static void setBaseFont(Font paramFont) { defFn = paramFont; }
  
  public static Font getBaseFont() { return defFn; }
  
  private static Font defFn = new Font("Serif", 0, 10);
  
  public static final TOC DEFAULT = new Default();
  
  public static final TOC CLASSIC = new Classic();
  
  public static final TOC DISTINCTIVE = new Distinctive();
  
  public static final TOC FANCY = new Fancy();
  
  public static final TOC MODERN = new Modern();
  
  public static final TOC FORMAL = new Formal();
  
  public static final TOC SIMPLE = new Simple();
  
  public static class Default extends TOC {
    public double getIndent(int param1Int) { return (param1Int - 1) * 0.1D; }
    
    public int getLeader(int param1Int) { return 4113; }
  }
  
  public static class Classic extends TOC {
    public double getIndent(int param1Int) { return (param1Int > 2) ? ((param1Int - 2) * 0.1D) : 0.0D; }
    
    public Font getFont(int param1Int) { return new Font(defFn.getName(), (param1Int < 3) ? 1 : 0, (param1Int == 1) ? (defFn.getSize() + 2) : defFn.getSize()); }
  }
  
  public static class Distinctive extends TOC {
    public double getIndent(int param1Int) { return (param1Int - 1) * 0.1D; }
    
    public Font getFont(int param1Int) {
      switch (param1Int) {
        case 1:
          return new Font(defFn.getName(), 3, defFn.getSize() + 2);
        case 2:
          return new Font(defFn.getName(), 1, defFn.getSize() + 1);
      } 
      return defFn;
    }
    
    public int getLeader(int param1Int) { return 4097; }
  }
  
  public static class Fancy extends TOC {
    public Font getFont(int param1Int) {
      switch (param1Int) {
        case 1:
          return new Font(defFn.getName(), 1, defFn.getSize() + 2);
        case 2:
          return new Font(defFn.getName(), 1, defFn.getSize() + 1);
      } 
      return defFn;
    }
    
    public int getSeparator(int param1Int) { return (param1Int == 1) ? 4097 : 0; }
  }
  
  public static class Modern extends TOC {
    public int getAlignment(int param1Int) { return 2; }
    
    public Font getFont(int param1Int) {
      switch (param1Int) {
        case 1:
          return new Font(defFn.getName(), 2, defFn.getSize() + 2);
        case 2:
          return new Font(defFn.getName(), 2, defFn.getSize() + 1);
      } 
      return defFn;
    }
    
    public int getSeparator(int param1Int) { return (param1Int == 1) ? 8195 : 0; }
    
    public boolean isPageNumberRight() { return false; }
  }
  
  public static class Formal extends TOC {
    public double getIndent(int param1Int) { return (param1Int - 1) * 0.1D; }
    
    public Font getFont(int param1Int) {
      switch (param1Int) {
        case 1:
          return new Font(defFn.getName(), 1, defFn.getSize() + 2);
        case 2:
          return new Font(defFn.getName(), 1, defFn.getSize() + 1);
      } 
      return defFn;
    }
    
    public int getLeader(int param1Int) { return 4113; }
  }
  
  public static class Simple extends TOC {
    public double getIndent(int param1Int) { return (param1Int - 1) * 0.1D; }
    
    public Font getFont(int param1Int) {
      switch (param1Int) {
        case 1:
          return new Font(defFn.getName(), 1, defFn.getSize() + 2);
        case 2:
          return new Font(defFn.getName(), 2, defFn.getSize() + 1);
      } 
      return defFn;
    }
  }
  
  public double getIndent(int paramInt) { return 0.0D; }
  
  public int getAlignment(int paramInt) { return 1; }
  
  public Font getFont(int paramInt) { return defFn; }
  
  public int getSeparator(int paramInt) { return 0; }
  
  public int getLeader(int paramInt) { return 0; }
  
  public boolean isPageNumberRight() { return true; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\TOC.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */