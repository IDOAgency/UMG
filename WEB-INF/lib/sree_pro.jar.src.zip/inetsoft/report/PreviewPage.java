package inetsoft.report;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Point;
import java.awt.PrintJob;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PreviewPage extends Container {
  private StylePage page;
  
  private double winch;
  
  private double hinch;
  
  private Dimension pgsize;
  
  private boolean drawBorder;
  
  private double percent;
  
  private int resolution;
  
  private int index;
  
  public PreviewPage(double paramDouble1, double paramDouble2) { this(paramDouble1, paramDouble2, 72); }
  
  public PreviewPage(PrintJob paramPrintJob) { this((paramPrintJob.getPageDimension()).width / 72.0D, (paramPrintJob.getPageDimension()).height / 72.0D, 72); }
  
  public PreviewPage(double paramDouble1, double paramDouble2, int paramInt) {
    this.drawBorder = true;
    this.percent = 1.0D;
    this.index = 0;
    this.winch = paramDouble1;
    this.hinch = paramDouble2;
    this.resolution = paramInt;
    setBackground(Color.white);
    setForeground(Color.black);
    this.pgsize = new Dimension((int)(paramDouble1 * paramInt), (int)(paramDouble2 * paramInt));
    this.page = new StylePage(this.pgsize, paramInt);
    addMouseListener(new MouseAdapter(this) {
          private final PreviewPage this$0;
          
          public void mousePressed(MouseEvent param1MouseEvent) { this.this$0.requestFocus(); }
        });
  }
  
  public Size getPageSizeInch() { return new Size((float)this.winch, (float)this.hinch); }
  
  public Dimension getPageSize() { return this.pgsize; }
  
  public void setPageSize(Dimension paramDimension) {
    if (paramDimension.width != this.pgsize.width || paramDimension.height != this.pgsize.height) {
      this.pgsize = paramDimension;
      this.winch = this.pgsize.width / this.resolution;
      this.hinch = this.pgsize.height / this.resolution;
    } 
  }
  
  public int getResolution() { return this.resolution; }
  
  public Dimension getPreferredSize() {
    Insets insets = getInsets();
    return new Dimension((int)((this.pgsize.width + insets.left + insets.right) * this.percent), (int)((this.pgsize.height + insets.top + insets.bottom) * this.percent));
  }
  
  public void setZoom(double paramDouble) {
    this.percent = paramDouble;
    invalidate();
  }
  
  public double getZoom() { return this.percent; }
  
  public StylePage getStylePage() { return this.page; }
  
  public void setStylePage(StylePage paramStylePage) {
    this.page = paramStylePage;
    if (paramStylePage != null)
      setPageSize(paramStylePage.getPageDimension()); 
  }
  
  public void setDrawBorder(boolean paramBoolean) { this.drawBorder = paramBoolean; }
  
  public boolean isDrawBorder() { return this.drawBorder; }
  
  public int getPageIndex() { return this.index; }
  
  public void setPageIndex(int paramInt) { this.index = paramInt; }
  
  public void paintBG(Graphics paramGraphics) {
    Insets insets = getInsets();
    paramGraphics.setColor(Color.white);
    paramGraphics.fillRect(-insets.left, -insets.top, this.pgsize.width + insets.left + insets.right, this.pgsize.height + insets.top + insets.bottom);
    if (insets.left > 0) {
      paramGraphics.setColor(Color.lightGray);
      Common.drawLine(paramGraphics, 0.0F, 0.0F, 0.0F, this.pgsize.height, 4145);
    } 
  }
  
  public void paintContainer(Graphics paramGraphics) { super.paint(paramGraphics); }
  
  public void paint(Graphics paramGraphics) { paintPage(paramGraphics, this); }
  
  public static void paintPage(Graphics paramGraphics, PreviewPage paramPreviewPage) {
    Dimension dimension1 = paramPreviewPage.getSize();
    Dimension dimension2 = paramPreviewPage.getPageSize();
    Insets insets = paramPreviewPage.getInsets();
    Dimension dimension3 = new Dimension(dimension2.width + insets.left + insets.right, dimension2.height + insets.top + insets.bottom);
    if (bSize.width != dimension3.width || bSize.height != dimension3.height) {
      buffer = null;
      buffer = paramPreviewPage.createImage(dimension3.width, dimension3.height);
      bSize = dimension3;
    } 
    Graphics graphics = buffer.getGraphics();
    graphics.translate(insets.left, insets.top);
    paramPreviewPage.paintBG(graphics);
    graphics.setColor(Color.black);
    if (paramPreviewPage.drawBorder)
      graphics.drawRect(-insets.left, -insets.top, bSize.width - 1, bSize.height - 1); 
    Point point = new Point((int)((StyleSheet.getPrinterMargin()).left * paramPreviewPage.getResolution()), (int)((StyleSheet.getPrinterMargin()).top * paramPreviewPage.getResolution()));
    graphics.translate(point.x, point.y);
    if (paramPreviewPage.getStylePage() != null)
      paramPreviewPage.getStylePage().print(graphics); 
    graphics.setColor(Color.black);
    graphics.translate(-insets.left, -insets.top);
    paramPreviewPage.paintContainer(graphics);
    graphics.dispose();
    paramGraphics.drawImage(buffer, 0, 0, dimension1.width, dimension1.height, paramPreviewPage);
  }
  
  public void update(Graphics paramGraphics) { paint(paramGraphics); }
  
  public Insets getInsets() { return new Insets(0, 0, 0, 0); }
  
  public static Image buffer = null;
  
  public static Dimension bSize = new Dimension(-1, -1);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\PreviewPage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */