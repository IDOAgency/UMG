/*     */ package inetsoft.report.pdf;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.util.BitSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TTFontInfo
/*     */   extends FontInfo
/*     */ {
/*     */   static final int TAG_CMAP = 1668112752;
/*     */   static final int TAG_HEAD = 1751474532;
/*     */   static final int TAG_NAME = 1851878757;
/*     */   static final int TAG_GLYF = 1735162214;
/*     */   static final int TAG_MAXP = 1835104368;
/*     */   static final int TAG_PREP = 1886545264;
/*     */   static final int TAG_HMTX = 1752003704;
/*     */   static final int TAG_KERN = 1801810542;
/*     */   static final int TAG_HDMX = 1751412088;
/*     */   static final int TAG_LOCA = 1819239265;
/*     */   static final int TAG_POST = 1886352244;
/*     */   static final int TAG_OS2 = 1330851634;
/*     */   static final int TAG_CVT = 1668707360;
/*     */   static final int TAG_GASP = 1734439792;
/*     */   static final int TAG_VDMX = 1447316824;
/*     */   static final int TAG_VMTX = 1986884728;
/*     */   static final int TAG_VHEA = 1986553185;
/*     */   static final int TAG_HHEA = 1751672161;
/*     */   static final int TAG_TYP1 = 1954115633;
/*     */   static final int TAG_BSLN = 1651731566;
/*     */   static final int TAG_GSUB = 1196643650;
/*     */   static final int TAG_DSIG = 1146308935;
/*     */   static final int TAG_FPGM = 1718642541;
/*     */   static final int TAG_FVAR = 1719034226;
/*     */   static final int TAG_GVAR = 1735811442;
/*     */   static final int TAG_CFF = 1128678944;
/*     */   static final int TAG_MMSD = 1296913220;
/*     */   static final int TAG_MMFX = 1296909912;
/*     */   static final int TAG_BASE = 1111577413;
/*     */   static final int TAG_GDEF = 1195656518;
/*     */   static final int TAG_GPOS = 1196445523;
/*     */   static final int TAG_JSTF = 1246975046;
/*     */   static final int TAG_EBDT = 1161970772;
/*     */   static final int TAG_EBLC = 1161972803;
/*     */   static final int TAG_EBSC = 1161974595;
/*     */   static final int TAG_LTSH = 1280594760;
/*     */   static final int TAG_PCLT = 1346587732;
/*     */   static final int TAG_ACNT = 1633906292;
/*     */   static final int TAG_AVAR = 1635148146;
/*     */   static final int TAG_BDAT = 1650745716;
/*     */   static final int TAG_BLOC = 1651273571;
/*     */   static final int TAG_CVAR = 1668702578;
/*     */   static final int TAG_FEAT = 1717920116;
/*     */   static final int TAG_FDSC = 1717859171;
/*     */   static final int TAG_FMTX = 1718449272;
/*     */   static final int TAG_JUST = 1786082164;
/*     */   static final int TAG_LCAR = 1818452338;
/*     */   static final int TAG_MORT = 1836020340;
/*     */   static final int TAG_OPBD = 1836020340;
/*     */   static final int TAG_PROP = 1886547824;
/*     */   static final int TAG_TRAK = 1953653099;
/*     */   
/*  84 */   public File getFontFile() { return this.file; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public String getPSName() { return this.psName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public int getFirstChar() { return this.firstChar; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public int getLastChar() { return this.lastChar; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public boolean isCJKFont() { return (this.cjk != null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public CMap getCMap() { return this.cjkmap; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public boolean isCFFont() { return (findTagOffLen(1128678944) != null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public int[] getCIDWidths() { return this.cidwidths; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse(File paramFile) throws IOException {
/* 140 */     this.file = paramFile;
/* 141 */     RandomAccessFile randomAccessFile = new RandomAccessFile(paramFile, "r");
/*     */     
/* 143 */     boolean bool = false;
/* 144 */     byte[] arrayOfByte1 = new byte[4096];
/* 145 */     byte[] arrayOfByte2 = new byte[8192];
/* 146 */     int[] arrayOfInt = null;
/* 147 */     int i = 16;
/* 148 */     int j = 1;
/*     */     
/* 150 */     randomAccessFile.read(arrayOfByte1, 0, 12);
/* 151 */     int k = getSHORT(arrayOfByte1, 4);
/* 152 */     this.tagofflen = new int[k][4];
/*     */     
/* 154 */     bool += true;
/* 155 */     for (byte b1 = 0; b1 < k; b1++) {
/* 156 */       randomAccessFile.seek(bool);
/* 157 */       randomAccessFile.read(arrayOfByte1, 0, 16);
/* 158 */       bool += true;
/*     */       
/* 160 */       int m = getLONG(arrayOfByte1, 0);
/* 161 */       int n = getLONG(arrayOfByte1, 4);
/* 162 */       int i1 = getLONG(arrayOfByte1, 8);
/* 163 */       int i2 = getLONG(arrayOfByte1, 12);
/*     */       
/* 165 */       this.tagofflen[b1][0] = m;
/* 166 */       this.tagofflen[b1][1] = i1;
/* 167 */       this.tagofflen[b1][2] = i2;
/* 168 */       this.tagofflen[b1][3] = n;
/*     */       
/* 170 */       randomAccessFile.seek(i1);
/*     */       
/* 172 */       if (arrayOfByte2.length < i2) {
/* 173 */         arrayOfByte2 = new byte[i2];
/*     */       }
/*     */       
/* 176 */       if (m == 1751474532) {
/* 177 */         randomAccessFile.read(arrayOfByte2, 0, i2);
/* 178 */         i = getSHORT(arrayOfByte2, 18);
/* 179 */         this.bbox = new Rectangle(getSHORT(arrayOfByte2, 36), getSHORT(arrayOfByte2, 38), getSHORT(arrayOfByte2, 40), getSHORT(arrayOfByte2, 42));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 188 */         this.indexToLocFormat = getSHORT(arrayOfByte2, 50);
/*     */       }
/* 190 */       else if (m == 1751672161) {
/* 191 */         randomAccessFile.read(arrayOfByte2, 0, i2);
/* 192 */         this.ascender = getSHORT(arrayOfByte2, 4);
/* 193 */         this.descender = getSHORT(arrayOfByte2, 6);
/* 194 */         this.advance = getSHORT(arrayOfByte2, 10);
/* 195 */         j = getSHORT(arrayOfByte2, 34);
/*     */ 
/*     */         
/* 198 */         if (this.capHeight == 0) {
/* 199 */           this.capHeight = this.ascender;
/*     */         }
/*     */       }
/* 202 */       else if (m == 1886352244) {
/* 203 */         randomAccessFile.read(arrayOfByte2, 0, i2);
/* 204 */         this.italicAngle = getFIXED(arrayOfByte2, 4);
/* 205 */         this.fixedPitch = (getLONG(arrayOfByte2, 12) != 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 216 */       else if (m == 1346587732) {
/* 217 */         randomAccessFile.read(arrayOfByte2, 0, i2);
/* 218 */         this.capHeight = getSHORT(arrayOfByte2, 16);
/*     */       }
/* 220 */       else if (m == 1835104368) {
/* 221 */         randomAccessFile.read(arrayOfByte2, 0, i2);
/* 222 */         this.numGlyphs = getSHORT(arrayOfByte2, 4);
/*     */       }
/* 224 */       else if (m == 1851878757) {
/* 225 */         randomAccessFile.read(arrayOfByte2, 0, i2);
/*     */         
/* 227 */         int i3 = getSHORT(arrayOfByte2, 2);
/* 228 */         int i4 = getSHORT(arrayOfByte2, 4);
/*     */         
/* 230 */         byte b3 = 6;
/* 231 */         for (byte b4 = 0; b4 < i3; b4++, b3 += 12) {
/* 232 */           int i5 = getSHORT(arrayOfByte2, b3 + 6);
/* 233 */           int i6 = getSHORT(arrayOfByte2, b3 + 8);
/* 234 */           int i7 = getSHORT(arrayOfByte2, b3 + 10);
/* 235 */           String str = new String(arrayOfByte2, i4 + i7, i6, "UnicodeBig");
/*     */ 
/*     */           
/* 238 */           switch (i5) {
/*     */             case 1:
/* 240 */               this.familyName = str;
/* 241 */               this.fontName = str;
/*     */               break;
/*     */             case 2:
/* 244 */               this.styleName = str;
/*     */               break;
/*     */             case 4:
/* 247 */               this.fullName = str;
/*     */               break;
/*     */             case 6:
/* 250 */               this.psName = str;
/*     */               break;
/*     */           } 
/*     */         
/*     */         } 
/* 255 */       } else if (m == 1668112752) {
/* 256 */         randomAccessFile.read(arrayOfByte2, 0, i2);
/* 257 */         int i3 = getSHORT(arrayOfByte2, 2);
/*     */         
/* 259 */         for (byte b = 0; b < i3; b++) {
/* 260 */           int i9; byte b3; int i8, arrayOfInt4[], arrayOfInt3[], arrayOfInt2[], arrayOfInt1[], i7, i6, i4 = getLONG(arrayOfByte2, 4 + b * 8 + 4);
/* 261 */           int i5 = getUSHORT(arrayOfByte2, i4);
/*     */           
/* 263 */           switch (i5) {
/*     */             case 0:
/* 265 */               arrayOfInt = new int[256];
/* 266 */               for (i6 = 0; i6 < arrayOfInt.length; i6++) {
/* 267 */                 arrayOfInt[i6] = arrayOfByte2[i4 + 6 + i6] & 0xFF;
/*     */               }
/*     */               break;
/*     */             
/*     */             case 4:
/* 272 */               i7 = getUSHORT(arrayOfByte2, i4 + 6) / 2;
/* 273 */               arrayOfInt1 = new int[i7];
/* 274 */               arrayOfInt2 = new int[i7];
/* 275 */               arrayOfInt3 = new int[i7];
/* 276 */               arrayOfInt4 = new int[i7];
/* 277 */               i8 = 16 + 2 * i7 * 4;
/*     */               
/* 279 */               for (b3 = 0; b3 < i7; b3++) {
/* 280 */                 arrayOfInt1[b3] = getUSHORT(arrayOfByte2, i4 + 14 + b3 * 2);
/* 281 */                 arrayOfInt2[b3] = getUSHORT(arrayOfByte2, i4 + 16 + i7 * 2 + b3 * 2);
/* 282 */                 arrayOfInt3[b3] = getSHORT(arrayOfByte2, i4 + 16 + i7 * 4 + b3 * 2);
/* 283 */                 arrayOfInt4[b3] = getUSHORT(arrayOfByte2, i4 + 16 + i7 * 6 + b3 * 2);
/*     */               } 
/*     */               
/* 286 */               arrayOfInt = new int[arrayOfInt1[arrayOfInt1.length - 2] + 1];
/* 287 */               for (i9 = 0; i9 < arrayOfInt.length; i9++) {
/* 288 */                 for (byte b4 = 0; b4 < arrayOfInt1.length; b4++) {
/* 289 */                   if (i9 <= arrayOfInt1[b4] && 
/* 290 */                     i9 >= arrayOfInt2[b4]) {
/* 291 */                     if (arrayOfInt4[b4] == 0) {
/* 292 */                       arrayOfInt[i9] = i9 + arrayOfInt3[b4];
/*     */                     } else {
/*     */                       
/* 295 */                       arrayOfInt[i9] = getUSHORT(arrayOfByte2, arrayOfInt4[b4] + (i9 - arrayOfInt2[b4]) * 2 + i4 + 16 + i7 * 6 + b4 * 2);
/*     */                     } 
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */               break;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         } 
/* 308 */       } else if (m == 1752003704) {
/* 309 */         randomAccessFile.read(arrayOfByte2, 0, i2);
/* 310 */         this.widths = new int[Math.max(j, 256)];
/*     */         
/*     */         byte b3;
/* 313 */         for (b3 = 0; b3 < j; b3++) {
/* 314 */           this.widths[b3] = getSHORT(arrayOfByte2, b3 * 4);
/*     */         }
/*     */         
/* 317 */         for (byte b4 = b3; b4 < this.widths.length; b4++) {
/* 318 */           this.widths[b4] = this.widths[b3 - 1];
/*     */         }
/*     */       }
/* 321 */       else if (m == 1668707360) {
/*     */       
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 332 */     this.ascender = this.ascender * 1000 / i;
/* 333 */     this.descender = this.descender * 1000 / i;
/* 334 */     this.advance = this.advance * 1000 / i;
/* 335 */     this.capHeight = this.capHeight * 1000 / i;
/* 336 */     this.bbox.x = this.bbox.x * 1000 / i;
/* 337 */     this.bbox.y = this.bbox.y * 1000 / i;
/* 338 */     this.bbox.width = this.bbox.width * 1000 / i;
/* 339 */     this.bbox.height = this.bbox.height * 1000 / i;
/* 340 */     this.cjk = FontManager.getFontManager().getCJKInfo(getFullName());
/*     */ 
/*     */     
/* 343 */     for (byte b2 = 0; b2 < this.widths.length; b2++) {
/* 344 */       this.widths[b2] = this.widths[b2] * 1000 / i;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 349 */     if (isCJKFont()) {
/* 350 */       this.cidwidths = this.widths;
/*     */       
/*     */       try {
/* 353 */         this.cjkmap = new CMap(this.cjk[1]);
/*     */         
/* 355 */         int[] arrayOfInt1 = new int[this.cjkmap.getMax() + 1];
/*     */         
/* 357 */         for (byte b = 0; b < arrayOfInt1.length; b++) {
/* 358 */           int m = this.cjkmap.map((char)b);
/* 359 */           arrayOfInt1[b] = (m >= 0 && m < this.widths.length) ? this.widths[m] : this.widths[0];
/*     */         } 
/*     */ 
/*     */         
/* 363 */         this.widths = arrayOfInt1;
/*     */       } catch (Exception exception) {
/* 365 */         exception.printStackTrace();
/*     */       }
/*     */     
/* 368 */     } else if (arrayOfInt != null) {
/*     */       
/* 370 */       int[] arrayOfInt1 = new int[256];
/*     */       
/* 372 */       for (byte b = 0; b < arrayOfInt1.length; b++) {
/* 373 */         arrayOfInt1[b] = (b < arrayOfInt.length && arrayOfInt[b] < this.widths.length) ? this.widths[arrayOfInt[b]] : this.widths[0];
/*     */       }
/*     */ 
/*     */       
/* 377 */       this.widths = arrayOfInt1;
/*     */     } else {
/*     */       
/* 380 */       System.err.println("No format 0 table (cmap): " + paramFile);
/*     */     } 
/*     */     
/* 383 */     randomAccessFile.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getFontData() throws IOException {
/* 390 */     File file1 = getFontFile();
/* 391 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream((int)file1.length());
/*     */     
/* 393 */     FileInputStream fileInputStream = new FileInputStream(file1);
/* 394 */     byte[] arrayOfByte = new byte[4096];
/*     */     
/*     */     int i;
/*     */     
/* 398 */     while ((i = fileInputStream.read(arrayOfByte)) > 0) {
/* 399 */       byteArrayOutputStream.write(arrayOfByte, 0, i);
/*     */     }
/* 401 */     fileInputStream.close();
/*     */     
/* 403 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getFontData(BitSet paramBitSet) throws IOException {
/* 410 */     RandomAccessFile randomAccessFile = new RandomAccessFile(this.file, "r");
/*     */ 
/*     */ 
/*     */     
/* 414 */     if (findTagOffLen(1819239265) != null) {
/* 415 */       ByteArrayOutputStream byteArrayOutputStream1 = new ByteArrayOutputStream();
/* 416 */       ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
/* 417 */       DataOutputStream dataOutputStream1 = new DataOutputStream(byteArrayOutputStream1);
/*     */       
/* 419 */       int[] arrayOfInt1 = findTagOffLen(1819239265);
/* 420 */       int[] arrayOfInt2 = findTagOffLen(1735162214);
/*     */       
/* 422 */       if (arrayOfInt2 == null) {
/* 423 */         throw new IOException("GLYF table missing: " + this.file);
/*     */       }
/*     */       
/* 426 */       randomAccessFile.seek(arrayOfInt1[1]);
/* 427 */       int i = (this.indexToLocFormat == 0) ? randomAccessFile.readUnsignedShort() : randomAccessFile.readInt();
/*     */ 
/*     */ 
/*     */       
/* 431 */       for (byte b1 = 0; b1 < this.numGlyphs; b1++) {
/* 432 */         int j = (this.indexToLocFormat == 0) ? randomAccessFile.readUnsignedShort() : randomAccessFile.readInt();
/*     */ 
/*     */         
/* 435 */         if (paramBitSet.get(b1) && j > i) {
/* 436 */           long l = randomAccessFile.getFilePointer();
/* 437 */           randomAccessFile.seek((arrayOfInt2[1] + i));
/* 438 */           byte[] arrayOfByte = new byte[j - i];
/* 439 */           randomAccessFile.readFully(arrayOfByte);
/* 440 */           byteArrayOutputStream2.write(arrayOfByte);
/* 441 */           randomAccessFile.seek(l);
/*     */         
/*     */         }
/* 444 */         else if (this.indexToLocFormat == 0) {
/* 445 */           dataOutputStream1.writeShort(arrayOfInt2[1] + byteArrayOutputStream2.size());
/*     */         } else {
/*     */           
/* 448 */           dataOutputStream1.writeInt(arrayOfInt2[1] + byteArrayOutputStream2.size());
/*     */         } 
/*     */ 
/*     */         
/* 452 */         i = j;
/*     */       } 
/*     */ 
/*     */       
/* 456 */       if (this.indexToLocFormat == 0) {
/* 457 */         dataOutputStream1.writeShort(arrayOfInt2[1] + byteArrayOutputStream2.size());
/*     */       } else {
/*     */         
/* 460 */         dataOutputStream1.writeInt(arrayOfInt2[1] + byteArrayOutputStream2.size());
/*     */       } 
/*     */       
/* 463 */       dataOutputStream1.flush();
/* 464 */       pad4(byteArrayOutputStream1);
/* 465 */       pad4(byteArrayOutputStream2);
/*     */ 
/*     */       
/* 468 */       ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
/*     */       
/* 470 */       ByteArrayOutputStream byteArrayOutputStream4 = new ByteArrayOutputStream();
/* 471 */       DataOutputStream dataOutputStream2 = new DataOutputStream(byteArrayOutputStream4);
/*     */       
/* 473 */       copy(randomAccessFile, 0, 12, byteArrayOutputStream3);
/*     */ 
/*     */ 
/*     */       
/* 477 */       copy(randomAccessFile, 12, 16 * this.tagofflen.length, byteArrayOutputStream3);
/*     */ 
/*     */       
/* 480 */       for (byte b2 = 0; b2 < this.tagofflen.length; b2++) {
/* 481 */         long l = byteArrayOutputStream3.size();
/* 482 */         int j = 0;
/*     */         
/* 484 */         if (this.tagofflen[b2][0] == 1819239265) {
/* 485 */           j = copy(byteArrayOutputStream1, byteArrayOutputStream3);
/*     */         }
/* 487 */         else if (this.tagofflen[b2][0] == 1735162214) {
/* 488 */           j = copy(byteArrayOutputStream2, byteArrayOutputStream3);
/*     */         } else {
/*     */           
/* 491 */           copy(randomAccessFile, this.tagofflen[b2][1], this.tagofflen[b2][2], byteArrayOutputStream3);
/* 492 */           j = this.tagofflen[b2][3];
/*     */         } 
/*     */         
/* 495 */         dataOutputStream2.writeInt(this.tagofflen[b2][0]);
/* 496 */         dataOutputStream2.writeInt(j);
/* 497 */         dataOutputStream2.writeInt((int)l);
/* 498 */         dataOutputStream2.writeInt((int)(byteArrayOutputStream3.size() - l));
/*     */ 
/*     */         
/* 501 */         pad4(byteArrayOutputStream3);
/*     */       } 
/*     */       
/* 504 */       randomAccessFile.close();
/* 505 */       return byteArrayOutputStream3.toByteArray();
/*     */     } 
/* 507 */     if (findTagOffLen(1128678944) != null) {
/* 508 */       int[] arrayOfInt = findTagOffLen(1128678944);
/* 509 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 510 */       CFF.extract(randomAccessFile, arrayOfInt[1], arrayOfInt[2], byteArrayOutputStream, paramBitSet);
/* 511 */       return byteArrayOutputStream.toByteArray();
/*     */     } 
/*     */     
/* 514 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int[] findTagOffLen(int paramInt) {
/* 521 */     for (byte b = 0; b < this.tagofflen.length; b++) {
/* 522 */       if (this.tagofflen[b][0] == paramInt) {
/* 523 */         return this.tagofflen[b];
/*     */       }
/*     */     } 
/*     */     
/* 527 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void pad4(ByteArrayOutputStream paramByteArrayOutputStream) throws IOException {
/* 534 */     int i = (4 - paramByteArrayOutputStream.size() % 4) % 4;
/* 535 */     paramByteArrayOutputStream.write(new byte[i]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int copy(RandomAccessFile paramRandomAccessFile, int paramInt1, int paramInt2, OutputStream paramOutputStream) throws IOException {
/* 545 */     byte[] arrayOfByte = new byte[paramInt2];
/* 546 */     paramRandomAccessFile.seek(paramInt1);
/* 547 */     paramRandomAccessFile.readFully(arrayOfByte);
/* 548 */     paramOutputStream.write(arrayOfByte);
/* 549 */     return getChecksum(arrayOfByte);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int copy(ByteArrayOutputStream paramByteArrayOutputStream, OutputStream paramOutputStream) throws IOException {
/* 559 */     byte[] arrayOfByte = paramByteArrayOutputStream.toByteArray();
/* 560 */     paramOutputStream.write(arrayOfByte);
/* 561 */     return getChecksum(arrayOfByte);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static int getChecksum(byte[] paramArrayOfByte) {
/* 567 */     long l = 0L;
/* 568 */     for (byte b = 0; b < paramArrayOfByte.length; b += 4) {
/* 569 */       l += (getLONG(paramArrayOfByte, b) & 0xFFFFFFFFL);
/* 570 */       l &= 0xFFFFFFFFL;
/*     */     } 
/*     */     
/* 573 */     return (int)l & 0xFFFFFFFF;
/*     */   }
/*     */ 
/*     */   
/* 577 */   static int getSHORT(byte[] paramArrayOfByte, int paramInt) { return (short)getNUMBER(paramArrayOfByte, paramInt, 2); }
/*     */ 
/*     */ 
/*     */   
/* 581 */   static int getUSHORT(byte[] paramArrayOfByte, int paramInt) { return getNUMBER(paramArrayOfByte, paramInt, 2); }
/*     */ 
/*     */ 
/*     */   
/* 585 */   static int getLONG(byte[] paramArrayOfByte, int paramInt) { return getNUMBER(paramArrayOfByte, paramInt, 4); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getNUMBER(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
/* 593 */     byte b = 0;
/*     */     
/* 595 */     for (byte b1 = 0; b1 < paramInt2; b1++) {
/* 596 */       byte b2 = (paramInt1 < paramArrayOfByte.length) ? (paramArrayOfByte[paramInt1++] & 0xFF) : 0;
/* 597 */       b = b << 8 | b2;
/*     */     } 
/*     */     
/* 600 */     return b;
/*     */   }
/*     */ 
/*     */   
/* 604 */   static double getFIXED(byte[] paramArrayOfByte, int paramInt) { return getSHORT(paramArrayOfByte, paramInt) + getSHORT(paramArrayOfByte, paramInt + 2) / 255.0D; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getFontNames(File paramFile) throws IOException {
/* 611 */     RandomAccessFile randomAccessFile = new RandomAccessFile(paramFile, "r");
/* 612 */     byte[] arrayOfByte = new byte[8192];
/* 613 */     String str1 = null, str2 = null, str3 = null;
/*     */     
/* 615 */     randomAccessFile.read(arrayOfByte, 0, 12);
/* 616 */     int i = getSHORT(arrayOfByte, 4);
/*     */     
/* 618 */     for (byte b = 0; b < i; b++) {
/* 619 */       randomAccessFile.read(arrayOfByte, 0, 16);
/* 620 */       int j = getLONG(arrayOfByte, 0);
/*     */       
/* 622 */       if (j == 1851878757) {
/* 623 */         int k = getLONG(arrayOfByte, 8);
/* 624 */         int m = getLONG(arrayOfByte, 12);
/*     */         
/* 626 */         randomAccessFile.seek(k);
/* 627 */         arrayOfByte = new byte[m];
/*     */         
/* 629 */         randomAccessFile.read(arrayOfByte, 0, m);
/*     */         
/* 631 */         int n = getSHORT(arrayOfByte, 2);
/* 632 */         int i1 = getSHORT(arrayOfByte, 4);
/*     */         
/* 634 */         byte b1 = 6;
/* 635 */         for (byte b2 = 0; b2 < n; b2++, b1 += 12) {
/* 636 */           int i2 = getSHORT(arrayOfByte, b1 + 6);
/* 637 */           int i3 = getSHORT(arrayOfByte, b1 + 8);
/* 638 */           int i4 = getSHORT(arrayOfByte, b1 + 10);
/*     */ 
/*     */           
/* 641 */           if (i1 + i4 + i3 <= arrayOfByte.length) {
/*     */ 
/*     */ 
/*     */             
/* 645 */             String str = new String(arrayOfByte, i1 + i4, i3, "UnicodeBig");
/*     */ 
/*     */             
/* 648 */             if (i2 == 1) {
/* 649 */               str1 = str;
/*     */             }
/* 651 */             else if (i2 == 4) {
/* 652 */               str2 = str;
/*     */             }
/* 654 */             else if (i2 == 6) {
/* 655 */               str3 = str;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 663 */     randomAccessFile.close();
/* 664 */     return new String[] { str1, str2, str3 };
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 668 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*     */       try {
/* 670 */         TTFontInfo tTFontInfo = new TTFontInfo();
/* 671 */         tTFontInfo.parse(new File(paramArrayOfString[b]));
/*     */         
/* 673 */         System.err.println("[" + paramArrayOfString[b] + "]");
/* 674 */         System.err.println("getFontName = " + tTFontInfo.getFontName());
/* 675 */         System.err.println("getFullName = " + tTFontInfo.getFullName());
/* 676 */         System.err.println("getFamilyName = " + tTFontInfo.getFamilyName());
/* 677 */         System.err.println("getPSName = " + tTFontInfo.getPSName());
/* 678 */         System.err.println("[style name] = " + tTFontInfo.styleName);
/* 679 */         System.err.println("getWeight = " + tTFontInfo.getWeight());
/* 680 */         System.err.println("isFixedPitch = " + tTFontInfo.isFixedPitch());
/* 681 */         System.err.println("getAscent = " + tTFontInfo.getAscent());
/* 682 */         System.err.println("getDescent = " + tTFontInfo.getDescent());
/* 683 */         System.err.println("getMaxAdvance = " + tTFontInfo.getMaxAdvance());
/* 684 */         System.err.println("getItalicAngle = " + tTFontInfo.getItalicAngle());
/* 685 */         System.err.println("getFontBBox = " + tTFontInfo.getFontBBox());
/* 686 */         System.err.println("getEncoding = " + tTFontInfo.getEncoding());
/* 687 */         System.err.println("getCapHeight = " + tTFontInfo.getCapHeight());
/*     */         
/* 689 */         int[] arrayOfInt = tTFontInfo.getWidths();
/* 690 */         System.err.print("width[");
/* 691 */         for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
/* 692 */           if (b1 % 15 == 0) {
/* 693 */             System.err.print("\n" + b1 + ": ");
/*     */           }
/*     */           
/* 696 */           System.err.print(arrayOfInt[b1] + " ");
/*     */         } 
/* 698 */         System.err.println("]");
/*     */       } catch (Exception exception) {
/* 700 */         exception.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/* 705 */   String psName = null; String styleName = null;
/* 706 */   int firstChar = 32; int lastChar = 255;
/*     */   File file;
/* 708 */   String[] cjk = null;
/* 709 */   CMap cjkmap = null;
/* 710 */   int indexToLocFormat = 0;
/* 711 */   int numGlyphs = 255;
/*     */   
/* 713 */   int[][] tagofflen = null;
/* 714 */   int[] cidwidths = null;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\TTFontInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */