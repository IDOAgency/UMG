package inetsoft.report.pdf;

import java.awt.Rectangle;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.BitSet;

class TTFontInfo extends FontInfo {
  static final int TAG_CMAP = 1668112752;
  
  static final int TAG_HEAD = 1751474532;
  
  static final int TAG_NAME = 1851878757;
  
  static final int TAG_GLYF = 1735162214;
  
  static final int TAG_MAXP = 1835104368;
  
  static final int TAG_PREP = 1886545264;
  
  static final int TAG_HMTX = 1752003704;
  
  static final int TAG_KERN = 1801810542;
  
  static final int TAG_HDMX = 1751412088;
  
  static final int TAG_LOCA = 1819239265;
  
  static final int TAG_POST = 1886352244;
  
  static final int TAG_OS2 = 1330851634;
  
  static final int TAG_CVT = 1668707360;
  
  static final int TAG_GASP = 1734439792;
  
  static final int TAG_VDMX = 1447316824;
  
  static final int TAG_VMTX = 1986884728;
  
  static final int TAG_VHEA = 1986553185;
  
  static final int TAG_HHEA = 1751672161;
  
  static final int TAG_TYP1 = 1954115633;
  
  static final int TAG_BSLN = 1651731566;
  
  static final int TAG_GSUB = 1196643650;
  
  static final int TAG_DSIG = 1146308935;
  
  static final int TAG_FPGM = 1718642541;
  
  static final int TAG_FVAR = 1719034226;
  
  static final int TAG_GVAR = 1735811442;
  
  static final int TAG_CFF = 1128678944;
  
  static final int TAG_MMSD = 1296913220;
  
  static final int TAG_MMFX = 1296909912;
  
  static final int TAG_BASE = 1111577413;
  
  static final int TAG_GDEF = 1195656518;
  
  static final int TAG_GPOS = 1196445523;
  
  static final int TAG_JSTF = 1246975046;
  
  static final int TAG_EBDT = 1161970772;
  
  static final int TAG_EBLC = 1161972803;
  
  static final int TAG_EBSC = 1161974595;
  
  static final int TAG_LTSH = 1280594760;
  
  static final int TAG_PCLT = 1346587732;
  
  static final int TAG_ACNT = 1633906292;
  
  static final int TAG_AVAR = 1635148146;
  
  static final int TAG_BDAT = 1650745716;
  
  static final int TAG_BLOC = 1651273571;
  
  static final int TAG_CVAR = 1668702578;
  
  static final int TAG_FEAT = 1717920116;
  
  static final int TAG_FDSC = 1717859171;
  
  static final int TAG_FMTX = 1718449272;
  
  static final int TAG_JUST = 1786082164;
  
  static final int TAG_LCAR = 1818452338;
  
  static final int TAG_MORT = 1836020340;
  
  static final int TAG_OPBD = 1836020340;
  
  static final int TAG_PROP = 1886547824;
  
  static final int TAG_TRAK = 1953653099;
  
  public File getFontFile() { return this.file; }
  
  public String getPSName() { return this.psName; }
  
  public int getFirstChar() { return this.firstChar; }
  
  public int getLastChar() { return this.lastChar; }
  
  public boolean isCJKFont() { return (this.cjk != null); }
  
  public CMap getCMap() { return this.cjkmap; }
  
  public boolean isCFFont() { return (findTagOffLen(1128678944) != null); }
  
  public int[] getCIDWidths() { return this.cidwidths; }
  
  public void parse(File paramFile) throws IOException {
    this.file = paramFile;
    RandomAccessFile randomAccessFile = new RandomAccessFile(paramFile, "r");
    boolean bool = false;
    byte[] arrayOfByte1 = new byte[4096];
    byte[] arrayOfByte2 = new byte[8192];
    int[] arrayOfInt = null;
    int i = 16;
    int j = 1;
    randomAccessFile.read(arrayOfByte1, 0, 12);
    int k = getSHORT(arrayOfByte1, 4);
    this.tagofflen = new int[k][4];
    bool += true;
    for (byte b1 = 0; b1 < k; b1++) {
      randomAccessFile.seek(bool);
      randomAccessFile.read(arrayOfByte1, 0, 16);
      bool += true;
      int m = getLONG(arrayOfByte1, 0);
      int n = getLONG(arrayOfByte1, 4);
      int i1 = getLONG(arrayOfByte1, 8);
      int i2 = getLONG(arrayOfByte1, 12);
      this.tagofflen[b1][0] = m;
      this.tagofflen[b1][1] = i1;
      this.tagofflen[b1][2] = i2;
      this.tagofflen[b1][3] = n;
      randomAccessFile.seek(i1);
      if (arrayOfByte2.length < i2)
        arrayOfByte2 = new byte[i2]; 
      if (m == 1751474532) {
        randomAccessFile.read(arrayOfByte2, 0, i2);
        i = getSHORT(arrayOfByte2, 18);
        this.bbox = new Rectangle(getSHORT(arrayOfByte2, 36), getSHORT(arrayOfByte2, 38), getSHORT(arrayOfByte2, 40), getSHORT(arrayOfByte2, 42));
        this.indexToLocFormat = getSHORT(arrayOfByte2, 50);
      } else if (m == 1751672161) {
        randomAccessFile.read(arrayOfByte2, 0, i2);
        this.ascender = getSHORT(arrayOfByte2, 4);
        this.descender = getSHORT(arrayOfByte2, 6);
        this.advance = getSHORT(arrayOfByte2, 10);
        j = getSHORT(arrayOfByte2, 34);
        if (this.capHeight == 0)
          this.capHeight = this.ascender; 
      } else if (m == 1886352244) {
        randomAccessFile.read(arrayOfByte2, 0, i2);
        this.italicAngle = getFIXED(arrayOfByte2, 4);
        this.fixedPitch = (getLONG(arrayOfByte2, 12) != 0);
      } else if (m == 1346587732) {
        randomAccessFile.read(arrayOfByte2, 0, i2);
        this.capHeight = getSHORT(arrayOfByte2, 16);
      } else if (m == 1835104368) {
        randomAccessFile.read(arrayOfByte2, 0, i2);
        this.numGlyphs = getSHORT(arrayOfByte2, 4);
      } else if (m == 1851878757) {
        randomAccessFile.read(arrayOfByte2, 0, i2);
        int i3 = getSHORT(arrayOfByte2, 2);
        int i4 = getSHORT(arrayOfByte2, 4);
        byte b3 = 6;
        for (byte b4 = 0; b4 < i3; b4++, b3 += 12) {
          int i5 = getSHORT(arrayOfByte2, b3 + 6);
          int i6 = getSHORT(arrayOfByte2, b3 + 8);
          int i7 = getSHORT(arrayOfByte2, b3 + 10);
          String str = new String(arrayOfByte2, i4 + i7, i6, "UnicodeBig");
          switch (i5) {
            case 1:
              this.familyName = str;
              this.fontName = str;
              break;
            case 2:
              this.styleName = str;
              break;
            case 4:
              this.fullName = str;
              break;
            case 6:
              this.psName = str;
              break;
          } 
        } 
      } else if (m == 1668112752) {
        randomAccessFile.read(arrayOfByte2, 0, i2);
        int i3 = getSHORT(arrayOfByte2, 2);
        for (byte b = 0; b < i3; b++) {
          int i9;
          byte b3;
          int i8, arrayOfInt4[], arrayOfInt3[], arrayOfInt2[], arrayOfInt1[], i7, i6, i4 = getLONG(arrayOfByte2, 4 + b * 8 + 4);
          int i5 = getUSHORT(arrayOfByte2, i4);
          switch (i5) {
            case 0:
              arrayOfInt = new int[256];
              for (i6 = 0; i6 < arrayOfInt.length; i6++)
                arrayOfInt[i6] = arrayOfByte2[i4 + 6 + i6] & 0xFF; 
              break;
            case 4:
              i7 = getUSHORT(arrayOfByte2, i4 + 6) / 2;
              arrayOfInt1 = new int[i7];
              arrayOfInt2 = new int[i7];
              arrayOfInt3 = new int[i7];
              arrayOfInt4 = new int[i7];
              i8 = 16 + 2 * i7 * 4;
              for (b3 = 0; b3 < i7; b3++) {
                arrayOfInt1[b3] = getUSHORT(arrayOfByte2, i4 + 14 + b3 * 2);
                arrayOfInt2[b3] = getUSHORT(arrayOfByte2, i4 + 16 + i7 * 2 + b3 * 2);
                arrayOfInt3[b3] = getSHORT(arrayOfByte2, i4 + 16 + i7 * 4 + b3 * 2);
                arrayOfInt4[b3] = getUSHORT(arrayOfByte2, i4 + 16 + i7 * 6 + b3 * 2);
              } 
              arrayOfInt = new int[arrayOfInt1[arrayOfInt1.length - 2] + 1];
              for (i9 = 0; i9 < arrayOfInt.length; i9++) {
                for (byte b4 = 0; b4 < arrayOfInt1.length; b4++) {
                  if (i9 <= arrayOfInt1[b4] && 
                    i9 >= arrayOfInt2[b4])
                    if (arrayOfInt4[b4] == 0) {
                      arrayOfInt[i9] = i9 + arrayOfInt3[b4];
                    } else {
                      arrayOfInt[i9] = getUSHORT(arrayOfByte2, arrayOfInt4[b4] + (i9 - arrayOfInt2[b4]) * 2 + i4 + 16 + i7 * 6 + b4 * 2);
                    }  
                } 
              } 
              break;
          } 
        } 
      } else if (m == 1752003704) {
        randomAccessFile.read(arrayOfByte2, 0, i2);
        this.widths = new int[Math.max(j, 256)];
        byte b3;
        for (b3 = 0; b3 < j; b3++)
          this.widths[b3] = getSHORT(arrayOfByte2, b3 * 4); 
        for (byte b4 = b3; b4 < this.widths.length; b4++)
          this.widths[b4] = this.widths[b3 - 1]; 
      } else if (m == 1668707360) {
      
      } 
    } 
    this.ascender = this.ascender * 1000 / i;
    this.descender = this.descender * 1000 / i;
    this.advance = this.advance * 1000 / i;
    this.capHeight = this.capHeight * 1000 / i;
    this.bbox.x = this.bbox.x * 1000 / i;
    this.bbox.y = this.bbox.y * 1000 / i;
    this.bbox.width = this.bbox.width * 1000 / i;
    this.bbox.height = this.bbox.height * 1000 / i;
    this.cjk = FontManager.getFontManager().getCJKInfo(getFullName());
    for (byte b2 = 0; b2 < this.widths.length; b2++)
      this.widths[b2] = this.widths[b2] * 1000 / i; 
    if (isCJKFont()) {
      this.cidwidths = this.widths;
      try {
        this.cjkmap = new CMap(this.cjk[1]);
        int[] arrayOfInt1 = new int[this.cjkmap.getMax() + 1];
        for (byte b = 0; b < arrayOfInt1.length; b++) {
          int m = this.cjkmap.map((char)b);
          arrayOfInt1[b] = (m >= 0 && m < this.widths.length) ? this.widths[m] : this.widths[0];
        } 
        this.widths = arrayOfInt1;
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } else if (arrayOfInt != null) {
      int[] arrayOfInt1 = new int[256];
      for (byte b = 0; b < arrayOfInt1.length; b++)
        arrayOfInt1[b] = (b < arrayOfInt.length && arrayOfInt[b] < this.widths.length) ? this.widths[arrayOfInt[b]] : this.widths[0]; 
      this.widths = arrayOfInt1;
    } else {
      System.err.println("No format 0 table (cmap): " + paramFile);
    } 
    randomAccessFile.close();
  }
  
  byte[] getFontData() throws IOException {
    File file1 = getFontFile();
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream((int)file1.length());
    FileInputStream fileInputStream = new FileInputStream(file1);
    byte[] arrayOfByte = new byte[4096];
    int i;
    while ((i = fileInputStream.read(arrayOfByte)) > 0)
      byteArrayOutputStream.write(arrayOfByte, 0, i); 
    fileInputStream.close();
    return byteArrayOutputStream.toByteArray();
  }
  
  byte[] getFontData(BitSet paramBitSet) throws IOException {
    RandomAccessFile randomAccessFile = new RandomAccessFile(this.file, "r");
    if (findTagOffLen(1819239265) != null) {
      ByteArrayOutputStream byteArrayOutputStream1 = new ByteArrayOutputStream();
      ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
      DataOutputStream dataOutputStream1 = new DataOutputStream(byteArrayOutputStream1);
      int[] arrayOfInt1 = findTagOffLen(1819239265);
      int[] arrayOfInt2 = findTagOffLen(1735162214);
      if (arrayOfInt2 == null)
        throw new IOException("GLYF table missing: " + this.file); 
      randomAccessFile.seek(arrayOfInt1[1]);
      int i = (this.indexToLocFormat == 0) ? randomAccessFile.readUnsignedShort() : randomAccessFile.readInt();
      for (byte b1 = 0; b1 < this.numGlyphs; b1++) {
        int j = (this.indexToLocFormat == 0) ? randomAccessFile.readUnsignedShort() : randomAccessFile.readInt();
        if (paramBitSet.get(b1) && j > i) {
          long l = randomAccessFile.getFilePointer();
          randomAccessFile.seek((arrayOfInt2[1] + i));
          byte[] arrayOfByte = new byte[j - i];
          randomAccessFile.readFully(arrayOfByte);
          byteArrayOutputStream2.write(arrayOfByte);
          randomAccessFile.seek(l);
        } else if (this.indexToLocFormat == 0) {
          dataOutputStream1.writeShort(arrayOfInt2[1] + byteArrayOutputStream2.size());
        } else {
          dataOutputStream1.writeInt(arrayOfInt2[1] + byteArrayOutputStream2.size());
        } 
        i = j;
      } 
      if (this.indexToLocFormat == 0) {
        dataOutputStream1.writeShort(arrayOfInt2[1] + byteArrayOutputStream2.size());
      } else {
        dataOutputStream1.writeInt(arrayOfInt2[1] + byteArrayOutputStream2.size());
      } 
      dataOutputStream1.flush();
      pad4(byteArrayOutputStream1);
      pad4(byteArrayOutputStream2);
      ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
      ByteArrayOutputStream byteArrayOutputStream4 = new ByteArrayOutputStream();
      DataOutputStream dataOutputStream2 = new DataOutputStream(byteArrayOutputStream4);
      copy(randomAccessFile, 0, 12, byteArrayOutputStream3);
      copy(randomAccessFile, 12, 16 * this.tagofflen.length, byteArrayOutputStream3);
      for (byte b2 = 0; b2 < this.tagofflen.length; b2++) {
        long l = byteArrayOutputStream3.size();
        int j = 0;
        if (this.tagofflen[b2][0] == 1819239265) {
          j = copy(byteArrayOutputStream1, byteArrayOutputStream3);
        } else if (this.tagofflen[b2][0] == 1735162214) {
          j = copy(byteArrayOutputStream2, byteArrayOutputStream3);
        } else {
          copy(randomAccessFile, this.tagofflen[b2][1], this.tagofflen[b2][2], byteArrayOutputStream3);
          j = this.tagofflen[b2][3];
        } 
        dataOutputStream2.writeInt(this.tagofflen[b2][0]);
        dataOutputStream2.writeInt(j);
        dataOutputStream2.writeInt((int)l);
        dataOutputStream2.writeInt((int)(byteArrayOutputStream3.size() - l));
        pad4(byteArrayOutputStream3);
      } 
      randomAccessFile.close();
      return byteArrayOutputStream3.toByteArray();
    } 
    if (findTagOffLen(1128678944) != null) {
      int[] arrayOfInt = findTagOffLen(1128678944);
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      CFF.extract(randomAccessFile, arrayOfInt[1], arrayOfInt[2], byteArrayOutputStream, paramBitSet);
      return byteArrayOutputStream.toByteArray();
    } 
    return null;
  }
  
  int[] findTagOffLen(int paramInt) {
    for (byte b = 0; b < this.tagofflen.length; b++) {
      if (this.tagofflen[b][0] == paramInt)
        return this.tagofflen[b]; 
    } 
    return null;
  }
  
  static void pad4(ByteArrayOutputStream paramByteArrayOutputStream) throws IOException {
    int i = (4 - paramByteArrayOutputStream.size() % 4) % 4;
    paramByteArrayOutputStream.write(new byte[i]);
  }
  
  static int copy(RandomAccessFile paramRandomAccessFile, int paramInt1, int paramInt2, OutputStream paramOutputStream) throws IOException {
    byte[] arrayOfByte = new byte[paramInt2];
    paramRandomAccessFile.seek(paramInt1);
    paramRandomAccessFile.readFully(arrayOfByte);
    paramOutputStream.write(arrayOfByte);
    return getChecksum(arrayOfByte);
  }
  
  static int copy(ByteArrayOutputStream paramByteArrayOutputStream, OutputStream paramOutputStream) throws IOException {
    byte[] arrayOfByte = paramByteArrayOutputStream.toByteArray();
    paramOutputStream.write(arrayOfByte);
    return getChecksum(arrayOfByte);
  }
  
  static int getChecksum(byte[] paramArrayOfByte) {
    long l = 0L;
    for (byte b = 0; b < paramArrayOfByte.length; b += 4) {
      l += (getLONG(paramArrayOfByte, b) & 0xFFFFFFFFL);
      l &= 0xFFFFFFFFL;
    } 
    return (int)l & 0xFFFFFFFF;
  }
  
  static int getSHORT(byte[] paramArrayOfByte, int paramInt) { return (short)getNUMBER(paramArrayOfByte, paramInt, 2); }
  
  static int getUSHORT(byte[] paramArrayOfByte, int paramInt) { return getNUMBER(paramArrayOfByte, paramInt, 2); }
  
  static int getLONG(byte[] paramArrayOfByte, int paramInt) { return getNUMBER(paramArrayOfByte, paramInt, 4); }
  
  static int getNUMBER(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    byte b = 0;
    for (byte b1 = 0; b1 < paramInt2; b1++) {
      byte b2 = (paramInt1 < paramArrayOfByte.length) ? (paramArrayOfByte[paramInt1++] & 0xFF) : 0;
      b = b << 8 | b2;
    } 
    return b;
  }
  
  static double getFIXED(byte[] paramArrayOfByte, int paramInt) { return getSHORT(paramArrayOfByte, paramInt) + getSHORT(paramArrayOfByte, paramInt + 2) / 255.0D; }
  
  public static String[] getFontNames(File paramFile) throws IOException {
    RandomAccessFile randomAccessFile = new RandomAccessFile(paramFile, "r");
    byte[] arrayOfByte = new byte[8192];
    String str1 = null, str2 = null, str3 = null;
    randomAccessFile.read(arrayOfByte, 0, 12);
    int i = getSHORT(arrayOfByte, 4);
    for (byte b = 0; b < i; b++) {
      randomAccessFile.read(arrayOfByte, 0, 16);
      int j = getLONG(arrayOfByte, 0);
      if (j == 1851878757) {
        int k = getLONG(arrayOfByte, 8);
        int m = getLONG(arrayOfByte, 12);
        randomAccessFile.seek(k);
        arrayOfByte = new byte[m];
        randomAccessFile.read(arrayOfByte, 0, m);
        int n = getSHORT(arrayOfByte, 2);
        int i1 = getSHORT(arrayOfByte, 4);
        byte b1 = 6;
        for (byte b2 = 0; b2 < n; b2++, b1 += 12) {
          int i2 = getSHORT(arrayOfByte, b1 + 6);
          int i3 = getSHORT(arrayOfByte, b1 + 8);
          int i4 = getSHORT(arrayOfByte, b1 + 10);
          if (i1 + i4 + i3 <= arrayOfByte.length) {
            String str = new String(arrayOfByte, i1 + i4, i3, "UnicodeBig");
            if (i2 == 1) {
              str1 = str;
            } else if (i2 == 4) {
              str2 = str;
            } else if (i2 == 6) {
              str3 = str;
            } 
          } 
        } 
        break;
      } 
    } 
    randomAccessFile.close();
    return new String[] { str1, str2, str3 };
  }
  
  public static void main(String[] paramArrayOfString) {
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      try {
        TTFontInfo tTFontInfo = new TTFontInfo();
        tTFontInfo.parse(new File(paramArrayOfString[b]));
        System.err.println("[" + paramArrayOfString[b] + "]");
        System.err.println("getFontName = " + tTFontInfo.getFontName());
        System.err.println("getFullName = " + tTFontInfo.getFullName());
        System.err.println("getFamilyName = " + tTFontInfo.getFamilyName());
        System.err.println("getPSName = " + tTFontInfo.getPSName());
        System.err.println("[style name] = " + tTFontInfo.styleName);
        System.err.println("getWeight = " + tTFontInfo.getWeight());
        System.err.println("isFixedPitch = " + tTFontInfo.isFixedPitch());
        System.err.println("getAscent = " + tTFontInfo.getAscent());
        System.err.println("getDescent = " + tTFontInfo.getDescent());
        System.err.println("getMaxAdvance = " + tTFontInfo.getMaxAdvance());
        System.err.println("getItalicAngle = " + tTFontInfo.getItalicAngle());
        System.err.println("getFontBBox = " + tTFontInfo.getFontBBox());
        System.err.println("getEncoding = " + tTFontInfo.getEncoding());
        System.err.println("getCapHeight = " + tTFontInfo.getCapHeight());
        int[] arrayOfInt = tTFontInfo.getWidths();
        System.err.print("width[");
        for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
          if (b1 % 15 == 0)
            System.err.print("\n" + b1 + ": "); 
          System.err.print(arrayOfInt[b1] + " ");
        } 
        System.err.println("]");
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
  }
  
  String psName = null;
  
  String styleName = null;
  
  int firstChar = 32;
  
  int lastChar = 255;
  
  File file;
  
  String[] cjk = null;
  
  CMap cjkmap = null;
  
  int indexToLocFormat = 0;
  
  int numGlyphs = 255;
  
  int[][] tagofflen = null;
  
  int[] cidwidths = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\TTFontInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */