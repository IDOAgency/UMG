package inetsoft.report.pdf;

import inetsoft.report.Common;
import inetsoft.report.PDFPrinter;
import inetsoft.report.internal.Encoder;
import java.awt.Font;
import java.awt.Rectangle;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;

public class PDF3Printer extends PDFPrinter {
  public PDF3Printer() {}
  
  public PDF3Printer(OutputStream paramOutputStream) { super(paramOutputStream); }
  
  public void setBase14Only(boolean paramBoolean) { this.base14 = paramBoolean; }
  
  public boolean isBase14Only() { return this.base14; }
  
  public void setEmbedFont(boolean paramBoolean) { this.embedFont = paramBoolean; }
  
  public boolean isEmbedFont() { return this.embedFont; }
  
  public String getFontName(Font paramFont) {
    String str1 = Common.getFontName(paramFont);
    String str2 = getPSName(str1, paramFont);
    if (!this.base14 && !isBase14Font(str1)) {
      if (this.fontMgr.exists(str2))
        return str2; 
      int i = str2.indexOf(',');
      if (i > 0) {
        str2 = str2.replace(',', '-');
        if (this.fontMgr.exists(str2))
          return str2; 
      } 
      if (this.fontMgr.exists(str1))
        return str1; 
    } 
    return super.getFontName(paramFont);
  }
  
  protected String getPSName(String paramString, Font paramFont) {
    String str = "";
    if ((paramFont.getStyle() & true) != 0)
      str = str + "Bold"; 
    if ((paramFont.getStyle() & 0x2) != 0)
      str = str + "Italic"; 
    return (str.length() > 0) ? (paramString = paramString + "," + str) : paramString;
  }
  
  protected void emitFont(Font paramFont) {
    this.psFontName = getFontName(paramFont);
    if (isBase14Font(this.psFontName)) {
      super.emitFont(paramFont);
      return;
    } 
    startPage();
    debug(this.pg, "%setFont3");
    String str = (String)this.fontFn.get(this.psFontName);
    if (str == null) {
      str = "F" + getNextFontIndex();
      String str1 = (String)this.fontObj.get(this.psFontName);
      if (str1 == null) {
        FontInfo fontInfo = this.fontMgr.getFontInfo(this.psFontName);
        if (fontInfo == null) {
          super.emitFont(paramFont);
          return;
        } 
        int i = getNextObjectID();
        str1 = i + " 0 R";
        this.fontObj.put(this.psFontName, str1);
        boolean bool = fontInfo instanceof TTFontInfo;
        int[] arrayOfInt = fontInfo.getWidths();
        String str2 = getPSName(strip(fontInfo.getFontName(), " "), paramFont);
        this.others.markObject(i);
        this.others.println(i + " 0 obj");
        this.others.println("<<");
        this.others.println("/Type /Font");
        this.others.println("/Subtype /" + (bool ? "TrueType" : "Type1"));
        this.others.println("/Name /" + str);
        this.others.println("/BaseFont /" + str2);
        String str3 = this.psFontName.equals("Symbol") ? "PDFDocEncoding" : "WinAnsiEncoding";
        this.others.println("/Encoding /" + str3);
        this.others.println("/FirstChar 32");
        this.others.println("/LastChar 255");
        this.others.print("/Widths [");
        for (byte b = 32; b <= 'ÿ'; b++)
          this.others.print(" " + arrayOfInt[b]); 
        this.others.println("]");
        int j = getNextObjectID();
        this.others.println("/FontDescriptor " + j + " 0 R");
        this.others.println(">>");
        this.others.println("endobj");
        emitFontDescriptor(j, str2, paramFont, fontInfo);
      } 
      this.fnList.addElement("/" + str + " " + str1 + " ");
    } 
    this.pg.println("/" + str + " " + paramFont.getSize() + " Tf");
    this.fontFn.put(this.psFontName, str);
  }
  
  void emitFontDescriptor(int paramInt, String paramString, Font paramFont, FontInfo paramFontInfo) {
    Rectangle rectangle = paramFontInfo.getFontBBox();
    boolean bool = paramFontInfo instanceof TTFontInfo;
    boolean bool1 = (bool && ((TTFontInfo)paramFontInfo).isCFFont()) ? 1 : 0;
    this.others.markObject(paramInt);
    this.others.println(paramInt + " 0 obj");
    this.others.println("<<");
    this.others.println("/Type /FontDescriptor");
    this.others.println("/FontName /" + paramString);
    this.others.println("/Flags 34");
    this.others.println("/FontBBox [ " + rectangle.x + " " + rectangle.y + " " + rectangle.width + " " + rectangle.height + " ]");
    this.others.println("/StemV 73");
    this.others.println("/ItalicAngle " + (((paramFont.getStyle() & 0x2) != 0) ? paramFontInfo.getItalicAngle() : 0.0D));
    this.others.println("/CapHeight " + paramFontInfo.getCapHeight());
    this.others.println("/Ascent " + paramFontInfo.getAscent());
    this.others.println("/Descent " + paramFontInfo.getDescent());
    int i = 0;
    if (bool && this.embedFont) {
      i = getNextObjectID();
      this.others.println((bool1 ? "/FontFile3 " : "/FontFile2 ") + i + " 0 R");
    } 
    this.others.println(">>");
    this.others.println("endobj");
    if (bool && this.embedFont)
      embedFont(i, paramString, (TTFontInfo)paramFontInfo); 
  }
  
  void embedFont(int paramInt, String paramString, TTFontInfo paramTTFontInfo) {
    try {
      byte[] arrayOfByte = getFontData(paramString, paramTTFontInfo);
      String[][] arrayOfString = null;
      if (paramTTFontInfo.isCFFont())
        arrayOfString = new String[][] { { "/Subtype", "/CIDFontType0C" } }; 
      emitStream(paramInt, arrayOfByte, arrayOfString, true);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  void emitStream(int paramInt, byte[] paramArrayOfByte, String[][] paramArrayOfString, boolean paramBoolean) {
    try {
      byte[] arrayOfByte = paramBoolean ? Encoder.encodeAscii85(Encoder.deflate(paramArrayOfByte)) : paramArrayOfByte;
      this.others.markObject(paramInt);
      this.others.println(paramInt + " 0 obj");
      this.others.println("<<");
      if (paramBoolean)
        this.others.println("/Filter [ /ASCII85Decode /FlateDecode ]"); 
      int i = getNextObjectID();
      this.others.println("/Length " + i + " 0 R");
      this.others.println("/Length1 " + paramArrayOfByte.length);
      if (paramArrayOfString != null)
        for (byte b = 0; b < paramArrayOfString.length; b++)
          this.others.println(paramArrayOfString[b][0] + " " + paramArrayOfString[b][1]);  
      this.others.println(">>");
      this.others.println("stream");
      int j = this.others.getOffset();
      if (paramBoolean) {
        for (int m = 0; m < arrayOfByte.length; m += 78) {
          if (m)
            this.others.println(""); 
          this.others.write(arrayOfByte, m, Math.min(arrayOfByte.length - m, 78));
        } 
        this.others.println("~>");
      } else {
        this.others.write(arrayOfByte);
      } 
      int k = this.others.getOffset() - j;
      this.others.println("endstream");
      this.others.println("endobj");
      this.others.markObject(i);
      this.others.println(i + " 0 obj");
      this.others.println(k + "");
      this.others.println("endobj");
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  byte[] getFontData(String paramString, TTFontInfo paramTTFontInfo) throws FileNotFoundException, IOException { return paramTTFontInfo.getFontData(); }
  
  protected int stringWidth(String paramString) {
    FontInfo fontInfo = this.fontMgr.getFontInfo(this.psFontName);
    return (fontInfo != null) ? fontInfo.stringWidth(paramString, this.font.getSize()) : super.stringWidth(paramString);
  }
  
  String strip(String paramString1, String paramString2) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramString1.length(); b++) {
      if (paramString2.indexOf(paramString1.charAt(b)) < 0)
        stringBuffer.append(paramString1.charAt(b)); 
    } 
    return stringBuffer.toString();
  }
  
  void addObject(int paramInt, String paramString) {
    this.others.markObject(paramInt);
    this.others.println(paramInt + " 0 obj");
    this.others.println(paramString);
    this.others.println("endobj");
  }
  
  String getPageID(int paramInt) { return (String)this.pageIds.elementAt(paramInt); }
  
  void setOutlines(String paramString) { this.outlines = paramString; }
  
  void flush() { writeOthers(); }
  
  FontManager fontMgr = FontManager.getFontManager();
  
  private boolean embedFont = false;
  
  private boolean base14 = false;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\PDF3Printer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */