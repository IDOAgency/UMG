/*     */ package inetsoft.report.pdf;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.PDFPrinter;
/*     */ import inetsoft.report.internal.Encoder;
/*     */ import java.awt.Font;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PDF3Printer
/*     */   extends PDFPrinter
/*     */ {
/*     */   public PDF3Printer() {}
/*     */   
/*  46 */   public PDF3Printer(OutputStream paramOutputStream) { super(paramOutputStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public void setBase14Only(boolean paramBoolean) { this.base14 = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public boolean isBase14Only() { return this.base14; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public void setEmbedFont(boolean paramBoolean) { this.embedFont = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public boolean isEmbedFont() { return this.embedFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFontName(Font paramFont) {
/*  84 */     String str1 = Common.getFontName(paramFont);
/*  85 */     String str2 = getPSName(str1, paramFont);
/*     */     
/*  87 */     if (!this.base14 && !isBase14Font(str1)) {
/*  88 */       if (this.fontMgr.exists(str2)) {
/*  89 */         return str2;
/*     */       }
/*     */       
/*  92 */       int i = str2.indexOf(',');
/*  93 */       if (i > 0) {
/*  94 */         str2 = str2.replace(',', '-');
/*  95 */         if (this.fontMgr.exists(str2)) {
/*  96 */           return str2;
/*     */         }
/*     */       } 
/*     */       
/* 100 */       if (this.fontMgr.exists(str1)) {
/* 101 */         return str1;
/*     */       }
/*     */     } 
/*     */     
/* 105 */     return super.getFontName(paramFont);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getPSName(String paramString, Font paramFont) {
/* 110 */     String str = "";
/*     */     
/* 112 */     if ((paramFont.getStyle() & true) != 0) {
/* 113 */       str = str + "Bold";
/*     */     }
/*     */     
/* 116 */     if ((paramFont.getStyle() & 0x2) != 0) {
/* 117 */       str = str + "Italic";
/*     */     }
/*     */ 
/*     */     
/* 121 */     return (str.length() > 0) ? (paramString = paramString + "," + str) : paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void emitFont(Font paramFont) {
/* 128 */     this.psFontName = getFontName(paramFont);
/*     */     
/* 130 */     if (isBase14Font(this.psFontName)) {
/* 131 */       super.emitFont(paramFont);
/*     */       
/*     */       return;
/*     */     } 
/* 135 */     startPage();
/* 136 */     debug(this.pg, "%setFont3");
/*     */     
/* 138 */     String str = (String)this.fontFn.get(this.psFontName);
/* 139 */     if (str == null) {
/* 140 */       str = "F" + getNextFontIndex();
/*     */       
/* 142 */       String str1 = (String)this.fontObj.get(this.psFontName);
/* 143 */       if (str1 == null) {
/* 144 */         FontInfo fontInfo = this.fontMgr.getFontInfo(this.psFontName);
/* 145 */         if (fontInfo == null) {
/* 146 */           super.emitFont(paramFont);
/*     */           
/*     */           return;
/*     */         } 
/* 150 */         int i = getNextObjectID();
/* 151 */         str1 = i + " 0 R";
/* 152 */         this.fontObj.put(this.psFontName, str1);
/*     */         
/* 154 */         boolean bool = fontInfo instanceof TTFontInfo;
/* 155 */         int[] arrayOfInt = fontInfo.getWidths();
/* 156 */         String str2 = getPSName(strip(fontInfo.getFontName(), " "), paramFont);
/*     */         
/* 158 */         this.others.markObject(i);
/* 159 */         this.others.println(i + " 0 obj");
/* 160 */         this.others.println("<<");
/* 161 */         this.others.println("/Type /Font");
/* 162 */         this.others.println("/Subtype /" + (bool ? "TrueType" : "Type1"));
/* 163 */         this.others.println("/Name /" + str);
/* 164 */         this.others.println("/BaseFont /" + str2);
/*     */         
/* 166 */         String str3 = this.psFontName.equals("Symbol") ? "PDFDocEncoding" : "WinAnsiEncoding";
/*     */         
/* 168 */         this.others.println("/Encoding /" + str3);
/* 169 */         this.others.println("/FirstChar 32");
/* 170 */         this.others.println("/LastChar 255");
/*     */         
/* 172 */         this.others.print("/Widths [");
/* 173 */         for (byte b = 32; b <= 'ÿ'; b++) {
/* 174 */           this.others.print(" " + arrayOfInt[b]);
/*     */         }
/* 176 */         this.others.println("]");
/*     */         
/* 178 */         int j = getNextObjectID();
/* 179 */         this.others.println("/FontDescriptor " + j + " 0 R");
/* 180 */         this.others.println(">>");
/* 181 */         this.others.println("endobj");
/*     */         
/* 183 */         emitFontDescriptor(j, str2, paramFont, fontInfo);
/*     */       } 
/*     */       
/* 186 */       this.fnList.addElement("/" + str + " " + str1 + " ");
/*     */     } 
/*     */     
/* 189 */     this.pg.println("/" + str + " " + paramFont.getSize() + " Tf");
/* 190 */     this.fontFn.put(this.psFontName, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void emitFontDescriptor(int paramInt, String paramString, Font paramFont, FontInfo paramFontInfo) {
/* 197 */     Rectangle rectangle = paramFontInfo.getFontBBox();
/* 198 */     boolean bool = paramFontInfo instanceof TTFontInfo;
/* 199 */     boolean bool1 = (bool && ((TTFontInfo)paramFontInfo).isCFFont()) ? 1 : 0;
/*     */     
/* 201 */     this.others.markObject(paramInt);
/* 202 */     this.others.println(paramInt + " 0 obj");
/* 203 */     this.others.println("<<");
/* 204 */     this.others.println("/Type /FontDescriptor");
/* 205 */     this.others.println("/FontName /" + paramString);
/* 206 */     this.others.println("/Flags 34");
/* 207 */     this.others.println("/FontBBox [ " + rectangle.x + " " + rectangle.y + " " + rectangle.width + " " + rectangle.height + " ]");
/*     */     
/* 209 */     this.others.println("/StemV 73");
/* 210 */     this.others.println("/ItalicAngle " + (((paramFont.getStyle() & 0x2) != 0) ? paramFontInfo.getItalicAngle() : 0.0D));
/*     */ 
/*     */     
/* 213 */     this.others.println("/CapHeight " + paramFontInfo.getCapHeight());
/* 214 */     this.others.println("/Ascent " + paramFontInfo.getAscent());
/* 215 */     this.others.println("/Descent " + paramFontInfo.getDescent());
/*     */     
/* 217 */     int i = 0;
/* 218 */     if (bool && this.embedFont) {
/* 219 */       i = getNextObjectID();
/* 220 */       this.others.println((bool1 ? "/FontFile3 " : "/FontFile2 ") + i + " 0 R");
/*     */     } 
/*     */     
/* 223 */     this.others.println(">>");
/* 224 */     this.others.println("endobj");
/*     */     
/* 226 */     if (bool && this.embedFont) {
/* 227 */       embedFont(i, paramString, (TTFontInfo)paramFontInfo);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void embedFont(int paramInt, String paramString, TTFontInfo paramTTFontInfo) {
/*     */     try {
/* 236 */       byte[] arrayOfByte = getFontData(paramString, paramTTFontInfo);
/* 237 */       String[][] arrayOfString = null;
/*     */       
/* 239 */       if (paramTTFontInfo.isCFFont()) {
/* 240 */         arrayOfString = new String[][] { { "/Subtype", "/CIDFontType0C" } };
/*     */       }
/*     */       
/* 243 */       emitStream(paramInt, arrayOfByte, arrayOfString, true);
/*     */     } catch (Exception exception) {
/*     */       
/* 246 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void emitStream(int paramInt, byte[] paramArrayOfByte, String[][] paramArrayOfString, boolean paramBoolean) {
/*     */     try {
/* 255 */       byte[] arrayOfByte = paramBoolean ? Encoder.encodeAscii85(Encoder.deflate(paramArrayOfByte)) : paramArrayOfByte;
/*     */ 
/*     */       
/* 258 */       this.others.markObject(paramInt);
/* 259 */       this.others.println(paramInt + " 0 obj");
/* 260 */       this.others.println("<<");
/*     */       
/* 262 */       if (paramBoolean) {
/* 263 */         this.others.println("/Filter [ /ASCII85Decode /FlateDecode ]");
/*     */       }
/*     */       
/* 266 */       int i = getNextObjectID();
/* 267 */       this.others.println("/Length " + i + " 0 R");
/* 268 */       this.others.println("/Length1 " + paramArrayOfByte.length);
/*     */       
/* 270 */       if (paramArrayOfString != null) {
/* 271 */         for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 272 */           this.others.println(paramArrayOfString[b][0] + " " + paramArrayOfString[b][1]);
/*     */         }
/*     */       }
/*     */       
/* 276 */       this.others.println(">>");
/* 277 */       this.others.println("stream");
/* 278 */       int j = this.others.getOffset();
/*     */       
/* 280 */       if (paramBoolean) {
/* 281 */         for (int m = 0; m < arrayOfByte.length; m += 78) {
/* 282 */           if (m) {
/* 283 */             this.others.println("");
/*     */           }
/*     */           
/* 286 */           this.others.write(arrayOfByte, m, Math.min(arrayOfByte.length - m, 78));
/*     */         } 
/* 288 */         this.others.println("~>");
/*     */       } else {
/*     */         
/* 291 */         this.others.write(arrayOfByte);
/*     */       } 
/*     */       
/* 294 */       int k = this.others.getOffset() - j;
/* 295 */       this.others.println("endstream");
/* 296 */       this.others.println("endobj");
/*     */       
/* 298 */       this.others.markObject(i);
/* 299 */       this.others.println(i + " 0 obj");
/* 300 */       this.others.println(k + "");
/* 301 */       this.others.println("endobj");
/*     */     } catch (Exception exception) {
/* 303 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 312 */   byte[] getFontData(String paramString, TTFontInfo paramTTFontInfo) throws FileNotFoundException, IOException { return paramTTFontInfo.getFontData(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int stringWidth(String paramString) {
/* 320 */     FontInfo fontInfo = this.fontMgr.getFontInfo(this.psFontName);
/* 321 */     return (fontInfo != null) ? fontInfo.stringWidth(paramString, this.font.getSize()) : super.stringWidth(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String strip(String paramString1, String paramString2) {
/* 329 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 331 */     for (byte b = 0; b < paramString1.length(); b++) {
/* 332 */       if (paramString2.indexOf(paramString1.charAt(b)) < 0) {
/* 333 */         stringBuffer.append(paramString1.charAt(b));
/*     */       }
/*     */     } 
/*     */     
/* 337 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addObject(int paramInt, String paramString) {
/* 344 */     this.others.markObject(paramInt);
/* 345 */     this.others.println(paramInt + " 0 obj");
/* 346 */     this.others.println(paramString);
/* 347 */     this.others.println("endobj");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 354 */   String getPageID(int paramInt) { return (String)this.pageIds.elementAt(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 361 */   void setOutlines(String paramString) { this.outlines = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 368 */   void flush() { writeOthers(); }
/*     */ 
/*     */   
/* 371 */   FontManager fontMgr = FontManager.getFontManager();
/*     */   private boolean embedFont = false;
/*     */   private boolean base14 = false;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\PDF3Printer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */