/*    */ package inetsoft.report.pdf;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PDF4Generator
/*    */   extends PDF3Generator
/*    */ {
/*    */   public PDF4Generator() {}
/*    */   
/* 41 */   public PDF4Generator(OutputStream paramOutputStream) { super(paramOutputStream); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PDF3Printer getPrinter() {
/* 48 */     if (this.printer == null) {
/* 49 */       this.printer = new PDF4Printer(this.output);
/*    */     }
/*    */     
/* 52 */     return this.printer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   PDF4Printer printer = null;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\PDF4Generator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */