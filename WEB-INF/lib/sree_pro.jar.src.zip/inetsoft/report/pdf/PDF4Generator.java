package inetsoft.report.pdf;

import java.io.OutputStream;

public class PDF4Generator extends PDF3Generator {
  public PDF4Generator() {}
  
  public PDF4Generator(OutputStream paramOutputStream) { super(paramOutputStream); }
  
  public PDF3Printer getPrinter() {
    if (this.printer == null)
      this.printer = new PDF4Printer(this.output); 
    return this.printer;
  }
  
  PDF4Printer printer = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\PDF4Generator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */