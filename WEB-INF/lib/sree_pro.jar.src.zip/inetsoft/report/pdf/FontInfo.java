/*     */ package inetsoft.report.pdf;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.Serializable;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FontInfo
/*     */   implements Serializable
/*     */ {
/*     */   protected String fontName;
/*     */   protected String fullName;
/*     */   protected String familyName;
/*     */   protected String weight;
/*     */   protected String encoding;
/*     */   protected boolean fixedPitch;
/*     */   protected double italicAngle;
/*     */   protected int ascender;
/*     */   protected int descender;
/*     */   protected int[] widths;
/*     */   protected int advance;
/*     */   protected int capHeight;
/*     */   protected Rectangle bbox;
/*     */   
/*  32 */   public String getFontName() { return this.fontName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   public String getFullName() { return this.fullName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public String getFamilyName() { return this.familyName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public String getWeight() { return this.weight; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public boolean isFixedPitch() { return this.fixedPitch; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public int getAscent() { return this.ascender; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public int getDescent() { return this.descender; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public int getMaxAdvance() { return this.advance; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public int[] getWidths() { return this.widths; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public double getItalicAngle() { return this.italicAngle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public Rectangle getFontBBox() { return this.bbox; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public String getEncoding() { return this.encoding; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public int getCapHeight() { return this.capHeight; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int stringWidth(String paramString, int paramInt) {
/* 129 */     int i = 0;
/*     */ 
/*     */     
/* 132 */     for (byte b = 0; b < paramString.length(); b++) {
/* 133 */       i += getWidth(paramString.charAt(b));
/*     */     }
/*     */ 
/*     */     
/* 137 */     if (this.pairKern.size() > 0) {
/* 138 */       for (byte b1 = 0; b1 < paramString.length() - 1; b1++) {
/* 139 */         Integer integer = (Integer)this.pairKern.get(paramString.substring(b1, b1 + 2));
/* 140 */         if (integer != null) {
/* 141 */           i += integer.intValue();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 146 */     return (int)Math.ceil((i * paramInt) / 1000.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FontMetrics getFontMetrics(Font paramFont) {
/* 154 */     int i = paramFont.getSize();
/* 155 */     return new FontMetrics(this, i, paramFont)
/*     */       {
/* 157 */         public int getAscent() { return (int)Math.ceil((getHeight() * this.this$0.ascender / (this.this$0.ascender + this.this$0.descender))); }
/*     */         
/*     */         private final int val$size;
/*     */         private final FontInfo this$0;
/*     */         
/* 162 */         public int getDescent() { return (int)Math.ceil((getHeight() * this.this$0.descender / (this.this$0.ascender + this.this$0.descender))); }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 167 */         public int getMaxAdvance() { return (int)Math.ceil((this.this$0.getMaxAdvance() * this.val$size) / 1000.0D); }
/*     */ 
/*     */ 
/*     */         
/* 171 */         public int getHeight() { return (int)Math.ceil(Math.max((this.this$0.bbox.height * this.val$size) / 1000.0D, ((this.this$0.descender + this.this$0.ascender) * this.val$size) / 1000.0D)); }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 176 */         public int charWidth(char param1Char) { return (int)Math.ceil((this.this$0.getWidth(param1Char) * this.val$size) / 1000.0D); }
/*     */ 
/*     */ 
/*     */         
/* 180 */         public int stringWidth(String param1String) { return this.this$0.stringWidth(param1String, this.val$size); }
/*     */ 
/*     */         
/*     */         public int[] getWidths() {
/* 184 */           int[] arrayOfInt = new int[this.this$0.widths.length];
/* 185 */           for (byte b = 0; b < 'Ā'; b++) {
/* 186 */             arrayOfInt[b] = this.this$0.widths[b];
/*     */           }
/*     */           
/* 189 */           return arrayOfInt;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   private int getWidth(int paramInt) { return (paramInt < this.widths.length && this.widths[paramInt] > 0) ? this.widths[paramInt] : 1000; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   protected Hashtable pairKern = new Hashtable();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\FontInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */