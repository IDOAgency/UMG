package inetsoft.report.pdf;

import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Rectangle;
import java.io.Serializable;
import java.util.Hashtable;

public abstract class FontInfo implements Serializable {
  protected String fontName;
  
  protected String fullName;
  
  protected String familyName;
  
  protected String weight;
  
  protected String encoding;
  
  protected boolean fixedPitch;
  
  protected double italicAngle;
  
  protected int ascender;
  
  protected int descender;
  
  protected int[] widths;
  
  protected int advance;
  
  protected int capHeight;
  
  protected Rectangle bbox;
  
  public String getFontName() { return this.fontName; }
  
  public String getFullName() { return this.fullName; }
  
  public String getFamilyName() { return this.familyName; }
  
  public String getWeight() { return this.weight; }
  
  public boolean isFixedPitch() { return this.fixedPitch; }
  
  public int getAscent() { return this.ascender; }
  
  public int getDescent() { return this.descender; }
  
  public int getMaxAdvance() { return this.advance; }
  
  public int[] getWidths() { return this.widths; }
  
  public double getItalicAngle() { return this.italicAngle; }
  
  public Rectangle getFontBBox() { return this.bbox; }
  
  public String getEncoding() { return this.encoding; }
  
  public int getCapHeight() { return this.capHeight; }
  
  public int stringWidth(String paramString, int paramInt) {
    int i = 0;
    for (byte b = 0; b < paramString.length(); b++)
      i += getWidth(paramString.charAt(b)); 
    if (this.pairKern.size() > 0)
      for (byte b1 = 0; b1 < paramString.length() - 1; b1++) {
        Integer integer = (Integer)this.pairKern.get(paramString.substring(b1, b1 + 2));
        if (integer != null)
          i += integer.intValue(); 
      }  
    return (int)Math.ceil((i * paramInt) / 1000.0D);
  }
  
  public FontMetrics getFontMetrics(Font paramFont) {
    int i = paramFont.getSize();
    return new FontMetrics(this, i, paramFont) {
        private final int val$size;
        
        private final FontInfo this$0;
        
        public int getAscent() { return (int)Math.ceil((getHeight() * this.this$0.ascender / (this.this$0.ascender + this.this$0.descender))); }
        
        public int getDescent() { return (int)Math.ceil((getHeight() * this.this$0.descender / (this.this$0.ascender + this.this$0.descender))); }
        
        public int getMaxAdvance() { return (int)Math.ceil((this.this$0.getMaxAdvance() * this.val$size) / 1000.0D); }
        
        public int getHeight() { return (int)Math.ceil(Math.max((this.this$0.bbox.height * this.val$size) / 1000.0D, ((this.this$0.descender + this.this$0.ascender) * this.val$size) / 1000.0D)); }
        
        public int charWidth(char param1Char) { return (int)Math.ceil((this.this$0.getWidth(param1Char) * this.val$size) / 1000.0D); }
        
        public int stringWidth(String param1String) { return this.this$0.stringWidth(param1String, this.val$size); }
        
        public int[] getWidths() {
          int[] arrayOfInt = new int[this.this$0.widths.length];
          for (byte b = 0; b < 'Ā'; b++)
            arrayOfInt[b] = this.this$0.widths[b]; 
          return arrayOfInt;
        }
      };
  }
  
  private int getWidth(int paramInt) { return (paramInt < this.widths.length && this.widths[paramInt] > 0) ? this.widths[paramInt] : 1000; }
  
  protected Hashtable pairKern = new Hashtable();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\FontInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */