package inetsoft.report.pdf;

import java.util.Vector;

class Node {
  private String label;
  
  private Node parent;
  
  private Vector children;
  
  private String pageId;
  
  private int pageY;
  
  private int id;
  
  Node(String paramString) {
    this.parent = null;
    this.children = new Vector();
    this.pageId = null;
    this.pageY = 0;
    this.id = 0;
    this.label = paramString;
  }
  
  public Node getChild(int paramInt) { return (Node)this.children.elementAt(paramInt); }
  
  public int getChildCount() { return this.children.size(); }
  
  public int getNodeCount() {
    if (getChildCount() == 0)
      return 0; 
    int i = getChildCount();
    for (byte b = 0; b < getChildCount(); b++)
      i += getChild(b).getNodeCount(); 
    return i;
  }
  
  public Node getParent() { return this.parent; }
  
  void addChild(Node paramNode) {
    if (paramNode.parent != null)
      paramNode.parent.removeChild(paramNode); 
    paramNode.parent = this;
    this.children.addElement(paramNode);
  }
  
  void removeChild(Node paramNode) {
    int i = this.children.indexOf(paramNode);
    if (i >= 0) {
      this.children.removeElementAt(i);
      paramNode.parent = null;
    } 
  }
  
  public void setLabel(String paramString) { this.label = paramString; }
  
  public String getLabel() { return this.label; }
  
  public void setPageID(String paramString) { this.pageId = paramString; }
  
  public String getPageID() { return this.pageId; }
  
  public void setPageY(int paramInt) { this.pageY = paramInt; }
  
  public int getPageY() { return this.pageY; }
  
  public int getID() { return this.id; }
  
  public void setID(int paramInt) { this.id = paramInt; }
  
  public Node getNext() {
    if (this.parent != null)
      for (byte b = 0; b < this.parent.getChildCount(); b++) {
        if (this.parent.getChild(b) == this)
          return (b < this.parent.getChildCount() - 1) ? this.parent.getChild(b + 1) : null; 
      }  
    return null;
  }
  
  public String toString() { return getLabel(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\Node.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */