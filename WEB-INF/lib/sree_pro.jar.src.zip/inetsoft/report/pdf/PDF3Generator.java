/*     */ package inetsoft.report.pdf;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.Paintable;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.ReportEnv;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.internal.PaperSize;
/*     */ import inetsoft.report.internal.TextContext;
/*     */ import inetsoft.report.internal.TextPaintable;
/*     */ import inetsoft.report.internal.Util;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.PrintJob;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PDF3Generator
/*     */ {
/*     */   protected OutputStream output;
/*     */   
/*     */   public static PDF3Generator getPDFGenerator(OutputStream paramOutputStream) {
/*  34 */     String str = Common.isJava2() ? "inetsoft.report.pdf.j2d.PDF4Generator2D" : "inetsoft.report.pdf.PDF4Generator";
/*     */     
/*     */     try {
/*  37 */       PDF3Generator pDF3Generator = (PDF3Generator)Class.forName(str).newInstance();
/*  38 */       pDF3Generator.setOutput(paramOutputStream);
/*     */       
/*  40 */       String str1 = ReportEnv.getProperty("pdf.font.mapping");
/*  41 */       if (str1 != null) {
/*  42 */         String[] arrayOfString = Util.split(str1, ';');
/*  43 */         PDF3Printer pDF3Printer = pDF3Generator.getPrinter();
/*     */         
/*  45 */         for (byte b = 0; b < arrayOfString.length; b++) {
/*  46 */           String[] arrayOfString1 = Util.split(arrayOfString[b], ':');
/*     */           
/*  48 */           if (arrayOfString1.length == 2 && arrayOfString1[0].length() > 0 && arrayOfString1[1].length() > 0) {
/*  49 */             pDF3Printer.putFontName(arrayOfString1[0], arrayOfString1[1]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/*  54 */       return pDF3Generator;
/*     */     } catch (Throwable throwable) {
/*  56 */       throwable.printStackTrace();
/*     */ 
/*     */       
/*  59 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PDF3Generator() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public PDF3Generator(OutputStream paramOutputStream) { this.output = paramOutputStream; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public void setOutput(OutputStream paramOutputStream) { this.output = paramOutputStream; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generate(Enumeration paramEnumeration) {
/*  88 */     Vector vector = new Vector();
/*     */     
/*  90 */     while (paramEnumeration.hasMoreElements()) {
/*  91 */       vector.addElement(paramEnumeration.nextElement());
/*     */     }
/*     */     
/*  94 */     generate(vector);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generate(StyleSheet paramStyleSheet) {
/* 102 */     int i = PaperSize.getOrientation(paramStyleSheet.getProperty("Orientation"));
/*     */     
/* 104 */     Size size = PaperSize.getSize(paramStyleSheet.getProperty("PageSize"));
/* 105 */     if (size != null) {
/* 106 */       setPageSize((i == 0) ? size.rotate() : size);
/*     */     }
/*     */     
/* 109 */     boolean bool = true;
/* 110 */     Vector vector = new Vector();
/*     */     
/* 112 */     Date date = new Date();
/* 113 */     Dimension dimension = getPageDimension();
/*     */     
/* 115 */     paramStyleSheet.reset();
/*     */ 
/*     */     
/* 118 */     while (bool) {
/* 119 */       StylePage stylePage = new StylePage(dimension, 72);
/* 120 */       bool = paramStyleSheet.printNext(stylePage);
/* 121 */       vector.addElement(stylePage);
/*     */     } 
/*     */     
/* 124 */     generate(vector);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generate(Vector paramVector) {
/* 131 */     if (paramVector.size() > 0) {
/* 132 */       Dimension dimension = ((StylePage)paramVector.elementAt(0)).getPageDimension();
/* 133 */       setPageSize(new Size(dimension.width / 72.0D, dimension.height / 72.0D));
/*     */     } 
/*     */     
/* 136 */     int i = (getPageDimension()).height;
/*     */     
/* 138 */     for (byte b1 = 0; b1 < paramVector.size(); b1++) {
/* 139 */       StylePage stylePage = (StylePage)paramVector.elementAt(b1);
/* 140 */       Graphics graphics = getGraphics();
/* 141 */       stylePage.print(graphics);
/* 142 */       graphics.dispose();
/*     */     } 
/*     */     
/* 145 */     Node node1 = new Node(null);
/* 146 */     node1.setID(getPrinter().getNextObjectID());
/* 147 */     Node node2 = node1;
/* 148 */     int j = 0;
/*     */     
/* 150 */     for (byte b2 = 0; b2 < paramVector.size(); b2++) {
/* 151 */       StylePage stylePage = (StylePage)paramVector.elementAt(b2);
/*     */       
/* 153 */       for (byte b = 0; b < stylePage.getPaintableCount(); b++) {
/* 154 */         Paintable paintable = stylePage.getPaintable(b);
/* 155 */         ReportElement reportElement = paintable.getElement();
/*     */         
/* 157 */         if (reportElement instanceof TextContext) {
/* 158 */           int k = ((TextContext)reportElement).getLevel();
/* 159 */           Node node = new Node(((TextPaintable)paintable).getText());
/* 160 */           node.setID(getPrinter().getNextObjectID());
/* 161 */           node.setPageID(getPrinter().getPageID(b2));
/* 162 */           node.setPageY(i - (paintable.getBounds()).y);
/*     */           
/* 164 */           if (k > j) {
/* 165 */             node2.addChild(node);
/*     */           }
/* 167 */           else if (k == j) {
/* 168 */             node2 = node2.getParent();
/* 169 */             if (node2 == null) {
/* 170 */               node2 = node1;
/*     */             }
/*     */             
/* 173 */             node2.addChild(node);
/*     */           } else {
/*     */             
/* 176 */             for (byte b3 = 0; b3 < j - k + 1 && node2 != null; b3++) {
/* 177 */               node2 = node2.getParent();
/*     */             }
/*     */             
/* 180 */             if (node2 == null) {
/* 181 */               node2 = node1;
/*     */             }
/*     */             
/* 184 */             node2.addChild(node);
/*     */           } 
/*     */           
/* 187 */           node2 = node;
/* 188 */           j = k;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 193 */     addBookmark(node1);
/* 194 */     getPrinter().flush();
/*     */     
/* 196 */     getPrinter().setOutlines(node1.getID() + " 0 R");
/*     */     
/* 198 */     getPrinter().close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addBookmark(Node paramNode) {
/* 205 */     String str = "<<\n";
/*     */     
/* 207 */     if (paramNode.getLabel() != null) {
/* 208 */       str = str + "/Title (" + paramNode + ")\n";
/*     */     }
/*     */     
/* 211 */     if (paramNode.getPageID() != null) {
/* 212 */       str = str + "/Dest [" + paramNode.getPageID() + " /FitH " + paramNode.getPageY() + "]\n";
/*     */     }
/*     */ 
/*     */     
/* 216 */     if (paramNode.getParent() != null) {
/* 217 */       str = str + "/Parent " + paramNode.getParent().getID() + " 0 R\n";
/*     */     }
/*     */     
/* 220 */     Node node = paramNode.getNext();
/* 221 */     if (node != null) {
/* 222 */       str = str + "/Next " + node.getID() + " 0 R\n";
/*     */     }
/*     */     
/* 225 */     if (paramNode.getChildCount() > 0) {
/* 226 */       Node node1 = paramNode.getChild(0);
/* 227 */       str = str + "/First " + node1.getID() + " 0 R\n";
/* 228 */       node1 = paramNode.getChild(paramNode.getChildCount() - 1);
/* 229 */       str = str + "/Last " + node1.getID() + " 0 R\n";
/* 230 */       str = str + "/Count " + paramNode.getNodeCount();
/*     */     } 
/*     */     
/* 233 */     str = str + ">>\n";
/*     */     
/* 235 */     getPrinter().addObject(paramNode.getID(), str);
/*     */     
/* 237 */     for (byte b = 0; b < paramNode.getChildCount(); b++) {
/* 238 */       addBookmark(paramNode.getChild(b));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PDF3Printer getPrinter() {
/* 246 */     if (this.printer == null) {
/* 247 */       this.printer = new PDF3Printer(this.output);
/*     */     }
/*     */     
/* 250 */     return this.printer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 257 */   protected Graphics getGraphics() { return getPrinter(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Dimension getPageDimension() {
/* 264 */     if (this.job == null) {
/* 265 */       this.job = getPrinter().getPrintJob();
/*     */     }
/*     */     
/* 268 */     return this.job.getPageDimension();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 276 */   public void setPageSize(Size paramSize) { ((PDFDevice)getGraphics()).setPageSize(paramSize); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 283 */   public Size getPageSize() { return getPrinter().getPageSize(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 291 */   PDF3Printer printer = null;
/* 292 */   PrintJob job = null;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\PDF3Generator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */