package inetsoft.report.pdf;

import inetsoft.report.Common;
import inetsoft.report.Paintable;
import inetsoft.report.ReportElement;
import inetsoft.report.ReportEnv;
import inetsoft.report.Size;
import inetsoft.report.StylePage;
import inetsoft.report.StyleSheet;
import inetsoft.report.internal.PaperSize;
import inetsoft.report.internal.TextContext;
import inetsoft.report.internal.TextPaintable;
import inetsoft.report.internal.Util;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.PrintJob;
import java.io.OutputStream;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;

public class PDF3Generator {
  protected OutputStream output;
  
  public static PDF3Generator getPDFGenerator(OutputStream paramOutputStream) {
    String str = Common.isJava2() ? "inetsoft.report.pdf.j2d.PDF4Generator2D" : "inetsoft.report.pdf.PDF4Generator";
    try {
      PDF3Generator pDF3Generator = (PDF3Generator)Class.forName(str).newInstance();
      pDF3Generator.setOutput(paramOutputStream);
      String str1 = ReportEnv.getProperty("pdf.font.mapping");
      if (str1 != null) {
        String[] arrayOfString = Util.split(str1, ';');
        PDF3Printer pDF3Printer = pDF3Generator.getPrinter();
        for (byte b = 0; b < arrayOfString.length; b++) {
          String[] arrayOfString1 = Util.split(arrayOfString[b], ':');
          if (arrayOfString1.length == 2 && arrayOfString1[0].length() > 0 && arrayOfString1[1].length() > 0)
            pDF3Printer.putFontName(arrayOfString1[0], arrayOfString1[1]); 
        } 
      } 
      return pDF3Generator;
    } catch (Throwable throwable) {
      throwable.printStackTrace();
      return null;
    } 
  }
  
  public PDF3Generator() {}
  
  public PDF3Generator(OutputStream paramOutputStream) { this.output = paramOutputStream; }
  
  public void setOutput(OutputStream paramOutputStream) { this.output = paramOutputStream; }
  
  public void generate(Enumeration paramEnumeration) {
    Vector vector = new Vector();
    while (paramEnumeration.hasMoreElements())
      vector.addElement(paramEnumeration.nextElement()); 
    generate(vector);
  }
  
  public void generate(StyleSheet paramStyleSheet) {
    int i = PaperSize.getOrientation(paramStyleSheet.getProperty("Orientation"));
    Size size = PaperSize.getSize(paramStyleSheet.getProperty("PageSize"));
    if (size != null)
      setPageSize((i == 0) ? size.rotate() : size); 
    boolean bool = true;
    Vector vector = new Vector();
    Date date = new Date();
    Dimension dimension = getPageDimension();
    paramStyleSheet.reset();
    while (bool) {
      StylePage stylePage = new StylePage(dimension, 72);
      bool = paramStyleSheet.printNext(stylePage);
      vector.addElement(stylePage);
    } 
    generate(vector);
  }
  
  public void generate(Vector paramVector) {
    if (paramVector.size() > 0) {
      Dimension dimension = ((StylePage)paramVector.elementAt(0)).getPageDimension();
      setPageSize(new Size(dimension.width / 72.0D, dimension.height / 72.0D));
    } 
    int i = (getPageDimension()).height;
    for (byte b1 = 0; b1 < paramVector.size(); b1++) {
      StylePage stylePage = (StylePage)paramVector.elementAt(b1);
      Graphics graphics = getGraphics();
      stylePage.print(graphics);
      graphics.dispose();
    } 
    Node node1 = new Node(null);
    node1.setID(getPrinter().getNextObjectID());
    Node node2 = node1;
    int j = 0;
    for (byte b2 = 0; b2 < paramVector.size(); b2++) {
      StylePage stylePage = (StylePage)paramVector.elementAt(b2);
      for (byte b = 0; b < stylePage.getPaintableCount(); b++) {
        Paintable paintable = stylePage.getPaintable(b);
        ReportElement reportElement = paintable.getElement();
        if (reportElement instanceof TextContext) {
          int k = ((TextContext)reportElement).getLevel();
          Node node = new Node(((TextPaintable)paintable).getText());
          node.setID(getPrinter().getNextObjectID());
          node.setPageID(getPrinter().getPageID(b2));
          node.setPageY(i - (paintable.getBounds()).y);
          if (k > j) {
            node2.addChild(node);
          } else if (k == j) {
            node2 = node2.getParent();
            if (node2 == null)
              node2 = node1; 
            node2.addChild(node);
          } else {
            for (byte b3 = 0; b3 < j - k + 1 && node2 != null; b3++)
              node2 = node2.getParent(); 
            if (node2 == null)
              node2 = node1; 
            node2.addChild(node);
          } 
          node2 = node;
          j = k;
        } 
      } 
    } 
    addBookmark(node1);
    getPrinter().flush();
    getPrinter().setOutlines(node1.getID() + " 0 R");
    getPrinter().close();
  }
  
  private void addBookmark(Node paramNode) {
    String str = "<<\n";
    if (paramNode.getLabel() != null)
      str = str + "/Title (" + paramNode + ")\n"; 
    if (paramNode.getPageID() != null)
      str = str + "/Dest [" + paramNode.getPageID() + " /FitH " + paramNode.getPageY() + "]\n"; 
    if (paramNode.getParent() != null)
      str = str + "/Parent " + paramNode.getParent().getID() + " 0 R\n"; 
    Node node = paramNode.getNext();
    if (node != null)
      str = str + "/Next " + node.getID() + " 0 R\n"; 
    if (paramNode.getChildCount() > 0) {
      Node node1 = paramNode.getChild(0);
      str = str + "/First " + node1.getID() + " 0 R\n";
      node1 = paramNode.getChild(paramNode.getChildCount() - 1);
      str = str + "/Last " + node1.getID() + " 0 R\n";
      str = str + "/Count " + paramNode.getNodeCount();
    } 
    str = str + ">>\n";
    getPrinter().addObject(paramNode.getID(), str);
    for (byte b = 0; b < paramNode.getChildCount(); b++)
      addBookmark(paramNode.getChild(b)); 
  }
  
  public PDF3Printer getPrinter() {
    if (this.printer == null)
      this.printer = new PDF3Printer(this.output); 
    return this.printer;
  }
  
  protected Graphics getGraphics() { return getPrinter(); }
  
  protected Dimension getPageDimension() {
    if (this.job == null)
      this.job = getPrinter().getPrintJob(); 
    return this.job.getPageDimension();
  }
  
  public void setPageSize(Size paramSize) { ((PDFDevice)getGraphics()).setPageSize(paramSize); }
  
  public Size getPageSize() { return getPrinter().getPageSize(); }
  
  PDF3Printer printer = null;
  
  PrintJob job = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\PDF3Generator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */