/*     */ package inetsoft.report.pdf.j2d;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.Margin;
/*     */ import inetsoft.report.ReportEnv;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.j2d.StyleBook;
/*     */ import inetsoft.report.j2d.StylePrintable;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.FileDialog;
/*     */ import java.awt.print.PageFormat;
/*     */ import java.awt.print.Pageable;
/*     */ import java.awt.print.Paper;
/*     */ import java.awt.print.Printable;
/*     */ import java.awt.print.PrinterException;
/*     */ import java.awt.print.PrinterJob;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PDF3PrinterJob
/*     */   extends PrinterJob
/*     */ {
/*     */   PDF3Printer2D psg;
/*     */   OutputStream output;
/*     */   Printable painter;
/*     */   Pageable book;
/*     */   PageFormat format;
/*     */   Paper paper;
/*     */   int copies;
/*     */   String jobname;
/*     */   String printer;
/*     */   String printOption;
/*     */   String file;
/*     */   boolean toFile;
/*     */   boolean cancelled;
/*     */   PrinterJob defJob;
/*     */   
/*     */   public PDF3PrinterJob() {
/* 506 */     this.painter = null;
/* 507 */     this.book = null;
/* 508 */     this.format = new PageFormat();
/* 509 */     this.paper = new Paper();
/*     */ 
/*     */     
/* 512 */     this.copies = 1;
/* 513 */     this.jobname = "Report";
/* 514 */     this.printer = "";
/* 515 */     this.printOption = "";
/* 516 */     this.file = "report.pdf";
/* 517 */     this.toFile = false;
/*     */     
/* 519 */     this.cancelled = false;
/* 520 */     this.defJob = PrinterJob.getPrinterJob(); this.psg = createPrinter(); this.psg.setPrinterJob(this); } public PDF3PrinterJob(OutputStream paramOutputStream) { this.painter = null; this.book = null; this.format = new PageFormat(); this.paper = new Paper(); this.copies = 1; this.jobname = "Report"; this.printer = ""; this.printOption = ""; this.file = "report.pdf"; this.toFile = false; this.cancelled = false; this.defJob = PrinterJob.getPrinterJob();
/*     */     this.psg = createPrinter();
/*     */     this.psg.setOutput(this.output = paramOutputStream);
/*     */     this.psg.setPrinterJob(this); }
/*     */ 
/*     */   
/*     */   public PDF3PrinterJob(File paramFile) throws IOException { this(new FileOutputStream(paramFile)); }
/*     */   
/*     */   protected PDF3Printer2D createPrinter() { return new PDF3Printer2D(); }
/*     */   
/*     */   public PDF3Printer2D getPrinter2D() { return this.psg; }
/*     */   
/*     */   public void setPageSize(double paramDouble1, double paramDouble2) { this.paper.setSize(paramDouble1 * 72.0D, paramDouble2 * 72.0D); }
/*     */   
/*     */   public void setPageSize(Size paramSize) { setPageSize(paramSize.width, paramSize.height); }
/*     */   
/*     */   public Size getPageSize() { return new Size(this.paper.getWidth() / 72.0D, this.paper.getHeight() / 72.0D); }
/*     */   
/*     */   public void setCompressText(boolean paramBoolean) { this.psg.setCompressText(paramBoolean); }
/*     */   
/*     */   public boolean isCompressText() { return this.psg.isCompressText(); }
/*     */   
/*     */   public void setAsciiOnly(boolean paramBoolean) { this.psg.setAsciiOnly(paramBoolean); }
/*     */   
/*     */   public boolean isAsciiOnly() { return this.psg.isAsciiOnly(); }
/*     */   
/*     */   public void setCompressImage(boolean paramBoolean) { this.psg.setCompressImage(paramBoolean); }
/*     */   
/*     */   public boolean isCompressImage() { return this.psg.isCompressImage(); }
/*     */   
/*     */   public void setBase14Only(boolean paramBoolean) { this.psg.setBase14Only(paramBoolean); }
/*     */   
/*     */   public boolean isBase14Only() { return this.psg.isBase14Only(); }
/*     */   
/*     */   public void setEmbedFont(boolean paramBoolean) { this.psg.setEmbedFont(paramBoolean); }
/*     */   
/*     */   public boolean isEmbedFont() { return this.psg.isEmbedFont(); }
/*     */   
/*     */   public void setPrintable(Printable paramPrintable) { this.painter = paramPrintable; }
/*     */   
/*     */   public void setPrintable(Printable paramPrintable, PageFormat paramPageFormat) {
/*     */     setPrintable(paramPrintable);
/*     */     this.format = paramPageFormat;
/*     */   }
/*     */   
/*     */   public void setPageable(Pageable paramPageable) throws NullPointerException { this.book = paramPageable; }
/*     */   
/*     */   public boolean printDialog() {
/*     */     FileDialog fileDialog = new FileDialog(Common.getInvisibleFrame(), Catalog.getString("PDF File"), 1);
/*     */     fileDialog.setFile(this.jobname + ".pdf");
/*     */     fileDialog.setDirectory(".");
/*     */     fileDialog.pack();
/*     */     fileDialog.setVisible(true);
/*     */     String str = fileDialog.getFile();
/*     */     if (str != null)
/*     */       try {
/*     */         File file1 = new File(fileDialog.getDirectory(), str);
/*     */         this.psg.setOutput(this.output = new FileOutputStream(file1));
/*     */         return true;
/*     */       } catch (Exception exception) {
/*     */         exception.printStackTrace();
/*     */       }  
/*     */     return false;
/*     */   }
/*     */   
/*     */   public PageFormat pageDialog(PageFormat paramPageFormat) { return this.defJob.pageDialog(paramPageFormat); }
/*     */   
/*     */   public PageFormat defaultPage(PageFormat paramPageFormat) {
/*     */     PageFormat pageFormat = (PageFormat)paramPageFormat.clone();
/*     */     pageFormat.setPaper(this.paper);
/*     */     return pageFormat;
/*     */   }
/*     */   
/*     */   public PageFormat validatePage(PageFormat paramPageFormat) {
/*     */     paramPageFormat.setPaper(this.paper);
/*     */     return paramPageFormat;
/*     */   }
/*     */   
/*     */   public void print() {
/*     */     try {
/*     */       if (this.output == null || this.toFile)
/*     */         this.psg.setOutput(this.output = new FileOutputStream(this.file)); 
/*     */     } catch (Exception exception) {
/*     */       throw new PrinterException(exception.toString());
/*     */     } 
/*     */     synchronized (StyleSheet.class) {
/*     */       Margin margin = StyleSheet.getPrinterMargin();
/*     */       if (this.book != null) {
/*     */         if (this.book instanceof StyleBook) {
/*     */           Margin margin1 = ((StyleBook)this.book).getMargin();
/*     */           StyleSheet.setPrinterMargin(margin1);
/*     */         } 
/*     */         boolean bool = true;
/*     */         int i = this.book.getNumberOfPages();
/*     */         this.psg.startDoc();
/*     */         for (byte b = bool; b <= i; b++) {
/*     */           byte b1 = b - true;
/*     */           PageFormat pageFormat = this.book.getPageFormat(b1);
/*     */           if (pageFormat.getOrientation() == 0) {
/*     */             this.psg.setPageSize(pageFormat.getPaper().getHeight() / 72.0D, pageFormat.getPaper().getWidth() / 72.0D);
/*     */           } else {
/*     */             this.psg.setPageSize(pageFormat.getPaper().getWidth() / 72.0D, pageFormat.getPaper().getHeight() / 72.0D);
/*     */           } 
/*     */           this.book.getPrintable(b1).print(this.psg, pageFormat, b);
/*     */           this.psg.dispose();
/*     */         } 
/*     */       } else if (this.painter != null) {
/*     */         if (this.painter instanceof StylePrintable)
/*     */           StyleSheet.setPrinterMargin(((StylePrintable)this.painter).getMargin()); 
/*     */         this.psg.startDoc();
/*     */         if (this.format.getOrientation() == 0) {
/*     */           this.psg.setPageSize(this.format.getPaper().getHeight() / 72.0D, this.format.getPaper().getWidth() / 72.0D);
/*     */         } else {
/*     */           this.psg.setPageSize(this.format.getPaper().getWidth() / 72.0D, this.format.getPaper().getHeight() / 72.0D);
/*     */         } 
/*     */         byte b = 0;
/*     */         for (; this.painter.print(this.psg, this.format, b) != 1; b++)
/*     */           this.psg.dispose(); 
/*     */       } 
/*     */       StyleSheet.setPrinterMargin(margin);
/*     */       this.psg.close();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setCopies(int paramInt) { this.copies = paramInt; }
/*     */   
/*     */   public int getCopies() { return this.copies; }
/*     */   
/*     */   public String getUserName() {
/*     */     try {
/*     */       return ReportEnv.getProperty("user.name");
/*     */     } catch (Exception exception) {
/*     */       return "Unknown";
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setJobName(String paramString) { this.jobname = paramString; }
/*     */   
/*     */   public String getJobName() { return this.jobname; }
/*     */   
/*     */   public void setFile(String paramString) { this.file = paramString; }
/*     */   
/*     */   public String getFile() { return this.file; }
/*     */   
/*     */   public void setPrintToFile(boolean paramBoolean) { this.toFile = paramBoolean; }
/*     */   
/*     */   public boolean isPrintToFile() { return this.toFile; }
/*     */   
/*     */   public void setPrinter(String paramString) { this.printer = paramString; }
/*     */   
/*     */   public String getPrinter() { return this.printer; }
/*     */   
/*     */   public void cancel() { this.cancelled = true; }
/*     */   
/*     */   public boolean isCancelled() { return this.cancelled; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\j2d\PDF3PrinterJob.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */