package inetsoft.report.pdf.j2d;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class PDF4PrinterJob extends PDF3PrinterJob {
  public PDF4PrinterJob() {}
  
  public PDF4PrinterJob(OutputStream paramOutputStream) { super(paramOutputStream); }
  
  public PDF4PrinterJob(File paramFile) throws IOException { this(new FileOutputStream(paramFile)); }
  
  protected PDF3Printer2D createPrinter() { return new PDF4Printer2D(); }
  
  public void setEmbedCMap(boolean paramBoolean) { ((PDF4Printer2D)this.psg).setEmbedCMap(paramBoolean); }
  
  public boolean isEmbedCMap() { return ((PDF4Printer2D)this.psg).isEmbedCMap(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\j2d\PDF4PrinterJob.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */