/*    */ package inetsoft.report.pdf.j2d;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PDF4PrinterJob
/*    */   extends PDF3PrinterJob
/*    */ {
/*    */   public PDF4PrinterJob() {}
/*    */   
/* 46 */   public PDF4PrinterJob(OutputStream paramOutputStream) { super(paramOutputStream); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public PDF4PrinterJob(File paramFile) throws IOException { this(new FileOutputStream(paramFile)); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 60 */   protected PDF3Printer2D createPrinter() { return new PDF4Printer2D(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 68 */   public void setEmbedCMap(boolean paramBoolean) { ((PDF4Printer2D)this.psg).setEmbedCMap(paramBoolean); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 75 */   public boolean isEmbedCMap() { return ((PDF4Printer2D)this.psg).isEmbedCMap(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\j2d\PDF4PrinterJob.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */