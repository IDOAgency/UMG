package inetsoft.report.pdf.j2d;

import inetsoft.report.pdf.PDF3Printer;
import java.awt.Graphics;
import java.io.OutputStream;

public class PDF4Generator2D extends PDF3Generator2D {
  public PDF4Generator2D() {}
  
  public PDF4Generator2D(OutputStream paramOutputStream) { super(paramOutputStream); }
  
  public PDF3Printer getPrinter() {
    getGraphics();
    return this.printer.getPrinter();
  }
  
  protected Graphics getGraphics() {
    if (this.printer == null)
      this.printer = new PDF4Printer2D(this.output); 
    return this.printer;
  }
  
  PDF4Printer2D printer = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\j2d\PDF4Generator2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */