/*    */ package inetsoft.report.pdf.j2d;
/*    */ 
/*    */ import inetsoft.report.pdf.PDF3Generator;
/*    */ import inetsoft.report.pdf.PDF3Printer;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PDF3Generator2D
/*    */   extends PDF3Generator
/*    */ {
/*    */   public PDF3Generator2D() {}
/*    */   
/* 42 */   public PDF3Generator2D(OutputStream paramOutputStream) { super(paramOutputStream); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PDF3Printer getPrinter() {
/* 49 */     getGraphics();
/* 50 */     return this.printer.getPrinter();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Graphics getGraphics() {
/* 57 */     if (this.printer == null) {
/* 58 */       this.printer = new PDF3Printer2D(this.output);
/*    */     }
/*    */     
/* 61 */     return this.printer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 68 */   protected Dimension getPageDimension() { return getPrinter().getPrintJob().getPageDimension(); }
/*    */ 
/*    */   
/* 71 */   PDF3Printer2D printer = null;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\j2d\PDF3Generator2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */