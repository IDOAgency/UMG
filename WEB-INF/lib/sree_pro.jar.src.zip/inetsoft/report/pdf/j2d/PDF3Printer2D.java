package inetsoft.report.pdf.j2d;

import inetsoft.report.Size;
import inetsoft.report.internal.Util;
import inetsoft.report.pdf.PDF3Printer;
import inetsoft.report.pdf.PDFDevice;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Polygon;
import java.awt.PrintJob;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.TexturePaint;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ImageObserver;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderableImage;
import java.awt.print.PrinterJob;
import java.io.OutputStream;
import java.text.AttributedCharacterIterator;
import java.util.Map;

public class PDF3Printer2D extends Graphics2D implements PDFDevice {
  PDF3Printer psg;
  
  AffineTransform trans;
  
  AffineTransform ptrans;
  
  FontRenderContext fontContext;
  
  Stroke stroke;
  
  Rectangle2D clipping;
  
  Paint brush;
  
  Color bg;
  
  Color fg;
  
  PrinterJob job;
  
  public PDF3Printer2D() {
    this.trans = new AffineTransform();
    this.ptrans = new AffineTransform();
    this.fontContext = new FontRenderContext(new AffineTransform(), true, true);
    this.stroke = new BasicStroke();
    this.clipping = null;
    this.brush = Color.black;
    this.bg = Color.white;
    this.fg = Color.black;
    this.psg = createPrinter();
    ((PrinterImpl)this.psg).setOuter(this);
    Rectangle rectangle = this.psg.getClipBounds();
    this.clipping = new Rectangle2D.Double(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
  }
  
  public PDF3Printer2D(OutputStream paramOutputStream) {
    this();
    this.psg.setOutput(paramOutputStream);
    this.psg.startDoc();
  }
  
  protected PDF3Printer createPrinter() { return new PDF3Printer2(); }
  
  public PDF3Printer getPrinter() { return this.psg; }
  
  public PrinterJob getPrinterJob() { return this.job; }
  
  public void setPrinterJob(PrinterJob paramPrinterJob) { this.job = paramPrinterJob; }
  
  public PrintJob getPrintJob() { return this.psg.getPrintJob(); }
  
  public void setPageSize(double paramDouble1, double paramDouble2) {
    this.psg.setPageSize(paramDouble1, paramDouble2);
    Rectangle rectangle = this.psg.getClipBounds();
    this.clipping = new Rectangle2D.Double(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
  }
  
  public Size getPageSize() { return this.psg.getPageSize(); }
  
  public void setPageSize(Size paramSize) { setPageSize(paramSize.width, paramSize.height); }
  
  public void setCompressText(boolean paramBoolean) { this.psg.setCompressText(paramBoolean); }
  
  public boolean isCompressText() { return this.psg.isCompressText(); }
  
  public void setAsciiOnly(boolean paramBoolean) { this.psg.setAsciiOnly(paramBoolean); }
  
  public boolean isAsciiOnly() { return this.psg.isAsciiOnly(); }
  
  public void setCompressImage(boolean paramBoolean) { this.psg.setCompressImage(paramBoolean); }
  
  public boolean isCompressImage() { return this.psg.isCompressImage(); }
  
  public void setBase14Only(boolean paramBoolean) { this.psg.setBase14Only(paramBoolean); }
  
  public boolean isBase14Only() { return this.psg.isBase14Only(); }
  
  public void setEmbedFont(boolean paramBoolean) { this.psg.setEmbedFont(paramBoolean); }
  
  public boolean isEmbedFont() { return this.psg.isEmbedFont(); }
  
  public void setMapSymbols(boolean paramBoolean) { this.psg.setMapSymbols(paramBoolean); }
  
  public boolean isMapSymbols() { return this.psg.isMapSymbols(); }
  
  public String getFontName(Font paramFont) { return this.psg.getFontName(paramFont); }
  
  public void putFontName(String paramString1, String paramString2) { this.psg.putFontName(paramString1, paramString2); }
  
  public void startDoc() { this.psg.startDoc(); }
  
  public void setOutput(OutputStream paramOutputStream) { this.psg.setOutput(paramOutputStream); }
  
  public void close() { this.psg.close(); }
  
  public Graphics create() {
    try {
      PDF3Printer2D pDF3Printer2D = (PDF3Printer2D)clone();
      pDF3Printer2D.ptrans = new AffineTransform(this.ptrans);
      pDF3Printer2D.ptrans.concatenate(this.trans);
      pDF3Printer2D.trans = new AffineTransform();
      pDF3Printer2D.psg = (PDF3Printer)this.psg.create();
      ((PrinterImpl)pDF3Printer2D.psg).setOuter(pDF3Printer2D);
      return pDF3Printer2D;
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public Graphics create(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    PDF3Printer2D pDF3Printer2D = (PDF3Printer2D)create();
    pDF3Printer2D.ptrans.translate(paramInt1, paramInt2);
    pDF3Printer2D.psg.checkTextObj(false);
    pDF3Printer2D.psg.emit("1 0 0 1 " + Util.toString(paramInt1, 3) + " " + Util.toString(-paramInt2, 3) + " cm");
    ((PrinterImpl)pDF3Printer2D.psg).emitClip(0.0D, 0.0D, paramInt3, paramInt4);
    pDF3Printer2D.clipping = new Rectangle2D.Double(0.0D, 0.0D, paramInt3, paramInt4);
    pDF3Printer2D.transformRect((Rectangle2D.Double)pDF3Printer2D.clipping, false);
    return pDF3Printer2D;
  }
  
  public void draw(Shape paramShape) {
    if (paramShape instanceof Arc2D) {
      Arc2D arc2D = (Arc2D)paramShape;
      this.psg.drawArc(arc2D.getX(), arc2D.getY(), arc2D.getWidth(), arc2D.getHeight(), arc2D.getAngleStart(), arc2D.getAngleExtent());
    } else if (paramShape instanceof Ellipse2D) {
      Ellipse2D ellipse2D = (Ellipse2D)paramShape;
      this.psg.drawOval(ellipse2D.getX(), ellipse2D.getY(), ellipse2D.getWidth(), ellipse2D.getHeight());
    } else if (paramShape instanceof Line2D) {
      Line2D line2D = (Line2D)paramShape;
      this.psg.drawLine(line2D.getX1(), line2D.getY1(), line2D.getX2(), line2D.getY2());
    } else if (paramShape instanceof Rectangle2D) {
      Rectangle2D rectangle2D = (Rectangle2D)paramShape;
      this.psg.drawRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    } else if (paramShape instanceof RoundRectangle2D) {
      RoundRectangle2D roundRectangle2D = (RoundRectangle2D)paramShape;
      this.psg.drawRoundRect(roundRectangle2D.getX(), roundRectangle2D.getY(), roundRectangle2D.getWidth(), roundRectangle2D.getHeight(), roundRectangle2D.getArcWidth(), roundRectangle2D.getArcHeight());
    } else if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      this.psg.drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } else if (paramShape instanceof Polygon) {
      Polygon polygon = (Polygon)paramShape;
      this.psg.drawPolygon(polygon.xpoints, polygon.ypoints, polygon.npoints);
    } else {
      throw new RuntimeException("Drapsg of " + paramShape.getClass().getName() + " not supported by PDF3Printer2D");
    } 
  }
  
  public boolean drawImage(Image paramImage, AffineTransform paramAffineTransform, ImageObserver paramImageObserver) {
    this.psg.gsave();
    emitcm(paramAffineTransform);
    drawImage(paramImage, 0, 0, paramImageObserver);
    this.psg.grestore();
    return true;
  }
  
  public void drawImage(BufferedImage paramBufferedImage, BufferedImageOp paramBufferedImageOp, int paramInt1, int paramInt2) { throw new RuntimeException("drawImage(BufferedImage, BufferedImageOp, int, int) not supported by PDF3Printer2D"); }
  
  public void drawRenderedImage(RenderedImage paramRenderedImage, AffineTransform paramAffineTransform) {
    this.psg.gsave();
    emitcm(paramAffineTransform);
    drawImage((Image)paramRenderedImage, 0, 0, null);
    this.psg.grestore();
  }
  
  public void drawRenderableImage(RenderableImage paramRenderableImage, AffineTransform paramAffineTransform) {
    this.psg.gsave();
    emitcm(paramAffineTransform);
    drawImage((Image)paramRenderableImage, 0, 0, null);
    this.psg.grestore();
  }
  
  public void drawString(String paramString, float paramFloat1, float paramFloat2) { this.psg.drawString(paramString, paramFloat1, paramFloat2); }
  
  public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, int paramInt1, int paramInt2) { throw new RuntimeException("drawString(AttributedCharactorIterator, int, int) not supported by PDF3Printer2D"); }
  
  public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, float paramFloat1, float paramFloat2) { throw new RuntimeException("drawString(AttributedCharactorIterator, float, float) not supported by PDF3Printer2D"); }
  
  public void drawGlyphVector(GlyphVector paramGlyphVector, float paramFloat1, float paramFloat2) { throw new RuntimeException("drawGlyphVector(GlyphVector, float, float) not supported by PDF3Printer2D"); }
  
  public void fill(Shape paramShape) {
    if (paramShape instanceof Arc2D) {
      Arc2D arc2D = (Arc2D)paramShape;
      this.psg.fillArc(arc2D.getX(), arc2D.getY(), arc2D.getWidth(), arc2D.getHeight(), arc2D.getAngleStart(), arc2D.getAngleExtent());
    } else if (paramShape instanceof Ellipse2D) {
      Ellipse2D ellipse2D = (Ellipse2D)paramShape;
      this.psg.fillOval(ellipse2D.getX(), ellipse2D.getY(), ellipse2D.getWidth(), ellipse2D.getHeight());
    } else if (paramShape instanceof Rectangle2D) {
      Rectangle2D rectangle2D = (Rectangle2D)paramShape;
      this.psg.fillRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    } else if (paramShape instanceof RoundRectangle2D) {
      RoundRectangle2D roundRectangle2D = (RoundRectangle2D)paramShape;
      this.psg.fillRoundRect(roundRectangle2D.getX(), roundRectangle2D.getY(), roundRectangle2D.getWidth(), roundRectangle2D.getHeight(), roundRectangle2D.getArcWidth(), roundRectangle2D.getArcHeight());
    } else if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      this.psg.fillRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } else if (paramShape instanceof Polygon) {
      Polygon polygon = (Polygon)paramShape;
      this.psg.fillPolygon(polygon.xpoints, polygon.ypoints, polygon.npoints);
    } else {
      throw new RuntimeException("Filling of " + paramShape.getClass().getName() + " not supported by PDF3Printer2D");
    } 
  }
  
  public boolean hit(Rectangle paramRectangle, Shape paramShape, boolean paramBoolean) { throw new RuntimeException("hit(Rectangle, Shape, boolean) not supported by PDF3Printer2D"); }
  
  public GraphicsConfiguration getDeviceConfiguration() { throw new RuntimeException("getDeviceConfiguration() not supported by PDF3Printer2D"); }
  
  public void setComposite(Composite paramComposite) { throw new RuntimeException("setComposite() not supported by PDF3Printer2D"); }
  
  public void setPaint(Paint paramPaint) {
    this.brush = paramPaint;
    if (this.brush instanceof TexturePaint) {
      BufferedImage bufferedImage = ((TexturePaint)this.brush).getImage();
    } else if (this.brush instanceof Color) {
      setColor((Color)this.brush);
    } else if (paramPaint != null) {
      throw new RuntimeException("Paint is supported: " + paramPaint);
    } 
  }
  
  public void setStroke(Stroke paramStroke) {
    if (this.stroke != null && paramStroke != null && this.stroke.equals(paramStroke))
      return; 
    this.stroke = paramStroke;
    if (this.stroke instanceof BasicStroke) {
      BasicStroke basicStroke = (BasicStroke)this.stroke;
      float[] arrayOfFloat = basicStroke.getDashArray();
      int i = (arrayOfFloat != null && arrayOfFloat.length > 0) ? (int)arrayOfFloat[0] : 0;
      this.psg.checkTextObj(false);
      emit(basicStroke.getLineWidth() + " w");
      if (i > 0) {
        emit("[ " + i + " " + i + " ] 0 d");
      } else {
        emit("[ ] 0 d");
      } 
      switch (basicStroke.getEndCap()) {
        case 0:
          emit("0 J");
          break;
        case 1:
          emit("1 J");
          break;
        case 2:
          emit("2 J");
          break;
      } 
      switch (basicStroke.getLineJoin()) {
        case 0:
          emit("0 j");
          break;
        case 1:
          emit("1 j");
          break;
        case 2:
          emit("2 j");
          break;
      } 
    } else {
      throw new RuntimeException("Only BasicStroke is supported by PDF3Printer2D");
    } 
  }
  
  public void setRenderingHint(RenderingHints.Key paramKey, Object paramObject) {}
  
  public Object getRenderingHint(RenderingHints.Key paramKey) { return null; }
  
  public void setRenderingHints(Map paramMap) {}
  
  public void addRenderingHints(Map paramMap) {}
  
  public RenderingHints getRenderingHints() { return null; }
  
  public void translate(int paramInt1, int paramInt2) { translate(paramInt1, paramInt2); }
  
  public void translate(double paramDouble1, double paramDouble2) {
    this.trans.translate(paramDouble1, paramDouble2);
    this.psg.checkTextObj(false);
    this.psg.gsave(4);
    this.psg.emit("1 0 0 1 " + Util.toString(paramDouble1, 3) + " " + Util.toString(-paramDouble2, 3) + " cm");
  }
  
  public void rotate(double paramDouble) {
    this.trans.rotate(paramDouble);
    paramDouble = -paramDouble;
    double d1 = Math.cos(paramDouble);
    double d2 = Math.sin(paramDouble);
    this.psg.checkTextObj(false);
    this.psg.gsave(4);
    this.psg.emit(Util.toString(d1, 6) + " " + Util.toString(d2, 6) + " " + Util.toString(-d2, 6) + " " + Util.toString(d1, 6) + " 0 0 cm");
  }
  
  public void rotate(double paramDouble1, double paramDouble2, double paramDouble3) {
    AffineTransform affineTransform = new AffineTransform();
    affineTransform.rotate(paramDouble1, paramDouble2, paramDouble3);
    transform(affineTransform);
  }
  
  public void scale(double paramDouble1, double paramDouble2) {
    this.trans.scale(paramDouble1, paramDouble2);
    this.psg.checkTextObj(false);
    this.psg.gsave(4);
    this.psg.emit(Util.toString(paramDouble1, 3) + " 0 0 " + Util.toString(paramDouble2, 3) + " 0 0 cm");
  }
  
  public void shear(double paramDouble1, double paramDouble2) {
    AffineTransform affineTransform = new AffineTransform();
    affineTransform.shear(paramDouble1, paramDouble2);
    transform(affineTransform);
  }
  
  public void transform(AffineTransform paramAffineTransform) {
    this.psg.gsave(4);
    this.trans.concatenate(paramAffineTransform);
    emitcm(paramAffineTransform);
  }
  
  public void setTransform(AffineTransform paramAffineTransform) {
    this.psg.grestore(4);
    this.psg.gsave(4);
    this.trans = paramAffineTransform;
    emitcm(paramAffineTransform);
    setClip(getClip());
  }
  
  public AffineTransform getTransform() { return new AffineTransform(this.trans); }
  
  protected void emitcm(AffineTransform paramAffineTransform) {
    double[] arrayOfDouble = new double[6];
    paramAffineTransform.getMatrix(arrayOfDouble);
    this.psg.checkTextObj(false);
    emit(Util.toString(arrayOfDouble[0], 3) + " " + Util.toString(-arrayOfDouble[1], 3) + " " + Util.toString(-arrayOfDouble[2], 3) + " " + Util.toString(arrayOfDouble[3], 3) + " " + Util.toString(arrayOfDouble[4], 3) + " " + Util.toString(-arrayOfDouble[5], 3) + " cm");
  }
  
  public Paint getPaint() { return this.brush; }
  
  public Composite getComposite() { return null; }
  
  public void setColor(Color paramColor) {
    this.fg = paramColor;
    this.brush = paramColor;
    this.psg.setColor(this.fg);
    setStroke(getStroke());
  }
  
  public Color getColor() { return this.fg; }
  
  public void setBackground(Color paramColor) { this.bg = paramColor; }
  
  public Color getBackground() { return this.bg; }
  
  public Stroke getStroke() { return this.stroke; }
  
  public boolean isSupported(int paramInt) { return true; }
  
  public void setClip(Shape paramShape) {
    if (paramShape instanceof Rectangle2D) {
      Rectangle2D rectangle2D = (Rectangle2D)paramShape;
      setClip(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    } else if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      setClip(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } else {
      throw new RuntimeException("Clipping of " + paramShape.getClass().getName() + " not supported by PDF3Printer2D");
    } 
  }
  
  public void clip(Shape paramShape) {
    if (paramShape instanceof Rectangle2D) {
      Rectangle2D rectangle2D = (Rectangle2D)paramShape;
      clipRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    } else if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      clipRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } else {
      throw new RuntimeException("Clipping of " + paramShape.getClass().getName() + " not supported by PDF3Printer2D");
    } 
  }
  
  public FontRenderContext getFontRenderContext() { return this.fontContext; }
  
  public void clipRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { clipRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void clipRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    Rectangle2D.Double double = new Rectangle2D.Double(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    transformRect(double, false);
    this.clipping = this.clipping.createIntersection(double);
    this.psg.clipRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
  }
  
  public void setClip(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { setClip(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void setClip(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    Rectangle2D.Double double = new Rectangle2D.Double(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    transformRect(double, false);
    this.clipping = double;
    this.psg.setClip(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
  }
  
  void emit(String paramString) { this.psg.emit(paramString); }
  
  public void setPaintMode() { this.psg.setPaintMode(); }
  
  public void setXORMode(Color paramColor) { this.psg.setXORMode(paramColor); }
  
  public Font getFont() { return this.psg.getFont(); }
  
  public void setFont(Font paramFont) { this.psg.setFont(paramFont); }
  
  public FontMetrics getFontMetrics(Font paramFont) { return this.psg.getFontMetrics(paramFont); }
  
  public Rectangle getClipBounds() {
    Rectangle2D.Double double = new Rectangle2D.Double();
    double.setRect(this.clipping);
    transformRect(double, true);
    return new Rectangle((int)double.getX(), (int)double.getY(), (int)double.getWidth(), (int)double.getHeight());
  }
  
  public Shape getClip() { return getClipBounds(); }
  
  public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.copyArea(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.drawLine(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void fillRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.fillRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void clearRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.clearRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void drawRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.drawRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void fillRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.fillRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void drawOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.drawOval(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void fillOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.fillOval(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void drawArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.drawArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void fillArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.fillArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void drawPolyline(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.psg.drawPolyline(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
  
  public void drawPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.psg.drawPolygon(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
  
  public void fillPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.psg.fillPolygon(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
  
  public void drawString(String paramString, int paramInt1, int paramInt2) { this.psg.drawString(paramString, paramInt1, paramInt2); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramImageObserver); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, Color paramColor, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramColor, paramImageObserver); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramColor, paramImageObserver); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, Color paramColor, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramColor, paramImageObserver); }
  
  public void dispose() {
    this.psg.dispose();
    this.stroke = new BasicStroke();
  }
  
  protected void transformRect(Rectangle2D.Double paramDouble, boolean paramBoolean) {
    Point2D point2D1 = new Point2D.Double(paramDouble.getX(), paramDouble.getY());
    Point2D point2D2 = new Point2D.Double(paramDouble.getX() + paramDouble.getWidth(), paramDouble.getY() + paramDouble.getHeight());
    if (paramBoolean) {
      try {
        point2D1 = this.trans.inverseTransform(point2D1, null);
        point2D2 = this.trans.inverseTransform(point2D2, null);
        point2D1 = this.ptrans.inverseTransform(point2D1, null);
        point2D2 = this.ptrans.inverseTransform(point2D2, null);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } else {
      point2D1 = this.ptrans.transform(point2D1, null);
      point2D2 = this.ptrans.transform(point2D2, null);
      point2D1 = this.trans.transform(point2D1, null);
      point2D2 = this.trans.transform(point2D2, null);
    } 
    paramDouble.x = point2D1.getX();
    paramDouble.y = point2D1.getY();
    paramDouble.width = point2D2.getX() - point2D1.getX();
    paramDouble.height = point2D2.getY() - point2D1.getY();
  }
  
  static class PDF3Printer2 extends PDF3Printer implements PrinterImpl {
    PDF3Printer2D outer;
    
    public int grestore(int param1Int) {
      int i = super.grestore(param1Int);
      if (i > 0) {
        this.outer.setStroke(this.outer.stroke);
        this.outer.setPaint(this.outer.brush);
      } 
      return i;
    }
    
    public void setClip(double param1Double1, double param1Double2, double param1Double3, double param1Double4) {
      startPage();
      checkTextObj(false);
      grestore(4);
      Rectangle2D.Double double = new Rectangle2D.Double(param1Double1, param1Double2, param1Double3, param1Double4);
      this.outer.transformRect(double, false);
      this.clippingRect = new Rectangle((int)double.getX() + this.center.x, (int)double.getY() + this.center.y, (int)double.getWidth(), (int)double.getHeight());
      gsave(4);
      this.outer.emitcm(this.outer.trans);
      emitClip(param1Double1, param1Double2, param1Double3, param1Double4);
    }
    
    public void emitClip(double param1Double1, double param1Double2, double param1Double3, double param1Double4) { super.emitClip(param1Double1, param1Double2, param1Double3, param1Double4); }
    
    public void setOuter(PDF3Printer2D param1PDF3Printer2D) { this.outer = param1PDF3Printer2D; }
  }
  
  static AffineTransform psmatrix = new AffineTransform();
  
  static  {
    psmatrix.scale(1.0D, -1.0D);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\j2d\PDF3Printer2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */