package inetsoft.report.pdf.j2d;

import inetsoft.report.pdf.PDF3Printer;
import inetsoft.report.pdf.PDF4Printer;
import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;
import java.io.OutputStream;

public class PDF4Printer2D extends PDF3Printer2D {
  protected PDF4Printer2 psg;
  
  public PDF4Printer2D() {}
  
  public PDF4Printer2D(OutputStream paramOutputStream) { super(paramOutputStream); }
  
  public void setEmbedCMap(boolean paramBoolean) { this.psg.setEmbedCMap(paramBoolean); }
  
  public boolean isEmbedCMap() { return this.psg.isEmbedCMap(); }
  
  protected PDF3Printer createPrinter() { return this.psg = new PDF4Printer2(); }
  
  static class PDF4Printer2 extends PDF4Printer implements PrinterImpl {
    PDF3Printer2D outer;
    
    public int grestore(int param1Int) {
      int i = super.grestore(param1Int);
      if (i > 0) {
        this.outer.setStroke(this.outer.stroke);
        this.outer.setPaint(this.outer.brush);
      } 
      return i;
    }
    
    public void setClip(double param1Double1, double param1Double2, double param1Double3, double param1Double4) {
      startPage();
      checkTextObj(false);
      grestore(4);
      Rectangle2D.Double double = new Rectangle2D.Double(param1Double1, param1Double2, param1Double3, param1Double4);
      this.outer.transformRect(double, false);
      this.clippingRect = new Rectangle((int)double.getX() + this.center.x, (int)double.getY() + this.center.y, (int)double.getWidth(), (int)double.getHeight());
      gsave(4);
      this.outer.emitcm(this.outer.trans);
      emitClip(param1Double1, param1Double2, param1Double3, param1Double4);
    }
    
    public void emitClip(double param1Double1, double param1Double2, double param1Double3, double param1Double4) { super.emitClip(param1Double1, param1Double2, param1Double3, param1Double4); }
    
    public void setOuter(PDF3Printer2D param1PDF3Printer2D) { this.outer = param1PDF3Printer2D; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\j2d\PDF4Printer2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */