/*     */ package inetsoft.report.pdf.j2d;
/*     */ 
/*     */ import inetsoft.report.pdf.PDF3Printer;
/*     */ import inetsoft.report.pdf.PDF4Printer;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PDF4Printer2D
/*     */   extends PDF3Printer2D
/*     */ {
/*     */   protected PDF4Printer2 psg;
/*     */   
/*     */   public PDF4Printer2D() {}
/*     */   
/*  51 */   public PDF4Printer2D(OutputStream paramOutputStream) { super(paramOutputStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public void setEmbedCMap(boolean paramBoolean) { this.psg.setEmbedCMap(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public boolean isEmbedCMap() { return this.psg.isEmbedCMap(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   protected PDF3Printer createPrinter() { return this.psg = new PDF4Printer2(); }
/*     */ 
/*     */   
/*     */   static class PDF4Printer2
/*     */     extends PDF4Printer
/*     */     implements PrinterImpl
/*     */   {
/*     */     PDF3Printer2D outer;
/*     */     
/*     */     public int grestore(int param1Int) {
/*  83 */       int i = super.grestore(param1Int);
/*  84 */       if (i > 0) {
/*     */         
/*  86 */         this.outer.setStroke(this.outer.stroke);
/*  87 */         this.outer.setPaint(this.outer.brush);
/*     */       } 
/*     */       
/*  90 */       return i;
/*     */     }
/*     */     
/*     */     public void setClip(double param1Double1, double param1Double2, double param1Double3, double param1Double4) {
/*  94 */       startPage();
/*     */       
/*  96 */       checkTextObj(false);
/*  97 */       grestore(4);
/*     */       
/*  99 */       Rectangle2D.Double double = new Rectangle2D.Double(param1Double1, param1Double2, param1Double3, param1Double4);
/* 100 */       this.outer.transformRect(double, false);
/* 101 */       this.clippingRect = new Rectangle((int)double.getX() + this.center.x, (int)double.getY() + this.center.y, (int)double.getWidth(), (int)double.getHeight());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 106 */       gsave(4);
/*     */ 
/*     */       
/* 109 */       this.outer.emitcm(this.outer.trans);
/* 110 */       emitClip(param1Double1, param1Double2, param1Double3, param1Double4);
/*     */     }
/*     */ 
/*     */     
/* 114 */     public void emitClip(double param1Double1, double param1Double2, double param1Double3, double param1Double4) { super.emitClip(param1Double1, param1Double2, param1Double3, param1Double4); }
/*     */ 
/*     */ 
/*     */     
/* 118 */     public void setOuter(PDF3Printer2D param1PDF3Printer2D) { this.outer = param1PDF3Printer2D; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\j2d\PDF4Printer2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */