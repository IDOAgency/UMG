package inetsoft.report.pdf.j2d;

interface PrinterImpl {
  void emitClip(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  void setOuter(PDF3Printer2D paramPDF3Printer2D);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\j2d\PrinterImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */