/*     */ package inetsoft.report.pdf;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AFMFontInfo
/*     */   extends FontInfo
/*     */ {
/*     */   public void parse(InputStream paramInputStream) throws IOException {
/*  31 */     Hashtable hashtable = new Hashtable();
/*     */     
/*  33 */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
/*     */     
/*  35 */     int i = 0;
/*     */ 
/*     */ 
/*     */     
/*  39 */     this.widths = new int[256];
/*     */     String str;
/*  41 */     while ((str = bufferedReader.readLine()) != null) {
/*  42 */       if (i) {
/*  43 */         i--;
/*     */         
/*     */         continue;
/*     */       } 
/*  47 */       StringTokenizer stringTokenizer = new StringTokenizer(str, " \t");
/*  48 */       String str1 = stringTokenizer.nextToken();
/*     */       
/*  50 */       if (str1 == null || str1.equals("Comment")) {
/*     */         continue;
/*     */       }
/*     */       
/*  54 */       if (str1.equals("FontName")) {
/*  55 */         this.fontName = stringTokenizer.nextToken(); continue;
/*     */       } 
/*  57 */       if (str1.equals("FullName")) {
/*  58 */         this.fullName = stringTokenizer.nextToken(); continue;
/*     */       } 
/*  60 */       if (str1.equals("FamilyName")) {
/*  61 */         this.familyName = stringTokenizer.nextToken(); continue;
/*     */       } 
/*  63 */       if (str1.equals("Weight")) {
/*  64 */         this.weight = stringTokenizer.nextToken(); continue;
/*     */       } 
/*  66 */       if (str1.equals("IsFixedPitch")) {
/*  67 */         this.fixedPitch = stringTokenizer.nextToken().equals("true"); continue;
/*     */       } 
/*  69 */       if (str1.equals("ItalicAngle")) {
/*  70 */         this.italicAngle = Double.valueOf(stringTokenizer.nextToken()).doubleValue(); continue;
/*     */       } 
/*  72 */       if (str1.equals("Ascender")) {
/*  73 */         this.ascender = Integer.parseInt(stringTokenizer.nextToken()); continue;
/*     */       } 
/*  75 */       if (str1.equals("Descenter")) {
/*  76 */         this.descender = Integer.parseInt(stringTokenizer.nextToken()); continue;
/*     */       } 
/*  78 */       if (str1.equals("FontBBox")) {
/*  79 */         this.bbox = new Rectangle();
/*  80 */         this.bbox.x = Integer.parseInt(stringTokenizer.nextToken());
/*  81 */         this.bbox.y = Integer.parseInt(stringTokenizer.nextToken());
/*  82 */         this.bbox.width = Integer.parseInt(stringTokenizer.nextToken());
/*  83 */         this.bbox.height = Integer.parseInt(stringTokenizer.nextToken());
/*  84 */         this.bbox.width -= this.bbox.x;
/*  85 */         this.bbox.height -= this.bbox.y;
/*  86 */         this.bbox.y += this.bbox.height; continue;
/*     */       } 
/*  88 */       if (str1.equals("EncodingScheme")) {
/*  89 */         this.encoding = stringTokenizer.nextToken(); continue;
/*     */       } 
/*  91 */       if (str1.equals("CapHeight")) {
/*  92 */         this.capHeight = Integer.parseInt(stringTokenizer.nextToken()); continue;
/*     */       } 
/*  94 */       if (str1.equals("StartCharMetrics")) {
/*  95 */         while ((str = bufferedReader.readLine()) != null && 
/*  96 */           !str.startsWith("EndCharMetrics")) {
/*     */ 
/*     */ 
/*     */           
/* 100 */           int j = -1, k = 0;
/* 101 */           String str2 = null;
/* 102 */           StringTokenizer stringTokenizer1 = new StringTokenizer(str, ";");
/*     */           
/* 104 */           while (stringTokenizer1.hasMoreTokens()) {
/* 105 */             StringTokenizer stringTokenizer2 = new StringTokenizer(stringTokenizer1.nextToken());
/* 106 */             String str3 = stringTokenizer2.nextToken();
/*     */             
/* 108 */             if (str3.equals("C")) {
/* 109 */               j = Integer.parseInt(stringTokenizer2.nextToken()); continue;
/*     */             } 
/* 111 */             if (str3.equals("WX") || str3.equals("W0X")) {
/* 112 */               k = Integer.parseInt(stringTokenizer2.nextToken()); continue;
/*     */             } 
/* 114 */             if (str3.equals("N")) {
/* 115 */               str2 = stringTokenizer2.nextToken();
/*     */             }
/*     */           } 
/*     */           
/* 119 */           if (j >= 0) {
/* 120 */             this.widths[j] = k;
/* 121 */             this.advance = Math.max(this.advance, k);
/*     */           } 
/*     */           
/* 124 */           if (str2 != null)
/* 125 */             hashtable.put(str2, new Character((char)j)); 
/*     */         } 
/*     */         continue;
/*     */       } 
/* 129 */       if (str1.equals("StartKernPairs")) {
/* 130 */         while ((str = bufferedReader.readLine()) != null && 
/* 131 */           !str.startsWith("EndKernPairs")) {
/*     */ 
/*     */ 
/*     */           
/* 135 */           StringTokenizer stringTokenizer1 = new StringTokenizer(str, ";");
/* 136 */           while (stringTokenizer1.hasMoreTokens()) {
/* 137 */             StringTokenizer stringTokenizer2 = new StringTokenizer(stringTokenizer1.nextToken());
/* 138 */             String str2 = stringTokenizer2.nextToken();
/*     */             
/* 140 */             if (str2.equals("KP") || str2.equals("KPX")) {
/* 141 */               String str3 = stringTokenizer2.nextToken();
/* 142 */               String str4 = stringTokenizer2.nextToken();
/*     */               
/* 144 */               char c1 = str3.charAt(0), c2 = str4.charAt(0);
/*     */               
/* 146 */               if (str3.length() > 1) {
/* 147 */                 Character character; c1 = ((character = (Character)hashtable.get(str3)) != null) ? character.charValue() : 0;
/*     */               } 
/*     */ 
/*     */               
/* 151 */               if (str4.length() > 1) {
/* 152 */                 Character character; c2 = ((character = (Character)hashtable.get(str4)) != null) ? character.charValue() : 0;
/*     */               } 
/*     */ 
/*     */               
/* 156 */               if (c1 != '\000' && c2 != '\000') {
/* 157 */                 this.pairKern.put(c1 + "" + c2, Integer.valueOf(stringTokenizer2.nextToken()));
/*     */               }
/*     */               continue;
/*     */             } 
/* 161 */             if (str2.equals("KPH")) {
/* 162 */               String str3 = stringTokenizer2.nextToken();
/* 163 */               String str4 = stringTokenizer2.nextToken();
/* 164 */               char c1 = (char)Integer.parseInt(str3.substring(1, str3.length() - 1), 16);
/*     */               
/* 166 */               char c2 = (char)Integer.parseInt(str4.substring(1, str4.length() - 1), 16);
/*     */ 
/*     */               
/* 169 */               this.pairKern.put(c1 + "" + c2, Integer.valueOf(stringTokenizer2.nextToken()));
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         continue;
/*     */       } 
/* 175 */       if (str1.equals("StartComposites") || str1.equals("StartTrackKern"))
/*     */       {
/* 177 */         i = Integer.parseInt(stringTokenizer.nextToken());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getFontNames(InputStream paramInputStream) throws IOException {
/* 187 */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
/* 188 */     String str2 = null, str3 = null;
/*     */     String str1;
/* 190 */     while ((str1 = bufferedReader.readLine()) != null) {
/* 191 */       str1 = str1.trim();
/*     */       
/* 193 */       if (str1.startsWith("FullName")) {
/* 194 */         str3 = str1.substring(8).trim();
/*     */       }
/* 196 */       else if (str1.startsWith("FontName")) {
/* 197 */         str2 = str1.substring(10).trim();
/*     */       } 
/*     */       
/* 200 */       if (str2 != null && str3 != null) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 205 */     new String[2][0] = str2; new String[2][1] = str3; return (str2 == null) ? null : new String[2];
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\AFMFontInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */