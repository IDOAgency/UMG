package inetsoft.report.pdf;

import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.StringTokenizer;

class AFMFontInfo extends FontInfo {
  public void parse(InputStream paramInputStream) throws IOException {
    Hashtable hashtable = new Hashtable();
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
    int i = 0;
    this.widths = new int[256];
    String str;
    while ((str = bufferedReader.readLine()) != null) {
      if (i) {
        i--;
        continue;
      } 
      StringTokenizer stringTokenizer = new StringTokenizer(str, " \t");
      String str1 = stringTokenizer.nextToken();
      if (str1 == null || str1.equals("Comment"))
        continue; 
      if (str1.equals("FontName")) {
        this.fontName = stringTokenizer.nextToken();
        continue;
      } 
      if (str1.equals("FullName")) {
        this.fullName = stringTokenizer.nextToken();
        continue;
      } 
      if (str1.equals("FamilyName")) {
        this.familyName = stringTokenizer.nextToken();
        continue;
      } 
      if (str1.equals("Weight")) {
        this.weight = stringTokenizer.nextToken();
        continue;
      } 
      if (str1.equals("IsFixedPitch")) {
        this.fixedPitch = stringTokenizer.nextToken().equals("true");
        continue;
      } 
      if (str1.equals("ItalicAngle")) {
        this.italicAngle = Double.valueOf(stringTokenizer.nextToken()).doubleValue();
        continue;
      } 
      if (str1.equals("Ascender")) {
        this.ascender = Integer.parseInt(stringTokenizer.nextToken());
        continue;
      } 
      if (str1.equals("Descenter")) {
        this.descender = Integer.parseInt(stringTokenizer.nextToken());
        continue;
      } 
      if (str1.equals("FontBBox")) {
        this.bbox = new Rectangle();
        this.bbox.x = Integer.parseInt(stringTokenizer.nextToken());
        this.bbox.y = Integer.parseInt(stringTokenizer.nextToken());
        this.bbox.width = Integer.parseInt(stringTokenizer.nextToken());
        this.bbox.height = Integer.parseInt(stringTokenizer.nextToken());
        this.bbox.width -= this.bbox.x;
        this.bbox.height -= this.bbox.y;
        this.bbox.y += this.bbox.height;
        continue;
      } 
      if (str1.equals("EncodingScheme")) {
        this.encoding = stringTokenizer.nextToken();
        continue;
      } 
      if (str1.equals("CapHeight")) {
        this.capHeight = Integer.parseInt(stringTokenizer.nextToken());
        continue;
      } 
      if (str1.equals("StartCharMetrics")) {
        while ((str = bufferedReader.readLine()) != null && 
          !str.startsWith("EndCharMetrics")) {
          int j = -1, k = 0;
          String str2 = null;
          StringTokenizer stringTokenizer1 = new StringTokenizer(str, ";");
          while (stringTokenizer1.hasMoreTokens()) {
            StringTokenizer stringTokenizer2 = new StringTokenizer(stringTokenizer1.nextToken());
            String str3 = stringTokenizer2.nextToken();
            if (str3.equals("C")) {
              j = Integer.parseInt(stringTokenizer2.nextToken());
              continue;
            } 
            if (str3.equals("WX") || str3.equals("W0X")) {
              k = Integer.parseInt(stringTokenizer2.nextToken());
              continue;
            } 
            if (str3.equals("N"))
              str2 = stringTokenizer2.nextToken(); 
          } 
          if (j >= 0) {
            this.widths[j] = k;
            this.advance = Math.max(this.advance, k);
          } 
          if (str2 != null)
            hashtable.put(str2, new Character((char)j)); 
        } 
        continue;
      } 
      if (str1.equals("StartKernPairs")) {
        while ((str = bufferedReader.readLine()) != null && 
          !str.startsWith("EndKernPairs")) {
          StringTokenizer stringTokenizer1 = new StringTokenizer(str, ";");
          while (stringTokenizer1.hasMoreTokens()) {
            StringTokenizer stringTokenizer2 = new StringTokenizer(stringTokenizer1.nextToken());
            String str2 = stringTokenizer2.nextToken();
            if (str2.equals("KP") || str2.equals("KPX")) {
              String str3 = stringTokenizer2.nextToken();
              String str4 = stringTokenizer2.nextToken();
              char c1 = str3.charAt(0), c2 = str4.charAt(0);
              if (str3.length() > 1) {
                Character character;
                c1 = ((character = (Character)hashtable.get(str3)) != null) ? character.charValue() : 0;
              } 
              if (str4.length() > 1) {
                Character character;
                c2 = ((character = (Character)hashtable.get(str4)) != null) ? character.charValue() : 0;
              } 
              if (c1 != '\000' && c2 != '\000')
                this.pairKern.put(c1 + "" + c2, Integer.valueOf(stringTokenizer2.nextToken())); 
              continue;
            } 
            if (str2.equals("KPH")) {
              String str3 = stringTokenizer2.nextToken();
              String str4 = stringTokenizer2.nextToken();
              char c1 = (char)Integer.parseInt(str3.substring(1, str3.length() - 1), 16);
              char c2 = (char)Integer.parseInt(str4.substring(1, str4.length() - 1), 16);
              this.pairKern.put(c1 + "" + c2, Integer.valueOf(stringTokenizer2.nextToken()));
            } 
          } 
        } 
        continue;
      } 
      if (str1.equals("StartComposites") || str1.equals("StartTrackKern"))
        i = Integer.parseInt(stringTokenizer.nextToken()); 
    } 
  }
  
  public static String[] getFontNames(InputStream paramInputStream) throws IOException {
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
    String str2 = null, str3 = null;
    String str1;
    while ((str1 = bufferedReader.readLine()) != null) {
      str1 = str1.trim();
      if (str1.startsWith("FullName")) {
        str3 = str1.substring(8).trim();
      } else if (str1.startsWith("FontName")) {
        str2 = str1.substring(10).trim();
      } 
      if (str2 != null && str3 != null)
        break; 
    } 
    new String[2][0] = str2;
    new String[2][1] = str3;
    return (str2 == null) ? null : new String[2];
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\AFMFontInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */