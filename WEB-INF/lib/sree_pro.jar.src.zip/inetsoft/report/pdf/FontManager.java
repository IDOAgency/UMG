package inetsoft.report.pdf;

import inetsoft.report.ReportEnv;
import inetsoft.report.internal.AFManager;
import inetsoft.report.internal.AFontMetrics;
import java.awt.Font;
import java.awt.FontMetrics;
import java.io.File;
import java.io.FileInputStream;
import java.util.Hashtable;
import java.util.StringTokenizer;

public class FontManager {
  public static FontManager getFontManager() { return (fontMgr == null) ? (fontMgr = new FontManager()) : fontMgr; }
  
  public FontInfo getFontInfo(String paramString) {
    FontInfo fontInfo = (FontInfo)this.cache.get(paramString);
    if (fontInfo == null) {
      try {
        fontInfo = loadFontInfo(paramString);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
      this.cache.put(paramString, (fontInfo == null) ? new TTFontInfo() : fontInfo);
    } 
    return (fontInfo != null && fontInfo.getFamilyName() != null) ? fontInfo : null;
  }
  
  public FontMetrics getFontMetrics(Font paramFont) {
    String str1 = paramFont.getName().toLowerCase();
    String str2 = (String)this.fontmap.get(str1);
    if (str2 == null) {
      int j = str1.indexOf('.');
      if (j > 0)
        str2 = (String)this.fontmap.get(str1.substring(0, j)); 
    } 
    str1 = (str2 == null) ? str1 : str2;
    String str3 = null;
    int i = paramFont.getStyle();
    String[] arrayOfString = new String[4];
    if ((i & true) != 0 && (i & 0x2) != 0) {
      arrayOfString[0] = str1 + "-BoldItalic";
      arrayOfString[1] = str1 + "-BoldOblique";
      arrayOfString[2] = str1 + ",BoldItalic";
    } else if ((i & true) != 0) {
      arrayOfString[0] = str1 + "-Bold";
      arrayOfString[1] = str1 + ",Bold";
    } else if ((i & 0x2) != 0) {
      arrayOfString[0] = str1 + "-Italic";
      arrayOfString[1] = str1 + "-Oblique";
      arrayOfString[2] = str1 + ",Italic";
    } else {
      arrayOfString[0] = str1;
      arrayOfString[1] = str1 + "-Roman";
    } 
    for (byte b = 0; b < arrayOfString.length && arrayOfString[b] != null; b++) {
      if (exists(arrayOfString[b])) {
        str3 = arrayOfString[b];
        break;
      } 
    } 
    str3 = (str3 != null) ? str3 : str1;
    FontInfo fontInfo = getFontInfo(str3);
    if (fontInfo != null)
      return fontInfo.getFontMetrics(paramFont); 
    AFontMetrics aFontMetrics = AFManager.getFontMetrics(str3, paramFont.getSize());
    return (aFontMetrics != null) ? aFontMetrics : AFManager.getFontMetrics("times-roman", paramFont.getSize());
  }
  
  public void putFontName(String paramString1, String paramString2) { this.fontmap.put(paramString1.toLowerCase(), paramString2); }
  
  public boolean exists(String paramString) { return (this.ttNameMap.get(paramString) != null || this.ttFullMap.get(paramString) != null || this.ttPsMap.get(paramString) != null || this.afmNameMap.get(paramString) != null || this.afmFullMap.get(paramString) != null); }
  
  public String[] getCJKInfo(String paramString) { return (String[])this.cjkmap.get(paramString); }
  
  protected FontInfo loadFontInfo(String paramString) {
    File file;
    if ((file = (File)this.ttPsMap.get(paramString)) != null) {
      TTFontInfo tTFontInfo = new TTFontInfo();
      tTFontInfo.parse(file);
      return tTFontInfo;
    } 
    if ((file = (File)this.ttFullMap.get(paramString)) != null) {
      TTFontInfo tTFontInfo = new TTFontInfo();
      tTFontInfo.parse(file);
      return tTFontInfo;
    } 
    if ((file = (File)this.ttNameMap.get(paramString)) != null) {
      TTFontInfo tTFontInfo = new TTFontInfo();
      tTFontInfo.parse(file);
      return tTFontInfo;
    } 
    if ((file = (File)this.afmFullMap.get(paramString)) != null) {
      AFMFontInfo aFMFontInfo = new AFMFontInfo();
      aFMFontInfo.parse(new FileInputStream(file));
      return aFMFontInfo;
    } 
    if ((file = (File)this.afmNameMap.get(paramString)) != null) {
      AFMFontInfo aFMFontInfo = new AFMFontInfo();
      aFMFontInfo.parse(new FileInputStream(file));
      return aFMFontInfo;
    } 
    return null;
  }
  
  private static FontManager fontMgr = null;
  
  private Hashtable cache = new Hashtable();
  
  private Hashtable ttNameMap = new Hashtable();
  
  private Hashtable ttPsMap = new Hashtable();
  
  private Hashtable ttFullMap = new Hashtable();
  
  private Hashtable afmNameMap = new Hashtable();
  
  private Hashtable afmFullMap = new Hashtable();
  
  private Hashtable cjkmap = new Hashtable();
  
  private Hashtable fontmap;
  
  private FontManager() {
    String[] arrayOfString1 = { "Japan1", "UniJIS-UCS2-H" };
    String[] arrayOfString2 = { "GB1", "UniGB-UCS2-H" };
    String[] arrayOfString3 = { "CNS1", "UniCNS-UCS2-H" };
    String[] arrayOfString4 = { "Korea1", "UniKS-UCS2-H" };
    this.cjkmap.put("HeiseiKakuGo-W5-Acro", arrayOfString1);
    this.cjkmap.put("HeiseiMin-W3-Acro", arrayOfString1);
    this.cjkmap.put("STSong-Light-Acro", arrayOfString2);
    this.cjkmap.put("MHei-Medium-Acro", arrayOfString3);
    this.cjkmap.put("MSung-Light-Acro", arrayOfString3);
    this.cjkmap.put("HYGoThic-Medium-Acro", arrayOfString4);
    this.cjkmap.put("HYSMyeongJo-Medium-Acro", arrayOfString4);
    this.fontmap = new Hashtable();
    this.fontmap.put("dialog", "Helvetica");
    this.fontmap.put("dialoginput", "Courier");
    this.fontmap.put("serif", "Times");
    this.fontmap.put("sansserif", "Helvetica");
    this.fontmap.put("monospaced", "Courier");
    this.fontmap.put("timesroman", "Times");
    this.fontmap.put("courier", "Courier");
    this.fontmap.put("helvetica", "Helvetica");
    String str = ReportEnv.getProperty("font.truetype.path", "c:/winnt/fonts");
    StringTokenizer stringTokenizer = new StringTokenizer(str, ";");
    while (stringTokenizer.hasMoreTokens()) {
      String str1 = stringTokenizer.nextToken();
      File file = new File(str1);
      if (file.exists()) {
        String[] arrayOfString = file.list();
        for (byte b = 0; b < arrayOfString.length; b++) {
          String str2 = arrayOfString[b].toLowerCase();
          if (str2.endsWith(".ttf") || str2.endsWith("-acro"))
            try {
              File file1 = new File(str1, arrayOfString[b]);
              String[] arrayOfString5 = TTFontInfo.getFontNames(file1);
              if (arrayOfString5[false] == null || arrayOfString5[true] == null) {
                System.err.println("Missing name in truetype font: " + file1 + " " + arrayOfString5[0] + " " + arrayOfString5[1]);
              } else {
                this.ttNameMap.put(arrayOfString5[0], file1);
                this.ttFullMap.put(arrayOfString5[1], file1);
                if (arrayOfString5[2] != null) {
                  String str3 = "";
                  if (arrayOfString5[2].indexOf("Bold") > 0)
                    str3 = str3 + "Bold"; 
                  if (arrayOfString5[2].indexOf("Italic") > 0)
                    str3 = str3 + "Italic"; 
                  if (str3.length() > 0)
                    str3 = "," + str3; 
                  this.ttPsMap.put(arrayOfString5[0] + str3, file1);
                } 
              } 
            } catch (Exception exception) {
              exception.printStackTrace();
            }  
        } 
        continue;
      } 
      System.err.println("TrueType font directory does not exist: " + str1);
    } 
    str = ReportEnv.getProperty("font.afm.path");
    if (str != null) {
      stringTokenizer = new StringTokenizer(str, ";");
      while (stringTokenizer.hasMoreTokens()) {
        String str1 = stringTokenizer.nextToken();
        File file = new File(str1);
        if (file.exists()) {
          String[] arrayOfString = file.list();
          for (byte b = 0; b < arrayOfString.length; b++) {
            if (arrayOfString[b].toLowerCase().endsWith(".afm"))
              try {
                File file1 = new File(str1, arrayOfString[b]);
                String[] arrayOfString5 = AFMFontInfo.getFontNames(new FileInputStream(file1));
                if (arrayOfString5 != null) {
                  this.afmNameMap.put(arrayOfString5[0], file1);
                  if (arrayOfString5[true] == null) {
                    this.afmFullMap.put(arrayOfString5[0], file1);
                  } else {
                    this.afmFullMap.put(arrayOfString5[1], file1);
                  } 
                } 
              } catch (Exception exception) {
                exception.printStackTrace();
              }  
          } 
          continue;
        } 
        System.err.println("AFM font directory does not exist: " + str1);
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\FontManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */