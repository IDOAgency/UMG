/*     */ package inetsoft.report.pdf;
/*     */ 
/*     */ import inetsoft.report.ReportEnv;
/*     */ import inetsoft.report.internal.AFManager;
/*     */ import inetsoft.report.internal.AFontMetrics;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FontManager
/*     */ {
/*  36 */   public static FontManager getFontManager() { return (fontMgr == null) ? (fontMgr = new FontManager()) : fontMgr; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FontInfo getFontInfo(String paramString) {
/* 146 */     FontInfo fontInfo = (FontInfo)this.cache.get(paramString);
/*     */     
/* 148 */     if (fontInfo == null) {
/*     */       try {
/* 150 */         fontInfo = loadFontInfo(paramString);
/*     */       } catch (Exception exception) {
/* 152 */         exception.printStackTrace();
/*     */       } 
/*     */ 
/*     */       
/* 156 */       this.cache.put(paramString, (fontInfo == null) ? new TTFontInfo() : fontInfo);
/*     */     } 
/*     */     
/* 159 */     return (fontInfo != null && fontInfo.getFamilyName() != null) ? fontInfo : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FontMetrics getFontMetrics(Font paramFont) {
/* 166 */     String str1 = paramFont.getName().toLowerCase();
/* 167 */     String str2 = (String)this.fontmap.get(str1);
/*     */     
/* 169 */     if (str2 == null) {
/* 170 */       int j = str1.indexOf('.');
/* 171 */       if (j > 0) {
/* 172 */         str2 = (String)this.fontmap.get(str1.substring(0, j));
/*     */       }
/*     */     } 
/*     */     
/* 176 */     str1 = (str2 == null) ? str1 : str2;
/* 177 */     String str3 = null;
/* 178 */     int i = paramFont.getStyle();
/* 179 */     String[] arrayOfString = new String[4];
/*     */     
/* 181 */     if ((i & true) != 0 && (i & 0x2) != 0) {
/* 182 */       arrayOfString[0] = str1 + "-BoldItalic";
/* 183 */       arrayOfString[1] = str1 + "-BoldOblique";
/* 184 */       arrayOfString[2] = str1 + ",BoldItalic";
/*     */     }
/* 186 */     else if ((i & true) != 0) {
/* 187 */       arrayOfString[0] = str1 + "-Bold";
/* 188 */       arrayOfString[1] = str1 + ",Bold";
/*     */     }
/* 190 */     else if ((i & 0x2) != 0) {
/* 191 */       arrayOfString[0] = str1 + "-Italic";
/* 192 */       arrayOfString[1] = str1 + "-Oblique";
/* 193 */       arrayOfString[2] = str1 + ",Italic";
/*     */     } else {
/*     */       
/* 196 */       arrayOfString[0] = str1;
/* 197 */       arrayOfString[1] = str1 + "-Roman";
/*     */     } 
/*     */     
/* 200 */     for (byte b = 0; b < arrayOfString.length && arrayOfString[b] != null; b++) {
/* 201 */       if (exists(arrayOfString[b])) {
/* 202 */         str3 = arrayOfString[b];
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 207 */     str3 = (str3 != null) ? str3 : str1;
/* 208 */     FontInfo fontInfo = getFontInfo(str3);
/* 209 */     if (fontInfo != null) {
/* 210 */       return fontInfo.getFontMetrics(paramFont);
/*     */     }
/*     */     
/* 213 */     AFontMetrics aFontMetrics = AFManager.getFontMetrics(str3, paramFont.getSize());
/* 214 */     return (aFontMetrics != null) ? aFontMetrics : AFManager.getFontMetrics("times-roman", paramFont.getSize());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public void putFontName(String paramString1, String paramString2) { this.fontmap.put(paramString1.toLowerCase(), paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 232 */   public boolean exists(String paramString) { return (this.ttNameMap.get(paramString) != null || this.ttFullMap.get(paramString) != null || this.ttPsMap.get(paramString) != null || this.afmNameMap.get(paramString) != null || this.afmFullMap.get(paramString) != null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 244 */   public String[] getCJKInfo(String paramString) { return (String[])this.cjkmap.get(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FontInfo loadFontInfo(String paramString) {
/*     */     File file;
/* 253 */     if ((file = (File)this.ttPsMap.get(paramString)) != null) {
/* 254 */       TTFontInfo tTFontInfo = new TTFontInfo();
/* 255 */       tTFontInfo.parse(file);
/* 256 */       return tTFontInfo;
/*     */     } 
/*     */     
/* 259 */     if ((file = (File)this.ttFullMap.get(paramString)) != null) {
/* 260 */       TTFontInfo tTFontInfo = new TTFontInfo();
/* 261 */       tTFontInfo.parse(file);
/* 262 */       return tTFontInfo;
/*     */     } 
/*     */     
/* 265 */     if ((file = (File)this.ttNameMap.get(paramString)) != null) {
/* 266 */       TTFontInfo tTFontInfo = new TTFontInfo();
/* 267 */       tTFontInfo.parse(file);
/* 268 */       return tTFontInfo;
/*     */     } 
/*     */     
/* 271 */     if ((file = (File)this.afmFullMap.get(paramString)) != null) {
/* 272 */       AFMFontInfo aFMFontInfo = new AFMFontInfo();
/* 273 */       aFMFontInfo.parse(new FileInputStream(file));
/* 274 */       return aFMFontInfo;
/*     */     } 
/*     */     
/* 277 */     if ((file = (File)this.afmNameMap.get(paramString)) != null) {
/* 278 */       AFMFontInfo aFMFontInfo = new AFMFontInfo();
/* 279 */       aFMFontInfo.parse(new FileInputStream(file));
/* 280 */       return aFMFontInfo;
/*     */     } 
/*     */     
/* 283 */     return null;
/*     */   }
/*     */   
/* 286 */   private static FontManager fontMgr = null;
/* 287 */   private Hashtable cache = new Hashtable();
/* 288 */   private Hashtable ttNameMap = new Hashtable();
/* 289 */   private Hashtable ttPsMap = new Hashtable();
/* 290 */   private Hashtable ttFullMap = new Hashtable();
/* 291 */   private Hashtable afmNameMap = new Hashtable();
/* 292 */   private Hashtable afmFullMap = new Hashtable();
/*     */   
/* 294 */   private Hashtable cjkmap = new Hashtable();
/*     */   private FontManager() {
/* 296 */     String[] arrayOfString1 = { "Japan1", "UniJIS-UCS2-H" };
/* 297 */     String[] arrayOfString2 = { "GB1", "UniGB-UCS2-H" };
/* 298 */     String[] arrayOfString3 = { "CNS1", "UniCNS-UCS2-H" };
/* 299 */     String[] arrayOfString4 = { "Korea1", "UniKS-UCS2-H" };
/*     */     
/* 301 */     this.cjkmap.put("HeiseiKakuGo-W5-Acro", arrayOfString1);
/* 302 */     this.cjkmap.put("HeiseiMin-W3-Acro", arrayOfString1);
/* 303 */     this.cjkmap.put("STSong-Light-Acro", arrayOfString2);
/* 304 */     this.cjkmap.put("MHei-Medium-Acro", arrayOfString3);
/* 305 */     this.cjkmap.put("MSung-Light-Acro", arrayOfString3);
/* 306 */     this.cjkmap.put("HYGoThic-Medium-Acro", arrayOfString4);
/* 307 */     this.cjkmap.put("HYSMyeongJo-Medium-Acro", arrayOfString4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     this.fontmap = new Hashtable();
/*     */     
/* 315 */     this.fontmap.put("dialog", "Helvetica");
/* 316 */     this.fontmap.put("dialoginput", "Courier");
/* 317 */     this.fontmap.put("serif", "Times");
/* 318 */     this.fontmap.put("sansserif", "Helvetica");
/* 319 */     this.fontmap.put("monospaced", "Courier");
/* 320 */     this.fontmap.put("timesroman", "Times");
/* 321 */     this.fontmap.put("courier", "Courier");
/* 322 */     this.fontmap.put("helvetica", "Helvetica");
/*     */     String str = ReportEnv.getProperty("font.truetype.path", "c:/winnt/fonts");
/*     */     StringTokenizer stringTokenizer = new StringTokenizer(str, ";");
/*     */     while (stringTokenizer.hasMoreTokens()) {
/*     */       String str1 = stringTokenizer.nextToken();
/*     */       File file = new File(str1);
/*     */       if (file.exists()) {
/*     */         String[] arrayOfString = file.list();
/*     */         for (byte b = 0; b < arrayOfString.length; b++) {
/*     */           String str2 = arrayOfString[b].toLowerCase();
/*     */           if (str2.endsWith(".ttf") || str2.endsWith("-acro"))
/*     */             try {
/*     */               File file1 = new File(str1, arrayOfString[b]);
/*     */               String[] arrayOfString5 = TTFontInfo.getFontNames(file1);
/*     */               if (arrayOfString5[false] == null || arrayOfString5[true] == null) {
/*     */                 System.err.println("Missing name in truetype font: " + file1 + " " + arrayOfString5[0] + " " + arrayOfString5[1]);
/*     */               } else {
/*     */                 this.ttNameMap.put(arrayOfString5[0], file1);
/*     */                 this.ttFullMap.put(arrayOfString5[1], file1);
/*     */                 if (arrayOfString5[2] != null) {
/*     */                   String str3 = "";
/*     */                   if (arrayOfString5[2].indexOf("Bold") > 0)
/*     */                     str3 = str3 + "Bold"; 
/*     */                   if (arrayOfString5[2].indexOf("Italic") > 0)
/*     */                     str3 = str3 + "Italic"; 
/*     */                   if (str3.length() > 0)
/*     */                     str3 = "," + str3; 
/*     */                   this.ttPsMap.put(arrayOfString5[0] + str3, file1);
/*     */                 } 
/*     */               } 
/*     */             } catch (Exception exception) {
/*     */               exception.printStackTrace();
/*     */             }  
/*     */         } 
/*     */         continue;
/*     */       } 
/*     */       System.err.println("TrueType font directory does not exist: " + str1);
/*     */     } 
/*     */     str = ReportEnv.getProperty("font.afm.path");
/*     */     if (str != null) {
/*     */       stringTokenizer = new StringTokenizer(str, ";");
/*     */       while (stringTokenizer.hasMoreTokens()) {
/*     */         String str1 = stringTokenizer.nextToken();
/*     */         File file = new File(str1);
/*     */         if (file.exists()) {
/*     */           String[] arrayOfString = file.list();
/*     */           for (byte b = 0; b < arrayOfString.length; b++) {
/*     */             if (arrayOfString[b].toLowerCase().endsWith(".afm"))
/*     */               try {
/*     */                 File file1 = new File(str1, arrayOfString[b]);
/*     */                 String[] arrayOfString5 = AFMFontInfo.getFontNames(new FileInputStream(file1));
/*     */                 if (arrayOfString5 != null) {
/*     */                   this.afmNameMap.put(arrayOfString5[0], file1);
/*     */                   if (arrayOfString5[true] == null) {
/*     */                     this.afmFullMap.put(arrayOfString5[0], file1);
/*     */                   } else {
/*     */                     this.afmFullMap.put(arrayOfString5[1], file1);
/*     */                   } 
/*     */                 } 
/*     */               } catch (Exception exception) {
/*     */                 exception.printStackTrace();
/*     */               }  
/*     */           } 
/*     */           continue;
/*     */         } 
/*     */         System.err.println("AFM font directory does not exist: " + str1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Hashtable fontmap;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\FontManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */