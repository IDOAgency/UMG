/*     */ package inetsoft.report.pdf;
/*     */ 
/*     */ import inetsoft.report.ReportEnv;
/*     */ import inetsoft.report.internal.Util;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CMap
/*     */ {
/*     */   String name;
/*     */   Range[] ranges;
/*     */   int max;
/*     */   
/*     */   public CMap(String paramString) throws IOException {
/* 181 */     this.ranges = null;
/*     */     this.name = paramString;
/*     */     InputStream inputStream = getCMapData(paramString);
/*     */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
/*     */     boolean bool = false;
/*     */     Vector vector = new Vector();
/*     */     String str;
/*     */     while ((str = bufferedReader.readLine()) != null) {
/*     */       String[] arrayOfString = Util.split(str, " <>\t\n");
/*     */       if (!bool && arrayOfString.length == 2 && arrayOfString[1].equals("begincidrange")) {
/*     */         bool = true;
/*     */         continue;
/*     */       } 
/*     */       if (bool && arrayOfString.length == 1 && arrayOfString[0].equals("endcidrange")) {
/*     */         bool = false;
/*     */         continue;
/*     */       } 
/*     */       if (bool && arrayOfString.length == 4) {
/*     */         Range range = new Range(this, Integer.parseInt(arrayOfString[1], 16), Integer.parseInt(arrayOfString[2], 16), Integer.parseInt(arrayOfString[3]));
/*     */         int i = vector.size();
/*     */         for (; i > 0 && range.compare((Range)vector.elementAt(i - 1)) < 0; i--);
/*     */         vector.insertElementAt(range, i);
/*     */       } 
/*     */     } 
/*     */     this.ranges = new Range[vector.size()];
/*     */     vector.copyInto(this.ranges);
/*     */     inputStream.close();
/*     */   }
/*     */   
/*     */   public int map(char paramChar) { return map(paramChar, 0, this.ranges.length - 1); }
/*     */   
/*     */   public static InputStream getCMapData(String paramString) {
/*     */     String str1 = ReportEnv.getProperty("font.cmap.path");
/*     */     String str2 = "";
/*     */     if (str1 == null) {
/*     */       str1 = ReportEnv.getProperty("font.truetype.path");
/*     */       str2 = "/../CMap";
/*     */     } 
/*     */     if (str1 != null)
/*     */       try {
/*     */         StringTokenizer stringTokenizer = new StringTokenizer(str1, ";");
/*     */         while (stringTokenizer.hasMoreTokens()) {
/*     */           String str = stringTokenizer.nextToken();
/*     */           File file = new File(str + str2, paramString);
/*     */           if (file.exists())
/*     */             return new FileInputStream(file); 
/*     */         } 
/*     */       } catch (FileNotFoundException fileNotFoundException) {
/*     */         fileNotFoundException.printStackTrace();
/*     */       }  
/*     */     return CMap.class.getResourceAsStream("/" + paramString);
/*     */   }
/*     */   
/*     */   private int map(char paramChar, int paramInt1, int paramInt2) {
/*     */     int i = (paramInt1 + paramInt2) / 2;
/*     */     int j = this.ranges[i].compare(paramChar);
/*     */     if (j == 0)
/*     */       return this.ranges[i].map(paramChar); 
/*     */     if (paramInt1 == i)
/*     */       paramInt1++; 
/*     */     if (paramInt2 == i)
/*     */       paramInt2--; 
/*     */     if (paramInt2 < paramInt1)
/*     */       return -1; 
/*     */     if (paramInt2 == paramInt1)
/*     */       return this.ranges[paramInt2].map(paramChar); 
/*     */     if (j > 0) {
/*     */       paramInt2 = i;
/*     */     } else {
/*     */       paramInt1 = i;
/*     */     } 
/*     */     return map(paramChar, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public int getMax() { return this.max; }
/*     */   
/*     */   class Range {
/*     */     private int lo;
/*     */     private int hi;
/*     */     private int base;
/*     */     private final CMap this$0;
/*     */     
/*     */     public Range(CMap this$0, int param1Int1, int param1Int2, int param1Int3) {
/*     */       this.this$0 = this$0;
/*     */       this.lo = param1Int1;
/*     */       this.hi = param1Int2;
/*     */       this.base = param1Int3;
/*     */       this$0.max = Math.max(this$0.max, param1Int2);
/*     */     }
/*     */     
/*     */     public boolean contains(int param1Int) { return (param1Int >= this.lo && param1Int <= this.hi); }
/*     */     
/*     */     public int map(int param1Int) { return contains(param1Int) ? (this.base + param1Int - this.lo) : -1; }
/*     */     
/*     */     public int compare(Range param1Range) { return this.lo - param1Range.lo; }
/*     */     
/*     */     public int compare(int param1Int) { return (param1Int < this.lo) ? 1 : ((param1Int > this.hi) ? -1 : 0); }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\CMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */