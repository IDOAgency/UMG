/*     */ package inetsoft.report.pdf;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.util.BitSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CFF
/*     */ {
/*     */   public static void extract(RandomAccessFile paramRandomAccessFile, int paramInt1, int paramInt2, ByteArrayOutputStream paramByteArrayOutputStream, BitSet paramBitSet) throws IOException {
/*  33 */     byte[] arrayOfByte1 = new byte[paramInt2];
/*  34 */     paramRandomAccessFile.seek(paramInt1);
/*  35 */     paramRandomAccessFile.readFully(arrayOfByte1);
/*     */     
/*  37 */     ByteArrayOutputStream byteArrayOutputStream1 = new ByteArrayOutputStream();
/*  38 */     ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
/*  39 */     byte b = arrayOfByte1[3];
/*     */ 
/*     */     
/*  42 */     int i = 4;
/*     */     
/*  44 */     for (byte b1 = 0; b1 < 4; b1++) {
/*  45 */       i += getIndexSize(arrayOfByte1, i);
/*     */     }
/*  47 */     i += 32;
/*     */ 
/*     */     
/*  50 */     int j = 4;
/*  51 */     byteArrayOutputStream1.write(arrayOfByte1, 0, 4);
/*     */     
/*  53 */     j += copyIndex(arrayOfByte1, j, byteArrayOutputStream1);
/*     */ 
/*     */     
/*  56 */     byte[] arrayOfByte2 = arrayOfByte1;
/*  57 */     int[] arrayOfInt = { j };
/*  58 */     int k = getIndexCount(arrayOfByte2, arrayOfInt[0]);
/*  59 */     j += getIndexSize(arrayOfByte1, j);
/*     */     
/*  61 */     for (byte b2 = 0; b2 < k; b2++) {
/*  62 */       int[] arrayOfInt1 = getIndexOffsets(arrayOfByte2, arrayOfInt[0], b2);
/*     */       
/*  64 */       int m = getDictInt(arrayOfByte2, arrayOfInt1[0], arrayOfInt1[1], "CharStrings");
/*     */       
/*  66 */       int n = getIndexCount(arrayOfByte1, m);
/*  67 */       int i1 = getDictInt(arrayOfByte2, arrayOfInt1[0], arrayOfInt1[1], "charset");
/*     */       
/*  69 */       int[] arrayOfInt2 = { getDictInt(arrayOfByte2, arrayOfInt1[0], arrayOfInt1[1], "FDArray") };
/*  70 */       int i2 = getDictInt(arrayOfByte2, arrayOfInt1[0], arrayOfInt1[1], "FDSelect");
/*  71 */       int[] arrayOfInt3 = getDictIntArray(arrayOfByte2, arrayOfInt1[0], arrayOfInt1[1], "Private");
/*     */       
/*  73 */       int i3 = 0;
/*  74 */       if (arrayOfInt3 != null) {
/*  75 */         i3 = getDictInt(arrayOfByte1, arrayOfInt3[1], arrayOfInt3[0] + arrayOfInt3[1], "Subrs");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*  80 */       byte[] arrayOfByte3 = arrayOfByte2;
/*     */       
/*  82 */       arrayOfByte3 = setDictInt(arrayOfByte3, arrayOfInt1, "CharStrings", byteArrayOutputStream2.size() + i);
/*  83 */       extractIndex(arrayOfByte1, m, paramBitSet, byteArrayOutputStream2);
/*     */ 
/*     */       
/*  86 */       arrayOfByte3 = setDictInt(arrayOfByte3, arrayOfInt1, "charset", byteArrayOutputStream2.size() + i);
/*  87 */       copyCharsets(arrayOfByte1, i1, n, byteArrayOutputStream2);
/*     */ 
/*     */       
/*  90 */       byte[] arrayOfByte4 = arrayOfByte1;
/*  91 */       int i4 = getIndexCount(arrayOfByte4, arrayOfInt2[0]);
/*     */ 
/*     */       
/*  94 */       for (byte b3 = 0; b3 < i4; b3++) {
/*  95 */         byte[] arrayOfByte = arrayOfByte4;
/*  96 */         int[] arrayOfInt4 = getIndexOffsets(arrayOfByte4, arrayOfInt2[0], b3);
/*  97 */         int[] arrayOfInt5 = getDictIntArray(arrayOfByte, arrayOfInt4[0], arrayOfInt4[1], "Private");
/*     */         
/*  99 */         if (arrayOfInt5 != null) {
/* 100 */           if (arrayOfInt5.length != 2) {
/* 101 */             throw new RuntimeException("Private OP wrong size: " + arrayOfInt5.length);
/*     */           }
/*     */ 
/*     */           
/* 105 */           arrayOfByte = setDictInt(arrayOfByte4, arrayOfInt4, "Private", byteArrayOutputStream2.size() + i);
/* 106 */           byteArrayOutputStream2.write(arrayOfByte1, arrayOfInt5[1], arrayOfInt5[0]);
/*     */           
/* 108 */           if (arrayOfByte != arrayOfByte4) {
/* 109 */             arrayOfByte4 = setIndexValue(arrayOfByte4, arrayOfInt2, b3, arrayOfByte);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 114 */       arrayOfByte3 = setDictInt(arrayOfByte3, arrayOfInt1, "FDArray", byteArrayOutputStream2.size() + i);
/* 115 */       copyIndex(arrayOfByte4, arrayOfInt2[0], byteArrayOutputStream2);
/*     */       
/* 117 */       arrayOfByte3 = setDictInt(arrayOfByte3, arrayOfInt1, "FDSelect", byteArrayOutputStream2.size() + i);
/* 118 */       copyFDSelect(arrayOfByte1, i2, n, byteArrayOutputStream2);
/*     */       
/* 120 */       if (arrayOfInt3 != null) {
/* 121 */         arrayOfByte3 = setDictInt(arrayOfByte3, arrayOfInt1, "Private", byteArrayOutputStream2.size() + i);
/* 122 */         byteArrayOutputStream2.write(arrayOfByte1, arrayOfInt3[1], arrayOfInt3[0]);
/* 123 */         copyIndex(arrayOfByte1, arrayOfInt3[1] + i3, byteArrayOutputStream2);
/*     */       } 
/*     */       
/* 126 */       if (arrayOfByte3 != arrayOfByte2) {
/* 127 */         arrayOfByte2 = setIndexValue(arrayOfByte2, arrayOfInt, b2, arrayOfByte3);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 132 */     copyIndex(arrayOfByte2, arrayOfInt[0], byteArrayOutputStream1);
/*     */     
/* 134 */     j += copyIndex(arrayOfByte1, j, byteArrayOutputStream1);
/* 135 */     j += copyIndex(arrayOfByte1, j, byteArrayOutputStream1);
/*     */ 
/*     */     
/* 138 */     if (byteArrayOutputStream1.size() < i) {
/* 139 */       byteArrayOutputStream1.write(new byte[i - byteArrayOutputStream1.size()]);
/*     */     }
/* 141 */     else if (byteArrayOutputStream1.size() > i) {
/* 142 */       throw new RuntimeException("CFF sizes incorrect!");
/*     */     } 
/*     */ 
/*     */     
/* 146 */     byteArrayOutputStream1.write(byteArrayOutputStream2.toByteArray());
/* 147 */     paramByteArrayOutputStream.write(byteArrayOutputStream1.toByteArray());
/*     */   }
/*     */   
/*     */   static class Op { public static final int INT = 1;
/*     */     public static final int DOUBLE = 2;
/*     */     public static final int OP = 3;
/*     */     int type;
/*     */     
/*     */     public Op(int param1Int1, int param1Int2) {
/* 156 */       this.inumber = param1Int1;
/* 157 */       this.len = param1Int2;
/* 158 */       this.type = 1;
/*     */     }
/*     */     int inumber; double dnumber; String op; int len;
/*     */     public Op(double param1Double, int param1Int) {
/* 162 */       this.dnumber = param1Double;
/* 163 */       this.len = param1Int;
/* 164 */       this.type = 2;
/*     */     }
/*     */     
/*     */     public Op(String param1String, int param1Int) {
/* 168 */       this.op = param1String;
/* 169 */       this.len = param1Int;
/* 170 */       this.type = 3;
/*     */     }
/*     */ 
/*     */     
/* 174 */     public int getType() { return this.type; }
/*     */ 
/*     */ 
/*     */     
/* 178 */     public int getInt() { return this.inumber; }
/*     */ 
/*     */ 
/*     */     
/* 182 */     public double getDouble() { return this.dnumber; }
/*     */ 
/*     */ 
/*     */     
/* 186 */     public String getOp() { return this.op; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     public int length() { return this.len; }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 195 */       switch (this.type) { case 3:
/* 196 */           return this.op;
/* 197 */         case 1: return this.inumber + " [" + this.len + "]";
/* 198 */         case 2: return this.dnumber + " [" + this.len + "]"; }
/*     */ 
/*     */       
/* 201 */       return "null";
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String[] ops = { 
/* 211 */       "version", "Notice", "FullName", "FamilyName", "Weight", "FontBBox", "6", "7", "8", "9", "10", "11", "12", "UniqueID", "XUID", "charset", "Encoding", "CharStrings", "Private", "Subrs", "20" };
/*     */ 
/*     */ 
/*     */   
/*     */   static final String[] ops2 = { 
/* 216 */       "Copyright", "isFixedPitch", "ItalicAngle", "UnderlinePosition", "UnderlineThickness", "PaintType", "CharstringType", "FontMatrix", "StrokeWidth", "9", "", "", "", "", "", "", "", "", "", "", "SyntheticBase", "PostScript", "BaseFontName", "BaseFontBlend", "MultipleMaster", "", "BlendAxisType", "27", "28", "29", "ROS", "CIDFontVersion", "CIDFontRevision", "CIDFontType", "CIDCount", "UIDBase", "FDArray", "FDSelect", "FontName", "Chameleon" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Op getOp(byte[] paramArrayOfByte, int paramInt) {
/* 228 */     byte b = paramArrayOfByte[paramInt] & 0xFF;
/*     */ 
/*     */     
/* 231 */     if (b == 12) {
/* 232 */       return new Op(ops2[paramArrayOfByte[paramInt + 1] & 0xFF], 2);
/*     */     }
/*     */     
/* 235 */     if ((b >= 0 && b <= 27) || b == 31) {
/* 236 */       return new Op((b < ops.length) ? ops[b] : "", 1);
/*     */     }
/* 238 */     if (b >= 32 && b <= 246) {
/* 239 */       return new Op(b - 139, 1);
/*     */     }
/* 241 */     if (b >= 247 && b <= 250) {
/* 242 */       byte b1 = paramArrayOfByte[paramInt + 1] & 0xFF;
/* 243 */       return new Op((b - 247) * 256 + b1 + 108, 2);
/*     */     } 
/* 245 */     if (b >= 251 && b <= 254) {
/* 246 */       byte b1 = paramArrayOfByte[paramInt + 1] & 0xFF;
/* 247 */       return new Op(-(b - 251) * 256 - b1 - 108, 2);
/*     */     } 
/* 249 */     if (b == 28) {
/* 250 */       byte b1 = paramArrayOfByte[paramInt + 1] & 0xFF;
/* 251 */       byte b2 = paramArrayOfByte[paramInt + 2] & 0xFF;
/* 252 */       return new Op(b1 << 8 | b2, 3);
/*     */     } 
/* 254 */     if (b == 29) {
/* 255 */       byte b1 = paramArrayOfByte[paramInt + 1] & 0xFF;
/* 256 */       byte b2 = paramArrayOfByte[paramInt + 2] & 0xFF;
/* 257 */       byte b3 = paramArrayOfByte[paramInt + 3] & 0xFF;
/* 258 */       byte b4 = paramArrayOfByte[paramInt + 4] & 0xFF;
/* 259 */       return new Op(b1 << 24 | b2 << 16 | b3 << 8 | b4, 5);
/*     */     } 
/* 261 */     if (b == 30) {
/* 262 */       for (int i = paramInt + 1; i < paramArrayOfByte.length; i++) {
/* 263 */         if ((paramArrayOfByte[i] & 0xF) == 15) {
/* 264 */           return new Op(0.1D, i - paramInt + 1);
/*     */         }
/*     */       } 
/*     */       
/* 268 */       return new Op(0.1D, paramArrayOfByte.length - paramInt);
/*     */     } 
/*     */     
/* 271 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] encodeDictInt(int paramInt) {
/* 278 */     if (paramInt >= -107 && paramInt <= 107) {
/* 279 */       return new byte[] { (byte)(paramInt + 139) };
/*     */     }
/* 281 */     if (paramInt >= 108 && paramInt <= 1131) {
/* 282 */       int i = (paramInt - 108) % 256;
/* 283 */       int j = (paramInt - 108) / 256 + 247;
/* 284 */       return new byte[] { (byte)j, (byte)i };
/*     */     } 
/* 286 */     if (paramInt >= -1131 && paramInt <= -108) {
/* 287 */       int i = (paramInt + 108) % 256;
/* 288 */       int j = -(paramInt + 108) / 256 + 251;
/* 289 */       return new byte[] { (byte)j, (byte)i };
/*     */     } 
/* 291 */     if (paramInt >= -32768 && paramInt <= 32767) {
/* 292 */       return new byte[] { 28, (byte)(paramInt >>> 8 & 0xFF), (byte)(paramInt & 0xFF) };
/*     */     }
/*     */ 
/*     */     
/* 296 */     return new byte[] { 29, (byte)(paramInt >>> 24 & 0xFF), (byte)(paramInt >>> 16 & 0xFF), (byte)(paramInt >>> 8 & 0xFF), (byte)(paramInt & 0xFF) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int copyCharsets(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ByteArrayOutputStream paramByteArrayOutputStream) {
/*     */     int j;
/*     */     byte b;
/* 307 */     int i = paramByteArrayOutputStream.size();
/*     */ 
/*     */     
/* 310 */     paramByteArrayOutputStream.write(paramArrayOfByte[paramInt1]);
/*     */     
/* 312 */     switch (paramArrayOfByte[paramInt1]) {
/*     */       
/*     */       case 0:
/* 315 */         paramByteArrayOutputStream.write(paramArrayOfByte, paramInt1 + 1, 2 * (paramInt2 - 1));
/*     */         break;
/*     */       case 1:
/*     */       case 2:
/* 319 */         b = (paramArrayOfByte[paramInt1] == 1) ? 1 : 2;
/* 320 */         paramInt2--;
/* 321 */         for (j = paramInt1 + 1; paramInt2 > 0; j += b + 2) {
/* 322 */           paramByteArrayOutputStream.write(paramArrayOfByte, j, b + 2);
/* 323 */           paramInt2 -= TTFontInfo.getNUMBER(paramArrayOfByte, j + 2, b) + 1;
/*     */         } 
/*     */         break;
/*     */     } 
/*     */     
/* 328 */     return paramByteArrayOutputStream.size() - i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int copyFDSelect(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ByteArrayOutputStream paramByteArrayOutputStream) {
/* 337 */     int j, i = paramByteArrayOutputStream.size();
/*     */ 
/*     */     
/* 340 */     paramByteArrayOutputStream.write(paramArrayOfByte[paramInt1]);
/*     */     
/* 342 */     switch (paramArrayOfByte[paramInt1]) {
/*     */       
/*     */       case 0:
/* 345 */         paramByteArrayOutputStream.write(paramArrayOfByte, paramInt1 + 1, paramInt2);
/*     */         break;
/*     */       
/*     */       case 3:
/* 349 */         j = TTFontInfo.getUSHORT(paramArrayOfByte, paramInt1 + 1);
/* 350 */         paramByteArrayOutputStream.write(paramArrayOfByte, paramInt1 + 1, j * 3 + 4);
/*     */         break;
/*     */     } 
/*     */     
/* 354 */     return paramByteArrayOutputStream.size() - i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int copyIndex(byte[] paramArrayOfByte, int paramInt, ByteArrayOutputStream paramByteArrayOutputStream) throws IOException {
/* 364 */     int i = getIndexSize(paramArrayOfByte, paramInt);
/* 365 */     paramByteArrayOutputStream.write(paramArrayOfByte, paramInt, i);
/* 366 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getIndexSize(byte[] paramArrayOfByte, int paramInt) {
/* 374 */     int i = TTFontInfo.getUSHORT(paramArrayOfByte, paramInt);
/*     */     
/* 376 */     if (i == 0) {
/* 377 */       return 2;
/*     */     }
/*     */     
/* 380 */     byte b = paramArrayOfByte[paramInt + 2];
/* 381 */     int j = TTFontInfo.getNUMBER(paramArrayOfByte, paramInt + 3 + i * b, b);
/*     */     
/* 383 */     return j + 2 + (i + 1) * b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 388 */   static int getIndexCount(byte[] paramArrayOfByte, int paramInt) { return TTFontInfo.getUSHORT(paramArrayOfByte, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int[] getIndexOffsets(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
/* 396 */     int i = TTFontInfo.getUSHORT(paramArrayOfByte, paramInt1);
/*     */     
/* 398 */     if (i == 0) {
/* 399 */       return new int[] { 0, 0 };
/*     */     }
/*     */     
/* 402 */     byte b = paramArrayOfByte[paramInt1 + 2];
/* 403 */     int j = TTFontInfo.getNUMBER(paramArrayOfByte, paramInt1 + 3 + paramInt2 * b, b);
/* 404 */     int k = TTFontInfo.getNUMBER(paramArrayOfByte, paramInt1 + 3 + (paramInt2 + 1) * b, b);
/* 405 */     int m = paramInt1 + 2 + (i + 1) * b;
/*     */     
/* 407 */     return new int[] { j + m, k + m };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] setIndexValue(byte[] paramArrayOfByte1, int[] paramArrayOfInt, int paramInt, byte[] paramArrayOfByte2) {
/* 415 */     int[] arrayOfInt = getIndexOffsets(paramArrayOfByte1, paramArrayOfInt[0], paramInt);
/*     */     
/* 417 */     if (arrayOfInt[1] - arrayOfInt[0] == paramArrayOfByte2.length) {
/* 418 */       System.arraycopy(paramArrayOfByte2, 0, paramArrayOfByte1, arrayOfInt[0], paramArrayOfByte2.length);
/*     */     } else {
/*     */       
/* 421 */       int i = getIndexSize(paramArrayOfByte1, paramArrayOfInt[0]);
/* 422 */       byte[] arrayOfByte = new byte[i + paramArrayOfByte2.length - arrayOfInt[1] + arrayOfInt[0]];
/* 423 */       System.arraycopy(paramArrayOfByte1, paramArrayOfInt[0], arrayOfByte, 0, arrayOfInt[0] - paramArrayOfInt[0]);
/* 424 */       System.arraycopy(paramArrayOfByte2, 0, arrayOfByte, arrayOfInt[0] - paramArrayOfInt[0], paramArrayOfByte2.length);
/* 425 */       System.arraycopy(paramArrayOfByte1, arrayOfInt[1], arrayOfByte, arrayOfInt[0] - paramArrayOfInt[0] + paramArrayOfByte2.length, i + paramArrayOfInt[0] - arrayOfInt[1]);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 430 */       int j = getIndexCount(paramArrayOfByte1, paramArrayOfInt[0]);
/* 431 */       byte b = paramArrayOfByte1[paramArrayOfInt[0] + 2];
/* 432 */       int k = paramArrayOfByte2.length - arrayOfInt[1] - arrayOfInt[0]; byte b1;
/*     */       int m;
/* 434 */       for (b1 = 0, m = 3; b1 < j + 1; b1++, m += b) {
/* 435 */         if (b1 > paramInt) {
/* 436 */           encodeNUMBER(arrayOfByte, m, TTFontInfo.getNUMBER(paramArrayOfByte1, paramArrayOfInt[0] + m, b) + k, b);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 442 */       paramArrayOfInt[0] = 0;
/* 443 */       return arrayOfByte;
/*     */     } 
/*     */     
/* 446 */     return paramArrayOfByte1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void extractIndex(byte[] paramArrayOfByte, int paramInt, BitSet paramBitSet, ByteArrayOutputStream paramByteArrayOutputStream) {
/*     */     try {
/* 455 */       DataOutputStream dataOutputStream = new DataOutputStream(paramByteArrayOutputStream);
/* 456 */       int i = TTFontInfo.getUSHORT(paramArrayOfByte, paramInt);
/*     */       
/* 458 */       if (i == 0) {
/* 459 */         dataOutputStream.writeShort(i);
/* 460 */         dataOutputStream.flush();
/*     */         
/*     */         return;
/*     */       } 
/* 464 */       byte b = paramArrayOfByte[paramInt + 2];
/* 465 */       int j = paramInt + 3;
/* 466 */       int k = j + b * (i + 1);
/*     */       
/* 468 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 469 */       dataOutputStream.writeShort(i);
/* 470 */       dataOutputStream.writeByte(2);
/*     */ 
/*     */ 
/*     */       
/* 474 */       dataOutputStream.writeShort(1);
/* 475 */       for (byte b1 = 0; b1 < i; b1++) {
/* 476 */         if (!b1 || paramBitSet.get(b1)) {
/* 477 */           int m = TTFontInfo.getNUMBER(paramArrayOfByte, j + b1 * b, b) - 1;
/*     */           
/* 479 */           int n = TTFontInfo.getNUMBER(paramArrayOfByte, j + (b1 + 1) * b, b) - 1;
/*     */ 
/*     */           
/* 482 */           byteArrayOutputStream.write(paramArrayOfByte, k + m, n - m);
/*     */         } 
/*     */         
/* 485 */         dataOutputStream.writeShort(byteArrayOutputStream.size() + 1);
/*     */       } 
/*     */       
/* 488 */       dataOutputStream.write(byteArrayOutputStream.toByteArray());
/* 489 */       dataOutputStream.flush();
/* 490 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void encodeNUMBER(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3) {
/* 499 */     for (int i = 0; i < paramInt3; i++) {
/* 500 */       paramArrayOfByte[paramInt1 + paramInt3 - i - 1] = (byte)(paramInt2 >>> i & 0xFF);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getDictInt(byte[] paramArrayOfByte, int paramInt1, int paramInt2, String paramString) {
/* 509 */     int i = -1;
/*     */     
/* 511 */     for (int j = paramInt1; j < paramInt2; ) {
/* 512 */       Op op = getOp(paramArrayOfByte, j);
/* 513 */       if (op.getType() == 1) {
/* 514 */         i = op.getInt();
/*     */       }
/* 516 */       else if (op.getType() == 3 && op.getOp().equals(paramString)) {
/* 517 */         return i;
/*     */       } 
/*     */       
/* 520 */       j += op.length();
/*     */     } 
/*     */     
/* 523 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int[] getDictIntArray(byte[] paramArrayOfByte, int paramInt1, int paramInt2, String paramString) {
/* 531 */     int[] arrayOfInt = new int[256];
/* 532 */     byte b = 0;
/*     */     
/* 534 */     for (int i = paramInt1; i < paramInt2; ) {
/* 535 */       Op op = getOp(paramArrayOfByte, i);
/* 536 */       if (op.getType() == 1) {
/* 537 */         arrayOfInt[b++] = op.getInt();
/*     */       }
/* 539 */       else if (op.getType() == 3) {
/* 540 */         if (op.getOp().equals(paramString)) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 545 */         b = 0;
/*     */       } 
/*     */       
/* 548 */       i += op.length();
/*     */     } 
/*     */     
/* 551 */     if (b > 0) {
/* 552 */       int[] arrayOfInt1 = new int[b];
/* 553 */       System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, b);
/* 554 */       return arrayOfInt1;
/*     */     } 
/*     */     
/* 557 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] setDictInt(byte[] paramArrayOfByte, int[] paramArrayOfInt, String paramString, int paramInt) {
/* 568 */     byte[] arrayOfByte = encodeDictInt(paramInt);
/* 569 */     Op op = null;
/*     */     
/* 571 */     for (int i = paramArrayOfInt[0]; i < paramArrayOfInt[1]; ) {
/* 572 */       Op op1 = getOp(paramArrayOfByte, i);
/* 573 */       if (op1.getType() == 1) {
/* 574 */         op = op1;
/*     */       
/*     */       }
/* 577 */       else if (op1.getType() == 3 && op1.getOp().equals(paramString)) {
/* 578 */         if (op.length() == arrayOfByte.length) {
/* 579 */           for (int j = 0; j < arrayOfByte.length; j++) {
/* 580 */             paramArrayOfByte[i - arrayOfByte.length + j] = arrayOfByte[j];
/*     */           }
/*     */           
/* 583 */           return paramArrayOfByte;
/*     */         } 
/*     */ 
/*     */         
/* 587 */         i -= op.length();
/* 588 */         byte[] arrayOfByte1 = new byte[paramArrayOfInt[1] - paramArrayOfInt[0] + arrayOfByte.length - op.length()];
/*     */         
/* 590 */         System.arraycopy(paramArrayOfByte, paramArrayOfInt[0], arrayOfByte1, 0, i - paramArrayOfInt[0]);
/* 591 */         System.arraycopy(arrayOfByte, 0, arrayOfByte1, i - paramArrayOfInt[0], arrayOfByte.length);
/* 592 */         System.arraycopy(paramArrayOfByte, i + op.length(), arrayOfByte1, i - paramArrayOfInt[0] + arrayOfByte.length, paramArrayOfInt[1] - i - op.length());
/*     */ 
/*     */         
/* 595 */         paramArrayOfInt[0] = 0;
/* 596 */         paramArrayOfInt[1] = arrayOfByte1.length;
/* 597 */         return arrayOfByte1;
/*     */       } 
/*     */ 
/*     */       
/* 601 */       i += op1.length();
/*     */     } 
/*     */     
/* 604 */     throw new RuntimeException("DICT operator not found: " + paramString);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\CFF.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */