package inetsoft.report.pdf;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.BitSet;

class CFF {
  public static void extract(RandomAccessFile paramRandomAccessFile, int paramInt1, int paramInt2, ByteArrayOutputStream paramByteArrayOutputStream, BitSet paramBitSet) throws IOException {
    byte[] arrayOfByte1 = new byte[paramInt2];
    paramRandomAccessFile.seek(paramInt1);
    paramRandomAccessFile.readFully(arrayOfByte1);
    ByteArrayOutputStream byteArrayOutputStream1 = new ByteArrayOutputStream();
    ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
    byte b = arrayOfByte1[3];
    int i = 4;
    for (byte b1 = 0; b1 < 4; b1++)
      i += getIndexSize(arrayOfByte1, i); 
    i += 32;
    int j = 4;
    byteArrayOutputStream1.write(arrayOfByte1, 0, 4);
    j += copyIndex(arrayOfByte1, j, byteArrayOutputStream1);
    byte[] arrayOfByte2 = arrayOfByte1;
    int[] arrayOfInt = { j };
    int k = getIndexCount(arrayOfByte2, arrayOfInt[0]);
    j += getIndexSize(arrayOfByte1, j);
    for (byte b2 = 0; b2 < k; b2++) {
      int[] arrayOfInt1 = getIndexOffsets(arrayOfByte2, arrayOfInt[0], b2);
      int m = getDictInt(arrayOfByte2, arrayOfInt1[0], arrayOfInt1[1], "CharStrings");
      int n = getIndexCount(arrayOfByte1, m);
      int i1 = getDictInt(arrayOfByte2, arrayOfInt1[0], arrayOfInt1[1], "charset");
      int[] arrayOfInt2 = { getDictInt(arrayOfByte2, arrayOfInt1[0], arrayOfInt1[1], "FDArray") };
      int i2 = getDictInt(arrayOfByte2, arrayOfInt1[0], arrayOfInt1[1], "FDSelect");
      int[] arrayOfInt3 = getDictIntArray(arrayOfByte2, arrayOfInt1[0], arrayOfInt1[1], "Private");
      int i3 = 0;
      if (arrayOfInt3 != null)
        i3 = getDictInt(arrayOfByte1, arrayOfInt3[1], arrayOfInt3[0] + arrayOfInt3[1], "Subrs"); 
      byte[] arrayOfByte3 = arrayOfByte2;
      arrayOfByte3 = setDictInt(arrayOfByte3, arrayOfInt1, "CharStrings", byteArrayOutputStream2.size() + i);
      extractIndex(arrayOfByte1, m, paramBitSet, byteArrayOutputStream2);
      arrayOfByte3 = setDictInt(arrayOfByte3, arrayOfInt1, "charset", byteArrayOutputStream2.size() + i);
      copyCharsets(arrayOfByte1, i1, n, byteArrayOutputStream2);
      byte[] arrayOfByte4 = arrayOfByte1;
      int i4 = getIndexCount(arrayOfByte4, arrayOfInt2[0]);
      for (byte b3 = 0; b3 < i4; b3++) {
        byte[] arrayOfByte = arrayOfByte4;
        int[] arrayOfInt4 = getIndexOffsets(arrayOfByte4, arrayOfInt2[0], b3);
        int[] arrayOfInt5 = getDictIntArray(arrayOfByte, arrayOfInt4[0], arrayOfInt4[1], "Private");
        if (arrayOfInt5 != null) {
          if (arrayOfInt5.length != 2)
            throw new RuntimeException("Private OP wrong size: " + arrayOfInt5.length); 
          arrayOfByte = setDictInt(arrayOfByte4, arrayOfInt4, "Private", byteArrayOutputStream2.size() + i);
          byteArrayOutputStream2.write(arrayOfByte1, arrayOfInt5[1], arrayOfInt5[0]);
          if (arrayOfByte != arrayOfByte4)
            arrayOfByte4 = setIndexValue(arrayOfByte4, arrayOfInt2, b3, arrayOfByte); 
        } 
      } 
      arrayOfByte3 = setDictInt(arrayOfByte3, arrayOfInt1, "FDArray", byteArrayOutputStream2.size() + i);
      copyIndex(arrayOfByte4, arrayOfInt2[0], byteArrayOutputStream2);
      arrayOfByte3 = setDictInt(arrayOfByte3, arrayOfInt1, "FDSelect", byteArrayOutputStream2.size() + i);
      copyFDSelect(arrayOfByte1, i2, n, byteArrayOutputStream2);
      if (arrayOfInt3 != null) {
        arrayOfByte3 = setDictInt(arrayOfByte3, arrayOfInt1, "Private", byteArrayOutputStream2.size() + i);
        byteArrayOutputStream2.write(arrayOfByte1, arrayOfInt3[1], arrayOfInt3[0]);
        copyIndex(arrayOfByte1, arrayOfInt3[1] + i3, byteArrayOutputStream2);
      } 
      if (arrayOfByte3 != arrayOfByte2)
        arrayOfByte2 = setIndexValue(arrayOfByte2, arrayOfInt, b2, arrayOfByte3); 
    } 
    copyIndex(arrayOfByte2, arrayOfInt[0], byteArrayOutputStream1);
    j += copyIndex(arrayOfByte1, j, byteArrayOutputStream1);
    j += copyIndex(arrayOfByte1, j, byteArrayOutputStream1);
    if (byteArrayOutputStream1.size() < i) {
      byteArrayOutputStream1.write(new byte[i - byteArrayOutputStream1.size()]);
    } else if (byteArrayOutputStream1.size() > i) {
      throw new RuntimeException("CFF sizes incorrect!");
    } 
    byteArrayOutputStream1.write(byteArrayOutputStream2.toByteArray());
    paramByteArrayOutputStream.write(byteArrayOutputStream1.toByteArray());
  }
  
  static class Op {
    public static final int INT = 1;
    
    public static final int DOUBLE = 2;
    
    public static final int OP = 3;
    
    int type;
    
    int inumber;
    
    double dnumber;
    
    String op;
    
    int len;
    
    public Op(int param1Int1, int param1Int2) {
      this.inumber = param1Int1;
      this.len = param1Int2;
      this.type = 1;
    }
    
    public Op(double param1Double, int param1Int) {
      this.dnumber = param1Double;
      this.len = param1Int;
      this.type = 2;
    }
    
    public Op(String param1String, int param1Int) {
      this.op = param1String;
      this.len = param1Int;
      this.type = 3;
    }
    
    public int getType() { return this.type; }
    
    public int getInt() { return this.inumber; }
    
    public double getDouble() { return this.dnumber; }
    
    public String getOp() { return this.op; }
    
    public int length() { return this.len; }
    
    public String toString() {
      switch (this.type) {
        case 3:
          return this.op;
        case 1:
          return this.inumber + " [" + this.len + "]";
        case 2:
          return this.dnumber + " [" + this.len + "]";
      } 
      return "null";
    }
  }
  
  static final String[] ops = { 
      "version", "Notice", "FullName", "FamilyName", "Weight", "FontBBox", "6", "7", "8", "9", 
      "10", "11", "12", "UniqueID", "XUID", "charset", "Encoding", "CharStrings", "Private", "Subrs", 
      "20" };
  
  static final String[] ops2 = { 
      "Copyright", "isFixedPitch", "ItalicAngle", "UnderlinePosition", "UnderlineThickness", "PaintType", "CharstringType", "FontMatrix", "StrokeWidth", "9", 
      "", "", "", "", "", "", "", "", "", "", 
      "SyntheticBase", "PostScript", "BaseFontName", "BaseFontBlend", "MultipleMaster", "", "BlendAxisType", "27", "28", "29", 
      "ROS", "CIDFontVersion", "CIDFontRevision", "CIDFontType", "CIDCount", "UIDBase", "FDArray", "FDSelect", "FontName", "Chameleon" };
  
  static Op getOp(byte[] paramArrayOfByte, int paramInt) {
    byte b = paramArrayOfByte[paramInt] & 0xFF;
    if (b == 12)
      return new Op(ops2[paramArrayOfByte[paramInt + 1] & 0xFF], 2); 
    if ((b >= 0 && b <= 27) || b == 31)
      return new Op((b < ops.length) ? ops[b] : "", 1); 
    if (b >= 32 && b <= 246)
      return new Op(b - 139, 1); 
    if (b >= 247 && b <= 250) {
      byte b1 = paramArrayOfByte[paramInt + 1] & 0xFF;
      return new Op((b - 247) * 256 + b1 + 108, 2);
    } 
    if (b >= 251 && b <= 254) {
      byte b1 = paramArrayOfByte[paramInt + 1] & 0xFF;
      return new Op(-(b - 251) * 256 - b1 - 108, 2);
    } 
    if (b == 28) {
      byte b1 = paramArrayOfByte[paramInt + 1] & 0xFF;
      byte b2 = paramArrayOfByte[paramInt + 2] & 0xFF;
      return new Op(b1 << 8 | b2, 3);
    } 
    if (b == 29) {
      byte b1 = paramArrayOfByte[paramInt + 1] & 0xFF;
      byte b2 = paramArrayOfByte[paramInt + 2] & 0xFF;
      byte b3 = paramArrayOfByte[paramInt + 3] & 0xFF;
      byte b4 = paramArrayOfByte[paramInt + 4] & 0xFF;
      return new Op(b1 << 24 | b2 << 16 | b3 << 8 | b4, 5);
    } 
    if (b == 30) {
      for (int i = paramInt + 1; i < paramArrayOfByte.length; i++) {
        if ((paramArrayOfByte[i] & 0xF) == 15)
          return new Op(0.1D, i - paramInt + 1); 
      } 
      return new Op(0.1D, paramArrayOfByte.length - paramInt);
    } 
    return null;
  }
  
  static byte[] encodeDictInt(int paramInt) {
    if (paramInt >= -107 && paramInt <= 107)
      return new byte[] { (byte)(paramInt + 139) }; 
    if (paramInt >= 108 && paramInt <= 1131) {
      int i = (paramInt - 108) % 256;
      int j = (paramInt - 108) / 256 + 247;
      return new byte[] { (byte)j, (byte)i };
    } 
    if (paramInt >= -1131 && paramInt <= -108) {
      int i = (paramInt + 108) % 256;
      int j = -(paramInt + 108) / 256 + 251;
      return new byte[] { (byte)j, (byte)i };
    } 
    if (paramInt >= -32768 && paramInt <= 32767)
      return new byte[] { 28, (byte)(paramInt >>> 8 & 0xFF), (byte)(paramInt & 0xFF) }; 
    return new byte[] { 29, (byte)(paramInt >>> 24 & 0xFF), (byte)(paramInt >>> 16 & 0xFF), (byte)(paramInt >>> 8 & 0xFF), (byte)(paramInt & 0xFF) };
  }
  
  static int copyCharsets(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ByteArrayOutputStream paramByteArrayOutputStream) {
    int j;
    byte b;
    int i = paramByteArrayOutputStream.size();
    paramByteArrayOutputStream.write(paramArrayOfByte[paramInt1]);
    switch (paramArrayOfByte[paramInt1]) {
      case 0:
        paramByteArrayOutputStream.write(paramArrayOfByte, paramInt1 + 1, 2 * (paramInt2 - 1));
        break;
      case 1:
      case 2:
        b = (paramArrayOfByte[paramInt1] == 1) ? 1 : 2;
        paramInt2--;
        for (j = paramInt1 + 1; paramInt2 > 0; j += b + 2) {
          paramByteArrayOutputStream.write(paramArrayOfByte, j, b + 2);
          paramInt2 -= TTFontInfo.getNUMBER(paramArrayOfByte, j + 2, b) + 1;
        } 
        break;
    } 
    return paramByteArrayOutputStream.size() - i;
  }
  
  static int copyFDSelect(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ByteArrayOutputStream paramByteArrayOutputStream) {
    int j, i = paramByteArrayOutputStream.size();
    paramByteArrayOutputStream.write(paramArrayOfByte[paramInt1]);
    switch (paramArrayOfByte[paramInt1]) {
      case 0:
        paramByteArrayOutputStream.write(paramArrayOfByte, paramInt1 + 1, paramInt2);
        break;
      case 3:
        j = TTFontInfo.getUSHORT(paramArrayOfByte, paramInt1 + 1);
        paramByteArrayOutputStream.write(paramArrayOfByte, paramInt1 + 1, j * 3 + 4);
        break;
    } 
    return paramByteArrayOutputStream.size() - i;
  }
  
  static int copyIndex(byte[] paramArrayOfByte, int paramInt, ByteArrayOutputStream paramByteArrayOutputStream) throws IOException {
    int i = getIndexSize(paramArrayOfByte, paramInt);
    paramByteArrayOutputStream.write(paramArrayOfByte, paramInt, i);
    return i;
  }
  
  static int getIndexSize(byte[] paramArrayOfByte, int paramInt) {
    int i = TTFontInfo.getUSHORT(paramArrayOfByte, paramInt);
    if (i == 0)
      return 2; 
    byte b = paramArrayOfByte[paramInt + 2];
    int j = TTFontInfo.getNUMBER(paramArrayOfByte, paramInt + 3 + i * b, b);
    return j + 2 + (i + 1) * b;
  }
  
  static int getIndexCount(byte[] paramArrayOfByte, int paramInt) { return TTFontInfo.getUSHORT(paramArrayOfByte, paramInt); }
  
  static int[] getIndexOffsets(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    int i = TTFontInfo.getUSHORT(paramArrayOfByte, paramInt1);
    if (i == 0)
      return new int[] { 0, 0 }; 
    byte b = paramArrayOfByte[paramInt1 + 2];
    int j = TTFontInfo.getNUMBER(paramArrayOfByte, paramInt1 + 3 + paramInt2 * b, b);
    int k = TTFontInfo.getNUMBER(paramArrayOfByte, paramInt1 + 3 + (paramInt2 + 1) * b, b);
    int m = paramInt1 + 2 + (i + 1) * b;
    return new int[] { j + m, k + m };
  }
  
  static byte[] setIndexValue(byte[] paramArrayOfByte1, int[] paramArrayOfInt, int paramInt, byte[] paramArrayOfByte2) {
    int[] arrayOfInt = getIndexOffsets(paramArrayOfByte1, paramArrayOfInt[0], paramInt);
    if (arrayOfInt[1] - arrayOfInt[0] == paramArrayOfByte2.length) {
      System.arraycopy(paramArrayOfByte2, 0, paramArrayOfByte1, arrayOfInt[0], paramArrayOfByte2.length);
    } else {
      int i = getIndexSize(paramArrayOfByte1, paramArrayOfInt[0]);
      byte[] arrayOfByte = new byte[i + paramArrayOfByte2.length - arrayOfInt[1] + arrayOfInt[0]];
      System.arraycopy(paramArrayOfByte1, paramArrayOfInt[0], arrayOfByte, 0, arrayOfInt[0] - paramArrayOfInt[0]);
      System.arraycopy(paramArrayOfByte2, 0, arrayOfByte, arrayOfInt[0] - paramArrayOfInt[0], paramArrayOfByte2.length);
      System.arraycopy(paramArrayOfByte1, arrayOfInt[1], arrayOfByte, arrayOfInt[0] - paramArrayOfInt[0] + paramArrayOfByte2.length, i + paramArrayOfInt[0] - arrayOfInt[1]);
      int j = getIndexCount(paramArrayOfByte1, paramArrayOfInt[0]);
      byte b = paramArrayOfByte1[paramArrayOfInt[0] + 2];
      int k = paramArrayOfByte2.length - arrayOfInt[1] - arrayOfInt[0];
      byte b1;
      int m;
      for (b1 = 0, m = 3; b1 < j + 1; b1++, m += b) {
        if (b1 > paramInt)
          encodeNUMBER(arrayOfByte, m, TTFontInfo.getNUMBER(paramArrayOfByte1, paramArrayOfInt[0] + m, b) + k, b); 
      } 
      paramArrayOfInt[0] = 0;
      return arrayOfByte;
    } 
    return paramArrayOfByte1;
  }
  
  static void extractIndex(byte[] paramArrayOfByte, int paramInt, BitSet paramBitSet, ByteArrayOutputStream paramByteArrayOutputStream) {
    try {
      DataOutputStream dataOutputStream = new DataOutputStream(paramByteArrayOutputStream);
      int i = TTFontInfo.getUSHORT(paramArrayOfByte, paramInt);
      if (i == 0) {
        dataOutputStream.writeShort(i);
        dataOutputStream.flush();
        return;
      } 
      byte b = paramArrayOfByte[paramInt + 2];
      int j = paramInt + 3;
      int k = j + b * (i + 1);
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      dataOutputStream.writeShort(i);
      dataOutputStream.writeByte(2);
      dataOutputStream.writeShort(1);
      for (byte b1 = 0; b1 < i; b1++) {
        if (!b1 || paramBitSet.get(b1)) {
          int m = TTFontInfo.getNUMBER(paramArrayOfByte, j + b1 * b, b) - 1;
          int n = TTFontInfo.getNUMBER(paramArrayOfByte, j + (b1 + 1) * b, b) - 1;
          byteArrayOutputStream.write(paramArrayOfByte, k + m, n - m);
        } 
        dataOutputStream.writeShort(byteArrayOutputStream.size() + 1);
      } 
      dataOutputStream.write(byteArrayOutputStream.toByteArray());
      dataOutputStream.flush();
    } catch (IOException iOException) {}
  }
  
  static void encodeNUMBER(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3) {
    for (int i = 0; i < paramInt3; i++)
      paramArrayOfByte[paramInt1 + paramInt3 - i - 1] = (byte)(paramInt2 >>> i & 0xFF); 
  }
  
  static int getDictInt(byte[] paramArrayOfByte, int paramInt1, int paramInt2, String paramString) {
    int i = -1;
    for (int j = paramInt1; j < paramInt2; ) {
      Op op = getOp(paramArrayOfByte, j);
      if (op.getType() == 1) {
        i = op.getInt();
      } else if (op.getType() == 3 && op.getOp().equals(paramString)) {
        return i;
      } 
      j += op.length();
    } 
    return -1;
  }
  
  static int[] getDictIntArray(byte[] paramArrayOfByte, int paramInt1, int paramInt2, String paramString) {
    int[] arrayOfInt = new int[256];
    byte b = 0;
    for (int i = paramInt1; i < paramInt2; ) {
      Op op = getOp(paramArrayOfByte, i);
      if (op.getType() == 1) {
        arrayOfInt[b++] = op.getInt();
      } else if (op.getType() == 3) {
        if (op.getOp().equals(paramString))
          break; 
        b = 0;
      } 
      i += op.length();
    } 
    if (b > 0) {
      int[] arrayOfInt1 = new int[b];
      System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, b);
      return arrayOfInt1;
    } 
    return null;
  }
  
  static byte[] setDictInt(byte[] paramArrayOfByte, int[] paramArrayOfInt, String paramString, int paramInt) {
    byte[] arrayOfByte = encodeDictInt(paramInt);
    Op op = null;
    for (int i = paramArrayOfInt[0]; i < paramArrayOfInt[1]; ) {
      Op op1 = getOp(paramArrayOfByte, i);
      if (op1.getType() == 1) {
        op = op1;
      } else if (op1.getType() == 3 && op1.getOp().equals(paramString)) {
        if (op.length() == arrayOfByte.length) {
          for (int j = 0; j < arrayOfByte.length; j++)
            paramArrayOfByte[i - arrayOfByte.length + j] = arrayOfByte[j]; 
          return paramArrayOfByte;
        } 
        i -= op.length();
        byte[] arrayOfByte1 = new byte[paramArrayOfInt[1] - paramArrayOfInt[0] + arrayOfByte.length - op.length()];
        System.arraycopy(paramArrayOfByte, paramArrayOfInt[0], arrayOfByte1, 0, i - paramArrayOfInt[0]);
        System.arraycopy(arrayOfByte, 0, arrayOfByte1, i - paramArrayOfInt[0], arrayOfByte.length);
        System.arraycopy(paramArrayOfByte, i + op.length(), arrayOfByte1, i - paramArrayOfInt[0] + arrayOfByte.length, paramArrayOfInt[1] - i - op.length());
        paramArrayOfInt[0] = 0;
        paramArrayOfInt[1] = arrayOfByte1.length;
        return arrayOfByte1;
      } 
      i += op1.length();
    } 
    throw new RuntimeException("DICT operator not found: " + paramString);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\CFF.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */