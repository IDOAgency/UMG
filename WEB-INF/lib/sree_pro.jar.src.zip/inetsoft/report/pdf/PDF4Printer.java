/*     */ package inetsoft.report.pdf;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import java.awt.Font;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.BitSet;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PDF4Printer
/*     */   extends PDF3Printer
/*     */ {
/*     */   public PDF4Printer() {}
/*     */   
/*  50 */   public PDF4Printer(OutputStream paramOutputStream) { super(paramOutputStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public void setEmbedCMap(boolean paramBoolean) { this.embedCMap = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public boolean isEmbedCMap() { return this.embedCMap; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFontName(Font paramFont) {
/*  73 */     String str1 = Common.getFontName(paramFont);
/*  74 */     String str2 = (String)this.fontmap.get(str1.toLowerCase());
/*     */ 
/*     */     
/*  77 */     if (str2 != null && this.fontMgr.exists(str2)) {
/*  78 */       return str2;
/*     */     }
/*     */     
/*  81 */     return super.getFontName(paramFont);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int stringWidth(String paramString) {
/*  88 */     if (this.fontMgr.getCJKInfo(this.psFontName) != null) {
/*  89 */       FontInfo fontInfo = this.fontMgr.getFontInfo(this.psFontName);
/*  90 */       if (fontInfo != null) {
/*  91 */         return fontInfo.stringWidth(paramString, this.font.getSize());
/*     */       }
/*     */     } 
/*     */     
/*  95 */     return super.stringWidth(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void emitFont(Font paramFont) {
/* 102 */     this.psFontName = getFontName(paramFont);
/* 103 */     String[] arrayOfString = this.fontMgr.getCJKInfo(this.psFontName);
/*     */     
/* 105 */     if (arrayOfString == null) {
/* 106 */       super.emitFont(paramFont);
/*     */       
/*     */       return;
/*     */     } 
/* 110 */     startPage();
/* 111 */     debug(this.pg, "%emitFont4");
/*     */     
/* 113 */     String str = (String)this.fontFn.get(this.psFontName);
/* 114 */     if (str == null) {
/* 115 */       str = "F" + getNextFontIndex();
/*     */       
/* 117 */       String str1 = (String)this.fontObj.get(this.psFontName);
/* 118 */       if (str1 == null) {
/* 119 */         FontInfo fontInfo = this.fontMgr.getFontInfo(this.psFontName);
/* 120 */         if (fontInfo == null) {
/* 121 */           super.emitFont(paramFont);
/*     */           
/*     */           return;
/*     */         } 
/* 125 */         int i = getNextObjectID();
/* 126 */         str1 = i + " 0 R";
/* 127 */         this.fontObj.put(this.psFontName, str1);
/*     */         
/* 129 */         boolean bool = fontInfo instanceof TTFontInfo;
/* 130 */         boolean bool1 = (bool && ((TTFontInfo)fontInfo).isCFFont()) ? 1 : 0;
/* 131 */         int[] arrayOfInt1 = fontInfo.getWidths();
/*     */ 
/*     */         
/* 134 */         String str2 = strip(fontInfo.getFullName(), " ");
/* 135 */         String str3 = "";
/*     */         
/* 137 */         if ((paramFont.getStyle() & true) != 0) {
/* 138 */           str3 = str3 + "Bold";
/*     */         }
/*     */         
/* 141 */         if ((paramFont.getStyle() & 0x2) != 0) {
/* 142 */           str3 = str3 + "Italic";
/*     */         }
/*     */ 
/*     */         
/* 146 */         if (str3.length() > 0) {
/* 147 */           str2 = str2 + "," + str3;
/*     */         }
/*     */         
/* 150 */         this.others.markObject(i);
/* 151 */         this.others.println(i + " 0 obj");
/* 152 */         this.others.println("<<");
/* 153 */         this.others.println("/Type /Font");
/* 154 */         this.others.println("/Subtype /Type0");
/* 155 */         this.others.println("/BaseFont /" + str2);
/*     */         
/* 157 */         Integer integer = null;
/*     */         
/* 159 */         if (isEmbedCMap()) {
/* 160 */           integer = (Integer)this.cmapmap.get(arrayOfString[1]);
/* 161 */           if (integer == null) {
/* 162 */             integer = new Integer(getNextObjectID());
/*     */           }
/*     */           
/* 165 */           this.others.println("/Encoding " + integer + " 0 R");
/*     */         } else {
/*     */           
/* 168 */           this.others.println("/Encoding /" + arrayOfString[1]);
/*     */         } 
/*     */         
/* 171 */         int j = getNextObjectID();
/* 172 */         this.others.println("/DescendantFonts [" + j + " 0 R]");
/* 173 */         this.others.println(">>");
/* 174 */         this.others.println("endobj");
/*     */         
/* 176 */         this.others.markObject(j);
/* 177 */         this.others.println(j + " 0 obj");
/* 178 */         this.others.println("<<");
/* 179 */         this.others.println("/Type /Font");
/* 180 */         this.others.println("/Subtype /" + ((bool && !bool1) ? "CIDFontType2" : "CIDFontType0"));
/*     */         
/* 182 */         this.others.println("/BaseFont /" + str2);
/* 183 */         this.others.println("/CIDSystemInfo <<");
/* 184 */         this.others.println(" /Registry (Adobe)");
/* 185 */         this.others.println(" /Ordering (" + arrayOfString[0] + ")");
/* 186 */         this.others.println(" /Supplement 2>>");
/*     */         
/* 188 */         int k = getNextObjectID();
/* 189 */         this.others.println("/FontDescriptor " + k + " 0 R");
/* 190 */         this.others.println("/DW 1000");
/*     */ 
/*     */         
/* 193 */         int[] arrayOfInt2 = ((TTFontInfo)fontInfo).getCIDWidths();
/* 194 */         this.others.print("/W [ ");
/* 195 */         for (byte b = 1; b < arrayOfInt2.length; ) {
/* 196 */           byte b1 = b + true;
/* 197 */           for (; b1 < arrayOfInt2.length && arrayOfInt2[b1] == arrayOfInt2[b]; b1++);
/*     */ 
/*     */ 
/*     */           
/* 201 */           if (b1 > b + true) {
/*     */             
/* 203 */             if (arrayOfInt2[b] != 1000) {
/* 204 */               this.others.print(b + " " + (b1 - 1) + " " + arrayOfInt2[b] + " ");
/*     */             }
/*     */             
/* 207 */             b = b1 - 1;
/*     */             continue;
/*     */           } 
/* 210 */           this.others.print(b + " [");
/* 211 */           for (; b < arrayOfInt2.length; b++) {
/*     */             
/* 213 */             if (b < arrayOfInt2.length - 1 && arrayOfInt2[b] == arrayOfInt2[b + 1]) {
/*     */               break;
/*     */             }
/*     */             
/* 217 */             this.others.print(arrayOfInt2[b] + " ");
/*     */           } 
/* 219 */           this.others.print("] ");
/*     */         } 
/*     */         
/* 222 */         this.others.println("]");
/*     */         
/* 224 */         this.others.println(">>");
/* 225 */         this.others.println("endobj");
/*     */         
/* 227 */         emitFontDescriptor(k, str2, paramFont, fontInfo);
/*     */         
/* 229 */         if (integer != null && this.cmapmap.get(arrayOfString[true]) == null) {
/*     */           try {
/* 231 */             InputStream inputStream = CMap.getCMapData(arrayOfString[1]);
/* 232 */             ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 233 */             byte[] arrayOfByte = new byte[256];
/*     */             
/*     */             int m;
/* 236 */             while ((m = inputStream.read(arrayOfByte)) >= 0) {
/* 237 */               byteArrayOutputStream.write(arrayOfByte, 0, m);
/*     */             }
/*     */             
/* 240 */             String[][] arrayOfString1 = { { "/Type", "/CMap" }, { "/CIDSystemInfo", "<<\n/Registry (Adobe)\n/Ordering (" + arrayOfString[0] + ")\n/Supplement 2 >>" }, { "/CMapName", "/" + arrayOfString[1] } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 247 */             emitStream(integer.intValue(), byteArrayOutputStream.toByteArray(), arrayOfString1, true);
/* 248 */             this.cmapmap.put(arrayOfString[1], integer);
/*     */           } catch (Exception exception) {
/* 250 */             exception.printStackTrace();
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 255 */       this.fnList.addElement("/" + str + " " + str1 + " ");
/*     */     } 
/*     */     
/* 258 */     this.pg.println("/" + str + " " + paramFont.getSize() + " Tf");
/* 259 */     this.fontFn.put(this.psFontName, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void emitTj(String paramString) {
/* 266 */     if (this.psFontName != null && this.fontMgr.getCJKInfo(this.psFontName) != null) {
/*     */       try {
/* 268 */         byte[] arrayOfByte = paramString.getBytes("UnicodeBig");
/* 269 */         byte b1 = (arrayOfByte.length > 2 && (arrayOfByte[0] & 0xFF) == 254 && (arrayOfByte[1] & 0xFF) == 255) ? 2 : 0;
/*     */ 
/*     */         
/* 272 */         this.pg.print("<");
/* 273 */         for (byte b2 = b1; b2 < arrayOfByte.length; b2++) {
/* 274 */           String str = "0" + Integer.toString(arrayOfByte[b2] & 0xFF, 16);
/* 275 */           this.pg.print(str.substring(str.length() - 2));
/*     */         } 
/* 277 */         this.pg.println("> Tj");
/*     */ 
/*     */         
/* 280 */         BitSet bitSet = getCIDSet(this.psFontName);
/* 281 */         TTFontInfo tTFontInfo = (TTFontInfo)this.fontMgr.getFontInfo(this.psFontName);
/* 282 */         if (tTFontInfo != null) {
/* 283 */           CMap cMap = tTFontInfo.getCMap();
/*     */           
/* 285 */           for (byte b = 0; b < paramString.length(); b++) {
/* 286 */             bitSet.set(cMap.map(paramString.charAt(b)));
/*     */           }
/*     */         } 
/*     */       } catch (Exception exception) {
/* 290 */         exception.printStackTrace();
/*     */       } 
/*     */     } else {
/*     */       
/* 294 */       super.emitTj(paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 303 */     for (byte b = 0; b < this.fontQ.size(); b++) {
/* 304 */       Object[] arrayOfObject = (Object[])this.fontQ.elementAt(b);
/* 305 */       super.embedFont(((Integer)arrayOfObject[0]).intValue(), (String)arrayOfObject[1], (TTFontInfo)arrayOfObject[2]);
/*     */     } 
/*     */ 
/*     */     
/* 309 */     super.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 318 */   public String getPDFVersion() { return "1.3"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void embedFont(int paramInt, String paramString, TTFontInfo paramTTFontInfo) {
/* 325 */     if (!paramTTFontInfo.isCJKFont()) {
/* 326 */       super.embedFont(paramInt, paramString, paramTTFontInfo);
/*     */     } else {
/*     */       
/* 329 */       this.fontQ.addElement(new Object[] { new Integer(paramInt), paramString, paramTTFontInfo });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getFontData(String paramString, TTFontInfo paramTTFontInfo) throws FileNotFoundException, IOException {
/* 338 */     if (!paramTTFontInfo.isCJKFont()) {
/* 339 */       return super.getFontData(paramString, paramTTFontInfo);
/*     */     }
/*     */     
/* 342 */     return paramTTFontInfo.getFontData(getCIDSet(paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BitSet getCIDSet(String paramString) {
/* 349 */     BitSet bitSet = (BitSet)this.cidsets.get(paramString);
/* 350 */     if (bitSet == null) {
/* 351 */       this.cidsets.put(paramString, bitSet = new BitSet());
/* 352 */       bitSet.set(0);
/*     */     } 
/*     */     
/* 355 */     return bitSet;
/*     */   }
/*     */   
/* 358 */   Hashtable cidsets = new Hashtable();
/* 359 */   Hashtable cmapmap = new Hashtable();
/* 360 */   Vector fontQ = new Vector();
/*     */   boolean embedCMap = false;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\PDF4Printer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */