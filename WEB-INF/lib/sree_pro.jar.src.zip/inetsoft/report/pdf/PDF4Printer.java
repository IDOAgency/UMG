package inetsoft.report.pdf;

import inetsoft.report.Common;
import java.awt.Font;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.BitSet;
import java.util.Hashtable;
import java.util.Vector;

public class PDF4Printer extends PDF3Printer {
  public PDF4Printer() {}
  
  public PDF4Printer(OutputStream paramOutputStream) { super(paramOutputStream); }
  
  public void setEmbedCMap(boolean paramBoolean) { this.embedCMap = paramBoolean; }
  
  public boolean isEmbedCMap() { return this.embedCMap; }
  
  public String getFontName(Font paramFont) {
    String str1 = Common.getFontName(paramFont);
    String str2 = (String)this.fontmap.get(str1.toLowerCase());
    if (str2 != null && this.fontMgr.exists(str2))
      return str2; 
    return super.getFontName(paramFont);
  }
  
  protected int stringWidth(String paramString) {
    if (this.fontMgr.getCJKInfo(this.psFontName) != null) {
      FontInfo fontInfo = this.fontMgr.getFontInfo(this.psFontName);
      if (fontInfo != null)
        return fontInfo.stringWidth(paramString, this.font.getSize()); 
    } 
    return super.stringWidth(paramString);
  }
  
  protected void emitFont(Font paramFont) {
    this.psFontName = getFontName(paramFont);
    String[] arrayOfString = this.fontMgr.getCJKInfo(this.psFontName);
    if (arrayOfString == null) {
      super.emitFont(paramFont);
      return;
    } 
    startPage();
    debug(this.pg, "%emitFont4");
    String str = (String)this.fontFn.get(this.psFontName);
    if (str == null) {
      str = "F" + getNextFontIndex();
      String str1 = (String)this.fontObj.get(this.psFontName);
      if (str1 == null) {
        FontInfo fontInfo = this.fontMgr.getFontInfo(this.psFontName);
        if (fontInfo == null) {
          super.emitFont(paramFont);
          return;
        } 
        int i = getNextObjectID();
        str1 = i + " 0 R";
        this.fontObj.put(this.psFontName, str1);
        boolean bool = fontInfo instanceof TTFontInfo;
        boolean bool1 = (bool && ((TTFontInfo)fontInfo).isCFFont()) ? 1 : 0;
        int[] arrayOfInt1 = fontInfo.getWidths();
        String str2 = strip(fontInfo.getFullName(), " ");
        String str3 = "";
        if ((paramFont.getStyle() & true) != 0)
          str3 = str3 + "Bold"; 
        if ((paramFont.getStyle() & 0x2) != 0)
          str3 = str3 + "Italic"; 
        if (str3.length() > 0)
          str2 = str2 + "," + str3; 
        this.others.markObject(i);
        this.others.println(i + " 0 obj");
        this.others.println("<<");
        this.others.println("/Type /Font");
        this.others.println("/Subtype /Type0");
        this.others.println("/BaseFont /" + str2);
        Integer integer = null;
        if (isEmbedCMap()) {
          integer = (Integer)this.cmapmap.get(arrayOfString[1]);
          if (integer == null)
            integer = new Integer(getNextObjectID()); 
          this.others.println("/Encoding " + integer + " 0 R");
        } else {
          this.others.println("/Encoding /" + arrayOfString[1]);
        } 
        int j = getNextObjectID();
        this.others.println("/DescendantFonts [" + j + " 0 R]");
        this.others.println(">>");
        this.others.println("endobj");
        this.others.markObject(j);
        this.others.println(j + " 0 obj");
        this.others.println("<<");
        this.others.println("/Type /Font");
        this.others.println("/Subtype /" + ((bool && !bool1) ? "CIDFontType2" : "CIDFontType0"));
        this.others.println("/BaseFont /" + str2);
        this.others.println("/CIDSystemInfo <<");
        this.others.println(" /Registry (Adobe)");
        this.others.println(" /Ordering (" + arrayOfString[0] + ")");
        this.others.println(" /Supplement 2>>");
        int k = getNextObjectID();
        this.others.println("/FontDescriptor " + k + " 0 R");
        this.others.println("/DW 1000");
        int[] arrayOfInt2 = ((TTFontInfo)fontInfo).getCIDWidths();
        this.others.print("/W [ ");
        for (byte b = 1; b < arrayOfInt2.length; ) {
          byte b1 = b + true;
          for (; b1 < arrayOfInt2.length && arrayOfInt2[b1] == arrayOfInt2[b]; b1++);
          if (b1 > b + true) {
            if (arrayOfInt2[b] != 1000)
              this.others.print(b + " " + (b1 - 1) + " " + arrayOfInt2[b] + " "); 
            b = b1 - 1;
            continue;
          } 
          this.others.print(b + " [");
          for (; b < arrayOfInt2.length; b++) {
            if (b < arrayOfInt2.length - 1 && arrayOfInt2[b] == arrayOfInt2[b + 1])
              break; 
            this.others.print(arrayOfInt2[b] + " ");
          } 
          this.others.print("] ");
        } 
        this.others.println("]");
        this.others.println(">>");
        this.others.println("endobj");
        emitFontDescriptor(k, str2, paramFont, fontInfo);
        if (integer != null && this.cmapmap.get(arrayOfString[true]) == null)
          try {
            InputStream inputStream = CMap.getCMapData(arrayOfString[1]);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] arrayOfByte = new byte[256];
            int m;
            while ((m = inputStream.read(arrayOfByte)) >= 0)
              byteArrayOutputStream.write(arrayOfByte, 0, m); 
            String[][] arrayOfString1 = { { "/Type", "/CMap" }, { "/CIDSystemInfo", "<<\n/Registry (Adobe)\n/Ordering (" + arrayOfString[0] + ")\n/Supplement 2 >>" }, { "/CMapName", "/" + arrayOfString[1] } };
            emitStream(integer.intValue(), byteArrayOutputStream.toByteArray(), arrayOfString1, true);
            this.cmapmap.put(arrayOfString[1], integer);
          } catch (Exception exception) {
            exception.printStackTrace();
          }  
      } 
      this.fnList.addElement("/" + str + " " + str1 + " ");
    } 
    this.pg.println("/" + str + " " + paramFont.getSize() + " Tf");
    this.fontFn.put(this.psFontName, str);
  }
  
  protected void emitTj(String paramString) {
    if (this.psFontName != null && this.fontMgr.getCJKInfo(this.psFontName) != null) {
      try {
        byte[] arrayOfByte = paramString.getBytes("UnicodeBig");
        byte b1 = (arrayOfByte.length > 2 && (arrayOfByte[0] & 0xFF) == 254 && (arrayOfByte[1] & 0xFF) == 255) ? 2 : 0;
        this.pg.print("<");
        for (byte b2 = b1; b2 < arrayOfByte.length; b2++) {
          String str = "0" + Integer.toString(arrayOfByte[b2] & 0xFF, 16);
          this.pg.print(str.substring(str.length() - 2));
        } 
        this.pg.println("> Tj");
        BitSet bitSet = getCIDSet(this.psFontName);
        TTFontInfo tTFontInfo = (TTFontInfo)this.fontMgr.getFontInfo(this.psFontName);
        if (tTFontInfo != null) {
          CMap cMap = tTFontInfo.getCMap();
          for (byte b = 0; b < paramString.length(); b++)
            bitSet.set(cMap.map(paramString.charAt(b))); 
        } 
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } else {
      super.emitTj(paramString);
    } 
  }
  
  public void close() {
    for (byte b = 0; b < this.fontQ.size(); b++) {
      Object[] arrayOfObject = (Object[])this.fontQ.elementAt(b);
      super.embedFont(((Integer)arrayOfObject[0]).intValue(), (String)arrayOfObject[1], (TTFontInfo)arrayOfObject[2]);
    } 
    super.close();
  }
  
  public String getPDFVersion() { return "1.3"; }
  
  void embedFont(int paramInt, String paramString, TTFontInfo paramTTFontInfo) {
    if (!paramTTFontInfo.isCJKFont()) {
      super.embedFont(paramInt, paramString, paramTTFontInfo);
    } else {
      this.fontQ.addElement(new Object[] { new Integer(paramInt), paramString, paramTTFontInfo });
    } 
  }
  
  byte[] getFontData(String paramString, TTFontInfo paramTTFontInfo) throws FileNotFoundException, IOException {
    if (!paramTTFontInfo.isCJKFont())
      return super.getFontData(paramString, paramTTFontInfo); 
    return paramTTFontInfo.getFontData(getCIDSet(paramString));
  }
  
  BitSet getCIDSet(String paramString) {
    BitSet bitSet = (BitSet)this.cidsets.get(paramString);
    if (bitSet == null) {
      this.cidsets.put(paramString, bitSet = new BitSet());
      bitSet.set(0);
    } 
    return bitSet;
  }
  
  Hashtable cidsets = new Hashtable();
  
  Hashtable cmapmap = new Hashtable();
  
  Vector fontQ = new Vector();
  
  boolean embedCMap = false;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\PDF4Printer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */