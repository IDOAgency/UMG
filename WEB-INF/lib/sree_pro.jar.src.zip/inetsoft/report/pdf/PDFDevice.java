package inetsoft.report.pdf;

import inetsoft.report.Size;
import inetsoft.report.internal.CustomGraphics;
import java.awt.Font;
import java.awt.PrintGraphics;
import java.awt.PrintJob;
import java.io.OutputStream;
import java.io.Serializable;

public interface PDFDevice extends PrintGraphics, Serializable, Cloneable, CustomGraphics {
  void setOutput(OutputStream paramOutputStream);
  
  void setCompressText(boolean paramBoolean);
  
  boolean isCompressText();
  
  void setAsciiOnly(boolean paramBoolean);
  
  boolean isAsciiOnly();
  
  void setCompressImage(boolean paramBoolean);
  
  boolean isCompressImage();
  
  void setMapSymbols(boolean paramBoolean);
  
  boolean isMapSymbols();
  
  Size getPageSize();
  
  void setPageSize(Size paramSize);
  
  String getFontName(Font paramFont);
  
  void putFontName(String paramString1, String paramString2);
  
  PrintJob getPrintJob();
  
  void close();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pdf\PDFDevice.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */