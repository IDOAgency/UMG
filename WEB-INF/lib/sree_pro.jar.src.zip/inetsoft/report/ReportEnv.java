/*     */ package inetsoft.report;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReportEnv
/*     */ {
/*     */   public static String getProperty(String paramString) {
/*  30 */     init();
/*  31 */     String str = prop.getProperty(paramString);
/*     */ 
/*     */     
/*  34 */     if (str != null) {
/*  35 */       str = substitute(str, prop);
/*     */     }
/*     */     
/*  38 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getProperty(String paramString1, String paramString2) {
/*  45 */     init();
/*  46 */     String str = prop.getProperty(paramString1, paramString2);
/*     */ 
/*     */     
/*  49 */     if (str != null) {
/*  50 */       str = substitute(str, prop);
/*     */     }
/*     */     
/*  53 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setProperty(String paramString1, String paramString2) {
/*  60 */     init();
/*  61 */     prop.put(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Properties getProperties() {
/*  68 */     init();
/*  69 */     return prop;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String substitute(String paramString, Properties paramProperties) {
/*  76 */     int i = 0;
/*  77 */     while ((i = paramString.indexOf("$(", i)) >= 0) {
/*  78 */       if (i == 0 || paramString.charAt(i - 1) != '\\') {
/*  79 */         int j = paramString.indexOf(')');
/*     */         
/*  81 */         if (j > i) {
/*  82 */           String str1 = paramString.substring(i + 2, j).trim();
/*  83 */           String str2 = paramProperties.getProperty(str1, "");
/*     */           
/*  85 */           paramString = paramString.substring(0, i) + str2 + paramString.substring(j + 1);
/*  86 */           i += str2.length();
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/*     */         break;
/*     */       } 
/*  93 */       i += 2;
/*     */     } 
/*     */ 
/*     */     
/*  97 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void init() {
/* 105 */     if (prop == null) {
/*     */       try {
/* 107 */         prop = new Properties(System.getProperties());
/*     */       } catch (Exception exception) {
/* 109 */         prop = new Properties();
/*     */       } 
/*     */       
/*     */       try {
/* 113 */         InputStream inputStream = ReportEnv.class.getResourceAsStream("/stylereport.properties");
/*     */         
/* 115 */         if (inputStream != null) {
/* 116 */           prop.load(inputStream);
/*     */           return;
/*     */         } 
/* 119 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 124 */   static Properties prop = null;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\ReportEnv.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */