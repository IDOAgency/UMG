package inetsoft.report;

import java.io.InputStream;
import java.util.Properties;

public class ReportEnv {
  public static String getProperty(String paramString) {
    init();
    String str = prop.getProperty(paramString);
    if (str != null)
      str = substitute(str, prop); 
    return str;
  }
  
  public static String getProperty(String paramString1, String paramString2) {
    init();
    String str = prop.getProperty(paramString1, paramString2);
    if (str != null)
      str = substitute(str, prop); 
    return str;
  }
  
  public static void setProperty(String paramString1, String paramString2) {
    init();
    prop.put(paramString1, paramString2);
  }
  
  public static Properties getProperties() {
    init();
    return prop;
  }
  
  public static String substitute(String paramString, Properties paramProperties) {
    int i = 0;
    while ((i = paramString.indexOf("$(", i)) >= 0) {
      if (i == 0 || paramString.charAt(i - 1) != '\\') {
        int j = paramString.indexOf(')');
        if (j > i) {
          String str1 = paramString.substring(i + 2, j).trim();
          String str2 = paramProperties.getProperty(str1, "");
          paramString = paramString.substring(0, i) + str2 + paramString.substring(j + 1);
          i += str2.length();
          continue;
        } 
        break;
      } 
      i += 2;
    } 
    return paramString;
  }
  
  static void init() {
    if (prop == null) {
      try {
        prop = new Properties(System.getProperties());
      } catch (Exception exception) {
        prop = new Properties();
      } 
      try {
        InputStream inputStream = ReportEnv.class.getResourceAsStream("/stylereport.properties");
        if (inputStream != null) {
          prop.load(inputStream);
          return;
        } 
      } catch (Exception exception) {}
    } 
  }
  
  static Properties prop = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\ReportEnv.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */