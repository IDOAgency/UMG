/*     */ package inetsoft.report;
/*     */ 
/*     */ import inetsoft.report.internal.Win32Graphics;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.PrintGraphics;
/*     */ import java.awt.PrintJob;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Win32Printer
/*     */   extends Win32Graphics
/*     */   implements PrintGraphics
/*     */ {
/*     */   public static final int CREATE_DEFAULT = 0;
/*     */   public static final int CREATE_NEW = 1;
/*     */   
/*     */   public static Win32Printer getPrinter(int paramInt) {
/*  51 */     Win32Printer win32Printer = new Win32Printer();
/*  52 */     if (win32Printer.create0(paramInt) == 0) {
/*  53 */       return null;
/*     */     }
/*     */     
/*  56 */     win32Printer.init();
/*  57 */     return win32Printer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Win32Printer getPrinter(String paramString) {
/*  66 */     Win32Printer win32Printer = new Win32Printer();
/*  67 */     if (win32Printer.create1(paramString) == 0) {
/*  68 */       return null;
/*     */     }
/*     */     
/*  71 */     win32Printer.startDoc0(win32Printer.getJobName());
/*  72 */     win32Printer.init();
/*  73 */     return win32Printer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Win32Printer getPrinter(String paramString1, String paramString2) {
/*  83 */     Win32Printer win32Printer = new Win32Printer();
/*  84 */     if (win32Printer.create1(paramString1) == 0) {
/*  85 */       return null;
/*     */     }
/*     */     
/*  88 */     if (paramString2 != null) {
/*  89 */       win32Printer.setJobName(paramString2);
/*     */     }
/*     */     
/*  92 */     win32Printer.startDoc0(win32Printer.getJobName());
/*  93 */     win32Printer.init();
/*  94 */     return win32Printer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public void setJobName(String paramString) { this.jobname = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public String getJobName() { return this.jobname; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public void setOrientation(int paramInt) { super.setOrientation(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   public int getOrientation() { return super.getOrientation(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   public void setTray(int paramInt) { super.setTray(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   public void setDuplex(boolean paramBoolean) { super.setDuplex(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public boolean isDuplex() { return super.isDuplex(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintJob getPrintJob() {
/* 168 */     if (this.printer == null) {
/* 169 */       this.printer = new Printer(this);
/*     */     }
/*     */     
/* 172 */     return this.printer;
/*     */   }
/*     */   
/*     */   class Printer extends PrintJob {
/*     */     private final Win32Printer this$0;
/*     */     
/* 178 */     Printer(Win32Printer this$0) { this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Graphics getGraphics() {
/* 187 */       this.this$0.nextPage();
/* 188 */       return this.this$0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     public Dimension getPageDimension() { return this.this$0.getPageSize(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 206 */     public int getPageResolution() { return this.this$0.getResolution(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     public boolean lastPageFirst() { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 220 */     public void end() { this.this$0.close(); }
/*     */   }
/*     */ 
/*     */   
/* 224 */   Printer printer = null;
/* 225 */   private String jobname = "Win32Printer";
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Win32Printer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */