package inetsoft.report;

import inetsoft.report.internal.Win32Graphics;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.PrintGraphics;
import java.awt.PrintJob;

public class Win32Printer extends Win32Graphics implements PrintGraphics {
  public static final int CREATE_DEFAULT = 0;
  
  public static final int CREATE_NEW = 1;
  
  public static Win32Printer getPrinter(int paramInt) {
    Win32Printer win32Printer = new Win32Printer();
    if (win32Printer.create0(paramInt) == 0)
      return null; 
    win32Printer.init();
    return win32Printer;
  }
  
  public static Win32Printer getPrinter(String paramString) {
    Win32Printer win32Printer = new Win32Printer();
    if (win32Printer.create1(paramString) == 0)
      return null; 
    win32Printer.startDoc0(win32Printer.getJobName());
    win32Printer.init();
    return win32Printer;
  }
  
  public static Win32Printer getPrinter(String paramString1, String paramString2) {
    Win32Printer win32Printer = new Win32Printer();
    if (win32Printer.create1(paramString1) == 0)
      return null; 
    if (paramString2 != null)
      win32Printer.setJobName(paramString2); 
    win32Printer.startDoc0(win32Printer.getJobName());
    win32Printer.init();
    return win32Printer;
  }
  
  public void setJobName(String paramString) { this.jobname = paramString; }
  
  public String getJobName() { return this.jobname; }
  
  public void setOrientation(int paramInt) { super.setOrientation(paramInt); }
  
  public int getOrientation() { return super.getOrientation(); }
  
  public void setTray(int paramInt) { super.setTray(paramInt); }
  
  public void setDuplex(boolean paramBoolean) { super.setDuplex(paramBoolean); }
  
  public boolean isDuplex() { return super.isDuplex(); }
  
  public PrintJob getPrintJob() {
    if (this.printer == null)
      this.printer = new Printer(this); 
    return this.printer;
  }
  
  class Printer extends PrintJob {
    private final Win32Printer this$0;
    
    Printer(Win32Printer this$0) { this.this$0 = this$0; }
    
    public Graphics getGraphics() {
      this.this$0.nextPage();
      return this.this$0;
    }
    
    public Dimension getPageDimension() { return this.this$0.getPageSize(); }
    
    public int getPageResolution() { return this.this$0.getResolution(); }
    
    public boolean lastPageFirst() { return false; }
    
    public void end() { this.this$0.close(); }
  }
  
  Printer printer = null;
  
  private String jobname = "Win32Printer";
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Win32Printer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */