package inetsoft.report;

public interface TextAreaElement extends FieldElement {
  String getText();
  
  void setText(String paramString);
  
  int getCols();
  
  void setCols(int paramInt);
  
  int getRows();
  
  void setRows(int paramInt);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\TextAreaElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */