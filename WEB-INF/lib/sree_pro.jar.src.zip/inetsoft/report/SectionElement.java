package inetsoft.report;

import java.text.Format;

public interface SectionElement extends ReportElement {
  SectionLens getSection();
  
  void setSection(SectionLens paramSectionLens);
  
  TableLens getTable();
  
  void setTable(TableLens paramTableLens);
  
  ReportElement getElement(String paramString);
  
  Presenter getPresenter(Class paramClass);
  
  void addPresenter(Class paramClass, Presenter paramPresenter);
  
  Format getFormat(Class paramClass);
  
  void addFormat(Class paramClass, Format paramFormat);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\SectionElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */