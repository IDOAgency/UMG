package inetsoft.report;

public interface HeadingLens extends TextLens {
  int getLevel();
  
  String format(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\HeadingLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */