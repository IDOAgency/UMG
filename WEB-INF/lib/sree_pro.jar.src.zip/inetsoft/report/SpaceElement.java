package inetsoft.report;

public interface SpaceElement extends ReportElement {
  int getSpace();
  
  void setSpace(int paramInt);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\SpaceElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */