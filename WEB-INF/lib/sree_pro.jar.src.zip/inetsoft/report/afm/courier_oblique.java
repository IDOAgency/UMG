package inetsoft.report.afm;

import inetsoft.report.internal.AFontMetrics;
import java.awt.Rectangle;
import java.util.Hashtable;

public class courier_oblique extends AFontMetrics {
  public courier_oblique() {
    this.fontName = s_fontName;
    this.fullName = s_fullName;
    this.familyName = s_familyName;
    this.weight = s_weight;
    this.fixedPitch = s_fixedPitch;
    this.italicAngle = s_italicAngle;
    this.ascender = s_ascender;
    this.descender = s_descender;
    this.widths = s_widths;
    this.pairKern = s_pairKern;
    this.advance = s_advance;
    this.bbox = s_bbox;
  }
  
  static String s_fontName = "Courier-Oblique";
  
  static String s_fullName = "Courier";
  
  static String s_familyName = "Courier";
  
  static String s_weight = "Medium";
  
  static boolean s_fixedPitch = true;
  
  static double s_italicAngle = -12.0D;
  
  static int s_ascender = 629;
  
  static int s_descender = 157;
  
  static int s_advance = 600;
  
  static Rectangle s_bbox = new Rectangle(-30, 805, 764, 962);
  
  static int[] s_widths = { 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 600, 600, 600, 600, 600, 600, 600, 600, 
      600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
      600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
      600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
      600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
      600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
      600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
      600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
      600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
      600, 600, 600, 600, 600, 600, 600, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
      600, 600, 600, 600, 600, 600, 0, 600, 600, 600, 
      600, 0, 600, 600, 600, 600, 600, 600, 600, 600, 
      0, 600, 0, 600, 600, 600, 600, 600, 600, 600, 
      600, 0, 600, 600, 0, 600, 600, 600, 600, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 600, 0, 600, 0, 0, 
      0, 0, 600, 600, 600, 600, 0, 0, 0, 0, 
      0, 600, 0, 0, 0, 600, 0, 0, 600, 600, 
      600, 600, 0, 0, 0, 0 };
  
  static Hashtable s_pairKern = new Hashtable();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\afm\courier_oblique.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */