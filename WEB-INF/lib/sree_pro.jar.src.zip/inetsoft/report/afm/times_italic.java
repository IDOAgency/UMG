/*     */ package inetsoft.report.afm;
/*     */ 
/*     */ import inetsoft.report.internal.AFontMetrics;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class times_italic
/*     */   extends AFontMetrics
/*     */ {
/*     */   public times_italic() {
/* 322 */     this.fontName = s_fontName;
/* 323 */     this.fullName = s_fullName;
/* 324 */     this.familyName = s_familyName;
/* 325 */     this.weight = s_weight;
/* 326 */     this.fixedPitch = s_fixedPitch;
/* 327 */     this.italicAngle = s_italicAngle;
/* 328 */     this.ascender = s_ascender;
/* 329 */     this.descender = s_descender;
/* 330 */     this.widths = s_widths;
/* 331 */     this.pairKern = s_pairKern;
/* 332 */     this.advance = s_advance;
/* 333 */     this.bbox = s_bbox;
/*     */   }
/*     */   
/*     */   static String s_fontName = "Times-Italic";
/*     */   static String s_fullName = "Times";
/*     */   static String s_familyName = "Times";
/*     */   static String s_weight = "Medium";
/*     */   static boolean s_fixedPitch = false;
/*     */   static double s_italicAngle = -15.5D;
/*     */   static int s_ascender = 683;
/*     */   static int s_descender = 205;
/*     */   static int s_advance = 1000;
/*     */   static Rectangle s_bbox = new Rectangle(-169, 883, 1179, 1100);
/*     */   static int[] s_widths = { 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 0, 250, 333, 420, 500, 500, 833, 778, 333, 
/*     */       333, 333, 500, 675, 250, 333, 250, 278, 500, 500, 
/*     */       500, 500, 500, 500, 500, 500, 500, 500, 333, 333, 
/*     */       675, 675, 675, 500, 920, 611, 611, 667, 722, 611, 
/*     */       611, 722, 722, 333, 444, 667, 556, 833, 667, 722, 
/*     */       611, 722, 611, 500, 556, 722, 611, 833, 611, 556, 
/*     */       556, 389, 278, 389, 422, 500, 333, 500, 500, 444, 
/*     */       500, 444, 278, 500, 500, 278, 278, 444, 278, 722, 
/*     */       500, 500, 500, 500, 389, 389, 278, 500, 444, 667, 
/*     */       444, 444, 389, 400, 275, 400, 541, 0, 0, 0, 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 389, 500, 500, 167, 500, 500, 500, 500, 214, 
/*     */       556, 500, 333, 333, 500, 500, 0, 500, 500, 500, 
/*     */       250, 0, 523, 350, 333, 556, 556, 500, 889, 1000, 
/*     */       0, 500, 0, 333, 333, 333, 333, 333, 333, 333, 
/*     */       333, 0, 333, 333, 0, 333, 333, 333, 889, 0, 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 0, 0, 0, 0, 889, 0, 276, 0, 0, 
/*     */       0, 0, 556, 722, 944, 310, 0, 0, 0, 0, 
/*     */       0, 667, 0, 0, 0, 278, 0, 0, 278, 500, 
/*     */       667, 500, 0, 0, 0, 0 };
/*     */   static Hashtable s_pairKern = new Hashtable();
/*     */   
/*     */   static  {
/*     */     s_pairKern.put("U,", new Integer(-25));
/*     */     s_pairKern.put("xe", new Integer(0));
/*     */     s_pairKern.put("ky", new Integer(-10));
/*     */     s_pairKern.put("TA", new Integer(-50));
/*     */     s_pairKern.put("Fr", new Integer(-55));
/*     */     s_pairKern.put("Fo", new Integer(-105));
/*     */     s_pairKern.put("T;", new Integer(-65));
/*     */     s_pairKern.put("ko", new Integer(-10));
/*     */     s_pairKern.put("T:", new Integer(-55));
/*     */     s_pairKern.put("`A", new Integer(0));
/*     */     s_pairKern.put("Fi", new Integer(-45));
/*     */     s_pairKern.put("ªA", new Integer(0));
/*     */     s_pairKern.put("Fe", new Integer(-75));
/*     */     s_pairKern.put("ke", new Integer(-10));
/*     */     s_pairKern.put("wo", new Integer(0));
/*     */     s_pairKern.put("Fa", new Integer(-75));
/*     */     s_pairKern.put("T.", new Integer(-74));
/*     */     s_pairKern.put("T-", new Integer(-74));
/*     */     s_pairKern.put("y.", new Integer(-55));
/*     */     s_pairKern.put("T,", new Integer(-74));
/*     */     s_pairKern.put("y,", new Integer(-55));
/*     */     s_pairKern.put("wh", new Integer(0));
/*     */     s_pairKern.put("we", new Integer(0));
/*     */     s_pairKern.put("fõ", new Integer(-60));
/*     */     s_pairKern.put("wa", new Integer(0));
/*     */     s_pairKern.put("RY", new Integer(-18));
/*     */     s_pairKern.put("G.", new Integer(0));
/*     */     s_pairKern.put("RW", new Integer(-18));
/*     */     s_pairKern.put("G,", new Integer(0));
/*     */     s_pairKern.put("RV", new Integer(-18));
/*     */     s_pairKern.put("RU", new Integer(-40));
/*     */     s_pairKern.put("RT", new Integer(0));
/*     */     s_pairKern.put("RO", new Integer(-40));
/*     */     s_pairKern.put("vo", new Integer(0));
/*     */     s_pairKern.put(" `", new Integer(0));
/*     */     s_pairKern.put("S.", new Integer(0));
/*     */     s_pairKern.put("FA", new Integer(-115));
/*     */     s_pairKern.put("S,", new Integer(0));
/*     */     s_pairKern.put(".'", new Integer(-140));
/*     */     s_pairKern.put(" Y", new Integer(-75));
/*     */     s_pairKern.put(" W", new Integer(-40));
/*     */     s_pairKern.put("ve", new Integer(0));
/*     */     s_pairKern.put(" V", new Integer(-35));
/*     */     s_pairKern.put(" T", new Integer(-18));
/*     */     s_pairKern.put("iv", new Integer(0));
/*     */     s_pairKern.put("va", new Integer(0));
/*     */     s_pairKern.put("F.", new Integer(-135));
/*     */     s_pairKern.put("F,", new Integer(-135));
/*     */     s_pairKern.put(": ", new Integer(0));
/*     */     s_pairKern.put("QU", new Integer(-10));
/*     */     s_pairKern.put("Po", new Integer(-80));
/*     */     s_pairKern.put(" A", new Integer(-18));
/*     */     s_pairKern.put("w.", new Integer(-74));
/*     */     s_pairKern.put("w,", new Integer(-74));
/*     */     s_pairKern.put("Aº", new Integer(0));
/*     */     s_pairKern.put("fº", new Integer(0));
/*     */     s_pairKern.put("Pe", new Integer(-80));
/*     */     s_pairKern.put("DY", new Integer(-40));
/*     */     s_pairKern.put("hy", new Integer(0));
/*     */     s_pairKern.put("DW", new Integer(-40));
/*     */     s_pairKern.put("DV", new Integer(-40));
/*     */     s_pairKern.put("Pa", new Integer(-80));
/*     */     s_pairKern.put("Q.", new Integer(0));
/*     */     s_pairKern.put("DA", new Integer(-35));
/*     */     s_pairKern.put("v.", new Integer(-74));
/*     */     s_pairKern.put("Q,", new Integer(0));
/*     */     s_pairKern.put("v,", new Integer(-74));
/*     */     s_pairKern.put(",'", new Integer(-140));
/*     */     s_pairKern.put("gy", new Integer(0));
/*     */     s_pairKern.put(", ", new Integer(0));
/*     */     s_pairKern.put("PA", new Integer(-90));
/*     */     s_pairKern.put("'º", new Integer(0));
/*     */     s_pairKern.put("Lº", new Integer(0));
/*     */     s_pairKern.put("gr", new Integer(0));
/*     */     s_pairKern.put("go", new Integer(0));
/*     */     s_pairKern.put("OY", new Integer(-50));
/*     */     s_pairKern.put("D.", new Integer(0));
/*     */     s_pairKern.put("OX", new Integer(-40));
/*     */     s_pairKern.put("OW", new Integer(-50));
/*     */     s_pairKern.put("sw", new Integer(0));
/*     */     s_pairKern.put("D,", new Integer(0));
/*     */     s_pairKern.put("OV", new Integer(-50));
/*     */     s_pairKern.put("OT", new Integer(-40));
/*     */     s_pairKern.put("gi", new Integer(0));
/*     */     s_pairKern.put("gg", new Integer(-10));
/*     */     s_pairKern.put("ge", new Integer(-10));
/*     */     s_pairKern.put("P.", new Integer(-135));
/*     */     s_pairKern.put("ga", new Integer(0));
/*     */     s_pairKern.put("P,", new Integer(-135));
/*     */     s_pairKern.put("Ay", new Integer(-55));
/*     */     s_pairKern.put("Aw", new Integer(-55));
/*     */     s_pairKern.put("Av", new Integer(-55));
/*     */     s_pairKern.put("Au", new Integer(-20));
/*     */     s_pairKern.put("BU", new Integer(-10));
/*     */     s_pairKern.put("OA", new Integer(-55));
/*     */     s_pairKern.put("Ap", new Integer(0));
/*     */     s_pairKern.put("fo", new Integer(0));
/*     */     s_pairKern.put("ry", new Integer(0));
/*     */     s_pairKern.put("fl", new Integer(0));
/*     */     s_pairKern.put("rv", new Integer(0));
/*     */     s_pairKern.put("ru", new Integer(0));
/*     */     s_pairKern.put("rt", new Integer(0));
/*     */     s_pairKern.put("fi", new Integer(-20));
/*     */     s_pairKern.put("rs", new Integer(-10));
/*     */     s_pairKern.put("rr", new Integer(0));
/*     */     s_pairKern.put("rq", new Integer(-37));
/*     */     s_pairKern.put("ff", new Integer(-18));
/*     */     s_pairKern.put("rp", new Integer(0));
/*     */     s_pairKern.put("fe", new Integer(0));
/*     */     s_pairKern.put("ro", new Integer(-45));
/*     */     s_pairKern.put("rn", new Integer(0));
/*     */     s_pairKern.put("O.", new Integer(0));
/*     */     s_pairKern.put("rm", new Integer(0));
/*     */     s_pairKern.put("BA", new Integer(-25));
/*     */     s_pairKern.put("rl", new Integer(0));
/*     */     s_pairKern.put("fa", new Integer(0));
/*     */     s_pairKern.put("O,", new Integer(0));
/*     */     s_pairKern.put("Yu", new Integer(-92));
/*     */     s_pairKern.put("rk", new Integer(0));
/*     */     s_pairKern.put("ri", new Integer(0));
/*     */     s_pairKern.put("rg", new Integer(-37));
/*     */     s_pairKern.put("AY", new Integer(-55));
/*     */     s_pairKern.put("Yo", new Integer(-92));
/*     */     s_pairKern.put("re", new Integer(-37));
/*     */     s_pairKern.put("ey", new Integer(-30));
/*     */     s_pairKern.put("rd", new Integer(-37));
/*     */     s_pairKern.put("ex", new Integer(-20));
/*     */     s_pairKern.put("AW", new Integer(-95));
/*     */     s_pairKern.put("rc", new Integer(-37));
/*     */     s_pairKern.put("ew", new Integer(-15));
/*     */     s_pairKern.put("AV", new Integer(-105));
/*     */     s_pairKern.put("ev", new Integer(-15));
/*     */     s_pairKern.put("NA", new Integer(-27));
/*     */     s_pairKern.put("AU", new Integer(-50));
/*     */     s_pairKern.put("ra", new Integer(-15));
/*     */     s_pairKern.put("AT", new Integer(-37));
/*     */     s_pairKern.put("Yi", new Integer(-74));
/*     */     s_pairKern.put("AQ", new Integer(-40));
/*     */     s_pairKern.put("ep", new Integer(0));
/*     */     s_pairKern.put("AO", new Integer(-40));
/*     */     s_pairKern.put("Ly", new Integer(-30));
/*     */     s_pairKern.put("Ye", new Integer(-92));
/*     */     s_pairKern.put("'v", new Integer(-10));
/*     */     s_pairKern.put("B.", new Integer(0));
/*     */     s_pairKern.put("'t", new Integer(-30));
/*     */     s_pairKern.put("'s", new Integer(-40));
/*     */     s_pairKern.put("g.", new Integer(-15));
/*     */     s_pairKern.put("B,", new Integer(0));
/*     */     s_pairKern.put("Ya", new Integer(-92));
/*     */     s_pairKern.put("'r", new Integer(-25));
/*     */     s_pairKern.put("g,", new Integer(-10));
/*     */     s_pairKern.put("AG", new Integer(-35));
/*     */     s_pairKern.put("eg", new Integer(-40));
/*     */     s_pairKern.put("'l", new Integer(0));
/*     */     s_pairKern.put("AC", new Integer(-30));
/*     */     s_pairKern.put("N.", new Integer(0));
/*     */     s_pairKern.put("eb", new Integer(0));
/*     */     s_pairKern.put("N,", new Integer(0));
/*     */     s_pairKern.put("'d", new Integer(-25));
/*     */     s_pairKern.put("dy", new Integer(0));
/*     */     s_pairKern.put("YO", new Integer(-15));
/*     */     s_pairKern.put("dw", new Integer(0));
/*     */     s_pairKern.put("dv", new Integer(0));
/*     */     s_pairKern.put("Ky", new Integer(-40));
/*     */     s_pairKern.put("LY", new Integer(-20));
/*     */     s_pairKern.put("py", new Integer(0));
/*     */     s_pairKern.put("LW", new Integer(-55));
/*     */     s_pairKern.put("f.", new Integer(-15));
/*     */     s_pairKern.put("LV", new Integer(-55));
/*     */     s_pairKern.put("Ku", new Integer(-40));
/*     */     s_pairKern.put("YA", new Integer(-50));
/*     */     s_pairKern.put("f,", new Integer(-10));
/*     */     s_pairKern.put("LT", new Integer(-20));
/*     */     s_pairKern.put("A'", new Integer(-37));
/*     */     s_pairKern.put("Ko", new Integer(-40));
/*     */     s_pairKern.put("f'", new Integer(92));
/*     */     s_pairKern.put("Wy", new Integer(-70));
/*     */     s_pairKern.put("Y;", new Integer(-65));
/*     */     s_pairKern.put("dd", new Integer(0));
/*     */     s_pairKern.put("Y:", new Integer(-65));
/*     */     s_pairKern.put("r.", new Integer(-111));
/*     */     s_pairKern.put("Wu", new Integer(-55));
/*     */     s_pairKern.put("r-", new Integer(-20));
/*     */     s_pairKern.put("r,", new Integer(-111));
/*     */     s_pairKern.put("Ke", new Integer(-35));
/*     */     s_pairKern.put("Wo", new Integer(-92));
/*     */     s_pairKern.put("cy", new Integer(0));
/*     */     s_pairKern.put("Y.", new Integer(-92));
/*     */     s_pairKern.put("Y-", new Integer(-74));
/*     */     s_pairKern.put("Y,", new Integer(-92));
/*     */     s_pairKern.put("Wi", new Integer(-55));
/*     */     s_pairKern.put("Wh", new Integer(0));
/*     */     s_pairKern.put("We", new Integer(-92));
/*     */     s_pairKern.put("oy", new Integer(0));
/*     */     s_pairKern.put("ox", new Integer(0));
/*     */     s_pairKern.put("ow", new Integer(0));
/*     */     s_pairKern.put("e.", new Integer(-15));
/*     */     s_pairKern.put("cl", new Integer(0));
/*     */     s_pairKern.put("Ju", new Integer(-35));
/*     */     s_pairKern.put("Wa", new Integer(-92));
/*     */     s_pairKern.put("ov", new Integer(-10));
/*     */     s_pairKern.put("ck", new Integer(-20));
/*     */     s_pairKern.put("e,", new Integer(-10));
/*     */     s_pairKern.put("ch", new Integer(-15));
/*     */     s_pairKern.put("Jo", new Integer(-25));
/*     */     s_pairKern.put("KO", new Integer(-50));
/*     */     s_pairKern.put("Vu", new Integer(-74));
/*     */     s_pairKern.put("''", new Integer(-111));
/*     */     s_pairKern.put("og", new Integer(-10));
/*     */     s_pairKern.put("L'", new Integer(-37));
/*     */     s_pairKern.put("Je", new Integer(-25));
/*     */     s_pairKern.put("Vo", new Integer(-111));
/*     */     s_pairKern.put("by", new Integer(0));
/*     */     s_pairKern.put("WO", new Integer(-25));
/*     */     s_pairKern.put("Ja", new Integer(-35));
/*     */     s_pairKern.put("' ", new Integer(-111));
/*     */     s_pairKern.put("bv", new Integer(0));
/*     */     s_pairKern.put("bu", new Integer(-20));
/*     */     s_pairKern.put("Vi", new Integer(-74));
/*     */     s_pairKern.put("Ve", new Integer(-111));
/*     */     s_pairKern.put("ny", new Integer(0));
/*     */     s_pairKern.put("d.", new Integer(0));
/*     */     s_pairKern.put("bl", new Integer(0));
/*     */     s_pairKern.put("Va", new Integer(-111));
/*     */     s_pairKern.put("nv", new Integer(-40));
/*     */     s_pairKern.put("WA", new Integer(-60));
/*     */     s_pairKern.put(".º", new Integer(-140));
/*     */     s_pairKern.put("nu", new Integer(0));
/*     */     s_pairKern.put("d,", new Integer(0));
/*     */     s_pairKern.put("W;", new Integer(-65));
/*     */     s_pairKern.put("W:", new Integer(-65));
/*     */     s_pairKern.put("bb", new Integer(0));
/*     */     s_pairKern.put("VO", new Integer(-30));
/*     */     s_pairKern.put("ay", new Integer(0));
/*     */     s_pairKern.put("zo", new Integer(0));
/*     */     s_pairKern.put("W.", new Integer(-92));
/*     */     s_pairKern.put("aw", new Integer(0));
/*     */     s_pairKern.put("av", new Integer(0));
/*     */     s_pairKern.put("JA", new Integer(-40));
/*     */     s_pairKern.put("W-", new Integer(-37));
/*     */     s_pairKern.put("W,", new Integer(-92));
/*     */     s_pairKern.put("at", new Integer(0));
/*     */     s_pairKern.put("VG", new Integer(0));
/*     */     s_pairKern.put("ap", new Integer(0));
/*     */     s_pairKern.put("ze", new Integer(0));
/*     */     s_pairKern.put("º ", new Integer(0));
/*     */     s_pairKern.put("my", new Integer(0));
/*     */     s_pairKern.put("c.", new Integer(0));
/*     */     s_pairKern.put("VA", new Integer(-60));
/*     */     s_pairKern.put("mu", new Integer(0));
/*     */     s_pairKern.put("c,", new Integer(0));
/*     */     s_pairKern.put("ag", new Integer(-10));
/*     */     s_pairKern.put("Ty", new Integer(-74));
/*     */     s_pairKern.put("V;", new Integer(-74));
/*     */     s_pairKern.put("V:", new Integer(-65));
/*     */     s_pairKern.put("J.", new Integer(-25));
/*     */     s_pairKern.put("Tw", new Integer(-74));
/*     */     s_pairKern.put("ab", new Integer(0));
/*     */     s_pairKern.put("J,", new Integer(-25));
/*     */     s_pairKern.put("Tu", new Integer(-55));
/*     */     s_pairKern.put("Tr", new Integer(-55));
/*     */     s_pairKern.put("To", new Integer(-92));
/*     */     s_pairKern.put("yo", new Integer(0));
/*     */     s_pairKern.put("V.", new Integer(-129));
/*     */     s_pairKern.put("V-", new Integer(-55));
/*     */     s_pairKern.put("V,", new Integer(-129));
/*     */     s_pairKern.put("Ti", new Integer(-55));
/*     */     s_pairKern.put("Th", new Integer(0));
/*     */     s_pairKern.put("Te", new Integer(-92));
/*     */     s_pairKern.put("ye", new Integer(0));
/*     */     s_pairKern.put("ly", new Integer(0));
/*     */     s_pairKern.put("lw", new Integer(0));
/*     */     s_pairKern.put("b.", new Integer(-40));
/*     */     s_pairKern.put("Ta", new Integer(-92));
/*     */     s_pairKern.put("UA", new Integer(-40));
/*     */     s_pairKern.put("ya", new Integer(0));
/*     */     s_pairKern.put(",º", new Integer(-140));
/*     */     s_pairKern.put("b,", new Integer(0));
/*     */     s_pairKern.put(" ª", new Integer(0));
/*     */     s_pairKern.put("``", new Integer(-111));
/*     */     s_pairKern.put("ª`", new Integer(0));
/*     */     s_pairKern.put("TO", new Integer(-18));
/*     */     s_pairKern.put("U.", new Integer(-25));
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\afm\times_italic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */