/*    */ package inetsoft.report.afm;
/*    */ 
/*    */ import inetsoft.report.internal.AFontMetrics;
/*    */ import java.awt.Rectangle;
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class courier_boldoblique
/*    */   extends AFontMetrics
/*    */ {
/*    */   public courier_boldoblique() {
/* 39 */     this.fontName = s_fontName;
/* 40 */     this.fullName = s_fullName;
/* 41 */     this.familyName = s_familyName;
/* 42 */     this.weight = s_weight;
/* 43 */     this.fixedPitch = s_fixedPitch;
/* 44 */     this.italicAngle = s_italicAngle;
/* 45 */     this.ascender = s_ascender;
/* 46 */     this.descender = s_descender;
/* 47 */     this.widths = s_widths;
/* 48 */     this.pairKern = s_pairKern;
/* 49 */     this.advance = s_advance;
/* 50 */     this.bbox = s_bbox;
/*    */   }
/*    */   
/*    */   static String s_fontName = "Courier-BoldOblique";
/*    */   static String s_fullName = "Courier";
/*    */   static String s_familyName = "Courier";
/*    */   static String s_weight = "Bold";
/*    */   static boolean s_fixedPitch = true;
/*    */   static double s_italicAngle = -12.0D;
/*    */   static int s_ascender = 626;
/*    */   static int s_descender = 142;
/*    */   static int s_advance = 600;
/*    */   static Rectangle s_bbox = new Rectangle(-46, 801, 914, 1007);
/*    */   static int[] s_widths = { 
/*    */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*    */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*    */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*    */       0, 0, 600, 600, 600, 600, 600, 600, 600, 600, 
/*    */       600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
/*    */       600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
/*    */       600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
/*    */       600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
/*    */       600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
/*    */       600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
/*    */       600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
/*    */       600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
/*    */       600, 600, 600, 600, 600, 600, 600, 0, 0, 0, 
/*    */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*    */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*    */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*    */       0, 600, 600, 600, 600, 600, 600, 600, 600, 600, 
/*    */       600, 600, 600, 600, 600, 600, 0, 600, 600, 600, 
/*    */       600, 0, 600, 600, 600, 600, 600, 600, 600, 600, 
/*    */       0, 600, 0, 600, 600, 600, 600, 600, 600, 600, 
/*    */       600, 0, 600, 600, 0, 600, 600, 600, 600, 0, 
/*    */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*    */       0, 0, 0, 0, 0, 600, 0, 600, 0, 0, 
/*    */       0, 0, 600, 600, 600, 600, 0, 0, 0, 0, 
/*    */       0, 600, 0, 0, 0, 600, 0, 0, 600, 600, 
/*    */       600, 600, 0, 0, 0, 0 };
/*    */   static Hashtable s_pairKern = new Hashtable();
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\afm\courier_boldoblique.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */