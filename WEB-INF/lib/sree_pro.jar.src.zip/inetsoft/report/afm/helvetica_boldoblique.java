/*     */ package inetsoft.report.afm;
/*     */ 
/*     */ import inetsoft.report.internal.AFontMetrics;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class helvetica_boldoblique
/*     */   extends AFontMetrics
/*     */ {
/*     */   public helvetica_boldoblique() {
/* 248 */     this.fontName = s_fontName;
/* 249 */     this.fullName = s_fullName;
/* 250 */     this.familyName = s_familyName;
/* 251 */     this.weight = s_weight;
/* 252 */     this.fixedPitch = s_fixedPitch;
/* 253 */     this.italicAngle = s_italicAngle;
/* 254 */     this.ascender = s_ascender;
/* 255 */     this.descender = s_descender;
/* 256 */     this.widths = s_widths;
/* 257 */     this.pairKern = s_pairKern;
/* 258 */     this.advance = s_advance;
/* 259 */     this.bbox = s_bbox;
/*     */   }
/*     */   
/*     */   static String s_fontName = "Helvetica-BoldOblique";
/*     */   static String s_fullName = "Helvetica";
/*     */   static String s_familyName = "Helvetica";
/*     */   static String s_weight = "Bold";
/*     */   static boolean s_fixedPitch = false;
/*     */   static double s_italicAngle = -12.0D;
/*     */   static int s_ascender = 718;
/*     */   static int s_descender = 207;
/*     */   static int s_advance = 1000;
/*     */   static Rectangle s_bbox = new Rectangle(-174, 962, 1288, 1190);
/*     */   static int[] s_widths = { 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 0, 278, 333, 474, 556, 556, 889, 722, 278, 
/*     */       333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 
/*     */       556, 556, 556, 556, 556, 556, 556, 556, 333, 333, 
/*     */       584, 584, 584, 611, 975, 722, 722, 722, 722, 667, 
/*     */       611, 778, 722, 278, 556, 722, 611, 833, 722, 778, 
/*     */       667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 
/*     */       611, 333, 278, 333, 584, 556, 278, 556, 611, 556, 
/*     */       611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 
/*     */       611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 
/*     */       556, 556, 500, 389, 280, 389, 584, 0, 0, 0, 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 333, 556, 556, 167, 556, 556, 556, 556, 238, 
/*     */       500, 556, 333, 333, 611, 611, 0, 556, 556, 556, 
/*     */       278, 0, 556, 350, 278, 500, 500, 556, 1000, 1000, 
/*     */       0, 611, 0, 333, 333, 333, 333, 333, 333, 333, 
/*     */       333, 0, 333, 333, 0, 333, 333, 333, 1000, 0, 
/*     */       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
/*     */       0, 0, 0, 0, 0, 1000, 0, 370, 0, 0, 
/*     */       0, 0, 611, 778, 1000, 365, 0, 0, 0, 0, 
/*     */       0, 889, 0, 0, 0, 278, 0, 0, 278, 611, 
/*     */       944, 611, 0, 0, 0, 0 };
/*     */   static Hashtable s_pairKern = new Hashtable();
/*     */   
/*     */   static  {
/*     */     s_pairKern.put("U,", new Integer(-30));
/*     */     s_pairKern.put("xe", new Integer(-10));
/*     */     s_pairKern.put("TA", new Integer(-90));
/*     */     s_pairKern.put("T;", new Integer(-40));
/*     */     s_pairKern.put("ko", new Integer(-15));
/*     */     s_pairKern.put("T:", new Integer(-40));
/*     */     s_pairKern.put("wo", new Integer(-20));
/*     */     s_pairKern.put("Fa", new Integer(-20));
/*     */     s_pairKern.put("T.", new Integer(-80));
/*     */     s_pairKern.put("T-", new Integer(-120));
/*     */     s_pairKern.put("y.", new Integer(-80));
/*     */     s_pairKern.put("T,", new Integer(-80));
/*     */     s_pairKern.put("y,", new Integer(-80));
/*     */     s_pairKern.put("RY", new Integer(-50));
/*     */     s_pairKern.put("RW", new Integer(-40));
/*     */     s_pairKern.put("RV", new Integer(-50));
/*     */     s_pairKern.put("; ", new Integer(-40));
/*     */     s_pairKern.put("RU", new Integer(-20));
/*     */     s_pairKern.put("RT", new Integer(-20));
/*     */     s_pairKern.put("RO", new Integer(-20));
/*     */     s_pairKern.put("vo", new Integer(-30));
/*     */     s_pairKern.put(" `", new Integer(-60));
/*     */     s_pairKern.put("FA", new Integer(-80));
/*     */     s_pairKern.put(".'", new Integer(-120));
/*     */     s_pairKern.put(" Y", new Integer(-120));
/*     */     s_pairKern.put(" W", new Integer(-80));
/*     */     s_pairKern.put(" V", new Integer(-80));
/*     */     s_pairKern.put(" T", new Integer(-100));
/*     */     s_pairKern.put(". ", new Integer(-40));
/*     */     s_pairKern.put("va", new Integer(-20));
/*     */     s_pairKern.put("F.", new Integer(-100));
/*     */     s_pairKern.put("F,", new Integer(-100));
/*     */     s_pairKern.put(": ", new Integer(-40));
/*     */     s_pairKern.put("QU", new Integer(-10));
/*     */     s_pairKern.put("Po", new Integer(-40));
/*     */     s_pairKern.put("w.", new Integer(-40));
/*     */     s_pairKern.put("w,", new Integer(-40));
/*     */     s_pairKern.put("fº", new Integer(30));
/*     */     s_pairKern.put("Pe", new Integer(-30));
/*     */     s_pairKern.put("DY", new Integer(-70));
/*     */     s_pairKern.put("hy", new Integer(-20));
/*     */     s_pairKern.put("DW", new Integer(-40));
/*     */     s_pairKern.put("DV", new Integer(-40));
/*     */     s_pairKern.put("Pa", new Integer(-30));
/*     */     s_pairKern.put("Q.", new Integer(20));
/*     */     s_pairKern.put("DA", new Integer(-40));
/*     */     s_pairKern.put("v.", new Integer(-80));
/*     */     s_pairKern.put("Q,", new Integer(20));
/*     */     s_pairKern.put("v,", new Integer(-80));
/*     */     s_pairKern.put(",'", new Integer(-120));
/*     */     s_pairKern.put(", ", new Integer(-40));
/*     */     s_pairKern.put("PA", new Integer(-100));
/*     */     s_pairKern.put("Lº", new Integer(-140));
/*     */     s_pairKern.put("OY", new Integer(-70));
/*     */     s_pairKern.put("D.", new Integer(-30));
/*     */     s_pairKern.put("OX", new Integer(-50));
/*     */     s_pairKern.put("OW", new Integer(-50));
/*     */     s_pairKern.put("sw", new Integer(-15));
/*     */     s_pairKern.put("D,", new Integer(-30));
/*     */     s_pairKern.put("OV", new Integer(-50));
/*     */     s_pairKern.put("OT", new Integer(-40));
/*     */     s_pairKern.put("gg", new Integer(-10));
/*     */     s_pairKern.put("ge", new Integer(10));
/*     */     s_pairKern.put("P.", new Integer(-120));
/*     */     s_pairKern.put("P,", new Integer(-120));
/*     */     s_pairKern.put("Ay", new Integer(-30));
/*     */     s_pairKern.put("Aw", new Integer(-30));
/*     */     s_pairKern.put("Av", new Integer(-40));
/*     */     s_pairKern.put("Au", new Integer(-30));
/*     */     s_pairKern.put("BU", new Integer(-10));
/*     */     s_pairKern.put("OA", new Integer(-50));
/*     */     s_pairKern.put("fo", new Integer(-20));
/*     */     s_pairKern.put("ry", new Integer(10));
/*     */     s_pairKern.put("rv", new Integer(10));
/*     */     s_pairKern.put("rt", new Integer(20));
/*     */     s_pairKern.put("rs", new Integer(-15));
/*     */     s_pairKern.put("rq", new Integer(-20));
/*     */     s_pairKern.put("fe", new Integer(-10));
/*     */     s_pairKern.put("ro", new Integer(-20));
/*     */     s_pairKern.put("O.", new Integer(-40));
/*     */     s_pairKern.put("BA", new Integer(-30));
/*     */     s_pairKern.put("O,", new Integer(-40));
/*     */     s_pairKern.put("Yu", new Integer(-100));
/*     */     s_pairKern.put("rg", new Integer(-15));
/*     */     s_pairKern.put("AY", new Integer(-110));
/*     */     s_pairKern.put("Yo", new Integer(-100));
/*     */     s_pairKern.put("ey", new Integer(-15));
/*     */     s_pairKern.put("rd", new Integer(-20));
/*     */     s_pairKern.put("AW", new Integer(-60));
/*     */     s_pairKern.put("ex", new Integer(-15));
/*     */     s_pairKern.put("rc", new Integer(-20));
/*     */     s_pairKern.put("AV", new Integer(-80));
/*     */     s_pairKern.put("ew", new Integer(-15));
/*     */     s_pairKern.put("ev", new Integer(-15));
/*     */     s_pairKern.put("AU", new Integer(-50));
/*     */     s_pairKern.put("AT", new Integer(-90));
/*     */     s_pairKern.put("AQ", new Integer(-40));
/*     */     s_pairKern.put("AO", new Integer(-40));
/*     */     s_pairKern.put("Ly", new Integer(-30));
/*     */     s_pairKern.put("Ye", new Integer(-80));
/*     */     s_pairKern.put("'v", new Integer(-20));
/*     */     s_pairKern.put("'s", new Integer(-60));
/*     */     s_pairKern.put("Ya", new Integer(-90));
/*     */     s_pairKern.put("'r", new Integer(-40));
/*     */     s_pairKern.put("AG", new Integer(-50));
/*     */     s_pairKern.put("'l", new Integer(-20));
/*     */     s_pairKern.put("AC", new Integer(-40));
/*     */     s_pairKern.put("'d", new Integer(-80));
/*     */     s_pairKern.put("YO", new Integer(-70));
/*     */     s_pairKern.put("dy", new Integer(-15));
/*     */     s_pairKern.put("dw", new Integer(-15));
/*     */     s_pairKern.put("dv", new Integer(-15));
/*     */     s_pairKern.put("Ky", new Integer(-40));
/*     */     s_pairKern.put("LY", new Integer(-120));
/*     */     s_pairKern.put("py", new Integer(-15));
/*     */     s_pairKern.put("LW", new Integer(-80));
/*     */     s_pairKern.put("f.", new Integer(-10));
/*     */     s_pairKern.put("LV", new Integer(-110));
/*     */     s_pairKern.put("Ku", new Integer(-30));
/*     */     s_pairKern.put("YA", new Integer(-110));
/*     */     s_pairKern.put("f,", new Integer(-10));
/*     */     s_pairKern.put("LT", new Integer(-90));
/*     */     s_pairKern.put("Ko", new Integer(-35));
/*     */     s_pairKern.put("Wy", new Integer(-20));
/*     */     s_pairKern.put("Y;", new Integer(-50));
/*     */     s_pairKern.put("f'", new Integer(30));
/*     */     s_pairKern.put("Y:", new Integer(-50));
/*     */     s_pairKern.put("dd", new Integer(-10));
/*     */     s_pairKern.put("r.", new Integer(-60));
/*     */     s_pairKern.put("Wu", new Integer(-45));
/*     */     s_pairKern.put("r-", new Integer(-20));
/*     */     s_pairKern.put("r,", new Integer(-60));
/*     */     s_pairKern.put("Ke", new Integer(-15));
/*     */     s_pairKern.put("Wo", new Integer(-60));
/*     */     s_pairKern.put("cy", new Integer(-10));
/*     */     s_pairKern.put("Y.", new Integer(-100));
/*     */     s_pairKern.put("Y,", new Integer(-100));
/*     */     s_pairKern.put("We", new Integer(-35));
/*     */     s_pairKern.put("oy", new Integer(-20));
/*     */     s_pairKern.put("ox", new Integer(-30));
/*     */     s_pairKern.put("ow", new Integer(-15));
/*     */     s_pairKern.put("Ju", new Integer(-20));
/*     */     s_pairKern.put("Wa", new Integer(-40));
/*     */     s_pairKern.put("cl", new Integer(-20));
/*     */     s_pairKern.put("e.", new Integer(20));
/*     */     s_pairKern.put("ov", new Integer(-20));
/*     */     s_pairKern.put("ck", new Integer(-20));
/*     */     s_pairKern.put("e,", new Integer(10));
/*     */     s_pairKern.put("ch", new Integer(-10));
/*     */     s_pairKern.put("KO", new Integer(-30));
/*     */     s_pairKern.put("Vu", new Integer(-60));
/*     */     s_pairKern.put("''", new Integer(-46));
/*     */     s_pairKern.put("L'", new Integer(-140));
/*     */     s_pairKern.put("Vo", new Integer(-90));
/*     */     s_pairKern.put("WO", new Integer(-20));
/*     */     s_pairKern.put("by", new Integer(-20));
/*     */     s_pairKern.put("' ", new Integer(-80));
/*     */     s_pairKern.put("bv", new Integer(-20));
/*     */     s_pairKern.put("bu", new Integer(-20));
/*     */     s_pairKern.put("Ve", new Integer(-50));
/*     */     s_pairKern.put("ny", new Integer(-20));
/*     */     s_pairKern.put("Va", new Integer(-60));
/*     */     s_pairKern.put("bl", new Integer(-10));
/*     */     s_pairKern.put("nv", new Integer(-40));
/*     */     s_pairKern.put("WA", new Integer(-60));
/*     */     s_pairKern.put(".º", new Integer(-120));
/*     */     s_pairKern.put("nu", new Integer(-10));
/*     */     s_pairKern.put("W;", new Integer(-10));
/*     */     s_pairKern.put("W:", new Integer(-10));
/*     */     s_pairKern.put("VO", new Integer(-50));
/*     */     s_pairKern.put("ay", new Integer(-20));
/*     */     s_pairKern.put("W.", new Integer(-80));
/*     */     s_pairKern.put("aw", new Integer(-15));
/*     */     s_pairKern.put("JA", new Integer(-20));
/*     */     s_pairKern.put("W-", new Integer(-40));
/*     */     s_pairKern.put("av", new Integer(-15));
/*     */     s_pairKern.put("W,", new Integer(-80));
/*     */     s_pairKern.put("VG", new Integer(-50));
/*     */     s_pairKern.put("ze", new Integer(10));
/*     */     s_pairKern.put("º ", new Integer(-80));
/*     */     s_pairKern.put("my", new Integer(-30));
/*     */     s_pairKern.put("VA", new Integer(-80));
/*     */     s_pairKern.put("mu", new Integer(-20));
/*     */     s_pairKern.put("ag", new Integer(-10));
/*     */     s_pairKern.put("Ty", new Integer(-60));
/*     */     s_pairKern.put("V;", new Integer(-40));
/*     */     s_pairKern.put("V:", new Integer(-40));
/*     */     s_pairKern.put("J.", new Integer(-20));
/*     */     s_pairKern.put("Tw", new Integer(-60));
/*     */     s_pairKern.put("J,", new Integer(-20));
/*     */     s_pairKern.put("Tu", new Integer(-90));
/*     */     s_pairKern.put("Tr", new Integer(-80));
/*     */     s_pairKern.put("To", new Integer(-80));
/*     */     s_pairKern.put("yo", new Integer(-25));
/*     */     s_pairKern.put("V.", new Integer(-120));
/*     */     s_pairKern.put("V-", new Integer(-80));
/*     */     s_pairKern.put("V,", new Integer(-120));
/*     */     s_pairKern.put("Te", new Integer(-60));
/*     */     s_pairKern.put("ye", new Integer(-10));
/*     */     s_pairKern.put("ly", new Integer(-15));
/*     */     s_pairKern.put("lw", new Integer(-15));
/*     */     s_pairKern.put("Ta", new Integer(-80));
/*     */     s_pairKern.put("UA", new Integer(-50));
/*     */     s_pairKern.put("ya", new Integer(-30));
/*     */     s_pairKern.put(",º", new Integer(-120));
/*     */     s_pairKern.put(" ª", new Integer(-80));
/*     */     s_pairKern.put("``", new Integer(-46));
/*     */     s_pairKern.put("TO", new Integer(-40));
/*     */     s_pairKern.put("U.", new Integer(-30));
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\afm\helvetica_boldoblique.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */