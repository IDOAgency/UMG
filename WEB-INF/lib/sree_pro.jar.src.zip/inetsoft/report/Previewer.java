/*     */ package inetsoft.report;
/*     */ 
/*     */ import inetsoft.report.event.SelectionListener;
/*     */ import inetsoft.report.internal.PagesMenu;
/*     */ import inetsoft.report.internal.ToolBar;
/*     */ import inetsoft.report.internal.ToolButton;
/*     */ import inetsoft.report.internal.ToolTip;
/*     */ import inetsoft.report.internal.Util;
/*     */ import inetsoft.report.io.Builder;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Choice;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.PrintJob;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.FileInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Previewer
/*     */   extends Frame
/*     */   implements PreviewView, ActionListener
/*     */ {
/*     */   ItemListener zoomListener;
/*     */   protected PreviewPane pane;
/*     */   protected StyleSheet sheet;
/*     */   ToolBar toolbar;
/*     */   ToolButton printerB;
/*     */   ToolButton onepageB;
/*     */   ToolButton npageB;
/*     */   ToolButton fullscrB;
/*     */   ToolButton closeB;
/*     */   PagesMenu menu;
/*     */   Dimension psize;
/*     */   Choice zoomChoice;
/*     */   PrintJob printjob;
/*     */   boolean exitit;
/*     */   int fsCount;
/*     */   Dimension frameSize;
/*     */   
/*  66 */   public static PreviewView createPreviewer() { return Common.getPreviewView(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public Previewer() { this(Catalog.getString("Print Preview")); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Previewer(String paramString, boolean paramBoolean) {
/*  84 */     this(paramString);
/*     */     
/*  86 */     if (paramBoolean) {
/*  87 */       this.zoomChoice.select(Catalog.getString("Whole Page"));
/*  88 */       this.zoomListener.itemStateChanged(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Previewer(String paramString, PrintJob paramPrintJob, boolean paramBoolean) {
/* 106 */     this(paramString, paramBoolean);
/* 107 */     this.printjob = paramPrintJob;
/*     */     
/* 109 */     Dimension dimension = paramPrintJob.getPageDimension();
/*     */     
/* 111 */     setPageWidth(dimension.width / 72.0D);
/* 112 */     setPageHeight(dimension.height / 72.0D);
/* 113 */     setPageResolution(72);
/*     */   } public Previewer(String paramString, int paramInt1, int paramInt2) { this(paramString); this.psize = new Dimension(paramInt1, paramInt2); } protected PreviewPane createPane() { return new PreviewPane(); } public void printAction() { if (this.sheet == null) return;  PrintJob printJob = this.printjob; if (printJob == null) printJob = getToolkit().getPrintJob(this, Catalog.getString("Previewer"), null);  if (printJob == null) return;  this.pane.showStatus(Catalog.getString("Printing") + "..."); this.sheet.print(printJob); printJob.end(); Dimension dimension = printJob.getPageDimension(); if (dimension.width != getPageWidth() || dimension.height != getPageHeight()) { this.sheet.reset(); print(this.sheet); }  this.pane.showStatus(""); } public void setToolbarButtons(int paramInt) { this.toolbar.remove(this.printerB); this.toolbar.remove(this.onepageB); this.toolbar.remove(this.npageB); this.toolbar.remove(this.fullscrB); this.toolbar.remove(this.zoomChoice); this.toolbar.remove(this.closeB); byte b = 0; if ((paramInt & true) != 0) this.toolbar.add(this.printerB, b++);  if ((paramInt & 0x2) != 0)
/*     */       this.toolbar.add(this.onepageB, b++);  if ((paramInt & 0x4) != 0)
/*     */       this.toolbar.add(this.npageB, b++);  if ((paramInt & 0x8) != 0)
/*     */       this.toolbar.add(this.fullscrB, b++);  if ((paramInt & 0x10) != 0)
/*     */       this.toolbar.add(this.zoomChoice, b++);  if ((paramInt & 0x20) != 0)
/*     */       this.toolbar.add(this.closeB, b++);  } public void addToolbarComponent(Component paramComponent) { this.toolbar.add(paramComponent); } public void actionPerformed(ActionEvent paramActionEvent) { (new Thread(this) { private final Previewer this$0; public void run() { this.this$0.printAction(); } }
/*     */       ).start(); }
/* 121 */   public Previewer(String paramString) { super(paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 485 */     this.zoomListener = new ItemListener(this) { private final Previewer this$0;
/*     */         public void itemStateChanged(ItemEvent param1ItemEvent) {
/* 487 */           int i = this.this$0.zoomChoice.getSelectedIndex();
/* 488 */           if (i >= 0) {
/* 489 */             this.this$0.pane.zoom(Previewer.zoomperc[i]);
/*     */           }
/*     */         } }
/*     */       ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 539 */     this.menu = null;
/*     */ 
/*     */ 
/*     */     
/* 543 */     this.exitit = false;
/* 544 */     this.fsCount = 0; setLayout(new BorderLayout()); this.toolbar = new ToolBar(); this.toolbar.add(this.printerB = new ToolButton("/inetsoft/report/images/printer.gif", Catalog.getString("Print"))); ToolTip.getToolTip().put(this.printerB, Catalog.getString("Print")); this.printerB.addActionListener(this); this.toolbar.add(new ToolBar.Separator()); this.toolbar.add(this.onepageB = new ToolButton("/inetsoft/report/images/onepage.gif", Catalog.getString("One Page"))); ToolTip.getToolTip().put(this.onepageB, Catalog.getString("One Page")); this.onepageB.addActionListener(new ActionListener(this) { private final Previewer this$0; public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.zoomChoice.select(Catalog.getString("Whole Page")); this.this$0.zoomListener.itemStateChanged(null); } }
/*     */       ); this.toolbar.add(this.npageB = new ToolButton("/inetsoft/report/images/npage.gif", Catalog.getString("Multi-Pages"))); ToolTip.getToolTip().put(this.npageB, Catalog.getString("Multiple Pages")); this.npageB.setToggle(true); this.npageB.addActionListener(new ActionListener(this) { private final Previewer this$0; public void actionPerformed(ActionEvent param1ActionEvent) { if (this.this$0.npageB.getState()) { this.this$0.menu = new PagesMenu(this.this$0); Point point = this.this$0.npageB.getLocationOnScreen(); point.y += (this.this$0.npageB.getSize()).height; this.this$0.menu.pack(); this.this$0.menu.setLocation(point); this.this$0.menu.setVisible(true); this.this$0.menu.setLocation(point); this.this$0.menu.addWindowListener(new Previewer$3(this)); this.this$0.menu.addActionListener(new Previewer$4(this)); } else if (this.this$0.menu != null) { this.this$0.menu.dispose(); this.this$0.menu = null; }  } }
/*     */       ); this.toolbar.add(new ToolBar.Separator()); this.toolbar.add(this.zoomChoice = new Choice()); for (byte b = 0; b < zoomname.length; b++) this.zoomChoice.add(zoomname[b]);  this.zoomChoice.select(Catalog.getString("100%")); ToolTip.getToolTip().put(this.zoomChoice, Catalog.getString("Zoom")); this.zoomChoice.addItemListener(this.zoomListener); this.toolbar.add(new ToolBar.Separator()); this.toolbar.add(this.fullscrB = new ToolButton("/inetsoft/report/images/fullscr.gif", Catalog.getString("Full Screen"))); ToolTip.getToolTip().put(this.fullscrB, Catalog.getString("Full Screen")); this.fullscrB.addActionListener(new ActionListener(this) { private final Previewer this$0; public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.fsCount++; if (this.this$0.fsCount % 2 == 1) { this.this$0.frameSize = this.this$0.getSize(); this.this$0.psize = Toolkit.getDefaultToolkit().getScreenSize(); this.this$0.pack(); this.this$0.setLocation(0, 0); } else { this.this$0.psize = this.this$0.frameSize; this.this$0.pack(); }  } }
/*     */       ); this.toolbar.add(new ToolBar.Separator()); this.toolbar.add(this.closeB = new ToolButton((Image)null, Catalog.getString("Close"))); ToolTip.getToolTip().put(this.closeB, Catalog.getString("Close Preview")); this.closeB.addActionListener(new ActionListener(this) { private final Previewer this$0; public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); } }
/* 548 */       ); add(this.toolbar, "North"); this.pane = createPane(); add(this.pane, "Center"); addWindowListener(new WindowAdapter(this) { private final Previewer this$0; public void windowClosing(WindowEvent param1WindowEvent) { this.this$0.dispose(); } }); Util.registerKeyListener(this, this.pane.scrollListener); addNotify(); } public Dimension getPreferredSize() { if (this.psize != null) return this.psize;  Dimension dimension = new Dimension(getToolkit().getScreenSize()); dimension.width = Math.min(dimension.width, 800); dimension.height = Math.min(dimension.height, 800); return dimension; } public void setPreferredSize(Dimension paramDimension) { this.psize = new Dimension(paramDimension); } public void setPageWidth(double paramDouble) { this.pane.setPageWidth(paramDouble); } static final String[] zoomname = { Catalog.getString("500%"), Catalog.getString("200%"), Catalog.getString("150%"), Catalog.getString("100%"), Catalog.getString("75%"), Catalog.getString("50%"), Catalog.getString("25%"), Catalog.getString("10%"), Catalog.getString("Page Width"), Catalog.getString("Whole Page"), Catalog.getString("Two Pages") };
/*     */   public double getPageWidth() { return this.pane.getPageWidth(); }
/*     */   public void setPageHeight(double paramDouble) { this.pane.setPageHeight(paramDouble); } public double getPageHeight() { return this.pane.getPageHeight(); } public void setOrientation(int paramInt) { this.pane.setOrientation(paramInt); } public int getOrientation() { return this.pane.getOrientation(); } public void setPageResolution(int paramInt) { this.pane.setPageResolution(paramInt); } public int getPageResolution() { return this.pane.getPageResolution(); } public void print(StyleSheet paramStyleSheet) { this.pane.print(this.sheet = paramStyleSheet); } public void zoom(double paramDouble) { this.pane.zoom(paramDouble); for (byte b = 0; b < zoomperc.length; b++) { if (Math.abs(zoomperc[b] - paramDouble) < 0.05D) {
/*     */         this.zoomChoice.select(b); break;
/*     */       }  }
/*     */      } public void setExitOnClose(boolean paramBoolean) { this.exitit = paramBoolean; } public void addSelectionListener(SelectionListener paramSelectionListener) { this.pane.addSelectionListener(paramSelectionListener); } public void removeSelectionListener(SelectionListener paramSelectionListener) { this.pane.removeSelectionListener(paramSelectionListener); } public void setPages(int paramInt1, int paramInt2) { this.pane.setPages(paramInt1, paramInt2); } public void update(Graphics paramGraphics) { paint(paramGraphics); } public void dispose() { super.dispose(); if (this.exitit)
/*     */       System.exit(0);  } static final double[] zoomperc = { 
/* 555 */       5.0D, 2.0D, 1.5D, 1.0D, 0.75D, 0.5D, 0.25D, 0.1D, -1.0D, -2.0D, -3.0D };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 568 */     if (paramArrayOfString.length < 1) {
/* 569 */       System.err.println("Usage: java inetsoft.report.Previewer report");
/* 570 */       System.exit(1);
/*     */     } 
/*     */     
/*     */     try {
/* 574 */       FileInputStream fileInputStream = new FileInputStream(paramArrayOfString[0]);
/* 575 */       Builder builder = Builder.getBuilder(2, fileInputStream);
/* 576 */       StyleSheet styleSheet = builder.read(".");
/* 577 */       fileInputStream.close();
/*     */       
/* 579 */       Previewer previewer = new Previewer();
/* 580 */       previewer.setExitOnClose(true);
/*     */       
/* 582 */       previewer.pack();
/* 583 */       previewer.setVisible(true);
/*     */       
/* 585 */       previewer.print(styleSheet);
/*     */     } catch (Exception exception) {
/* 587 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Previewer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */