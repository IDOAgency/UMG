package inetsoft.report;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.io.Serializable;

public class Context implements ReportElement, Serializable {
  private StyleSheet report;
  
  private ReportElement elem;
  
  private int c_align;
  
  private double c_indent;
  
  private int c_spacing;
  
  private Font c_font;
  
  private Color c_fg;
  
  private Color c_bg;
  
  private int c_autosize;
  
  private int c_policy;
  
  private Insets c_padding;
  
  private double c_tblwidth;
  
  private double[] c_tabstops;
  
  private int c_textadv;
  
  private boolean c_orphan;
  
  private boolean c_keep;
  
  private String c_script;
  
  private String c_onClick;
  
  public Context(StyleSheet paramStyleSheet) {
    this.report = paramStyleSheet;
    this.c_align = paramStyleSheet.getCurrentAlignment();
    this.c_indent = paramStyleSheet.getCurrentIndent();
    this.c_spacing = paramStyleSheet.getCurrentLineSpacing();
    this.c_font = paramStyleSheet.getCurrentFont();
    this.c_fg = paramStyleSheet.getCurrentForeground();
    this.c_bg = paramStyleSheet.getCurrentBackground();
    this.c_autosize = paramStyleSheet.getCurrentTableLayout();
    this.c_policy = paramStyleSheet.getCurrentPainterLayout();
    this.c_padding = paramStyleSheet.getCurrentCellPadding();
    this.c_tblwidth = paramStyleSheet.getCurrentTableWidth();
    this.c_tabstops = paramStyleSheet.getCurrentTabStops();
    this.c_textadv = paramStyleSheet.getCurrentTextAdvance();
    this.c_orphan = paramStyleSheet.isCurrentOrphanControl();
  }
  
  public Context(ReportElement paramReportElement) { setContext(paramReportElement); }
  
  public void setContext(ReportElement paramReportElement) {
    this.elem = paramReportElement;
    this.c_align = paramReportElement.getAlignment();
    this.c_indent = paramReportElement.getIndent();
    this.c_spacing = paramReportElement.getSpacing();
    this.c_font = paramReportElement.getFont();
    this.c_fg = paramReportElement.getForeground();
    this.c_bg = paramReportElement.getBackground();
  }
  
  public void restore() {
    this.report.setCurrentAlignment(this.c_align);
    this.report.setCurrentIndent(this.c_indent);
    this.report.setCurrentLineSpacing(this.c_spacing);
    this.report.setCurrentFont(this.c_font);
    this.report.setCurrentForeground(this.c_fg);
    this.report.setCurrentBackground(this.c_bg);
    this.report.setCurrentTableLayout(this.c_autosize);
    this.report.setCurrentPainterLayout(this.c_policy);
    this.report.setCurrentCellPadding(this.c_padding);
    this.report.setCurrentTableWidth(this.c_tblwidth);
    this.report.setCurrentTabStops(this.c_tabstops);
    this.report.setCurrentTextAdvance(this.c_textadv);
    this.report.setCurrentOrphanControl(this.c_orphan);
  }
  
  public String getID() { return ""; }
  
  public void setID(String paramString) {}
  
  public boolean isVisible() { return true; }
  
  public void setVisible(boolean paramBoolean) {}
  
  public String getType() { return "StyleSheet"; }
  
  public int getAlignment() { return this.c_align; }
  
  public void setAlignment(int paramInt) { this.c_align = paramInt; }
  
  public double getIndent() { return this.c_indent; }
  
  public void setIndent(double paramDouble) { this.c_indent = paramDouble; }
  
  public int getSpacing() { return this.c_spacing; }
  
  public void setSpacing(int paramInt) { this.c_spacing = paramInt; }
  
  public Font getFont() { return this.c_font; }
  
  public void setFont(Font paramFont) { this.c_font = paramFont; }
  
  public Color getForeground() { return this.c_fg; }
  
  public void setForeground(Color paramColor) { this.c_fg = paramColor; }
  
  public Color getBackground() { return this.c_bg; }
  
  public void setBackground(Color paramColor) { this.c_bg = paramColor; }
  
  public int getTableLayout() { return this.c_autosize; }
  
  public void setTableLayout(int paramInt) { this.c_autosize = paramInt; }
  
  public int getPainterLayout() { return this.c_policy; }
  
  public void setPainterLayout(int paramInt) { this.c_policy = paramInt; }
  
  public Insets getCellPadding() { return this.c_padding; }
  
  public void setCellPadding(Insets paramInsets) { this.c_padding = paramInsets; }
  
  public double getTableWidth() { return this.c_tblwidth; }
  
  public void setTableWidth(double paramDouble) { this.c_tblwidth = paramDouble; }
  
  public double[] getTabStops() { return this.c_tabstops; }
  
  public void setTabStops(double[] paramArrayOfDouble) { this.c_tabstops = paramArrayOfDouble; }
  
  public int getTextAdvance() { return this.c_textadv; }
  
  public void setTextAdvance(int paramInt) { this.c_textadv = paramInt; }
  
  public boolean isOrphanControl() { return this.c_orphan; }
  
  public void setOrphanControl(boolean paramBoolean) { this.c_orphan = paramBoolean; }
  
  public boolean isKeepWithNext() { return this.c_keep; }
  
  public void setKeepWithNext(boolean paramBoolean) { this.c_keep = paramBoolean; }
  
  public String getScript() { return this.c_script; }
  
  public void setScript(String paramString) { this.c_script = paramString; }
  
  public String getOnClick() { return this.c_onClick; }
  
  public void setOnClick(String paramString) { this.c_onClick = paramString; }
  
  public String getProperty(String paramString) { return null; }
  
  public void setProperty(String paramString1, String paramString2) {}
  
  public Object clone() throws CloneNotSupportedException { return super.clone(); }
  
  public Size getPreferredSize() { return null; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Context.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */