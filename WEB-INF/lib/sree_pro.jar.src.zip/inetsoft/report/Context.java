/*     */ package inetsoft.report;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class Context
/*     */   implements ReportElement, Serializable
/*     */ {
/*     */   private StyleSheet report;
/*     */   private ReportElement elem;
/*     */   private int c_align;
/*     */   private double c_indent;
/*     */   private int c_spacing;
/*     */   private Font c_font;
/*     */   private Color c_fg;
/*     */   private Color c_bg;
/*     */   private int c_autosize;
/*     */   private int c_policy;
/*     */   private Insets c_padding;
/*     */   private double c_tblwidth;
/*     */   private double[] c_tabstops;
/*     */   private int c_textadv;
/*     */   private boolean c_orphan;
/*     */   private boolean c_keep;
/*     */   private String c_script;
/*     */   private String c_onClick;
/*     */   
/*     */   public Context(StyleSheet paramStyleSheet) {
/*  31 */     this.report = paramStyleSheet;
/*     */     
/*  33 */     this.c_align = paramStyleSheet.getCurrentAlignment();
/*  34 */     this.c_indent = paramStyleSheet.getCurrentIndent();
/*  35 */     this.c_spacing = paramStyleSheet.getCurrentLineSpacing();
/*  36 */     this.c_font = paramStyleSheet.getCurrentFont();
/*  37 */     this.c_fg = paramStyleSheet.getCurrentForeground();
/*  38 */     this.c_bg = paramStyleSheet.getCurrentBackground();
/*  39 */     this.c_autosize = paramStyleSheet.getCurrentTableLayout();
/*  40 */     this.c_policy = paramStyleSheet.getCurrentPainterLayout();
/*  41 */     this.c_padding = paramStyleSheet.getCurrentCellPadding();
/*  42 */     this.c_tblwidth = paramStyleSheet.getCurrentTableWidth();
/*  43 */     this.c_tabstops = paramStyleSheet.getCurrentTabStops();
/*  44 */     this.c_textadv = paramStyleSheet.getCurrentTextAdvance();
/*  45 */     this.c_orphan = paramStyleSheet.isCurrentOrphanControl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public Context(ReportElement paramReportElement) { setContext(paramReportElement); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContext(ReportElement paramReportElement) {
/*  59 */     this.elem = paramReportElement;
/*     */     
/*  61 */     this.c_align = paramReportElement.getAlignment();
/*  62 */     this.c_indent = paramReportElement.getIndent();
/*  63 */     this.c_spacing = paramReportElement.getSpacing();
/*  64 */     this.c_font = paramReportElement.getFont();
/*  65 */     this.c_fg = paramReportElement.getForeground();
/*  66 */     this.c_bg = paramReportElement.getBackground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void restore() {
/*  73 */     this.report.setCurrentAlignment(this.c_align);
/*  74 */     this.report.setCurrentIndent(this.c_indent);
/*  75 */     this.report.setCurrentLineSpacing(this.c_spacing);
/*  76 */     this.report.setCurrentFont(this.c_font);
/*  77 */     this.report.setCurrentForeground(this.c_fg);
/*  78 */     this.report.setCurrentBackground(this.c_bg);
/*  79 */     this.report.setCurrentTableLayout(this.c_autosize);
/*  80 */     this.report.setCurrentPainterLayout(this.c_policy);
/*  81 */     this.report.setCurrentCellPadding(this.c_padding);
/*  82 */     this.report.setCurrentTableWidth(this.c_tblwidth);
/*  83 */     this.report.setCurrentTabStops(this.c_tabstops);
/*  84 */     this.report.setCurrentTextAdvance(this.c_textadv);
/*  85 */     this.report.setCurrentOrphanControl(this.c_orphan);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public String getID() { return ""; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setID(String paramString) {}
/*     */ 
/*     */   
/*  99 */   public boolean isVisible() { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVisible(boolean paramBoolean) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public String getType() { return "StyleSheet"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public int getAlignment() { return this.c_align; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public void setAlignment(int paramInt) { this.c_align = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public double getIndent() { return this.c_indent; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public void setIndent(double paramDouble) { this.c_indent = paramDouble; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public int getSpacing() { return this.c_spacing; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   public void setSpacing(int paramInt) { this.c_spacing = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   public Font getFont() { return this.c_font; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   public void setFont(Font paramFont) { this.c_font = paramFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   public Color getForeground() { return this.c_fg; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   public void setForeground(Color paramColor) { this.c_fg = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 186 */   public Color getBackground() { return this.c_bg; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 193 */   public void setBackground(Color paramColor) { this.c_bg = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 200 */   public int getTableLayout() { return this.c_autosize; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 207 */   public void setTableLayout(int paramInt) { this.c_autosize = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 214 */   public int getPainterLayout() { return this.c_policy; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 221 */   public void setPainterLayout(int paramInt) { this.c_policy = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 228 */   public Insets getCellPadding() { return this.c_padding; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 235 */   public void setCellPadding(Insets paramInsets) { this.c_padding = paramInsets; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 242 */   public double getTableWidth() { return this.c_tblwidth; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 249 */   public void setTableWidth(double paramDouble) { this.c_tblwidth = paramDouble; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 256 */   public double[] getTabStops() { return this.c_tabstops; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 263 */   public void setTabStops(double[] paramArrayOfDouble) { this.c_tabstops = paramArrayOfDouble; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 270 */   public int getTextAdvance() { return this.c_textadv; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 277 */   public void setTextAdvance(int paramInt) { this.c_textadv = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 284 */   public boolean isOrphanControl() { return this.c_orphan; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 291 */   public void setOrphanControl(boolean paramBoolean) { this.c_orphan = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 299 */   public boolean isKeepWithNext() { return this.c_keep; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 306 */   public void setKeepWithNext(boolean paramBoolean) { this.c_keep = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 313 */   public String getScript() { return this.c_script; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 320 */   public void setScript(String paramString) { this.c_script = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 327 */   public String getOnClick() { return this.c_onClick; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 334 */   public void setOnClick(String paramString) { this.c_onClick = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 345 */   public String getProperty(String paramString) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String paramString1, String paramString2) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 358 */   public Object clone() throws CloneNotSupportedException { return super.clone(); }
/*     */ 
/*     */ 
/*     */   
/* 362 */   public Size getPreferredSize() { return null; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Context.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */