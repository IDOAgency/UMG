package inetsoft.report;

public interface ButtonElement extends FieldElement {
  String getText();
  
  void setText(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\ButtonElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */