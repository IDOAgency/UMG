/*    */ package inetsoft.report;
/*    */ 
/*    */ import inetsoft.report.internal.BaseElement;
/*    */ import inetsoft.report.internal.BasePaintable;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Point;
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EmptyPaintable
/*    */   extends BasePaintable
/*    */ {
/*    */   float x;
/*    */   float y;
/*    */   ReportElement elem;
/*    */   Rectangle bounds;
/*    */   
/*    */   public EmptyPaintable(float paramFloat1, float paramFloat2, ReportElement paramReportElement) {
/* 30 */     super(paramReportElement);
/* 31 */     this.x = paramFloat1;
/* 32 */     this.y = paramFloat2;
/* 33 */     this.elem = paramReportElement;
/*    */     
/* 35 */     Size size = ((BaseElement)paramReportElement).getPreferredSize();
/* 36 */     this.bounds = new Rectangle((int)paramFloat1, (int)paramFloat2, (int)size.width, (int)size.height);
/*    */   }
/*    */ 
/*    */   
/*    */   public void paint(Graphics paramGraphics) {}
/*    */ 
/*    */   
/* 43 */   public Rectangle getBounds() { return this.bounds; }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setLocation(Point paramPoint) {}
/*    */ 
/*    */   
/* 50 */   public ReportElement getElement() { return this.elem; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\EmptyPaintable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */