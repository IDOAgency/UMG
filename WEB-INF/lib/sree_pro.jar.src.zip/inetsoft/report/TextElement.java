package inetsoft.report;

public interface TextElement extends TabElement {
  String getText();
  
  void setText(String paramString);
  
  void setText(TextLens paramTextLens);
  
  boolean isJustify();
  
  void setJustify(boolean paramBoolean);
  
  int getTextAdvance();
  
  void setTextAdvance(int paramInt);
  
  boolean isOrphanControl();
  
  void setOrphanControl(boolean paramBoolean);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\TextElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */