package inetsoft.report.internal;

import inetsoft.report.Common;
import java.awt.Image;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class JpegEncoder {
  Thread runner;
  
  BufferedOutputStream outStream;
  
  Image image;
  
  JpegInfo JpegObj;
  
  Huffman Huf;
  
  DCT dct;
  
  int imageHeight;
  
  int imageWidth;
  
  int Quality;
  
  int code;
  
  public static int[] jpegNaturalOrder = { 
      0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 
      32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 
      40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 
      21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 
      29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 
      52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 
      47, 55, 62, 63 };
  
  public JpegEncoder(Image paramImage, int paramInt, OutputStream paramOutputStream) {
    this.Quality = paramInt;
    this.JpegObj = new JpegInfo(paramImage);
    this.imageHeight = this.JpegObj.imageHeight;
    this.imageWidth = this.JpegObj.imageWidth;
    this.outStream = new BufferedOutputStream(paramOutputStream);
    this.dct = new DCT(this.Quality);
    this.Huf = new Huffman(this.imageWidth, this.imageHeight);
  }
  
  public void setQuality(int paramInt) { this.dct = new DCT(paramInt); }
  
  public int getQuality() { return this.Quality; }
  
  public void Compress() {
    WriteHeaders(this.outStream);
    WriteCompressedData(this.outStream);
    WriteEOI(this.outStream);
    try {
      this.outStream.flush();
    } catch (IOException iOException) {
      System.out.println("IO Error: " + iOException.getMessage());
    } 
  }
  
  public void WriteCompressedData(BufferedOutputStream paramBufferedOutputStream) {
    boolean bool1 = false;
    float[][] arrayOfFloat = new float[8][8];
    double[][] arrayOfDouble = new double[8][8];
    int[] arrayOfInt1 = new int[64];
    int[] arrayOfInt2 = new int[this.JpegObj.NumberOfComponents];
    int[] arrayOfInt3 = new int[64];
    int i = 0, j = 0;
    boolean bool2 = false;
    int k = (this.imageWidth % 8 != 0) ? ((int)(Math.floor(this.imageWidth / 8.0D) + 1.0D) * 8) : this.imageWidth;
    int m = (this.imageHeight % 8 != 0) ? ((int)(Math.floor(this.imageHeight / 8.0D) + 1.0D) * 8) : this.imageHeight;
    byte b2;
    for (b2 = 0; b2 < this.JpegObj.NumberOfComponents; b2++) {
      k = Math.min(k, this.JpegObj.BlockWidth[b2]);
      m = Math.min(m, this.JpegObj.BlockHeight[b2]);
    } 
    byte b3 = 0;
    for (byte b1 = 0; b1 < m; b1++) {
      for (byte b = 0; b < k; b++) {
        b3 = b * 8;
        byte b4 = b1 * 8;
        for (b2 = 0; b2 < this.JpegObj.NumberOfComponents; b2++) {
          i = this.JpegObj.BlockWidth[b2];
          j = this.JpegObj.BlockHeight[b2];
          float[][] arrayOfFloat1 = (float[][])this.JpegObj.Components[b2];
          for (byte b5 = 0; b5 < this.JpegObj.VsampFactor[b2]; b5++) {
            for (byte b6 = 0; b6 < this.JpegObj.HsampFactor[b2]; b6++) {
              byte b8 = b6 * 8;
              byte b9 = b5 * 8;
              for (byte b7 = 0; b7 < 8; b7++) {
                for (byte b10 = 0; b10 < 8; b10++)
                  arrayOfFloat[b7][b10] = arrayOfFloat1[b4 + b9 + b7][b3 + b8 + b10]; 
              } 
              arrayOfDouble = this.dct.forwardDCT(arrayOfFloat);
              arrayOfInt1 = this.dct.quantizeBlock(arrayOfDouble, this.JpegObj.QtableNumber[b2]);
              this.Huf.HuffmanBlockEncoder(paramBufferedOutputStream, arrayOfInt1, arrayOfInt2[b2], this.JpegObj.DCtableNumber[b2], this.JpegObj.ACtableNumber[b2]);
              arrayOfInt2[b2] = arrayOfInt1[0];
            } 
          } 
        } 
      } 
    } 
    this.Huf.flushBuffer(paramBufferedOutputStream);
  }
  
  public void WriteEOI(BufferedOutputStream paramBufferedOutputStream) {
    byte[] arrayOfByte = { -1, -39 };
    WriteMarker(arrayOfByte, paramBufferedOutputStream);
  }
  
  public void WriteHeaders(BufferedOutputStream paramBufferedOutputStream) {
    byte[] arrayOfByte1 = { -1, -40 };
    WriteMarker(arrayOfByte1, paramBufferedOutputStream);
    byte[] arrayOfByte2 = new byte[18];
    arrayOfByte2[0] = -1;
    arrayOfByte2[1] = -32;
    arrayOfByte2[2] = 0;
    arrayOfByte2[3] = 16;
    arrayOfByte2[4] = 74;
    arrayOfByte2[5] = 70;
    arrayOfByte2[6] = 73;
    arrayOfByte2[7] = 70;
    arrayOfByte2[8] = 0;
    arrayOfByte2[9] = 1;
    arrayOfByte2[10] = 0;
    arrayOfByte2[11] = 0;
    arrayOfByte2[12] = 0;
    arrayOfByte2[13] = 1;
    arrayOfByte2[14] = 0;
    arrayOfByte2[15] = 1;
    arrayOfByte2[16] = 0;
    arrayOfByte2[17] = 0;
    WriteArray(arrayOfByte2, paramBufferedOutputStream);
    String str = new String();
    str = this.JpegObj.getComment();
    int i = str.length();
    byte[] arrayOfByte3 = new byte[i + 4];
    arrayOfByte3[0] = -1;
    arrayOfByte3[1] = -2;
    arrayOfByte3[2] = (byte)(i >> 8 & 0xFF);
    arrayOfByte3[3] = (byte)(i & 0xFF);
    System.arraycopy(this.JpegObj.Comment.getBytes(), 0, arrayOfByte3, 4, this.JpegObj.Comment.length());
    WriteArray(arrayOfByte3, paramBufferedOutputStream);
    byte[] arrayOfByte4 = new byte[134];
    arrayOfByte4[0] = -1;
    arrayOfByte4[1] = -37;
    arrayOfByte4[2] = 0;
    arrayOfByte4[3] = -124;
    byte b3 = 4;
    byte b1;
    for (b1 = 0; b1 < 2; b1++) {
      arrayOfByte4[b3++] = (byte)(false + b1);
      int[] arrayOfInt = (int[])this.dct.quantum[b1];
      for (byte b = 0; b < 64; b++)
        arrayOfByte4[b3++] = (byte)arrayOfInt[jpegNaturalOrder[b]]; 
    } 
    WriteArray(arrayOfByte4, paramBufferedOutputStream);
    byte[] arrayOfByte5 = new byte[19];
    arrayOfByte5[0] = -1;
    arrayOfByte5[1] = -64;
    arrayOfByte5[2] = 0;
    arrayOfByte5[3] = 17;
    arrayOfByte5[4] = (byte)this.JpegObj.Precision;
    arrayOfByte5[5] = (byte)(this.JpegObj.imageHeight >> 8 & 0xFF);
    arrayOfByte5[6] = (byte)(this.JpegObj.imageHeight & 0xFF);
    arrayOfByte5[7] = (byte)(this.JpegObj.imageWidth >> 8 & 0xFF);
    arrayOfByte5[8] = (byte)(this.JpegObj.imageWidth & 0xFF);
    arrayOfByte5[9] = (byte)this.JpegObj.NumberOfComponents;
    byte b2 = 10;
    for (b1 = 0; b1 < arrayOfByte5[9]; b1++) {
      arrayOfByte5[b2++] = (byte)this.JpegObj.CompID[b1];
      arrayOfByte5[b2++] = (byte)((this.JpegObj.HsampFactor[b1] << 4) + this.JpegObj.VsampFactor[b1]);
      arrayOfByte5[b2++] = (byte)this.JpegObj.QtableNumber[b1];
    } 
    WriteArray(arrayOfByte5, paramBufferedOutputStream);
    i = 2;
    b2 = 4;
    byte b4 = 4;
    byte[] arrayOfByte6 = new byte[17];
    byte[] arrayOfByte7 = new byte[4];
    arrayOfByte7[0] = -1;
    arrayOfByte7[1] = -60;
    for (b1 = 0; b1 < 4; b1++) {
      int j = 0;
      arrayOfByte6[b2++ - b4] = (byte)(int[])this.Huf.bits.elementAt(b1)[0];
      byte b5;
      for (b5 = 1; b5 < 17; b5++) {
        int k = (int[])this.Huf.bits.elementAt(b1)[b5];
        arrayOfByte6[b2++ - b4] = (byte)k;
        j += k;
      } 
      byte b6 = b2;
      byte[] arrayOfByte9 = new byte[j];
      for (b5 = 0; b5 < j; b5++)
        arrayOfByte9[b2++ - b6] = (byte)(int[])this.Huf.val.elementAt(b1)[b5]; 
      byte[] arrayOfByte10 = new byte[b2];
      System.arraycopy(arrayOfByte7, 0, arrayOfByte10, 0, b4);
      System.arraycopy(arrayOfByte6, 0, arrayOfByte10, b4, 17);
      System.arraycopy(arrayOfByte9, 0, arrayOfByte10, b4 + 17, j);
      arrayOfByte7 = arrayOfByte10;
      b4 = b2;
    } 
    arrayOfByte7[2] = (byte)(b2 - 2 >> 8 & 0xFF);
    arrayOfByte7[3] = (byte)(b2 - 2 & 0xFF);
    WriteArray(arrayOfByte7, paramBufferedOutputStream);
    byte[] arrayOfByte8 = new byte[14];
    arrayOfByte8[0] = -1;
    arrayOfByte8[1] = -38;
    arrayOfByte8[2] = 0;
    arrayOfByte8[3] = 12;
    arrayOfByte8[4] = (byte)this.JpegObj.NumberOfComponents;
    b2 = 5;
    for (b1 = 0; b1 < arrayOfByte8[4]; b1++) {
      arrayOfByte8[b2++] = (byte)this.JpegObj.CompID[b1];
      arrayOfByte8[b2++] = (byte)((this.JpegObj.DCtableNumber[b1] << 4) + this.JpegObj.ACtableNumber[b1]);
    } 
    arrayOfByte8[b2++] = (byte)this.JpegObj.Ss;
    arrayOfByte8[b2++] = (byte)this.JpegObj.Se;
    arrayOfByte8[b2++] = (byte)((this.JpegObj.Ah << 4) + this.JpegObj.Al);
    WriteArray(arrayOfByte8, paramBufferedOutputStream);
  }
  
  void WriteMarker(byte[] paramArrayOfByte, BufferedOutputStream paramBufferedOutputStream) {
    try {
      paramBufferedOutputStream.write(paramArrayOfByte, 0, 2);
    } catch (IOException iOException) {
      System.out.println("IO Error: " + iOException.getMessage());
    } 
  }
  
  void WriteArray(byte[] paramArrayOfByte, BufferedOutputStream paramBufferedOutputStream) {
    try {
      byte b = ((paramArrayOfByte[2] & 0xFF) << 8) + (paramArrayOfByte[3] & 0xFF) + 2;
      paramBufferedOutputStream.write(paramArrayOfByte, 0, b);
    } catch (IOException iOException) {
      System.out.println("IO Error: " + iOException.getMessage());
    } 
  }
  
  public static void main(String[] paramArrayOfString) {
    try {
      Image image1 = Common.createImage(300, 300);
      FileOutputStream fileOutputStream = new FileOutputStream(new File("jpg.jpg"));
      long l1 = System.currentTimeMillis();
      Common.writeJPEG(image1, fileOutputStream);
      long l2 = System.currentTimeMillis();
      System.err.println("compress: " + (l2 - l1));
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    System.exit(0);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\JpegEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */