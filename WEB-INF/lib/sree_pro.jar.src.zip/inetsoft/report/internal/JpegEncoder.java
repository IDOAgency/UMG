/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import java.awt.Image;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JpegEncoder
/*     */ {
/*     */   Thread runner;
/*     */   BufferedOutputStream outStream;
/*     */   Image image;
/*     */   JpegInfo JpegObj;
/*     */   Huffman Huf;
/*     */   DCT dct;
/*     */   int imageHeight;
/*     */   int imageWidth;
/*     */   int Quality;
/*     */   int code;
/*     */   public static int[] jpegNaturalOrder = { 
/*  41 */       0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JpegEncoder(Image paramImage, int paramInt, OutputStream paramOutputStream) {
/*  69 */     this.Quality = paramInt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     this.JpegObj = new JpegInfo(paramImage);
/*     */     
/*  77 */     this.imageHeight = this.JpegObj.imageHeight;
/*  78 */     this.imageWidth = this.JpegObj.imageWidth;
/*  79 */     this.outStream = new BufferedOutputStream(paramOutputStream);
/*  80 */     this.dct = new DCT(this.Quality);
/*  81 */     this.Huf = new Huffman(this.imageWidth, this.imageHeight);
/*     */   }
/*     */ 
/*     */   
/*  85 */   public void setQuality(int paramInt) { this.dct = new DCT(paramInt); }
/*     */ 
/*     */ 
/*     */   
/*  89 */   public int getQuality() { return this.Quality; }
/*     */ 
/*     */   
/*     */   public void Compress() {
/*  93 */     WriteHeaders(this.outStream);
/*  94 */     WriteCompressedData(this.outStream);
/*  95 */     WriteEOI(this.outStream);
/*     */     try {
/*  97 */       this.outStream.flush();
/*     */     } catch (IOException iOException) {
/*  99 */       System.out.println("IO Error: " + iOException.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void WriteCompressedData(BufferedOutputStream paramBufferedOutputStream) {
/* 104 */     boolean bool1 = false;
/*     */ 
/*     */     
/* 107 */     float[][] arrayOfFloat = new float[8][8];
/* 108 */     double[][] arrayOfDouble = new double[8][8];
/* 109 */     int[] arrayOfInt1 = new int[64];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     int[] arrayOfInt2 = new int[this.JpegObj.NumberOfComponents];
/* 118 */     int[] arrayOfInt3 = new int[64];
/* 119 */     int i = 0, j = 0;
/* 120 */     boolean bool2 = false;
/*     */ 
/*     */ 
/*     */     
/* 124 */     int k = (this.imageWidth % 8 != 0) ? ((int)(Math.floor(this.imageWidth / 8.0D) + 1.0D) * 8) : this.imageWidth;
/* 125 */     int m = (this.imageHeight % 8 != 0) ? ((int)(Math.floor(this.imageHeight / 8.0D) + 1.0D) * 8) : this.imageHeight; byte b2;
/* 126 */     for (b2 = 0; b2 < this.JpegObj.NumberOfComponents; b2++) {
/* 127 */       k = Math.min(k, this.JpegObj.BlockWidth[b2]);
/* 128 */       m = Math.min(m, this.JpegObj.BlockHeight[b2]);
/*     */     } 
/* 130 */     byte b3 = 0;
/* 131 */     for (byte b1 = 0; b1 < m; b1++) {
/* 132 */       for (byte b = 0; b < k; b++) {
/* 133 */         b3 = b * 8;
/* 134 */         byte b4 = b1 * 8;
/* 135 */         for (b2 = 0; b2 < this.JpegObj.NumberOfComponents; b2++) {
/* 136 */           i = this.JpegObj.BlockWidth[b2];
/* 137 */           j = this.JpegObj.BlockHeight[b2];
/* 138 */           float[][] arrayOfFloat1 = (float[][])this.JpegObj.Components[b2];
/*     */           
/* 140 */           for (byte b5 = 0; b5 < this.JpegObj.VsampFactor[b2]; b5++) {
/* 141 */             for (byte b6 = 0; b6 < this.JpegObj.HsampFactor[b2]; b6++) {
/* 142 */               byte b8 = b6 * 8;
/* 143 */               byte b9 = b5 * 8;
/* 144 */               for (byte b7 = 0; b7 < 8; b7++) {
/* 145 */                 for (byte b10 = 0; b10 < 8; b10++)
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 152 */                   arrayOfFloat[b7][b10] = arrayOfFloat1[b4 + b9 + b7][b3 + b8 + b10];
/*     */                 }
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/* 158 */               arrayOfDouble = this.dct.forwardDCT(arrayOfFloat);
/* 159 */               arrayOfInt1 = this.dct.quantizeBlock(arrayOfDouble, this.JpegObj.QtableNumber[b2]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 166 */               this.Huf.HuffmanBlockEncoder(paramBufferedOutputStream, arrayOfInt1, arrayOfInt2[b2], this.JpegObj.DCtableNumber[b2], this.JpegObj.ACtableNumber[b2]);
/* 167 */               arrayOfInt2[b2] = arrayOfInt1[0];
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 173 */     this.Huf.flushBuffer(paramBufferedOutputStream);
/*     */   }
/*     */   
/*     */   public void WriteEOI(BufferedOutputStream paramBufferedOutputStream) {
/* 177 */     byte[] arrayOfByte = { -1, -39 };
/* 178 */     WriteMarker(arrayOfByte, paramBufferedOutputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void WriteHeaders(BufferedOutputStream paramBufferedOutputStream) {
/* 186 */     byte[] arrayOfByte1 = { -1, -40 };
/* 187 */     WriteMarker(arrayOfByte1, paramBufferedOutputStream);
/*     */ 
/*     */ 
/*     */     
/* 191 */     byte[] arrayOfByte2 = new byte[18];
/* 192 */     arrayOfByte2[0] = -1;
/* 193 */     arrayOfByte2[1] = -32;
/* 194 */     arrayOfByte2[2] = 0;
/* 195 */     arrayOfByte2[3] = 16;
/* 196 */     arrayOfByte2[4] = 74;
/* 197 */     arrayOfByte2[5] = 70;
/* 198 */     arrayOfByte2[6] = 73;
/* 199 */     arrayOfByte2[7] = 70;
/* 200 */     arrayOfByte2[8] = 0;
/* 201 */     arrayOfByte2[9] = 1;
/* 202 */     arrayOfByte2[10] = 0;
/* 203 */     arrayOfByte2[11] = 0;
/* 204 */     arrayOfByte2[12] = 0;
/* 205 */     arrayOfByte2[13] = 1;
/* 206 */     arrayOfByte2[14] = 0;
/* 207 */     arrayOfByte2[15] = 1;
/* 208 */     arrayOfByte2[16] = 0;
/* 209 */     arrayOfByte2[17] = 0;
/* 210 */     WriteArray(arrayOfByte2, paramBufferedOutputStream);
/*     */ 
/*     */     
/* 213 */     String str = new String();
/* 214 */     str = this.JpegObj.getComment();
/* 215 */     int i = str.length();
/* 216 */     byte[] arrayOfByte3 = new byte[i + 4];
/* 217 */     arrayOfByte3[0] = -1;
/* 218 */     arrayOfByte3[1] = -2;
/* 219 */     arrayOfByte3[2] = (byte)(i >> 8 & 0xFF);
/* 220 */     arrayOfByte3[3] = (byte)(i & 0xFF);
/* 221 */     System.arraycopy(this.JpegObj.Comment.getBytes(), 0, arrayOfByte3, 4, this.JpegObj.Comment.length());
/* 222 */     WriteArray(arrayOfByte3, paramBufferedOutputStream);
/*     */ 
/*     */ 
/*     */     
/* 226 */     byte[] arrayOfByte4 = new byte[134];
/* 227 */     arrayOfByte4[0] = -1;
/* 228 */     arrayOfByte4[1] = -37;
/* 229 */     arrayOfByte4[2] = 0;
/* 230 */     arrayOfByte4[3] = -124;
/* 231 */     byte b3 = 4; byte b1;
/* 232 */     for (b1 = 0; b1 < 2; b1++) {
/* 233 */       arrayOfByte4[b3++] = (byte)(false + b1);
/* 234 */       int[] arrayOfInt = (int[])this.dct.quantum[b1];
/* 235 */       for (byte b = 0; b < 64; b++) {
/* 236 */         arrayOfByte4[b3++] = (byte)arrayOfInt[jpegNaturalOrder[b]];
/*     */       }
/*     */     } 
/* 239 */     WriteArray(arrayOfByte4, paramBufferedOutputStream);
/*     */ 
/*     */     
/* 242 */     byte[] arrayOfByte5 = new byte[19];
/* 243 */     arrayOfByte5[0] = -1;
/* 244 */     arrayOfByte5[1] = -64;
/* 245 */     arrayOfByte5[2] = 0;
/* 246 */     arrayOfByte5[3] = 17;
/* 247 */     arrayOfByte5[4] = (byte)this.JpegObj.Precision;
/* 248 */     arrayOfByte5[5] = (byte)(this.JpegObj.imageHeight >> 8 & 0xFF);
/* 249 */     arrayOfByte5[6] = (byte)(this.JpegObj.imageHeight & 0xFF);
/* 250 */     arrayOfByte5[7] = (byte)(this.JpegObj.imageWidth >> 8 & 0xFF);
/* 251 */     arrayOfByte5[8] = (byte)(this.JpegObj.imageWidth & 0xFF);
/* 252 */     arrayOfByte5[9] = (byte)this.JpegObj.NumberOfComponents;
/* 253 */     byte b2 = 10;
/* 254 */     for (b1 = 0; b1 < arrayOfByte5[9]; b1++) {
/* 255 */       arrayOfByte5[b2++] = (byte)this.JpegObj.CompID[b1];
/* 256 */       arrayOfByte5[b2++] = (byte)((this.JpegObj.HsampFactor[b1] << 4) + this.JpegObj.VsampFactor[b1]);
/* 257 */       arrayOfByte5[b2++] = (byte)this.JpegObj.QtableNumber[b1];
/*     */     } 
/* 259 */     WriteArray(arrayOfByte5, paramBufferedOutputStream);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 264 */     i = 2;
/* 265 */     b2 = 4;
/* 266 */     byte b4 = 4;
/* 267 */     byte[] arrayOfByte6 = new byte[17];
/* 268 */     byte[] arrayOfByte7 = new byte[4];
/* 269 */     arrayOfByte7[0] = -1;
/* 270 */     arrayOfByte7[1] = -60;
/* 271 */     for (b1 = 0; b1 < 4; b1++) {
/* 272 */       int j = 0;
/* 273 */       arrayOfByte6[b2++ - b4] = (byte)(int[])this.Huf.bits.elementAt(b1)[0]; byte b5;
/* 274 */       for (b5 = 1; b5 < 17; b5++) {
/* 275 */         int k = (int[])this.Huf.bits.elementAt(b1)[b5];
/* 276 */         arrayOfByte6[b2++ - b4] = (byte)k;
/* 277 */         j += k;
/*     */       } 
/* 279 */       byte b6 = b2;
/* 280 */       byte[] arrayOfByte9 = new byte[j];
/* 281 */       for (b5 = 0; b5 < j; b5++) {
/* 282 */         arrayOfByte9[b2++ - b6] = (byte)(int[])this.Huf.val.elementAt(b1)[b5];
/*     */       }
/* 284 */       byte[] arrayOfByte10 = new byte[b2];
/* 285 */       System.arraycopy(arrayOfByte7, 0, arrayOfByte10, 0, b4);
/* 286 */       System.arraycopy(arrayOfByte6, 0, arrayOfByte10, b4, 17);
/* 287 */       System.arraycopy(arrayOfByte9, 0, arrayOfByte10, b4 + 17, j);
/* 288 */       arrayOfByte7 = arrayOfByte10;
/* 289 */       b4 = b2;
/*     */     } 
/* 291 */     arrayOfByte7[2] = (byte)(b2 - 2 >> 8 & 0xFF);
/* 292 */     arrayOfByte7[3] = (byte)(b2 - 2 & 0xFF);
/* 293 */     WriteArray(arrayOfByte7, paramBufferedOutputStream);
/*     */ 
/*     */ 
/*     */     
/* 297 */     byte[] arrayOfByte8 = new byte[14];
/* 298 */     arrayOfByte8[0] = -1;
/* 299 */     arrayOfByte8[1] = -38;
/* 300 */     arrayOfByte8[2] = 0;
/* 301 */     arrayOfByte8[3] = 12;
/* 302 */     arrayOfByte8[4] = (byte)this.JpegObj.NumberOfComponents;
/* 303 */     b2 = 5;
/* 304 */     for (b1 = 0; b1 < arrayOfByte8[4]; b1++) {
/* 305 */       arrayOfByte8[b2++] = (byte)this.JpegObj.CompID[b1];
/* 306 */       arrayOfByte8[b2++] = (byte)((this.JpegObj.DCtableNumber[b1] << 4) + this.JpegObj.ACtableNumber[b1]);
/*     */     } 
/* 308 */     arrayOfByte8[b2++] = (byte)this.JpegObj.Ss;
/* 309 */     arrayOfByte8[b2++] = (byte)this.JpegObj.Se;
/* 310 */     arrayOfByte8[b2++] = (byte)((this.JpegObj.Ah << 4) + this.JpegObj.Al);
/* 311 */     WriteArray(arrayOfByte8, paramBufferedOutputStream);
/*     */   }
/*     */ 
/*     */   
/*     */   void WriteMarker(byte[] paramArrayOfByte, BufferedOutputStream paramBufferedOutputStream) {
/*     */     try {
/* 317 */       paramBufferedOutputStream.write(paramArrayOfByte, 0, 2);
/*     */     } catch (IOException iOException) {
/* 319 */       System.out.println("IO Error: " + iOException.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void WriteArray(byte[] paramArrayOfByte, BufferedOutputStream paramBufferedOutputStream) {
/*     */     try {
/* 326 */       byte b = ((paramArrayOfByte[2] & 0xFF) << 8) + (paramArrayOfByte[3] & 0xFF) + 2;
/* 327 */       paramBufferedOutputStream.write(paramArrayOfByte, 0, b);
/*     */     } catch (IOException iOException) {
/* 329 */       System.out.println("IO Error: " + iOException.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/*     */     try {
/* 336 */       Image image1 = Common.createImage(300, 300);
/* 337 */       FileOutputStream fileOutputStream = new FileOutputStream(new File("jpg.jpg"));
/* 338 */       long l1 = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 344 */       Common.writeJPEG(image1, fileOutputStream);
/* 345 */       long l2 = System.currentTimeMillis();
/* 346 */       System.err.println("compress: " + (l2 - l1));
/*     */     } catch (Exception exception) {
/* 348 */       exception.printStackTrace();
/*     */     } 
/*     */     
/* 351 */     System.exit(0);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\JpegEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */