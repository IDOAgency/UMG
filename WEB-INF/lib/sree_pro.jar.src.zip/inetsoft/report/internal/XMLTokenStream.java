/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLTokenStream
/*     */   implements Serializable
/*     */ {
/*     */   public XMLTokenStream(InputStream paramInputStream) {
/*     */     try {
/*  34 */       char[] arrayOfChar = new char[256]; int i; do {  }
/*  35 */       while ((i = paramInputStream.read()) != 60 && i >= 0);
/*     */ 
/*     */       
/*  38 */       byte b1 = 0;
/*  39 */       for (byte b2 = 0; b2 < arrayOfChar.length && (i = paramInputStream.read()) != 62; b2++) {
/*  40 */         arrayOfChar[b1++] = (char)i;
/*     */       }
/*     */       
/*  43 */       String str1 = (new String(arrayOfChar, 0, b1)).toUpperCase();
/*  44 */       int j = str1.indexOf("ENCODING");
/*     */ 
/*     */       
/*  47 */       String str2 = null;
/*  48 */       if (j > 0) {
/*  49 */         j = str1.indexOf('"', j);
/*  50 */         if (j > 0) {
/*  51 */           int k = j + 1;
/*  52 */           int m = str1.indexOf('"', k);
/*     */           
/*  54 */           if (m > 0) {
/*  55 */             str2 = str1.substring(k, m);
/*  56 */             if (str2.equals("UTF-8")) {
/*  57 */               str2 = "UTF8";
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/*  63 */       if (str2 != null) {
/*  64 */         this.reader = new BufferedReader(new InputStreamReader(paramInputStream, str2));
/*     */       } else {
/*     */         
/*  67 */         this.reader = new BufferedReader(new InputStreamReader(paramInputStream));
/*     */       } 
/*     */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*  70 */       this.reader = new BufferedReader(new InputStreamReader(paramInputStream));
/*  71 */       unsupportedEncodingException.printStackTrace();
/*     */     } catch (IOException iOException) {
/*  73 */       iOException.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public Reader getReader() { return this.reader; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getToken() throws IOException, XMLException {
/*  91 */     if (this.nextTag != null) {
/*  92 */       Object object = this.nextTag;
/*  93 */       this.nextTag = null;
/*  94 */       return object;
/*     */     } 
/*     */ 
/*     */     
/*  98 */     if (this.nextchar == -999) {
/*  99 */       this.nextchar = this.reader.read();
/*     */     }
/*     */ 
/*     */     
/* 103 */     if (this.nextchar == -1) {
/* 104 */       return null;
/*     */     }
/*     */     
/* 107 */     skipWhitespace();
/*     */ 
/*     */     
/* 110 */     if (this.nextchar == 60) {
/* 111 */       boolean bool = false;
/* 112 */       this.nextchar = this.reader.read();
/* 113 */       skipWhitespace();
/*     */       
/* 115 */       StringBuffer stringBuffer = new StringBuffer();
/*     */       
/* 117 */       if (this.nextchar == 33) {
/* 118 */         for (; this.nextchar >= 0 && this.nextchar != 62; this.nextchar = this.reader.read()) {
/*     */           
/* 120 */           if ((char)this.nextchar != '\r') {
/* 121 */             stringBuffer.append((char)this.nextchar);
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 126 */         if (stringBuffer.toString().startsWith("![CDATA[")) {
/* 127 */           stringBuffer = new StringBuffer(stringBuffer.toString().substring(8));
/*     */ 
/*     */           
/* 130 */           if (!stringBuffer.toString().endsWith("]]")) {
/* 131 */             for (; this.nextchar >= 0; this.nextchar = this.reader.read()) {
/* 132 */               if (this.nextchar == 93) {
/* 133 */                 this.nextchar = this.reader.read();
/*     */                 
/* 135 */                 if (this.nextchar != 93) {
/* 136 */                   stringBuffer.append("]");
/* 137 */                   if (this.nextchar >= 0) {
/* 138 */                     stringBuffer.append((char)this.nextchar);
/*     */                   }
/*     */                   else {
/*     */                     
/*     */                     break;
/*     */                   }
/*     */                 
/*     */                 } else {
/*     */                   
/* 147 */                   this.nextchar = this.reader.read();
/*     */                   
/* 149 */                   if (this.nextchar != 62) {
/* 150 */                     stringBuffer.append("]]");
/* 151 */                     if (this.nextchar >= 0) {
/* 152 */                       stringBuffer.append((char)this.nextchar);
/*     */                     }
/*     */                     else {
/*     */                       
/*     */                       break;
/*     */                     }
/*     */                   
/*     */                   }
/*     */                   else {
/*     */                     
/* 162 */                     this.nextchar = this.reader.read();
/*     */ 
/*     */ 
/*     */                     
/*     */                     break;
/*     */                   } 
/*     */                 } 
/* 169 */               } else if ((char)this.nextchar != '\r') {
/* 170 */                 stringBuffer.append((char)this.nextchar);
/*     */               } 
/*     */             } 
/*     */           } else {
/*     */             
/* 175 */             stringBuffer.setLength(stringBuffer.length() - 2);
/* 176 */             this.nextchar = this.reader.read();
/*     */           } 
/*     */           
/* 179 */           return stringBuffer.toString();
/*     */         } 
/*     */         
/* 182 */         this.nextchar = this.reader.read();
/* 183 */         return new Tag(stringBuffer.toString());
/*     */       } 
/* 185 */       if (this.nextchar == 63) {
/* 186 */         bool = true;
/* 187 */         this.nextchar = this.reader.read();
/*     */       }
/* 189 */       else if (this.nextchar == 47) {
/* 190 */         stringBuffer.append("/");
/* 191 */         this.nextchar = this.reader.read();
/*     */       } 
/*     */       
/* 194 */       stringBuffer.append(getName());
/* 195 */       skipWhitespace();
/*     */       
/* 197 */       Tag tag = new Tag(stringBuffer.toString());
/* 198 */       while (this.nextchar != 62) {
/* 199 */         if (bool && this.nextchar == 63) {
/* 200 */           this.nextchar = this.reader.read();
/*     */           
/*     */           continue;
/*     */         } 
/* 204 */         String str = tag.getName();
/*     */         
/* 206 */         if (this.nextchar != 61) {
/* 207 */           str = getName();
/*     */         }
/* 209 */         skipWhitespace();
/*     */         
/* 211 */         char c = (char)this.nextchar;
/* 212 */         if (c == '=') {
/* 213 */           this.nextchar = this.reader.read();
/* 214 */           skipWhitespace();
/* 215 */           String str1 = getValue();
/* 216 */           if (str == null || c != '=' || str1 == null) {
/* 217 */             throw new XMLException("XML tag format error: (" + stringBuffer + ":" + str + ":" + c + ":" + str1 + ")");
/*     */           }
/*     */           
/* 220 */           tag.put(str, str1);
/*     */         }
/* 222 */         else if (str != null) {
/*     */           
/* 224 */           tag.put(str, "");
/*     */         } else {
/* 226 */           if (c == '/') {
/*     */ 
/*     */             
/* 229 */             skipWhitespace();
/* 230 */             this.nextchar = this.reader.read();
/* 231 */             if (this.nextchar == 62) {
/* 232 */               this.nextTag = new Tag("/" + tag.getName());
/*     */               
/*     */               break;
/*     */             } 
/* 236 */             throw new XMLException("XML tag format error: (" + c + "): " + tag.getName());
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 241 */           throw new XMLException("XML tag format error: (" + c + "): " + tag.getName());
/*     */         } 
/*     */ 
/*     */         
/* 245 */         skipWhitespace();
/*     */       } 
/*     */ 
/*     */       
/* 249 */       this.nextchar = this.reader.read();
/*     */       
/* 251 */       return tag;
/*     */     } 
/*     */ 
/*     */     
/* 255 */     return getString();
/*     */   }
/*     */   
/*     */   public void skipWhitespace() throws IOException {
/* 259 */     while (this.nextchar >= 0 && Character.isWhitespace((char)this.nextchar)) {
/* 260 */       this.nextchar = this.reader.read();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 265 */   private static final String[][] encoding = { { "&nbsp;", "&amp;", "&lt;", "&gt;", "&apos;", "&quot;" }, { " ", "&", "<", ">", "'", "\"" } };
/*     */   
/*     */   private BufferedReader reader;
/*     */ 
/*     */   
/*     */   public static String encodeXML(String paramString) {
/* 271 */     StringBuffer stringBuffer = new StringBuffer();
/*     */ 
/*     */     
/* 274 */     for (byte b = 0; b < paramString.length(); b++) {
/* 275 */       byte b1 = 0; while (true) { if (b1 >= encoding[1].length)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 282 */           stringBuffer.append(paramString.charAt(b)); break; }  if (paramString.charAt(b) == encoding[1][b1].charAt(0)) { stringBuffer.append(encoding[0][b1]); break; }
/*     */          b1++; }
/*     */     
/* 285 */     }  return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   protected String getString() throws IOException {
/* 289 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 291 */     if (this.nextchar == 34) {
/* 292 */       while ((this.nextchar = this.reader.read()) >= 0 && this.nextchar != 34) {
/* 293 */         stringBuffer.append((char)this.nextchar);
/*     */       }
/* 295 */       this.nextchar = this.reader.read();
/*     */     } else {
/*     */ 
/*     */       
/*     */       do {
/* 300 */         switch (this.nextchar) {
/*     */           case 60:
/*     */             break;
/*     */ 
/*     */           
/*     */           case 9:
/*     */           case 10:
/*     */           case 13:
/*     */             break;
/*     */           
/*     */           default:
/* 311 */             stringBuffer.append((char)this.nextchar); break;
/*     */         } 
/* 313 */       } while ((this.nextchar = this.reader.read()) >= 0);
/*     */ 
/*     */       
/* 316 */       String str = stringBuffer.toString();
/*     */       
/* 318 */       for (byte b = 0; b < encoding[0].length; b++) {
/* 319 */         int i = 0;
/*     */ 
/*     */         
/* 322 */         while ((i = str.indexOf(encoding[0][b], i)) >= 0) {
/* 323 */           str = str.substring(0, i) + encoding[1][b] + str.substring(i + encoding[0][b].length());
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 332 */       return str;
/*     */     } 
/*     */ 
/*     */     
/* 336 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   protected String getName() throws IOException {
/* 340 */     if (this.nextchar == 34) {
/* 341 */       return getString();
/*     */     }
/* 343 */     if (Character.isUnicodeIdentifierStart((char)this.nextchar)) {
/* 344 */       StringBuffer stringBuffer = new StringBuffer();
/*     */       do {
/* 346 */         stringBuffer.append((char)this.nextchar);
/* 347 */         this.nextchar = this.reader.read();
/*     */       }
/* 349 */       while (Character.isUnicodeIdentifierPart((char)this.nextchar) || this.nextchar == 45);
/* 350 */       return stringBuffer.toString();
/*     */     } 
/* 352 */     return null;
/*     */   }
/*     */   
/*     */   protected String getValue() throws IOException {
/* 356 */     if (this.nextchar == 34) {
/* 357 */       return getString();
/*     */     }
/*     */     
/* 360 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     do {
/* 362 */       stringBuffer.append((char)this.nextchar);
/* 363 */       this.nextchar = this.reader.read();
/*     */     }
/* 365 */     while (this.nextchar > 0 && !Character.isWhitespace((char)this.nextchar) && this.nextchar != 62);
/* 366 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/* 370 */   private int nextchar = -999;
/*     */   
/* 372 */   private Object nextTag = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Tag
/*     */     implements Serializable
/*     */   {
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Hashtable attrmap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Tag(String param1String) {
/* 446 */       this.name = "";
/* 447 */       this.attrmap = new Hashtable();
/*     */       this.name = param1String.toUpperCase();
/*     */     }
/*     */     
/*     */     public String getName() throws IOException { return this.name; }
/*     */     
/*     */     public void put(String param1String1, String param1String2) { this.attrmap.put(param1String1.toUpperCase(), param1String2); }
/*     */     
/*     */     public String get(String param1String) { return (String)this.attrmap.get(param1String.toUpperCase()); }
/*     */     
/*     */     public Enumeration getAttributes() { return this.attrmap.keys(); }
/*     */     
/*     */     public boolean is(String param1String) { return this.name.equals(param1String.toUpperCase()); }
/*     */     
/*     */     public boolean equals(Object param1Object) {
/*     */       if (param1Object instanceof String)
/*     */         return is((String)param1Object); 
/*     */       if (param1Object instanceof Tag)
/*     */         return is(((Tag)param1Object).getName()); 
/*     */       return false;
/*     */     }
/*     */     
/*     */     public String toString() throws IOException {
/*     */       StringBuffer stringBuffer = new StringBuffer("<" + this.name);
/*     */       Enumeration enumeration1 = this.attrmap.keys(), enumeration2 = this.attrmap.elements();
/*     */       while (enumeration1.hasMoreElements())
/*     */         stringBuffer.append(" " + enumeration1.nextElement() + "=" + enumeration2.nextElement()); 
/*     */       stringBuffer.append(">");
/*     */       return stringBuffer.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\XMLTokenStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */