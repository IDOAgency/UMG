package inetsoft.report.internal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Hashtable;

public class XMLTokenStream implements Serializable {
  public XMLTokenStream(InputStream paramInputStream) {
    try {
      char[] arrayOfChar = new char[256];
      int i;
      do {
      
      } while ((i = paramInputStream.read()) != 60 && i >= 0);
      byte b1 = 0;
      for (byte b2 = 0; b2 < arrayOfChar.length && (i = paramInputStream.read()) != 62; b2++)
        arrayOfChar[b1++] = (char)i; 
      String str1 = (new String(arrayOfChar, 0, b1)).toUpperCase();
      int j = str1.indexOf("ENCODING");
      String str2 = null;
      if (j > 0) {
        j = str1.indexOf('"', j);
        if (j > 0) {
          int k = j + 1;
          int m = str1.indexOf('"', k);
          if (m > 0) {
            str2 = str1.substring(k, m);
            if (str2.equals("UTF-8"))
              str2 = "UTF8"; 
          } 
        } 
      } 
      if (str2 != null) {
        this.reader = new BufferedReader(new InputStreamReader(paramInputStream, str2));
      } else {
        this.reader = new BufferedReader(new InputStreamReader(paramInputStream));
      } 
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      this.reader = new BufferedReader(new InputStreamReader(paramInputStream));
      unsupportedEncodingException.printStackTrace();
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
  }
  
  public Reader getReader() { return this.reader; }
  
  public Object getToken() throws IOException, XMLException {
    if (this.nextTag != null) {
      Object object = this.nextTag;
      this.nextTag = null;
      return object;
    } 
    if (this.nextchar == -999)
      this.nextchar = this.reader.read(); 
    if (this.nextchar == -1)
      return null; 
    skipWhitespace();
    if (this.nextchar == 60) {
      boolean bool = false;
      this.nextchar = this.reader.read();
      skipWhitespace();
      StringBuffer stringBuffer = new StringBuffer();
      if (this.nextchar == 33) {
        for (; this.nextchar >= 0 && this.nextchar != 62; this.nextchar = this.reader.read()) {
          if ((char)this.nextchar != '\r')
            stringBuffer.append((char)this.nextchar); 
        } 
        if (stringBuffer.toString().startsWith("![CDATA[")) {
          stringBuffer = new StringBuffer(stringBuffer.toString().substring(8));
          if (!stringBuffer.toString().endsWith("]]")) {
            for (; this.nextchar >= 0; this.nextchar = this.reader.read()) {
              if (this.nextchar == 93) {
                this.nextchar = this.reader.read();
                if (this.nextchar != 93) {
                  stringBuffer.append("]");
                  if (this.nextchar >= 0) {
                    stringBuffer.append((char)this.nextchar);
                  } else {
                    break;
                  } 
                } else {
                  this.nextchar = this.reader.read();
                  if (this.nextchar != 62) {
                    stringBuffer.append("]]");
                    if (this.nextchar >= 0) {
                      stringBuffer.append((char)this.nextchar);
                    } else {
                      break;
                    } 
                  } else {
                    this.nextchar = this.reader.read();
                    break;
                  } 
                } 
              } else if ((char)this.nextchar != '\r') {
                stringBuffer.append((char)this.nextchar);
              } 
            } 
          } else {
            stringBuffer.setLength(stringBuffer.length() - 2);
            this.nextchar = this.reader.read();
          } 
          return stringBuffer.toString();
        } 
        this.nextchar = this.reader.read();
        return new Tag(stringBuffer.toString());
      } 
      if (this.nextchar == 63) {
        bool = true;
        this.nextchar = this.reader.read();
      } else if (this.nextchar == 47) {
        stringBuffer.append("/");
        this.nextchar = this.reader.read();
      } 
      stringBuffer.append(getName());
      skipWhitespace();
      Tag tag = new Tag(stringBuffer.toString());
      while (this.nextchar != 62) {
        if (bool && this.nextchar == 63) {
          this.nextchar = this.reader.read();
          continue;
        } 
        String str = tag.getName();
        if (this.nextchar != 61)
          str = getName(); 
        skipWhitespace();
        char c = (char)this.nextchar;
        if (c == '=') {
          this.nextchar = this.reader.read();
          skipWhitespace();
          String str1 = getValue();
          if (str == null || c != '=' || str1 == null)
            throw new XMLException("XML tag format error: (" + stringBuffer + ":" + str + ":" + c + ":" + str1 + ")"); 
          tag.put(str, str1);
        } else if (str != null) {
          tag.put(str, "");
        } else {
          if (c == '/') {
            skipWhitespace();
            this.nextchar = this.reader.read();
            if (this.nextchar == 62) {
              this.nextTag = new Tag("/" + tag.getName());
              break;
            } 
            throw new XMLException("XML tag format error: (" + c + "): " + tag.getName());
          } 
          throw new XMLException("XML tag format error: (" + c + "): " + tag.getName());
        } 
        skipWhitespace();
      } 
      this.nextchar = this.reader.read();
      return tag;
    } 
    return getString();
  }
  
  public void skipWhitespace() throws IOException {
    while (this.nextchar >= 0 && Character.isWhitespace((char)this.nextchar))
      this.nextchar = this.reader.read(); 
  }
  
  private static final String[][] encoding = { { "&nbsp;", "&amp;", "&lt;", "&gt;", "&apos;", "&quot;" }, { " ", "&", "<", ">", "'", "\"" } };
  
  private BufferedReader reader;
  
  public static String encodeXML(String paramString) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramString.length(); b++) {
      byte b1 = 0;
      while (true) {
        if (b1 >= encoding[1].length) {
          stringBuffer.append(paramString.charAt(b));
          break;
        } 
        if (paramString.charAt(b) == encoding[1][b1].charAt(0)) {
          stringBuffer.append(encoding[0][b1]);
          break;
        } 
        b1++;
      } 
    } 
    return stringBuffer.toString();
  }
  
  protected String getString() throws IOException {
    StringBuffer stringBuffer = new StringBuffer();
    if (this.nextchar == 34) {
      while ((this.nextchar = this.reader.read()) >= 0 && this.nextchar != 34)
        stringBuffer.append((char)this.nextchar); 
      this.nextchar = this.reader.read();
    } else {
      do {
        switch (this.nextchar) {
          case 60:
            break;
          case 9:
          case 10:
          case 13:
            break;
          default:
            stringBuffer.append((char)this.nextchar);
            break;
        } 
      } while ((this.nextchar = this.reader.read()) >= 0);
      String str = stringBuffer.toString();
      for (byte b = 0; b < encoding[0].length; b++) {
        int i = 0;
        while ((i = str.indexOf(encoding[0][b], i)) >= 0)
          str = str.substring(0, i) + encoding[1][b] + str.substring(i + encoding[0][b].length()); 
      } 
      return str;
    } 
    return stringBuffer.toString();
  }
  
  protected String getName() throws IOException {
    if (this.nextchar == 34)
      return getString(); 
    if (Character.isUnicodeIdentifierStart((char)this.nextchar)) {
      StringBuffer stringBuffer = new StringBuffer();
      do {
        stringBuffer.append((char)this.nextchar);
        this.nextchar = this.reader.read();
      } while (Character.isUnicodeIdentifierPart((char)this.nextchar) || this.nextchar == 45);
      return stringBuffer.toString();
    } 
    return null;
  }
  
  protected String getValue() throws IOException {
    if (this.nextchar == 34)
      return getString(); 
    StringBuffer stringBuffer = new StringBuffer();
    do {
      stringBuffer.append((char)this.nextchar);
      this.nextchar = this.reader.read();
    } while (this.nextchar > 0 && !Character.isWhitespace((char)this.nextchar) && this.nextchar != 62);
    return stringBuffer.toString();
  }
  
  private int nextchar = -999;
  
  private Object nextTag = null;
  
  public static class Tag implements Serializable {
    private String name;
    
    private Hashtable attrmap;
    
    public Tag(String param1String) {
      this.name = "";
      this.attrmap = new Hashtable();
      this.name = param1String.toUpperCase();
    }
    
    public String getName() throws IOException { return this.name; }
    
    public void put(String param1String1, String param1String2) { this.attrmap.put(param1String1.toUpperCase(), param1String2); }
    
    public String get(String param1String) { return (String)this.attrmap.get(param1String.toUpperCase()); }
    
    public Enumeration getAttributes() { return this.attrmap.keys(); }
    
    public boolean is(String param1String) { return this.name.equals(param1String.toUpperCase()); }
    
    public boolean equals(Object param1Object) {
      if (param1Object instanceof String)
        return is((String)param1Object); 
      if (param1Object instanceof Tag)
        return is(((Tag)param1Object).getName()); 
      return false;
    }
    
    public String toString() throws IOException {
      StringBuffer stringBuffer = new StringBuffer("<" + this.name);
      Enumeration enumeration1 = this.attrmap.keys(), enumeration2 = this.attrmap.elements();
      while (enumeration1.hasMoreElements())
        stringBuffer.append(" " + enumeration1.nextElement() + "=" + enumeration2.nextElement()); 
      stringBuffer.append(">");
      return stringBuffer.toString();
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\XMLTokenStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */