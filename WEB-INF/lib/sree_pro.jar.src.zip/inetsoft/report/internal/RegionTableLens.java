package inetsoft.report.internal;

import inetsoft.report.TableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Rectangle;
import java.io.Serializable;

public class RegionTableLens implements TableLens, Serializable {
  Cell[][] values;
  
  int[] rowHeights;
  
  int[] colWidths;
  
  int nrow;
  
  int ncol;
  
  int hrow;
  
  int hcol;
  
  Rectangle region;
  
  public RegionTableLens(int paramInt1, int paramInt2, int paramInt3, int paramInt4, Rectangle paramRectangle) {
    this.nrow = paramInt1;
    this.ncol = paramInt2;
    this.hrow = paramInt3;
    this.hcol = paramInt4;
    this.region = paramRectangle;
    this.values = new Cell[paramRectangle.height + paramInt3 + 3][paramRectangle.width + paramInt4 + 3];
    this.rowHeights = new int[paramRectangle.height + paramInt3 + 3];
    this.colWidths = new int[paramRectangle.width + paramInt4 + 3];
    for (byte b = 0; b < this.values.length; b++) {
      for (byte b1 = 0; b1 < this.values[b].length; b1++)
        this.values[b][b1] = new Cell(); 
    } 
  }
  
  public int getRowCount() { return this.nrow; }
  
  public int getColCount() { return this.ncol; }
  
  public int getHeaderRowCount() { return this.hrow; }
  
  public int getHeaderColCount() { return this.hcol; }
  
  public void setRowHeight(int paramInt1, int paramInt2) { this.rowHeights[rowN(paramInt1)] = paramInt2; }
  
  public int getRowHeight(int paramInt) { return this.rowHeights[rowN(paramInt)]; }
  
  public void setColWidth(int paramInt1, int paramInt2) { this.colWidths[colN(paramInt1)] = paramInt2; }
  
  public int getColWidth(int paramInt) { return this.colWidths[colN(paramInt)]; }
  
  public void setRowBorderColor(int paramInt1, int paramInt2, Color paramColor) { (this.values[rowN(paramInt1)][colN(paramInt2)]).rowBorderC = paramColor; }
  
  public Color getRowBorderColor(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).rowBorderC; }
  
  public void setColBorderColor(int paramInt1, int paramInt2, Color paramColor) { (this.values[rowN(paramInt1)][colN(paramInt2)]).colBorderC = paramColor; }
  
  public Color getColBorderColor(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).colBorderC; }
  
  public void setRowBorder(int paramInt1, int paramInt2, int paramInt3) { (this.values[rowN(paramInt1)][colN(paramInt2)]).rowBorder = paramInt3; }
  
  public int getRowBorder(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).rowBorder; }
  
  public void setColBorder(int paramInt1, int paramInt2, int paramInt3) { (this.values[rowN(paramInt1)][colN(paramInt2)]).colBorder = paramInt3; }
  
  public int getColBorder(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).colBorder; }
  
  public void setInsets(int paramInt1, int paramInt2, Insets paramInsets) { (this.values[rowN(paramInt1)][colN(paramInt2)]).insets = paramInsets; }
  
  public Insets getInsets(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).insets; }
  
  public void setSpan(int paramInt1, int paramInt2, Dimension paramDimension) { (this.values[rowN(paramInt1)][colN(paramInt2)]).span = paramDimension; }
  
  public Dimension getSpan(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).span; }
  
  public void setAlignment(int paramInt1, int paramInt2, int paramInt3) { (this.values[rowN(paramInt1)][colN(paramInt2)]).align = paramInt3; }
  
  public int getAlignment(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).align; }
  
  public void setFont(int paramInt1, int paramInt2, Font paramFont) { (this.values[rowN(paramInt1)][colN(paramInt2)]).font = paramFont; }
  
  public Font getFont(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).font; }
  
  public void setLineWrap(int paramInt1, int paramInt2, boolean paramBoolean) { (this.values[rowN(paramInt1)][colN(paramInt2)]).wrap = paramBoolean; }
  
  public boolean isLineWrap(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).wrap; }
  
  public void setForeground(int paramInt1, int paramInt2, Color paramColor) { (this.values[rowN(paramInt1)][colN(paramInt2)]).foreground = paramColor; }
  
  public Color getForeground(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).foreground; }
  
  public void setBackground(int paramInt1, int paramInt2, Color paramColor) { (this.values[rowN(paramInt1)][colN(paramInt2)]).background = paramColor; }
  
  public Color getBackground(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).background; }
  
  public void setObject(int paramInt1, int paramInt2, Object paramObject) { (this.values[rowN(paramInt1)][colN(paramInt2)]).value = paramObject; }
  
  public Object getObject(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).value; }
  
  int rowN(int paramInt) {
    paramInt = ((paramInt < this.hrow + 1) ? paramInt : (paramInt - this.region.y + this.hrow + 1)) + 1;
    return Math.min(paramInt, this.hrow + this.region.height + 1);
  }
  
  int colN(int paramInt) {
    paramInt = ((paramInt < this.hcol + 1) ? paramInt : (paramInt - this.region.x + this.hcol + 1)) + 1;
    return Math.min(paramInt, this.hcol + this.region.width + 1);
  }
  
  static class Cell {
    Object value;
    
    Color foreground;
    
    Color background;
    
    int rowBorder;
    
    int colBorder;
    
    Color rowBorderC;
    
    Color colBorderC;
    
    int align;
    
    Font font;
    
    boolean wrap;
    
    Dimension span;
    
    Insets insets;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\RegionTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */