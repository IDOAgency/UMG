/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionTableLens
/*     */   implements TableLens, Serializable
/*     */ {
/*     */   Cell[][] values;
/*     */   int[] rowHeights;
/*     */   int[] colWidths;
/*     */   int nrow;
/*     */   int ncol;
/*     */   int hrow;
/*     */   int hcol;
/*     */   Rectangle region;
/*     */   
/*     */   public RegionTableLens(int paramInt1, int paramInt2, int paramInt3, int paramInt4, Rectangle paramRectangle) {
/*  33 */     this.nrow = paramInt1;
/*  34 */     this.ncol = paramInt2;
/*  35 */     this.hrow = paramInt3;
/*  36 */     this.hcol = paramInt4;
/*  37 */     this.region = paramRectangle;
/*  38 */     this.values = new Cell[paramRectangle.height + paramInt3 + 3][paramRectangle.width + paramInt4 + 3];
/*  39 */     this.rowHeights = new int[paramRectangle.height + paramInt3 + 3];
/*  40 */     this.colWidths = new int[paramRectangle.width + paramInt4 + 3];
/*     */     
/*  42 */     for (byte b = 0; b < this.values.length; b++) {
/*  43 */       for (byte b1 = 0; b1 < this.values[b].length; b1++) {
/*  44 */         this.values[b][b1] = new Cell();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public int getRowCount() { return this.nrow; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public int getColCount() { return this.ncol; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public int getHeaderRowCount() { return this.hrow; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public int getHeaderColCount() { return this.hcol; }
/*     */ 
/*     */ 
/*     */   
/*  85 */   public void setRowHeight(int paramInt1, int paramInt2) { this.rowHeights[rowN(paramInt1)] = paramInt2; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public int getRowHeight(int paramInt) { return this.rowHeights[rowN(paramInt)]; }
/*     */ 
/*     */ 
/*     */   
/* 100 */   public void setColWidth(int paramInt1, int paramInt2) { this.colWidths[colN(paramInt1)] = paramInt2; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public int getColWidth(int paramInt) { return this.colWidths[colN(paramInt)]; }
/*     */ 
/*     */ 
/*     */   
/* 120 */   public void setRowBorderColor(int paramInt1, int paramInt2, Color paramColor) { (this.values[rowN(paramInt1)][colN(paramInt2)]).rowBorderC = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public Color getRowBorderColor(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).rowBorderC; }
/*     */ 
/*     */ 
/*     */   
/* 134 */   public void setColBorderColor(int paramInt1, int paramInt2, Color paramColor) { (this.values[rowN(paramInt1)][colN(paramInt2)]).colBorderC = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public Color getColBorderColor(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).colBorderC; }
/*     */ 
/*     */ 
/*     */   
/* 148 */   public void setRowBorder(int paramInt1, int paramInt2, int paramInt3) { (this.values[rowN(paramInt1)][colN(paramInt2)]).rowBorder = paramInt3; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public int getRowBorder(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).rowBorder; }
/*     */ 
/*     */ 
/*     */   
/* 165 */   public void setColBorder(int paramInt1, int paramInt2, int paramInt3) { (this.values[rowN(paramInt1)][colN(paramInt2)]).colBorder = paramInt3; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   public int getColBorder(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).colBorder; }
/*     */ 
/*     */ 
/*     */   
/* 182 */   public void setInsets(int paramInt1, int paramInt2, Insets paramInsets) { (this.values[rowN(paramInt1)][colN(paramInt2)]).insets = paramInsets; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   public Insets getInsets(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).insets; }
/*     */ 
/*     */ 
/*     */   
/* 196 */   public void setSpan(int paramInt1, int paramInt2, Dimension paramDimension) { (this.values[rowN(paramInt1)][colN(paramInt2)]).span = paramDimension; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   public Dimension getSpan(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).span; }
/*     */ 
/*     */ 
/*     */   
/* 214 */   public void setAlignment(int paramInt1, int paramInt2, int paramInt3) { (this.values[rowN(paramInt1)][colN(paramInt2)]).align = paramInt3; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 224 */   public int getAlignment(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).align; }
/*     */ 
/*     */ 
/*     */   
/* 228 */   public void setFont(int paramInt1, int paramInt2, Font paramFont) { (this.values[rowN(paramInt1)][colN(paramInt2)]).font = paramFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 238 */   public Font getFont(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).font; }
/*     */ 
/*     */ 
/*     */   
/* 242 */   public void setLineWrap(int paramInt1, int paramInt2, boolean paramBoolean) { (this.values[rowN(paramInt1)][colN(paramInt2)]).wrap = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   public boolean isLineWrap(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).wrap; }
/*     */ 
/*     */ 
/*     */   
/* 258 */   public void setForeground(int paramInt1, int paramInt2, Color paramColor) { (this.values[rowN(paramInt1)][colN(paramInt2)]).foreground = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 269 */   public Color getForeground(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).foreground; }
/*     */ 
/*     */ 
/*     */   
/* 273 */   public void setBackground(int paramInt1, int paramInt2, Color paramColor) { (this.values[rowN(paramInt1)][colN(paramInt2)]).background = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 284 */   public Color getBackground(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).background; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 294 */   public void setObject(int paramInt1, int paramInt2, Object paramObject) { (this.values[rowN(paramInt1)][colN(paramInt2)]).value = paramObject; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 304 */   public Object getObject(int paramInt1, int paramInt2) { return (this.values[rowN(paramInt1)][colN(paramInt2)]).value; }
/*     */ 
/*     */   
/*     */   int rowN(int paramInt) {
/* 308 */     paramInt = ((paramInt < this.hrow + 1) ? paramInt : (paramInt - this.region.y + this.hrow + 1)) + 1;
/* 309 */     return Math.min(paramInt, this.hrow + this.region.height + 1);
/*     */   }
/*     */   
/*     */   int colN(int paramInt) {
/* 313 */     paramInt = ((paramInt < this.hcol + 1) ? paramInt : (paramInt - this.region.x + this.hcol + 1)) + 1;
/* 314 */     return Math.min(paramInt, this.hcol + this.region.width + 1);
/*     */   }
/*     */   
/*     */   static class Cell {
/*     */     Object value;
/*     */     Color foreground;
/*     */     Color background;
/*     */     int rowBorder;
/*     */     int colBorder;
/*     */     Color rowBorderC;
/*     */     Color colBorderC;
/*     */     int align;
/*     */     Font font;
/*     */     boolean wrap;
/*     */     Dimension span;
/*     */     Insets insets;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\RegionTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */