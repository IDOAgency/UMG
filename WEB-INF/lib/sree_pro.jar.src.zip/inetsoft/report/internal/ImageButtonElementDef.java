package inetsoft.report.internal;

import inetsoft.report.ImageButtonElement;
import inetsoft.report.Painter;
import inetsoft.report.StyleSheet;

public class ImageButtonElementDef extends FieldElementDef implements ImageButtonElement {
  ImageButtonPainter painter;
  
  public ImageButtonElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, double paramDouble1, double paramDouble2) { super(paramStyleSheet, paramString1, paramString2, paramDouble1, paramDouble2); }
  
  public ImageButtonElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2) { this(paramStyleSheet, paramString1, paramString2, 0.0D, 0.0D); }
  
  protected FieldPainter createPainter() { return this.painter = new ImageButtonPainter(this); }
  
  public String getResource() { return this.painter.getResource(); }
  
  public void setResource(String paramString) { this.painter.setResource(paramString); }
  
  public void setPainter(Painter paramPainter) {
    super.setPainter(paramPainter);
    this.painter = (ImageButtonPainter)paramPainter;
  }
  
  public String getType() { return "ImageButton"; }
  
  public Object clone() throws CloneNotSupportedException {
    ImageButtonElementDef imageButtonElementDef = (ImageButtonElementDef)super.clone();
    imageButtonElementDef.setPainter(new ImageButtonPainter(imageButtonElementDef));
    imageButtonElementDef.setResource(this.painter.getResource());
    return imageButtonElementDef;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ImageButtonElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */