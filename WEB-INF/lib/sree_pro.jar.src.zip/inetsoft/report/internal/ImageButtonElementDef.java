/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.ImageButtonElement;
/*    */ import inetsoft.report.Painter;
/*    */ import inetsoft.report.StyleSheet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageButtonElementDef
/*    */   extends FieldElementDef
/*    */   implements ImageButtonElement
/*    */ {
/*    */   ImageButtonPainter painter;
/*    */   
/* 33 */   public ImageButtonElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, double paramDouble1, double paramDouble2) { super(paramStyleSheet, paramString1, paramString2, paramDouble1, paramDouble2); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public ImageButtonElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2) { this(paramStyleSheet, paramString1, paramString2, 0.0D, 0.0D); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   protected FieldPainter createPainter() { return this.painter = new ImageButtonPainter(this); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   public String getResource() { return this.painter.getResource(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   public void setResource(String paramString) { this.painter.setResource(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPainter(Painter paramPainter) {
/* 69 */     super.setPainter(paramPainter);
/* 70 */     this.painter = (ImageButtonPainter)paramPainter;
/*    */   }
/*    */ 
/*    */   
/* 74 */   public String getType() { return "ImageButton"; }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 78 */     ImageButtonElementDef imageButtonElementDef = (ImageButtonElementDef)super.clone();
/* 79 */     imageButtonElementDef.setPainter(new ImageButtonPainter(imageButtonElementDef));
/* 80 */     imageButtonElementDef.setResource(this.painter.getResource());
/* 81 */     return imageButtonElementDef;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ImageButtonElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */