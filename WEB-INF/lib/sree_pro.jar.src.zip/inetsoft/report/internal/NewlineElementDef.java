/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.NewlineElement;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NewlineElementDef
/*     */   extends BaseElement
/*     */   implements NewlineElement
/*     */ {
/*     */   private int count;
/*     */   private int skipped;
/*     */   
/*     */   public NewlineElementDef(StyleSheet paramStyleSheet, int paramInt, boolean paramBoolean) {
/*  33 */     super(paramStyleSheet, !paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     this.skipped = 0;
/*     */     this.count = paramInt;
/*     */     setContinuation(paramBoolean);
/* 190 */   } public int getCount() { return this.count; } public void setCount(int paramInt) { this.count = paramInt; } public boolean isBreak() { return !isBlock(); } public void setBreak(boolean paramBoolean) { setBlock(!paramBoolean); } public void skip() { this.skipped++; } public int getRemain() { return this.count - this.skipped; } static Image newlineMarker = null; public void reset() { super.reset(); this.skipped = 0; } public boolean isFlowControl() { return true; } public boolean isLastOnLine() { return true; } public Size getPreferredSize() { return new Size(0.0F, Common.getHeight(getFont(), null) + getSpacing()); } public boolean print(StylePage paramStylePage) { if (!isVisible()) return false;  super.print(paramStylePage); if (this.report.designtime && newlineMarker == null) try { newlineMarker = Common.getImage(this, "/inetsoft/report/images/paramarker.gif"); Common.waitForImage(newlineMarker); markerW = newlineMarker.getWidth(null); markerH = newlineMarker.getHeight(null); } catch (Exception exception) { exception.printStackTrace(); }   float f = Common.getHeight(getFont(), null) + getSpacing(); int i = (newlineMarker != null) ? newlineMarker.getWidth(null) : 1; byte b = 0; do { if (this.report.designtime) paramStylePage.addPaintable(new BasePaintable(this, i, f, this) { Rectangle box; private final int val$w; private final float val$h; private final NewlineElementDef this$0; public void paint(Graphics param1Graphics) { if (NewlineElementDef.newlineMarker != null) { int i = Math.max(Math.min(NewlineElementDef.markerH, (int)this.val$h), 4); param1Graphics.drawImage(NewlineElementDef.newlineMarker, this.box.x, this.box.y, NewlineElementDef.markerW, i, null); }  } public Rectangle getBounds() { return this.box; } public void setLocation(Point param1Point) { this.box.x = param1Point.x; this.box.y = param1Point.y; } }
/* 191 */           );  if (b >= this.count - this.skipped) continue;  this.report.advance(0.0F, f); ++b; } while (b < this.count - this.skipped); return false; } public String toString() { return getID() + " [" + Catalog.getString(getType()) + ": " + this.count + "]"; } public String getType() { return "Newline"; } static int markerW = 0, markerH = 0;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\NewlineElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */