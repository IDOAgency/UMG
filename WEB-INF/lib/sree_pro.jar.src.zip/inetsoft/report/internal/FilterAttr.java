package inetsoft.report.internal;

import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import inetsoft.report.filter.Formula;
import inetsoft.report.filter.SumFormula;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;

public abstract class FilterAttr implements Serializable {
  public static final String AVERAGE_FORMULA = "Average";
  
  public static final String COUNT_FORMULA = "Count";
  
  public static final String DISTINCTCOUNT_FORMULA = "DistinctCount";
  
  public static final String MAX_FORMULA = "Max";
  
  public static final String MIN_FORMULA = "Min";
  
  public static final String PRODUCT_FORMULA = "Product";
  
  public static final String STANDARDDEVIATION_FORMULA = "StandardDeviation";
  
  public static final String SUM_FORMULA = "Sum";
  
  public static final int SORT_ASC = 1;
  
  public static final int SORT_DESC = 2;
  
  public static final int SORT_NONE = 0;
  
  public abstract TableFilter createFilter(TableLens paramTableLens);
  
  public abstract void writeXML(PrintWriter paramPrintWriter);
  
  public abstract void parseXML(XMLTokenStream paramXMLTokenStream) throws IOException, XMLException;
  
  public static FilterAttr parse(XMLTokenStream.Tag paramTag, XMLTokenStream paramXMLTokenStream) throws IOException, XMLException {
    String str = paramTag.get("type");
    DatasetAttr datasetAttr = null;
    if (str != null)
      if (str.equals("group")) {
        datasetAttr = new GroupAttr();
      } else if (str.equals("crosstab")) {
        CrosstabAttr crosstabAttr = new CrosstabAttr();
      } else if (str.equals("dataset")) {
        datasetAttr = new DatasetAttr();
      }  
    if (datasetAttr != null)
      datasetAttr.parseXML(paramXMLTokenStream); 
    do {
    
    } while ((paramTag = (XMLTokenStream.Tag)paramXMLTokenStream.getToken()) != null && !paramTag.getName().equals("/FILTER"));
    return datasetAttr;
  }
  
  protected int[] findColumns(TableLens paramTableLens, String[] paramArrayOfString) {
    int[] arrayOfInt = new int[paramArrayOfString.length];
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      arrayOfInt[b] = findColumn(paramTableLens, paramArrayOfString[b]);
      if (arrayOfInt[b] < 0)
        return null; 
    } 
    return arrayOfInt;
  }
  
  protected int findColumn(TableLens paramTableLens, String paramString) {
    if (paramTableLens != null && paramTableLens.getRowCount() > 0)
      for (byte b = 0; b < paramTableLens.getColCount(); b++) {
        Object object = paramTableLens.getObject(0, b);
        if (paramString.equals(object))
          return b; 
      }  
    return -1;
  }
  
  protected Formula createFormula(String paramString) {
    if (paramString == null)
      return null; 
    try {
      return (Formula)Class.forName("inetsoft.report.filter." + paramString + "Formula").newInstance();
    } catch (Exception exception) {
      exception.printStackTrace();
      return new SumFormula();
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\FilterAttr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */