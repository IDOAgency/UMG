/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.TableFilter;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.filter.Formula;
/*     */ import inetsoft.report.filter.SumFormula;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FilterAttr
/*     */   implements Serializable
/*     */ {
/*     */   public static final String AVERAGE_FORMULA = "Average";
/*     */   public static final String COUNT_FORMULA = "Count";
/*     */   public static final String DISTINCTCOUNT_FORMULA = "DistinctCount";
/*     */   public static final String MAX_FORMULA = "Max";
/*     */   public static final String MIN_FORMULA = "Min";
/*     */   public static final String PRODUCT_FORMULA = "Product";
/*     */   public static final String STANDARDDEVIATION_FORMULA = "StandardDeviation";
/*     */   public static final String SUM_FORMULA = "Sum";
/*     */   public static final int SORT_ASC = 1;
/*     */   public static final int SORT_DESC = 2;
/*     */   public static final int SORT_NONE = 0;
/*     */   
/*     */   public abstract TableFilter createFilter(TableLens paramTableLens);
/*     */   
/*     */   public abstract void writeXML(PrintWriter paramPrintWriter);
/*     */   
/*     */   public abstract void parseXML(XMLTokenStream paramXMLTokenStream) throws IOException, XMLException;
/*     */   
/*     */   public static FilterAttr parse(XMLTokenStream.Tag paramTag, XMLTokenStream paramXMLTokenStream) throws IOException, XMLException {
/*  61 */     String str = paramTag.get("type");
/*  62 */     DatasetAttr datasetAttr = null;
/*     */     
/*  64 */     if (str != null) {
/*  65 */       if (str.equals("group")) {
/*  66 */         datasetAttr = new GroupAttr();
/*     */       }
/*  68 */       else if (str.equals("crosstab")) {
/*  69 */         CrosstabAttr crosstabAttr = new CrosstabAttr();
/*     */       }
/*  71 */       else if (str.equals("dataset")) {
/*  72 */         datasetAttr = new DatasetAttr();
/*     */       } 
/*     */     }
/*     */     
/*  76 */     if (datasetAttr != null)
/*  77 */       datasetAttr.parseXML(paramXMLTokenStream); 
/*     */     do {
/*     */     
/*  80 */     } while ((paramTag = (XMLTokenStream.Tag)paramXMLTokenStream.getToken()) != null && !paramTag.getName().equals("/FILTER"));
/*     */ 
/*     */ 
/*     */     
/*  84 */     return datasetAttr;
/*     */   }
/*     */   
/*     */   protected int[] findColumns(TableLens paramTableLens, String[] paramArrayOfString) {
/*  88 */     int[] arrayOfInt = new int[paramArrayOfString.length];
/*     */     
/*  90 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*  91 */       arrayOfInt[b] = findColumn(paramTableLens, paramArrayOfString[b]);
/*  92 */       if (arrayOfInt[b] < 0) {
/*  93 */         return null;
/*     */       }
/*     */     } 
/*     */     
/*  97 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   protected int findColumn(TableLens paramTableLens, String paramString) {
/* 101 */     if (paramTableLens != null && paramTableLens.getRowCount() > 0) {
/* 102 */       for (byte b = 0; b < paramTableLens.getColCount(); b++) {
/* 103 */         Object object = paramTableLens.getObject(0, b);
/*     */         
/* 105 */         if (paramString.equals(object)) {
/* 106 */           return b;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 111 */     return -1;
/*     */   }
/*     */   
/*     */   protected Formula createFormula(String paramString) {
/* 115 */     if (paramString == null) {
/* 116 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 120 */       return (Formula)Class.forName("inetsoft.report.filter." + paramString + "Formula").newInstance();
/*     */     } catch (Exception exception) {
/*     */       
/* 123 */       exception.printStackTrace();
/*     */ 
/*     */       
/* 126 */       return new SumFormula();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\FilterAttr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */