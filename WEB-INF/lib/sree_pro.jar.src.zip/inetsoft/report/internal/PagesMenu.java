/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.AWTEventMulticaster;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.MediaTracker;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ 
/*     */ public class PagesMenu
/*     */   extends Window {
/*     */   MenuListener menuListener;
/*     */   protected ActionListener actionListener;
/*     */   Image page;
/*     */   Dimension isize;
/*     */   int borderW;
/*     */   int buttonH;
/*     */   Rectangle[][] pages;
/*     */   Rectangle button;
/*     */   Point currPage;
/*     */   String label;
/*     */   
/*  36 */   public PagesMenu(Frame paramFrame) { this(paramFrame, 2, 3); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public PagesMenu(Frame paramFrame, int paramInt1, int paramInt2) { this(paramFrame, paramInt1, paramInt2, "/inetsoft/report/images/page.gif"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PagesMenu(Frame paramFrame, int paramInt1, int paramInt2, String paramString) {
/*  57 */     super(paramFrame);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 164 */     this.menuListener = new MenuListener(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 246 */     this.borderW = 3;
/* 247 */     this.buttonH = 22;
/*     */     
/* 249 */     this.button = new Rectangle();
/* 250 */     this.currPage = new Point(-1, -1);
/* 251 */     this.label = Catalog.getString("Cancel");
/*     */     this.pages = new Rectangle[paramInt1][paramInt2];
/*     */     if (paramString != null) {
/*     */       try {
/*     */         this.page = Common.getImage(this, paramString);
/*     */         MediaTracker mediaTracker = new MediaTracker(this);
/*     */         mediaTracker.addImage(this.page, 0);
/*     */         mediaTracker.waitForAll();
/*     */         this.isize = new Dimension(this.page.getWidth(null), this.page.getHeight(null));
/*     */         this.isize.width += 8;
/*     */         this.isize.height += 8;
/*     */       } catch (Exception exception) {
/*     */         exception.printStackTrace();
/*     */       } 
/*     */     } else {
/*     */       this.isize = new Dimension(30, 30);
/*     */     } 
/*     */     addMouseListener(this.menuListener);
/*     */     addMouseMotionListener(this.menuListener);
/*     */   }
/*     */   
/*     */   public Dimension getPreferredSize() { return new Dimension(this.pages[0].length * this.isize.width + (this.pages[0].length + 1) * this.borderW, this.pages.length * this.isize.height + (this.pages.length + 1) * this.borderW + this.buttonH); }
/*     */   
/*     */   public void paint(Graphics paramGraphics) {
/*     */     Dimension dimension = getSize();
/*     */     Image image = createImage(dimension.width, dimension.height);
/*     */     Graphics graphics = image.getGraphics();
/*     */     graphics.setColor(getBackground());
/*     */     graphics.fill3DRect(0, 0, dimension.width, dimension.height, true);
/*     */     for (int i = 0; i < this.pages.length; i++) {
/*     */       int m = this.borderW, n = this.borderW * (i + true) + this.isize.height * i;
/*     */       for (byte b = 0; b < this.pages[i].length; b++) {
/*     */         if (i <= this.currPage.y && b <= this.currPage.x) {
/*     */           graphics.setColor(new Color(0, 0, 128));
/*     */           graphics.fillRect(m, n, this.isize.width, this.isize.height);
/*     */           graphics.setColor(getBackground());
/*     */         } 
/*     */         this.pages[i][b] = new Rectangle(m, n, this.isize.width, this.isize.height);
/*     */         if (this.page != null)
/*     */           graphics.drawImage(this.page, m + 4, n + 4, this); 
/*     */         graphics.draw3DRect(m, n, this.isize.width, this.isize.height, false);
/*     */         m += this.isize.width + this.borderW;
/*     */       } 
/*     */     } 
/*     */     this.button = new Rectangle(this.borderW, dimension.height - this.buttonH - this.borderW, dimension.width - 2 * this.borderW, dimension.height - (this.pages.length + 1) * this.borderW - this.pages.length * this.isize.height);
/*     */     graphics.setColor(getBackground());
/*     */     graphics.draw3DRect(this.button.x, this.button.y, this.button.width, this.button.height, false);
/*     */     this.label = (this.currPage.x >= 0 && this.currPage.y >= 0) ? ((this.currPage.y + 1) + "x" + (this.currPage.x + 1)) : Catalog.getString("Cancel");
/*     */     FontMetrics fontMetrics = paramGraphics.getFontMetrics();
/*     */     int j = (dimension.width - fontMetrics.stringWidth(this.label)) / 2;
/*     */     int k = this.button.y + (this.button.height - fontMetrics.getHeight()) / 2 + fontMetrics.getAscent();
/*     */     graphics.setColor(getForeground());
/*     */     graphics.drawString(this.label, j, k);
/*     */     graphics.setColor(getBackground());
/*     */     graphics.draw3DRect(this.button.x, this.button.y, this.button.width, this.button.height, false);
/*     */     graphics.dispose();
/*     */     paramGraphics.drawImage(image, 0, 0, this);
/*     */   }
/*     */   
/*     */   public void show(Component paramComponent) {
/*     */     Point point = paramComponent.getLocationOnScreen();
/*     */     point.y += (paramComponent.getSize()).height;
/*     */     pack();
/*     */     setLocation(point);
/*     */     setVisible(true);
/*     */     setLocation(point);
/*     */   }
/*     */   
/*     */   public void update(Graphics paramGraphics) { paint(paramGraphics); }
/*     */   
/*     */   class MenuListener extends MouseAdapter implements MouseMotionListener {
/*     */     private final PagesMenu this$0;
/*     */     
/*     */     MenuListener(PagesMenu this$0) { this.this$0 = this$0; }
/*     */     
/*     */     public void mouseMoved(MouseEvent param1MouseEvent) {
/*     */       for (byte b = 0; b < this.this$0.pages.length; b++) {
/*     */         for (byte b1 = 0; b1 < this.this$0.pages[b].length; b1++) {
/*     */           if (this.this$0.pages[b][b1] != null && this.this$0.pages[b][b1].contains(param1MouseEvent.getX(), param1MouseEvent.getY())) {
/*     */             if (this.this$0.currPage.x != b1 && this.this$0.currPage.y != b) {
/*     */               this.this$0.currPage.x = b1;
/*     */               this.this$0.currPage.y = b;
/*     */               this.this$0.repaint();
/*     */             } 
/*     */             return;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       if (this.this$0.currPage.x != -1 || this.this$0.currPage.y != -1) {
/*     */         this.this$0.currPage.x = this.this$0.currPage.y = -1;
/*     */         this.this$0.repaint();
/*     */       } 
/*     */     }
/*     */     
/*     */     public void mouseDragged(MouseEvent param1MouseEvent) {}
/*     */     
/*     */     public void mouseClicked(MouseEvent param1MouseEvent) {
/*     */       if (this.this$0.button.contains(param1MouseEvent.getX(), param1MouseEvent.getY())) {
/*     */         this.this$0.dispose();
/*     */       } else if (this.this$0.currPage.x != -1 && this.this$0.currPage.y != -1) {
/*     */         this.this$0.fire(new ActionEvent(this.this$0, 1, this.this$0.label));
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public int getRows() { return this.currPage.y + 1; }
/*     */   
/*     */   public int getCols() { return this.currPage.x + 1; }
/*     */   
/*     */   public void addActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.add(this.actionListener, paramActionListener); }
/*     */   
/*     */   public void removeActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.remove(this.actionListener, paramActionListener); }
/*     */   
/*     */   private void fire(ActionEvent paramActionEvent) {
/*     */     if (this.actionListener != null)
/*     */       this.actionListener.actionPerformed(paramActionEvent); 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\PagesMenu.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */