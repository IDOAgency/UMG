package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.SeparatorElement;
import inetsoft.report.Size;
import inetsoft.report.StylePage;
import inetsoft.report.StyleSheet;
import inetsoft.report.locale.Catalog;
import java.awt.Dimension;

public class SeparatorElementDef extends BaseElement implements SeparatorElement {
  private int style;
  
  private int adv;
  
  private int height;
  
  public SeparatorElementDef(StyleSheet paramStyleSheet, int paramInt) {
    super(paramStyleSheet, true);
    this.height = 5;
    this.adv = paramStyleSheet.sepadv;
    setStyle(paramInt);
  }
  
  public int getStyle() { return this.style; }
  
  public void setStyle(int paramInt) {
    this.style = paramInt;
    this.height = (int)Math.ceil(Common.getLineWidth(paramInt)) + this.adv;
  }
  
  public int getSeparatorAdvance() { return this.adv; }
  
  public void setSeparatorAdvance(int paramInt) {
    this.adv = paramInt;
    this.height = (int)Math.ceil(Common.getLineWidth(this.style)) + this.adv;
  }
  
  public Size getPreferredSize() { return new Size(5000.0F, this.height); }
  
  public boolean print(StylePage paramStylePage) {
    if (!isVisible())
      return false; 
    super.print(paramStylePage);
    Dimension dimension = paramStylePage.getPageDimension();
    paramStylePage.addPaintable(new SeparatorPaintable(this.report.printHead.x + this.report.printBox.x, this.report.printHead.y + this.report.printBox.y, this.report.printBox.width, this.style, this.adv, this));
    this.report.advance(0.0F, this.height);
    return false;
  }
  
  public String toString() { return getID() + " [" + Catalog.getString(getType()) + ": " + Util.getLineStyleName(this.style) + "]"; }
  
  public String getType() { return "Separator"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SeparatorElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */