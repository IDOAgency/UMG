package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.ReportElement;
import inetsoft.report.Size;
import inetsoft.report.SpaceElement;
import inetsoft.report.StylePage;
import inetsoft.report.StyleSheet;
import inetsoft.report.locale.Catalog;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;

public class SpaceElementDef extends BaseElement implements SpaceElement {
  private int pixels;
  
  public SpaceElementDef(StyleSheet paramStyleSheet, int paramInt) {
    super(paramStyleSheet, false);
    this.pixels = paramInt;
  }
  
  public Size getPreferredSize() {
    FontMetrics fontMetrics = Common.getFontMetrics(getFont());
    return new Size(this.pixels, Common.getHeight(getFont(), fontMetrics));
  }
  
  public boolean print(StylePage paramStylePage) {
    if (!isVisible())
      return false; 
    super.print(paramStylePage);
    byte b = (this.pixels == 0) ? 0 : ((int)Common.getHeight(getFont(), null) + getSpacing());
    if (this.report.designtime)
      paramStylePage.addPaintable(new BasePaintable(this, b, this) {
            Rectangle box;
            
            private final int val$h;
            
            private final SpaceElementDef this$0;
            
            public void paint(Graphics param1Graphics) {
              param1Graphics.setColor(Color.gray);
              int i = this.box.y + this.val$h / 2;
              for (int j = this.box.x + 2; j < this.box.x + this.box.width; j += 4)
                Common.drawLine(param1Graphics, j, i, j, i); 
            }
            
            public Rectangle getBounds() { return this.box; }
            
            public void setLocation(Point param1Point) { this.box.x = param1Point.x;
              this.box.y = param1Point.y; }
          }); 
    this.report.advance(this.pixels, b);
    return false;
  }
  
  public int getSpace() { return this.pixels; }
  
  public void setSpace(int paramInt) { this.pixels = paramInt; }
  
  public String toString() { return getID() + " [" + Catalog.getString(getType()) + ": " + this.pixels + "]"; }
  
  public String getType() { return "Space"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SpaceElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */