/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.SpaceElement;
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.Color;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpaceElementDef
/*     */   extends BaseElement
/*     */   implements SpaceElement
/*     */ {
/*     */   private int pixels;
/*     */   
/*     */   public SpaceElementDef(StyleSheet paramStyleSheet, int paramInt) {
/*  32 */     super(paramStyleSheet, false);
/*  33 */     this.pixels = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Size getPreferredSize() {
/*  40 */     FontMetrics fontMetrics = Common.getFontMetrics(getFont());
/*  41 */     return new Size(this.pixels, Common.getHeight(getFont(), fontMetrics));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean print(StylePage paramStylePage) {
/*  50 */     if (!isVisible()) {
/*  51 */       return false;
/*     */     }
/*     */     
/*  54 */     super.print(paramStylePage);
/*     */     
/*  56 */     byte b = (this.pixels == 0) ? 0 : ((int)Common.getHeight(getFont(), null) + getSpacing());
/*     */ 
/*     */     
/*  59 */     if (this.report.designtime) {
/*  60 */       paramStylePage.addPaintable(new BasePaintable(this, b, this)
/*     */           {
/*     */             Rectangle box;
/*     */             
/*     */             private final int val$h;
/*     */             private final SpaceElementDef this$0;
/*     */             
/*     */             public void paint(Graphics param1Graphics) {
/*  68 */               param1Graphics.setColor(Color.gray);
/*  69 */               int i = this.box.y + this.val$h / 2;
/*     */               
/*  71 */               for (int j = this.box.x + 2; j < this.box.x + this.box.width; j += 4) {
/*  72 */                 Common.drawLine(param1Graphics, j, i, j, i);
/*     */               }
/*     */             }
/*     */ 
/*     */             
/*  77 */             public Rectangle getBounds() { return this.box; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             public void setLocation(Point param1Point) {
/*  87 */               this.box.x = param1Point.x; this.box.y = param1Point.y;
/*     */             }
/*     */           });
/*     */     }
/*     */     
/*  92 */     this.report.advance(this.pixels, b);
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public int getSpace() { return this.pixels; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public void setSpace(int paramInt) { this.pixels = paramInt; }
/*     */ 
/*     */ 
/*     */   
/* 113 */   public String toString() { return getID() + " [" + Catalog.getString(getType()) + ": " + this.pixels + "]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public String getType() { return "Space"; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SpaceElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */