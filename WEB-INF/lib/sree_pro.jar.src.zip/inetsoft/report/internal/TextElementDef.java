package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.Size;
import inetsoft.report.StylePage;
import inetsoft.report.StyleSheet;
import inetsoft.report.TextElement;
import inetsoft.report.TextLens;
import inetsoft.report.lens.DefaultTextLens;
import inetsoft.report.locale.Catalog;
import java.awt.FontMetrics;
import java.awt.Point;
import java.awt.Rectangle;

public class TextElementDef extends TabSupport implements TextBased, TextElement {
  private boolean cache;
  
  private TextLens lens;
  
  private boolean justify;
  
  private int textadv;
  
  private boolean orphan;
  
  private String text;
  
  private String lensText;
  
  private Size psize;
  
  private float lastX;
  
  static final int MAX_LINE = 400;
  
  public TextElementDef(StyleSheet paramStyleSheet, TextLens paramTextLens) {
    super(paramStyleSheet, 0);
    this.cache = true;
    this.psize = null;
    this.lastX = 0.0F;
    this.lens = paramTextLens;
    this.justify = paramStyleSheet.justify;
    this.textadv = paramStyleSheet.textadv;
    this.orphan = paramStyleSheet.orphan;
    this.cache = !(paramTextLens instanceof HTextLens);
  }
  
  public Size getPreferredSize() {
    try {
      evaluate();
    } catch (Throwable throwable) {
      if (Util.isGUI()) {
        MessageDialog.show(throwable + "\n" + getScript());
      } else {
        System.err.println("Script failed: " + getScript());
        System.err.println(throwable);
      } 
    } 
    if (!this.cache || this.psize == null) {
      this.psize = StyleCore.getTextSize(getDisplayText(), getFont(), getSpacing());
      this.psize.width += this.textadv;
    } 
    return this.psize;
  }
  
  public boolean isBreakable() { return true; }
  
  public boolean isLastOnLine() {
    String str = (this.text == null) ? getDisplayText() : this.text;
    return (str.length() > 400 || str.indexOf('\n') >= 0);
  }
  
  public String getText() {
    if (!this.cache || this.lensText == null)
      this.lensText = this.lens.getText(); 
    return this.lensText;
  }
  
  public void setText(String paramString) { setText(new DefaultTextLens(paramString)); }
  
  public String getDisplayText() {
    if (this.lens instanceof HeaderTextLens)
      return ((HeaderTextLens)this.lens).getDisplayText(); 
    String str = getText();
    return (str == null) ? "" : str;
  }
  
  public void setText(TextLens paramTextLens) {
    this.lens = paramTextLens;
    this.lensText = null;
    this.psize = null;
  }
  
  public TextLens getTextLens() { return this.lens; }
  
  public TextElementDef clone(String paramString) {
    try {
      TextElementDef textElementDef = (TextElementDef)super.clone();
      textElementDef.lens = new DefaultTextLens(paramString);
      return textElementDef;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public boolean print(StylePage paramStylePage) {
    super.print(paramStylePage);
    if (!isVisible())
      return false; 
    this.report.resolution = paramStylePage.getPageResolution();
    boolean bool = (this.orphan && !(this.lens instanceof HTextLens)) ? 1 : 0;
    if (this.text == null) {
      this.text = getDisplayText();
      this.lastX = this.report.lastHead.x;
      if (this.report.designtime && this.text.length() == 0)
        this.text = " "; 
    } 
    if (getHindent() > 0)
      this.report.printHead.x = Math.max(this.report.printHead.x, this.lastX); 
    FontMetrics fontMetrics = Common.getFontMetrics(getFont());
    float f1 = Common.getHeight(getFont(), fontMetrics) + getSpacing();
    if (this.report.printHead.y + f1 > this.report.printBox.height && this.report.printHead.y > 0.0F) {
      this.report.printHead.y += f1;
      return true;
    } 
    if (this.report.printHead.x >= this.report.printBox.width)
      return true; 
    float f2 = (float)getIndent() * this.report.resolution + getHindent();
    float f3 = this.report.lineH;
    while (this.text != null && this.text.length() > 0) {
      boolean bool1 = true;
      char c = '\n';
      String str = this.text;
      int i = str.indexOf('\n');
      if (i >= 0)
        str = str.substring(0, i); 
      int j = str.indexOf('\t');
      if (j >= 0) {
        str = str.substring(0, j);
        i = j;
        c = '\t';
      } 
      str = (i >= 0) ? str : this.text;
      this.text = (i >= 0) ? this.text.substring(i + 1) : null;
      while (bool1) {
        String str1 = str;
        float f = this.report.printBox.width - this.report.printHead.x;
        TextPaintable textPaintable = null;
        int k = Util.breakLine(str, f, getFont(), true);
        if (k >= 0) {
          if (this.report.printHead.x > f2 && this.report.printHead.x > this.lastX && !Character.isWhitespace(str.charAt(k)))
            k = 0; 
          bool1 = (!this.report.horFlow && f3 > 0.0F) ? 1 : 0;
          str1 = str.substring(0, k);
          while (k < str.length() && Character.isWhitespace(str.charAt(k)))
            k++; 
          str = str.substring(k);
        } else {
          str = "";
          bool1 = false;
        } 
        boolean bool2 = (this.lens instanceof HTextLens || (this.lens instanceof HeaderTextLens && this.lens.getText().indexOf("{N}") >= 0)) ? 1 : 0;
        if (bool2) {
          textPaintable = new TextPaintable(this.lens, this.report.printBox.x + this.report.printHead.x, this.report.printBox.y + this.report.printHead.y, this);
          paramStylePage.addPaintable(textPaintable);
          this.text = null;
          this.report.printHead.x += Common.stringWidth(str1, getFont(), fontMetrics) + this.textadv;
          this.report.printHead.y += f1;
          return false;
        } 
        if (this.justify && str.length() > 0) {
          textPaintable = new TextPaintable(str1, this.report.printBox.x + this.report.printHead.x, this.report.printBox.y + this.report.printHead.y, f, this);
        } else {
          textPaintable = new TextPaintable(str1, this.report.printBox.x + this.report.printHead.x, this.report.printBox.y + this.report.printHead.y, this);
        } 
        paramStylePage.addPaintable(textPaintable);
        f3 -= f1;
        this.report.printHead.x = (str.length() > 0) ? this.report.printBox.width : (this.report.printHead.x + Common.stringWidth(str1, getFont(), fontMetrics) + this.textadv);
        if ((c == '\n' || this.report.printHead.x >= this.report.printBox.width) && ((this.text != null && this.text.length() > 0) || str.length() > 0)) {
          if (!this.report.horFlow)
            if ((getAlignment() & 0x2) != 0) {
              Rectangle rectangle = textPaintable.getBounds();
              float f4 = (this.report.printBox.x + (this.report.printBox.width - rectangle.width) / 2);
              f4 = Math.max(f4, rectangle.x);
              textPaintable.setLocation(new Point((int)f4, rectangle.y));
            } else if ((getAlignment() & 0x4) != 0) {
              Rectangle rectangle = textPaintable.getBounds();
              float f4 = (this.report.printBox.x + this.report.printBox.width - rectangle.width);
              f4 = Math.max(f4, rectangle.x);
              textPaintable.setLocation(new Point((int)f4, rectangle.y));
            }  
          if (this.report.printHead.y + 2.0F * f1 > this.report.printBox.height) {
            if (bool && !this.nonflow) {
              int m = paramStylePage.getPaintableCount() - 1;
              while (m >= 0 && paramStylePage.getPaintable(m).getElement() == this)
                m--; 
              m++;
              if (paramStylePage.getPaintableCount() == m + 1) {
                paramStylePage.removePaintable(m);
                this.text = getDisplayText();
                str = "";
              } else if (Common.stringWidth(this.text, getFont(), fontMetrics) <= this.report.printBox.width) {
                if (paramStylePage.getPaintableCount() > m + 2) {
                  str = str1 + " " + str;
                  paramStylePage.removePaintable(paramStylePage.getPaintableCount() - 1);
                } else {
                  int n = paramStylePage.getPaintableCount() - 1;
                  for (; n >= m; n--)
                    paramStylePage.removePaintable(n); 
                  this.text = getDisplayText();
                  str = "";
                } 
              } 
            } 
            this.text = (this.text == null) ? str : ((str == null || str.length() == 0) ? this.text : (str + c + this.text));
            if (this.nonflow && this.text.length() > 0) {
              String str2 = textPaintable.getText() + " " + this.text;
              k = Util.breakLine(str2, f, getFont(), false);
              textPaintable.setText(str2.substring(0, k));
            } 
            this.report.printHead.y += 2.0F * f1;
            return true;
          } 
          if (!this.report.horFlow) {
            if (f3 > 0.0F || getHindent() > 0) {
              this.report.printHead.x = this.lastX;
            } else {
              this.report.printHead.x = f2;
            } 
            if (bool1) {
              this.report.printHead.y += f1;
              this.report.advanceLine = Math.max(this.report.advanceLine, f1);
            } 
          } 
        } 
      } 
      if (c == '\t') {
        if ((getAlignment() & true) != 0) {
          float f = this.report.printHead.y;
          printTab(paramStylePage);
          if (this.report.printHead.x >= this.report.printBox.width && this.text.length() > 0) {
            this.report.printHead.y = f + f1;
            if (f3 > 0.0F || getHindent() > 0) {
              this.report.printHead.x = this.lastX;
            } else {
              this.report.printHead.x = f2;
            } 
            this.report.advanceLine = Math.max(this.report.advanceLine, f1);
            continue;
          } 
          this.report.printHead.y = f;
          continue;
        } 
        this.report.printHead.x += (fontMetrics.charWidth('\t') - 1);
        continue;
      } 
      if (c == '\n') {
        this.report.printHead.y += f1;
        this.text = (this.text == null) ? str : ((str == null || str.length() == 0) ? this.text : (str + '\n' + this.text));
        return (this.text != null && this.text.length() > 0);
      } 
    } 
    this.report.printHead.y += f1;
    this.text = null;
    return false;
  }
  
  public void reset() {
    super.reset();
    this.text = null;
    this.lensText = null;
  }
  
  public boolean isJustify() { return this.justify; }
  
  public void setJustify(boolean paramBoolean) { this.justify = paramBoolean; }
  
  public int getTextAdvance() { return this.textadv; }
  
  public void setTextAdvance(int paramInt) { this.textadv = paramInt; }
  
  public boolean isOrphanControl() { return this.orphan; }
  
  public void setOrphanControl(boolean paramBoolean) { this.orphan = paramBoolean; }
  
  public boolean isRightTab() { return false; }
  
  public void setRightTab(boolean paramBoolean) {}
  
  public String toString() { return getID() + " [" + Catalog.getString(getType()) + "]"; }
  
  public String getType() { return "Text"; }
  
  public Object clone() throws CloneNotSupportedException { return clone(getText()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TextElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */