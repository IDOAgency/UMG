/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.TableFilter;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.filter.DefaultSortedTable;
/*     */ import inetsoft.report.filter.Formula;
/*     */ import inetsoft.report.filter.GroupFilter;
/*     */ import inetsoft.report.filter.SortFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupAttr
/*     */   extends SummaryAttr
/*     */ {
/*     */   public TableFilter createFilter(TableLens paramTableLens) {
/*  32 */     String[] arrayOfString1 = getGroupCols();
/*  33 */     String[] arrayOfString2 = getSummaryCols();
/*  34 */     int[] arrayOfInt1 = findColumns(paramTableLens, arrayOfString1);
/*  35 */     int[] arrayOfInt2 = findColumns(paramTableLens, arrayOfString2);
/*     */     
/*  37 */     if (arrayOfInt1 == null) {
/*  38 */       System.err.println("Group columns defined in group filter not found in table: " + toString(getGroupCols()) + " in " + toString(paramTableLens));
/*     */       
/*  40 */       return null;
/*     */     } 
/*     */     
/*  43 */     if (arrayOfInt2 == null) {
/*  44 */       System.err.println("Summary columns defined in group filter not found in table" + toString(getSummaryCols()) + " in " + toString(paramTableLens));
/*     */       
/*  46 */       return null;
/*     */     } 
/*     */ 
/*     */     
/*  50 */     SortFilter sortFilter = null;
/*  51 */     if (isSorted()) {
/*  52 */       sortFilter = new DefaultSortedTable(paramTableLens, arrayOfInt1);
/*     */     } else {
/*     */       
/*  55 */       boolean[] arrayOfBoolean = new boolean[arrayOfInt1.length];
/*  56 */       for (byte b1 = 0; b1 < arrayOfBoolean.length; b1++) {
/*  57 */         arrayOfBoolean[b1] = (getOrder(arrayOfString1[b1]) != 2);
/*     */       }
/*     */       
/*  60 */       sortFilter = new SortFilter(paramTableLens, arrayOfInt1, arrayOfBoolean);
/*     */     } 
/*     */     
/*  63 */     boolean bool = true;
/*  64 */     Formula[] arrayOfFormula = new Formula[arrayOfInt2.length];
/*     */ 
/*     */     
/*  67 */     for (byte b = 0; b < arrayOfFormula.length; b++) {
/*  68 */       String str = getFormula(arrayOfString2[b]);
/*  69 */       if (str != null) {
/*  70 */         bool = false;
/*  71 */         arrayOfFormula[b] = createFormula(str);
/*     */       } 
/*     */     } 
/*     */     
/*  75 */     GroupFilter groupFilter = new GroupFilter(sortFilter, arrayOfInt2, bool ? null : arrayOfFormula, (this.grandTotal && !bool) ? arrayOfFormula : null);
/*     */ 
/*     */     
/*  78 */     groupFilter.setAddGroupHeader(isShowHeader());
/*  79 */     groupFilter.setShowGroupColumns(isShowGroupCols());
/*  80 */     groupFilter.setGroupHeaderStyle(isInPlaceHeader() ? 2 : 1);
/*     */ 
/*     */     
/*  83 */     groupFilter.setBreakAfterSection(isBreakAfter());
/*  84 */     groupFilter.setGrandLabel(getGrandLabel());
/*  85 */     return groupFilter;
/*     */   }
/*     */ 
/*     */   
/*  89 */   public void setShowHeader(boolean paramBoolean) { this.showHeader = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*  93 */   public boolean isShowHeader() { return this.showHeader; }
/*     */ 
/*     */ 
/*     */   
/*  97 */   public void setShowGroupCols(boolean paramBoolean) { this.showGroupCols = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 101 */   public boolean isShowGroupCols() { return this.showGroupCols; }
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void setInPlaceHeader(boolean paramBoolean) { this.inplace = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 109 */   public boolean isInPlaceHeader() { return this.inplace; }
/*     */ 
/*     */ 
/*     */   
/* 113 */   public void setBreakAfter(boolean paramBoolean) { this.breakAfter = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 117 */   public boolean isBreakAfter() { return this.breakAfter; }
/*     */ 
/*     */ 
/*     */   
/* 121 */   public void setGrandTotal(boolean paramBoolean) { this.grandTotal = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 125 */   public boolean isGrandTotal() { return this.grandTotal; }
/*     */ 
/*     */ 
/*     */   
/* 129 */   public void setGrandLabel(String paramString) { this.grandLabel = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 133 */   public String getGrandLabel() { return this.grandLabel; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeXML(PrintWriter paramPrintWriter) {
/* 140 */     paramPrintWriter.println("<filter type=\"group\">");
/* 141 */     paramPrintWriter.print("<group sorted=\"" + this.sorted + "\" showHeader=\"" + this.showHeader + "\" showGroupCols=\"" + this.showGroupCols + "\" inplace=\"" + this.inplace + "\" breakAfter=\"" + this.breakAfter + "\" grandTotal=\"" + this.grandTotal + "\"");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     if (this.grandLabel != null) {
/* 148 */       paramPrintWriter.print(" grandLabel=\"" + this.grandLabel + "\"");
/*     */     }
/*     */     
/* 151 */     paramPrintWriter.println(">");
/*     */     
/* 153 */     for (byte b1 = 0; b1 < this.groupCols.size(); b1++) {
/* 154 */       String str = (String)this.groupCols.elementAt(b1);
/* 155 */       paramPrintWriter.print("<groupCol order=\"" + getOrder(str) + "\">");
/* 156 */       paramPrintWriter.println("<![CDATA[" + str + "]]></groupCol>");
/*     */     } 
/*     */     
/* 159 */     for (byte b2 = 0; b2 < this.sumCols.size(); b2++) {
/* 160 */       String str1 = (String)this.sumCols.elementAt(b2);
/* 161 */       String str2 = getFormula(str1);
/*     */       
/* 163 */       paramPrintWriter.print("<sumCol");
/* 164 */       if (str2 != null) {
/* 165 */         paramPrintWriter.print(" formula=\"" + str2 + "\"");
/*     */       }
/*     */       
/* 168 */       paramPrintWriter.println("><![CDATA[" + str1 + "]]></sumCol>");
/*     */     } 
/*     */     
/* 171 */     paramPrintWriter.println("</group>");
/* 172 */     paramPrintWriter.println("</filter>");
/*     */   }
/*     */   
/*     */   public void parseXML(XMLTokenStream paramXMLTokenStream) throws IOException, XMLException {
/* 176 */     XMLTokenStream.Tag tag = (XMLTokenStream.Tag)paramXMLTokenStream.getToken();
/* 177 */     int i = -1;
/* 178 */     String str = null;
/*     */     
/* 180 */     if (tag.is("group")) {
/*     */       String str1;
/*     */       
/* 183 */       if ((str1 = tag.get("order")) != null) {
/* 184 */         i = Integer.parseInt(str1);
/*     */       }
/*     */       
/* 187 */       if ((str1 = tag.get("sorted")) != null) {
/* 188 */         this.sorted = str1.equalsIgnoreCase("true");
/*     */       }
/*     */       
/* 191 */       if ((str1 = tag.get("showHeader")) != null) {
/* 192 */         this.showHeader = str1.equalsIgnoreCase("true");
/*     */       }
/*     */       
/* 195 */       if ((str1 = tag.get("showGroupCols")) != null) {
/* 196 */         this.showGroupCols = str1.equalsIgnoreCase("true");
/*     */       }
/*     */       
/* 199 */       if ((str1 = tag.get("inplace")) != null) {
/* 200 */         this.inplace = str1.equalsIgnoreCase("true");
/*     */       }
/*     */       
/* 203 */       if ((str1 = tag.get("breakAfter")) != null) {
/* 204 */         this.breakAfter = str1.equalsIgnoreCase("true");
/*     */       }
/*     */       
/* 207 */       if ((str1 = tag.get("grandTotal")) != null) {
/* 208 */         this.grandTotal = str1.equalsIgnoreCase("true");
/*     */       }
/*     */       
/* 211 */       this.grandLabel = tag.get("grandLabel");
/* 212 */       str = tag.get("formula");
/*     */       
/*     */       Object object;
/* 215 */       while ((object = paramXMLTokenStream.getToken()) != null) {
/* 216 */         if (!(object instanceof XMLTokenStream.Tag)) {
/*     */           continue;
/*     */         }
/*     */         
/* 220 */         XMLTokenStream.Tag tag1 = (XMLTokenStream.Tag)object;
/* 221 */         if (tag1.is("/group")) {
/*     */           break;
/*     */         }
/* 224 */         if (tag1.is("groupCol")) {
/* 225 */           String str2 = (String)paramXMLTokenStream.getToken();
/* 226 */           int j = i;
/*     */           
/* 228 */           if ((str1 = tag1.get("order")) != null) {
/* 229 */             j = Integer.parseInt(str1);
/*     */           }
/*     */           
/* 232 */           addGroupCol(str2);
/* 233 */           setOrder(str2, j); continue;
/*     */         } 
/* 235 */         if (tag1.is("sumCol")) {
/* 236 */           String str2 = (String)paramXMLTokenStream.getToken();
/* 237 */           String str3 = str;
/*     */           
/* 239 */           if ((str1 = tag1.get("formula")) != null) {
/* 240 */             str3 = str1;
/*     */           }
/*     */           
/* 243 */           addSummaryCol(str2);
/* 244 */           setFormula(str2, str3);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean showHeader = true;
/*     */   private boolean showGroupCols = false;
/*     */   private boolean inplace = true;
/*     */   private boolean breakAfter = false;
/*     */   private boolean grandTotal = true;
/* 255 */   private String grandLabel = null;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\GroupAttr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */