package inetsoft.report.internal;

import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import inetsoft.report.filter.DefaultSortedTable;
import inetsoft.report.filter.Formula;
import inetsoft.report.filter.GroupFilter;
import inetsoft.report.filter.SortFilter;
import java.io.IOException;
import java.io.PrintWriter;

public class GroupAttr extends SummaryAttr {
  public TableFilter createFilter(TableLens paramTableLens) {
    String[] arrayOfString1 = getGroupCols();
    String[] arrayOfString2 = getSummaryCols();
    int[] arrayOfInt1 = findColumns(paramTableLens, arrayOfString1);
    int[] arrayOfInt2 = findColumns(paramTableLens, arrayOfString2);
    if (arrayOfInt1 == null) {
      System.err.println("Group columns defined in group filter not found in table: " + toString(getGroupCols()) + " in " + toString(paramTableLens));
      return null;
    } 
    if (arrayOfInt2 == null) {
      System.err.println("Summary columns defined in group filter not found in table" + toString(getSummaryCols()) + " in " + toString(paramTableLens));
      return null;
    } 
    SortFilter sortFilter = null;
    if (isSorted()) {
      sortFilter = new DefaultSortedTable(paramTableLens, arrayOfInt1);
    } else {
      boolean[] arrayOfBoolean = new boolean[arrayOfInt1.length];
      for (byte b1 = 0; b1 < arrayOfBoolean.length; b1++)
        arrayOfBoolean[b1] = (getOrder(arrayOfString1[b1]) != 2); 
      sortFilter = new SortFilter(paramTableLens, arrayOfInt1, arrayOfBoolean);
    } 
    boolean bool = true;
    Formula[] arrayOfFormula = new Formula[arrayOfInt2.length];
    for (byte b = 0; b < arrayOfFormula.length; b++) {
      String str = getFormula(arrayOfString2[b]);
      if (str != null) {
        bool = false;
        arrayOfFormula[b] = createFormula(str);
      } 
    } 
    GroupFilter groupFilter = new GroupFilter(sortFilter, arrayOfInt2, bool ? null : arrayOfFormula, (this.grandTotal && !bool) ? arrayOfFormula : null);
    groupFilter.setAddGroupHeader(isShowHeader());
    groupFilter.setShowGroupColumns(isShowGroupCols());
    groupFilter.setGroupHeaderStyle(isInPlaceHeader() ? 2 : 1);
    groupFilter.setBreakAfterSection(isBreakAfter());
    groupFilter.setGrandLabel(getGrandLabel());
    return groupFilter;
  }
  
  public void setShowHeader(boolean paramBoolean) { this.showHeader = paramBoolean; }
  
  public boolean isShowHeader() { return this.showHeader; }
  
  public void setShowGroupCols(boolean paramBoolean) { this.showGroupCols = paramBoolean; }
  
  public boolean isShowGroupCols() { return this.showGroupCols; }
  
  public void setInPlaceHeader(boolean paramBoolean) { this.inplace = paramBoolean; }
  
  public boolean isInPlaceHeader() { return this.inplace; }
  
  public void setBreakAfter(boolean paramBoolean) { this.breakAfter = paramBoolean; }
  
  public boolean isBreakAfter() { return this.breakAfter; }
  
  public void setGrandTotal(boolean paramBoolean) { this.grandTotal = paramBoolean; }
  
  public boolean isGrandTotal() { return this.grandTotal; }
  
  public void setGrandLabel(String paramString) { this.grandLabel = paramString; }
  
  public String getGrandLabel() { return this.grandLabel; }
  
  public void writeXML(PrintWriter paramPrintWriter) {
    paramPrintWriter.println("<filter type=\"group\">");
    paramPrintWriter.print("<group sorted=\"" + this.sorted + "\" showHeader=\"" + this.showHeader + "\" showGroupCols=\"" + this.showGroupCols + "\" inplace=\"" + this.inplace + "\" breakAfter=\"" + this.breakAfter + "\" grandTotal=\"" + this.grandTotal + "\"");
    if (this.grandLabel != null)
      paramPrintWriter.print(" grandLabel=\"" + this.grandLabel + "\""); 
    paramPrintWriter.println(">");
    for (byte b1 = 0; b1 < this.groupCols.size(); b1++) {
      String str = (String)this.groupCols.elementAt(b1);
      paramPrintWriter.print("<groupCol order=\"" + getOrder(str) + "\">");
      paramPrintWriter.println("<![CDATA[" + str + "]]></groupCol>");
    } 
    for (byte b2 = 0; b2 < this.sumCols.size(); b2++) {
      String str1 = (String)this.sumCols.elementAt(b2);
      String str2 = getFormula(str1);
      paramPrintWriter.print("<sumCol");
      if (str2 != null)
        paramPrintWriter.print(" formula=\"" + str2 + "\""); 
      paramPrintWriter.println("><![CDATA[" + str1 + "]]></sumCol>");
    } 
    paramPrintWriter.println("</group>");
    paramPrintWriter.println("</filter>");
  }
  
  public void parseXML(XMLTokenStream paramXMLTokenStream) throws IOException, XMLException {
    XMLTokenStream.Tag tag = (XMLTokenStream.Tag)paramXMLTokenStream.getToken();
    int i = -1;
    String str = null;
    if (tag.is("group")) {
      String str1;
      if ((str1 = tag.get("order")) != null)
        i = Integer.parseInt(str1); 
      if ((str1 = tag.get("sorted")) != null)
        this.sorted = str1.equalsIgnoreCase("true"); 
      if ((str1 = tag.get("showHeader")) != null)
        this.showHeader = str1.equalsIgnoreCase("true"); 
      if ((str1 = tag.get("showGroupCols")) != null)
        this.showGroupCols = str1.equalsIgnoreCase("true"); 
      if ((str1 = tag.get("inplace")) != null)
        this.inplace = str1.equalsIgnoreCase("true"); 
      if ((str1 = tag.get("breakAfter")) != null)
        this.breakAfter = str1.equalsIgnoreCase("true"); 
      if ((str1 = tag.get("grandTotal")) != null)
        this.grandTotal = str1.equalsIgnoreCase("true"); 
      this.grandLabel = tag.get("grandLabel");
      str = tag.get("formula");
      Object object;
      while ((object = paramXMLTokenStream.getToken()) != null) {
        if (!(object instanceof XMLTokenStream.Tag))
          continue; 
        XMLTokenStream.Tag tag1 = (XMLTokenStream.Tag)object;
        if (tag1.is("/group"))
          break; 
        if (tag1.is("groupCol")) {
          String str2 = (String)paramXMLTokenStream.getToken();
          int j = i;
          if ((str1 = tag1.get("order")) != null)
            j = Integer.parseInt(str1); 
          addGroupCol(str2);
          setOrder(str2, j);
          continue;
        } 
        if (tag1.is("sumCol")) {
          String str2 = (String)paramXMLTokenStream.getToken();
          String str3 = str;
          if ((str1 = tag1.get("formula")) != null)
            str3 = str1; 
          addSummaryCol(str2);
          setFormula(str2, str3);
        } 
      } 
    } 
  }
  
  private boolean showHeader = true;
  
  private boolean showGroupCols = false;
  
  private boolean inplace = true;
  
  private boolean breakAfter = false;
  
  private boolean grandTotal = true;
  
  private String grandLabel = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\GroupAttr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */