/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Presenter;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.SectionBand;
/*     */ import inetsoft.report.SectionElement;
/*     */ import inetsoft.report.SectionLens;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.filter.Formula;
/*     */ import inetsoft.report.filter.GroupFilter;
/*     */ import inetsoft.report.filter.SortFilter;
/*     */ import inetsoft.report.lens.AbstractTableLens;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.Rectangle;
/*     */ import java.text.Format;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class SectionElementDef extends BaseElement implements SectionElement {
/*     */   static final int OK = 0;
/*     */   static final int ADVANCE = 1;
/*     */   static final int REPEAT = 2;
/*     */   private TableLens tablelens;
/*     */   private SectionLens sectionlens;
/*     */   private Hashtable presenters;
/*     */   private Hashtable formats;
/*     */   private Hashtable bandGaps;
/*     */   private int currentRow;
/*     */   private GroupFilter group;
/*     */   private boolean allDone;
/*     */   private int headerLevel;
/*     */   private int footerLevel;
/*     */   private int lastHeaderRow;
/*     */   private Vector bandinfos;
/*     */   
/*     */   public SectionElementDef(StyleSheet paramStyleSheet, SectionLens paramSectionLens, TableLens paramTableLens) {
/*  41 */     super(paramStyleSheet, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 759 */     this.bandGaps = new Hashtable();
/*     */ 
/*     */     
/* 762 */     this.currentRow = 1;
/*     */     
/* 764 */     this.allDone = false;
/* 765 */     this.headerLevel = 0;
/* 766 */     this.footerLevel = 0;
/* 767 */     this.lastHeaderRow = -1;
/*     */ 
/*     */     
/* 770 */     this.bandinfos = new Vector();
/*     */     setSection(paramSectionLens);
/*     */     setTable(paramTableLens);
/*     */     this.presenters = (Hashtable)paramStyleSheet.presentermap.clone();
/*     */     this.formats = (Hashtable)paramStyleSheet.formatmap.clone();
/*     */   }
/*     */   
/*     */   public void setStyleSheet(StyleSheet paramStyleSheet) {
/*     */     super.setStyleSheet(paramStyleSheet);
/*     */     setStyleSheet(this.sectionlens, paramStyleSheet);
/*     */   }
/*     */   
/*     */   private void setStyleSheet(SectionLens paramSectionLens, StyleSheet paramStyleSheet) {
/*     */     if (paramSectionLens == null)
/*     */       return; 
/*     */     if (paramSectionLens.getSectionHeader() != null)
/*     */       paramSectionLens.getSectionHeader().setStyleSheet(paramStyleSheet); 
/*     */     if (paramSectionLens.getSectionFooter() != null)
/*     */       paramSectionLens.getSectionFooter().setStyleSheet(paramStyleSheet); 
/*     */     Object object = paramSectionLens.getSectionContent();
/*     */     if (object instanceof SectionBand) {
/*     */       ((SectionBand)object).setStyleSheet(paramStyleSheet);
/*     */     } else if (object instanceof SectionLens) {
/*     */       setStyleSheet((SectionLens)object, paramStyleSheet);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Presenter getPresenter(Class paramClass) { return StyleCore.getPresenter(this.presenters, paramClass); }
/*     */   
/*     */   public void addPresenter(Class paramClass, Presenter paramPresenter) { this.presenters.put(paramClass, paramPresenter); }
/*     */   
/*     */   public Format getFormat(Class paramClass) { return StyleCore.getFormat(this.formats, paramClass); }
/*     */   
/*     */   public void addFormat(Class paramClass, Format paramFormat) { this.formats.put(paramClass, paramFormat); }
/*     */   
/*     */   public void reset() {
/*     */     super.reset();
/*     */     this.bandGaps.clear();
/*     */     this.group = null;
/*     */     this.currentRow = 1;
/*     */     this.lastHeaderRow = -1;
/*     */     this.headerLevel = 0;
/*     */     this.footerLevel = 0;
/*     */     this.allDone = false;
/*     */   }
/*     */   
/*     */   public Size getPreferredSize() { return new Size(0.0F, 0.0F); }
/*     */   
/*     */   public boolean isBreakable() { return true; }
/*     */   
/*     */   public boolean print(StylePage paramStylePage) {
/*     */     if (!isVisible() || this.allDone)
/*     */       return false; 
/*     */     AbstractTableLens abstractTableLens = (this.group != null) ? this.group : getTable();
/*     */     Hashtable hashtable = new Hashtable();
/*     */     SectionLens sectionLens = getSection();
/*     */     if (sectionLens == null)
/*     */       throw new RuntimeException("Section content can not be null"); 
/*     */     boolean bool = (sectionLens.getSectionContent() instanceof SectionLens || abstractTableLens instanceof GroupFilter) ? 1 : 0;
/*     */     SectionBand sectionBand1 = sectionLens.getSectionFooter();
/*     */     boolean bool1 = false;
/*     */     super.print(paramStylePage);
/*     */     this.report.printHead.x = 0.0F;
/*     */     float f1 = this.report.printHead.y;
/*     */     this.bandinfos.removeAllElements();
/*     */     if (this.group == null && abstractTableLens instanceof GroupFilter) {
/*     */       this.group = (GroupFilter)abstractTableLens;
/*     */       this.group.setAddGroupHeader(true);
/*     */       this.group.setGroupHeaderStyle(4098);
/*     */     } 
/*     */     if (abstractTableLens != null)
/*     */       for (byte b = 0; b < abstractTableLens.getColCount(); b++) {
/*     */         Object object = abstractTableLens.getObject(0, b);
/*     */         hashtable.put((object == null) ? Integer.toString(b) : object, new Integer(b));
/*     */       }  
/*     */     if (bool && this.report.designtime && abstractTableLens == null)
/*     */       abstractTableLens = new AbstractTableLens(this) {
/*     */           private final SectionElementDef this$0;
/*     */           
/*     */           public Object getObject(int param1Int1, int param1Int2) { return (param1Int1 == 0) ? ("Column " + param1Int2) : ("Cell " + param1Int2); }
/*     */           
/*     */           public int getRowCount() { return 2; }
/*     */           
/*     */           public int getColCount() { return 50; }
/*     */           
/*     */           public int getHeaderRowCount() { return 1; }
/*     */         }; 
/*     */     SectionBand sectionBand2 = sectionLens.getSectionHeader();
/*     */     float f2 = 0.0F;
/*     */     boolean bool2 = true;
/*     */     if (sectionBand2 != null && sectionBand2.isVisible()) {
/*     */       f2 = sectionBand2.getHeight() * this.report.resolution;
/*     */       if (this.report.printHead.y > 0.0F && this.report.printHead.y + f2 > this.report.printBox.height)
/*     */         return true; 
/*     */       if (abstractTableLens != null)
/*     */         bind(sectionBand2, abstractTableLens, (this.currentRow < abstractTableLens.getRowCount()) ? this.currentRow : (this.currentRow - 1), hashtable); 
/*     */       if (printBand(paramStylePage, sectionBand2, "Header", 0, false) != 0)
/*     */         return true; 
/*     */     } 
/*     */     if (bool) {
/*     */       if (this.group == null) {
/*     */         Vector vector = new Vector();
/*     */         byte b1 = 0;
/*     */         Object object = sectionLens.getSectionContent();
/*     */         for (; object instanceof SectionLens; object = ((SectionLens)object).getSectionContent())
/*     */           vector.addElement(new Integer(b1++)); 
/*     */         int[] arrayOfInt = new int[vector.size()];
/*     */         for (byte b2 = 0; b2 < arrayOfInt.length; b2++)
/*     */           arrayOfInt[b2] = ((Integer)vector.elementAt(b2)).intValue(); 
/*     */         this.group = new GroupFilter(new SortFilter(abstractTableLens, arrayOfInt), null, null, (Formula)null);
/*     */         this.group.setAddGroupHeader(true);
/*     */         this.group.setGroupHeaderStyle(4098);
/*     */       } 
/*     */       int i = this.group.hasGrandSummary() ? 1 : 0;
/*     */       int j = this.group.getGroupColCount();
/*     */       String str = "Content";
/*     */       while (this.currentRow < this.group.getRowCount() - i) {
/*     */         boolean bool3 = false;
/*     */         boolean bool4 = false;
/*     */         if (this.group.isGroupHeaderCell(this.currentRow, this.group.getGroupColCount() - 1)) {
/*     */           int m = this.group.getGroupLevel(this.currentRow) + 1;
/*     */           if (this.lastHeaderRow != this.currentRow)
/*     */             this.headerLevel = m - 1; 
/*     */           if (this.headerLevel < j) {
/*     */             if (m < this.footerLevel && str != "Header") {
/*     */               bool4 = true;
/*     */             } else {
/*     */               bool3 = true;
/*     */             } 
/*     */           } else {
/*     */             this.headerLevel = m;
/*     */           } 
/*     */         } 
/*     */         if (bool3) {
/*     */           SectionLens sectionLens1 = getSection(sectionLens, this.headerLevel + 1);
/*     */           sectionBand2 = sectionLens1.getSectionHeader();
/*     */           str = "Header";
/*     */           int m = 0;
/*     */           this.lastHeaderRow = this.currentRow;
/*     */           if (sectionBand2 != null && sectionBand2.isVisible()) {
/*     */             if (this.report.printHead.y > Math.ceil(f2) && this.report.printHead.y + sectionBand2.getHeight() * this.report.resolution > this.report.printBox.height) {
/*     */               bool1 = true;
/*     */               break;
/*     */             } 
/*     */             bind(sectionBand2, this.group, this.currentRow, hashtable);
/*     */             m = printBand(paramStylePage, sectionBand2, str, this.headerLevel + 1, bool2);
/*     */             bool2 = (m != 0);
/*     */           } 
/*     */           if (m != 2) {
/*     */             this.headerLevel++;
/*     */             this.footerLevel = Math.max(this.headerLevel, this.footerLevel);
/*     */             if (this.group.isGroupHeaderRow(this.currentRow))
/*     */               this.currentRow++; 
/*     */           } 
/*     */           if (m != 0) {
/*     */             bool1 = true;
/*     */             break;
/*     */           } 
/*     */           continue;
/*     */         } 
/*     */         if (bool4 || this.group.isSummaryRow(this.currentRow)) {
/*     */           SectionLens sectionLens1 = getSection(sectionLens, this.footerLevel);
/*     */           sectionBand2 = sectionLens1.getSectionFooter();
/*     */           str = "Footer";
/*     */           int m = 0;
/*     */           if (sectionBand2 != null && sectionBand2.isVisible()) {
/*     */             if (this.report.printHead.y > Math.ceil(f2) && this.report.printHead.y + sectionBand2.getHeight() * this.report.resolution > this.report.printBox.height) {
/*     */               bool1 = true;
/*     */               break;
/*     */             } 
/*     */             bind(sectionBand2, this.group, this.currentRow, hashtable);
/*     */             m = printBand(paramStylePage, sectionBand2, str, this.footerLevel, bool2);
/*     */             bool2 = (m != 0);
/*     */           } 
/*     */           if (m != 2) {
/*     */             this.footerLevel--;
/*     */             if (!bool4)
/*     */               this.currentRow++; 
/*     */           } 
/*     */           if (m != 0) {
/*     */             bool1 = true;
/*     */             break;
/*     */           } 
/*     */           continue;
/*     */         } 
/*     */         int k = 0;
/*     */         sectionBand2 = getSectionBand(sectionLens);
/*     */         str = "Content";
/*     */         this.footerLevel = j;
/*     */         if (sectionBand2 != null && sectionBand2.isVisible()) {
/*     */           if (this.report.printHead.y > Math.ceil(f2) && this.report.printHead.y + sectionBand2.getHeight() * this.report.resolution > this.report.printBox.height) {
/*     */             bool1 = true;
/*     */             break;
/*     */           } 
/*     */           bind(sectionBand2, this.group, this.currentRow, hashtable);
/*     */           k = printBand(paramStylePage, sectionBand2, str, j, bool2);
/*     */           bool2 = (k != 0);
/*     */         } 
/*     */         if (k != 2)
/*     */           this.currentRow++; 
/*     */         if (k != 0) {
/*     */           bool1 = true;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       if (i > 0 && this.currentRow == this.group.getRowCount() - 1)
/*     */         bind(sectionBand1, this.group, this.currentRow, hashtable); 
/*     */     } else if (sectionLens.getSectionContent() instanceof SectionBand) {
/*     */       sectionBand2 = (SectionBand)sectionLens.getSectionContent();
/*     */       while ((abstractTableLens == null && this.currentRow <= 1) || (abstractTableLens != null && this.currentRow < abstractTableLens.getRowCount())) {
/*     */         int i = 0;
/*     */         if (sectionBand2.isVisible()) {
/*     */           if (this.report.printHead.y > Math.ceil(f2) && this.report.printHead.y + sectionBand2.getHeight() * this.report.resolution > this.report.printBox.height) {
/*     */             bool1 = true;
/*     */             break;
/*     */           } 
/*     */           if (abstractTableLens != null)
/*     */             bind(sectionBand2, abstractTableLens, this.currentRow, hashtable); 
/*     */           i = printBand(paramStylePage, sectionBand2, "Content", 0, bool2);
/*     */           bool2 = (i != 0);
/*     */         } 
/*     */         if (i != 2)
/*     */           this.currentRow++; 
/*     */         if (i != 0) {
/*     */           bool1 = true;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     if (!bool1) {
/*     */       while (this.footerLevel > 0) {
/*     */         SectionLens sectionLens1 = getSection(sectionLens, this.footerLevel);
/*     */         sectionBand2 = sectionLens1.getSectionFooter();
/*     */         int i = 0;
/*     */         if (sectionBand2 != null && sectionBand2.isVisible()) {
/*     */           if (this.report.printHead.y > Math.ceil(f2) && this.report.printHead.y + sectionBand2.getHeight() * this.report.resolution > this.report.printBox.height) {
/*     */             bool1 = true;
/*     */             break;
/*     */           } 
/*     */           i = printBand(paramStylePage, sectionBand2, "Footer", this.footerLevel, bool2);
/*     */         } 
/*     */         if (i != 2)
/*     */           this.footerLevel--; 
/*     */         if (i != 0) {
/*     */           bool1 = true;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       if (!bool1 && sectionBand1 != null && sectionBand1.isVisible()) {
/*     */         int i = printBand(paramStylePage, sectionBand1, "Footer", 0, bool2);
/*     */         switch (i) {
/*     */           case 0:
/*     */             this.allDone = true;
/*     */             break;
/*     */           case 1:
/*     */             this.allDone = true;
/*     */             bool1 = true;
/*     */             break;
/*     */           case 2:
/*     */             this.allDone = false;
/*     */             bool1 = true;
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     if (this.bandinfos.size() > 0) {
/*     */       SectionBandInfo[] arrayOfSectionBandInfo = new SectionBandInfo[this.bandinfos.size()];
/*     */       this.bandinfos.copyInto(arrayOfSectionBandInfo);
/*     */       paramStylePage.addPaintable(new SectionPaintable(this.report.printBox.x, f1 + this.report.printBox.y, this.report.printBox.width, arrayOfSectionBandInfo, this));
/*     */     } 
/*     */     this.report.printHead.y += (getSpacing() + 1);
/*     */     return bool1;
/*     */   }
/*     */   
/*     */   public TableLens getTable() { return this.tablelens; }
/*     */   
/*     */   public void setTable(TableLens paramTableLens) { this.tablelens = paramTableLens; }
/*     */   
/*     */   public SectionLens getSection() { return this.sectionlens; }
/*     */   
/*     */   public void setSection(SectionLens paramSectionLens) { this.sectionlens = paramSectionLens; }
/*     */   
/*     */   public SectionLens getSection(SectionLens paramSectionLens, int paramInt) {
/*     */     while (paramSectionLens != null && paramInt > 0 && paramSectionLens.getSectionContent() instanceof SectionLens) {
/*     */       paramSectionLens = (SectionLens)paramSectionLens.getSectionContent();
/*     */       paramInt--;
/*     */     } 
/*     */     return paramSectionLens;
/*     */   }
/*     */   
/*     */   public ReportElement getElement(String paramString) { return getElement(this.sectionlens, paramString); }
/*     */   
/*     */   private ReportElement getElement(SectionLens paramSectionLens, String paramString) {
/*     */     if (paramSectionLens == null)
/*     */       return null; 
/*     */     ReportElement reportElement = null;
/*     */     if (paramSectionLens.getSectionHeader() != null) {
/*     */       reportElement = paramSectionLens.getSectionHeader().getElement(paramString);
/*     */       if (reportElement != null)
/*     */         return reportElement; 
/*     */     } 
/*     */     if (paramSectionLens.getSectionFooter() != null) {
/*     */       reportElement = paramSectionLens.getSectionFooter().getElement(paramString);
/*     */       if (reportElement != null)
/*     */         return reportElement; 
/*     */     } 
/*     */     Object object = paramSectionLens.getSectionContent();
/*     */     if (object instanceof SectionBand)
/*     */       return ((SectionBand)object).getElement(paramString); 
/*     */     if (object instanceof SectionLens)
/*     */       return getElement((SectionLens)object, paramString); 
/*     */     return null;
/*     */   }
/*     */   
/*     */   public Enumeration getElements() {
/*     */     Vector vector = new Vector();
/*     */     getAllElements(this.sectionlens, vector);
/*     */     return vector.elements();
/*     */   }
/*     */   
/*     */   private void getAllElements(SectionLens paramSectionLens, Vector paramVector) {
/*     */     if (paramSectionLens == null)
/*     */       return; 
/*     */     append(paramVector, paramSectionLens.getSectionHeader());
/*     */     append(paramVector, paramSectionLens.getSectionFooter());
/*     */     Object object = paramSectionLens.getSectionContent();
/*     */     if (object instanceof SectionBand) {
/*     */       append(paramVector, (SectionBand)object);
/*     */     } else if (object instanceof SectionLens) {
/*     */       getAllElements((SectionLens)object, paramVector);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void append(Vector paramVector, SectionBand paramSectionBand) {
/*     */     for (byte b = 0; b < paramSectionBand.getElementCount(); b++)
/*     */       paramVector.addElement(paramSectionBand.getElement(b)); 
/*     */   }
/*     */   
/*     */   public SectionBand getSectionBand(SectionLens paramSectionLens) {
/*     */     while (paramSectionLens != null) {
/*     */       Object object = paramSectionLens.getSectionContent();
/*     */       if (object instanceof SectionBand)
/*     */         return (SectionBand)object; 
/*     */       paramSectionLens = (SectionLens)object;
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   public void bind(SectionBand paramSectionBand, TableLens paramTableLens, int paramInt, Hashtable paramHashtable) {
/*     */     for (byte b = 0; b < paramSectionBand.getElementCount(); b++) {
/*     */       ReportElement reportElement = paramSectionBand.getElement(b);
/*     */       String str = paramSectionBand.getBinding(reportElement.getID());
/*     */       if (str != null) {
/*     */         Integer integer = (Integer)paramHashtable.get(str);
/*     */         if (integer != null)
/*     */           this.report.setValue(reportElement, paramTableLens.getObject(paramInt, integer.intValue())); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int printBand(StylePage paramStylePage, SectionBand paramSectionBand, String paramString, int paramInt, boolean paramBoolean) {
/*     */     if (!paramBoolean && paramSectionBand.isPageBefore() && this.report.printHead.y > 0.0F)
/*     */       return 2; 
/*     */     SectionInfo sectionInfo = new SectionInfo(getID(), this.currentRow, paramString, paramInt);
/*     */     float f = Math.min(paramSectionBand.getHeight() * this.report.resolution, this.report.printBox.height - this.report.printHead.y);
/*     */     int i = paramStylePage.getPaintableCount();
/*     */     Rectangle rectangle = new Rectangle(this.report.printBox.x, (int)this.report.printHead.y + this.report.printBox.y, this.report.printBox.width, (int)f);
/*     */     for (byte b = 0; b < paramSectionBand.getElementCount(); b++)
/*     */       ((BaseElement)paramSectionBand.getElement(b)).setUserObject(sectionInfo); 
/*     */     this.report.printFixedContainer(paramStylePage, paramSectionBand, rectangle, true);
/*     */     if (paramSectionBand.isShrinkToFit()) {
/*     */       int j = rectangle.y;
/*     */       for (int k = i; k < paramStylePage.getPaintableCount(); k++) {
/*     */         Rectangle rectangle1 = paramStylePage.getPaintable(k).getBounds();
/*     */         j = Math.max(j, rectangle1.y + rectangle1.height);
/*     */       } 
/*     */       f = (j + getBottomGap(paramSectionBand) - rectangle.y);
/*     */     } 
/*     */     this.report.printHead.x = 0.0F;
/*     */     this.report.printHead.y += f;
/*     */     this.bandinfos.addElement(new SectionBandInfo(paramSectionBand, paramString, paramInt));
/*     */     if (((paramInt > 0 || paramString != "Header") && paramSectionBand.isPageAfter()) || this.report.printHead.y >= (this.report.printBox.height - 2))
/*     */       return 1; 
/*     */     return 0;
/*     */   }
/*     */   
/*     */   private int getBottomGap(SectionBand paramSectionBand) {
/*     */     Integer integer = (Integer)this.bandGaps.get(paramSectionBand);
/*     */     if (integer == null) {
/*     */       int i = 0;
/*     */       for (byte b = 0; b < paramSectionBand.getElementCount(); b++) {
/*     */         Rectangle rectangle = paramSectionBand.getBounds(b);
/*     */         i = Math.max(rectangle.y + rectangle.height, i);
/*     */       } 
/*     */       int j = (int)(paramSectionBand.getHeight() * this.report.resolution);
/*     */       this.bandGaps.put(paramSectionBand, integer = new Integer(Math.max(0, j - i)));
/*     */     } 
/*     */     return integer.intValue();
/*     */   }
/*     */   
/*     */   public String toString() { return getID() + " [" + Catalog.getString(getType()) + "]"; }
/*     */   
/*     */   public String getType() { return "Section"; }
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException {
/*     */     SectionElementDef sectionElementDef = (SectionElementDef)super.clone();
/*     */     sectionElementDef.sectionlens = (SectionLens)this.sectionlens.clone();
/*     */     return sectionElementDef;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SectionElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */