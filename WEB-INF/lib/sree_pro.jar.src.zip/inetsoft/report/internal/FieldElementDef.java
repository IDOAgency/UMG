package inetsoft.report.internal;

import inetsoft.report.FieldElement;
import inetsoft.report.Painter;
import inetsoft.report.StyleSheet;
import inetsoft.report.locale.Catalog;

public abstract class FieldElementDef extends PainterElementDef implements FieldElement {
  FieldPainter painter;
  
  public FieldElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, double paramDouble1, double paramDouble2) {
    super(paramStyleSheet, null, paramDouble1, paramDouble2);
    setPainter(this.painter = createPainter());
    this.painter.setForm(paramString1);
    this.painter.setName(paramString2);
  }
  
  public String getName() { return this.painter.getName(); }
  
  public void setName(String paramString) { this.painter.setName(paramString); }
  
  public String getForm() { return this.painter.getForm(); }
  
  public void setForm(String paramString) { this.painter.setForm(paramString); }
  
  public void setPainter(Painter paramPainter) {
    super.setPainter(paramPainter);
    this.painter = (FieldPainter)paramPainter;
  }
  
  protected abstract FieldPainter createPainter();
  
  public Object clone() throws CloneNotSupportedException {
    FieldElementDef fieldElementDef = (FieldElementDef)super.clone();
    fieldElementDef.painter = (FieldPainter)this.painter.clone();
    return fieldElementDef;
  }
  
  public String toString() { return getID() + " [" + Catalog.getString(getType()) + "]"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\FieldElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */