/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.Context;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import java.awt.Image;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TabSupport
/*     */   extends BaseElement
/*     */ {
/*     */   private int fill;
/*     */   private double[] stops;
/*     */   
/*     */   public TabSupport(StyleSheet paramStyleSheet, int paramInt) {
/*  30 */     super(paramStyleSheet, false);
/*     */     
/*  32 */     this.fill = paramInt;
/*  33 */     this.stops = (double[])paramStyleSheet.tabStops.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean printTab(StylePage paramStylePage) {
/*  40 */     if (this.report.designtime && tabMarker == null) {
/*     */       try {
/*  42 */         tabMarker = Common.getImage(this, "/inetsoft/report/images/tabmarker.gif");
/*     */ 
/*     */         
/*  45 */         Common.waitForImage(tabMarker);
/*     */       } catch (Exception exception) {
/*  47 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/*  51 */     float f = Common.getHeight(getFont(), null) + getSpacing();
/*     */     
/*  53 */     if (this.report.printHead.y + f > this.report.printBox.height) {
/*  54 */       this.report.printHead.y += f;
/*  55 */       return true;
/*     */     } 
/*     */     
/*  58 */     int i = 0;
/*  59 */     for (byte b = 0; b < this.stops.length; b++) {
/*  60 */       i = (int)(this.stops[b] * this.report.resolution);
/*  61 */       if (this.report.printHead.x < i || i >= this.report.printBox.width) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  67 */     i = Math.min(i, this.report.printBox.width);
/*  68 */     if (i > this.report.printHead.x) {
/*  69 */       float f1 = i - this.report.printHead.x;
/*  70 */       TabPaintable tabPaintable = new TabPaintable(this.report.printHead.x + this.report.printBox.x, this.report.printHead.y + this.report.printBox.y, f1, f, this.fill, this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  76 */       if (this.report.designtime) {
/*  77 */         tabPaintable.setTabMarker(tabMarker);
/*     */       }
/*     */       
/*  80 */       paramStylePage.addPaintable(tabPaintable);
/*  81 */       this.report.advance(f1, f);
/*     */     } 
/*     */     
/*  84 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public int getFillStyle() { return this.fill; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public void setFillStyle(int paramInt) { this.fill = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public double[] getTabStops() { return this.stops; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public void setTabStops(double[] paramArrayOfDouble) { this.stops = paramArrayOfDouble; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContext(ReportElement paramReportElement) {
/* 123 */     super.setContext(paramReportElement);
/*     */     
/* 125 */     if (paramReportElement instanceof Context) {
/* 126 */       Context context = (Context)paramReportElement;
/* 127 */       setTabStops(context.getTabStops());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   static Image tabMarker = null, rtabMarker = null;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TabSupport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */