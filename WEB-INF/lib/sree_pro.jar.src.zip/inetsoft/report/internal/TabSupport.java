package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.Context;
import inetsoft.report.ReportElement;
import inetsoft.report.StylePage;
import inetsoft.report.StyleSheet;
import java.awt.Image;

public abstract class TabSupport extends BaseElement {
  private int fill;
  
  private double[] stops;
  
  public TabSupport(StyleSheet paramStyleSheet, int paramInt) {
    super(paramStyleSheet, false);
    this.fill = paramInt;
    this.stops = (double[])paramStyleSheet.tabStops.clone();
  }
  
  public boolean printTab(StylePage paramStylePage) {
    if (this.report.designtime && tabMarker == null)
      try {
        tabMarker = Common.getImage(this, "/inetsoft/report/images/tabmarker.gif");
        Common.waitForImage(tabMarker);
      } catch (Exception exception) {
        exception.printStackTrace();
      }  
    float f = Common.getHeight(getFont(), null) + getSpacing();
    if (this.report.printHead.y + f > this.report.printBox.height) {
      this.report.printHead.y += f;
      return true;
    } 
    int i = 0;
    for (byte b = 0; b < this.stops.length; b++) {
      i = (int)(this.stops[b] * this.report.resolution);
      if (this.report.printHead.x < i || i >= this.report.printBox.width)
        break; 
    } 
    i = Math.min(i, this.report.printBox.width);
    if (i > this.report.printHead.x) {
      float f1 = i - this.report.printHead.x;
      TabPaintable tabPaintable = new TabPaintable(this.report.printHead.x + this.report.printBox.x, this.report.printHead.y + this.report.printBox.y, f1, f, this.fill, this);
      if (this.report.designtime)
        tabPaintable.setTabMarker(tabMarker); 
      paramStylePage.addPaintable(tabPaintable);
      this.report.advance(f1, f);
    } 
    return false;
  }
  
  public int getFillStyle() { return this.fill; }
  
  public void setFillStyle(int paramInt) { this.fill = paramInt; }
  
  public double[] getTabStops() { return this.stops; }
  
  public void setTabStops(double[] paramArrayOfDouble) { this.stops = paramArrayOfDouble; }
  
  public void setContext(ReportElement paramReportElement) {
    super.setContext(paramReportElement);
    if (paramReportElement instanceof Context) {
      Context context = (Context)paramReportElement;
      setTabStops(context.getTabStops());
    } 
  }
  
  static Image tabMarker = null, rtabMarker = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TabSupport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */