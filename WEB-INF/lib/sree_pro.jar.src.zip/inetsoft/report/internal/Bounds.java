/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import java.awt.Point;
/*    */ import java.awt.Rectangle;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bounds
/*    */   implements Serializable
/*    */ {
/*    */   public float x;
/*    */   public float y;
/*    */   public float width;
/*    */   public float height;
/*    */   
/* 29 */   public Bounds() { this(0.0F, 0.0F, 0.0F, 0.0F); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Bounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 40 */     this.x = paramFloat1;
/* 41 */     this.y = paramFloat2;
/* 42 */     this.width = paramFloat3;
/* 43 */     this.height = paramFloat4;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   public Bounds(Bounds paramBounds) { this(paramBounds.x, paramBounds.y, paramBounds.width, paramBounds.height); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 57 */   public Bounds(Rectangle paramRectangle) { this(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 64 */   public Rectangle getRectangle() { return new Rectangle((int)this.x, (int)this.y, (int)this.width, (int)this.height); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 71 */   public void setLocation(Point paramPoint) { this.x = paramPoint.x; this.y = paramPoint.y; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Bounds round() {
/* 78 */     float f1 = (float)Math.ceil((this.x + this.width));
/* 79 */     float f2 = (float)Math.ceil((this.y + this.height));
/* 80 */     float f3 = (float)Math.ceil(this.x);
/* 81 */     float f4 = (float)Math.ceil(this.y);
/* 82 */     return new Bounds(f3, f4, f1 - f3, f2 - f4);
/*    */   }
/*    */ 
/*    */   
/* 86 */   public String toString() { return "Bounds[" + this.x + "," + this.y + " " + this.width + "x" + this.height + "]"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\Bounds.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */