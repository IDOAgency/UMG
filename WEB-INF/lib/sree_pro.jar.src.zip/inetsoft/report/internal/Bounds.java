package inetsoft.report.internal;

import java.awt.Point;
import java.awt.Rectangle;
import java.io.Serializable;

public class Bounds implements Serializable {
  public float x;
  
  public float y;
  
  public float width;
  
  public float height;
  
  public Bounds() { this(0.0F, 0.0F, 0.0F, 0.0F); }
  
  public Bounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.x = paramFloat1;
    this.y = paramFloat2;
    this.width = paramFloat3;
    this.height = paramFloat4;
  }
  
  public Bounds(Bounds paramBounds) { this(paramBounds.x, paramBounds.y, paramBounds.width, paramBounds.height); }
  
  public Bounds(Rectangle paramRectangle) { this(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height); }
  
  public Rectangle getRectangle() { return new Rectangle((int)this.x, (int)this.y, (int)this.width, (int)this.height); }
  
  public void setLocation(Point paramPoint) { this.x = paramPoint.x;
    this.y = paramPoint.y; }
  
  public Bounds round() {
    float f1 = (float)Math.ceil((this.x + this.width));
    float f2 = (float)Math.ceil((this.y + this.height));
    float f3 = (float)Math.ceil(this.x);
    float f4 = (float)Math.ceil(this.y);
    return new Bounds(f3, f4, f1 - f3, f2 - f4);
  }
  
  public String toString() { return "Bounds[" + this.x + "," + this.y + " " + this.width + "x" + this.height + "]"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\Bounds.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */