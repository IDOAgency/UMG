package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.ReportElement;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SeparatorPaintable extends BasePaintable {
  private float x;
  
  private float y;
  
  private float w;
  
  private int style;
  
  private int adv;
  
  public SeparatorPaintable(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, ReportElement paramReportElement) {
    super(paramReportElement);
    this.x = paramFloat1;
    this.y = paramFloat2;
    this.w = paramFloat3;
    this.style = paramInt1;
    this.adv = paramInt2;
  }
  
  public int getStyle() { return this.style; }
  
  public void paint(Graphics paramGraphics) {
    paramGraphics.setColor(this.elem.getForeground());
    Common.drawHLine(paramGraphics, this.y, this.x, this.x + this.w, this.style, 0, 0);
  }
  
  public Rectangle getBounds() { return new Rectangle((int)this.x, (int)this.y, (int)this.w, (int)Math.ceil((Common.getLineWidth(this.style) + this.adv))); }
  
  public void setLocation(Point paramPoint) { this.x = paramPoint.x;
    this.y = paramPoint.y; }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
    paramObjectInputStream.defaultReadObject();
    this.elem = new DefaultContext();
    ((DefaultContext)this.elem).read(paramObjectInputStream);
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    paramObjectOutputStream.defaultWriteObject();
    DefaultContext.write(paramObjectOutputStream, this.elem);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SeparatorPaintable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */