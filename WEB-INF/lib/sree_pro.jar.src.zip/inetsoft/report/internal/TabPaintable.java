package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.ReportElement;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TabPaintable extends BasePaintable {
  float x;
  
  float y;
  
  float w;
  
  float h;
  
  int fill;
  
  Image tabMarker;
  
  public TabPaintable(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, ReportElement paramReportElement) {
    super(paramReportElement);
    this.w = paramFloat3;
    this.h = paramFloat4;
    this.x = paramFloat1;
    this.y = paramFloat2;
    this.fill = paramInt;
  }
  
  public void setTabMarker(Image paramImage) { this.tabMarker = paramImage; }
  
  public void paint(Graphics paramGraphics) {
    paramGraphics.setColor(this.elem.getForeground());
    if (this.fill != 0) {
      float f = this.y + Common.getHeight(this.elem.getFont(), null) - Common.getLineWidth(this.fill) - 1.0F;
      Common.drawHLine(paramGraphics, f, this.x, this.x + this.w, this.fill, 0, 0);
    } else if (this.tabMarker != null) {
      int i = this.tabMarker.getWidth(null);
      int j = this.tabMarker.getHeight(null);
      paramGraphics.drawImage(this.tabMarker, (int)(this.x + (this.w - i) / 2.0F), (int)(this.y + (this.h - j) / 2.0F), null);
    } 
  }
  
  public Rectangle getBounds() { return new Rectangle((int)this.x, (int)this.y, (int)this.w, (int)this.h); }
  
  public void setLocation(Point paramPoint) { this.x = paramPoint.x;
    this.y = paramPoint.y; }
  
  public int getFill() { return this.fill; }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
    paramObjectInputStream.defaultReadObject();
    this.elem = new DefaultContext();
    ((DefaultContext)this.elem).read(paramObjectInputStream);
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    paramObjectOutputStream.defaultWriteObject();
    DefaultContext.write(paramObjectOutputStream, this.elem);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TabPaintable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */