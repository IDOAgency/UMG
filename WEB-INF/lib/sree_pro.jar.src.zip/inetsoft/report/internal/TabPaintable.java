/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.Common;
/*    */ import inetsoft.report.ReportElement;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Image;
/*    */ import java.awt.Point;
/*    */ import java.awt.Rectangle;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TabPaintable
/*    */   extends BasePaintable
/*    */ {
/*    */   float x;
/*    */   float y;
/*    */   float w;
/*    */   float h;
/*    */   int fill;
/*    */   Image tabMarker;
/*    */   
/*    */   public TabPaintable(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, ReportElement paramReportElement) {
/* 28 */     super(paramReportElement);
/* 29 */     this.w = paramFloat3; this.h = paramFloat4;
/* 30 */     this.x = paramFloat1; this.y = paramFloat2;
/* 31 */     this.fill = paramInt;
/*    */   }
/*    */ 
/*    */   
/* 35 */   public void setTabMarker(Image paramImage) { this.tabMarker = paramImage; }
/*    */ 
/*    */   
/*    */   public void paint(Graphics paramGraphics) {
/* 39 */     paramGraphics.setColor(this.elem.getForeground());
/*    */     
/* 41 */     if (this.fill != 0) {
/* 42 */       float f = this.y + Common.getHeight(this.elem.getFont(), null) - Common.getLineWidth(this.fill) - 1.0F;
/*    */       
/* 44 */       Common.drawHLine(paramGraphics, f, this.x, this.x + this.w, this.fill, 0, 0);
/*    */     
/*    */     }
/* 47 */     else if (this.tabMarker != null) {
/* 48 */       int i = this.tabMarker.getWidth(null);
/* 49 */       int j = this.tabMarker.getHeight(null);
/* 50 */       paramGraphics.drawImage(this.tabMarker, (int)(this.x + (this.w - i) / 2.0F), (int)(this.y + (this.h - j) / 2.0F), null);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 61 */   public Rectangle getBounds() { return new Rectangle((int)this.x, (int)this.y, (int)this.w, (int)this.h); }
/*    */ 
/*    */ 
/*    */   
/* 65 */   public void setLocation(Point paramPoint) { this.x = paramPoint.x; this.y = paramPoint.y; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 72 */   public int getFill() { return this.fill; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
/* 78 */     paramObjectInputStream.defaultReadObject();
/* 79 */     this.elem = new DefaultContext();
/* 80 */     ((DefaultContext)this.elem).read(paramObjectInputStream);
/*    */   }
/*    */   
/*    */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/* 84 */     paramObjectOutputStream.defaultWriteObject();
/* 85 */     DefaultContext.write(paramObjectOutputStream, this.elem);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TabPaintable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */