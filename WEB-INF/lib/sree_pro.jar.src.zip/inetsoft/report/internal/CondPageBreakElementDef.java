/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.CondPageBreakElement;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CondPageBreakElementDef
/*     */   extends BaseElement
/*     */   implements CondPageBreakElement
/*     */ {
/*     */   private int pixels;
/*     */   private double inch;
/*     */   Font defFont;
/*     */   
/*     */   public CondPageBreakElementDef(StyleSheet paramStyleSheet, int paramInt) {
/*  32 */     super(paramStyleSheet, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     this.pixels = 0;
/* 140 */     this.inch = 0.0D;
/* 141 */     this.defFont = new Font("Serif", 0, 10); this.pixels = paramInt; } public CondPageBreakElementDef(StyleSheet paramStyleSheet, double paramDouble) { super(paramStyleSheet, true); this.pixels = 0; this.inch = 0.0D; this.defFont = new Font("Serif", 0, 10);
/*     */     this.inch = paramDouble; }
/*     */ 
/*     */   
/*     */   public boolean isFlowControl() { return true; }
/*     */   
/*     */   public boolean print(StylePage paramStylePage) {
/*     */     if (!isVisible())
/*     */       return false; 
/*     */     super.print(paramStylePage);
/*     */     if (this.report.designtime)
/*     */       paramStylePage.addPaintable(new BasePaintable(this, this) {
/*     */             float x;
/*     */             float y;
/*     */             float w;
/*     */             float h;
/*     */             Rectangle box;
/*     */             private final CondPageBreakElementDef this$0;
/*     */             
/*     */             public void paint(Graphics param1Graphics) {
/*     */               String str = "Conditional Page Break";
/*     */               param1Graphics.setColor(Color.gray);
/*     */               float f1 = Common.stringWidth(str, this.this$0.defFont);
/*     */               float f2 = this.x + (this.w - f1) / 2.0F;
/*     */               float f3 = f2 + f1;
/*     */               Common.drawHLine(param1Graphics, this.y + this.h / 2.0F, this.x, f2, 4145, 0, 0);
/*     */               param1Graphics.setFont(this.this$0.defFont);
/*     */               Common.drawString(param1Graphics, str, f2, this.y + Common.getAscent(this.this$0.defFont));
/*     */               Common.drawHLine(param1Graphics, this.y + this.h / 2.0F, f3, this.x + this.w, 4145, 0, 0);
/*     */             }
/*     */             
/*     */             public Rectangle getBounds() { return this.box; }
/*     */             
/*     */             public void setLocation(Point param1Point) { this.x = param1Point.x;
/*     */               this.y = param1Point.y; }
/*     */           }); 
/*     */     return false;
/*     */   }
/*     */   
/*     */   public int getMinimumHeight() { return (this.pixels > 0) ? this.pixels : (int)(this.inch * this.report.resolution); }
/*     */   
/*     */   public double getCondHeight() { return (this.pixels > 0) ? (this.pixels / this.report.resolution) : this.inch; }
/*     */   
/*     */   public void setCondHeight(double paramDouble) {
/*     */     this.inch = paramDouble;
/*     */     this.pixels = 0;
/*     */   }
/*     */   
/*     */   public String toString() { return getID() + " [" + Catalog.getString("Conditional PageBreak") + ": " + this.pixels + ":" + this.inch + "]"; }
/*     */   
/*     */   public String getType() { return "CondPageBreak"; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\CondPageBreakElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */