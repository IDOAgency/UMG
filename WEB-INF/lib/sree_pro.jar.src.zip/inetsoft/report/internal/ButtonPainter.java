package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.ReportElement;
import inetsoft.report.Size;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;

public class ButtonPainter extends FieldPainter {
  private String text;
  
  public ButtonPainter(ReportElement paramReportElement) { super(paramReportElement); }
  
  public Object getValue() { return getText(); }
  
  public String getText() { return this.text; }
  
  public void setText(String paramString) { this.text = paramString; }
  
  public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramGraphics.setColor(Color.lightGray);
    paramGraphics.fillRect(paramInt1, paramInt2, paramInt3 - 1, paramInt4 - 1);
    paramGraphics.setColor(Color.gray);
    paramGraphics.draw3DRect(paramInt1, paramInt2, paramInt3 - 1, paramInt4 - 1, true);
    paramGraphics.setColor(this.elem.getForeground());
    paramGraphics.setFont(this.elem.getFont());
    FontMetrics fontMetrics = Common.getFontMetrics(paramGraphics.getFont());
    float f1 = Common.getHeight(paramGraphics.getFont(), fontMetrics);
    float f2 = Common.stringWidth(this.text, paramGraphics.getFont(), fontMetrics);
    Common.drawString(paramGraphics, this.text, paramInt1 + (paramInt3 - f2) / 2.0F, paramInt2 + (paramInt4 - f1) / 2.0F + fontMetrics.getAscent());
  }
  
  public Dimension getPreferredSize() {
    Size size = StyleCore.getTextSize(this.text, this.elem.getFont(), 0);
    return new Dimension((int)(size.width + 10.0F), (int)(size.height + 4.0F));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ButtonPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */