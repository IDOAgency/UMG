package inetsoft.report.internal;

import inetsoft.report.Painter;
import inetsoft.report.StyleSheet;

public class RadioButtonElementDef extends CheckBoxElementDef {
  RadioButtonPainter rpainter;
  
  public RadioButtonElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4, double paramDouble1, double paramDouble2) {
    super(paramStyleSheet, paramString1, paramString2, paramString3, paramBoolean, paramDouble1, paramDouble2);
    this.rpainter.setGroup(paramString4);
  }
  
  public RadioButtonElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4) { this(paramStyleSheet, paramString1, paramString2, paramString3, paramBoolean, paramString4, 0.0D, 0.0D); }
  
  protected FieldPainter createPainter() { return this.painter = this.rpainter = new RadioButtonPainter(this); }
  
  public String getGroup() { return this.rpainter.getGroup(); }
  
  public void setGroup(String paramString) { this.rpainter.setGroup(paramString); }
  
  public void setPainter(Painter paramPainter) {
    super.setPainter(paramPainter);
    if (paramPainter instanceof RadioButtonPainter)
      this.painter = (RadioButtonPainter)paramPainter; 
  }
  
  public String getType() { return "RadioButton"; }
  
  public Object clone() throws CloneNotSupportedException {
    RadioButtonElementDef radioButtonElementDef = (RadioButtonElementDef)super.clone();
    radioButtonElementDef.setPainter(new RadioButtonPainter(radioButtonElementDef));
    radioButtonElementDef.setText(this.painter.getText());
    radioButtonElementDef.setSelected(this.painter.isSelected());
    radioButtonElementDef.setGroup(this.rpainter.getGroup());
    return radioButtonElementDef;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\RadioButtonElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */