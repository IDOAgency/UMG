/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.Painter;
/*    */ import inetsoft.report.StyleSheet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RadioButtonElementDef
/*    */   extends CheckBoxElementDef
/*    */ {
/*    */   RadioButtonPainter rpainter;
/*    */   
/*    */   public RadioButtonElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4, double paramDouble1, double paramDouble2) {
/* 34 */     super(paramStyleSheet, paramString1, paramString2, paramString3, paramBoolean, paramDouble1, paramDouble2);
/* 35 */     this.rpainter.setGroup(paramString4);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   public RadioButtonElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4) { this(paramStyleSheet, paramString1, paramString2, paramString3, paramBoolean, paramString4, 0.0D, 0.0D); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   protected FieldPainter createPainter() { return this.painter = this.rpainter = new RadioButtonPainter(this); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   public String getGroup() { return this.rpainter.getGroup(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 65 */   public void setGroup(String paramString) { this.rpainter.setGroup(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPainter(Painter paramPainter) {
/* 72 */     super.setPainter(paramPainter);
/* 73 */     if (paramPainter instanceof RadioButtonPainter) {
/* 74 */       this.painter = (RadioButtonPainter)paramPainter;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/* 79 */   public String getType() { return "RadioButton"; }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 83 */     RadioButtonElementDef radioButtonElementDef = (RadioButtonElementDef)super.clone();
/* 84 */     radioButtonElementDef.setPainter(new RadioButtonPainter(radioButtonElementDef));
/* 85 */     radioButtonElementDef.setText(this.painter.getText());
/* 86 */     radioButtonElementDef.setSelected(this.painter.isSelected());
/* 87 */     radioButtonElementDef.setGroup(this.rpainter.getGroup());
/* 88 */     return radioButtonElementDef;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\RadioButtonElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */