package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.ReportElement;
import inetsoft.report.Size;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;

public class CheckBoxPainter extends FieldPainter {
  private Image true_icon;
  
  private Image false_icon;
  
  private String text;
  
  private boolean selected;
  
  static final String true_cb = "/inetsoft/report/images/checkbox_true.gif";
  
  static final String false_cb = "/inetsoft/report/images/checkbox_false.gif";
  
  public CheckBoxPainter(ReportElement paramReportElement) {
    super(paramReportElement);
    this.true_icon = null;
    this.false_icon = null;
    this.selected = false;
  }
  
  public Object getValue() { return isSelected() ? getName() : null; }
  
  public String getText() { return this.text; }
  
  public void setText(String paramString) { this.text = paramString; }
  
  public boolean isSelected() { return this.selected; }
  
  public void setSelected(boolean paramBoolean) { this.selected = paramBoolean; }
  
  public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramGraphics.setColor(this.elem.getForeground());
    paramGraphics.setFont(this.elem.getFont());
    FontMetrics fontMetrics = Common.getFontMetrics(paramGraphics.getFont());
    float f = Common.getHeight(paramGraphics.getFont(), fontMetrics);
    paramGraphics.drawImage(getIcon(), paramInt1 + 1, paramInt2 + (paramInt4 - 14) / 2, null);
    Common.drawString(paramGraphics, this.text, (paramInt1 + 20), paramInt2 + (paramInt4 - f) / 2.0F + fontMetrics.getAscent());
  }
  
  public Dimension getPreferredSize() {
    Size size = StyleCore.getTextSize(this.text, this.elem.getFont(), 0);
    return new Dimension((int)(size.width + 20.0F), Math.max((int)(size.height + 2.0F), 14));
  }
  
  protected Image getIcon() { return getIcon("/inetsoft/report/images/checkbox_true.gif", "/inetsoft/report/images/checkbox_false.gif"); }
  
  protected Image getIcon(String paramString1, String paramString2) {
    if (this.selected && this.true_icon == null) {
      this.true_icon = Common.getImage(this, paramString1);
      waitImage(this.true_icon);
    } 
    if (!this.selected && this.false_icon == null) {
      this.false_icon = Common.getImage(this, paramString2);
      waitImage(this.false_icon);
    } 
    return this.selected ? this.true_icon : this.false_icon;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\CheckBoxPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */