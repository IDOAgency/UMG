/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.ReportElement;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageButtonPainter
/*     */   extends FieldPainter
/*     */ {
/*     */   private Image icon;
/*     */   private String resource;
/*     */   
/*     */   public ImageButtonPainter(ReportElement paramReportElement) {
/*  30 */     super(paramReportElement);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     this.icon = null;
/*     */   }
/*     */   
/*     */   public Object getValue() { return getResource(); }
/*     */   
/*     */   public String getResource() { return this.resource; }
/*     */   
/*     */   public void setResource(String paramString) {
/*     */     this.resource = paramString;
/*     */     this.icon = null;
/*     */   }
/*     */   
/*     */   public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*     */     Image image = getIcon();
/*     */     if (image != null) {
/*     */       paramInt1 += (paramInt3 - image.getWidth(null)) / 2;
/*     */       paramInt2 += (paramInt4 - image.getHeight(null)) / 2;
/*     */       paramGraphics.drawImage(image, paramInt1, paramInt2, null);
/*     */     } else {
/*     */       paramGraphics.drawString("Submit", paramInt1, (int)(paramInt2 + paramInt3 * 0.7D));
/*     */     } 
/*     */   }
/*     */   
/*     */   public Dimension getPreferredSize() {
/*     */     Image image = getIcon();
/*     */     return (image == null) ? new Dimension(40, 20) : new Dimension(image.getWidth(null), image.getHeight(null));
/*     */   }
/*     */   
/*     */   public Image getIcon() {
/*     */     if (this.icon == null)
/*     */       if (this.resource != null && this.resource.length() > 0) {
/*     */         this.icon = Common.getImage(this, this.resource);
/*     */         waitImage(this.icon);
/*     */       } else {
/*     */         this.icon = Common.createImage(40, 18);
/*     */         Graphics graphics = this.icon.getGraphics();
/*     */         graphics.setColor(Color.lightGray);
/*     */         graphics.fillRect(0, 0, 40, 18);
/*     */         graphics.draw3DRect(0, 0, 39, 17, true);
/*     */       }  
/*     */     return this.icon;
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
/*     */     paramObjectInputStream.defaultReadObject();
/*     */     byte[] arrayOfByte = (byte[])paramObjectInputStream.readObject();
/*     */     if (arrayOfByte != null) {
/*     */       int i = paramObjectInputStream.readInt();
/*     */       int j = paramObjectInputStream.readInt();
/*     */       this.icon = Encoder.decodeImage(i, j, arrayOfByte);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/*     */     paramObjectOutputStream.defaultWriteObject();
/*     */     if (this.resource != null)
/*     */       getIcon(); 
/*     */     byte[] arrayOfByte = (this.icon != null) ? Encoder.encodeImage(this.icon) : null;
/*     */     paramObjectOutputStream.writeObject(arrayOfByte);
/*     */     if (arrayOfByte != null) {
/*     */       paramObjectOutputStream.writeInt(this.icon.getWidth(null));
/*     */       paramObjectOutputStream.writeInt(this.icon.getHeight(null));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ImageButtonPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */