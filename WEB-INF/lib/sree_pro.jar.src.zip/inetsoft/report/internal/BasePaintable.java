/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Paintable;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.StyleFont;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BasePaintable
/*     */   implements Paintable
/*     */ {
/*     */   protected ReportElement elem;
/*     */   private Rectangle frame;
/*     */   private Object userObj;
/*     */   
/*     */   public BasePaintable(ReportElement paramReportElement) {
/*  33 */     this.elem = paramReportElement;
/*     */     
/*  35 */     if (paramReportElement != null) {
/*  36 */       this.userObj = ((BaseElement)paramReportElement).getUserObject();
/*  37 */       this.frame = ((BaseElement)paramReportElement).getFrame();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public ReportElement getElement() { return this.elem; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public void setUserObject(Object paramObject) { this.userObj = paramObject; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public Object getUserObject() { return this.userObj; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public void setFrame(Rectangle paramRectangle) { this.frame = paramRectangle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public Rectangle getFrame() { return this.frame; }
/*     */ 
/*     */   
/*     */   public void finalize() {
/*  78 */     this.elem = null;
/*  79 */     this.userObj = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Color readColor(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/*  85 */     Integer integer = (Integer)paramObjectInputStream.readObject();
/*  86 */     return (integer == null) ? null : new Color(integer.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   static void writeColor(ObjectOutputStream paramObjectOutputStream, Color paramColor) throws IOException { paramObjectOutputStream.writeObject((paramColor == null) ? null : new Integer(paramColor.getRGB())); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Font readFont(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/*  98 */     String str = (String)paramObjectInputStream.readObject();
/*  99 */     return (str == null) ? null : StyleFont.decode(str);
/*     */   }
/*     */ 
/*     */   
/* 103 */   static void writeFont(ObjectOutputStream paramObjectOutputStream, Font paramFont) throws IOException { paramObjectOutputStream.writeObject((paramFont == null) ? null : StyleFont.toString(paramFont)); }
/*     */   
/*     */   public abstract void setLocation(Point paramPoint);
/*     */   
/*     */   public abstract Rectangle getBounds();
/*     */   
/*     */   public abstract void paint(Graphics paramGraphics);
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\BasePaintable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */