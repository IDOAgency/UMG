package inetsoft.report.internal;

import inetsoft.report.Paintable;
import inetsoft.report.ReportElement;
import inetsoft.report.StyleFont;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public abstract class BasePaintable implements Paintable {
  protected ReportElement elem;
  
  private Rectangle frame;
  
  private Object userObj;
  
  public BasePaintable(ReportElement paramReportElement) {
    this.elem = paramReportElement;
    if (paramReportElement != null) {
      this.userObj = ((BaseElement)paramReportElement).getUserObject();
      this.frame = ((BaseElement)paramReportElement).getFrame();
    } 
  }
  
  public ReportElement getElement() { return this.elem; }
  
  public void setUserObject(Object paramObject) { this.userObj = paramObject; }
  
  public Object getUserObject() { return this.userObj; }
  
  public void setFrame(Rectangle paramRectangle) { this.frame = paramRectangle; }
  
  public Rectangle getFrame() { return this.frame; }
  
  public void finalize() {
    this.elem = null;
    this.userObj = null;
  }
  
  static Color readColor(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
    Integer integer = (Integer)paramObjectInputStream.readObject();
    return (integer == null) ? null : new Color(integer.intValue());
  }
  
  static void writeColor(ObjectOutputStream paramObjectOutputStream, Color paramColor) throws IOException { paramObjectOutputStream.writeObject((paramColor == null) ? null : new Integer(paramColor.getRGB())); }
  
  static Font readFont(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
    String str = (String)paramObjectInputStream.readObject();
    return (str == null) ? null : StyleFont.decode(str);
  }
  
  static void writeFont(ObjectOutputStream paramObjectOutputStream, Font paramFont) throws IOException { paramObjectOutputStream.writeObject((paramFont == null) ? null : StyleFont.toString(paramFont)); }
  
  public abstract void setLocation(Point paramPoint);
  
  public abstract Rectangle getBounds();
  
  public abstract void paint(Graphics paramGraphics);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\BasePaintable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */