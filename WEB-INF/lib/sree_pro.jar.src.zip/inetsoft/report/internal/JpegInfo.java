package inetsoft.report.internal;

import java.awt.AWTException;
import java.awt.Image;

class JpegInfo {
  String Comment;
  
  public Image imageobj;
  
  public int imageHeight;
  
  public int imageWidth;
  
  public int[] BlockWidth;
  
  public int[] BlockHeight;
  
  public int Precision;
  
  public int NumberOfComponents;
  
  public Object[] Components;
  
  public int[] CompID;
  
  public int[] HsampFactor;
  
  public int[] VsampFactor;
  
  public int[] QtableNumber;
  
  public int[] DCtableNumber;
  
  public int[] ACtableNumber;
  
  public boolean[] lastColumnIsDummy;
  
  public boolean[] lastRowIsDummy;
  
  public int Ss;
  
  public int Se;
  
  public int Ah;
  
  public int Al;
  
  public int[] compWidth;
  
  public int[] compHeight;
  
  public int MaxHsampFactor;
  
  public int MaxVsampFactor;
  
  public JpegInfo(Image paramImage) {
    this.Precision = 8;
    this.NumberOfComponents = 3;
    this.CompID = new int[] { 1, 2, 3 };
    this.HsampFactor = new int[] { 1, 1, 1 };
    this.VsampFactor = new int[] { 1, 1, 1 };
    this.QtableNumber = new int[] { 0, 1, 1 };
    this.DCtableNumber = new int[] { 0, 1, 1 };
    this.ACtableNumber = new int[] { 0, 1, 1 };
    this.lastColumnIsDummy = new boolean[] { false, false, false };
    this.lastRowIsDummy = new boolean[] { false, false, false };
    this.Ss = 0;
    this.Se = 63;
    this.Ah = 0;
    this.Al = 0;
    this.Components = new Object[this.NumberOfComponents];
    this.compWidth = new int[this.NumberOfComponents];
    this.compHeight = new int[this.NumberOfComponents];
    this.BlockWidth = new int[this.NumberOfComponents];
    this.BlockHeight = new int[this.NumberOfComponents];
    this.imageobj = paramImage;
    this.imageWidth = paramImage.getWidth(null);
    this.imageHeight = paramImage.getHeight(null);
    this.Comment = "JPEG Encoder Copyright 1998, James R. Weeks and BioElectroMech.  ";
    getYCCArray();
  }
  
  public void setComment(String paramString) { this.Comment.concat(paramString); }
  
  public String getComment() { return this.Comment; }
  
  private void getYCCArray() {
    int[] arrayOfInt = new int[this.imageWidth * this.imageHeight];
    PixelGrabber pixelGrabber = new PixelGrabber(this.imageobj.getSource(), 0, 0, this.imageWidth, this.imageHeight, arrayOfInt, 0, this.imageWidth);
    this.MaxHsampFactor = 1;
    this.MaxVsampFactor = 1;
    byte b1;
    for (b1 = 0; b1 < this.NumberOfComponents; b1++) {
      this.MaxHsampFactor = Math.max(this.MaxHsampFactor, this.HsampFactor[b1]);
      this.MaxVsampFactor = Math.max(this.MaxVsampFactor, this.VsampFactor[b1]);
    } 
    for (b1 = 0; b1 < this.NumberOfComponents; b1++) {
      this.compWidth[b1] = ((this.imageWidth % 8 != 0) ? ((int)Math.ceil(this.imageWidth / 8.0D) * 8) : this.imageWidth) / this.MaxHsampFactor * this.HsampFactor[b1];
      if (this.compWidth[b1] != this.imageWidth / this.MaxHsampFactor * this.HsampFactor[b1])
        this.lastColumnIsDummy[b1] = true; 
      this.BlockWidth[b1] = (int)Math.ceil(this.compWidth[b1] / 8.0D);
      this.compHeight[b1] = ((this.imageHeight % 8 != 0) ? ((int)Math.ceil(this.imageHeight / 8.0D) * 8) : this.imageHeight) / this.MaxVsampFactor * this.VsampFactor[b1];
      if (this.compHeight[b1] != this.imageHeight / this.MaxVsampFactor * this.VsampFactor[b1])
        this.lastRowIsDummy[b1] = true; 
      this.BlockHeight[b1] = (int)Math.ceil(this.compHeight[b1] / 8.0D);
    } 
    try {
      if (pixelGrabber.grabPixels() != true)
        try {
          throw new AWTException("Grabber returned false: " + pixelGrabber.status());
        } catch (Exception exception) {} 
    } catch (InterruptedException interruptedException) {}
    float[][] arrayOfFloat1 = new float[this.compHeight[0]][this.compWidth[0]];
    float[][] arrayOfFloat2 = new float[this.compHeight[0]][this.compWidth[0]];
    float[][] arrayOfFloat3 = new float[this.compHeight[0]][this.compWidth[0]];
    float[][] arrayOfFloat4 = new float[this.compHeight[1]][this.compWidth[1]];
    float[][] arrayOfFloat5 = new float[this.compHeight[2]][this.compWidth[2]];
    byte b2 = 0;
    for (b1 = 0; b1 < this.imageHeight; b1++) {
      for (byte b = 0; b < this.imageWidth; b++) {
        int i = arrayOfInt[b2] >> 16 & 0xFF;
        int j = arrayOfInt[b2] >> 8 & 0xFF;
        int k = arrayOfInt[b2] & 0xFF;
        arrayOfFloat1[b1][b] = (float)(0.299D * i + 0.587D * j + 0.114D * k);
        arrayOfFloat3[b1][b] = 128.0F + (float)(-0.16874D * i - 0.33126D * j + 0.5D * k);
        arrayOfFloat2[b1][b] = 128.0F + (float)(0.5D * i - 0.41869D * j - 0.08131D * k);
        b2++;
      } 
    } 
    this.Components[0] = arrayOfFloat1;
    this.Components[1] = arrayOfFloat3;
    this.Components[2] = arrayOfFloat2;
  }
  
  float[][] DownSample(float[][] paramArrayOfFloat, int paramInt) {
    byte b1 = 0;
    byte b2 = 0;
    float[][] arrayOfFloat = new float[this.compHeight[paramInt]][this.compWidth[paramInt]];
    for (byte b3 = 0; b3 < this.compHeight[paramInt]; b3++) {
      byte b5 = 1;
      for (byte b4 = 0; b4 < this.compWidth[paramInt]; b4++) {
        arrayOfFloat[b3][b4] = (paramArrayOfFloat[b1][b2++] + paramArrayOfFloat[b1++][b2--] + paramArrayOfFloat[b1][b2++] + paramArrayOfFloat[b1--][b2++] + b5) / 4.0F;
        b5 ^= 0x3;
      } 
      b1 += 2;
      b2 = 0;
    } 
    return arrayOfFloat;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\JpegInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */