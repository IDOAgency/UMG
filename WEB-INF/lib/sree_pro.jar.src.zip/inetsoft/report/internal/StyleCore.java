/*      */ package inetsoft.report.internal;
/*      */ import inetsoft.report.Common;
/*      */ import inetsoft.report.CompositeLens;
/*      */ import inetsoft.report.FixedContainer;
/*      */ import inetsoft.report.Margin;
/*      */ import inetsoft.report.PageArea;
/*      */ import inetsoft.report.Paintable;
/*      */ import inetsoft.report.Position;
/*      */ import inetsoft.report.Presenter;
/*      */ import inetsoft.report.ReportElement;
/*      */ import inetsoft.report.ReportEnv;
/*      */ import inetsoft.report.Size;
/*      */ import inetsoft.report.StylePage;
/*      */ import inetsoft.report.StyleSheet;
/*      */ import inetsoft.report.TableLens;
/*      */ import inetsoft.report.TextElement;
/*      */ import inetsoft.report.TextLens;
/*      */ import inetsoft.report.lens.DefaultTableLens;
/*      */ import inetsoft.report.style.TableStyle;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.text.Format;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.Vector;
/*      */ 
/*      */ public abstract class StyleCore implements StyleConstants {
/*      */   public StyleCore() {
/*   36 */     if (limited) {
/*   37 */       String str = ReportEnv.getProperty("license.key");
/*      */       
/*   39 */       if (str != null) {
/*   40 */         if (!KeyUtil.verify2(str, 'R')) {
/*   41 */           System.err.println("Invalid license key: " + str);
/*   42 */           System.err.println("Software running in evaluation mode!");
/*      */         } else {
/*      */           
/*   45 */           limited = false;
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*   50 */     if (limited) {
/*   51 */       String[] arrayOfString = Util.getCallers();
/*   52 */       this.internal = false;
/*      */       
/*   54 */       for (byte b = 0; b < arrayOfString.length; b++) {
/*   55 */         if (arrayOfString[b].startsWith("inetsoft.report.design.") || arrayOfString[b].startsWith("inetsoft.report.jbuilder") || arrayOfString[b].startsWith("inetsoft.report.vcafe")) {
/*      */ 
/*      */           
/*   58 */           this.internal = true;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*   63 */       this.max_report = 1;
/*   64 */       this.max_row = 50;
/*      */       try {
/*   66 */         Class.forName("inetsoft.sree.Replet");
/*   67 */         this.max_report = 10;
/*   68 */         this.max_row = 200;
/*   69 */       } catch (Throwable throwable) {}
/*      */ 
/*      */       
/*   72 */       if (!this.internal && ++counter > this.max_report) {
/*   73 */         throw new Error("Style Report/Lite is limited to " + this.max_report + " report(s) per application!");
/*      */       
/*      */       }
/*      */     }
/*   77 */     else if (Util.isServer()) {
/*   78 */       String str = ReportEnv.getProperty("license.key");
/*   79 */       if (str == null || !KeyUtil.verify2(str, 'R')) {
/*   80 */         throw new RuntimeException("Runtime license require for server-side deployment. Please add the runtime key to the properties as license.key!");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   92 */   public void setDesignTime(boolean paramBoolean) { this.designtime = paramBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   99 */   public Hashtable getElementHeaders() { return this.elemHeader; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  106 */   public Hashtable getElementFooters() { return this.elemFooter; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   public void setOverrideHeader(Vector paramVector) { this.overrideHeader = paramVector; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  120 */   public void setOverrideFooter(Vector paramVector) { this.overrideFooter = paramVector; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBackgroundImageLocation(ImageLocation paramImageLocation) {
/*  127 */     this.bgimage = paramImageLocation;
/*      */     
/*  129 */     if (paramImageLocation != null) {
/*      */       try {
/*  131 */         this.bg = paramImageLocation.getImage();
/*      */       } catch (Exception exception) {
/*  133 */         System.err.println("Failed to load image: " + paramImageLocation.getPath());
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  142 */   public ImageLocation getBackgroundImageLocation() { return this.bgimage; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNextID(String paramString) {
/*  150 */     Integer integer = (Integer)this.idmap.get(paramString);
/*  151 */     if (integer == null) {
/*  152 */       integer = new Integer(1);
/*      */     }
/*      */     
/*  155 */     this.idmap.put(paramString, new Integer(integer.intValue() + 1));
/*  156 */     return paramString + integer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  163 */   public void setHindent(int paramInt) { this.hindent = paramInt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  170 */   public Hashtable getElementAreas() { return this.areamap; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReportElement getCompositeElement(String paramString, Object paramObject, Context paramContext) {
/*  178 */     PainterElementDef painterElementDef = null;
/*      */     
/*  180 */     if (paramObject == CompositeLens.PAGE_BREAK) {
/*  181 */       painterElementDef = new PageBreakElementDef((StyleSheet)this);
/*      */     }
/*  183 */     else if (paramObject == CompositeLens.AREA_BREAK) {
/*  184 */       AreaBreakElementDef areaBreakElementDef = new AreaBreakElementDef((StyleSheet)this);
/*      */     }
/*  186 */     else if (paramObject == CompositeLens.NEWLINE) {
/*  187 */       NewlineElementDef newlineElementDef = new NewlineElementDef((StyleSheet)this, 1, false);
/*      */     }
/*  189 */     else if (paramObject == CompositeLens.BREAK) {
/*  190 */       NewlineElementDef newlineElementDef = new NewlineElementDef((StyleSheet)this, 1, true);
/*      */     
/*      */     }
/*  193 */     else if (paramObject instanceof CompositeLens.Tab) {
/*  194 */       int i = ((CompositeLens.Tab)paramObject).getFillStyle();
/*  195 */       TabElementDef tabElementDef = new TabElementDef((StyleSheet)this, i);
/*      */     }
/*  197 */     else if (paramObject instanceof CompositeLens.Separator) {
/*  198 */       int i = ((CompositeLens.Separator)paramObject).getStyle();
/*  199 */       SeparatorElementDef separatorElementDef = new SeparatorElementDef((StyleSheet)this, i);
/*      */     }
/*  201 */     else if (paramObject instanceof CompositeLens.Space) {
/*  202 */       int i = ((CompositeLens.Space)paramObject).getSpace();
/*  203 */       SpaceElementDef spaceElementDef = new SpaceElementDef((StyleSheet)this, i);
/*      */     }
/*  205 */     else if (paramObject instanceof TableLens) {
/*  206 */       TableElementDef tableElementDef = new TableElementDef((StyleSheet)this, (TableLens)paramObject);
/*      */     }
/*  208 */     else if (paramObject instanceof TextLens) {
/*  209 */       TextElementDef textElementDef = new TextElementDef((StyleSheet)this, (TextLens)paramObject);
/*      */     }
/*  211 */     else if (paramObject instanceof String) {
/*  212 */       TextElementDef textElementDef = new TextElementDef((StyleSheet)this, new DefaultTextLens((String)paramObject));
/*      */     
/*      */     }
/*  215 */     else if (paramObject instanceof FormLens) {
/*  216 */       FormElementDef formElementDef = new FormElementDef((StyleSheet)this, (FormLens)paramObject);
/*      */     }
/*  218 */     else if (paramObject instanceof ChartLens) {
/*  219 */       ChartElementDef chartElementDef = new ChartElementDef((StyleSheet)this, (ChartLens)paramObject);
/*      */     }
/*  221 */     else if (paramObject instanceof Image) {
/*  222 */       PainterElementDef painterElementDef1 = new PainterElementDef((StyleSheet)this, new ImagePainter((Image)paramObject));
/*      */     
/*      */     }
/*  225 */     else if (paramObject instanceof Painter) {
/*  226 */       painterElementDef = new PainterElementDef((StyleSheet)this, (Painter)paramObject);
/*      */     } 
/*      */ 
/*      */     
/*  230 */     if (painterElementDef != null) {
/*  231 */       painterElementDef.setID(paramString + "." + painterElementDef.getID());
/*  232 */       painterElementDef.setContext(paramContext);
/*      */     } 
/*      */     
/*  235 */     return painterElementDef;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getNextHeadingNumber(int paramInt) {
/*  253 */     for (int i = paramInt; i < this.headingCnt.length; i++) {
/*  254 */       this.headingCnt[i] = 0;
/*      */     }
/*      */     
/*  257 */     this.headingCnt[paramInt - 1] = this.headingCnt[paramInt - 1] + 1;
/*      */     
/*  259 */     StringBuffer stringBuffer = new StringBuffer();
/*  260 */     for (byte b = 0; b < paramInt; b++) {
/*  261 */       stringBuffer.append((b ? "." : "") + this.headingCnt[b]);
/*      */     }
/*      */     
/*  264 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void advance(float paramFloat1, float paramFloat2) {
/*  277 */     this.printHead.y += paramFloat2;
/*      */ 
/*      */     
/*  280 */     if (paramFloat1 == 0.0F && paramFloat2 != 0.0F) {
/*  281 */       this.printHead.x = 0.0F;
/*      */     } else {
/*      */       
/*  284 */       this.printHead.x += paramFloat1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Size getTextSize(String paramString, Font paramFont, int paramInt) {
/*  295 */     FontMetrics fontMetrics = Common.getFontMetrics(paramFont);
/*  296 */     int i = 0, j = 0;
/*  297 */     Size size = new Size(0.0F, 0.0F);
/*      */     
/*  299 */     while (!i) {
/*  300 */       i = paramString.indexOf("\n", j);
/*      */       
/*  302 */       String str = (i >= 0) ? paramString.substring(j, i) : paramString.substring(j);
/*      */ 
/*      */       
/*  305 */       float f = Common.stringWidth(str, paramFont, fontMetrics);
/*      */       
/*  307 */       size.width = Math.max(size.width, f);
/*  308 */       size.height += Common.getHeight(paramFont, fontMetrics) + ((i >= 0) ? paramInt : 0.0F);
/*      */       
/*  310 */       j = i + 1;
/*      */     } 
/*      */     
/*  313 */     return size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static float[] getPrefMinWidth(String paramString, Font paramFont, boolean paramBoolean, float paramFloat) {
/*  327 */     FontMetrics fontMetrics = Common.getFontMetrics(paramFont);
/*  328 */     int i = 0, j = 0;
/*  329 */     float[] arrayOfFloat = new float[2];
/*      */     
/*  331 */     while (!i) {
/*  332 */       i = paramString.indexOf("\n", j);
/*      */       
/*  334 */       String str = (i >= 0) ? paramString.substring(j, i) : paramString.substring(j);
/*      */ 
/*      */       
/*  337 */       float f = Common.stringWidth(str, paramFont, fontMetrics);
/*      */       
/*  339 */       arrayOfFloat[0] = Math.max(arrayOfFloat[0], f);
/*      */ 
/*      */       
/*  342 */       if (paramBoolean && str.length() > 0) {
/*      */ 
/*      */ 
/*      */         
/*  346 */         int k = 0;
/*      */         
/*  348 */         for (int m = 0, n = str.indexOf(' '); !m; 
/*  349 */           m = n, n = (n > 0) ? str.indexOf(' ', n + 1) : -1) {
/*  350 */           int i1 = (n > 0) ? (n - m) : (str.length() - m);
/*  351 */           if (i1 > k) {
/*  352 */             k = i1;
/*      */           }
/*      */         } 
/*      */         
/*  356 */         arrayOfFloat[1] = Math.max(arrayOfFloat[1], f * k / str.length());
/*      */ 
/*      */         
/*  359 */         arrayOfFloat[1] = Math.min(arrayOfFloat[1], paramFloat);
/*      */         
/*  361 */         arrayOfFloat[0] = Math.max(arrayOfFloat[0], arrayOfFloat[1]);
/*      */       }
/*  363 */       else if (arrayOfFloat[1] > arrayOfFloat[0] || arrayOfFloat[1] <= 0.0F) {
/*  364 */         arrayOfFloat[1] = arrayOfFloat[0];
/*      */       } 
/*      */       
/*  367 */       j = i + 1;
/*      */     } 
/*      */     
/*  370 */     return arrayOfFloat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String format(String paramString, int paramInt1, int paramInt2, Date paramDate) {
/*  382 */     paramString = Util.replaceAll(paramString, "'", "''");
/*      */ 
/*      */     
/*  385 */     StringBuffer stringBuffer = new StringBuffer();
/*  386 */     for (int i = 0; i < paramString.length(); i++) {
/*  387 */       if (paramString.charAt(i) == '{')
/*  388 */       { int k = paramString.indexOf('}', i + 1);
/*  389 */         if (k > i + 1)
/*  390 */         { String str1 = paramString.substring(i + 1, k);
/*  391 */           String str2 = str1.toLowerCase();
/*  392 */           if (str2.startsWith("p,") || str2.startsWith("n,") || str2.startsWith("d,") || str2.startsWith("t,") || str2.equals("p") || str2.equals("n") || str2.equals("d") || str2.equals("t"))
/*      */           
/*      */           { 
/*      */             
/*  396 */             stringBuffer.append("{" + str1 + "}");
/*  397 */             i = k; }
/*      */           
/*      */           else
/*      */           
/*  401 */           { stringBuffer.append('\\');
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  416 */             stringBuffer.append(paramString.charAt(i)); }  } else { stringBuffer.append('\\'); stringBuffer.append(paramString.charAt(i)); }  } else { if (paramString.charAt(i) == '}') { stringBuffer.append('\\'); } else if (paramString.charAt(i) == '\\') { stringBuffer.append('\\'); i++; }  stringBuffer.append(paramString.charAt(i)); }
/*      */     
/*      */     } 
/*  419 */     boolean bool = false;
/*  420 */     paramString = stringBuffer.toString();
/*      */     
/*  422 */     for (int j = 0; j < paramString.length(); j++) {
/*  423 */       if (paramString.charAt(j) == '\\') {
/*  424 */         paramString = paramString.substring(0, j) + paramString.substring(j + 1);
/*      */ 
/*      */         
/*  427 */         char c = paramString.charAt(j);
/*  428 */         if (c == '{' || c == '}') {
/*  429 */           if (bool) {
/*      */             
/*  431 */             paramString = paramString.substring(0, j - 1) + c + "'" + paramString.substring(j + 1);
/*      */             
/*  433 */             j++;
/*      */           } else {
/*      */             
/*  436 */             paramString = paramString.substring(0, j) + "'" + c + "'" + paramString.substring(j + 1);
/*      */             
/*  438 */             j += 2;
/*      */           } 
/*      */           
/*  441 */           bool = true;
/*      */           
/*      */           continue;
/*      */         } 
/*  445 */       } else if (paramString.charAt(j) == '{') {
/*  446 */         j++;
/*  447 */         String str = null;
/*      */         
/*  449 */         switch (paramString.charAt(j)) { case 'P': case 'p':
/*  450 */             str = "0"; break;
/*  451 */           case 'N': case 'n': str = "1"; break;
/*  452 */           case 'D': case 'd': str = "2,date"; break;
/*  453 */           case 'T': case 't': str = "2,time";
/*      */             break; }
/*      */         
/*  456 */         if (str != null) {
/*  457 */           paramString = paramString.substring(0, j) + str + paramString.substring(j + 1);
/*  458 */           j += str.length() - 1;
/*      */         } 
/*      */       } 
/*      */       
/*  462 */       bool = false;
/*      */       continue;
/*      */     } 
/*      */     try {
/*  466 */       return MessageFormat.format(paramString, new Object[] { new Integer(paramInt1), new Integer(paramInt2), paramDate });
/*      */     } catch (Exception exception) {
/*      */       
/*  469 */       exception.printStackTrace();
/*      */ 
/*      */       
/*  472 */       return paramString;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Rectangle[] getFrames(PageArea[] paramArrayOfPageArea) {
/*  479 */     Vector vector = new Vector();
/*      */     
/*  481 */     for (byte b = 0; b < paramArrayOfPageArea.length; b++) {
/*  482 */       if (paramArrayOfPageArea[b].isFlow()) {
/*  483 */         vector.addElement(paramArrayOfPageArea[b].getPrintArea(this.pageBox, this.resolution));
/*      */       }
/*      */     } 
/*      */     
/*  487 */     Rectangle[] arrayOfRectangle = new Rectangle[vector.size()];
/*  488 */     vector.copyInto(arrayOfRectangle);
/*  489 */     return arrayOfRectangle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  496 */   static float roundup(float paramFloat1, float paramFloat2) { return (float)Math.ceil((paramFloat1 / paramFloat2)) * paramFloat2; }
/*      */ 
/*      */   
/*      */   public static Presenter getPresenter(Hashtable paramHashtable, Class paramClass) {
/*  500 */     Presenter presenter = null;
/*      */     
/*  502 */     while (paramClass != null && (presenter = (Presenter)paramHashtable.get(paramClass)) == null) {
/*  503 */       paramClass = paramClass.getSuperclass();
/*      */     }
/*      */     
/*  506 */     return presenter;
/*      */   }
/*      */   
/*      */   public static Format getFormat(Hashtable paramHashtable, Class paramClass) {
/*  510 */     Format format = null;
/*  511 */     while (paramClass != null && (format = (Format)paramHashtable.get(paramClass)) == null) {
/*  512 */       paramClass = paramClass.getSuperclass();
/*      */     }
/*      */     
/*  515 */     return format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  522 */   public Properties getProperties() { return this.prop; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vector getAllElements() {
/*  531 */     Vector vector = new Vector();
/*      */     
/*  533 */     vector.addElement(this.elements);
/*      */     
/*  535 */     Enumeration enumeration = this.areamap.elements();
/*  536 */     while (enumeration.hasMoreElements()) {
/*  537 */       PageArea[] arrayOfPageArea = (PageArea[])enumeration.nextElement();
/*      */       
/*  539 */       for (byte b = 0; b < arrayOfPageArea.length; b++) {
/*  540 */         FixedContainer fixedContainer = arrayOfPageArea[b].getElements();
/*  541 */         if (fixedContainer != null) {
/*  542 */           vector.addElement(fixedContainer);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  547 */     return vector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vector getAllHeaderElements() {
/*  556 */     Vector vector = new Vector();
/*      */     
/*  558 */     vector.addElement(this.headerElements);
/*  559 */     vector.addElement(this.firstHeader);
/*  560 */     vector.addElement(this.evenHeader);
/*  561 */     vector.addElement(this.oddHeader);
/*      */     
/*  563 */     Enumeration enumeration = this.elemHeader.elements();
/*  564 */     while (enumeration.hasMoreElements()) {
/*  565 */       vector.addElement(enumeration.nextElement());
/*      */     }
/*      */     
/*  568 */     return vector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vector getAllFooterElements() {
/*  577 */     Vector vector = new Vector();
/*      */     
/*  579 */     vector.addElement(this.footerElements);
/*  580 */     vector.addElement(this.firstFooter);
/*  581 */     vector.addElement(this.evenFooter);
/*  582 */     vector.addElement(this.oddFooter);
/*      */     
/*  584 */     Enumeration enumeration = this.elemFooter.elements();
/*  585 */     while (enumeration.hasMoreElements()) {
/*  586 */       vector.addElement(enumeration.nextElement());
/*      */     }
/*      */     
/*  589 */     return vector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Rectangle[][] calcGrid(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Vector paramVector) {
/*  597 */     Vector vector1 = new Vector();
/*  598 */     Vector vector2 = new Vector();
/*      */     
/*  600 */     vector1.addElement(new Integer((int)paramFloat1));
/*  601 */     vector2.addElement(new Integer((int)paramFloat2));
/*      */ 
/*      */     
/*  604 */     for (byte b1 = 0; b1 < paramVector.size(); b1++) {
/*  605 */       Rectangle rectangle = (Rectangle)paramVector.elementAt(b1);
/*  606 */       int[] arrayOfInt1 = { rectangle.x, rectangle.x + rectangle.width };
/*  607 */       int[] arrayOfInt2 = { rectangle.y, rectangle.y + rectangle.height };
/*      */       
/*  609 */       for (byte b4 = 0; b4 < arrayOfInt1.length; b4++)
/*      */       {
/*  611 */         Util.insertSorted(arrayOfInt1[b4], vector1);
/*      */       }
/*      */       
/*  614 */       for (byte b5 = 0; b5 < arrayOfInt2.length; b5++)
/*      */       {
/*  616 */         Util.insertSorted(arrayOfInt2[b5], vector2);
/*      */       }
/*      */     } 
/*      */     
/*  620 */     Util.insertSorted((int)(paramFloat1 + paramFloat3), vector1);
/*  621 */     Util.insertSorted((int)(paramFloat2 + paramFloat4), vector2);
/*      */ 
/*      */     
/*  624 */     boolean[][] arrayOfBoolean = new boolean[vector2.size() - 1][vector1.size() - 1];
/*      */ 
/*      */     
/*  627 */     for (byte b2 = 0; b2 < paramVector.size(); b2++) {
/*  628 */       Rectangle rectangle = (Rectangle)paramVector.elementAt(b2);
/*      */       
/*  630 */       int i = vector2.indexOf(new Integer(rectangle.y));
/*  631 */       int j = vector1.indexOf(new Integer(rectangle.x));
/*  632 */       int k = vector2.indexOf(new Integer(rectangle.y + rectangle.height), i);
/*  633 */       int m = vector1.indexOf(new Integer(rectangle.x + rectangle.width), j);
/*      */       
/*  635 */       for (int n = i; n < k; n++) {
/*  636 */         for (int i1 = j; i1 < m; i1++) {
/*  637 */           arrayOfBoolean[n][i1] = true;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  643 */     Rectangle[][] arrayOfRectangle = new Rectangle[vector2.size() - 1][];
/*  644 */     for (byte b3 = 0; b3 < vector2.size() - 1; b3++) {
/*  645 */       int i = ((Integer)vector2.elementAt(b3)).intValue();
/*  646 */       int j = ((Integer)vector2.elementAt(b3 + 1)).intValue();
/*  647 */       Rectangle rectangle = null;
/*  648 */       Vector vector = new Vector();
/*      */       
/*  650 */       for (byte b = 0; b < vector1.size() - 1; b++) {
/*      */         
/*  652 */         if (arrayOfBoolean[b3][b]) {
/*  653 */           if (rectangle != null) {
/*  654 */             vector.addElement(rectangle);
/*  655 */             rectangle = null;
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  661 */           int k = ((Integer)vector1.elementAt(b)).intValue();
/*  662 */           int m = ((Integer)vector1.elementAt(b + 1)).intValue();
/*      */ 
/*      */           
/*  665 */           if (rectangle == null) {
/*  666 */             rectangle = new Rectangle(k, i, m - k, j - i);
/*      */           }
/*      */           else {
/*      */             
/*  670 */             rectangle.width = m - rectangle.x;
/*      */           } 
/*      */         } 
/*      */       } 
/*  674 */       if (rectangle != null) {
/*  675 */         vector.addElement(rectangle);
/*  676 */         rectangle = null;
/*      */       } 
/*      */       
/*  679 */       arrayOfRectangle[b3] = new Rectangle[vector.size()];
/*  680 */       vector.copyInto(arrayOfRectangle[b3]);
/*      */     } 
/*      */     
/*  683 */     return arrayOfRectangle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void alignLine(int paramInt1, int paramInt2, StylePage paramStylePage, float paramFloat) {
/*  692 */     float f1 = 0.0F;
/*  693 */     float f2 = 0.0F;
/*  694 */     byte b = 0;
/*  695 */     boolean bool1 = true, bool2 = true;
/*  696 */     float f3 = (this.printBox.x + this.printBox.width), f4 = 0.0F;
/*  697 */     paramInt2 = Math.min(paramStylePage.getPaintableCount(), paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  702 */     for (int i = paramInt1; i < paramInt2; i++) {
/*  703 */       Paintable paintable = paramStylePage.getPaintable(i);
/*  704 */       Rectangle rectangle = paintable.getBounds();
/*  705 */       BaseElement baseElement = (BaseElement)paintable.getElement();
/*      */       
/*  707 */       if ((baseElement.getAlignment() & 0x2) == 0) {
/*  708 */         bool1 = false;
/*      */       }
/*      */       
/*  711 */       if ((baseElement.getAlignment() & 0x4) == 0) {
/*  712 */         bool2 = false;
/*      */       }
/*      */       
/*  715 */       if (bool1 || bool2) {
/*  716 */         f3 = Math.min(f3, rectangle.x);
/*  717 */         f4 = Math.max(f4, (rectangle.x + rectangle.width));
/*      */       } 
/*      */       
/*  720 */       if ((baseElement.getAlignment() & 0x10) != 0) {
/*  721 */         int j = (int)(rectangle.y + (paramFloat - rectangle.height) / 2.0F);
/*  722 */         paintable.setLocation(new Point(rectangle.x, j));
/*      */       }
/*  724 */       else if ((baseElement.getAlignment() & 0x20) != 0) {
/*  725 */         int j = (int)(rectangle.y + paramFloat - rectangle.height);
/*  726 */         paintable.setLocation(new Point(rectangle.x, j));
/*      */       } 
/*      */       
/*  729 */       if (paintable instanceof TextPaintable) {
/*  730 */         if ((baseElement.getAlignment() & 0x8) == 0 || (baseElement.getAlignment() & 0x40) != 0)
/*      */         {
/*  732 */           b++;
/*      */         }
/*      */         
/*  735 */         if (rectangle.height > f2) {
/*  736 */           f2 = rectangle.height;
/*  737 */           f1 = (paintable.getBounds()).y + Common.getAscent(baseElement.getFont());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  745 */     if (b > 1) {
/*  746 */       for (int j = paramInt1; j < paramInt2; j++) {
/*  747 */         Paintable paintable = paramStylePage.getPaintable(j);
/*      */ 
/*      */         
/*  750 */         if (paintable instanceof TextPaintable) {
/*  751 */           BaseElement baseElement = (BaseElement)paintable.getElement();
/*      */           
/*  753 */           if ((baseElement.getAlignment() & 0x8) == 0 || (baseElement.getAlignment() & 0x40) != 0) {
/*      */             
/*  755 */             Rectangle rectangle = paintable.getBounds();
/*  756 */             int k = (int)(f1 - Common.getAscent(baseElement.getFont()));
/*      */             
/*  758 */             paintable.setLocation(new Point(rectangle.x, k));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  765 */     if (bool1 || bool2) {
/*  766 */       int j = (int)((this.printBox.width - f4 - f3) / (bool1 ? 2.0F : 1.0F) + this.printBox.x - f3);
/*      */ 
/*      */       
/*  769 */       if (j != 0) {
/*  770 */         for (int k = paramInt1; k < paramInt2; k++) {
/*  771 */           Paintable paintable = paramStylePage.getPaintable(k);
/*  772 */           Rectangle rectangle = paintable.getBounds();
/*  773 */           paintable.setLocation(new Point(rectangle.x + j, rectangle.y));
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void processHF(Vector paramVector) {
/*  788 */     for (byte b = 0; b < paramVector.size(); b++) {
/*  789 */       BaseElement baseElement = (BaseElement)paramVector.elementAt(b);
/*  790 */       baseElement.reset();
/*      */ 
/*      */       
/*  793 */       if (baseElement instanceof TextElement) {
/*  794 */         TextElementDef textElementDef = (TextElementDef)baseElement;
/*  795 */         textElementDef.setText(this.hfFmt.create(textElementDef.getTextLens()));
/*      */       }
/*  797 */       else if (baseElement instanceof TextBoxElement) {
/*  798 */         TextBoxElementDef textBoxElementDef = (TextBoxElementDef)baseElement;
/*  799 */         TextLens textLens = this.hfFmt.create(textBoxElementDef.getTextLens());
/*  800 */         ((TextPainter)textBoxElementDef.getPainter()).setText(textLens);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void printFixedContainer(StylePage paramStylePage, FixedContainer paramFixedContainer, Rectangle paramRectangle, boolean paramBoolean) {
/*  810 */     int i = paramRectangle.x + paramRectangle.width;
/*  811 */     int j = paramRectangle.y + paramRectangle.height;
/*      */ 
/*      */     
/*  814 */     Rectangle rectangle = this.printBox;
/*  815 */     Rectangle[] arrayOfRectangle1 = this.frames;
/*  816 */     Rectangle[] arrayOfRectangle2 = this.npframes;
/*  817 */     Position position = this.printHead;
/*  818 */     int k = this.currFrame;
/*  819 */     int m = this.current;
/*  820 */     int n = paramStylePage.getPaintableCount();
/*      */ 
/*      */     
/*  823 */     for (byte b = 0; b < paramFixedContainer.getElementCount(); b++) {
/*  824 */       Rectangle rectangle1 = paramFixedContainer.getBounds(b);
/*  825 */       BaseElement baseElement = (BaseElement)paramFixedContainer.getElement(b);
/*  826 */       this.printHead = new Position(0.0F, 0.0F);
/*  827 */       this.printBox = new Rectangle(paramRectangle.x + rectangle1.x, paramRectangle.y + rectangle1.y, rectangle1.width, rectangle1.height);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  832 */       Point point = new Point(this.printBox.x + this.printBox.width, this.printBox.y + this.printBox.height);
/*      */       
/*  834 */       this.printBox.x = Math.min(i, Math.max(paramRectangle.x, this.printBox.x));
/*  835 */       this.printBox.y = Math.min(j, Math.max(paramRectangle.y, this.printBox.y));
/*  836 */       point.x = Math.min(i, Math.max(paramRectangle.x, point.x));
/*  837 */       point.y = Math.min(j, Math.max(paramRectangle.y, point.y));
/*  838 */       this.printBox.width = point.x - this.printBox.x;
/*  839 */       this.printBox.height = point.y - this.printBox.y;
/*      */       
/*  841 */       this.frames = new Rectangle[] { this.printBox };
/*  842 */       this.npframes = null;
/*  843 */       this.currFrame = 0;
/*  844 */       Vector vector = new Vector();
/*  845 */       vector.addElement(baseElement);
/*  846 */       this.current = 0;
/*      */       
/*  848 */       if (baseElement instanceof PainterElement) {
/*  849 */         PainterElementDef painterElementDef = (PainterElementDef)baseElement;
/*      */         
/*  851 */         Insets insets = painterElementDef.getMargin();
/*  852 */         painterElementDef.setSize(new Size(this.printBox.width - insets.left - insets.right, this.printBox.height - insets.top - insets.bottom, this.resolution));
/*      */ 
/*      */         
/*  855 */         painterElementDef.setAnchor(null);
/*      */       } 
/*      */ 
/*      */       
/*  859 */       if (paramBoolean) {
/*  860 */         baseElement.reset();
/*      */       }
/*      */       
/*  863 */       baseElement.setNonFlow(paramBoolean);
/*      */       
/*  865 */       printNextArea(paramStylePage, vector);
/*      */     } 
/*      */ 
/*      */     
/*  869 */     for (int i1 = n; i1 < paramStylePage.getPaintableCount(); i1++) {
/*  870 */       ((BasePaintable)paramStylePage.getPaintable(i1)).setFrame(paramRectangle);
/*      */     }
/*      */ 
/*      */     
/*  874 */     this.printBox = rectangle;
/*  875 */     this.printHead = position;
/*  876 */     this.frames = arrayOfRectangle1;
/*  877 */     this.npframes = arrayOfRectangle2;
/*  878 */     this.currFrame = k;
/*  879 */     this.current = m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValue(ReportElement paramReportElement, Object paramObject) throws IllegalArgumentException {
/*  887 */     if (paramReportElement instanceof TableElement) {
/*  888 */       if (paramObject instanceof TableLens) {
/*  889 */         ((TableElement)paramReportElement).setTable((TableLens)paramObject);
/*      */       }
/*  891 */       else if (paramObject instanceof FormLens) {
/*  892 */         ((FormXElement)paramReportElement).setForm((FormLens)paramObject);
/*      */       
/*      */       }
/*  895 */       else if (paramObject instanceof Object[][]) {
/*  896 */         TableLens tableLens = ((TableElement)paramReportElement).getTable();
/*  897 */         TableStyle tableStyle = null;
/*      */         
/*  899 */         if (tableLens instanceof TableStyle) {
/*  900 */           tableStyle = (TableStyle)tableLens;
/*      */           
/*      */           while (true) {
/*  903 */             tableLens = tableStyle.getTable();
/*  904 */             if (tableLens instanceof TableStyle) {
/*  905 */               tableStyle = (TableStyle)tableLens;
/*      */               
/*      */               continue;
/*      */             } 
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*  913 */         if (tableLens instanceof DefaultTableLens) {
/*  914 */           ((DefaultTableLens)tableLens).setData((Object[][])paramObject);
/*      */         }
/*  916 */         else if (tableStyle != null) {
/*  917 */           tableStyle.setTable(new DefaultTableLens((Object[][])paramObject));
/*      */         } else {
/*      */           
/*  920 */           ((TableElement)paramReportElement).setTable(new DefaultTableLens((Object[][])paramObject));
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  925 */         throw new IllegalArgumentException("Only TableLens or FormLens can be used in a Table: " + paramObject.getClass());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  930 */       if (paramReportElement instanceof TableXElement) {
/*  931 */         TableStyle tableStyle = ((TableXElement)paramReportElement).getStyle();
/*  932 */         if (tableStyle != null) {
/*  933 */           tableStyle.refresh();
/*      */         }
/*      */       }
/*      */     
/*  937 */     } else if (paramReportElement instanceof SectionElement) {
/*  938 */       if (paramObject instanceof TableLens) {
/*  939 */         ((SectionElement)paramReportElement).setTable((TableLens)paramObject);
/*      */       }
/*  941 */       else if (paramObject instanceof Object[][]) {
/*  942 */         ((SectionElement)paramReportElement).setTable(new DefaultTableLens((Object[][])paramObject));
/*      */       }
/*      */       else {
/*      */         
/*  946 */         throw new IllegalArgumentException("Only TableLens can be used in a Section: " + paramObject.getClass());
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  951 */     else if (paramReportElement instanceof ChartElement) {
/*  952 */       if (paramObject instanceof ChartLens) {
/*  953 */         ((ChartElement)paramReportElement).setChart((ChartLens)paramObject);
/*      */       }
/*  955 */       else if (paramObject instanceof TableLens) {
/*  956 */         ((ChartElement)paramReportElement).setChart(new TableChartLens((TableLens)paramObject));
/*      */       } else {
/*      */         
/*  959 */         throw new IllegalArgumentException("Only ChartLens can be used in a Chart: " + paramObject.getClass());
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  964 */     else if (paramReportElement instanceof TextBoxElement) {
/*  965 */       if (paramObject instanceof String) {
/*  966 */         ((TextBoxElement)paramReportElement).setText(new DefaultTextLens(paramObject.toString()));
/*      */       
/*      */       }
/*  969 */       else if (paramObject instanceof TextLens) {
/*  970 */         ((TextBoxElement)paramReportElement).setText((TextLens)paramObject);
/*      */       } else {
/*      */         
/*  973 */         ((TextBoxElement)paramReportElement).setText(toString(paramObject));
/*      */       }
/*      */     
/*  976 */     } else if (paramReportElement instanceof TextElement) {
/*  977 */       if (paramObject instanceof String) {
/*  978 */         ((TextElement)paramReportElement).setText(new DefaultTextLens(paramObject.toString()));
/*      */       }
/*  980 */       else if (paramObject instanceof TextLens) {
/*  981 */         ((TextElement)paramReportElement).setText((TextLens)paramObject);
/*      */       } else {
/*      */         
/*  984 */         ((TextElement)paramReportElement).setText(toString(paramObject));
/*      */       }
/*      */     
/*  987 */     } else if (paramReportElement instanceof ButtonElementDef) {
/*  988 */       ((ButtonElementDef)paramReportElement).setText(toString(paramObject));
/*      */     
/*      */     }
/*  991 */     else if (paramReportElement instanceof CheckBoxElementDef) {
/*  992 */       ((CheckBoxElementDef)paramReportElement).setText(toString(paramObject));
/*      */     }
/*  994 */     else if (paramReportElement instanceof ChoiceElementDef) {
/*  995 */       if (paramObject instanceof Object[]) {
/*  996 */         ((ChoiceElementDef)paramReportElement).setChoices((Object[])paramObject);
/*      */       } else {
/*      */         
/*  999 */         ((ChoiceElementDef)paramReportElement).setSelectedItem(paramObject);
/*      */       }
/*      */     
/* 1002 */     } else if (paramReportElement instanceof TextFieldElementDef) {
/* 1003 */       ((TextFieldElementDef)paramReportElement).setText(toString(paramObject));
/*      */     }
/* 1005 */     else if (paramReportElement instanceof TextAreaElementDef) {
/* 1006 */       ((TextAreaElementDef)paramReportElement).setText(toString(paramObject));
/*      */     }
/* 1008 */     else if (paramReportElement instanceof PainterElementDef) {
/* 1009 */       if (paramObject instanceof Image) {
/* 1010 */         ((PainterElementDef)paramReportElement).setPainter(new ImagePainter((Image)paramObject));
/*      */       
/*      */       }
/* 1013 */       else if (paramObject instanceof Painter) {
/* 1014 */         ((PainterElement)paramReportElement).setPainter((Painter)paramObject);
/*      */       }
/* 1016 */       else if (paramObject instanceof Component) {
/* 1017 */         ((PainterElement)paramReportElement).setPainter(new ComponentPainter((Component)paramObject));
/*      */       }
/*      */       else {
/*      */         
/* 1021 */         throw new IllegalArgumentException("Only Image, Component, or  Painter can be used in a Painter: " + paramObject.getClass());
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1027 */     else if (paramReportElement instanceof CompositeElement) {
/* 1028 */       if (paramObject instanceof inetsoft.report.lens.ElementContainer) {
/* 1029 */         ((CompositeElement)paramReportElement).setComposite((CompositeLens)paramObject);
/*      */       } else {
/*      */         
/* 1032 */         throw new IllegalArgumentException("Only ElementContainer can be used in a Composite: " + paramObject.getClass());
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1038 */       throw new IllegalArgumentException(paramReportElement + ":" + paramObject);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ScriptEnv getScriptEnv() {
/* 1046 */     if (this.scriptenv == null) {
/* 1047 */       this.scriptenv = ScriptEnv.getScriptEnv((StyleSheet)this);
/*      */     }
/*      */     
/* 1050 */     return this.scriptenv;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void runOnLoad() {
/* 1058 */     if (this.loadCalled) {
/*      */       return;
/*      */     }
/*      */     
/* 1062 */     this.loadCalled = true;
/* 1063 */     String str = this.loadCmd;
/*      */     
/* 1065 */     if (str != null) {
/*      */       try {
/* 1067 */         ScriptEnv scriptEnv = getScriptEnv();
/*      */         
/* 1069 */         if (this.loadScript == null && scriptEnv != null) {
/* 1070 */           this.loadScript = scriptEnv.compile(str);
/*      */         }
/*      */         
/* 1073 */         if (this.loadScript != null) {
/* 1074 */           scriptEnv.exec(null, this.loadScript, null);
/*      */         }
/*      */       } catch (Exception exception) {
/* 1077 */         if (Util.isGUI()) {
/* 1078 */           MessageDialog.show(exception + "\n" + str);
/*      */         } else {
/*      */           
/* 1081 */           System.err.println("onLoad script failed: " + exception);
/*      */         } 
/*      */         
/* 1084 */         exception.printStackTrace();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1091 */   public void setHFTextFormatter(HFTextFormatter paramHFTextFormatter) { this.hfFmt = paramHFTextFormatter; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1096 */   public HFTextFormatter getHFTextFormatter() { return this.hfFmt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String toString(Object paramObject) {
/* 1103 */     if (paramObject == null) {
/* 1104 */       return "";
/*      */     }
/*      */     
/* 1107 */     Format format = getFormat(this.formatmap, paramObject.getClass());
/* 1108 */     return (format != null) ? format.format(paramObject) : paramObject.toString();
/*      */   }
/*      */   
/*      */   protected void checkLimit() {
/* 1112 */     if (limited && !this.internal && ++counter > this.max_report) {
/* 1113 */       throw new Error("Style Report/Lite is limited to " + this.max_report + " report(s) per application!");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1120 */   protected Margin margin = new Margin(1.0D, 1.0D, 1.0D, 1.0D);
/* 1121 */   protected Margin pmargin = new Margin(g_pmargin);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1127 */   protected static Margin g_pmargin = new Margin(0.0D, 0.0D, 0.0D, 0.0D);
/*      */   
/*      */   static  { try {
/* 1130 */       if (ReportEnv.getProperty("os.name").startsWith("Win")) {
/* 1131 */         String str = ReportEnv.getProperty("java.version");
/* 1132 */         if (str.compareTo("1.1.7") < 0 || (str.compareTo("1.2") >= 0 && str.compareTo("1.2.2") < 0))
/*      */         {
/* 1134 */           g_pmargin = new Margin(0.25D, 0.25D, 0.25D, 0.25D);
/*      */         }
/*      */       } 
/* 1137 */     } catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1266 */     limited = false;
/* 1267 */     counter = 0; } protected double headerFromEdge = 0.5D; protected double footerFromEdge = 0.75D; protected String header = null; protected int pgStart = 0; protected int alignment = 1; protected double indent = 0.0D; protected Position anchor = null; protected int hindent = 0; protected double[] tabStops = { 
/*      */       0.5D, 1.0D, 1.5D, 2.0D, 2.5D, 3.0D, 3.5D, 4.0D, 4.5D, 5.0D, 
/* 1269 */       5.5D, 6.0D, 6.5D, 7.0D, 7.5D, 8.0D }; protected int spacing = 0; protected Insets padding = new Insets(1, 1, 1, 1); protected Font font = new Font("Serif", 0, 10); protected Color foreground = Color.black; protected Color background = null; protected int autosize = 1; protected int painterLayout = 0; protected Insets painterMargin = new Insets(1, 1, 1, 1); protected ChartDescriptor chartinfo = null; protected double tableW = 0.0D; protected Hashtable presentermap = new Hashtable(); protected Hashtable formatmap = new Hashtable(); protected boolean justify = false; protected int textadv = 3; protected int sepadv = 4; protected int tableadv = 3; protected int wrapping = 3; protected boolean orphan = false; protected boolean tableorphan = false; protected int current = 0; protected Position printHead = new Position(0.0F, 0.0F); protected float lineH = 0.0F; protected Rectangle printBox = new Rectangle(72, 72, 468, 648); protected Rectangle pageBox = new Rectangle(72, 72, 468, 648); protected Position lastHead = new Position(0.0F, 0.0F); protected Rectangle[] frames = null; protected Rectangle[] npframes = null; protected PageArea[] npareas = null; protected int currFrame = 0; private int max_report = 1; protected PageArea[] areas = null; protected float advanceLine = 0.0F; protected int[] headingCnt = new int[20]; protected Hashtable headingMap = new Hashtable(); protected int resolution = 72; protected Hashtable contexts = new Hashtable(); protected Hashtable idmap = new Hashtable(); protected Vector elements = new Vector(50); protected Hashtable areamap = new Hashtable(); protected Vector headerElements = new Vector(); protected Vector footerElements = new Vector(); protected Vector firstHeader = new Vector(); protected Vector firstFooter = new Vector(); protected Vector evenHeader = new Vector(); protected Vector evenFooter = new Vector(); protected Vector oddHeader = new Vector(); protected Vector oddFooter = new Vector(); protected Hashtable elemHeader = new Hashtable(); protected Hashtable elemFooter = new Hashtable(); protected Vector currHeader = this.headerElements; protected Vector currFooter = this.footerElements; protected Vector overrideHeader = null; protected Vector overrideFooter = null; protected boolean horFlow = false; protected boolean designtime = false; protected Properties prop = new Properties(); protected Object bg; protected ImageLocation bgimage; protected String pagebreakCmd = null; protected Object pagebreakScript = null; protected String loadCmd = null; protected boolean loadCalled = false; protected Object loadScript = null; protected ScriptEnv scriptenv = null; protected HFTextFormatter hfFmt = null; private static boolean limited; private static int counter; private boolean internal = false;
/* 1270 */   private int max_row = 50;
/*      */ 
/*      */   
/* 1273 */   public static boolean isLimited() { return limited; }
/*      */ 
/*      */ 
/*      */   
/* 1277 */   protected int getMaxRows() { return this.max_row; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
/* 1283 */     paramObjectInputStream.defaultReadObject();
/*      */     
/* 1285 */     char c = paramObjectInputStream.readChar();
/* 1286 */     if (c == 'I') {
/* 1287 */       byte[] arrayOfByte = (byte[])paramObjectInputStream.readObject();
/* 1288 */       if (arrayOfByte != null) {
/* 1289 */         int i = paramObjectInputStream.readInt();
/* 1290 */         int j = paramObjectInputStream.readInt();
/* 1291 */         this.bg = Encoder.decodeImage(i, j, arrayOfByte);
/*      */       } 
/*      */     } else {
/*      */       
/* 1295 */       this.bg = paramObjectInputStream.readObject();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/* 1300 */     paramObjectOutputStream.defaultWriteObject();
/*      */     
/* 1302 */     if (this.bg instanceof Image) {
/* 1303 */       paramObjectOutputStream.writeChar(73);
/* 1304 */       Image image = (Image)this.bg;
/* 1305 */       byte[] arrayOfByte = Encoder.encodeImage(image);
/* 1306 */       paramObjectOutputStream.writeObject(arrayOfByte);
/* 1307 */       if (arrayOfByte != null) {
/* 1308 */         paramObjectOutputStream.writeInt(image.getWidth(null));
/* 1309 */         paramObjectOutputStream.writeInt(image.getHeight(null));
/*      */       } 
/*      */     } else {
/*      */       
/* 1313 */       paramObjectOutputStream.writeChar(79);
/* 1314 */       paramObjectOutputStream.writeObject(this.bg);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected abstract boolean printNextArea(StylePage paramStylePage, Vector paramVector);
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\StyleCore.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */