package inetsoft.report.internal;

import inetsoft.report.ChartDescriptor;
import inetsoft.report.ChartElement;
import inetsoft.report.ChartLens;
import inetsoft.report.Common;
import inetsoft.report.CompositeElement;
import inetsoft.report.CompositeLens;
import inetsoft.report.Context;
import inetsoft.report.FixedContainer;
import inetsoft.report.FormLens;
import inetsoft.report.Margin;
import inetsoft.report.PageArea;
import inetsoft.report.Paintable;
import inetsoft.report.Painter;
import inetsoft.report.PainterElement;
import inetsoft.report.Position;
import inetsoft.report.Presenter;
import inetsoft.report.ReportElement;
import inetsoft.report.ReportEnv;
import inetsoft.report.SectionElement;
import inetsoft.report.Size;
import inetsoft.report.StyleConstants;
import inetsoft.report.StylePage;
import inetsoft.report.StyleSheet;
import inetsoft.report.TableElement;
import inetsoft.report.TableLens;
import inetsoft.report.TextBoxElement;
import inetsoft.report.TextElement;
import inetsoft.report.TextLens;
import inetsoft.report.lens.DefaultTableLens;
import inetsoft.report.lens.DefaultTextLens;
import inetsoft.report.lens.TableChartLens;
import inetsoft.report.painter.ComponentPainter;
import inetsoft.report.painter.ImagePainter;
import inetsoft.report.style.TableStyle;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.Format;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;

public abstract class StyleCore implements StyleConstants {
  public StyleCore() {
    if (limited) {
      String str = ReportEnv.getProperty("license.key");
      if (str != null)
        if (!KeyUtil.verify2(str, 'R')) {
          System.err.println("Invalid license key: " + str);
          System.err.println("Software running in evaluation mode!");
        } else {
          limited = false;
        }  
    } 
    if (limited) {
      String[] arrayOfString = Util.getCallers();
      this.internal = false;
      for (byte b = 0; b < arrayOfString.length; b++) {
        if (arrayOfString[b].startsWith("inetsoft.report.design.") || arrayOfString[b].startsWith("inetsoft.report.jbuilder") || arrayOfString[b].startsWith("inetsoft.report.vcafe")) {
          this.internal = true;
          break;
        } 
      } 
      this.max_report = 1;
      this.max_row = 50;
      try {
        Class.forName("inetsoft.sree.Replet");
        this.max_report = 10;
        this.max_row = 200;
      } catch (Throwable throwable) {}
      if (!this.internal && ++counter > this.max_report)
        throw new Error("Style Report/Lite is limited to " + this.max_report + " report(s) per application!"); 
    } else if (Util.isServer()) {
      String str = ReportEnv.getProperty("license.key");
      if (str == null || !KeyUtil.verify2(str, 'R'))
        throw new RuntimeException("Runtime license require for server-side deployment. Please add the runtime key to the properties as license.key!"); 
    } 
  }
  
  public void setDesignTime(boolean paramBoolean) { this.designtime = paramBoolean; }
  
  public Hashtable getElementHeaders() { return this.elemHeader; }
  
  public Hashtable getElementFooters() { return this.elemFooter; }
  
  public void setOverrideHeader(Vector paramVector) { this.overrideHeader = paramVector; }
  
  public void setOverrideFooter(Vector paramVector) { this.overrideFooter = paramVector; }
  
  public void setBackgroundImageLocation(ImageLocation paramImageLocation) {
    this.bgimage = paramImageLocation;
    if (paramImageLocation != null)
      try {
        this.bg = paramImageLocation.getImage();
      } catch (Exception exception) {
        System.err.println("Failed to load image: " + paramImageLocation.getPath());
      }  
  }
  
  public ImageLocation getBackgroundImageLocation() { return this.bgimage; }
  
  public String getNextID(String paramString) {
    Integer integer = (Integer)this.idmap.get(paramString);
    if (integer == null)
      integer = new Integer(1); 
    this.idmap.put(paramString, new Integer(integer.intValue() + 1));
    return paramString + integer;
  }
  
  public void setHindent(int paramInt) { this.hindent = paramInt; }
  
  public Hashtable getElementAreas() { return this.areamap; }
  
  public ReportElement getCompositeElement(String paramString, Object paramObject, Context paramContext) {
    PainterElementDef painterElementDef = null;
    if (paramObject == CompositeLens.PAGE_BREAK) {
      painterElementDef = new PageBreakElementDef((StyleSheet)this);
    } else if (paramObject == CompositeLens.AREA_BREAK) {
      AreaBreakElementDef areaBreakElementDef = new AreaBreakElementDef((StyleSheet)this);
    } else if (paramObject == CompositeLens.NEWLINE) {
      NewlineElementDef newlineElementDef = new NewlineElementDef((StyleSheet)this, 1, false);
    } else if (paramObject == CompositeLens.BREAK) {
      NewlineElementDef newlineElementDef = new NewlineElementDef((StyleSheet)this, 1, true);
    } else if (paramObject instanceof CompositeLens.Tab) {
      int i = ((CompositeLens.Tab)paramObject).getFillStyle();
      TabElementDef tabElementDef = new TabElementDef((StyleSheet)this, i);
    } else if (paramObject instanceof CompositeLens.Separator) {
      int i = ((CompositeLens.Separator)paramObject).getStyle();
      SeparatorElementDef separatorElementDef = new SeparatorElementDef((StyleSheet)this, i);
    } else if (paramObject instanceof CompositeLens.Space) {
      int i = ((CompositeLens.Space)paramObject).getSpace();
      SpaceElementDef spaceElementDef = new SpaceElementDef((StyleSheet)this, i);
    } else if (paramObject instanceof TableLens) {
      TableElementDef tableElementDef = new TableElementDef((StyleSheet)this, (TableLens)paramObject);
    } else if (paramObject instanceof TextLens) {
      TextElementDef textElementDef = new TextElementDef((StyleSheet)this, (TextLens)paramObject);
    } else if (paramObject instanceof String) {
      TextElementDef textElementDef = new TextElementDef((StyleSheet)this, new DefaultTextLens((String)paramObject));
    } else if (paramObject instanceof FormLens) {
      FormElementDef formElementDef = new FormElementDef((StyleSheet)this, (FormLens)paramObject);
    } else if (paramObject instanceof ChartLens) {
      ChartElementDef chartElementDef = new ChartElementDef((StyleSheet)this, (ChartLens)paramObject);
    } else if (paramObject instanceof Image) {
      PainterElementDef painterElementDef1 = new PainterElementDef((StyleSheet)this, new ImagePainter((Image)paramObject));
    } else if (paramObject instanceof Painter) {
      painterElementDef = new PainterElementDef((StyleSheet)this, (Painter)paramObject);
    } 
    if (painterElementDef != null) {
      painterElementDef.setID(paramString + "." + painterElementDef.getID());
      painterElementDef.setContext(paramContext);
    } 
    return painterElementDef;
  }
  
  protected String getNextHeadingNumber(int paramInt) {
    for (int i = paramInt; i < this.headingCnt.length; i++)
      this.headingCnt[i] = 0; 
    this.headingCnt[paramInt - 1] = this.headingCnt[paramInt - 1] + 1;
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramInt; b++)
      stringBuffer.append((b ? "." : "") + this.headingCnt[b]); 
    return stringBuffer.toString();
  }
  
  protected void advance(float paramFloat1, float paramFloat2) {
    this.printHead.y += paramFloat2;
    if (paramFloat1 == 0.0F && paramFloat2 != 0.0F) {
      this.printHead.x = 0.0F;
    } else {
      this.printHead.x += paramFloat1;
    } 
  }
  
  public static Size getTextSize(String paramString, Font paramFont, int paramInt) {
    FontMetrics fontMetrics = Common.getFontMetrics(paramFont);
    int i = 0, j = 0;
    Size size = new Size(0.0F, 0.0F);
    while (!i) {
      i = paramString.indexOf("\n", j);
      String str = (i >= 0) ? paramString.substring(j, i) : paramString.substring(j);
      float f = Common.stringWidth(str, paramFont, fontMetrics);
      size.width = Math.max(size.width, f);
      size.height += Common.getHeight(paramFont, fontMetrics) + ((i >= 0) ? paramInt : 0.0F);
      j = i + 1;
    } 
    return size;
  }
  
  static float[] getPrefMinWidth(String paramString, Font paramFont, boolean paramBoolean, float paramFloat) {
    FontMetrics fontMetrics = Common.getFontMetrics(paramFont);
    int i = 0, j = 0;
    float[] arrayOfFloat = new float[2];
    while (!i) {
      i = paramString.indexOf("\n", j);
      String str = (i >= 0) ? paramString.substring(j, i) : paramString.substring(j);
      float f = Common.stringWidth(str, paramFont, fontMetrics);
      arrayOfFloat[0] = Math.max(arrayOfFloat[0], f);
      if (paramBoolean && str.length() > 0) {
        int k = 0;
        for (int m = 0, n = str.indexOf(' '); !m; 
          m = n, n = (n > 0) ? str.indexOf(' ', n + 1) : -1) {
          int i1 = (n > 0) ? (n - m) : (str.length() - m);
          if (i1 > k)
            k = i1; 
        } 
        arrayOfFloat[1] = Math.max(arrayOfFloat[1], f * k / str.length());
        arrayOfFloat[1] = Math.min(arrayOfFloat[1], paramFloat);
        arrayOfFloat[0] = Math.max(arrayOfFloat[0], arrayOfFloat[1]);
      } else if (arrayOfFloat[1] > arrayOfFloat[0] || arrayOfFloat[1] <= 0.0F) {
        arrayOfFloat[1] = arrayOfFloat[0];
      } 
      j = i + 1;
    } 
    return arrayOfFloat;
  }
  
  public static String format(String paramString, int paramInt1, int paramInt2, Date paramDate) {
    paramString = Util.replaceAll(paramString, "'", "''");
    StringBuffer stringBuffer = new StringBuffer();
    for (int i = 0; i < paramString.length(); i++) {
      if (paramString.charAt(i) == '{') {
        int k = paramString.indexOf('}', i + 1);
        if (k > i + 1) {
          String str1 = paramString.substring(i + 1, k);
          String str2 = str1.toLowerCase();
          if (str2.startsWith("p,") || str2.startsWith("n,") || str2.startsWith("d,") || str2.startsWith("t,") || str2.equals("p") || str2.equals("n") || str2.equals("d") || str2.equals("t")) {
            stringBuffer.append("{" + str1 + "}");
            i = k;
          } else {
            stringBuffer.append('\\');
            stringBuffer.append(paramString.charAt(i));
          } 
        } else {
          stringBuffer.append('\\');
          stringBuffer.append(paramString.charAt(i));
        } 
      } else {
        if (paramString.charAt(i) == '}') {
          stringBuffer.append('\\');
        } else if (paramString.charAt(i) == '\\') {
          stringBuffer.append('\\');
          i++;
        } 
        stringBuffer.append(paramString.charAt(i));
      } 
    } 
    boolean bool = false;
    paramString = stringBuffer.toString();
    for (int j = 0; j < paramString.length(); j++) {
      if (paramString.charAt(j) == '\\') {
        paramString = paramString.substring(0, j) + paramString.substring(j + 1);
        char c = paramString.charAt(j);
        if (c == '{' || c == '}') {
          if (bool) {
            paramString = paramString.substring(0, j - 1) + c + "'" + paramString.substring(j + 1);
            j++;
          } else {
            paramString = paramString.substring(0, j) + "'" + c + "'" + paramString.substring(j + 1);
            j += 2;
          } 
          bool = true;
          continue;
        } 
      } else if (paramString.charAt(j) == '{') {
        j++;
        String str = null;
        switch (paramString.charAt(j)) {
          case 'P':
          case 'p':
            str = "0";
            break;
          case 'N':
          case 'n':
            str = "1";
            break;
          case 'D':
          case 'd':
            str = "2,date";
            break;
          case 'T':
          case 't':
            str = "2,time";
            break;
        } 
        if (str != null) {
          paramString = paramString.substring(0, j) + str + paramString.substring(j + 1);
          j += str.length() - 1;
        } 
      } 
      bool = false;
      continue;
    } 
    try {
      return MessageFormat.format(paramString, new Object[] { new Integer(paramInt1), new Integer(paramInt2), paramDate });
    } catch (Exception exception) {
      exception.printStackTrace();
      return paramString;
    } 
  }
  
  protected Rectangle[] getFrames(PageArea[] paramArrayOfPageArea) {
    Vector vector = new Vector();
    for (byte b = 0; b < paramArrayOfPageArea.length; b++) {
      if (paramArrayOfPageArea[b].isFlow())
        vector.addElement(paramArrayOfPageArea[b].getPrintArea(this.pageBox, this.resolution)); 
    } 
    Rectangle[] arrayOfRectangle = new Rectangle[vector.size()];
    vector.copyInto(arrayOfRectangle);
    return arrayOfRectangle;
  }
  
  static float roundup(float paramFloat1, float paramFloat2) { return (float)Math.ceil((paramFloat1 / paramFloat2)) * paramFloat2; }
  
  public static Presenter getPresenter(Hashtable paramHashtable, Class paramClass) {
    Presenter presenter = null;
    while (paramClass != null && (presenter = (Presenter)paramHashtable.get(paramClass)) == null)
      paramClass = paramClass.getSuperclass(); 
    return presenter;
  }
  
  public static Format getFormat(Hashtable paramHashtable, Class paramClass) {
    Format format = null;
    while (paramClass != null && (format = (Format)paramHashtable.get(paramClass)) == null)
      paramClass = paramClass.getSuperclass(); 
    return format;
  }
  
  public Properties getProperties() { return this.prop; }
  
  public Vector getAllElements() {
    Vector vector = new Vector();
    vector.addElement(this.elements);
    Enumeration enumeration = this.areamap.elements();
    while (enumeration.hasMoreElements()) {
      PageArea[] arrayOfPageArea = (PageArea[])enumeration.nextElement();
      for (byte b = 0; b < arrayOfPageArea.length; b++) {
        FixedContainer fixedContainer = arrayOfPageArea[b].getElements();
        if (fixedContainer != null)
          vector.addElement(fixedContainer); 
      } 
    } 
    return vector;
  }
  
  public Vector getAllHeaderElements() {
    Vector vector = new Vector();
    vector.addElement(this.headerElements);
    vector.addElement(this.firstHeader);
    vector.addElement(this.evenHeader);
    vector.addElement(this.oddHeader);
    Enumeration enumeration = this.elemHeader.elements();
    while (enumeration.hasMoreElements())
      vector.addElement(enumeration.nextElement()); 
    return vector;
  }
  
  public Vector getAllFooterElements() {
    Vector vector = new Vector();
    vector.addElement(this.footerElements);
    vector.addElement(this.firstFooter);
    vector.addElement(this.evenFooter);
    vector.addElement(this.oddFooter);
    Enumeration enumeration = this.elemFooter.elements();
    while (enumeration.hasMoreElements())
      vector.addElement(enumeration.nextElement()); 
    return vector;
  }
  
  protected Rectangle[][] calcGrid(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Vector paramVector) {
    Vector vector1 = new Vector();
    Vector vector2 = new Vector();
    vector1.addElement(new Integer((int)paramFloat1));
    vector2.addElement(new Integer((int)paramFloat2));
    for (byte b1 = 0; b1 < paramVector.size(); b1++) {
      Rectangle rectangle = (Rectangle)paramVector.elementAt(b1);
      int[] arrayOfInt1 = { rectangle.x, rectangle.x + rectangle.width };
      int[] arrayOfInt2 = { rectangle.y, rectangle.y + rectangle.height };
      for (byte b4 = 0; b4 < arrayOfInt1.length; b4++)
        Util.insertSorted(arrayOfInt1[b4], vector1); 
      for (byte b5 = 0; b5 < arrayOfInt2.length; b5++)
        Util.insertSorted(arrayOfInt2[b5], vector2); 
    } 
    Util.insertSorted((int)(paramFloat1 + paramFloat3), vector1);
    Util.insertSorted((int)(paramFloat2 + paramFloat4), vector2);
    boolean[][] arrayOfBoolean = new boolean[vector2.size() - 1][vector1.size() - 1];
    for (byte b2 = 0; b2 < paramVector.size(); b2++) {
      Rectangle rectangle = (Rectangle)paramVector.elementAt(b2);
      int i = vector2.indexOf(new Integer(rectangle.y));
      int j = vector1.indexOf(new Integer(rectangle.x));
      int k = vector2.indexOf(new Integer(rectangle.y + rectangle.height), i);
      int m = vector1.indexOf(new Integer(rectangle.x + rectangle.width), j);
      for (int n = i; n < k; n++) {
        for (int i1 = j; i1 < m; i1++)
          arrayOfBoolean[n][i1] = true; 
      } 
    } 
    Rectangle[][] arrayOfRectangle = new Rectangle[vector2.size() - 1][];
    for (byte b3 = 0; b3 < vector2.size() - 1; b3++) {
      int i = ((Integer)vector2.elementAt(b3)).intValue();
      int j = ((Integer)vector2.elementAt(b3 + 1)).intValue();
      Rectangle rectangle = null;
      Vector vector = new Vector();
      for (byte b = 0; b < vector1.size() - 1; b++) {
        if (arrayOfBoolean[b3][b]) {
          if (rectangle != null) {
            vector.addElement(rectangle);
            rectangle = null;
          } 
        } else {
          int k = ((Integer)vector1.elementAt(b)).intValue();
          int m = ((Integer)vector1.elementAt(b + 1)).intValue();
          if (rectangle == null) {
            rectangle = new Rectangle(k, i, m - k, j - i);
          } else {
            rectangle.width = m - rectangle.x;
          } 
        } 
      } 
      if (rectangle != null) {
        vector.addElement(rectangle);
        rectangle = null;
      } 
      arrayOfRectangle[b3] = new Rectangle[vector.size()];
      vector.copyInto(arrayOfRectangle[b3]);
    } 
    return arrayOfRectangle;
  }
  
  protected void alignLine(int paramInt1, int paramInt2, StylePage paramStylePage, float paramFloat) {
    float f1 = 0.0F;
    float f2 = 0.0F;
    byte b = 0;
    boolean bool1 = true, bool2 = true;
    float f3 = (this.printBox.x + this.printBox.width), f4 = 0.0F;
    paramInt2 = Math.min(paramStylePage.getPaintableCount(), paramInt2);
    for (int i = paramInt1; i < paramInt2; i++) {
      Paintable paintable = paramStylePage.getPaintable(i);
      Rectangle rectangle = paintable.getBounds();
      BaseElement baseElement = (BaseElement)paintable.getElement();
      if ((baseElement.getAlignment() & 0x2) == 0)
        bool1 = false; 
      if ((baseElement.getAlignment() & 0x4) == 0)
        bool2 = false; 
      if (bool1 || bool2) {
        f3 = Math.min(f3, rectangle.x);
        f4 = Math.max(f4, (rectangle.x + rectangle.width));
      } 
      if ((baseElement.getAlignment() & 0x10) != 0) {
        int j = (int)(rectangle.y + (paramFloat - rectangle.height) / 2.0F);
        paintable.setLocation(new Point(rectangle.x, j));
      } else if ((baseElement.getAlignment() & 0x20) != 0) {
        int j = (int)(rectangle.y + paramFloat - rectangle.height);
        paintable.setLocation(new Point(rectangle.x, j));
      } 
      if (paintable instanceof TextPaintable) {
        if ((baseElement.getAlignment() & 0x8) == 0 || (baseElement.getAlignment() & 0x40) != 0)
          b++; 
        if (rectangle.height > f2) {
          f2 = rectangle.height;
          f1 = (paintable.getBounds()).y + Common.getAscent(baseElement.getFont());
        } 
      } 
    } 
    if (b > 1)
      for (int j = paramInt1; j < paramInt2; j++) {
        Paintable paintable = paramStylePage.getPaintable(j);
        if (paintable instanceof TextPaintable) {
          BaseElement baseElement = (BaseElement)paintable.getElement();
          if ((baseElement.getAlignment() & 0x8) == 0 || (baseElement.getAlignment() & 0x40) != 0) {
            Rectangle rectangle = paintable.getBounds();
            int k = (int)(f1 - Common.getAscent(baseElement.getFont()));
            paintable.setLocation(new Point(rectangle.x, k));
          } 
        } 
      }  
    if (bool1 || bool2) {
      int j = (int)((this.printBox.width - f4 - f3) / (bool1 ? 2.0F : 1.0F) + this.printBox.x - f3);
      if (j != 0)
        for (int k = paramInt1; k < paramInt2; k++) {
          Paintable paintable = paramStylePage.getPaintable(k);
          Rectangle rectangle = paintable.getBounds();
          paintable.setLocation(new Point(rectangle.x + j, rectangle.y));
        }  
    } 
  }
  
  protected void processHF(Vector paramVector) {
    for (byte b = 0; b < paramVector.size(); b++) {
      BaseElement baseElement = (BaseElement)paramVector.elementAt(b);
      baseElement.reset();
      if (baseElement instanceof TextElement) {
        TextElementDef textElementDef = (TextElementDef)baseElement;
        textElementDef.setText(this.hfFmt.create(textElementDef.getTextLens()));
      } else if (baseElement instanceof TextBoxElement) {
        TextBoxElementDef textBoxElementDef = (TextBoxElementDef)baseElement;
        TextLens textLens = this.hfFmt.create(textBoxElementDef.getTextLens());
        ((TextPainter)textBoxElementDef.getPainter()).setText(textLens);
      } 
    } 
  }
  
  public void printFixedContainer(StylePage paramStylePage, FixedContainer paramFixedContainer, Rectangle paramRectangle, boolean paramBoolean) {
    int i = paramRectangle.x + paramRectangle.width;
    int j = paramRectangle.y + paramRectangle.height;
    Rectangle rectangle = this.printBox;
    Rectangle[] arrayOfRectangle1 = this.frames;
    Rectangle[] arrayOfRectangle2 = this.npframes;
    Position position = this.printHead;
    int k = this.currFrame;
    int m = this.current;
    int n = paramStylePage.getPaintableCount();
    for (byte b = 0; b < paramFixedContainer.getElementCount(); b++) {
      Rectangle rectangle1 = paramFixedContainer.getBounds(b);
      BaseElement baseElement = (BaseElement)paramFixedContainer.getElement(b);
      this.printHead = new Position(0.0F, 0.0F);
      this.printBox = new Rectangle(paramRectangle.x + rectangle1.x, paramRectangle.y + rectangle1.y, rectangle1.width, rectangle1.height);
      Point point = new Point(this.printBox.x + this.printBox.width, this.printBox.y + this.printBox.height);
      this.printBox.x = Math.min(i, Math.max(paramRectangle.x, this.printBox.x));
      this.printBox.y = Math.min(j, Math.max(paramRectangle.y, this.printBox.y));
      point.x = Math.min(i, Math.max(paramRectangle.x, point.x));
      point.y = Math.min(j, Math.max(paramRectangle.y, point.y));
      this.printBox.width = point.x - this.printBox.x;
      this.printBox.height = point.y - this.printBox.y;
      this.frames = new Rectangle[] { this.printBox };
      this.npframes = null;
      this.currFrame = 0;
      Vector vector = new Vector();
      vector.addElement(baseElement);
      this.current = 0;
      if (baseElement instanceof PainterElement) {
        PainterElementDef painterElementDef = (PainterElementDef)baseElement;
        Insets insets = painterElementDef.getMargin();
        painterElementDef.setSize(new Size(this.printBox.width - insets.left - insets.right, this.printBox.height - insets.top - insets.bottom, this.resolution));
        painterElementDef.setAnchor(null);
      } 
      if (paramBoolean)
        baseElement.reset(); 
      baseElement.setNonFlow(paramBoolean);
      printNextArea(paramStylePage, vector);
    } 
    for (int i1 = n; i1 < paramStylePage.getPaintableCount(); i1++)
      ((BasePaintable)paramStylePage.getPaintable(i1)).setFrame(paramRectangle); 
    this.printBox = rectangle;
    this.printHead = position;
    this.frames = arrayOfRectangle1;
    this.npframes = arrayOfRectangle2;
    this.currFrame = k;
    this.current = m;
  }
  
  public void setValue(ReportElement paramReportElement, Object paramObject) throws IllegalArgumentException {
    if (paramReportElement instanceof TableElement) {
      if (paramObject instanceof TableLens) {
        ((TableElement)paramReportElement).setTable((TableLens)paramObject);
      } else if (paramObject instanceof FormLens) {
        ((FormXElement)paramReportElement).setForm((FormLens)paramObject);
      } else if (paramObject instanceof Object[][]) {
        TableLens tableLens = ((TableElement)paramReportElement).getTable();
        TableStyle tableStyle = null;
        if (tableLens instanceof TableStyle) {
          tableStyle = (TableStyle)tableLens;
          while (true) {
            tableLens = tableStyle.getTable();
            if (tableLens instanceof TableStyle) {
              tableStyle = (TableStyle)tableLens;
              continue;
            } 
            break;
          } 
        } 
        if (tableLens instanceof DefaultTableLens) {
          ((DefaultTableLens)tableLens).setData((Object[][])paramObject);
        } else if (tableStyle != null) {
          tableStyle.setTable(new DefaultTableLens((Object[][])paramObject));
        } else {
          ((TableElement)paramReportElement).setTable(new DefaultTableLens((Object[][])paramObject));
        } 
      } else {
        throw new IllegalArgumentException("Only TableLens or FormLens can be used in a Table: " + paramObject.getClass());
      } 
      if (paramReportElement instanceof TableXElement) {
        TableStyle tableStyle = ((TableXElement)paramReportElement).getStyle();
        if (tableStyle != null)
          tableStyle.refresh(); 
      } 
    } else if (paramReportElement instanceof SectionElement) {
      if (paramObject instanceof TableLens) {
        ((SectionElement)paramReportElement).setTable((TableLens)paramObject);
      } else if (paramObject instanceof Object[][]) {
        ((SectionElement)paramReportElement).setTable(new DefaultTableLens((Object[][])paramObject));
      } else {
        throw new IllegalArgumentException("Only TableLens can be used in a Section: " + paramObject.getClass());
      } 
    } else if (paramReportElement instanceof ChartElement) {
      if (paramObject instanceof ChartLens) {
        ((ChartElement)paramReportElement).setChart((ChartLens)paramObject);
      } else if (paramObject instanceof TableLens) {
        ((ChartElement)paramReportElement).setChart(new TableChartLens((TableLens)paramObject));
      } else {
        throw new IllegalArgumentException("Only ChartLens can be used in a Chart: " + paramObject.getClass());
      } 
    } else if (paramReportElement instanceof TextBoxElement) {
      if (paramObject instanceof String) {
        ((TextBoxElement)paramReportElement).setText(new DefaultTextLens(paramObject.toString()));
      } else if (paramObject instanceof TextLens) {
        ((TextBoxElement)paramReportElement).setText((TextLens)paramObject);
      } else {
        ((TextBoxElement)paramReportElement).setText(toString(paramObject));
      } 
    } else if (paramReportElement instanceof TextElement) {
      if (paramObject instanceof String) {
        ((TextElement)paramReportElement).setText(new DefaultTextLens(paramObject.toString()));
      } else if (paramObject instanceof TextLens) {
        ((TextElement)paramReportElement).setText((TextLens)paramObject);
      } else {
        ((TextElement)paramReportElement).setText(toString(paramObject));
      } 
    } else if (paramReportElement instanceof ButtonElementDef) {
      ((ButtonElementDef)paramReportElement).setText(toString(paramObject));
    } else if (paramReportElement instanceof CheckBoxElementDef) {
      ((CheckBoxElementDef)paramReportElement).setText(toString(paramObject));
    } else if (paramReportElement instanceof ChoiceElementDef) {
      if (paramObject instanceof Object[]) {
        ((ChoiceElementDef)paramReportElement).setChoices((Object[])paramObject);
      } else {
        ((ChoiceElementDef)paramReportElement).setSelectedItem(paramObject);
      } 
    } else if (paramReportElement instanceof TextFieldElementDef) {
      ((TextFieldElementDef)paramReportElement).setText(toString(paramObject));
    } else if (paramReportElement instanceof TextAreaElementDef) {
      ((TextAreaElementDef)paramReportElement).setText(toString(paramObject));
    } else if (paramReportElement instanceof PainterElementDef) {
      if (paramObject instanceof Image) {
        ((PainterElementDef)paramReportElement).setPainter(new ImagePainter((Image)paramObject));
      } else if (paramObject instanceof Painter) {
        ((PainterElement)paramReportElement).setPainter((Painter)paramObject);
      } else if (paramObject instanceof Component) {
        ((PainterElement)paramReportElement).setPainter(new ComponentPainter((Component)paramObject));
      } else {
        throw new IllegalArgumentException("Only Image, Component, or  Painter can be used in a Painter: " + paramObject.getClass());
      } 
    } else if (paramReportElement instanceof CompositeElement) {
      if (paramObject instanceof inetsoft.report.lens.ElementContainer) {
        ((CompositeElement)paramReportElement).setComposite((CompositeLens)paramObject);
      } else {
        throw new IllegalArgumentException("Only ElementContainer can be used in a Composite: " + paramObject.getClass());
      } 
    } else {
      throw new IllegalArgumentException(paramReportElement + ":" + paramObject);
    } 
  }
  
  public ScriptEnv getScriptEnv() {
    if (this.scriptenv == null)
      this.scriptenv = ScriptEnv.getScriptEnv((StyleSheet)this); 
    return this.scriptenv;
  }
  
  public void runOnLoad() {
    if (this.loadCalled)
      return; 
    this.loadCalled = true;
    String str = this.loadCmd;
    if (str != null)
      try {
        ScriptEnv scriptEnv = getScriptEnv();
        if (this.loadScript == null && scriptEnv != null)
          this.loadScript = scriptEnv.compile(str); 
        if (this.loadScript != null)
          scriptEnv.exec(null, this.loadScript, null); 
      } catch (Exception exception) {
        if (Util.isGUI()) {
          MessageDialog.show(exception + "\n" + str);
        } else {
          System.err.println("onLoad script failed: " + exception);
        } 
        exception.printStackTrace();
      }  
  }
  
  public void setHFTextFormatter(HFTextFormatter paramHFTextFormatter) { this.hfFmt = paramHFTextFormatter; }
  
  public HFTextFormatter getHFTextFormatter() { return this.hfFmt; }
  
  protected String toString(Object paramObject) {
    if (paramObject == null)
      return ""; 
    Format format = getFormat(this.formatmap, paramObject.getClass());
    return (format != null) ? format.format(paramObject) : paramObject.toString();
  }
  
  protected void checkLimit() {
    if (limited && !this.internal && ++counter > this.max_report)
      throw new Error("Style Report/Lite is limited to " + this.max_report + " report(s) per application!"); 
  }
  
  protected Margin margin = new Margin(1.0D, 1.0D, 1.0D, 1.0D);
  
  protected Margin pmargin = new Margin(g_pmargin);
  
  protected static Margin g_pmargin = new Margin(0.0D, 0.0D, 0.0D, 0.0D);
  
  static  {
    try {
      if (ReportEnv.getProperty("os.name").startsWith("Win")) {
        String str = ReportEnv.getProperty("java.version");
        if (str.compareTo("1.1.7") < 0 || (str.compareTo("1.2") >= 0 && str.compareTo("1.2.2") < 0))
          g_pmargin = new Margin(0.25D, 0.25D, 0.25D, 0.25D); 
      } 
    } catch (Exception exception) {}
    limited = false;
    counter = 0;
  }
  
  protected double headerFromEdge = 0.5D;
  
  protected double footerFromEdge = 0.75D;
  
  protected String header = null;
  
  protected int pgStart = 0;
  
  protected int alignment = 1;
  
  protected double indent = 0.0D;
  
  protected Position anchor = null;
  
  protected int hindent = 0;
  
  protected double[] tabStops = { 
      0.5D, 1.0D, 1.5D, 2.0D, 2.5D, 3.0D, 3.5D, 4.0D, 4.5D, 5.0D, 
      5.5D, 6.0D, 6.5D, 7.0D, 7.5D, 8.0D };
  
  protected int spacing = 0;
  
  protected Insets padding = new Insets(1, 1, 1, 1);
  
  protected Font font = new Font("Serif", 0, 10);
  
  protected Color foreground = Color.black;
  
  protected Color background = null;
  
  protected int autosize = 1;
  
  protected int painterLayout = 0;
  
  protected Insets painterMargin = new Insets(1, 1, 1, 1);
  
  protected ChartDescriptor chartinfo = null;
  
  protected double tableW = 0.0D;
  
  protected Hashtable presentermap = new Hashtable();
  
  protected Hashtable formatmap = new Hashtable();
  
  protected boolean justify = false;
  
  protected int textadv = 3;
  
  protected int sepadv = 4;
  
  protected int tableadv = 3;
  
  protected int wrapping = 3;
  
  protected boolean orphan = false;
  
  protected boolean tableorphan = false;
  
  protected int current = 0;
  
  protected Position printHead = new Position(0.0F, 0.0F);
  
  protected float lineH = 0.0F;
  
  protected Rectangle printBox = new Rectangle(72, 72, 468, 648);
  
  protected Rectangle pageBox = new Rectangle(72, 72, 468, 648);
  
  protected Position lastHead = new Position(0.0F, 0.0F);
  
  protected Rectangle[] frames = null;
  
  protected Rectangle[] npframes = null;
  
  protected PageArea[] npareas = null;
  
  protected int currFrame = 0;
  
  protected PageArea[] areas = null;
  
  protected float advanceLine = 0.0F;
  
  protected int[] headingCnt = new int[20];
  
  protected Hashtable headingMap = new Hashtable();
  
  protected int resolution = 72;
  
  protected Hashtable contexts = new Hashtable();
  
  protected Hashtable idmap = new Hashtable();
  
  protected Vector elements = new Vector(50);
  
  protected Hashtable areamap = new Hashtable();
  
  protected Vector headerElements = new Vector();
  
  protected Vector footerElements = new Vector();
  
  protected Vector firstHeader = new Vector();
  
  protected Vector firstFooter = new Vector();
  
  protected Vector evenHeader = new Vector();
  
  protected Vector evenFooter = new Vector();
  
  protected Vector oddHeader = new Vector();
  
  protected Vector oddFooter = new Vector();
  
  protected Hashtable elemHeader = new Hashtable();
  
  protected Hashtable elemFooter = new Hashtable();
  
  protected Vector currHeader = this.headerElements;
  
  protected Vector currFooter = this.footerElements;
  
  protected Vector overrideHeader = null;
  
  protected Vector overrideFooter = null;
  
  protected boolean horFlow = false;
  
  protected boolean designtime = false;
  
  protected Properties prop = new Properties();
  
  protected Object bg;
  
  protected ImageLocation bgimage;
  
  protected String pagebreakCmd = null;
  
  protected Object pagebreakScript = null;
  
  protected String loadCmd = null;
  
  protected boolean loadCalled = false;
  
  protected Object loadScript = null;
  
  protected ScriptEnv scriptenv = null;
  
  protected HFTextFormatter hfFmt = null;
  
  private static boolean limited;
  
  private static int counter;
  
  private boolean internal = false;
  
  private int max_report = 1;
  
  private int max_row = 50;
  
  public static boolean isLimited() { return limited; }
  
  protected int getMaxRows() { return this.max_row; }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
    paramObjectInputStream.defaultReadObject();
    char c = paramObjectInputStream.readChar();
    if (c == 'I') {
      byte[] arrayOfByte = (byte[])paramObjectInputStream.readObject();
      if (arrayOfByte != null) {
        int i = paramObjectInputStream.readInt();
        int j = paramObjectInputStream.readInt();
        this.bg = Encoder.decodeImage(i, j, arrayOfByte);
      } 
    } else {
      this.bg = paramObjectInputStream.readObject();
    } 
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    paramObjectOutputStream.defaultWriteObject();
    if (this.bg instanceof Image) {
      paramObjectOutputStream.writeChar(73);
      Image image = (Image)this.bg;
      byte[] arrayOfByte = Encoder.encodeImage(image);
      paramObjectOutputStream.writeObject(arrayOfByte);
      if (arrayOfByte != null) {
        paramObjectOutputStream.writeInt(image.getWidth(null));
        paramObjectOutputStream.writeInt(image.getHeight(null));
      } 
    } else {
      paramObjectOutputStream.writeChar(79);
      paramObjectOutputStream.writeObject(this.bg);
    } 
  }
  
  protected abstract boolean printNextArea(StylePage paramStylePage, Vector paramVector);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\StyleCore.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */