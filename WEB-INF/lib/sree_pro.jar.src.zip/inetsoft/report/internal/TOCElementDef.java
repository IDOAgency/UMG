package inetsoft.report.internal;

import inetsoft.report.StyleSheet;
import inetsoft.report.TOC;
import inetsoft.report.TOCElement;
import java.awt.Font;

public class TOCElementDef extends CompositeElementDef implements TOCElement {
  private TOC toc;
  
  public TOCElementDef(StyleSheet paramStyleSheet, TOC paramTOC) {
    super(paramStyleSheet, null);
    setComposite(new TOCLens(paramStyleSheet, paramTOC));
    this.toc = paramTOC;
  }
  
  public void setStyleSheet(StyleSheet paramStyleSheet) {
    super.setStyleSheet(paramStyleSheet);
    ((TOCLens)getComposite()).setStyleSheet(paramStyleSheet);
  }
  
  public TOC getTOC() { return this.toc; }
  
  public void setTOC(TOC paramTOC) { setComposite(new TOCLens(this.report, this.toc = paramTOC)); }
  
  public Font getFont() { return TOC.getBaseFont(); }
  
  public void setFont(Font paramFont) { TOC.setBaseFont(paramFont); }
  
  public String getType() { return "TOC"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TOCElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */