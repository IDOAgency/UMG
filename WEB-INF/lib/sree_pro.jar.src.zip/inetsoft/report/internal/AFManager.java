package inetsoft.report.internal;

import java.io.Serializable;

public class AFManager implements Serializable {
  public static AFontMetrics getFontMetrics(String paramString, int paramInt) {
    paramString = paramString.toLowerCase().replace('-', '_');
    String str = "inetsoft.report.afm." + paramString;
    try {
      AFontMetrics aFontMetrics = (AFontMetrics)Class.forName(str).newInstance();
      aFontMetrics.setSize(paramInt);
      return aFontMetrics;
    } catch (ClassNotFoundException classNotFoundException) {
    
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\AFManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */