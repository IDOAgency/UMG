/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AFManager
/*    */   implements Serializable
/*    */ {
/*    */   public static AFontMetrics getFontMetrics(String paramString, int paramInt) {
/* 37 */     paramString = paramString.toLowerCase().replace('-', '_');
/* 38 */     String str = "inetsoft.report.afm." + paramString;
/*    */     try {
/* 40 */       AFontMetrics aFontMetrics = (AFontMetrics)Class.forName(str).newInstance();
/* 41 */       aFontMetrics.setSize(paramInt);
/* 42 */       return aFontMetrics;
/* 43 */     } catch (ClassNotFoundException classNotFoundException) {
/*    */     
/*    */     } catch (Exception exception) {
/* 46 */       exception.printStackTrace();
/*    */     } 
/*    */     
/* 49 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\AFManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */