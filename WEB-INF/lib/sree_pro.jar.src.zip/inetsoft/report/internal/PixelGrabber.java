/*      */ package inetsoft.report.internal;
/*      */ 
/*      */ import java.awt.Image;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.awt.image.ImageConsumer;
/*      */ import java.awt.image.ImageProducer;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class PixelGrabber
/*      */   implements ImageConsumer
/*      */ {
/*      */   ImageProducer producer;
/*      */   int dstX;
/*      */   int dstY;
/*      */   int dstW;
/*      */   int dstH;
/*      */   ColorModel imageModel;
/*      */   byte[] bytePixels;
/*      */   int[] intPixels;
/*      */   int dstOff;
/*      */   int dstScan;
/*      */   private boolean grabbing;
/*      */   private int flags;
/*      */   private final int GRABBEDBITS = 48;
/*      */   private final int DONEBITS = 112;
/*      */   
/* 1409 */   public PixelGrabber(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt, int paramInt5, int paramInt6) { this(paramImage.getSource(), paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt, paramInt5, paramInt6); }
/*      */   
/*      */   public PixelGrabber(ImageProducer paramImageProducer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt, int paramInt5, int paramInt6) {
/*      */     this.GRABBEDBITS = 48;
/*      */     this.DONEBITS = 112;
/* 1414 */     this.producer = paramImageProducer;
/* 1415 */     this.dstX = paramInt1;
/* 1416 */     this.dstY = paramInt2;
/* 1417 */     this.dstW = paramInt3;
/* 1418 */     this.dstH = paramInt4;
/* 1419 */     this.dstOff = paramInt5;
/* 1420 */     this.dstScan = paramInt6;
/* 1421 */     this.intPixels = paramArrayOfInt;
/*      */   }
/*      */   
/*      */   public void startGrabbing() {
/* 1425 */     if ((this.flags & 0x70) != 0) {
/*      */       return;
/*      */     }
/* 1428 */     if (!this.grabbing) {
/* 1429 */       this.grabbing = true;
/* 1430 */       this.flags &= 0xFFFFFF7F;
/* 1431 */       this.producer.startProduction(this);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 1436 */   public void abortGrabbing() { imageComplete(4); }
/*      */ 
/*      */ 
/*      */   
/* 1440 */   public boolean grabPixels() throws InterruptedException { return grabPixels(0L); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean grabPixels(long paramLong) throws InterruptedException {
/* 1446 */     if ((this.flags & 0x70) != 0) {
/* 1447 */       return ((this.flags & 0x30) != 0);
/*      */     }
/* 1449 */     long l = paramLong + System.currentTimeMillis();
/* 1450 */     if (!this.grabbing) {
/* 1451 */       this.grabbing = true;
/* 1452 */       this.flags &= 0xFFFFFF7F;
/* 1453 */       this.producer.startProduction(this);
/*      */     } 
/* 1455 */     while (this.grabbing) {
/*      */       long l1;
/* 1457 */       if (paramLong == 0L) {
/* 1458 */         l1 = 0L;
/*      */       } else {
/* 1460 */         l1 = l - System.currentTimeMillis();
/* 1461 */         if (l1 <= 0L) {
/*      */           break;
/*      */         }
/*      */       } 
/* 1465 */       wait(l1);
/*      */     } 
/* 1467 */     return ((this.flags & 0x30) != 0);
/*      */   }
/*      */ 
/*      */   
/* 1471 */   public int getStatus() { return this.flags; }
/*      */ 
/*      */ 
/*      */   
/* 1475 */   public int getWidth() { return (this.dstW < 0) ? -1 : this.dstW; }
/*      */ 
/*      */ 
/*      */   
/* 1479 */   public int getHeight() { return (this.dstH < 0) ? -1 : this.dstH; }
/*      */ 
/*      */ 
/*      */   
/* 1483 */   public Object getPixels() { return (this.bytePixels == null) ? this.intPixels : this.bytePixels; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1489 */   public ColorModel getColorModel() { return this.imageModel; }
/*      */ 
/*      */   
/*      */   public void setDimensions(int paramInt1, int paramInt2) {
/* 1493 */     if (this.dstW < 0) {
/* 1494 */       this.dstW = paramInt1 - this.dstX;
/*      */     }
/* 1496 */     if (this.dstH < 0) {
/* 1497 */       this.dstH = paramInt2 - this.dstY;
/*      */     }
/* 1499 */     if (this.dstW <= 0 || this.dstH <= 0) {
/* 1500 */       imageComplete(3);
/* 1501 */     } else if (this.intPixels == null) {
/* 1502 */       this.intPixels = new int[this.dstW * this.dstH];
/* 1503 */       this.dstScan = this.dstW;
/* 1504 */       this.dstOff = 0;
/*      */     } 
/* 1506 */     this.flags |= 0x3;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHints(int paramInt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProperties(Hashtable paramHashtable) {}
/*      */ 
/*      */   
/*      */   public void setColorModel(ColorModel paramColorModel) {}
/*      */ 
/*      */   
/*      */   private void convertToRGB() {
/* 1522 */     int i = this.dstW * this.dstH;
/* 1523 */     int[] arrayOfInt = new int[i];
/* 1524 */     if (this.bytePixels != null) {
/* 1525 */       for (byte b = 0; b < i; b++) {
/* 1526 */         arrayOfInt[b] = this.imageModel.getRGB(this.bytePixels[b] & 0xFF);
/*      */       }
/* 1528 */     } else if (this.intPixels != null) {
/* 1529 */       for (byte b = 0; b < i; b++) {
/* 1530 */         arrayOfInt[b] = this.imageModel.getRGB(this.intPixels[b]);
/*      */       }
/*      */     } 
/* 1533 */     this.bytePixels = null;
/* 1534 */     this.intPixels = arrayOfInt;
/* 1535 */     this.dstScan = this.dstW;
/* 1536 */     this.dstOff = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4, ColorModel paramColorModel, byte[] paramArrayOfByte, int paramInt5, int paramInt6) {
/* 1542 */     if (paramInt2 < this.dstY) {
/* 1543 */       int j = this.dstY - paramInt2;
/* 1544 */       if (j >= paramInt4) {
/*      */         return;
/*      */       }
/* 1547 */       paramInt5 += paramInt6 * j;
/* 1548 */       paramInt2 += j;
/* 1549 */       paramInt4 -= j;
/*      */     } 
/* 1551 */     if (paramInt2 + paramInt4 > this.dstY + this.dstH) {
/* 1552 */       paramInt4 = this.dstY + this.dstH - paramInt2;
/* 1553 */       if (paramInt4 <= 0) {
/*      */         return;
/*      */       }
/*      */     } 
/* 1557 */     if (paramInt1 < this.dstX) {
/* 1558 */       int j = this.dstX - paramInt1;
/* 1559 */       if (j >= paramInt3) {
/*      */         return;
/*      */       }
/* 1562 */       paramInt5 += j;
/* 1563 */       paramInt1 += j;
/* 1564 */       paramInt3 -= j;
/*      */     } 
/* 1566 */     if (paramInt1 + paramInt3 > this.dstX + this.dstW) {
/* 1567 */       paramInt3 = this.dstX + this.dstW - paramInt1;
/* 1568 */       if (paramInt3 <= 0) {
/*      */         return;
/*      */       }
/*      */     } 
/* 1572 */     int i = this.dstOff + (paramInt2 - this.dstY) * this.dstScan + paramInt1 - this.dstX;
/* 1573 */     if (this.intPixels == null) {
/* 1574 */       if (this.bytePixels == null) {
/* 1575 */         this.bytePixels = new byte[this.dstW * this.dstH];
/* 1576 */         this.dstScan = this.dstW;
/* 1577 */         this.dstOff = 0;
/* 1578 */         this.imageModel = paramColorModel;
/* 1579 */       } else if (this.imageModel != paramColorModel) {
/* 1580 */         convertToRGB();
/*      */       } 
/* 1582 */       if (this.bytePixels != null) {
/* 1583 */         for (int j = paramInt4; j > 0; j--) {
/* 1584 */           System.arraycopy(paramArrayOfByte, paramInt5, this.bytePixels, i, paramInt3);
/* 1585 */           paramInt5 += paramInt6;
/* 1586 */           i += this.dstScan;
/*      */         } 
/*      */       }
/*      */     } 
/* 1590 */     if (this.intPixels != null) {
/* 1591 */       int j = this.dstScan - paramInt3;
/* 1592 */       int k = paramInt6 - paramInt3;
/* 1593 */       for (int m = paramInt4; m > 0; m--) {
/* 1594 */         for (int n = paramInt3; n > 0; n--) {
/* 1595 */           this.intPixels[i++] = paramColorModel.getRGB(paramArrayOfByte[paramInt5++] & 0xFF);
/*      */         }
/* 1597 */         paramInt5 += k;
/* 1598 */         i += j;
/*      */       } 
/*      */     } 
/* 1601 */     this.flags |= 0x8;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4, ColorModel paramColorModel, int[] paramArrayOfInt, int paramInt5, int paramInt6) {
/* 1611 */     if (paramInt2 < this.dstY) {
/* 1612 */       int j = this.dstY - paramInt2;
/* 1613 */       if (j >= paramInt4) {
/*      */         return;
/*      */       }
/* 1616 */       paramInt5 += paramInt6 * j;
/* 1617 */       paramInt2 += j;
/* 1618 */       paramInt4 -= j;
/*      */     } 
/* 1620 */     if (paramInt2 + paramInt4 > this.dstY + this.dstH) {
/* 1621 */       paramInt4 = this.dstY + this.dstH - paramInt2;
/* 1622 */       if (paramInt4 <= 0) {
/*      */         return;
/*      */       }
/*      */     } 
/* 1626 */     if (paramInt1 < this.dstX) {
/* 1627 */       int j = this.dstX - paramInt1;
/* 1628 */       if (j >= paramInt3) {
/*      */         return;
/*      */       }
/* 1631 */       paramInt5 += j;
/* 1632 */       paramInt1 += j;
/* 1633 */       paramInt3 -= j;
/*      */     } 
/* 1635 */     if (paramInt1 + paramInt3 > this.dstX + this.dstW) {
/* 1636 */       paramInt3 = this.dstX + this.dstW - paramInt1;
/* 1637 */       if (paramInt3 <= 0) {
/*      */         return;
/*      */       }
/*      */     } 
/* 1641 */     if (this.intPixels == null) {
/* 1642 */       if (this.bytePixels == null) {
/* 1643 */         this.intPixels = new int[this.dstW * this.dstH];
/* 1644 */         this.dstScan = this.dstW;
/* 1645 */         this.dstOff = 0;
/* 1646 */         this.imageModel = paramColorModel;
/*      */       } else {
/* 1648 */         convertToRGB();
/*      */       } 
/*      */     }
/* 1651 */     int i = this.dstOff + (paramInt2 - this.dstY) * this.dstScan + paramInt1 - this.dstX;
/* 1652 */     if (this.imageModel == paramColorModel) {
/* 1653 */       for (int j = paramInt4; j > 0; j--) {
/* 1654 */         System.arraycopy(paramArrayOfInt, paramInt5, this.intPixels, i, paramInt3);
/* 1655 */         paramInt5 += paramInt6;
/* 1656 */         i += this.dstScan;
/*      */       } 
/*      */     } else {
/* 1659 */       int j = this.dstScan - paramInt3;
/* 1660 */       int k = paramInt6 - paramInt3;
/* 1661 */       for (int m = paramInt4; m > 0; m--) {
/* 1662 */         for (int n = paramInt3; n > 0; n--) {
/* 1663 */           this.intPixels[i++] = paramColorModel.getRGB(paramArrayOfInt[paramInt5++]);
/*      */         }
/* 1665 */         paramInt5 += k;
/* 1666 */         i += j;
/*      */       } 
/*      */     } 
/* 1669 */     this.flags |= 0x8;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void imageComplete(int paramInt) {
/* 1677 */     this.grabbing = false;
/* 1678 */     switch (paramInt) {
/*      */       
/*      */       default:
/* 1681 */         this.flags |= 0xC0;
/*      */         break;
/*      */       case 4:
/* 1684 */         this.flags |= 0x80;
/*      */         break;
/*      */       case 3:
/* 1687 */         this.flags |= 0x20;
/*      */         break;
/*      */       case 2:
/* 1690 */         this.flags |= 0x10;
/*      */         break;
/*      */     } 
/* 1693 */     this.producer.removeConsumer(this);
/* 1694 */     notifyAll();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1701 */   public int status() { return this.flags; }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\PixelGrabber.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */