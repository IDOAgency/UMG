/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.PSPrinter;
/*     */ import inetsoft.report.Painter;
/*     */ import inetsoft.report.PreviewPage;
/*     */ import inetsoft.report.PreviewView;
/*     */ import inetsoft.report.Previewer;
/*     */ import inetsoft.report.ReportEnv;
/*     */ import inetsoft.report.StyleConstants;
/*     */ import inetsoft.report.StyleFont;
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.Win32Printer;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.report.painter.ImagePainter;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Polygon;
/*     */ import java.awt.PrintJob;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ import java.awt.image.FilteredImageSource;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.awt.image.MemoryImageSource;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ public class Gop
/*     */   implements StyleConstants {
/*  36 */   private static Gop gop = null;
/*     */   
/*     */   private static boolean swing = false;
/*     */   
/*     */   Image buffer;
/*     */   
/*     */   public static Gop getInstance() {
/*  43 */     if (gop == null) {
/*     */       
/*  45 */       try { Class.forName("java.awt.JobAttributes");
/*  46 */         gop = (Gop)Class.forName("inetsoft.report.internal.j2d.Gop1_3").newInstance();
/*     */          }
/*     */       
/*  49 */       catch (Throwable throwable) { try {
/*  50 */           Class.forName("java.awt.Graphics2D");
/*  51 */           gop = (Gop)Class.forName("inetsoft.report.internal.j2d.Gop2D").newInstance();
/*     */         }
/*     */         catch (Throwable throwable1) {
/*     */           
/*  55 */           gop = new Gop();
/*     */         }  }
/*     */ 
/*     */       
/*     */       try {
/*  60 */         Class.forName("javax.swing.JFrame");
/*  61 */         swing = true;
/*     */       } catch (Throwable throwable) {
/*     */         
/*  64 */         swing = false;
/*     */       } 
/*     */     } 
/*     */     
/*  68 */     return gop;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public boolean isJava2() { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public StyleSheet createStyleSheet() { return new StyleSheet(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreviewView getPreviewView() {
/*     */     try {
/*  91 */       if (swing) {
/*  92 */         return (PreviewView)Class.forName("inetsoft.report.j2d.JPreviewer").newInstance();
/*     */       
/*     */       }
/*     */     }
/*  96 */     catch (Exception exception) {}
/*     */ 
/*     */     
/*  99 */     return new Previewer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(StyleSheet paramStyleSheet) throws Exception {
/* 106 */     PrintJob printJob = Common.getToolkit().getPrintJob(Common.getInvisibleFrame(), Catalog.getString("Report"), null);
/*     */ 
/*     */     
/* 109 */     if (printJob != null) {
/* 110 */       paramStyleSheet.print(printJob);
/* 111 */       printJob.end();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(String paramString, Enumeration paramEnumeration, boolean paramBoolean) throws Exception {
/* 121 */     PrintJob printJob = null;
/*     */     
/* 123 */     if (paramString == null) {
/* 124 */       printJob = Common.getToolkit().getPrintJob(Common.getInvisibleFrame(), Catalog.getString("Report"), null);
/*     */ 
/*     */     
/*     */     }
/* 128 */     else if (ReportEnv.getProperty("os.name").startsWith("Windows")) {
/* 129 */       Win32Printer win32Printer = Win32Printer.getPrinter(paramString);
/* 130 */       if (win32Printer != null) {
/* 131 */         printJob = win32Printer.getPrintJob();
/*     */       }
/*     */     }
/* 134 */     else if (ReportEnv.getProperty("os.name").startsWith("Solaris") || ReportEnv.getProperty("os.name").startsWith("SunOS")) {
/*     */       
/* 136 */       String str = "lp -d\"" + paramString + "\"";
/* 137 */       PSPrinter pSPrinter = new PSPrinter(str);
/* 138 */       printJob = pSPrinter.getPrintJob();
/*     */     } 
/*     */     
/* 141 */     if (printJob != null) {
/* 142 */       while (paramEnumeration.hasMoreElements()) {
/* 143 */         StylePage stylePage = (StylePage)paramEnumeration.nextElement();
/* 144 */         Graphics graphics = printJob.getGraphics();
/* 145 */         stylePage.print(graphics);
/* 146 */         graphics.dispose();
/*     */       } 
/*     */       
/* 149 */       printJob.end();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public float getLineAdjustment(Graphics paramGraphics) { return 0.0F; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public boolean isGraphics2D(Graphics paramGraphics) { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawHLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, int paramInt3) {
/* 182 */     float f1 = getLineWidth(paramInt1);
/* 183 */     float f2 = Math.min(paramFloat2, paramFloat3), f3 = Math.max(paramFloat2, paramFloat3);
/* 184 */     paramFloat2 = f2; paramFloat3 = f3;
/*     */     
/* 186 */     if ((paramInt1 & 0x1000) != 0) {
/* 187 */       float f = Math.min(getLineWidth(paramInt2), getLineWidth(paramInt3));
/*     */       
/* 189 */       if ((paramInt1 & 0xF0) != 0) {
/* 190 */         boolean bool = true;
/* 191 */         int i = (paramInt1 & 0xF0) >> 4;
/*     */         
/* 193 */         for (float f4 = paramFloat2 + f; f4 <= paramFloat3; f4 += i, bool = !bool ? 1 : 0) {
/* 194 */           if (bool) {
/* 195 */             drawLine(paramGraphics, f4, paramFloat1, Math.min(paramFloat3, f4 + i - 1.0F), paramFloat1, 4097);
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 200 */         int i = ((paramInt1 & 0xF0000) != 0) ? paramInt1 : 4097;
/*     */         
/* 202 */         for (byte b = 0; b < f1; b++) {
/* 203 */           drawLine(paramGraphics, paramFloat2 + f, paramFloat1 + b, paramFloat3, paramFloat1 + b, i);
/*     */         }
/*     */       }
/*     */     
/* 207 */     } else if ((paramInt1 & 0x2000) != 0) {
/* 208 */       Color color = paramGraphics.getColor();
/* 209 */       if (color == null) {
/* 210 */         color = new Color(0, 0, 0);
/*     */       }
/*     */       
/* 213 */       if ((paramInt1 & 0x4000) != 0) {
/* 214 */         paramGraphics.setColor(Util.brighter(color));
/*     */       }
/* 216 */       else if ((paramInt1 & 0x8000) != 0) {
/* 217 */         paramGraphics.setColor(Util.darker(color));
/*     */       } 
/*     */       
/* 220 */       float f = getLineWidth(paramInt2);
/* 221 */       if (paramFloat2 + f <= paramFloat3) {
/* 222 */         drawLine(paramGraphics, paramFloat2 + f, paramFloat1, paramFloat3, paramFloat1, 4097);
/*     */       }
/*     */       
/* 225 */       if ((paramInt1 & 0x4000) != 0) {
/* 226 */         paramGraphics.setColor(Util.darker(color));
/*     */       }
/* 228 */       else if ((paramInt1 & 0x8000) != 0) {
/* 229 */         paramGraphics.setColor(Util.brighter(color));
/*     */       } 
/*     */       
/* 232 */       f = getLineWidth(paramInt3);
/*     */       
/* 234 */       f = (f > 0.0F) ? (f - 1.0F) : f;
/* 235 */       if (paramFloat2 + f <= paramFloat3) {
/* 236 */         drawLine(paramGraphics, paramFloat2 + f, paramFloat1 + f1 - 1.0F, paramFloat3, paramFloat1 + f1 - 1.0F, 4097);
/*     */       }
/*     */       
/* 239 */       paramGraphics.setColor(color);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawVLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, int paramInt3) {
/* 256 */     float f1 = getLineWidth(paramInt1);
/* 257 */     float f2 = Math.min(paramFloat2, paramFloat3), f3 = Math.max(paramFloat2, paramFloat3);
/* 258 */     paramFloat2 = f2; paramFloat3 = f3;
/*     */     
/* 260 */     if ((paramInt1 & 0x1000) != 0) {
/*     */       
/* 262 */       float f = ((paramInt2 & 0x1000) != 0 || (paramInt3 & 0x1000) != 0) ? 0.0F : Math.min(getLineWidth(paramInt2), getLineWidth(paramInt3));
/*     */ 
/*     */       
/* 265 */       if ((paramInt1 & 0xF0) != 0) {
/* 266 */         boolean bool = true;
/* 267 */         int i = (paramInt1 & 0xF0) >> 4;
/*     */         
/* 269 */         for (float f4 = paramFloat2 + f; f4 <= paramFloat3; f4 += i, bool = !bool ? 1 : 0) {
/* 270 */           if (bool) {
/* 271 */             drawLine(paramGraphics, paramFloat1, f4, paramFloat1, Math.min(paramFloat3, f4 + i - 1.0F), 4097);
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 276 */         int i = ((paramInt1 & 0xF0000) != 0) ? paramInt1 : 4097;
/*     */         
/* 278 */         for (byte b = 0; b < f1; b++) {
/* 279 */           drawLine(paramGraphics, paramFloat1 + b, paramFloat2 + f, paramFloat1 + b, paramFloat3, i);
/*     */         }
/*     */       }
/*     */     
/* 283 */     } else if (paramInt1 != 0) {
/* 284 */       Color color = paramGraphics.getColor();
/* 285 */       if ((paramInt1 & 0x4000) != 0) {
/* 286 */         paramGraphics.setColor(Util.brighter(color));
/*     */       }
/* 288 */       else if ((paramInt1 & 0x8000) != 0) {
/* 289 */         paramGraphics.setColor(Util.darker(color));
/*     */       } 
/*     */       
/* 292 */       float f = getLineWidth(paramInt2);
/* 293 */       f = (f > 0.0F) ? (f - 1.0F) : f;
/* 294 */       if (paramFloat2 + f <= paramFloat3) {
/* 295 */         drawLine(paramGraphics, paramFloat1, paramFloat2 + f, paramFloat1, paramFloat3, 4097);
/*     */       }
/*     */       
/* 298 */       if ((paramInt1 & 0x4000) != 0) {
/* 299 */         paramGraphics.setColor(Util.darker(color));
/*     */       }
/* 301 */       else if ((paramInt1 & 0x8000) != 0) {
/* 302 */         paramGraphics.setColor(Util.brighter(color));
/*     */       } 
/*     */       
/* 305 */       f = getLineWidth(paramInt3);
/* 306 */       if (paramFloat2 + f <= paramFloat3) {
/* 307 */         drawLine(paramGraphics, paramFloat1 + f1 - 1.0F, paramFloat2 + f, paramFloat1 + f1 - 1.0F, paramFloat3, 4097);
/*     */       }
/*     */       
/* 310 */       paramGraphics.setColor(color);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 319 */   public void drawLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt) { drawLine(paramGraphics, round(paramFloat1), round(paramFloat2), round(paramFloat3), round(paramFloat4)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 326 */   public void drawLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) { paramGraphics.drawLine(round(paramFloat1), round(paramFloat2), round(paramFloat3), round(paramFloat4)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fillRect(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 337 */     Bounds bounds = (new Bounds(paramFloat1, paramFloat2, paramFloat3, paramFloat4)).round();
/* 338 */     paramGraphics.fillRect(round(bounds.x), round(bounds.y), round(bounds.width), round(bounds.height));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fillArc(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, Object paramObject) {
/*     */     try {
/* 348 */       paramGraphics.setColor((Color)paramObject);
/*     */     } catch (Exception exception) {
/* 350 */       paramGraphics.setColor(Color.gray);
/*     */     } 
/*     */     
/* 353 */     paramGraphics.fillArc((int)paramFloat1, (int)paramFloat2, (int)paramFloat3, (int)paramFloat4, (int)paramFloat5, round(paramFloat6));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fill(Graphics paramGraphics, Shape paramShape, Object paramObject) {
/* 363 */     Color color = paramGraphics.getColor();
/*     */     try {
/* 365 */       paramGraphics.setColor((Color)paramObject);
/*     */     } catch (Exception exception) {
/* 367 */       paramGraphics.setColor(Color.gray);
/*     */     } 
/*     */     
/* 370 */     if (paramShape instanceof Rectangle) {
/* 371 */       Rectangle rectangle = (Rectangle)paramShape;
/* 372 */       paramGraphics.fillRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*     */     }
/* 374 */     else if (paramShape instanceof Polygon) {
/* 375 */       paramGraphics.fillPolygon((Polygon)paramShape);
/*     */     } 
/*     */     
/* 378 */     paramGraphics.setColor(color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClip(Graphics paramGraphics, Bounds paramBounds) {
/* 387 */     Bounds bounds = paramBounds.round();
/* 388 */     paramGraphics.setClip(round(bounds.x), round(bounds.y), round(bounds.width), round(bounds.height));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clipRect(Graphics paramGraphics, Bounds paramBounds) {
/* 398 */     Bounds bounds = paramBounds.round();
/* 399 */     paramGraphics.clipRect((int)bounds.x, (int)bounds.y, round(bounds.width), round(bounds.height));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawImage(Graphics paramGraphics, Image paramImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, ImageObserver paramImageObserver) {
/* 415 */     Dimension dimension = new Dimension(paramImage.getWidth(null), paramImage.getHeight(null));
/* 416 */     String str = ReportEnv.getProperty("StyleReport.ditherImage");
/*     */ 
/*     */     
/* 419 */     if (paramImage instanceof MetaImage) {
/* 420 */       paramImage = ((MetaImage)paramImage).getImage();
/*     */     }
/*     */     
/* 423 */     if (paramFloat3 > 0.0F && paramFloat4 > 0.0F && dimension.width != round(paramFloat3) && dimension.height != round(paramFloat4) && str != null && str.equals("true"))
/*     */     {
/* 425 */       paramImage = paramImage.getScaledInstance(round(paramFloat3), round(paramFloat4), 4);
/*     */     }
/*     */     
/* 428 */     paramGraphics.drawImage(paramImage, round(paramFloat1), round(paramFloat2), round(paramFloat3), round(paramFloat4), paramImageObserver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rotate(Graphics paramGraphics, double paramDouble) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 441 */   public void paintPage(Graphics paramGraphics, PreviewPage paramPreviewPage) { PreviewPage.paintPage(paramGraphics, paramPreviewPage); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Image createImage(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
/* 448 */     int[] arrayOfInt = new int[paramInt1 * paramInt2];
/*     */     
/* 450 */     byte b1 = 0, b2 = 0;
/* 451 */     for (byte b3 = 0; b3 < paramInt2; b3++) {
/* 452 */       for (byte b = 0; b < paramInt1; b++) {
/* 453 */         byte b4 = paramArrayOfByte[b1++] & 0xFF;
/* 454 */         byte b5 = paramArrayOfByte[b1++] & 0xFF;
/* 455 */         byte b6 = paramArrayOfByte[b1++] & 0xFF;
/* 456 */         arrayOfInt[b2++] = 0xFF000000 | b4 << 16 | b5 << 8 | b6;
/*     */       } 
/*     */     } 
/*     */     
/* 460 */     return Common.getToolkit().createImage(new MemoryImageSource(paramInt1, paramInt2, arrayOfInt, 0, paramInt1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 470 */   public Object getPaint(int paramInt) { return Common.getColor(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getHeight(Font paramFont, FontMetrics paramFontMetrics) {
/* 482 */     if (paramFontMetrics == null) {
/* 483 */       paramFontMetrics = Common.getFontMetrics(paramFont);
/*     */     }
/*     */     
/* 486 */     int i = paramFontMetrics.getHeight() - paramFontMetrics.getLeading();
/*     */     
/* 488 */     if (paramFont instanceof StyleFont) {
/* 489 */       StyleFont styleFont = (StyleFont)paramFont;
/*     */       
/* 491 */       if ((styleFont.getStyle() & 0x10) != 0) {
/* 492 */         return i + getLineWidth(styleFont.getLineStyle()) - 1.0F;
/*     */       }
/*     */     } 
/*     */     
/* 496 */     return adjustHeight(paramFont, i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 506 */   public float stringWidth(String paramString, Font paramFont, FontMetrics paramFontMetrics) { return adjustSpacing(paramFont, paramFontMetrics.stringWidth(paramString)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 525 */   public float getAscent(FontMetrics paramFontMetrics) { return paramFontMetrics.getAscent(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 536 */   public void drawString(Graphics paramGraphics, String paramString, float paramFloat1, float paramFloat2) { paramGraphics.drawString(paramString, round(paramFloat1), round(paramFloat2)); }
/*     */ 
/*     */ 
/*     */   
/* 540 */   Dimension bSize = new Dimension(-1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Painter paramPainter, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, Color paramColor1, Color paramColor2) {
/* 564 */     if (paramFloat3 == paramFloat7 && paramFloat4 == paramFloat8) {
/* 565 */       Shape shape = paramGraphics.getClip();
/* 566 */       Color color = paramGraphics.getColor();
/*     */       
/* 568 */       paramGraphics.translate(round(paramFloat1), round(paramFloat2));
/* 569 */       paramGraphics.clipRect(0, 0, round(paramFloat3), round(paramFloat4));
/*     */ 
/*     */ 
/*     */       
/* 573 */       paramGraphics.setColor((paramColor2 == null) ? Color.white : paramColor2);
/* 574 */       paramGraphics.fillRect(0, 0, round(paramFloat3), round(paramFloat4));
/*     */       
/* 576 */       paramGraphics.setColor(paramColor1);
/* 577 */       paramPainter.paint(paramGraphics, (int)paramFloat5, (int)paramFloat6, (int)paramFloat7, (int)paramFloat8);
/*     */       
/* 579 */       paramGraphics.translate(-round(paramFloat1), -round(paramFloat2));
/* 580 */       paramGraphics.setClip(shape);
/* 581 */       paramGraphics.setColor(color);
/*     */ 
/*     */     
/*     */     }
/* 585 */     else if (paramPainter instanceof ImagePainter) {
/* 586 */       Image image = ((ImagePainter)paramPainter).getImage();
/* 587 */       boolean bool = ((ImagePainter)paramPainter).isFit();
/*     */       
/* 589 */       if (image instanceof MetaImage) {
/* 590 */         image = ((MetaImage)image).getImage();
/*     */       }
/*     */ 
/*     */       
/* 594 */       if (image != null) {
/* 595 */         Shape shape = paramGraphics.getClip();
/* 596 */         Color color = paramGraphics.getColor();
/*     */         
/* 598 */         paramGraphics.translate((int)paramFloat1, (int)paramFloat2);
/* 599 */         paramGraphics.clipRect(0, 0, (int)paramFloat3, (int)paramFloat4);
/*     */         
/* 601 */         if (paramColor2 != null) {
/* 602 */           paramGraphics.setColor(paramColor2);
/* 603 */           paramGraphics.fillRect(0, 0, (int)paramFloat3, (int)paramFloat4);
/*     */         } 
/*     */         
/* 606 */         float f1 = paramFloat3 / paramFloat7;
/* 607 */         float f2 = paramFloat4 / paramFloat9;
/*     */ 
/*     */         
/* 610 */         if (bool) {
/* 611 */           Common.drawImage(paramGraphics, image, paramFloat5 * f1, paramFloat6 * f2, paramFloat7 * f1, paramFloat8 * f2, null);
/*     */         }
/*     */         else {
/*     */           
/* 615 */           Common.drawImage(paramGraphics, image, paramFloat5 * f1, paramFloat6 * f2, 0.0F, 0.0F, null);
/*     */         } 
/*     */         
/* 618 */         paramGraphics.translate(-((int)paramFloat1), -((int)paramFloat2));
/* 619 */         paramGraphics.setClip(shape);
/* 620 */         paramGraphics.setColor(color);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 625 */       if (round(paramFloat7) != this.bSize.width || round(paramFloat9) != this.bSize.height) {
/* 626 */         this.bSize = new Dimension(round(paramFloat7), round(paramFloat9));
/* 627 */         this.buffer = Common.createImage(this.bSize.width, this.bSize.height);
/*     */       } 
/*     */       
/* 630 */       Graphics graphics = this.buffer.getGraphics();
/* 631 */       graphics.setClip(0, 0, this.bSize.width, this.bSize.height);
/*     */       
/* 633 */       graphics.setColor((paramColor2 == null) ? Color.white : paramColor2);
/* 634 */       graphics.fillRect(0, 0, this.bSize.width, this.bSize.height);
/*     */       
/* 636 */       graphics.setColor(paramColor1);
/* 637 */       paramPainter.paint(graphics, round(paramFloat5), round(paramFloat6), round(paramFloat7), round(paramFloat8));
/* 638 */       graphics.dispose();
/*     */       
/* 640 */       if (paramGraphics instanceof CustomGraphics) {
/* 641 */         Common.drawImage(paramGraphics, this.buffer, paramFloat1, paramFloat2, paramFloat3, paramFloat4, null);
/*     */       }
/*     */       else {
/*     */         
/* 645 */         Common.drawImage(paramGraphics, Common.getToolkit().createImage(this.buffer.getSource()), paramFloat1, paramFloat2, paramFloat3, paramFloat4, null);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getAllFonts() {
/* 656 */     if (fonts == null) {
/* 657 */       fonts = Common.getToolkit().getFontList();
/*     */     }
/*     */     
/* 660 */     return fonts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 667 */   public String getFontName(Font paramFont) { return paramFont.getName(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 674 */   public String getPSName(Font paramFont) { return paramFont.getName(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintRotate(Painter paramPainter, Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 682 */     paramFloat1 = round(paramFloat1); paramFloat2 = round(paramFloat2);
/* 683 */     paramFloat3 = round(paramFloat3); paramFloat4 = round(paramFloat4);
/*     */     
/* 685 */     if ((int)paramFloat4 != this.bSize.width || (int)paramFloat3 != this.bSize.height) {
/* 686 */       this.bSize = new Dimension((int)paramFloat4, (int)paramFloat3);
/* 687 */       this.buffer = Common.createImage(this.bSize.width, this.bSize.height);
/*     */     } 
/*     */     
/* 690 */     Graphics graphics = this.buffer.getGraphics();
/* 691 */     paramPainter.paint(graphics, 0, 0, (int)paramFloat4, (int)paramFloat3);
/* 692 */     graphics.dispose();
/*     */     
/* 694 */     RotateFilter rotateFilter = new RotateFilter();
/* 695 */     Image image = Common.getToolkit().createImage(new FilteredImageSource(this.buffer.getSource(), rotateFilter));
/*     */     
/* 697 */     paramGraphics.drawImage(image, (int)paramFloat1, (int)paramFloat2, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startPage(Graphics paramGraphics, StylePage paramStylePage) {
/* 708 */     Dimension dimension = paramStylePage.getPageDimension();
/* 709 */     Rectangle rectangle = paramGraphics.getClipBounds();
/* 710 */     String str = ReportEnv.getProperty("os.name");
/* 711 */     boolean bool = (paramGraphics.getClass().getName().indexOf("PeekG") < 0 && str != null && str.startsWith("Windows 9")) ? 1 : 0;
/*     */ 
/*     */ 
/*     */     
/* 715 */     if ((bool && !Common.isGraphics2D(paramGraphics)) || paramGraphics.getClip() == null || rectangle == null || (rectangle.x < 0 && rectangle.y < 0 && rectangle.width > dimension.width && rectangle.height > dimension.height))
/*     */     {
/*     */ 
/*     */       
/* 719 */       paramGraphics.setClip(new Rectangle(0, 0, dimension.width, dimension.height));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compare(Object paramObject1, Object paramObject2) {
/* 730 */     if (paramObject1 == null || paramObject2 == null) {
/* 731 */       return (paramObject1 == null && paramObject2 == null) ? 0 : ((paramObject1 == null) ? -1 : 1);
/*     */     }
/* 733 */     if (paramObject1 instanceof Number && paramObject2 instanceof Number) {
/* 734 */       double d = ((Number)paramObject1).doubleValue() - ((Number)paramObject2).doubleValue();
/* 735 */       return (d == 0.0D) ? 0 : ((d > 0.0D) ? 1 : -1);
/*     */     } 
/*     */     
/* 738 */     return paramObject1.toString().compareTo(paramObject2.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeJPEG(Image paramImage, OutputStream paramOutputStream) {
/* 745 */     JpegEncoder jpegEncoder = new JpegEncoder(paramImage, 80, paramOutputStream);
/* 746 */     jpegEncoder.Compress();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 753 */   public static int round(double paramDouble) { return Common.round(paramDouble); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected float adjustSpacing(Font paramFont, float paramFloat) {
/* 760 */     if (this.fontratios == null) {
/* 761 */       this.fontratios = new Hashtable();
/*     */ 
/*     */ 
/*     */       
/* 765 */       String str = ReportEnv.getProperty("font.ratio.x");
/* 766 */       if (str == null)
/*     */       {
/* 768 */         str = ReportEnv.getProperty("pdf.font.ratio");
/*     */       }
/*     */       
/* 771 */       if (str != null) {
/* 772 */         parseRatios(this.fontratios, str);
/*     */       }
/*     */     } 
/*     */     
/* 776 */     if (this.fontratios.size() > 0) {
/* 777 */       Double double = (Double)this.fontratios.get(paramFont.getName());
/* 778 */       return (double == null) ? paramFloat : (int)(paramFloat * double.doubleValue());
/*     */     } 
/*     */     
/* 781 */     return paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected float adjustHeight(Font paramFont, float paramFloat) {
/* 788 */     if (this.vfontratios == null) {
/* 789 */       this.vfontratios = new Hashtable();
/*     */ 
/*     */ 
/*     */       
/* 793 */       String str = ReportEnv.getProperty("font.ratio.y");
/*     */       
/* 795 */       if (str != null) {
/* 796 */         parseRatios(this.vfontratios, str);
/*     */       }
/*     */     } 
/*     */     
/* 800 */     if (this.vfontratios.size() > 0) {
/* 801 */       Double double = (Double)this.vfontratios.get(paramFont.getName());
/* 802 */       return (double == null) ? paramFloat : (int)(paramFloat * double.doubleValue());
/*     */     } 
/*     */     
/* 805 */     return paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseRatios(Hashtable paramHashtable, String paramString) {
/* 813 */     String[] arrayOfString = Util.split(paramString, ';');
/* 814 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 815 */       String[] arrayOfString1 = Util.split(arrayOfString[b], ':');
/* 816 */       if (arrayOfString1.length == 2 && arrayOfString1[0].length() > 0) {
/*     */         try {
/* 818 */           paramHashtable.put(arrayOfString1[0], Double.valueOf(arrayOfString1[1]));
/* 819 */         } catch (Exception exception) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 831 */   public Image createImage(int paramInt1, int paramInt2) { return Common.getInvisibleFrame().createImage(paramInt1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 838 */   public float getLineWidth(int paramInt) { return (paramInt & 0xF) + (float)Math.ceil((((paramInt & 0xF0000) >> 16) / 16.0F)); }
/*     */ 
/*     */ 
/*     */   
/* 842 */   static String[] fonts = null;
/* 843 */   Hashtable fontratios = null;
/* 844 */   Hashtable vfontratios = null;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\Gop.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */