package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.PSPrinter;
import inetsoft.report.Painter;
import inetsoft.report.PreviewPage;
import inetsoft.report.PreviewView;
import inetsoft.report.Previewer;
import inetsoft.report.ReportEnv;
import inetsoft.report.StyleConstants;
import inetsoft.report.StyleFont;
import inetsoft.report.StylePage;
import inetsoft.report.StyleSheet;
import inetsoft.report.Win32Printer;
import inetsoft.report.locale.Catalog;
import inetsoft.report.painter.ImagePainter;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Polygon;
import java.awt.PrintJob;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.image.FilteredImageSource;
import java.awt.image.ImageObserver;
import java.awt.image.MemoryImageSource;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Hashtable;

public class Gop implements StyleConstants {
  private static Gop gop = null;
  
  private static boolean swing = false;
  
  Image buffer;
  
  public static Gop getInstance() {
    if (gop == null) {
      try {
        Class.forName("java.awt.JobAttributes");
        gop = (Gop)Class.forName("inetsoft.report.internal.j2d.Gop1_3").newInstance();
      } catch (Throwable throwable) {
        try {
          Class.forName("java.awt.Graphics2D");
          gop = (Gop)Class.forName("inetsoft.report.internal.j2d.Gop2D").newInstance();
        } catch (Throwable throwable1) {
          gop = new Gop();
        } 
      } 
      try {
        Class.forName("javax.swing.JFrame");
        swing = true;
      } catch (Throwable throwable) {
        swing = false;
      } 
    } 
    return gop;
  }
  
  public boolean isJava2() { return false; }
  
  public StyleSheet createStyleSheet() { return new StyleSheet(); }
  
  public PreviewView getPreviewView() {
    try {
      if (swing)
        return (PreviewView)Class.forName("inetsoft.report.j2d.JPreviewer").newInstance(); 
    } catch (Exception exception) {}
    return new Previewer();
  }
  
  public void print(StyleSheet paramStyleSheet) throws Exception {
    PrintJob printJob = Common.getToolkit().getPrintJob(Common.getInvisibleFrame(), Catalog.getString("Report"), null);
    if (printJob != null) {
      paramStyleSheet.print(printJob);
      printJob.end();
    } 
  }
  
  public void print(String paramString, Enumeration paramEnumeration, boolean paramBoolean) throws Exception {
    PrintJob printJob = null;
    if (paramString == null) {
      printJob = Common.getToolkit().getPrintJob(Common.getInvisibleFrame(), Catalog.getString("Report"), null);
    } else if (ReportEnv.getProperty("os.name").startsWith("Windows")) {
      Win32Printer win32Printer = Win32Printer.getPrinter(paramString);
      if (win32Printer != null)
        printJob = win32Printer.getPrintJob(); 
    } else if (ReportEnv.getProperty("os.name").startsWith("Solaris") || ReportEnv.getProperty("os.name").startsWith("SunOS")) {
      String str = "lp -d\"" + paramString + "\"";
      PSPrinter pSPrinter = new PSPrinter(str);
      printJob = pSPrinter.getPrintJob();
    } 
    if (printJob != null) {
      while (paramEnumeration.hasMoreElements()) {
        StylePage stylePage = (StylePage)paramEnumeration.nextElement();
        Graphics graphics = printJob.getGraphics();
        stylePage.print(graphics);
        graphics.dispose();
      } 
      printJob.end();
    } 
  }
  
  public float getLineAdjustment(Graphics paramGraphics) { return 0.0F; }
  
  public boolean isGraphics2D(Graphics paramGraphics) { return false; }
  
  public void drawHLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, int paramInt3) {
    float f1 = getLineWidth(paramInt1);
    float f2 = Math.min(paramFloat2, paramFloat3), f3 = Math.max(paramFloat2, paramFloat3);
    paramFloat2 = f2;
    paramFloat3 = f3;
    if ((paramInt1 & 0x1000) != 0) {
      float f = Math.min(getLineWidth(paramInt2), getLineWidth(paramInt3));
      if ((paramInt1 & 0xF0) != 0) {
        boolean bool = true;
        int i = (paramInt1 & 0xF0) >> 4;
        for (float f4 = paramFloat2 + f; f4 <= paramFloat3; f4 += i, bool = !bool ? 1 : 0) {
          if (bool)
            drawLine(paramGraphics, f4, paramFloat1, Math.min(paramFloat3, f4 + i - 1.0F), paramFloat1, 4097); 
        } 
      } else {
        int i = ((paramInt1 & 0xF0000) != 0) ? paramInt1 : 4097;
        for (byte b = 0; b < f1; b++)
          drawLine(paramGraphics, paramFloat2 + f, paramFloat1 + b, paramFloat3, paramFloat1 + b, i); 
      } 
    } else if ((paramInt1 & 0x2000) != 0) {
      Color color = paramGraphics.getColor();
      if (color == null)
        color = new Color(0, 0, 0); 
      if ((paramInt1 & 0x4000) != 0) {
        paramGraphics.setColor(Util.brighter(color));
      } else if ((paramInt1 & 0x8000) != 0) {
        paramGraphics.setColor(Util.darker(color));
      } 
      float f = getLineWidth(paramInt2);
      if (paramFloat2 + f <= paramFloat3)
        drawLine(paramGraphics, paramFloat2 + f, paramFloat1, paramFloat3, paramFloat1, 4097); 
      if ((paramInt1 & 0x4000) != 0) {
        paramGraphics.setColor(Util.darker(color));
      } else if ((paramInt1 & 0x8000) != 0) {
        paramGraphics.setColor(Util.brighter(color));
      } 
      f = getLineWidth(paramInt3);
      f = (f > 0.0F) ? (f - 1.0F) : f;
      if (paramFloat2 + f <= paramFloat3)
        drawLine(paramGraphics, paramFloat2 + f, paramFloat1 + f1 - 1.0F, paramFloat3, paramFloat1 + f1 - 1.0F, 4097); 
      paramGraphics.setColor(color);
    } 
  }
  
  public void drawVLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, int paramInt3) {
    float f1 = getLineWidth(paramInt1);
    float f2 = Math.min(paramFloat2, paramFloat3), f3 = Math.max(paramFloat2, paramFloat3);
    paramFloat2 = f2;
    paramFloat3 = f3;
    if ((paramInt1 & 0x1000) != 0) {
      float f = ((paramInt2 & 0x1000) != 0 || (paramInt3 & 0x1000) != 0) ? 0.0F : Math.min(getLineWidth(paramInt2), getLineWidth(paramInt3));
      if ((paramInt1 & 0xF0) != 0) {
        boolean bool = true;
        int i = (paramInt1 & 0xF0) >> 4;
        for (float f4 = paramFloat2 + f; f4 <= paramFloat3; f4 += i, bool = !bool ? 1 : 0) {
          if (bool)
            drawLine(paramGraphics, paramFloat1, f4, paramFloat1, Math.min(paramFloat3, f4 + i - 1.0F), 4097); 
        } 
      } else {
        int i = ((paramInt1 & 0xF0000) != 0) ? paramInt1 : 4097;
        for (byte b = 0; b < f1; b++)
          drawLine(paramGraphics, paramFloat1 + b, paramFloat2 + f, paramFloat1 + b, paramFloat3, i); 
      } 
    } else if (paramInt1 != 0) {
      Color color = paramGraphics.getColor();
      if ((paramInt1 & 0x4000) != 0) {
        paramGraphics.setColor(Util.brighter(color));
      } else if ((paramInt1 & 0x8000) != 0) {
        paramGraphics.setColor(Util.darker(color));
      } 
      float f = getLineWidth(paramInt2);
      f = (f > 0.0F) ? (f - 1.0F) : f;
      if (paramFloat2 + f <= paramFloat3)
        drawLine(paramGraphics, paramFloat1, paramFloat2 + f, paramFloat1, paramFloat3, 4097); 
      if ((paramInt1 & 0x4000) != 0) {
        paramGraphics.setColor(Util.darker(color));
      } else if ((paramInt1 & 0x8000) != 0) {
        paramGraphics.setColor(Util.brighter(color));
      } 
      f = getLineWidth(paramInt3);
      if (paramFloat2 + f <= paramFloat3)
        drawLine(paramGraphics, paramFloat1 + f1 - 1.0F, paramFloat2 + f, paramFloat1 + f1 - 1.0F, paramFloat3, 4097); 
      paramGraphics.setColor(color);
    } 
  }
  
  public void drawLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt) { drawLine(paramGraphics, round(paramFloat1), round(paramFloat2), round(paramFloat3), round(paramFloat4)); }
  
  public void drawLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) { paramGraphics.drawLine(round(paramFloat1), round(paramFloat2), round(paramFloat3), round(paramFloat4)); }
  
  public void fillRect(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    Bounds bounds = (new Bounds(paramFloat1, paramFloat2, paramFloat3, paramFloat4)).round();
    paramGraphics.fillRect(round(bounds.x), round(bounds.y), round(bounds.width), round(bounds.height));
  }
  
  public void fillArc(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, Object paramObject) {
    try {
      paramGraphics.setColor((Color)paramObject);
    } catch (Exception exception) {
      paramGraphics.setColor(Color.gray);
    } 
    paramGraphics.fillArc((int)paramFloat1, (int)paramFloat2, (int)paramFloat3, (int)paramFloat4, (int)paramFloat5, round(paramFloat6));
  }
  
  public void fill(Graphics paramGraphics, Shape paramShape, Object paramObject) {
    Color color = paramGraphics.getColor();
    try {
      paramGraphics.setColor((Color)paramObject);
    } catch (Exception exception) {
      paramGraphics.setColor(Color.gray);
    } 
    if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      paramGraphics.fillRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } else if (paramShape instanceof Polygon) {
      paramGraphics.fillPolygon((Polygon)paramShape);
    } 
    paramGraphics.setColor(color);
  }
  
  public void setClip(Graphics paramGraphics, Bounds paramBounds) {
    Bounds bounds = paramBounds.round();
    paramGraphics.setClip(round(bounds.x), round(bounds.y), round(bounds.width), round(bounds.height));
  }
  
  public void clipRect(Graphics paramGraphics, Bounds paramBounds) {
    Bounds bounds = paramBounds.round();
    paramGraphics.clipRect((int)bounds.x, (int)bounds.y, round(bounds.width), round(bounds.height));
  }
  
  public void drawImage(Graphics paramGraphics, Image paramImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, ImageObserver paramImageObserver) {
    Dimension dimension = new Dimension(paramImage.getWidth(null), paramImage.getHeight(null));
    String str = ReportEnv.getProperty("StyleReport.ditherImage");
    if (paramImage instanceof MetaImage)
      paramImage = ((MetaImage)paramImage).getImage(); 
    if (paramFloat3 > 0.0F && paramFloat4 > 0.0F && dimension.width != round(paramFloat3) && dimension.height != round(paramFloat4) && str != null && str.equals("true"))
      paramImage = paramImage.getScaledInstance(round(paramFloat3), round(paramFloat4), 4); 
    paramGraphics.drawImage(paramImage, round(paramFloat1), round(paramFloat2), round(paramFloat3), round(paramFloat4), paramImageObserver);
  }
  
  public void rotate(Graphics paramGraphics, double paramDouble) {}
  
  public void paintPage(Graphics paramGraphics, PreviewPage paramPreviewPage) { PreviewPage.paintPage(paramGraphics, paramPreviewPage); }
  
  public Image createImage(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    int[] arrayOfInt = new int[paramInt1 * paramInt2];
    byte b1 = 0, b2 = 0;
    for (byte b3 = 0; b3 < paramInt2; b3++) {
      for (byte b = 0; b < paramInt1; b++) {
        byte b4 = paramArrayOfByte[b1++] & 0xFF;
        byte b5 = paramArrayOfByte[b1++] & 0xFF;
        byte b6 = paramArrayOfByte[b1++] & 0xFF;
        arrayOfInt[b2++] = 0xFF000000 | b4 << 16 | b5 << 8 | b6;
      } 
    } 
    return Common.getToolkit().createImage(new MemoryImageSource(paramInt1, paramInt2, arrayOfInt, 0, paramInt1));
  }
  
  public Object getPaint(int paramInt) { return Common.getColor(paramInt); }
  
  public float getHeight(Font paramFont, FontMetrics paramFontMetrics) {
    if (paramFontMetrics == null)
      paramFontMetrics = Common.getFontMetrics(paramFont); 
    int i = paramFontMetrics.getHeight() - paramFontMetrics.getLeading();
    if (paramFont instanceof StyleFont) {
      StyleFont styleFont = (StyleFont)paramFont;
      if ((styleFont.getStyle() & 0x10) != 0)
        return i + getLineWidth(styleFont.getLineStyle()) - 1.0F; 
    } 
    return adjustHeight(paramFont, i);
  }
  
  public float stringWidth(String paramString, Font paramFont, FontMetrics paramFontMetrics) { return adjustSpacing(paramFont, paramFontMetrics.stringWidth(paramString)); }
  
  public float getAscent(FontMetrics paramFontMetrics) { return paramFontMetrics.getAscent(); }
  
  public void drawString(Graphics paramGraphics, String paramString, float paramFloat1, float paramFloat2) { paramGraphics.drawString(paramString, round(paramFloat1), round(paramFloat2)); }
  
  Dimension bSize = new Dimension(-1, -1);
  
  public void paint(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Painter paramPainter, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, Color paramColor1, Color paramColor2) {
    if (paramFloat3 == paramFloat7 && paramFloat4 == paramFloat8) {
      Shape shape = paramGraphics.getClip();
      Color color = paramGraphics.getColor();
      paramGraphics.translate(round(paramFloat1), round(paramFloat2));
      paramGraphics.clipRect(0, 0, round(paramFloat3), round(paramFloat4));
      paramGraphics.setColor((paramColor2 == null) ? Color.white : paramColor2);
      paramGraphics.fillRect(0, 0, round(paramFloat3), round(paramFloat4));
      paramGraphics.setColor(paramColor1);
      paramPainter.paint(paramGraphics, (int)paramFloat5, (int)paramFloat6, (int)paramFloat7, (int)paramFloat8);
      paramGraphics.translate(-round(paramFloat1), -round(paramFloat2));
      paramGraphics.setClip(shape);
      paramGraphics.setColor(color);
    } else if (paramPainter instanceof ImagePainter) {
      Image image = ((ImagePainter)paramPainter).getImage();
      boolean bool = ((ImagePainter)paramPainter).isFit();
      if (image instanceof MetaImage)
        image = ((MetaImage)image).getImage(); 
      if (image != null) {
        Shape shape = paramGraphics.getClip();
        Color color = paramGraphics.getColor();
        paramGraphics.translate((int)paramFloat1, (int)paramFloat2);
        paramGraphics.clipRect(0, 0, (int)paramFloat3, (int)paramFloat4);
        if (paramColor2 != null) {
          paramGraphics.setColor(paramColor2);
          paramGraphics.fillRect(0, 0, (int)paramFloat3, (int)paramFloat4);
        } 
        float f1 = paramFloat3 / paramFloat7;
        float f2 = paramFloat4 / paramFloat9;
        if (bool) {
          Common.drawImage(paramGraphics, image, paramFloat5 * f1, paramFloat6 * f2, paramFloat7 * f1, paramFloat8 * f2, null);
        } else {
          Common.drawImage(paramGraphics, image, paramFloat5 * f1, paramFloat6 * f2, 0.0F, 0.0F, null);
        } 
        paramGraphics.translate(-((int)paramFloat1), -((int)paramFloat2));
        paramGraphics.setClip(shape);
        paramGraphics.setColor(color);
      } 
    } else {
      if (round(paramFloat7) != this.bSize.width || round(paramFloat9) != this.bSize.height) {
        this.bSize = new Dimension(round(paramFloat7), round(paramFloat9));
        this.buffer = Common.createImage(this.bSize.width, this.bSize.height);
      } 
      Graphics graphics = this.buffer.getGraphics();
      graphics.setClip(0, 0, this.bSize.width, this.bSize.height);
      graphics.setColor((paramColor2 == null) ? Color.white : paramColor2);
      graphics.fillRect(0, 0, this.bSize.width, this.bSize.height);
      graphics.setColor(paramColor1);
      paramPainter.paint(graphics, round(paramFloat5), round(paramFloat6), round(paramFloat7), round(paramFloat8));
      graphics.dispose();
      if (paramGraphics instanceof CustomGraphics) {
        Common.drawImage(paramGraphics, this.buffer, paramFloat1, paramFloat2, paramFloat3, paramFloat4, null);
      } else {
        Common.drawImage(paramGraphics, Common.getToolkit().createImage(this.buffer.getSource()), paramFloat1, paramFloat2, paramFloat3, paramFloat4, null);
      } 
    } 
  }
  
  public String[] getAllFonts() {
    if (fonts == null)
      fonts = Common.getToolkit().getFontList(); 
    return fonts;
  }
  
  public String getFontName(Font paramFont) { return paramFont.getName(); }
  
  public String getPSName(Font paramFont) { return paramFont.getName(); }
  
  public void paintRotate(Painter paramPainter, Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    paramFloat1 = round(paramFloat1);
    paramFloat2 = round(paramFloat2);
    paramFloat3 = round(paramFloat3);
    paramFloat4 = round(paramFloat4);
    if ((int)paramFloat4 != this.bSize.width || (int)paramFloat3 != this.bSize.height) {
      this.bSize = new Dimension((int)paramFloat4, (int)paramFloat3);
      this.buffer = Common.createImage(this.bSize.width, this.bSize.height);
    } 
    Graphics graphics = this.buffer.getGraphics();
    paramPainter.paint(graphics, 0, 0, (int)paramFloat4, (int)paramFloat3);
    graphics.dispose();
    RotateFilter rotateFilter = new RotateFilter();
    Image image = Common.getToolkit().createImage(new FilteredImageSource(this.buffer.getSource(), rotateFilter));
    paramGraphics.drawImage(image, (int)paramFloat1, (int)paramFloat2, null);
  }
  
  public void startPage(Graphics paramGraphics, StylePage paramStylePage) {
    Dimension dimension = paramStylePage.getPageDimension();
    Rectangle rectangle = paramGraphics.getClipBounds();
    String str = ReportEnv.getProperty("os.name");
    boolean bool = (paramGraphics.getClass().getName().indexOf("PeekG") < 0 && str != null && str.startsWith("Windows 9")) ? 1 : 0;
    if ((bool && !Common.isGraphics2D(paramGraphics)) || paramGraphics.getClip() == null || rectangle == null || (rectangle.x < 0 && rectangle.y < 0 && rectangle.width > dimension.width && rectangle.height > dimension.height))
      paramGraphics.setClip(new Rectangle(0, 0, dimension.width, dimension.height)); 
  }
  
  public int compare(Object paramObject1, Object paramObject2) {
    if (paramObject1 == null || paramObject2 == null)
      return (paramObject1 == null && paramObject2 == null) ? 0 : ((paramObject1 == null) ? -1 : 1); 
    if (paramObject1 instanceof Number && paramObject2 instanceof Number) {
      double d = ((Number)paramObject1).doubleValue() - ((Number)paramObject2).doubleValue();
      return (d == 0.0D) ? 0 : ((d > 0.0D) ? 1 : -1);
    } 
    return paramObject1.toString().compareTo(paramObject2.toString());
  }
  
  public void writeJPEG(Image paramImage, OutputStream paramOutputStream) {
    JpegEncoder jpegEncoder = new JpegEncoder(paramImage, 80, paramOutputStream);
    jpegEncoder.Compress();
  }
  
  public static int round(double paramDouble) { return Common.round(paramDouble); }
  
  protected float adjustSpacing(Font paramFont, float paramFloat) {
    if (this.fontratios == null) {
      this.fontratios = new Hashtable();
      String str = ReportEnv.getProperty("font.ratio.x");
      if (str == null)
        str = ReportEnv.getProperty("pdf.font.ratio"); 
      if (str != null)
        parseRatios(this.fontratios, str); 
    } 
    if (this.fontratios.size() > 0) {
      Double double = (Double)this.fontratios.get(paramFont.getName());
      return (double == null) ? paramFloat : (int)(paramFloat * double.doubleValue());
    } 
    return paramFloat;
  }
  
  protected float adjustHeight(Font paramFont, float paramFloat) {
    if (this.vfontratios == null) {
      this.vfontratios = new Hashtable();
      String str = ReportEnv.getProperty("font.ratio.y");
      if (str != null)
        parseRatios(this.vfontratios, str); 
    } 
    if (this.vfontratios.size() > 0) {
      Double double = (Double)this.vfontratios.get(paramFont.getName());
      return (double == null) ? paramFloat : (int)(paramFloat * double.doubleValue());
    } 
    return paramFloat;
  }
  
  protected void parseRatios(Hashtable paramHashtable, String paramString) {
    String[] arrayOfString = Util.split(paramString, ';');
    for (byte b = 0; b < arrayOfString.length; b++) {
      String[] arrayOfString1 = Util.split(arrayOfString[b], ':');
      if (arrayOfString1.length == 2 && arrayOfString1[0].length() > 0)
        try {
          paramHashtable.put(arrayOfString1[0], Double.valueOf(arrayOfString1[1]));
        } catch (Exception exception) {} 
    } 
  }
  
  public Image createImage(int paramInt1, int paramInt2) { return Common.getInvisibleFrame().createImage(paramInt1, paramInt2); }
  
  public float getLineWidth(int paramInt) { return (paramInt & 0xF) + (float)Math.ceil((((paramInt & 0xF0000) >> 16) / 16.0F)); }
  
  static String[] fonts = null;
  
  Hashtable fontratios = null;
  
  Hashtable vfontratios = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\Gop.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */