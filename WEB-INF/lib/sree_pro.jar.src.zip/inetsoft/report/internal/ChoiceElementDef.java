/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.ChoiceElement;
/*     */ import inetsoft.report.Painter;
/*     */ import inetsoft.report.StyleSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChoiceElementDef
/*     */   extends FieldElementDef
/*     */   implements ChoiceElement
/*     */ {
/*     */   ChoicePainter painter;
/*     */   
/*     */   public ChoiceElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, Object paramObject, Object[] paramArrayOfObject, double paramDouble1, double paramDouble2) {
/*  35 */     super(paramStyleSheet, paramString1, paramString2, paramDouble1, paramDouble2);
/*  36 */     this.painter.setSelectedItem(paramObject);
/*  37 */     this.painter.setChoices(paramArrayOfObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public ChoiceElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, Object paramObject, Object[] paramArrayOfObject) { this(paramStyleSheet, paramString1, paramString2, paramObject, paramArrayOfObject, 0.0D, 0.0D); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   protected FieldPainter createPainter() { return this.painter = new ChoicePainter(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public Object[] getChoices() { return this.painter.getChoices(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public void setChoices(Object[] paramArrayOfObject) { this.painter.setChoices(paramArrayOfObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public Object getSelectedItem() { return this.painter.getSelectedItem(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public void setSelectedItem(Object paramObject) { this.painter.setSelectedItem(paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPainter(Painter paramPainter) {
/*  88 */     super.setPainter(paramPainter);
/*  89 */     this.painter = (ChoicePainter)paramPainter;
/*     */   }
/*     */ 
/*     */   
/*  93 */   public String getType() { return "Choice"; }
/*     */ 
/*     */   
/*     */   public Object clone() {
/*  97 */     ChoiceElementDef choiceElementDef = (ChoiceElementDef)super.clone();
/*  98 */     choiceElementDef.setPainter(new ChoicePainter(choiceElementDef));
/*  99 */     choiceElementDef.setSelectedItem(this.painter.getSelectedItem());
/* 100 */     choiceElementDef.setChoices(this.painter.getChoices());
/* 101 */     return choiceElementDef;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ChoiceElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */