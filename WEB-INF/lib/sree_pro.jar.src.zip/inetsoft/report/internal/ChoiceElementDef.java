package inetsoft.report.internal;

import inetsoft.report.ChoiceElement;
import inetsoft.report.Painter;
import inetsoft.report.StyleSheet;

public class ChoiceElementDef extends FieldElementDef implements ChoiceElement {
  ChoicePainter painter;
  
  public ChoiceElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, Object paramObject, Object[] paramArrayOfObject, double paramDouble1, double paramDouble2) {
    super(paramStyleSheet, paramString1, paramString2, paramDouble1, paramDouble2);
    this.painter.setSelectedItem(paramObject);
    this.painter.setChoices(paramArrayOfObject);
  }
  
  public ChoiceElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, Object paramObject, Object[] paramArrayOfObject) { this(paramStyleSheet, paramString1, paramString2, paramObject, paramArrayOfObject, 0.0D, 0.0D); }
  
  protected FieldPainter createPainter() { return this.painter = new ChoicePainter(this); }
  
  public Object[] getChoices() { return this.painter.getChoices(); }
  
  public void setChoices(Object[] paramArrayOfObject) { this.painter.setChoices(paramArrayOfObject); }
  
  public Object getSelectedItem() { return this.painter.getSelectedItem(); }
  
  public void setSelectedItem(Object paramObject) { this.painter.setSelectedItem(paramObject); }
  
  public void setPainter(Painter paramPainter) {
    super.setPainter(paramPainter);
    this.painter = (ChoicePainter)paramPainter;
  }
  
  public String getType() { return "Choice"; }
  
  public Object clone() {
    ChoiceElementDef choiceElementDef = (ChoiceElementDef)super.clone();
    choiceElementDef.setPainter(new ChoicePainter(choiceElementDef));
    choiceElementDef.setSelectedItem(this.painter.getSelectedItem());
    choiceElementDef.setChoices(this.painter.getChoices());
    return choiceElementDef;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ChoiceElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */