/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AFontMetrics
/*     */   extends FontMetrics
/*     */ {
/*     */   protected String fontName;
/*     */   protected String fullName;
/*     */   protected String familyName;
/*     */   protected String weight;
/*     */   protected boolean fixedPitch;
/*     */   protected double italicAngle;
/*     */   protected int ascender;
/*     */   protected int descender;
/*     */   protected int[] widths;
/*     */   protected Hashtable pairKern;
/*     */   protected int advance;
/*     */   protected Rectangle bbox;
/*     */   int size;
/*     */   
/*     */   protected AFontMetrics() {
/*  35 */     super(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     this.size = 10; } public AFontMetrics(InputStream paramInputStream) throws IOException { super(null); this.size = 10;
/*     */     parse(paramInputStream); }
/*     */ 
/*     */   
/*     */   public void setSize(int paramInt) { this.size = paramInt; }
/*     */   
/*     */   public int getSize() { return this.size; }
/*     */   
/*     */   public int getAscent() { return (int)Math.ceil((getHeight() * this.ascender / (this.ascender + this.descender))); }
/*     */   
/*     */   public int getDescent() { return (int)Math.ceil((getHeight() * this.descender / (this.ascender + this.descender))); }
/*     */   
/*     */   public int getMaxAdvance() { return (int)Math.ceil((this.advance * this.size) / 1000.0D); }
/*     */   
/*     */   public int getHeight() { return (int)Math.ceil(Math.max((this.bbox.height * this.size) / 1000.0D, ((this.descender + this.ascender) * this.size) / 1000.0D)); }
/*     */   
/*     */   public int charWidth(char paramChar) { return (int)Math.ceil((getWidth(paramChar) * this.size) / 1000.0D); }
/*     */   
/*     */   public int stringWidth(String paramString) {
/*     */     int i = 0;
/*     */     for (byte b1 = 0; b1 < paramString.length(); b1++)
/*     */       i += getWidth(paramString.charAt(b1)); 
/*     */     for (byte b2 = 0; b2 < paramString.length() - 1; b2++) {
/*     */       Integer integer = (Integer)this.pairKern.get(paramString.substring(b2, b2 + 2));
/*     */       if (integer != null)
/*     */         i += integer.intValue(); 
/*     */     } 
/*     */     return (int)Math.ceil((i * this.size) / 1000.0D);
/*     */   }
/*     */   
/*     */   public int[] getWidths() {
/*     */     int[] arrayOfInt = new int[this.widths.length];
/*     */     for (byte b = 0; b < arrayOfInt.length; b++)
/*     */       arrayOfInt[b] = getWidth(b) * this.size / 1000; 
/*     */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   void parse(InputStream paramInputStream) throws IOException {
/*     */     Hashtable hashtable = new Hashtable();
/*     */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
/*     */     int i = 0;
/*     */     this.pairKern = new Hashtable();
/*     */     this.widths = new int[256];
/*     */     String str;
/*     */     while ((str = bufferedReader.readLine()) != null) {
/*     */       if (i) {
/*     */         i--;
/*     */         continue;
/*     */       } 
/*     */       StringTokenizer stringTokenizer = new StringTokenizer(str, " \t");
/*     */       String str1 = stringTokenizer.nextToken();
/*     */       if (str1 == null || str1.equals("Comment"))
/*     */         continue; 
/*     */       if (str1.equals("FontName")) {
/*     */         this.fontName = stringTokenizer.nextToken();
/*     */         continue;
/*     */       } 
/*     */       if (str1.equals("FullName")) {
/*     */         this.fullName = stringTokenizer.nextToken();
/*     */         continue;
/*     */       } 
/*     */       if (str1.equals("FamilyName")) {
/*     */         this.familyName = stringTokenizer.nextToken();
/*     */         continue;
/*     */       } 
/*     */       if (str1.equals("Weight")) {
/*     */         this.weight = stringTokenizer.nextToken();
/*     */         continue;
/*     */       } 
/*     */       if (str1.equals("IsFixedPitch")) {
/*     */         this.fixedPitch = stringTokenizer.nextToken().equals("true");
/*     */         continue;
/*     */       } 
/*     */       if (str1.equals("ItalicAngle")) {
/*     */         this.italicAngle = Double.valueOf(stringTokenizer.nextToken()).doubleValue();
/*     */         continue;
/*     */       } 
/*     */       if (str1.equals("Ascender")) {
/*     */         this.ascender = Integer.parseInt(stringTokenizer.nextToken());
/*     */         continue;
/*     */       } 
/*     */       if (str1.equals("Descender")) {
/*     */         this.descender = -Integer.parseInt(stringTokenizer.nextToken());
/*     */         continue;
/*     */       } 
/*     */       if (str1.equals("FontBBox")) {
/*     */         this.bbox = new Rectangle();
/*     */         this.bbox.x = Integer.parseInt(stringTokenizer.nextToken());
/*     */         this.bbox.y = Integer.parseInt(stringTokenizer.nextToken());
/*     */         this.bbox.width = Integer.parseInt(stringTokenizer.nextToken());
/*     */         this.bbox.height = Integer.parseInt(stringTokenizer.nextToken());
/*     */         this.bbox.width -= this.bbox.x;
/*     */         this.bbox.height -= this.bbox.y;
/*     */         this.bbox.y += this.bbox.height;
/*     */         continue;
/*     */       } 
/*     */       if (str1.equals("StartCharMetrics")) {
/*     */         while ((str = bufferedReader.readLine()) != null && !str.startsWith("EndCharMetrics")) {
/*     */           int j = -1, k = 0;
/*     */           String str2 = null;
/*     */           StringTokenizer stringTokenizer1 = new StringTokenizer(str, ";");
/*     */           while (stringTokenizer1.hasMoreTokens()) {
/*     */             StringTokenizer stringTokenizer2 = new StringTokenizer(stringTokenizer1.nextToken());
/*     */             String str3 = stringTokenizer2.nextToken();
/*     */             if (str3.equals("C")) {
/*     */               j = Integer.parseInt(stringTokenizer2.nextToken());
/*     */               continue;
/*     */             } 
/*     */             if (str3.equals("WX") || str3.equals("W0X")) {
/*     */               k = Integer.parseInt(stringTokenizer2.nextToken());
/*     */               continue;
/*     */             } 
/*     */             if (str3.equals("N"))
/*     */               str2 = stringTokenizer2.nextToken(); 
/*     */           } 
/*     */           if (j >= 0) {
/*     */             this.widths[j] = k;
/*     */             this.advance = Math.max(this.advance, getWidth(j));
/*     */           } 
/*     */           if (str2 != null)
/*     */             hashtable.put(str2, new Character((char)j)); 
/*     */         } 
/*     */         continue;
/*     */       } 
/*     */       if (str1.equals("StartKernPairs")) {
/*     */         while ((str = bufferedReader.readLine()) != null && !str.startsWith("EndKernPairs")) {
/*     */           StringTokenizer stringTokenizer1 = new StringTokenizer(str, ";");
/*     */           while (stringTokenizer1.hasMoreTokens()) {
/*     */             StringTokenizer stringTokenizer2 = new StringTokenizer(stringTokenizer1.nextToken());
/*     */             String str2 = stringTokenizer2.nextToken();
/*     */             if (str2.equals("KP") || str2.equals("KPX")) {
/*     */               String str3 = stringTokenizer2.nextToken();
/*     */               String str4 = stringTokenizer2.nextToken();
/*     */               char c1 = str3.charAt(0), c2 = str4.charAt(0);
/*     */               if (str3.length() > 1) {
/*     */                 Character character;
/*     */                 c1 = ((character = (Character)hashtable.get(str3)) != null) ? character.charValue() : 0;
/*     */               } 
/*     */               if (str4.length() > 1) {
/*     */                 Character character;
/*     */                 c2 = ((character = (Character)hashtable.get(str4)) != null) ? character.charValue() : 0;
/*     */               } 
/*     */               if (c1 != '\000' && c2 != '\000')
/*     */                 this.pairKern.put(c1 + "" + c2, Integer.valueOf(stringTokenizer2.nextToken())); 
/*     */               continue;
/*     */             } 
/*     */             if (str2.equals("KPH")) {
/*     */               String str3 = stringTokenizer2.nextToken();
/*     */               String str4 = stringTokenizer2.nextToken();
/*     */               char c1 = (char)Integer.parseInt(str3.substring(1, str3.length() - 1), 16);
/*     */               char c2 = (char)Integer.parseInt(str4.substring(1, str4.length() - 1), 16);
/*     */               this.pairKern.put(c1 + "" + c2, Integer.valueOf(stringTokenizer2.nextToken()));
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         continue;
/*     */       } 
/*     */       if (str1.equals("StartComposites") || str1.equals("StartTrackKern"))
/*     */         i = Integer.parseInt(stringTokenizer.nextToken()); 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected int getWidth(int paramInt) { return (paramInt < this.widths.length && this.widths[paramInt] > 0) ? this.widths[paramInt] : this.widths[97]; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\AFontMetrics.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */