/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.ChartDescriptor;
/*    */ import inetsoft.report.ChartElement;
/*    */ import inetsoft.report.ChartLens;
/*    */ import inetsoft.report.ChartPainter;
/*    */ import inetsoft.report.StyleSheet;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChartElementDef
/*    */   extends PainterElementDef
/*    */   implements ChartElement
/*    */ {
/*    */   protected ChartLens chart;
/*    */   protected ChartDescriptor chartinfo;
/*    */   
/*    */   public ChartElementDef(StyleSheet paramStyleSheet, ChartLens paramChartLens) {
/* 32 */     super(paramStyleSheet, null);
/* 33 */     this.chartinfo = paramStyleSheet.chartinfo;
/* 34 */     setPainter(new ChartPainter(paramChartLens, this, this.chartinfo));
/* 35 */     this.chart = paramChartLens;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ChartElementDef(StyleSheet paramStyleSheet, ChartLens paramChartLens, double paramDouble1, double paramDouble2) {
/* 43 */     super(paramStyleSheet, null, paramDouble1, paramDouble2);
/* 44 */     this.chartinfo = paramStyleSheet.chartinfo;
/* 45 */     setPainter(new ChartPainter(paramChartLens, this, this.chartinfo));
/* 46 */     this.chart = paramChartLens;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public ChartLens getChart() { return this.chart; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setChart(ChartLens paramChartLens) {
/* 60 */     this.chart = paramChartLens;
/* 61 */     setPainter(new ChartPainter(paramChartLens, this, this.chartinfo));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 68 */   public ChartDescriptor getChartDescriptor() { return this.chartinfo; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setChartDescriptor(ChartDescriptor paramChartDescriptor) {
/* 75 */     this.chartinfo = paramChartDescriptor;
/* 76 */     setPainter(new ChartPainter(this.chart, this, paramChartDescriptor));
/*    */   }
/*    */ 
/*    */   
/* 80 */   public String toString() { return getID() + " [" + Catalog.getString(getType()) + "]"; }
/*    */ 
/*    */ 
/*    */   
/* 84 */   public String getType() { return "Chart"; }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 88 */     ChartElementDef chartElementDef = (ChartElementDef)super.clone();
/* 89 */     chartElementDef.setPainter(new ChartPainter(chartElementDef.chart, chartElementDef));
/* 90 */     return chartElementDef;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ChartElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */