package inetsoft.report.internal;

import inetsoft.report.ChartDescriptor;
import inetsoft.report.ChartElement;
import inetsoft.report.ChartLens;
import inetsoft.report.ChartPainter;
import inetsoft.report.StyleSheet;
import inetsoft.report.locale.Catalog;

public class ChartElementDef extends PainterElementDef implements ChartElement {
  protected ChartLens chart;
  
  protected ChartDescriptor chartinfo;
  
  public ChartElementDef(StyleSheet paramStyleSheet, ChartLens paramChartLens) {
    super(paramStyleSheet, null);
    this.chartinfo = paramStyleSheet.chartinfo;
    setPainter(new ChartPainter(paramChartLens, this, this.chartinfo));
    this.chart = paramChartLens;
  }
  
  public ChartElementDef(StyleSheet paramStyleSheet, ChartLens paramChartLens, double paramDouble1, double paramDouble2) {
    super(paramStyleSheet, null, paramDouble1, paramDouble2);
    this.chartinfo = paramStyleSheet.chartinfo;
    setPainter(new ChartPainter(paramChartLens, this, this.chartinfo));
    this.chart = paramChartLens;
  }
  
  public ChartLens getChart() { return this.chart; }
  
  public void setChart(ChartLens paramChartLens) {
    this.chart = paramChartLens;
    setPainter(new ChartPainter(paramChartLens, this, this.chartinfo));
  }
  
  public ChartDescriptor getChartDescriptor() { return this.chartinfo; }
  
  public void setChartDescriptor(ChartDescriptor paramChartDescriptor) {
    this.chartinfo = paramChartDescriptor;
    setPainter(new ChartPainter(this.chart, this, paramChartDescriptor));
  }
  
  public String toString() { return getID() + " [" + Catalog.getString(getType()) + "]"; }
  
  public String getType() { return "Chart"; }
  
  public Object clone() throws CloneNotSupportedException {
    ChartElementDef chartElementDef = (ChartElementDef)super.clone();
    chartElementDef.setPainter(new ChartPainter(chartElementDef.chart, chartElementDef));
    return chartElementDef;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ChartElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */