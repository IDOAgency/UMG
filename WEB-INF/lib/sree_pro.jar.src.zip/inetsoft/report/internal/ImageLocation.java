/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.io.Builder;
/*     */ import java.awt.Image;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageLocation
/*     */   implements Serializable
/*     */ {
/*     */   public static final int FULL_PATH = 1;
/*     */   public static final int RELATIVE_PATH = 2;
/*     */   public static final int RESOURCE = 3;
/*     */   public static final int IMAGE_URL = 4;
/*     */   String path;
/*     */   int pathtype;
/*     */   boolean embed;
/*     */   String dir;
/*     */   
/*     */   public ImageLocation(String paramString) {
/* 168 */     this.pathtype = 1;
/* 169 */     this.embed = false;
/*     */     this.dir = paramString;
/*     */   }
/*     */   
/*     */   public boolean isEmbedded() { return this.embed; }
/*     */   
/*     */   public void setEmbedded(boolean paramBoolean) { this.embed = paramBoolean; }
/*     */   
/*     */   public String getPath() { return this.path; }
/*     */   
/*     */   public void setPath(String paramString) { this.path = paramString; }
/*     */   
/*     */   public Image getImage() throws IOException {
/*     */     if (this.path != null) {
/*     */       MetaImage metaImage = null;
/*     */       if (this.pathtype == 3) {
/*     */         metaImage = new MetaImage(this.path);
/*     */       } else if (this.pathtype == 4) {
/*     */         URL uRL = new URL(Builder.getBaseURL(), this.path);
/*     */         metaImage = new MetaImage(uRL);
/*     */       } else if (this.pathtype == 2) {
/*     */         File file = new File(this.path);
/*     */         String str = file.isAbsolute() ? this.path : (this.dir + File.separator + this.path);
/*     */         metaImage = new MetaImage(new File(str));
/*     */       } else {
/*     */         metaImage = new MetaImage(new File(this.path));
/*     */       } 
/*     */       return metaImage;
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   public int getPathType() { return this.pathtype; }
/*     */   
/*     */   public void setPathType(int paramInt) { this.pathtype = paramInt; }
/*     */   
/*     */   public String getAdjustedPath() {
/*     */     String str = this.path;
/*     */     if (this.path != null && this.pathtype == 2) {
/*     */       File file = new File(str);
/*     */       if (!file.isAbsolute())
/*     */         return str; 
/*     */       if (this.dir.indexOf(":\\") > 0)
/*     */         str = this.path.toLowerCase(); 
/*     */       int i = 0;
/*     */       for (; i < str.length() && i < this.dir.length() && str.charAt(i) == this.dir.charAt(i); i++);
/*     */       for (; i >= 0 && str.charAt(i) != File.separatorChar; i--);
/*     */       str = str.substring(i + 1);
/*     */       if (this.dir.endsWith(File.separator))
/*     */         i++; 
/*     */       while ((i = this.dir.indexOf(File.separator, i) + 1) > 0)
/*     */         str = ".." + File.separator + str; 
/*     */     } 
/*     */     return str;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ImageLocation.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */