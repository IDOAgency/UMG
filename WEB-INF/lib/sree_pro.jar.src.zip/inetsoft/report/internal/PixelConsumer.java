/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.ImageConsumer;
/*     */ import java.awt.image.ImageProducer;
/*     */ import java.io.Serializable;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PixelConsumer
/*     */   implements ImageConsumer, Serializable
/*     */ {
/*     */   public int width;
/*     */   public int height;
/*     */   public int iwidth;
/*     */   public int iheight;
/*     */   public int[][] pix;
/*     */   private boolean complete;
/*     */   private boolean region;
/*     */   private Image image;
/*     */   private int sx1;
/*     */   private int sy1;
/*     */   private int sx2;
/*     */   private int sy2;
/*     */   private int trycnt;
/*     */   private boolean init;
/*     */   
/*     */   public PixelConsumer(Image paramImage) {
/* 260 */     this.complete = false;
/* 261 */     this.region = false;
/*     */ 
/*     */     
/* 264 */     this.trycnt = 0;
/* 265 */     this.init = false;
/*     */     this.image = (paramImage instanceof MetaImage) ? ((MetaImage)paramImage).getImage() : paramImage;
/*     */   }
/*     */   
/*     */   public PixelConsumer(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*     */     this(paramImage);
/*     */     this.region = true;
/*     */     this.sx1 = paramInt1;
/*     */     this.sy1 = paramInt2;
/*     */     this.sx2 = paramInt3;
/*     */     this.sy2 = paramInt4;
/*     */   }
/*     */   
/*     */   public Object getKey() { return new Key(this); }
/*     */   
/*     */   public void produce() {
/*     */     if (!this.init) {
/*     */       this.init = true;
/*     */       produce(this.image);
/*     */     } 
/*     */   }
/*     */   
/*     */   void produce(Image paramImage) {
/*     */     ImageProducer imageProducer = paramImage.getSource();
/*     */     imageProducer.removeConsumer(this);
/*     */     imageProducer.startProduction(this);
/*     */     synchronized (this) {
/*     */       while (!this.complete) {
/*     */         try {
/*     */           wait();
/*     */         } catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */     imageProducer.removeConsumer(this);
/*     */   }
/*     */   
/*     */   public void setProperties(Hashtable paramHashtable) {}
/*     */   
/*     */   public void setColorModel(ColorModel paramColorModel) {}
/*     */   
/*     */   public void setHints(int paramInt) {}
/*     */   
/*     */   public void imageComplete(int paramInt) {
/*     */     if (paramInt == 1 || paramInt == 4)
/*     */       if (this.trycnt < 3) {
/*     */         this.trycnt++;
/*     */         produce(this.image);
/*     */       } else {
/*     */         paramInt = 3;
/*     */       }  
/*     */     if (paramInt == 3 || paramInt == 2) {
/*     */       this.complete = true;
/*     */       notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setDimensions(int paramInt1, int paramInt2) {
/*     */     if (this.region) {
/*     */       paramInt1 = this.sx2 - this.sx1 + 1;
/*     */       paramInt2 = this.sy2 - this.sy1 + 1;
/*     */     } 
/*     */     if (this.pix == null || paramInt1 != this.width || paramInt2 != this.height)
/*     */       this.pix = new int[this.width = paramInt1][this.height = paramInt2]; 
/*     */     this.iwidth = this.width;
/*     */     this.iheight = this.height;
/*     */   }
/*     */   
/*     */   public void setPixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4, ColorModel paramColorModel, byte[] paramArrayOfByte, int paramInt5, int paramInt6) {
/*     */     int i = 0, j = 0, n = paramInt5, i1 = paramInt5;
/*     */     int k = paramInt1 + paramInt3;
/*     */     int m = paramInt2 + paramInt4;
/*     */     for (j = paramInt2; j < m; j++) {
/*     */       n = i1;
/*     */       for (i = paramInt1; i < k && n < paramArrayOfByte.length; i++) {
/*     */         if (this.region) {
/*     */           if (i >= this.sx1 && i <= this.sx2 && j >= this.sy1 && j <= this.sy2) {
/*     */             this.pix[i - this.sx1][j - this.sy1] = getInt(paramArrayOfByte[n++]);
/*     */             if (paramColorModel != null)
/*     */               this.pix[i - this.sx1][j - this.sy1] = paramColorModel.getRGB(this.pix[i - this.sx1][j - this.sy1]); 
/*     */           } 
/*     */         } else {
/*     */           this.pix[i][j] = getInt(paramArrayOfByte[n++]);
/*     */           if (paramColorModel != null)
/*     */             this.pix[i][j] = paramColorModel.getRGB(this.pix[i][j]); 
/*     */         } 
/*     */       } 
/*     */       i1 += paramInt6;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setPixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4, ColorModel paramColorModel, int[] paramArrayOfInt, int paramInt5, int paramInt6) {
/*     */     int i = 0, j = 0;
/*     */     int k = paramInt1 + paramInt3;
/*     */     int m = paramInt2 + paramInt4;
/*     */     int n = paramInt5;
/*     */     for (j = paramInt2; j < m; j++) {
/*     */       int i1 = n;
/*     */       for (i = paramInt1; i < k && i1 < paramArrayOfInt.length; i++) {
/*     */         if (this.region) {
/*     */           if (i >= this.sx1 && i <= this.sx2 && j >= this.sy1 && j <= this.sy2)
/*     */             this.pix[i - this.sx1][j - this.sy1] = paramColorModel.getRGB(paramArrayOfInt[i1++]); 
/*     */         } else {
/*     */           this.pix[i][j] = paramColorModel.getRGB(paramArrayOfInt[i1++]);
/*     */         } 
/*     */       } 
/*     */       n += paramInt6;
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getInt(byte paramByte) { return paramByte & 0xFF; }
/*     */   
/*     */   public int hashCode() { return this.image.hashCode() + this.sx1 + this.sy1 + this.sx2 + this.sy2; }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*     */     if (!(paramObject instanceof PixelConsumer))
/*     */       return false; 
/*     */     PixelConsumer pixelConsumer = (PixelConsumer)paramObject;
/*     */     return (this.image == pixelConsumer.image && this.sx1 == pixelConsumer.sx1 && this.sy1 == pixelConsumer.sy1 && this.sx2 == pixelConsumer.sx2 && this.sy2 == pixelConsumer.sy2);
/*     */   }
/*     */   
/*     */   static class Key {
/*     */     Image image;
/*     */     int sx1;
/*     */     int sy1;
/*     */     int sx2;
/*     */     int sy2;
/*     */     
/*     */     public Key(PixelConsumer param1PixelConsumer) {
/*     */       this.image = param1PixelConsumer.image;
/*     */       this.sx1 = param1PixelConsumer.sx1;
/*     */       this.sx2 = param1PixelConsumer.sx2;
/*     */       this.sy1 = param1PixelConsumer.sy1;
/*     */       this.sy2 = param1PixelConsumer.sy2;
/*     */     }
/*     */     
/*     */     public int hashCode() { return this.image.hashCode() + this.sx1 + this.sy1 + this.sx2 + this.sy2; }
/*     */     
/*     */     public boolean equals(Object param1Object) {
/*     */       try {
/*     */         Key key = (Key)param1Object;
/*     */         return (this.image == key.image && this.sx1 == key.sx1 && this.sy1 == key.sy1 && this.sx2 == key.sx2 && this.sy2 == key.sy2);
/*     */       } catch (Exception exception) {
/*     */         return false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\PixelConsumer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */