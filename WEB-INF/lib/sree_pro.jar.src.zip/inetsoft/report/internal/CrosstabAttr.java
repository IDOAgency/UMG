package inetsoft.report.internal;

import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import inetsoft.report.filter.CrossTabFilter;
import inetsoft.report.filter.DefaultComparer;
import inetsoft.report.filter.Formula;
import inetsoft.report.filter.SortFilter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

public class CrosstabAttr extends FilterAttr {
  public TableFilter createFilter(TableLens paramTableLens) {
    int[] arrayOfInt = findColumns(paramTableLens, getRowHeaders());
    int i = findColumn(paramTableLens, getColHeader());
    int j = findColumn(paramTableLens, getSummaryCol());
    Formula formula1 = createFormula(getFormula());
    if (arrayOfInt == null || i < 0 || j < 0) {
      System.err.println("Columns defined in Crosstab filter not found in table");
      return null;
    } 
    CrossTabFilter crossTabFilter = new CrossTabFilter(paramTableLens, arrayOfInt, i, j, formula1);
    crossTabFilter.setKeepColumnHeaders(isKeepColHeader());
    if (getColOrder() != 0) {
      DefaultComparer defaultComparer = new DefaultComparer();
      defaultComparer.setNegate((getColOrder() == 2));
      crossTabFilter.setColHeaderSorting(defaultComparer);
    } 
    if (getRowOrder() == 0)
      return crossTabFilter; 
    return new SortFilter(crossTabFilter, new int[] { 0 }, (getRowOrder() == 1));
  }
  
  public void addRowHeader(String paramString) {
    if (this.rowHeaders.indexOf(paramString) < 0)
      this.rowHeaders.addElement(paramString); 
  }
  
  public void removeRowHeader(String paramString) { this.rowHeaders.removeElement(paramString); }
  
  public String[] getRowHeaders() {
    String[] arrayOfString = new String[this.rowHeaders.size()];
    this.rowHeaders.copyInto(arrayOfString);
    return arrayOfString;
  }
  
  public void setColHeader(String paramString) { this.colHeader = paramString; }
  
  public String getColHeader() { return this.colHeader; }
  
  public void setSummaryCol(String paramString) { this.sum = paramString; }
  
  public String getSummaryCol() { return this.sum; }
  
  public void setFormula(String paramString) { this.formula = paramString; }
  
  public String getFormula() { return this.formula; }
  
  public void setRowOrder(int paramInt) { this.orderR = paramInt; }
  
  public int getRowOrder() { return this.orderR; }
  
  public void setColOrder(int paramInt) { this.orderC = paramInt; }
  
  public int getColOrder() { return this.orderC; }
  
  public void setKeepColHeader(boolean paramBoolean) { this.keep = paramBoolean; }
  
  public boolean isKeepColHeader() { return this.keep; }
  
  public void writeXML(PrintWriter paramPrintWriter) {
    paramPrintWriter.println("<filter type=\"crosstab\">");
    paramPrintWriter.println("<crosstab orderR=\"" + this.orderR + "\" orderC=\"" + this.orderC + "\" formula=\"" + this.formula + "\" keepHeader=\"" + this.keep + "\">");
    if (this.colHeader != null)
      paramPrintWriter.println("<colHeader><![CDATA[" + this.colHeader + "]]></colHeader>"); 
    if (this.sum != null)
      paramPrintWriter.println("<sumCol><![CDATA[" + this.sum + "]]></sumCol>"); 
    for (byte b = 0; b < this.rowHeaders.size(); b++)
      paramPrintWriter.println("<rowHeader><![CDATA[" + this.rowHeaders.elementAt(b) + "]]></rowHeader>"); 
    paramPrintWriter.println("</crosstab>");
    paramPrintWriter.println("</filter>");
  }
  
  public void parseXML(XMLTokenStream paramXMLTokenStream) throws IOException, XMLException {
    XMLTokenStream.Tag tag = (XMLTokenStream.Tag)paramXMLTokenStream.getToken();
    if (tag.is("crosstab")) {
      String str;
      if ((str = tag.get("orderC")) != null)
        this.orderC = Integer.parseInt(str); 
      if ((str = tag.get("orderR")) != null)
        this.orderR = Integer.parseInt(str); 
      if ((str = tag.get("keepHeader")) != null)
        this.keep = str.equalsIgnoreCase("true"); 
      this.formula = tag.get("formula");
      Object object;
      while ((object = paramXMLTokenStream.getToken()) != null) {
        if (!(object instanceof XMLTokenStream.Tag))
          continue; 
        XMLTokenStream.Tag tag1 = (XMLTokenStream.Tag)object;
        if (tag1.is("/crosstab"))
          break; 
        if (tag1.is("rowHeader")) {
          addRowHeader((String)paramXMLTokenStream.getToken());
          continue;
        } 
        if (tag1.is("colHeader")) {
          setColHeader((String)paramXMLTokenStream.getToken());
          continue;
        } 
        if (tag1.is("sumCol"))
          setSummaryCol((String)paramXMLTokenStream.getToken()); 
      } 
    } 
  }
  
  private Vector rowHeaders = new Vector();
  
  private String colHeader;
  
  private String sum;
  
  private String formula = "Sum";
  
  private int orderR = 0;
  
  private int orderC = 0;
  
  private boolean keep = false;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\CrosstabAttr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */