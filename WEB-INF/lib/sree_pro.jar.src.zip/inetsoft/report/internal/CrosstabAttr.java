/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.TableFilter;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.filter.CrossTabFilter;
/*     */ import inetsoft.report.filter.DefaultComparer;
/*     */ import inetsoft.report.filter.Formula;
/*     */ import inetsoft.report.filter.SortFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CrosstabAttr
/*     */   extends FilterAttr
/*     */ {
/*     */   public TableFilter createFilter(TableLens paramTableLens) {
/*  32 */     int[] arrayOfInt = findColumns(paramTableLens, getRowHeaders());
/*  33 */     int i = findColumn(paramTableLens, getColHeader());
/*  34 */     int j = findColumn(paramTableLens, getSummaryCol());
/*  35 */     Formula formula1 = createFormula(getFormula());
/*     */     
/*  37 */     if (arrayOfInt == null || i < 0 || j < 0) {
/*  38 */       System.err.println("Columns defined in Crosstab filter not found in table");
/*  39 */       return null;
/*     */     } 
/*     */     
/*  42 */     CrossTabFilter crossTabFilter = new CrossTabFilter(paramTableLens, arrayOfInt, i, j, formula1);
/*     */ 
/*     */     
/*  45 */     crossTabFilter.setKeepColumnHeaders(isKeepColHeader());
/*  46 */     if (getColOrder() != 0) {
/*  47 */       DefaultComparer defaultComparer = new DefaultComparer();
/*  48 */       defaultComparer.setNegate((getColOrder() == 2));
/*  49 */       crossTabFilter.setColHeaderSorting(defaultComparer);
/*     */     } 
/*     */     
/*  52 */     if (getRowOrder() == 0) {
/*  53 */       return crossTabFilter;
/*     */     }
/*     */     
/*  56 */     return new SortFilter(crossTabFilter, new int[] { 0 }, (getRowOrder() == 1));
/*     */   }
/*     */   
/*     */   public void addRowHeader(String paramString) {
/*  60 */     if (this.rowHeaders.indexOf(paramString) < 0) {
/*  61 */       this.rowHeaders.addElement(paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*  66 */   public void removeRowHeader(String paramString) { this.rowHeaders.removeElement(paramString); }
/*     */ 
/*     */   
/*     */   public String[] getRowHeaders() {
/*  70 */     String[] arrayOfString = new String[this.rowHeaders.size()];
/*  71 */     this.rowHeaders.copyInto(arrayOfString);
/*  72 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */   
/*  76 */   public void setColHeader(String paramString) { this.colHeader = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  80 */   public String getColHeader() { return this.colHeader; }
/*     */ 
/*     */ 
/*     */   
/*  84 */   public void setSummaryCol(String paramString) { this.sum = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  88 */   public String getSummaryCol() { return this.sum; }
/*     */ 
/*     */ 
/*     */   
/*  92 */   public void setFormula(String paramString) { this.formula = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  96 */   public String getFormula() { return this.formula; }
/*     */ 
/*     */ 
/*     */   
/* 100 */   public void setRowOrder(int paramInt) { this.orderR = paramInt; }
/*     */ 
/*     */ 
/*     */   
/* 104 */   public int getRowOrder() { return this.orderR; }
/*     */ 
/*     */ 
/*     */   
/* 108 */   public void setColOrder(int paramInt) { this.orderC = paramInt; }
/*     */ 
/*     */ 
/*     */   
/* 112 */   public int getColOrder() { return this.orderC; }
/*     */ 
/*     */ 
/*     */   
/* 116 */   public void setKeepColHeader(boolean paramBoolean) { this.keep = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 120 */   public boolean isKeepColHeader() { return this.keep; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeXML(PrintWriter paramPrintWriter) {
/* 127 */     paramPrintWriter.println("<filter type=\"crosstab\">");
/* 128 */     paramPrintWriter.println("<crosstab orderR=\"" + this.orderR + "\" orderC=\"" + this.orderC + "\" formula=\"" + this.formula + "\" keepHeader=\"" + this.keep + "\">");
/*     */ 
/*     */ 
/*     */     
/* 132 */     if (this.colHeader != null) {
/* 133 */       paramPrintWriter.println("<colHeader><![CDATA[" + this.colHeader + "]]></colHeader>");
/*     */     }
/*     */     
/* 136 */     if (this.sum != null) {
/* 137 */       paramPrintWriter.println("<sumCol><![CDATA[" + this.sum + "]]></sumCol>");
/*     */     }
/*     */     
/* 140 */     for (byte b = 0; b < this.rowHeaders.size(); b++) {
/* 141 */       paramPrintWriter.println("<rowHeader><![CDATA[" + this.rowHeaders.elementAt(b) + "]]></rowHeader>");
/*     */     }
/*     */ 
/*     */     
/* 145 */     paramPrintWriter.println("</crosstab>");
/* 146 */     paramPrintWriter.println("</filter>");
/*     */   }
/*     */   
/*     */   public void parseXML(XMLTokenStream paramXMLTokenStream) throws IOException, XMLException {
/* 150 */     XMLTokenStream.Tag tag = (XMLTokenStream.Tag)paramXMLTokenStream.getToken();
/* 151 */     if (tag.is("crosstab")) {
/*     */       String str;
/*     */       
/* 154 */       if ((str = tag.get("orderC")) != null) {
/* 155 */         this.orderC = Integer.parseInt(str);
/*     */       }
/*     */       
/* 158 */       if ((str = tag.get("orderR")) != null) {
/* 159 */         this.orderR = Integer.parseInt(str);
/*     */       }
/*     */       
/* 162 */       if ((str = tag.get("keepHeader")) != null) {
/* 163 */         this.keep = str.equalsIgnoreCase("true");
/*     */       }
/*     */       
/* 166 */       this.formula = tag.get("formula");
/*     */       
/*     */       Object object;
/* 169 */       while ((object = paramXMLTokenStream.getToken()) != null) {
/* 170 */         if (!(object instanceof XMLTokenStream.Tag)) {
/*     */           continue;
/*     */         }
/*     */         
/* 174 */         XMLTokenStream.Tag tag1 = (XMLTokenStream.Tag)object;
/* 175 */         if (tag1.is("/crosstab")) {
/*     */           break;
/*     */         }
/* 178 */         if (tag1.is("rowHeader")) {
/* 179 */           addRowHeader((String)paramXMLTokenStream.getToken()); continue;
/*     */         } 
/* 181 */         if (tag1.is("colHeader")) {
/* 182 */           setColHeader((String)paramXMLTokenStream.getToken()); continue;
/*     */         } 
/* 184 */         if (tag1.is("sumCol")) {
/* 185 */           setSummaryCol((String)paramXMLTokenStream.getToken());
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/* 191 */   private Vector rowHeaders = new Vector();
/*     */   private String colHeader;
/*     */   private String sum;
/* 194 */   private String formula = "Sum";
/* 195 */   private int orderR = 0;
/* 196 */   private int orderC = 0;
/*     */   private boolean keep = false;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\CrosstabAttr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */