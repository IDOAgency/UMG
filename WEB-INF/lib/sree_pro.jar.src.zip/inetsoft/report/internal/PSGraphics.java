/*      */ package inetsoft.report.internal;
/*      */ 
/*      */ import inetsoft.report.Common;
/*      */ import inetsoft.report.Margin;
/*      */ import inetsoft.report.StyleSheet;
/*      */ import java.awt.Color;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Image;
/*      */ import java.awt.Point;
/*      */ import java.awt.Polygon;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Shape;
/*      */ import java.awt.image.ImageObserver;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.Serializable;
/*      */ import java.text.AttributedCharacterIterator;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PSGraphics
/*      */   extends Graphics
/*      */   implements Serializable, Cloneable
/*      */ {
/*      */   private boolean closed;
/*      */   private Point center;
/*      */   private Vector oblique;
/*      */   protected int pageheight;
/*      */   protected int pagewidth;
/*      */   protected static final int RESOLUTION = 72;
/*      */   
/*   51 */   public PSGraphics(File paramFile) throws IOException { this(new FileOutputStream(paramFile)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   62 */   public PSGraphics(String paramString) throws IOException { this(Runtime.getRuntime().exec(paramString).getOutputStream()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PSGraphics(OutputStream paramOutputStream)
/*      */   {
/* 1715 */     this.closed = false;
/* 1716 */     this.center = new Point(0, 0);
/* 1717 */     this.oblique = new Vector();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1722 */     this.pageheight = 792;
/*      */ 
/*      */ 
/*      */     
/* 1726 */     this.pagewidth = 612;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1742 */     this.writer = new PrintWriter(System.out);
/*      */     
/* 1744 */     this.orientation = 1;
/*      */     
/* 1746 */     this.clr = Color.black;
/*      */ 
/*      */     
/* 1749 */     this.backClr = Color.white;
/*      */     
/* 1751 */     this.font = new Font("Helvetica", 0, 10);
/* 1752 */     this.cloned = false;
/* 1753 */     this.savelevel = 0;
/* 1754 */     this.clippingRect = new Rectangle(0, 0, this.pagewidth, this.pageheight);
/* 1755 */     this.disposed = false;
/* 1756 */     this.inited = false;
/* 1757 */     this.fontset = new Hashtable();
/* 1758 */     this.compressImg = true;
/*      */ 
/*      */ 
/*      */     
/* 1762 */     fontmap.put("dialog", "Helvetica");
/* 1763 */     fontmap.put("dialoginput", "Courier");
/* 1764 */     fontmap.put("serif", "Times");
/* 1765 */     fontmap.put("sansserif", "Helvetica");
/* 1766 */     fontmap.put("monospaced", "Courier");
/* 1767 */     fontmap.put("timesroman", "Times");
/* 1768 */     fontmap.put("courier", "Courier");
/* 1769 */     fontmap.put("helvetica", "Helvetica");
/*      */     
/* 1771 */     this.oblique.addElement("Courier");
/* 1772 */     this.oblique.addElement("Helvetica");
/* 1773 */     this.oblique.addElement("Courier"); setOutput(paramOutputStream); } public PSGraphics() { this.closed = false; this.center = new Point(0, 0); this.oblique = new Vector(); this.pageheight = 792; this.pagewidth = 612; this.writer = new PrintWriter(System.out); this.orientation = 1; this.clr = Color.black; this.backClr = Color.white; this.font = new Font("Helvetica", 0, 10); this.cloned = false; this.savelevel = 0; this.clippingRect = new Rectangle(0, 0, this.pagewidth, this.pageheight); this.disposed = false; this.inited = false; this.fontset = new Hashtable(); this.compressImg = true; fontmap.put("dialog", "Helvetica"); fontmap.put("dialoginput", "Courier"); fontmap.put("serif", "Times"); fontmap.put("sansserif", "Helvetica"); fontmap.put("monospaced", "Courier"); fontmap.put("timesroman", "Times"); fontmap.put("courier", "Courier"); fontmap.put("helvetica", "Helvetica"); this.oblique.addElement("Courier"); this.oblique.addElement("Helvetica"); this.oblique.addElement("Courier"); } public void setOutput(OutputStream paramOutputStream) { this.writer = new PrintWriter(this.os = paramOutputStream); } public void setCompressImage(boolean paramBoolean) { this.compressImg = paramBoolean; } public boolean isCompressImage() { return this.compressImg; } public void setPageSize(double paramDouble1, double paramDouble2) {
/*      */     this.pagewidth = (int)Math.ceil(72.0D * paramDouble1);
/*      */     this.pageheight = (int)Math.ceil(72.0D * paramDouble2);
/*      */     this.clippingRect = new Rectangle(0, 0, this.pagewidth, this.pageheight);
/* 1777 */   } public Dimension getPageDimension() { return new Dimension(this.pagewidth, this.pageheight); } public void setOrientation(int paramInt) { this.orientation = paramInt; } void debug(PrintWriter paramPrintWriter, String paramString) { this.writer.println(paramString); }
/*      */   
/*      */   public int getOrientation() { return this.orientation; }
/*      */   
/*      */   public Graphics create() {
/*      */     try {
/*      */       debug(this.writer, "%create");
/*      */       PSGraphics pSGraphics = (PSGraphics)clone();
/*      */       pSGraphics.center = new Point(this.center);
/*      */       pSGraphics.savelevel = 0;
/*      */       pSGraphics.cloned = true;
/*      */       pSGraphics.gsave();
/*      */       pSGraphics.gsave();
/*      */       return pSGraphics;
/*      */     } catch (Exception exception) {
/*      */       exception.printStackTrace();
/*      */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void translate(int paramInt1, int paramInt2) {
/*      */     debug(this.writer, "%translate");
/*      */     this.center.x += paramInt1;
/*      */     this.center.y += paramInt2;
/*      */   }
/*      */   
/*      */   public Color getColor() { return this.clr; }
/*      */   
/*      */   public void setColor(Color paramColor) {
/*      */     debug(this.writer, "%setColor");
/*      */     this.clr = (paramColor != null) ? paramColor : this.backClr;
/*      */     this.writer.print(this.clr.getRed() / 255.0D);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(this.clr.getGreen() / 255.0D);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(this.clr.getBlue() / 255.0D);
/*      */     this.writer.println(" setrgbcolor");
/*      */   }
/*      */   
/*      */   public void setBackground(Color paramColor) { this.backClr = paramColor; }
/*      */   
/*      */   public void setPaintMode() {}
/*      */   
/*      */   public void setXORMode(Color paramColor) { System.err.println("Not supported"); }
/*      */   
/*      */   public Font getFont() { return this.font; }
/*      */   
/*      */   public void setFont(Font paramFont) {
/*      */     debug(this.writer, "%setFont");
/*      */     if (paramFont != null) {
/*      */       this.font = paramFont;
/*      */       int i = this.font.getStyle();
/*      */       String str1 = getFontName(this.font);
/*      */       if ((i & true) != 0 && (i & 0x2) != 0) {
/*      */         str1 = str1 + (this.oblique.contains(str1) ? "-BoldOblique" : "-BoldItalic");
/*      */       } else if ((i & true) != 0) {
/*      */         str1 = str1 + "-Bold";
/*      */       } else if ((i & 0x2) != 0) {
/*      */         str1 = str1 + (this.oblique.contains(str1) ? "-Oblique" : "-Italic");
/*      */       } else if (str1.equals("Times")) {
/*      */         str1 = str1 + "-Roman";
/*      */       } 
/*      */       String str2 = Util.remove(str1, ' ');
/*      */       if (this.fontset.get(str1) == null) {
/*      */         this.writer.println("/(" + str2 + ") findfont");
/*      */         this.writer.println("dup length dict begin");
/*      */         this.writer.println("{1 index /FID ne {def} {pop pop} ifelse} forall");
/*      */         this.writer.println("/Encoding ISOLatin1Encoding def");
/*      */         this.writer.println("currentdict");
/*      */         this.writer.println("end");
/*      */         this.writer.println("/" + str2 + "-ISOLatin1 exch definefont pop");
/*      */         this.fontset.put(str1, str1);
/*      */       } 
/*      */       this.writer.println("/" + str2 + "-ISOLatin1 findfont");
/*      */       this.writer.print(this.font.getSize());
/*      */       this.writer.println(" scalefont setfont");
/*      */     } 
/*      */   }
/*      */   
/*      */   public FontMetrics getFontMetrics() { return getFontMetrics(getFont()); }
/*      */   
/*      */   public FontMetrics getFontMetrics(Font paramFont) { return Common.getFontMetrics(paramFont); }
/*      */   
/*      */   public Rectangle getClipBounds() { return new Rectangle(this.clippingRect.x - this.center.x, this.clippingRect.y - this.center.y, this.clippingRect.width, this.clippingRect.height); }
/*      */   
/*      */   public Shape getClip() { return getClipBounds(); }
/*      */   
/*      */   public void clipRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { clipRect(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */   
/*      */   public void clipRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*      */     debug(this.writer, "%clipRect");
/*      */     this.clippingRect = this.clippingRect.intersection(new Rectangle((int)paramDouble1 + this.center.x, (int)paramDouble2 + this.center.y, (int)paramDouble3, (int)paramDouble4));
/*      */     paramDouble2 = transformY(paramDouble2);
/*      */     paramDouble1 = transformX(paramDouble1);
/*      */     this.writer.println(paramDouble1 + " " + paramDouble2 + " moveto");
/*      */     this.writer.println((paramDouble1 + paramDouble3) + " " + paramDouble2 + " lineto");
/*      */     this.writer.println((paramDouble1 + paramDouble3) + " " + (paramDouble2 - paramDouble4) + " lineto");
/*      */     this.writer.println(paramDouble1 + " " + (paramDouble2 - paramDouble4) + " lineto");
/*      */     this.writer.println("closepath eoclip newpath");
/*      */   }
/*      */   
/*      */   public void setClip(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { setClip(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */   
/*      */   public void setClip(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*      */     debug(this.writer, "%setClip");
/*      */     this.clippingRect = new Rectangle((int)paramDouble1 + this.center.x, (int)paramDouble2 + this.center.y, (int)paramDouble3, (int)paramDouble4);
/*      */     paramDouble2 = transformY(paramDouble2);
/*      */     paramDouble1 = transformX(paramDouble1);
/*      */     this.writer.println("initclip");
/*      */     this.writer.println(paramDouble1 + " " + paramDouble2 + " moveto");
/*      */     this.writer.println((paramDouble1 + paramDouble3) + " " + paramDouble2 + " lineto");
/*      */     this.writer.println((paramDouble1 + paramDouble3) + " " + (paramDouble2 - paramDouble4) + " lineto");
/*      */     this.writer.println(paramDouble1 + " " + (paramDouble2 - paramDouble4) + " lineto");
/*      */     this.writer.println("closepath eoclip newpath");
/*      */   }
/*      */   
/*      */   public void setClip(Shape paramShape) {
/*      */     Rectangle rectangle = (Rectangle)paramShape;
/*      */     setClip(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*      */   }
/*      */   
/*      */   public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { throw new RuntimeException("copyArea not supported"); }
/*      */   
/*      */   public void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { drawLine(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */   
/*      */   public void drawLine(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*      */     debug(this.writer, "%drawLine");
/*      */     paramDouble2 = transformY(paramDouble2);
/*      */     paramDouble4 = transformY(paramDouble4);
/*      */     paramDouble1 = transformX(paramDouble1);
/*      */     paramDouble3 = transformX(paramDouble3);
/*      */     this.writer.print(paramDouble1);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2);
/*      */     this.writer.print(" moveto ");
/*      */     this.writer.print(paramDouble3);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble4);
/*      */     this.writer.println(" lineto stroke");
/*      */   }
/*      */   
/*      */   public void drawPolyline(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) {
/*      */     for (byte b = 1; b < paramInt; b++)
/*      */       drawLine(paramArrayOfInt1[b - true], paramArrayOfInt2[b - true], paramArrayOfInt1[b], paramArrayOfInt2[b]); 
/*      */   }
/*      */   
/*      */   void doRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean) {
/*      */     debug(this.writer, "%doRect");
/*      */     paramDouble2 = transformY(paramDouble2);
/*      */     paramDouble1 = transformX(paramDouble1);
/*      */     this.writer.print(paramDouble1);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2);
/*      */     this.writer.println(" moveto ");
/*      */     this.writer.print(paramDouble1 + paramDouble3);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2);
/*      */     this.writer.println(" lineto ");
/*      */     this.writer.print(paramDouble1 + paramDouble3);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2 - paramDouble4);
/*      */     this.writer.println(" lineto ");
/*      */     this.writer.print(paramDouble1);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2 - paramDouble4);
/*      */     this.writer.println(" lineto ");
/*      */     this.writer.print(paramDouble1);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2);
/*      */     this.writer.println(" lineto ");
/*      */     if (paramBoolean) {
/*      */       this.writer.println("eofill");
/*      */     } else {
/*      */       this.writer.println("stroke");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void fillRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { fillRect(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */   
/*      */   public void fillRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*      */     debug(this.writer, "%fillRect");
/*      */     doRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, true);
/*      */   }
/*      */   
/*      */   public void drawRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { drawRect(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */   
/*      */   public void drawRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*      */     debug(this.writer, "%drawRect");
/*      */     doRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, false);
/*      */   }
/*      */   
/*      */   public void clearRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { clearRect(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */   
/*      */   public void clearRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*      */     debug(this.writer, "%clearRect");
/*      */     gsave();
/*      */     Color color = getColor();
/*      */     setColor(this.backClr);
/*      */     doRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, true);
/*      */     setColor(color);
/*      */     grestore();
/*      */   }
/*      */   
/*      */   private void doRoundRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, boolean paramBoolean) {
/*      */     debug(this.writer, "%doRoundRect");
/*      */     paramDouble2 = transformY(paramDouble2);
/*      */     paramDouble1 = transformX(paramDouble1);
/*      */     this.writer.print(paramDouble1 + paramDouble6);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2);
/*      */     this.writer.println(" moveto");
/*      */     this.writer.print(paramDouble1 + paramDouble3);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble1 + paramDouble3);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2 - paramDouble4);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble6);
/*      */     this.writer.println(" arcto");
/*      */     this.writer.println("4 {pop} repeat");
/*      */     this.writer.print(paramDouble1 + paramDouble3);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2 - paramDouble4);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble1);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2 - paramDouble4);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble6);
/*      */     this.writer.println(" arcto");
/*      */     this.writer.println("4 {pop} repeat");
/*      */     this.writer.print(paramDouble1);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2 - paramDouble4);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble1);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble6);
/*      */     this.writer.println(" arcto");
/*      */     this.writer.println("4 {pop} repeat");
/*      */     this.writer.print(paramDouble1);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble1 + paramDouble3);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble2);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble6);
/*      */     this.writer.println(" arcto");
/*      */     this.writer.println("4 {pop} repeat");
/*      */     if (paramBoolean) {
/*      */       this.writer.println("eofill");
/*      */     } else {
/*      */       this.writer.println("stroke");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void drawRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { drawRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*      */   
/*      */   public void drawRoundRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*      */     debug(this.writer, "%drawRoundRect");
/*      */     doRoundRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, false);
/*      */   }
/*      */   
/*      */   public void fillRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { fillRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*      */   
/*      */   public void fillRoundRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*      */     debug(this.writer, "%fillRoundRect");
/*      */     doRoundRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, true);
/*      */   }
/*      */   
/*      */   public void draw3DRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) { draw3DRect(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean); }
/*      */   
/*      */   public void draw3DRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean) {
/*      */     debug(this.writer, "%draw3DRect");
/*      */     paramDouble2 = transformY(paramDouble2);
/*      */     paramDouble1 = transformX(paramDouble1);
/*      */     Color color1 = getColor();
/*      */     Color color2 = color1.brighter();
/*      */     Color color3 = color1.darker();
/*      */     setColor(paramBoolean ? color2 : color3);
/*      */     drawLine(paramDouble1, paramDouble2, paramDouble1, paramDouble2 - paramDouble4);
/*      */     drawLine(paramDouble1 + 1.0D, paramDouble2, paramDouble1 + paramDouble3 - 1.0D, paramDouble2);
/*      */     setColor(paramBoolean ? color3 : color2);
/*      */     drawLine(paramDouble1 + 1.0D, paramDouble2 - paramDouble4, paramDouble1 + paramDouble3, paramDouble2 - paramDouble4);
/*      */     drawLine(paramDouble1 + paramDouble3, paramDouble2, paramDouble1 + paramDouble3, paramDouble2 - paramDouble4);
/*      */     setColor(color1);
/*      */   }
/*      */   
/*      */   public void fill3DRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) { fill3DRect(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean); }
/*      */   
/*      */   public void fill3DRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean) {
/*      */     debug(this.writer, "%fill3DRect");
/*      */     paramDouble2 = transformY(paramDouble2);
/*      */     paramDouble1 = transformX(paramDouble1);
/*      */     Color color1 = getColor();
/*      */     Color color2 = color1.brighter();
/*      */     Color color3 = color1.darker();
/*      */     if (!paramBoolean)
/*      */       setColor(color3); 
/*      */     fillRect(paramDouble1 + 1.0D, paramDouble2 + 1.0D, paramDouble3 - 2.0D, paramDouble4 - 2.0D);
/*      */     setColor(paramBoolean ? color2 : color3);
/*      */     drawLine(paramDouble1, paramDouble2, paramDouble1, paramDouble2 - paramDouble4 - 1.0D);
/*      */     drawLine(paramDouble1 + 1.0D, paramDouble2, paramDouble1 + paramDouble3 - 2.0D, paramDouble2);
/*      */     setColor(paramBoolean ? color3 : color2);
/*      */     drawLine(paramDouble1 + 1.0D, paramDouble2 - paramDouble4 - 1.0D, paramDouble1 + paramDouble3 - 1.0D, paramDouble2 - paramDouble4 - 1.0D);
/*      */     drawLine(paramDouble1 + paramDouble3 - 1.0D, paramDouble2, paramDouble1 + paramDouble3 - 1.0D, paramDouble2 - paramDouble4 - 1.0D);
/*      */     setColor(color1);
/*      */   }
/*      */   
/*      */   public void drawOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { drawOval(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */   
/*      */   public void drawOval(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*      */     debug(this.writer, "%drawOval");
/*      */     doArc(paramDouble1, paramDouble2, paramDouble3, paramDouble4, 0.0D, 360.0D, false);
/*      */   }
/*      */   
/*      */   public void fillOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { fillOval(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */   
/*      */   public void fillOval(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*      */     debug(this.writer, "%fillOval");
/*      */     doArc(paramDouble1, paramDouble2, paramDouble3, paramDouble4, 0.0D, 360.0D, true);
/*      */   }
/*      */   
/*      */   private void doArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, boolean paramBoolean) {
/*      */     debug(this.writer, "%doArc");
/*      */     paramDouble2 = transformY(paramDouble2);
/*      */     paramDouble1 = transformX(paramDouble1);
/*      */     gsave();
/*      */     double d1 = paramDouble1 + paramDouble3 / 2.0D;
/*      */     double d2 = paramDouble2 - paramDouble4 / 2.0D;
/*      */     this.writer.print(d1);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(d2);
/*      */     this.writer.println(" translate");
/*      */     double d3 = paramDouble4 / paramDouble3;
/*      */     this.writer.print(1.0D);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(d3);
/*      */     this.writer.println(" scale");
/*      */     if (paramBoolean) {
/*      */       this.writer.println("0 0 moveto");
/*      */     } else if (paramDouble5 == 0.0D && paramDouble6 == 360.0D) {
/*      */       this.writer.println((paramDouble3 / 2.0D) + " 0 moveto");
/*      */     } 
/*      */     double d4 = paramDouble5 + paramDouble6;
/*      */     this.writer.print("0 0 ");
/*      */     this.writer.print(paramDouble3 / 2.0D);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramDouble5);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(d4);
/*      */     this.writer.println(" arc");
/*      */     if (paramBoolean) {
/*      */       this.writer.println("closepath eofill");
/*      */     } else {
/*      */       this.writer.println("stroke");
/*      */     } 
/*      */     grestore();
/*      */   }
/*      */   
/*      */   public void drawArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { drawArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*      */   
/*      */   public void drawArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*      */     debug(this.writer, "%drawArc");
/*      */     doArc(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, false);
/*      */   }
/*      */   
/*      */   public void fillArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { fillArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*      */   
/*      */   public void fillArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*      */     debug(this.writer, "%fillArc");
/*      */     doArc(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, true);
/*      */   }
/*      */   
/*      */   private void doPoly(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt, boolean paramBoolean) {
/*      */     if (paramInt < 2)
/*      */       return; 
/*      */     int[] arrayOfInt1 = new int[paramInt];
/*      */     int[] arrayOfInt2 = new int[paramInt];
/*      */     byte b;
/*      */     for (b = 0; b < paramInt; b++) {
/*      */       arrayOfInt1[b] = (int)transformY(paramArrayOfInt2[b]);
/*      */       arrayOfInt2[b] = (int)transformX(paramArrayOfInt1[b]);
/*      */     } 
/*      */     this.writer.println(arrayOfInt2[0] + " " + arrayOfInt1[0] + " moveto");
/*      */     for (b = 0; b < paramInt; b++)
/*      */       this.writer.println(arrayOfInt2[b] + " " + arrayOfInt1[b] + " lineto"); 
/*      */     this.writer.println(arrayOfInt2[0] + " " + arrayOfInt1[0] + " lineto");
/*      */     if (paramBoolean) {
/*      */       this.writer.println("eofill");
/*      */     } else {
/*      */       this.writer.println("stroke");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void drawPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) {
/*      */     debug(this.writer, "%drawPoly");
/*      */     doPoly(paramArrayOfInt1, paramArrayOfInt2, paramInt, false);
/*      */   }
/*      */   
/*      */   public void drawPolygon(Polygon paramPolygon) {
/*      */     debug(this.writer, "%drawPoly");
/*      */     doPoly(paramPolygon.xpoints, paramPolygon.ypoints, paramPolygon.npoints, false);
/*      */   }
/*      */   
/*      */   public void fillPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) {
/*      */     debug(this.writer, "%fillPoly");
/*      */     doPoly(paramArrayOfInt1, paramArrayOfInt2, paramInt, true);
/*      */   }
/*      */   
/*      */   public void fillPolygon(Polygon paramPolygon) {
/*      */     debug(this.writer, "%fillPoly");
/*      */     doPoly(paramPolygon.xpoints, paramPolygon.ypoints, paramPolygon.npoints, true);
/*      */   }
/*      */   
/*      */   public void drawString(String paramString, int paramInt1, int paramInt2) { drawString(paramString, paramInt1, paramInt2); }
/*      */   
/*      */   public void drawString(String paramString, double paramDouble1, double paramDouble2) {
/*      */     debug(this.writer, "%drawString");
/*      */     if (paramString.trim().length() == 0)
/*      */       return; 
/*      */     paramDouble2 = transformY(paramDouble2);
/*      */     paramDouble1 = transformX(paramDouble1);
/*      */     byte b1 = 0, b2 = 1;
/*      */     for (byte b = 0; b < paramString.length(); b++) {
/*      */       if (paramString.charAt(b) == ' ')
/*      */         b1++; 
/*      */     } 
/*      */     b1 *= b2;
/*      */     String str = escapeString(paramString);
/*      */     this.writer.print(Common.stringWidth(paramString, getFont()) + " ");
/*      */     this.writer.println("(" + str + ") dup 3 1 roll ");
/*      */     this.writer.print("stringwidth pop " + b1 + " sub ");
/*      */     this.writer.println("sub " + paramString.length() + " div");
/*      */     this.writer.print(paramDouble1 + " " + paramDouble2 + " moveto ");
/*      */     this.writer.println("-" + b2 + " 0 32 4 -1 roll 0 6 -1 roll awidthshow");
/*      */   }
/*      */   
/*      */   public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, int paramInt1, int paramInt2) {}
/*      */   
/*      */   public void drawChars(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*      */     debug(this.writer, "%drawChars");
/*      */     drawString(new String(paramArrayOfChar, paramInt1, paramInt2), paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void drawBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*      */     debug(this.writer, "%drawBytes");
/*      */     drawString(new String(paramArrayOfByte, paramInt1, paramInt2), paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public boolean doImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
/*      */     PixelConsumer pixelConsumer = new PixelConsumer(paramImage);
/*      */     return doImage(pixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
/*      */   }
/*      */   
/*      */   public boolean doImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver, Color paramColor) {
/*      */     PixelConsumer pixelConsumer = new PixelConsumer(paramImage, paramInt5, paramInt6, paramInt7, paramInt8);
/*      */     return doImage(pixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
/*      */   }
/*      */   
/*      */   boolean doImage(PixelConsumer paramPixelConsumer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
/*      */     if (this.compressImg)
/*      */       return doImage2(paramPixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor); 
/*      */     return doImage1(paramPixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
/*      */   }
/*      */   
/*      */   boolean doImage2(PixelConsumer paramPixelConsumer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
/*      */     gsave();
/*      */     paramInt2 = (int)transformY(paramInt2);
/*      */     paramInt1 = (int)transformX(paramInt1);
/*      */     if (paramInt4 == 0 || paramInt3 == 0) {
/*      */       paramPixelConsumer.produce();
/*      */       paramInt4 = paramPixelConsumer.height;
/*      */       paramInt3 = paramPixelConsumer.width;
/*      */     } else {
/*      */       paramPixelConsumer.produce();
/*      */     } 
/*      */     this.writer.println("/DeviceRGB setcolorspace");
/*      */     this.writer.println(paramInt1 + " " + (paramInt2 - paramInt4) + " translate");
/*      */     this.writer.println(paramInt3 + " " + paramInt4 + " scale");
/*      */     this.writer.println("<<");
/*      */     this.writer.println("/ImageType 1");
/*      */     this.writer.println("/Width " + paramPixelConsumer.width);
/*      */     this.writer.println("/Height " + paramPixelConsumer.height);
/*      */     this.writer.println("/BitsPerComponent 8");
/*      */     this.writer.println("/Decode [0 1 0 1 0 1]");
/*      */     this.writer.println("/ImageMatrix [" + paramPixelConsumer.width + " 0 0 " + paramPixelConsumer.height + " 0 0]");
/*      */     this.writer.println("/DataSource currentfile /ASCII85Decode filter /FlateDecode filter");
/*      */     this.writer.println(">>");
/*      */     this.writer.println("image");
/*      */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*      */     for (int i = paramPixelConsumer.height - 1; i >= 0; i--) {
/*      */       for (byte b = 0; b < paramPixelConsumer.width; b++) {
/*      */         int j = paramPixelConsumer.pix[b][i];
/*      */         if ((j & 0xFF000000) == 0)
/*      */           j = (paramColor == null) ? 16777215 : paramColor.getRGB(); 
/*      */         byteArrayOutputStream.write((byte)((j & 0xFF0000) >> 16));
/*      */         byteArrayOutputStream.write((byte)((j & 0xFF00) >> 8));
/*      */         byteArrayOutputStream.write((byte)(j & 0xFF));
/*      */       } 
/*      */     } 
/*      */     byte[] arrayOfByte = Encoder.encodeAscii85(Encoder.deflate(byteArrayOutputStream.toByteArray()));
/*      */     this.writer.flush();
/*      */     try {
/*      */       for (int j = 0; j < arrayOfByte.length; j += 72) {
/*      */         if (j) {
/*      */           this.writer.println("");
/*      */           this.writer.flush();
/*      */         } 
/*      */         this.os.write(arrayOfByte, j, Math.min(arrayOfByte.length - j, 72));
/*      */       } 
/*      */     } catch (Exception exception) {
/*      */       exception.printStackTrace();
/*      */     } 
/*      */     this.writer.println("~>");
/*      */     grestore();
/*      */     return true;
/*      */   }
/*      */   
/*      */   boolean doImage1(PixelConsumer paramPixelConsumer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
/*      */     debug(this.writer, "%doImage");
/*      */     paramPixelConsumer.produce();
/*      */     paramInt2 = (int)transformY(paramInt2);
/*      */     paramInt1 = (int)transformX(paramInt1);
/*      */     gsave();
/*      */     debug(this.writer, "% build a temporary dictionary");
/*      */     this.writer.println("20 dict begin");
/*      */     emitColorImageProlog(paramPixelConsumer.width);
/*      */     debug(this.writer, "% lower left corner");
/*      */     this.writer.print(paramInt1);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramInt2);
/*      */     this.writer.println(" translate");
/*      */     if (paramInt4 == 0 || paramInt3 == 0) {
/*      */       paramInt4 = paramPixelConsumer.height;
/*      */       paramInt3 = paramPixelConsumer.width;
/*      */     } 
/*      */     debug(this.writer, "% size of image");
/*      */     this.writer.print(paramInt3);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramInt4);
/*      */     this.writer.println(" scale");
/*      */     this.writer.print(paramPixelConsumer.width);
/*      */     this.writer.print(" ");
/*      */     this.writer.print(paramPixelConsumer.height);
/*      */     this.writer.println(" 8");
/*      */     this.writer.print("[");
/*      */     this.writer.print(paramPixelConsumer.width);
/*      */     this.writer.print(" 0 0 -");
/*      */     this.writer.print(paramPixelConsumer.height);
/*      */     this.writer.print(" 0 ");
/*      */     this.writer.print(0);
/*      */     this.writer.println("]");
/*      */     this.writer.println("{currentfile pix readhexstring pop}");
/*      */     this.writer.println("false 3 colorimage");
/*      */     this.writer.println("");
/*      */     byte b1 = 0;
/*      */     char[] arrayOfChar = new char[73];
/*      */     for (byte b2 = 0; b2 < paramPixelConsumer.height; b2++) {
/*      */       byte b3 = 0;
/*      */       b1++;
/*      */       for (byte b4 = 0; b4 < paramPixelConsumer.width; b4++) {
/*      */         int i = paramPixelConsumer.pix[b4][b2];
/*      */         if ((i & 0xFF000000) == 0)
/*      */           i = (paramColor == null) ? 16777215 : paramColor.getRGB(); 
/*      */         arrayOfChar[b3++] = hd[(i & 0xF00000) >> 20];
/*      */         arrayOfChar[b3++] = hd[(i & 0xF0000) >> 16];
/*      */         arrayOfChar[b3++] = hd[(i & 0xF000) >> 12];
/*      */         arrayOfChar[b3++] = hd[(i & 0xF00) >> 8];
/*      */         arrayOfChar[b3++] = hd[(i & 0xF0) >> 4];
/*      */         arrayOfChar[b3++] = hd[i & 0xF];
/*      */         if (b3 >= 72) {
/*      */           String str = String.copyValueOf(arrayOfChar, 0, b3);
/*      */           this.writer.println(str);
/*      */           if (b1 > 5) {
/*      */             try {
/*      */               Thread.sleep(15L);
/*      */             } catch (InterruptedException interruptedException) {}
/*      */             b1 = 0;
/*      */           } 
/*      */           b3 = 0;
/*      */         } 
/*      */       } 
/*      */       if (b3 != 0) {
/*      */         String str = String.copyValueOf(arrayOfChar, 0, b3);
/*      */         this.writer.println(str);
/*      */       } 
/*      */     } 
/*      */     this.writer.println("");
/*      */     this.writer.println("end");
/*      */     grestore();
/*      */     return true;
/*      */   }
/*      */   
/*      */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, ImageObserver paramImageObserver) {
/*      */     debug(this.writer, "%drawImage-1");
/*      */     return doImage(paramImage, paramInt1, paramInt2, 0, 0, paramImageObserver, null);
/*      */   }
/*      */   
/*      */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver) {
/*      */     debug(this.writer, "%drawImage-2");
/*      */     return doImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, null);
/*      */   }
/*      */   
/*      */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, Color paramColor, ImageObserver paramImageObserver) {
/*      */     debug(this.writer, "%drawImage-3");
/*      */     return doImage(paramImage, paramInt1, paramInt2, 0, 0, paramImageObserver, paramColor);
/*      */   }
/*      */   
/*      */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, ImageObserver paramImageObserver) {
/*      */     debug(this.writer, "%drawImage-4");
/*      */     return doImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
/*      */   }
/*      */   
/*      */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver) {
/*      */     debug(this.writer, "%drawImage-5");
/*      */     return doImage(paramImage, paramInt1, paramInt2, paramInt3 - paramInt1 + 1, paramInt4 - paramInt2 + 1, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver, null);
/*      */   }
/*      */   
/*      */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, Color paramColor, ImageObserver paramImageObserver) {
/*      */     debug(this.writer, "%drawImage-6");
/*      */     return doImage(paramImage, paramInt1, paramInt2, paramInt3 - paramInt1 + 1, paramInt4 - paramInt2 + 1, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver, paramColor);
/*      */   }
/*      */   
/*      */   public void reset() {
/*      */     this.fontset.clear();
/*      */     this.disposed = false;
/*      */   }
/*      */   
/*      */   public void dispose() {
/*      */     if (this.disposed)
/*      */       return; 
/*      */     this.disposed = true;
/*      */     if (this.cloned) {
/*      */       while (this.savelevel > 0) {
/*      */         debug(this.writer, "%dispose");
/*      */         grestore();
/*      */       } 
/*      */     } else {
/*      */       debug(this.writer, "%dispose");
/*      */       this.writer.println("showpage");
/*      */       this.writer.flush();
/*      */       startPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void close() {
/*      */     if (!this.closed) {
/*      */       this.writer.println("%%EOF");
/*      */       this.writer.close();
/*      */       this.closed = true;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void finalize() { dispose(); }
/*      */   
/*      */   public String toString() { return getClass().getName() + "[font=" + getFont() + ",color=" + getColor() + "]"; }
/*      */   
/*      */   public double transformY(double paramDouble) { return -(paramDouble + this.center.y); }
/*      */   
/*      */   public double transformX(double paramDouble) { return paramDouble + this.center.x; }
/*      */   
/*      */   public double rtransformY(double paramDouble) { return -(paramDouble + this.center.y); }
/*      */   
/*      */   public double rtransformX(double paramDouble) { return paramDouble - this.center.x; }
/*      */   
/*      */   public void startDoc() {
/*      */     if (!this.inited) {
/*      */       this.writer.println("%!PS-Adobe-2.0 Created by PSGraphics Java Context");
/*      */       if (this.orientation == 0) {
/*      */         this.writer.println("2 dict dup /PageSize[ " + this.pageheight + " " + this.pagewidth + " ] put dup /ImagingBBox null put setpagedevice");
/*      */       } else {
/*      */         this.writer.println("2 dict dup /PageSize[ " + this.pagewidth + " " + this.pageheight + " ] put dup /ImagingBBox null put setpagedevice");
/*      */       } 
/*      */       startPage();
/*      */       this.inited = true;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void startPage() {
/*      */     Margin margin = StyleSheet.getPrinterMargin();
/*      */     if (this.orientation == 1) {
/*      */       this.writer.println((margin.left * 72.0D) + " " + (this.pageheight - margin.top * 72.0D) + " translate");
/*      */     } else if (this.orientation == 0) {
/*      */       this.writer.println((this.pageheight - margin.top * 72.0D) + " " + (this.pagewidth - margin.left * 72.0D) + " translate");
/*      */       this.writer.println("-90 rotate");
/*      */     } 
/*      */     setFont(this.font);
/*      */     gsave();
/*      */   }
/*      */   
/*      */   void emitColorImageProlog(int paramInt) {
/*      */     debug(this.writer, "% Color picture stuff, lifted from XV's PS files");
/*      */     debug(this.writer, "% define string to hold a scanline's worth of data");
/*      */     this.writer.print("/pix ");
/*      */     this.writer.print(paramInt * 3);
/*      */     this.writer.println(" string def");
/*      */     debug(this.writer, "% define space for color conversions");
/*      */     this.writer.print("/grays ");
/*      */     this.writer.print(paramInt);
/*      */     this.writer.println(" string def  % space for gray scale line");
/*      */     this.writer.println("/npixls 0 def");
/*      */     this.writer.println("/rgbindx 0 def");
/*      */     debug(this.writer, "% define 'colorimage' if it isn't defined");
/*      */     debug(this.writer, "%   ('colortogray' and 'mergeprocs' come from xwd2ps");
/*      */     debug(this.writer, "%     via xgrab)");
/*      */     this.writer.println("/colorimage where   % do we know about 'colorimage'?");
/*      */     this.writer.println("{ pop }           % yes: pop off the 'dict' returned");
/*      */     this.writer.println("{                 % no:  define one");
/*      */     this.writer.println("/colortogray {  % define an RGB->I function");
/*      */     this.writer.println("/rgbdata exch store    % call input 'rgbdata'");
/*      */     this.writer.println("rgbdata length 3 idiv");
/*      */     this.writer.println("/npixls exch store");
/*      */     this.writer.println("/rgbindx 0 store");
/*      */     this.writer.println("0 1 npixls 1 sub {");
/*      */     this.writer.println("grays exch");
/*      */     this.writer.println("rgbdata rgbindx       get 20 mul    % Red");
/*      */     this.writer.println("rgbdata rgbindx 1 add get 32 mul    % Green");
/*      */     this.writer.println("rgbdata rgbindx 2 add get 12 mul    % Blue");
/*      */     this.writer.println("add add 64 idiv      % I = .5G + .31R + .18B");
/*      */     this.writer.println("put");
/*      */     this.writer.println("/rgbindx rgbindx 3 add store");
/*      */     this.writer.println("} for");
/*      */     this.writer.println("grays 0 npixls getinterval");
/*      */     this.writer.println("} bind def");
/*      */     this.writer.println("");
/*      */     debug(this.writer, "% Utility procedure for colorimage operator.");
/*      */     debug(this.writer, "% This procedure takes two procedures off the");
/*      */     debug(this.writer, "% stack and merges them into a single procedure.");
/*      */     this.writer.println("");
/*      */     this.writer.println("/mergeprocs { % def");
/*      */     this.writer.println("dup length");
/*      */     this.writer.println("3 -1 roll");
/*      */     this.writer.println("dup");
/*      */     this.writer.println("length");
/*      */     this.writer.println("dup");
/*      */     this.writer.println("5 1 roll");
/*      */     this.writer.println("3 -1 roll");
/*      */     this.writer.println("add");
/*      */     this.writer.println("array cvx");
/*      */     this.writer.println("dup");
/*      */     this.writer.println("3 -1 roll");
/*      */     this.writer.println("0 exch");
/*      */     this.writer.println("putinterval");
/*      */     this.writer.println("dup");
/*      */     this.writer.println("4 2 roll");
/*      */     this.writer.println("putinterval");
/*      */     this.writer.println("} bind def");
/*      */     this.writer.println("");
/*      */     this.writer.println("/colorimage { % def");
/*      */     this.writer.println("pop pop     % remove 'false 3' operands");
/*      */     this.writer.println("{colortogray} mergeprocs");
/*      */     this.writer.println("image");
/*      */     this.writer.println("} bind def");
/*      */     this.writer.println("} ifelse          % end of 'false' case");
/*      */   }
/*      */   
/*      */   public void gsave() {
/*      */     this.writer.println("gsave");
/*      */     this.savelevel++;
/*      */   }
/*      */   
/*      */   public void grestore() {
/*      */     this.writer.println("grestore");
/*      */     this.savelevel--;
/*      */   }
/*      */   
/*      */   public static String escapeString(String paramString) {
/*      */     StringBuffer stringBuffer = new StringBuffer();
/*      */     for (byte b = 0; b < paramString.length(); b++) {
/*      */       switch (paramString.charAt(b)) {
/*      */         case '\n':
/*      */           stringBuffer.append("\\n");
/*      */           break;
/*      */         case '\r':
/*      */           stringBuffer.append("\\r");
/*      */           break;
/*      */         case '\t':
/*      */           stringBuffer.append("\\t");
/*      */           break;
/*      */         case '\b':
/*      */           stringBuffer.append("\\b");
/*      */           break;
/*      */         case '\f':
/*      */           stringBuffer.append("\\f");
/*      */           break;
/*      */         case '\\':
/*      */           stringBuffer.append("\\\\");
/*      */           break;
/*      */         case '(':
/*      */           stringBuffer.append("\\(");
/*      */           break;
/*      */         case ')':
/*      */           stringBuffer.append("\\)");
/*      */           break;
/*      */         default:
/*      */           if (paramString.charAt(b) > '') {
/*      */             stringBuffer.append("\\" + Integer.toString(paramString.charAt(b), 8));
/*      */             break;
/*      */           } 
/*      */           stringBuffer.append(paramString.charAt(b));
/*      */           break;
/*      */       } 
/*      */     } 
/*      */     return stringBuffer.toString();
/*      */   }
/*      */   
/*      */   public String getFontName(Font paramFont) {
/*      */     String str1 = Common.getPSName(paramFont);
/*      */     String str2 = (String)fontmap.get(str1.toLowerCase());
/*      */     if (str2 == null) {
/*      */       int i = str1.indexOf('.');
/*      */       if (i > 0)
/*      */         str2 = (String)fontmap.get(str1.substring(0, i).toLowerCase()); 
/*      */     } 
/*      */     return (str2 == null) ? str1 : str2;
/*      */   }
/*      */   
/*      */   public void putFontName(String paramString1, String paramString2) { fontmap.put(paramString1, paramString2); }
/*      */   
/*      */   public void emit(String paramString) throws IOException { this.writer.println(paramString); }
/*      */   
/*      */   static final char[] hd = { 
/*      */       '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
/*      */       'A', 'B', 'C', 'D', 'E', 'F' };
/*      */   static final int charsPerRow = 72;
/*      */   protected PrintWriter writer;
/*      */   OutputStream os;
/*      */   int orientation;
/*      */   Color clr;
/*      */   Color backClr;
/*      */   Font font;
/*      */   boolean cloned;
/*      */   int savelevel;
/*      */   Rectangle clippingRect;
/*      */   private boolean disposed;
/*      */   private boolean inited;
/*      */   private Hashtable fontset;
/*      */   private boolean compressImg;
/*      */   private static Hashtable fontmap = new Hashtable();
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\PSGraphics.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */