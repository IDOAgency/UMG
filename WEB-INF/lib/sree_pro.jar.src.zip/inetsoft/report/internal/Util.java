package inetsoft.report.internal;

import inetsoft.report.ChartLens;
import inetsoft.report.Common;
import inetsoft.report.Comparer;
import inetsoft.report.ReportElement;
import inetsoft.report.StyleConstants;
import inetsoft.report.StyleSheet;
import inetsoft.report.TableLens;
import inetsoft.report.lens.AttributeTableLens;
import inetsoft.report.lens.DefaultTableLens;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Polygon;
import java.awt.Window;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

public class Util implements StyleConstants {
  public static final int COLOR_CHART = 4096;
  
  public static final int CHART_NOLABEL_MASK = 8192;
  
  public static final int CHART_STYLE_MASK = 255;
  
  public static String getCaller() {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    PrintWriter printWriter = new PrintWriter(byteArrayOutputStream);
    (new Exception("xxx")).printStackTrace(printWriter);
    printWriter.close();
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(byteArrayInputStream));
    try {
      String str = bufferedReader.readLine();
      str = bufferedReader.readLine();
      str = bufferedReader.readLine().trim();
      int i = str.indexOf('(');
      if (i > 0) {
        str = str.substring(0, i);
        int j = str.lastIndexOf(' ');
        if (j > 0) {
          str = str.substring(j + 1);
          int k = str.lastIndexOf('.');
          return (k > 0) ? str.substring(0, k) : str;
        } 
      } 
    } catch (Exception exception) {}
    return null;
  }
  
  public static String[] getCallers() {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    PrintWriter printWriter = new PrintWriter(byteArrayOutputStream);
    (new Exception("xxx")).printStackTrace(printWriter);
    printWriter.close();
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(byteArrayInputStream));
    Vector vector = new Vector();
    try {
      String str = bufferedReader.readLine();
      while ((str = bufferedReader.readLine()) != null) {
        str = str.trim();
        int i = str.indexOf('(');
        if (i > 0) {
          str = str.substring(0, i);
          int j = str.lastIndexOf(' ');
          if (j > 0) {
            str = str.substring(j + 1);
            int k = str.lastIndexOf('.');
            vector.addElement((k > 0) ? str.substring(0, k) : str);
          } 
        } 
      } 
    } catch (Exception exception) {}
    String[] arrayOfString = new String[vector.size()];
    vector.copyInto(arrayOfString);
    return arrayOfString;
  }
  
  public static boolean isServer() {
    String[] arrayOfString = getCallers();
    for (byte b = 0; b < arrayOfString.length; b++) {
      if (arrayOfString[b].startsWith("javax.servlet."))
        return true; 
    } 
    return false;
  }
  
  public static boolean isGUI() {
    String[] arrayOfString = getCallers();
    for (byte b = 0; b < arrayOfString.length; b++) {
      if (arrayOfString[b].startsWith("java.awt"))
        return true; 
    } 
    return false;
  }
  
  public static int breakLine(String paramString, double paramDouble, Font paramFont, boolean paramBoolean) {
    FontMetrics fontMetrics = Common.getFontMetrics(paramFont);
    int i = paramString.length() - 1;
    if (paramString.length() > 150) {
      float f1 = 0.0F;
      for (int m = 0, n = 100; m < paramString.length(); m = n, n += 50) {
        n = Math.min(n, paramString.length());
        f1 += Common.stringWidth(paramString.substring(m, n), paramFont, fontMetrics);
        if (f1 > paramDouble) {
          i = n - 1;
          break;
        } 
      } 
      if (f1 < paramDouble)
        return -1; 
    } else if (Common.stringWidth(paramString, paramFont, fontMetrics) <= paramDouble) {
      return -1;
    } 
    int j = i / 2;
    float f = 0.0F;
    for (int k = 0; i > k; ) {
      j = Math.min((k + i) / 2, k + 150);
      if (j == k || j == i) {
        j = i;
        break;
      } 
      float f1 = Common.stringWidth(paramString.substring(k, j + 1), paramFont, fontMetrics);
      if ((f + f1) > paramDouble) {
        i = j;
        continue;
      } 
      k = j;
      f += f1;
    } 
    if (paramBoolean)
      for (int m = j; m > 0; m--) {
        if (Character.isWhitespace(paramString.charAt(m)))
          return m; 
      }  
    String str = paramString.substring(0, Math.min(paramString.length(), j + 1));
    return (Common.stringWidth(str, paramFont) > paramDouble) ? j : (j + 1);
  }
  
  public static Frame findFrame(Component paramComponent) {
    for (Component component = paramComponent; component != null; component = component.getParent()) {
      if (component instanceof Frame)
        return (Frame)component; 
    } 
    return null;
  }
  
  public static Window findWindow(Component paramComponent) {
    for (Component component = paramComponent; component != null; component = component.getParent()) {
      if (component instanceof Window)
        return (Window)component; 
    } 
    return null;
  }
  
  public static boolean isLightWeight(Component paramComponent) { return paramComponent.getPeer() instanceof java.awt.peer.LightweightPeer; }
  
  public static String toString(Number paramNumber, int paramInt) { return (paramNumber == null) ? "" : toString(paramNumber.doubleValue(), paramInt); }
  
  public static String toString(double paramDouble, int paramInt) {
    if (Math.abs(paramDouble) > 9.223372036854776E18D)
      return toString(Double.toString(paramDouble), paramInt); 
    String str1 = (paramDouble < 0.0D) ? "-" : "";
    long l1 = (long)Math.pow(10.0D, (paramInt - 1));
    long l2 = l1 * 10L;
    paramDouble = Math.abs(paramDouble);
    long l3 = (long)(paramDouble * l2);
    String str2 = str1 + Long.toString((long)paramDouble);
    long l4 = l3 % l2;
    if (l4 == 0L)
      return str2; 
    String str3 = Long.toString(l4);
    while (l4 < l1) {
      l4 *= 10L;
      str3 = "0" + str3;
    } 
    return str2 + "." + str3;
  }
  
  private static String toString(String paramString, int paramInt) {
    int i = paramString.indexOf(".");
    String str = (i > 0 && paramString.length() - i - 1 > paramInt) ? paramString.substring(0, i + paramInt + 1) : paramString;
    return str.endsWith(".0") ? str.substring(0, str.length() - 2) : str;
  }
  
  public static String toString(Object paramObject) {
    String str = paramObject.toString();
    if (paramObject instanceof Number) {
      int i = str.indexOf('.');
      if (i >= 0) {
        int j = str.indexOf('E');
        if (i == 1 && j > 0) {
          String str2 = str.substring(0, j);
          StringBuffer stringBuffer = new StringBuffer(str2.substring(2));
          stringBuffer.insert(0, str2.charAt(0));
          int m = Integer.parseInt(str.substring(j + 1));
          if (m > 0) {
            while (stringBuffer.length() < m + 1)
              stringBuffer.append("0"); 
          } else {
            for (byte b = 0; b < -m; b++)
              stringBuffer.insert(0, "0"); 
            stringBuffer.insert(1, ".");
          } 
          return stringBuffer.toString();
        } 
        String str1 = str.substring(i + 1);
        int k;
        if ((k = str1.indexOf("999999")) >= 0) {
          str = toString((Number)paramObject, k);
        } else if ((k = str1.indexOf("000000")) >= 0) {
          str = str.substring(0, i + k + 1);
        } 
      } 
    } 
    return str;
  }
  
  public static String trimEnd(String paramString) {
    for (int i = paramString.length() - 1; i >= 0; i--) {
      if (paramString.charAt(i) > ' ')
        return paramString.substring(0, i + 1); 
    } 
    return paramString;
  }
  
  public static boolean isFlatDatasetChart(ChartLens paramChartLens) {
    int i = paramChartLens.getStyle();
    if (i == 1 || i == 5 || i == 3 || i == 7 || i == 9) {
      boolean bool = false;
      try {
        Object object1 = paramChartLens.getColor(0);
        Object object2 = paramChartLens.getColor(1);
        bool = (object2 == null || object1.equals(object2)) ? 1 : 0;
      } catch (Exception exception) {}
      return (!bool && paramChartLens.getDatasetCount() == 1);
    } 
    return (i == 8 || i == 6 || i == 8198 || i == 8200);
  }
  
  public static String getLineStyleName(int paramInt) {
    switch (paramInt) {
      case 0:
        return "NO_BORDER";
      case 266240:
        return "ULTRA_THIN_LINE";
      case 528384:
        return "THIN_THIN_LINE";
      case 4097:
        return "THIN_LINE";
      case 4098:
        return "MEDIUM_LINE";
      case 4099:
        return "THICK_LINE";
      case 8195:
        return "DOUBLE_LINE";
      case 24578:
        return "RAISED_3D";
      case 40962:
        return "LOWERED_3D";
      case 24579:
        return "DOUBLE_3D_RAISED";
      case 40963:
        return "DOUBLE_3D_LOWERED";
      case 4113:
        return "DOT_LINE";
      case 4145:
        return "DASH_LINE";
      case 4193:
        return "MEDIUM_DASH";
      case 4241:
        return "LARGE_DASH";
    } 
    return "" + paramInt;
  }
  
  public static void qsort(Object[] paramArrayOfObject, int paramInt1, int paramInt2, boolean paramBoolean, Comparer paramComparer) {
    if (paramInt1 >= paramInt2)
      return; 
    int i = paramInt1;
    int j = paramInt2;
    byte b = paramBoolean ? -1 : 1;
    int k = paramBoolean ? 1 : -1;
    int m = (i + j) / 2;
    Object object = paramArrayOfObject[m];
    paramArrayOfObject[m] = paramArrayOfObject[paramInt1];
    paramArrayOfObject[paramInt1] = object;
    while (i < j) {
      int n = paramComparer.compare(paramArrayOfObject[i], paramArrayOfObject[paramInt1]);
      for (; i < paramInt2 && (n == 0 || n / Math.abs(n) == b); 
        n = paramComparer.compare(paramArrayOfObject[i], paramArrayOfObject[paramInt1]))
        i++; 
      n = paramComparer.compare(paramArrayOfObject[j], paramArrayOfObject[paramInt1]);
      for (; n != 0 && n == Math.abs(n) * k; 
        n = paramComparer.compare(paramArrayOfObject[j], paramArrayOfObject[paramInt1]))
        j--; 
      if (i < j) {
        object = paramArrayOfObject[i];
        paramArrayOfObject[i] = paramArrayOfObject[j];
        paramArrayOfObject[j] = object;
      } 
    } 
    object = paramArrayOfObject[paramInt1];
    paramArrayOfObject[paramInt1] = paramArrayOfObject[j];
    paramArrayOfObject[j] = object;
    qsort(paramArrayOfObject, paramInt1, j - 1, paramBoolean, paramComparer);
    qsort(paramArrayOfObject, j + 1, paramInt2, paramBoolean, paramComparer);
  }
  
  public static int mergeLineStyle(int paramInt1, int paramInt2) { return Math.max(paramInt1 & 0xF, paramInt2 & 0xF) | Math.max(paramInt1 & 0xF0000, paramInt2 & 0xF0000) | Math.min(paramInt1 & 0xF0, paramInt2 & 0xF0) | Math.max(paramInt1 & 0x1000, paramInt2 & 0x1000) | (paramInt1 | paramInt2) & 0x2000 | (paramInt1 | paramInt2) & 0x4000 | (paramInt1 | paramInt2) & 0x8000; }
  
  public static void registerKeyListener(Component paramComponent, KeyListener paramKeyListener) {
    paramComponent.addKeyListener(paramKeyListener);
    if (paramComponent instanceof Container) {
      Container container = (Container)paramComponent;
      for (byte b = 0; b < container.getComponentCount(); b++)
        registerKeyListener(container.getComponent(b), paramKeyListener); 
    } 
  }
  
  public static Color brighter(Color paramColor) { return ((paramColor.getRGB() & 0xFFFFFF) == 0) ? Color.gray : paramColor.brighter(); }
  
  public static Color darker(Color paramColor) { return paramColor.darker(); }
  
  public static String replace(String paramString1, String paramString2, String paramString3) {
    int i = 0;
    if ((i = paramString1.indexOf(paramString2, i)) >= 0)
      paramString1 = paramString1.substring(0, i) + paramString3 + paramString1.substring(i + paramString2.length()); 
    return paramString1;
  }
  
  public static String replaceAll(String paramString1, String paramString2, String paramString3) {
    int i = 0;
    while ((i = paramString1.indexOf(paramString2, i)) >= 0) {
      paramString1 = paramString1.substring(0, i) + paramString3 + paramString1.substring(i + paramString2.length());
      i += paramString3.length();
    } 
    return paramString1;
  }
  
  public static String[] split(String paramString, char paramChar) {
    if (paramString == null || paramString.length() == 0)
      return new String[0]; 
    Vector vector = new Vector();
    int i;
    while ((i = paramString.indexOf(paramChar)) >= 0) {
      vector.addElement(paramString.substring(0, i));
      paramString = paramString.substring(i + 1);
    } 
    vector.addElement(paramString);
    String[] arrayOfString = new String[vector.size()];
    vector.copyInto(arrayOfString);
    return arrayOfString;
  }
  
  public static String[] split(String paramString1, String paramString2) {
    if (paramString1 == null || paramString1.length() == 0)
      return new String[0]; 
    Vector vector = new Vector();
    StringTokenizer stringTokenizer = new StringTokenizer("X" + paramString1, paramString2);
    while (stringTokenizer.hasMoreTokens())
      vector.addElement(stringTokenizer.nextToken()); 
    String[] arrayOfString = new String[vector.size()];
    vector.copyInto(arrayOfString);
    arrayOfString[0] = arrayOfString[0].substring(1);
    return arrayOfString;
  }
  
  public static byte[] getImageBytesRGB(PixelConsumer paramPixelConsumer, Color paramColor) {
    paramPixelConsumer.produce();
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      for (int i = paramPixelConsumer.height - 1; i >= 0; i--) {
        boolean bool = false;
        for (byte b = 0; b < paramPixelConsumer.width; b++) {
          int j = paramPixelConsumer.pix[b][i];
          if ((j & 0xFF000000) == 0)
            j = (paramColor == null) ? 16777215 : paramColor.getRGB(); 
          byteArrayOutputStream.write((byte)(j & 0xFF));
          byteArrayOutputStream.write((byte)((j & 0xFF00) >> 8));
          byteArrayOutputStream.write((byte)((j & 0xFF0000) >> 16));
          bool += true;
        } 
        if (bool % 4 != 0) {
          byte b1 = 4 - bool % 4;
          for (byte b2 = 0; b2 < b1; b2++)
            byteArrayOutputStream.write(-1); 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return byteArrayOutputStream.toByteArray();
  }
  
  public static String remove(String paramString, char paramChar) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramString.length(); b++) {
      if (paramString.charAt(b) != paramChar)
        stringBuffer.append(paramString.charAt(b)); 
    } 
    return stringBuffer.toString();
  }
  
  public static String findDuplicate(StyleSheet paramStyleSheet, boolean paramBoolean) {
    int[] arrayOfInt = { 0, 256, 257, 258, 259, 512, 513, 514, 515 };
    Vector vector = new Vector();
    for (byte b1 = 0; b1 < arrayOfInt.length; b1++)
      vector.addElement(paramStyleSheet.getElements(arrayOfInt[b1])); 
    Enumeration enumeration = paramStyleSheet.getElementHeaders().elements();
    while (enumeration.hasMoreElements())
      vector.addElement((Vector)enumeration.nextElement()); 
    Hashtable hashtable = new Hashtable();
    for (byte b2 = 0; b2 < vector.size(); b2++) {
      Vector vector1 = (Vector)vector.elementAt(b2);
      for (byte b = 0; b < vector1.size(); b++) {
        ReportElement reportElement = (ReportElement)vector1.elementAt(b);
        String str = reportElement.getID();
        if (str == null)
          str = ""; 
        if (hashtable.get(str) != null) {
          if (!paramBoolean)
            return str; 
          String str1 = reportElement.getType();
          try {
            reportElement = (ReportElement)reportElement.clone();
            do {
            
            } while (hashtable.get(str = paramStyleSheet.getNextID(str1)) != null);
            reportElement.setID(str);
            vector1.setElementAt(reportElement, b);
          } catch (CloneNotSupportedException cloneNotSupportedException) {}
        } 
        hashtable.put(str, str);
      } 
    } 
    return null;
  }
  
  public static void insertSorted(int paramInt, Vector paramVector) {
    int i = 0;
    for (i = paramVector.size() - 1; i >= 0; i--) {
      int j = ((Integer)paramVector.elementAt(i)).intValue();
      if (paramInt == j)
        break; 
      if (paramInt > j) {
        paramVector.insertElementAt(new Integer(paramInt), i + 1);
        break;
      } 
    } 
    if (i < 0)
      paramVector.insertElementAt(new Integer(paramInt), 0); 
  }
  
  public static void drawPoint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int arrayOfInt6[], arrayOfInt5[], arrayOfInt4[], arrayOfInt3[], arrayOfInt2[], arrayOfInt1[], i = paramInt3 / 2;
    switch (paramInt4) {
      case 908:
        arrayOfInt1 = new int[] { paramInt1 - i, paramInt1 + i, paramInt1 };
        arrayOfInt2 = new int[] { paramInt2 + i, paramInt2 + i, paramInt2 - i };
        paramGraphics.fillPolygon(new Polygon(arrayOfInt1, arrayOfInt2, 3));
        break;
      case 904:
        Common.drawLine(paramGraphics, (paramInt1 - i), paramInt2, (paramInt1 + i), paramInt2);
        Common.drawLine(paramGraphics, paramInt1, (paramInt2 + i), paramInt1, (paramInt2 - i));
        Common.drawLine(paramGraphics, (paramInt1 - i), (paramInt2 - i), (paramInt1 + i), (paramInt2 + i));
        Common.drawLine(paramGraphics, (paramInt1 - i), (paramInt2 + i), (paramInt1 + i), (paramInt2 - i));
        break;
      case 907:
        paramGraphics.fillArc(paramInt1 - i, paramInt2 - i, paramInt3, paramInt3, 0, 360);
        break;
      case 902:
        paramGraphics.drawRect(paramInt1 - i, paramInt2 - i, paramInt3, paramInt3);
        break;
      case 906:
        Common.drawLine(paramGraphics, (paramInt1 - i), (paramInt2 - i), (paramInt1 + i), (paramInt2 + i));
        Common.drawLine(paramGraphics, (paramInt1 - i), (paramInt2 + i), (paramInt1 + i), (paramInt2 - i));
        break;
      case 910:
        arrayOfInt3 = new int[] { paramInt1 - i, paramInt1, paramInt1 + i, paramInt1 };
        arrayOfInt4 = new int[] { paramInt2, paramInt2 - i, paramInt2, paramInt2 + i };
        paramGraphics.fillPolygon(new Polygon(arrayOfInt3, arrayOfInt4, 4));
        break;
      case 900:
        paramGraphics.drawArc(paramInt1 - i, paramInt2 - i, paramInt3, paramInt3, 0, 360);
        break;
      case 901:
        Common.drawLine(paramGraphics, (paramInt1 - i), (paramInt2 + i), (paramInt1 + i), (paramInt2 + i));
        Common.drawLine(paramGraphics, (paramInt1 - i), (paramInt2 + i), paramInt1, (paramInt2 - i));
        Common.drawLine(paramGraphics, paramInt1, (paramInt2 - i), (paramInt1 + i), (paramInt2 + i));
        break;
      case 905:
        arrayOfInt5 = new int[] { paramInt1 - i, paramInt1, paramInt1 + i, paramInt1 };
        arrayOfInt6 = new int[] { paramInt2, paramInt2 - i, paramInt2, paramInt2 + i };
        paramGraphics.drawPolygon(arrayOfInt5, arrayOfInt6, 4);
        break;
      case 909:
        paramGraphics.fillRect(paramInt1 - i, paramInt2 - i, paramInt3, paramInt3);
        break;
      case 903:
        Common.drawLine(paramGraphics, (paramInt1 - i), paramInt2, (paramInt1 + i), paramInt2);
        Common.drawLine(paramGraphics, paramInt1, (paramInt2 + i), paramInt1, (paramInt2 - i));
        break;
    } 
  }
  
  public static TableLens merge(TableLens paramTableLens1, TableLens paramTableLens2) {
    DefaultTableLens defaultTableLens;
    AttributeTableLens attributeTableLens1 = null, attributeTableLens2 = null;
    if (paramTableLens1 instanceof inetsoft.report.style.TableStyle || paramTableLens1.getClass() == AttributeTableLens.class) {
      attributeTableLens1 = (AttributeTableLens)paramTableLens1;
      attributeTableLens2 = attributeTableLens1;
      paramTableLens1 = attributeTableLens2.getTable();
      while (paramTableLens1 instanceof inetsoft.report.style.TableStyle || paramTableLens1.getClass() == AttributeTableLens.class) {
        attributeTableLens2 = (AttributeTableLens)paramTableLens1;
        paramTableLens1 = attributeTableLens2.getTable();
      } 
    } 
    int i = Math.max(paramTableLens1.getRowCount(), paramTableLens2.getRowCount());
    int j = Math.max(paramTableLens1.getColCount(), paramTableLens2.getColCount());
    int k = Math.min(paramTableLens1.getRowCount(), paramTableLens2.getRowCount());
    int m = Math.min(paramTableLens1.getColCount(), paramTableLens2.getColCount());
    if (paramTableLens2 instanceof DefaultTableLens) {
      defaultTableLens = (DefaultTableLens)paramTableLens2;
      defaultTableLens.setDimension(i, j);
    } else if (paramTableLens1 instanceof DefaultTableLens) {
      defaultTableLens = (DefaultTableLens)paramTableLens1;
      defaultTableLens.setDimension(i, j);
    } else {
      defaultTableLens = new DefaultTableLens(i, j);
    } 
    for (byte b = 0; b < k; b++) {
      for (byte b1 = 0; b1 < m; b1++) {
        Object object = paramTableLens2.getObject(b, b1);
        if (object != null && object.toString().length() > 0) {
          if (defaultTableLens != paramTableLens2)
            defaultTableLens.setObject(b, b1, object); 
        } else {
          Object object1 = paramTableLens1.getObject(b, b1);
          if (defaultTableLens != paramTableLens1)
            defaultTableLens.setObject(b, b1, object1); 
        } 
      } 
    } 
    if (attributeTableLens1 != null) {
      attributeTableLens2.setTable(defaultTableLens);
      return attributeTableLens1;
    } 
    return defaultTableLens;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\Util.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */