/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.ChartLens;
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.Comparer;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.StyleConstants;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.lens.AttributeTableLens;
/*     */ import inetsoft.report.lens.DefaultTableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Polygon;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class Util implements StyleConstants {
/*     */   public static final int COLOR_CHART = 4096;
/*     */   public static final int CHART_NOLABEL_MASK = 8192;
/*     */   public static final int CHART_STYLE_MASK = 255;
/*     */   
/*     */   public static String getCaller() {
/*  38 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*  39 */     PrintWriter printWriter = new PrintWriter(byteArrayOutputStream);
/*  40 */     (new Exception("xxx")).printStackTrace(printWriter);
/*  41 */     printWriter.close();
/*  42 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
/*  43 */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(byteArrayInputStream));
/*     */ 
/*     */     
/*     */     try {
/*  47 */       String str = bufferedReader.readLine();
/*  48 */       str = bufferedReader.readLine();
/*  49 */       str = bufferedReader.readLine().trim();
/*  50 */       int i = str.indexOf('(');
/*     */       
/*  52 */       if (i > 0) {
/*  53 */         str = str.substring(0, i);
/*  54 */         int j = str.lastIndexOf(' ');
/*  55 */         if (j > 0) {
/*  56 */           str = str.substring(j + 1);
/*  57 */           int k = str.lastIndexOf('.');
/*  58 */           return (k > 0) ? str.substring(0, k) : str;
/*     */         }
/*     */       
/*     */       } 
/*  62 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getCallers() {
/*  73 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*  74 */     PrintWriter printWriter = new PrintWriter(byteArrayOutputStream);
/*  75 */     (new Exception("xxx")).printStackTrace(printWriter);
/*  76 */     printWriter.close();
/*  77 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
/*  78 */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(byteArrayInputStream));
/*     */ 
/*     */     
/*  81 */     Vector vector = new Vector();
/*     */     
/*     */     try {
/*  84 */       String str = bufferedReader.readLine();
/*     */       
/*  86 */       while ((str = bufferedReader.readLine()) != null) {
/*  87 */         str = str.trim();
/*  88 */         int i = str.indexOf('(');
/*     */         
/*  90 */         if (i > 0) {
/*  91 */           str = str.substring(0, i);
/*  92 */           int j = str.lastIndexOf(' ');
/*  93 */           if (j > 0) {
/*  94 */             str = str.substring(j + 1);
/*  95 */             int k = str.lastIndexOf('.');
/*  96 */             vector.addElement((k > 0) ? str.substring(0, k) : str);
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 101 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 105 */     String[] arrayOfString = new String[vector.size()];
/* 106 */     vector.copyInto(arrayOfString);
/* 107 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isServer() {
/* 114 */     String[] arrayOfString = getCallers();
/* 115 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 116 */       if (arrayOfString[b].startsWith("javax.servlet.")) {
/* 117 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 121 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isGUI() {
/* 128 */     String[] arrayOfString = getCallers();
/* 129 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 130 */       if (arrayOfString[b].startsWith("java.awt")) {
/* 131 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 135 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int breakLine(String paramString, double paramDouble, Font paramFont, boolean paramBoolean) {
/* 148 */     FontMetrics fontMetrics = Common.getFontMetrics(paramFont);
/* 149 */     int i = paramString.length() - 1;
/*     */ 
/*     */     
/* 152 */     if (paramString.length() > 150) {
/* 153 */       float f1 = 0.0F;
/*     */       
/* 155 */       for (int m = 0, n = 100; m < paramString.length(); m = n, n += 50) {
/* 156 */         n = Math.min(n, paramString.length());
/* 157 */         f1 += Common.stringWidth(paramString.substring(m, n), paramFont, fontMetrics);
/* 158 */         if (f1 > paramDouble) {
/* 159 */           i = n - 1;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 164 */       if (f1 < paramDouble) {
/* 165 */         return -1;
/*     */       }
/*     */     }
/* 168 */     else if (Common.stringWidth(paramString, paramFont, fontMetrics) <= paramDouble) {
/* 169 */       return -1;
/*     */     } 
/*     */     
/* 172 */     int j = i / 2;
/*     */     
/* 174 */     float f = 0.0F;
/* 175 */     for (int k = 0; i > k; ) {
/*     */       
/* 177 */       j = Math.min((k + i) / 2, k + 150);
/*     */ 
/*     */       
/* 180 */       if (j == k || j == i) {
/* 181 */         j = i;
/*     */         
/*     */         break;
/*     */       } 
/* 185 */       float f1 = Common.stringWidth(paramString.substring(k, j + 1), paramFont, fontMetrics);
/* 186 */       if ((f + f1) > paramDouble) {
/* 187 */         i = j;
/*     */         continue;
/*     */       } 
/* 190 */       k = j;
/* 191 */       f += f1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 196 */     if (paramBoolean) {
/* 197 */       for (int m = j; m > 0; m--) {
/* 198 */         if (Character.isWhitespace(paramString.charAt(m))) {
/* 199 */           return m;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 204 */     String str = paramString.substring(0, Math.min(paramString.length(), j + 1));
/* 205 */     return (Common.stringWidth(str, paramFont) > paramDouble) ? j : (j + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Frame findFrame(Component paramComponent) {
/* 214 */     for (Component component = paramComponent; component != null; component = component.getParent()) {
/* 215 */       if (component instanceof Frame) {
/* 216 */         return (Frame)component;
/*     */       }
/*     */     } 
/* 219 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Window findWindow(Component paramComponent) {
/* 228 */     for (Component component = paramComponent; component != null; component = component.getParent()) {
/* 229 */       if (component instanceof Window) {
/* 230 */         return (Window)component;
/*     */       }
/*     */     } 
/* 233 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 240 */   public static boolean isLightWeight(Component paramComponent) { return paramComponent.getPeer() instanceof java.awt.peer.LightweightPeer; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 250 */   public static String toString(Number paramNumber, int paramInt) { return (paramNumber == null) ? "" : toString(paramNumber.doubleValue(), paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(double paramDouble, int paramInt) {
/* 260 */     if (Math.abs(paramDouble) > 9.223372036854776E18D) {
/* 261 */       return toString(Double.toString(paramDouble), paramInt);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 268 */     String str1 = (paramDouble < 0.0D) ? "-" : "";
/* 269 */     long l1 = (long)Math.pow(10.0D, (paramInt - 1));
/* 270 */     long l2 = l1 * 10L;
/* 271 */     paramDouble = Math.abs(paramDouble);
/* 272 */     long l3 = (long)(paramDouble * l2);
/* 273 */     String str2 = str1 + Long.toString((long)paramDouble);
/* 274 */     long l4 = l3 % l2;
/*     */     
/* 276 */     if (l4 == 0L) {
/* 277 */       return str2;
/*     */     }
/*     */ 
/*     */     
/* 281 */     String str3 = Long.toString(l4);
/* 282 */     while (l4 < l1) {
/* 283 */       l4 *= 10L;
/* 284 */       str3 = "0" + str3;
/*     */     } 
/*     */     
/* 287 */     return str2 + "." + str3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String toString(String paramString, int paramInt) {
/* 294 */     int i = paramString.indexOf(".");
/*     */     
/* 296 */     String str = (i > 0 && paramString.length() - i - 1 > paramInt) ? paramString.substring(0, i + paramInt + 1) : paramString;
/*     */ 
/*     */     
/* 299 */     return str.endsWith(".0") ? str.substring(0, str.length() - 2) : str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(Object paramObject) {
/* 307 */     String str = paramObject.toString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     if (paramObject instanceof Number) {
/* 314 */       int i = str.indexOf('.');
/*     */       
/* 316 */       if (i >= 0) {
/* 317 */         int j = str.indexOf('E');
/*     */         
/* 319 */         if (i == 1 && j > 0) {
/* 320 */           String str2 = str.substring(0, j);
/*     */           
/* 322 */           StringBuffer stringBuffer = new StringBuffer(str2.substring(2));
/* 323 */           stringBuffer.insert(0, str2.charAt(0));
/* 324 */           int m = Integer.parseInt(str.substring(j + 1));
/*     */           
/* 326 */           if (m > 0) {
/* 327 */             while (stringBuffer.length() < m + 1) {
/* 328 */               stringBuffer.append("0");
/*     */             }
/*     */           } else {
/*     */             
/* 332 */             for (byte b = 0; b < -m; b++) {
/* 333 */               stringBuffer.insert(0, "0");
/*     */             }
/*     */             
/* 336 */             stringBuffer.insert(1, ".");
/*     */           } 
/*     */           
/* 339 */           return stringBuffer.toString();
/*     */         } 
/*     */         
/* 342 */         String str1 = str.substring(i + 1);
/*     */         
/*     */         int k;
/* 345 */         if ((k = str1.indexOf("999999")) >= 0) {
/* 346 */           str = toString((Number)paramObject, k);
/*     */         }
/* 348 */         else if ((k = str1.indexOf("000000")) >= 0) {
/* 349 */           str = str.substring(0, i + k + 1);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 354 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String trimEnd(String paramString) {
/* 363 */     for (int i = paramString.length() - 1; i >= 0; i--) {
/* 364 */       if (paramString.charAt(i) > ' ') {
/* 365 */         return paramString.substring(0, i + 1);
/*     */       }
/*     */     } 
/*     */     
/* 369 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFlatDatasetChart(ChartLens paramChartLens) {
/* 379 */     int i = paramChartLens.getStyle();
/* 380 */     if (i == 1 || i == 5 || i == 3 || i == 7 || i == 9) {
/*     */ 
/*     */       
/* 383 */       boolean bool = false;
/*     */       try {
/* 385 */         Object object1 = paramChartLens.getColor(0);
/* 386 */         Object object2 = paramChartLens.getColor(1);
/* 387 */         bool = (object2 == null || object1.equals(object2)) ? 1 : 0;
/* 388 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 391 */       return (!bool && paramChartLens.getDatasetCount() == 1);
/*     */     } 
/*     */     
/* 394 */     return (i == 8 || i == 6 || i == 8198 || i == 8200);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLineStyleName(int paramInt) {
/* 404 */     switch (paramInt) { case 0:
/* 405 */         return "NO_BORDER";
/* 406 */       case 266240: return "ULTRA_THIN_LINE";
/* 407 */       case 528384: return "THIN_THIN_LINE";
/* 408 */       case 4097: return "THIN_LINE";
/* 409 */       case 4098: return "MEDIUM_LINE";
/* 410 */       case 4099: return "THICK_LINE";
/* 411 */       case 8195: return "DOUBLE_LINE";
/* 412 */       case 24578: return "RAISED_3D";
/* 413 */       case 40962: return "LOWERED_3D";
/* 414 */       case 24579: return "DOUBLE_3D_RAISED";
/* 415 */       case 40963: return "DOUBLE_3D_LOWERED";
/* 416 */       case 4113: return "DOT_LINE";
/* 417 */       case 4145: return "DASH_LINE";
/* 418 */       case 4193: return "MEDIUM_DASH";
/* 419 */       case 4241: return "LARGE_DASH"; }
/*     */ 
/*     */     
/* 422 */     return "" + paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void qsort(Object[] paramArrayOfObject, int paramInt1, int paramInt2, boolean paramBoolean, Comparer paramComparer) {
/* 430 */     if (paramInt1 >= paramInt2) {
/*     */       return;
/*     */     }
/*     */     
/* 434 */     int i = paramInt1;
/* 435 */     int j = paramInt2;
/* 436 */     byte b = paramBoolean ? -1 : 1;
/* 437 */     int k = paramBoolean ? 1 : -1;
/*     */ 
/*     */     
/* 440 */     int m = (i + j) / 2;
/* 441 */     Object object = paramArrayOfObject[m];
/* 442 */     paramArrayOfObject[m] = paramArrayOfObject[paramInt1];
/* 443 */     paramArrayOfObject[paramInt1] = object;
/*     */     
/* 445 */     while (i < j) {
/*     */       
/* 447 */       int n = paramComparer.compare(paramArrayOfObject[i], paramArrayOfObject[paramInt1]);
/* 448 */       for (; i < paramInt2 && (n == 0 || n / Math.abs(n) == b); 
/* 449 */         n = paramComparer.compare(paramArrayOfObject[i], paramArrayOfObject[paramInt1])) {
/* 450 */         i++;
/*     */       }
/*     */       
/* 453 */       n = paramComparer.compare(paramArrayOfObject[j], paramArrayOfObject[paramInt1]);
/* 454 */       for (; n != 0 && n == Math.abs(n) * k; 
/* 455 */         n = paramComparer.compare(paramArrayOfObject[j], paramArrayOfObject[paramInt1])) {
/* 456 */         j--;
/*     */       }
/*     */       
/* 459 */       if (i < j) {
/* 460 */         object = paramArrayOfObject[i];
/* 461 */         paramArrayOfObject[i] = paramArrayOfObject[j];
/* 462 */         paramArrayOfObject[j] = object;
/*     */       } 
/*     */     } 
/*     */     
/* 466 */     object = paramArrayOfObject[paramInt1];
/* 467 */     paramArrayOfObject[paramInt1] = paramArrayOfObject[j];
/* 468 */     paramArrayOfObject[j] = object;
/*     */     
/* 470 */     qsort(paramArrayOfObject, paramInt1, j - 1, paramBoolean, paramComparer);
/* 471 */     qsort(paramArrayOfObject, j + 1, paramInt2, paramBoolean, paramComparer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 481 */   public static int mergeLineStyle(int paramInt1, int paramInt2) { return Math.max(paramInt1 & 0xF, paramInt2 & 0xF) | Math.max(paramInt1 & 0xF0000, paramInt2 & 0xF0000) | Math.min(paramInt1 & 0xF0, paramInt2 & 0xF0) | Math.max(paramInt1 & 0x1000, paramInt2 & 0x1000) | (paramInt1 | paramInt2) & 0x2000 | (paramInt1 | paramInt2) & 0x4000 | (paramInt1 | paramInt2) & 0x8000; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerKeyListener(Component paramComponent, KeyListener paramKeyListener) {
/* 494 */     paramComponent.addKeyListener(paramKeyListener);
/*     */     
/* 496 */     if (paramComponent instanceof Container) {
/* 497 */       Container container = (Container)paramComponent;
/* 498 */       for (byte b = 0; b < container.getComponentCount(); b++) {
/* 499 */         registerKeyListener(container.getComponent(b), paramKeyListener);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 510 */   public static Color brighter(Color paramColor) { return ((paramColor.getRGB() & 0xFFFFFF) == 0) ? Color.gray : paramColor.brighter(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 519 */   public static Color darker(Color paramColor) { return paramColor.darker(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String replace(String paramString1, String paramString2, String paramString3) {
/* 526 */     int i = 0;
/*     */     
/* 528 */     if ((i = paramString1.indexOf(paramString2, i)) >= 0) {
/* 529 */       paramString1 = paramString1.substring(0, i) + paramString3 + paramString1.substring(i + paramString2.length());
/*     */     }
/*     */     
/* 532 */     return paramString1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String replaceAll(String paramString1, String paramString2, String paramString3) {
/* 539 */     int i = 0;
/* 540 */     while ((i = paramString1.indexOf(paramString2, i)) >= 0) {
/* 541 */       paramString1 = paramString1.substring(0, i) + paramString3 + paramString1.substring(i + paramString2.length());
/* 542 */       i += paramString3.length();
/*     */     } 
/*     */     
/* 545 */     return paramString1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] split(String paramString, char paramChar) {
/* 552 */     if (paramString == null || paramString.length() == 0) {
/* 553 */       return new String[0];
/*     */     }
/*     */     
/* 556 */     Vector vector = new Vector();
/*     */     
/*     */     int i;
/* 559 */     while ((i = paramString.indexOf(paramChar)) >= 0) {
/* 560 */       vector.addElement(paramString.substring(0, i));
/* 561 */       paramString = paramString.substring(i + 1);
/*     */     } 
/* 563 */     vector.addElement(paramString);
/*     */     
/* 565 */     String[] arrayOfString = new String[vector.size()];
/* 566 */     vector.copyInto(arrayOfString);
/*     */     
/* 568 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] split(String paramString1, String paramString2) {
/* 575 */     if (paramString1 == null || paramString1.length() == 0) {
/* 576 */       return new String[0];
/*     */     }
/*     */     
/* 579 */     Vector vector = new Vector();
/*     */     
/* 581 */     StringTokenizer stringTokenizer = new StringTokenizer("X" + paramString1, paramString2);
/*     */     
/* 583 */     while (stringTokenizer.hasMoreTokens()) {
/* 584 */       vector.addElement(stringTokenizer.nextToken());
/*     */     }
/*     */     
/* 587 */     String[] arrayOfString = new String[vector.size()];
/* 588 */     vector.copyInto(arrayOfString);
/*     */     
/* 590 */     arrayOfString[0] = arrayOfString[0].substring(1);
/*     */     
/* 592 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getImageBytesRGB(PixelConsumer paramPixelConsumer, Color paramColor) {
/* 599 */     paramPixelConsumer.produce();
/* 600 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/*     */     try {
/* 603 */       for (int i = paramPixelConsumer.height - 1; i >= 0; i--) {
/* 604 */         boolean bool = false;
/*     */         
/* 606 */         for (byte b = 0; b < paramPixelConsumer.width; b++) {
/* 607 */           int j = paramPixelConsumer.pix[b][i];
/*     */ 
/*     */           
/* 610 */           if ((j & 0xFF000000) == 0) {
/* 611 */             j = (paramColor == null) ? 16777215 : paramColor.getRGB();
/*     */           }
/*     */ 
/*     */           
/* 615 */           byteArrayOutputStream.write((byte)(j & 0xFF));
/* 616 */           byteArrayOutputStream.write((byte)((j & 0xFF00) >> 8));
/* 617 */           byteArrayOutputStream.write((byte)((j & 0xFF0000) >> 16));
/* 618 */           bool += true;
/*     */         } 
/*     */ 
/*     */         
/* 622 */         if (bool % 4 != 0) {
/* 623 */           byte b1 = 4 - bool % 4;
/* 624 */           for (byte b2 = 0; b2 < b1; b2++) {
/* 625 */             byteArrayOutputStream.write(-1);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } catch (Exception exception) {
/* 630 */       exception.printStackTrace();
/*     */     } 
/*     */     
/* 633 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String remove(String paramString, char paramChar) {
/* 640 */     StringBuffer stringBuffer = new StringBuffer();
/* 641 */     for (byte b = 0; b < paramString.length(); b++) {
/* 642 */       if (paramString.charAt(b) != paramChar) {
/* 643 */         stringBuffer.append(paramString.charAt(b));
/*     */       }
/*     */     } 
/*     */     
/* 647 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String findDuplicate(StyleSheet paramStyleSheet, boolean paramBoolean) {
/* 654 */     int[] arrayOfInt = { 0, 256, 257, 258, 259, 512, 513, 514, 515 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 665 */     Vector vector = new Vector();
/*     */     
/* 667 */     for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
/* 668 */       vector.addElement(paramStyleSheet.getElements(arrayOfInt[b1]));
/*     */     }
/*     */     
/* 671 */     Enumeration enumeration = paramStyleSheet.getElementHeaders().elements();
/*     */     
/* 673 */     while (enumeration.hasMoreElements()) {
/* 674 */       vector.addElement((Vector)enumeration.nextElement());
/*     */     }
/*     */     
/* 677 */     Hashtable hashtable = new Hashtable();
/*     */     
/* 679 */     for (byte b2 = 0; b2 < vector.size(); b2++) {
/* 680 */       Vector vector1 = (Vector)vector.elementAt(b2);
/*     */ 
/*     */       
/* 683 */       for (byte b = 0; b < vector1.size(); b++) {
/* 684 */         ReportElement reportElement = (ReportElement)vector1.elementAt(b);
/* 685 */         String str = reportElement.getID();
/*     */         
/* 687 */         if (str == null) {
/* 688 */           str = "";
/*     */         }
/*     */         
/* 691 */         if (hashtable.get(str) != null) {
/* 692 */           if (!paramBoolean) {
/* 693 */             return str;
/*     */           }
/*     */ 
/*     */           
/* 697 */           String str1 = reportElement.getType();
/*     */           try {
/* 699 */             reportElement = (ReportElement)reportElement.clone();
/*     */             do {
/*     */             
/* 702 */             } while (hashtable.get(str = paramStyleSheet.getNextID(str1)) != null);
/* 703 */             reportElement.setID(str);
/* 704 */             vector1.setElementAt(reportElement, b);
/*     */ 
/*     */           
/*     */           }
/* 708 */           catch (CloneNotSupportedException cloneNotSupportedException) {}
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 713 */         hashtable.put(str, str);
/*     */       } 
/*     */     } 
/*     */     
/* 717 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void insertSorted(int paramInt, Vector paramVector) {
/* 724 */     int i = 0;
/* 725 */     for (i = paramVector.size() - 1; i >= 0; i--) {
/* 726 */       int j = ((Integer)paramVector.elementAt(i)).intValue();
/* 727 */       if (paramInt == j) {
/*     */         break;
/*     */       }
/* 730 */       if (paramInt > j) {
/* 731 */         paramVector.insertElementAt(new Integer(paramInt), i + 1);
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 736 */     if (i < 0) {
/* 737 */       paramVector.insertElementAt(new Integer(paramInt), 0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawPoint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 746 */     int arrayOfInt6[], arrayOfInt5[], arrayOfInt4[], arrayOfInt3[], arrayOfInt2[], arrayOfInt1[], i = paramInt3 / 2;
/*     */     
/* 748 */     switch (paramInt4) {
/*     */       case 908:
/* 750 */         arrayOfInt1 = new int[] { paramInt1 - i, paramInt1 + i, paramInt1 };
/* 751 */         arrayOfInt2 = new int[] { paramInt2 + i, paramInt2 + i, paramInt2 - i };
/* 752 */         paramGraphics.fillPolygon(new Polygon(arrayOfInt1, arrayOfInt2, 3));
/*     */         break;
/*     */       case 904:
/* 755 */         Common.drawLine(paramGraphics, (paramInt1 - i), paramInt2, (paramInt1 + i), paramInt2);
/* 756 */         Common.drawLine(paramGraphics, paramInt1, (paramInt2 + i), paramInt1, (paramInt2 - i));
/* 757 */         Common.drawLine(paramGraphics, (paramInt1 - i), (paramInt2 - i), (paramInt1 + i), (paramInt2 + i));
/* 758 */         Common.drawLine(paramGraphics, (paramInt1 - i), (paramInt2 + i), (paramInt1 + i), (paramInt2 - i));
/*     */         break;
/*     */       case 907:
/* 761 */         paramGraphics.fillArc(paramInt1 - i, paramInt2 - i, paramInt3, paramInt3, 0, 360);
/*     */         break;
/*     */       case 902:
/* 764 */         paramGraphics.drawRect(paramInt1 - i, paramInt2 - i, paramInt3, paramInt3);
/*     */         break;
/*     */       case 906:
/* 767 */         Common.drawLine(paramGraphics, (paramInt1 - i), (paramInt2 - i), (paramInt1 + i), (paramInt2 + i));
/* 768 */         Common.drawLine(paramGraphics, (paramInt1 - i), (paramInt2 + i), (paramInt1 + i), (paramInt2 - i));
/*     */         break;
/*     */       case 910:
/* 771 */         arrayOfInt3 = new int[] { paramInt1 - i, paramInt1, paramInt1 + i, paramInt1 };
/* 772 */         arrayOfInt4 = new int[] { paramInt2, paramInt2 - i, paramInt2, paramInt2 + i };
/* 773 */         paramGraphics.fillPolygon(new Polygon(arrayOfInt3, arrayOfInt4, 4));
/*     */         break;
/*     */       case 900:
/* 776 */         paramGraphics.drawArc(paramInt1 - i, paramInt2 - i, paramInt3, paramInt3, 0, 360);
/*     */         break;
/*     */       case 901:
/* 779 */         Common.drawLine(paramGraphics, (paramInt1 - i), (paramInt2 + i), (paramInt1 + i), (paramInt2 + i));
/* 780 */         Common.drawLine(paramGraphics, (paramInt1 - i), (paramInt2 + i), paramInt1, (paramInt2 - i));
/* 781 */         Common.drawLine(paramGraphics, paramInt1, (paramInt2 - i), (paramInt1 + i), (paramInt2 + i));
/*     */         break;
/*     */       case 905:
/* 784 */         arrayOfInt5 = new int[] { paramInt1 - i, paramInt1, paramInt1 + i, paramInt1 };
/* 785 */         arrayOfInt6 = new int[] { paramInt2, paramInt2 - i, paramInt2, paramInt2 + i };
/* 786 */         paramGraphics.drawPolygon(arrayOfInt5, arrayOfInt6, 4);
/*     */         break;
/*     */       case 909:
/* 789 */         paramGraphics.fillRect(paramInt1 - i, paramInt2 - i, paramInt3, paramInt3);
/*     */         break;
/*     */       case 903:
/* 792 */         Common.drawLine(paramGraphics, (paramInt1 - i), paramInt2, (paramInt1 + i), paramInt2);
/* 793 */         Common.drawLine(paramGraphics, paramInt1, (paramInt2 + i), paramInt1, (paramInt2 - i));
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TableLens merge(TableLens paramTableLens1, TableLens paramTableLens2) {
/*     */     DefaultTableLens defaultTableLens;
/* 805 */     AttributeTableLens attributeTableLens1 = null, attributeTableLens2 = null;
/*     */ 
/*     */     
/* 808 */     if (paramTableLens1 instanceof inetsoft.report.style.TableStyle || paramTableLens1.getClass() == AttributeTableLens.class) {
/*     */       
/* 810 */       attributeTableLens1 = (AttributeTableLens)paramTableLens1;
/* 811 */       attributeTableLens2 = attributeTableLens1;
/* 812 */       paramTableLens1 = attributeTableLens2.getTable();
/*     */       
/* 814 */       while (paramTableLens1 instanceof inetsoft.report.style.TableStyle || paramTableLens1.getClass() == AttributeTableLens.class) {
/*     */         
/* 816 */         attributeTableLens2 = (AttributeTableLens)paramTableLens1;
/* 817 */         paramTableLens1 = attributeTableLens2.getTable();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 822 */     int i = Math.max(paramTableLens1.getRowCount(), paramTableLens2.getRowCount());
/* 823 */     int j = Math.max(paramTableLens1.getColCount(), paramTableLens2.getColCount());
/* 824 */     int k = Math.min(paramTableLens1.getRowCount(), paramTableLens2.getRowCount());
/* 825 */     int m = Math.min(paramTableLens1.getColCount(), paramTableLens2.getColCount());
/*     */     
/* 827 */     if (paramTableLens2 instanceof DefaultTableLens) {
/* 828 */       defaultTableLens = (DefaultTableLens)paramTableLens2;
/* 829 */       defaultTableLens.setDimension(i, j);
/*     */     }
/* 831 */     else if (paramTableLens1 instanceof DefaultTableLens) {
/* 832 */       defaultTableLens = (DefaultTableLens)paramTableLens1;
/* 833 */       defaultTableLens.setDimension(i, j);
/*     */     } else {
/*     */       
/* 836 */       defaultTableLens = new DefaultTableLens(i, j);
/*     */     } 
/*     */     
/* 839 */     for (byte b = 0; b < k; b++) {
/* 840 */       for (byte b1 = 0; b1 < m; b1++) {
/* 841 */         Object object = paramTableLens2.getObject(b, b1);
/*     */         
/* 843 */         if (object != null && object.toString().length() > 0) {
/* 844 */           if (defaultTableLens != paramTableLens2) {
/* 845 */             defaultTableLens.setObject(b, b1, object);
/*     */           }
/*     */         } else {
/*     */           
/* 849 */           Object object1 = paramTableLens1.getObject(b, b1);
/* 850 */           if (defaultTableLens != paramTableLens1) {
/* 851 */             defaultTableLens.setObject(b, b1, object1);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 857 */     if (attributeTableLens1 != null) {
/* 858 */       attributeTableLens2.setTable(defaultTableLens);
/* 859 */       return attributeTableLens1;
/*     */     } 
/*     */     
/* 862 */     return defaultTableLens;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\Util.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */