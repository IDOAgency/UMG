package inetsoft.report.internal;

import inetsoft.report.Size;
import java.util.Hashtable;

public class PaperSize {
  public static String[] getList() { return sizestrs; }
  
  public static Size getSize(int paramInt) { return (Size)sizes[paramInt][1]; }
  
  public static Size getSize(String paramString) {
    if (paramString == null)
      return null; 
    Size size = (Size)map.get(paramString);
    if (size == null) {
      int i = paramString.indexOf('x');
      if (i > 0) {
        size = new Size();
        try {
          size.width = Float.valueOf(paramString.substring(0, i)).floatValue();
          size.height = Float.valueOf(paramString.substring(i + 1)).floatValue();
        } catch (Exception exception) {
          return null;
        } 
      } 
    } 
    return size;
  }
  
  public static int getIndex(String paramString) {
    for (byte b = 0; b < sizes.length; b++) {
      if (sizes[b][0].equals(paramString))
        return b; 
    } 
    return -1;
  }
  
  public static int getOrientation(String paramString) { return (paramString != null && (paramString.equalsIgnoreCase("landscape") || paramString.equals("0"))) ? 0 : 1; }
  
  static final Object[][] sizes = { 
      { "Letter [8.5x11 in]", new Size(8.5D, 11.0D) }, { "Legal [8.5x14 in]", new Size(8.5D, 14.0D) }, { "A2 [420x594 mm]", new Size(16.5D, 23.375D) }, { "A3 [297x420 mm]", new Size(11.693455D, 16.5362D) }, { "A4 [210x297 mm]", new Size(8.2681D, 11.693455D) }, { "A5 [148x210 mm]", new Size(5.827042D, 8.2681D) }, { "Executive [7.25x10.5 in]", new Size(7.25D, 10.5D) }, { "Tabloid [11x17 in]", new Size(11.0F, 17.0F) }, { "Ledger [17x11 in]", new Size(17.0F, 11.0F) }, { "Statement [5.5x8.5 in]", new Size(5.5D, 8.5D) }, 
      { "B4 [250x353 mm]", new Size(9.842976D, 13.937654D) }, { "B5 [182x257 mm]", new Size(7.165687D, 10.118579D) }, { "Folio [8.5x13 in]", new Size(8.5D, 13.0D) }, { "Quarto [215x275 mm]", new Size(8.464959D, 10.827274D) } };
  
  static String[] sizestrs;
  
  static Hashtable map = new Hashtable();
  
  static  {
    sizestrs = new String[sizes.length];
    for (byte b = 0; b < sizes.length; b++) {
      sizestrs[b] = (String)sizes[b][0];
      map.put(sizes[b][0], sizes[b][1]);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\PaperSize.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */