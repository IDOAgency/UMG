package inetsoft.report.internal;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class SwingRunner {
  static Class array$Ljava$lang$String;
  
  static Class class$(String paramString) { try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    }  }
  
  public static void main(String[] paramArrayOfString) {
    String str = "";
    try {
      Class.forName("javax.swing.JPanel");
      try {
        String str1 = (paramArrayOfString.length > 0) ? paramArrayOfString[0] : "inetsoft.report.design.Designer";
        String[] arrayOfString = new String[0];
        if (paramArrayOfString.length > 1) {
          arrayOfString = new String[paramArrayOfString.length - 1];
          System.arraycopy(paramArrayOfString, 1, arrayOfString, 0, arrayOfString.length);
        } 
        Class clazz = Class.forName(str1);
        Method method = clazz.getMethod("main", new Class[] { (array$Ljava$lang$String == null) ? (array$Ljava$lang$String = class$("[Ljava.lang.String;")) : array$Ljava$lang$String });
        method.invoke(null, new Object[] { arrayOfString });
        return;
      } catch (ClassNotFoundException classNotFoundException) {
        str = "Style Report classes not found!\nMake sure CLASSPATH is correct.\nJVM:\n      Version: " + System.getProperty("java.version") + "\n" + "      Path: " + System.getProperty("runner.jre.path") + "\n" + "      Command: " + System.getProperty("runner.jre.exe");
      } catch (InvocationTargetException invocationTargetException) {
        str = "Invocation error: " + invocationTargetException;
        invocationTargetException.getTargetException().printStackTrace();
      } catch (Exception exception) {
        str = "Intenal error: " + exception;
        exception.printStackTrace();
      } 
    } catch (ClassNotFoundException classNotFoundException) {
      str = "Swing 1.1 classes not found!\nMake sure Swing 1.1 is installed \nand the JAR file is on the CLASSPATH.\nJVM:\n      Version: " + System.getProperty("java.version") + "\n" + "      Path: " + System.getProperty("runner.jre.path") + "\n" + "      Command: " + System.getProperty("runner.jre.exe");
    } 
    Frame frame = new Frame();
    TextArea textArea = new TextArea(str);
    textArea.setBackground(Color.white);
    textArea.setEditable(false);
    frame.add(textArea, "Center");
    Button button = new Button("Close");
    button.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent param1ActionEvent) { System.exit(0); }
        });
    Panel panel = new Panel();
    panel.add(button);
    frame.add(panel, "South");
    frame.pack();
    frame.setVisible(true);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SwingRunner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */