/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import java.awt.Button;
/*    */ import java.awt.Color;
/*    */ import java.awt.Frame;
/*    */ import java.awt.Panel;
/*    */ import java.awt.TextArea;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SwingRunner
/*    */ {
/*    */   static Class array$Ljava$lang$String;
/*    */   
/*    */   static Class class$(String paramString) { 
/* 25 */     try { return Class.forName(paramString); } catch (ClassNotFoundException classNotFoundException) { throw new NoClassDefFoundError(classNotFoundException.getMessage()); }
/*    */      } public static void main(String[] paramArrayOfString) {
/* 27 */     String str = "";
/*    */     
/*    */     try {
/* 30 */       Class.forName("javax.swing.JPanel");
/*    */       
/*    */       try {
/* 33 */         String str1 = (paramArrayOfString.length > 0) ? paramArrayOfString[0] : "inetsoft.report.design.Designer";
/*    */ 
/*    */         
/* 36 */         String[] arrayOfString = new String[0];
/* 37 */         if (paramArrayOfString.length > 1) {
/* 38 */           arrayOfString = new String[paramArrayOfString.length - 1];
/* 39 */           System.arraycopy(paramArrayOfString, 1, arrayOfString, 0, arrayOfString.length);
/*    */         } 
/*    */         
/* 42 */         Class clazz = Class.forName(str1);
/* 43 */         Method method = clazz.getMethod("main", new Class[] { (array$Ljava$lang$String == null) ? (array$Ljava$lang$String = class$("[Ljava.lang.String;")) : array$Ljava$lang$String });
/* 44 */         method.invoke(null, new Object[] { arrayOfString });
/*    */         
/*    */         return;
/*    */       } catch (ClassNotFoundException classNotFoundException) {
/* 48 */         str = "Style Report classes not found!\nMake sure CLASSPATH is correct.\nJVM:\n      Version: " + System.getProperty("java.version") + "\n" + "      Path: " + System.getProperty("runner.jre.path") + "\n" + "      Command: " + System.getProperty("runner.jre.exe");
/*    */ 
/*    */       
/*    */       }
/*    */       catch (InvocationTargetException invocationTargetException) {
/*    */ 
/*    */ 
/*    */         
/* 56 */         str = "Invocation error: " + invocationTargetException;
/* 57 */         invocationTargetException.getTargetException().printStackTrace();
/*    */       } catch (Exception exception) {
/*    */         
/* 60 */         str = "Intenal error: " + exception;
/* 61 */         exception.printStackTrace();
/*    */       } 
/*    */     } catch (ClassNotFoundException classNotFoundException) {
/*    */       
/* 65 */       str = "Swing 1.1 classes not found!\nMake sure Swing 1.1 is installed \nand the JAR file is on the CLASSPATH.\nJVM:\n      Version: " + System.getProperty("java.version") + "\n" + "      Path: " + System.getProperty("runner.jre.path") + "\n" + "      Command: " + System.getProperty("runner.jre.exe");
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 74 */     Frame frame = new Frame();
/* 75 */     TextArea textArea = new TextArea(str);
/* 76 */     textArea.setBackground(Color.white);
/* 77 */     textArea.setEditable(false);
/* 78 */     frame.add(textArea, "Center");
/*    */     
/* 80 */     Button button = new Button("Close");
/* 81 */     button.addActionListener(new ActionListener() {
/*    */           public void actionPerformed(ActionEvent param1ActionEvent) {
/* 83 */             System.exit(0);
/*    */           }
/*    */         });
/*    */     
/* 87 */     Panel panel = new Panel();
/* 88 */     panel.add(button);
/* 89 */     frame.add(panel, "South");
/*    */     
/* 91 */     frame.pack();
/* 92 */     frame.setVisible(true);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SwingRunner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */