package inetsoft.report.internal;

import inetsoft.report.StyleConstants;

public class KeyUtil implements StyleConstants {
  private static int checksum(String paramString) {
    char c = Character.MIN_VALUE;
    for (byte b = 0; b < paramString.length(); b++) {
      c <<= 4;
      c += paramString.charAt(b);
    } 
    return c & 0xFFFFFF;
  }
  
  private static boolean verify(String paramString) {
    try {
      int i = Integer.parseInt(paramString.substring(1, 4) + paramString.substring(5, 8), 16);
      int j = checksum(paramString.substring(9));
      return (i == j);
    } catch (Exception exception) {
      return false;
    } 
  }
  
  public static boolean verifyEval(String paramString, char paramChar) {
    try {
      int i = Integer.parseInt(paramString.substring(1, 4) + paramString.substring(5, 8), 16);
      String str = paramString.substring(9);
      int j = checksum(paramString.charAt(0) + str);
      if (i != j || paramString.substring(9, 12).indexOf(paramChar) < 0)
        return false; 
      long l = Long.valueOf(str.substring(4), 16).longValue() ^ 0xF383920ABCDEL;
      return (l > System.currentTimeMillis());
    } catch (Exception exception) {
      exception.printStackTrace();
      return false;
    } 
  }
  
  public static boolean verify2(String paramString, char paramChar) {
    if (paramString == null || paramString.length() == 0)
      return false; 
    if (paramString.charAt(0) == 'A')
      return verify(paramString); 
    if (paramString.charAt(0) == 'L')
      return verifyEval(paramString, paramChar); 
    try {
      int i = Integer.parseInt(paramString.substring(1, 4) + paramString.substring(5, 8), 16);
      int j = checksum(paramString.charAt(0) + paramString.substring(9));
      return (i == j && paramString.substring(9, 12).indexOf(paramChar) >= 0);
    } catch (Exception exception) {
      return false;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\KeyUtil.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */