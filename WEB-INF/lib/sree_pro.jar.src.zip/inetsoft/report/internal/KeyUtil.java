/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.StyleConstants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyUtil
/*    */   implements StyleConstants
/*    */ {
/*    */   private static int checksum(String paramString) {
/* 29 */     char c = Character.MIN_VALUE;
/*    */     
/* 31 */     for (byte b = 0; b < paramString.length(); b++) {
/* 32 */       c <<= 4;
/* 33 */       c += paramString.charAt(b);
/*    */     } 
/*    */     
/* 36 */     return c & 0xFFFFFF;
/*    */   }
/*    */   
/*    */   private static boolean verify(String paramString) {
/*    */     try {
/* 41 */       int i = Integer.parseInt(paramString.substring(1, 4) + paramString.substring(5, 8), 16);
/*    */       
/* 43 */       int j = checksum(paramString.substring(9));
/* 44 */       return (i == j);
/* 45 */     } catch (Exception exception) {
/*    */ 
/*    */       
/* 48 */       return false;
/*    */     } 
/*    */   }
/*    */   public static boolean verifyEval(String paramString, char paramChar) {
/*    */     try {
/* 53 */       int i = Integer.parseInt(paramString.substring(1, 4) + paramString.substring(5, 8), 16);
/*    */       
/* 55 */       String str = paramString.substring(9);
/* 56 */       int j = checksum(paramString.charAt(0) + str);
/* 57 */       if (i != j || paramString.substring(9, 12).indexOf(paramChar) < 0) {
/* 58 */         return false;
/*    */       }
/*    */       
/* 61 */       long l = Long.valueOf(str.substring(4), 16).longValue() ^ 0xF383920ABCDEL;
/*    */       
/* 63 */       return (l > System.currentTimeMillis());
/*    */     } catch (Exception exception) {
/* 65 */       exception.printStackTrace();
/*    */ 
/*    */       
/* 68 */       return false;
/*    */     } 
/*    */   }
/*    */   public static boolean verify2(String paramString, char paramChar) {
/* 72 */     if (paramString == null || paramString.length() == 0) {
/* 73 */       return false;
/*    */     }
/* 75 */     if (paramString.charAt(0) == 'A') {
/* 76 */       return verify(paramString);
/*    */     }
/* 78 */     if (paramString.charAt(0) == 'L') {
/* 79 */       return verifyEval(paramString, paramChar);
/*    */     }
/*    */     
/*    */     try {
/* 83 */       int i = Integer.parseInt(paramString.substring(1, 4) + paramString.substring(5, 8), 16);
/*    */       
/* 85 */       int j = checksum(paramString.charAt(0) + paramString.substring(9));
/* 86 */       return (i == j && paramString.substring(9, 12).indexOf(paramChar) >= 0);
/* 87 */     } catch (Exception exception) {
/*    */ 
/*    */       
/* 90 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\KeyUtil.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */