/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.CompositeElement;
/*     */ import inetsoft.report.CompositeLens;
/*     */ import inetsoft.report.Context;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeElementDef
/*     */   extends BaseElement
/*     */   implements CompositeElement
/*     */ {
/*     */   private CompositeLens composite;
/*     */   private Vector elems;
/*     */   private int curr;
/*     */   
/*     */   public CompositeElementDef(StyleSheet paramStyleSheet, CompositeLens paramCompositeLens) {
/*  33 */     super(paramStyleSheet, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     this.elems = null;
/* 129 */     this.curr = 0;
/*     */     this.composite = paramCompositeLens;
/*     */   }
/*     */   
/*     */   public Size getPreferredSize() { return new Size(); }
/*     */   
/*     */   public boolean print(StylePage paramStylePage) {
/*     */     if (!isVisible())
/*     */       return false; 
/*     */     super.print(paramStylePage);
/*     */     if (this.elems == null) {
/*     */       this.elems = new Vector();
/*     */       Context context = new Context(this);
/*     */       this.composite.reset();
/*     */       Object object;
/*     */       for (; (object = this.composite.nextElement(context)) != null; context = new Context(this)) {
/*     */         BaseElement baseElement = null;
/*     */         if (object instanceof inetsoft.report.ReportElement) {
/*     */           baseElement = (BaseElement)object;
/*     */         } else {
/*     */           baseElement = (BaseElement)this.report.getCompositeElement(getID(), object, context);
/*     */         } 
/*     */         if (baseElement != null) {
/*     */           baseElement.setParent(this);
/*     */           this.elems.addElement(baseElement);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     int i = this.report.current;
/*     */     this.report.current = this.curr;
/*     */     boolean bool = this.report.printNextArea(paramStylePage, this.elems);
/*     */     this.curr = this.report.current;
/*     */     this.report.current = i;
/*     */     return (this.curr < this.elems.size());
/*     */   }
/*     */   
/*     */   public CompositeLens getComposite() { return this.composite; }
/*     */   
/*     */   public void setComposite(CompositeLens paramCompositeLens) { this.composite = paramCompositeLens; }
/*     */   
/*     */   public void reset() {
/*     */     super.reset();
/*     */     this.elems = null;
/*     */     this.curr = 0;
/*     */   }
/*     */   
/*     */   public String toString() { return getID() + " [" + Catalog.getString(getType()) + "]"; }
/*     */   
/*     */   public String getType() { return "Composite"; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\CompositeElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */