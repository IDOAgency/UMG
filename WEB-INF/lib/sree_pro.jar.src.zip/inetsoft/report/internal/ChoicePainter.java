/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.Common;
/*    */ import inetsoft.report.ReportElement;
/*    */ import inetsoft.report.Size;
/*    */ import java.awt.Color;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.FontMetrics;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChoicePainter
/*    */   extends FieldPainter
/*    */ {
/*    */   private Image icon;
/*    */   private String longest;
/*    */   private Object selected;
/*    */   private Object[] choices;
/*    */   static final String icon_url = "/inetsoft/report/images/choice_arrow.gif";
/*    */   
/*    */   public ChoicePainter(ReportElement paramReportElement) {
/* 29 */     super(paramReportElement);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 93 */     this.icon = null;
/* 94 */     this.longest = null;
/*    */   }
/*    */   
/*    */   public Object getValue() { return getSelectedItem(); }
/*    */   
/*    */   public Object getSelectedItem() { return this.selected; }
/*    */   
/*    */   public void setSelectedItem(Object paramObject) { this.selected = paramObject; }
/*    */   
/*    */   public Object[] getChoices() { return this.choices; }
/*    */   
/*    */   public void setChoices(Object[] paramArrayOfObject) {
/*    */     this.choices = paramArrayOfObject;
/*    */     this.longest = null;
/*    */   }
/*    */   
/*    */   public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*    */     paramGraphics.setColor(this.elem.getForeground());
/*    */     paramGraphics.setFont(this.elem.getFont());
/*    */     FontMetrics fontMetrics = Common.getFontMetrics(paramGraphics.getFont());
/*    */     float f = Common.getHeight(paramGraphics.getFont(), fontMetrics);
/*    */     paramGraphics.drawImage(getIcon(), paramInt1 + paramInt3 - 16, paramInt2 + (paramInt4 - 16) / 2, null);
/*    */     Common.drawString(paramGraphics, (this.selected == null) ? "" : this.selected.toString(), (paramInt1 + 1), paramInt2 + (paramInt4 - f) / 2.0F + fontMetrics.getAscent());
/*    */     paramGraphics.setColor(Color.gray);
/*    */     paramGraphics.draw3DRect(paramInt1, paramInt2, paramInt3 - 1, paramInt4 - 1, false);
/*    */   }
/*    */   
/*    */   public Dimension getPreferredSize() {
/*    */     if (this.longest == null) {
/*    */       this.longest = "";
/*    */       for (byte b = 0; b < this.choices.length; b++) {
/*    */         if (this.choices[b].toString().length() > this.longest.length())
/*    */           this.longest = this.choices[b].toString(); 
/*    */       } 
/*    */     } 
/*    */     Size size = StyleCore.getTextSize(this.longest, this.elem.getFont(), 0);
/*    */     return new Dimension((int)(size.width + 20.0F), Math.max((int)(size.height + 2.0F), 16));
/*    */   }
/*    */   
/*    */   protected Image getIcon() {
/*    */     if (this.icon == null) {
/*    */       this.icon = Common.getImage(this, "/inetsoft/report/images/choice_arrow.gif");
/*    */       waitImage(this.icon);
/*    */     } 
/*    */     return this.icon;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ChoicePainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */