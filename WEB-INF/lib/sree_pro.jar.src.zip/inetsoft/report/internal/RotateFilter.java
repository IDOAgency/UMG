/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import java.awt.image.ColorModel;
/*    */ import java.awt.image.ImageFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RotateFilter
/*    */   extends ImageFilter
/*    */ {
/*    */   private int width;
/*    */   private int height;
/*    */   private int[][] buffer;
/*    */   private ColorModel model;
/*    */   
/*    */   public void setDimensions(int paramInt1, int paramInt2) {
/* 32 */     this.consumer.setDimensions(this.height = paramInt2, this.width = paramInt1);
/* 33 */     this.buffer = new int[paramInt1][paramInt2];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4, ColorModel paramColorModel, int[] paramArrayOfInt, int paramInt5, int paramInt6) {
/* 44 */     this.model = paramColorModel;
/* 45 */     for (int i = 0; i < paramArrayOfInt.length; i++) {
/* 46 */       this.buffer[paramInt1 + i][this.height - paramInt2 - 1] = paramArrayOfInt[i];
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void imageComplete(int paramInt) {
/* 57 */     for (byte b = 0; b < this.buffer.length; b++) {
/* 58 */       this.consumer.setPixels(0, b, this.buffer[b].length, 1, this.model, this.buffer[b], 0, this.buffer[b].length);
/*    */     }
/*    */ 
/*    */     
/* 62 */     this.consumer.imageComplete(paramInt);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\RotateFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */