/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Label;
/*     */ import java.awt.Panel;
/*     */ import java.awt.Point;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ContainerEvent;
/*     */ import java.awt.event.ContainerListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.io.Serializable;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToolTip
/*     */   implements MouseListener, ContainerListener, Runnable, Serializable
/*     */ {
/*     */   private ToolTip() {
/* 345 */     this.mmap = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 354 */     this.delay = 500;
/* 355 */     this.disabled = false;
/*     */     this.thread = new Thread(this);
/*     */     this.thread.setDaemon(true);
/*     */     this.thread.start();
/*     */     this.scnsize = Toolkit.getDefaultToolkit().getScreenSize();
/*     */   }
/*     */   
/*     */   private static ToolTip theInstance = null;
/*     */   Hashtable mmap;
/*     */   TipWin currWin;
/*     */   Component currComp;
/*     */   Thread thread;
/*     */   long downTime;
/*     */   Dimension scnsize;
/*     */   int delay;
/*     */   boolean disabled;
/*     */   
/*     */   public static ToolTip getToolTip() {
/*     */     if (theInstance == null)
/*     */       theInstance = new ToolTip(); 
/*     */     return theInstance;
/*     */   }
/*     */   
/*     */   public void finalize() { this.thread.stop(); }
/*     */   
/*     */   public void setDelay(int paramInt) { this.delay = paramInt; }
/*     */   
/*     */   public int getDelay() { return this.delay; }
/*     */   
/*     */   public void run() {
/*     */     while (true) {
/*     */       try {
/*     */         while (this.currComp == null || this.disabled)
/*     */           wait(); 
/*     */         if (System.currentTimeMillis() - this.downTime > this.delay)
/*     */           wait(this.delay); 
/*     */       } catch (Exception exception) {}
/*     */       if (this.currComp != null) {
/*     */         popup(this.currComp);
/*     */         this.currComp = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void put(Component paramComponent, String paramString) {
/*     */     this.mmap.put(paramComponent, paramString);
/*     */     paramComponent.addMouseListener(this);
/*     */     if (paramComponent instanceof Container) {
/*     */       Container container = (Container)paramComponent;
/*     */       container.addContainerListener(this);
/*     */       for (byte b = 0; b < container.getComponentCount(); b++)
/*     */         put(container.getComponent(b), paramString); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void remove(Component paramComponent) {
/*     */     paramComponent.removeMouseListener(this);
/*     */     this.mmap.remove(paramComponent);
/*     */     if (paramComponent instanceof Container) {
/*     */       Container container = (Container)paramComponent;
/*     */       container.removeContainerListener(this);
/*     */       for (byte b = 0; b < container.getComponentCount(); b++)
/*     */         remove(container.getComponent(b)); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mouseClicked(MouseEvent paramMouseEvent) { notifyEnd(); }
/*     */   
/*     */   public void mousePressed(MouseEvent paramMouseEvent) { notifyEnd(); }
/*     */   
/*     */   public void mouseReleased(MouseEvent paramMouseEvent) { notifyStart((Component)paramMouseEvent.getSource()); }
/*     */   
/*     */   public void mouseEntered(MouseEvent paramMouseEvent) { notifyStart((Component)paramMouseEvent.getSource()); }
/*     */   
/*     */   public void mouseExited(MouseEvent paramMouseEvent) { notifyEnd(); }
/*     */   
/*     */   public void componentAdded(ContainerEvent paramContainerEvent) {
/*     */     Component component = paramContainerEvent.getChild();
/*     */     if (!this.mmap.containsKey(component))
/*     */       for (Container container = component.getParent(); container != null; container = container.getParent()) {
/*     */         if (this.mmap.containsKey(container))
/*     */           this.mmap.put(component, this.mmap.get(container)); 
/*     */       }  
/*     */     component.addMouseListener(this);
/*     */     if (component instanceof Container)
/*     */       ((Container)component).addContainerListener(this); 
/*     */   }
/*     */   
/*     */   public void componentRemoved(ContainerEvent paramContainerEvent) {
/*     */     Component component = paramContainerEvent.getChild();
/*     */     component.removeMouseListener(this);
/*     */     if (component instanceof Container)
/*     */       ((Container)component).removeContainerListener(this); 
/*     */   }
/*     */   
/*     */   public boolean isEnabled() { return !this.disabled; }
/*     */   
/*     */   public void setEnabled(boolean paramBoolean) {
/*     */     this.disabled = !paramBoolean;
/*     */     notifyAll();
/*     */   }
/*     */   
/*     */   void notifyStart(Component paramComponent) {
/*     */     if (this.currWin == null || (this.currWin.comp != paramComponent && this.currWin.comp.getParent() != paramComponent)) {
/*     */       popdown();
/*     */       this.currComp = paramComponent;
/*     */       notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   void notifyEnd() {
/*     */     popdown();
/*     */     this.currComp = null;
/*     */   }
/*     */   
/*     */   void popup(Component paramComponent) {
/*     */     popdown();
/*     */     if (this.mmap.containsKey(paramComponent)) {
/*     */       this.currWin = new TipWin(this, paramComponent);
/*     */       Point point = null;
/*     */       try {
/*     */         point = paramComponent.getLocationOnScreen();
/*     */       } catch (Exception exception) {
/*     */         return;
/*     */       } 
/*     */       this.currWin.setSize(this.currWin.getPreferredSize());
/*     */       this.currWin.pack();
/*     */       Dimension dimension1 = paramComponent.getSize();
/*     */       Dimension dimension2 = this.currWin.getSize();
/*     */       int i = point.y + dimension1.height + 2;
/*     */       i = (i + dimension2.height > this.scnsize.height) ? (point.y - dimension2.height - 2) : i;
/*     */       int j = Math.min(point.x + dimension1.width / 2, this.scnsize.width - dimension2.width);
/*     */       this.currWin.setLocation(j, i);
/*     */       this.currWin.setVisible(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   void popdown() {
/*     */     if (this.currWin != null) {
/*     */       this.downTime = System.currentTimeMillis();
/*     */       this.currWin.dispose();
/*     */       this.currWin = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private class TipWin extends Window {
/*     */     private final ToolTip this$0;
/*     */     private Component comp;
/*     */     
/*     */     public TipWin(ToolTip this$0, Component param1Component) {
/*     */       super(ToolTip.findFrame(param1Component));
/*     */       this.this$0 = this$0;
/*     */       this.this$0 = this$0;
/*     */       setBackground(new Color(245, 245, 218));
/*     */       setForeground(Color.black);
/*     */       this.comp = param1Component;
/*     */       Label label = new Label((String)this$0.mmap.get(param1Component));
/*     */       Panel panel = new Panel(label) {
/*     */           private final Label val$tc;
/*     */           
/*     */           public Dimension getPreferredSize() {
/*     */             Dimension dimension = this.val$tc.getPreferredSize();
/*     */             dimension.width++;
/*     */             dimension.height++;
/*     */             return dimension;
/*     */           }
/*     */           
/*     */           public void doLayout() {
/*     */             Dimension dimension = getSize();
/*     */             this.val$tc.setBounds(1, 1, dimension.width - 2, dimension.height - 2);
/*     */           }
/*     */           
/*     */           public void paint(Graphics param2Graphics) {
/*     */             Dimension dimension = getSize();
/*     */             param2Graphics.setColor(Color.black);
/*     */             param2Graphics.drawRect(0, 0, dimension.width - 1, dimension.height - 1);
/*     */           }
/*     */         };
/*     */       add(panel, "Center");
/*     */     }
/*     */   }
/*     */   
/*     */   public static Frame findFrame(Component paramComponent) {
/*     */     for (Component component = paramComponent; component != null; component = component.getParent()) {
/*     */       if (component instanceof Frame)
/*     */         return (Frame)component; 
/*     */     } 
/*     */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ToolTip.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */