/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.SectionBand;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SectionPaintable
/*     */   extends BasePaintable
/*     */ {
/*     */   float x;
/*     */   float y;
/*     */   float width;
/*     */   SectionBandInfo[] infos;
/*     */   Font font;
/*     */   boolean designtime;
/*     */   static final int INDENT = 3;
/*     */   public static final float MIN_MARGIN = 1.0F;
/*     */   
/*     */   public SectionPaintable(float paramFloat1, float paramFloat2, float paramFloat3, SectionBandInfo[] paramArrayOfSectionBandInfo, ReportElement paramReportElement) {
/*  32 */     super(paramReportElement);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 214 */     this.font = new Font("Serif", 0, 9);
/* 215 */     this.designtime = false;
/*     */     this.x = paramFloat1;
/*     */     this.y = paramFloat2;
/*     */     this.width = paramFloat3;
/*     */     this.infos = paramArrayOfSectionBandInfo;
/*     */     this.designtime = (((BaseElement)paramReportElement).getStyleSheet()).designtime;
/*     */   }
/*     */   
/*     */   public void paint(Graphics paramGraphics) {
/*     */     float f = this.y;
/*     */     for (byte b = 0; b < this.infos.length; b++) {
/*     */       SectionBand sectionBand = (this.infos[b]).band;
/*     */       float f1 = sectionBand.getHeight() * 72.0F;
/*     */       int i;
/*     */       if ((i = sectionBand.getTopBorder()) != 0)
/*     */         Common.drawHLine(paramGraphics, f, this.x, this.x + this.width, i, 0, sectionBand.getRightBorder()); 
/*     */       if ((i = sectionBand.getLeftBorder()) != 0)
/*     */         Common.drawVLine(paramGraphics, this.x, f, f + f1, i, 0, sectionBand.getBottomBorder()); 
/*     */       if ((i = sectionBand.getBottomBorder()) != 0)
/*     */         Common.drawHLine(paramGraphics, f + f1, this.x, this.x + this.width, i, sectionBand.getRightBorder(), 0); 
/*     */       if ((i = sectionBand.getRightBorder()) != 0)
/*     */         Common.drawVLine(paramGraphics, this.x + this.width, f, f + f1, i, sectionBand.getBottomBorder(), 0); 
/*     */       f += f1;
/*     */     } 
/*     */     if (this.designtime)
/*     */       paintDesign(paramGraphics); 
/*     */   }
/*     */   
/*     */   private void paintDesign(Graphics paramGraphics) {
/*     */     float f1 = this.y;
/*     */     paramGraphics.setFont(this.font);
/*     */     FontMetrics fontMetrics = Common.getFontMetrics(this.font);
/*     */     float f2 = fontMetrics.getHeight() * 0.6F;
/*     */     Shape shape = paramGraphics.getClip();
/*     */     int i = (this.x < 72.0F) ? (int)(72.0F - (int)this.x) : 0;
/*     */     Rectangle rectangle = paramGraphics.getClipBounds();
/*     */     rectangle.x -= i;
/*     */     rectangle.width += i;
/*     */     paramGraphics.setClip(rectangle);
/*     */     for (byte b = 0; b < this.infos.length; b++) {
/*     */       int j = !(this.infos[b]).type.equals("Content") ? ((this.infos[b]).level - 1) : (this.infos[b]).level;
/*     */       int k = Math.max(0, (this.infos[b]).level) * 3 - i + 1;
/*     */       float f = (this.infos[b]).band.getHeight() * 72.0F;
/*     */       paramGraphics.setColor(Color.lightGray);
/*     */       Common.drawLine(paramGraphics, k, (int)f1, (int)this.x, (int)f1);
/*     */       if (f >= f2) {
/*     */         paramGraphics.setColor(new Color(80, 80, 80));
/*     */         if ((this.infos[b]).level > 0) {
/*     */           paramGraphics.drawString("#" + (this.infos[b]).level + " " + (this.infos[b]).type, k, (int)(f1 + fontMetrics.getMaxAscent()));
/*     */         } else {
/*     */           paramGraphics.drawString((this.infos[b]).type, k, (int)(f1 + fontMetrics.getMaxAscent()));
/*     */         } 
/*     */       } 
/*     */       paramGraphics.setColor(Color.gray);
/*     */       Common.drawLine(paramGraphics, (int)this.x, (int)f1, (int)(this.x + this.width), (int)f1);
/*     */       f1 += f;
/*     */     } 
/*     */     paramGraphics.setColor(Color.lightGray);
/*     */     Common.drawLine(paramGraphics, (1 - i), (int)f1, (int)this.x, (int)f1);
/*     */     paramGraphics.setColor(Color.gray);
/*     */     Common.drawLine(paramGraphics, (int)this.x, (int)f1, (int)(this.x + this.width), (int)f1);
/*     */     paramGraphics.setClip(shape);
/*     */   }
/*     */   
/*     */   public Rectangle getBounds() {
/*     */     float f = 0.0F;
/*     */     for (byte b = 0; b < this.infos.length; b++)
/*     */       f += (this.infos[b]).band.getHeight() * 72.0F; 
/*     */     return new Rectangle((int)this.x, (int)this.y, (int)this.width, (int)f);
/*     */   }
/*     */   
/*     */   public void setLocation(Point paramPoint) { this.x = paramPoint.x;
/*     */     this.y = paramPoint.y; }
/*     */   
/*     */   public SectionBand findSectionBand(Rectangle paramRectangle) {
/*     */     float f = paramRectangle.y - this.y;
/*     */     for (byte b = 0; b < this.infos.length; b++) {
/*     */       float f1 = (this.infos[b]).band.getHeight() * 72.0F;
/*     */       if (f <= f1) {
/*     */         paramRectangle.y = (int)f;
/*     */         return (this.infos[b]).band;
/*     */       } 
/*     */       f -= f1;
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   public Rectangle getSectionBandBounds(SectionBand paramSectionBand) {
/*     */     float f = this.y;
/*     */     for (byte b = 0; b < this.infos.length && (this.infos[b]).band != paramSectionBand; b++) {
/*     */       float f1 = (this.infos[b]).band.getHeight() * 72.0F;
/*     */       f += f1;
/*     */     } 
/*     */     return new Rectangle((int)this.x, (int)f, (int)this.width, (int)(paramSectionBand.getHeight() * 72.0F));
/*     */   }
/*     */   
/*     */   public int getSectionBandCount() { return this.infos.length; }
/*     */   
/*     */   public SectionBand getSectionBand(int paramInt) { return (this.infos[paramInt]).band; }
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
/*     */     paramObjectInputStream.defaultReadObject();
/*     */     this.elem = new DefaultContext();
/*     */     ((DefaultContext)this.elem).read(paramObjectInputStream);
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/*     */     paramObjectOutputStream.defaultWriteObject();
/*     */     DefaultContext.write(paramObjectOutputStream, this.elem);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SectionPaintable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */