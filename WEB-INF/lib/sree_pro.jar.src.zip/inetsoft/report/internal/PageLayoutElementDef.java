package inetsoft.report.internal;

import inetsoft.report.PageArea;
import inetsoft.report.PageLayoutElement;
import inetsoft.report.ReportElement;
import inetsoft.report.StylePage;
import inetsoft.report.StyleSheet;
import inetsoft.report.locale.Catalog;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;

public class PageLayoutElementDef extends BaseElement implements PageLayoutElement {
  private PageArea[] areas;
  
  public PageLayoutElementDef(StyleSheet paramStyleSheet, PageArea[] paramArrayOfPageArea) {
    super(paramStyleSheet, true);
    this.areas = paramArrayOfPageArea;
  }
  
  public boolean isFlowControl() { return true; }
  
  public boolean print(StylePage paramStylePage) {
    if (!isVisible())
      return false; 
    this.report.areas = this.areas;
    this.report.npareas = null;
    this.report.npframes = null;
    super.print(paramStylePage);
    if (this.report.designtime)
      paramStylePage.addPaintable(new BasePaintable(this, this) {
            Rectangle box;
            
            private final PageLayoutElementDef this$0;
            
            public void paint(Graphics param1Graphics) {}
            
            public Rectangle getBounds() { return this.box; }
            
            public void setLocation(Point param1Point) { this.box.x = param1Point.x;
              this.box.y = param1Point.y; }
          }); 
    return false;
  }
  
  public String toString() { return getID() + " [" + Catalog.getString(getType()) + ": " + this.areas.length + "]"; }
  
  public String getType() { return "PageLayout"; }
  
  public PageArea[] getPageAreas() { return this.areas; }
  
  public void setPageAreas(PageArea[] paramArrayOfPageArea) { this.areas = paramArrayOfPageArea; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\PageLayoutElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */