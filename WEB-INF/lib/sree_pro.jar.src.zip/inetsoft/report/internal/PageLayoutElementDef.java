/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.PageArea;
/*     */ import inetsoft.report.PageLayoutElement;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PageLayoutElementDef
/*     */   extends BaseElement
/*     */   implements PageLayoutElement
/*     */ {
/*     */   private PageArea[] areas;
/*     */   
/*     */   public PageLayoutElementDef(StyleSheet paramStyleSheet, PageArea[] paramArrayOfPageArea) {
/*  32 */     super(paramStyleSheet, true);
/*     */     
/*  34 */     this.areas = paramArrayOfPageArea;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   public boolean isFlowControl() { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean print(StylePage paramStylePage) {
/*  49 */     if (!isVisible()) {
/*  50 */       return false;
/*     */     }
/*     */     
/*  53 */     this.report.areas = this.areas;
/*  54 */     this.report.npareas = null;
/*  55 */     this.report.npframes = null;
/*     */     
/*  57 */     super.print(paramStylePage);
/*     */     
/*  59 */     if (this.report.designtime) {
/*  60 */       paramStylePage.addPaintable(new BasePaintable(this, this)
/*     */           {
/*     */             Rectangle box;
/*     */             
/*     */             private final PageLayoutElementDef this$0;
/*     */ 
/*     */             
/*     */             public void paint(Graphics param1Graphics) {}
/*     */ 
/*     */             
/*  70 */             public Rectangle getBounds() { return this.box; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             public void setLocation(Point param1Point) {
/*  80 */               this.box.x = param1Point.x; this.box.y = param1Point.y;
/*     */             }
/*     */           });
/*     */     }
/*     */     
/*  85 */     return false;
/*     */   }
/*     */ 
/*     */   
/*  89 */   public String toString() { return getID() + " [" + Catalog.getString(getType()) + ": " + this.areas.length + "]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public String getType() { return "PageLayout"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public PageArea[] getPageAreas() { return this.areas; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public void setPageAreas(PageArea[] paramArrayOfPageArea) { this.areas = paramArrayOfPageArea; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\PageLayoutElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */