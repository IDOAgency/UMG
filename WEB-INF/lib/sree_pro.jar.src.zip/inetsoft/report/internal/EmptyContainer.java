/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.CompositeLens;
/*    */ import inetsoft.report.Context;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyContainer
/*    */   implements CompositeLens
/*    */ {
/* 28 */   public Object nextElement(Context paramContext) { return (this.idx++ == 0) ? this.painter : null; }
/*    */ 
/*    */ 
/*    */   
/* 32 */   public void reset() { this.idx = 0; }
/*    */ 
/*    */   
/* 35 */   int idx = 0;
/* 36 */   EmptyPainter painter = new EmptyPainter(Catalog.getString("Container Area"), -1000, 20);
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\EmptyContainer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */