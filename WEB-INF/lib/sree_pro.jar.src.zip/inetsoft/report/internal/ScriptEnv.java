package inetsoft.report.internal;

import inetsoft.report.FixedContainer;
import inetsoft.report.ReportElement;
import inetsoft.report.StyleSheet;

public abstract class ScriptEnv {
  static boolean found = false;
  
  static  {
    try {
      Class.forName("inetsoft.report.script.ScriptEngine");
      found = true;
    } catch (Throwable throwable) {}
  }
  
  public abstract Object newScope(FixedContainer paramFixedContainer) throws Exception;
  
  public abstract void put(String paramString, Object paramObject);
  
  public abstract Object exec(ReportElement paramReportElement, Object paramObject1, Object paramObject2) throws Exception;
  
  public abstract Object compile(String paramString) throws Exception;
  
  public abstract void reset();
  
  public abstract void setStyleSheet(StyleSheet paramStyleSheet);
  
  public static ScriptEnv getScriptEnv(StyleSheet paramStyleSheet) {
    if (found)
      try {
        ScriptEnv scriptEnv = (ScriptEnv)Class.forName("inetsoft.report.internal.JavaScriptEnv").newInstance();
        scriptEnv.setStyleSheet(paramStyleSheet);
        return scriptEnv;
      } catch (Throwable throwable) {} 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ScriptEnv.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */