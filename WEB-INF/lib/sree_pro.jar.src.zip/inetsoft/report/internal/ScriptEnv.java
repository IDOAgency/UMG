/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.FixedContainer;
/*    */ import inetsoft.report.ReportElement;
/*    */ import inetsoft.report.StyleSheet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ScriptEnv
/*    */ {
/*    */   static boolean found = false;
/*    */   
/*    */   static  {
/*    */     try {
/* 29 */       Class.forName("inetsoft.report.script.ScriptEngine");
/* 30 */       found = true;
/* 31 */     } catch (Throwable throwable) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract Object newScope(FixedContainer paramFixedContainer) throws Exception;
/*    */ 
/*    */   
/*    */   public static ScriptEnv getScriptEnv(StyleSheet paramStyleSheet) {
/* 39 */     if (found) {
/*    */       try {
/* 41 */         ScriptEnv scriptEnv = (ScriptEnv)Class.forName("inetsoft.report.internal.JavaScriptEnv").newInstance();
/*    */         
/* 43 */         scriptEnv.setStyleSheet(paramStyleSheet);
/* 44 */         return scriptEnv;
/* 45 */       } catch (Throwable throwable) {}
/*    */     }
/*    */ 
/*    */     
/* 49 */     return null;
/*    */   }
/*    */   
/*    */   public abstract void put(String paramString, Object paramObject);
/*    */   
/*    */   public abstract Object exec(ReportElement paramReportElement, Object paramObject1, Object paramObject2) throws Exception;
/*    */   
/*    */   public abstract Object compile(String paramString) throws Exception;
/*    */   
/*    */   public abstract void reset();
/*    */   
/*    */   public abstract void setStyleSheet(StyleSheet paramStyleSheet);
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ScriptEnv.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */