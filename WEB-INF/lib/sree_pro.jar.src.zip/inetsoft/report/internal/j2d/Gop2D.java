/*     */ package inetsoft.report.internal.j2d;
/*     */ import com.sun.image.codec.jpeg.JPEGImageEncoder;
/*     */ import inetsoft.report.Margin;
/*     */ import inetsoft.report.Painter;
/*     */ import inetsoft.report.PreviewPage;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.internal.Bounds;
/*     */ import inetsoft.report.internal.CustomGraphics;
/*     */ import inetsoft.report.internal.Gop;
/*     */ import inetsoft.report.internal.PaperSize;
/*     */ import inetsoft.report.j2d.StyleBook;
/*     */ import inetsoft.report.j2d.StylePrinter;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.font.FontRenderContext;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Arc2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.awt.print.PageFormat;
/*     */ import java.awt.print.Pageable;
/*     */ import java.awt.print.Paper;
/*     */ import java.awt.print.PrinterJob;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class Gop2D extends Gop {
/*  41 */   public boolean isJava2() { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   public StyleSheet createStyleSheet() { return new StyleSheet2D(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public PreviewView getPreviewView() { return new Previewer2D(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(StyleSheet paramStyleSheet) throws Exception {
/*  63 */     PrinterJob printerJob = StylePrinter.getPrinterJob();
/*  64 */     PageFormat pageFormat = printerJob.defaultPage();
/*  65 */     String str = paramStyleSheet.getProperty("Orientation");
/*     */     
/*  67 */     pageFormat.setOrientation(PaperSize.getOrientation(str));
/*     */     
/*  69 */     str = paramStyleSheet.getProperty("PageSize");
/*  70 */     if (str != null) {
/*  71 */       Size size = PaperSize.getSize(str);
/*  72 */       pageFormat.getPaper().setSize(size.width, size.height);
/*     */     } 
/*     */     
/*  75 */     StyleBook styleBook = new StyleBook(paramStyleSheet, pageFormat);
/*  76 */     printerJob.setPageable(styleBook);
/*     */ 
/*     */     
/*  79 */     if (printerJob.printDialog()) {
/*  80 */       printerJob.print();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(String paramString, Enumeration paramEnumeration, boolean paramBoolean) throws Exception {
/*  90 */     if (!paramEnumeration.hasMoreElements()) {
/*     */       return;
/*     */     }
/*     */     
/*  94 */     PrinterJob printerJob = (paramString == null) ? StylePrinter.getPrinterJob() : StylePrinter.getPrinterJob(paramString);
/*     */ 
/*     */     
/*  97 */     if (printerJob == null) {
/*  98 */       throw new RuntimeException("Printer can not be accessed: " + paramString);
/*     */     }
/*     */     
/* 101 */     Vector vector = new Vector();
/* 102 */     while (paramEnumeration.hasMoreElements()) {
/* 103 */       vector.addElement(paramEnumeration.nextElement());
/*     */     }
/*     */     
/* 106 */     StylePage[] arrayOfStylePage = new StylePage[vector.size()];
/* 107 */     vector.copyInto(arrayOfStylePage);
/* 108 */     Dimension dimension = arrayOfStylePage[0].getPageDimension();
/*     */     
/* 110 */     PageFormat pageFormat = printerJob.defaultPage();
/* 111 */     Paper paper = pageFormat.getPaper();
/* 112 */     Margin margin = StyleSheet.getPrinterMargin();
/*     */     
/* 114 */     if (dimension.width > dimension.height) {
/* 115 */       pageFormat.setOrientation(0);
/* 116 */       paper.setSize(dimension.height, dimension.width);
/*     */     } else {
/*     */       
/* 119 */       pageFormat.setOrientation(1);
/* 120 */       paper.setSize(dimension.width, dimension.height);
/*     */     } 
/*     */     
/* 123 */     paper.setImageableArea(paper.getImageableX() - margin.left * 72.0D, 0.0D, paper.getWidth(), paper.getHeight());
/*     */     
/* 125 */     pageFormat.setPaper(paper);
/*     */     
/* 127 */     Pageable pageable = new Pageable(this, arrayOfStylePage, pageFormat) { private final StylePage[] val$pgarr; private final PageFormat val$fmt; private final Gop2D this$0;
/* 128 */         public int getNumberOfPages() { return this.val$pgarr.length; }
/* 129 */         public PageFormat getPageFormat(int param1Int) { return this.val$fmt; }
/*     */         
/* 131 */         public Printable getPrintable(int param1Int) { return new Gop2D$2(this, param1Int); }
/*     */          }
/*     */       ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     printerJob.setPageable(pageable);
/*     */ 
/*     */     
/* 143 */     if (!paramBoolean || printerJob.printDialog()) {
/* 144 */       printerJob.print();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 185 */   public float stringWidth(String paramString, Font paramFont, FontMetrics paramFontMetrics) { return adjustSpacing(paramFont, (paramFontMetrics.stringWidth(paramString) + 1)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClip(Graphics paramGraphics, Bounds paramBounds) {
/*     */     try {
/* 208 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 209 */       graphics2D.setClip(new Rectangle2D.Float(paramBounds.x, paramBounds.y, paramBounds.width, paramBounds.height));
/*     */     } catch (Exception exception) {
/* 211 */       super.setClip(paramGraphics, paramBounds);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clipRect(Graphics paramGraphics, Bounds paramBounds) {
/*     */     try {
/* 222 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 223 */       graphics2D.clip(new Rectangle2D.Float(paramBounds.x, paramBounds.y, paramBounds.width, paramBounds.height));
/*     */     } catch (Exception exception) {
/* 225 */       super.clipRect(paramGraphics, paramBounds);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawImage(Graphics paramGraphics, Image paramImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, ImageObserver paramImageObserver) {
/*     */     try {
/* 242 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/*     */       
/* 244 */       Dimension dimension = new Dimension(paramImage.getWidth(null), paramImage.getHeight(null));
/* 245 */       AffineTransform affineTransform = new AffineTransform();
/* 246 */       affineTransform.translate(paramFloat1, paramFloat2);
/*     */ 
/*     */       
/* 249 */       if (paramImage instanceof MetaImage) {
/* 250 */         paramImage = ((MetaImage)paramImage).getImage();
/*     */       }
/*     */       
/* 253 */       if (paramFloat3 > 0.0F && paramFloat4 > 0.0F && dimension.width != (int)paramFloat3 && dimension.width != 0 && dimension.height != (int)paramFloat4 && dimension.height != 0) {
/*     */         
/* 255 */         String str = ReportEnv.getProperty("StyleReport.ditherImage");
/*     */         
/* 257 */         if (str != null && str.equals("true")) {
/* 258 */           paramImage = paramImage.getScaledInstance((int)paramFloat3, (int)paramFloat4, 4);
/*     */         }
/*     */         else {
/*     */           
/* 262 */           affineTransform.scale((paramFloat3 / dimension.width), (paramFloat4 / dimension.height));
/*     */         } 
/*     */       } 
/*     */       
/* 266 */       if (paramImage instanceof RenderedImage) {
/* 267 */         graphics2D.drawRenderedImage((RenderedImage)paramImage, affineTransform);
/*     */       } else {
/*     */         
/* 270 */         graphics2D.drawImage(paramImage, affineTransform, paramImageObserver);
/*     */       } 
/*     */     } catch (ClassCastException classCastException) {
/* 273 */       super.drawImage(paramGraphics, paramImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramImageObserver);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rotate(Graphics paramGraphics, double paramDouble) {
/*     */     try {
/* 282 */       ((Graphics2D)paramGraphics).rotate(paramDouble);
/* 283 */     } catch (ClassCastException classCastException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 291 */   public void paintPage(Graphics paramGraphics, PreviewPage paramPreviewPage) { PreviewPage2D.paintPage(paramGraphics, paramPreviewPage); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Image createImage(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
/* 298 */     BufferedImage bufferedImage = new BufferedImage(paramInt1, paramInt2, 1);
/*     */     
/* 300 */     int[] arrayOfInt = new int[paramInt1];
/*     */     
/* 302 */     byte b1 = 0;
/* 303 */     for (byte b2 = 0; b2 < paramInt2; b2++) {
/* 304 */       for (byte b = 0; b < paramInt1; b++) {
/* 305 */         byte b3 = paramArrayOfByte[b1++] & 0xFF;
/* 306 */         byte b4 = paramArrayOfByte[b1++] & 0xFF;
/* 307 */         byte b5 = paramArrayOfByte[b1++] & 0xFF;
/* 308 */         arrayOfInt[b] = 0xFF000000 | b3 << 16 | b4 << 8 | b5;
/*     */       } 
/*     */       
/* 311 */       bufferedImage.setRGB(0, b2, paramInt1, 1, arrayOfInt, 0, paramInt1);
/*     */     } 
/*     */     
/* 314 */     return bufferedImage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Painter paramPainter, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, Color paramColor1, Color paramColor2) {
/*     */     try {
/* 341 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/*     */       
/* 343 */       Shape shape = graphics2D.getClip();
/* 344 */       AffineTransform affineTransform = graphics2D.getTransform();
/* 345 */       Color color = graphics2D.getColor();
/*     */       
/* 347 */       graphics2D.translate(paramFloat1, paramFloat2);
/* 348 */       graphics2D.clip(new Rectangle2D.Float(0.0F, 0.0F, paramFloat3, paramFloat4));
/*     */       
/* 350 */       if (paramColor2 != null) {
/* 351 */         graphics2D.setColor(paramColor2);
/* 352 */         graphics2D.fill(new Rectangle2D.Float(0.0F, 0.0F, paramFloat3, paramFloat4));
/*     */       } 
/*     */       
/* 355 */       graphics2D.setColor(paramColor1);
/* 356 */       graphics2D.scale((paramFloat3 / paramFloat7), (paramFloat4 / paramFloat9));
/* 357 */       paramPainter.paint(graphics2D, (int)paramFloat5, (int)paramFloat6, (int)paramFloat7, (int)paramFloat8);
/*     */       
/* 359 */       graphics2D.setTransform(affineTransform);
/* 360 */       graphics2D.setClip(shape);
/* 361 */       graphics2D.setColor(color);
/*     */     } catch (ClassCastException classCastException) {
/* 363 */       super.paint(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramPainter, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramColor1, paramColor2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 374 */   public float getLineAdjustment(Graphics paramGraphics) { return (paramGraphics instanceof java.awt.print.PrinterGraphics && paramGraphics instanceof Graphics2D && !(paramGraphics instanceof CustomGraphics)) ? 0.5F : 0.0F; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 382 */   public boolean isGraphics2D(Graphics paramGraphics) { return paramGraphics instanceof Graphics2D; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawHLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, int paramInt3) {
/*     */     try {
/* 399 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/*     */       
/* 401 */       if ((!(paramGraphics instanceof CustomGraphics) || ((CustomGraphics)paramGraphics).isSupported(1)) && (paramInt1 & 0x1000) != 0 && (paramInt1 & 0xF0) != 0) {
/*     */ 
/*     */         
/* 404 */         float f = Math.min(getLineWidth(paramInt2), getLineWidth(paramInt3));
/*     */         
/* 406 */         drawLine(paramGraphics, paramFloat2 + f, paramFloat1, paramFloat3, paramFloat1, paramInt1);
/*     */       } else {
/*     */         
/* 409 */         super.drawHLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramInt1, paramInt2, paramInt3);
/*     */       } 
/*     */     } catch (Exception exception) {
/*     */       
/* 413 */       super.drawHLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawVLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, int paramInt3) {
/*     */     try {
/* 431 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/*     */       
/* 433 */       if ((!(paramGraphics instanceof CustomGraphics) || ((CustomGraphics)paramGraphics).isSupported(1)) && (paramInt1 & 0x1000) != 0 && (paramInt1 & 0xF0) != 0) {
/*     */ 
/*     */         
/* 436 */         float f = Math.min(getLineWidth(paramInt2), getLineWidth(paramInt3));
/*     */         
/* 438 */         drawLine(paramGraphics, paramFloat1, paramFloat2 + f, paramFloat1, paramFloat3, paramInt1);
/*     */       } else {
/*     */         
/* 441 */         super.drawVLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramInt1, paramInt2, paramInt3);
/*     */       } 
/*     */     } catch (Exception exception) {
/* 444 */       super.drawVLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt) {
/*     */     try {
/* 454 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 455 */       Stroke stroke = graphics2D.getStroke();
/*     */       
/* 457 */       if ((paramInt & 0xF0) != 0) {
/* 458 */         int i = (paramInt & 0xF0) >> 4;
/* 459 */         graphics2D.setStroke(new BasicStroke(getLineWidth(paramInt), 0, 0, 10.0F, new float[] { i }, 0.0F));
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 465 */         graphics2D.setStroke(new BasicStroke(getLineWidth(paramInt), 0, 0));
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 470 */       drawLine(graphics2D, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 471 */       graphics2D.setStroke(stroke);
/*     */     } catch (ClassCastException classCastException) {
/* 473 */       super.drawLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*     */     try {
/* 482 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 501 */       graphics2D.draw(new Line2D.Float(paramFloat1, paramFloat2, paramFloat3, paramFloat4));
/*     */     } catch (ClassCastException classCastException) {
/* 503 */       super.drawLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fill(Graphics paramGraphics, Shape paramShape, Object paramObject) {
/*     */     try {
/* 514 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 515 */       Paint paint = graphics2D.getPaint();
/* 516 */       graphics2D.setPaint((Paint)paramObject);
/* 517 */       graphics2D.fill(paramShape);
/* 518 */       graphics2D.setPaint(paint);
/*     */     } catch (ClassCastException classCastException) {
/* 520 */       super.fill(paramGraphics, paramShape, paramObject);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fillRect(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*     */     try {
/* 533 */       ((Graphics2D)paramGraphics).fill(new Rectangle2D.Float(paramFloat1, paramFloat2, paramFloat3, paramFloat4));
/*     */     } catch (ClassCastException classCastException) {
/* 535 */       super.fillRect(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fillArc(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, Object paramObject) {
/*     */     try {
/* 545 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 546 */       Arc2D.Float float = new Arc2D.Float(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, 2);
/* 547 */       fill(paramGraphics, float, paramObject);
/*     */     } catch (ClassCastException classCastException) {
/* 549 */       super.fillArc(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramObject);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 577 */   public Object getPaint(int paramInt) { return this.brush[paramInt % this.brush.length]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getAllFonts() {
/* 585 */     if (this.fonts == null) {
/* 586 */       this.fonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
/*     */     }
/*     */ 
/*     */     
/* 590 */     return this.fonts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 597 */   public String getFontName(Font paramFont) { return paramFont.getName(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 604 */   public String getPSName(Font paramFont) { return paramFont.getPSName(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintRotate(Painter paramPainter, Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*     */     try {
/* 613 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/*     */       
/* 615 */       AffineTransform affineTransform = graphics2D.getTransform();
/* 616 */       Color color = graphics2D.getColor();
/* 617 */       Font font = graphics2D.getFont();
/*     */       
/* 619 */       graphics2D.translate((paramFloat1 + paramFloat3 - 1.0F), paramFloat2);
/* 620 */       graphics2D.rotate(1.5707963267948966D);
/* 621 */       paramPainter.paint(graphics2D, 0, 0, Gop.round(paramFloat4), Gop.round(paramFloat3));
/*     */       
/* 623 */       graphics2D.setTransform(affineTransform);
/* 624 */       graphics2D.setColor(color);
/* 625 */       graphics2D.setFont(font);
/*     */     } catch (ClassCastException classCastException) {
/* 627 */       super.paintRotate(paramPainter, paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startPage(Graphics paramGraphics, StylePage paramStylePage) {
/* 635 */     super.startPage(paramGraphics, paramStylePage);
/*     */     
/* 637 */     Rectangle rectangle = paramGraphics.getClipBounds();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 642 */     if (paramGraphics instanceof java.awt.print.PrinterGraphics && !(paramGraphics instanceof CustomGraphics) && rectangle.height > 50) {
/*     */       
/*     */       try {
/* 645 */         Graphics2D graphics2D = (Graphics2D)paramGraphics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 662 */       catch (ClassCastException classCastException) {}
/*     */ 
/*     */       
/* 665 */       Dimension dimension = paramStylePage.getPageDimension();
/* 666 */       Color color = paramGraphics.getColor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 673 */       paramGraphics.drawImage(dot, dimension.width / 2, dimension.height / 2, null);
/*     */ 
/*     */       
/* 676 */       paramGraphics.setColor(Color.white);
/* 677 */       int i = rectangle.y + rectangle.height, j = 0;
/*     */       
/* 679 */       for (byte b = 0; b < paramStylePage.getPaintableCount(); b++) {
/* 680 */         Rectangle rectangle1 = paramStylePage.getPaintable(b).getBounds();
/* 681 */         i = Math.min(i, rectangle1.y);
/* 682 */         j = Math.max(j, rectangle1.y + rectangle1.height);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 692 */       if (j > i) {
/* 693 */         drawLine(paramGraphics, rectangle.x, i, rectangle.y, j);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeJPEG(Image paramImage, OutputStream paramOutputStream) {
/*     */     try {
/* 703 */       if (paramImage instanceof BufferedImage) {
/* 704 */         JPEGImageEncoder jPEGImageEncoder = JPEGCodec.createJPEGEncoder(paramOutputStream);
/* 705 */         jPEGImageEncoder.encode((BufferedImage)paramImage);
/*     */         return;
/*     */       } 
/* 708 */     } catch (Throwable throwable) {}
/*     */ 
/*     */     
/* 711 */     super.writeJPEG(paramImage, paramOutputStream);
/*     */   }
/*     */   
/* 714 */   AffineTransform notransform = new AffineTransform();
/*     */ 
/*     */ 
/*     */   
/* 718 */   FontRenderContext fontRenderContext = new FontRenderContext(this.notransform, false, true);
/*     */ 
/*     */   
/*     */   String[] fonts;
/*     */ 
/*     */   
/* 724 */   Paint[] brush = new Paint[28]; public Gop2D() {
/* 725 */     byte b1 = 0;
/*     */ 
/*     */     
/* 728 */     for (byte b2 = 0; b2 < 2; b2++) {
/* 729 */       for (byte b = 0; b < 2; b++) {
/* 730 */         for (byte b3 = 0; b3 < 5; b3++) {
/* 731 */           Dimension dimension = null;
/* 732 */           boolean bool = !b2 ? 1 : 2;
/*     */           
/* 734 */           byte b4 = !b ? 4 : 6;
/* 735 */           if (b3 == 3 || b3 == 5) {
/* 736 */             dimension = new Dimension(b4, 2 * b4);
/*     */           }
/* 738 */           else if (b3 == 4 || b3 == 6) {
/* 739 */             dimension = new Dimension(2 * b4, b4);
/*     */           } else {
/*     */             
/* 742 */             dimension = new Dimension(b4, b4);
/*     */           } 
/*     */           
/* 745 */           BufferedImage bufferedImage = new BufferedImage(dimension.width, dimension.height, 10);
/*     */           
/* 747 */           Graphics2D graphics2D = (Graphics2D)bufferedImage.getGraphics();
/* 748 */           graphics2D.setColor(Color.white);
/* 749 */           graphics2D.fillRect(0, 0, dimension.width, dimension.height);
/* 750 */           graphics2D.setStroke(new BasicStroke(bool));
/* 751 */           graphics2D.setColor(Color.black);
/*     */           
/* 753 */           switch (b3) { case false: case true:
/*     */             case true:
/* 755 */               drawLine(graphics2D, 0.0F, (dimension.height - 1), (dimension.width - 1), 0.0F);
/*     */               break;
/*     */             case true:
/* 758 */               drawLine(graphics2D, 0.0F, (dimension.height - 1), (dimension.width - 1), 0.0F);
/*     */             case true: case true:
/*     */             case true:
/* 761 */               drawLine(graphics2D, 0.0F, 0.0F, (dimension.width - 1), (dimension.height - 1));
/*     */               break; }
/*     */ 
/*     */           
/* 765 */           graphics2D.dispose();
/* 766 */           this.brush[b1++] = new TexturePaint(bufferedImage, new Rectangle2D.Float(0.0F, 0.0F, dimension.width, dimension.height));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 779 */   public Image createImage(int paramInt1, int paramInt2) { return new BufferedImage(paramInt1, paramInt2, 1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 786 */   public float getLineWidth(int paramInt) { return (paramInt & 0xF) + ((paramInt & 0xF0000) >> 16) / 16.0F; }
/*     */ 
/*     */ 
/*     */   
/* 790 */   static BufferedImage dot = new BufferedImage(1, 1, 1);
/*     */   
/*     */   static  {
/* 793 */     dot.setRGB(0, 0, -1);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\Gop2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */