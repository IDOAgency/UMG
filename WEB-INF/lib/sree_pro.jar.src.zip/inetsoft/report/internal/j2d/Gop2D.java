package inetsoft.report.internal.j2d;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;
import inetsoft.report.Margin;
import inetsoft.report.Painter;
import inetsoft.report.PreviewPage;
import inetsoft.report.PreviewView;
import inetsoft.report.ReportEnv;
import inetsoft.report.Size;
import inetsoft.report.StylePage;
import inetsoft.report.StyleSheet;
import inetsoft.report.internal.Bounds;
import inetsoft.report.internal.CustomGraphics;
import inetsoft.report.internal.Gop;
import inetsoft.report.internal.MetaImage;
import inetsoft.report.internal.PaperSize;
import inetsoft.report.j2d.PreviewPage2D;
import inetsoft.report.j2d.Previewer2D;
import inetsoft.report.j2d.StyleBook;
import inetsoft.report.j2d.StylePrinter;
import inetsoft.report.j2d.StyleSheet2D;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.TexturePaint;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.RenderedImage;
import java.awt.print.PageFormat;
import java.awt.print.Pageable;
import java.awt.print.Paper;
import java.awt.print.Printable;
import java.awt.print.PrinterJob;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Vector;

public class Gop2D extends Gop {
  public boolean isJava2() { return true; }
  
  public StyleSheet createStyleSheet() { return new StyleSheet2D(); }
  
  public PreviewView getPreviewView() { return new Previewer2D(); }
  
  public void print(StyleSheet paramStyleSheet) throws Exception {
    PrinterJob printerJob = StylePrinter.getPrinterJob();
    PageFormat pageFormat = printerJob.defaultPage();
    String str = paramStyleSheet.getProperty("Orientation");
    pageFormat.setOrientation(PaperSize.getOrientation(str));
    str = paramStyleSheet.getProperty("PageSize");
    if (str != null) {
      Size size = PaperSize.getSize(str);
      pageFormat.getPaper().setSize(size.width, size.height);
    } 
    StyleBook styleBook = new StyleBook(paramStyleSheet, pageFormat);
    printerJob.setPageable(styleBook);
    if (printerJob.printDialog())
      printerJob.print(); 
  }
  
  public void print(String paramString, Enumeration paramEnumeration, boolean paramBoolean) throws Exception {
    if (!paramEnumeration.hasMoreElements())
      return; 
    PrinterJob printerJob = (paramString == null) ? StylePrinter.getPrinterJob() : StylePrinter.getPrinterJob(paramString);
    if (printerJob == null)
      throw new RuntimeException("Printer can not be accessed: " + paramString); 
    Vector vector = new Vector();
    while (paramEnumeration.hasMoreElements())
      vector.addElement(paramEnumeration.nextElement()); 
    StylePage[] arrayOfStylePage = new StylePage[vector.size()];
    vector.copyInto(arrayOfStylePage);
    Dimension dimension = arrayOfStylePage[0].getPageDimension();
    PageFormat pageFormat = printerJob.defaultPage();
    Paper paper = pageFormat.getPaper();
    Margin margin = StyleSheet.getPrinterMargin();
    if (dimension.width > dimension.height) {
      pageFormat.setOrientation(0);
      paper.setSize(dimension.height, dimension.width);
    } else {
      pageFormat.setOrientation(1);
      paper.setSize(dimension.width, dimension.height);
    } 
    paper.setImageableArea(paper.getImageableX() - margin.left * 72.0D, 0.0D, paper.getWidth(), paper.getHeight());
    pageFormat.setPaper(paper);
    Pageable pageable = new Pageable(this, arrayOfStylePage, pageFormat) {
        private final StylePage[] val$pgarr;
        
        private final PageFormat val$fmt;
        
        private final Gop2D this$0;
        
        public int getNumberOfPages() { return this.val$pgarr.length; }
        
        public PageFormat getPageFormat(int param1Int) { return this.val$fmt; }
        
        public Printable getPrintable(int param1Int) { return new Gop2D$2(this, param1Int); }
      };
    printerJob.setPageable(pageable);
    if (!paramBoolean || printerJob.printDialog())
      printerJob.print(); 
  }
  
  public float stringWidth(String paramString, Font paramFont, FontMetrics paramFontMetrics) { return adjustSpacing(paramFont, (paramFontMetrics.stringWidth(paramString) + 1)); }
  
  public void setClip(Graphics paramGraphics, Bounds paramBounds) {
    try {
      Graphics2D graphics2D = (Graphics2D)paramGraphics;
      graphics2D.setClip(new Rectangle2D.Float(paramBounds.x, paramBounds.y, paramBounds.width, paramBounds.height));
    } catch (Exception exception) {
      super.setClip(paramGraphics, paramBounds);
    } 
  }
  
  public void clipRect(Graphics paramGraphics, Bounds paramBounds) {
    try {
      Graphics2D graphics2D = (Graphics2D)paramGraphics;
      graphics2D.clip(new Rectangle2D.Float(paramBounds.x, paramBounds.y, paramBounds.width, paramBounds.height));
    } catch (Exception exception) {
      super.clipRect(paramGraphics, paramBounds);
    } 
  }
  
  public void drawImage(Graphics paramGraphics, Image paramImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, ImageObserver paramImageObserver) {
    try {
      Graphics2D graphics2D = (Graphics2D)paramGraphics;
      Dimension dimension = new Dimension(paramImage.getWidth(null), paramImage.getHeight(null));
      AffineTransform affineTransform = new AffineTransform();
      affineTransform.translate(paramFloat1, paramFloat2);
      if (paramImage instanceof MetaImage)
        paramImage = ((MetaImage)paramImage).getImage(); 
      if (paramFloat3 > 0.0F && paramFloat4 > 0.0F && dimension.width != (int)paramFloat3 && dimension.width != 0 && dimension.height != (int)paramFloat4 && dimension.height != 0) {
        String str = ReportEnv.getProperty("StyleReport.ditherImage");
        if (str != null && str.equals("true")) {
          paramImage = paramImage.getScaledInstance((int)paramFloat3, (int)paramFloat4, 4);
        } else {
          affineTransform.scale((paramFloat3 / dimension.width), (paramFloat4 / dimension.height));
        } 
      } 
      if (paramImage instanceof RenderedImage) {
        graphics2D.drawRenderedImage((RenderedImage)paramImage, affineTransform);
      } else {
        graphics2D.drawImage(paramImage, affineTransform, paramImageObserver);
      } 
    } catch (ClassCastException classCastException) {
      super.drawImage(paramGraphics, paramImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramImageObserver);
    } 
  }
  
  public void rotate(Graphics paramGraphics, double paramDouble) {
    try {
      ((Graphics2D)paramGraphics).rotate(paramDouble);
    } catch (ClassCastException classCastException) {}
  }
  
  public void paintPage(Graphics paramGraphics, PreviewPage paramPreviewPage) { PreviewPage2D.paintPage(paramGraphics, paramPreviewPage); }
  
  public Image createImage(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
    BufferedImage bufferedImage = new BufferedImage(paramInt1, paramInt2, 1);
    int[] arrayOfInt = new int[paramInt1];
    byte b1 = 0;
    for (byte b2 = 0; b2 < paramInt2; b2++) {
      for (byte b = 0; b < paramInt1; b++) {
        byte b3 = paramArrayOfByte[b1++] & 0xFF;
        byte b4 = paramArrayOfByte[b1++] & 0xFF;
        byte b5 = paramArrayOfByte[b1++] & 0xFF;
        arrayOfInt[b] = 0xFF000000 | b3 << 16 | b4 << 8 | b5;
      } 
      bufferedImage.setRGB(0, b2, paramInt1, 1, arrayOfInt, 0, paramInt1);
    } 
    return bufferedImage;
  }
  
  public void paint(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Painter paramPainter, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, Color paramColor1, Color paramColor2) {
    try {
      Graphics2D graphics2D = (Graphics2D)paramGraphics;
      Shape shape = graphics2D.getClip();
      AffineTransform affineTransform = graphics2D.getTransform();
      Color color = graphics2D.getColor();
      graphics2D.translate(paramFloat1, paramFloat2);
      graphics2D.clip(new Rectangle2D.Float(0.0F, 0.0F, paramFloat3, paramFloat4));
      if (paramColor2 != null) {
        graphics2D.setColor(paramColor2);
        graphics2D.fill(new Rectangle2D.Float(0.0F, 0.0F, paramFloat3, paramFloat4));
      } 
      graphics2D.setColor(paramColor1);
      graphics2D.scale((paramFloat3 / paramFloat7), (paramFloat4 / paramFloat9));
      paramPainter.paint(graphics2D, (int)paramFloat5, (int)paramFloat6, (int)paramFloat7, (int)paramFloat8);
      graphics2D.setTransform(affineTransform);
      graphics2D.setClip(shape);
      graphics2D.setColor(color);
    } catch (ClassCastException classCastException) {
      super.paint(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramPainter, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramColor1, paramColor2);
    } 
  }
  
  public float getLineAdjustment(Graphics paramGraphics) { return (paramGraphics instanceof java.awt.print.PrinterGraphics && paramGraphics instanceof Graphics2D && !(paramGraphics instanceof CustomGraphics)) ? 0.5F : 0.0F; }
  
  public boolean isGraphics2D(Graphics paramGraphics) { return paramGraphics instanceof Graphics2D; }
  
  public void drawHLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, int paramInt3) {
    try {
      Graphics2D graphics2D = (Graphics2D)paramGraphics;
      if ((!(paramGraphics instanceof CustomGraphics) || ((CustomGraphics)paramGraphics).isSupported(1)) && (paramInt1 & 0x1000) != 0 && (paramInt1 & 0xF0) != 0) {
        float f = Math.min(getLineWidth(paramInt2), getLineWidth(paramInt3));
        drawLine(paramGraphics, paramFloat2 + f, paramFloat1, paramFloat3, paramFloat1, paramInt1);
      } else {
        super.drawHLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramInt1, paramInt2, paramInt3);
      } 
    } catch (Exception exception) {
      super.drawHLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramInt1, paramInt2, paramInt3);
    } 
  }
  
  public void drawVLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, int paramInt3) {
    try {
      Graphics2D graphics2D = (Graphics2D)paramGraphics;
      if ((!(paramGraphics instanceof CustomGraphics) || ((CustomGraphics)paramGraphics).isSupported(1)) && (paramInt1 & 0x1000) != 0 && (paramInt1 & 0xF0) != 0) {
        float f = Math.min(getLineWidth(paramInt2), getLineWidth(paramInt3));
        drawLine(paramGraphics, paramFloat1, paramFloat2 + f, paramFloat1, paramFloat3, paramInt1);
      } else {
        super.drawVLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramInt1, paramInt2, paramInt3);
      } 
    } catch (Exception exception) {
      super.drawVLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramInt1, paramInt2, paramInt3);
    } 
  }
  
  public void drawLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt) {
    try {
      Graphics2D graphics2D = (Graphics2D)paramGraphics;
      Stroke stroke = graphics2D.getStroke();
      if ((paramInt & 0xF0) != 0) {
        int i = (paramInt & 0xF0) >> 4;
        graphics2D.setStroke(new BasicStroke(getLineWidth(paramInt), 0, 0, 10.0F, new float[] { i }, 0.0F));
      } else {
        graphics2D.setStroke(new BasicStroke(getLineWidth(paramInt), 0, 0));
      } 
      drawLine(graphics2D, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
      graphics2D.setStroke(stroke);
    } catch (ClassCastException classCastException) {
      super.drawLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt);
    } 
  }
  
  public void drawLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    try {
      Graphics2D graphics2D = (Graphics2D)paramGraphics;
      graphics2D.draw(new Line2D.Float(paramFloat1, paramFloat2, paramFloat3, paramFloat4));
    } catch (ClassCastException classCastException) {
      super.drawLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    } 
  }
  
  public void fill(Graphics paramGraphics, Shape paramShape, Object paramObject) {
    try {
      Graphics2D graphics2D = (Graphics2D)paramGraphics;
      Paint paint = graphics2D.getPaint();
      graphics2D.setPaint((Paint)paramObject);
      graphics2D.fill(paramShape);
      graphics2D.setPaint(paint);
    } catch (ClassCastException classCastException) {
      super.fill(paramGraphics, paramShape, paramObject);
    } 
  }
  
  public void fillRect(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    try {
      ((Graphics2D)paramGraphics).fill(new Rectangle2D.Float(paramFloat1, paramFloat2, paramFloat3, paramFloat4));
    } catch (ClassCastException classCastException) {
      super.fillRect(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    } 
  }
  
  public void fillArc(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, Object paramObject) {
    try {
      Graphics2D graphics2D = (Graphics2D)paramGraphics;
      Arc2D.Float float = new Arc2D.Float(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, 2);
      fill(paramGraphics, float, paramObject);
    } catch (ClassCastException classCastException) {
      super.fillArc(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramObject);
    } 
  }
  
  public Object getPaint(int paramInt) { return this.brush[paramInt % this.brush.length]; }
  
  public String[] getAllFonts() {
    if (this.fonts == null)
      this.fonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames(); 
    return this.fonts;
  }
  
  public String getFontName(Font paramFont) { return paramFont.getName(); }
  
  public String getPSName(Font paramFont) { return paramFont.getPSName(); }
  
  public void paintRotate(Painter paramPainter, Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    try {
      Graphics2D graphics2D = (Graphics2D)paramGraphics;
      AffineTransform affineTransform = graphics2D.getTransform();
      Color color = graphics2D.getColor();
      Font font = graphics2D.getFont();
      graphics2D.translate((paramFloat1 + paramFloat3 - 1.0F), paramFloat2);
      graphics2D.rotate(1.5707963267948966D);
      paramPainter.paint(graphics2D, 0, 0, Gop.round(paramFloat4), Gop.round(paramFloat3));
      graphics2D.setTransform(affineTransform);
      graphics2D.setColor(color);
      graphics2D.setFont(font);
    } catch (ClassCastException classCastException) {
      super.paintRotate(paramPainter, paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    } 
  }
  
  public void startPage(Graphics paramGraphics, StylePage paramStylePage) {
    super.startPage(paramGraphics, paramStylePage);
    Rectangle rectangle = paramGraphics.getClipBounds();
    if (paramGraphics instanceof java.awt.print.PrinterGraphics && !(paramGraphics instanceof CustomGraphics) && rectangle.height > 50) {
      try {
        Graphics2D graphics2D = (Graphics2D)paramGraphics;
      } catch (ClassCastException classCastException) {}
      Dimension dimension = paramStylePage.getPageDimension();
      Color color = paramGraphics.getColor();
      paramGraphics.drawImage(dot, dimension.width / 2, dimension.height / 2, null);
      paramGraphics.setColor(Color.white);
      int i = rectangle.y + rectangle.height, j = 0;
      for (byte b = 0; b < paramStylePage.getPaintableCount(); b++) {
        Rectangle rectangle1 = paramStylePage.getPaintable(b).getBounds();
        i = Math.min(i, rectangle1.y);
        j = Math.max(j, rectangle1.y + rectangle1.height);
      } 
      if (j > i)
        drawLine(paramGraphics, rectangle.x, i, rectangle.y, j); 
    } 
  }
  
  public void writeJPEG(Image paramImage, OutputStream paramOutputStream) {
    try {
      if (paramImage instanceof BufferedImage) {
        JPEGImageEncoder jPEGImageEncoder = JPEGCodec.createJPEGEncoder(paramOutputStream);
        jPEGImageEncoder.encode((BufferedImage)paramImage);
        return;
      } 
    } catch (Throwable throwable) {}
    super.writeJPEG(paramImage, paramOutputStream);
  }
  
  AffineTransform notransform = new AffineTransform();
  
  FontRenderContext fontRenderContext = new FontRenderContext(this.notransform, false, true);
  
  String[] fonts;
  
  Paint[] brush = new Paint[28];
  
  public Gop2D() {
    byte b1 = 0;
    for (byte b2 = 0; b2 < 2; b2++) {
      for (byte b = 0; b < 2; b++) {
        for (byte b3 = 0; b3 < 5; b3++) {
          Dimension dimension = null;
          boolean bool = !b2 ? 1 : 2;
          byte b4 = !b ? 4 : 6;
          if (b3 == 3 || b3 == 5) {
            dimension = new Dimension(b4, 2 * b4);
          } else if (b3 == 4 || b3 == 6) {
            dimension = new Dimension(2 * b4, b4);
          } else {
            dimension = new Dimension(b4, b4);
          } 
          BufferedImage bufferedImage = new BufferedImage(dimension.width, dimension.height, 10);
          Graphics2D graphics2D = (Graphics2D)bufferedImage.getGraphics();
          graphics2D.setColor(Color.white);
          graphics2D.fillRect(0, 0, dimension.width, dimension.height);
          graphics2D.setStroke(new BasicStroke(bool));
          graphics2D.setColor(Color.black);
          switch (b3) {
            case false:
            case true:
            case true:
              drawLine(graphics2D, 0.0F, (dimension.height - 1), (dimension.width - 1), 0.0F);
              break;
            case true:
              drawLine(graphics2D, 0.0F, (dimension.height - 1), (dimension.width - 1), 0.0F);
            case true:
            case true:
            case true:
              drawLine(graphics2D, 0.0F, 0.0F, (dimension.width - 1), (dimension.height - 1));
              break;
          } 
          graphics2D.dispose();
          this.brush[b1++] = new TexturePaint(bufferedImage, new Rectangle2D.Float(0.0F, 0.0F, dimension.width, dimension.height));
        } 
      } 
    } 
  }
  
  public Image createImage(int paramInt1, int paramInt2) { return new BufferedImage(paramInt1, paramInt2, 1); }
  
  public float getLineWidth(int paramInt) { return (paramInt & 0xF) + ((paramInt & 0xF0000) >> 16) / 16.0F; }
  
  static BufferedImage dot = new BufferedImage(1, 1, 1);
  
  static  {
    dot.setRGB(0, 0, -1);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\Gop2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */