package inetsoft.report.internal.j2d;

import inetsoft.report.internal.CustomGraphics;
import inetsoft.report.internal.Win32Graphics;
import java.awt.print.PrinterGraphics;
import java.awt.print.PrinterJob;

public class Win9xGraphics2D extends Win32Graphics implements CustomGraphics, PrinterGraphics {
  PrinterJob job;
  
  public static Win9xGraphics2D getGraphics(String paramString) {
    if (!Win32Graphics.isInitialized())
      return null; 
    Win9xGraphics2D win9xGraphics2D = new Win9xGraphics2D();
    if (paramString == null) {
      if (win9xGraphics2D.create2() == 0)
        return null; 
    } else if (win9xGraphics2D.create1(paramString) == 0) {
      return null;
    } 
    win9xGraphics2D.init();
    return win9xGraphics2D;
  }
  
  public boolean printDialog(int paramInt) {
    boolean bool = printDialog0(paramInt);
    if (bool)
      init(); 
    return bool;
  }
  
  public PrinterJob getPrinterJob() { return this.job; }
  
  public void setPrinterJob(PrinterJob paramPrinterJob) { this.job = paramPrinterJob; }
  
  public void startDoc(String paramString) { startDoc0(paramString); }
  
  public void startPage() { nextPage(); }
  
  public boolean isPages() { return isPages0(); }
  
  public int getFromPage() { return getFromPage0(); }
  
  public int getToPage() { return getToPage0(); }
  
  public int getCopies() { return getCopies0(); }
  
  public void setCopies(int paramInt) { setCopies0(paramInt); }
  
  public boolean isSupported(int paramInt) { return (paramInt != 1); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\Win9xGraphics2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */