/*     */ package inetsoft.report.internal.j2d;
/*     */ 
/*     */ import inetsoft.report.internal.CustomGraphics;
/*     */ import inetsoft.report.internal.Win32Graphics;
/*     */ import java.awt.print.PrinterGraphics;
/*     */ import java.awt.print.PrinterJob;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Win9xGraphics2D
/*     */   extends Win32Graphics
/*     */   implements CustomGraphics, PrinterGraphics
/*     */ {
/*     */   PrinterJob job;
/*     */   
/*     */   public static Win9xGraphics2D getGraphics(String paramString) {
/*  41 */     if (!Win32Graphics.isInitialized()) {
/*  42 */       return null;
/*     */     }
/*     */     
/*  45 */     Win9xGraphics2D win9xGraphics2D = new Win9xGraphics2D();
/*     */     
/*  47 */     if (paramString == null) {
/*  48 */       if (win9xGraphics2D.create2() == 0) {
/*  49 */         return null;
/*     */       
/*     */       }
/*     */     }
/*  53 */     else if (win9xGraphics2D.create1(paramString) == 0) {
/*  54 */       return null;
/*     */     } 
/*     */ 
/*     */     
/*  58 */     win9xGraphics2D.init();
/*  59 */     return win9xGraphics2D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean printDialog(int paramInt) {
/*  67 */     boolean bool = printDialog0(paramInt);
/*  68 */     if (bool) {
/*  69 */       init();
/*     */     }
/*     */     
/*  72 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public PrinterJob getPrinterJob() { return this.job; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public void setPrinterJob(PrinterJob paramPrinterJob) { this.job = paramPrinterJob; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public void startDoc(String paramString) { startDoc0(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public void startPage() { nextPage(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public boolean isPages() { return isPages0(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public int getFromPage() { return getFromPage0(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public int getToPage() { return getToPage0(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public int getCopies() { return getCopies0(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public void setCopies(int paramInt) { setCopies0(paramInt); }
/*     */ 
/*     */ 
/*     */   
/* 142 */   public boolean isSupported(int paramInt) { return (paramInt != 1); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\Win9xGraphics2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */