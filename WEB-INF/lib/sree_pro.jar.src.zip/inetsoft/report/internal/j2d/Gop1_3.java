/*     */ package inetsoft.report.internal.j2d;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.StylePage;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.JobAttributes;
/*     */ import java.awt.PageAttributes;
/*     */ import java.awt.PrintJob;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Gop1_3
/*     */   extends Gop2D
/*     */ {
/*  44 */   public float stringWidth(String paramString, Font paramFont, FontMetrics paramFontMetrics) { return adjustSpacing(paramFont, (paramFontMetrics.stringWidth(paramString) + 1)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(String paramString, Enumeration paramEnumeration, boolean paramBoolean) throws Exception {
/*  53 */     if (!paramEnumeration.hasMoreElements()) {
/*     */       return;
/*     */     }
/*     */     
/*  57 */     Vector vector = new Vector();
/*  58 */     while (paramEnumeration.hasMoreElements()) {
/*  59 */       vector.addElement(paramEnumeration.nextElement());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  68 */       super.print(paramString, vector.elements(), paramBoolean);
/*     */       
/*     */       return;
/*     */     } catch (Exception exception) {
/*  72 */       exception.printStackTrace();
/*     */ 
/*     */       
/*  75 */       JobAttributes jobAttributes = new JobAttributes();
/*  76 */       jobAttributes.setPrinter(paramString);
/*  77 */       jobAttributes.setDialog(paramBoolean ? JobAttributes.DialogType.NATIVE : JobAttributes.DialogType.NONE);
/*     */ 
/*     */       
/*  80 */       PageAttributes pageAttributes = new PageAttributes();
/*  81 */       pageAttributes.setOrigin(PageAttributes.OriginType.PHYSICAL);
/*     */       
/*  83 */       StylePage[] arrayOfStylePage = new StylePage[vector.size()];
/*  84 */       vector.copyInto(arrayOfStylePage);
/*  85 */       Dimension dimension = arrayOfStylePage[0].getPageDimension();
/*     */       
/*  87 */       pageAttributes.setMedia(findMediaType(dimension));
/*  88 */       if (dimension.width > dimension.height) {
/*  89 */         pageAttributes.setOrientationRequested(PageAttributes.OrientationRequestedType.LANDSCAPE);
/*     */       }
/*     */       else {
/*     */         
/*  93 */         pageAttributes.setOrientationRequested(PageAttributes.OrientationRequestedType.PORTRAIT);
/*     */       } 
/*     */ 
/*     */       
/*  97 */       PrintJob printJob = Common.getToolkit().getPrintJob(Common.getInvisibleFrame(), "Report", jobAttributes, pageAttributes);
/*     */ 
/*     */       
/* 100 */       if (printJob == null) {
/* 101 */         throw new RuntimeException("Printer not found: " + paramString);
/*     */       }
/*     */       
/* 104 */       for (byte b = 0; b < arrayOfStylePage.length; b++) {
/* 105 */         Graphics graphics = printJob.getGraphics();
/* 106 */         arrayOfStylePage[b].print(graphics);
/* 107 */         graphics.dispose();
/*     */       } 
/*     */       
/* 110 */       printJob.end();
/*     */       return;
/*     */     } 
/*     */   } private PageAttributes.MediaType findMediaType(Dimension paramDimension) {
/* 114 */     int i = Integer.MAX_VALUE;
/* 115 */     PageAttributes.MediaType mediaType = null;
/*     */     
/* 117 */     for (byte b = 0; b < this.mediamap.length; b++) {
/* 118 */       Dimension dimension = (Dimension)this.mediamap[b][0];
/* 119 */       int j = Math.abs(dimension.width - paramDimension.width) + Math.abs(dimension.height - paramDimension.height);
/*     */ 
/*     */       
/* 122 */       if (j < i) {
/* 123 */         i = j;
/* 124 */         mediaType = (PageAttributes.MediaType)this.mediamap[b][1];
/*     */ 
/*     */         
/* 127 */         if (i == 0) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 133 */     return mediaType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 138 */   private int inch(double paramDouble) { return (int)(paramDouble * 25.4D); }
/*     */   
/*     */   Object[][] mediamap = { 
/* 141 */       { new Dimension(1682, 2378), PageAttributes.MediaType.ISO_4A0 }, { new Dimension(1189, 1682), PageAttributes.MediaType.ISO_2A0 }, { new Dimension(841, 1189), PageAttributes.MediaType.ISO_A0 }, { new Dimension(594, 841), PageAttributes.MediaType.ISO_A1 }, { new Dimension(420, 594), PageAttributes.MediaType.ISO_A2 }, { new Dimension(297, 420), PageAttributes.MediaType.ISO_A3 }, { new Dimension(210, 297), PageAttributes.MediaType.ISO_A4 }, { new Dimension(148, 210), PageAttributes.MediaType.ISO_A5 }, { new Dimension(105, 148), PageAttributes.MediaType.ISO_A6 }, { new Dimension(74, 105), PageAttributes.MediaType.ISO_A7 }, { new Dimension(52, 74), PageAttributes.MediaType.ISO_A8 }, { new Dimension(37, 52), PageAttributes.MediaType.ISO_A9 }, { new Dimension(26, 37), PageAttributes.MediaType.ISO_A10 }, { new Dimension(1000, 1414), PageAttributes.MediaType.ISO_B0 }, { new Dimension(707, 1000), PageAttributes.MediaType.ISO_B1 }, { new Dimension(500, 707), PageAttributes.MediaType.ISO_B2 }, { new Dimension(353, 500), PageAttributes.MediaType.ISO_B3 }, { new Dimension(250, 353), PageAttributes.MediaType.ISO_B4 }, { new Dimension(176, 250), PageAttributes.MediaType.ISO_B5 }, { new Dimension(125, 176), PageAttributes.MediaType.ISO_B6 }, { new Dimension(88, 125), PageAttributes.MediaType.ISO_B7 }, { new Dimension(62, 88), PageAttributes.MediaType.ISO_B8 }, { new Dimension(44, 62), PageAttributes.MediaType.ISO_B9 }, { new Dimension(31, 44), PageAttributes.MediaType.ISO_B10 }, { new Dimension(1030, 1456), PageAttributes.MediaType.JIS_B0 }, { new Dimension(728, 1030), PageAttributes.MediaType.JIS_B1 }, { new Dimension(515, 728), PageAttributes.MediaType.JIS_B2 }, { new Dimension(364, 515), PageAttributes.MediaType.JIS_B3 }, { new Dimension(257, 364), PageAttributes.MediaType.JIS_B4 }, { new Dimension(182, 257), PageAttributes.MediaType.JIS_B5 }, { new Dimension(128, 182), PageAttributes.MediaType.JIS_B6 }, { new Dimension(91, 128), PageAttributes.MediaType.JIS_B7 }, { new Dimension(64, 91), PageAttributes.MediaType.JIS_B8 }, { new Dimension(45, 64), PageAttributes.MediaType.JIS_B9 }, { new Dimension(32, 45), PageAttributes.MediaType.JIS_B10 }, { new Dimension(917, 1297), PageAttributes.MediaType.ISO_C0 }, { new Dimension(648, 917), PageAttributes.MediaType.ISO_C1 }, { new Dimension(458, 648), PageAttributes.MediaType.ISO_C2 }, { new Dimension(324, 458), PageAttributes.MediaType.ISO_C3 }, { new Dimension(229, 324), PageAttributes.MediaType.ISO_C4 }, { new Dimension(162, 229), PageAttributes.MediaType.ISO_C5 }, { new Dimension(114, 162), PageAttributes.MediaType.ISO_C6 }, { new Dimension(81, 114), PageAttributes.MediaType.ISO_C7 }, { new Dimension(57, 81), PageAttributes.MediaType.ISO_C8 }, { new Dimension(40, 57), PageAttributes.MediaType.ISO_C9 }, { new Dimension(28, 40), PageAttributes.MediaType.ISO_C10 }, { new Dimension(inch(7.25D), inch(10.5D)), PageAttributes.MediaType.EXECUTIVE }, { new Dimension(inch(8.5D), inch(13.0D)), PageAttributes.MediaType.FOLIO }, { new Dimension(inch(5.5D), inch(8.5D)), PageAttributes.MediaType.INVOICE }, { new Dimension(inch(11.0D), inch(17.0D)), PageAttributes.MediaType.LEDGER }, { new Dimension(inch(8.5D), inch(11.0D)), PageAttributes.MediaType.LETTER }, { new Dimension(inch(8.5D), inch(14.0D)), PageAttributes.MediaType.LEGAL }, { new Dimension(215, 275), PageAttributes.MediaType.QUARTO }, { new Dimension(inch(8.5D), inch(11.0D)), PageAttributes.MediaType.A }, { new Dimension(inch(11.0D), inch(17.0D)), PageAttributes.MediaType.B }, { new Dimension(inch(17.0D), inch(22.0D)), PageAttributes.MediaType.C }, { new Dimension(inch(22.0D), inch(34.0D)), PageAttributes.MediaType.D }, { new Dimension(inch(34.0D), inch(44.0D)), PageAttributes.MediaType.E }, { new Dimension(inch(10.0D), inch(15.0D)), PageAttributes.MediaType.NA_10X15_ENVELOPE }, { new Dimension(inch(10.0D), inch(14.0D)), PageAttributes.MediaType.NA_10X14_ENVELOPE }, { new Dimension(inch(10.0D), inch(13.0D)), PageAttributes.MediaType.NA_10X13_ENVELOPE }, { new Dimension(inch(9.0D), inch(12.0D)), PageAttributes.MediaType.NA_9X12_ENVELOPE }, { new Dimension(inch(9.0D), inch(11.0D)), PageAttributes.MediaType.NA_9X11_ENVELOPE }, { new Dimension(inch(7.0D), inch(9.0D)), PageAttributes.MediaType.NA_7X9_ENVELOPE }, { new Dimension(inch(6.0D), inch(9.0D)), PageAttributes.MediaType.NA_6X9_ENVELOPE }, { new Dimension(inch(3.875D), inch(8.875D)), PageAttributes.MediaType.NA_NUMBER_9_ENVELOPE }, { new Dimension(inch(4.125D), inch(9.5D)), PageAttributes.MediaType.NA_NUMBER_10_ENVELOPE }, { new Dimension(inch(4.5D), inch(10.375D)), PageAttributes.MediaType.NA_NUMBER_11_ENVELOPE }, { new Dimension(inch(4.75D), inch(11.0D)), PageAttributes.MediaType.NA_NUMBER_12_ENVELOPE }, { new Dimension(inch(5.0D), inch(11.5D)), PageAttributes.MediaType.NA_NUMBER_14_ENVELOPE }, { new Dimension(220, 220), PageAttributes.MediaType.INVITE_ENVELOPE }, { new Dimension(110, 230), PageAttributes.MediaType.ITALY_ENVELOPE }, { new Dimension(inch(3.875D), inch(7.5D)), PageAttributes.MediaType.MONARCH_ENVELOPE }, { new Dimension(inch(3.625D), inch(6.5D)), PageAttributes.MediaType.PERSONAL_ENVELOPE } };
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\Gop1_3.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */