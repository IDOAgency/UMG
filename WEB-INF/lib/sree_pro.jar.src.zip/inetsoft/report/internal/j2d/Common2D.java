/*     */ package inetsoft.report.internal.j2d;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Common2D
/*     */ {
/*     */   public static JButton createToolButton(Object paramObject, String paramString) {
/*  34 */     JButton jButton = new JButton(new ImageIcon(Common.getImage(paramObject, paramString)));
/*  35 */     jButton.setAlignmentY(0.5F);
/*  36 */     jButton.setPreferredSize(new Dimension(25, 25));
/*  37 */     jButton.setMinimumSize(new Dimension(25, 25));
/*  38 */     jButton.setMaximumSize(new Dimension(25, 25));
/*  39 */     jButton.setBorderPainted(false);
/*  40 */     jButton.setRequestFocusEnabled(false);
/*  41 */     jButton.setMargin(new Insets(1, 1, 1, 1));
/*  42 */     jButton.addMouseListener(armListener);
/*     */     
/*  44 */     return jButton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JToggleButton createToolButton(Object paramObject, String paramString, boolean paramBoolean) {
/*  54 */     JToggleButton jToggleButton = new JToggleButton(new ImageIcon(Common.getImage(paramObject, paramString)));
/*     */     
/*  56 */     jToggleButton.setAlignmentY(0.5F);
/*  57 */     jToggleButton.setPreferredSize(new Dimension(25, 25));
/*  58 */     jToggleButton.setMinimumSize(new Dimension(25, 25));
/*  59 */     jToggleButton.setMaximumSize(new Dimension(25, 25));
/*  60 */     jToggleButton.setSelected(paramBoolean);
/*  61 */     jToggleButton.setBorderPainted(paramBoolean);
/*  62 */     jToggleButton.setRequestFocusEnabled(false);
/*  63 */     jToggleButton.setMargin(new Insets(1, 1, 1, 1));
/*  64 */     jToggleButton.addMouseListener(armListener);
/*  65 */     jToggleButton.addItemListener(itemListener);
/*     */     
/*  67 */     return jToggleButton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setLookAndFeel() {
/*     */     
/*  75 */     try { UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
/*     */        }
/*     */     
/*  78 */     catch (Exception exception) { try {
/*  79 */         UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
/*     */       } catch (Exception exception1) {
/*     */         
/*  82 */         exception1.printStackTrace();
/*     */       }  }
/*     */   
/*     */   }
/*     */   
/*     */   public static void setLookAndFeel(String paramString) {
/*  88 */     UIManager.LookAndFeelInfo[] arrayOfLookAndFeelInfo = UIManager.getInstalledLookAndFeels();
/*     */     
/*  90 */     for (byte b = 0; b < arrayOfLookAndFeelInfo.length; b++) {
/*  91 */       if (arrayOfLookAndFeelInfo[b].getName().equals(paramString)) {
/*     */         try {
/*  93 */           UIManager.setLookAndFeel(arrayOfLookAndFeelInfo[b].getClassName());
/*     */         } catch (Exception exception) {
/*  95 */           JOptionPane.showMessageDialog(null, exception.toString(), "Error", 0);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 102 */   public static MouseListener armListener = new MouseAdapter()
/*     */     {
/* 104 */       public void mouseEntered(MouseEvent param1MouseEvent) { ((AbstractButton)param1MouseEvent.getSource()).setBorderPainted(true); }
/*     */ 
/*     */       
/*     */       public void mouseExited(MouseEvent param1MouseEvent) {
/* 108 */         AbstractButton abstractButton = (AbstractButton)param1MouseEvent.getSource();
/* 109 */         abstractButton.setBorderPainted((abstractButton instanceof JToggleButton && abstractButton.isSelected()));
/*     */       }
/*     */     };
/*     */   
/* 113 */   public static ItemListener itemListener = new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent param1ItemEvent) {
/* 115 */         JToggleButton jToggleButton = (JToggleButton)param1ItemEvent.getSource();
/* 116 */         jToggleButton.setBorderPainted(jToggleButton.isSelected());
/*     */       }
/*     */     };
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\Common2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */