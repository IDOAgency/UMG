package inetsoft.report.internal.j2d;

import inetsoft.report.Common;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JToggleButton;
import javax.swing.UIManager;

public class Common2D {
  public static JButton createToolButton(Object paramObject, String paramString) {
    JButton jButton = new JButton(new ImageIcon(Common.getImage(paramObject, paramString)));
    jButton.setAlignmentY(0.5F);
    jButton.setPreferredSize(new Dimension(25, 25));
    jButton.setMinimumSize(new Dimension(25, 25));
    jButton.setMaximumSize(new Dimension(25, 25));
    jButton.setBorderPainted(false);
    jButton.setRequestFocusEnabled(false);
    jButton.setMargin(new Insets(1, 1, 1, 1));
    jButton.addMouseListener(armListener);
    return jButton;
  }
  
  public static JToggleButton createToolButton(Object paramObject, String paramString, boolean paramBoolean) {
    JToggleButton jToggleButton = new JToggleButton(new ImageIcon(Common.getImage(paramObject, paramString)));
    jToggleButton.setAlignmentY(0.5F);
    jToggleButton.setPreferredSize(new Dimension(25, 25));
    jToggleButton.setMinimumSize(new Dimension(25, 25));
    jToggleButton.setMaximumSize(new Dimension(25, 25));
    jToggleButton.setSelected(paramBoolean);
    jToggleButton.setBorderPainted(paramBoolean);
    jToggleButton.setRequestFocusEnabled(false);
    jToggleButton.setMargin(new Insets(1, 1, 1, 1));
    jToggleButton.addMouseListener(armListener);
    jToggleButton.addItemListener(itemListener);
    return jToggleButton;
  }
  
  public static void setLookAndFeel() {
    try {
      UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
    } catch (Exception exception) {
      try {
        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
      } catch (Exception exception1) {
        exception1.printStackTrace();
      } 
    } 
  }
  
  public static void setLookAndFeel(String paramString) {
    UIManager.LookAndFeelInfo[] arrayOfLookAndFeelInfo = UIManager.getInstalledLookAndFeels();
    for (byte b = 0; b < arrayOfLookAndFeelInfo.length; b++) {
      if (arrayOfLookAndFeelInfo[b].getName().equals(paramString))
        try {
          UIManager.setLookAndFeel(arrayOfLookAndFeelInfo[b].getClassName());
        } catch (Exception exception) {
          JOptionPane.showMessageDialog(null, exception.toString(), "Error", 0);
        }  
    } 
  }
  
  public static MouseListener armListener = new MouseAdapter() {
      public void mouseEntered(MouseEvent param1MouseEvent) { ((AbstractButton)param1MouseEvent.getSource()).setBorderPainted(true); }
      
      public void mouseExited(MouseEvent param1MouseEvent) {
        AbstractButton abstractButton = (AbstractButton)param1MouseEvent.getSource();
        abstractButton.setBorderPainted((abstractButton instanceof JToggleButton && abstractButton.isSelected()));
      }
    };
  
  public static ItemListener itemListener = new ItemListener() {
      public void itemStateChanged(ItemEvent param1ItemEvent) {
        JToggleButton jToggleButton = (JToggleButton)param1ItemEvent.getSource();
        jToggleButton.setBorderPainted(jToggleButton.isSelected());
      }
    };
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\Common2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */