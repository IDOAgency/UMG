/*     */ package inetsoft.report.internal.j2d;
/*     */ import inetsoft.report.Margin;
/*     */ import inetsoft.report.internal.CustomGraphics;
/*     */ import inetsoft.report.internal.PixelConsumer;
/*     */ import inetsoft.report.internal.Win32Graphics;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Composite;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.Image;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Polygon;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Shape;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.TexturePaint;
/*     */ import java.awt.font.FontRenderContext;
/*     */ import java.awt.font.GlyphVector;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Arc2D;
/*     */ import java.awt.geom.Ellipse2D;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.geom.RoundRectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.BufferedImageOp;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.awt.image.renderable.RenderableImage;
/*     */ import java.awt.print.PrinterGraphics;
/*     */ import java.awt.print.PrinterJob;
/*     */ import java.text.AttributedCharacterIterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class Win32Graphics2D extends Graphics2D implements Cloneable, CustomGraphics, PrinterGraphics {
/*     */   public static Win32Graphics2D getGraphics(String paramString) {
/*  43 */     if (!Win32Graphics.isInitialized()) {
/*  44 */       return null;
/*     */     }
/*     */     
/*  47 */     Win32Graphics2D win32Graphics2D = new Win32Graphics2D();
/*     */     
/*  49 */     if (paramString == null) {
/*  50 */       if (win32Graphics2D.wing.create2() == 0) {
/*  51 */         return null;
/*     */       
/*     */       }
/*     */     }
/*  55 */     else if (win32Graphics2D.wing.create1(paramString) == 0) {
/*  56 */       return null;
/*     */     } 
/*     */ 
/*     */     
/*  60 */     win32Graphics2D.wing.init();
/*  61 */     return win32Graphics2D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean printDialog(int paramInt) {
/*  69 */     boolean bool = this.wing.printDialog0(paramInt);
/*  70 */     if (bool) {
/*  71 */       this.wing.init();
/*     */     }
/*     */     
/*  74 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public PrinterJob getPrinterJob() { return this.job; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public void setPrinterJob(PrinterJob paramPrinterJob) { this.job = paramPrinterJob; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public void setOrientation(int paramInt) { this.wing.setOrientation(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public int getOrientation() { return this.wing.getOrientation(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public void setDuplex(boolean paramBoolean) { this.wing.setDuplex(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public boolean isDuplex() { return this.wing.isDuplex(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public void setTray(int paramInt) { this.wing.setTray(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public void startDoc(String paramString) { this.wing.setError((this.wing.startDoc0(paramString) < 0)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public void startPage() { this.wing.nextPage(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public boolean isPages() { return this.wing.isPages0(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public int getFromPage() { return this.wing.getFromPage0(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   public int getToPage() { return this.wing.getToPage0(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   public int getCopies() { return this.wing.getCopies0(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCopies(int paramInt) {
/* 182 */     if (this.wing.isError()) {
/*     */       return;
/*     */     }
/*     */     
/* 186 */     this.wing.setCopies0(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 193 */   public void close() { this.wing.close(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 200 */   Win32Graphics wing = new Win32Graphics();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Graphics create() {
/*     */     try {
/* 208 */       Win32Graphics2D win32Graphics2D = (Win32Graphics2D)clone();
/* 209 */       win32Graphics2D.wing = (Win32Graphics)this.wing.create();
/* 210 */       return win32Graphics2D;
/*     */     } catch (Exception exception) {
/* 212 */       exception.printStackTrace();
/*     */ 
/*     */       
/* 215 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Shape paramShape) {
/* 222 */     if (paramShape instanceof Arc2D) {
/* 223 */       Arc2D arc2D = (Arc2D)paramShape;
/* 224 */       this.wing.drawArc(arc2D.getX(), arc2D.getY(), arc2D.getWidth(), arc2D.getHeight(), arc2D.getAngleStart(), arc2D.getAngleExtent());
/*     */     
/*     */     }
/* 227 */     else if (paramShape instanceof Ellipse2D) {
/* 228 */       Ellipse2D ellipse2D = (Ellipse2D)paramShape;
/* 229 */       this.wing.drawOval(ellipse2D.getX(), ellipse2D.getY(), ellipse2D.getWidth(), ellipse2D.getHeight());
/*     */     }
/* 231 */     else if (paramShape instanceof Line2D) {
/* 232 */       Line2D line2D = (Line2D)paramShape;
/* 233 */       this.wing.drawLine(line2D.getX1(), line2D.getY1(), line2D.getX2(), line2D.getY2());
/*     */     }
/* 235 */     else if (paramShape instanceof Rectangle2D) {
/* 236 */       Rectangle2D rectangle2D = (Rectangle2D)paramShape;
/* 237 */       this.wing.drawRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
/*     */     
/*     */     }
/* 240 */     else if (paramShape instanceof RoundRectangle2D) {
/* 241 */       RoundRectangle2D roundRectangle2D = (RoundRectangle2D)paramShape;
/* 242 */       this.wing.drawRoundRect(roundRectangle2D.getX(), roundRectangle2D.getY(), roundRectangle2D.getWidth(), roundRectangle2D.getHeight(), roundRectangle2D.getArcWidth(), roundRectangle2D.getArcHeight());
/*     */ 
/*     */     
/*     */     }
/* 246 */     else if (paramShape instanceof Rectangle) {
/* 247 */       Rectangle rectangle = (Rectangle)paramShape;
/* 248 */       this.wing.drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*     */     }
/* 250 */     else if (paramShape instanceof Polygon) {
/* 251 */       Polygon polygon = (Polygon)paramShape;
/* 252 */       this.wing.drawPolygon(polygon.xpoints, polygon.ypoints, polygon.npoints);
/*     */     } else {
/*     */       
/* 255 */       throw new RuntimeException("Drawing of " + paramShape.getClass().getName() + " not supported by Win32Graphics2D");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 261 */   public void drawRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.wing.drawRect(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean drawImage(Image paramImage, AffineTransform paramAffineTransform, ImageObserver paramImageObserver) {
/* 266 */     AffineTransform affineTransform = getTransform();
/* 267 */     transform(paramAffineTransform);
/* 268 */     drawImage(paramImage, 0, 0, paramImageObserver);
/* 269 */     setTransform(affineTransform);
/* 270 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 277 */   public void drawImage(BufferedImage paramBufferedImage, BufferedImageOp paramBufferedImageOp, int paramInt1, int paramInt2) { throw new RuntimeException("drawImage(BufferedImage, BufferedImageOp, int, int) not supported by Win32Graphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawRenderedImage(RenderedImage paramRenderedImage, AffineTransform paramAffineTransform) {
/* 284 */     AffineTransform affineTransform = getTransform();
/* 285 */     transform(paramAffineTransform);
/* 286 */     drawImage((Image)paramRenderedImage, 0, 0, null);
/* 287 */     setTransform(affineTransform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawRenderableImage(RenderableImage paramRenderableImage, AffineTransform paramAffineTransform) {
/* 295 */     AffineTransform affineTransform = getTransform();
/* 296 */     transform(paramAffineTransform);
/* 297 */     drawImage((Image)paramRenderableImage, 0, 0, null);
/* 298 */     setTransform(affineTransform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 305 */   public void drawString(String paramString, float paramFloat1, float paramFloat2) { this.wing.drawString(paramString, paramFloat1, paramFloat2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 312 */   public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, int paramInt1, int paramInt2) { throw new RuntimeException("drawString(AttributedCharactorIterator, int, int) not supported by Win32Graphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 320 */   public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, float paramFloat1, float paramFloat2) { throw new RuntimeException("drawString(AttributedCharactorIterator, float, float) not supported by Win32Graphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 327 */   public void drawGlyphVector(GlyphVector paramGlyphVector, float paramFloat1, float paramFloat2) { throw new RuntimeException("drawGlyphVector(GlyphVector, float, float) not supported by Win32Graphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fill(Shape paramShape) {
/* 334 */     if (paramShape instanceof Arc2D) {
/* 335 */       Arc2D arc2D = (Arc2D)paramShape;
/* 336 */       this.wing.fillArc(arc2D.getX(), arc2D.getY(), arc2D.getWidth(), arc2D.getHeight(), arc2D.getAngleStart(), arc2D.getAngleExtent());
/*     */     
/*     */     }
/* 339 */     else if (paramShape instanceof Ellipse2D) {
/* 340 */       Ellipse2D ellipse2D = (Ellipse2D)paramShape;
/* 341 */       this.wing.fillOval(ellipse2D.getX(), ellipse2D.getY(), ellipse2D.getWidth(), ellipse2D.getHeight());
/*     */     }
/* 343 */     else if (paramShape instanceof Rectangle2D) {
/* 344 */       Rectangle2D rectangle2D = (Rectangle2D)paramShape;
/* 345 */       this.wing.fillRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
/*     */     
/*     */     }
/* 348 */     else if (paramShape instanceof RoundRectangle2D) {
/* 349 */       RoundRectangle2D roundRectangle2D = (RoundRectangle2D)paramShape;
/* 350 */       this.wing.fillRoundRect(roundRectangle2D.getX(), roundRectangle2D.getY(), roundRectangle2D.getWidth(), roundRectangle2D.getHeight(), roundRectangle2D.getArcWidth(), roundRectangle2D.getArcHeight());
/*     */ 
/*     */     
/*     */     }
/* 354 */     else if (paramShape instanceof Rectangle) {
/* 355 */       Rectangle rectangle = (Rectangle)paramShape;
/* 356 */       this.wing.fillRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*     */     }
/* 358 */     else if (paramShape instanceof Polygon) {
/* 359 */       Polygon polygon = (Polygon)paramShape;
/* 360 */       this.wing.fillPolygon(polygon.xpoints, polygon.ypoints, polygon.npoints);
/*     */     } else {
/*     */       
/* 363 */       throw new RuntimeException("Filling of " + paramShape.getClass().getName() + " not supported by Win32Graphics2D");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 372 */   public boolean hit(Rectangle paramRectangle, Shape paramShape, boolean paramBoolean) { throw new RuntimeException("hit(Rectangle, Shape, boolean) not supported by Win32Graphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 379 */   public GraphicsConfiguration getDeviceConfiguration() { throw new RuntimeException("getDeviceConfiguration() not supported by Win32Graphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 386 */   public void setComposite(Composite paramComposite) { throw new RuntimeException("setComposite() not supported by Win32Graphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPaint(Paint paramPaint) {
/* 393 */     if (this.wing.isError()) {
/*     */       return;
/*     */     }
/*     */     
/* 397 */     this.brush = paramPaint;
/*     */     
/* 399 */     if (this.brush instanceof TexturePaint) {
/* 400 */       BufferedImage bufferedImage = ((TexturePaint)this.brush).getImage();
/* 401 */       byte[] arrayOfByte = this.wing.getImageBytes(new PixelConsumer(bufferedImage), Color.white);
/*     */       
/* 403 */       this.wing.setBrush0(arrayOfByte, bufferedImage.getWidth(null), bufferedImage.getHeight(null), this.wing.isDither());
/*     */     
/*     */     }
/* 406 */     else if (this.brush instanceof Color) {
/* 407 */       setColor((Color)this.brush);
/*     */     } else {
/*     */       
/* 410 */       throw new RuntimeException("Only TexturePaint is supported by Win32Graphics2D");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStroke(Stroke paramStroke) {
/* 418 */     if (this.wing.isError()) {
/*     */       return;
/*     */     }
/*     */     
/* 422 */     this.stroke = paramStroke;
/*     */     
/* 424 */     if (this.stroke instanceof BasicStroke) {
/* 425 */       BasicStroke basicStroke = (BasicStroke)this.stroke;
/* 426 */       float[] arrayOfFloat = basicStroke.getDashArray();
/* 427 */       int i = (arrayOfFloat != null && arrayOfFloat.length > 0) ? (int)arrayOfFloat[0] : 0;
/*     */       
/* 429 */       this.wing.setPen0(Win32Graphics.getRGB(getColor()), this.wing.realW(basicStroke.getLineWidth()), basicStroke.getEndCap(), basicStroke.getLineJoin(), i);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 435 */       throw new RuntimeException("Only BasicStroke is supported by Win32Graphics2D");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRenderingHint(RenderingHints.Key paramKey, Object paramObject) {}
/*     */ 
/*     */   
/* 443 */   public Object getRenderingHint(RenderingHints.Key paramKey) { return null; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderingHints(Map paramMap) {}
/*     */ 
/*     */   
/*     */   public void addRenderingHints(Map paramMap) {}
/*     */ 
/*     */   
/* 453 */   public RenderingHints getRenderingHints() { return null; }
/*     */ 
/*     */   
/*     */   public void translate(int paramInt1, int paramInt2) {
/* 457 */     AffineTransform affineTransform = getTransform();
/* 458 */     affineTransform.translate(paramInt1, paramInt2);
/* 459 */     setTransform(affineTransform);
/*     */   }
/*     */   
/*     */   public void translate(double paramDouble1, double paramDouble2) {
/* 463 */     AffineTransform affineTransform = getTransform();
/* 464 */     affineTransform.translate(paramDouble1, paramDouble2);
/* 465 */     setTransform(affineTransform);
/*     */   }
/*     */   
/*     */   public void rotate(double paramDouble) {
/* 469 */     AffineTransform affineTransform = getTransform();
/* 470 */     affineTransform.rotate(paramDouble);
/* 471 */     setTransform(affineTransform);
/*     */   }
/*     */   
/*     */   public void rotate(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 475 */     AffineTransform affineTransform = getTransform();
/* 476 */     affineTransform.rotate(paramDouble1, paramDouble2, paramDouble3);
/* 477 */     setTransform(affineTransform);
/*     */   }
/*     */   
/*     */   public void scale(double paramDouble1, double paramDouble2) {
/* 481 */     AffineTransform affineTransform = getTransform();
/* 482 */     affineTransform.scale(paramDouble1, paramDouble2);
/* 483 */     setTransform(affineTransform);
/*     */   }
/*     */   
/*     */   public void shear(double paramDouble1, double paramDouble2) {
/* 487 */     AffineTransform affineTransform = getTransform();
/* 488 */     affineTransform.shear(paramDouble1, paramDouble2);
/* 489 */     setTransform(affineTransform);
/*     */   }
/*     */   
/*     */   public void transform(AffineTransform paramAffineTransform) {
/* 493 */     AffineTransform affineTransform = getTransform();
/* 494 */     affineTransform.concatenate(paramAffineTransform);
/* 495 */     setTransform(affineTransform);
/*     */   }
/*     */   
/*     */   public void setTransform(AffineTransform paramAffineTransform) {
/* 499 */     if (this.wing.isError()) {
/*     */       return;
/*     */     }
/*     */     
/* 503 */     this.trans = paramAffineTransform;
/* 504 */     double[] arrayOfDouble = new double[6];
/* 505 */     paramAffineTransform.getMatrix(arrayOfDouble);
/*     */ 
/*     */     
/* 508 */     this.wing.setTransform0(arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2], arrayOfDouble[3], this.wing.realW(arrayOfDouble[4]), this.wing.realH(arrayOfDouble[5]));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 513 */   public AffineTransform getTransform() { return new AffineTransform(this.trans); }
/*     */ 
/*     */ 
/*     */   
/* 517 */   public Paint getPaint() { return this.brush; }
/*     */ 
/*     */ 
/*     */   
/* 521 */   public Composite getComposite() { return null; }
/*     */ 
/*     */   
/*     */   public void setColor(Color paramColor) {
/* 525 */     if (this.wing.isError()) {
/*     */       return;
/*     */     }
/*     */     
/* 529 */     this.fg = paramColor;
/* 530 */     this.brush = paramColor;
/*     */     
/* 532 */     this.wing.setColor1(Win32Graphics.getRGB(this.fg));
/* 533 */     setStroke(getStroke());
/*     */   }
/*     */ 
/*     */   
/* 537 */   public Color getColor() { return this.fg; }
/*     */ 
/*     */ 
/*     */   
/* 541 */   public void setBackground(Color paramColor) { this.bg = paramColor; }
/*     */ 
/*     */ 
/*     */   
/* 545 */   public Color getBackground() { return this.bg; }
/*     */ 
/*     */ 
/*     */   
/* 549 */   public Stroke getStroke() { return this.stroke; }
/*     */ 
/*     */ 
/*     */   
/* 553 */   public boolean isSupported(int paramInt) { return (paramInt != 1); }
/*     */ 
/*     */   
/*     */   public void setClip(Shape paramShape) {
/* 557 */     if (paramShape instanceof Rectangle2D) {
/* 558 */       Rectangle2D rectangle2D = (Rectangle2D)paramShape;
/* 559 */       setClip(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
/*     */     }
/* 561 */     else if (paramShape instanceof Rectangle) {
/* 562 */       Rectangle rectangle = (Rectangle)paramShape;
/* 563 */       setClip(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*     */     } else {
/*     */       
/* 566 */       throw new RuntimeException("Clipping of " + paramShape.getClass().getName() + " not supported by Win32Graphics2D");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clip(Shape paramShape) {
/* 572 */     if (paramShape instanceof Rectangle2D) {
/* 573 */       Rectangle2D rectangle2D = (Rectangle2D)paramShape;
/* 574 */       clipRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
/*     */     }
/* 576 */     else if (paramShape instanceof Rectangle) {
/* 577 */       Rectangle rectangle = (Rectangle)paramShape;
/* 578 */       clipRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*     */     } else {
/*     */       
/* 581 */       throw new RuntimeException("Clipping of " + paramShape.getClass().getName() + " not supported by Win32Graphics2D");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 587 */   public FontRenderContext getFontRenderContext() { return this.fontContext; }
/*     */ 
/*     */ 
/*     */   
/* 591 */   public void clipRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { clipRect(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */   
/* 595 */   public void clipRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) { this.wing.clipRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4); }
/*     */ 
/*     */ 
/*     */   
/* 599 */   public void setClip(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { setClip(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */   
/*     */   public void setClip(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 603 */     if (this.wing.isError()) {
/*     */       return;
/*     */     }
/*     */     
/* 607 */     Rectangle2D.Double double = new Rectangle2D.Double(this.wing.realX(paramDouble1), this.wing.realY(paramDouble2), this.wing.realW(paramDouble3), this.wing.realH(paramDouble4));
/*     */ 
/*     */     
/* 610 */     transformRect(double, new AffineTransform(this.wing.getTransform0()), false);
/*     */     
/* 612 */     Margin margin = StyleSheet.getPrinterMargin();
/* 613 */     double.x += (this.wing.realX(margin.left * 72.0D) - (this.wing.getMargin()).x);
/* 614 */     double.y += (this.wing.realY(margin.top * 72.0D) - (this.wing.getMargin()).y);
/* 615 */     this.wing.setClip0((int)double.x, (int)double.y, (int)(double.x + double.width), (int)(double.y + double.height));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 623 */   public void setPaintMode() { this.wing.setPaintMode(); }
/*     */ 
/*     */ 
/*     */   
/* 627 */   public void setXORMode(Color paramColor) { this.wing.setXORMode(paramColor); }
/*     */ 
/*     */ 
/*     */   
/* 631 */   public Font getFont() { return this.wing.getFont(); }
/*     */ 
/*     */ 
/*     */   
/* 635 */   public void setFont(Font paramFont) { this.wing.setFont(paramFont); }
/*     */ 
/*     */ 
/*     */   
/* 639 */   public FontMetrics getFontMetrics(Font paramFont) { return this.wing.getFontMetrics(paramFont); }
/*     */ 
/*     */ 
/*     */   
/* 643 */   public Rectangle getClipBounds() { return this.wing.getClipBounds(); }
/*     */ 
/*     */ 
/*     */   
/* 647 */   public Shape getClip() { return this.wing.getClip(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 652 */   public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.wing.copyArea(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*     */ 
/*     */ 
/*     */   
/* 656 */   public void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.wing.drawLine(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */   
/* 660 */   public void fillRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.wing.fillRect(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */   
/* 664 */   public void clearRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.wing.clearRect(paramInt1, paramInt2, paramInt3, paramInt4, this.bg); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 669 */   public void drawRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.wing.drawRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 674 */   public void fillRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.wing.fillRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*     */ 
/*     */ 
/*     */   
/* 678 */   public void drawOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.wing.drawOval(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */   
/* 682 */   public void fillOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.wing.fillOval(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 687 */   public void drawArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.wing.drawArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 692 */   public void fillArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.wing.fillArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 697 */   public void drawPolyline(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.wing.drawPolyline(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
/*     */ 
/*     */ 
/*     */   
/* 701 */   public void drawPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.wing.drawPolygon(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
/*     */ 
/*     */ 
/*     */   
/* 705 */   public void fillPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.wing.fillPolygon(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
/*     */ 
/*     */ 
/*     */   
/* 709 */   public void drawString(String paramString, int paramInt1, int paramInt2) { this.wing.drawString(paramString, paramInt1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 714 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, 0, 0, paramImageObserver, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 719 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 724 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, Color paramColor, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, 0, 0, paramImageObserver, paramColor); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 729 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 735 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3 - paramInt1 + 1, paramInt4 - paramInt2 + 1, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 742 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, Color paramColor, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3 - paramInt1 + 1, paramInt4 - paramInt2 + 1, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver, paramColor); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean doImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
/* 749 */     PixelConsumer pixelConsumer = new PixelConsumer(paramImage);
/*     */     
/* 751 */     return doImage(pixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean doImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver, Color paramColor) {
/* 758 */     PixelConsumer pixelConsumer = new PixelConsumer(paramImage, paramInt5, paramInt6, paramInt7, paramInt8);
/*     */     
/* 760 */     return doImage(pixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean doImage(PixelConsumer paramPixelConsumer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
/* 768 */     if (this.wing.isError()) {
/* 769 */       return true;
/*     */     }
/*     */     
/* 772 */     byte[] arrayOfByte = this.wing.getImageBytes(paramPixelConsumer, paramColor);
/*     */     
/* 774 */     if (paramInt3 == 0) {
/* 775 */       paramInt3 = paramPixelConsumer.iwidth;
/*     */     }
/*     */     
/* 778 */     if (paramInt4 == 0) {
/* 779 */       paramInt4 = paramPixelConsumer.iheight;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 797 */     this; this.wing.drawImage0(arrayOfByte, paramPixelConsumer.width, paramPixelConsumer.height, this.wing.realX(paramInt1), this.wing.realY(paramInt2), this.wing.realW(paramInt3), this.wing.realH(paramInt4), (paramColor == null) ? 16777215 : (Win32Graphics.getRGB(paramColor) & 0xFFFFFF), this.wing.isDither());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 802 */     return true;
/*     */   }
/*     */ 
/*     */   
/* 806 */   public void dispose() { this.wing.dispose(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void transformRect(Rectangle2D.Double paramDouble, AffineTransform paramAffineTransform, boolean paramBoolean) {
/* 812 */     Point2D point2D1 = new Point2D.Double(paramDouble.getX(), paramDouble.getY());
/* 813 */     Point2D point2D2 = new Point2D.Double(paramDouble.getX() + paramDouble.getWidth(), paramDouble.getY() + paramDouble.getHeight());
/*     */ 
/*     */     
/* 816 */     if (paramBoolean) {
/*     */       try {
/* 818 */         point2D1 = paramAffineTransform.inverseTransform(point2D1, null);
/* 819 */         point2D2 = paramAffineTransform.inverseTransform(point2D2, null);
/*     */       } catch (Exception exception) {
/* 821 */         exception.printStackTrace();
/*     */       } 
/*     */     } else {
/*     */       
/* 825 */       point2D1 = paramAffineTransform.transform(point2D1, null);
/* 826 */       point2D2 = paramAffineTransform.transform(point2D2, null);
/*     */     } 
/*     */     
/* 829 */     paramDouble.x = point2D1.getX();
/* 830 */     paramDouble.y = point2D1.getY();
/* 831 */     paramDouble.width = point2D2.getX() - point2D1.getX();
/* 832 */     paramDouble.height = point2D2.getY() - point2D1.getY();
/*     */   }
/*     */ 
/*     */   
/* 836 */   AffineTransform trans = new AffineTransform();
/* 837 */   FontRenderContext fontContext = new FontRenderContext(new AffineTransform(), true, true);
/*     */   
/* 839 */   Stroke stroke = new BasicStroke();
/* 840 */   Paint brush = Color.black;
/* 841 */   Color bg = Color.white;
/* 842 */   Color fg = Color.black;
/*     */   PrinterJob job;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\Win32Graphics2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */