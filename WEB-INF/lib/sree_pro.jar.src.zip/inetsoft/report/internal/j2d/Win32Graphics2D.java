package inetsoft.report.internal.j2d;

import inetsoft.report.Margin;
import inetsoft.report.StyleSheet;
import inetsoft.report.internal.CustomGraphics;
import inetsoft.report.internal.PixelConsumer;
import inetsoft.report.internal.Win32Graphics;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.TexturePaint;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ImageObserver;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderableImage;
import java.awt.print.PrinterGraphics;
import java.awt.print.PrinterJob;
import java.text.AttributedCharacterIterator;
import java.util.Map;

public class Win32Graphics2D extends Graphics2D implements Cloneable, CustomGraphics, PrinterGraphics {
  public static Win32Graphics2D getGraphics(String paramString) {
    if (!Win32Graphics.isInitialized())
      return null; 
    Win32Graphics2D win32Graphics2D = new Win32Graphics2D();
    if (paramString == null) {
      if (win32Graphics2D.wing.create2() == 0)
        return null; 
    } else if (win32Graphics2D.wing.create1(paramString) == 0) {
      return null;
    } 
    win32Graphics2D.wing.init();
    return win32Graphics2D;
  }
  
  public boolean printDialog(int paramInt) {
    boolean bool = this.wing.printDialog0(paramInt);
    if (bool)
      this.wing.init(); 
    return bool;
  }
  
  public PrinterJob getPrinterJob() { return this.job; }
  
  public void setPrinterJob(PrinterJob paramPrinterJob) { this.job = paramPrinterJob; }
  
  public void setOrientation(int paramInt) { this.wing.setOrientation(paramInt); }
  
  public int getOrientation() { return this.wing.getOrientation(); }
  
  public void setDuplex(boolean paramBoolean) { this.wing.setDuplex(paramBoolean); }
  
  public boolean isDuplex() { return this.wing.isDuplex(); }
  
  public void setTray(int paramInt) { this.wing.setTray(paramInt); }
  
  public void startDoc(String paramString) { this.wing.setError((this.wing.startDoc0(paramString) < 0)); }
  
  public void startPage() { this.wing.nextPage(); }
  
  public boolean isPages() { return this.wing.isPages0(); }
  
  public int getFromPage() { return this.wing.getFromPage0(); }
  
  public int getToPage() { return this.wing.getToPage0(); }
  
  public int getCopies() { return this.wing.getCopies0(); }
  
  public void setCopies(int paramInt) {
    if (this.wing.isError())
      return; 
    this.wing.setCopies0(paramInt);
  }
  
  public void close() { this.wing.close(); }
  
  Win32Graphics wing = new Win32Graphics();
  
  public Graphics create() {
    try {
      Win32Graphics2D win32Graphics2D = (Win32Graphics2D)clone();
      win32Graphics2D.wing = (Win32Graphics)this.wing.create();
      return win32Graphics2D;
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public void draw(Shape paramShape) {
    if (paramShape instanceof Arc2D) {
      Arc2D arc2D = (Arc2D)paramShape;
      this.wing.drawArc(arc2D.getX(), arc2D.getY(), arc2D.getWidth(), arc2D.getHeight(), arc2D.getAngleStart(), arc2D.getAngleExtent());
    } else if (paramShape instanceof Ellipse2D) {
      Ellipse2D ellipse2D = (Ellipse2D)paramShape;
      this.wing.drawOval(ellipse2D.getX(), ellipse2D.getY(), ellipse2D.getWidth(), ellipse2D.getHeight());
    } else if (paramShape instanceof Line2D) {
      Line2D line2D = (Line2D)paramShape;
      this.wing.drawLine(line2D.getX1(), line2D.getY1(), line2D.getX2(), line2D.getY2());
    } else if (paramShape instanceof Rectangle2D) {
      Rectangle2D rectangle2D = (Rectangle2D)paramShape;
      this.wing.drawRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    } else if (paramShape instanceof RoundRectangle2D) {
      RoundRectangle2D roundRectangle2D = (RoundRectangle2D)paramShape;
      this.wing.drawRoundRect(roundRectangle2D.getX(), roundRectangle2D.getY(), roundRectangle2D.getWidth(), roundRectangle2D.getHeight(), roundRectangle2D.getArcWidth(), roundRectangle2D.getArcHeight());
    } else if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      this.wing.drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } else if (paramShape instanceof Polygon) {
      Polygon polygon = (Polygon)paramShape;
      this.wing.drawPolygon(polygon.xpoints, polygon.ypoints, polygon.npoints);
    } else {
      throw new RuntimeException("Drawing of " + paramShape.getClass().getName() + " not supported by Win32Graphics2D");
    } 
  }
  
  public void drawRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.wing.drawRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public boolean drawImage(Image paramImage, AffineTransform paramAffineTransform, ImageObserver paramImageObserver) {
    AffineTransform affineTransform = getTransform();
    transform(paramAffineTransform);
    drawImage(paramImage, 0, 0, paramImageObserver);
    setTransform(affineTransform);
    return true;
  }
  
  public void drawImage(BufferedImage paramBufferedImage, BufferedImageOp paramBufferedImageOp, int paramInt1, int paramInt2) { throw new RuntimeException("drawImage(BufferedImage, BufferedImageOp, int, int) not supported by Win32Graphics2D"); }
  
  public void drawRenderedImage(RenderedImage paramRenderedImage, AffineTransform paramAffineTransform) {
    AffineTransform affineTransform = getTransform();
    transform(paramAffineTransform);
    drawImage((Image)paramRenderedImage, 0, 0, null);
    setTransform(affineTransform);
  }
  
  public void drawRenderableImage(RenderableImage paramRenderableImage, AffineTransform paramAffineTransform) {
    AffineTransform affineTransform = getTransform();
    transform(paramAffineTransform);
    drawImage((Image)paramRenderableImage, 0, 0, null);
    setTransform(affineTransform);
  }
  
  public void drawString(String paramString, float paramFloat1, float paramFloat2) { this.wing.drawString(paramString, paramFloat1, paramFloat2); }
  
  public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, int paramInt1, int paramInt2) { throw new RuntimeException("drawString(AttributedCharactorIterator, int, int) not supported by Win32Graphics2D"); }
  
  public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, float paramFloat1, float paramFloat2) { throw new RuntimeException("drawString(AttributedCharactorIterator, float, float) not supported by Win32Graphics2D"); }
  
  public void drawGlyphVector(GlyphVector paramGlyphVector, float paramFloat1, float paramFloat2) { throw new RuntimeException("drawGlyphVector(GlyphVector, float, float) not supported by Win32Graphics2D"); }
  
  public void fill(Shape paramShape) {
    if (paramShape instanceof Arc2D) {
      Arc2D arc2D = (Arc2D)paramShape;
      this.wing.fillArc(arc2D.getX(), arc2D.getY(), arc2D.getWidth(), arc2D.getHeight(), arc2D.getAngleStart(), arc2D.getAngleExtent());
    } else if (paramShape instanceof Ellipse2D) {
      Ellipse2D ellipse2D = (Ellipse2D)paramShape;
      this.wing.fillOval(ellipse2D.getX(), ellipse2D.getY(), ellipse2D.getWidth(), ellipse2D.getHeight());
    } else if (paramShape instanceof Rectangle2D) {
      Rectangle2D rectangle2D = (Rectangle2D)paramShape;
      this.wing.fillRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    } else if (paramShape instanceof RoundRectangle2D) {
      RoundRectangle2D roundRectangle2D = (RoundRectangle2D)paramShape;
      this.wing.fillRoundRect(roundRectangle2D.getX(), roundRectangle2D.getY(), roundRectangle2D.getWidth(), roundRectangle2D.getHeight(), roundRectangle2D.getArcWidth(), roundRectangle2D.getArcHeight());
    } else if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      this.wing.fillRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } else if (paramShape instanceof Polygon) {
      Polygon polygon = (Polygon)paramShape;
      this.wing.fillPolygon(polygon.xpoints, polygon.ypoints, polygon.npoints);
    } else {
      throw new RuntimeException("Filling of " + paramShape.getClass().getName() + " not supported by Win32Graphics2D");
    } 
  }
  
  public boolean hit(Rectangle paramRectangle, Shape paramShape, boolean paramBoolean) { throw new RuntimeException("hit(Rectangle, Shape, boolean) not supported by Win32Graphics2D"); }
  
  public GraphicsConfiguration getDeviceConfiguration() { throw new RuntimeException("getDeviceConfiguration() not supported by Win32Graphics2D"); }
  
  public void setComposite(Composite paramComposite) { throw new RuntimeException("setComposite() not supported by Win32Graphics2D"); }
  
  public void setPaint(Paint paramPaint) {
    if (this.wing.isError())
      return; 
    this.brush = paramPaint;
    if (this.brush instanceof TexturePaint) {
      BufferedImage bufferedImage = ((TexturePaint)this.brush).getImage();
      byte[] arrayOfByte = this.wing.getImageBytes(new PixelConsumer(bufferedImage), Color.white);
      this.wing.setBrush0(arrayOfByte, bufferedImage.getWidth(null), bufferedImage.getHeight(null), this.wing.isDither());
    } else if (this.brush instanceof Color) {
      setColor((Color)this.brush);
    } else {
      throw new RuntimeException("Only TexturePaint is supported by Win32Graphics2D");
    } 
  }
  
  public void setStroke(Stroke paramStroke) {
    if (this.wing.isError())
      return; 
    this.stroke = paramStroke;
    if (this.stroke instanceof BasicStroke) {
      BasicStroke basicStroke = (BasicStroke)this.stroke;
      float[] arrayOfFloat = basicStroke.getDashArray();
      int i = (arrayOfFloat != null && arrayOfFloat.length > 0) ? (int)arrayOfFloat[0] : 0;
      this.wing.setPen0(Win32Graphics.getRGB(getColor()), this.wing.realW(basicStroke.getLineWidth()), basicStroke.getEndCap(), basicStroke.getLineJoin(), i);
    } else {
      throw new RuntimeException("Only BasicStroke is supported by Win32Graphics2D");
    } 
  }
  
  public void setRenderingHint(RenderingHints.Key paramKey, Object paramObject) {}
  
  public Object getRenderingHint(RenderingHints.Key paramKey) { return null; }
  
  public void setRenderingHints(Map paramMap) {}
  
  public void addRenderingHints(Map paramMap) {}
  
  public RenderingHints getRenderingHints() { return null; }
  
  public void translate(int paramInt1, int paramInt2) {
    AffineTransform affineTransform = getTransform();
    affineTransform.translate(paramInt1, paramInt2);
    setTransform(affineTransform);
  }
  
  public void translate(double paramDouble1, double paramDouble2) {
    AffineTransform affineTransform = getTransform();
    affineTransform.translate(paramDouble1, paramDouble2);
    setTransform(affineTransform);
  }
  
  public void rotate(double paramDouble) {
    AffineTransform affineTransform = getTransform();
    affineTransform.rotate(paramDouble);
    setTransform(affineTransform);
  }
  
  public void rotate(double paramDouble1, double paramDouble2, double paramDouble3) {
    AffineTransform affineTransform = getTransform();
    affineTransform.rotate(paramDouble1, paramDouble2, paramDouble3);
    setTransform(affineTransform);
  }
  
  public void scale(double paramDouble1, double paramDouble2) {
    AffineTransform affineTransform = getTransform();
    affineTransform.scale(paramDouble1, paramDouble2);
    setTransform(affineTransform);
  }
  
  public void shear(double paramDouble1, double paramDouble2) {
    AffineTransform affineTransform = getTransform();
    affineTransform.shear(paramDouble1, paramDouble2);
    setTransform(affineTransform);
  }
  
  public void transform(AffineTransform paramAffineTransform) {
    AffineTransform affineTransform = getTransform();
    affineTransform.concatenate(paramAffineTransform);
    setTransform(affineTransform);
  }
  
  public void setTransform(AffineTransform paramAffineTransform) {
    if (this.wing.isError())
      return; 
    this.trans = paramAffineTransform;
    double[] arrayOfDouble = new double[6];
    paramAffineTransform.getMatrix(arrayOfDouble);
    this.wing.setTransform0(arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2], arrayOfDouble[3], this.wing.realW(arrayOfDouble[4]), this.wing.realH(arrayOfDouble[5]));
  }
  
  public AffineTransform getTransform() { return new AffineTransform(this.trans); }
  
  public Paint getPaint() { return this.brush; }
  
  public Composite getComposite() { return null; }
  
  public void setColor(Color paramColor) {
    if (this.wing.isError())
      return; 
    this.fg = paramColor;
    this.brush = paramColor;
    this.wing.setColor1(Win32Graphics.getRGB(this.fg));
    setStroke(getStroke());
  }
  
  public Color getColor() { return this.fg; }
  
  public void setBackground(Color paramColor) { this.bg = paramColor; }
  
  public Color getBackground() { return this.bg; }
  
  public Stroke getStroke() { return this.stroke; }
  
  public boolean isSupported(int paramInt) { return (paramInt != 1); }
  
  public void setClip(Shape paramShape) {
    if (paramShape instanceof Rectangle2D) {
      Rectangle2D rectangle2D = (Rectangle2D)paramShape;
      setClip(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    } else if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      setClip(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } else {
      throw new RuntimeException("Clipping of " + paramShape.getClass().getName() + " not supported by Win32Graphics2D");
    } 
  }
  
  public void clip(Shape paramShape) {
    if (paramShape instanceof Rectangle2D) {
      Rectangle2D rectangle2D = (Rectangle2D)paramShape;
      clipRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    } else if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      clipRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } else {
      throw new RuntimeException("Clipping of " + paramShape.getClass().getName() + " not supported by Win32Graphics2D");
    } 
  }
  
  public FontRenderContext getFontRenderContext() { return this.fontContext; }
  
  public void clipRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { clipRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void clipRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) { this.wing.clipRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4); }
  
  public void setClip(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { setClip(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void setClip(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    if (this.wing.isError())
      return; 
    Rectangle2D.Double double = new Rectangle2D.Double(this.wing.realX(paramDouble1), this.wing.realY(paramDouble2), this.wing.realW(paramDouble3), this.wing.realH(paramDouble4));
    transformRect(double, new AffineTransform(this.wing.getTransform0()), false);
    Margin margin = StyleSheet.getPrinterMargin();
    double.x += (this.wing.realX(margin.left * 72.0D) - (this.wing.getMargin()).x);
    double.y += (this.wing.realY(margin.top * 72.0D) - (this.wing.getMargin()).y);
    this.wing.setClip0((int)double.x, (int)double.y, (int)(double.x + double.width), (int)(double.y + double.height));
  }
  
  public void setPaintMode() { this.wing.setPaintMode(); }
  
  public void setXORMode(Color paramColor) { this.wing.setXORMode(paramColor); }
  
  public Font getFont() { return this.wing.getFont(); }
  
  public void setFont(Font paramFont) { this.wing.setFont(paramFont); }
  
  public FontMetrics getFontMetrics(Font paramFont) { return this.wing.getFontMetrics(paramFont); }
  
  public Rectangle getClipBounds() { return this.wing.getClipBounds(); }
  
  public Shape getClip() { return this.wing.getClip(); }
  
  public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.wing.copyArea(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.wing.drawLine(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void fillRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.wing.fillRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void clearRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.wing.clearRect(paramInt1, paramInt2, paramInt3, paramInt4, this.bg); }
  
  public void drawRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.wing.drawRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void fillRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.wing.fillRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void drawOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.wing.drawOval(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void fillOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.wing.fillOval(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void drawArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.wing.drawArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void fillArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.wing.fillArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void drawPolyline(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.wing.drawPolyline(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
  
  public void drawPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.wing.drawPolygon(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
  
  public void fillPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.wing.fillPolygon(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
  
  public void drawString(String paramString, int paramInt1, int paramInt2) { this.wing.drawString(paramString, paramInt1, paramInt2); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, 0, 0, paramImageObserver, null); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, null); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, Color paramColor, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, 0, 0, paramImageObserver, paramColor); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3 - paramInt1 + 1, paramInt4 - paramInt2 + 1, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver, null); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, Color paramColor, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3 - paramInt1 + 1, paramInt4 - paramInt2 + 1, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver, paramColor); }
  
  protected boolean doImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
    PixelConsumer pixelConsumer = new PixelConsumer(paramImage);
    return doImage(pixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
  }
  
  protected boolean doImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver, Color paramColor) {
    PixelConsumer pixelConsumer = new PixelConsumer(paramImage, paramInt5, paramInt6, paramInt7, paramInt8);
    return doImage(pixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
  }
  
  protected boolean doImage(PixelConsumer paramPixelConsumer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
    if (this.wing.isError())
      return true; 
    byte[] arrayOfByte = this.wing.getImageBytes(paramPixelConsumer, paramColor);
    if (paramInt3 == 0)
      paramInt3 = paramPixelConsumer.iwidth; 
    if (paramInt4 == 0)
      paramInt4 = paramPixelConsumer.iheight; 
    this;
    this.wing.drawImage0(arrayOfByte, paramPixelConsumer.width, paramPixelConsumer.height, this.wing.realX(paramInt1), this.wing.realY(paramInt2), this.wing.realW(paramInt3), this.wing.realH(paramInt4), (paramColor == null) ? 16777215 : (Win32Graphics.getRGB(paramColor) & 0xFFFFFF), this.wing.isDither());
    return true;
  }
  
  public void dispose() { this.wing.dispose(); }
  
  private void transformRect(Rectangle2D.Double paramDouble, AffineTransform paramAffineTransform, boolean paramBoolean) {
    Point2D point2D1 = new Point2D.Double(paramDouble.getX(), paramDouble.getY());
    Point2D point2D2 = new Point2D.Double(paramDouble.getX() + paramDouble.getWidth(), paramDouble.getY() + paramDouble.getHeight());
    if (paramBoolean) {
      try {
        point2D1 = paramAffineTransform.inverseTransform(point2D1, null);
        point2D2 = paramAffineTransform.inverseTransform(point2D2, null);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } else {
      point2D1 = paramAffineTransform.transform(point2D1, null);
      point2D2 = paramAffineTransform.transform(point2D2, null);
    } 
    paramDouble.x = point2D1.getX();
    paramDouble.y = point2D1.getY();
    paramDouble.width = point2D2.getX() - point2D1.getX();
    paramDouble.height = point2D2.getY() - point2D1.getY();
  }
  
  AffineTransform trans = new AffineTransform();
  
  FontRenderContext fontContext = new FontRenderContext(new AffineTransform(), true, true);
  
  Stroke stroke = new BasicStroke();
  
  Paint brush = Color.black;
  
  Color bg = Color.white;
  
  Color fg = Color.black;
  
  PrinterJob job;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\Win32Graphics2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */