package inetsoft.report.internal.j2d;

import inetsoft.report.internal.CustomGraphics;
import inetsoft.report.internal.PSGraphics;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.TexturePaint;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ImageObserver;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderableImage;
import java.awt.print.PrinterGraphics;
import java.awt.print.PrinterJob;
import java.io.OutputStream;
import java.text.AttributedCharacterIterator;
import java.util.Map;

public class PSGraphics2D extends Graphics2D implements Cloneable, CustomGraphics, PrinterGraphics {
  public static PSGraphics2D getGraphics() { return new PSGraphics2D(); }
  
  public PrinterJob getPrinterJob() { return this.job; }
  
  public void setPrinterJob(PrinterJob paramPrinterJob) { this.job = paramPrinterJob; }
  
  public void setPageSize(double paramDouble1, double paramDouble2) {
    this.psg.setPageSize(paramDouble1, paramDouble2);
    Rectangle rectangle = this.psg.getClipBounds();
    this.clipping = new Rectangle2D.Double(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
  }
  
  public Dimension getPageDimension() { return this.psg.getPageDimension(); }
  
  public void setOrientation(int paramInt) {
    this.psg.setOrientation(paramInt);
    Rectangle rectangle = this.psg.getClipBounds();
    this.clipping = new Rectangle2D.Double(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
  }
  
  public int getOrientation() { return this.psg.getOrientation(); }
  
  public void startDoc(OutputStream paramOutputStream) {
    this.psg.setOutput(paramOutputStream);
    this.psg.startDoc();
  }
  
  public void setCompressImage(boolean paramBoolean) { this.psg.setCompressImage(paramBoolean); }
  
  public boolean isCompressImage() { return this.psg.isCompressImage(); }
  
  public void close() { this.psg.close(); }
  
  PSGraphics psg = new PSGraphics();
  
  protected PSGraphics2D() {
    Rectangle rectangle = this.psg.getClipBounds();
    this.clipping = new Rectangle2D.Double(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
  }
  
  public Graphics create() {
    try {
      PSGraphics2D pSGraphics2D = (PSGraphics2D)clone();
      pSGraphics2D.ptrans = new AffineTransform(this.ptrans);
      pSGraphics2D.ptrans.concatenate(this.trans);
      pSGraphics2D.trans = new AffineTransform();
      pSGraphics2D.psg = (PSGraphics)this.psg.create();
      return pSGraphics2D;
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public Graphics create(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    PSGraphics2D pSGraphics2D = (PSGraphics2D)super.create(paramInt1, paramInt2, paramInt3, paramInt4);
    pSGraphics2D.ptrans.concatenate(pSGraphics2D.trans);
    pSGraphics2D.trans = new AffineTransform();
    return pSGraphics2D;
  }
  
  public void draw(Shape paramShape) {
    if (paramShape instanceof Arc2D) {
      Arc2D arc2D = (Arc2D)paramShape;
      this.psg.drawArc(arc2D.getX(), arc2D.getY(), arc2D.getWidth(), arc2D.getHeight(), arc2D.getAngleStart(), arc2D.getAngleExtent());
    } else if (paramShape instanceof Ellipse2D) {
      Ellipse2D ellipse2D = (Ellipse2D)paramShape;
      this.psg.drawOval(ellipse2D.getX(), ellipse2D.getY(), ellipse2D.getWidth(), ellipse2D.getHeight());
    } else if (paramShape instanceof Line2D) {
      Line2D line2D = (Line2D)paramShape;
      this.psg.drawLine(line2D.getX1(), line2D.getY1(), line2D.getX2(), line2D.getY2());
    } else if (paramShape instanceof Rectangle2D) {
      Rectangle2D rectangle2D = (Rectangle2D)paramShape;
      this.psg.drawRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    } else if (paramShape instanceof RoundRectangle2D) {
      RoundRectangle2D roundRectangle2D = (RoundRectangle2D)paramShape;
      this.psg.drawRoundRect(roundRectangle2D.getX(), roundRectangle2D.getY(), roundRectangle2D.getWidth(), roundRectangle2D.getHeight(), roundRectangle2D.getArcWidth(), roundRectangle2D.getArcHeight());
    } else if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      this.psg.drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } else if (paramShape instanceof Polygon) {
      Polygon polygon = (Polygon)paramShape;
      this.psg.drawPolygon(polygon.xpoints, polygon.ypoints, polygon.npoints);
    } else {
      throw new RuntimeException("Drapsg of " + paramShape.getClass().getName() + " not supported by PSGraphics2D");
    } 
  }
  
  public boolean drawImage(Image paramImage, AffineTransform paramAffineTransform, ImageObserver paramImageObserver) {
    AffineTransform affineTransform = getTransform();
    transform(paramAffineTransform);
    drawImage(paramImage, 0, 0, paramImageObserver);
    setTransform(affineTransform);
    return true;
  }
  
  public void drawImage(BufferedImage paramBufferedImage, BufferedImageOp paramBufferedImageOp, int paramInt1, int paramInt2) { throw new RuntimeException("drawImage(BufferedImage, BufferedImageOp, int, int) not supported by PSGraphics2D"); }
  
  public void drawRenderedImage(RenderedImage paramRenderedImage, AffineTransform paramAffineTransform) {
    AffineTransform affineTransform = getTransform();
    transform(paramAffineTransform);
    drawImage((Image)paramRenderedImage, 0, 0, null);
    setTransform(affineTransform);
  }
  
  public void drawRenderableImage(RenderableImage paramRenderableImage, AffineTransform paramAffineTransform) {
    AffineTransform affineTransform = getTransform();
    transform(paramAffineTransform);
    drawImage((Image)paramRenderableImage, 0, 0, null);
    setTransform(affineTransform);
  }
  
  public void drawString(String paramString, float paramFloat1, float paramFloat2) { this.psg.drawString(paramString, paramFloat1, paramFloat2); }
  
  public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, int paramInt1, int paramInt2) { throw new RuntimeException("drawString(AttributedCharactorIterator, int, int) not supported by PSGraphics2D"); }
  
  public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, float paramFloat1, float paramFloat2) { throw new RuntimeException("drawString(AttributedCharactorIterator, float, float) not supported by PSGraphics2D"); }
  
  public void drawGlyphVector(GlyphVector paramGlyphVector, float paramFloat1, float paramFloat2) { throw new RuntimeException("drawGlyphVector(GlyphVector, float, float) not supported by PSGraphics2D"); }
  
  public void fill(Shape paramShape) {
    if (paramShape instanceof Arc2D) {
      Arc2D arc2D = (Arc2D)paramShape;
      this.psg.fillArc(arc2D.getX(), arc2D.getY(), arc2D.getWidth(), arc2D.getHeight(), arc2D.getAngleStart(), arc2D.getAngleExtent());
    } else if (paramShape instanceof Ellipse2D) {
      Ellipse2D ellipse2D = (Ellipse2D)paramShape;
      this.psg.fillOval(ellipse2D.getX(), ellipse2D.getY(), ellipse2D.getWidth(), ellipse2D.getHeight());
    } else if (paramShape instanceof Rectangle2D) {
      Rectangle2D rectangle2D = (Rectangle2D)paramShape;
      this.psg.fillRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    } else if (paramShape instanceof RoundRectangle2D) {
      RoundRectangle2D roundRectangle2D = (RoundRectangle2D)paramShape;
      this.psg.fillRoundRect(roundRectangle2D.getX(), roundRectangle2D.getY(), roundRectangle2D.getWidth(), roundRectangle2D.getHeight(), roundRectangle2D.getArcWidth(), roundRectangle2D.getArcHeight());
    } else if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      this.psg.fillRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } else if (paramShape instanceof Polygon) {
      Polygon polygon = (Polygon)paramShape;
      this.psg.fillPolygon(polygon.xpoints, polygon.ypoints, polygon.npoints);
    } else {
      throw new RuntimeException("Filling of " + paramShape.getClass().getName() + " not supported by PSGraphics2D");
    } 
  }
  
  public boolean hit(Rectangle paramRectangle, Shape paramShape, boolean paramBoolean) { throw new RuntimeException("hit(Rectangle, Shape, boolean) not supported by PSGraphics2D"); }
  
  public GraphicsConfiguration getDeviceConfiguration() { throw new RuntimeException("getDeviceConfiguration() not supported by PSGraphics2D"); }
  
  public void setComposite(Composite paramComposite) { throw new RuntimeException("setComposite() not supported by PSGraphics2D"); }
  
  public void setPaint(Paint paramPaint) {
    this.brush = paramPaint;
    if (this.brush instanceof TexturePaint) {
      BufferedImage bufferedImage = ((TexturePaint)this.brush).getImage();
    } else if (this.brush instanceof Color) {
      setColor((Color)this.brush);
    } else {
      throw new RuntimeException("Only TexturePaint is supported by PSGraphics2D");
    } 
  }
  
  public void setStroke(Stroke paramStroke) {
    this.stroke = paramStroke;
    if (this.stroke instanceof BasicStroke) {
      BasicStroke basicStroke = (BasicStroke)this.stroke;
      float[] arrayOfFloat = basicStroke.getDashArray();
      int i = (arrayOfFloat != null && arrayOfFloat.length > 0) ? (int)arrayOfFloat[0] : 0;
      emit(basicStroke.getLineWidth() + " setlinewidth");
      if (i > 0) {
        emit("[ " + i + " " + i + " ] 0 setdash");
      } else {
        emit("[ ] 0 setdash");
      } 
      switch (basicStroke.getEndCap()) {
        case 0:
          emit("0 setlinecap");
          break;
        case 1:
          emit("1 setlinecap");
          break;
        case 2:
          emit("2 setlinecap");
          break;
      } 
      switch (basicStroke.getLineJoin()) {
        case 0:
          emit("0 setlinejoin");
          break;
        case 1:
          emit("1 setlinejoin");
          break;
        case 2:
          emit("2 setlinejoin");
          break;
      } 
    } else {
      throw new RuntimeException("Only BasicStroke is supported by PSGraphics2D");
    } 
  }
  
  public void setRenderingHint(RenderingHints.Key paramKey, Object paramObject) {}
  
  public Object getRenderingHint(RenderingHints.Key paramKey) { return null; }
  
  public void setRenderingHints(Map paramMap) {}
  
  public void addRenderingHints(Map paramMap) {}
  
  public RenderingHints getRenderingHints() { return null; }
  
  public void translate(int paramInt1, int paramInt2) { translate(paramInt1, paramInt2); }
  
  public void translate(double paramDouble1, double paramDouble2) {
    this.trans.translate(paramDouble1, paramDouble2);
    emit(paramDouble1 + " " + -paramDouble2 + " translate");
  }
  
  public void rotate(double paramDouble) {
    this.trans.rotate(paramDouble);
    paramDouble = -paramDouble;
    double d = paramDouble * 180.0D / Math.PI;
    emit(d + " rotate");
  }
  
  public void rotate(double paramDouble1, double paramDouble2, double paramDouble3) {
    AffineTransform affineTransform = new AffineTransform();
    affineTransform.rotate(paramDouble1, paramDouble2, paramDouble3);
    transform(affineTransform);
  }
  
  public void scale(double paramDouble1, double paramDouble2) {
    this.trans.scale(paramDouble1, paramDouble2);
    emit(paramDouble1 + " " + paramDouble2 + " scale");
  }
  
  public void shear(double paramDouble1, double paramDouble2) {
    AffineTransform affineTransform = new AffineTransform();
    affineTransform.shear(paramDouble1, paramDouble2);
    transform(affineTransform);
  }
  
  public void transform(AffineTransform paramAffineTransform) {
    this.trans.concatenate(paramAffineTransform);
    concat(paramAffineTransform);
  }
  
  public void setTransform(AffineTransform paramAffineTransform) {
    this.psg.grestore();
    setColor(getColor());
    setFont(getFont());
    setClip(getClip());
    this.psg.gsave();
    this.trans = paramAffineTransform;
    concat(paramAffineTransform);
  }
  
  public AffineTransform getTransform() { return new AffineTransform(this.trans); }
  
  private void concat(AffineTransform paramAffineTransform) {
    double[] arrayOfDouble = new double[6];
    paramAffineTransform.getMatrix(arrayOfDouble);
    emit("[ " + arrayOfDouble[0] + " " + -arrayOfDouble[1] + " " + -arrayOfDouble[2] + " " + arrayOfDouble[3] + " " + arrayOfDouble[4] + " " + -arrayOfDouble[5] + " ] concat");
  }
  
  public Paint getPaint() { return this.brush; }
  
  public Composite getComposite() { return null; }
  
  public void setColor(Color paramColor) {
    this.fg = paramColor;
    this.brush = paramColor;
    this.psg.setColor(this.fg);
    setStroke(getStroke());
  }
  
  public Color getColor() { return this.fg; }
  
  public void setBackground(Color paramColor) { this.bg = paramColor; }
  
  public Color getBackground() { return this.bg; }
  
  public Stroke getStroke() { return this.stroke; }
  
  public boolean isSupported(int paramInt) { return true; }
  
  public void setClip(Shape paramShape) {
    if (paramShape instanceof Rectangle2D) {
      Rectangle2D rectangle2D = (Rectangle2D)paramShape;
      setClip(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    } else if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      setClip(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } else {
      throw new RuntimeException("Clipping of " + paramShape.getClass().getName() + " not supported by PSGraphics2D");
    } 
  }
  
  public void clip(Shape paramShape) {
    if (paramShape instanceof Rectangle2D) {
      Rectangle2D rectangle2D = (Rectangle2D)paramShape;
      clipRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    } else if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      clipRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } else {
      throw new RuntimeException("Clipping of " + paramShape.getClass().getName() + " not supported by PSGraphics2D");
    } 
  }
  
  public FontRenderContext getFontRenderContext() { return this.fontContext; }
  
  public void clipRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { clipRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void clipRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    Rectangle2D.Double double = new Rectangle2D.Double(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    transformRect(double, false);
    this.clipping = this.clipping.createIntersection(double);
    this.psg.clipRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
  }
  
  public void setClip(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { setClip(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void setClip(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    Rectangle2D.Double double = new Rectangle2D.Double(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    transformRect(double, false);
    this.clipping = double;
    this.psg.setClip(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
  }
  
  void emit(String paramString) { this.psg.emit(paramString); }
  
  public void setPaintMode() { this.psg.setPaintMode(); }
  
  public void setXORMode(Color paramColor) { this.psg.setXORMode(paramColor); }
  
  public Font getFont() { return this.psg.getFont(); }
  
  public void setFont(Font paramFont) { this.psg.setFont(paramFont); }
  
  public FontMetrics getFontMetrics(Font paramFont) { return this.psg.getFontMetrics(paramFont); }
  
  public Rectangle getClipBounds() {
    Rectangle2D.Double double = new Rectangle2D.Double();
    double.setRect(this.clipping);
    transformRect(double, true);
    return new Rectangle((int)double.getX(), (int)double.getY(), (int)double.getWidth(), (int)double.getHeight());
  }
  
  public Shape getClip() { return getClipBounds(); }
  
  public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.copyArea(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.drawLine(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void fillRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.fillRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void clearRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.clearRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void drawRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.drawRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void fillRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.fillRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void drawOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.drawOval(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void fillOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.fillOval(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void drawArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.drawArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void fillArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.fillArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void drawPolyline(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.psg.drawPolyline(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
  
  public void drawPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.psg.drawPolygon(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
  
  public void fillPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.psg.fillPolygon(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
  
  public void drawString(String paramString, int paramInt1, int paramInt2) { this.psg.drawString(paramString, paramInt1, paramInt2); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramImageObserver); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, Color paramColor, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramColor, paramImageObserver); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramColor, paramImageObserver); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, Color paramColor, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramColor, paramImageObserver); }
  
  public void reset() { this.psg.reset(); }
  
  public void dispose() { this.psg.dispose(); }
  
  private void transformRect(Rectangle2D.Double paramDouble, boolean paramBoolean) {
    Point2D point2D1 = new Point2D.Double(paramDouble.getX(), paramDouble.getY());
    Point2D point2D2 = new Point2D.Double(paramDouble.getX() + paramDouble.getWidth(), paramDouble.getY() + paramDouble.getHeight());
    if (paramBoolean) {
      try {
        point2D1 = this.trans.inverseTransform(point2D1, null);
        point2D2 = this.trans.inverseTransform(point2D2, null);
        point2D1 = this.ptrans.inverseTransform(point2D1, null);
        point2D2 = this.ptrans.inverseTransform(point2D2, null);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } else {
      point2D1 = this.ptrans.transform(point2D1, null);
      point2D2 = this.ptrans.transform(point2D2, null);
      point2D1 = this.trans.transform(point2D1, null);
      point2D2 = this.trans.transform(point2D2, null);
    } 
    paramDouble.x = point2D1.getX();
    paramDouble.y = point2D1.getY();
    paramDouble.width = point2D2.getX() - point2D1.getX();
    paramDouble.height = point2D2.getY() - point2D1.getY();
  }
  
  AffineTransform trans = new AffineTransform();
  
  AffineTransform ptrans = new AffineTransform();
  
  FontRenderContext fontContext = new FontRenderContext(new AffineTransform(), true, true);
  
  Stroke stroke = new BasicStroke();
  
  Rectangle2D clipping = null;
  
  Paint brush = Color.black;
  
  Color bg = Color.white;
  
  Color fg = Color.black;
  
  PrinterJob job;
  
  static AffineTransform psmatrix = new AffineTransform();
  
  static  {
    psmatrix.scale(1.0D, -1.0D);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\PSGraphics2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */