/*     */ package inetsoft.report.internal.j2d;
/*     */ 
/*     */ import inetsoft.report.internal.CustomGraphics;
/*     */ import inetsoft.report.internal.PSGraphics;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Composite;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.Image;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Polygon;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Shape;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.TexturePaint;
/*     */ import java.awt.font.FontRenderContext;
/*     */ import java.awt.font.GlyphVector;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Arc2D;
/*     */ import java.awt.geom.Ellipse2D;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.geom.RoundRectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.BufferedImageOp;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.awt.image.renderable.RenderableImage;
/*     */ import java.awt.print.PrinterGraphics;
/*     */ import java.awt.print.PrinterJob;
/*     */ import java.io.OutputStream;
/*     */ import java.text.AttributedCharacterIterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class PSGraphics2D extends Graphics2D implements Cloneable, CustomGraphics, PrinterGraphics {
/*  43 */   public static PSGraphics2D getGraphics() { return new PSGraphics2D(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public PrinterJob getPrinterJob() { return this.job; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public void setPrinterJob(PrinterJob paramPrinterJob) { this.job = paramPrinterJob; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPageSize(double paramDouble1, double paramDouble2) {
/*  70 */     this.psg.setPageSize(paramDouble1, paramDouble2);
/*  71 */     Rectangle rectangle = this.psg.getClipBounds();
/*  72 */     this.clipping = new Rectangle2D.Double(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public Dimension getPageDimension() { return this.psg.getPageDimension(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrientation(int paramInt) {
/*  91 */     this.psg.setOrientation(paramInt);
/*  92 */     Rectangle rectangle = this.psg.getClipBounds();
/*  93 */     this.clipping = new Rectangle2D.Double(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public int getOrientation() { return this.psg.getOrientation(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDoc(OutputStream paramOutputStream) {
/* 109 */     this.psg.setOutput(paramOutputStream);
/* 110 */     this.psg.startDoc();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public void setCompressImage(boolean paramBoolean) { this.psg.setCompressImage(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public boolean isCompressImage() { return this.psg.isCompressImage(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   public void close() { this.psg.close(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   PSGraphics psg = new PSGraphics(); protected PSGraphics2D() {
/* 143 */     Rectangle rectangle = this.psg.getClipBounds();
/* 144 */     this.clipping = new Rectangle2D.Double(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Graphics create() {
/*     */     try {
/* 153 */       PSGraphics2D pSGraphics2D = (PSGraphics2D)clone();
/* 154 */       pSGraphics2D.ptrans = new AffineTransform(this.ptrans);
/* 155 */       pSGraphics2D.ptrans.concatenate(this.trans);
/* 156 */       pSGraphics2D.trans = new AffineTransform();
/* 157 */       pSGraphics2D.psg = (PSGraphics)this.psg.create();
/* 158 */       return pSGraphics2D;
/*     */     } catch (Exception exception) {
/* 160 */       exception.printStackTrace();
/*     */ 
/*     */       
/* 163 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Graphics create(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 175 */     PSGraphics2D pSGraphics2D = (PSGraphics2D)super.create(paramInt1, paramInt2, paramInt3, paramInt4);
/* 176 */     pSGraphics2D.ptrans.concatenate(pSGraphics2D.trans);
/* 177 */     pSGraphics2D.trans = new AffineTransform();
/* 178 */     return pSGraphics2D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Shape paramShape) {
/* 185 */     if (paramShape instanceof Arc2D) {
/* 186 */       Arc2D arc2D = (Arc2D)paramShape;
/* 187 */       this.psg.drawArc(arc2D.getX(), arc2D.getY(), arc2D.getWidth(), arc2D.getHeight(), arc2D.getAngleStart(), arc2D.getAngleExtent());
/*     */     
/*     */     }
/* 190 */     else if (paramShape instanceof Ellipse2D) {
/* 191 */       Ellipse2D ellipse2D = (Ellipse2D)paramShape;
/* 192 */       this.psg.drawOval(ellipse2D.getX(), ellipse2D.getY(), ellipse2D.getWidth(), ellipse2D.getHeight());
/*     */     }
/* 194 */     else if (paramShape instanceof Line2D) {
/* 195 */       Line2D line2D = (Line2D)paramShape;
/* 196 */       this.psg.drawLine(line2D.getX1(), line2D.getY1(), line2D.getX2(), line2D.getY2());
/*     */     }
/* 198 */     else if (paramShape instanceof Rectangle2D) {
/* 199 */       Rectangle2D rectangle2D = (Rectangle2D)paramShape;
/* 200 */       this.psg.drawRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
/*     */     
/*     */     }
/* 203 */     else if (paramShape instanceof RoundRectangle2D) {
/* 204 */       RoundRectangle2D roundRectangle2D = (RoundRectangle2D)paramShape;
/* 205 */       this.psg.drawRoundRect(roundRectangle2D.getX(), roundRectangle2D.getY(), roundRectangle2D.getWidth(), roundRectangle2D.getHeight(), roundRectangle2D.getArcWidth(), roundRectangle2D.getArcHeight());
/*     */ 
/*     */     
/*     */     }
/* 209 */     else if (paramShape instanceof Rectangle) {
/* 210 */       Rectangle rectangle = (Rectangle)paramShape;
/* 211 */       this.psg.drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*     */     }
/* 213 */     else if (paramShape instanceof Polygon) {
/* 214 */       Polygon polygon = (Polygon)paramShape;
/* 215 */       this.psg.drawPolygon(polygon.xpoints, polygon.ypoints, polygon.npoints);
/*     */     } else {
/*     */       
/* 218 */       throw new RuntimeException("Drapsg of " + paramShape.getClass().getName() + " not supported by PSGraphics2D");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean drawImage(Image paramImage, AffineTransform paramAffineTransform, ImageObserver paramImageObserver) {
/* 228 */     AffineTransform affineTransform = getTransform();
/* 229 */     transform(paramAffineTransform);
/* 230 */     drawImage(paramImage, 0, 0, paramImageObserver);
/* 231 */     setTransform(affineTransform);
/* 232 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 239 */   public void drawImage(BufferedImage paramBufferedImage, BufferedImageOp paramBufferedImageOp, int paramInt1, int paramInt2) { throw new RuntimeException("drawImage(BufferedImage, BufferedImageOp, int, int) not supported by PSGraphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawRenderedImage(RenderedImage paramRenderedImage, AffineTransform paramAffineTransform) {
/* 246 */     AffineTransform affineTransform = getTransform();
/* 247 */     transform(paramAffineTransform);
/* 248 */     drawImage((Image)paramRenderedImage, 0, 0, null);
/* 249 */     setTransform(affineTransform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawRenderableImage(RenderableImage paramRenderableImage, AffineTransform paramAffineTransform) {
/* 257 */     AffineTransform affineTransform = getTransform();
/* 258 */     transform(paramAffineTransform);
/* 259 */     drawImage((Image)paramRenderableImage, 0, 0, null);
/* 260 */     setTransform(affineTransform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 267 */   public void drawString(String paramString, float paramFloat1, float paramFloat2) { this.psg.drawString(paramString, paramFloat1, paramFloat2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 274 */   public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, int paramInt1, int paramInt2) { throw new RuntimeException("drawString(AttributedCharactorIterator, int, int) not supported by PSGraphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 282 */   public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, float paramFloat1, float paramFloat2) { throw new RuntimeException("drawString(AttributedCharactorIterator, float, float) not supported by PSGraphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 289 */   public void drawGlyphVector(GlyphVector paramGlyphVector, float paramFloat1, float paramFloat2) { throw new RuntimeException("drawGlyphVector(GlyphVector, float, float) not supported by PSGraphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fill(Shape paramShape) {
/* 296 */     if (paramShape instanceof Arc2D) {
/* 297 */       Arc2D arc2D = (Arc2D)paramShape;
/* 298 */       this.psg.fillArc(arc2D.getX(), arc2D.getY(), arc2D.getWidth(), arc2D.getHeight(), arc2D.getAngleStart(), arc2D.getAngleExtent());
/*     */     
/*     */     }
/* 301 */     else if (paramShape instanceof Ellipse2D) {
/* 302 */       Ellipse2D ellipse2D = (Ellipse2D)paramShape;
/* 303 */       this.psg.fillOval(ellipse2D.getX(), ellipse2D.getY(), ellipse2D.getWidth(), ellipse2D.getHeight());
/*     */     }
/* 305 */     else if (paramShape instanceof Rectangle2D) {
/* 306 */       Rectangle2D rectangle2D = (Rectangle2D)paramShape;
/* 307 */       this.psg.fillRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
/*     */     
/*     */     }
/* 310 */     else if (paramShape instanceof RoundRectangle2D) {
/* 311 */       RoundRectangle2D roundRectangle2D = (RoundRectangle2D)paramShape;
/* 312 */       this.psg.fillRoundRect(roundRectangle2D.getX(), roundRectangle2D.getY(), roundRectangle2D.getWidth(), roundRectangle2D.getHeight(), roundRectangle2D.getArcWidth(), roundRectangle2D.getArcHeight());
/*     */ 
/*     */     
/*     */     }
/* 316 */     else if (paramShape instanceof Rectangle) {
/* 317 */       Rectangle rectangle = (Rectangle)paramShape;
/* 318 */       this.psg.fillRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*     */     }
/* 320 */     else if (paramShape instanceof Polygon) {
/* 321 */       Polygon polygon = (Polygon)paramShape;
/* 322 */       this.psg.fillPolygon(polygon.xpoints, polygon.ypoints, polygon.npoints);
/*     */     } else {
/*     */       
/* 325 */       throw new RuntimeException("Filling of " + paramShape.getClass().getName() + " not supported by PSGraphics2D");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 334 */   public boolean hit(Rectangle paramRectangle, Shape paramShape, boolean paramBoolean) { throw new RuntimeException("hit(Rectangle, Shape, boolean) not supported by PSGraphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 341 */   public GraphicsConfiguration getDeviceConfiguration() { throw new RuntimeException("getDeviceConfiguration() not supported by PSGraphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 348 */   public void setComposite(Composite paramComposite) { throw new RuntimeException("setComposite() not supported by PSGraphics2D"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPaint(Paint paramPaint) {
/* 355 */     this.brush = paramPaint;
/*     */     
/* 357 */     if (this.brush instanceof TexturePaint) {
/* 358 */       BufferedImage bufferedImage = ((TexturePaint)this.brush).getImage();
/*     */     }
/* 360 */     else if (this.brush instanceof Color) {
/* 361 */       setColor((Color)this.brush);
/*     */     } else {
/*     */       
/* 364 */       throw new RuntimeException("Only TexturePaint is supported by PSGraphics2D");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStroke(Stroke paramStroke) {
/* 372 */     this.stroke = paramStroke;
/*     */     
/* 374 */     if (this.stroke instanceof BasicStroke) {
/* 375 */       BasicStroke basicStroke = (BasicStroke)this.stroke;
/* 376 */       float[] arrayOfFloat = basicStroke.getDashArray();
/* 377 */       int i = (arrayOfFloat != null && arrayOfFloat.length > 0) ? (int)arrayOfFloat[0] : 0;
/*     */       
/* 379 */       emit(basicStroke.getLineWidth() + " setlinewidth");
/*     */       
/* 381 */       if (i > 0) {
/* 382 */         emit("[ " + i + " " + i + " ] 0 setdash");
/*     */       } else {
/*     */         
/* 385 */         emit("[ ] 0 setdash");
/*     */       } 
/*     */       
/* 388 */       switch (basicStroke.getEndCap()) {
/*     */         case 0:
/* 390 */           emit("0 setlinecap");
/*     */           break;
/*     */         case 1:
/* 393 */           emit("1 setlinecap");
/*     */           break;
/*     */         case 2:
/* 396 */           emit("2 setlinecap");
/*     */           break;
/*     */       } 
/*     */       
/* 400 */       switch (basicStroke.getLineJoin()) {
/*     */         case 0:
/* 402 */           emit("0 setlinejoin");
/*     */           break;
/*     */         case 1:
/* 405 */           emit("1 setlinejoin");
/*     */           break;
/*     */         case 2:
/* 408 */           emit("2 setlinejoin");
/*     */           break;
/*     */       } 
/*     */     
/*     */     } else {
/* 413 */       throw new RuntimeException("Only BasicStroke is supported by PSGraphics2D");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderingHint(RenderingHints.Key paramKey, Object paramObject) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 427 */   public Object getRenderingHint(RenderingHints.Key paramKey) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderingHints(Map paramMap) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRenderingHints(Map paramMap) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 446 */   public RenderingHints getRenderingHints() { return null; }
/*     */ 
/*     */ 
/*     */   
/* 450 */   public void translate(int paramInt1, int paramInt2) { translate(paramInt1, paramInt2); }
/*     */ 
/*     */   
/*     */   public void translate(double paramDouble1, double paramDouble2) {
/* 454 */     this.trans.translate(paramDouble1, paramDouble2);
/* 455 */     emit(paramDouble1 + " " + -paramDouble2 + " translate");
/*     */   }
/*     */   
/*     */   public void rotate(double paramDouble) {
/* 459 */     this.trans.rotate(paramDouble);
/* 460 */     paramDouble = -paramDouble;
/* 461 */     double d = paramDouble * 180.0D / Math.PI;
/* 462 */     emit(d + " rotate");
/*     */   }
/*     */   
/*     */   public void rotate(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 466 */     AffineTransform affineTransform = new AffineTransform();
/* 467 */     affineTransform.rotate(paramDouble1, paramDouble2, paramDouble3);
/* 468 */     transform(affineTransform);
/*     */   }
/*     */   
/*     */   public void scale(double paramDouble1, double paramDouble2) {
/* 472 */     this.trans.scale(paramDouble1, paramDouble2);
/* 473 */     emit(paramDouble1 + " " + paramDouble2 + " scale");
/*     */   }
/*     */   
/*     */   public void shear(double paramDouble1, double paramDouble2) {
/* 477 */     AffineTransform affineTransform = new AffineTransform();
/* 478 */     affineTransform.shear(paramDouble1, paramDouble2);
/* 479 */     transform(affineTransform);
/*     */   }
/*     */   
/*     */   public void transform(AffineTransform paramAffineTransform) {
/* 483 */     this.trans.concatenate(paramAffineTransform);
/* 484 */     concat(paramAffineTransform);
/*     */   }
/*     */   
/*     */   public void setTransform(AffineTransform paramAffineTransform) {
/* 488 */     this.psg.grestore();
/*     */     
/* 490 */     setColor(getColor());
/* 491 */     setFont(getFont());
/* 492 */     setClip(getClip());
/* 493 */     this.psg.gsave();
/*     */     
/* 495 */     this.trans = paramAffineTransform;
/* 496 */     concat(paramAffineTransform);
/*     */   }
/*     */ 
/*     */   
/* 500 */   public AffineTransform getTransform() { return new AffineTransform(this.trans); }
/*     */ 
/*     */   
/*     */   private void concat(AffineTransform paramAffineTransform) {
/* 504 */     double[] arrayOfDouble = new double[6];
/* 505 */     paramAffineTransform.getMatrix(arrayOfDouble);
/*     */     
/* 507 */     emit("[ " + arrayOfDouble[0] + " " + -arrayOfDouble[1] + " " + -arrayOfDouble[2] + " " + arrayOfDouble[3] + " " + arrayOfDouble[4] + " " + -arrayOfDouble[5] + " ] concat");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 513 */   public Paint getPaint() { return this.brush; }
/*     */ 
/*     */ 
/*     */   
/* 517 */   public Composite getComposite() { return null; }
/*     */ 
/*     */   
/*     */   public void setColor(Color paramColor) {
/* 521 */     this.fg = paramColor;
/* 522 */     this.brush = paramColor;
/*     */     
/* 524 */     this.psg.setColor(this.fg);
/* 525 */     setStroke(getStroke());
/*     */   }
/*     */ 
/*     */   
/* 529 */   public Color getColor() { return this.fg; }
/*     */ 
/*     */ 
/*     */   
/* 533 */   public void setBackground(Color paramColor) { this.bg = paramColor; }
/*     */ 
/*     */ 
/*     */   
/* 537 */   public Color getBackground() { return this.bg; }
/*     */ 
/*     */ 
/*     */   
/* 541 */   public Stroke getStroke() { return this.stroke; }
/*     */ 
/*     */ 
/*     */   
/* 545 */   public boolean isSupported(int paramInt) { return true; }
/*     */ 
/*     */   
/*     */   public void setClip(Shape paramShape) {
/* 549 */     if (paramShape instanceof Rectangle2D) {
/* 550 */       Rectangle2D rectangle2D = (Rectangle2D)paramShape;
/* 551 */       setClip(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
/*     */     }
/* 553 */     else if (paramShape instanceof Rectangle) {
/* 554 */       Rectangle rectangle = (Rectangle)paramShape;
/* 555 */       setClip(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*     */     } else {
/*     */       
/* 558 */       throw new RuntimeException("Clipping of " + paramShape.getClass().getName() + " not supported by PSGraphics2D");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clip(Shape paramShape) {
/* 564 */     if (paramShape instanceof Rectangle2D) {
/* 565 */       Rectangle2D rectangle2D = (Rectangle2D)paramShape;
/* 566 */       clipRect(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
/*     */     }
/* 568 */     else if (paramShape instanceof Rectangle) {
/* 569 */       Rectangle rectangle = (Rectangle)paramShape;
/* 570 */       clipRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*     */     } else {
/*     */       
/* 573 */       throw new RuntimeException("Clipping of " + paramShape.getClass().getName() + " not supported by PSGraphics2D");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 579 */   public FontRenderContext getFontRenderContext() { return this.fontContext; }
/*     */ 
/*     */ 
/*     */   
/* 583 */   public void clipRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { clipRect(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */   
/*     */   public void clipRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 587 */     Rectangle2D.Double double = new Rectangle2D.Double(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/* 588 */     transformRect(double, false);
/* 589 */     this.clipping = this.clipping.createIntersection(double);
/* 590 */     this.psg.clipRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */   }
/*     */ 
/*     */   
/* 594 */   public void setClip(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { setClip(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */   
/*     */   public void setClip(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 598 */     Rectangle2D.Double double = new Rectangle2D.Double(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/* 599 */     transformRect(double, false);
/* 600 */     this.clipping = double;
/* 601 */     this.psg.setClip(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 608 */   void emit(String paramString) { this.psg.emit(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 615 */   public void setPaintMode() { this.psg.setPaintMode(); }
/*     */ 
/*     */ 
/*     */   
/* 619 */   public void setXORMode(Color paramColor) { this.psg.setXORMode(paramColor); }
/*     */ 
/*     */ 
/*     */   
/* 623 */   public Font getFont() { return this.psg.getFont(); }
/*     */ 
/*     */ 
/*     */   
/* 627 */   public void setFont(Font paramFont) { this.psg.setFont(paramFont); }
/*     */ 
/*     */ 
/*     */   
/* 631 */   public FontMetrics getFontMetrics(Font paramFont) { return this.psg.getFontMetrics(paramFont); }
/*     */ 
/*     */   
/*     */   public Rectangle getClipBounds() {
/* 635 */     Rectangle2D.Double double = new Rectangle2D.Double();
/* 636 */     double.setRect(this.clipping);
/* 637 */     transformRect(double, true);
/* 638 */     return new Rectangle((int)double.getX(), (int)double.getY(), (int)double.getWidth(), (int)double.getHeight());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 643 */   public Shape getClip() { return getClipBounds(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 648 */   public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.copyArea(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*     */ 
/*     */ 
/*     */   
/* 652 */   public void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.drawLine(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */   
/* 656 */   public void fillRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.fillRect(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */   
/* 660 */   public void clearRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.clearRect(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 665 */   public void drawRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.drawRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 670 */   public void fillRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.fillRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*     */ 
/*     */ 
/*     */   
/* 674 */   public void drawOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.drawOval(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */   
/* 678 */   public void fillOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.psg.fillOval(paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 683 */   public void drawArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.drawArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 688 */   public void fillArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { this.psg.fillArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 693 */   public void drawPolyline(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.psg.drawPolyline(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
/*     */ 
/*     */ 
/*     */   
/* 697 */   public void drawPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.psg.drawPolygon(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
/*     */ 
/*     */ 
/*     */   
/* 701 */   public void fillPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) { this.psg.fillPolygon(paramArrayOfInt1, paramArrayOfInt2, paramInt); }
/*     */ 
/*     */ 
/*     */   
/* 705 */   public void drawString(String paramString, int paramInt1, int paramInt2) { this.psg.drawString(paramString, paramInt1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 710 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramImageObserver); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 715 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 720 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, Color paramColor, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramColor, paramImageObserver); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 725 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramColor, paramImageObserver); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 731 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 738 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, Color paramColor, ImageObserver paramImageObserver) { return this.psg.drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramColor, paramImageObserver); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 743 */   public void reset() { this.psg.reset(); }
/*     */ 
/*     */ 
/*     */   
/* 747 */   public void dispose() { this.psg.dispose(); }
/*     */ 
/*     */ 
/*     */   
/*     */   private void transformRect(Rectangle2D.Double paramDouble, boolean paramBoolean) {
/* 752 */     Point2D point2D1 = new Point2D.Double(paramDouble.getX(), paramDouble.getY());
/* 753 */     Point2D point2D2 = new Point2D.Double(paramDouble.getX() + paramDouble.getWidth(), paramDouble.getY() + paramDouble.getHeight());
/*     */ 
/*     */     
/* 756 */     if (paramBoolean) {
/*     */       try {
/* 758 */         point2D1 = this.trans.inverseTransform(point2D1, null);
/* 759 */         point2D2 = this.trans.inverseTransform(point2D2, null);
/* 760 */         point2D1 = this.ptrans.inverseTransform(point2D1, null);
/* 761 */         point2D2 = this.ptrans.inverseTransform(point2D2, null);
/*     */       } catch (Exception exception) {
/* 763 */         exception.printStackTrace();
/*     */       } 
/*     */     } else {
/*     */       
/* 767 */       point2D1 = this.ptrans.transform(point2D1, null);
/* 768 */       point2D2 = this.ptrans.transform(point2D2, null);
/* 769 */       point2D1 = this.trans.transform(point2D1, null);
/* 770 */       point2D2 = this.trans.transform(point2D2, null);
/*     */     } 
/*     */     
/* 773 */     paramDouble.x = point2D1.getX();
/* 774 */     paramDouble.y = point2D1.getY();
/* 775 */     paramDouble.width = point2D2.getX() - point2D1.getX();
/* 776 */     paramDouble.height = point2D2.getY() - point2D1.getY();
/*     */   }
/*     */ 
/*     */   
/* 780 */   AffineTransform trans = new AffineTransform();
/*     */   
/* 782 */   AffineTransform ptrans = new AffineTransform();
/* 783 */   FontRenderContext fontContext = new FontRenderContext(new AffineTransform(), true, true);
/*     */   
/* 785 */   Stroke stroke = new BasicStroke();
/* 786 */   Rectangle2D clipping = null;
/* 787 */   Paint brush = Color.black;
/* 788 */   Color bg = Color.white;
/* 789 */   Color fg = Color.black;
/*     */   
/*     */   PrinterJob job;
/* 792 */   static AffineTransform psmatrix = new AffineTransform();
/*     */   
/*     */   static  {
/* 795 */     psmatrix.scale(1.0D, -1.0D);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\PSGraphics2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */