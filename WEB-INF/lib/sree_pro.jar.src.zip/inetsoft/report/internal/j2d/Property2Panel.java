/*     */ package inetsoft.report.internal.j2d;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.border.EtchedBorder;
/*     */ import javax.swing.border.TitledBorder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Property2Panel
/*     */   extends JPanel
/*     */ {
/*     */   JPanel pnl;
/*     */   
/*  32 */   public Property2Panel() { setLayout(new GridBagLayout()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(String paramString, Object[][] paramArrayOfObject) {
/*  41 */     if (this.pnl != null) {
/*  42 */       remove(this.pnl);
/*     */ 
/*     */       
/*  45 */       GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
/*  46 */       gridBagConstraints1.gridwidth = 0;
/*  47 */       gridBagConstraints1.weightx = 1.0D; gridBagConstraints1.weighty = 0.0D;
/*  48 */       gridBagConstraints1.anchor = 11;
/*  49 */       gridBagConstraints1.fill = 2;
/*     */       
/*  51 */       add(this.pnl, gridBagConstraints1);
/*     */     } 
/*     */     
/*  54 */     this.pnl = new JPanel();
/*  55 */     if (paramString != null) {
/*  56 */       this.pnl.setBorder(new TitledBorder(new EtchedBorder(0), paramString));
/*     */     }
/*     */     
/*  59 */     this.pnl.setLayout(new GridBagLayout());
/*     */     
/*  61 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*  62 */     gridBagConstraints.gridwidth = 0;
/*  63 */     gridBagConstraints.weightx = 1.0D; gridBagConstraints.weighty = 1.0D;
/*  64 */     gridBagConstraints.anchor = 11;
/*  65 */     gridBagConstraints.fill = 2;
/*     */     
/*  67 */     add(this.pnl, gridBagConstraints);
/*     */     
/*  69 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/*  70 */       int i = 1;
/*     */       
/*  72 */       for (byte b1 = 0; b1 < paramArrayOfObject[b].length; b1++) {
/*     */         
/*  74 */         if (paramArrayOfObject[b][b1] instanceof Integer) {
/*  75 */           i = ((Integer)paramArrayOfObject[b][b1]).intValue();
/*     */           
/*     */           continue;
/*     */         } 
/*  79 */         GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
/*  80 */         gridBagConstraints1.weightx = gridBagConstraints1.weighty = 1.0D;
/*  81 */         gridBagConstraints1.anchor = 17;
/*  82 */         gridBagConstraints1.insets = new Insets(5, 5, 5, 5);
/*  83 */         gridBagConstraints1.gridwidth = i;
/*  84 */         i = 1;
/*     */         
/*  86 */         if (b1 == paramArrayOfObject[b].length - 1) {
/*  87 */           gridBagConstraints1.gridwidth = 0;
/*     */         }
/*     */         else {
/*     */           
/*  91 */           for (byte b2 = b1 + 1; b2 < paramArrayOfObject[b].length && paramArrayOfObject[b][b2] == null; 
/*  92 */             b2++) {
/*  93 */             gridBagConstraints1.gridwidth++;
/*     */           }
/*     */         } 
/*     */         
/*  97 */         Component component = null;
/*  98 */         if (paramArrayOfObject[b][b1] instanceof Component) {
/*  99 */           component = (Component)paramArrayOfObject[b][b1];
/*     */           
/* 101 */           if (component instanceof JLabel) {
/* 102 */             gridBagConstraints1.anchor = 13;
/*     */           }
/*     */         } else {
/* 105 */           if (paramArrayOfObject[b][b1] == null) {
/*     */             continue;
/*     */           }
/* 108 */           if (paramArrayOfObject[b][b1] instanceof Object[]) {
/* 109 */             JPanel jPanel = new JPanel();
/* 110 */             jPanel.setLayout(new FlowLayout(0, 0, 0));
/* 111 */             Object[] arrayOfObject = (Object[])paramArrayOfObject[b][b1];
/*     */             
/* 113 */             for (byte b2 = 0; b2 < arrayOfObject.length; b2++) {
/* 114 */               if (b2) {
/* 115 */                 jPanel.add(new JLabel(" "));
/*     */               }
/*     */               
/* 118 */               if (arrayOfObject[b2] instanceof Component) {
/* 119 */                 jPanel.add((Component)arrayOfObject[b2]);
/*     */               } else {
/*     */                 
/* 122 */                 jPanel.add(new JLabel(arrayOfObject[b2].toString()));
/*     */               } 
/*     */             } 
/*     */             
/* 126 */             component = jPanel;
/*     */           } else {
/*     */             
/* 129 */             gridBagConstraints1.anchor = 13;
/* 130 */             component = new JLabel(paramArrayOfObject[b][b1].toString());
/*     */           } 
/*     */         } 
/* 133 */         this.pnl.add(component, gridBagConstraints1);
/*     */         continue;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\Property2Panel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */