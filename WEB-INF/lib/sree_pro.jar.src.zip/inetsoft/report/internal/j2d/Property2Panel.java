package inetsoft.report.internal.j2d;

import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

public class Property2Panel extends JPanel {
  JPanel pnl;
  
  public Property2Panel() { setLayout(new GridBagLayout()); }
  
  public void add(String paramString, Object[][] paramArrayOfObject) {
    if (this.pnl != null) {
      remove(this.pnl);
      GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
      gridBagConstraints1.gridwidth = 0;
      gridBagConstraints1.weightx = 1.0D;
      gridBagConstraints1.weighty = 0.0D;
      gridBagConstraints1.anchor = 11;
      gridBagConstraints1.fill = 2;
      add(this.pnl, gridBagConstraints1);
    } 
    this.pnl = new JPanel();
    if (paramString != null)
      this.pnl.setBorder(new TitledBorder(new EtchedBorder(0), paramString)); 
    this.pnl.setLayout(new GridBagLayout());
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 0;
    gridBagConstraints.weightx = 1.0D;
    gridBagConstraints.weighty = 1.0D;
    gridBagConstraints.anchor = 11;
    gridBagConstraints.fill = 2;
    add(this.pnl, gridBagConstraints);
    for (byte b = 0; b < paramArrayOfObject.length; b++) {
      int i = 1;
      for (byte b1 = 0; b1 < paramArrayOfObject[b].length; b1++) {
        if (paramArrayOfObject[b][b1] instanceof Integer) {
          i = ((Integer)paramArrayOfObject[b][b1]).intValue();
          continue;
        } 
        GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
        gridBagConstraints1.weightx = gridBagConstraints1.weighty = 1.0D;
        gridBagConstraints1.anchor = 17;
        gridBagConstraints1.insets = new Insets(5, 5, 5, 5);
        gridBagConstraints1.gridwidth = i;
        i = 1;
        if (b1 == paramArrayOfObject[b].length - 1) {
          gridBagConstraints1.gridwidth = 0;
        } else {
          for (byte b2 = b1 + 1; b2 < paramArrayOfObject[b].length && paramArrayOfObject[b][b2] == null; 
            b2++)
            gridBagConstraints1.gridwidth++; 
        } 
        Component component = null;
        if (paramArrayOfObject[b][b1] instanceof Component) {
          component = (Component)paramArrayOfObject[b][b1];
          if (component instanceof JLabel)
            gridBagConstraints1.anchor = 13; 
        } else {
          if (paramArrayOfObject[b][b1] == null)
            continue; 
          if (paramArrayOfObject[b][b1] instanceof Object[]) {
            JPanel jPanel = new JPanel();
            jPanel.setLayout(new FlowLayout(0, 0, 0));
            Object[] arrayOfObject = (Object[])paramArrayOfObject[b][b1];
            for (byte b2 = 0; b2 < arrayOfObject.length; b2++) {
              if (b2)
                jPanel.add(new JLabel(" ")); 
              if (arrayOfObject[b2] instanceof Component) {
                jPanel.add((Component)arrayOfObject[b2]);
              } else {
                jPanel.add(new JLabel(arrayOfObject[b2].toString()));
              } 
            } 
            component = jPanel;
          } else {
            gridBagConstraints1.anchor = 13;
            component = new JLabel(paramArrayOfObject[b][b1].toString());
          } 
        } 
        this.pnl.add(component, gridBagConstraints1);
        continue;
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\Property2Panel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */