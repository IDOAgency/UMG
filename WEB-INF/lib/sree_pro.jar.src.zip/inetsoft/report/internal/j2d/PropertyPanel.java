/*    */ package inetsoft.report.internal.j2d;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.GridBagLayout;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyPanel
/*    */   extends JPanel
/*    */ {
/*    */   Insets insets;
/*    */   
/*    */   public PropertyPanel() {
/* 78 */     this.insets = new Insets(8, 5, 8, 5);
/*    */     setLayout(new GridBagLayout());
/*    */   }
/*    */   
/*    */   public PropertyPanel(Insets paramInsets) {
/*    */     this();
/*    */     this.insets = paramInsets;
/*    */   }
/*    */   
/*    */   public void setFields(Object[][] paramArrayOfObject) {
/*    */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/*    */       for (byte b1 = 0; b1 < paramArrayOfObject[b].length; b1++) {
/*    */         GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
/*    */         if (b1 == paramArrayOfObject[b].length - 1)
/*    */           gridBagConstraints1.gridwidth = 0; 
/*    */         gridBagConstraints1.weightx = 1.0D;
/*    */         gridBagConstraints1.weighty = 0.0D;
/*    */         gridBagConstraints1.anchor = 17;
/*    */         gridBagConstraints1.insets = this.insets;
/*    */         if (paramArrayOfObject[b][b1] instanceof Component) {
/*    */           add((Component)paramArrayOfObject[b][b1], gridBagConstraints1);
/*    */         } else if (paramArrayOfObject[b][b1] instanceof Object[]) {
/*    */           PropertyPanel propertyPanel = new PropertyPanel(new Insets(0, 0, 0, 4));
/*    */           propertyPanel.setFields(new Object[][] { (Object[])paramArrayOfObject[b][b1] });
/*    */           add(propertyPanel, gridBagConstraints1);
/*    */         } else {
/*    */           gridBagConstraints1.anchor = 13;
/*    */           add(new JLabel(paramArrayOfObject[b][b1].toString()), gridBagConstraints1);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*    */     gridBagConstraints.weightx = 1.0D;
/*    */     gridBagConstraints.weighty = 1.0D;
/*    */     add(new JLabel(""), gridBagConstraints);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\PropertyPanel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */