/*     */ package inetsoft.report.internal.j2d;
/*     */ 
/*     */ import java.awt.AWTEventMulticaster;
/*     */ import java.awt.event.TextEvent;
/*     */ import java.awt.event.TextListener;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumField
/*     */   extends JTextField
/*     */ {
/*     */   TextListener textListener;
/*     */   DocumentListener changeListener;
/*     */   boolean integer;
/*     */   boolean empty;
/*     */   
/*     */   public NumField(int paramInt, boolean paramBoolean) {
/*  34 */     super(paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     this.textListener = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     this.changeListener = new DocumentListener(this)
/*     */       {
/* 158 */         public void insertUpdate(DocumentEvent param1DocumentEvent) { this.this$0.fireTextEvent(); }
/*     */         
/*     */         private final NumField this$0;
/*     */         
/* 162 */         public void removeUpdate(DocumentEvent param1DocumentEvent) { this.this$0.fireTextEvent(); }
/*     */ 
/*     */         
/*     */         public void changedUpdate(DocumentEvent param1DocumentEvent) {
/* 166 */           this.this$0.fireTextEvent();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     this.integer = true;
/* 214 */     this.empty = false;
/*     */     this.integer = paramBoolean;
/*     */     getDocument().addDocumentListener(new Listener(this, paramBoolean, this.empty));
/*     */     getDocument().addDocumentListener(this.changeListener);
/*     */   }
/*     */   
/*     */   public NumField(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
/*     */     this(paramInt, paramBoolean1);
/*     */     this.empty = paramBoolean2;
/*     */   }
/*     */   
/*     */   public boolean isInteger() { return this.integer; }
/*     */   
/*     */   public void setValue(int paramInt) {
/*     */     setText(Integer.toString(paramInt));
/*     */     moveCaretPosition(0);
/*     */   }
/*     */   
/*     */   public void setValue(float paramFloat) {
/*     */     setText(Float.toString(paramFloat));
/*     */     moveCaretPosition(0);
/*     */   }
/*     */   
/*     */   public void setValue(double paramDouble) {
/*     */     setValue((float)paramDouble);
/*     */     moveCaretPosition(0);
/*     */   }
/*     */   
/*     */   public void setText(String paramString) {
/*     */     super.setText(paramString);
/*     */     moveCaretPosition(0);
/*     */   }
/*     */   
/*     */   public float floatValue() { return (getText().trim().length() == 0) ? 0.0F : Float.valueOf(getText()).floatValue(); }
/*     */   
/*     */   public double doubleValue() { return (getText().trim().length() == 0) ? 0.0D : Double.valueOf(getText()).doubleValue(); }
/*     */   
/*     */   public int intValue() { return (getText().trim().length() == 0) ? 0 : Integer.parseInt(getText()); }
/*     */   
/*     */   public Float floatObject() { return (getText().trim().length() == 0) ? null : Float.valueOf(getText()); }
/*     */   
/*     */   public Double doubleObject() { return (getText().trim().length() == 0) ? null : Double.valueOf(getText()); }
/*     */   
/*     */   public Integer intOject() { return (getText().trim().length() == 0) ? null : Integer.valueOf(getText()); }
/*     */   
/*     */   public void addTextListener(TextListener paramTextListener) { this.textListener = AWTEventMulticaster.add(this.textListener, paramTextListener); }
/*     */   
/*     */   public void removeTextListener(TextListener paramTextListener) { this.textListener = AWTEventMulticaster.remove(this.textListener, paramTextListener); }
/*     */   
/*     */   void fireTextEvent() {
/*     */     if (this.textListener != null)
/*     */       this.textListener.textValueChanged(new TextEvent(this, 900)); 
/*     */   }
/*     */   
/*     */   static class Listener implements DocumentListener {
/*     */     JTextField field;
/*     */     boolean integer;
/*     */     boolean empty;
/*     */     
/*     */     public Listener(JTextField param1JTextField, boolean param1Boolean1, boolean param1Boolean2) {
/*     */       this.field = param1JTextField;
/*     */       this.integer = param1Boolean1;
/*     */       this.empty = param1Boolean2;
/*     */     }
/*     */     
/*     */     public void insertUpdate(DocumentEvent param1DocumentEvent) {
/*     */       if (this.field.getText().length() == 0 && this.empty)
/*     */         return; 
/*     */       for (int i = param1DocumentEvent.getOffset(); i < param1DocumentEvent.getOffset() + param1DocumentEvent.getLength(); ) {
/*     */         char c = this.field.getText().charAt(i);
/*     */         if (Character.isDigit(c) || (!this.integer && c == '.') || c == '-') {
/*     */           i++;
/*     */           continue;
/*     */         } 
/*     */         int j = param1DocumentEvent.getOffset();
/*     */         int k = param1DocumentEvent.getLength();
/*     */         SwingUtilities.invokeLater(new NumField$2(this, j, k));
/*     */         break;
/*     */       } 
/*     */     }
/*     */     
/*     */     public void removeUpdate(DocumentEvent param1DocumentEvent) {}
/*     */     
/*     */     public void changedUpdate(DocumentEvent param1DocumentEvent) {}
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\j2d\NumField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */