package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.ReportElement;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Shape;

public class TextFieldPainter extends FieldPainter {
  private String text;
  
  private int cols;
  
  public TextFieldPainter(ReportElement paramReportElement) {
    super(paramReportElement);
    this.cols = 15;
  }
  
  public Object getValue() { return getText(); }
  
  public String getText() { return this.text; }
  
  public void setText(String paramString) { this.text = paramString; }
  
  public int getCols() { return this.cols; }
  
  public void setCols(int paramInt) { this.cols = paramInt; }
  
  public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Shape shape = paramGraphics.getClip();
    paramGraphics.setColor(this.elem.getForeground());
    paramGraphics.setFont(this.elem.getFont());
    paramGraphics.setClip(paramInt1 + 1, paramInt2 + 1, paramInt3 - 2, paramInt4 - 2);
    FontMetrics fontMetrics = Common.getFontMetrics(paramGraphics.getFont());
    float f = Common.getHeight(paramGraphics.getFont(), fontMetrics);
    Common.drawString(paramGraphics, this.text, (paramInt1 + 2), paramInt2 + (paramInt4 - f) / 2.0F + fontMetrics.getAscent());
    paramGraphics.setClip(shape);
    paramGraphics.setColor(Color.gray);
    paramGraphics.draw3DRect(paramInt1, paramInt2, paramInt3 - 1, paramInt4 - 1, false);
  }
  
  public Dimension getPreferredSize() { return new Dimension((int)(Common.stringWidth("M", this.elem.getFont()) * this.cols), (int)Common.getHeight(this.elem.getFont(), null) + 2); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TextFieldPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */