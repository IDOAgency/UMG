package inetsoft.report.internal;

import inetsoft.report.StyleSheet;
import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import inetsoft.report.lens.AttributeTableLens;
import inetsoft.report.lens.DefaultTableLens;
import inetsoft.report.locale.Catalog;
import inetsoft.report.style.TableStyle;
import java.util.Enumeration;
import java.util.Hashtable;

public class TableXElement extends TableElementDef implements Tabular, Groupable {
  TableLens toptable;
  
  TableLens table;
  
  TableStyle style;
  
  TableFilter filterTbl;
  
  AttributeTableLens attrTbl;
  
  FilterAttr filter;
  
  Hashtable rowattrs;
  
  Hashtable colattrs;
  
  boolean fixWidth;
  
  boolean embed;
  
  int hrows;
  
  int hcols;
  
  public TableXElement(StyleSheet paramStyleSheet) { this(paramStyleSheet, new DefaultTableLens(5, 5)); }
  
  public TableXElement(StyleSheet paramStyleSheet, DefaultTableLens paramDefaultTableLens) {
    super(paramStyleSheet, paramDefaultTableLens);
    this.rowattrs = new Hashtable();
    this.colattrs = new Hashtable();
    this.fixWidth = false;
    this.embed = true;
    this.hrows = 1;
    this.hcols = 0;
    paramDefaultTableLens.setHeaderRowCount(1);
    this.table = paramDefaultTableLens;
  }
  
  public void setData(TableLens paramTableLens) {
    DefaultTableLens defaultTableLens = new DefaultTableLens(paramTableLens.getRowCount(), paramTableLens.getColCount());
    for (byte b = 0; b < paramTableLens.getRowCount(); b++) {
      for (byte b1 = 0; b1 < paramTableLens.getColCount(); b1++) {
        Object object = paramTableLens.getObject(b, b1);
        defaultTableLens.setObject(b, b1, (object == null) ? "" : object);
      } 
    } 
    defaultTableLens.setHeaderRowCount(paramTableLens.getHeaderRowCount());
    defaultTableLens.setHeaderColCount(paramTableLens.getHeaderColCount());
    setTable(defaultTableLens);
  }
  
  public boolean isEmbedded() { return this.embed; }
  
  public void setEmbedded(boolean paramBoolean) { this.embed = paramBoolean; }
  
  public TableStyle getStyle() { return this.style; }
  
  public void setStyle(TableStyle paramTableStyle) {
    this.style = paramTableStyle;
    if (paramTableStyle != null) {
      paramTableStyle.setTable(this.table);
      super.setTable(this.toptable = paramTableStyle);
    } else {
      super.setTable(this.toptable = this.table);
    } 
    setFilter(this.filter);
  }
  
  public FilterAttr getFilter() { return this.filter; }
  
  public void setFilter(FilterAttr paramFilterAttr) {
    this.filter = paramFilterAttr;
    this.filterTbl = null;
  }
  
  public void setTable(TableLens paramTableLens) {
    this.filterTbl = null;
    if (this.style != null) {
      TableLens tableLens = paramTableLens;
      for (; tableLens instanceof TableStyle || tableLens.getClass() == AttributeTableLens.class; tableLens = ((AttributeTableLens)tableLens).getTable()) {
        if (tableLens == this.style) {
          paramTableLens = ((AttributeTableLens)tableLens).getTable();
          break;
        } 
      } 
      this.style.setTable(this.table = paramTableLens);
    } else {
      super.setTable(this.toptable = this.table = paramTableLens);
    } 
  }
  
  public TableLens getTable() {
    if (this.filter != null && this.filterTbl == null)
      try {
        this.filterTbl = this.filter.createFilter(getRootTable());
        if (this.style != null && this.filterTbl != null)
          this.style.setTable(this.filterTbl); 
      } catch (Exception exception) {
        exception.printStackTrace();
      }  
    TableFilter tableFilter = this.toptable;
    if (this.style != null) {
      TableStyle tableStyle = this.style;
    } else if (this.filter != null && this.filterTbl != null) {
      tableFilter = this.filterTbl;
    } 
    return applyAttributes(tableFilter);
  }
  
  public TableLens getRootTable() { return this.table; }
  
  public int getHeaderRowCount() { return this.hrows; }
  
  public void setHeaderRowCount(int paramInt) { this.hrows = paramInt; }
  
  public int getHeaderColCount() { return this.hcols; }
  
  public void setHeaderColCount(int paramInt) { this.hcols = this.hcols; }
  
  public boolean isEmbedWidth() { return this.fixWidth; }
  
  public void setEmbedWidth(boolean paramBoolean) { this.fixWidth = paramBoolean; }
  
  public void setFixedWidths(int[] paramArrayOfInt) {
    super.setFixedWidths(paramArrayOfInt);
    setEmbedWidth(true);
  }
  
  public void setRowAlignment(int paramInt1, int paramInt2) {
    (getTableAttr(this.rowattrs, paramInt1)).alignment = new Integer(paramInt2);
    this.attrTbl = null;
  }
  
  public void setColAlignment(int paramInt1, int paramInt2) {
    (getTableAttr(this.colattrs, paramInt1)).alignment = new Integer(paramInt2);
    this.attrTbl = null;
  }
  
  public void setRowFormat(int paramInt, String paramString1, String paramString2) {
    TableAttr tableAttr = getTableAttr(this.rowattrs, paramInt);
    tableAttr.format = paramString1;
    tableAttr.format_spec = paramString2;
    this.attrTbl = null;
  }
  
  public void setRowLineWrap(int paramInt, boolean paramBoolean) {
    (getTableAttr(this.rowattrs, paramInt)).linewrap = new Boolean(paramBoolean);
    this.attrTbl = null;
  }
  
  public void setColFormat(int paramInt, String paramString1, String paramString2) {
    TableAttr tableAttr = getTableAttr(this.colattrs, paramInt);
    tableAttr.format = paramString1;
    tableAttr.format_spec = paramString2;
    this.attrTbl = null;
  }
  
  public void setRowPresenter(int paramInt, String paramString) {
    (getTableAttr(this.rowattrs, paramInt)).presenter = paramString;
    this.attrTbl = null;
  }
  
  public void setColPresenter(int paramInt, String paramString) {
    (getTableAttr(this.colattrs, paramInt)).presenter = paramString;
    this.attrTbl = null;
  }
  
  public void setColLineWrap(int paramInt, boolean paramBoolean) {
    (getTableAttr(this.colattrs, paramInt)).linewrap = new Boolean(paramBoolean);
    this.attrTbl = null;
  }
  
  public String toString() { return (this.style != null) ? (getID() + " [" + Catalog.getString("Table") + ": " + this.style.getName() + "]") : super.toString(); }
  
  public Object clone() throws CloneNotSupportedException {
    TableXElement tableXElement = (TableXElement)super.clone();
    if (this.style != null)
      tableXElement.setStyle((TableStyle)this.style.clone()); 
    return tableXElement;
  }
  
  public Enumeration getAttributeRows() { return this.rowattrs.keys(); }
  
  public Enumeration getAttributeCols() { return this.colattrs.keys(); }
  
  public TableAttr getRowAttribute(int paramInt) { return (TableAttr)this.rowattrs.get(new Integer(paramInt)); }
  
  public TableAttr getColAttribute(int paramInt) { return (TableAttr)this.colattrs.get(new Integer(paramInt)); }
  
  private TableLens applyAttributes(TableLens paramTableLens) {
    if ((this.rowattrs == null || this.rowattrs.size() == 0) && (this.colattrs == null || this.colattrs.size() == 0))
      return paramTableLens; 
    if (this.attrTbl != null) {
      if (this.attrTbl != paramTableLens && this.attrTbl.getTable() != paramTableLens)
        this.attrTbl.setTable(paramTableLens); 
      return this.attrTbl;
    } 
    this.attrTbl = new AttributeTableLens(paramTableLens);
    Enumeration enumeration = getAttributeRows();
    while (enumeration.hasMoreElements()) {
      int i = ((Integer)enumeration.nextElement()).intValue();
      TableAttr tableAttr = getRowAttribute(i);
      if (tableAttr.alignment != null)
        this.attrTbl.setRowAlignment(i, tableAttr.alignment.intValue()); 
      if (tableAttr.format != null)
        this.attrTbl.setRowFormat(i, tableAttr.getFormat()); 
      if (tableAttr.presenter != null)
        this.attrTbl.setRowPresenter(i, tableAttr.getPresenter()); 
      if (tableAttr.linewrap != null)
        this.attrTbl.setRowLineWrap(i, tableAttr.linewrap.booleanValue()); 
    } 
    enumeration = getAttributeCols();
    while (enumeration.hasMoreElements()) {
      int i = ((Integer)enumeration.nextElement()).intValue();
      TableAttr tableAttr = getColAttribute(i);
      if (tableAttr.alignment != null)
        this.attrTbl.setColAlignment(i, tableAttr.alignment.intValue()); 
      if (tableAttr.format != null)
        this.attrTbl.setFormat(i, tableAttr.getFormat()); 
      if (tableAttr.presenter != null)
        this.attrTbl.setPresenter(i, tableAttr.getPresenter()); 
      if (tableAttr.linewrap != null)
        this.attrTbl.setColLineWrap(i, tableAttr.linewrap.booleanValue()); 
    } 
    return this.attrTbl;
  }
  
  private TableAttr getTableAttr(Hashtable paramHashtable, int paramInt) {
    TableAttr tableAttr = (TableAttr)paramHashtable.get(new Integer(paramInt));
    if (tableAttr == null)
      paramHashtable.put(new Integer(paramInt), tableAttr = new TableAttr()); 
    return tableAttr;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TableXElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */