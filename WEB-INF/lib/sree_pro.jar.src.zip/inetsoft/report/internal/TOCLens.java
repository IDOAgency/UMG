package inetsoft.report.internal;

import inetsoft.report.CompositeLens;
import inetsoft.report.Context;
import inetsoft.report.HeadingElement;
import inetsoft.report.StyleSheet;
import inetsoft.report.TOC;
import inetsoft.report.lens.DefaultHeadingLens;
import inetsoft.report.lens.DefaultTextLens;
import java.io.Serializable;
import java.util.Vector;

class TOCLens implements CompositeLens, Serializable {
  private TOC toc;
  
  private int step;
  
  private int curr;
  
  private Vector headings;
  
  private StyleSheet report;
  
  public TOCLens(StyleSheet paramStyleSheet, TOC paramTOC) {
    this.step = 0;
    this.curr = 0;
    this.headings = new Vector();
    this.report = paramStyleSheet;
    this.toc = paramTOC;
  }
  
  public void setStyleSheet(StyleSheet paramStyleSheet) { this.report = paramStyleSheet; }
  
  public Object nextElement(Context paramContext) {
    Object object;
    CompositeLens.Space space;
    HTextLens hTextLens;
    if (this.curr >= this.headings.size())
      return null; 
    HeadingElementDef headingElementDef = (HeadingElementDef)this.headings.elementAt(this.curr);
    DefaultTextLens defaultTextLens = null;
    switch (this.step) {
      case 0:
        defaultTextLens = new DefaultTextLens(headingElementDef.getDisplayText());
        paramContext.setIndent(this.toc.getIndent(headingElementDef.getLevel()));
        paramContext.setFont(this.toc.getFont(headingElementDef.getLevel()));
        break;
      case 1:
        if (this.toc.isPageNumberRight()) {
          CompositeLens.Tab tab = new CompositeLens.Tab(this.toc.getLeader(headingElementDef.getLevel()));
          double d = this.report.printBox.width / this.report.resolution - 0.4D;
          paramContext.setTabStops(new double[] { d });
          paramContext.setFont(this.toc.getFont(headingElementDef.getLevel()));
          break;
        } 
        space = new CompositeLens.Space(15);
        break;
      case 2:
        hTextLens = new HTextLens(headingElementDef, this.report);
        paramContext.setFont(this.toc.getFont(headingElementDef.getLevel()));
        break;
      case 3:
        if (this.toc.getSeparator(headingElementDef.getLevel()) != 0) {
          CompositeLens.Separator separator = new CompositeLens.Separator(this.toc.getSeparator(headingElementDef.getLevel()));
          break;
        } 
        object = CompositeLens.NEWLINE;
        break;
    } 
    paramContext.setAlignment(this.toc.getAlignment(headingElementDef.getLevel()));
    this.step++;
    if (this.step > 3) {
      this.step = 0;
      this.curr++;
    } 
    return object;
  }
  
  public void reset() {
    this.step = this.curr = 0;
    this.headings.removeAllElements();
    for (byte b = 0; b < this.report.elements.size(); b++) {
      Object object = this.report.elements.elementAt(b);
      if (object instanceof HeadingElement && ((HeadingElement)object).isVisible())
        this.headings.addElement(object); 
    } 
    if (this.report.designtime && this.headings.size() == 0) {
      DefaultHeadingLens defaultHeadingLens = new DefaultHeadingLens("Empty Table of Contents", 1);
      this.headings.addElement(new HeadingElementDef(this.report, defaultHeadingLens));
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TOCLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */