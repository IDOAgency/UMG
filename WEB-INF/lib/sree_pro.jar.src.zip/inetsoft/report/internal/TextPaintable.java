/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.TextLens;
/*     */ import inetsoft.report.lens.DefaultTextLens;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextPaintable
/*     */   extends BasePaintable
/*     */ {
/*     */   String text;
/*     */   TextLens lens;
/*     */   float x;
/*     */   float y;
/*     */   float width;
/*     */   boolean highlighted;
/*     */   Rectangle box;
/*     */   
/*     */   public TextPaintable(String paramString, float paramFloat1, float paramFloat2, ReportElement paramReportElement) {
/*  35 */     super(paramReportElement);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 180 */     this.highlighted = false;
/* 181 */     this.box = null; this.text = paramString; this.x = paramFloat1; this.y = paramFloat2; } public TextPaintable(TextLens paramTextLens, float paramFloat1, float paramFloat2, ReportElement paramReportElement) { super(paramReportElement); this.highlighted = false; this.box = null;
/*     */     this.lens = paramTextLens;
/*     */     this.text = null;
/*     */     this.x = paramFloat1;
/*     */     this.y = paramFloat2; }
/*     */ 
/*     */   
/*     */   public TextPaintable(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, ReportElement paramReportElement) {
/*     */     this(paramString, paramFloat1, paramFloat2, paramReportElement);
/*     */     this.width = paramFloat3;
/*     */   }
/*     */   
/*     */   public Rectangle getBounds() {
/*     */     if (this.box == null) {
/*     */       String str = getText();
/*     */       Font font = this.elem.getFont();
/*     */       float f = (this.width > 0.0F) ? this.width : Common.stringWidth(str, font);
/*     */       this.box = new Rectangle((int)this.x, (int)this.y, Common.round(f), Common.round(Common.getHeight(font, null)));
/*     */     } 
/*     */     return this.box;
/*     */   }
/*     */   
/*     */   public void setLocation(Point paramPoint) {
/*     */     this.x = paramPoint.x;
/*     */     this.y = paramPoint.y;
/*     */     if (this.box != null) {
/*     */       this.box.x = paramPoint.x;
/*     */       this.box.y = paramPoint.y;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paint(Graphics paramGraphics) {
/*     */     Font font = this.elem.getFont();
/*     */     paramGraphics.setFont(font);
/*     */     String str = getText();
/*     */     FontMetrics fontMetrics = Common.getFontMetrics(font);
/*     */     float f = (this.width > 0.0F) ? this.width : Common.stringWidth(str, font, fontMetrics);
/*     */     if (this.elem.getBackground() != null) {
/*     */       paramGraphics.setColor(this.elem.getBackground());
/*     */       Common.fillRect(paramGraphics, this.x, this.y, f, Common.getHeight(font, fontMetrics));
/*     */     } 
/*     */     paramGraphics.setColor(this.elem.getForeground());
/*     */     if (this.width > 0.0F) {
/*     */       Common.drawString(paramGraphics, str, this.x, this.y + Common.getAscent(fontMetrics), this.width);
/*     */     } else if (font.getSize() > 14) {
/*     */       Common.drawString(paramGraphics, str, this.x, this.y + Common.getAscent(fontMetrics));
/*     */     } else {
/*     */       Common.drawString(paramGraphics, str, this.x, this.y + Common.getAscent(fontMetrics), f);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getText() { return (this.text != null) ? this.text : ((this.lens instanceof HeaderTextLens) ? ((HeaderTextLens)this.lens).getDisplayText() : this.lens.getText()); }
/*     */   
/*     */   public void setText(String paramString) {
/*     */     this.lens = new DefaultTextLens(paramString);
/*     */     this.text = paramString;
/*     */   }
/*     */   
/*     */   public void setHighlighted(boolean paramBoolean) { this.highlighted = paramBoolean; }
/*     */   
/*     */   public boolean isHighlighted() { return this.highlighted; }
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
/*     */     paramObjectInputStream.defaultReadObject();
/*     */     this.elem = new DefaultTextContext();
/*     */     ((DefaultTextContext)this.elem).read(paramObjectInputStream);
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/*     */     paramObjectOutputStream.defaultWriteObject();
/*     */     DefaultTextContext.write(paramObjectOutputStream, this.elem);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TextPaintable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */