package inetsoft.report.internal;

public class TokenParser {
  private String str;
  
  private int idx;
  
  public TokenParser(String paramString) {
    this.idx = 0;
    this.str = paramString;
  }
  
  public void skipWhitespace() { for (; this.idx < this.str.length() && Character.isWhitespace(this.str.charAt(this.idx)); this.idx++); }
  
  public boolean skipTo(char paramChar) {
    for (; this.idx < this.str.length(); this.idx++) {
      if (this.str.charAt(this.idx) == paramChar) {
        this.idx++;
        return true;
      } 
    } 
    return false;
  }
  
  public boolean isNext(char paramChar) {
    skipWhitespace();
    boolean bool = (this.idx < this.str.length() && this.str.charAt(this.idx) == paramChar);
    if (bool)
      this.idx++; 
    return bool;
  }
  
  public char next() {
    skipWhitespace();
    return (this.idx < this.str.length()) ? this.str.charAt(this.idx) : 0;
  }
  
  public void advance() { this.idx++; }
  
  public String getString() {
    skipWhitespace();
    if (this.idx >= this.str.length() || this.str.charAt(this.idx) != '"')
      return null; 
    String str1 = null;
    for (int i = this.idx + 1; i < this.str.length(); i++) {
      if (this.str.charAt(i) == '"') {
        str1 = this.str.substring(this.idx + 1, i);
        this.idx = i + 1;
        break;
      } 
    } 
    return str1;
  }
  
  public String getName() {
    skipWhitespace();
    if (this.idx >= this.str.length() || !Character.isJavaIdentifierStart(this.str.charAt(this.idx)))
      return null; 
    String str1 = null;
    for (int i = this.idx + 1; i < this.str.length(); i++) {
      if (!Character.isJavaLetterOrDigit(this.str.charAt(i))) {
        str1 = this.str.substring(this.idx, i);
        this.idx = i;
        break;
      } 
    } 
    return str1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TokenParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */