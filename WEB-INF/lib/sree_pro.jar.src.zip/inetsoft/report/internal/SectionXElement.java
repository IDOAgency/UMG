package inetsoft.report.internal;

import inetsoft.report.SectionBand;
import inetsoft.report.StyleSheet;
import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import inetsoft.report.lens.DefaultSectionLens;

public class SectionXElement extends SectionElementDef implements Groupable {
  TableLens toptable;
  
  TableLens table;
  
  TableFilter filterTbl;
  
  FilterAttr filter;
  
  public SectionXElement(StyleSheet paramStyleSheet) {
    this(paramStyleSheet, new DefaultSectionLens(new SectionBand(paramStyleSheet), new SectionBand(paramStyleSheet), new SectionBand(paramStyleSheet)));
    ((SectionBand)getSection().getSectionContent()).setHeight(0.6F);
  }
  
  public SectionXElement(StyleSheet paramStyleSheet, DefaultSectionLens paramDefaultSectionLens) { super(paramStyleSheet, paramDefaultSectionLens, null); }
  
  public FilterAttr getFilter() { return this.filter; }
  
  public void setFilter(FilterAttr paramFilterAttr) {
    this.filter = paramFilterAttr;
    this.filterTbl = null;
  }
  
  public void setTable(TableLens paramTableLens) {
    this.filterTbl = null;
    super.setTable(this.toptable = this.table = paramTableLens);
  }
  
  public TableLens getTable() {
    if (this.filter != null && this.filterTbl == null)
      try {
        this.toptable = this.filterTbl = this.filter.createFilter(getRootTable());
      } catch (Exception exception) {
        exception.printStackTrace();
      }  
    return this.toptable;
  }
  
  public TableLens getRootTable() { return this.table; }
  
  public Object clone() throws CloneNotSupportedException { return (SectionXElement)super.clone(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SectionXElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */