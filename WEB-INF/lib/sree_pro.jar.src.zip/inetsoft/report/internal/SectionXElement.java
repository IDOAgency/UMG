/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.SectionBand;
/*    */ import inetsoft.report.StyleSheet;
/*    */ import inetsoft.report.TableFilter;
/*    */ import inetsoft.report.TableLens;
/*    */ import inetsoft.report.lens.DefaultSectionLens;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SectionXElement
/*    */   extends SectionElementDef
/*    */   implements Groupable
/*    */ {
/*    */   TableLens toptable;
/*    */   TableLens table;
/*    */   TableFilter filterTbl;
/*    */   FilterAttr filter;
/*    */   
/*    */   public SectionXElement(StyleSheet paramStyleSheet) {
/* 34 */     this(paramStyleSheet, new DefaultSectionLens(new SectionBand(paramStyleSheet), new SectionBand(paramStyleSheet), new SectionBand(paramStyleSheet)));
/*    */ 
/*    */     
/* 37 */     ((SectionBand)getSection().getSectionContent()).setHeight(0.6F);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   public SectionXElement(StyleSheet paramStyleSheet, DefaultSectionLens paramDefaultSectionLens) { super(paramStyleSheet, paramDefaultSectionLens, null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   public FilterAttr getFilter() { return this.filter; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setFilter(FilterAttr paramFilterAttr) {
/* 58 */     this.filter = paramFilterAttr;
/* 59 */     this.filterTbl = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTable(TableLens paramTableLens) {
/* 66 */     this.filterTbl = null;
/* 67 */     super.setTable(this.toptable = this.table = paramTableLens);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TableLens getTable() {
/* 76 */     if (this.filter != null && this.filterTbl == null) {
/*    */       try {
/* 78 */         this.toptable = this.filterTbl = this.filter.createFilter(getRootTable());
/*    */       } catch (Exception exception) {
/* 80 */         exception.printStackTrace();
/*    */       } 
/*    */     }
/*    */     
/* 84 */     return this.toptable;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 91 */   public TableLens getRootTable() { return this.table; }
/*    */ 
/*    */ 
/*    */   
/* 95 */   public Object clone() throws CloneNotSupportedException { return (SectionXElement)super.clone(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SectionXElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */