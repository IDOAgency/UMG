package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.Context;
import inetsoft.report.Painter;
import inetsoft.report.PainterElement;
import inetsoft.report.Position;
import inetsoft.report.ReportElement;
import inetsoft.report.Size;
import inetsoft.report.StylePage;
import inetsoft.report.StyleSheet;
import inetsoft.report.locale.Catalog;
import java.awt.Dimension;
import java.awt.Insets;

public class PainterElementDef extends BaseElement implements PainterElement {
  private Painter painter;
  
  private int layout;
  
  private int wrapping;
  
  private Position anchor;
  
  private ReportElement anchorElem;
  
  private Size psize;
  
  private int offsetY;
  
  private float anchorDepth;
  
  private Insets margin;
  
  public PainterElementDef(StyleSheet paramStyleSheet, Painter paramPainter) {
    super(paramStyleSheet, false);
    this.anchor = null;
    this.anchorElem = null;
    this.anchorDepth = 0.0F;
    this.layout = paramStyleSheet.painterLayout;
    this.anchor = paramStyleSheet.anchor;
    this.wrapping = paramStyleSheet.wrapping;
    paramStyleSheet.anchor = null;
    this.painter = paramPainter;
    this.margin = paramStyleSheet.painterMargin;
  }
  
  public PainterElementDef(StyleSheet paramStyleSheet, Painter paramPainter, double paramDouble1, double paramDouble2) {
    this(paramStyleSheet, paramPainter);
    if (paramDouble1 > 0.0D && paramDouble2 > 0.0D)
      this.psize = new Size((float)paramDouble1, (float)paramDouble2); 
  }
  
  public Painter getPainter() { return this.painter; }
  
  public void setPainter(Painter paramPainter) { this.painter = paramPainter; }
  
  public Insets getMargin() { return this.margin; }
  
  public void setMargin(Insets paramInsets) { this.margin = paramInsets; }
  
  public Size getPreferredSize() {
    int i = 0, j = 0;
    if (this.margin != null) {
      i = this.margin.left + this.margin.right;
      j = this.margin.top + this.margin.bottom;
    } 
    if (this.painter instanceof inetsoft.report.painter.BulletPainter) {
      float f = Common.getHeight(getFont(), null);
      return new Size(f + i, f + j);
    } 
    if (this.psize != null)
      return new Size(this.psize.width * this.report.resolution + i, this.psize.height * this.report.resolution + j); 
    Dimension dimension = this.painter.getPreferredSize();
    if (dimension.width < 0)
      dimension.width = -dimension.width * this.report.printBox.width / 1000; 
    if (dimension.height < 0)
      dimension.height = -dimension.height * this.report.printBox.width / 1000; 
    return new Size((dimension.width + i), (dimension.height + j));
  }
  
  public boolean isBreakable() { return (this.layout == 1); }
  
  public void reset() {
    super.reset();
    this.offsetY = 0;
    this.anchorDepth = 0.0F;
  }
  
  public boolean print(StylePage paramStylePage) {
    if (!isVisible())
      return false; 
    Size size = getPreferredSize();
    int i = 0, j = 0;
    int k = 0, m = 0;
    if (this.margin != null) {
      size.width -= (k = this.margin.left + this.margin.right);
      size.height -= (m = this.margin.top + this.margin.bottom);
      i = this.margin.left;
      j = this.margin.top;
    } 
    if (this.offsetY >= size.height)
      reset(); 
    super.print(paramStylePage);
    Dimension dimension = !this.painter.isScalable() ? this.painter.getPreferredSize() : size.getDimension();
    int n = Common.round(Math.min(size.height - this.offsetY, this.report.printBox.height - this.report.printHead.y));
    int i1 = Common.round(Math.min(this.report.printBox.width - this.report.printHead.x, size.width));
    if (dimension.width < 0)
      dimension.width = -dimension.width * this.report.printBox.width / 1000; 
    if (dimension.height < 0)
      dimension.height = -dimension.height * this.report.printBox.width / 1000; 
    TextPainter textPainter = (this.painter instanceof TextPainter) ? ((TextPainter)this.painter).clone(null) : this.painter;
    paramStylePage.addPaintable(new PainterPaintable(this.report.printHead.x + this.report.printBox.x + i, this.report.printHead.y + this.report.printBox.y + j, i1, n, dimension, (int)size.height, this, textPainter, this.offsetY));
    if (getWrapping() != 0) {
      this.report.printHead.x += (i1 + k);
      this.report.printHead.y += (n + m);
    } 
    this.offsetY += n;
    return (isBreakable() && (int)(this.offsetY - size.height) < 0);
  }
  
  public void setSize(Size paramSize) { this.psize = paramSize; }
  
  public Size getSize() { return this.psize; }
  
  public void setWrapping(int paramInt) { this.wrapping = paramInt; }
  
  public int getWrapping() { return this.wrapping; }
  
  public void setLayout(int paramInt) { this.layout = paramInt; }
  
  public int getLayout() { return this.layout; }
  
  public Position getAnchor() { return this.anchor; }
  
  public void setAnchor(Position paramPosition) {
    if (paramPosition == null)
      this.anchorElem = null; 
    this.anchor = (paramPosition != null) ? new Position(paramPosition.x, this.anchorDepth + paramPosition.y) : null;
  }
  
  public boolean isBlock() { return (super.isBlock() || this.wrapping == 256); }
  
  public boolean isNewline() { return (super.isNewline() || this.wrapping == 2 || this.wrapping == 256 || (this.anchor != null && this.anchor.y > 0.0F)); }
  
  public boolean isLastOnLine() { return (this.wrapping == 1 || this.wrapping == 256); }
  
  public void setContext(ReportElement paramReportElement) {
    super.setContext(paramReportElement);
    if (paramReportElement instanceof Context) {
      Context context = (Context)paramReportElement;
      setLayout(context.getPainterLayout());
    } 
  }
  
  public float getAnchorDepth() { return this.anchorDepth; }
  
  public void setAnchorDepth(float paramFloat) { this.anchorDepth = Math.min(paramFloat, (this.anchor != null) ? this.anchor.y : 0.0F); }
  
  public ReportElement getAnchorElement() { return this.anchorElem; }
  
  public void setAnchorElement(ReportElement paramReportElement) { this.anchorElem = paramReportElement; }
  
  public float getAnchorX() {
    if (getAnchor() == null)
      return 0.0F; 
    return ((getAnchor()).x >= 0.0F) ? ((getAnchor()).x * this.report.resolution) : ((getAnchor()).x * this.report.resolution + this.report.printBox.width);
  }
  
  public String toString() { return getID() + " [" + Catalog.getString(getType()) + "]"; }
  
  public String getType() { return "Painter"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\PainterElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */