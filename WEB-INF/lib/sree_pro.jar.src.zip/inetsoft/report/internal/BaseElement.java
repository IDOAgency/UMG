/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.PageArea;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.SectionBand;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseElement
/*     */   implements ReportElement
/*     */ {
/*     */   protected StyleSheet report;
/*     */   private String id;
/*     */   private int alignment;
/*     */   private double indent;
/*     */   private int hindent;
/*     */   private Font font;
/*     */   private Color foreground;
/*     */   private Color background;
/*     */   private int spacing;
/*     */   private boolean visible;
/*     */   private String scmd;
/*     */   private String onClickCmd;
/*     */   private Object script;
/*     */   private Object onClickScript;
/*     */   private Object scope;
/*     */   private boolean execed;
/*     */   private Rectangle frame;
/*     */   private boolean block;
/*     */   private boolean conti;
/*     */   private Object parent;
/*     */   private Hashtable attrmap;
/*     */   private Object userObj;
/*     */   private boolean keep;
/*     */   boolean nonflow;
/*     */   
/*     */   public BaseElement(StyleSheet paramStyleSheet, boolean paramBoolean) {
/* 557 */     this.report = null;
/*     */ 
/*     */ 
/*     */     
/* 561 */     this.id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 593 */     this.visible = true;
/*     */ 
/*     */ 
/*     */     
/* 597 */     this.scmd = null;
/*     */ 
/*     */ 
/*     */     
/* 601 */     this.onClickCmd = null;
/*     */     
/* 603 */     this.script = null;
/* 604 */     this.onClickScript = null;
/* 605 */     this.scope = null;
/* 606 */     this.execed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 611 */     this.attrmap = new Hashtable();
/*     */     
/* 613 */     this.keep = false;
/* 614 */     this.nonflow = false;
/*     */     this.report = paramStyleSheet;
/*     */     this.block = paramBoolean;
/*     */     this.alignment = paramStyleSheet.alignment;
/*     */     this.indent = paramStyleSheet.indent;
/*     */     this.hindent = paramStyleSheet.hindent;
/*     */     this.font = paramStyleSheet.font;
/*     */     this.foreground = paramStyleSheet.foreground;
/*     */     this.background = paramStyleSheet.background;
/*     */     this.spacing = paramStyleSheet.spacing;
/*     */     this.id = paramStyleSheet.getNextID(getType());
/*     */   }
/*     */   
/*     */   public StyleSheet getStyleSheet() { return this.report; }
/*     */   
/*     */   public void setStyleSheet(StyleSheet paramStyleSheet) { this.report = paramStyleSheet; }
/*     */   
/*     */   public String getID() { return this.id; }
/*     */   
/*     */   public void setID(String paramString) {
/*     */     if (this.parent instanceof SectionBand) {
/*     */       SectionBand sectionBand = (SectionBand)this.parent;
/*     */       String str = sectionBand.getBinding(this.id);
/*     */       sectionBand.setBinding(this.id, null);
/*     */       sectionBand.setBinding(paramString, str);
/*     */     } 
/*     */     this.id = paramString;
/*     */   }
/*     */   
/*     */   public int getAlignment() { return this.alignment; }
/*     */   
/*     */   public void setAlignment(int paramInt) { this.alignment = paramInt; }
/*     */   
/*     */   public double getIndent() { return this.indent; }
/*     */   
/*     */   public void setIndent(double paramDouble) { this.indent = paramDouble; }
/*     */   
/*     */   public int getHindent() { return this.hindent; }
/*     */   
/*     */   public void setHindent(int paramInt) { this.hindent = paramInt; }
/*     */   
/*     */   public Font getFont() { return this.font; }
/*     */   
/*     */   public void setFont(Font paramFont) { this.font = paramFont; }
/*     */   
/*     */   public Color getForeground() { return this.foreground; }
/*     */   
/*     */   public void setForeground(Color paramColor) { this.foreground = paramColor; }
/*     */   
/*     */   public Color getBackground() { return this.background; }
/*     */   
/*     */   public void setBackground(Color paramColor) { this.background = paramColor; }
/*     */   
/*     */   public int getSpacing() { return this.spacing; }
/*     */   
/*     */   public void setSpacing(int paramInt) { this.spacing = paramInt; }
/*     */   
/*     */   public boolean isVisible() { return (this.visible || this.report.designtime); }
/*     */   
/*     */   public void setVisible(boolean paramBoolean) { this.visible = paramBoolean; }
/*     */   
/*     */   public boolean isKeepWithNext() { return this.keep; }
/*     */   
/*     */   public void setKeepWithNext(boolean paramBoolean) { this.keep = paramBoolean; }
/*     */   
/*     */   public String getScript() { return this.scmd; }
/*     */   
/*     */   public void setScript(String paramString) { this.scmd = paramString; }
/*     */   
/*     */   public String getOnClick() { return this.onClickCmd; }
/*     */   
/*     */   public void setOnClick(String paramString) { this.onClickCmd = paramString; }
/*     */   
/*     */   public boolean isBlock() { return this.block; }
/*     */   
/*     */   public void setBlock(boolean paramBoolean) { this.block = paramBoolean; }
/*     */   
/*     */   public boolean isNewline() { return this.block; }
/*     */   
/*     */   public boolean isLastOnLine() { return this.block; }
/*     */   
/*     */   public boolean isFlowControl() { return false; }
/*     */   
/*     */   public boolean isBreakable() { return false; }
/*     */   
/*     */   public void setContinuation(boolean paramBoolean) { this.conti = paramBoolean; }
/*     */   
/*     */   public boolean isContinuation() { return this.conti; }
/*     */   
/*     */   public Size getPreferredSize() { return new Size(0.0F, 0.0F); }
/*     */   
/*     */   public boolean print(StylePage paramStylePage) {
/*     */     try {
/*     */       evaluate();
/*     */     } catch (Throwable throwable) {
/*     */       if (Util.isGUI()) {
/*     */         MessageDialog.show(throwable + "\n" + getScript());
/*     */       } else {
/*     */         System.err.println("Script failed: " + getScript());
/*     */         System.err.println(throwable);
/*     */       } 
/*     */     } 
/*     */     if (!isVisible())
/*     */       return false; 
/*     */     if (this.report.printHead.x == 0.0F)
/*     */       this.report.printHead.x = (float)this.indent * paramStylePage.getPageResolution() + this.hindent; 
/*     */     this.report.advanceLine = 0.0F;
/*     */     this.frame = this.report.printBox;
/*     */     checkElementAreas();
/*     */     return false;
/*     */   }
/*     */   
/*     */   protected void checkElementAreas() {
/*     */     PageArea[] arrayOfPageArea = (PageArea[])this.report.areamap.get(this.id);
/*     */     if (arrayOfPageArea != null) {
/*     */       this.report.npareas = arrayOfPageArea;
/*     */       this.report.npframes = this.report.getFrames(this.report.npareas);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reset() {
/*     */     this.frame = null;
/*     */     this.execed = false;
/*     */     this.script = null;
/*     */     this.onClickScript = null;
/*     */     this.scope = null;
/*     */   }
/*     */   
/*     */   public String getProperty(String paramString) { return (String)this.attrmap.get(paramString); }
/*     */   
/*     */   public void setProperty(String paramString1, String paramString2) {
/*     */     if (paramString2 == null) {
/*     */       this.attrmap.remove(paramString1);
/*     */     } else {
/*     */       this.attrmap.put(paramString1, paramString2);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Enumeration getPropertyNames() { return this.attrmap.keys(); }
/*     */   
/*     */   public Rectangle getFrame() { return this.frame; }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*     */     try {
/*     */       return getID().equals(((ReportElement)paramObject).getID());
/*     */     } catch (Exception exception) {
/*     */       return (this == paramObject);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setContext(ReportElement paramReportElement) {
/*     */     if (paramReportElement != null) {
/*     */       this.alignment = paramReportElement.getAlignment();
/*     */       this.indent = paramReportElement.getIndent();
/*     */       this.font = paramReportElement.getFont();
/*     */       this.foreground = paramReportElement.getForeground();
/*     */       this.background = paramReportElement.getBackground();
/*     */       this.spacing = paramReportElement.getSpacing();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setParent(Object paramObject) { this.parent = paramObject; }
/*     */   
/*     */   public Object getParent() { return this.parent; }
/*     */   
/*     */   public void setNonFlow(boolean paramBoolean) { this.nonflow = paramBoolean; }
/*     */   
/*     */   public void evaluate() {
/*     */     if (!this.execed && this.report != null && !this.report.designtime) {
/*     */       String str = getScript();
/*     */       this.execed = true;
/*     */       if (str != null) {
/*     */         ScriptEnv scriptEnv = this.report.getScriptEnv();
/*     */         if (this.script == null && scriptEnv != null)
/*     */           this.script = scriptEnv.compile(str); 
/*     */         if (this.script != null)
/*     */           scriptEnv.exec(this, this.script, this.scope); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object onClick() {
/*     */     String str = getOnClick();
/*     */     if (str != null && this.report != null && !this.report.designtime) {
/*     */       ScriptEnv scriptEnv = this.report.getScriptEnv();
/*     */       if (this.onClickScript == null) {
/*     */         this.onClickScript = scriptEnv.compile(str);
/*     */         if (this.onClickScript != null)
/*     */           return scriptEnv.exec(this, this.onClickScript, this.scope); 
/*     */       } 
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   public int hashCode() { return (getID() == null) ? super.hashCode() : getID().hashCode(); }
/*     */   
/*     */   public Object clone() {
/*     */     BaseElement baseElement = (BaseElement)super.clone();
/*     */     baseElement.attrmap = (Hashtable)this.attrmap.clone();
/*     */     return baseElement;
/*     */   }
/*     */   
/*     */   public String getType() { return ""; }
/*     */   
/*     */   public void setUserObject(Object paramObject) { this.userObj = paramObject; }
/*     */   
/*     */   public Object getUserObject() { return this.userObj; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\BaseElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */