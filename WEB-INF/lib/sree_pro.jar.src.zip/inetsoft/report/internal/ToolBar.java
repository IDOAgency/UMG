package inetsoft.report.internal;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Panel;

public class ToolBar extends Panel {
  public ToolBar() { setLayout(new FlowLayout(0, 0, 0)); }
  
  public static class Separator extends Component {
    public Dimension getPreferredSize() { return new Dimension(7, 25); }
    
    public Dimension getMaximumSize() { return new Dimension(7, 25); }
    
    public Dimension getMinimumSize() { return new Dimension(7, 25); }
    
    public void paint(Graphics param1Graphics) {
      param1Graphics.setColor(getBackground());
      Dimension dimension = getSize();
      param1Graphics.fill3DRect(3, 0, 2, dimension.height - 1, false);
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ToolBar.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */