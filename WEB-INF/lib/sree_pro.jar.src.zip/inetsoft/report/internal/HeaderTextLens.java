package inetsoft.report.internal;

import inetsoft.report.lens.DefaultTextLens;

public abstract class HeaderTextLens extends DefaultTextLens {
  public abstract String getDisplayText();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\HeaderTextLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */