/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.ChartLens;
/*     */ import inetsoft.report.ChartPainter;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.lens.AttributeChartLens;
/*     */ import inetsoft.report.lens.DefaultChartLens;
/*     */ import inetsoft.report.lens.TableChartLens;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChartXElement
/*     */   extends ChartElementDef
/*     */   implements Tabular
/*     */ {
/*     */   AttributeChartLens attr;
/*     */   DatasetAttr dataset;
/*     */   boolean embed;
/*     */   
/*  34 */   public ChartXElement(StyleSheet paramStyleSheet) { this(paramStyleSheet, 5); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChartXElement(StyleSheet paramStyleSheet, int paramInt) {
/*  42 */     super(paramStyleSheet, new AttributeChartLens(new DefaultChartLens(1, 6)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     this.embed = true;
/*     */     this.attr = (AttributeChartLens)getChart();
/*     */     this.attr.setStyle(paramInt);
/*     */   }
/*     */   
/*     */   public void setData(TableLens paramTableLens) { setChart(new TableChartLens(paramTableLens)); }
/*     */   
/*     */   public boolean isEmbedded() { return this.embed; }
/*     */   
/*     */   public void setEmbedded(boolean paramBoolean) { this.embed = paramBoolean; }
/*     */   
/*     */   public void setChart(ChartLens paramChartLens) {
/*     */     if (paramChartLens != this.attr)
/*     */       this.attr.setChart(paramChartLens); 
/*     */   }
/*     */   
/*     */   public void setDataset(DatasetAttr paramDatasetAttr) { this.dataset = paramDatasetAttr; }
/*     */   
/*     */   public DatasetAttr getDataset() { return this.dataset; }
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException {
/*     */     ChartXElement chartXElement = (ChartXElement)super.clone();
/*     */     chartXElement.chart = chartXElement.attr = (AttributeChartLens)this.attr.clone();
/*     */     chartXElement.setPainter(new ChartPainter(chartXElement.chart, chartXElement));
/*     */     return chartXElement;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ChartXElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */