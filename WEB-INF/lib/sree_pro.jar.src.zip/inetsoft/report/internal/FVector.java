package inetsoft.report.internal;

import java.util.Vector;

public class FVector extends Vector {
  public FVector() {}
  
  public FVector(int paramInt) { super(paramInt); }
  
  public Object getElement(int paramInt) { return this.elementData[paramInt]; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\FVector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */