package inetsoft.report.internal;

import inetsoft.report.TableLens;
import java.util.Hashtable;
import java.util.Vector;

public abstract class SummaryAttr extends FilterAttr {
  public void addGroupCol(String paramString) {
    if (this.groupCols.indexOf(paramString) < 0)
      this.groupCols.addElement(paramString); 
  }
  
  public void removeAllGroupCols() { this.groupCols.removeAllElements(); }
  
  public void removeGroupCol(String paramString) { this.groupCols.removeElement(paramString); }
  
  public String[] getGroupCols() {
    String[] arrayOfString = new String[this.groupCols.size()];
    this.groupCols.copyInto(arrayOfString);
    return arrayOfString;
  }
  
  public void addSummaryCol(String paramString) {
    if (this.sumCols.indexOf(paramString) < 0)
      this.sumCols.addElement(paramString); 
  }
  
  public void removeAllSummaryCols() { this.sumCols.removeAllElements(); }
  
  public void removeSummaryCol(String paramString) { this.sumCols.removeElement(paramString); }
  
  public String[] getSummaryCols() {
    String[] arrayOfString = new String[this.sumCols.size()];
    this.sumCols.copyInto(arrayOfString);
    return arrayOfString;
  }
  
  public void setOrder(String paramString, int paramInt) { this.ordermap.put(paramString, new Integer(paramInt)); }
  
  public int getOrder(String paramString) {
    Integer integer = (Integer)this.ordermap.get(paramString);
    return (integer == null) ? 1 : integer.intValue();
  }
  
  public void setSorted(boolean paramBoolean) { this.sorted = paramBoolean; }
  
  public boolean isSorted() { return this.sorted; }
  
  public void setFormula(String paramString1, String paramString2) {
    if (paramString2 == null) {
      this.formulamap.remove(paramString1);
    } else {
      this.formulamap.put(paramString1, paramString2);
    } 
  }
  
  public String getFormula(String paramString) { return (String)this.formulamap.get(paramString); }
  
  String toString(String[] paramArrayOfString) {
    StringBuffer stringBuffer = new StringBuffer("[");
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      if (b)
        stringBuffer.append(","); 
      stringBuffer.append(paramArrayOfString[b]);
    } 
    stringBuffer.append("]");
    return stringBuffer.toString();
  }
  
  String toString(TableLens paramTableLens) {
    if (paramTableLens == null)
      return "[]"; 
    StringBuffer stringBuffer = new StringBuffer("[");
    for (byte b = 0; b < paramTableLens.getColCount(); b++) {
      if (b)
        stringBuffer.append(","); 
      stringBuffer.append(paramTableLens.getObject(0, b));
    } 
    stringBuffer.append("]");
    return stringBuffer.toString();
  }
  
  protected Vector groupCols = new Vector();
  
  protected Vector sumCols = new Vector();
  
  protected Hashtable ordermap = new Hashtable();
  
  protected boolean sorted = false;
  
  protected Hashtable formulamap = new Hashtable();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SummaryAttr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */