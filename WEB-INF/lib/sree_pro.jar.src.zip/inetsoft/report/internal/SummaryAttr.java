/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SummaryAttr
/*     */   extends FilterAttr
/*     */ {
/*     */   public void addGroupCol(String paramString) {
/*  35 */     if (this.groupCols.indexOf(paramString) < 0) {
/*  36 */       this.groupCols.addElement(paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   public void removeAllGroupCols() { this.groupCols.removeAllElements(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public void removeGroupCol(String paramString) { this.groupCols.removeElement(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getGroupCols() {
/*  58 */     String[] arrayOfString = new String[this.groupCols.size()];
/*  59 */     this.groupCols.copyInto(arrayOfString);
/*  60 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSummaryCol(String paramString) {
/*  67 */     if (this.sumCols.indexOf(paramString) < 0) {
/*  68 */       this.sumCols.addElement(paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public void removeAllSummaryCols() { this.sumCols.removeAllElements(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public void removeSummaryCol(String paramString) { this.sumCols.removeElement(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getSummaryCols() {
/*  90 */     String[] arrayOfString = new String[this.sumCols.size()];
/*  91 */     this.sumCols.copyInto(arrayOfString);
/*  92 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public void setOrder(String paramString, int paramInt) { this.ordermap.put(paramString, new Integer(paramInt)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder(String paramString) {
/* 106 */     Integer integer = (Integer)this.ordermap.get(paramString);
/* 107 */     return (integer == null) ? 1 : integer.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public void setSorted(boolean paramBoolean) { this.sorted = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public boolean isSorted() { return this.sorted; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormula(String paramString1, String paramString2) {
/* 128 */     if (paramString2 == null) {
/* 129 */       this.formulamap.remove(paramString1);
/*     */     } else {
/*     */       
/* 132 */       this.formulamap.put(paramString1, paramString2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public String getFormula(String paramString) { return (String)this.formulamap.get(paramString); }
/*     */ 
/*     */ 
/*     */   
/*     */   String toString(String[] paramArrayOfString) {
/* 145 */     StringBuffer stringBuffer = new StringBuffer("[");
/* 146 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 147 */       if (b) {
/* 148 */         stringBuffer.append(",");
/*     */       }
/*     */       
/* 151 */       stringBuffer.append(paramArrayOfString[b]);
/*     */     } 
/*     */     
/* 154 */     stringBuffer.append("]");
/* 155 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   String toString(TableLens paramTableLens) {
/* 160 */     if (paramTableLens == null) {
/* 161 */       return "[]";
/*     */     }
/*     */     
/* 164 */     StringBuffer stringBuffer = new StringBuffer("[");
/* 165 */     for (byte b = 0; b < paramTableLens.getColCount(); b++) {
/* 166 */       if (b) {
/* 167 */         stringBuffer.append(",");
/*     */       }
/*     */       
/* 170 */       stringBuffer.append(paramTableLens.getObject(0, b));
/*     */     } 
/*     */     
/* 173 */     stringBuffer.append("]");
/* 174 */     return stringBuffer.toString();
/*     */   }
/*     */   
/* 177 */   protected Vector groupCols = new Vector();
/* 178 */   protected Vector sumCols = new Vector();
/* 179 */   protected Hashtable ordermap = new Hashtable();
/*     */   protected boolean sorted = false;
/* 181 */   protected Hashtable formulamap = new Hashtable();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SummaryAttr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */