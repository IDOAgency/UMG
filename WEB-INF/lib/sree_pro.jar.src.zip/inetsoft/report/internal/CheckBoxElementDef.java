/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.CheckBoxElement;
/*     */ import inetsoft.report.Painter;
/*     */ import inetsoft.report.StyleSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CheckBoxElementDef
/*     */   extends FieldElementDef
/*     */   implements CheckBoxElement
/*     */ {
/*     */   CheckBoxPainter painter;
/*     */   
/*     */   public CheckBoxElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3, boolean paramBoolean, double paramDouble1, double paramDouble2) {
/*  35 */     super(paramStyleSheet, paramString1, paramString2, paramDouble1, paramDouble2);
/*  36 */     this.painter.setText(paramString3);
/*  37 */     this.painter.setSelected(paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public CheckBoxElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3, boolean paramBoolean) { this(paramStyleSheet, paramString1, paramString2, paramString3, paramBoolean, 0.0D, 0.0D); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   protected FieldPainter createPainter() { return this.painter = new CheckBoxPainter(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public String getText() { return this.painter.getText(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public void setText(String paramString) { this.painter.setText(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public boolean isSelected() { return this.painter.isSelected(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public void setSelected(boolean paramBoolean) { this.painter.setSelected(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPainter(Painter paramPainter) {
/*  88 */     super.setPainter(paramPainter);
/*  89 */     this.painter = (CheckBoxPainter)paramPainter;
/*     */   }
/*     */ 
/*     */   
/*  93 */   public String getType() { return "CheckBox"; }
/*     */ 
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException {
/*  97 */     CheckBoxElementDef checkBoxElementDef = (CheckBoxElementDef)super.clone();
/*  98 */     checkBoxElementDef.setPainter(new CheckBoxPainter(checkBoxElementDef));
/*  99 */     checkBoxElementDef.setText(this.painter.getText());
/* 100 */     checkBoxElementDef.setSelected(this.painter.isSelected());
/* 101 */     return checkBoxElementDef;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\CheckBoxElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */