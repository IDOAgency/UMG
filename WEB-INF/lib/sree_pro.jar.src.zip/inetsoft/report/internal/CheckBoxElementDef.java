package inetsoft.report.internal;

import inetsoft.report.CheckBoxElement;
import inetsoft.report.Painter;
import inetsoft.report.StyleSheet;

public class CheckBoxElementDef extends FieldElementDef implements CheckBoxElement {
  CheckBoxPainter painter;
  
  public CheckBoxElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3, boolean paramBoolean, double paramDouble1, double paramDouble2) {
    super(paramStyleSheet, paramString1, paramString2, paramDouble1, paramDouble2);
    this.painter.setText(paramString3);
    this.painter.setSelected(paramBoolean);
  }
  
  public CheckBoxElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3, boolean paramBoolean) { this(paramStyleSheet, paramString1, paramString2, paramString3, paramBoolean, 0.0D, 0.0D); }
  
  protected FieldPainter createPainter() { return this.painter = new CheckBoxPainter(this); }
  
  public String getText() { return this.painter.getText(); }
  
  public void setText(String paramString) { this.painter.setText(paramString); }
  
  public boolean isSelected() { return this.painter.isSelected(); }
  
  public void setSelected(boolean paramBoolean) { this.painter.setSelected(paramBoolean); }
  
  public void setPainter(Painter paramPainter) {
    super.setPainter(paramPainter);
    this.painter = (CheckBoxPainter)paramPainter;
  }
  
  public String getType() { return "CheckBox"; }
  
  public Object clone() throws CloneNotSupportedException {
    CheckBoxElementDef checkBoxElementDef = (CheckBoxElementDef)super.clone();
    checkBoxElementDef.setPainter(new CheckBoxPainter(checkBoxElementDef));
    checkBoxElementDef.setText(this.painter.getText());
    checkBoxElementDef.setSelected(this.painter.isSelected());
    return checkBoxElementDef;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\CheckBoxElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */