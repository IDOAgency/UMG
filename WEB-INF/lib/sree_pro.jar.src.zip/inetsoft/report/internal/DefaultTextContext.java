/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.ReportElement;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultTextContext
/*    */   extends DefaultContext
/*    */   implements TextContext
/*    */ {
/* 32 */   public int getLevel() { return this.heading; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   public void setLevel(int paramInt) { this.heading = paramInt; }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void write(ObjectOutputStream paramObjectOutputStream, ReportElement paramReportElement) throws IOException {
/* 44 */     DefaultContext.write(paramObjectOutputStream, paramReportElement);
/*    */     
/* 46 */     if (paramReportElement instanceof TextContext) {
/* 47 */       paramObjectOutputStream.writeInt(((TextContext)paramReportElement).getLevel());
/*    */     } else {
/*    */       
/* 50 */       paramObjectOutputStream.writeInt(-1);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void read(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/* 57 */     super.read(paramObjectInputStream);
/* 58 */     this.heading = paramObjectInputStream.readInt();
/*    */   }
/*    */   
/* 61 */   int heading = -1;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\DefaultTextContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */