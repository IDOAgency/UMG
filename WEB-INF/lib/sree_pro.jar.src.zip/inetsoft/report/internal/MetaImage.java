package inetsoft.report.internal;

import inetsoft.report.Common;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.File;
import java.net.URL;

public class MetaImage extends Image {
  private int width;
  
  private int height;
  
  private String resource;
  
  private File file;
  
  private URL url;
  
  private Image image;
  
  public MetaImage(String paramString) {
    this.width = -1;
    this.height = -1;
    this.resource = paramString;
  }
  
  public MetaImage(File paramFile) {
    this.width = -1;
    this.height = -1;
    this.file = paramFile;
  }
  
  public MetaImage(URL paramURL) {
    this.width = -1;
    this.height = -1;
    this.url = paramURL;
  }
  
  public void setWidth(int paramInt) { this.width = paramInt; }
  
  public int getWidth(ImageObserver paramImageObserver) { return (this.width >= 0) ? this.width : getImage().getWidth(paramImageObserver); }
  
  public void setHeight(int paramInt) { this.height = paramInt; }
  
  public int getHeight(ImageObserver paramImageObserver) { return (this.height >= 0) ? this.height : getImage().getHeight(paramImageObserver); }
  
  public ImageProducer getSource() { return getImage().getSource(); }
  
  public Graphics getGraphics() { return getImage().getGraphics(); }
  
  public Object getProperty(String paramString, ImageObserver paramImageObserver) { return getImage().getProperty(paramString, paramImageObserver); }
  
  public void flush() {
    if (this.image != null)
      this.image.flush(); 
  }
  
  public Image getImage() {
    if (this.image != null)
      return this.image; 
    Toolkit toolkit = Common.getToolkit();
    if (this.resource != null) {
      this.image = Common.getImage(this, this.resource);
    } else if (this.url != null) {
      try {
        ImageProducer imageProducer = (ImageProducer)this.url.getContent();
        this.image = Common.getToolkit().createImage(imageProducer);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } else if (this.file != null && this.file.exists()) {
      this.image = toolkit.createImage(this.file.getPath());
    } 
    Common.waitForImage(this.image);
    return this.image;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\MetaImage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */