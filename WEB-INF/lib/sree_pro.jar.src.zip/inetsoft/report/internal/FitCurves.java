package inetsoft.report.internal;

import java.util.Vector;

public class FitCurves {
  public static class Point2 {
    public double x;
    
    public double y;
    
    public Point2(double param1Double1, double param1Double2) { this.x = param1Double1;
      this.y = param1Double2; }
    
    public Point2 dup() { return new Point2(this.x, this.y); }
    
    public String toString() { return "(" + this.x + "," + this.y + ")"; }
  }
  
  public FitCurves(Point2[] paramArrayOfPoint2, double paramDouble) {
    int i = paramArrayOfPoint2.length;
    Point2 point21 = ComputeLeftTangent(paramArrayOfPoint2, 0);
    Point2 point22 = ComputeRightTangent(paramArrayOfPoint2, i - 1);
    FitCubic(paramArrayOfPoint2, 0, i - 1, point21, point22, paramDouble);
  }
  
  public Vector getCurves() { return this.curves; }
  
  void FitCubic(Point2[] paramArrayOfPoint2, int paramInt1, int paramInt2, Point2 paramPoint21, Point2 paramPoint22, double paramDouble) {
    int[] arrayOfInt = { 0 };
    byte b = 4;
    double d2 = paramDouble * paramDouble;
    int i = paramInt2 - paramInt1 + 1;
    if (i == 2) {
      double d = V2DistanceBetween2Points(paramArrayOfPoint2[paramInt2], paramArrayOfPoint2[paramInt1]) / 3.0D;
      Point2[] arrayOfPoint21 = new Point2[4];
      alloc(arrayOfPoint21);
      arrayOfPoint21[0] = paramArrayOfPoint2[paramInt1];
      arrayOfPoint21[3] = paramArrayOfPoint2[paramInt2];
      V2Add(arrayOfPoint21[0], V2Scale(paramPoint21, d), arrayOfPoint21[1]);
      V2Add(arrayOfPoint21[3], V2Scale(paramPoint22, d), arrayOfPoint21[2]);
      DrawBezierCurve(arrayOfPoint21);
      return;
    } 
    double[] arrayOfDouble = ChordLengthParameterize(paramArrayOfPoint2, paramInt1, paramInt2);
    Point2[] arrayOfPoint2 = GenerateBezier(paramArrayOfPoint2, paramInt1, paramInt2, arrayOfDouble, paramPoint21, paramPoint22);
    double d1 = ComputeMaxError(paramArrayOfPoint2, paramInt1, paramInt2, arrayOfPoint2, arrayOfDouble, arrayOfInt);
    if (d1 < paramDouble) {
      DrawBezierCurve(arrayOfPoint2);
      return;
    } 
    if (d1 < d2)
      for (byte b1 = 0; b1 < b; b1++) {
        double[] arrayOfDouble1 = Reparameterize(paramArrayOfPoint2, paramInt1, paramInt2, arrayOfDouble, arrayOfPoint2);
        arrayOfPoint2 = GenerateBezier(paramArrayOfPoint2, paramInt1, paramInt2, arrayOfDouble1, paramPoint21, paramPoint22);
        d1 = ComputeMaxError(paramArrayOfPoint2, paramInt1, paramInt2, arrayOfPoint2, arrayOfDouble1, arrayOfInt);
        if (d1 < paramDouble) {
          DrawBezierCurve(arrayOfPoint2);
          return;
        } 
        arrayOfDouble = arrayOfDouble1;
      }  
    Point2 point2 = ComputeCenterTangent(paramArrayOfPoint2, arrayOfInt[0]);
    FitCubic(paramArrayOfPoint2, paramInt1, arrayOfInt[0], paramPoint21, point2, paramDouble);
    V2Negate(point2);
    FitCubic(paramArrayOfPoint2, arrayOfInt[0], paramInt2, point2, paramPoint22, paramDouble);
  }
  
  static Point2[] GenerateBezier(Point2[] paramArrayOfPoint2, int paramInt1, int paramInt2, double[] paramArrayOfDouble, Point2 paramPoint21, Point2 paramPoint22) {
    int j = paramInt2 - paramInt1 + 1;
    Point2[][] arrayOfPoint2 = new Point2[j][2];
    double[][] arrayOfDouble = new double[2][2];
    double[] arrayOfDouble1 = new double[2];
    Point2[] arrayOfPoint21 = new Point2[4];
    alloc(arrayOfPoint21);
    j = paramInt2 - paramInt1 + 1;
    int i;
    for (i = 0; i < j; i++) {
      Point2 point21 = paramPoint21.dup();
      Point2 point22 = paramPoint22.dup();
      V2Scale(point21, B1(paramArrayOfDouble[i]));
      V2Scale(point22, B2(paramArrayOfDouble[i]));
      arrayOfPoint2[i][0] = point21;
      arrayOfPoint2[i][1] = point22;
    } 
    arrayOfDouble[0][0] = 0.0D;
    arrayOfDouble[0][1] = 0.0D;
    arrayOfDouble[1][0] = 0.0D;
    arrayOfDouble[1][1] = 0.0D;
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble1[1] = 0.0D;
    for (i = 0; i < j; i++) {
      arrayOfDouble[0][0] = arrayOfDouble[0][0] + V2Dot(arrayOfPoint2[i][0], arrayOfPoint2[i][0]);
      arrayOfDouble[0][1] = arrayOfDouble[0][1] + V2Dot(arrayOfPoint2[i][0], arrayOfPoint2[i][1]);
      arrayOfDouble[1][0] = arrayOfDouble[0][1];
      arrayOfDouble[1][1] = arrayOfDouble[1][1] + V2Dot(arrayOfPoint2[i][1], arrayOfPoint2[i][1]);
      Point2 point2 = V2SubII(paramArrayOfPoint2[paramInt1 + i], V2AddII(V2ScaleIII(paramArrayOfPoint2[paramInt1], B0(paramArrayOfDouble[i])), V2AddII(V2ScaleIII(paramArrayOfPoint2[paramInt1], B1(paramArrayOfDouble[i])), V2AddII(V2ScaleIII(paramArrayOfPoint2[paramInt2], B2(paramArrayOfDouble[i])), V2ScaleIII(paramArrayOfPoint2[paramInt2], B3(paramArrayOfDouble[i]))))));
      arrayOfDouble1[0] = arrayOfDouble1[0] + V2Dot(arrayOfPoint2[i][0], point2);
      arrayOfDouble1[1] = arrayOfDouble1[1] + V2Dot(arrayOfPoint2[i][1], point2);
    } 
    double d1 = arrayOfDouble[0][0] * arrayOfDouble[1][1] - arrayOfDouble[1][0] * arrayOfDouble[0][1];
    double d2 = arrayOfDouble[0][0] * arrayOfDouble1[1] - arrayOfDouble[0][1] * arrayOfDouble1[0];
    double d3 = arrayOfDouble1[0] * arrayOfDouble[1][1] - arrayOfDouble1[1] * arrayOfDouble[0][1];
    if (d1 == 0.0D)
      d1 = arrayOfDouble[0][0] * arrayOfDouble[1][1] * 1.0E-11D; 
    double d4 = d3 / d1;
    double d5 = d2 / d1;
    if (d4 < 1.0E-6D || d5 < 1.0E-6D) {
      double d = V2DistanceBetween2Points(paramArrayOfPoint2[paramInt2], paramArrayOfPoint2[paramInt1]) / 3.0D;
      arrayOfPoint21[0] = paramArrayOfPoint2[paramInt1];
      arrayOfPoint21[3] = paramArrayOfPoint2[paramInt2];
      V2Add(arrayOfPoint21[0], V2Scale(paramPoint21, d), arrayOfPoint21[1]);
      V2Add(arrayOfPoint21[3], V2Scale(paramPoint22, d), arrayOfPoint21[2]);
      return arrayOfPoint21;
    } 
    arrayOfPoint21[0] = paramArrayOfPoint2[paramInt1];
    arrayOfPoint21[3] = paramArrayOfPoint2[paramInt2];
    V2Add(arrayOfPoint21[0], V2Scale(paramPoint21, d4), arrayOfPoint21[1]);
    V2Add(arrayOfPoint21[3], V2Scale(paramPoint22, d5), arrayOfPoint21[2]);
    return arrayOfPoint21;
  }
  
  static double[] Reparameterize(Point2[] paramArrayOfPoint21, int paramInt1, int paramInt2, double[] paramArrayOfDouble, Point2[] paramArrayOfPoint22) {
    int i = paramInt2 - paramInt1 + 1;
    double[] arrayOfDouble = new double[i];
    for (int j = paramInt1; j <= paramInt2; j++)
      arrayOfDouble[j - paramInt1] = NewtonRaphsonRootFind(paramArrayOfPoint22, paramArrayOfPoint21[j], paramArrayOfDouble[j - paramInt1]); 
    return arrayOfDouble;
  }
  
  static double NewtonRaphsonRootFind(Point2[] paramArrayOfPoint2, Point2 paramPoint2, double paramDouble) {
    Point2[] arrayOfPoint21 = new Point2[3], arrayOfPoint22 = new Point2[2];
    Point2 point21 = BezierII(3, paramArrayOfPoint2, paramDouble);
    byte b;
    for (b = 0; b <= 2; b++)
      arrayOfPoint21[b] = new Point2(((paramArrayOfPoint2[b + true]).x - (paramArrayOfPoint2[b]).x) * 3.0D, ((paramArrayOfPoint2[b + true]).y - (paramArrayOfPoint2[b]).y) * 3.0D); 
    for (b = 0; b <= 1; b++)
      arrayOfPoint22[b] = new Point2(((arrayOfPoint21[b + 1]).x - (arrayOfPoint21[b]).x) * 2.0D, ((arrayOfPoint21[b + 1]).y - (arrayOfPoint21[b]).y) * 2.0D); 
    Point2 point22 = BezierII(2, arrayOfPoint21, paramDouble);
    Point2 point23 = BezierII(1, arrayOfPoint22, paramDouble);
    double d1 = (point21.x - paramPoint2.x) * point22.x + (point21.y - paramPoint2.y) * point22.y;
    double d2 = point22.x * point22.x + point22.y * point22.y + (point21.x - paramPoint2.x) * point23.x + (point21.y - paramPoint2.y) * point23.y;
    return paramDouble - d1 / d2;
  }
  
  static Point2 BezierII(int paramInt, Point2[] paramArrayOfPoint2, double paramDouble) {
    Point2[] arrayOfPoint2 = new Point2[paramInt + 1];
    int i;
    for (i = 0; i <= paramInt; i++)
      arrayOfPoint2[i] = paramArrayOfPoint2[i].dup(); 
    for (i = 1; i <= paramInt; i++) {
      for (byte b = 0; b <= paramInt - i; b++) {
        (arrayOfPoint2[b]).x = (1.0D - paramDouble) * (arrayOfPoint2[b]).x + paramDouble * (arrayOfPoint2[b + true]).x;
        (arrayOfPoint2[b]).y = (1.0D - paramDouble) * (arrayOfPoint2[b]).y + paramDouble * (arrayOfPoint2[b + true]).y;
      } 
    } 
    return arrayOfPoint2[0];
  }
  
  static double B0(double paramDouble) {
    double d = 1.0D - paramDouble;
    return d * d * d;
  }
  
  static double B1(double paramDouble) {
    double d = 1.0D - paramDouble;
    return 3.0D * paramDouble * d * d;
  }
  
  static double B2(double paramDouble) {
    double d = 1.0D - paramDouble;
    return 3.0D * paramDouble * paramDouble * d;
  }
  
  static double B3(double paramDouble) { return paramDouble * paramDouble * paramDouble; }
  
  static Point2 ComputeLeftTangent(Point2[] paramArrayOfPoint2, int paramInt) {
    null = V2SubII(paramArrayOfPoint2[paramInt + 1], paramArrayOfPoint2[paramInt]);
    return V2Normalize(null);
  }
  
  static Point2 ComputeRightTangent(Point2[] paramArrayOfPoint2, int paramInt) {
    null = V2SubII(paramArrayOfPoint2[paramInt - 1], paramArrayOfPoint2[paramInt]);
    return V2Normalize(null);
  }
  
  static Point2 ComputeCenterTangent(Point2[] paramArrayOfPoint2, int paramInt) {
    Point2 point21 = V2SubII(paramArrayOfPoint2[paramInt - 1], paramArrayOfPoint2[paramInt]);
    Point2 point22 = V2SubII(paramArrayOfPoint2[paramInt], paramArrayOfPoint2[paramInt + 1]);
    null = new Point2((point21.x + point22.x) / 2.0D, (point21.y + point22.y) / 2.0D);
    return V2Normalize(null);
  }
  
  static double[] ChordLengthParameterize(Point2[] paramArrayOfPoint2, int paramInt1, int paramInt2) {
    double[] arrayOfDouble = new double[paramInt2 - paramInt1 + 1];
    arrayOfDouble[0] = 0.0D;
    int i;
    for (i = paramInt1 + 1; i <= paramInt2; i++)
      arrayOfDouble[i - paramInt1] = arrayOfDouble[i - paramInt1 - 1] + V2DistanceBetween2Points(paramArrayOfPoint2[i], paramArrayOfPoint2[i - 1]); 
    for (i = paramInt1 + 1; i <= paramInt2; i++)
      arrayOfDouble[i - paramInt1] = arrayOfDouble[i - paramInt1] / arrayOfDouble[paramInt2 - paramInt1]; 
    return arrayOfDouble;
  }
  
  static double ComputeMaxError(Point2[] paramArrayOfPoint21, int paramInt1, int paramInt2, Point2[] paramArrayOfPoint22, double[] paramArrayOfDouble, int[] paramArrayOfInt) {
    paramArrayOfInt[0] = (paramInt2 - paramInt1 + 1) / 2;
    double d = 0.0D;
    for (int i = paramInt1 + 1; i < paramInt2; i++) {
      Point2 point21 = BezierII(3, paramArrayOfPoint22, paramArrayOfDouble[i - paramInt1]);
      Point2 point22 = V2SubII(point21, paramArrayOfPoint21[i]);
      double d1 = V2SquaredLength(point22);
      if (d1 >= d) {
        d = d1;
        paramArrayOfInt[0] = i;
      } 
    } 
    return d;
  }
  
  static Point2 V2AddII(Point2 paramPoint21, Point2 paramPoint22) { return new Point2(paramPoint21.x + paramPoint22.x, paramPoint21.y + paramPoint22.y); }
  
  static Point2 V2ScaleIII(Point2 paramPoint2, double paramDouble) { return new Point2(paramPoint2.x * paramDouble, paramPoint2.y * paramDouble); }
  
  static Point2 V2SubII(Point2 paramPoint21, Point2 paramPoint22) { return new Point2(paramPoint21.x - paramPoint22.x, paramPoint21.y - paramPoint22.y); }
  
  static Point2 V2Scale(Point2 paramPoint2, double paramDouble) {
    double d = V2Length(paramPoint2);
    if (d != 0.0D) {
      paramPoint2.x *= paramDouble / d;
      paramPoint2.y *= paramDouble / d;
    } 
    return paramPoint2;
  }
  
  static Point2 V2Add(Point2 paramPoint21, Point2 paramPoint22, Point2 paramPoint23) {
    paramPoint21.x += paramPoint22.x;
    paramPoint21.y += paramPoint22.y;
    return paramPoint23;
  }
  
  static Point2 V2Negate(Point2 paramPoint2) {
    paramPoint2.x = -paramPoint2.x;
    paramPoint2.y = -paramPoint2.y;
    return paramPoint2;
  }
  
  static double V2Dot(Point2 paramPoint21, Point2 paramPoint22) { return paramPoint21.x * paramPoint22.x + paramPoint21.y * paramPoint22.y; }
  
  static Point2 V2Normalize(Point2 paramPoint2) {
    double d = V2Length(paramPoint2);
    if (d != 0.0D) {
      paramPoint2.x /= d;
      paramPoint2.y /= d;
    } 
    return paramPoint2;
  }
  
  static double V2DistanceBetween2Points(Point2 paramPoint21, Point2 paramPoint22) {
    double d1 = paramPoint21.x - paramPoint22.x;
    double d2 = paramPoint21.y - paramPoint22.y;
    return Math.sqrt(d1 * d1 + d2 * d2);
  }
  
  static double V2SquaredLength(Point2 paramPoint2) { return paramPoint2.x * paramPoint2.x + paramPoint2.y * paramPoint2.y; }
  
  static double V2Length(Point2 paramPoint2) { return Math.sqrt(V2SquaredLength(paramPoint2)); }
  
  static void alloc(Point2[] paramArrayOfPoint2) {
    for (byte b = 0; b < paramArrayOfPoint2.length; b++)
      paramArrayOfPoint2[b] = new Point2(0.0D, 0.0D); 
  }
  
  void DrawBezierCurve(Point2[] paramArrayOfPoint2) { this.curves.addElement(paramArrayOfPoint2); }
  
  public static void main(String[] paramArrayOfString) {
    Point2[] arrayOfPoint2 = { new Point2(0.0D, 0.0D), new Point2(0.0D, 0.5D), new Point2(1.1D, 1.4D), new Point2(2.1D, 1.6D), new Point2(3.2D, 1.1D), new Point2(4.0D, 0.2D), new Point2(4.0D, 0.0D) };
    double d = 4.0D;
    new FitCurves(arrayOfPoint2, d);
  }
  
  Vector curves = new Vector();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\FitCurves.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */