/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FitCurves
/*     */ {
/*     */   public static class Point2
/*     */   {
/*     */     public double x;
/*     */     public double y;
/*     */     
/*  33 */     public Point2(double param1Double1, double param1Double2) { this.x = param1Double1; this.y = param1Double2; }
/*     */ 
/*     */ 
/*     */     
/*  37 */     public Point2 dup() { return new Point2(this.x, this.y); }
/*     */ 
/*     */ 
/*     */     
/*  41 */     public String toString() { return "(" + this.x + "," + this.y + ")"; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FitCurves(Point2[] paramArrayOfPoint2, double paramDouble) {
/*  56 */     int i = paramArrayOfPoint2.length;
/*     */     
/*  58 */     Point2 point21 = ComputeLeftTangent(paramArrayOfPoint2, 0);
/*  59 */     Point2 point22 = ComputeRightTangent(paramArrayOfPoint2, i - 1);
/*  60 */     FitCubic(paramArrayOfPoint2, 0, i - 1, point21, point22, paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public Vector getCurves() { return this.curves; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void FitCubic(Point2[] paramArrayOfPoint2, int paramInt1, int paramInt2, Point2 paramPoint21, Point2 paramPoint22, double paramDouble) {
/*  86 */     int[] arrayOfInt = { 0 };
/*     */ 
/*     */     
/*  89 */     byte b = 4;
/*     */ 
/*     */ 
/*     */     
/*  93 */     double d2 = paramDouble * paramDouble;
/*  94 */     int i = paramInt2 - paramInt1 + 1;
/*     */ 
/*     */     
/*  97 */     if (i == 2) {
/*  98 */       double d = V2DistanceBetween2Points(paramArrayOfPoint2[paramInt2], paramArrayOfPoint2[paramInt1]) / 3.0D;
/*     */       
/* 100 */       Point2[] arrayOfPoint21 = new Point2[4];
/* 101 */       alloc(arrayOfPoint21);
/* 102 */       arrayOfPoint21[0] = paramArrayOfPoint2[paramInt1];
/* 103 */       arrayOfPoint21[3] = paramArrayOfPoint2[paramInt2];
/* 104 */       V2Add(arrayOfPoint21[0], V2Scale(paramPoint21, d), arrayOfPoint21[1]);
/* 105 */       V2Add(arrayOfPoint21[3], V2Scale(paramPoint22, d), arrayOfPoint21[2]);
/* 106 */       DrawBezierCurve(arrayOfPoint21);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 111 */     double[] arrayOfDouble = ChordLengthParameterize(paramArrayOfPoint2, paramInt1, paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     Point2[] arrayOfPoint2 = GenerateBezier(paramArrayOfPoint2, paramInt1, paramInt2, arrayOfDouble, paramPoint21, paramPoint22);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     double d1 = ComputeMaxError(paramArrayOfPoint2, paramInt1, paramInt2, arrayOfPoint2, arrayOfDouble, arrayOfInt);
/* 131 */     if (d1 < paramDouble) {
/* 132 */       DrawBezierCurve(arrayOfPoint2);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 138 */     if (d1 < d2) {
/* 139 */       for (byte b1 = 0; b1 < b; b1++) {
/* 140 */         double[] arrayOfDouble1 = Reparameterize(paramArrayOfPoint2, paramInt1, paramInt2, arrayOfDouble, arrayOfPoint2);
/* 141 */         arrayOfPoint2 = GenerateBezier(paramArrayOfPoint2, paramInt1, paramInt2, arrayOfDouble1, paramPoint21, paramPoint22);
/* 142 */         d1 = ComputeMaxError(paramArrayOfPoint2, paramInt1, paramInt2, arrayOfPoint2, arrayOfDouble1, arrayOfInt);
/*     */ 
/*     */         
/* 145 */         if (d1 < paramDouble) {
/* 146 */           DrawBezierCurve(arrayOfPoint2);
/*     */           return;
/*     */         } 
/* 149 */         arrayOfDouble = arrayOfDouble1;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 154 */     Point2 point2 = ComputeCenterTangent(paramArrayOfPoint2, arrayOfInt[0]);
/* 155 */     FitCubic(paramArrayOfPoint2, paramInt1, arrayOfInt[0], paramPoint21, point2, paramDouble);
/* 156 */     V2Negate(point2);
/* 157 */     FitCubic(paramArrayOfPoint2, arrayOfInt[0], paramInt2, point2, paramPoint22, paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Point2[] GenerateBezier(Point2[] paramArrayOfPoint2, int paramInt1, int paramInt2, double[] paramArrayOfDouble, Point2 paramPoint21, Point2 paramPoint22) {
/* 175 */     int j = paramInt2 - paramInt1 + 1;
/* 176 */     Point2[][] arrayOfPoint2 = new Point2[j][2];
/* 177 */     double[][] arrayOfDouble = new double[2][2];
/* 178 */     double[] arrayOfDouble1 = new double[2];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     Point2[] arrayOfPoint21 = new Point2[4];
/* 188 */     alloc(arrayOfPoint21);
/* 189 */     j = paramInt2 - paramInt1 + 1;
/*     */     
/*     */     int i;
/* 192 */     for (i = 0; i < j; i++) {
/*     */       
/* 194 */       Point2 point21 = paramPoint21.dup();
/* 195 */       Point2 point22 = paramPoint22.dup();
/* 196 */       V2Scale(point21, B1(paramArrayOfDouble[i]));
/* 197 */       V2Scale(point22, B2(paramArrayOfDouble[i]));
/* 198 */       arrayOfPoint2[i][0] = point21;
/* 199 */       arrayOfPoint2[i][1] = point22;
/*     */     } 
/*     */ 
/*     */     
/* 203 */     arrayOfDouble[0][0] = 0.0D;
/* 204 */     arrayOfDouble[0][1] = 0.0D;
/* 205 */     arrayOfDouble[1][0] = 0.0D;
/* 206 */     arrayOfDouble[1][1] = 0.0D;
/* 207 */     arrayOfDouble1[0] = 0.0D;
/* 208 */     arrayOfDouble1[1] = 0.0D;
/*     */     
/* 210 */     for (i = 0; i < j; i++) {
/* 211 */       arrayOfDouble[0][0] = arrayOfDouble[0][0] + V2Dot(arrayOfPoint2[i][0], arrayOfPoint2[i][0]);
/* 212 */       arrayOfDouble[0][1] = arrayOfDouble[0][1] + V2Dot(arrayOfPoint2[i][0], arrayOfPoint2[i][1]);
/* 213 */       arrayOfDouble[1][0] = arrayOfDouble[0][1];
/* 214 */       arrayOfDouble[1][1] = arrayOfDouble[1][1] + V2Dot(arrayOfPoint2[i][1], arrayOfPoint2[i][1]);
/*     */       
/* 216 */       Point2 point2 = V2SubII(paramArrayOfPoint2[paramInt1 + i], V2AddII(V2ScaleIII(paramArrayOfPoint2[paramInt1], B0(paramArrayOfDouble[i])), V2AddII(V2ScaleIII(paramArrayOfPoint2[paramInt1], B1(paramArrayOfDouble[i])), V2AddII(V2ScaleIII(paramArrayOfPoint2[paramInt2], B2(paramArrayOfDouble[i])), V2ScaleIII(paramArrayOfPoint2[paramInt2], B3(paramArrayOfDouble[i]))))));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 225 */       arrayOfDouble1[0] = arrayOfDouble1[0] + V2Dot(arrayOfPoint2[i][0], point2);
/* 226 */       arrayOfDouble1[1] = arrayOfDouble1[1] + V2Dot(arrayOfPoint2[i][1], point2);
/*     */     } 
/*     */ 
/*     */     
/* 230 */     double d1 = arrayOfDouble[0][0] * arrayOfDouble[1][1] - arrayOfDouble[1][0] * arrayOfDouble[0][1];
/* 231 */     double d2 = arrayOfDouble[0][0] * arrayOfDouble1[1] - arrayOfDouble[0][1] * arrayOfDouble1[0];
/* 232 */     double d3 = arrayOfDouble1[0] * arrayOfDouble[1][1] - arrayOfDouble1[1] * arrayOfDouble[0][1];
/*     */ 
/*     */     
/* 235 */     if (d1 == 0.0D) {
/* 236 */       d1 = arrayOfDouble[0][0] * arrayOfDouble[1][1] * 1.0E-11D;
/*     */     }
/* 238 */     double d4 = d3 / d1;
/* 239 */     double d5 = d2 / d1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 244 */     if (d4 < 1.0E-6D || d5 < 1.0E-6D) {
/* 245 */       double d = V2DistanceBetween2Points(paramArrayOfPoint2[paramInt2], paramArrayOfPoint2[paramInt1]) / 3.0D;
/*     */       
/* 247 */       arrayOfPoint21[0] = paramArrayOfPoint2[paramInt1];
/* 248 */       arrayOfPoint21[3] = paramArrayOfPoint2[paramInt2];
/* 249 */       V2Add(arrayOfPoint21[0], V2Scale(paramPoint21, d), arrayOfPoint21[1]);
/* 250 */       V2Add(arrayOfPoint21[3], V2Scale(paramPoint22, d), arrayOfPoint21[2]);
/* 251 */       return arrayOfPoint21;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 258 */     arrayOfPoint21[0] = paramArrayOfPoint2[paramInt1];
/* 259 */     arrayOfPoint21[3] = paramArrayOfPoint2[paramInt2];
/* 260 */     V2Add(arrayOfPoint21[0], V2Scale(paramPoint21, d4), arrayOfPoint21[1]);
/* 261 */     V2Add(arrayOfPoint21[3], V2Scale(paramPoint22, d5), arrayOfPoint21[2]);
/* 262 */     return arrayOfPoint21;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static double[] Reparameterize(Point2[] paramArrayOfPoint21, int paramInt1, int paramInt2, double[] paramArrayOfDouble, Point2[] paramArrayOfPoint22) {
/* 279 */     int i = paramInt2 - paramInt1 + 1;
/*     */ 
/*     */ 
/*     */     
/* 283 */     double[] arrayOfDouble = new double[i];
/* 284 */     for (int j = paramInt1; j <= paramInt2; j++) {
/* 285 */       arrayOfDouble[j - paramInt1] = NewtonRaphsonRootFind(paramArrayOfPoint22, paramArrayOfPoint21[j], paramArrayOfDouble[j - paramInt1]);
/*     */     }
/* 287 */     return arrayOfDouble;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static double NewtonRaphsonRootFind(Point2[] paramArrayOfPoint2, Point2 paramPoint2, double paramDouble) {
/* 300 */     Point2[] arrayOfPoint21 = new Point2[3], arrayOfPoint22 = new Point2[2];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 306 */     Point2 point21 = BezierII(3, paramArrayOfPoint2, paramDouble);
/*     */     
/*     */     byte b;
/* 309 */     for (b = 0; b <= 2; b++) {
/* 310 */       arrayOfPoint21[b] = new Point2(((paramArrayOfPoint2[b + true]).x - (paramArrayOfPoint2[b]).x) * 3.0D, ((paramArrayOfPoint2[b + true]).y - (paramArrayOfPoint2[b]).y) * 3.0D);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 315 */     for (b = 0; b <= 1; b++) {
/* 316 */       arrayOfPoint22[b] = new Point2(((arrayOfPoint21[b + 1]).x - (arrayOfPoint21[b]).x) * 2.0D, ((arrayOfPoint21[b + 1]).y - (arrayOfPoint21[b]).y) * 2.0D);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 321 */     Point2 point22 = BezierII(2, arrayOfPoint21, paramDouble);
/* 322 */     Point2 point23 = BezierII(1, arrayOfPoint22, paramDouble);
/*     */ 
/*     */     
/* 325 */     double d1 = (point21.x - paramPoint2.x) * point22.x + (point21.y - paramPoint2.y) * point22.y;
/* 326 */     double d2 = point22.x * point22.x + point22.y * point22.y + (point21.x - paramPoint2.x) * point23.x + (point21.y - paramPoint2.y) * point23.y;
/*     */ 
/*     */ 
/*     */     
/* 330 */     return paramDouble - d1 / d2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Point2 BezierII(int paramInt, Point2[] paramArrayOfPoint2, double paramDouble) {
/* 347 */     Point2[] arrayOfPoint2 = new Point2[paramInt + 1]; int i;
/* 348 */     for (i = 0; i <= paramInt; i++) {
/* 349 */       arrayOfPoint2[i] = paramArrayOfPoint2[i].dup();
/*     */     }
/*     */ 
/*     */     
/* 353 */     for (i = 1; i <= paramInt; i++) {
/* 354 */       for (byte b = 0; b <= paramInt - i; b++) {
/* 355 */         (arrayOfPoint2[b]).x = (1.0D - paramDouble) * (arrayOfPoint2[b]).x + paramDouble * (arrayOfPoint2[b + true]).x;
/* 356 */         (arrayOfPoint2[b]).y = (1.0D - paramDouble) * (arrayOfPoint2[b]).y + paramDouble * (arrayOfPoint2[b + true]).y;
/*     */       } 
/*     */     } 
/*     */     
/* 360 */     return arrayOfPoint2[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static double B0(double paramDouble) {
/* 370 */     double d = 1.0D - paramDouble;
/* 371 */     return d * d * d;
/*     */   }
/*     */ 
/*     */   
/*     */   static double B1(double paramDouble) {
/* 376 */     double d = 1.0D - paramDouble;
/* 377 */     return 3.0D * paramDouble * d * d;
/*     */   }
/*     */   
/*     */   static double B2(double paramDouble) {
/* 381 */     double d = 1.0D - paramDouble;
/* 382 */     return 3.0D * paramDouble * paramDouble * d;
/*     */   }
/*     */ 
/*     */   
/* 386 */   static double B3(double paramDouble) { return paramDouble * paramDouble * paramDouble; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Point2 ComputeLeftTangent(Point2[] paramArrayOfPoint2, int paramInt) {
/* 397 */     null = V2SubII(paramArrayOfPoint2[paramInt + 1], paramArrayOfPoint2[paramInt]);
/* 398 */     return V2Normalize(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Point2 ComputeRightTangent(Point2[] paramArrayOfPoint2, int paramInt) {
/* 408 */     null = V2SubII(paramArrayOfPoint2[paramInt - 1], paramArrayOfPoint2[paramInt]);
/* 409 */     return V2Normalize(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Point2 ComputeCenterTangent(Point2[] paramArrayOfPoint2, int paramInt) {
/* 420 */     Point2 point21 = V2SubII(paramArrayOfPoint2[paramInt - 1], paramArrayOfPoint2[paramInt]);
/* 421 */     Point2 point22 = V2SubII(paramArrayOfPoint2[paramInt], paramArrayOfPoint2[paramInt + 1]);
/* 422 */     null = new Point2((point21.x + point22.x) / 2.0D, (point21.y + point22.y) / 2.0D);
/* 423 */     return V2Normalize(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static double[] ChordLengthParameterize(Point2[] paramArrayOfPoint2, int paramInt1, int paramInt2) {
/* 439 */     double[] arrayOfDouble = new double[paramInt2 - paramInt1 + 1];
/*     */     
/* 441 */     arrayOfDouble[0] = 0.0D; int i;
/* 442 */     for (i = paramInt1 + 1; i <= paramInt2; i++) {
/* 443 */       arrayOfDouble[i - paramInt1] = arrayOfDouble[i - paramInt1 - 1] + V2DistanceBetween2Points(paramArrayOfPoint2[i], paramArrayOfPoint2[i - 1]);
/*     */     }
/*     */ 
/*     */     
/* 447 */     for (i = paramInt1 + 1; i <= paramInt2; i++) {
/* 448 */       arrayOfDouble[i - paramInt1] = arrayOfDouble[i - paramInt1] / arrayOfDouble[paramInt2 - paramInt1];
/*     */     }
/*     */     
/* 451 */     return arrayOfDouble;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static double ComputeMaxError(Point2[] paramArrayOfPoint21, int paramInt1, int paramInt2, Point2[] paramArrayOfPoint22, double[] paramArrayOfDouble, int[] paramArrayOfInt) {
/* 474 */     paramArrayOfInt[0] = (paramInt2 - paramInt1 + 1) / 2;
/* 475 */     double d = 0.0D;
/* 476 */     for (int i = paramInt1 + 1; i < paramInt2; i++) {
/* 477 */       Point2 point21 = BezierII(3, paramArrayOfPoint22, paramArrayOfDouble[i - paramInt1]);
/* 478 */       Point2 point22 = V2SubII(point21, paramArrayOfPoint21[i]);
/* 479 */       double d1 = V2SquaredLength(point22);
/* 480 */       if (d1 >= d) {
/* 481 */         d = d1;
/* 482 */         paramArrayOfInt[0] = i;
/*     */       } 
/*     */     } 
/* 485 */     return d;
/*     */   }
/*     */ 
/*     */   
/* 489 */   static Point2 V2AddII(Point2 paramPoint21, Point2 paramPoint22) { return new Point2(paramPoint21.x + paramPoint22.x, paramPoint21.y + paramPoint22.y); }
/*     */ 
/*     */ 
/*     */   
/* 493 */   static Point2 V2ScaleIII(Point2 paramPoint2, double paramDouble) { return new Point2(paramPoint2.x * paramDouble, paramPoint2.y * paramDouble); }
/*     */ 
/*     */ 
/*     */   
/* 497 */   static Point2 V2SubII(Point2 paramPoint21, Point2 paramPoint22) { return new Point2(paramPoint21.x - paramPoint22.x, paramPoint21.y - paramPoint22.y); }
/*     */ 
/*     */ 
/*     */   
/*     */   static Point2 V2Scale(Point2 paramPoint2, double paramDouble) {
/* 502 */     double d = V2Length(paramPoint2);
/* 503 */     if (d != 0.0D) { paramPoint2.x *= paramDouble / d; paramPoint2.y *= paramDouble / d; }
/* 504 */      return paramPoint2;
/*     */   }
/*     */ 
/*     */   
/*     */   static Point2 V2Add(Point2 paramPoint21, Point2 paramPoint22, Point2 paramPoint23) {
/* 509 */     paramPoint21.x += paramPoint22.x; paramPoint21.y += paramPoint22.y;
/* 510 */     return paramPoint23;
/*     */   }
/*     */ 
/*     */   
/*     */   static Point2 V2Negate(Point2 paramPoint2) {
/* 515 */     paramPoint2.x = -paramPoint2.x; paramPoint2.y = -paramPoint2.y;
/* 516 */     return paramPoint2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 521 */   static double V2Dot(Point2 paramPoint21, Point2 paramPoint22) { return paramPoint21.x * paramPoint22.x + paramPoint21.y * paramPoint22.y; }
/*     */ 
/*     */ 
/*     */   
/*     */   static Point2 V2Normalize(Point2 paramPoint2) {
/* 526 */     double d = V2Length(paramPoint2);
/* 527 */     if (d != 0.0D) { paramPoint2.x /= d; paramPoint2.y /= d; }
/* 528 */      return paramPoint2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static double V2DistanceBetween2Points(Point2 paramPoint21, Point2 paramPoint22) {
/* 534 */     double d1 = paramPoint21.x - paramPoint22.x;
/* 535 */     double d2 = paramPoint21.y - paramPoint22.y;
/* 536 */     return Math.sqrt(d1 * d1 + d2 * d2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 541 */   static double V2SquaredLength(Point2 paramPoint2) { return paramPoint2.x * paramPoint2.x + paramPoint2.y * paramPoint2.y; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 546 */   static double V2Length(Point2 paramPoint2) { return Math.sqrt(V2SquaredLength(paramPoint2)); }
/*     */ 
/*     */   
/*     */   static void alloc(Point2[] paramArrayOfPoint2) {
/* 550 */     for (byte b = 0; b < paramArrayOfPoint2.length; b++) {
/* 551 */       paramArrayOfPoint2[b] = new Point2(0.0D, 0.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 562 */   void DrawBezierCurve(Point2[] paramArrayOfPoint2) { this.curves.addElement(paramArrayOfPoint2); }
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 566 */     Point2[] arrayOfPoint2 = { new Point2(0.0D, 0.0D), new Point2(0.0D, 0.5D), new Point2(1.1D, 1.4D), new Point2(2.1D, 1.6D), new Point2(3.2D, 1.1D), new Point2(4.0D, 0.2D), new Point2(4.0D, 0.0D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 575 */     double d = 4.0D;
/*     */     
/* 577 */     new FitCurves(arrayOfPoint2, d);
/*     */   }
/*     */   
/* 580 */   Vector curves = new Vector();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\FitCurves.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */