package inetsoft.report.internal;

import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import inetsoft.report.filter.DefaultSortedTable;
import inetsoft.report.filter.Formula;
import inetsoft.report.filter.SortFilter;
import inetsoft.report.filter.SummaryFilter;
import inetsoft.report.lens.RotatedTableLens;
import inetsoft.report.lens.SubTableLens;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;

public class DatasetAttr extends SummaryAttr {
  public TableFilter createFilter(TableLens paramTableLens) {
    RotatedTableLens rotatedTableLens;
    String[] arrayOfString1 = getGroupCols();
    String[] arrayOfString2 = getSummaryCols();
    int[] arrayOfInt1 = findColumns(paramTableLens, arrayOfString1);
    int[] arrayOfInt2 = findColumns(paramTableLens, arrayOfString2);
    if (arrayOfInt1 != null && arrayOfInt1.length > 0 && arrayOfInt2 != null && arrayOfInt2.length > 0) {
      SortFilter sortFilter = null;
      if (isSorted()) {
        sortFilter = new DefaultSortedTable(paramTableLens, arrayOfInt1);
      } else {
        boolean[] arrayOfBoolean = new boolean[arrayOfInt1.length];
        for (byte b1 = 0; b1 < arrayOfBoolean.length; b1++)
          arrayOfBoolean[b1] = (getOrder(arrayOfString1[b1]) != 2); 
        sortFilter = new SortFilter(paramTableLens, arrayOfInt1, arrayOfBoolean);
      } 
      boolean bool = true;
      Formula[] arrayOfFormula = new Formula[arrayOfInt2.length];
      for (byte b = 0; b < arrayOfFormula.length; b++) {
        String str = getFormula(arrayOfString2[b]);
        if (str != null) {
          bool = false;
          arrayOfFormula[b] = createFormula(str);
        } 
      } 
      if (bool) {
        rotatedTableLens = sortFilter;
      } else {
        rotatedTableLens = new SummaryFilter(sortFilter, arrayOfInt2, arrayOfFormula, null);
      } 
    } else {
      rotatedTableLens = paramTableLens;
    } 
    if (this.labelCol != null) {
      int i = findColumn(rotatedTableLens, this.labelCol);
      if (i >= 0) {
        int[] arrayOfInt = new int[rotatedTableLens.getColCount()];
        for (byte b = 0; b < arrayOfInt.length; b++) {
          if (!b) {
            arrayOfInt[b] = i;
          } else {
            arrayOfInt[b] = (b < i) ? (b + true) : b;
          } 
        } 
        rotatedTableLens = new SubTableLens(this, rotatedTableLens, null, arrayOfInt) {
            private final DatasetAttr this$0;
            
            public int getHeaderColCount() { return 1; }
          };
      } 
    } 
    if (!this.rowMajor)
      rotatedTableLens = new RotatedTableLens(rotatedTableLens); 
    return !(rotatedTableLens instanceof TableFilter) ? new SubTableLens(rotatedTableLens, null, null) : (TableFilter)rotatedTableLens;
  }
  
  public void setLabelColumn(String paramString) { this.labelCol = paramString; }
  
  public String getLabelColumn() { return this.labelCol; }
  
  public void setLabelDateFormat(String paramString) { this.labelFmt = paramString; }
  
  public String getLabelDateFormat() { return this.labelFmt; }
  
  public Format getLabelFormat() { return (this.labelFmt != null) ? ((this.labelFmt.length() > 0) ? new SimpleDateFormat(this.labelFmt) : DateFormat.getDateInstance()) : null; }
  
  public void setRowMajor(boolean paramBoolean) { this.rowMajor = paramBoolean; }
  
  public boolean isRowMajor() { return this.rowMajor; }
  
  public void writeXML(PrintWriter paramPrintWriter) {
    paramPrintWriter.println("<filter type=\"dataset\">");
    paramPrintWriter.print("<dataset sorted=\"" + this.sorted + "\" rowMajor=\"" + this.rowMajor + "\"");
    if (this.labelCol != null)
      paramPrintWriter.print(" labelCol=\"" + this.labelCol + "\""); 
    if (this.labelFmt != null)
      paramPrintWriter.print(" labelFormat=\"" + this.labelFmt + "\""); 
    paramPrintWriter.println(">");
    for (byte b1 = 0; b1 < this.groupCols.size(); b1++) {
      String str = (String)this.groupCols.elementAt(b1);
      paramPrintWriter.print("<groupCol order=\"" + getOrder(str) + "\">");
      paramPrintWriter.println("<![CDATA[" + str + "]]></groupCol>");
    } 
    for (byte b2 = 0; b2 < this.sumCols.size(); b2++) {
      String str1 = (String)this.sumCols.elementAt(b2);
      String str2 = getFormula(str1);
      paramPrintWriter.print("<sumCol");
      if (str2 != null)
        paramPrintWriter.print(" formula=\"" + str2 + "\""); 
      paramPrintWriter.println("><![CDATA[" + str1 + "]]></sumCol>");
    } 
    paramPrintWriter.println("</dataset>");
    paramPrintWriter.println("</filter>");
  }
  
  public void parseXML(XMLTokenStream paramXMLTokenStream) throws IOException, XMLException {
    XMLTokenStream.Tag tag = (XMLTokenStream.Tag)paramXMLTokenStream.getToken();
    if (tag.is("dataset")) {
      int i = -1;
      String str2 = null;
      String str1;
      if ((str1 = tag.get("order")) != null)
        i = Integer.parseInt(str1); 
      if ((str1 = tag.get("sorted")) != null)
        this.sorted = str1.equalsIgnoreCase("true"); 
      if ((str1 = tag.get("rowMajor")) != null)
        this.rowMajor = str1.equalsIgnoreCase("true"); 
      str2 = tag.get("formula");
      this.labelCol = tag.get("labelCol");
      this.labelFmt = tag.get("labelFormat");
      Object object;
      while ((object = paramXMLTokenStream.getToken()) != null) {
        if (!(object instanceof XMLTokenStream.Tag))
          continue; 
        XMLTokenStream.Tag tag1 = (XMLTokenStream.Tag)object;
        if (tag1.is("/dataset"))
          break; 
        if (tag1.is("groupCol")) {
          String str = (String)paramXMLTokenStream.getToken();
          int j = i;
          if ((str1 = tag1.get("order")) != null)
            j = Integer.parseInt(str1); 
          addGroupCol(str);
          setOrder(str, j);
          continue;
        } 
        if (tag1.is("sumCol")) {
          String str3 = (String)paramXMLTokenStream.getToken();
          String str4 = str2;
          if ((str1 = tag1.get("order")) != null)
            str4 = str1; 
          addSummaryCol(str3);
          setFormula(str3, str4);
        } 
      } 
    } 
  }
  
  private String labelCol = null;
  
  private String labelFmt = null;
  
  private boolean rowMajor = false;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\DatasetAttr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */