/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.TableFilter;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.filter.DefaultSortedTable;
/*     */ import inetsoft.report.filter.Formula;
/*     */ import inetsoft.report.filter.SortFilter;
/*     */ import inetsoft.report.filter.SummaryFilter;
/*     */ import inetsoft.report.lens.RotatedTableLens;
/*     */ import inetsoft.report.lens.SubTableLens;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.text.DateFormat;
/*     */ import java.text.Format;
/*     */ import java.text.SimpleDateFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatasetAttr
/*     */   extends SummaryAttr
/*     */ {
/*     */   public TableFilter createFilter(TableLens paramTableLens) {
/*     */     RotatedTableLens rotatedTableLens;
/*  32 */     String[] arrayOfString1 = getGroupCols();
/*  33 */     String[] arrayOfString2 = getSummaryCols();
/*  34 */     int[] arrayOfInt1 = findColumns(paramTableLens, arrayOfString1);
/*  35 */     int[] arrayOfInt2 = findColumns(paramTableLens, arrayOfString2);
/*     */ 
/*     */     
/*  38 */     if (arrayOfInt1 != null && arrayOfInt1.length > 0 && arrayOfInt2 != null && arrayOfInt2.length > 0) {
/*     */       
/*  40 */       SortFilter sortFilter = null;
/*  41 */       if (isSorted()) {
/*  42 */         sortFilter = new DefaultSortedTable(paramTableLens, arrayOfInt1);
/*     */       } else {
/*     */         
/*  45 */         boolean[] arrayOfBoolean = new boolean[arrayOfInt1.length];
/*  46 */         for (byte b1 = 0; b1 < arrayOfBoolean.length; b1++) {
/*  47 */           arrayOfBoolean[b1] = (getOrder(arrayOfString1[b1]) != 2);
/*     */         }
/*     */         
/*  50 */         sortFilter = new SortFilter(paramTableLens, arrayOfInt1, arrayOfBoolean);
/*     */       } 
/*     */       
/*  53 */       boolean bool = true;
/*  54 */       Formula[] arrayOfFormula = new Formula[arrayOfInt2.length];
/*     */ 
/*     */       
/*  57 */       for (byte b = 0; b < arrayOfFormula.length; b++) {
/*  58 */         String str = getFormula(arrayOfString2[b]);
/*  59 */         if (str != null) {
/*  60 */           bool = false;
/*  61 */           arrayOfFormula[b] = createFormula(str);
/*     */         } 
/*     */       } 
/*     */       
/*  65 */       if (bool) {
/*  66 */         rotatedTableLens = sortFilter;
/*     */       } else {
/*     */         
/*  69 */         rotatedTableLens = new SummaryFilter(sortFilter, arrayOfInt2, arrayOfFormula, null);
/*     */       } 
/*     */     } else {
/*     */       
/*  73 */       rotatedTableLens = paramTableLens;
/*     */     } 
/*     */     
/*  76 */     if (this.labelCol != null) {
/*  77 */       int i = findColumn(rotatedTableLens, this.labelCol);
/*     */       
/*  79 */       if (i >= 0) {
/*  80 */         int[] arrayOfInt = new int[rotatedTableLens.getColCount()];
/*  81 */         for (byte b = 0; b < arrayOfInt.length; b++) {
/*  82 */           if (!b) {
/*  83 */             arrayOfInt[b] = i;
/*     */           } else {
/*     */             
/*  86 */             arrayOfInt[b] = (b < i) ? (b + true) : b;
/*     */           } 
/*     */         } 
/*     */         
/*  90 */         rotatedTableLens = new SubTableLens(this, rotatedTableLens, null, arrayOfInt)
/*     */           {
/*  92 */             public int getHeaderColCount() { return 1; }
/*     */             
/*     */             private final DatasetAttr this$0;
/*     */           };
/*     */       } 
/*     */     } 
/*  98 */     if (!this.rowMajor) {
/*  99 */       rotatedTableLens = new RotatedTableLens(rotatedTableLens);
/*     */     }
/*     */ 
/*     */     
/* 103 */     return !(rotatedTableLens instanceof TableFilter) ? new SubTableLens(rotatedTableLens, null, null) : (TableFilter)rotatedTableLens;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public void setLabelColumn(String paramString) { this.labelCol = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 113 */   public String getLabelColumn() { return this.labelCol; }
/*     */ 
/*     */ 
/*     */   
/* 117 */   public void setLabelDateFormat(String paramString) { this.labelFmt = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 121 */   public String getLabelDateFormat() { return this.labelFmt; }
/*     */ 
/*     */ 
/*     */   
/* 125 */   public Format getLabelFormat() { return (this.labelFmt != null) ? ((this.labelFmt.length() > 0) ? new SimpleDateFormat(this.labelFmt) : DateFormat.getDateInstance()) : null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public void setRowMajor(boolean paramBoolean) { this.rowMajor = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 135 */   public boolean isRowMajor() { return this.rowMajor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeXML(PrintWriter paramPrintWriter) {
/* 142 */     paramPrintWriter.println("<filter type=\"dataset\">");
/* 143 */     paramPrintWriter.print("<dataset sorted=\"" + this.sorted + "\" rowMajor=\"" + this.rowMajor + "\"");
/*     */ 
/*     */     
/* 146 */     if (this.labelCol != null) {
/* 147 */       paramPrintWriter.print(" labelCol=\"" + this.labelCol + "\"");
/*     */     }
/*     */     
/* 150 */     if (this.labelFmt != null) {
/* 151 */       paramPrintWriter.print(" labelFormat=\"" + this.labelFmt + "\"");
/*     */     }
/*     */     
/* 154 */     paramPrintWriter.println(">");
/*     */     
/* 156 */     for (byte b1 = 0; b1 < this.groupCols.size(); b1++) {
/* 157 */       String str = (String)this.groupCols.elementAt(b1);
/* 158 */       paramPrintWriter.print("<groupCol order=\"" + getOrder(str) + "\">");
/* 159 */       paramPrintWriter.println("<![CDATA[" + str + "]]></groupCol>");
/*     */     } 
/*     */     
/* 162 */     for (byte b2 = 0; b2 < this.sumCols.size(); b2++) {
/* 163 */       String str1 = (String)this.sumCols.elementAt(b2);
/* 164 */       String str2 = getFormula(str1);
/*     */       
/* 166 */       paramPrintWriter.print("<sumCol");
/* 167 */       if (str2 != null) {
/* 168 */         paramPrintWriter.print(" formula=\"" + str2 + "\"");
/*     */       }
/*     */       
/* 171 */       paramPrintWriter.println("><![CDATA[" + str1 + "]]></sumCol>");
/*     */     } 
/*     */     
/* 174 */     paramPrintWriter.println("</dataset>");
/* 175 */     paramPrintWriter.println("</filter>");
/*     */   }
/*     */   
/*     */   public void parseXML(XMLTokenStream paramXMLTokenStream) throws IOException, XMLException {
/* 179 */     XMLTokenStream.Tag tag = (XMLTokenStream.Tag)paramXMLTokenStream.getToken();
/* 180 */     if (tag.is("dataset")) {
/*     */       
/* 182 */       int i = -1;
/* 183 */       String str2 = null;
/*     */       String str1;
/* 185 */       if ((str1 = tag.get("order")) != null) {
/* 186 */         i = Integer.parseInt(str1);
/*     */       }
/*     */       
/* 189 */       if ((str1 = tag.get("sorted")) != null) {
/* 190 */         this.sorted = str1.equalsIgnoreCase("true");
/*     */       }
/*     */       
/* 193 */       if ((str1 = tag.get("rowMajor")) != null) {
/* 194 */         this.rowMajor = str1.equalsIgnoreCase("true");
/*     */       }
/*     */       
/* 197 */       str2 = tag.get("formula");
/* 198 */       this.labelCol = tag.get("labelCol");
/* 199 */       this.labelFmt = tag.get("labelFormat");
/*     */       
/*     */       Object object;
/* 202 */       while ((object = paramXMLTokenStream.getToken()) != null) {
/* 203 */         if (!(object instanceof XMLTokenStream.Tag)) {
/*     */           continue;
/*     */         }
/*     */         
/* 207 */         XMLTokenStream.Tag tag1 = (XMLTokenStream.Tag)object;
/* 208 */         if (tag1.is("/dataset")) {
/*     */           break;
/*     */         }
/* 211 */         if (tag1.is("groupCol")) {
/* 212 */           String str = (String)paramXMLTokenStream.getToken();
/* 213 */           int j = i;
/*     */           
/* 215 */           if ((str1 = tag1.get("order")) != null) {
/* 216 */             j = Integer.parseInt(str1);
/*     */           }
/*     */           
/* 219 */           addGroupCol(str);
/* 220 */           setOrder(str, j); continue;
/*     */         } 
/* 222 */         if (tag1.is("sumCol")) {
/* 223 */           String str3 = (String)paramXMLTokenStream.getToken();
/* 224 */           String str4 = str2;
/*     */           
/* 226 */           if ((str1 = tag1.get("order")) != null) {
/* 227 */             str4 = str1;
/*     */           }
/*     */           
/* 230 */           addSummaryCol(str3);
/* 231 */           setFormula(str3, str4);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/* 237 */   private String labelCol = null;
/* 238 */   private String labelFmt = null;
/*     */   private boolean rowMajor = false;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\DatasetAttr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */