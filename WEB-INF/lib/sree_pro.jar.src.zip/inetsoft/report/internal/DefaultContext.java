package inetsoft.report.internal;

import inetsoft.report.ReportElement;
import inetsoft.report.Size;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class DefaultContext implements ReportElement {
  String id;
  
  String type;
  
  int align;
  
  double ind;
  
  Font font;
  
  Color fg;
  
  Color bg;
  
  int spacing;
  
  boolean vis;
  
  Size size;
  
  boolean keep;
  
  String scmd;
  
  String onClickCmd;
  
  public String getID() { return this.id; }
  
  public String getType() { return this.type; }
  
  public int getAlignment() { return this.align; }
  
  public double getIndent() { return this.ind; }
  
  public Font getFont() { return this.font; }
  
  public Color getForeground() { return this.fg; }
  
  public Color getBackground() { return this.bg; }
  
  public int getSpacing() { return this.spacing; }
  
  public void setID(String paramString) { this.id = paramString; }
  
  public void setType(String paramString) { this.type = paramString; }
  
  public void setAlignment(int paramInt) { this.align = paramInt; }
  
  public void setIndent(double paramDouble) { this.ind = paramDouble; }
  
  public void setFont(Font paramFont) { this.font = paramFont; }
  
  public void setForeground(Color paramColor) { this.fg = paramColor; }
  
  public void setBackground(Color paramColor) { this.bg = paramColor; }
  
  public void setSpacing(int paramInt) { this.spacing = paramInt; }
  
  public boolean isVisible() { return this.vis; }
  
  public void setVisible(boolean paramBoolean) { this.vis = paramBoolean; }
  
  public boolean isKeepWithNext() { return this.keep; }
  
  public void setKeepWithNext(boolean paramBoolean) { this.keep = paramBoolean; }
  
  public String getScript() { return this.scmd; }
  
  public void setScript(String paramString) { this.scmd = paramString; }
  
  public String getOnClick() { return this.onClickCmd; }
  
  public void setOnClick(String paramString) { this.onClickCmd = paramString; }
  
  public Size getPreferredSize() { return this.size; }
  
  public void setContext(ReportElement paramReportElement) {}
  
  public String getProperty(String paramString) { return null; }
  
  public void setProperty(String paramString1, String paramString2) {}
  
  public Object clone() throws CloneNotSupportedException { return super.clone(); }
  
  public static void write(ObjectOutputStream paramObjectOutputStream, ReportElement paramReportElement) throws IOException {
    paramObjectOutputStream.writeObject(paramReportElement.getID());
    paramObjectOutputStream.writeObject(paramReportElement.getType());
    paramObjectOutputStream.writeInt(paramReportElement.getAlignment());
    paramObjectOutputStream.writeDouble(paramReportElement.getIndent());
    BasePaintable.writeFont(paramObjectOutputStream, paramReportElement.getFont());
    BasePaintable.writeColor(paramObjectOutputStream, paramReportElement.getForeground());
    BasePaintable.writeColor(paramObjectOutputStream, paramReportElement.getBackground());
    paramObjectOutputStream.writeInt(paramReportElement.getSpacing());
    paramObjectOutputStream.writeBoolean(paramReportElement.isVisible());
    paramObjectOutputStream.writeBoolean(paramReportElement.isKeepWithNext());
    paramObjectOutputStream.writeObject(paramReportElement.getPreferredSize());
    paramObjectOutputStream.writeObject(paramReportElement.getScript());
    paramObjectOutputStream.writeObject(paramReportElement.getOnClick());
  }
  
  public void read(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
    this.id = (String)paramObjectInputStream.readObject();
    this.type = (String)paramObjectInputStream.readObject();
    this.align = paramObjectInputStream.readInt();
    this.ind = paramObjectInputStream.readDouble();
    this.font = BasePaintable.readFont(paramObjectInputStream);
    this.fg = BasePaintable.readColor(paramObjectInputStream);
    this.bg = BasePaintable.readColor(paramObjectInputStream);
    this.spacing = paramObjectInputStream.readInt();
    this.vis = paramObjectInputStream.readBoolean();
    this.keep = paramObjectInputStream.readBoolean();
    this.size = (Size)paramObjectInputStream.readObject();
    this.scmd = (String)paramObjectInputStream.readObject();
    this.onClickCmd = (String)paramObjectInputStream.readObject();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\DefaultContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */