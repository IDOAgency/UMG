/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.Size;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultContext
/*     */   implements ReportElement
/*     */ {
/*     */   String id;
/*     */   String type;
/*     */   int align;
/*     */   double ind;
/*     */   Font font;
/*     */   Color fg;
/*     */   Color bg;
/*     */   int spacing;
/*     */   boolean vis;
/*     */   Size size;
/*     */   boolean keep;
/*     */   String scmd;
/*     */   String onClickCmd;
/*     */   
/*  32 */   public String getID() { return this.id; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   public String getType() { return this.type; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public int getAlignment() { return this.align; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public double getIndent() { return this.ind; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public Font getFont() { return this.font; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public Color getForeground() { return this.fg; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public Color getBackground() { return this.bg; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public int getSpacing() { return this.spacing; }
/*     */ 
/*     */ 
/*     */   
/*  85 */   public void setID(String paramString) { this.id = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  89 */   public void setType(String paramString) { this.type = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  93 */   public void setAlignment(int paramInt) { this.align = paramInt; }
/*     */ 
/*     */ 
/*     */   
/*  97 */   public void setIndent(double paramDouble) { this.ind = paramDouble; }
/*     */ 
/*     */ 
/*     */   
/* 101 */   public void setFont(Font paramFont) { this.font = paramFont; }
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void setForeground(Color paramColor) { this.fg = paramColor; }
/*     */ 
/*     */ 
/*     */   
/* 109 */   public void setBackground(Color paramColor) { this.bg = paramColor; }
/*     */ 
/*     */ 
/*     */   
/* 113 */   public void setSpacing(int paramInt) { this.spacing = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   public boolean isVisible() { return this.vis; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public void setVisible(boolean paramBoolean) { this.vis = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public boolean isKeepWithNext() { return this.keep; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public void setKeepWithNext(boolean paramBoolean) { this.keep = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public String getScript() { return this.scmd; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public void setScript(String paramString) { this.scmd = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public String getOnClick() { return this.onClickCmd; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public void setOnClick(String paramString) { this.onClickCmd = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 177 */   public Size getPreferredSize() { return this.size; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContext(ReportElement paramReportElement) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public String getProperty(String paramString) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String paramString1, String paramString2) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 207 */   public Object clone() throws CloneNotSupportedException { return super.clone(); }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void write(ObjectOutputStream paramObjectOutputStream, ReportElement paramReportElement) throws IOException {
/* 212 */     paramObjectOutputStream.writeObject(paramReportElement.getID());
/* 213 */     paramObjectOutputStream.writeObject(paramReportElement.getType());
/* 214 */     paramObjectOutputStream.writeInt(paramReportElement.getAlignment());
/* 215 */     paramObjectOutputStream.writeDouble(paramReportElement.getIndent());
/* 216 */     BasePaintable.writeFont(paramObjectOutputStream, paramReportElement.getFont());
/* 217 */     BasePaintable.writeColor(paramObjectOutputStream, paramReportElement.getForeground());
/* 218 */     BasePaintable.writeColor(paramObjectOutputStream, paramReportElement.getBackground());
/* 219 */     paramObjectOutputStream.writeInt(paramReportElement.getSpacing());
/* 220 */     paramObjectOutputStream.writeBoolean(paramReportElement.isVisible());
/* 221 */     paramObjectOutputStream.writeBoolean(paramReportElement.isKeepWithNext());
/* 222 */     paramObjectOutputStream.writeObject(paramReportElement.getPreferredSize());
/* 223 */     paramObjectOutputStream.writeObject(paramReportElement.getScript());
/* 224 */     paramObjectOutputStream.writeObject(paramReportElement.getOnClick());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void read(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/* 230 */     this.id = (String)paramObjectInputStream.readObject();
/* 231 */     this.type = (String)paramObjectInputStream.readObject();
/* 232 */     this.align = paramObjectInputStream.readInt();
/* 233 */     this.ind = paramObjectInputStream.readDouble();
/* 234 */     this.font = BasePaintable.readFont(paramObjectInputStream);
/* 235 */     this.fg = BasePaintable.readColor(paramObjectInputStream);
/* 236 */     this.bg = BasePaintable.readColor(paramObjectInputStream);
/* 237 */     this.spacing = paramObjectInputStream.readInt();
/* 238 */     this.vis = paramObjectInputStream.readBoolean();
/* 239 */     this.keep = paramObjectInputStream.readBoolean();
/* 240 */     this.size = (Size)paramObjectInputStream.readObject();
/* 241 */     this.scmd = (String)paramObjectInputStream.readObject();
/* 242 */     this.onClickCmd = (String)paramObjectInputStream.readObject();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\DefaultContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */