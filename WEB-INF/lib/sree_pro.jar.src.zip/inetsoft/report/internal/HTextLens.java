package inetsoft.report.internal;

import inetsoft.report.HeadingElement;
import inetsoft.report.StyleSheet;
import inetsoft.report.TextLens;

public class HTextLens implements TextLens {
  private HeadingElement heading;
  
  private StyleSheet report;
  
  public HTextLens(HeadingElement paramHeadingElement, StyleSheet paramStyleSheet) {
    this.heading = paramHeadingElement;
    this.report = paramStyleSheet;
  }
  
  public String getText() {
    Object object = this.report.headingMap.get(this.heading);
    return (object == null) ? "000" : object.toString();
  }
  
  public HeadingElement getHeadingElement() { return this.heading; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\HTextLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */