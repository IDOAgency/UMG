/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.HeadingElement;
/*    */ import inetsoft.report.StyleSheet;
/*    */ import inetsoft.report.TextLens;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTextLens
/*    */   implements TextLens
/*    */ {
/*    */   private HeadingElement heading;
/*    */   private StyleSheet report;
/*    */   
/*    */   public HTextLens(HeadingElement paramHeadingElement, StyleSheet paramStyleSheet) {
/* 27 */     this.heading = paramHeadingElement;
/* 28 */     this.report = paramStyleSheet;
/*    */   }
/*    */   
/*    */   public String getText() {
/* 32 */     Object object = this.report.headingMap.get(this.heading);
/* 33 */     return (object == null) ? "000" : object.toString();
/*    */   }
/*    */ 
/*    */   
/* 37 */   public HeadingElement getHeadingElement() { return this.heading; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\HTextLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */