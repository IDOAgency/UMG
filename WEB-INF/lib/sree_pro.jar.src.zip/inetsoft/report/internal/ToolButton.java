/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import java.awt.AWTEventMulticaster;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.MediaTracker;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToolButton
/*     */   extends Canvas
/*     */   implements MouseListener
/*     */ {
/*     */   public static final int LABEL_ONLY = 1;
/*     */   public static final int IMAGE_ONLY = 2;
/*     */   public static final int LABEL_IMAGE = 3;
/*     */   public static final int TOP = 1;
/*     */   public static final int LEFT = 2;
/*     */   public static final int BOTTOM = 3;
/*     */   public static final int RIGHT = 4;
/*     */   protected ActionListener actionListener;
/*     */   int percent;
/*     */   int border;
/*     */   MediaTracker tracker;
/*     */   Image pressedButton;
/*     */   Image normalButton;
/*     */   Image plainButton;
/*     */   Dimension oSize;
/*     */   Point labelPos;
/*     */   Point imagePos;
/*     */   int gap;
/*     */   String label;
/*     */   int pos;
/*     */   Image image;
/*     */   Image image2;
/*     */   int style;
/*     */   Dimension iSize;
/*     */   boolean toggle;
/*     */   boolean state;
/*     */   Dimension pSize;
/*     */   boolean eventEnabled;
/*     */   int borderGap;
/*     */   boolean pointerIn;
/*     */   boolean inOnly;
/*     */   boolean mousePressed;
/*     */   
/*     */   public ToolButton() {
/* 578 */     this.percent = 50;
/* 579 */     this.border = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 589 */     this.tracker = new MediaTracker(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 685 */     this.pressedButton = null;
/* 686 */     this.normalButton = null;
/* 687 */     this.plainButton = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 698 */     this.oSize = new Dimension(0, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 855 */     this.labelPos = null;
/* 856 */     this.imagePos = null;
/* 857 */     this.gap = 2;
/* 858 */     this.label = null;
/* 859 */     this.pos = 3;
/*     */ 
/*     */     
/* 862 */     this.style = 3;
/* 863 */     this.iSize = null;
/* 864 */     this.toggle = false;
/* 865 */     this.state = false;
/* 866 */     this.pSize = null;
/* 867 */     this.eventEnabled = true;
/* 868 */     this.borderGap = 4;
/* 869 */     this.pointerIn = false;
/* 870 */     this.inOnly = true;
/* 871 */     this.mousePressed = false;
/*     */     addMouseListener(this);
/*     */     addKeyListener(new IbKeyListener(this, null));
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
/* 877 */     paramObjectInputStream.defaultReadObject();
/* 878 */     this.oSize = new Dimension(0, 0);
/*     */   }
/*     */   
/*     */   public ToolButton(String paramString1, String paramString2) {
/*     */     this();
/*     */     try {
/*     */       Image image1 = Common.getImage(null, paramString1);
/*     */       if (image1 == null) {
/*     */         setLabel(paramString2);
/*     */       } else {
/*     */         setImage(image1);
/*     */       } 
/*     */     } catch (Exception exception) {
/*     */       setLabel(paramString2);
/*     */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public ToolButton(Image paramImage) {
/*     */     this();
/*     */     setImage(paramImage);
/*     */   }
/*     */   
/*     */   public ToolButton(Image paramImage, int paramInt) {
/*     */     this(paramImage);
/*     */     this.border = paramInt;
/*     */   }
/*     */   
/*     */   public ToolButton(Image paramImage, String paramString) { this(paramImage, paramString, 3); }
/*     */   
/*     */   public ToolButton(Image paramImage, String paramString, int paramInt) {
/*     */     this(paramImage);
/*     */     setLabel(paramString, paramInt);
/*     */   }
/*     */   
/*     */   public void setToggle(boolean paramBoolean) { this.toggle = paramBoolean; }
/*     */   
/*     */   public boolean isToggle() { return this.toggle; }
/*     */   
/*     */   public void setState(boolean paramBoolean) {
/*     */     if (this.toggle) {
/*     */       this.mousePressed = this.state = paramBoolean;
/*     */       fire(new ActionEvent(this, 1001, this.label));
/*     */       repaint();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean getState() { return this.state; }
/*     */   
/*     */   public void setLabel(String paramString, int paramInt) {
/*     */     this.label = paramString;
/*     */     this.pos = paramInt;
/*     */     calcCoord();
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public void setLabel(String paramString) { setLabel(paramString, this.pos); }
/*     */   
/*     */   public String getLabel() { return this.label; }
/*     */   
/*     */   public void setLabelPos(int paramInt) { setLabel(this.label, paramInt); }
/*     */   
/*     */   public int getLabelPos() { return this.pos; }
/*     */   
/*     */   public void setDisplay(int paramInt) {
/*     */     this.style = paramInt;
/*     */     calcCoord();
/*     */   }
/*     */   
/*     */   public int getDisplay() { return this.style; }
/*     */   
/*     */   public void setBorder(int paramInt) {
/*     */     this.border = paramInt;
/*     */     calcCoord();
/*     */   }
/*     */   
/*     */   public int getBorder() { return this.border; }
/*     */   
/*     */   public void setShowOnEntry(boolean paramBoolean) {
/*     */     if (this.inOnly != paramBoolean) {
/*     */       this.inOnly = paramBoolean;
/*     */       repaint();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isShowOnEntry() { return this.inOnly; }
/*     */   
/*     */   public void setBorderGap(int paramInt) {
/*     */     this.borderGap = paramInt;
/*     */     calcCoord();
/*     */   }
/*     */   
/*     */   public int getBorderGap() { return this.borderGap; }
/*     */   
/*     */   public void setEnabled(boolean paramBoolean) {
/*     */     if (isEnabled() != paramBoolean) {
/*     */       super.setEnabled(paramBoolean);
/*     */       repaint();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setPreferredSize(Dimension paramDimension) {
/*     */     this.pSize = paramDimension;
/*     */     calcCoord();
/*     */   }
/*     */   
/*     */   public Dimension getMinimumSize() {
/*     */     if (this.pSize == null)
/*     */       this.pSize = calcSize(); 
/*     */     return this.pSize;
/*     */   }
/*     */   
/*     */   public Dimension getPreferredSize() {
/*     */     if (this.pSize == null)
/*     */       this.pSize = calcSize(); 
/*     */     return this.pSize;
/*     */   }
/*     */   
/*     */   public void setImage(Image paramImage) {
/*     */     if (paramImage != null) {
/*     */       this.image = paramImage;
/*     */       if (this.image.getWidth(null) <= 0) {
/*     */         this.tracker.addImage(this.image, 0);
/*     */         try {
/*     */           this.tracker.waitForID(0);
/*     */         } catch (Exception exception) {
/*     */           exception.printStackTrace();
/*     */         } 
/*     */       } 
/*     */       this.iSize = new Dimension(this.image.getWidth(null), this.image.getHeight(null));
/*     */       clearCache();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Image getImage() { return this.image; }
/*     */   
/*     */   public void setImage2(Image paramImage) {
/*     */     if (paramImage != null) {
/*     */       this.image2 = paramImage;
/*     */       if (this.image.getWidth(null) <= 0) {
/*     */         this.tracker.addImage(this.image, 0);
/*     */         try {
/*     */           this.tracker.waitForID(0);
/*     */         } catch (Exception exception) {
/*     */           exception.printStackTrace();
/*     */         } 
/*     */       } 
/*     */       clearCache();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Image getImage2() { return this.image2; }
/*     */   
/*     */   public void setForeground(Color paramColor) {
/*     */     clearCache();
/*     */     super.setForeground(paramColor);
/*     */   }
/*     */   
/*     */   public void setBackground(Color paramColor) {
/*     */     clearCache();
/*     */     super.setBackground(paramColor);
/*     */   }
/*     */   
/*     */   public void setFont(Font paramFont) {
/*     */     clearCache();
/*     */     super.setFont(paramFont);
/*     */   }
/*     */   
/*     */   public void addActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.add(this.actionListener, paramActionListener); }
/*     */   
/*     */   public void removeActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.remove(this.actionListener, paramActionListener); }
/*     */   
/*     */   private void fire(ActionEvent paramActionEvent) {
/*     */     if (this.actionListener != null)
/*     */       this.actionListener.actionPerformed(paramActionEvent); 
/*     */   }
/*     */   
/*     */   public boolean isFocusTraversable() { return true; }
/*     */   
/*     */   protected Dimension calcSize() {
/*     */     Dimension dimension1 = (this.image == null || (this.style & 0x2) == 0) ? new Dimension(2 * this.borderGap, 2 * this.borderGap) : new Dimension(this.image.getWidth(null) + 2 * this.borderGap, this.image.getHeight(null) + 2 * this.borderGap);
/*     */     Dimension dimension2 = dimension1;
/*     */     if (this.label == null || (this.style & true) == 0)
/*     */       return dimension2; 
/*     */     Font font = getFont();
/*     */     if (font != null) {
/*     */       FontMetrics fontMetrics = getFontMetrics(font);
/*     */       switch (this.pos) {
/*     */         case 1:
/*     */         case 3:
/*     */           dimension2.height += fontMetrics.getHeight() + this.gap + 3 * this.border;
/*     */           dimension2.width = Math.max(dimension2.width + 2 * this.border, fontMetrics.stringWidth(this.label) + 2) + 2 * this.border;
/*     */           break;
/*     */         case 2:
/*     */         case 4:
/*     */           dimension2.width += fontMetrics.stringWidth(this.label) + this.gap + 2 * this.border + 2;
/*     */           dimension2.height += 4 * this.border;
/*     */           break;
/*     */       } 
/*     */     } 
/*     */     return dimension2;
/*     */   }
/*     */   
/*     */   protected Rectangle getAreaBounds() { return new Rectangle(this.borderGap, this.borderGap, (getSize()).width - 2 * this.borderGap, (getSize()).height - 2 * this.borderGap); }
/*     */   
/*     */   void calcCoord() {
/*     */     if (this.label == null || (this.style & true) == 0) {
/*     */       this.imagePos = new Point(this.border + this.borderGap, this.border + this.borderGap);
/*     */       this.iSize = new Dimension((getSize()).width - 2 * this.border - 2 * this.borderGap, (getSize()).height - 2 * this.border - 2 * this.borderGap);
/*     */       return;
/*     */     } 
/*     */     Rectangle rectangle = getAreaBounds();
/*     */     Font font = getFont();
/*     */     if (font == null)
/*     */       return; 
/*     */     FontMetrics fontMetrics = getFontMetrics(font);
/*     */     int i = fontMetrics.getAscent();
/*     */     int j = fontMetrics.stringWidth(this.label);
/*     */     if (this.image == null || (this.style & 0x2) == 0) {
/*     */       this.labelPos = new Point((rectangle.width - j) / 2 + rectangle.x, (rectangle.height - fontMetrics.getHeight()) / 2 + i + rectangle.y);
/*     */     } else {
/*     */       switch (this.pos) {
/*     */         case 1:
/*     */         case 3:
/*     */           this.iSize = new Dimension(rectangle.width - 2 * (this.border + this.gap), rectangle.height - fontMetrics.getHeight() - this.gap - 2 * this.border);
/*     */           break;
/*     */         case 2:
/*     */         case 4:
/*     */           this.iSize = new Dimension(rectangle.width - j - 2 * (this.border + this.gap), rectangle.height - 2 * (this.border + this.gap));
/*     */           break;
/*     */       } 
/*     */       this.iSize.width = Math.min(this.iSize.width, this.iSize.height);
/*     */       this.iSize.height = this.iSize.width;
/*     */       switch (this.pos) {
/*     */         case 1:
/*     */           this.labelPos = new Point((rectangle.width - j) / 2, i + this.border);
/*     */           this.imagePos = new Point((rectangle.width - this.iSize.width) / 2, fontMetrics.getHeight() + this.border + this.gap);
/*     */           break;
/*     */         case 3:
/*     */           this.labelPos = new Point((rectangle.width - j) / 2, i + this.border + this.gap + this.iSize.height);
/*     */           this.imagePos = new Point((rectangle.width - this.iSize.width) / 2, 2 * this.border);
/*     */           break;
/*     */         case 2:
/*     */           this.labelPos = new Point(this.border, (rectangle.height - i) / 2 + i);
/*     */           this.imagePos = new Point(this.border + this.gap + j, (rectangle.height - this.iSize.height) / 2);
/*     */           break;
/*     */         case 4:
/*     */           this.imagePos = new Point(2 * this.border, (rectangle.height - this.iSize.height) / 2);
/*     */           this.labelPos = new Point(this.imagePos.x + this.gap + this.iSize.width, (rectangle.height - i) / 2 + i);
/*     */           break;
/*     */       } 
/*     */       this.labelPos.x += rectangle.x;
/*     */       this.labelPos.y += rectangle.y;
/*     */       this.imagePos.x += rectangle.x;
/*     */       this.imagePos.y += rectangle.y;
/*     */       clearCache();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void clearImages() { this.image = this.image2 = null; }
/*     */   
/*     */   protected Image makeImage(Image paramImage, boolean paramBoolean) { return makeImage(paramImage, paramBoolean, false); }
/*     */   
/*     */   protected Image makeImage(Image paramImage, boolean paramBoolean1, boolean paramBoolean2) {
/*     */     Dimension dimension = getSize();
/*     */     Image image1 = createImage(dimension.width, dimension.height);
/*     */     Graphics graphics = image1.getGraphics();
/*     */     graphics.setColor(getBackground());
/*     */     graphics.fillRect(0, 0, dimension.width, dimension.height);
/*     */     graphics.setColor(getForeground());
/*     */     graphics.setFont(getFont());
/*     */     Image image3 = paramImage;
/*     */     if ((this.label == null || (this.style & true) == 0) && paramImage != null && (this.style & 0x2) != 0) {
/*     */       graphics.drawImage(image3, this.imagePos.x, this.imagePos.y, this);
/*     */       try {
/*     */         this.tracker.addImage(image3, 0);
/*     */         this.tracker.waitForID(0);
/*     */       } catch (Exception exception) {}
/*     */       graphics.drawImage(image3, this.imagePos.x, this.imagePos.y, this);
/*     */     } else if (this.label != null && (this.style & true) != 0) {
/*     */       graphics.drawString(this.label, this.labelPos.x, this.labelPos.y);
/*     */       if (paramImage != null && (this.style & 0x2) != 0) {
/*     */         graphics.drawImage(image3, this.imagePos.x, this.imagePos.y, this);
/*     */         try {
/*     */           this.tracker.addImage(image3, 0);
/*     */           this.tracker.waitForID(0);
/*     */         } catch (Exception exception) {}
/*     */         graphics.drawImage(image3, this.imagePos.x, this.imagePos.y, this);
/*     */       } 
/*     */     } 
/*     */     if (!paramBoolean2) {
/*     */       graphics.setColor(getBackground());
/*     */       for (int i = 0; i < this.border; i++)
/*     */         graphics.draw3DRect(i, i, dimension.width - i * this.border - 1, dimension.height - i * this.border - 1, !paramBoolean1); 
/*     */     } 
/*     */     graphics.dispose();
/*     */     return image1;
/*     */   }
/*     */   
/*     */   void clearCache() {
/*     */     synchronized (this.oSize) {
/*     */       this.pressedButton = null;
/*     */       this.normalButton = null;
/*     */       this.plainButton = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paint(Graphics paramGraphics) {
/*     */     Dimension dimension = getSize();
/*     */     if (dimension.width != this.oSize.width || dimension.height != this.oSize.height) {
/*     */       this.oSize = dimension;
/*     */       clearCache();
/*     */       calcCoord();
/*     */     } 
/*     */     try {
/*     */       synchronized (this.oSize) {
/*     */         if (this.normalButton == null) {
/*     */           this.normalButton = makeImage(this.image, false, false);
/*     */           this.tracker.addImage(this.normalButton, 1);
/*     */           this.tracker.waitForID(1);
/*     */           this.pressedButton = makeImage((this.image2 == null) ? this.image : this.image2, true, false);
/*     */           this.tracker.addImage(this.pressedButton, 2);
/*     */           this.tracker.waitForID(2);
/*     */           this.plainButton = makeImage(this.image, true, true);
/*     */           this.tracker.addImage(this.plainButton, 3);
/*     */           this.tracker.waitForID(3);
/*     */         } 
/*     */         if ((this.tracker.statusAll(true) & 0x4) != 0) {
/*     */           paramGraphics.setColor(Color.red);
/*     */           paramGraphics.fillRect(0, 0, dimension.width, dimension.height);
/*     */           paramGraphics.drawString("Error loading image", 5, 5);
/*     */         } 
/*     */         Image image1 = this.mousePressed ? this.pressedButton : this.normalButton;
/*     */         image1 = (this.inOnly && !this.pointerIn) ? this.plainButton : image1;
/*     */         paramGraphics.drawImage(image1, 0, 0, this);
/*     */       } 
/*     */     } catch (Exception exception) {
/*     */       exception.printStackTrace();
/*     */       paramGraphics.drawImage(this.image, 0, 0, this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mousePressed(MouseEvent paramMouseEvent) {
/*     */     if (isEnabled() && isEventEnabled()) {
/*     */       if (this.toggle) {
/*     */         this.mousePressed = this.state = !this.state;
/*     */         fire(new ActionEvent(this, 1001, this.label));
/*     */       } else {
/*     */         this.mousePressed = true;
/*     */       } 
/*     */       repaint();
/*     */     } 
/*     */     requestFocus();
/*     */   }
/*     */   
/*     */   public void mouseExited(MouseEvent paramMouseEvent) {
/*     */     this.pointerIn = false;
/*     */     if (!this.toggle)
/*     */       this.mousePressed = false; 
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public void mouseReleased(MouseEvent paramMouseEvent) {
/*     */     if (isEnabled() && isEventEnabled() && !this.toggle && this.mousePressed) {
/*     */       fire(new ActionEvent(this, 1001, this.label));
/*     */       this.mousePressed = false;
/*     */     } 
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public void mouseEntered(MouseEvent paramMouseEvent) {
/*     */     this.pointerIn = true;
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public void mouseClicked(MouseEvent paramMouseEvent) {}
/*     */   
/*     */   Dimension getImageSize() { return this.iSize; }
/*     */   
/*     */   private class IbKeyListener extends KeyAdapter {
/*     */     private final ToolButton this$0;
/*     */     
/*     */     private IbKeyListener(ToolButton this$0) { this.this$0 = this$0; }
/*     */     
/*     */     public void keyPressed(KeyEvent param1KeyEvent) {
/*     */       if (param1KeyEvent.getKeyChar() == ' ')
/*     */         this.this$0.mousePressed(new MouseEvent(this.this$0, 501, 0L, 0, 0, 0, 0, false)); 
/*     */     }
/*     */     
/*     */     public void keyReleased(KeyEvent param1KeyEvent) { this.this$0.mouseReleased(new MouseEvent(this.this$0, 502, 0L, 0, 0, 0, 0, false)); }
/*     */   }
/*     */   
/*     */   protected void preSave() {}
/*     */   
/*     */   protected boolean isEventEnabled() { return this.eventEnabled; }
/*     */   
/*     */   protected void setEventEnabled(boolean paramBoolean) { this.eventEnabled = paramBoolean; }
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/*     */     preSave();
/*     */     paramObjectOutputStream.defaultWriteObject();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ToolButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */