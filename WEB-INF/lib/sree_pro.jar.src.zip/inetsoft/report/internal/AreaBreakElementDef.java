package inetsoft.report.internal;

import inetsoft.report.AreaBreakElement;
import inetsoft.report.Common;
import inetsoft.report.ReportElement;
import inetsoft.report.StylePage;
import inetsoft.report.StyleSheet;
import inetsoft.report.locale.Catalog;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;

public class AreaBreakElementDef extends BaseElement implements AreaBreakElement {
  protected String label;
  
  Font defFont;
  
  public AreaBreakElementDef(StyleSheet paramStyleSheet) {
    super(paramStyleSheet, true);
    this.label = Catalog.getString("Area Break");
    this.defFont = new Font("Serif", 0, 10);
  }
  
  public boolean isFlowControl() { return true; }
  
  public boolean print(StylePage paramStylePage) {
    if (!isVisible())
      return false; 
    super.print(paramStylePage);
    if (this.report.designtime)
      paramStylePage.addPaintable(new BasePaintable(this, this) {
            float x;
            
            float y;
            
            float w;
            
            float h;
            
            Rectangle box;
            
            private final AreaBreakElementDef this$0;
            
            public void paint(Graphics param1Graphics) {
              param1Graphics.setColor(Color.gray);
              float f1 = Common.stringWidth(this.this$0.label, this.this$0.defFont);
              float f2 = this.x + (this.w - f1) / 2.0F;
              float f3 = f2 + f1;
              Common.drawHLine(param1Graphics, this.y + this.h / 2.0F, this.x, f2, 4145, 0, 0);
              param1Graphics.setFont(this.this$0.defFont);
              Common.drawString(param1Graphics, this.this$0.label, f2, this.y + Common.getAscent(this.this$0.defFont));
              Common.drawHLine(param1Graphics, this.y + this.h / 2.0F, f3, this.x + this.w, 4145, 0, 0);
            }
            
            public Rectangle getBounds() { return this.box; }
            
            public void setLocation(Point param1Point) { this.x = param1Point.x;
              this.y = param1Point.y; }
          }); 
    return false;
  }
  
  public String toString() { return getID() + " [" + Catalog.getString(getType()) + "]"; }
  
  public String getType() { return "AreaBreak"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\AreaBreakElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */