/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Painter;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.TextBoxElement;
/*     */ import inetsoft.report.TextLens;
/*     */ import inetsoft.report.lens.DefaultTextLens;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.Insets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextBoxElementDef
/*     */   extends PainterElementDef
/*     */   implements TextBased, TextBoxElement
/*     */ {
/*     */   TextPainter painter;
/*     */   TextLens text;
/*     */   
/*     */   public TextBoxElementDef(StyleSheet paramStyleSheet, TextLens paramTextLens, double paramDouble1, double paramDouble2) {
/*  35 */     super(paramStyleSheet, null, paramDouble1, paramDouble2);
/*  36 */     setPainter(this.painter = new TextPainter(this));
/*  37 */     this.painter.setText(this.text = paramTextLens);
/*  38 */     this.painter.setPadding(paramStyleSheet.padding);
/*  39 */     this.painter.setJustify(paramStyleSheet.justify);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextBoxElementDef(StyleSheet paramStyleSheet, TextLens paramTextLens) {
/*  47 */     super(paramStyleSheet, null);
/*  48 */     setPainter(this.painter = new TextPainter(this));
/*  49 */     this.painter.setText(this.text = paramTextLens);
/*  50 */     this.painter.setPadding(paramStyleSheet.padding);
/*  51 */     this.painter.setJustify(paramStyleSheet.justify);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextBoxElementDef clone(String paramString) {
/*     */     try {
/*  60 */       TextBoxElementDef textBoxElementDef = (TextBoxElementDef)clone();
/*  61 */       textBoxElementDef.setText(paramString);
/*  62 */       return textBoxElementDef;
/*     */     } catch (Exception exception) {
/*  64 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public void setBorder(int paramInt) { this.painter.setBorder(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public int getBorder() { return this.painter.getBorder(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public void setBorders(Insets paramInsets) { this.painter.setBorders(paramInsets); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public Insets getBorders() { return this.painter.getBorders(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public void setShape(int paramInt) { this.painter.setShape(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public int getShape() { return this.painter.getShape(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   public Insets getPadding() { return this.painter.getPadding(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public void setPadding(Insets paramInsets) { this.painter.setPadding(paramInsets); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public boolean isJustify() { return this.painter.isJustify(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public void setJustify(boolean paramBoolean) { this.painter.setJustify(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public void setPainter(Painter paramPainter) { super.setPainter(this.painter = (TextPainter)paramPainter); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public String getText() { return this.text.getText(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public void setText(String paramString) { this.painter.setText(this.text = new DefaultTextLens(paramString)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public void setText(TextLens paramTextLens) { this.painter.setText(this.text = paramTextLens); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public TextLens getTextLens() { return this.text; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 187 */   public int getTextAlignment() { return this.painter.getTextAlignment(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public void setTextAlignment(int paramInt) { this.painter.setTextAlignment(paramInt); }
/*     */ 
/*     */ 
/*     */   
/* 198 */   public String toString() { return getID() + " [" + Catalog.getString(getType()) + "]"; }
/*     */ 
/*     */ 
/*     */   
/* 202 */   public String getType() { return "TextBox"; }
/*     */ 
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException {
/* 206 */     TextBoxElementDef textBoxElementDef = (TextBoxElementDef)super.clone();
/* 207 */     textBoxElementDef.setPainter(this.painter.clone(this.painter.getTextLens()));
/* 208 */     textBoxElementDef.setText(this.text);
/* 209 */     return textBoxElementDef;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TextBoxElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */