package inetsoft.report.internal;

import inetsoft.report.Painter;
import inetsoft.report.StyleSheet;
import inetsoft.report.TextBoxElement;
import inetsoft.report.TextLens;
import inetsoft.report.lens.DefaultTextLens;
import inetsoft.report.locale.Catalog;
import java.awt.Insets;

public class TextBoxElementDef extends PainterElementDef implements TextBased, TextBoxElement {
  TextPainter painter;
  
  TextLens text;
  
  public TextBoxElementDef(StyleSheet paramStyleSheet, TextLens paramTextLens, double paramDouble1, double paramDouble2) {
    super(paramStyleSheet, null, paramDouble1, paramDouble2);
    setPainter(this.painter = new TextPainter(this));
    this.painter.setText(this.text = paramTextLens);
    this.painter.setPadding(paramStyleSheet.padding);
    this.painter.setJustify(paramStyleSheet.justify);
  }
  
  public TextBoxElementDef(StyleSheet paramStyleSheet, TextLens paramTextLens) {
    super(paramStyleSheet, null);
    setPainter(this.painter = new TextPainter(this));
    this.painter.setText(this.text = paramTextLens);
    this.painter.setPadding(paramStyleSheet.padding);
    this.painter.setJustify(paramStyleSheet.justify);
  }
  
  public TextBoxElementDef clone(String paramString) {
    try {
      TextBoxElementDef textBoxElementDef = (TextBoxElementDef)clone();
      textBoxElementDef.setText(paramString);
      return textBoxElementDef;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public void setBorder(int paramInt) { this.painter.setBorder(paramInt); }
  
  public int getBorder() { return this.painter.getBorder(); }
  
  public void setBorders(Insets paramInsets) { this.painter.setBorders(paramInsets); }
  
  public Insets getBorders() { return this.painter.getBorders(); }
  
  public void setShape(int paramInt) { this.painter.setShape(paramInt); }
  
  public int getShape() { return this.painter.getShape(); }
  
  public Insets getPadding() { return this.painter.getPadding(); }
  
  public void setPadding(Insets paramInsets) { this.painter.setPadding(paramInsets); }
  
  public boolean isJustify() { return this.painter.isJustify(); }
  
  public void setJustify(boolean paramBoolean) { this.painter.setJustify(paramBoolean); }
  
  public void setPainter(Painter paramPainter) { super.setPainter(this.painter = (TextPainter)paramPainter); }
  
  public String getText() { return this.text.getText(); }
  
  public void setText(String paramString) { this.painter.setText(this.text = new DefaultTextLens(paramString)); }
  
  public void setText(TextLens paramTextLens) { this.painter.setText(this.text = paramTextLens); }
  
  public TextLens getTextLens() { return this.text; }
  
  public int getTextAlignment() { return this.painter.getTextAlignment(); }
  
  public void setTextAlignment(int paramInt) { this.painter.setTextAlignment(paramInt); }
  
  public String toString() { return getID() + " [" + Catalog.getString(getType()) + "]"; }
  
  public String getType() { return "TextBox"; }
  
  public Object clone() throws CloneNotSupportedException {
    TextBoxElementDef textBoxElementDef = (TextBoxElementDef)super.clone();
    textBoxElementDef.setPainter(this.painter.clone(this.painter.getTextLens()));
    textBoxElementDef.setText(this.text);
    return textBoxElementDef;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TextBoxElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */