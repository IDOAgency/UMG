package inetsoft.report.internal;

import inetsoft.report.Presenter;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;

public class TableAttr implements Serializable {
  public static final String BAR_PRESENTER = "BarPresenter";
  
  public static final String BAR2_PRESENTER = "Bar2Presenter";
  
  public static final String BOOLEAN_PRESENTER = "BooleanPresenter";
  
  public static final String BUTTON_PRESENTER = "ButtonPresenter";
  
  public static final String ICON_PRESENTER = "IconCounterPresenter";
  
  public static final String SHADOW_PRESENTER = "ShadowPresenter";
  
  public static final String DATE_FORMAT = "DateFormat";
  
  public static final String DECIMAL_FORMAT = "DecimalFormat";
  
  public static final String CURRENCY_FORMAT = "CurrencyFormat";
  
  public static final String PERCENT_FORMAT = "PercentFormat";
  
  public Integer alignment;
  
  public String format;
  
  public String format_spec;
  
  public String presenter;
  
  public Boolean linewrap;
  
  public Format getFormat() {
    if (this.format.equals("DateFormat"))
      return (this.format_spec != null) ? new SimpleDateFormat(this.format_spec) : new SimpleDateFormat("yyyy-MM-dd"); 
    if (this.format.equals("DecimalFormat"))
      return (this.format_spec != null) ? new DecimalFormat(this.format_spec) : NumberFormat.getInstance(); 
    if (this.format.equals("CurrencyFormat"))
      return NumberFormat.getCurrencyInstance(); 
    if (this.format.equals("PercentFormat"))
      return NumberFormat.getPercentInstance(); 
    return null;
  }
  
  public Presenter getPresenter() {
    try {
      return (Presenter)Class.forName("inetsoft.report.painter." + this.presenter).newInstance();
    } catch (Exception exception) {
      try {
        return (Presenter)Class.forName(this.presenter).newInstance();
      } catch (Exception exception) {
        return null;
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TableAttr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */