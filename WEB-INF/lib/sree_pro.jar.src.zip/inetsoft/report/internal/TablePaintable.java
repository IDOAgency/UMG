package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.Painter;
import inetsoft.report.Presenter;
import inetsoft.report.ReportElement;
import inetsoft.report.Size;
import inetsoft.report.SummaryTableLens;
import inetsoft.report.TableLens;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.Format;
import java.util.Hashtable;
import java.util.Vector;

public class TablePaintable extends BasePaintable {
  float height;
  
  float width;
  
  Rectangle reg;
  
  float x;
  
  float y;
  
  int resolution;
  
  Rectangle printBox;
  
  Bounds box;
  
  int headerR;
  
  int headerC;
  
  int summaryR;
  
  int[][] hor;
  
  int[][] ver;
  
  TableLens lens;
  
  SummaryTableLens summary;
  
  float[] rowHeight;
  
  float[] rowBorderH;
  
  Bounds[][] cellbounds;
  
  Hashtable linescache;
  
  float headerW;
  
  float headerH;
  
  float trailerH;
  
  Hashtable sumspan;
  
  Hashtable spanmap;
  
  Hashtable presenters;
  
  Hashtable formats;
  
  Insets padding;
  
  float[] colWidth;
  
  float[] colBorderW;
  
  private static final int R = 2;
  
  public TablePaintable(Rectangle paramRectangle1, float paramFloat1, float paramFloat2, int paramInt, Rectangle paramRectangle2, float paramFloat3, float paramFloat4, float paramFloat5, float[] paramArrayOfFloat1, float[] paramArrayOfFloat2, TableLens paramTableLens, ReportElement paramReportElement, Hashtable paramHashtable1, Hashtable paramHashtable2, Hashtable paramHashtable3, Hashtable paramHashtable4, Insets paramInsets, float[] paramArrayOfFloat3, float[] paramArrayOfFloat4) {
    super(paramReportElement);
    this.height = 0.0F;
    this.width = 0.0F;
    this.reg = paramRectangle1;
    this.resolution = paramInt;
    this.x = paramFloat1;
    this.y = paramFloat2;
    this.printBox = new Rectangle(paramRectangle2);
    this.headerW = paramFloat3;
    this.headerH = paramFloat4;
    this.trailerH = paramFloat5;
    this.colWidth = paramArrayOfFloat1;
    this.rowHeight = paramArrayOfFloat2;
    this.lens = paramTableLens;
    this.sumspan = paramHashtable1;
    this.spanmap = paramHashtable2;
    this.padding = paramInsets;
    this.rowBorderH = paramArrayOfFloat3;
    this.colBorderW = paramArrayOfFloat4;
    this.presenters = paramHashtable3;
    this.formats = paramHashtable4;
    init();
  }
  
  public void init() {
    if (this.lens instanceof SummaryTableLens)
      this.summary = (SummaryTableLens)this.lens; 
    this.width = this.headerW;
    for (int i = this.reg.x; i < this.reg.x + this.reg.width; i++)
      this.width += this.colWidth[i]; 
    this.height = this.headerH + this.trailerH;
    for (int j = this.reg.y; j < this.reg.y + this.reg.height; j++)
      this.height += this.rowHeight[j]; 
    this.box = new Bounds(0.0F, this.printBox.y + this.y, this.width, this.height);
    this.headerR = this.lens.getHeaderRowCount();
    this.headerC = this.lens.getHeaderColCount();
    this.summaryR = (this.trailerH > 0.0F) ? 1 : 0;
    this.hor = new int[this.headerR + this.reg.height + this.summaryR + 2][this.headerC + this.reg.width + 2];
    this.ver = new int[this.headerR + this.reg.height + this.summaryR + 2][this.headerC + this.reg.width + 2];
    this.linescache = new Hashtable();
    this.cellbounds = new Bounds[this.headerR + this.reg.height + this.summaryR][this.headerC + this.reg.width];
    if ((this.elem.getAlignment() & 0x2) != 0) {
      this.box.x = this.printBox.x + (this.printBox.width - this.box.width) / 2.0F;
    } else if ((this.elem.getAlignment() & 0x4) != 0) {
      this.box.x = (this.printBox.x + this.printBox.width) - this.box.width;
    } else {
      this.box.x = this.printBox.x + (float)this.elem.getIndent() * this.resolution + 1.0F;
    } 
    for (int k = 0; k < this.hor.length - 1; k++) {
      for (int i1 = 0; i1 < this.hor[k].length - 1; i1++) {
        byte b1 = (k <= this.headerR) ? (k - true) : (k - this.headerR + this.reg.y - 1);
        byte b2 = (i1 <= this.headerC) ? (i1 - true) : (i1 - this.headerC + this.reg.x - 1);
        boolean bool = (k == this.hor.length - 2 && this.summaryR == 1) ? 1 : 0;
        Rectangle rectangle = null;
        if (bool) {
          rectangle = (Rectangle)this.sumspan.get(new Integer(b2));
        } else {
          rectangle = (Rectangle)this.spanmap.get(new Point(b2, b1));
        } 
        if (rectangle != null) {
          if (k <= this.headerR + 1 || i1 <= this.headerC + 1 || (rectangle.x == 0 && rectangle.y == 0)) {
            int i2 = bool ? this.summary.getSummaryRowBorder(b2) : this.lens.getRowBorder(b1, b2);
            int i3 = bool ? this.summary.getSummaryColBorder(b2) : this.lens.getColBorder(b1, b2);
            for (int i4 = 0; i4 < rectangle.height && k + i4 < this.hor.length - 1; i4++) {
              for (int i5 = 0; i5 < rectangle.width && i1 + i5 < this.hor[k].length - 1; i5++) {
                this.hor[k + i4][i1 + i5] = (i4 == rectangle.height - 1 || k + i4 == this.hor.length - 2) ? i2 : 0;
                this.ver[k + i4][i1 + i5] = (i5 == rectangle.width - 1 || i1 + i5 == this.hor[k].length - 2) ? i3 : 0;
              } 
            } 
          } 
        } else {
          this.hor[k][i1] = (i1 == 0) ? 0 : (bool ? this.summary.getSummaryRowBorder(b2) : this.lens.getRowBorder(b1, b2));
          this.ver[k][i1] = (k == 0) ? 0 : (bool ? this.summary.getSummaryColBorder(b2) : this.lens.getColBorder(b1, b2));
        } 
      } 
    } 
    int m = this.hor[0].length - 2;
    for (int n = 1; n < this.hor.length - 1; n++) {
      byte b = (n <= this.headerR) ? (n - true) : (n - this.headerR + this.reg.y - 1);
      int i1 = this.lens.getColBorder(b, this.lens.getColCount() - 1);
      this.ver[n][m] = Util.mergeLineStyle(this.ver[n][m], i1);
    } 
    if (this.summaryR == 0) {
      int i1 = this.hor.length - 2;
      for (int i2 = 1; i2 < this.hor[0].length - 1; i2++) {
        byte b = (i2 <= this.headerC) ? (i2 - true) : (i2 - this.headerC + this.reg.x - 1);
        int i3 = this.lens.getRowBorder(this.lens.getRowCount() - 1, b);
        this.hor[i1][i2] = Util.mergeLineStyle(this.hor[i1][i2], i3);
      } 
    } 
  }
  
  public float getHeight() { return this.height; }
  
  public void paint(Graphics paramGraphics) {
    Rectangle rectangle = paramGraphics.getClipBounds();
    float f1 = Common.getLineAdjustment(paramGraphics);
    Color color = paramGraphics.getColor();
    Font font = paramGraphics.getFont();
    int i;
    label252: for (i = 0; i < this.hor.length - 2; i++) {
      int n = (i < this.headerR) ? i : (i - this.headerR + this.reg.y);
      boolean bool = (i == this.hor.length - 3 && this.summaryR == 1);
      for (int i1 = 0; i1 < this.hor[i].length - 2; i1++) {
        int i2 = (i1 < this.headerC) ? i1 : (i1 - this.headerC + this.reg.x);
        Color color1 = paramGraphics.getColor();
        Object object = bool ? this.summary.getSummary(i2, this.reg.y, this.reg.height) : this.lens.getObject(n, i2);
        boolean bool1 = bool ? this.summary.isSummaryLineWrap(i2) : this.lens.isLineWrap(n, i2);
        Rectangle rectangle1 = bool ? (Rectangle)this.sumspan.get(new Integer(i2)) : (Rectangle)this.spanmap.get(new Point(i2, n));
        if (rectangle1 == null || ((rectangle1.x == 0 || (i1 == this.headerC && i2 + rectangle1.x >= this.headerC)) && (rectangle1.y == 0 || (i == this.headerR && n + rectangle1.y >= this.headerR)))) {
          Bounds bounds = getCellBounds(n, i2, bool);
          if (rectangle != null && bounds.y > (rectangle.y + rectangle.height))
            break label252; 
          if (rectangle == null || bounds.y + bounds.height >= rectangle.y) {
            Color color2 = bool ? this.summary.getSummaryBackground(i2) : this.lens.getBackground(n, i2);
            Shape shape = null;
            Bounds bounds1 = null;
            if (rectangle1 != null) {
              float f4 = Common.getLineWidth(this.lens.getColBorder(n, this.headerC - 1));
              float f5 = Common.getLineWidth(this.lens.getRowBorder(this.headerR - 1, i2));
              object = bool ? this.summary.getSummary(i2 + rectangle1.x, this.reg.y, this.reg.height) : this.lens.getObject(n + rectangle1.y, i2 + rectangle1.x);
              bounds1 = (rectangle1.x == 0 && rectangle1.y == 0) ? new Bounds(bounds) : getPrintBounds(n, i2, bool);
              bounds1.width = Math.min(bounds1.width, this.box.width + this.box.x - bounds1.x);
              bounds1.height = Math.min(bounds1.height, this.box.height + this.box.y - bounds1.y);
              float f6 = this.box.x + f4 + ((i2 >= this.headerC) ? this.headerW : 0.0F);
              float f7 = this.box.y + f5 + ((n >= this.headerR) ? this.headerH : 0.0F);
              bounds1.x = Math.max(bounds1.x, f6);
              bounds1.y = Math.max(bounds1.y, f7);
              shape = paramGraphics.getClip();
              Common.clipRect(paramGraphics, bounds1);
            } 
            if (color2 != null) {
              paramGraphics.setColor(color2);
              Common.fillRect(paramGraphics, bounds.x, bounds.y, bounds.width, bounds.height);
              paramGraphics.setColor(color1);
            } 
            Color color3 = bool ? this.summary.getSummaryForeground(i2) : this.lens.getForeground(n, i2);
            paramGraphics.setColor((color3 != null) ? color3 : this.elem.getForeground());
            Font font1 = bool ? this.summary.getSummaryFont(i2) : this.lens.getFont(n, i2);
            paramGraphics.setFont((font1 != null) ? font1 : this.elem.getFont());
            if (object != null) {
              int i3 = bool ? this.summary.getSummaryAlignment(i2) : this.lens.getAlignment(n, i2);
              Insets insets = bool ? this.summary.getSummaryInsets(i2) : this.lens.getInsets(n, i2);
              if (insets != null) {
                bounds.x += insets.left;
                bounds.y += insets.top;
                bounds.width -= (insets.left + insets.right);
                bounds.height -= (insets.top + insets.bottom);
              } 
              Presenter presenter = StyleCore.getPresenter(this.presenters, object.getClass());
              if (presenter != null) {
                Dimension dimension = presenter.getPreferredSize(object);
                Bounds bounds2 = Common.alignCell(bounds, new Size(dimension), i3);
                presenter.paint(paramGraphics, object, (int)bounds2.x, (int)bounds2.y, (int)bounds2.width, (int)bounds2.height);
              } else if (object instanceof Component) {
                Component component = (Component)object;
                Dimension dimension = component.getSize();
                Bounds bounds2 = Common.alignCell(bounds, new Size(dimension), i3);
                Shape shape1 = paramGraphics.getClip();
                Common.clipRect(paramGraphics, bounds2);
                paramGraphics.translate((int)bounds2.x, (int)bounds2.y);
                component.printAll(paramGraphics);
                paramGraphics.translate(-((int)bounds2.x), -((int)bounds2.y));
                paramGraphics.setClip(shape1);
              } else if (object instanceof Image) {
                Image image = (Image)object;
                Dimension dimension = new Dimension(image.getWidth(null), image.getHeight(null));
                Bounds bounds2 = Common.alignCell(bounds, new Size(dimension), i3);
                Common.drawImage(paramGraphics, image, bounds2.x, bounds2.y, bounds2.width, bounds2.height, null);
              } else if (object instanceof Painter) {
                Painter painter = (Painter)object;
                Dimension dimension = painter.getPreferredSize();
                Bounds bounds2 = Common.alignCell(bounds, new Size(dimension), i3);
                Common.paint(paramGraphics, bounds2.x, bounds2.y, bounds2.width, bounds2.height, painter, 0.0F, 0.0F, bounds2.width, bounds2.height, bounds2.height, color3, color2);
              } else if (object != null) {
                if (this.padding != null) {
                  bounds.x += this.padding.left;
                  bounds.y += this.padding.top;
                  bounds.width -= (this.padding.left + this.padding.right);
                  bounds.height -= (this.padding.top + this.padding.bottom);
                } 
                Format format = StyleCore.getFormat(this.formats, object.getClass());
                if (format != null)
                  object = format.format(object); 
                String str = Util.toString(object);
                Object[] arrayOfObject = (Object[])this.linescache.get(new Point(i, i1));
                Bounds bounds2 = null;
                Vector vector1 = null;
                Vector vector2 = null;
                if (arrayOfObject != null) {
                  vector1 = (Vector)arrayOfObject[0];
                  vector2 = (Vector)arrayOfObject[1];
                  bounds2 = (Bounds)arrayOfObject[2];
                  if (vector1.size() > 0) {
                    int[] arrayOfInt = (int[])vector1.elementAt(vector1.size() - 1);
                    if (arrayOfInt[1] > str.length())
                      vector1 = null; 
                  } 
                } 
                if (vector1 == null) {
                  bounds2 = new Bounds();
                  vector2 = new Vector();
                  vector1 = Common.processText(str, bounds, i3, bool1, paramGraphics.getFont(), bounds2, vector2, this.elem.getSpacing());
                  this.linescache.put(new Point(i, i1), new Object[] { vector1, vector2, bounds2 });
                } 
                if (rectangle1 != null && (bounds1.y > bounds2.y || bounds1.y + bounds1.height < bounds2.y + bounds2.height)) {
                  float f4 = Common.getHeight(paramGraphics.getFont(), null) + this.elem.getSpacing();
                  boolean bool2 = false;
                  int i4 = vector1.size();
                  float f5 = bounds2.y;
                  for (int i5 = 0; i5 < vector1.size(); i5++) {
                    if (f5 + f4 + 2.0F < bounds1.y) {
                      bool2 = i5 + true;
                    } else if ((f5 + f4) > (bounds1.y + bounds1.height) + 0.5D) {
                      i4 = i5;
                      break;
                    } 
                    f5 += f4;
                  } 
                  if (!bool2 || i4 < vector1.size()) {
                    Vector vector3 = new Vector();
                    Vector vector4 = new Vector();
                    for (byte b = bool2; b < i4; b++) {
                      vector3.addElement(vector1.elementAt(b));
                      vector4.addElement(vector2.elementAt(b));
                    } 
                    vector1 = vector3;
                    vector2 = vector4;
                  } 
                  Bounds bounds3 = new Bounds(bounds1);
                  bounds3.y = Math.max(bounds3.y, bounds2.y);
                  bounds3.height = bounds1.y + bounds1.height - bounds3.y;
                  Common.clipRect(paramGraphics, bounds3);
                  bounds2 = new Bounds(bounds2.x, bounds3.y, bounds2.width, bounds3.height);
                } 
                Common.paintText(paramGraphics, str, vector1, bounds, bounds2, false, vector2, this.elem.getSpacing());
              } 
            } 
            paramGraphics.setColor(color1);
            if (shape != null)
              paramGraphics.setClip(shape); 
          } 
        } 
      } 
    } 
    float f2 = this.box.x, f3 = this.box.y;
    int j = Common.round(f2), k = Common.round(f3);
    for (int m = 0; m < this.hor.length - 1; m++) {
      byte b = (m <= this.headerR) ? (m - true) : (m - this.headerR + this.reg.y - 1);
      boolean bool = (m == this.hor.length - 2 && this.summaryR == 1) ? 1 : 0;
      float f4 = Common.round((bool || b) ? this.trailerH : this.rowHeight[b]);
      float f5 = k - f4;
      f2 = this.box.x;
      j = Common.round(f2);
      if (rectangle != null && f3 - f4 > (rectangle.y + rectangle.height))
        break; 
      if (rectangle == null || f3 + 5.0F > rectangle.y)
        for (int n = 0; n < this.hor[m].length - 1; n++) {
          byte b1 = (n <= this.headerC) ? (n - true) : (n - this.headerC + this.reg.x - 1);
          int i1 = this.hor[m][n];
          int i2 = this.ver[m][n];
          Color color1 = bool ? this.summary.getSummaryRowBorderColor(b1) : this.lens.getRowBorderColor(b, b1);
          Color color2 = bool ? this.summary.getSummaryColBorderColor(b1) : this.lens.getColBorderColor(b, b1);
          if (m > 0) {
            paramGraphics.setColor((color2 != null) ? color2 : color);
            if (i2 != 0) {
              Common.drawVLine(paramGraphics, j + f1, f5, k, i2, this.hor[m - 1][n], this.hor[m - 1][n + 1]);
              if (n == 0 && m == this.hor.length - 2 && this.hor[m][1] != 0)
                Common.drawVLine(paramGraphics, j + f1, k, k + Common.getLineWidth(this.hor[m][1]) - 1.0F, i2, 0, this.hor[m][1]); 
            } 
          } 
          if (n > 0) {
            paramGraphics.setColor((color1 != null) ? color1 : color);
            if (i1 != 0) {
              Common.drawHLine(paramGraphics, k + f1, Common.round((f2 - this.colWidth[b1])), j, i1, this.ver[m][n - 1], this.ver[m + 1][n - 1]);
              if (m == 0 && n == this.hor[m].length - 2 && this.ver[1][n] != 0)
                Common.drawHLine(paramGraphics, k + f1, j, j + Common.getLineWidth(this.ver[1][n]) - 1.0F, i1, 0, this.ver[1][n]); 
            } 
          } 
          if (m > 0 && m == this.hor.length - 2 && n > 0 && n == this.hor[m].length - 2) {
            paramGraphics.setColor((color2 != null) ? color2 : color);
            Common.drawVLine(paramGraphics, j + f1, k, k + Common.getLineWidth(this.hor[m][n]) - 1.0F, i2, this.hor[m][n - 1], 0);
            paramGraphics.setColor((color1 != null) ? color1 : color);
            Common.drawHLine(paramGraphics, k + f1, j, j + Common.getLineWidth(this.ver[m][n]) - 1.0F, i1, this.ver[m - 1][n], 0);
          } 
          if (n < this.hor[m].length - 2) {
            f2 += this.colWidth[(n == this.headerC) ? this.reg.x : (b1 + 1)];
            j = Common.round(f2);
          } 
        }  
      if (this.summaryR == 1 && m == this.hor.length - 2 - this.summaryR) {
        f3 += this.trailerH;
      } else if (m < this.hor.length - 2 - this.summaryR) {
        f3 += this.rowHeight[(m == this.headerR) ? this.reg.y : (b + 1)];
      } 
      k = Common.round(f3);
    } 
    paramGraphics.setColor(color);
    paramGraphics.setFont(font);
  }
  
  public Rectangle getBounds() {
    int i = this.ver[0].length - 2;
    int j = this.ver.length - 2;
    float f1 = Math.max(Common.getLineWidth(this.ver[0][i]), Common.getLineWidth(this.ver[j][i]));
    float f2 = Math.max(Common.getLineWidth(this.hor[j][0]), Common.getLineWidth(this.hor[j][i]));
    return new Rectangle((int)this.box.x, (int)this.box.y, (int)Math.ceil((this.box.width + f1 - 1.0F)), (int)Math.ceil((this.box.height + f2 - 1.0F)));
  }
  
  public void setLocation(Point paramPoint) { this.box.setLocation(paramPoint); }
  
  public Point locate(int paramInt1, int paramInt2) { return locate(paramInt1, paramInt2, false); }
  
  public Point locateBorder(int paramInt1, int paramInt2) { return locate(paramInt1, paramInt2, true); }
  
  private Point locate(int paramInt1, int paramInt2, boolean paramBoolean) {
    paramInt1 -= (int)this.box.x;
    paramInt2 -= (int)this.box.y;
    if (paramInt1 < 0 || paramInt1 > this.box.width + 1.0F || paramInt2 < 0 || paramInt2 > this.box.height + 1.0F || this.colWidth == null || this.colBorderW == null || this.rowHeight == null || this.rowBorderH == null || this.colWidth.length < this.lens.getColCount() || this.rowHeight.length < this.lens.getRowCount() || this.colBorderW.length < this.lens.getColCount() || this.rowBorderH.length < this.lens.getRowCount())
      return null; 
    Point point = new Point(-1, -1);
    int i = this.lens.getHeaderRowCount();
    int j = this.lens.getHeaderColCount();
    for (byte b1 = 0; b1 < i; b1++) {
      float f = this.rowHeight[b1] + ((b1 < i - 1) ? Math.max(2.0F, this.rowBorderH[b1 + true]) : 2.0F);
      if ((!paramBoolean && paramInt2 < this.rowHeight[b1]) || (paramBoolean && paramInt2 >= this.rowHeight[b1] && paramInt2 <= f)) {
        point.y = b1;
        break;
      } 
      paramInt2 = (int)(paramInt2 - this.rowHeight[b1]);
    } 
    for (byte b2 = 0; b2 < j; b2++) {
      float f = this.colWidth[b2] + ((b2 < j - 1) ? Math.max(2.0F, this.colBorderW[b2 + true]) : 2.0F);
      if ((!paramBoolean && paramInt1 < this.colWidth[b2]) || (paramBoolean && paramInt1 >= this.colWidth[b2] && paramInt1 <= f)) {
        point.x = b2;
        break;
      } 
      paramInt1 = (int)(paramInt1 - this.colWidth[b2]);
    } 
    if (point.x < 0) {
      int k = this.reg.x + this.reg.width;
      point.x = -1;
      for (int m = this.reg.x; m < k && m < this.colWidth.length; m++) {
        float f = this.colWidth[m] + ((m < this.colBorderW.length - 1) ? Math.max(2.0F, this.colBorderW[m + 1]) : 2.0F);
        if ((!paramBoolean && paramInt1 < this.colWidth[m]) || (paramBoolean && paramInt1 >= this.colWidth[m] && paramInt1 <= f)) {
          point.x = m;
          break;
        } 
        paramInt1 = (int)(paramInt1 - this.colWidth[m]);
      } 
    } 
    if (point.y < 0) {
      int k = this.reg.y + this.reg.height;
      point.y = -1;
      for (int m = this.reg.y; m < k && m < this.rowHeight.length; m++) {
        float f = this.rowHeight[m] + ((m < this.rowBorderH.length - 1) ? Math.max(2.0F, this.rowBorderH[m + 1]) : 2.0F);
        if ((!paramBoolean && paramInt2 < this.rowHeight[m]) || (paramBoolean && paramInt2 >= this.rowHeight[m] && paramInt2 <= f)) {
          point.y = m;
          break;
        } 
        paramInt2 = (int)(paramInt2 - this.rowHeight[m]);
      } 
    } 
    return ((paramBoolean && point.x < 0 && point.y < 0) || (!paramBoolean && (point.x < 0 || point.y < 0)) || point.x > this.colWidth.length || point.y > this.rowHeight.length) ? null : point;
  }
  
  public Bounds getCellBounds(int paramInt1, int paramInt2, boolean paramBoolean) {
    int i = (paramInt1 < this.headerR) ? paramInt1 : (paramInt1 + this.headerR - this.reg.y);
    int j = (paramInt2 < this.headerC) ? paramInt2 : (paramInt2 + this.headerC - this.reg.x);
    if (this.cellbounds[i][j] != null)
      return new Bounds(this.cellbounds[i][j]); 
    int k = (paramInt2 == this.reg.x) ? (this.lens.getHeaderColCount() - 1) : (paramInt2 - 1);
    int m = (paramInt1 == this.reg.y) ? (this.lens.getHeaderRowCount() - 1) : (paramInt1 - 1);
    float f1 = Common.getLineWidth(this.lens.getColBorder(paramInt1, k));
    float f2 = Common.getLineWidth(this.lens.getRowBorder(m, paramInt2));
    Bounds bounds = new Bounds(this.box.x + f1, this.box.y + f2, -f1, -f2);
    Rectangle rectangle = paramBoolean ? (Rectangle)this.sumspan.get(new Integer(paramInt2)) : (Rectangle)this.spanmap.get(new Point(paramInt2, paramInt1));
    if (rectangle != null)
      rectangle = new Rectangle(rectangle); 
    if (rectangle != null && (rectangle.x != 0 || rectangle.y != 0)) {
      for (int i2 = paramInt1 + rectangle.y; i2 < paramInt1; i2++)
        bounds.y -= this.rowHeight[i2]; 
      for (int i3 = paramInt2 + rectangle.x; i3 < paramInt2; i3++)
        bounds.x -= this.colWidth[i3]; 
      paramInt1 += rectangle.y;
      paramInt2 += rectangle.x;
      rectangle.width -= rectangle.x;
      rectangle.height -= rectangle.y;
    } 
    if (paramInt1 >= this.lens.getHeaderRowCount()) {
      bounds.y += this.headerH;
    } else {
      for (byte b = 0; b < paramInt1; b++)
        bounds.y += this.rowHeight[b]; 
    } 
    for (int n = this.reg.y; n < paramInt1; n++)
      bounds.y += this.rowHeight[n]; 
    if (paramInt2 >= this.lens.getHeaderColCount()) {
      bounds.x += this.headerW;
    } else {
      for (byte b = 0; b < paramInt2; b++)
        bounds.x += this.colWidth[b]; 
    } 
    for (int i1 = this.reg.x; i1 < paramInt2; i1++)
      bounds.x += this.colWidth[i1]; 
    if (rectangle != null) {
      for (int i2 = paramInt2; i2 < paramInt2 + rectangle.width; i2++)
        bounds.width += this.colWidth[i2]; 
      if (paramBoolean) {
        bounds.height += this.trailerH;
      } else {
        for (int i3 = paramInt1; i3 < paramInt1 + rectangle.height; i3++)
          bounds.height += this.rowHeight[i3]; 
      } 
    } else {
      bounds.width += this.colWidth[paramInt2];
      bounds.height += (paramBoolean ? this.trailerH : this.rowHeight[paramInt1]);
    } 
    return new Bounds(this.cellbounds[i][j] = bounds.round());
  }
  
  public Bounds getPrintBounds(int paramInt1, int paramInt2, boolean paramBoolean) {
    Bounds bounds = getCellBounds(paramInt1, paramInt2, paramBoolean);
    Rectangle rectangle = paramBoolean ? (Rectangle)this.sumspan.get(new Integer(paramInt2)) : (Rectangle)this.spanmap.get(new Point(paramInt2, paramInt1));
    if (rectangle == null)
      return bounds; 
    for (int i = paramInt2 + rectangle.x; i < paramInt2; i++) {
      bounds.width -= this.colWidth[i];
      bounds.x += this.colWidth[i];
    } 
    for (int j = paramInt1 + rectangle.y; j < paramInt1; j++) {
      bounds.height -= this.rowHeight[j];
      bounds.y += this.rowHeight[j];
    } 
    return bounds.round();
  }
  
  public Rectangle getTableRegion() { return this.reg; }
  
  public TableLens getTable() { return this.lens; }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
    paramObjectInputStream.defaultReadObject();
    this.elem = new DefaultContext();
    ((DefaultContext)this.elem).read(paramObjectInputStream);
    int i = paramObjectInputStream.readInt();
    int j = paramObjectInputStream.readInt();
    int k = paramObjectInputStream.readInt();
    int m = paramObjectInputStream.readInt();
    RegionTableLens regionTableLens = new RegionTableLens(i, j, k, m, this.reg);
    this.lens = regionTableLens;
    for (int n = this.reg.y; n < this.reg.y + this.reg.height; n++)
      regionTableLens.setRowHeight(n, paramObjectInputStream.readInt()); 
    for (int i1 = this.reg.x; i1 < this.reg.x + this.reg.width; i1++)
      regionTableLens.setColWidth(i1, paramObjectInputStream.readInt()); 
    if (this.reg.y > 0)
      for (byte b = 0; b < regionTableLens.getHeaderRowCount(); b++) {
        for (int i5 = this.reg.x; i5 < this.reg.x + this.reg.width; i5++)
          readCell(paramObjectInputStream, regionTableLens, b, i5); 
      }  
    if (this.reg.x > 0)
      for (int i5 = this.reg.y; i5 < this.reg.y + this.reg.height; i5++) {
        for (byte b = 0; b < regionTableLens.getHeaderColCount(); b++)
          readCell(paramObjectInputStream, regionTableLens, i5, b); 
      }  
    for (byte b1 = 0; b1 < regionTableLens.getHeaderRowCount(); b1++) {
      for (byte b = 0; b < regionTableLens.getHeaderColCount(); b++)
        readCell(paramObjectInputStream, regionTableLens, b1, b); 
    } 
    for (int i2 = this.reg.y; i2 < this.reg.y + this.reg.height; i2++) {
      for (int i5 = this.reg.x; i5 < this.reg.x + this.reg.width; i5++) {
        readCell(paramObjectInputStream, regionTableLens, i2, i5);
        Rectangle rectangle = (Rectangle)this.spanmap.get(new Point(i5, i2));
        if (rectangle != null && rectangle.width == 0 && rectangle.height == 0)
          readCell(paramObjectInputStream, regionTableLens, i2 + rectangle.y, i5 + rectangle.x); 
      } 
    } 
    int i3 = regionTableLens.getColCount() - 1;
    int i4 = regionTableLens.getRowCount() - 1;
    int[][] arrayOfInt1 = { { 0, regionTableLens.getHeaderRowCount() + 1 }, { this.reg.y, this.reg.y + this.reg.height }, { regionTableLens.getRowCount() - 1, regionTableLens.getRowCount() } };
    for (byte b2 = 0; b2 < arrayOfInt1.length; b2++) {
      for (int i5 = arrayOfInt1[b2][0]; i5 < arrayOfInt1[b2][1]; i5++) {
        regionTableLens.setColBorder(i5, -1, paramObjectInputStream.readInt());
        regionTableLens.setColBorderColor(i5, -1, (Color)paramObjectInputStream.readObject());
        regionTableLens.setColBorder(i5, i3, paramObjectInputStream.readInt());
        regionTableLens.setColBorderColor(i5, i3, (Color)paramObjectInputStream.readObject());
      } 
    } 
    int[][] arrayOfInt2 = { { 0, regionTableLens.getHeaderColCount() + 1 }, { this.reg.x, this.reg.x + this.reg.width }, { regionTableLens.getColCount() - 1, regionTableLens.getColCount() } };
    for (byte b3 = 0; b3 < arrayOfInt2.length; b3++) {
      for (int i5 = arrayOfInt2[b3][0]; i5 < arrayOfInt2[b3][1]; i5++) {
        regionTableLens.setRowBorder(-1, i5, paramObjectInputStream.readInt());
        regionTableLens.setRowBorderColor(-1, i5, (Color)paramObjectInputStream.readObject());
        regionTableLens.setRowBorder(i4, i5, paramObjectInputStream.readInt());
        regionTableLens.setRowBorderColor(i4, i5, (Color)paramObjectInputStream.readObject());
      } 
    } 
    this.rowHeight = new float[paramObjectInputStream.readInt()];
    this.rowBorderH = new float[paramObjectInputStream.readInt()];
    int[][] arrayOfInt3 = { { 0, regionTableLens.getHeaderRowCount() + 1 }, { this.reg.y, this.reg.y + this.reg.height + 3 } };
    float[][] arrayOfFloat = { this.rowHeight, this.rowBorderH };
    for (byte b4 = 0; b4 < arrayOfInt3.length; b4++) {
      for (int i5 = arrayOfInt3[b4][0]; i5 < arrayOfInt3[b4][1]; i5++) {
        for (byte b = 0; b < arrayOfFloat.length; b++) {
          if (i5 < arrayOfFloat[b].length)
            arrayOfFloat[b][i5] = paramObjectInputStream.readFloat(); 
        } 
      } 
    } 
    init();
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    paramObjectOutputStream.defaultWriteObject();
    DefaultContext.write(paramObjectOutputStream, this.elem);
    paramObjectOutputStream.writeInt(this.lens.getRowCount());
    paramObjectOutputStream.writeInt(this.lens.getColCount());
    paramObjectOutputStream.writeInt(this.lens.getHeaderRowCount());
    paramObjectOutputStream.writeInt(this.lens.getHeaderColCount());
    for (int i = this.reg.y; i < this.reg.y + this.reg.height; i++)
      paramObjectOutputStream.writeInt(this.lens.getRowHeight(i)); 
    for (int j = this.reg.x; j < this.reg.x + this.reg.width; j++)
      paramObjectOutputStream.writeInt(this.lens.getColWidth(j)); 
    if (this.reg.y > 0)
      for (int i1 = 0; i1 < this.lens.getHeaderRowCount(); i1++) {
        for (int i2 = this.reg.x; i2 < this.reg.x + this.reg.width; i2++) {
          writeCell(paramObjectOutputStream, this.lens, i1, i2);
          Rectangle rectangle = (Rectangle)this.spanmap.get(new Point(i2, i1));
          if (rectangle != null && rectangle.width == 0 && rectangle.height == 0)
            writeCell(paramObjectOutputStream, this.lens, i1 + rectangle.y, i2 + rectangle.x); 
        } 
      }  
    if (this.reg.x > 0)
      for (int i1 = this.reg.y; i1 < this.reg.y + this.reg.height; i1++) {
        for (byte b = 0; b < this.lens.getHeaderColCount(); b++)
          writeCell(paramObjectOutputStream, this.lens, i1, b); 
      }  
    for (byte b1 = 0; b1 < this.lens.getHeaderRowCount(); b1++) {
      for (byte b = 0; b < this.lens.getHeaderColCount(); b++)
        writeCell(paramObjectOutputStream, this.lens, b1, b); 
    } 
    for (int k = this.reg.y; k < this.reg.y + this.reg.height; k++) {
      for (int i1 = this.reg.x; i1 < this.reg.x + this.reg.width; i1++)
        writeCell(paramObjectOutputStream, this.lens, k, i1); 
    } 
    int m = this.lens.getColCount() - 1;
    int n = this.lens.getRowCount() - 1;
    int[][] arrayOfInt1 = { { 0, this.lens.getHeaderRowCount() + 1 }, { this.reg.y, this.reg.y + this.reg.height }, { this.lens.getRowCount() - 1, this.lens.getRowCount() } };
    for (byte b2 = 0; b2 < arrayOfInt1.length; b2++) {
      for (int i1 = arrayOfInt1[b2][0]; i1 < arrayOfInt1[b2][1]; i1++) {
        paramObjectOutputStream.writeInt(this.lens.getColBorder(i1, -1));
        paramObjectOutputStream.writeObject(this.lens.getColBorderColor(i1, -1));
        paramObjectOutputStream.writeInt(this.lens.getColBorder(i1, m));
        paramObjectOutputStream.writeObject(this.lens.getColBorderColor(i1, m));
      } 
    } 
    int[][] arrayOfInt2 = { { 0, this.lens.getHeaderColCount() + 1 }, { this.reg.x, this.reg.x + this.reg.width }, { this.lens.getColCount() - 1, this.lens.getColCount() } };
    for (byte b3 = 0; b3 < arrayOfInt2.length; b3++) {
      for (int i1 = arrayOfInt2[b3][0]; i1 < arrayOfInt2[b3][1]; i1++) {
        paramObjectOutputStream.writeInt(this.lens.getRowBorder(-1, i1));
        paramObjectOutputStream.writeObject(this.lens.getRowBorderColor(-1, i1));
        paramObjectOutputStream.writeInt(this.lens.getRowBorder(n, i1));
        paramObjectOutputStream.writeObject(this.lens.getRowBorderColor(n, i1));
      } 
    } 
    paramObjectOutputStream.writeInt(this.rowHeight.length);
    paramObjectOutputStream.writeInt(this.rowBorderH.length);
    int[][] arrayOfInt3 = { { 0, this.lens.getHeaderRowCount() + 1 }, { this.reg.y, this.reg.y + this.reg.height + 3 } };
    float[][] arrayOfFloat = { this.rowHeight, this.rowBorderH };
    for (byte b4 = 0; b4 < arrayOfInt3.length; b4++) {
      for (int i1 = arrayOfInt3[b4][0]; i1 < arrayOfInt3[b4][1]; i1++) {
        for (byte b = 0; b < arrayOfFloat.length; b++) {
          if (i1 < arrayOfFloat[b].length)
            paramObjectOutputStream.writeFloat(arrayOfFloat[b][i1]); 
        } 
      } 
    } 
  }
  
  public void readCell(ObjectInputStream paramObjectInputStream, RegionTableLens paramRegionTableLens, int paramInt1, int paramInt2) throws ClassNotFoundException, IOException {
    paramRegionTableLens.setRowBorderColor(paramInt1, paramInt2, BasePaintable.readColor(paramObjectInputStream));
    paramRegionTableLens.setColBorderColor(paramInt1, paramInt2, BasePaintable.readColor(paramObjectInputStream));
    paramRegionTableLens.setRowBorder(paramInt1, paramInt2, paramObjectInputStream.readInt());
    paramRegionTableLens.setColBorder(paramInt1, paramInt2, paramObjectInputStream.readInt());
    paramRegionTableLens.setInsets(paramInt1, paramInt2, (Insets)paramObjectInputStream.readObject());
    paramRegionTableLens.setSpan(paramInt1, paramInt2, (Dimension)paramObjectInputStream.readObject());
    paramRegionTableLens.setAlignment(paramInt1, paramInt2, paramObjectInputStream.readInt());
    paramRegionTableLens.setFont(paramInt1, paramInt2, BasePaintable.readFont(paramObjectInputStream));
    paramRegionTableLens.setLineWrap(paramInt1, paramInt2, paramObjectInputStream.readBoolean());
    paramRegionTableLens.setForeground(paramInt1, paramInt2, BasePaintable.readColor(paramObjectInputStream));
    paramRegionTableLens.setBackground(paramInt1, paramInt2, BasePaintable.readColor(paramObjectInputStream));
    paramRegionTableLens.setObject(paramInt1, paramInt2, paramObjectInputStream.readObject());
  }
  
  public void writeCell(ObjectOutputStream paramObjectOutputStream, TableLens paramTableLens, int paramInt1, int paramInt2) throws IOException {
    BasePaintable.writeColor(paramObjectOutputStream, paramTableLens.getRowBorderColor(paramInt1, paramInt2));
    BasePaintable.writeColor(paramObjectOutputStream, paramTableLens.getColBorderColor(paramInt1, paramInt2));
    paramObjectOutputStream.writeInt(paramTableLens.getRowBorder(paramInt1, paramInt2));
    paramObjectOutputStream.writeInt(paramTableLens.getColBorder(paramInt1, paramInt2));
    paramObjectOutputStream.writeObject(paramTableLens.getInsets(paramInt1, paramInt2));
    paramObjectOutputStream.writeObject(paramTableLens.getSpan(paramInt1, paramInt2));
    paramObjectOutputStream.writeInt(paramTableLens.getAlignment(paramInt1, paramInt2));
    BasePaintable.writeFont(paramObjectOutputStream, paramTableLens.getFont(paramInt1, paramInt2));
    paramObjectOutputStream.writeBoolean(paramTableLens.isLineWrap(paramInt1, paramInt2));
    BasePaintable.writeColor(paramObjectOutputStream, paramTableLens.getForeground(paramInt1, paramInt2));
    BasePaintable.writeColor(paramObjectOutputStream, paramTableLens.getBackground(paramInt1, paramInt2));
    paramObjectOutputStream.writeObject(paramTableLens.getObject(paramInt1, paramInt2));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TablePaintable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */