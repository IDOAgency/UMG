package inetsoft.report.internal;

import inetsoft.report.TableLens;

public interface Groupable {
  FilterAttr getFilter();
  
  void setFilter(FilterAttr paramFilterAttr);
  
  void setTable(TableLens paramTableLens);
  
  TableLens getTable();
  
  TableLens getRootTable();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\Groupable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */