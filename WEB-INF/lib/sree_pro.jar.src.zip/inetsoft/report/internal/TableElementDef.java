/*      */ package inetsoft.report.internal;
/*      */ 
/*      */ import inetsoft.report.Common;
/*      */ import inetsoft.report.CompositeLens;
/*      */ import inetsoft.report.Context;
/*      */ import inetsoft.report.Painter;
/*      */ import inetsoft.report.Presenter;
/*      */ import inetsoft.report.ReportElement;
/*      */ import inetsoft.report.Size;
/*      */ import inetsoft.report.StylePage;
/*      */ import inetsoft.report.StyleSheet;
/*      */ import inetsoft.report.SummaryTableLens;
/*      */ import inetsoft.report.TableElement;
/*      */ import inetsoft.report.TableFilter;
/*      */ import inetsoft.report.TableLens;
/*      */ import inetsoft.report.locale.Catalog;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.text.Format;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ 
/*      */ public class TableElementDef extends BaseElement implements TableElement {
/*      */   private TableLens tablelens;
/*      */   private double tableW;
/*      */   
/*      */   public TableElementDef(StyleSheet paramStyleSheet, TableLens paramTableLens) {
/*   34 */     super(paramStyleSheet, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1136 */     this.valid = false;
/* 1137 */     this.regions = new Vector();
/* 1138 */     this.currentRegion = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1143 */     this.headerW = 0.0F; this.headerH = 0.0F;
/*      */     
/* 1145 */     this.trailerH = 0.0F;
/* 1146 */     this.summary = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1153 */     this.spanmap = new Hashtable();
/*      */     
/* 1155 */     this.sumspan = new Hashtable();
/*      */     setTable(paramTableLens);
/*      */     this.autosize = paramStyleSheet.autosize;
/*      */     this.tableW = paramStyleSheet.tableW;
/*      */     this.padding = paramStyleSheet.padding;
/*      */     this.tableadv = paramStyleSheet.tableadv;
/*      */     this.presenters = (Hashtable)paramStyleSheet.presentermap.clone();
/*      */     this.formats = (Hashtable)paramStyleSheet.formatmap.clone();
/*      */   }
/*      */   
/*      */   private int autosize;
/*      */   private Insets padding;
/*      */   private Hashtable presenters;
/*      */   private Hashtable formats;
/*      */   private int[] fixedWidths;
/*      */   private int tableadv;
/*      */   private boolean orphan;
/*      */   private Point[] onClickRange;
/*      */   private boolean valid;
/*      */   private Vector regions;
/*      */   private int currentRegion;
/*      */   private float[] colWidth;
/*      */   private float[] rowHeight;
/*      */   private float[] rowBorderH;
/*      */   private float[] colBorderW;
/*      */   private float headerW;
/*      */   private float headerH;
/*      */   private float trailerH;
/*      */   private SummaryTableLens summary;
/*      */   private Hashtable spanmap;
/*      */   private Hashtable sumspan;
/*      */   
/*      */   public Presenter getPresenter(Class paramClass) { return StyleCore.getPresenter(this.presenters, paramClass); }
/*      */   
/*      */   public void addPresenter(Class paramClass, Presenter paramPresenter) { this.presenters.put(paramClass, paramPresenter); }
/*      */   
/*      */   public Format getFormat(Class paramClass) { return StyleCore.getFormat(this.formats, paramClass); }
/*      */   
/*      */   public void addFormat(Class paramClass, Format paramFormat) { this.formats.put(paramClass, paramFormat); }
/*      */   
/*      */   public void reset() {
/*      */     super.reset();
/*      */     this.valid = false;
/*      */     this.regions.removeAllElements();
/*      */     this.currentRegion = 0;
/*      */   }
/*      */   
/*      */   public Size getPreferredSize() { return new Size(0.0F, 0.0F); }
/*      */   
/*      */   public boolean isBreakable() { return true; }
/*      */   
/*      */   public void validate(StylePage paramStylePage) {
/*      */     if (!this.valid) {
/*      */       if (getTable() instanceof TableFilter)
/*      */         ((TableFilter)getTable()).refresh(); 
/*      */       checkElementAreas();
/*      */       layout(paramStylePage);
/*      */       this.valid = true;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean print(StylePage paramStylePage) {
/*      */     if (!isVisible())
/*      */       return false; 
/*      */     TableLens tableLens = getTable();
/*      */     if (tableLens.getRowCount() <= 0 || tableLens.getColCount() <= 0 || this.currentRegion >= this.regions.size())
/*      */       return false; 
/*      */     validate(paramStylePage);
/*      */     super.print(paramStylePage);
/*      */     Object object = this.regions.elementAt(this.currentRegion++);
/*      */     if (object == CompositeLens.AREA_BREAK)
/*      */       return true; 
/*      */     Rectangle rectangle = (Rectangle)object;
/*      */     TablePaintable tablePaintable = new TablePaintable(rectangle, this.report.printHead.x, this.report.printHead.y, paramStylePage.getPageResolution(), this.report.printBox, this.headerW, this.headerH, this.trailerH, this.colWidth, this.rowHeight, tableLens, this, this.sumspan, this.spanmap, this.presenters, this.formats, getPadding(), this.rowBorderH, this.colBorderW);
/*      */     paramStylePage.addPaintable(tablePaintable);
/*      */     float f = Common.getLineWidth(tableLens.getRowBorder(tableLens.getRowCount() - 1, 0));
/*      */     this.report.printHead.y += tablePaintable.getHeight() + getSpacing() + ((this.tableadv > 0) ? Math.max(this.tableadv, f + 1.0F) : this.tableadv);
/*      */     this.report.printHead.x = 0.0F;
/*      */     return (this.currentRegion < this.regions.size());
/*      */   }
/*      */   
/*      */   public int fitNext(float paramFloat) {
/*      */     if (this.currentRegion < this.regions.size()) {
/*      */       if (this.regions.elementAt(this.currentRegion) == CompositeLens.AREA_BREAK) {
/*      */         this.currentRegion++;
/*      */         return 0;
/*      */       } 
/*      */       float f = this.headerH;
/*      */       Rectangle rectangle = (Rectangle)this.regions.elementAt(this.currentRegion);
/*      */       for (int i = 0; i < rectangle.height; i++)
/*      */         f += this.rowHeight[rectangle.y + i]; 
/*      */       return (paramFloat >= f) ? 1 : -1;
/*      */     } 
/*      */     return 1;
/*      */   }
/*      */   
/*      */   private void layout(StylePage paramStylePage) {
/*      */     this.report.resolution = paramStylePage.getPageResolution();
/*      */     TableLens tableLens = getTable();
/*      */     this;
/*      */     if (StyleCore.isLimited() && tableLens.getRowCount() > this.report.getMaxRows())
/*      */       throw new Error("Style Report/Lite is limited to " + this.report.getMaxRows() + " rows per table: " + tableLens.getRowCount()); 
/*      */     this.spanmap.clear();
/*      */     for (int i = 0; i < tableLens.getRowCount(); i++) {
/*      */       for (int i3 = 0; i3 < tableLens.getColCount(); i3++) {
/*      */         Dimension dimension = tableLens.getSpan(i, i3);
/*      */         if (dimension != null)
/*      */           for (int i4 = 0; i4 < dimension.height; i4++) {
/*      */             for (int i5 = 0; i5 < dimension.width; i5++) {
/*      */               Rectangle rectangle1 = new Rectangle(-i5, -i4, dimension.width - i5, dimension.height - i4);
/*      */               this.spanmap.put(new Point(i5 + i3, i4 + i), rectangle1);
/*      */             } 
/*      */           }  
/*      */       } 
/*      */     } 
/*      */     this.sumspan.clear();
/*      */     if (this.summary != null)
/*      */       for (int i3 = 0; i3 < tableLens.getColCount(); i3++) {
/*      */         Dimension dimension = this.summary.getSummarySpan(i3);
/*      */         if (dimension != null)
/*      */           for (int i4 = 0; i4 < dimension.width; i4++) {
/*      */             Rectangle rectangle1 = new Rectangle(-i4, 0, dimension.width - i4, 1);
/*      */             this.sumspan.put(new Integer(i4 + i3), rectangle1);
/*      */           }  
/*      */       }  
/*      */     float f1 = (this.tableW > 0.0D) ? (float)(this.tableW * this.report.resolution) : (float)(this.report.printBox.width - getIndent() * this.report.resolution - getHindent());
/*      */     f1 -= 2.0F;
/*      */     int j = tableLens.getColCount();
/*      */     float f2 = f1 / j;
/*      */     if (this.autosize == 2) {
/*      */       this.colWidth = new float[j];
/*      */       for (byte b = 0; b < this.colWidth.length; b++)
/*      */         this.colWidth[b] = f2; 
/*      */       this.colBorderW = calcColBorderW();
/*      */     } else {
/*      */       float[][] arrayOfFloat = null;
/*      */       this.colWidth = new float[tableLens.getColCount()];
/*      */       if (this.fixedWidths == null) {
/*      */         arrayOfFloat = calcColWidth(f2);
/*      */       } else {
/*      */         arrayOfFloat = new float[tableLens.getColCount()][2];
/*      */         for (byte b = 0; b < this.colWidth.length; b++) {
/*      */           arrayOfFloat[b][0] = (b < this.fixedWidths.length) ? this.fixedWidths[b] : -1.0F;
/*      */           arrayOfFloat[b][1] = arrayOfFloat[b][0];
/*      */         } 
/*      */         this.colBorderW = calcColBorderW();
/*      */       } 
/*      */       byte b3 = 0;
/*      */       float f3 = 0.0F;
/*      */       float f4 = 0.0F;
/*      */       float f5 = 0.0F;
/*      */       float f6 = 0.0F;
/*      */       for (byte b4 = 0; b4 < this.colWidth.length; b4++) {
/*      */         if (arrayOfFloat[b4][0] == 0.0F) {
/*      */           b3++;
/*      */           if (this.autosize == 1)
/*      */             arrayOfFloat[b4][0] = f2; 
/*      */         } 
/*      */         if (this.autosize == 1) {
/*      */           this.colWidth[b4] = arrayOfFloat[b4][1];
/*      */           f4 += arrayOfFloat[b4][0];
/*      */           f5 += arrayOfFloat[b4][1];
/*      */           f6 += arrayOfFloat[b4][0] - arrayOfFloat[b4][1];
/*      */         } else {
/*      */           this.colWidth[b4] = arrayOfFloat[b4][0];
/*      */         } 
/*      */         f3 += this.colWidth[b4];
/*      */       } 
/*      */       if (this.autosize == 1) {
/*      */         float f = f1 - f3;
/*      */         if (f < 0.0F) {
/*      */           for (byte b = 0; b < this.colWidth.length; b++)
/*      */             this.colWidth[b] = this.colWidth[b] + arrayOfFloat[b][1] * f / f5; 
/*      */         } else {
/*      */           float f7 = Math.min(f, f6);
/*      */           if (f7 > 0.0F && f6 > 0.0F)
/*      */             for (byte b = 0; b < this.colWidth.length; b++)
/*      */               this.colWidth[b] = this.colWidth[b] + (arrayOfFloat[b][0] - arrayOfFloat[b][1]) * f7 / f6;  
/*      */           f7 = f - f7;
/*      */           if (f7 > 0.0F)
/*      */             for (byte b = 0; b < this.colWidth.length; b++)
/*      */               this.colWidth[b] = this.colWidth[b] + arrayOfFloat[b][0] * f7 / f4;  
/*      */         } 
/*      */       } else if (b3 > 0) {
/*      */         float f = Math.max(f2 / 2.0F, (f1 - f3) / b3);
/*      */         for (byte b = 0; b < this.colWidth.length; b++) {
/*      */           if (arrayOfFloat[b][0] == 0.0F)
/*      */             this.colWidth[b] = f; 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     int k = tableLens.getHeaderRowCount();
/*      */     int m = tableLens.getHeaderColCount();
/*      */     this.headerW = this.headerH = 0.0F;
/*      */     for (byte b1 = 0; b1 < m; b1++)
/*      */       this.headerW += this.colWidth[b1]; 
/*      */     for (int n = m; n < tableLens.getColCount(); n++) {
/*      */       if (this.headerW + this.colWidth[n] > this.report.printBox.width)
/*      */         this.colWidth[n] = this.report.printBox.width - this.headerW; 
/*      */     } 
/*      */     this.rowHeight = calcRowHeight(this.colWidth, this.report.printBox.height - this.report.printHead.y);
/*      */     for (byte b2 = 0; b2 < k; b2++)
/*      */       this.headerH += this.rowHeight[b2]; 
/*      */     if (this.summary != null)
/*      */       this.trailerH = this.summary.getSummaryHeight(); 
/*      */     this.regions.removeAllElements();
/*      */     this.currentRegion = 0;
/*      */     Rectangle rectangle = new Rectangle(this.report.printBox);
/*      */     int i1 = this.report.currFrame + 1;
/*      */     rectangle.height = (int)(rectangle.height - this.report.printHead.y);
/*      */     rectangle.x = (int)(rectangle.x + getIndent() * this.report.resolution + getHindent());
/*      */     rectangle.width = (int)(rectangle.width - getIndent() * this.report.resolution + getHindent());
/*      */     Point point = new Point(m, k);
/*      */     int i2 = 0;
/*      */     while (point.x < this.colWidth.length && point.y < this.rowHeight.length) {
/*      */       Rectangle rectangle1 = new Rectangle(point.x, point.y, this.colWidth.length - point.x, this.rowHeight.length - point.y);
/*      */       if (rectangle1.y != k && rectangle1.x == m)
/*      */         this.rowHeight[rectangle1.y] = this.rowHeight[rectangle1.y] - this.rowBorderH[rectangle1.y] - this.rowBorderH[k]; 
/*      */       if (rectangle1.x != m && rectangle1.y == k)
/*      */         this.colWidth[rectangle1.x] = this.colWidth[rectangle1.x] - this.colBorderW[rectangle1.x] - this.colBorderW[m]; 
/*      */       float f = this.headerW;
/*      */       for (int i3 = point.x; i3 < this.colWidth.length; i3++) {
/*      */         f += this.colWidth[i3];
/*      */         if (f > rectangle.width) {
/*      */           rectangle1.width = i3 - point.x;
/*      */           break;
/*      */         } 
/*      */       } 
/*      */       if (this.autosize == 4) {
/*      */         int i4 = point.x + rectangle1.width - 1;
/*      */         float f3 = rectangle.width - f - ((i4 + 1 < this.colWidth.length) ? this.colWidth[i4 + 1] : 0.0F);
/*      */         this.colWidth[i4] = this.colWidth[i4] + f3;
/*      */       } 
/*      */       boolean bool = false;
/*      */       if (point.x != m) {
/*      */         rectangle1.height = i2;
/*      */         float f3 = this.headerH + this.trailerH;
/*      */         for (int i4 = point.y; i4 < rectangle1.y + rectangle1.height; i4++) {
/*      */           f3 += this.rowHeight[i4];
/*      */           if (f3 > rectangle.height) {
/*      */             rectangle1.height = 0;
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } else {
/*      */         float f3 = this.headerH + this.trailerH;
/*      */         for (int i4 = point.y; i4 < this.rowHeight.length; i4++) {
/*      */           f3 += this.rowHeight[i4];
/*      */           bool = ((tableLens.getRowBorder(i4, 0) & 0x1000000) != 0) ? 1 : 0;
/*      */           if (bool) {
/*      */             rectangle1.height = i2 = i4 - point.y + 1;
/*      */             break;
/*      */           } 
/*      */           if (f3 > rectangle.height) {
/*      */             rectangle1.height = i2 = i4 - point.y;
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       if ((rectangle1.width == 0 || rectangle1.height == 0) && rectangle.height == this.report.printBox.height && rectangle.width == this.report.printBox.width) {
/*      */         if (rectangle1.height == 0) {
/*      */           rectangle1.height = Math.max(rectangle1.height, 1);
/*      */           float f3 = this.headerH;
/*      */           for (int i4 = 0; i4 < rectangle1.height - 1; i4++)
/*      */             f3 += this.rowHeight[rectangle1.y + i4]; 
/*      */           this.rowHeight[rectangle1.y + rectangle1.height - 1] = rectangle.height - f3;
/*      */         } 
/*      */         if (rectangle1.width == 0) {
/*      */           rectangle1.width = Math.max(rectangle1.width, 1);
/*      */           float f3 = this.headerW;
/*      */           for (int i4 = 0; i4 < rectangle1.width - 1; i4++)
/*      */             f3 += this.colWidth[rectangle1.x + i4]; 
/*      */           this.colWidth[rectangle1.x + rectangle1.width - 1] = rectangle.width - f3;
/*      */         } 
/*      */       } 
/*      */       if (this.orphan)
/*      */         if (point.x == m && rectangle1.height == 1 && this.rowHeight.length - point.y > 2) {
/*      */           rectangle1.height = 0;
/*      */         } else if (point.x == m && rectangle1.height > 2 && this.rowHeight.length - rectangle1.y - rectangle1.height == 1) {
/*      */           rectangle1.height--;
/*      */         }  
/*      */       if (rectangle1.width > 0 && rectangle1.height > 0) {
/*      */         this.regions.addElement(rectangle1);
/*      */         if (bool)
/*      */           this.regions.addElement(CompositeLens.AREA_BREAK); 
/*      */         if (rectangle1.x + rectangle1.width == this.colWidth.length) {
/*      */           point.x = m;
/*      */           point.y += rectangle1.height;
/*      */         } else {
/*      */           point.x += rectangle1.width;
/*      */         } 
/*      */         i2 = rectangle1.height;
/*      */         float f3 = this.headerH + this.trailerH;
/*      */         for (int i4 = rectangle1.y; i4 < rectangle1.y + rectangle1.height; i4++)
/*      */           f3 += this.rowHeight[i4]; 
/*      */         rectangle.height = (int)(rectangle.height - f3);
/*      */         rectangle.y = (int)(rectangle.y + f3);
/*      */       } else {
/*      */         rectangle.height = 0;
/*      */       } 
/*      */       if (this.autosize == 3 || bool || (point.y < this.rowHeight.length && rectangle.height < this.headerH + this.rowHeight[point.y] + 30.0F)) {
/*      */         rectangle = new Rectangle((this.report.npframes == null || i1 < this.report.frames.length) ? this.report.frames[i1 % this.report.frames.length] : this.report.npframes[(i1 - this.report.frames.length) % this.report.npframes.length]);
/*      */         i1++;
/*      */         rectangle.x = (int)(rectangle.x + getIndent() * this.report.resolution + getHindent());
/*      */         rectangle.width = (int)(rectangle.width - getIndent() * this.report.resolution + getHindent());
/*      */       } 
/*      */     } 
/*      */     if (this.regions.size() == 0 && (point.x > 0 || point.y > 0))
/*      */       this.regions.addElement(new Rectangle(point.x, point.y, tableLens.getColCount() - point.x, tableLens.getRowCount() - point.y)); 
/*      */   }
/*      */   
/*      */   public float[] calcColBorderW() {
/*      */     TableLens tableLens = getTable();
/*      */     float[] arrayOfFloat = new float[tableLens.getColCount()];
/*      */     for (byte b = 0; b < tableLens.getRowCount(); b++) {
/*      */       float f = Common.getLineWidth(tableLens.getColBorder(b, tableLens.getHeaderColCount() - 1));
/*      */       for (byte b1 = 0; b1 < arrayOfFloat.length; b1++) {
/*      */         arrayOfFloat[b1] = Math.max(arrayOfFloat[b1], Common.getLineWidth(tableLens.getColBorder(b, b1 - true)));
/*      */         arrayOfFloat[b1] = Math.max(arrayOfFloat[b1], f);
/*      */       } 
/*      */     } 
/*      */     return arrayOfFloat;
/*      */   }
/*      */   
/*      */   public float[][] calcColWidth(float paramFloat) {
/*      */     TableLens tableLens = getTable();
/*      */     Hashtable hashtable = new Hashtable();
/*      */     float[][] arrayOfFloat = new float[tableLens.getColCount()][2];
/*      */     int i = tableLens.getHeaderColCount() - 1;
/*      */     this.colBorderW = calcColBorderW();
/*      */     for (int j = 0; j < tableLens.getColCount(); j++) {
/*      */       float[] arrayOfFloat1 = { tableLens.getColWidth(j), 0.0F };
/*      */       if (arrayOfFloat1[0] == 0.0F) {
/*      */         arrayOfFloat[j][0] = 0.0F;
/*      */       } else {
/*      */         if (arrayOfFloat1[0] < 0.0F)
/*      */           for (int k = 0; k < tableLens.getRowCount(); k++) {
/*      */             float[] arrayOfFloat2, arrayOfFloat3 = (float[])hashtable.get(new Point(j, k));
/*      */             if (arrayOfFloat3 == null) {
/*      */               Font font = tableLens.getFont(k, j);
/*      */               font = (font == null) ? getFont() : font;
/*      */               arrayOfFloat2 = calcPrefMinWidth(tableLens.getObject(k, j), font, tableLens.isLineWrap(k, j), paramFloat);
/*      */               Insets insets = tableLens.getInsets(k, j);
/*      */               if (insets != null) {
/*      */                 arrayOfFloat2[0] = arrayOfFloat2[0] + (insets.left + insets.right);
/*      */                 arrayOfFloat2[1] = arrayOfFloat2[1] + (insets.left + insets.right);
/*      */               } 
/*      */               Dimension dimension = tableLens.getSpan(k, j);
/*      */               if (dimension != null) {
/*      */                 arrayOfFloat2[0] = arrayOfFloat2[0] / dimension.width;
/*      */                 arrayOfFloat2[1] = arrayOfFloat2[1] / dimension.width;
/*      */                 for (byte b = k; b < k + dimension.height; b++) {
/*      */                   for (byte b1 = j; b1 < j + dimension.width; b1++)
/*      */                     hashtable.put(new Point(b1, b), arrayOfFloat2); 
/*      */                 } 
/*      */               } 
/*      */             } else {
/*      */               arrayOfFloat2 = arrayOfFloat3;
/*      */               hashtable.remove(new Point(j, k));
/*      */             } 
/*      */             arrayOfFloat1[0] = Math.max(arrayOfFloat1[0], arrayOfFloat2[0]);
/*      */             arrayOfFloat1[1] = Math.max(arrayOfFloat1[1], arrayOfFloat2[1]);
/*      */           }  
/*      */         if (getPadding() != null) {
/*      */           arrayOfFloat1[0] = arrayOfFloat1[0] + ((getPadding()).left + (getPadding()).right);
/*      */           arrayOfFloat1[1] = arrayOfFloat1[1] + ((getPadding()).left + (getPadding()).right);
/*      */         } 
/*      */         arrayOfFloat[j][0] = arrayOfFloat1[0] + this.colBorderW[j];
/*      */         arrayOfFloat[j][1] = arrayOfFloat1[1] + this.colBorderW[j];
/*      */       } 
/*      */     } 
/*      */     return arrayOfFloat;
/*      */   }
/*      */   
/*      */   private float[] calcRowHeight(float[] paramArrayOfFloat, float paramFloat) {
/*      */     TableLens tableLens = getTable();
/*      */     Hashtable hashtable = new Hashtable();
/*      */     float[] arrayOfFloat = new float[tableLens.getRowCount()];
/*      */     this.rowBorderH = new float[tableLens.getRowCount()];
/*      */     for (byte b1 = 0; b1 < this.rowBorderH.length; b1++) {
/*      */       for (byte b = 0; b < tableLens.getColCount(); b++)
/*      */         this.rowBorderH[b1] = Math.max(this.rowBorderH[b1], Common.getLineWidth(tableLens.getRowBorder(b1 - true, b))); 
/*      */     } 
/*      */     Insets insets = getPadding();
/*      */     byte b2 = 0;
/*      */     for (int i = 0; i < tableLens.getRowCount(); i++) {
/*      */       float f = tableLens.getRowHeight(i);
/*      */       boolean bool = (f == 0.0F) ? 1 : 0;
/*      */       if (f < 0.0F)
/*      */         for (int j = 0; j < tableLens.getColCount(); j++) {
/*      */           Float float = (Float)hashtable.get(new Point(j, i));
/*      */           float f1 = 0.0F;
/*      */           if (float == null) {
/*      */             Font font = tableLens.getFont(i, j);
/*      */             font = (font == null) ? getFont() : font;
/*      */             Rectangle rectangle = (Rectangle)this.spanmap.get(new Point(j, i));
/*      */             Insets insets1 = tableLens.getInsets(i, j);
/*      */             float f2 = (insets1 == null) ? paramArrayOfFloat[j] : (paramArrayOfFloat[j] - insets1.left - insets1.right);
/*      */             if (insets != null)
/*      */               f2 -= (insets.left + insets.right); 
/*      */             if (rectangle != null)
/*      */               for (int m = j + rectangle.x; m < j + rectangle.width; m++) {
/*      */                 if (m != j)
/*      */                   f2 += this.colWidth[m]; 
/*      */               }  
/*      */             int k = tableLens.getHeaderColCount() - 1;
/*      */             f2 -= Math.max(Common.getLineWidth(tableLens.getColBorder(i, j - 1)), Common.getLineWidth(tableLens.getColBorder(i, k)));
/*      */             f1 = calcPreferredHeight(font, tableLens.getObject(i, j), (float)Math.ceil(f2), tableLens.isLineWrap(i, j));
/*      */             if (insets1 != null)
/*      */               f1 += (insets1.top + insets1.bottom); 
/*      */             Dimension dimension = tableLens.getSpan(i, j);
/*      */             if (dimension != null) {
/*      */               float f3 = Common.getHeight(font, null) + getSpacing();
/*      */               FontMetrics fontMetrics = Common.getFontMetrics(font);
/*      */               float f4 = f1;
/*      */               for (int m = i; m < i + dimension.height; m++) {
/*      */                 float f5 = StyleCore.roundup(f4 / (dimension.height - m + i), f3);
/*      */                 if (m == i)
/*      */                   f1 = f5; 
/*      */                 for (int n = j; n < j + dimension.width; n++)
/*      */                   hashtable.put(new Point(n, m), new Float(f5)); 
/*      */                 f4 = StyleCore.roundup(f4 - f5, f3);
/*      */               } 
/*      */             } 
/*      */           } else {
/*      */             f1 = float.intValue();
/*      */             hashtable.remove(new Point(j, i));
/*      */           } 
/*      */           f = Math.max(f, f1);
/*      */           if (f == 0.0F)
/*      */             f = Common.getHeight(getFont(), null); 
/*      */         }  
/*      */       if (!bool) {
/*      */         if (insets != null)
/*      */           f += (insets.top + insets.bottom); 
/*      */         f += this.rowBorderH[i];
/*      */       } else {
/*      */         b2++;
/*      */       } 
/*      */       paramFloat -= f;
/*      */       arrayOfFloat[i] = f;
/*      */     } 
/*      */     if (b2 > 0 && paramFloat > 3.0F) {
/*      */       float f = (paramFloat - 3.0F) / b2;
/*      */       for (byte b = 0; b < arrayOfFloat.length; b++) {
/*      */         if (arrayOfFloat[b] == 0.0F)
/*      */           arrayOfFloat[b] = f; 
/*      */       } 
/*      */     } 
/*      */     return arrayOfFloat;
/*      */   }
/*      */   
/*      */   private float[] calcPrefMinWidth(Object paramObject, Font paramFont, boolean paramBoolean, float paramFloat) {
/*      */     if (paramObject == null)
/*      */       return new float[] { 0.0F, 0.0F }; 
/*      */     float[] arrayOfFloat = new float[2];
/*      */     Presenter presenter = getPresenter(paramObject.getClass());
/*      */     if (presenter != null) {
/*      */       arrayOfFloat[0] = (presenter.getPreferredSize(paramObject)).width;
/*      */       arrayOfFloat[1] = arrayOfFloat[0];
/*      */       return arrayOfFloat;
/*      */     } 
/*      */     Format format = getFormat(paramObject.getClass());
/*      */     if (format != null)
/*      */       paramObject = format.format(paramObject); 
/*      */     if (paramObject instanceof String)
/*      */       return StyleCore.getPrefMinWidth((String)paramObject, paramFont, paramBoolean, paramFloat); 
/*      */     if (paramObject instanceof Painter) {
/*      */       arrayOfFloat[0] = (((Painter)paramObject).getPreferredSize()).width;
/*      */       arrayOfFloat[1] = arrayOfFloat[0];
/*      */       return arrayOfFloat;
/*      */     } 
/*      */     if (paramObject instanceof Component) {
/*      */       arrayOfFloat[0] = (((Component)paramObject).getSize()).width;
/*      */       arrayOfFloat[1] = arrayOfFloat[0];
/*      */       return arrayOfFloat;
/*      */     } 
/*      */     if (paramObject instanceof Image) {
/*      */       arrayOfFloat[0] = ((Image)paramObject).getWidth(null);
/*      */       arrayOfFloat[1] = arrayOfFloat[0];
/*      */       return arrayOfFloat;
/*      */     } 
/*      */     return StyleCore.getPrefMinWidth(Util.toString(paramObject), paramFont, paramBoolean, paramFloat);
/*      */   }
/*      */   
/*      */   private float calcPreferredHeight(Font paramFont, Object paramObject, float paramFloat, boolean paramBoolean) {
/*      */     if (paramObject == null)
/*      */       return 0.0F; 
/*      */     Presenter presenter = getPresenter(paramObject.getClass());
/*      */     if (presenter != null)
/*      */       return (presenter.getPreferredSize(paramObject)).height; 
/*      */     Format format = getFormat(paramObject.getClass());
/*      */     if (format != null)
/*      */       paramObject = format.format(paramObject); 
/*      */     if (paramObject instanceof Painter)
/*      */       return (((Painter)paramObject).getPreferredSize()).height; 
/*      */     if (paramObject instanceof Component)
/*      */       return (((Component)paramObject).getSize()).height; 
/*      */     if (paramObject instanceof Image)
/*      */       return ((Image)paramObject).getHeight(null); 
/*      */     String str1 = Util.toString(paramObject);
/*      */     FontMetrics fontMetrics = Common.getFontMetrics(paramFont);
/*      */     float f = 0.0F;
/*      */     int i = str1.indexOf('\n'), j = 0;
/*      */     String str2 = null;
/*      */     while (!j) {
/*      */       str2 = (i >= 0) ? str1.substring(j, i) : str1.substring(j);
/*      */       while (str2 != null) {
/*      */         f += Common.getHeight(paramFont, fontMetrics) + getSpacing();
/*      */         int k = Util.breakLine(str2, paramFloat, paramFont, true);
/*      */         if (paramBoolean && k >= 0 && str2.length() > 0) {
/*      */           str2 = str2.substring(Math.max(1, k));
/*      */           continue;
/*      */         } 
/*      */         str2 = null;
/*      */       } 
/*      */       if (i < 0)
/*      */         break; 
/*      */       j = i + 1;
/*      */       i = str1.indexOf('\n', j);
/*      */     } 
/*      */     return Math.max(f, Common.getHeight(paramFont, fontMetrics));
/*      */   }
/*      */   
/*      */   public double getTableWidth() { return this.tableW; }
/*      */   
/*      */   public void setTableWidth(double paramDouble) { this.tableW = paramDouble; }
/*      */   
/*      */   public int[] getFixedWidths() { return this.fixedWidths; }
/*      */   
/*      */   public void setFixedWidths(int[] paramArrayOfInt) { this.fixedWidths = paramArrayOfInt; }
/*      */   
/*      */   public int getLayout() { return this.autosize; }
/*      */   
/*      */   public void setLayout(int paramInt) { this.autosize = paramInt; }
/*      */   
/*      */   public Insets getPadding() { return this.padding; }
/*      */   
/*      */   public void setPadding(Insets paramInsets) { this.padding = paramInsets; }
/*      */   
/*      */   public int getTableAdvance() { return this.tableadv; }
/*      */   
/*      */   public void setTableAdvance(int paramInt) { this.tableadv = paramInt; }
/*      */   
/*      */   public void setOrphanControl(boolean paramBoolean) { this.orphan = paramBoolean; }
/*      */   
/*      */   public boolean isOrphanControl() { return this.orphan; }
/*      */   
/*      */   public TableLens getTable() { return this.tablelens; }
/*      */   
/*      */   public void setTable(TableLens paramTableLens) {
/*      */     this.tablelens = paramTableLens;
/*      */     if (paramTableLens instanceof SummaryTableLens)
/*      */       this.summary = (SummaryTableLens)paramTableLens; 
/*      */   }
/*      */   
/*      */   public void setOnClickRange(Point[] paramArrayOfPoint) { this.onClickRange = paramArrayOfPoint; }
/*      */   
/*      */   public Point[] getOnClickRange() { return this.onClickRange; }
/*      */   
/*      */   public float getColWidth(int paramInt) { return this.colWidth[paramInt]; }
/*      */   
/*      */   public void setContext(ReportElement paramReportElement) {
/*      */     super.setContext(paramReportElement);
/*      */     if (paramReportElement instanceof Context) {
/*      */       Context context = (Context)paramReportElement;
/*      */       setLayout(context.getTableLayout());
/*      */       setTableWidth(context.getTableWidth());
/*      */       setPadding(context.getCellPadding());
/*      */     } 
/*      */   }
/*      */   
/*      */   public String toString() { return getID() + " [" + Catalog.getString(getType()) + "]"; }
/*      */   
/*      */   public String getType() { return "Table"; }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TableElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */