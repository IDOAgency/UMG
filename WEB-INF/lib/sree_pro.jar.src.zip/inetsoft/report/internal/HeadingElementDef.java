/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.HeadingElement;
/*    */ import inetsoft.report.HeadingLens;
/*    */ import inetsoft.report.StyleSheet;
/*    */ import inetsoft.report.lens.DefaultHeadingLens;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeadingElementDef
/*    */   extends TextElementDef
/*    */   implements TextContext, HeadingElement
/*    */ {
/*    */   private HeadingLens heading;
/*    */   private String number;
/*    */   
/*    */   public HeadingElementDef(StyleSheet paramStyleSheet, HeadingLens paramHeadingLens) {
/* 33 */     super(paramStyleSheet, paramHeadingLens);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 86 */     this.number = null;
/*    */     this.heading = paramHeadingLens;
/*    */   }
/*    */   
/*    */   public void setText(String paramString) { setText(this.heading = new DefaultHeadingLens(paramString, this.heading.getLevel())); }
/*    */   
/*    */   public String getDisplayText() {
/*    */     if (this.number == null)
/*    */       this.number = this.report.getNextHeadingNumber(getLevel()); 
/*    */     return this.heading.format(this.number) + " " + super.getDisplayText();
/*    */   }
/*    */   
/*    */   public String getType() { return "Heading"; }
/*    */   
/*    */   public void reset() {
/*    */     super.reset();
/*    */     this.number = null;
/*    */   }
/*    */   
/*    */   public int getLevel() { return this.heading.getLevel(); }
/*    */   
/*    */   public void setLevel(int paramInt) {
/*    */     if (this.heading instanceof DefaultHeadingLens)
/*    */       ((DefaultHeadingLens)this.heading).setLevel(paramInt); 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\HeadingElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */