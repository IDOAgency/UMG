package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.Margin;
import inetsoft.report.ReportEnv;
import inetsoft.report.StyleSheet;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;
import java.util.Hashtable;

public class Win32Graphics extends Graphics implements Cloneable {
  public static final int CREATE_DEFAULT = 0;
  
  public static final int CREATE_NEW = 1;
  
  static final int CREATE_CLONE = 2;
  
  static final int JOIN_MITER = 0;
  
  static final int JOIN_ROUND = 1;
  
  static final int JOIN_BEVEL = 2;
  
  static final int CAP_BUTT = 0;
  
  static final int CAP_ROUND = 1;
  
  static final int CAP_SQUARE = 2;
  
  private native int getResolutionX0();
  
  private native int getResolutionY0();
  
  private native int getOffsetX0();
  
  private native int getOffsetY0();
  
  private native double getPageWidth0();
  
  private native double getPageHeight0();
  
  private native int getBitsPerPixel0();
  
  private native void setLandscape0(boolean paramBoolean);
  
  private native boolean isLandscape0();
  
  private native void setDuplex0(boolean paramBoolean);
  
  private native boolean isDuplex0();
  
  public void init() {
    this.resolutionX0 = getResolutionX0();
    this.resolutionY0 = getResolutionY0();
    this.pageSize0 = new Dimension((int)(getPageWidth0() * this.resolutionX0), (int)(getPageHeight0() * this.resolutionY0));
    this.pageSize = new Dimension(this.pageSize0.width * this.resolution / this.resolutionX0, this.pageSize0.height * this.resolution / this.resolutionY0);
    setPen0(getRGB(Color.black), realW(1.0D), 0, 0, 0);
    this.offset.x = getOffsetX0();
    this.offset.y = getOffsetY0();
  }
  
  public Point getMargin() { return this.offset; }
  
  public Dimension getPageSize() { return this.pageSize; }
  
  public int getResolution() { return this.resolution; }
  
  public void setOrientation(int paramInt) {
    if (isError())
      return; 
    setLandscape0((paramInt == 0));
    init();
  }
  
  public int getOrientation() { return isLandscape0() ? 0 : 1; }
  
  public void setDuplex(boolean paramBoolean) {
    if (isError())
      return; 
    setDuplex0(paramBoolean);
    init();
  }
  
  public boolean isDuplex() { return isDuplex0(); }
  
  public void setTray(int paramInt) { setTray0(paramInt); }
  
  private native void setTray0(int paramInt);
  
  public boolean isDither() {
    try {
      String str = ReportEnv.getProperty("StyleReport.dither");
      return (str != null && ((getBitsPerPixel0() == 1 && str.equalsIgnoreCase("true")) || str.equalsIgnoreCase("force")));
    } catch (Exception exception) {
      return false;
    } 
  }
  
  public Graphics create() {
    try {
      Win32Graphics win32Graphics = (Win32Graphics)clone();
      win32Graphics.cloned = true;
      win32Graphics.center = new Point(this.center);
      win32Graphics.context = win32Graphics.save0();
      return win32Graphics;
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public native int create0(int paramInt);
  
  public native int create1(String paramString);
  
  public native int create2();
  
  public native boolean printDialog0(int paramInt);
  
  public native int startDoc0(String paramString);
  
  public native boolean isPages0();
  
  public native int getFromPage0();
  
  public native int getToPage0();
  
  public native int getCopies0();
  
  public native void setCopies0(int paramInt);
  
  public void translate(int paramInt1, int paramInt2) {
    this.center.x += paramInt1;
    this.center.y += paramInt2;
  }
  
  public Color getColor() { return this.color; }
  
  public void setColor(Color paramColor) {
    if (isError())
      return; 
    this.color = paramColor;
    setColor0(getRGB(paramColor), realW(1.0D));
  }
  
  private native void setColor0(int paramInt1, int paramInt2);
  
  public native void setColor1(int paramInt);
  
  public native void setPen0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public native void setBrush0(byte[] paramArrayOfByte, int paramInt1, int paramInt2, boolean paramBoolean);
  
  public native void setPaintMode();
  
  public void setXORMode(Color paramColor) { setXORMode0(getRGB(paramColor) & 0xFFFFFF); }
  
  private native void setXORMode0(int paramInt);
  
  public Font getFont() { return this.font; }
  
  public void setFont(Font paramFont) {
    if (paramFont != null && !isError()) {
      this.font = paramFont;
      setFont0(getFontName(paramFont), paramFont.getStyle(), realH(paramFont.getSize()));
    } 
  }
  
  private native void setFont0(String paramString, int paramInt1, int paramInt2);
  
  public String getFontName(Font paramFont) {
    String str1 = Common.getFontName(paramFont);
    String str2 = (String)fontmap.get(str1.toLowerCase());
    if (str2 == null) {
      int i = str1.indexOf('.');
      if (i > 0)
        str2 = (String)fontmap.get(str1.substring(0, i).toLowerCase()); 
    } 
    return (str2 == null) ? str1 : str2;
  }
  
  public void putFontName(String paramString1, String paramString2) { fontmap.put(paramString1, paramString2); }
  
  public FontMetrics getFontMetrics(Font paramFont) { return Toolkit.getDefaultToolkit().getFontMetrics(paramFont); }
  
  public Rectangle getClipBounds() {
    Rectangle rectangle = getClipBounds0();
    if (rectangle == null)
      return new Rectangle(0, 0, this.pageSize.width, this.pageSize.height); 
    rectangle.x = virtualX(rectangle.x);
    rectangle.y = virtualY(rectangle.y);
    rectangle.width = virtualW(rectangle.width);
    rectangle.height = virtualH(rectangle.height);
    return rectangle;
  }
  
  private native Rectangle getClipBounds0();
  
  public void clipRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { clipRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void clipRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    if (isError())
      return; 
    clipRect0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4));
  }
  
  private native void clipRect0(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public void setClip(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { setClip(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void setClip(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    if (isError())
      return; 
    Margin margin = StyleSheet.getPrinterMargin();
    setClip0(realX(paramDouble1 + margin.left * this.resolution) - this.offset.x, realY(paramDouble2 + margin.top * this.resolution) - this.offset.y, realX(paramDouble1 + margin.left * this.resolution + paramDouble3) - this.offset.x, realY(paramDouble2 + margin.top * this.resolution + paramDouble4) - this.offset.y);
  }
  
  public native void setClip0(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public Shape getClip() { return getClipBounds(); }
  
  public void setClip(Shape paramShape) {
    if (paramShape instanceof Rectangle) {
      Rectangle rectangle = (Rectangle)paramShape;
      setClip(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    } 
  }
  
  public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { copyArea(realX(paramInt1), realY(paramInt2), realW(paramInt3), realH(paramInt4), realX(paramInt5), realY(paramInt6)); }
  
  private native void copyArea0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { drawLine(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void drawLine(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    if (isError())
      return; 
    double d1 = 0.5D;
    double d2 = paramDouble3 - paramDouble1, d3 = paramDouble4 - paramDouble2;
    double d4 = Math.sqrt(d2 * d2 + d3 * d3);
    double d5 = (d4 > 0.0D) ? (d1 * Math.abs(d3) / d4) : 0.0D;
    double d6 = (d4 > 0.0D) ? (d1 * Math.abs(d2) / d4) : 0.0D;
    if (paramDouble1 == paramDouble3 && paramDouble2 == paramDouble4)
      paramDouble3 += 0.5D; 
    drawLine0(realX(paramDouble1 + d5), realY(paramDouble2 + d6), realX(paramDouble3 + d5), realY(paramDouble4 + d6));
  }
  
  private native void drawLine0(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public void fillRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { fillRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void fillRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    if (isError())
      return; 
    fillRect0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4));
  }
  
  private native void fillRect0(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public void clearRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { clearRect(paramInt1, paramInt2, paramInt3, paramInt4, Color.white); }
  
  public void clearRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Color paramColor) {
    if (isError())
      return; 
    clearRect0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4), getRGB(paramColor));
  }
  
  private native void clearRect0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public void drawRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { drawRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void drawRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    if (paramDouble3 < 0.0D || paramDouble4 < 0.0D || isError())
      return; 
    if (paramDouble4 == 0.0D || paramDouble3 == 0.0D) {
      drawLine(paramDouble1, paramDouble2, paramDouble1 + paramDouble3, paramDouble2 + paramDouble4);
    } else {
      drawLine(paramDouble1, paramDouble2, paramDouble1 + paramDouble3, paramDouble2);
      drawLine(paramDouble1 + paramDouble3, paramDouble2, paramDouble1 + paramDouble3, paramDouble2 + paramDouble4);
      drawLine(paramDouble1 + paramDouble3, paramDouble2 + paramDouble4, paramDouble1, paramDouble2 + paramDouble4);
      drawLine(paramDouble1, paramDouble2 + paramDouble4, paramDouble1, paramDouble2);
    } 
  }
  
  public void drawRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { drawRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void drawRoundRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
    if (isError())
      return; 
    drawRoundRect0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4), realW(paramDouble5), realH(paramDouble6));
  }
  
  private native void drawRoundRect0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public void fillRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { fillRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void fillRoundRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
    if (isError())
      return; 
    fillRoundRect0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4), realW(paramDouble5), realH(paramDouble6));
  }
  
  private native void fillRoundRect0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public void drawOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { drawOval(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void drawOval(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    if (isError())
      return; 
    drawOval0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4));
  }
  
  private native void drawOval0(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public void fillOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { fillOval(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void fillOval(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    if (isError())
      return; 
    fillOval0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4));
  }
  
  private native void fillOval0(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public void drawArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { drawArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void drawArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
    if (isError() || paramDouble6 == 0.0D)
      return; 
    double d = paramDouble3 / paramDouble4;
    int i = (int)(paramDouble1 + paramDouble3 / 2.0D + 1000.0D * Math.cos(paramDouble5 / 180.0D * Math.PI) * d);
    int j = (int)(paramDouble2 + paramDouble4 / 2.0D - 1000.0D * Math.sin(paramDouble5 / 180.0D * Math.PI));
    int k = (int)(paramDouble1 + paramDouble3 / 2.0D + 1000.0D * Math.cos((paramDouble5 + paramDouble6) / 180.0D * Math.PI) * d);
    int m = (int)(paramDouble2 + paramDouble4 / 2.0D - 1000.0D * Math.sin((paramDouble5 + paramDouble6) / 180.0D * Math.PI));
    drawArc0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4), realX(i), realY(j), realX(k), realY(m));
  }
  
  private native void drawArc0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);
  
  public void fillArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { fillArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void fillArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
    if (isError() || paramDouble6 == 0.0D)
      return; 
    double d = paramDouble3 / paramDouble4;
    int i = (int)(paramDouble1 + paramDouble3 / 2.0D + 1000.0D * Math.cos(paramDouble5 / 180.0D * Math.PI) * d);
    int j = (int)(paramDouble2 + paramDouble4 / 2.0D - 1000.0D * Math.sin(paramDouble5 / 180.0D * Math.PI));
    int k = (int)(paramDouble1 + paramDouble3 / 2.0D + 1000.0D * Math.cos((paramDouble5 + paramDouble6) / 180.0D * Math.PI) * d);
    int m = (int)(paramDouble2 + paramDouble4 / 2.0D - 1000.0D * Math.sin((paramDouble5 + paramDouble6) / 180.0D * Math.PI));
    fillArc0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4), realX(i), realY(j), realX(k), realY(m));
  }
  
  private native void fillArc0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);
  
  public void drawPolyline(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) {
    if (isError())
      return; 
    int[] arrayOfInt1 = new int[paramArrayOfInt1.length];
    int[] arrayOfInt2 = new int[paramArrayOfInt2.length];
    for (byte b = 0; b < paramInt; b++) {
      arrayOfInt1[b] = realX(paramArrayOfInt1[b]);
      arrayOfInt2[b] = realY(paramArrayOfInt2[b]);
    } 
    drawPolyline0(arrayOfInt1, arrayOfInt2, paramInt);
  }
  
  private native void drawPolyline0(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt);
  
  public void drawPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) {
    if (isError())
      return; 
    int[] arrayOfInt1 = new int[paramArrayOfInt1.length];
    int[] arrayOfInt2 = new int[paramArrayOfInt2.length];
    for (byte b = 0; b < paramInt; b++) {
      arrayOfInt1[b] = realX(paramArrayOfInt1[b]);
      arrayOfInt2[b] = realY(paramArrayOfInt2[b]);
    } 
    drawPolygon0(arrayOfInt1, arrayOfInt2, paramInt);
  }
  
  private native void drawPolygon0(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt);
  
  public void fillPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) {
    if (isError())
      return; 
    int[] arrayOfInt1 = new int[paramArrayOfInt1.length];
    int[] arrayOfInt2 = new int[paramArrayOfInt2.length];
    for (byte b = 0; b < paramInt; b++) {
      arrayOfInt1[b] = realX(paramArrayOfInt1[b]);
      arrayOfInt2[b] = realY(paramArrayOfInt2[b]);
    } 
    fillPolygon0(arrayOfInt1, arrayOfInt2, paramInt);
  }
  
  private native void fillPolygon0(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt);
  
  public void drawString(String paramString, int paramInt1, int paramInt2) {
    if (isError())
      return; 
    drawString0(paramString, realX(paramInt1), realY(paramInt2), realW(Common.stringWidth(paramString, getFont())));
  }
  
  public void drawString(String paramString, double paramDouble1, double paramDouble2) {
    if (isError())
      return; 
    drawString0(paramString, realX(paramDouble1), realY(paramDouble2), realW(Common.stringWidth(paramString, getFont())));
  }
  
  private native void drawString0(String paramString, int paramInt1, int paramInt2, int paramInt3);
  
  public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, int paramInt1, int paramInt2) {}
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, 0, 0, paramImageObserver, null); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, null); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, Color paramColor, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, 0, 0, paramImageObserver, paramColor); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3 - paramInt1 + 1, paramInt4 - paramInt2 + 1, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver, null); }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, Color paramColor, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3 - paramInt1 + 1, paramInt4 - paramInt2 + 1, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver, paramColor); }
  
  public void dispose() {
    if (this.disposed || isError())
      return; 
    this.disposed = true;
    if (this.cloned) {
      setError((restore0(this.context) == 0));
    } else {
      setError((dispose0() < 0));
    } 
  }
  
  public native int dispose0();
  
  public native int save0();
  
  public native int restore0(int paramInt);
  
  public void nextPage() {
    if (isError())
      return; 
    setError((startPage0() < 0));
    if (!isError()) {
      Margin margin = StyleSheet.getPrinterMargin();
      this.origin = new Point(realX(margin.left * this.resolution) - this.offset.x, realY(margin.top * this.resolution) - this.offset.y);
      setViewportOrg0(this.origin.x, this.origin.y);
      this.disposed = false;
    } 
  }
  
  public native int startPage0();
  
  public native void setViewportOrg0(int paramInt1, int paramInt2);
  
  public void close() {
    if (!this.closed) {
      this.closed = true;
      close0(this.error);
    } 
  }
  
  public native void close0(boolean paramBoolean);
  
  protected boolean doImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
    PixelConsumer pixelConsumer = new PixelConsumer(paramImage);
    return doImage(pixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
  }
  
  protected boolean doImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver, Color paramColor) {
    PixelConsumer pixelConsumer = new PixelConsumer(paramImage, paramInt5, paramInt6, paramInt7, paramInt8);
    return doImage(pixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
  }
  
  public boolean isError() { return this.error; }
  
  public void setError(boolean paramBoolean) {
    this.error = paramBoolean;
    if (this.error)
      throw new RuntimeException("Printer operation failed"); 
  }
  
  public static int getRGB(Color paramColor) {
    if (paramColor == null)
      return 0; 
    return paramColor.getRed() & 0xFF | (paramColor.getGreen() & 0xFF) << 8 | (paramColor.getBlue() & 0xFF) << 16;
  }
  
  private static int approximate(int paramInt) { return (paramInt > 128) ? 255 : 0; }
  
  public byte[] getImageBytes(PixelConsumer paramPixelConsumer, Color paramColor) {
    paramPixelConsumer.produce();
    if (isDither()) {
      int i = getResolutionX0() / getResolution();
      int j = getResolutionY0() / getResolution();
      int k = i * paramPixelConsumer.width;
      int m = j * paramPixelConsumer.height;
      short[][] arrayOfShort = new short[k][m];
      byte b1;
      int n;
      for (b1 = 0, n = 0; b1 < paramPixelConsumer.height; b1++, n += j) {
        byte b;
        int i4;
        for (b = 0, i4 = 0; b < paramPixelConsumer.width; b++, i4 += i) {
          int i5 = paramPixelConsumer.pix[b][b1];
          if ((i5 & 0xFF000000) == 0)
            i5 = (paramColor == null) ? 16777215 : paramColor.getRGB(); 
          int i6 = Encoder.toGray((i5 & 0xFF0000) >> 16, (i5 & 0xFF00) >> 8, i5 & 0xFF);
          for (byte b3 = 0; b3 < j; b3++) {
            for (byte b4 = 0; b4 < i; b4++)
              arrayOfShort[i4 + b4][n + b3] = (short)i6; 
          } 
        } 
      } 
      paramPixelConsumer.pix = null;
      for (byte b2 = 0; b2 < m; b2++) {
        for (byte b = 0; b < k; b++) {
          int i4 = approximate(arrayOfShort[b][b2]);
          short s = arrayOfShort[b][b2] - i4;
          arrayOfShort[b][b2] = (short)i4;
          if (b < k - 1)
            arrayOfShort[b + true][b2] = (short)(arrayOfShort[b + true][b2] + 7 * s / 16); 
          if (b && b2 < m - 1)
            arrayOfShort[b - true][b2 + true] = (short)(arrayOfShort[b - true][b2 + true] + 3 * s / 16); 
          if (b2 < m - 1)
            arrayOfShort[b][b2 + true] = (short)(arrayOfShort[b][b2 + true] + 5 * s / 16); 
          if (b < k - 1 && b2 < m - 1)
            arrayOfShort[b + true][b2 + true] = (short)(arrayOfShort[b + true][b2 + true] + s / 16); 
        } 
      } 
      int i1 = (int)Math.ceil(k / 8.0D), i2 = m;
      i1 = (i1 % 4 != 0) ? (i1 + 4 - i1 % 4) : i1;
      byte[] arrayOfByte = new byte[i1 * i2];
      for (int i3 = m - 1; i3 >= 0; i3--) {
        int i4 = (m - 1 - i3) * i1;
        byte b3 = 0;
        for (byte b4 = 0; b4 < k; b4++) {
          byte b = (arrayOfShort[b4][i3] > 128) ? 1 : 0;
          if (b) {
            b = (byte)(b << 7 - b3);
            arrayOfByte[i4] = (byte)(arrayOfByte[i4] | b);
          } 
          b3++;
          if (b3 >= 8) {
            b3 = 0;
            i4++;
          } 
        } 
      } 
      paramPixelConsumer.width = k;
      paramPixelConsumer.height = m;
      return arrayOfByte;
    } 
    return Util.getImageBytesRGB(paramPixelConsumer, paramColor);
  }
  
  protected boolean doImage(PixelConsumer paramPixelConsumer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
    byte[] arrayOfByte = getImageBytes(paramPixelConsumer, paramColor);
    if (paramInt3 == 0)
      paramInt3 = paramPixelConsumer.iwidth; 
    if (paramInt4 == 0)
      paramInt4 = paramPixelConsumer.iheight; 
    drawImage0(arrayOfByte, paramPixelConsumer.width, paramPixelConsumer.height, realX(paramInt1), realY(paramInt2), realW(paramInt3), realH(paramInt4), (paramColor == null) ? 16777215 : (getRGB(paramColor) & 0xFFFFFF), isDither());
    return true;
  }
  
  public native void drawImage0(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean);
  
  public native void drawImage1(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean);
  
  public native void setTransform0(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
  
  public native double[] getTransform0();
  
  private int virtualX(double paramDouble) {
    double d = Math.round(this.pageSize.width * paramDouble / this.pageSize0.width);
    return (int)(d - this.center.x);
  }
  
  private int virtualY(double paramDouble) {
    double d = Math.round(this.pageSize.height * paramDouble / this.pageSize0.height);
    return (int)(d - this.center.y);
  }
  
  private int virtualW(double paramDouble) { return (int)Math.round(this.pageSize.width * paramDouble / this.pageSize0.width); }
  
  private int virtualH(double paramDouble) { return (int)Math.round(this.pageSize.height * paramDouble / this.pageSize0.height); }
  
  public int realX(double paramDouble) { return (int)Math.round(this.pageSize0.width * (paramDouble + this.center.x) / this.pageSize.width); }
  
  public int realY(double paramDouble) { return (int)Math.round(this.pageSize0.height * (paramDouble + this.center.y) / this.pageSize.height); }
  
  public int realW(double paramDouble) { return (int)Math.round(this.pageSize0.width * paramDouble / this.pageSize.width); }
  
  public int realH(double paramDouble) { return (int)Math.round(this.pageSize0.height * paramDouble / this.pageSize.height); }
  
  private int resolution = 72;
  
  private Dimension pageSize = new Dimension(610, 792);
  
  private int resolutionX0 = 72;
  
  private int resolutionY0 = 72;
  
  private Dimension pageSize0 = new Dimension(610, 792);
  
  private Point center = new Point(0, 0);
  
  private Color color = Color.black;
  
  private Font font = new Font("Dialog", 0, 10);
  
  private long handle = 0L;
  
  private boolean cloned = false;
  
  private int context = 0;
  
  private boolean closed = false;
  
  private Point origin = new Point(0, 0);
  
  private Point offset = new Point(0, 0);
  
  private boolean disposed = true;
  
  protected boolean error = false;
  
  public static boolean isInitialized() { return ok; }
  
  private static Hashtable fontmap = new Hashtable();
  
  private static boolean ok = false;
  
  static  {
    try {
      System.loadLibrary("Win32Printer");
      ok = true;
    } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
      System.err.println("Custom driver not used!");
      System.err.println("Please make sure the directory containing Win32Printer.dll is on the PATH.");
    } 
    fontmap.put("dialog", "Arial");
    fontmap.put("dialoginput", "Courier New");
    fontmap.put("serif", "Times New Roman");
    fontmap.put("sansserif", "Arial");
    fontmap.put("monospaced", "Courier New");
    fontmap.put("timesroman", "Times New Roman");
    fontmap.put("courier", "Courier New");
    fontmap.put("helvetica", "Arial");
    fontmap.put("zapfdingbats", "WingDings");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\Win32Graphics.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */