/*      */ package inetsoft.report.internal;
/*      */ 
/*      */ import inetsoft.report.Common;
/*      */ import inetsoft.report.Margin;
/*      */ import inetsoft.report.ReportEnv;
/*      */ import inetsoft.report.StyleSheet;
/*      */ import java.awt.Color;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Image;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Shape;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.image.ImageObserver;
/*      */ import java.text.AttributedCharacterIterator;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Win32Graphics
/*      */   extends Graphics
/*      */   implements Cloneable
/*      */ {
/*      */   public static final int CREATE_DEFAULT = 0;
/*      */   public static final int CREATE_NEW = 1;
/*      */   static final int CREATE_CLONE = 2;
/*      */   static final int JOIN_MITER = 0;
/*      */   static final int JOIN_ROUND = 1;
/*      */   static final int JOIN_BEVEL = 2;
/*      */   static final int CAP_BUTT = 0;
/*      */   static final int CAP_ROUND = 1;
/*      */   static final int CAP_SQUARE = 2;
/*      */   
/*      */   private native int getResolutionX0();
/*      */   
/*      */   private native int getResolutionY0();
/*      */   
/*      */   private native int getOffsetX0();
/*      */   
/*      */   private native int getOffsetY0();
/*      */   
/*      */   private native double getPageWidth0();
/*      */   
/*      */   private native double getPageHeight0();
/*      */   
/*      */   private native int getBitsPerPixel0();
/*      */   
/*      */   private native void setLandscape0(boolean paramBoolean);
/*      */   
/*      */   private native boolean isLandscape0();
/*      */   
/*      */   private native void setDuplex0(boolean paramBoolean);
/*      */   
/*      */   private native boolean isDuplex0();
/*      */   
/*      */   public void init() {
/*  118 */     this.resolutionX0 = getResolutionX0();
/*  119 */     this.resolutionY0 = getResolutionY0();
/*  120 */     this.pageSize0 = new Dimension((int)(getPageWidth0() * this.resolutionX0), (int)(getPageHeight0() * this.resolutionY0));
/*      */     
/*  122 */     this.pageSize = new Dimension(this.pageSize0.width * this.resolution / this.resolutionX0, this.pageSize0.height * this.resolution / this.resolutionY0);
/*      */     
/*  124 */     setPen0(getRGB(Color.black), realW(1.0D), 0, 0, 0);
/*  125 */     this.offset.x = getOffsetX0();
/*  126 */     this.offset.y = getOffsetY0();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  134 */   public Point getMargin() { return this.offset; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  141 */   public Dimension getPageSize() { return this.pageSize; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  148 */   public int getResolution() { return this.resolution; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOrientation(int paramInt) {
/*  157 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/*  161 */     setLandscape0((paramInt == 0));
/*  162 */     init();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  170 */   public int getOrientation() { return isLandscape0() ? 0 : 1; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDuplex(boolean paramBoolean) {
/*  179 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/*  183 */     setDuplex0(paramBoolean);
/*  184 */     init();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  192 */   public boolean isDuplex() { return isDuplex0(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  201 */   public void setTray(int paramInt) { setTray0(paramInt); }
/*      */ 
/*      */ 
/*      */   
/*      */   private native void setTray0(int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDither() {
/*      */     try {
/*  211 */       String str = ReportEnv.getProperty("StyleReport.dither");
/*  212 */       return (str != null && ((getBitsPerPixel0() == 1 && str.equalsIgnoreCase("true")) || str.equalsIgnoreCase("force")));
/*      */     
/*      */     }
/*  215 */     catch (Exception exception) {
/*      */ 
/*      */       
/*  218 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Graphics create() {
/*      */     try {
/*  230 */       Win32Graphics win32Graphics = (Win32Graphics)clone();
/*  231 */       win32Graphics.cloned = true;
/*  232 */       win32Graphics.center = new Point(this.center);
/*  233 */       win32Graphics.context = win32Graphics.save0();
/*  234 */       return win32Graphics;
/*      */     } catch (Exception exception) {
/*  236 */       exception.printStackTrace();
/*      */ 
/*      */       
/*  239 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native int create0(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native int create1(String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native int create2();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native boolean printDialog0(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native int startDoc0(String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native boolean isPages0();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native int getFromPage0();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native int getToPage0();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native int getCopies0();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native void setCopies0(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void translate(int paramInt1, int paramInt2) {
/*  313 */     this.center.x += paramInt1;
/*  314 */     this.center.y += paramInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  322 */   public Color getColor() { return this.color; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColor(Color paramColor) {
/*  332 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/*  336 */     this.color = paramColor;
/*      */     
/*  338 */     setColor0(getRGB(paramColor), realW(1.0D));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void setColor0(int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native void setColor1(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native void setPen0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native void setBrush0(byte[] paramArrayOfByte, int paramInt1, int paramInt2, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native void setPaintMode();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  388 */   public void setXORMode(Color paramColor) { setXORMode0(getRGB(paramColor) & 0xFFFFFF); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void setXORMode0(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  401 */   public Font getFont() { return this.font; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFont(Font paramFont) {
/*  411 */     if (paramFont != null && !isError()) {
/*  412 */       this.font = paramFont;
/*  413 */       setFont0(getFontName(paramFont), paramFont.getStyle(), realH(paramFont.getSize()));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void setFont0(String paramString, int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFontName(Font paramFont) {
/*  429 */     String str1 = Common.getFontName(paramFont);
/*  430 */     String str2 = (String)fontmap.get(str1.toLowerCase());
/*      */     
/*  432 */     if (str2 == null) {
/*  433 */       int i = str1.indexOf('.');
/*  434 */       if (i > 0) {
/*  435 */         str2 = (String)fontmap.get(str1.substring(0, i).toLowerCase());
/*      */       }
/*      */     } 
/*      */     
/*  439 */     return (str2 == null) ? str1 : str2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  449 */   public void putFontName(String paramString1, String paramString2) { fontmap.put(paramString1, paramString2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  458 */   public FontMetrics getFontMetrics(Font paramFont) { return Toolkit.getDefaultToolkit().getFontMetrics(paramFont); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Rectangle getClipBounds() {
/*  469 */     Rectangle rectangle = getClipBounds0();
/*      */     
/*  471 */     if (rectangle == null) {
/*  472 */       return new Rectangle(0, 0, this.pageSize.width, this.pageSize.height);
/*      */     }
/*      */     
/*  475 */     rectangle.x = virtualX(rectangle.x);
/*  476 */     rectangle.y = virtualY(rectangle.y);
/*  477 */     rectangle.width = virtualW(rectangle.width);
/*  478 */     rectangle.height = virtualH(rectangle.height);
/*      */     
/*  480 */     return rectangle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native Rectangle getClipBounds0();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  501 */   public void clipRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { clipRect(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clipRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  508 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/*  512 */     clipRect0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void clipRect0(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  530 */   public void setClip(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { setClip(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClip(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  537 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/*  541 */     Margin margin = StyleSheet.getPrinterMargin();
/*  542 */     setClip0(realX(paramDouble1 + margin.left * this.resolution) - this.offset.x, realY(paramDouble2 + margin.top * this.resolution) - this.offset.y, realX(paramDouble1 + margin.left * this.resolution + paramDouble3) - this.offset.x, realY(paramDouble2 + margin.top * this.resolution + paramDouble4) - this.offset.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native void setClip0(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  559 */   public Shape getClip() { return getClipBounds(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClip(Shape paramShape) {
/*  572 */     if (paramShape instanceof Rectangle) {
/*  573 */       Rectangle rectangle = (Rectangle)paramShape;
/*  574 */       setClip(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  600 */   public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { copyArea(realX(paramInt1), realY(paramInt2), realW(paramInt3), realH(paramInt4), realX(paramInt5), realY(paramInt6)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void copyArea0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  621 */   public void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { drawLine(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawLine(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  628 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  633 */     double d1 = 0.5D;
/*  634 */     double d2 = paramDouble3 - paramDouble1, d3 = paramDouble4 - paramDouble2;
/*      */     
/*  636 */     double d4 = Math.sqrt(d2 * d2 + d3 * d3);
/*      */     
/*  638 */     double d5 = (d4 > 0.0D) ? (d1 * Math.abs(d3) / d4) : 0.0D;
/*  639 */     double d6 = (d4 > 0.0D) ? (d1 * Math.abs(d2) / d4) : 0.0D;
/*      */ 
/*      */     
/*  642 */     if (paramDouble1 == paramDouble3 && paramDouble2 == paramDouble4) {
/*  643 */       paramDouble3 += 0.5D;
/*      */     }
/*      */     
/*  646 */     drawLine0(realX(paramDouble1 + d5), realY(paramDouble2 + d6), realX(paramDouble3 + d5), realY(paramDouble4 + d6));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void drawLine0(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  672 */   public void fillRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { fillRect(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */ 
/*      */   
/*      */   public void fillRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  676 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/*  680 */     fillRect0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void fillRect0(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  703 */   public void clearRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { clearRect(paramInt1, paramInt2, paramInt3, paramInt4, Color.white); }
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Color paramColor) {
/*  708 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/*  712 */     clearRect0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4), getRGB(paramColor));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void clearRect0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*      */ 
/*      */ 
/*      */   
/*  722 */   public void drawRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { drawRect(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */ 
/*      */   
/*      */   public void drawRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  726 */     if (paramDouble3 < 0.0D || paramDouble4 < 0.0D || isError()) {
/*      */       return;
/*      */     }
/*      */     
/*  730 */     if (paramDouble4 == 0.0D || paramDouble3 == 0.0D) {
/*  731 */       drawLine(paramDouble1, paramDouble2, paramDouble1 + paramDouble3, paramDouble2 + paramDouble4);
/*      */     } else {
/*  733 */       drawLine(paramDouble1, paramDouble2, paramDouble1 + paramDouble3, paramDouble2);
/*  734 */       drawLine(paramDouble1 + paramDouble3, paramDouble2, paramDouble1 + paramDouble3, paramDouble2 + paramDouble4);
/*  735 */       drawLine(paramDouble1 + paramDouble3, paramDouble2 + paramDouble4, paramDouble1, paramDouble2 + paramDouble4);
/*  736 */       drawLine(paramDouble1, paramDouble2 + paramDouble4, paramDouble1, paramDouble2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  757 */   public void drawRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { drawRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawRoundRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*  763 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/*  767 */     drawRoundRect0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4), realW(paramDouble5), realH(paramDouble6));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void drawRoundRect0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  794 */   public void fillRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { fillRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fillRoundRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*  800 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/*  804 */     fillRoundRect0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4), realW(paramDouble5), realH(paramDouble6));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void fillRoundRect0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  831 */   public void drawOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { drawOval(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */ 
/*      */   
/*      */   public void drawOval(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  835 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/*  839 */     drawOval0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void drawOval0(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  858 */   public void fillOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { fillOval(paramInt1, paramInt2, paramInt3, paramInt4); }
/*      */ 
/*      */   
/*      */   public void fillOval(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  862 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/*  866 */     fillOval0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void fillOval0(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  904 */   public void drawArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { drawArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*  910 */     if (isError() || paramDouble6 == 0.0D) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  915 */     double d = paramDouble3 / paramDouble4;
/*      */     
/*  917 */     int i = (int)(paramDouble1 + paramDouble3 / 2.0D + 1000.0D * Math.cos(paramDouble5 / 180.0D * Math.PI) * d);
/*  918 */     int j = (int)(paramDouble2 + paramDouble4 / 2.0D - 1000.0D * Math.sin(paramDouble5 / 180.0D * Math.PI));
/*  919 */     int k = (int)(paramDouble1 + paramDouble3 / 2.0D + 1000.0D * Math.cos((paramDouble5 + paramDouble6) / 180.0D * Math.PI) * d);
/*      */     
/*  921 */     int m = (int)(paramDouble2 + paramDouble4 / 2.0D - 1000.0D * Math.sin((paramDouble5 + paramDouble6) / 180.0D * Math.PI));
/*      */ 
/*      */     
/*  924 */     drawArc0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4), realX(i), realY(j), realX(k), realY(m));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void drawArc0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  963 */   public void fillArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { fillArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fillArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*  969 */     if (isError() || paramDouble6 == 0.0D) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  974 */     double d = paramDouble3 / paramDouble4;
/*      */     
/*  976 */     int i = (int)(paramDouble1 + paramDouble3 / 2.0D + 1000.0D * Math.cos(paramDouble5 / 180.0D * Math.PI) * d);
/*  977 */     int j = (int)(paramDouble2 + paramDouble4 / 2.0D - 1000.0D * Math.sin(paramDouble5 / 180.0D * Math.PI));
/*  978 */     int k = (int)(paramDouble1 + paramDouble3 / 2.0D + 1000.0D * Math.cos((paramDouble5 + paramDouble6) / 180.0D * Math.PI) * d);
/*      */     
/*  980 */     int m = (int)(paramDouble2 + paramDouble4 / 2.0D - 1000.0D * Math.sin((paramDouble5 + paramDouble6) / 180.0D * Math.PI));
/*      */ 
/*      */     
/*  983 */     fillArc0(realX(paramDouble1), realY(paramDouble2), realX(paramDouble1 + paramDouble3), realY(paramDouble2 + paramDouble4), realX(i), realY(j), realX(k), realY(m));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void fillArc0(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawPolyline(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) {
/* 1004 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/* 1008 */     int[] arrayOfInt1 = new int[paramArrayOfInt1.length];
/* 1009 */     int[] arrayOfInt2 = new int[paramArrayOfInt2.length];
/*      */     
/* 1011 */     for (byte b = 0; b < paramInt; b++) {
/* 1012 */       arrayOfInt1[b] = realX(paramArrayOfInt1[b]);
/* 1013 */       arrayOfInt2[b] = realY(paramArrayOfInt2[b]);
/*      */     } 
/*      */     
/* 1016 */     drawPolyline0(arrayOfInt1, arrayOfInt2, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void drawPolyline0(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) {
/* 1042 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/* 1046 */     int[] arrayOfInt1 = new int[paramArrayOfInt1.length];
/* 1047 */     int[] arrayOfInt2 = new int[paramArrayOfInt2.length];
/*      */     
/* 1049 */     for (byte b = 0; b < paramInt; b++) {
/* 1050 */       arrayOfInt1[b] = realX(paramArrayOfInt1[b]);
/* 1051 */       arrayOfInt2[b] = realY(paramArrayOfInt2[b]);
/*      */     } 
/*      */     
/* 1054 */     drawPolygon0(arrayOfInt1, arrayOfInt2, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void drawPolygon0(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fillPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) {
/* 1083 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/* 1087 */     int[] arrayOfInt1 = new int[paramArrayOfInt1.length];
/* 1088 */     int[] arrayOfInt2 = new int[paramArrayOfInt2.length];
/*      */     
/* 1090 */     for (byte b = 0; b < paramInt; b++) {
/* 1091 */       arrayOfInt1[b] = realX(paramArrayOfInt1[b]);
/* 1092 */       arrayOfInt2[b] = realY(paramArrayOfInt2[b]);
/*      */     } 
/*      */     
/* 1095 */     fillPolygon0(arrayOfInt1, arrayOfInt2, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void fillPolygon0(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawString(String paramString, int paramInt1, int paramInt2) {
/* 1111 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/* 1115 */     drawString0(paramString, realX(paramInt1), realY(paramInt2), realW(Common.stringWidth(paramString, getFont())));
/*      */   }
/*      */ 
/*      */   
/*      */   public void drawString(String paramString, double paramDouble1, double paramDouble2) {
/* 1120 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/* 1124 */     drawString0(paramString, realX(paramDouble1), realY(paramDouble2), realW(Common.stringWidth(paramString, getFont())));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private native void drawString0(String paramString, int paramInt1, int paramInt2, int paramInt3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, int paramInt1, int paramInt2) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1156 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, 0, 0, paramImageObserver, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1191 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1223 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, Color paramColor, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, 0, 0, paramImageObserver, paramColor); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1263 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1312 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3 - paramInt1 + 1, paramInt4 - paramInt2 + 1, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1368 */   public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, Color paramColor, ImageObserver paramImageObserver) { return doImage(paramImage, paramInt1, paramInt2, paramInt3 - paramInt1 + 1, paramInt4 - paramInt2 + 1, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver, paramColor); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dispose() {
/* 1396 */     if (this.disposed || isError()) {
/*      */       return;
/*      */     }
/* 1399 */     this.disposed = true;
/*      */     
/* 1401 */     if (this.cloned) {
/* 1402 */       setError((restore0(this.context) == 0));
/*      */     } else {
/*      */       
/* 1405 */       setError((dispose0() < 0));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native int dispose0();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native int save0();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native int restore0(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void nextPage() {
/* 1428 */     if (isError()) {
/*      */       return;
/*      */     }
/*      */     
/* 1432 */     setError((startPage0() < 0));
/*      */     
/* 1434 */     if (!isError()) {
/* 1435 */       Margin margin = StyleSheet.getPrinterMargin();
/* 1436 */       this.origin = new Point(realX(margin.left * this.resolution) - this.offset.x, realY(margin.top * this.resolution) - this.offset.y);
/*      */       
/* 1438 */       setViewportOrg0(this.origin.x, this.origin.y);
/* 1439 */       this.disposed = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native int startPage0();
/*      */ 
/*      */ 
/*      */   
/*      */   public native void setViewportOrg0(int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() {
/* 1455 */     if (!this.closed) {
/* 1456 */       this.closed = true;
/* 1457 */       close0(this.error);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public native void close0(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean doImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
/* 1469 */     PixelConsumer pixelConsumer = new PixelConsumer(paramImage);
/*      */     
/* 1471 */     return doImage(pixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean doImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver, Color paramColor) {
/* 1481 */     PixelConsumer pixelConsumer = new PixelConsumer(paramImage, paramInt5, paramInt6, paramInt7, paramInt8);
/*      */     
/* 1483 */     return doImage(pixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1490 */   public boolean isError() { return this.error; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setError(boolean paramBoolean) {
/* 1497 */     this.error = paramBoolean;
/* 1498 */     if (this.error) {
/* 1499 */       throw new RuntimeException("Printer operation failed");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getRGB(Color paramColor) {
/* 1507 */     if (paramColor == null) {
/* 1508 */       return 0;
/*      */     }
/*      */     
/* 1511 */     return paramColor.getRed() & 0xFF | (paramColor.getGreen() & 0xFF) << 8 | (paramColor.getBlue() & 0xFF) << 16;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1519 */   private static int approximate(int paramInt) { return (paramInt > 128) ? 255 : 0; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getImageBytes(PixelConsumer paramPixelConsumer, Color paramColor) {
/* 1526 */     paramPixelConsumer.produce();
/*      */ 
/*      */     
/* 1529 */     if (isDither()) {
/* 1530 */       int i = getResolutionX0() / getResolution();
/* 1531 */       int j = getResolutionY0() / getResolution();
/* 1532 */       int k = i * paramPixelConsumer.width;
/* 1533 */       int m = j * paramPixelConsumer.height;
/*      */       
/* 1535 */       short[][] arrayOfShort = new short[k][m];
/*      */       byte b1;
/*      */       int n;
/* 1538 */       for (b1 = 0, n = 0; b1 < paramPixelConsumer.height; b1++, n += j) {
/* 1539 */         byte b; int i4; for (b = 0, i4 = 0; b < paramPixelConsumer.width; b++, i4 += i) {
/* 1540 */           int i5 = paramPixelConsumer.pix[b][b1];
/*      */ 
/*      */           
/* 1543 */           if ((i5 & 0xFF000000) == 0) {
/* 1544 */             i5 = (paramColor == null) ? 16777215 : paramColor.getRGB();
/*      */           }
/*      */           
/* 1547 */           int i6 = Encoder.toGray((i5 & 0xFF0000) >> 16, (i5 & 0xFF00) >> 8, i5 & 0xFF);
/*      */ 
/*      */ 
/*      */           
/* 1551 */           for (byte b3 = 0; b3 < j; b3++) {
/* 1552 */             for (byte b4 = 0; b4 < i; b4++) {
/* 1553 */               arrayOfShort[i4 + b4][n + b3] = (short)i6;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1559 */       paramPixelConsumer.pix = null;
/*      */ 
/*      */       
/* 1562 */       for (byte b2 = 0; b2 < m; b2++) {
/* 1563 */         for (byte b = 0; b < k; b++) {
/* 1564 */           int i4 = approximate(arrayOfShort[b][b2]);
/* 1565 */           short s = arrayOfShort[b][b2] - i4;
/* 1566 */           arrayOfShort[b][b2] = (short)i4;
/*      */           
/* 1568 */           if (b < k - 1) {
/* 1569 */             arrayOfShort[b + true][b2] = (short)(arrayOfShort[b + true][b2] + 7 * s / 16);
/*      */           }
/*      */           
/* 1572 */           if (b && b2 < m - 1) {
/* 1573 */             arrayOfShort[b - true][b2 + true] = (short)(arrayOfShort[b - true][b2 + true] + 3 * s / 16);
/*      */           }
/*      */           
/* 1576 */           if (b2 < m - 1) {
/* 1577 */             arrayOfShort[b][b2 + true] = (short)(arrayOfShort[b][b2 + true] + 5 * s / 16);
/*      */           }
/*      */           
/* 1580 */           if (b < k - 1 && b2 < m - 1) {
/* 1581 */             arrayOfShort[b + true][b2 + true] = (short)(arrayOfShort[b + true][b2 + true] + s / 16);
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1587 */       int i1 = (int)Math.ceil(k / 8.0D), i2 = m;
/*      */ 
/*      */       
/* 1590 */       i1 = (i1 % 4 != 0) ? (i1 + 4 - i1 % 4) : i1;
/* 1591 */       byte[] arrayOfByte = new byte[i1 * i2];
/*      */       
/* 1593 */       for (int i3 = m - 1; i3 >= 0; i3--) {
/* 1594 */         int i4 = (m - 1 - i3) * i1;
/* 1595 */         byte b3 = 0;
/*      */         
/* 1597 */         for (byte b4 = 0; b4 < k; b4++) {
/* 1598 */           byte b = (arrayOfShort[b4][i3] > 128) ? 1 : 0;
/* 1599 */           if (b) {
/* 1600 */             b = (byte)(b << 7 - b3);
/* 1601 */             arrayOfByte[i4] = (byte)(arrayOfByte[i4] | b);
/*      */           } 
/*      */           
/* 1604 */           b3++;
/* 1605 */           if (b3 >= 8) {
/* 1606 */             b3 = 0;
/* 1607 */             i4++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1612 */       paramPixelConsumer.width = k;
/* 1613 */       paramPixelConsumer.height = m;
/* 1614 */       return arrayOfByte;
/*      */     } 
/*      */     
/* 1617 */     return Util.getImageBytesRGB(paramPixelConsumer, paramColor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean doImage(PixelConsumer paramPixelConsumer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
/* 1625 */     byte[] arrayOfByte = getImageBytes(paramPixelConsumer, paramColor);
/*      */     
/* 1627 */     if (paramInt3 == 0) {
/* 1628 */       paramInt3 = paramPixelConsumer.iwidth;
/*      */     }
/*      */     
/* 1631 */     if (paramInt4 == 0) {
/* 1632 */       paramInt4 = paramPixelConsumer.iheight;
/*      */     }
/*      */     
/* 1635 */     drawImage0(arrayOfByte, paramPixelConsumer.width, paramPixelConsumer.height, realX(paramInt1), realY(paramInt2), realW(paramInt3), realH(paramInt4), (paramColor == null) ? 16777215 : (getRGB(paramColor) & 0xFFFFFF), isDither());
/*      */ 
/*      */ 
/*      */     
/* 1639 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public native void drawImage0(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public native void drawImage1(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public native void setTransform0(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*      */ 
/*      */   
/*      */   public native double[] getTransform0();
/*      */ 
/*      */   
/*      */   private int virtualX(double paramDouble) {
/* 1658 */     double d = Math.round(this.pageSize.width * paramDouble / this.pageSize0.width);
/* 1659 */     return (int)(d - this.center.x);
/*      */   }
/*      */   
/*      */   private int virtualY(double paramDouble) {
/* 1663 */     double d = Math.round(this.pageSize.height * paramDouble / this.pageSize0.height);
/* 1664 */     return (int)(d - this.center.y);
/*      */   }
/*      */ 
/*      */   
/* 1668 */   private int virtualW(double paramDouble) { return (int)Math.round(this.pageSize.width * paramDouble / this.pageSize0.width); }
/*      */ 
/*      */ 
/*      */   
/* 1672 */   private int virtualH(double paramDouble) { return (int)Math.round(this.pageSize.height * paramDouble / this.pageSize0.height); }
/*      */ 
/*      */ 
/*      */   
/* 1676 */   public int realX(double paramDouble) { return (int)Math.round(this.pageSize0.width * (paramDouble + this.center.x) / this.pageSize.width); }
/*      */ 
/*      */ 
/*      */   
/* 1680 */   public int realY(double paramDouble) { return (int)Math.round(this.pageSize0.height * (paramDouble + this.center.y) / this.pageSize.height); }
/*      */ 
/*      */ 
/*      */   
/* 1684 */   public int realW(double paramDouble) { return (int)Math.round(this.pageSize0.width * paramDouble / this.pageSize.width); }
/*      */ 
/*      */ 
/*      */   
/* 1688 */   public int realH(double paramDouble) { return (int)Math.round(this.pageSize0.height * paramDouble / this.pageSize.height); }
/*      */ 
/*      */   
/* 1691 */   private int resolution = 72;
/* 1692 */   private Dimension pageSize = new Dimension(610, 792);
/* 1693 */   private int resolutionX0 = 72;
/* 1694 */   private int resolutionY0 = 72;
/* 1695 */   private Dimension pageSize0 = new Dimension(610, 792);
/* 1696 */   private Point center = new Point(0, 0);
/* 1697 */   private Color color = Color.black;
/* 1698 */   private Font font = new Font("Dialog", 0, 10);
/* 1699 */   private long handle = 0L;
/*      */   private boolean cloned = false;
/* 1701 */   private int context = 0;
/*      */   private boolean closed = false;
/* 1703 */   private Point origin = new Point(0, 0);
/* 1704 */   private Point offset = new Point(0, 0);
/*      */ 
/*      */   
/*      */   private boolean disposed = true;
/*      */   
/*      */   protected boolean error = false;
/*      */ 
/*      */   
/* 1712 */   public static boolean isInitialized() { return ok; }
/*      */ 
/*      */   
/* 1715 */   private static Hashtable fontmap = new Hashtable(); private static boolean ok = false;
/*      */   
/*      */   static  {
/*      */     try {
/* 1719 */       System.loadLibrary("Win32Printer");
/* 1720 */       ok = true;
/*      */     } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
/* 1722 */       System.err.println("Custom driver not used!");
/* 1723 */       System.err.println("Please make sure the directory containing Win32Printer.dll is on the PATH.");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1728 */     fontmap.put("dialog", "Arial");
/* 1729 */     fontmap.put("dialoginput", "Courier New");
/* 1730 */     fontmap.put("serif", "Times New Roman");
/* 1731 */     fontmap.put("sansserif", "Arial");
/* 1732 */     fontmap.put("monospaced", "Courier New");
/* 1733 */     fontmap.put("timesroman", "Times New Roman");
/* 1734 */     fontmap.put("courier", "Courier New");
/* 1735 */     fontmap.put("helvetica", "Arial");
/* 1736 */     fontmap.put("zapfdingbats", "WingDings");
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\Win32Graphics.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */