/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.FixedContainer;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.script.ElementScriptable;
/*     */ import inetsoft.report.script.ScriptEngine;
/*     */ import java.util.Vector;
/*     */ import org.mozilla.javascript.Script;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaScriptEnv
/*     */   extends ScriptEnv
/*     */ {
/*     */   StyleSheet report;
/*     */   ScriptEngine engine;
/*     */   
/*  39 */   public void setStyleSheet(StyleSheet paramStyleSheet) { this.report = paramStyleSheet; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public void reset() { this.engine = null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object compile(String paramString) throws Exception {
/*  54 */     init();
/*  55 */     return this.engine.compile(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object exec(ReportElement paramReportElement, Object paramObject1, Object paramObject2) throws Exception {
/*  68 */     init();
/*  69 */     Scriptable scriptable = (paramReportElement == null) ? (Scriptable)paramObject2 : this.engine.getScriptable(paramReportElement.getID(), (Scriptable)paramObject2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     if (scriptable instanceof ElementScriptable) {
/*  75 */       ((ElementScriptable)scriptable).setElement(paramReportElement);
/*     */     }
/*     */     
/*  78 */     return this.engine.exec((Script)paramObject1, (scriptable == null) ? (Scriptable)paramObject2 : scriptable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String paramString, Object paramObject) {
/*  89 */     this.vars.addElement(new Object[] { paramString, paramObject });
/*     */     
/*  91 */     if (this.engine != null) {
/*  92 */       this.engine.put(paramString, paramObject);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object newScope(FixedContainer paramFixedContainer) throws Exception {
/* 100 */     init();
/* 101 */     return this.engine.newScope(paramFixedContainer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init() {
/* 108 */     if (this.engine == null) {
/* 109 */       this.engine = new ScriptEngine();
/*     */       
/*     */       try {
/* 112 */         this.engine.init(this.report);
/*     */         
/* 114 */         for (byte b = 0; b < this.vars.size(); b++) {
/* 115 */           Object[] arrayOfObject = (Object[])this.vars.elementAt(b);
/* 116 */           this.engine.put((String)arrayOfObject[0], arrayOfObject[1]);
/*     */         } 
/*     */       } catch (Exception exception) {
/* 119 */         exception.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 126 */   Vector vars = new Vector();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\JavaScriptEnv.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */