package inetsoft.report.internal;

import inetsoft.report.Painter;
import inetsoft.report.StyleSheet;
import inetsoft.report.TextAreaElement;

public class TextAreaElementDef extends FieldElementDef implements TextAreaElement {
  TextAreaPainter painter;
  
  public TextAreaElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3, double paramDouble1, double paramDouble2) {
    super(paramStyleSheet, paramString1, paramString2, paramDouble1, paramDouble2);
    this.painter.setText(paramString3);
  }
  
  public TextAreaElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3) { this(paramStyleSheet, paramString1, paramString2, paramString3, 0.0D, 0.0D); }
  
  protected FieldPainter createPainter() { return this.painter = new TextAreaPainter(this); }
  
  public String getText() { return this.painter.getText(); }
  
  public void setText(String paramString) { this.painter.setText(paramString); }
  
  public int getCols() { return this.painter.getCols(); }
  
  public void setCols(int paramInt) { this.painter.setCols(paramInt); }
  
  public int getRows() { return this.painter.getRows(); }
  
  public void setRows(int paramInt) { this.painter.setRows(paramInt); }
  
  public void setPainter(Painter paramPainter) {
    super.setPainter(paramPainter);
    this.painter = (TextAreaPainter)paramPainter;
  }
  
  public String getType() { return "TextArea"; }
  
  public Object clone() throws CloneNotSupportedException {
    TextAreaElementDef textAreaElementDef = (TextAreaElementDef)super.clone();
    textAreaElementDef.setPainter(new TextAreaPainter(textAreaElementDef));
    textAreaElementDef.setText(this.painter.getText());
    return textAreaElementDef;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TextAreaElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */