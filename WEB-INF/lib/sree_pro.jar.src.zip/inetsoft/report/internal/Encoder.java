package inetsoft.report.internal;

import inetsoft.report.Common;
import java.awt.Image;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Serializable;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

public class Encoder implements Serializable {
  public static byte[] encodeImage(Image paramImage) {
    PixelConsumer pixelConsumer = new PixelConsumer(paramImage);
    pixelConsumer.produce();
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    for (byte b = 0; b < pixelConsumer.height; b++) {
      for (byte b1 = 0; b1 < pixelConsumer.width; b1++) {
        int i = pixelConsumer.pix[b1][b];
        if ((i & 0xFF000000) == 0)
          i = 16777215; 
        byteArrayOutputStream.write((byte)((i & 0xFF0000) >> 16));
        byteArrayOutputStream.write((byte)((i & 0xFF00) >> 8));
        byteArrayOutputStream.write((byte)(i & 0xFF));
      } 
    } 
    return byteArrayOutputStream.toByteArray();
  }
  
  public static int toGray(int paramInt1, int paramInt2, int paramInt3) { return (int)(0.299D * paramInt1 + 0.587D * paramInt2 + 0.114D * paramInt3); }
  
  public static Image decodeImage(int paramInt1, int paramInt2, byte[] paramArrayOfByte) { return Common.createImage(paramArrayOfByte, paramInt1, paramInt2); }
  
  public static byte[] encodeAscii85(byte[] paramArrayOfByte) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    byte[] arrayOfByte = new byte[5];
    for (int i = 0; i < paramArrayOfByte.length; ) {
      int j = Math.min(paramArrayOfByte.length - i, 4);
      long l1 = (0xFF & paramArrayOfByte[i++]);
      long l2 = (i < paramArrayOfByte.length) ? (paramArrayOfByte[i++] & 0xFF) : 0L;
      long l3 = (i < paramArrayOfByte.length) ? (paramArrayOfByte[i++] & 0xFF) : 0L;
      long l4 = (i < paramArrayOfByte.length) ? (paramArrayOfByte[i++] & 0xFF) : 0L;
      if (l1 == 0L && l2 == 0L && l3 == 0L && l4 == 0L && j == 4) {
        byteArrayOutputStream.write(122);
        continue;
      } 
      long l5 = (l1 << 24) + (l2 << 16) + (l3 << 8) + l4;
      for (byte b = 0; b < arrayOfByte.length; b++) {
        arrayOfByte[4 - b] = (byte)(int)(l5 % 85L + 33L);
        l5 /= 85L;
      } 
      byteArrayOutputStream.write(arrayOfByte, 0, j + 1);
    } 
    return byteArrayOutputStream.toByteArray();
  }
  
  public static byte[] decodeAscii85(byte[] paramArrayOfByte) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    for (byte b = 0; b < paramArrayOfByte.length; b++) {
      byte[] arrayOfByte = new byte[5];
      if (paramArrayOfByte[b] == 122) {
        byteArrayOutputStream.write(0);
        byteArrayOutputStream.write(0);
        byteArrayOutputStream.write(0);
        byteArrayOutputStream.write(0);
      } else {
        byte b1 = 0;
        for (; b1 < arrayOfByte.length && b < paramArrayOfByte.length; b1++, b++)
          arrayOfByte[b1] = (byte)(paramArrayOfByte[b] - 33); 
        b--;
        long l = 0L;
        for (byte b2 = 0; b2 < arrayOfByte.length; b2++)
          l = l * 85L + ((b2 < b1) ? arrayOfByte[b2] : 85L); 
        if (--b1 <= 0)
          break; 
        byteArrayOutputStream.write((byte)(int)(l >> 24 & 0xFFL));
        if (--b1 <= 0)
          break; 
        byteArrayOutputStream.write((byte)(int)(l >> 16 & 0xFFL));
        if (--b1 <= 0)
          break; 
        byteArrayOutputStream.write((byte)(int)(l >> 8 & 0xFFL));
        if (--b1 <= 0)
          break; 
        byteArrayOutputStream.write((byte)(int)(l & 0xFFL));
      } 
    } 
    return byteArrayOutputStream.toByteArray();
  }
  
  public static byte[] deflate(byte[] paramArrayOfByte) {
    Deflater deflater = new Deflater(9);
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(byteArrayOutputStream, deflater);
    try {
      deflaterOutputStream.write(paramArrayOfByte, 0, paramArrayOfByte.length);
      deflaterOutputStream.close();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return byteArrayOutputStream.toByteArray();
  }
  
  public static byte[] inflate(byte[] paramArrayOfByte) {
    Inflater inflater = new Inflater();
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    InflaterInputStream inflaterInputStream = new InflaterInputStream(byteArrayInputStream, inflater);
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      byte[] arrayOfByte = new byte[256];
      int i;
      while ((i = inflaterInputStream.read(arrayOfByte, 0, arrayOfByte.length)) >= 0)
        byteArrayOutputStream.write(arrayOfByte, 0, i); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return byteArrayOutputStream.toByteArray();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\Encoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */