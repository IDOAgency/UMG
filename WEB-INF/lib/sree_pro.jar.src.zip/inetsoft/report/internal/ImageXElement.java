/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.XStyleSheet;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.report.painter.ImagePainter;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageXElement
/*     */   extends PainterElementDef
/*     */ {
/*     */   public static final int FULL_PATH = 1;
/*     */   public static final int RELATIVE_PATH = 2;
/*     */   public static final int RESOURCE = 3;
/*     */   public static final int IMAGE_URL = 4;
/*     */   ImageLocation iloc;
/*     */   
/*     */   public ImageXElement(StyleSheet paramStyleSheet) {
/*  42 */     super(paramStyleSheet, new EmptyPainter());
/*  43 */     this.iloc = new ImageLocation(((XStyleSheet)paramStyleSheet).getDirectory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public boolean isEmbedded() { return this.iloc.isEmbedded(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public void setEmbedded(boolean paramBoolean) { this.iloc.setEmbedded(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public String getPath() { return this.iloc.getPath(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPath(String paramString) throws IOException {
/*  72 */     this.iloc.setPath(paramString);
/*  73 */     updateImage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public int getPathType() { return this.iloc.getPathType(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public void setPathType(int paramInt) throws IOException { this.iloc.setPathType(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateImage() throws IOException {
/*  94 */     MetaImage metaImage = (MetaImage)this.iloc.getImage();
/*  95 */     if (metaImage.getImage() == null) {
/*  96 */       throw new IOException("Image not found: " + this.iloc.getPath());
/*     */     }
/*     */     
/*  99 */     setPainter(new ImagePainter(metaImage));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public String getAdjustedPath() { return this.iloc.getAdjustedPath(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public ImageLocation getImageLocation() { return this.iloc; }
/*     */ 
/*     */ 
/*     */   
/* 119 */   public String toString() { return getID() + " [" + Catalog.getString(getType()) + ": " + getPath() + "]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public String getType() { return "Image"; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ImageXElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */