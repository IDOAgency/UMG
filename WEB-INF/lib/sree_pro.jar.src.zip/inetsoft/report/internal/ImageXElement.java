package inetsoft.report.internal;

import inetsoft.report.StyleSheet;
import inetsoft.report.XStyleSheet;
import inetsoft.report.locale.Catalog;
import inetsoft.report.painter.ImagePainter;
import java.io.IOException;

public class ImageXElement extends PainterElementDef {
  public static final int FULL_PATH = 1;
  
  public static final int RELATIVE_PATH = 2;
  
  public static final int RESOURCE = 3;
  
  public static final int IMAGE_URL = 4;
  
  ImageLocation iloc;
  
  public ImageXElement(StyleSheet paramStyleSheet) {
    super(paramStyleSheet, new EmptyPainter());
    this.iloc = new ImageLocation(((XStyleSheet)paramStyleSheet).getDirectory());
  }
  
  public boolean isEmbedded() { return this.iloc.isEmbedded(); }
  
  public void setEmbedded(boolean paramBoolean) { this.iloc.setEmbedded(paramBoolean); }
  
  public String getPath() { return this.iloc.getPath(); }
  
  public void setPath(String paramString) throws IOException {
    this.iloc.setPath(paramString);
    updateImage();
  }
  
  public int getPathType() { return this.iloc.getPathType(); }
  
  public void setPathType(int paramInt) throws IOException { this.iloc.setPathType(paramInt); }
  
  public void updateImage() throws IOException {
    MetaImage metaImage = (MetaImage)this.iloc.getImage();
    if (metaImage.getImage() == null)
      throw new IOException("Image not found: " + this.iloc.getPath()); 
    setPainter(new ImagePainter(metaImage));
  }
  
  public String getAdjustedPath() { return this.iloc.getAdjustedPath(); }
  
  public ImageLocation getImageLocation() { return this.iloc; }
  
  public String toString() { return getID() + " [" + Catalog.getString(getType()) + ": " + getPath() + "]"; }
  
  public String getType() { return "Image"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ImageXElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */