/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.Painter;
/*     */ import inetsoft.report.ReportElement;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ public class PainterPaintable
/*     */   extends BasePaintable
/*     */ {
/*     */   float x;
/*     */   float y;
/*     */   int oY;
/*     */   int painterW;
/*     */   int painterH;
/*     */   int prefH;
/*     */   Dimension pd;
/*     */   Painter painter;
/*     */   boolean breakable;
/*     */   
/*     */   public PainterPaintable(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2, Dimension paramDimension, int paramInt3, ReportElement paramReportElement, Painter paramPainter, int paramInt4) {
/*  30 */     super(paramReportElement);
/*  31 */     this.x = Common.round(paramFloat1);
/*  32 */     this.y = Common.round(paramFloat2);
/*  33 */     this.painterW = paramInt1;
/*  34 */     this.painterH = paramInt2;
/*  35 */     this.prefH = paramInt3;
/*  36 */     this.pd = paramDimension;
/*  37 */     this.painter = paramPainter;
/*  38 */     this.oY = paramInt4;
/*     */   }
/*     */   
/*     */   public void paint(Graphics paramGraphics) {
/*  42 */     Shape shape = paramGraphics.getClip();
/*     */ 
/*     */     
/*  45 */     paramGraphics.clipRect((int)this.x, (int)this.y, this.painterW, this.painterH);
/*     */     
/*  47 */     int i = this.pd.width;
/*     */ 
/*     */ 
/*     */     
/*  51 */     int j = this.pd.height * this.painterH / Math.max(1, this.prefH);
/*     */     
/*  53 */     boolean bool = (!this.painter.isScalable() && (i != this.painterW || j != this.painterH)) ? 1 : 0;
/*     */     
/*  55 */     Color color = this.elem.getBackground();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     if (bool) {
/*  62 */       Common.paint(paramGraphics, this.x, this.y, this.painterW, this.painterH, this.painter, 0.0F, -this.oY, this.pd.width, this.pd.height, j, this.elem.getForeground(), color);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/*  68 */       if (color != null) {
/*  69 */         paramGraphics.setColor(color);
/*  70 */         paramGraphics.fillRect((int)this.x, (int)this.y, i, j);
/*     */       } 
/*     */ 
/*     */       
/*  74 */       paramGraphics.setColor(this.elem.getForeground());
/*  75 */       this.painter.paint(paramGraphics, (int)this.x, (int)(this.y - this.oY), this.pd.width, this.pd.height);
/*     */     } 
/*     */ 
/*     */     
/*  79 */     paramGraphics.setClip(shape);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public Rectangle getBounds() { return new Rectangle((int)this.x, (int)this.y, this.painterW, this.painterH); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public void setLocation(Point paramPoint) { this.x = paramPoint.x; this.y = paramPoint.y; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public Painter getPainter() { return this.painter; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
/* 110 */     paramObjectInputStream.defaultReadObject();
/* 111 */     this.elem = new DefaultContext();
/* 112 */     ((DefaultContext)this.elem).read(paramObjectInputStream);
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/* 116 */     paramObjectOutputStream.defaultWriteObject();
/* 117 */     DefaultContext.write(paramObjectOutputStream, this.elem);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\PainterPaintable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */