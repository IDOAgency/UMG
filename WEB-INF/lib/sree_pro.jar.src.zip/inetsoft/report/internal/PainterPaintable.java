package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.Painter;
import inetsoft.report.ReportElement;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class PainterPaintable extends BasePaintable {
  float x;
  
  float y;
  
  int oY;
  
  int painterW;
  
  int painterH;
  
  int prefH;
  
  Dimension pd;
  
  Painter painter;
  
  boolean breakable;
  
  public PainterPaintable(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2, Dimension paramDimension, int paramInt3, ReportElement paramReportElement, Painter paramPainter, int paramInt4) {
    super(paramReportElement);
    this.x = Common.round(paramFloat1);
    this.y = Common.round(paramFloat2);
    this.painterW = paramInt1;
    this.painterH = paramInt2;
    this.prefH = paramInt3;
    this.pd = paramDimension;
    this.painter = paramPainter;
    this.oY = paramInt4;
  }
  
  public void paint(Graphics paramGraphics) {
    Shape shape = paramGraphics.getClip();
    paramGraphics.clipRect((int)this.x, (int)this.y, this.painterW, this.painterH);
    int i = this.pd.width;
    int j = this.pd.height * this.painterH / Math.max(1, this.prefH);
    boolean bool = (!this.painter.isScalable() && (i != this.painterW || j != this.painterH)) ? 1 : 0;
    Color color = this.elem.getBackground();
    if (bool) {
      Common.paint(paramGraphics, this.x, this.y, this.painterW, this.painterH, this.painter, 0.0F, -this.oY, this.pd.width, this.pd.height, j, this.elem.getForeground(), color);
    } else {
      if (color != null) {
        paramGraphics.setColor(color);
        paramGraphics.fillRect((int)this.x, (int)this.y, i, j);
      } 
      paramGraphics.setColor(this.elem.getForeground());
      this.painter.paint(paramGraphics, (int)this.x, (int)(this.y - this.oY), this.pd.width, this.pd.height);
    } 
    paramGraphics.setClip(shape);
  }
  
  public Rectangle getBounds() { return new Rectangle((int)this.x, (int)this.y, this.painterW, this.painterH); }
  
  public void setLocation(Point paramPoint) { this.x = paramPoint.x;
    this.y = paramPoint.y; }
  
  public Painter getPainter() { return this.painter; }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
    paramObjectInputStream.defaultReadObject();
    this.elem = new DefaultContext();
    ((DefaultContext)this.elem).read(paramObjectInputStream);
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    paramObjectOutputStream.defaultWriteObject();
    DefaultContext.write(paramObjectOutputStream, this.elem);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\PainterPaintable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */