package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.Margin;
import inetsoft.report.Painter;
import inetsoft.report.ReportElement;
import inetsoft.report.Size;
import inetsoft.report.StyleConstants;
import inetsoft.report.TextLens;
import inetsoft.report.lens.DefaultTextLens;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TextPainter implements Painter, StyleConstants, Cloneable {
  private int border;
  
  private Insets borders;
  
  private int shape;
  
  private TextLens text;
  
  private Insets padding;
  
  private boolean justify;
  
  private int talignment;
  
  private ReportElement elem;
  
  public TextPainter(ReportElement paramReportElement) {
    this.border = 4097;
    this.borders = null;
    this.shape = 1;
    this.padding = new Insets(0, 0, 0, 0);
    this.talignment = 18;
    this.elem = paramReportElement;
  }
  
  public void setBorder(int paramInt) { this.border = paramInt; }
  
  public int getBorder() { return this.border; }
  
  public void setBorders(Insets paramInsets) { this.borders = paramInsets; }
  
  public Insets getBorders() { return this.borders; }
  
  public void setShape(int paramInt) { this.shape = paramInt; }
  
  public int getShape() { return this.shape; }
  
  public Insets getPadding() { return this.padding; }
  
  public void setPadding(Insets paramInsets) { this.padding = paramInsets; }
  
  public boolean isJustify() { return this.justify; }
  
  public void setJustify(boolean paramBoolean) { this.justify = paramBoolean; }
  
  public String getText() { return this.text.getText(); }
  
  public void setText(String paramString) { this.text = new DefaultTextLens(paramString); }
  
  public void setText(TextLens paramTextLens) { this.text = paramTextLens; }
  
  public TextLens getTextLens() { return this.text; }
  
  public int getTextAlignment() { return this.talignment; }
  
  public void setTextAlignment(int paramInt) { this.talignment = paramInt; }
  
  public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Margin margin = new Margin();
    Insets insets = calcPadding();
    String str = (this.text instanceof HeaderTextLens) ? ((HeaderTextLens)this.text).getDisplayText() : ((this.text == null) ? "" : this.text.getText());
    paramGraphics.setColor(this.elem.getForeground());
    paramGraphics.setFont(this.elem.getFont());
    if (this.borders != null) {
      int i = (this.borders.top != -1) ? this.borders.top : 0;
      int j = (this.borders.left != -1) ? this.borders.left : 0;
      int k = (this.borders.bottom != -1) ? this.borders.bottom : 0;
      int m = (this.borders.right != -1) ? this.borders.right : 0;
      float f1 = Common.getLineWidth(i);
      float f2 = Common.getLineWidth(j);
      float f3 = Common.getLineWidth(k);
      float f4 = Common.getLineWidth(m);
      margin = new Margin(f1, f2, f3, f4);
      Common.drawRect(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, i, j, k, m);
    } else {
      byte b = (this.border == -1) ? 0 : this.border;
      margin.top = Common.getLineWidth(b);
      margin.left = margin.bottom = margin.right = margin.top;
      if (b != 0)
        switch (this.shape) {
          case 1:
            Common.drawRect(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, b);
            break;
          case 2:
            paramGraphics.drawRoundRect(paramInt1, paramInt2, paramInt3 - 1, paramInt4 - 1, 5, 5);
            break;
        }  
    } 
    Common.paintText(paramGraphics, str, new Bounds((float)(paramInt1 + margin.left + insets.left), (float)(paramInt2 + margin.top + insets.top), (float)(paramInt3 - margin.left - margin.right - insets.left - insets.right), (float)(paramInt4 - margin.top - margin.bottom - insets.top - insets.bottom)), getTextAlignment(), true, isJustify(), this.elem.getSpacing());
  }
  
  public Dimension getPreferredSize() {
    float f = 2.0F * Common.getLineWidth(this.border);
    String str = (this.text instanceof HeaderTextLens) ? ((HeaderTextLens)this.text).getDisplayText() : ((this.text == null) ? "" : this.text.getText());
    Size size = (str.length() == 0) ? new Size(20.0F, 15.0F) : StyleCore.getTextSize(str, this.elem.getFont(), this.elem.getSpacing());
    Insets insets = calcPadding();
    return new Dimension((int)(size.width + f + insets.left + insets.right), (int)(size.height + f + insets.top + insets.bottom));
  }
  
  public boolean isScalable() { return true; }
  
  private Insets calcPadding() {
    Insets insets = new Insets(this.padding.top, this.padding.left, this.padding.bottom, this.padding.right);
    int i = 0;
    if (this.shape == 2)
      i = 5; 
    insets.top += i;
    insets.left += i;
    insets.bottom += i;
    insets.right += i;
    return insets;
  }
  
  public TextPainter clone(TextLens paramTextLens) {
    try {
      TextPainter textPainter = (TextPainter)clone();
      if (paramTextLens != null)
        textPainter.text = paramTextLens; 
      return textPainter;
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
    paramObjectInputStream.defaultReadObject();
    this.elem = new DefaultContext();
    ((DefaultContext)this.elem).read(paramObjectInputStream);
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    paramObjectOutputStream.defaultWriteObject();
    DefaultContext.write(paramObjectOutputStream, this.elem);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TextPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */