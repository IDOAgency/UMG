package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.Painter;
import inetsoft.report.ReportElement;
import inetsoft.report.StyleConstants;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public abstract class FieldPainter implements Painter, StyleConstants, Cloneable {
  protected String form;
  
  protected String name;
  
  protected ReportElement elem;
  
  public FieldPainter(ReportElement paramReportElement) { this.elem = paramReportElement; }
  
  public abstract Object getValue();
  
  public String getName() { return this.name; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getForm() { return this.form; }
  
  public void setForm(String paramString) { this.form = paramString; }
  
  public boolean isScalable() { return true; }
  
  protected void waitImage(Image paramImage) { Common.waitForImage(paramImage); }
  
  public Object clone() { return super.clone(); }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
    paramObjectInputStream.defaultReadObject();
    this.elem = new DefaultContext();
    ((DefaultContext)this.elem).read(paramObjectInputStream);
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    paramObjectOutputStream.defaultWriteObject();
    DefaultContext.write(paramObjectOutputStream, this.elem);
  }
  
  public abstract Dimension getPreferredSize();
  
  public abstract void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\FieldPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */