package inetsoft.report.internal;

import inetsoft.report.Common;
import inetsoft.report.Paintable;
import inetsoft.report.Position;
import inetsoft.report.StylePage;
import inetsoft.report.StyleSheet;
import inetsoft.report.TabElement;
import inetsoft.report.locale.Catalog;
import java.awt.Point;
import java.awt.Rectangle;

public class TabElementDef extends TabSupport implements TabElement {
  boolean right;
  
  public TabElementDef(StyleSheet paramStyleSheet, boolean paramBoolean) {
    this(paramStyleSheet, 0);
    this.right = paramBoolean;
  }
  
  public TabElementDef(StyleSheet paramStyleSheet, int paramInt) {
    super(paramStyleSheet, paramInt);
    this.right = false;
  }
  
  public boolean isRightTab() { return this.right; }
  
  public void setRightTab(boolean paramBoolean) { this.right = paramBoolean; }
  
  public boolean print(StylePage paramStylePage) {
    if (!isVisible())
      return false; 
    super.print(paramStylePage);
    Position position = new Position(this.report.printHead);
    if (printTab(paramStylePage))
      return true; 
    if (isRightTab() && this.report.printHead.x > position.x) {
      if (this.report.designtime && TabSupport.rtabMarker == null)
        try {
          TabSupport.rtabMarker = Common.getImage(this, "/inetsoft/report/images/rtabmarker.gif");
          Common.waitForImage(TabSupport.rtabMarker);
        } catch (Exception exception) {
          exception.printStackTrace();
        }  
      Paintable paintable = paramStylePage.getPaintable(paramStylePage.getPaintableCount() - 1);
      Rectangle rectangle1 = paintable.getBounds();
      int i = paramStylePage.getPaintableCount() - 2;
      Rectangle rectangle2 = paramStylePage.getPaintable(i).getBounds();
      int j = (int)(this.report.printHead.x - position.x);
      if (this.report.designtime)
        ((TabPaintable)paintable).setTabMarker(TabSupport.rtabMarker); 
      int k = i;
      for (; k >= 0; k--) {
        Paintable paintable1 = paramStylePage.getPaintable(k);
        if (!paintable1.getElement().getType().equals("Text") || (paintable1.getBounds()).y < rectangle1.y)
          break; 
      } 
      k++;
      if (k <= i) {
        Paintable paintable1 = paramStylePage.getPaintable(k);
        paintable.setLocation(new Point((paintable1.getBounds()).x, rectangle1.y));
        for (; k <= i; k++) {
          Rectangle rectangle = paramStylePage.getPaintable(k).getBounds();
          int m = rectangle.x + j;
          paramStylePage.getPaintable(k).setLocation(new Point(m, rectangle.y));
        } 
      } 
    } 
    return false;
  }
  
  public String toString() { return getID() + " [" + Catalog.getString(getType()) + ": " + Util.getLineStyleName(getFillStyle()) + "]"; }
  
  public String getType() { return "Tab"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TabElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */