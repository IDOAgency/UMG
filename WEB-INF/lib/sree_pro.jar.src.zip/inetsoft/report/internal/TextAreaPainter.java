/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.Common;
/*    */ import inetsoft.report.ReportElement;
/*    */ import java.awt.Color;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextAreaPainter
/*    */   extends FieldPainter
/*    */ {
/*    */   private String text;
/*    */   private int cols;
/*    */   private int rows;
/*    */   
/*    */   public TextAreaPainter(ReportElement paramReportElement) {
/* 29 */     super(paramReportElement);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 98 */     this.cols = 15;
/* 99 */     this.rows = 4;
/*    */   }
/*    */   
/*    */   public Object getValue() { return getText(); }
/*    */   
/*    */   public String getText() { return this.text; }
/*    */   
/*    */   public void setText(String paramString) { this.text = paramString; }
/*    */   
/*    */   public int getCols() { return this.cols; }
/*    */   
/*    */   public void setCols(int paramInt) { this.cols = paramInt; }
/*    */   
/*    */   public int getRows() { return this.rows; }
/*    */   
/*    */   public void setRows(int paramInt) { this.rows = paramInt; }
/*    */   
/*    */   public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*    */     paramGraphics.setColor(this.elem.getForeground());
/*    */     paramGraphics.setFont(this.elem.getFont());
/*    */     Common.paintText(paramGraphics, this.text, new Bounds((paramInt1 + 2), (paramInt2 + 2), (paramInt3 - 4), (paramInt4 - 4)), 9, true, false, 0);
/*    */     paramGraphics.setColor(Color.gray);
/*    */     paramGraphics.draw3DRect(paramInt1, paramInt2, paramInt3 - 1, paramInt4 - 1, false);
/*    */   }
/*    */   
/*    */   public Dimension getPreferredSize() { return new Dimension((int)(Common.stringWidth("M", this.elem.getFont()) * this.cols), (int)Common.getHeight(this.elem.getFont(), null) * this.rows + 2); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TextAreaPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */