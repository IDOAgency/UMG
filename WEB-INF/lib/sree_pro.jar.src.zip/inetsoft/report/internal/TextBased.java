package inetsoft.report.internal;

public interface TextBased {
  boolean isJustify();
  
  void setJustify(boolean paramBoolean);
  
  String getText();
  
  void setText(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TextBased.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */