package inetsoft.report.internal;

public interface CustomGraphics {
  public static final int G_DASH_LINE = 1;
  
  boolean isSupported(int paramInt);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\CustomGraphics.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */