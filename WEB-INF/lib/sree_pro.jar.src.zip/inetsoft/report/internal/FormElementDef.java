/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.FormElement;
/*    */ import inetsoft.report.FormLens;
/*    */ import inetsoft.report.FormTable;
/*    */ import inetsoft.report.StyleSheet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormElementDef
/*    */   extends TableElementDef
/*    */   implements FormElement
/*    */ {
/*    */   protected FormLens form;
/*    */   
/*    */   public FormElementDef(StyleSheet paramStyleSheet, FormLens paramFormLens) {
/* 28 */     super(paramStyleSheet, new FormTable(paramFormLens));
/* 29 */     this.form = paramFormLens;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   public FormLens getForm() { return this.form; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   public void setForm(FormLens paramFormLens) { setTable(new FormTable(this.form = paramFormLens)); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\FormElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */