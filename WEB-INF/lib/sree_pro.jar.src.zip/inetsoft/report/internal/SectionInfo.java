/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SectionInfo
/*    */   implements Serializable
/*    */ {
/*    */   public static final String HEADER = "Header";
/*    */   public static final String CONTENT = "Content";
/*    */   public static final String FOOTER = "Footer";
/*    */   public String id;
/*    */   public int row;
/*    */   public Object type;
/*    */   public int level;
/*    */   
/*    */   public SectionInfo(String paramString, int paramInt1, Object paramObject, int paramInt2) {
/* 28 */     this.id = paramString;
/* 29 */     this.row = paramInt1;
/* 30 */     this.type = paramObject;
/* 31 */     this.level = paramInt2;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SectionInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */