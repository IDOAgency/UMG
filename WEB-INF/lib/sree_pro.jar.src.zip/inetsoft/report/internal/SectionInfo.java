package inetsoft.report.internal;

import java.io.Serializable;

public class SectionInfo implements Serializable {
  public static final String HEADER = "Header";
  
  public static final String CONTENT = "Content";
  
  public static final String FOOTER = "Footer";
  
  public String id;
  
  public int row;
  
  public Object type;
  
  public int level;
  
  public SectionInfo(String paramString, int paramInt1, Object paramObject, int paramInt2) {
    this.id = paramString;
    this.row = paramInt1;
    this.type = paramObject;
    this.level = paramInt2;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SectionInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */