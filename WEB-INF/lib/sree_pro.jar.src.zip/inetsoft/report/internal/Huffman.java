/*      */ package inetsoft.report.internal;
/*      */ 
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class Huffman
/*      */ {
/*      */   int bufferPutBits;
/*      */   int bufferPutBuffer;
/*      */   public int ImageHeight;
/*      */   public int ImageWidth;
/*      */   public int[][] DC_matrix0;
/*      */   public int[][] AC_matrix0;
/*      */   public int[][] DC_matrix1;
/*      */   public int[][] AC_matrix1;
/*      */   public Object[] DC_matrix;
/*      */   public Object[] AC_matrix;
/*      */   public int code;
/*      */   public int NumOfDCTables;
/*      */   public int NumOfACTables;
/*      */   public int[] bitsDCluminance;
/*      */   public int[] valDCluminance;
/*      */   public int[] bitsDCchrominance;
/*      */   public int[] valDCchrominance;
/*      */   public int[] bitsACluminance;
/*      */   public int[] valACluminance;
/*      */   public int[] bitsACchrominance;
/*      */   public int[] valACchrominance;
/*      */   public Vector bits;
/*      */   public Vector val;
/*      */   public static int[] jpegNaturalOrder = { 
/*  874 */       0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63 }; public Huffman(int paramInt1, int paramInt2) { this.bitsDCluminance = new int[] { 0, 0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0 }; this.valDCluminance = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 }; this.bitsDCchrominance = new int[] { 1, 0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0 }; this.valDCchrominance = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 }; this.bitsACluminance = new int[] { 16, 0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 125 }; this.valACluminance = new int[] { 1, 2, 3, 0, 4, 17, 5, 18, 33, 49, 65, 6, 19, 81, 97, 7, 34, 113, 20, 50, 129, 145, 161, 8, 35, 66, 177, 193, 21, 82, 209, 240, 36, 51, 98, 114, 130, 9, 10, 22, 23, 24, 25, 26, 37, 38, 39, 40, 41, 42, 52, 53, 54, 55, 56, 57, 58, 67, 68, 69, 70, 71, 72, 73, 74, 83, 84, 85, 86, 87, 88, 89, 90, 99, 100, 101, 102, 103, 104, 105, 106, 115, 116, 117, 118, 119, 120, 121, 122, 131, 132, 133, 134, 135, 136, 137, 138, 146, 147, 148, 149, 150, 151, 152, 153, 154, 162, 163, 164, 165, 166, 167, 168, 169, 170, 178, 179, 180, 181, 182, 183, 184, 185, 186, 194, 195, 196, 197, 198, 199, 200, 201, 202, 210, 211, 212, 213, 214, 215, 216, 217, 218, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250 }; this.bitsACchrominance = new int[] { 17, 0, 2, 1, 2, 4, 4, 3, 4, 7, 5, 4, 4, 0, 1, 2, 119 }; this.valACchrominance = new int[] { 0, 1, 2, 3, 17, 4, 5, 33, 49, 6, 
/*      */         18, 65, 81, 7, 97, 113, 19, 34, 50, 129, 
/*      */         8, 20, 66, 145, 161, 177, 193, 9, 35, 51, 
/*      */         82, 240, 21, 98, 114, 209, 10, 22, 36, 52, 
/*      */         225, 37, 241, 23, 24, 25, 26, 38, 39, 40, 
/*      */         41, 42, 53, 54, 55, 56, 57, 58, 67, 68, 
/*      */         69, 70, 71, 72, 73, 74, 83, 84, 85, 86, 
/*      */         87, 88, 89, 90, 99, 100, 101, 102, 103, 104, 
/*      */         105, 106, 115, 116, 117, 118, 119, 120, 121, 122, 
/*      */         130, 131, 132, 133, 134, 135, 136, 137, 138, 146, 
/*      */         147, 148, 149, 150, 151, 152, 153, 154, 162, 163, 
/*      */         164, 165, 166, 167, 168, 169, 170, 178, 179, 180, 
/*      */         181, 182, 183, 184, 185, 186, 194, 195, 196, 197, 
/*      */         198, 199, 200, 201, 202, 210, 211, 212, 213, 214, 
/*      */         215, 216, 217, 218, 226, 227, 228, 229, 230, 231, 
/*      */         232, 233, 234, 242, 243, 244, 245, 246, 247, 248, 
/*  890 */         249, 250 }; this.bits = new Vector();
/*  891 */     this.bits.addElement(this.bitsDCluminance);
/*  892 */     this.bits.addElement(this.bitsACluminance);
/*  893 */     this.bits.addElement(this.bitsDCchrominance);
/*  894 */     this.bits.addElement(this.bitsACchrominance);
/*  895 */     this.val = new Vector();
/*  896 */     this.val.addElement(this.valDCluminance);
/*  897 */     this.val.addElement(this.valACluminance);
/*  898 */     this.val.addElement(this.valDCchrominance);
/*  899 */     this.val.addElement(this.valACchrominance);
/*  900 */     initHuf();
/*  901 */     this.code = this.code;
/*  902 */     this.ImageWidth = paramInt1;
/*  903 */     this.ImageHeight = paramInt2; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void HuffmanBlockEncoder(BufferedOutputStream paramBufferedOutputStream, int[] paramArrayOfInt, int paramInt1, int paramInt2, int paramInt3) {
/*  916 */     this.NumOfDCTables = 2;
/*  917 */     this.NumOfACTables = 2;
/*      */ 
/*      */ 
/*      */     
/*  921 */     int j = paramArrayOfInt[0] - paramInt1, i = j;
/*  922 */     if (i < 0) {
/*  923 */       i = -i;
/*  924 */       j--;
/*      */     } 
/*  926 */     byte b1 = 0;
/*  927 */     while (i != 0) {
/*  928 */       b1++;
/*  929 */       i >>= 1;
/*      */     } 
/*      */     
/*  932 */     bufferIt(paramBufferedOutputStream, (int[][])this.DC_matrix[paramInt2][b1][0], (int[][])this.DC_matrix[paramInt2][b1][1]);
/*      */     
/*  934 */     if (b1 != 0) {
/*  935 */       bufferIt(paramBufferedOutputStream, j, b1);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  940 */     byte b3 = 0;
/*      */     
/*  942 */     for (byte b2 = 1; b2 < 64; b2++) {
/*  943 */       if ((i = paramArrayOfInt[jpegNaturalOrder[b2]]) == 0) {
/*  944 */         b3++;
/*      */       } else {
/*      */         
/*  947 */         while (b3 > 15) {
/*  948 */           bufferIt(paramBufferedOutputStream, (int[][])this.AC_matrix[paramInt3][240][0], (int[][])this.AC_matrix[paramInt3][240][1]);
/*  949 */           b3 -= 16;
/*      */         } 
/*  951 */         j = i;
/*  952 */         if (i < 0) {
/*  953 */           i = -i;
/*  954 */           j--;
/*      */         } 
/*  956 */         b1 = 1;
/*  957 */         while (i >>= 1 != 0) {
/*  958 */           b1++;
/*      */         }
/*  960 */         byte b = (b3 << 4) + b1;
/*  961 */         bufferIt(paramBufferedOutputStream, (int[][])this.AC_matrix[paramInt3][b][0], (int[][])this.AC_matrix[paramInt3][b][1]);
/*  962 */         bufferIt(paramBufferedOutputStream, j, b1);
/*      */         
/*  964 */         b3 = 0;
/*      */       } 
/*      */     } 
/*      */     
/*  968 */     if (b3 > 0) {
/*  969 */       bufferIt(paramBufferedOutputStream, (int[][])this.AC_matrix[paramInt3][0][0], (int[][])this.AC_matrix[paramInt3][0][1]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void bufferIt(BufferedOutputStream paramBufferedOutputStream, int paramInt1, int paramInt2) {
/*  979 */     int i = paramInt1;
/*  980 */     int j = this.bufferPutBits;
/*      */     
/*  982 */     i &= (1 << paramInt2) - 1;
/*  983 */     j += paramInt2;
/*  984 */     i <<= 24 - j;
/*  985 */     i |= this.bufferPutBuffer;
/*      */     
/*  987 */     while (j >= 8) {
/*  988 */       int k = i >> 16 & 0xFF;
/*      */       
/*      */       try {
/*  991 */         paramBufferedOutputStream.write(k);
/*      */       } catch (IOException iOException) {
/*      */         
/*  994 */         System.out.println("IO Error: " + iOException.getMessage());
/*      */       } 
/*  996 */       if (k == 255) {
/*      */         
/*      */         try {
/*  999 */           paramBufferedOutputStream.write(0);
/*      */         } catch (IOException iOException) {
/*      */           
/* 1002 */           System.out.println("IO Error: " + iOException.getMessage());
/*      */         } 
/*      */       }
/* 1005 */       i <<= 8;
/* 1006 */       j -= 8;
/*      */     } 
/* 1008 */     this.bufferPutBuffer = i;
/* 1009 */     this.bufferPutBits = j;
/*      */   }
/*      */ 
/*      */   
/*      */   void flushBuffer(BufferedOutputStream paramBufferedOutputStream) {
/* 1014 */     int i = this.bufferPutBuffer;
/* 1015 */     int j = this.bufferPutBits;
/* 1016 */     while (j >= 8) {
/* 1017 */       int k = i >> 16 & 0xFF;
/*      */       
/*      */       try {
/* 1020 */         paramBufferedOutputStream.write(k);
/*      */       } catch (IOException iOException) {
/*      */         
/* 1023 */         System.out.println("IO Error: " + iOException.getMessage());
/*      */       } 
/* 1025 */       if (k == 255) {
/*      */         try {
/* 1027 */           paramBufferedOutputStream.write(0);
/*      */         } catch (IOException iOException) {
/*      */           
/* 1030 */           System.out.println("IO Error: " + iOException.getMessage());
/*      */         } 
/*      */       }
/* 1033 */       i <<= 8;
/* 1034 */       j -= 8;
/*      */     } 
/* 1036 */     if (j > 0) {
/* 1037 */       int k = i >> 16 & 0xFF;
/*      */       
/*      */       try {
/* 1040 */         paramBufferedOutputStream.write(k);
/*      */       } catch (IOException iOException) {
/*      */         
/* 1043 */         System.out.println("IO Error: " + iOException.getMessage());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initHuf() {
/* 1056 */     this.DC_matrix0 = new int[12][2];
/* 1057 */     this.DC_matrix1 = new int[12][2];
/* 1058 */     this.AC_matrix0 = new int[255][2];
/* 1059 */     this.AC_matrix1 = new int[255][2];
/* 1060 */     this.DC_matrix = new Object[2];
/* 1061 */     this.AC_matrix = new Object[2];
/*      */     
/* 1063 */     int[] arrayOfInt1 = new int[257];
/* 1064 */     int[] arrayOfInt2 = new int[257];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1071 */     byte b1 = 0; byte b2;
/* 1072 */     for (b2 = 1; b2 <= 16; b2++) {
/*      */       
/* 1074 */       for (byte b = 1; b <= this.bitsDCchrominance[b2]; b++)
/*      */       {
/* 1076 */         arrayOfInt1[b1++] = b2;
/*      */       }
/*      */     } 
/* 1079 */     arrayOfInt1[b1] = 0;
/* 1080 */     byte b3 = b1;
/*      */     
/* 1082 */     byte b4 = 0;
/* 1083 */     int i = arrayOfInt1[0];
/* 1084 */     b1 = 0;
/* 1085 */     while (arrayOfInt1[b1] != 0) {
/*      */       
/* 1087 */       while (arrayOfInt1[b1] == i) {
/*      */         
/* 1089 */         arrayOfInt2[b1++] = b4;
/* 1090 */         b4++;
/*      */       } 
/* 1092 */       b4 <<= 1;
/* 1093 */       i++;
/*      */     } 
/*      */     
/* 1096 */     for (b1 = 0; b1 < b3; b1++) {
/*      */       
/* 1098 */       this.DC_matrix1[this.valDCchrominance[b1]][0] = arrayOfInt2[b1];
/* 1099 */       this.DC_matrix1[this.valDCchrominance[b1]][1] = arrayOfInt1[b1];
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1107 */     b1 = 0;
/* 1108 */     for (b2 = 1; b2 <= 16; b2++) {
/*      */       
/* 1110 */       for (byte b = 1; b <= this.bitsACchrominance[b2]; b++)
/*      */       {
/* 1112 */         arrayOfInt1[b1++] = b2;
/*      */       }
/*      */     } 
/* 1115 */     arrayOfInt1[b1] = 0;
/* 1116 */     b3 = b1;
/*      */     
/* 1118 */     b4 = 0;
/* 1119 */     i = arrayOfInt1[0];
/* 1120 */     b1 = 0;
/* 1121 */     while (arrayOfInt1[b1] != 0) {
/*      */       
/* 1123 */       while (arrayOfInt1[b1] == i) {
/*      */         
/* 1125 */         arrayOfInt2[b1++] = b4;
/* 1126 */         b4++;
/*      */       } 
/* 1128 */       b4 <<= 1;
/* 1129 */       i++;
/*      */     } 
/*      */     
/* 1132 */     for (b1 = 0; b1 < b3; b1++) {
/*      */       
/* 1134 */       this.AC_matrix1[this.valACchrominance[b1]][0] = arrayOfInt2[b1];
/* 1135 */       this.AC_matrix1[this.valACchrominance[b1]][1] = arrayOfInt1[b1];
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1142 */     b1 = 0;
/* 1143 */     for (b2 = 1; b2 <= 16; b2++) {
/*      */       
/* 1145 */       for (byte b = 1; b <= this.bitsDCluminance[b2]; b++)
/*      */       {
/* 1147 */         arrayOfInt1[b1++] = b2;
/*      */       }
/*      */     } 
/* 1150 */     arrayOfInt1[b1] = 0;
/* 1151 */     b3 = b1;
/*      */     
/* 1153 */     b4 = 0;
/* 1154 */     i = arrayOfInt1[0];
/* 1155 */     b1 = 0;
/* 1156 */     while (arrayOfInt1[b1] != 0) {
/*      */       
/* 1158 */       while (arrayOfInt1[b1] == i) {
/*      */         
/* 1160 */         arrayOfInt2[b1++] = b4;
/* 1161 */         b4++;
/*      */       } 
/* 1163 */       b4 <<= 1;
/* 1164 */       i++;
/*      */     } 
/*      */     
/* 1167 */     for (b1 = 0; b1 < b3; b1++) {
/*      */       
/* 1169 */       this.DC_matrix0[this.valDCluminance[b1]][0] = arrayOfInt2[b1];
/* 1170 */       this.DC_matrix0[this.valDCluminance[b1]][1] = arrayOfInt1[b1];
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1178 */     b1 = 0;
/* 1179 */     for (b2 = 1; b2 <= 16; b2++) {
/*      */       
/* 1181 */       for (byte b = 1; b <= this.bitsACluminance[b2]; b++)
/*      */       {
/* 1183 */         arrayOfInt1[b1++] = b2;
/*      */       }
/*      */     } 
/* 1186 */     arrayOfInt1[b1] = 0;
/* 1187 */     b3 = b1;
/*      */     
/* 1189 */     b4 = 0;
/* 1190 */     i = arrayOfInt1[0];
/* 1191 */     b1 = 0;
/* 1192 */     while (arrayOfInt1[b1] != 0) {
/*      */       
/* 1194 */       while (arrayOfInt1[b1] == i) {
/*      */         
/* 1196 */         arrayOfInt2[b1++] = b4;
/* 1197 */         b4++;
/*      */       } 
/* 1199 */       b4 <<= 1;
/* 1200 */       i++;
/*      */     } 
/* 1202 */     for (byte b5 = 0; b5 < b3; b5++) {
/*      */       
/* 1204 */       this.AC_matrix0[this.valACluminance[b5]][0] = arrayOfInt2[b5];
/* 1205 */       this.AC_matrix0[this.valACluminance[b5]][1] = arrayOfInt1[b5];
/*      */     } 
/*      */     
/* 1208 */     this.DC_matrix[0] = this.DC_matrix0;
/* 1209 */     this.DC_matrix[1] = this.DC_matrix1;
/* 1210 */     this.AC_matrix[0] = this.AC_matrix0;
/* 1211 */     this.AC_matrix[1] = this.AC_matrix1;
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\Huffman.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */