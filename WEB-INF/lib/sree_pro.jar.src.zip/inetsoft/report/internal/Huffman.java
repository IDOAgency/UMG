package inetsoft.report.internal;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.util.Vector;

class Huffman {
  int bufferPutBits;
  
  int bufferPutBuffer;
  
  public int ImageHeight;
  
  public int ImageWidth;
  
  public int[][] DC_matrix0;
  
  public int[][] AC_matrix0;
  
  public int[][] DC_matrix1;
  
  public int[][] AC_matrix1;
  
  public Object[] DC_matrix;
  
  public Object[] AC_matrix;
  
  public int code;
  
  public int NumOfDCTables;
  
  public int NumOfACTables;
  
  public int[] bitsDCluminance;
  
  public int[] valDCluminance;
  
  public int[] bitsDCchrominance;
  
  public int[] valDCchrominance;
  
  public int[] bitsACluminance;
  
  public int[] valACluminance;
  
  public int[] bitsACchrominance;
  
  public int[] valACchrominance;
  
  public Vector bits;
  
  public Vector val;
  
  public static int[] jpegNaturalOrder = { 
      0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 
      32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 
      40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 
      21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 
      29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 
      52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 
      47, 55, 62, 63 };
  
  public Huffman(int paramInt1, int paramInt2) {
    this.bitsDCluminance = new int[] { 
        0, 0, 1, 5, 1, 1, 1, 1, 1, 1, 
        0, 0, 0, 0, 0, 0, 0 };
    this.valDCluminance = new int[] { 
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 
        10, 11 };
    this.bitsDCchrominance = new int[] { 
        1, 0, 3, 1, 1, 1, 1, 1, 1, 1, 
        1, 1, 0, 0, 0, 0, 0 };
    this.valDCchrominance = new int[] { 
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 
        10, 11 };
    this.bitsACluminance = new int[] { 
        16, 0, 2, 1, 3, 3, 2, 4, 3, 5, 
        5, 4, 4, 0, 0, 1, 125 };
    this.valACluminance = new int[] { 
        1, 2, 3, 0, 4, 17, 5, 18, 33, 49, 
        65, 6, 19, 81, 97, 7, 34, 113, 20, 50, 
        129, 145, 161, 8, 35, 66, 177, 193, 21, 82, 
        209, 240, 36, 51, 98, 114, 130, 9, 10, 22, 
        23, 24, 25, 26, 37, 38, 39, 40, 41, 42, 
        52, 53, 54, 55, 56, 57, 58, 67, 68, 69, 
        70, 71, 72, 73, 74, 83, 84, 85, 86, 87, 
        88, 89, 90, 99, 100, 101, 102, 103, 104, 105, 
        106, 115, 116, 117, 118, 119, 120, 121, 122, 131, 
        132, 133, 134, 135, 136, 137, 138, 146, 147, 148, 
        149, 150, 151, 152, 153, 154, 162, 163, 164, 165, 
        166, 167, 168, 169, 170, 178, 179, 180, 181, 182, 
        183, 184, 185, 186, 194, 195, 196, 197, 198, 199, 
        200, 201, 202, 210, 211, 212, 213, 214, 215, 216, 
        217, 218, 225, 226, 227, 228, 229, 230, 231, 232, 
        233, 234, 241, 242, 243, 244, 245, 246, 247, 248, 
        249, 250 };
    this.bitsACchrominance = new int[] { 
        17, 0, 2, 1, 2, 4, 4, 3, 4, 7, 
        5, 4, 4, 0, 1, 2, 119 };
    this.valACchrominance = new int[] { 
        0, 1, 2, 3, 17, 4, 5, 33, 49, 6, 
        18, 65, 81, 7, 97, 113, 19, 34, 50, 129, 
        8, 20, 66, 145, 161, 177, 193, 9, 35, 51, 
        82, 240, 21, 98, 114, 209, 10, 22, 36, 52, 
        225, 37, 241, 23, 24, 25, 26, 38, 39, 40, 
        41, 42, 53, 54, 55, 56, 57, 58, 67, 68, 
        69, 70, 71, 72, 73, 74, 83, 84, 85, 86, 
        87, 88, 89, 90, 99, 100, 101, 102, 103, 104, 
        105, 106, 115, 116, 117, 118, 119, 120, 121, 122, 
        130, 131, 132, 133, 134, 135, 136, 137, 138, 146, 
        147, 148, 149, 150, 151, 152, 153, 154, 162, 163, 
        164, 165, 166, 167, 168, 169, 170, 178, 179, 180, 
        181, 182, 183, 184, 185, 186, 194, 195, 196, 197, 
        198, 199, 200, 201, 202, 210, 211, 212, 213, 214, 
        215, 216, 217, 218, 226, 227, 228, 229, 230, 231, 
        232, 233, 234, 242, 243, 244, 245, 246, 247, 248, 
        249, 250 };
    this.bits = new Vector();
    this.bits.addElement(this.bitsDCluminance);
    this.bits.addElement(this.bitsACluminance);
    this.bits.addElement(this.bitsDCchrominance);
    this.bits.addElement(this.bitsACchrominance);
    this.val = new Vector();
    this.val.addElement(this.valDCluminance);
    this.val.addElement(this.valACluminance);
    this.val.addElement(this.valDCchrominance);
    this.val.addElement(this.valACchrominance);
    initHuf();
    this.code = this.code;
    this.ImageWidth = paramInt1;
    this.ImageHeight = paramInt2;
  }
  
  public void HuffmanBlockEncoder(BufferedOutputStream paramBufferedOutputStream, int[] paramArrayOfInt, int paramInt1, int paramInt2, int paramInt3) {
    this.NumOfDCTables = 2;
    this.NumOfACTables = 2;
    int j = paramArrayOfInt[0] - paramInt1, i = j;
    if (i < 0) {
      i = -i;
      j--;
    } 
    byte b1 = 0;
    while (i != 0) {
      b1++;
      i >>= 1;
    } 
    bufferIt(paramBufferedOutputStream, (int[][])this.DC_matrix[paramInt2][b1][0], (int[][])this.DC_matrix[paramInt2][b1][1]);
    if (b1 != 0)
      bufferIt(paramBufferedOutputStream, j, b1); 
    byte b3 = 0;
    for (byte b2 = 1; b2 < 64; b2++) {
      if ((i = paramArrayOfInt[jpegNaturalOrder[b2]]) == 0) {
        b3++;
      } else {
        while (b3 > 15) {
          bufferIt(paramBufferedOutputStream, (int[][])this.AC_matrix[paramInt3][240][0], (int[][])this.AC_matrix[paramInt3][240][1]);
          b3 -= 16;
        } 
        j = i;
        if (i < 0) {
          i = -i;
          j--;
        } 
        b1 = 1;
        while (i >>= 1 != 0)
          b1++; 
        byte b = (b3 << 4) + b1;
        bufferIt(paramBufferedOutputStream, (int[][])this.AC_matrix[paramInt3][b][0], (int[][])this.AC_matrix[paramInt3][b][1]);
        bufferIt(paramBufferedOutputStream, j, b1);
        b3 = 0;
      } 
    } 
    if (b3 > 0)
      bufferIt(paramBufferedOutputStream, (int[][])this.AC_matrix[paramInt3][0][0], (int[][])this.AC_matrix[paramInt3][0][1]); 
  }
  
  void bufferIt(BufferedOutputStream paramBufferedOutputStream, int paramInt1, int paramInt2) {
    int i = paramInt1;
    int j = this.bufferPutBits;
    i &= (1 << paramInt2) - 1;
    j += paramInt2;
    i <<= 24 - j;
    i |= this.bufferPutBuffer;
    while (j >= 8) {
      int k = i >> 16 & 0xFF;
      try {
        paramBufferedOutputStream.write(k);
      } catch (IOException iOException) {
        System.out.println("IO Error: " + iOException.getMessage());
      } 
      if (k == 255)
        try {
          paramBufferedOutputStream.write(0);
        } catch (IOException iOException) {
          System.out.println("IO Error: " + iOException.getMessage());
        }  
      i <<= 8;
      j -= 8;
    } 
    this.bufferPutBuffer = i;
    this.bufferPutBits = j;
  }
  
  void flushBuffer(BufferedOutputStream paramBufferedOutputStream) {
    int i = this.bufferPutBuffer;
    int j = this.bufferPutBits;
    while (j >= 8) {
      int k = i >> 16 & 0xFF;
      try {
        paramBufferedOutputStream.write(k);
      } catch (IOException iOException) {
        System.out.println("IO Error: " + iOException.getMessage());
      } 
      if (k == 255)
        try {
          paramBufferedOutputStream.write(0);
        } catch (IOException iOException) {
          System.out.println("IO Error: " + iOException.getMessage());
        }  
      i <<= 8;
      j -= 8;
    } 
    if (j > 0) {
      int k = i >> 16 & 0xFF;
      try {
        paramBufferedOutputStream.write(k);
      } catch (IOException iOException) {
        System.out.println("IO Error: " + iOException.getMessage());
      } 
    } 
  }
  
  public void initHuf() {
    this.DC_matrix0 = new int[12][2];
    this.DC_matrix1 = new int[12][2];
    this.AC_matrix0 = new int[255][2];
    this.AC_matrix1 = new int[255][2];
    this.DC_matrix = new Object[2];
    this.AC_matrix = new Object[2];
    int[] arrayOfInt1 = new int[257];
    int[] arrayOfInt2 = new int[257];
    byte b1 = 0;
    byte b2;
    for (b2 = 1; b2 <= 16; b2++) {
      for (byte b = 1; b <= this.bitsDCchrominance[b2]; b++)
        arrayOfInt1[b1++] = b2; 
    } 
    arrayOfInt1[b1] = 0;
    byte b3 = b1;
    byte b4 = 0;
    int i = arrayOfInt1[0];
    b1 = 0;
    while (arrayOfInt1[b1] != 0) {
      while (arrayOfInt1[b1] == i) {
        arrayOfInt2[b1++] = b4;
        b4++;
      } 
      b4 <<= 1;
      i++;
    } 
    for (b1 = 0; b1 < b3; b1++) {
      this.DC_matrix1[this.valDCchrominance[b1]][0] = arrayOfInt2[b1];
      this.DC_matrix1[this.valDCchrominance[b1]][1] = arrayOfInt1[b1];
    } 
    b1 = 0;
    for (b2 = 1; b2 <= 16; b2++) {
      for (byte b = 1; b <= this.bitsACchrominance[b2]; b++)
        arrayOfInt1[b1++] = b2; 
    } 
    arrayOfInt1[b1] = 0;
    b3 = b1;
    b4 = 0;
    i = arrayOfInt1[0];
    b1 = 0;
    while (arrayOfInt1[b1] != 0) {
      while (arrayOfInt1[b1] == i) {
        arrayOfInt2[b1++] = b4;
        b4++;
      } 
      b4 <<= 1;
      i++;
    } 
    for (b1 = 0; b1 < b3; b1++) {
      this.AC_matrix1[this.valACchrominance[b1]][0] = arrayOfInt2[b1];
      this.AC_matrix1[this.valACchrominance[b1]][1] = arrayOfInt1[b1];
    } 
    b1 = 0;
    for (b2 = 1; b2 <= 16; b2++) {
      for (byte b = 1; b <= this.bitsDCluminance[b2]; b++)
        arrayOfInt1[b1++] = b2; 
    } 
    arrayOfInt1[b1] = 0;
    b3 = b1;
    b4 = 0;
    i = arrayOfInt1[0];
    b1 = 0;
    while (arrayOfInt1[b1] != 0) {
      while (arrayOfInt1[b1] == i) {
        arrayOfInt2[b1++] = b4;
        b4++;
      } 
      b4 <<= 1;
      i++;
    } 
    for (b1 = 0; b1 < b3; b1++) {
      this.DC_matrix0[this.valDCluminance[b1]][0] = arrayOfInt2[b1];
      this.DC_matrix0[this.valDCluminance[b1]][1] = arrayOfInt1[b1];
    } 
    b1 = 0;
    for (b2 = 1; b2 <= 16; b2++) {
      for (byte b = 1; b <= this.bitsACluminance[b2]; b++)
        arrayOfInt1[b1++] = b2; 
    } 
    arrayOfInt1[b1] = 0;
    b3 = b1;
    b4 = 0;
    i = arrayOfInt1[0];
    b1 = 0;
    while (arrayOfInt1[b1] != 0) {
      while (arrayOfInt1[b1] == i) {
        arrayOfInt2[b1++] = b4;
        b4++;
      } 
      b4 <<= 1;
      i++;
    } 
    for (byte b5 = 0; b5 < b3; b5++) {
      this.AC_matrix0[this.valACluminance[b5]][0] = arrayOfInt2[b5];
      this.AC_matrix0[this.valACluminance[b5]][1] = arrayOfInt1[b5];
    } 
    this.DC_matrix[0] = this.DC_matrix0;
    this.DC_matrix[1] = this.DC_matrix1;
    this.AC_matrix[0] = this.AC_matrix0;
    this.AC_matrix[1] = this.AC_matrix1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\Huffman.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */