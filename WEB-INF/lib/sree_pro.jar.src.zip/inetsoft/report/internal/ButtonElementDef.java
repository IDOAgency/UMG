package inetsoft.report.internal;

import inetsoft.report.ButtonElement;
import inetsoft.report.Painter;
import inetsoft.report.StyleSheet;

public class ButtonElementDef extends FieldElementDef implements ButtonElement {
  ButtonPainter painter;
  
  public ButtonElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3, double paramDouble1, double paramDouble2) {
    super(paramStyleSheet, paramString1, paramString2, paramDouble1, paramDouble2);
    this.painter.setText(paramString3);
  }
  
  public ButtonElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3) { this(paramStyleSheet, paramString1, paramString2, paramString3, 0.0D, 0.0D); }
  
  protected FieldPainter createPainter() { return this.painter = new ButtonPainter(this); }
  
  public String getText() { return this.painter.getText(); }
  
  public void setText(String paramString) { this.painter.setText(paramString); }
  
  public void setPainter(Painter paramPainter) {
    super.setPainter(paramPainter);
    this.painter = (ButtonPainter)paramPainter;
  }
  
  public String getType() { return "Button"; }
  
  public Object clone() throws CloneNotSupportedException {
    ButtonElementDef buttonElementDef = (ButtonElementDef)super.clone();
    buttonElementDef.setPainter(new ButtonPainter(buttonElementDef));
    buttonElementDef.setText(this.painter.getText());
    return buttonElementDef;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ButtonElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */