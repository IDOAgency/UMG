/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.ButtonElement;
/*    */ import inetsoft.report.Painter;
/*    */ import inetsoft.report.StyleSheet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ButtonElementDef
/*    */   extends FieldElementDef
/*    */   implements ButtonElement
/*    */ {
/*    */   ButtonPainter painter;
/*    */   
/*    */   public ButtonElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3, double paramDouble1, double paramDouble2) {
/* 34 */     super(paramStyleSheet, paramString1, paramString2, paramDouble1, paramDouble2);
/* 35 */     this.painter.setText(paramString3);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   public ButtonElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3) { this(paramStyleSheet, paramString1, paramString2, paramString3, 0.0D, 0.0D); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   protected FieldPainter createPainter() { return this.painter = new ButtonPainter(this); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   public String getText() { return this.painter.getText(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 65 */   public void setText(String paramString) { this.painter.setText(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPainter(Painter paramPainter) {
/* 72 */     super.setPainter(paramPainter);
/* 73 */     this.painter = (ButtonPainter)paramPainter;
/*    */   }
/*    */ 
/*    */   
/* 77 */   public String getType() { return "Button"; }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 81 */     ButtonElementDef buttonElementDef = (ButtonElementDef)super.clone();
/* 82 */     buttonElementDef.setPainter(new ButtonPainter(buttonElementDef));
/* 83 */     buttonElementDef.setText(this.painter.getText());
/* 84 */     return buttonElementDef;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\ButtonElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */