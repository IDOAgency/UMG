/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Button;
/*    */ import java.awt.Color;
/*    */ import java.awt.Frame;
/*    */ import java.awt.Panel;
/*    */ import java.awt.TextArea;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageDialog
/*    */   extends Frame
/*    */ {
/*    */   public MessageDialog(String paramString) {
/* 26 */     setLayout(new BorderLayout());
/*    */     
/* 28 */     TextArea textArea = new TextArea(paramString, 8, 65);
/* 29 */     textArea.setBackground(Color.white);
/* 30 */     textArea.setEditable(false);
/* 31 */     add(textArea, "Center");
/*    */     
/* 33 */     Button button = new Button("Close");
/* 34 */     button.addActionListener(new ActionListener(this)
/*    */         {
/* 36 */           public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
/*    */           
/*    */           private final MessageDialog this$0;
/*    */         });
/* 40 */     Panel panel = new Panel();
/* 41 */     panel.add(button);
/* 42 */     add(panel, "South");
/*    */   }
/*    */   
/*    */   public static void show(String paramString) {
/* 46 */     MessageDialog messageDialog = new MessageDialog(paramString);
/* 47 */     messageDialog.pack();
/* 48 */     messageDialog.setVisible(true);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\MessageDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */