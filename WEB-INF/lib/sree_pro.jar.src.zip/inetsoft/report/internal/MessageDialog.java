package inetsoft.report.internal;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MessageDialog extends Frame {
  public MessageDialog(String paramString) {
    setLayout(new BorderLayout());
    TextArea textArea = new TextArea(paramString, 8, 65);
    textArea.setBackground(Color.white);
    textArea.setEditable(false);
    add(textArea, "Center");
    Button button = new Button("Close");
    button.addActionListener(new ActionListener(this) {
          private final MessageDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
        });
    Panel panel = new Panel();
    panel.add(button);
    add(panel, "South");
  }
  
  public static void show(String paramString) {
    MessageDialog messageDialog = new MessageDialog(paramString);
    messageDialog.pack();
    messageDialog.setVisible(true);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\MessageDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */