/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ import inetsoft.report.TextLens;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HFTextFormatter
/*     */ {
/*     */   private Date now;
/*     */   private int pgidx;
/*     */   private int pgnum;
/*     */   private int total;
/*     */   private int start;
/*     */   
/*     */   public HFTextFormatter(Date paramDate, int paramInt) {
/* 113 */     this.pgidx = 0;
/* 114 */     this.pgnum = 1;
/* 115 */     this.total = 1000;
/* 116 */     this.start = 0;
/*     */     this.now = paramDate;
/*     */     this.start = paramInt;
/*     */     this.pgnum = 1 - paramInt;
/*     */   }
/*     */   
/*     */   public void nextPage(boolean paramBoolean) {
/*     */     this.pgnum++;
/*     */     this.pgidx++;
/*     */     if (!paramBoolean)
/*     */       this.total = this.pgidx; 
/*     */   }
/*     */   
/*     */   public int getPageNumber() { return this.pgnum; }
/*     */   
/*     */   public int getPageIndex() { return this.pgidx; }
/*     */   
/*     */   public TextLens create(String paramString) {
/*     */     return new HTextLens(this, paramString, null) {
/*     */         int pgnum2;
/*     */         private final String val$fmt;
/*     */         private final HFTextFormatter this$0;
/*     */         
/*     */         public String getDisplayText() { return StyleCore.format(getText(), this.pgnum2, this.this$0.total - this.this$0.start, this.this$0.now); }
/*     */       };
/*     */   }
/*     */   
/*     */   public TextLens create(TextLens paramTextLens) { return new HTextLens(this, paramTextLens); }
/*     */   
/*     */   class HTextLens extends HeaderTextLens {
/*     */     TextLens lens;
/*     */     int pgnum2;
/*     */     String text;
/*     */     private final HFTextFormatter this$0;
/*     */     
/*     */     public HTextLens(HFTextFormatter this$0, TextLens param1TextLens) {
/*     */       this.this$0 = this$0;
/*     */       this.pgnum2 = this.this$0.pgnum;
/*     */       this.text = null;
/*     */       while (param1TextLens instanceof HTextLens)
/*     */         param1TextLens = ((HTextLens)param1TextLens).lens; 
/*     */       this.lens = param1TextLens;
/*     */     }
/*     */     
/*     */     public String getDisplayText() { return StyleCore.format(getText(), this.pgnum2, this.this$0.total - this.this$0.start, this.this$0.now); }
/*     */     
/*     */     public String getText() { return (this.text == null) ? this.lens.getText() : this.text; }
/*     */     
/*     */     public void setText(String param1String) { this.text = param1String; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\HFTextFormatter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */