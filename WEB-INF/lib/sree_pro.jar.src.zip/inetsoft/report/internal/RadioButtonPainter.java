package inetsoft.report.internal;

import inetsoft.report.ReportElement;
import java.awt.Image;

public class RadioButtonPainter extends CheckBoxPainter {
  private String group;
  
  static final String true_rb = "/inetsoft/report/images/radio_true.gif";
  
  static final String false_rb = "/inetsoft/report/images/radio_false.gif";
  
  public RadioButtonPainter(ReportElement paramReportElement) { super(paramReportElement); }
  
  public Object getValue() { return isSelected() ? getName() : null; }
  
  public String getGroup() { return this.group; }
  
  public void setGroup(String paramString) { this.group = paramString; }
  
  protected Image getIcon() { return getIcon("/inetsoft/report/images/radio_true.gif", "/inetsoft/report/images/radio_false.gif"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\RadioButtonPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */