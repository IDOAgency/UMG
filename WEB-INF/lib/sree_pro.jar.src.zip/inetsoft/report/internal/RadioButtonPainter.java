/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.ReportElement;
/*    */ import java.awt.Image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RadioButtonPainter
/*    */   extends CheckBoxPainter
/*    */ {
/*    */   private String group;
/*    */   static final String true_rb = "/inetsoft/report/images/radio_true.gif";
/*    */   static final String false_rb = "/inetsoft/report/images/radio_false.gif";
/*    */   
/* 29 */   public RadioButtonPainter(ReportElement paramReportElement) { super(paramReportElement); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   public Object getValue() { return isSelected() ? getName() : null; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   public String getGroup() { return this.group; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   public void setGroup(String paramString) { this.group = paramString; }
/*    */ 
/*    */ 
/*    */   
/* 54 */   protected Image getIcon() { return getIcon("/inetsoft/report/images/radio_true.gif", "/inetsoft/report/images/radio_false.gif"); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\RadioButtonPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */