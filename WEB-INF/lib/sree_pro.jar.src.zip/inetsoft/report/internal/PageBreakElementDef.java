/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.PageBreakElement;
/*    */ import inetsoft.report.StyleSheet;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PageBreakElementDef
/*    */   extends AreaBreakElementDef
/*    */   implements PageBreakElement
/*    */ {
/*    */   public PageBreakElementDef(StyleSheet paramStyleSheet) {
/* 29 */     super(paramStyleSheet);
/*    */     
/* 31 */     this.label = Catalog.getString("Page Break");
/*    */   }
/*    */ 
/*    */   
/* 35 */   public String toString() { return getID() + " [" + Catalog.getString(getType()) + "]"; }
/*    */ 
/*    */ 
/*    */   
/* 39 */   public String getType() { return "PageBreak"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\PageBreakElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */