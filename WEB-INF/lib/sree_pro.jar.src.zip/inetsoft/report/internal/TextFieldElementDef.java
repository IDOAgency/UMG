/*    */ package inetsoft.report.internal;
/*    */ 
/*    */ import inetsoft.report.Painter;
/*    */ import inetsoft.report.StyleSheet;
/*    */ import inetsoft.report.TextFieldElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextFieldElementDef
/*    */   extends FieldElementDef
/*    */   implements TextFieldElement
/*    */ {
/*    */   TextFieldPainter painter;
/*    */   
/*    */   public TextFieldElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3, double paramDouble1, double paramDouble2) {
/* 34 */     super(paramStyleSheet, paramString1, paramString2, paramDouble1, paramDouble2);
/* 35 */     this.painter.setText(paramString3);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   public TextFieldElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3) { this(paramStyleSheet, paramString1, paramString2, paramString3, 0.0D, 0.0D); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   protected FieldPainter createPainter() { return this.painter = new TextFieldPainter(this); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   public String getText() { return this.painter.getText(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 65 */   public void setText(String paramString) { this.painter.setText(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 72 */   public int getCols() { return this.painter.getCols(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 79 */   public void setCols(int paramInt) { this.painter.setCols(paramInt); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPainter(Painter paramPainter) {
/* 86 */     super.setPainter(paramPainter);
/* 87 */     this.painter = (TextFieldPainter)paramPainter;
/*    */   }
/*    */ 
/*    */   
/* 91 */   public String getType() { return "TextField"; }
/*    */ 
/*    */   
/*    */   public Object clone() throws CloneNotSupportedException {
/* 95 */     TextFieldElementDef textFieldElementDef = (TextFieldElementDef)super.clone();
/* 96 */     textFieldElementDef.setPainter(new TextFieldPainter(textFieldElementDef));
/* 97 */     textFieldElementDef.setText(this.painter.getText());
/* 98 */     return textFieldElementDef;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TextFieldElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */