package inetsoft.report.internal;

import inetsoft.report.Painter;
import inetsoft.report.StyleSheet;
import inetsoft.report.TextFieldElement;

public class TextFieldElementDef extends FieldElementDef implements TextFieldElement {
  TextFieldPainter painter;
  
  public TextFieldElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3, double paramDouble1, double paramDouble2) {
    super(paramStyleSheet, paramString1, paramString2, paramDouble1, paramDouble2);
    this.painter.setText(paramString3);
  }
  
  public TextFieldElementDef(StyleSheet paramStyleSheet, String paramString1, String paramString2, String paramString3) { this(paramStyleSheet, paramString1, paramString2, paramString3, 0.0D, 0.0D); }
  
  protected FieldPainter createPainter() { return this.painter = new TextFieldPainter(this); }
  
  public String getText() { return this.painter.getText(); }
  
  public void setText(String paramString) { this.painter.setText(paramString); }
  
  public int getCols() { return this.painter.getCols(); }
  
  public void setCols(int paramInt) { this.painter.setCols(paramInt); }
  
  public void setPainter(Painter paramPainter) {
    super.setPainter(paramPainter);
    this.painter = (TextFieldPainter)paramPainter;
  }
  
  public String getType() { return "TextField"; }
  
  public Object clone() throws CloneNotSupportedException {
    TextFieldElementDef textFieldElementDef = (TextFieldElementDef)super.clone();
    textFieldElementDef.setPainter(new TextFieldPainter(textFieldElementDef));
    textFieldElementDef.setText(this.painter.getText());
    return textFieldElementDef;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\TextFieldElementDef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */