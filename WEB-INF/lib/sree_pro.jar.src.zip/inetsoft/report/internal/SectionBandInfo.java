package inetsoft.report.internal;

import inetsoft.report.SectionBand;
import java.io.Serializable;

public class SectionBandInfo implements Serializable {
  public SectionBand band;
  
  public String type;
  
  public int level;
  
  public SectionBandInfo(SectionBand paramSectionBand, String paramString, int paramInt) {
    this.type = "Content";
    this.band = paramSectionBand;
    this.type = paramString;
    this.level = paramInt;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\SectionBandInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */