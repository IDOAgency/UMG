package inetsoft.report.internal;

import inetsoft.report.Painter;
import inetsoft.report.locale.Catalog;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;

public class EmptyPainter implements Painter {
  Dimension psize;
  
  String title;
  
  public EmptyPainter() { this(Catalog.getString("Painter"), 80, 80); }
  
  public EmptyPainter(String paramString, int paramInt1, int paramInt2) {
    this.title = null;
    this.psize = new Dimension(paramInt1, paramInt2);
    this.title = paramString;
  }
  
  public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Color color = paramGraphics.getColor();
    Font font = paramGraphics.getFont();
    paramGraphics.setColor(new Color(150, 150, 150));
    paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
    paramGraphics.setFont(new Font("Serif", 0, 10));
    if (this.title != null) {
      paramGraphics.setColor(Color.white);
      paramGraphics.drawString(this.title, paramInt1 + 2, paramInt2 + 12);
    } 
    paramGraphics.setColor(color);
    paramGraphics.setFont(font);
  }
  
  public Dimension getPreferredSize() { return this.psize; }
  
  public boolean isScalable() { return true; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\EmptyPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */