package inetsoft.report.internal;

import inetsoft.report.FormLens;
import inetsoft.report.FormTable;
import inetsoft.report.StyleSheet;
import inetsoft.report.TableLens;
import inetsoft.report.lens.AttributeFormLens;
import inetsoft.report.lens.DefaultFormLens;
import inetsoft.report.locale.Catalog;

public class FormXElement extends FormElementDef implements Tabular {
  AttributeFormLens attr;
  
  boolean embed;
  
  boolean fixWidth;
  
  public FormXElement(StyleSheet paramStyleSheet) { this(paramStyleSheet, 1, 2); }
  
  public FormXElement(StyleSheet paramStyleSheet, int paramInt1, int paramInt2) {
    super(paramStyleSheet, new AttributeFormLens(new DefaultFormLens(paramInt1 * paramInt2)));
    this.embed = true;
    this.fixWidth = false;
    this.attr = (AttributeFormLens)getForm();
    this.attr.setFieldPerRow(paramInt2);
  }
  
  public void setData(TableLens paramTableLens) {
    DefaultFormLens defaultFormLens = new DefaultFormLens();
    setForm(defaultFormLens);
    defaultFormLens.setFieldCount(paramTableLens.getRowCount());
    for (byte b = 0; b < paramTableLens.getRowCount(); b++) {
      defaultFormLens.setLabel(b, paramTableLens.getObject(b, 0));
      defaultFormLens.setField(b, paramTableLens.getObject(b, 1));
    } 
  }
  
  public void setForm(FormLens paramFormLens) {
    if (paramFormLens != this.attr)
      this.attr.setForm(paramFormLens); 
  }
  
  public boolean isEmbedded() { return this.embed; }
  
  public void setEmbedded(boolean paramBoolean) { this.embed = paramBoolean; }
  
  public boolean isEmbedWidth() { return this.fixWidth; }
  
  public void setEmbedWidth(boolean paramBoolean) { this.fixWidth = paramBoolean; }
  
  public void setFixedWidths(int[] paramArrayOfInt) {
    super.setFixedWidths(paramArrayOfInt);
    setEmbedWidth(true);
  }
  
  public String toString() { return getID() + " [" + Catalog.getString(getType()) + "]"; }
  
  public String getType() { return "Form"; }
  
  public Object clone() throws CloneNotSupportedException {
    FormXElement formXElement = (FormXElement)super.clone();
    formXElement.form = formXElement.attr = (AttributeFormLens)this.attr.clone();
    formXElement.setTable(new FormTable(formXElement.form));
    return formXElement;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\FormXElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */