/*     */ package inetsoft.report.internal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DCT
/*     */ {
/*     */   public int N;
/*     */   public int QUALITY;
/*     */   public Object[] quantum;
/*     */   public Object[] Divisors;
/*     */   public int[] quantum_luminance;
/*     */   public double[] DivisorsLuminance;
/*     */   public int[] quantum_chrominance;
/*     */   public double[] DivisorsChrominance;
/*     */   
/*     */   public DCT(int paramInt) {
/* 367 */     this.N = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 372 */     this.QUALITY = 80;
/*     */     
/* 374 */     this.quantum = new Object[2];
/* 375 */     this.Divisors = new Object[2];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 380 */     this.quantum_luminance = new int[this.N * this.N];
/* 381 */     this.DivisorsLuminance = new double[this.N * this.N];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 386 */     this.quantum_chrominance = new int[this.N * this.N];
/* 387 */     this.DivisorsChrominance = new double[this.N * this.N];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 401 */     initMatrix(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initMatrix(int paramInt) {
/* 411 */     double[] arrayOfDouble = { 1.0D, 1.387039845D, 1.306562965D, 1.175875602D, 1.0D, 0.785694958D, 0.5411961D, 0.275899379D };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 422 */     int i = paramInt;
/* 423 */     if (i <= 0)
/* 424 */       i = 1; 
/* 425 */     if (i > 100)
/* 426 */       i = 100; 
/* 427 */     if (i < 50) {
/* 428 */       i = 5000 / i;
/*     */     } else {
/* 430 */       i = 200 - i * 2;
/*     */     } 
/*     */ 
/*     */     
/* 434 */     this.quantum_luminance[0] = 16;
/* 435 */     this.quantum_luminance[1] = 11;
/* 436 */     this.quantum_luminance[2] = 10;
/* 437 */     this.quantum_luminance[3] = 16;
/* 438 */     this.quantum_luminance[4] = 24;
/* 439 */     this.quantum_luminance[5] = 40;
/* 440 */     this.quantum_luminance[6] = 51;
/* 441 */     this.quantum_luminance[7] = 61;
/* 442 */     this.quantum_luminance[8] = 12;
/* 443 */     this.quantum_luminance[9] = 12;
/* 444 */     this.quantum_luminance[10] = 14;
/* 445 */     this.quantum_luminance[11] = 19;
/* 446 */     this.quantum_luminance[12] = 26;
/* 447 */     this.quantum_luminance[13] = 58;
/* 448 */     this.quantum_luminance[14] = 60;
/* 449 */     this.quantum_luminance[15] = 55;
/* 450 */     this.quantum_luminance[16] = 14;
/* 451 */     this.quantum_luminance[17] = 13;
/* 452 */     this.quantum_luminance[18] = 16;
/* 453 */     this.quantum_luminance[19] = 24;
/* 454 */     this.quantum_luminance[20] = 40;
/* 455 */     this.quantum_luminance[21] = 57;
/* 456 */     this.quantum_luminance[22] = 69;
/* 457 */     this.quantum_luminance[23] = 56;
/* 458 */     this.quantum_luminance[24] = 14;
/* 459 */     this.quantum_luminance[25] = 17;
/* 460 */     this.quantum_luminance[26] = 22;
/* 461 */     this.quantum_luminance[27] = 29;
/* 462 */     this.quantum_luminance[28] = 51;
/* 463 */     this.quantum_luminance[29] = 87;
/* 464 */     this.quantum_luminance[30] = 80;
/* 465 */     this.quantum_luminance[31] = 62;
/* 466 */     this.quantum_luminance[32] = 18;
/* 467 */     this.quantum_luminance[33] = 22;
/* 468 */     this.quantum_luminance[34] = 37;
/* 469 */     this.quantum_luminance[35] = 56;
/* 470 */     this.quantum_luminance[36] = 68;
/* 471 */     this.quantum_luminance[37] = 109;
/* 472 */     this.quantum_luminance[38] = 103;
/* 473 */     this.quantum_luminance[39] = 77;
/* 474 */     this.quantum_luminance[40] = 24;
/* 475 */     this.quantum_luminance[41] = 35;
/* 476 */     this.quantum_luminance[42] = 55;
/* 477 */     this.quantum_luminance[43] = 64;
/* 478 */     this.quantum_luminance[44] = 81;
/* 479 */     this.quantum_luminance[45] = 104;
/* 480 */     this.quantum_luminance[46] = 113;
/* 481 */     this.quantum_luminance[47] = 92;
/* 482 */     this.quantum_luminance[48] = 49;
/* 483 */     this.quantum_luminance[49] = 64;
/* 484 */     this.quantum_luminance[50] = 78;
/* 485 */     this.quantum_luminance[51] = 87;
/* 486 */     this.quantum_luminance[52] = 103;
/* 487 */     this.quantum_luminance[53] = 121;
/* 488 */     this.quantum_luminance[54] = 120;
/* 489 */     this.quantum_luminance[55] = 101;
/* 490 */     this.quantum_luminance[56] = 72;
/* 491 */     this.quantum_luminance[57] = 92;
/* 492 */     this.quantum_luminance[58] = 95;
/* 493 */     this.quantum_luminance[59] = 98;
/* 494 */     this.quantum_luminance[60] = 112;
/* 495 */     this.quantum_luminance[61] = 100;
/* 496 */     this.quantum_luminance[62] = 103;
/* 497 */     this.quantum_luminance[63] = 99;
/*     */     byte b2;
/* 499 */     for (b2 = 0; b2 < 64; b2++) {
/*     */       
/* 501 */       int j = (this.quantum_luminance[b2] * i + 50) / 100;
/* 502 */       if (j <= 0) j = 1; 
/* 503 */       if (j > 255) j = 255; 
/* 504 */       this.quantum_luminance[b2] = j;
/*     */     } 
/* 506 */     byte b3 = 0; byte b1;
/* 507 */     for (b1 = 0; b1 < 8; b1++) {
/* 508 */       for (b2 = 0; b2 < 8; b2++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 514 */         this.DivisorsLuminance[b3] = 1.0D / this.quantum_luminance[b3] * arrayOfDouble[b1] * arrayOfDouble[b2] * 8.0D;
/* 515 */         b3++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 522 */     this.quantum_chrominance[0] = 17;
/* 523 */     this.quantum_chrominance[1] = 18;
/* 524 */     this.quantum_chrominance[2] = 24;
/* 525 */     this.quantum_chrominance[3] = 47;
/* 526 */     this.quantum_chrominance[4] = 99;
/* 527 */     this.quantum_chrominance[5] = 99;
/* 528 */     this.quantum_chrominance[6] = 99;
/* 529 */     this.quantum_chrominance[7] = 99;
/* 530 */     this.quantum_chrominance[8] = 18;
/* 531 */     this.quantum_chrominance[9] = 21;
/* 532 */     this.quantum_chrominance[10] = 26;
/* 533 */     this.quantum_chrominance[11] = 66;
/* 534 */     this.quantum_chrominance[12] = 99;
/* 535 */     this.quantum_chrominance[13] = 99;
/* 536 */     this.quantum_chrominance[14] = 99;
/* 537 */     this.quantum_chrominance[15] = 99;
/* 538 */     this.quantum_chrominance[16] = 24;
/* 539 */     this.quantum_chrominance[17] = 26;
/* 540 */     this.quantum_chrominance[18] = 56;
/* 541 */     this.quantum_chrominance[19] = 99;
/* 542 */     this.quantum_chrominance[20] = 99;
/* 543 */     this.quantum_chrominance[21] = 99;
/* 544 */     this.quantum_chrominance[22] = 99;
/* 545 */     this.quantum_chrominance[23] = 99;
/* 546 */     this.quantum_chrominance[24] = 47;
/* 547 */     this.quantum_chrominance[25] = 66;
/* 548 */     this.quantum_chrominance[26] = 99;
/* 549 */     this.quantum_chrominance[27] = 99;
/* 550 */     this.quantum_chrominance[28] = 99;
/* 551 */     this.quantum_chrominance[29] = 99;
/* 552 */     this.quantum_chrominance[30] = 99;
/* 553 */     this.quantum_chrominance[31] = 99;
/* 554 */     this.quantum_chrominance[32] = 99;
/* 555 */     this.quantum_chrominance[33] = 99;
/* 556 */     this.quantum_chrominance[34] = 99;
/* 557 */     this.quantum_chrominance[35] = 99;
/* 558 */     this.quantum_chrominance[36] = 99;
/* 559 */     this.quantum_chrominance[37] = 99;
/* 560 */     this.quantum_chrominance[38] = 99;
/* 561 */     this.quantum_chrominance[39] = 99;
/* 562 */     this.quantum_chrominance[40] = 99;
/* 563 */     this.quantum_chrominance[41] = 99;
/* 564 */     this.quantum_chrominance[42] = 99;
/* 565 */     this.quantum_chrominance[43] = 99;
/* 566 */     this.quantum_chrominance[44] = 99;
/* 567 */     this.quantum_chrominance[45] = 99;
/* 568 */     this.quantum_chrominance[46] = 99;
/* 569 */     this.quantum_chrominance[47] = 99;
/* 570 */     this.quantum_chrominance[48] = 99;
/* 571 */     this.quantum_chrominance[49] = 99;
/* 572 */     this.quantum_chrominance[50] = 99;
/* 573 */     this.quantum_chrominance[51] = 99;
/* 574 */     this.quantum_chrominance[52] = 99;
/* 575 */     this.quantum_chrominance[53] = 99;
/* 576 */     this.quantum_chrominance[54] = 99;
/* 577 */     this.quantum_chrominance[55] = 99;
/* 578 */     this.quantum_chrominance[56] = 99;
/* 579 */     this.quantum_chrominance[57] = 99;
/* 580 */     this.quantum_chrominance[58] = 99;
/* 581 */     this.quantum_chrominance[59] = 99;
/* 582 */     this.quantum_chrominance[60] = 99;
/* 583 */     this.quantum_chrominance[61] = 99;
/* 584 */     this.quantum_chrominance[62] = 99;
/* 585 */     this.quantum_chrominance[63] = 99;
/*     */     
/* 587 */     for (b2 = 0; b2 < 64; b2++) {
/*     */       
/* 589 */       int j = (this.quantum_chrominance[b2] * i + 50) / 100;
/* 590 */       if (j <= 0) j = 1; 
/* 591 */       if (j >= 255) j = 255; 
/* 592 */       this.quantum_chrominance[b2] = j;
/*     */     } 
/* 594 */     b3 = 0;
/* 595 */     for (b1 = 0; b1 < 8; b1++) {
/* 596 */       for (b2 = 0; b2 < 8; b2++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 602 */         this.DivisorsChrominance[b3] = 1.0D / this.quantum_chrominance[b3] * arrayOfDouble[b1] * arrayOfDouble[b2] * 8.0D;
/* 603 */         b3++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 609 */     this.quantum[0] = this.quantum_luminance;
/* 610 */     this.Divisors[0] = this.DivisorsLuminance;
/* 611 */     this.quantum[1] = this.quantum_chrominance;
/* 612 */     this.Divisors[1] = this.DivisorsChrominance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[][] forwardDCTExtreme(float[][] paramArrayOfFloat) {
/* 631 */     double[][] arrayOfDouble = new double[this.N][this.N];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 638 */     for (byte b = 0; b < 8; b++) {
/* 639 */       for (byte b1 = 0; b1 < 8; b1++) {
/* 640 */         for (byte b2 = 0; b2 < 8; b2++) {
/* 641 */           for (byte b3 = 0; b3 < 8; b3++) {
/* 642 */             arrayOfDouble[b][b1] = arrayOfDouble[b][b1] + paramArrayOfFloat[b2][b3] * Math.cos((2 * b2 + 1) * b1 * Math.PI / 16.0D) * Math.cos((2 * b3 + 1) * b * Math.PI / 16.0D);
/*     */           }
/*     */         } 
/* 645 */         arrayOfDouble[b][b1] = arrayOfDouble[b][b1] * 0.25D * (!b1 ? (1.0D / Math.sqrt(2.0D)) : 1.0D) * (!b ? (1.0D / Math.sqrt(2.0D)) : 1.0D);
/*     */       } 
/*     */     } 
/* 648 */     return arrayOfDouble;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[][] forwardDCT(float[][] paramArrayOfFloat) {
/* 658 */     double[][] arrayOfDouble = new double[this.N][this.N];
/*     */ 
/*     */ 
/*     */     
/*     */     byte b;
/*     */ 
/*     */ 
/*     */     
/* 666 */     for (b = 0; b < 8; b++) {
/* 667 */       for (byte b1 = 0; b1 < 8; b1++) {
/* 668 */         arrayOfDouble[b][b1] = paramArrayOfFloat[b][b1] - 128.0D;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 674 */     for (b = 0; b < 8; b++) {
/* 675 */       double d1 = arrayOfDouble[b][0] + arrayOfDouble[b][7];
/* 676 */       double d8 = arrayOfDouble[b][0] - arrayOfDouble[b][7];
/* 677 */       double d2 = arrayOfDouble[b][1] + arrayOfDouble[b][6];
/* 678 */       double d7 = arrayOfDouble[b][1] - arrayOfDouble[b][6];
/* 679 */       double d3 = arrayOfDouble[b][2] + arrayOfDouble[b][5];
/* 680 */       double d6 = arrayOfDouble[b][2] - arrayOfDouble[b][5];
/* 681 */       double d4 = arrayOfDouble[b][3] + arrayOfDouble[b][4];
/* 682 */       double d5 = arrayOfDouble[b][3] - arrayOfDouble[b][4];
/*     */       
/* 684 */       double d9 = d1 + d4;
/* 685 */       double d12 = d1 - d4;
/* 686 */       double d10 = d2 + d3;
/* 687 */       double d11 = d2 - d3;
/*     */       
/* 689 */       arrayOfDouble[b][0] = d9 + d10;
/* 690 */       arrayOfDouble[b][4] = d9 - d10;
/*     */       
/* 692 */       double d13 = (d11 + d12) * 0.707106781D;
/* 693 */       arrayOfDouble[b][2] = d12 + d13;
/* 694 */       arrayOfDouble[b][6] = d12 - d13;
/*     */       
/* 696 */       d9 = d5 + d6;
/* 697 */       d10 = d6 + d7;
/* 698 */       d11 = d7 + d8;
/*     */       
/* 700 */       double d17 = (d9 - d11) * 0.382683433D;
/* 701 */       double d14 = 0.5411961D * d9 + d17;
/* 702 */       double d16 = 1.306562965D * d11 + d17;
/* 703 */       double d15 = d10 * 0.707106781D;
/*     */       
/* 705 */       double d18 = d8 + d15;
/* 706 */       double d19 = d8 - d15;
/*     */       
/* 708 */       arrayOfDouble[b][5] = d19 + d14;
/* 709 */       arrayOfDouble[b][3] = d19 - d14;
/* 710 */       arrayOfDouble[b][1] = d18 + d16;
/* 711 */       arrayOfDouble[b][7] = d18 - d16;
/*     */     } 
/*     */     
/* 714 */     for (b = 0; b < 8; b++) {
/* 715 */       double d1 = arrayOfDouble[0][b] + arrayOfDouble[7][b];
/* 716 */       double d8 = arrayOfDouble[0][b] - arrayOfDouble[7][b];
/* 717 */       double d2 = arrayOfDouble[1][b] + arrayOfDouble[6][b];
/* 718 */       double d7 = arrayOfDouble[1][b] - arrayOfDouble[6][b];
/* 719 */       double d3 = arrayOfDouble[2][b] + arrayOfDouble[5][b];
/* 720 */       double d6 = arrayOfDouble[2][b] - arrayOfDouble[5][b];
/* 721 */       double d4 = arrayOfDouble[3][b] + arrayOfDouble[4][b];
/* 722 */       double d5 = arrayOfDouble[3][b] - arrayOfDouble[4][b];
/*     */       
/* 724 */       double d9 = d1 + d4;
/* 725 */       double d12 = d1 - d4;
/* 726 */       double d10 = d2 + d3;
/* 727 */       double d11 = d2 - d3;
/*     */       
/* 729 */       arrayOfDouble[0][b] = d9 + d10;
/* 730 */       arrayOfDouble[4][b] = d9 - d10;
/*     */       
/* 732 */       double d13 = (d11 + d12) * 0.707106781D;
/* 733 */       arrayOfDouble[2][b] = d12 + d13;
/* 734 */       arrayOfDouble[6][b] = d12 - d13;
/*     */       
/* 736 */       d9 = d5 + d6;
/* 737 */       d10 = d6 + d7;
/* 738 */       d11 = d7 + d8;
/*     */       
/* 740 */       double d17 = (d9 - d11) * 0.382683433D;
/* 741 */       double d14 = 0.5411961D * d9 + d17;
/* 742 */       double d16 = 1.306562965D * d11 + d17;
/* 743 */       double d15 = d10 * 0.707106781D;
/*     */       
/* 745 */       double d18 = d8 + d15;
/* 746 */       double d19 = d8 - d15;
/*     */       
/* 748 */       arrayOfDouble[5][b] = d19 + d14;
/* 749 */       arrayOfDouble[3][b] = d19 - d14;
/* 750 */       arrayOfDouble[1][b] = d18 + d16;
/* 751 */       arrayOfDouble[7][b] = d18 - d16;
/*     */     } 
/*     */     
/* 754 */     return arrayOfDouble;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] quantizeBlock(double[][] paramArrayOfDouble, int paramInt) {
/* 762 */     int[] arrayOfInt = new int[this.N * this.N];
/*     */ 
/*     */     
/* 765 */     byte b2 = 0;
/* 766 */     for (byte b1 = 0; b1 < 8; b1++) {
/* 767 */       for (byte b = 0; b < 8; b++) {
/*     */         
/* 769 */         arrayOfInt[b2] = (int)Math.round(paramArrayOfDouble[b1][b] * (double[])this.Divisors[paramInt][b2]);
/*     */         
/* 771 */         b2++;
/*     */       } 
/*     */     } 
/*     */     
/* 775 */     return arrayOfInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] quantizeBlockExtreme(double[][] paramArrayOfDouble, int paramInt) {
/* 784 */     int[] arrayOfInt = new int[this.N * this.N];
/*     */ 
/*     */     
/* 787 */     byte b2 = 0;
/* 788 */     for (byte b1 = 0; b1 < 8; b1++) {
/* 789 */       for (byte b = 0; b < 8; b++) {
/* 790 */         arrayOfInt[b2] = (int)Math.round(paramArrayOfDouble[b1][b] / (int[])this.quantum[paramInt][b2]);
/* 791 */         b2++;
/*     */       } 
/*     */     } 
/*     */     
/* 795 */     return arrayOfInt;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\DCT.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */