package inetsoft.report.internal;

class DCT {
  public int N;
  
  public int QUALITY;
  
  public Object[] quantum;
  
  public Object[] Divisors;
  
  public int[] quantum_luminance;
  
  public double[] DivisorsLuminance;
  
  public int[] quantum_chrominance;
  
  public double[] DivisorsChrominance;
  
  public DCT(int paramInt) {
    this.N = 8;
    this.QUALITY = 80;
    this.quantum = new Object[2];
    this.Divisors = new Object[2];
    this.quantum_luminance = new int[this.N * this.N];
    this.DivisorsLuminance = new double[this.N * this.N];
    this.quantum_chrominance = new int[this.N * this.N];
    this.DivisorsChrominance = new double[this.N * this.N];
    initMatrix(paramInt);
  }
  
  private void initMatrix(int paramInt) {
    double[] arrayOfDouble = { 1.0D, 1.387039845D, 1.306562965D, 1.175875602D, 1.0D, 0.785694958D, 0.5411961D, 0.275899379D };
    int i = paramInt;
    if (i <= 0)
      i = 1; 
    if (i > 100)
      i = 100; 
    if (i < 50) {
      i = 5000 / i;
    } else {
      i = 200 - i * 2;
    } 
    this.quantum_luminance[0] = 16;
    this.quantum_luminance[1] = 11;
    this.quantum_luminance[2] = 10;
    this.quantum_luminance[3] = 16;
    this.quantum_luminance[4] = 24;
    this.quantum_luminance[5] = 40;
    this.quantum_luminance[6] = 51;
    this.quantum_luminance[7] = 61;
    this.quantum_luminance[8] = 12;
    this.quantum_luminance[9] = 12;
    this.quantum_luminance[10] = 14;
    this.quantum_luminance[11] = 19;
    this.quantum_luminance[12] = 26;
    this.quantum_luminance[13] = 58;
    this.quantum_luminance[14] = 60;
    this.quantum_luminance[15] = 55;
    this.quantum_luminance[16] = 14;
    this.quantum_luminance[17] = 13;
    this.quantum_luminance[18] = 16;
    this.quantum_luminance[19] = 24;
    this.quantum_luminance[20] = 40;
    this.quantum_luminance[21] = 57;
    this.quantum_luminance[22] = 69;
    this.quantum_luminance[23] = 56;
    this.quantum_luminance[24] = 14;
    this.quantum_luminance[25] = 17;
    this.quantum_luminance[26] = 22;
    this.quantum_luminance[27] = 29;
    this.quantum_luminance[28] = 51;
    this.quantum_luminance[29] = 87;
    this.quantum_luminance[30] = 80;
    this.quantum_luminance[31] = 62;
    this.quantum_luminance[32] = 18;
    this.quantum_luminance[33] = 22;
    this.quantum_luminance[34] = 37;
    this.quantum_luminance[35] = 56;
    this.quantum_luminance[36] = 68;
    this.quantum_luminance[37] = 109;
    this.quantum_luminance[38] = 103;
    this.quantum_luminance[39] = 77;
    this.quantum_luminance[40] = 24;
    this.quantum_luminance[41] = 35;
    this.quantum_luminance[42] = 55;
    this.quantum_luminance[43] = 64;
    this.quantum_luminance[44] = 81;
    this.quantum_luminance[45] = 104;
    this.quantum_luminance[46] = 113;
    this.quantum_luminance[47] = 92;
    this.quantum_luminance[48] = 49;
    this.quantum_luminance[49] = 64;
    this.quantum_luminance[50] = 78;
    this.quantum_luminance[51] = 87;
    this.quantum_luminance[52] = 103;
    this.quantum_luminance[53] = 121;
    this.quantum_luminance[54] = 120;
    this.quantum_luminance[55] = 101;
    this.quantum_luminance[56] = 72;
    this.quantum_luminance[57] = 92;
    this.quantum_luminance[58] = 95;
    this.quantum_luminance[59] = 98;
    this.quantum_luminance[60] = 112;
    this.quantum_luminance[61] = 100;
    this.quantum_luminance[62] = 103;
    this.quantum_luminance[63] = 99;
    byte b2;
    for (b2 = 0; b2 < 64; b2++) {
      int j = (this.quantum_luminance[b2] * i + 50) / 100;
      if (j <= 0)
        j = 1; 
      if (j > 255)
        j = 255; 
      this.quantum_luminance[b2] = j;
    } 
    byte b3 = 0;
    byte b1;
    for (b1 = 0; b1 < 8; b1++) {
      for (b2 = 0; b2 < 8; b2++) {
        this.DivisorsLuminance[b3] = 1.0D / this.quantum_luminance[b3] * arrayOfDouble[b1] * arrayOfDouble[b2] * 8.0D;
        b3++;
      } 
    } 
    this.quantum_chrominance[0] = 17;
    this.quantum_chrominance[1] = 18;
    this.quantum_chrominance[2] = 24;
    this.quantum_chrominance[3] = 47;
    this.quantum_chrominance[4] = 99;
    this.quantum_chrominance[5] = 99;
    this.quantum_chrominance[6] = 99;
    this.quantum_chrominance[7] = 99;
    this.quantum_chrominance[8] = 18;
    this.quantum_chrominance[9] = 21;
    this.quantum_chrominance[10] = 26;
    this.quantum_chrominance[11] = 66;
    this.quantum_chrominance[12] = 99;
    this.quantum_chrominance[13] = 99;
    this.quantum_chrominance[14] = 99;
    this.quantum_chrominance[15] = 99;
    this.quantum_chrominance[16] = 24;
    this.quantum_chrominance[17] = 26;
    this.quantum_chrominance[18] = 56;
    this.quantum_chrominance[19] = 99;
    this.quantum_chrominance[20] = 99;
    this.quantum_chrominance[21] = 99;
    this.quantum_chrominance[22] = 99;
    this.quantum_chrominance[23] = 99;
    this.quantum_chrominance[24] = 47;
    this.quantum_chrominance[25] = 66;
    this.quantum_chrominance[26] = 99;
    this.quantum_chrominance[27] = 99;
    this.quantum_chrominance[28] = 99;
    this.quantum_chrominance[29] = 99;
    this.quantum_chrominance[30] = 99;
    this.quantum_chrominance[31] = 99;
    this.quantum_chrominance[32] = 99;
    this.quantum_chrominance[33] = 99;
    this.quantum_chrominance[34] = 99;
    this.quantum_chrominance[35] = 99;
    this.quantum_chrominance[36] = 99;
    this.quantum_chrominance[37] = 99;
    this.quantum_chrominance[38] = 99;
    this.quantum_chrominance[39] = 99;
    this.quantum_chrominance[40] = 99;
    this.quantum_chrominance[41] = 99;
    this.quantum_chrominance[42] = 99;
    this.quantum_chrominance[43] = 99;
    this.quantum_chrominance[44] = 99;
    this.quantum_chrominance[45] = 99;
    this.quantum_chrominance[46] = 99;
    this.quantum_chrominance[47] = 99;
    this.quantum_chrominance[48] = 99;
    this.quantum_chrominance[49] = 99;
    this.quantum_chrominance[50] = 99;
    this.quantum_chrominance[51] = 99;
    this.quantum_chrominance[52] = 99;
    this.quantum_chrominance[53] = 99;
    this.quantum_chrominance[54] = 99;
    this.quantum_chrominance[55] = 99;
    this.quantum_chrominance[56] = 99;
    this.quantum_chrominance[57] = 99;
    this.quantum_chrominance[58] = 99;
    this.quantum_chrominance[59] = 99;
    this.quantum_chrominance[60] = 99;
    this.quantum_chrominance[61] = 99;
    this.quantum_chrominance[62] = 99;
    this.quantum_chrominance[63] = 99;
    for (b2 = 0; b2 < 64; b2++) {
      int j = (this.quantum_chrominance[b2] * i + 50) / 100;
      if (j <= 0)
        j = 1; 
      if (j >= 255)
        j = 255; 
      this.quantum_chrominance[b2] = j;
    } 
    b3 = 0;
    for (b1 = 0; b1 < 8; b1++) {
      for (b2 = 0; b2 < 8; b2++) {
        this.DivisorsChrominance[b3] = 1.0D / this.quantum_chrominance[b3] * arrayOfDouble[b1] * arrayOfDouble[b2] * 8.0D;
        b3++;
      } 
    } 
    this.quantum[0] = this.quantum_luminance;
    this.Divisors[0] = this.DivisorsLuminance;
    this.quantum[1] = this.quantum_chrominance;
    this.Divisors[1] = this.DivisorsChrominance;
  }
  
  public double[][] forwardDCTExtreme(float[][] paramArrayOfFloat) {
    double[][] arrayOfDouble = new double[this.N][this.N];
    for (byte b = 0; b < 8; b++) {
      for (byte b1 = 0; b1 < 8; b1++) {
        for (byte b2 = 0; b2 < 8; b2++) {
          for (byte b3 = 0; b3 < 8; b3++)
            arrayOfDouble[b][b1] = arrayOfDouble[b][b1] + paramArrayOfFloat[b2][b3] * Math.cos((2 * b2 + 1) * b1 * Math.PI / 16.0D) * Math.cos((2 * b3 + 1) * b * Math.PI / 16.0D); 
        } 
        arrayOfDouble[b][b1] = arrayOfDouble[b][b1] * 0.25D * (!b1 ? (1.0D / Math.sqrt(2.0D)) : 1.0D) * (!b ? (1.0D / Math.sqrt(2.0D)) : 1.0D);
      } 
    } 
    return arrayOfDouble;
  }
  
  public double[][] forwardDCT(float[][] paramArrayOfFloat) {
    double[][] arrayOfDouble = new double[this.N][this.N];
    byte b;
    for (b = 0; b < 8; b++) {
      for (byte b1 = 0; b1 < 8; b1++)
        arrayOfDouble[b][b1] = paramArrayOfFloat[b][b1] - 128.0D; 
    } 
    for (b = 0; b < 8; b++) {
      double d1 = arrayOfDouble[b][0] + arrayOfDouble[b][7];
      double d8 = arrayOfDouble[b][0] - arrayOfDouble[b][7];
      double d2 = arrayOfDouble[b][1] + arrayOfDouble[b][6];
      double d7 = arrayOfDouble[b][1] - arrayOfDouble[b][6];
      double d3 = arrayOfDouble[b][2] + arrayOfDouble[b][5];
      double d6 = arrayOfDouble[b][2] - arrayOfDouble[b][5];
      double d4 = arrayOfDouble[b][3] + arrayOfDouble[b][4];
      double d5 = arrayOfDouble[b][3] - arrayOfDouble[b][4];
      double d9 = d1 + d4;
      double d12 = d1 - d4;
      double d10 = d2 + d3;
      double d11 = d2 - d3;
      arrayOfDouble[b][0] = d9 + d10;
      arrayOfDouble[b][4] = d9 - d10;
      double d13 = (d11 + d12) * 0.707106781D;
      arrayOfDouble[b][2] = d12 + d13;
      arrayOfDouble[b][6] = d12 - d13;
      d9 = d5 + d6;
      d10 = d6 + d7;
      d11 = d7 + d8;
      double d17 = (d9 - d11) * 0.382683433D;
      double d14 = 0.5411961D * d9 + d17;
      double d16 = 1.306562965D * d11 + d17;
      double d15 = d10 * 0.707106781D;
      double d18 = d8 + d15;
      double d19 = d8 - d15;
      arrayOfDouble[b][5] = d19 + d14;
      arrayOfDouble[b][3] = d19 - d14;
      arrayOfDouble[b][1] = d18 + d16;
      arrayOfDouble[b][7] = d18 - d16;
    } 
    for (b = 0; b < 8; b++) {
      double d1 = arrayOfDouble[0][b] + arrayOfDouble[7][b];
      double d8 = arrayOfDouble[0][b] - arrayOfDouble[7][b];
      double d2 = arrayOfDouble[1][b] + arrayOfDouble[6][b];
      double d7 = arrayOfDouble[1][b] - arrayOfDouble[6][b];
      double d3 = arrayOfDouble[2][b] + arrayOfDouble[5][b];
      double d6 = arrayOfDouble[2][b] - arrayOfDouble[5][b];
      double d4 = arrayOfDouble[3][b] + arrayOfDouble[4][b];
      double d5 = arrayOfDouble[3][b] - arrayOfDouble[4][b];
      double d9 = d1 + d4;
      double d12 = d1 - d4;
      double d10 = d2 + d3;
      double d11 = d2 - d3;
      arrayOfDouble[0][b] = d9 + d10;
      arrayOfDouble[4][b] = d9 - d10;
      double d13 = (d11 + d12) * 0.707106781D;
      arrayOfDouble[2][b] = d12 + d13;
      arrayOfDouble[6][b] = d12 - d13;
      d9 = d5 + d6;
      d10 = d6 + d7;
      d11 = d7 + d8;
      double d17 = (d9 - d11) * 0.382683433D;
      double d14 = 0.5411961D * d9 + d17;
      double d16 = 1.306562965D * d11 + d17;
      double d15 = d10 * 0.707106781D;
      double d18 = d8 + d15;
      double d19 = d8 - d15;
      arrayOfDouble[5][b] = d19 + d14;
      arrayOfDouble[3][b] = d19 - d14;
      arrayOfDouble[1][b] = d18 + d16;
      arrayOfDouble[7][b] = d18 - d16;
    } 
    return arrayOfDouble;
  }
  
  public int[] quantizeBlock(double[][] paramArrayOfDouble, int paramInt) {
    int[] arrayOfInt = new int[this.N * this.N];
    byte b2 = 0;
    for (byte b1 = 0; b1 < 8; b1++) {
      for (byte b = 0; b < 8; b++) {
        arrayOfInt[b2] = (int)Math.round(paramArrayOfDouble[b1][b] * (double[])this.Divisors[paramInt][b2]);
        b2++;
      } 
    } 
    return arrayOfInt;
  }
  
  public int[] quantizeBlockExtreme(double[][] paramArrayOfDouble, int paramInt) {
    int[] arrayOfInt = new int[this.N * this.N];
    byte b2 = 0;
    for (byte b1 = 0; b1 < 8; b1++) {
      for (byte b = 0; b < 8; b++) {
        arrayOfInt[b2] = (int)Math.round(paramArrayOfDouble[b1][b] / (int[])this.quantum[paramInt][b2]);
        b2++;
      } 
    } 
    return arrayOfInt;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\DCT.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */