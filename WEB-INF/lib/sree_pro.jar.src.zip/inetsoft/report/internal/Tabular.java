package inetsoft.report.internal;

import inetsoft.report.TableLens;

public interface Tabular {
  void setData(TableLens paramTableLens);
  
  boolean isEmbedded();
  
  void setEmbedded(boolean paramBoolean);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\internal\Tabular.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */