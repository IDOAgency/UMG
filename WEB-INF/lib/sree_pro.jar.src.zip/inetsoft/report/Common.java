package inetsoft.report;

import inetsoft.report.internal.BasePaintable;
import inetsoft.report.internal.Bounds;
import inetsoft.report.internal.Gop;
import inetsoft.report.internal.Util;
import inetsoft.report.pdf.FontManager;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class Common extends Util {
  public static StyleSheet createStyleSheet() { return g2d.createStyleSheet(); }
  
  public static void print(StyleSheet paramStyleSheet) throws Exception { g2d.print(paramStyleSheet); }
  
  public static void print(String paramString, Enumeration paramEnumeration, boolean paramBoolean) throws Exception { g2d.print(paramString, paramEnumeration, paramBoolean); }
  
  public static float getLineAdjustment(Graphics paramGraphics) { return g2d.getLineAdjustment(paramGraphics); }
  
  public static boolean isGraphics2D(Graphics paramGraphics) { return g2d.isGraphics2D(paramGraphics); }
  
  public static boolean isJava2() { return g2d.isJava2(); }
  
  public static void drawLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt) { g2d.drawLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt); }
  
  public static void drawLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) { g2d.drawLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4); }
  
  public static void drawHLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, int paramInt3) { g2d.drawHLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramInt1, paramInt2, paramInt3); }
  
  public static void drawVLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, int paramInt3) { g2d.drawVLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramInt1, paramInt2, paramInt3); }
  
  public static void fillRect(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) { g2d.fillRect(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4); }
  
  public static void fillArc(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, Object paramObject) { g2d.fillArc(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramObject); }
  
  public static void fill(Graphics paramGraphics, Shape paramShape, Object paramObject) { g2d.fill(paramGraphics, paramShape, paramObject); }
  
  public static void setClip(Graphics paramGraphics, Bounds paramBounds) { g2d.setClip(paramGraphics, paramBounds); }
  
  public static void clipRect(Graphics paramGraphics, Bounds paramBounds) { g2d.clipRect(paramGraphics, paramBounds); }
  
  public static void drawImage(Graphics paramGraphics, Image paramImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, ImageObserver paramImageObserver) { g2d.drawImage(paramGraphics, paramImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramImageObserver); }
  
  public static void rotate(Graphics paramGraphics, double paramDouble) { g2d.rotate(paramGraphics, paramDouble); }
  
  public static void paintPage(Graphics paramGraphics, PreviewPage paramPreviewPage) { g2d.paintPage(paramGraphics, paramPreviewPage); }
  
  public static Image createImage(byte[] paramArrayOfByte, int paramInt1, int paramInt2) { return g2d.createImage(paramArrayOfByte, paramInt1, paramInt2); }
  
  public static void paint(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Painter paramPainter, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, Color paramColor1, Color paramColor2) { g2d.paint(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramPainter, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramColor1, paramColor2); }
  
  public static Object getPaint(int paramInt) { return g2d.getPaint(paramInt); }
  
  public static float getHeight(Font paramFont, FontMetrics paramFontMetrics) { return g2d.getHeight(paramFont, paramFontMetrics); }
  
  public static float getAscent(FontMetrics paramFontMetrics) { return g2d.getAscent(paramFontMetrics); }
  
  public static float getAscent(Font paramFont) { return g2d.getAscent(getFontMetrics(paramFont)); }
  
  public static String[] getAllFonts() { return g2d.getAllFonts(); }
  
  public static String getFontName(Font paramFont) { return g2d.getFontName(paramFont); }
  
  public static String getPSName(Font paramFont) { return g2d.getPSName(paramFont); }
  
  public static void paintRotate(Painter paramPainter, Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) { g2d.paintRotate(paramPainter, paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4); }
  
  public static void startPage(Graphics paramGraphics, StylePage paramStylePage) { g2d.startPage(paramGraphics, paramStylePage); }
  
  private static Frame root = null;
  
  public static Frame getInvisibleFrame() {
    if (root == null) {
      root = new Frame("invisible");
      root.pack();
    } 
    return root;
  }
  
  public static Image createImage(int paramInt1, int paramInt2) { return g2d.createImage(paramInt1, paramInt2); }
  
  public static float stringWidth(String paramString, Font paramFont) { return stringWidth(paramString, paramFont, getFontMetrics(paramFont)); }
  
  public static float stringWidth(String paramString, Font paramFont, FontMetrics paramFontMetrics) {
    if (paramString == null || paramString.length() == 0)
      return 0.0F; 
    if (paramFont instanceof StyleFont) {
      StyleFont styleFont = (StyleFont)paramFont;
      int i = styleFont.getStyle();
      if ((i & 0x40) != 0 || (i & 0x80) != 0) {
        paramFont = styleFont = new StyleFont(styleFont.getName(), i, styleFont.getSize() * 2 / 3);
        paramFontMetrics = getFontMetrics(styleFont);
      } 
      if ((i & 0x200) != 0) {
        Font font = new Font(styleFont.getName(), styleFont.getStyle(), styleFont.getSize() - 2);
        FontMetrics fontMetrics = getFontMetrics(font);
        int j = 0;
        for (byte b = 0; b < paramString.length(); b++) {
          char c = paramString.charAt(b);
          if (Character.isLowerCase(c)) {
            j += fontMetrics.charWidth(Character.toUpperCase(c));
          } else {
            j += paramFontMetrics.charWidth(c);
          } 
        } 
        return j;
      } 
      if ((i & 0x400) != 0)
        return g2d.stringWidth(paramString.toUpperCase(), paramFont, paramFontMetrics); 
    } 
    return g2d.stringWidth(paramString, paramFont, paramFontMetrics);
  }
  
  public static void drawString(Graphics paramGraphics, String paramString, float paramFloat1, float paramFloat2, float paramFloat3) {
    if (paramString == null || paramString.length() == 0)
      return; 
    if (paramString.indexOf(' ') < 0) {
      drawString(paramGraphics, paramString, paramFloat1, paramFloat2);
      return;
    } 
    Font font = paramGraphics.getFont();
    FontMetrics fontMetrics = paramGraphics.getFontMetrics();
    int i = 0;
    int j = 0;
    if (font instanceof StyleFont && (((StyleFont)font).getStyle() & 0x10) != 0)
      j = ((StyleFont)font).getLineStyle(); 
    String[] arrayOfString = Util.split(paramString, ' ');
    float[] arrayOfFloat = new float[arrayOfString.length];
    for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
      arrayOfFloat[b1] = stringWidth(arrayOfString[b1], font, fontMetrics);
      i = (int)(i + arrayOfFloat[b1]);
    } 
    double d1 = (paramFloat3 - i) / (arrayOfString.length - 1.0D);
    double d2 = paramFloat1;
    for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
      drawString(paramGraphics, arrayOfString[b2], (float)d2, paramFloat2);
      d2 += arrayOfFloat[b2];
      if (j != 0 && b2 < arrayOfString.length - 1) {
        float f = paramFloat2 + fontMetrics.getDescent() - 1.0F;
        drawHLine(paramGraphics, f, (float)d2, (float)(d2 + d1), j, 0, 0);
      } 
      d2 += d1;
    } 
  }
  
  public static void drawString(Graphics paramGraphics, String paramString, float paramFloat1, float paramFloat2) {
    if (paramString == null || paramString.length() == 0)
      return; 
    if (paramGraphics.getFont() instanceof StyleFont) {
      StyleFont styleFont = (StyleFont)paramGraphics.getFont();
      FontMetrics fontMetrics = getFontMetrics(styleFont);
      int i = styleFont.getStyle();
      if ((i & 0x40) != 0) {
        paramFloat2 -= getAscent(fontMetrics) / 3.0F;
        styleFont = new StyleFont(styleFont.getName(), i, styleFont.getSize() * 2 / 3);
        fontMetrics = getFontMetrics(styleFont);
        paramGraphics.setFont(styleFont);
      } else if ((i & 0x80) != 0) {
        paramFloat2 += (fontMetrics.getDescent() / 3);
        styleFont = new StyleFont(styleFont.getName(), i, styleFont.getSize() * 2 / 3);
        fontMetrics = getFontMetrics(styleFont);
        paramGraphics.setFont(styleFont);
      } 
      drawStringCase(paramGraphics, paramString, paramFloat1, paramFloat2);
      if ((i & 0x20) != 0) {
        float f = paramFloat2 - getAscent(fontMetrics) + getHeight(styleFont, fontMetrics) / 2.0F - getLineWidth(styleFont.getLineStyle()) / 2.0F;
        drawHLine(paramGraphics, f, paramFloat1, paramFloat1 + stringWidth(paramString, styleFont), styleFont.getLineStyle(), 0, 0);
      } 
      if ((i & 0x10) != 0) {
        float f = paramFloat2 + fontMetrics.getDescent() - 1.0F;
        drawHLine(paramGraphics, f, paramFloat1, paramFloat1 + stringWidth(paramString, styleFont), styleFont.getLineStyle(), 0, 0);
      } 
    } else {
      g2d.drawString(paramGraphics, paramString, paramFloat1, paramFloat2);
    } 
  }
  
  static void drawStringCase(Graphics paramGraphics, String paramString, float paramFloat1, float paramFloat2) {
    StyleFont styleFont = (StyleFont)paramGraphics.getFont();
    int i = styleFont.getStyle();
    if ((i & 0x200) != 0) {
      FontMetrics fontMetrics1 = getFontMetrics(styleFont);
      Font font = new Font(styleFont.getName(), styleFont.getStyle(), styleFont.getSize() - 2);
      FontMetrics fontMetrics2 = getFontMetrics(font);
      for (byte b = 0; b < paramString.length(); b++) {
        char c = paramString.charAt(b);
        if (Character.isLowerCase(c)) {
          c = Character.toUpperCase(c);
          paramGraphics.setFont(font);
          if ((i & 0x100) != 0) {
            Color color = paramGraphics.getColor();
            paramGraphics.setColor(Util.brighter(color));
            g2d.drawString(paramGraphics, "" + c, paramFloat1 + 1.0F, paramFloat2 + 1.0F);
            paramGraphics.setColor(color);
          } 
          g2d.drawString(paramGraphics, "" + c, paramFloat1, paramFloat2);
          paramFloat1 += fontMetrics2.charWidth(c);
        } else {
          paramGraphics.setFont(styleFont);
          if ((i & 0x100) != 0) {
            Color color = paramGraphics.getColor();
            paramGraphics.setColor(Util.brighter(color));
            g2d.drawString(paramGraphics, "" + c, paramFloat1 + 1.0F, paramFloat2 + 1.0F);
            paramGraphics.setColor(color);
          } 
          g2d.drawString(paramGraphics, "" + c, paramFloat1, paramFloat2);
          paramFloat1 += fontMetrics1.charWidth(c);
        } 
      } 
      paramGraphics.setFont(styleFont);
    } else {
      if ((i & 0x400) != 0)
        paramString = paramString.toUpperCase(); 
      if ((i & 0x100) != 0) {
        Color color = paramGraphics.getColor();
        paramGraphics.setColor(Util.brighter(color));
        g2d.drawString(paramGraphics, paramString, paramFloat1 + 1.0F, paramFloat2 + 1.0F);
        paramGraphics.setColor(color);
      } 
      g2d.drawString(paramGraphics, paramString, paramFloat1, paramFloat2);
    } 
  }
  
  public static int compare(Object paramObject1, Object paramObject2) { return g2d.compare(paramObject1, paramObject2); }
  
  static Font lastFn = null;
  
  static FontMetrics lastFm = null;
  
  static Hashtable fmcache = new Hashtable();
  
  public static FontMetrics getFontMetrics(Font paramFont) {
    if (paramFont == lastFn)
      return lastFm; 
    FontMetrics fontMetrics = (FontMetrics)fmcache.get(paramFont);
    if (fontMetrics == null) {
      if (ReportEnv.getProperty("font.metrics.source", "awt").equals("awt")) {
        fontMetrics = getToolkit().getFontMetrics(paramFont);
      } else {
        fontMetrics = FontManager.getFontManager().getFontMetrics(paramFont);
      } 
      fmcache.put(paramFont, fontMetrics);
    } 
    lastFn = paramFont;
    lastFm = fontMetrics;
    return fontMetrics;
  }
  
  public static PreviewView getPreviewView() { return g2d.getPreviewView(); }
  
  public static void writeJPEG(Image paramImage, OutputStream paramOutputStream) { g2d.writeJPEG(paramImage, paramOutputStream); }
  
  public static void paintText(Graphics paramGraphics, String paramString, Bounds paramBounds, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2) {
    Bounds bounds = new Bounds();
    Vector vector1 = new Vector();
    Vector vector2 = processText(paramString, paramBounds, paramInt1, paramBoolean1, paramGraphics.getFont(), bounds, vector1, paramInt2);
    paintText(paramGraphics, paramString, vector2, paramBounds, bounds, paramBoolean2, vector1, paramInt2);
  }
  
  public static void paintText(Graphics paramGraphics, String paramString, Vector paramVector1, Bounds paramBounds1, Bounds paramBounds2, boolean paramBoolean, Vector paramVector2, int paramInt) {
    Shape shape = paramGraphics.getClip();
    clipRect(paramGraphics, new Bounds(paramBounds1.x, paramBounds1.y, paramBounds1.width, paramBounds1.height));
    Font font = paramGraphics.getFont();
    FontMetrics fontMetrics = getFontMetrics(font);
    float f = paramBounds2.y + getAscent(fontMetrics);
    for (byte b = 0; b < paramVector1.size(); b++) {
      float f1 = paramBounds2.x;
      if (paramVector2 != null && b < paramVector2.size())
        f1 += ((Float)paramVector2.elementAt(b)).floatValue(); 
      int[] arrayOfInt = (int[])paramVector1.elementAt(b);
      String str = paramString.substring(arrayOfInt[0], arrayOfInt[1]);
      if (paramBoolean && b < paramVector1.size() - 1) {
        drawString(paramGraphics, str, f1, f, paramBounds2.width);
      } else if (str.indexOf(' ') >= 0) {
        if (font.getSize() > 14) {
          drawString(paramGraphics, str, f1, f);
        } else {
          drawString(paramGraphics, str, f1, f, stringWidth(str, paramGraphics.getFont(), fontMetrics));
        } 
      } else {
        drawString(paramGraphics, str, f1, f);
      } 
      f += getHeight(paramGraphics.getFont(), fontMetrics) + paramInt;
    } 
    paramGraphics.setClip(shape);
  }
  
  public static Vector processText(String paramString, Bounds paramBounds1, int paramInt1, boolean paramBoolean, Font paramFont, Bounds paramBounds2, Vector paramVector, int paramInt2) {
    Vector vector = new Vector();
    paramVector.removeAllElements();
    if (paramBounds1.width <= 0.0F || paramBounds1.height <= 0.0F)
      return vector; 
    Size size = new Size();
    FontMetrics fontMetrics = getFontMetrics(paramFont);
    int i = 0;
    while (paramString != null) {
      int j = paramString.indexOf('\n');
      if (paramBoolean) {
        int k = Math.max(fontMetrics.charWidth('.'), 4);
        int m = (j >= 0) ? j : Math.min(paramString.length(), (int)(paramBounds1.width / k * 0.5D));
        String str = paramString.substring(0, m);
        boolean bool = true;
        if (stringWidth(str, paramFont) > paramBounds1.width) {
          int i1 = Math.max(1, m) - 1;
          str = paramString.substring(0, i1);
          while (i1 > 0 && stringWidth(str, paramFont) > paramBounds1.width)
            str = paramString.substring(0, --i1); 
          m = i1;
          while (m > 0 && !Character.isWhitespace(paramString.charAt(m)))
            m--; 
          if (m <= 0) {
            m = i1;
            bool = false;
          } 
          str = paramString.substring(0, m);
        } 
        str = Util.trimEnd(str);
        vector.addElement(new int[] { i, i + str.length() });
        float f1 = stringWidth(str, paramFont, fontMetrics);
        paramVector.addElement(new Float(f1));
        size.width = Math.max(size.width, f1);
        if (m >= paramString.length())
          break; 
        int n = bool ? (m + 1) : Math.max(m, 1);
        i += n;
        paramString = paramString.substring(n);
        continue;
      } 
      if (j >= 0) {
        String str = Util.trimEnd(paramString.substring(0, j));
        float f1 = stringWidth(str, paramFont, fontMetrics);
        paramVector.addElement(new Float(f1));
        size.width = Math.max(size.width, f1);
        paramString = paramString.substring(j + 1);
        vector.addElement(new int[] { i, i + str.length() });
        i += j + 1;
        continue;
      } 
      paramString = Util.trimEnd(paramString);
      float f = stringWidth(paramString, paramFont, fontMetrics);
      paramVector.addElement(new Float(f));
      size.width = Math.max(size.width, f);
      vector.addElement(new int[] { i, i + paramString.length() });
      break;
    } 
    size.height = (getHeight(fontMetrics.getFont(), fontMetrics) + paramInt2) * vector.size();
    Bounds bounds = alignCell(paramBounds1, size, paramInt1);
    paramBounds2.x = bounds.x;
    bounds.y += Math.max((bounds.height - size.height) / 2.0F, 0.0F);
    paramBounds2.width = bounds.width;
    paramBounds2.height = Math.min(size.height, paramBounds1.y + paramBounds1.height - paramBounds2.y);
    for (byte b = 0; b < paramVector.size(); b++) {
      float f = ((Float)paramVector.elementAt(b)).floatValue();
      if ((paramInt1 & 0x2) != 0) {
        paramVector.setElementAt(new Float((bounds.width - f) / 2.0F), b);
      } else if ((paramInt1 & 0x4) != 0) {
        paramVector.setElementAt(new Float(bounds.width - f), b);
      } else {
        paramVector.setElementAt(new Float(0.0F), b);
      } 
    } 
    return vector;
  }
  
  public static Bounds alignCell(Bounds paramBounds, Size paramSize, int paramInt) {
    Bounds bounds = new Bounds(paramBounds.x, paramBounds.y, paramBounds.width, paramBounds.height);
    if (paramSize.width < bounds.width)
      if ((paramInt & 0x2) != 0) {
        bounds.x += (bounds.width - paramSize.width) / 2.0F;
        bounds.width = paramSize.width;
      } else if ((paramInt & 0x4) != 0) {
        bounds.x += bounds.width - paramSize.width - 1.0F;
        bounds.width = paramSize.width;
      } else if ((paramInt & true) != 0) {
        bounds.width = paramSize.width;
      }  
    if (paramSize.height < bounds.height)
      if ((paramInt & 0x10) != 0) {
        bounds.y += (bounds.height - paramSize.height) / 2.0F;
        bounds.height = paramSize.height;
      } else if ((paramInt & 0x20) != 0) {
        bounds.y += bounds.height - paramSize.height - 1.0F;
        bounds.height = paramSize.height;
      } else if ((paramInt & 0x8) != 0) {
        bounds.height = paramSize.height;
      }  
    return bounds;
  }
  
  public static void drawRect(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt) {
    float f1 = getLineAdjustment(paramGraphics);
    float f2 = getLineWidth(paramInt);
    paramFloat3 -= f2;
    paramFloat4 -= f2;
    drawHLine(paramGraphics, paramFloat2 + f1, paramFloat1, paramFloat1 + paramFloat3, paramInt, 0, paramInt);
    drawHLine(paramGraphics, paramFloat2 + paramFloat4 + f1, paramFloat1, paramFloat1 + paramFloat3, paramInt, paramInt, 0);
    drawVLine(paramGraphics, paramFloat1 + f1, paramFloat2, paramFloat2 + paramFloat4, paramInt, 0, paramInt);
    drawVLine(paramGraphics, paramFloat1 + paramFloat3 + f1, paramFloat2, paramFloat2 + paramFloat4, paramInt, paramInt, 0);
    drawVLine(paramGraphics, paramFloat1 + f1, paramFloat2 + paramFloat4, paramFloat2 + paramFloat4 + f2 - 1.0F, paramInt, 0, paramInt);
    drawHLine(paramGraphics, paramFloat2 + f1, paramFloat1 + paramFloat3, paramFloat1 + paramFloat3 + f2 - 1.0F, paramInt, 0, paramInt);
    drawVLine(paramGraphics, paramFloat1 + paramFloat3 + f1, paramFloat2 + paramFloat4, paramFloat2 + paramFloat4 + f2 - 1.0F, paramInt, paramInt, 0);
    drawHLine(paramGraphics, paramFloat2 + paramFloat4 + f1, paramFloat1 + paramFloat3, paramFloat1 + paramFloat3 + f2 - 1.0F, paramInt, paramInt, 0);
  }
  
  public static void drawRect(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    float f1 = getLineAdjustment(paramGraphics);
    float f2 = getLineWidth(paramInt3);
    float f3 = getLineWidth(paramInt4);
    paramFloat3 -= f3;
    paramFloat4 -= f2;
    drawHLine(paramGraphics, paramFloat2 + f1, paramFloat1, paramFloat1 + paramFloat3, paramInt1, 0, paramInt2);
    drawHLine(paramGraphics, paramFloat2 + paramFloat4 + f1, paramFloat1, paramFloat1 + paramFloat3, paramInt3, paramInt2, 0);
    drawVLine(paramGraphics, paramFloat1 + f1, paramFloat2, paramFloat2 + paramFloat4, paramInt2, 0, paramInt1);
    drawVLine(paramGraphics, paramFloat1 + paramFloat3 + f1, paramFloat2, paramFloat2 + paramFloat4, paramInt4, paramInt1, 0);
    drawVLine(paramGraphics, paramFloat1 + f1, paramFloat2 + paramFloat4, paramFloat2 + paramFloat4 + f2 - 1.0F, paramInt2, 0, paramInt3);
    drawHLine(paramGraphics, paramFloat2 + f1, paramFloat1 + paramFloat3, paramFloat1 + paramFloat3 + f3 - 1.0F, paramInt1, 0, paramInt4);
    drawVLine(paramGraphics, paramFloat1 + paramFloat3 + f1, paramFloat2 + paramFloat4, paramFloat2 + paramFloat4 + f2, paramInt4, paramInt3, 0);
    drawHLine(paramGraphics, paramFloat2 + paramFloat4 + f1, paramFloat1 + paramFloat3, paramFloat1 + paramFloat3 + f3, paramInt3, paramInt4, 0);
  }
  
  public static void drawRect(StylePage paramStylePage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, Color paramColor) {
    paramStylePage.addPaintable(new BasePaintable(paramColor, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt, null) {
          private final Color val$color;
          
          private final float val$x;
          
          private final float val$y;
          
          private final float val$w;
          
          private final float val$h;
          
          private final int val$style;
          
          public void paint(Graphics param1Graphics) {
            Color color = param1Graphics.getColor();
            if (this.val$color != null)
              param1Graphics.setColor(this.val$color); 
            Common.drawRect(param1Graphics, this.val$x, this.val$y, this.val$w, this.val$h, this.val$style);
            param1Graphics.setColor(color);
          }
          
          public Rectangle getBounds() { return new Rectangle(Common.round(this.val$x), Common.round(this.val$y), Common.round(this.val$w), Common.round(this.val$h)); }
          
          public void setLocation(Point param1Point) {}
          
          public ReportElement getElement() { return null; }
        });
  }
  
  public static Color getColor(int paramInt) { return colors[paramInt % colors.length]; }
  
  public static Image getImage(Object paramObject, String paramString) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    InputStream inputStream = ((paramObject == null) ? Common.class : ((paramObject instanceof Class) ? (Class)paramObject : paramObject.getClass())).getResourceAsStream(paramString);
    if (inputStream == null)
      return null; 
    try {
      byte[] arrayOfByte = new byte[4096];
      int i;
      while ((i = inputStream.read(arrayOfByte)) >= 0)
        byteArrayOutputStream.write(arrayOfByte, 0, i); 
      return getToolkit().createImage(byteArrayOutputStream.toByteArray());
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public static int round(double paramDouble) { return (int)Math.ceil(paramDouble); }
  
  public static Toolkit getToolkit() {
    if (toolkit == null)
      toolkit = Toolkit.getDefaultToolkit(); 
    return toolkit;
  }
  
  public static void waitForImage(Image paramImage) {
    tracker.addImage(paramImage, 0);
    try {
      tracker.waitForAll();
    } catch (Exception exception) {}
    tracker.removeImage(paramImage);
  }
  
  public static float getLineWidth(int paramInt) {
    if (paramInt == -1)
      return 0.0F; 
    return g2d.getLineWidth(paramInt);
  }
  
  private static Toolkit toolkit = null;
  
  private static Gop g2d = Gop.getInstance();
  
  private static final Component component = new Component() {
    
    };
  
  private static final MediaTracker tracker = new MediaTracker(component);
  
  private static final Color[] colors = { 
      Color.green, Color.red, Color.yellow, Color.magenta, Color.orange, Color.cyan, Color.blue, Color.gray, Color.pink, Color.darkGray, 
      new Color(150, 0, 150), new Color(25, 80, 150), new Color(150, 80, 25), new Color(126, 0, 0), new Color(0, 126, 0), new Color(0, 0, 126), new Color(240, 80, 240), new Color(80, 240, 80), new Color(50, 100, 150), new Color(100, 150, 200), 
      new Color(150, 200, 250), new Color(150, 100, 50), new Color(200, 150, 100), new Color(250, 200, 150), new Color(60, 75, 60), new Color(90, 75, 45), new Color(128, 0, 64), new Color(64, 0, 128), new Color(70, 20, 38), new Color(100, 100, 30) };
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Common.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */