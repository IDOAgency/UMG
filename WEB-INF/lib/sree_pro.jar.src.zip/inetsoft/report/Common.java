/*      */ package inetsoft.report;
/*      */ 
/*      */ import inetsoft.report.internal.BasePaintable;
/*      */ import inetsoft.report.internal.Bounds;
/*      */ import inetsoft.report.internal.Gop;
/*      */ import inetsoft.report.internal.Util;
/*      */ import inetsoft.report.pdf.FontManager;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Frame;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Image;
/*      */ import java.awt.MediaTracker;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Shape;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.image.ImageObserver;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Common
/*      */   extends Util
/*      */ {
/*   40 */   public static StyleSheet createStyleSheet() { return g2d.createStyleSheet(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   47 */   public static void print(StyleSheet paramStyleSheet) throws Exception { g2d.print(paramStyleSheet); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   58 */   public static void print(String paramString, Enumeration paramEnumeration, boolean paramBoolean) throws Exception { g2d.print(paramString, paramEnumeration, paramBoolean); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   67 */   public static float getLineAdjustment(Graphics paramGraphics) { return g2d.getLineAdjustment(paramGraphics); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   74 */   public static boolean isGraphics2D(Graphics paramGraphics) { return g2d.isGraphics2D(paramGraphics); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   81 */   public static boolean isJava2() { return g2d.isJava2(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   89 */   public static void drawLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt) { g2d.drawLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   97 */   public static void drawLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) { g2d.drawLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   public static void drawHLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, int paramInt3) { g2d.drawHLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramInt1, paramInt2, paramInt3); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  129 */   public static void drawVLine(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt1, int paramInt2, int paramInt3) { g2d.drawVLine(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramInt1, paramInt2, paramInt3); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  140 */   public static void fillRect(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) { g2d.fillRect(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  148 */   public static void fillArc(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, Object paramObject) { g2d.fillArc(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramObject); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  157 */   public static void fill(Graphics paramGraphics, Shape paramShape, Object paramObject) { g2d.fill(paramGraphics, paramShape, paramObject); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  166 */   public static void setClip(Graphics paramGraphics, Bounds paramBounds) { g2d.setClip(paramGraphics, paramBounds); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  175 */   public static void clipRect(Graphics paramGraphics, Bounds paramBounds) { g2d.clipRect(paramGraphics, paramBounds); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  190 */   public static void drawImage(Graphics paramGraphics, Image paramImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, ImageObserver paramImageObserver) { g2d.drawImage(paramGraphics, paramImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramImageObserver); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  197 */   public static void rotate(Graphics paramGraphics, double paramDouble) { g2d.rotate(paramGraphics, paramDouble); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  204 */   public static void paintPage(Graphics paramGraphics, PreviewPage paramPreviewPage) { g2d.paintPage(paramGraphics, paramPreviewPage); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  214 */   public static Image createImage(byte[] paramArrayOfByte, int paramInt1, int paramInt2) { return g2d.createImage(paramArrayOfByte, paramInt1, paramInt2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  237 */   public static void paint(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Painter paramPainter, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, Color paramColor1, Color paramColor2) { g2d.paint(paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramPainter, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramColor1, paramColor2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  246 */   public static Object getPaint(int paramInt) { return g2d.getPaint(paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  258 */   public static float getHeight(Font paramFont, FontMetrics paramFontMetrics) { return g2d.getHeight(paramFont, paramFontMetrics); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  267 */   public static float getAscent(FontMetrics paramFontMetrics) { return g2d.getAscent(paramFontMetrics); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  276 */   public static float getAscent(Font paramFont) { return g2d.getAscent(getFontMetrics(paramFont)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  284 */   public static String[] getAllFonts() { return g2d.getAllFonts(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  291 */   public static String getFontName(Font paramFont) { return g2d.getFontName(paramFont); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  298 */   public static String getPSName(Font paramFont) { return g2d.getPSName(paramFont); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  306 */   public static void paintRotate(Painter paramPainter, Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) { g2d.paintRotate(paramPainter, paramGraphics, paramFloat1, paramFloat2, paramFloat3, paramFloat4); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  313 */   public static void startPage(Graphics paramGraphics, StylePage paramStylePage) { g2d.startPage(paramGraphics, paramStylePage); }
/*      */ 
/*      */   
/*  316 */   private static Frame root = null;
/*      */   public static Frame getInvisibleFrame() {
/*  318 */     if (root == null) {
/*  319 */       root = new Frame("invisible");
/*  320 */       root.pack();
/*      */     } 
/*      */     
/*  323 */     return root;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  332 */   public static Image createImage(int paramInt1, int paramInt2) { return g2d.createImage(paramInt1, paramInt2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  343 */   public static float stringWidth(String paramString, Font paramFont) { return stringWidth(paramString, paramFont, getFontMetrics(paramFont)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float stringWidth(String paramString, Font paramFont, FontMetrics paramFontMetrics) {
/*  355 */     if (paramString == null || paramString.length() == 0) {
/*  356 */       return 0.0F;
/*      */     }
/*      */     
/*  359 */     if (paramFont instanceof StyleFont) {
/*  360 */       StyleFont styleFont = (StyleFont)paramFont;
/*  361 */       int i = styleFont.getStyle();
/*      */       
/*  363 */       if ((i & 0x40) != 0 || (i & 0x80) != 0) {
/*      */         
/*  365 */         paramFont = styleFont = new StyleFont(styleFont.getName(), i, styleFont.getSize() * 2 / 3);
/*  366 */         paramFontMetrics = getFontMetrics(styleFont);
/*      */       } 
/*      */       
/*  369 */       if ((i & 0x200) != 0) {
/*  370 */         Font font = new Font(styleFont.getName(), styleFont.getStyle(), styleFont.getSize() - 2);
/*      */         
/*  372 */         FontMetrics fontMetrics = getFontMetrics(font);
/*  373 */         int j = 0;
/*      */         
/*  375 */         for (byte b = 0; b < paramString.length(); b++) {
/*  376 */           char c = paramString.charAt(b);
/*  377 */           if (Character.isLowerCase(c)) {
/*  378 */             j += fontMetrics.charWidth(Character.toUpperCase(c));
/*      */           } else {
/*      */             
/*  381 */             j += paramFontMetrics.charWidth(c);
/*      */           } 
/*      */         } 
/*      */         
/*  385 */         return j;
/*      */       } 
/*  387 */       if ((i & 0x400) != 0) {
/*  388 */         return g2d.stringWidth(paramString.toUpperCase(), paramFont, paramFontMetrics);
/*      */       }
/*      */     } 
/*      */     
/*  392 */     return g2d.stringWidth(paramString, paramFont, paramFontMetrics);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void drawString(Graphics paramGraphics, String paramString, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  406 */     if (paramString == null || paramString.length() == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  411 */     if (paramString.indexOf(' ') < 0) {
/*  412 */       drawString(paramGraphics, paramString, paramFloat1, paramFloat2);
/*      */       
/*      */       return;
/*      */     } 
/*  416 */     Font font = paramGraphics.getFont();
/*  417 */     FontMetrics fontMetrics = paramGraphics.getFontMetrics();
/*  418 */     int i = 0;
/*  419 */     int j = 0;
/*      */     
/*  421 */     if (font instanceof StyleFont && (((StyleFont)font).getStyle() & 0x10) != 0)
/*      */     {
/*  423 */       j = ((StyleFont)font).getLineStyle();
/*      */     }
/*      */     
/*  426 */     String[] arrayOfString = Util.split(paramString, ' ');
/*  427 */     float[] arrayOfFloat = new float[arrayOfString.length];
/*      */     
/*  429 */     for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/*  430 */       arrayOfFloat[b1] = stringWidth(arrayOfString[b1], font, fontMetrics);
/*  431 */       i = (int)(i + arrayOfFloat[b1]);
/*      */     } 
/*      */ 
/*      */     
/*  435 */     double d1 = (paramFloat3 - i) / (arrayOfString.length - 1.0D);
/*  436 */     double d2 = paramFloat1;
/*      */     
/*  438 */     for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
/*  439 */       drawString(paramGraphics, arrayOfString[b2], (float)d2, paramFloat2);
/*  440 */       d2 += arrayOfFloat[b2];
/*      */ 
/*      */       
/*  443 */       if (j != 0 && b2 < arrayOfString.length - 1) {
/*  444 */         float f = paramFloat2 + fontMetrics.getDescent() - 1.0F;
/*  445 */         drawHLine(paramGraphics, f, (float)d2, (float)(d2 + d1), j, 0, 0);
/*      */       } 
/*      */       
/*  448 */       d2 += d1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void drawString(Graphics paramGraphics, String paramString, float paramFloat1, float paramFloat2) {
/*  462 */     if (paramString == null || paramString.length() == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  466 */     if (paramGraphics.getFont() instanceof StyleFont) {
/*  467 */       StyleFont styleFont = (StyleFont)paramGraphics.getFont();
/*  468 */       FontMetrics fontMetrics = getFontMetrics(styleFont);
/*  469 */       int i = styleFont.getStyle();
/*      */       
/*  471 */       if ((i & 0x40) != 0) {
/*  472 */         paramFloat2 -= getAscent(fontMetrics) / 3.0F;
/*  473 */         styleFont = new StyleFont(styleFont.getName(), i, styleFont.getSize() * 2 / 3);
/*  474 */         fontMetrics = getFontMetrics(styleFont);
/*  475 */         paramGraphics.setFont(styleFont);
/*      */       }
/*  477 */       else if ((i & 0x80) != 0) {
/*  478 */         paramFloat2 += (fontMetrics.getDescent() / 3);
/*  479 */         styleFont = new StyleFont(styleFont.getName(), i, styleFont.getSize() * 2 / 3);
/*  480 */         fontMetrics = getFontMetrics(styleFont);
/*  481 */         paramGraphics.setFont(styleFont);
/*      */       } 
/*      */       
/*  484 */       drawStringCase(paramGraphics, paramString, paramFloat1, paramFloat2);
/*      */       
/*  486 */       if ((i & 0x20) != 0) {
/*  487 */         float f = paramFloat2 - getAscent(fontMetrics) + getHeight(styleFont, fontMetrics) / 2.0F - getLineWidth(styleFont.getLineStyle()) / 2.0F;
/*      */         
/*  489 */         drawHLine(paramGraphics, f, paramFloat1, paramFloat1 + stringWidth(paramString, styleFont), styleFont.getLineStyle(), 0, 0);
/*      */       } 
/*      */ 
/*      */       
/*  493 */       if ((i & 0x10) != 0) {
/*  494 */         float f = paramFloat2 + fontMetrics.getDescent() - 1.0F;
/*  495 */         drawHLine(paramGraphics, f, paramFloat1, paramFloat1 + stringWidth(paramString, styleFont), styleFont.getLineStyle(), 0, 0);
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  500 */       g2d.drawString(paramGraphics, paramString, paramFloat1, paramFloat2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void drawStringCase(Graphics paramGraphics, String paramString, float paramFloat1, float paramFloat2) {
/*  513 */     StyleFont styleFont = (StyleFont)paramGraphics.getFont();
/*  514 */     int i = styleFont.getStyle();
/*      */     
/*  516 */     if ((i & 0x200) != 0) {
/*  517 */       FontMetrics fontMetrics1 = getFontMetrics(styleFont);
/*  518 */       Font font = new Font(styleFont.getName(), styleFont.getStyle(), styleFont.getSize() - 2);
/*      */       
/*  520 */       FontMetrics fontMetrics2 = getFontMetrics(font);
/*      */       
/*  522 */       for (byte b = 0; b < paramString.length(); b++) {
/*  523 */         char c = paramString.charAt(b);
/*  524 */         if (Character.isLowerCase(c)) {
/*  525 */           c = Character.toUpperCase(c);
/*  526 */           paramGraphics.setFont(font);
/*      */           
/*  528 */           if ((i & 0x100) != 0) {
/*  529 */             Color color = paramGraphics.getColor();
/*  530 */             paramGraphics.setColor(Util.brighter(color));
/*  531 */             g2d.drawString(paramGraphics, "" + c, paramFloat1 + 1.0F, paramFloat2 + 1.0F);
/*  532 */             paramGraphics.setColor(color);
/*      */           } 
/*      */           
/*  535 */           g2d.drawString(paramGraphics, "" + c, paramFloat1, paramFloat2);
/*  536 */           paramFloat1 += fontMetrics2.charWidth(c);
/*      */         } else {
/*      */           
/*  539 */           paramGraphics.setFont(styleFont);
/*      */           
/*  541 */           if ((i & 0x100) != 0) {
/*  542 */             Color color = paramGraphics.getColor();
/*  543 */             paramGraphics.setColor(Util.brighter(color));
/*  544 */             g2d.drawString(paramGraphics, "" + c, paramFloat1 + 1.0F, paramFloat2 + 1.0F);
/*  545 */             paramGraphics.setColor(color);
/*      */           } 
/*      */           
/*  548 */           g2d.drawString(paramGraphics, "" + c, paramFloat1, paramFloat2);
/*  549 */           paramFloat1 += fontMetrics1.charWidth(c);
/*      */         } 
/*      */       } 
/*      */       
/*  553 */       paramGraphics.setFont(styleFont);
/*      */     } else {
/*      */       
/*  556 */       if ((i & 0x400) != 0) {
/*  557 */         paramString = paramString.toUpperCase();
/*      */       }
/*      */       
/*  560 */       if ((i & 0x100) != 0) {
/*  561 */         Color color = paramGraphics.getColor();
/*  562 */         paramGraphics.setColor(Util.brighter(color));
/*  563 */         g2d.drawString(paramGraphics, paramString, paramFloat1 + 1.0F, paramFloat2 + 1.0F);
/*  564 */         paramGraphics.setColor(color);
/*      */       } 
/*      */       
/*  567 */       g2d.drawString(paramGraphics, paramString, paramFloat1, paramFloat2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  578 */   public static int compare(Object paramObject1, Object paramObject2) { return g2d.compare(paramObject1, paramObject2); }
/*      */ 
/*      */   
/*  581 */   static Font lastFn = null;
/*  582 */   static FontMetrics lastFm = null;
/*  583 */   static Hashtable fmcache = new Hashtable();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FontMetrics getFontMetrics(Font paramFont) {
/*  593 */     if (paramFont == lastFn) {
/*  594 */       return lastFm;
/*      */     }
/*      */     
/*  597 */     FontMetrics fontMetrics = (FontMetrics)fmcache.get(paramFont);
/*  598 */     if (fontMetrics == null) {
/*  599 */       if (ReportEnv.getProperty("font.metrics.source", "awt").equals("awt")) {
/*  600 */         fontMetrics = getToolkit().getFontMetrics(paramFont);
/*      */       } else {
/*      */         
/*  603 */         fontMetrics = FontManager.getFontManager().getFontMetrics(paramFont);
/*      */       } 
/*      */       
/*  606 */       fmcache.put(paramFont, fontMetrics);
/*      */     } 
/*      */     
/*  609 */     lastFn = paramFont;
/*  610 */     lastFm = fontMetrics;
/*      */     
/*  612 */     return fontMetrics;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  620 */   public static PreviewView getPreviewView() { return g2d.getPreviewView(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  627 */   public static void writeJPEG(Image paramImage, OutputStream paramOutputStream) { g2d.writeJPEG(paramImage, paramOutputStream); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void paintText(Graphics paramGraphics, String paramString, Bounds paramBounds, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2) {
/*  645 */     Bounds bounds = new Bounds();
/*  646 */     Vector vector1 = new Vector();
/*  647 */     Vector vector2 = processText(paramString, paramBounds, paramInt1, paramBoolean1, paramGraphics.getFont(), bounds, vector1, paramInt2);
/*      */ 
/*      */     
/*  650 */     paintText(paramGraphics, paramString, vector2, paramBounds, bounds, paramBoolean2, vector1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void paintText(Graphics paramGraphics, String paramString, Vector paramVector1, Bounds paramBounds1, Bounds paramBounds2, boolean paramBoolean, Vector paramVector2, int paramInt) {
/*  666 */     Shape shape = paramGraphics.getClip();
/*  667 */     clipRect(paramGraphics, new Bounds(paramBounds1.x, paramBounds1.y, paramBounds1.width, paramBounds1.height));
/*  668 */     Font font = paramGraphics.getFont();
/*  669 */     FontMetrics fontMetrics = getFontMetrics(font);
/*      */ 
/*      */     
/*  672 */     float f = paramBounds2.y + getAscent(fontMetrics);
/*  673 */     for (byte b = 0; b < paramVector1.size(); b++) {
/*  674 */       float f1 = paramBounds2.x;
/*      */       
/*  676 */       if (paramVector2 != null && b < paramVector2.size()) {
/*  677 */         f1 += ((Float)paramVector2.elementAt(b)).floatValue();
/*      */       }
/*      */       
/*  680 */       int[] arrayOfInt = (int[])paramVector1.elementAt(b);
/*  681 */       String str = paramString.substring(arrayOfInt[0], arrayOfInt[1]);
/*      */       
/*  683 */       if (paramBoolean && b < paramVector1.size() - 1) {
/*  684 */         drawString(paramGraphics, str, f1, f, paramBounds2.width);
/*      */       }
/*  686 */       else if (str.indexOf(' ') >= 0) {
/*      */ 
/*      */ 
/*      */         
/*  690 */         if (font.getSize() > 14) {
/*  691 */           drawString(paramGraphics, str, f1, f);
/*      */         } else {
/*      */           
/*  694 */           drawString(paramGraphics, str, f1, f, stringWidth(str, paramGraphics.getFont(), fontMetrics));
/*      */         } 
/*      */       } else {
/*      */         
/*  698 */         drawString(paramGraphics, str, f1, f);
/*      */       } 
/*      */ 
/*      */       
/*  702 */       f += getHeight(paramGraphics.getFont(), fontMetrics) + paramInt;
/*      */     } 
/*      */     
/*  705 */     paramGraphics.setClip(shape);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Vector processText(String paramString, Bounds paramBounds1, int paramInt1, boolean paramBoolean, Font paramFont, Bounds paramBounds2, Vector paramVector, int paramInt2) {
/*  722 */     Vector vector = new Vector();
/*  723 */     paramVector.removeAllElements();
/*      */     
/*  725 */     if (paramBounds1.width <= 0.0F || paramBounds1.height <= 0.0F) {
/*  726 */       return vector;
/*      */     }
/*      */     
/*  729 */     Size size = new Size();
/*  730 */     FontMetrics fontMetrics = getFontMetrics(paramFont);
/*  731 */     int i = 0;
/*      */ 
/*      */     
/*  734 */     while (paramString != null) {
/*  735 */       int j = paramString.indexOf('\n');
/*      */       
/*  737 */       if (paramBoolean) {
/*  738 */         int k = Math.max(fontMetrics.charWidth('.'), 4);
/*  739 */         int m = (j >= 0) ? j : Math.min(paramString.length(), (int)(paramBounds1.width / k * 0.5D));
/*      */         
/*  741 */         String str = paramString.substring(0, m);
/*  742 */         boolean bool = true;
/*      */ 
/*      */         
/*  745 */         if (stringWidth(str, paramFont) > paramBounds1.width) {
/*      */           
/*  747 */           int i1 = Math.max(1, m) - 1;
/*  748 */           str = paramString.substring(0, i1);
/*  749 */           while (i1 > 0 && stringWidth(str, paramFont) > paramBounds1.width) {
/*  750 */             str = paramString.substring(0, --i1);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  755 */           m = i1;
/*  756 */           while (m > 0 && !Character.isWhitespace(paramString.charAt(m))) {
/*  757 */             m--;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  762 */           if (m <= 0) {
/*  763 */             m = i1;
/*  764 */             bool = false;
/*      */           } 
/*      */           
/*  767 */           str = paramString.substring(0, m);
/*      */         } 
/*      */         
/*  770 */         str = Util.trimEnd(str);
/*  771 */         vector.addElement(new int[] { i, i + str.length() });
/*  772 */         float f1 = stringWidth(str, paramFont, fontMetrics);
/*  773 */         paramVector.addElement(new Float(f1));
/*  774 */         size.width = Math.max(size.width, f1);
/*      */         
/*  776 */         if (m >= paramString.length()) {
/*      */           break;
/*      */         }
/*      */         
/*  780 */         int n = bool ? (m + 1) : Math.max(m, 1);
/*  781 */         i += n;
/*  782 */         paramString = paramString.substring(n); continue;
/*      */       } 
/*  784 */       if (j >= 0) {
/*  785 */         String str = Util.trimEnd(paramString.substring(0, j));
/*  786 */         float f1 = stringWidth(str, paramFont, fontMetrics);
/*  787 */         paramVector.addElement(new Float(f1));
/*  788 */         size.width = Math.max(size.width, f1);
/*  789 */         paramString = paramString.substring(j + 1);
/*  790 */         vector.addElement(new int[] { i, i + str.length() });
/*  791 */         i += j + 1;
/*      */         continue;
/*      */       } 
/*  794 */       paramString = Util.trimEnd(paramString);
/*  795 */       float f = stringWidth(paramString, paramFont, fontMetrics);
/*  796 */       paramVector.addElement(new Float(f));
/*  797 */       size.width = Math.max(size.width, f);
/*  798 */       vector.addElement(new int[] { i, i + paramString.length() });
/*      */       
/*      */       break;
/*      */     } 
/*  802 */     size.height = (getHeight(fontMetrics.getFont(), fontMetrics) + paramInt2) * vector.size();
/*      */ 
/*      */     
/*  805 */     Bounds bounds = alignCell(paramBounds1, size, paramInt1);
/*      */ 
/*      */     
/*  808 */     paramBounds2.x = bounds.x;
/*  809 */     bounds.y += Math.max((bounds.height - size.height) / 2.0F, 0.0F);
/*  810 */     paramBounds2.width = bounds.width;
/*  811 */     paramBounds2.height = Math.min(size.height, paramBounds1.y + paramBounds1.height - paramBounds2.y);
/*      */ 
/*      */     
/*  814 */     for (byte b = 0; b < paramVector.size(); b++) {
/*  815 */       float f = ((Float)paramVector.elementAt(b)).floatValue();
/*      */       
/*  817 */       if ((paramInt1 & 0x2) != 0) {
/*  818 */         paramVector.setElementAt(new Float((bounds.width - f) / 2.0F), b);
/*      */       }
/*  820 */       else if ((paramInt1 & 0x4) != 0) {
/*  821 */         paramVector.setElementAt(new Float(bounds.width - f), b);
/*      */       } else {
/*      */         
/*  824 */         paramVector.setElementAt(new Float(0.0F), b);
/*      */       } 
/*      */     } 
/*      */     
/*  828 */     return vector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Bounds alignCell(Bounds paramBounds, Size paramSize, int paramInt) {
/*  842 */     Bounds bounds = new Bounds(paramBounds.x, paramBounds.y, paramBounds.width, paramBounds.height);
/*      */     
/*  844 */     if (paramSize.width < bounds.width) {
/*  845 */       if ((paramInt & 0x2) != 0) {
/*  846 */         bounds.x += (bounds.width - paramSize.width) / 2.0F;
/*  847 */         bounds.width = paramSize.width;
/*      */       }
/*  849 */       else if ((paramInt & 0x4) != 0) {
/*      */         
/*  851 */         bounds.x += bounds.width - paramSize.width - 1.0F;
/*  852 */         bounds.width = paramSize.width;
/*      */       }
/*  854 */       else if ((paramInt & true) != 0) {
/*  855 */         bounds.width = paramSize.width;
/*      */       } 
/*      */     }
/*      */     
/*  859 */     if (paramSize.height < bounds.height) {
/*  860 */       if ((paramInt & 0x10) != 0) {
/*  861 */         bounds.y += (bounds.height - paramSize.height) / 2.0F;
/*  862 */         bounds.height = paramSize.height;
/*      */       }
/*  864 */       else if ((paramInt & 0x20) != 0) {
/*  865 */         bounds.y += bounds.height - paramSize.height - 1.0F;
/*  866 */         bounds.height = paramSize.height;
/*      */       }
/*  868 */       else if ((paramInt & 0x8) != 0) {
/*  869 */         bounds.height = paramSize.height;
/*      */       } 
/*      */     }
/*      */     
/*  873 */     return bounds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void drawRect(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt) {
/*  887 */     float f1 = getLineAdjustment(paramGraphics);
/*  888 */     float f2 = getLineWidth(paramInt);
/*  889 */     paramFloat3 -= f2; paramFloat4 -= f2;
/*      */     
/*  891 */     drawHLine(paramGraphics, paramFloat2 + f1, paramFloat1, paramFloat1 + paramFloat3, paramInt, 0, paramInt);
/*  892 */     drawHLine(paramGraphics, paramFloat2 + paramFloat4 + f1, paramFloat1, paramFloat1 + paramFloat3, paramInt, paramInt, 0);
/*  893 */     drawVLine(paramGraphics, paramFloat1 + f1, paramFloat2, paramFloat2 + paramFloat4, paramInt, 0, paramInt);
/*  894 */     drawVLine(paramGraphics, paramFloat1 + paramFloat3 + f1, paramFloat2, paramFloat2 + paramFloat4, paramInt, paramInt, 0);
/*      */ 
/*      */     
/*  897 */     drawVLine(paramGraphics, paramFloat1 + f1, paramFloat2 + paramFloat4, paramFloat2 + paramFloat4 + f2 - 1.0F, paramInt, 0, paramInt);
/*      */     
/*  899 */     drawHLine(paramGraphics, paramFloat2 + f1, paramFloat1 + paramFloat3, paramFloat1 + paramFloat3 + f2 - 1.0F, paramInt, 0, paramInt);
/*      */     
/*  901 */     drawVLine(paramGraphics, paramFloat1 + paramFloat3 + f1, paramFloat2 + paramFloat4, paramFloat2 + paramFloat4 + f2 - 1.0F, paramInt, paramInt, 0);
/*  902 */     drawHLine(paramGraphics, paramFloat2 + paramFloat4 + f1, paramFloat1 + paramFloat3, paramFloat1 + paramFloat3 + f2 - 1.0F, paramInt, paramInt, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void drawRect(Graphics paramGraphics, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  920 */     float f1 = getLineAdjustment(paramGraphics);
/*  921 */     float f2 = getLineWidth(paramInt3);
/*  922 */     float f3 = getLineWidth(paramInt4);
/*  923 */     paramFloat3 -= f3; paramFloat4 -= f2;
/*      */     
/*  925 */     drawHLine(paramGraphics, paramFloat2 + f1, paramFloat1, paramFloat1 + paramFloat3, paramInt1, 0, paramInt2);
/*  926 */     drawHLine(paramGraphics, paramFloat2 + paramFloat4 + f1, paramFloat1, paramFloat1 + paramFloat3, paramInt3, paramInt2, 0);
/*  927 */     drawVLine(paramGraphics, paramFloat1 + f1, paramFloat2, paramFloat2 + paramFloat4, paramInt2, 0, paramInt1);
/*  928 */     drawVLine(paramGraphics, paramFloat1 + paramFloat3 + f1, paramFloat2, paramFloat2 + paramFloat4, paramInt4, paramInt1, 0);
/*      */ 
/*      */     
/*  931 */     drawVLine(paramGraphics, paramFloat1 + f1, paramFloat2 + paramFloat4, paramFloat2 + paramFloat4 + f2 - 1.0F, paramInt2, 0, paramInt3);
/*      */     
/*  933 */     drawHLine(paramGraphics, paramFloat2 + f1, paramFloat1 + paramFloat3, paramFloat1 + paramFloat3 + f3 - 1.0F, paramInt1, 0, paramInt4);
/*      */     
/*  935 */     drawVLine(paramGraphics, paramFloat1 + paramFloat3 + f1, paramFloat2 + paramFloat4, paramFloat2 + paramFloat4 + f2, paramInt4, paramInt3, 0);
/*  936 */     drawHLine(paramGraphics, paramFloat2 + paramFloat4 + f1, paramFloat1 + paramFloat3, paramFloat1 + paramFloat3 + f3, paramInt3, paramInt4, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void drawRect(StylePage paramStylePage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, Color paramColor) {
/*  951 */     paramStylePage.addPaintable(new BasePaintable(paramColor, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt, null) { private final Color val$color; private final float val$x; private final float val$y;
/*      */           public void paint(Graphics param1Graphics) {
/*  953 */             Color color = param1Graphics.getColor();
/*  954 */             if (this.val$color != null) {
/*  955 */               param1Graphics.setColor(this.val$color);
/*      */             }
/*      */             
/*  958 */             Common.drawRect(param1Graphics, this.val$x, this.val$y, this.val$w, this.val$h, this.val$style);
/*  959 */             param1Graphics.setColor(color);
/*      */           }
/*      */           private final float val$w; private final float val$h; private final int val$style;
/*      */           
/*  963 */           public Rectangle getBounds() { return new Rectangle(Common.round(this.val$x), Common.round(this.val$y), Common.round(this.val$w), Common.round(this.val$h)); }
/*      */ 
/*      */ 
/*      */           
/*      */           public void setLocation(Point param1Point) {}
/*      */ 
/*      */ 
/*      */           
/*  971 */           public ReportElement getElement() { return null; } }
/*      */       );
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  982 */   public static Color getColor(int paramInt) { return colors[paramInt % colors.length]; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Image getImage(Object paramObject, String paramString) {
/*  989 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*  990 */     InputStream inputStream = ((paramObject == null) ? Common.class : ((paramObject instanceof Class) ? (Class)paramObject : paramObject.getClass())).getResourceAsStream(paramString);
/*      */ 
/*      */     
/*  993 */     if (inputStream == null) {
/*  994 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  999 */       byte[] arrayOfByte = new byte[4096];
/*      */       int i;
/* 1001 */       while ((i = inputStream.read(arrayOfByte)) >= 0) {
/* 1002 */         byteArrayOutputStream.write(arrayOfByte, 0, i);
/*      */       }
/*      */       
/* 1005 */       return getToolkit().createImage(byteArrayOutputStream.toByteArray());
/*      */     } catch (Exception exception) {
/* 1007 */       exception.printStackTrace();
/*      */ 
/*      */       
/* 1010 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1017 */   public static int round(double paramDouble) { return (int)Math.ceil(paramDouble); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Toolkit getToolkit() {
/* 1024 */     if (toolkit == null) {
/* 1025 */       toolkit = Toolkit.getDefaultToolkit();
/*      */     }
/*      */     
/* 1028 */     return toolkit;
/*      */   }
/*      */   
/*      */   public static void waitForImage(Image paramImage) {
/* 1032 */     tracker.addImage(paramImage, 0); 
/* 1033 */     try { tracker.waitForAll(); } catch (Exception exception) {}
/* 1034 */     tracker.removeImage(paramImage);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float getLineWidth(int paramInt) {
/* 1041 */     if (paramInt == -1) {
/* 1042 */       return 0.0F;
/*      */     }
/*      */     
/* 1045 */     return g2d.getLineWidth(paramInt);
/*      */   }
/*      */   
/* 1048 */   private static Toolkit toolkit = null;
/* 1049 */   private static Gop g2d = Gop.getInstance();
/* 1050 */   private static final Component component = new Component() {  }
/* 1051 */   ; private static final MediaTracker tracker = new MediaTracker(component);
/*      */   private static final Color[] colors = { 
/* 1053 */       Color.green, Color.red, Color.yellow, Color.magenta, Color.orange, Color.cyan, Color.blue, Color.gray, Color.pink, Color.darkGray, new Color(150, 0, 150), new Color(25, 80, 150), new Color(150, 80, 25), new Color(126, 0, 0), new Color(0, 126, 0), new Color(0, 0, 126), new Color(240, 80, 240), new Color(80, 240, 80), new Color(50, 100, 150), new Color(100, 150, 200), new Color(150, 200, 250), new Color(150, 100, 50), new Color(200, 150, 100), new Color(250, 200, 150), new Color(60, 75, 60), new Color(90, 75, 45), new Color(128, 0, 64), new Color(64, 0, 128), new Color(70, 20, 38), new Color(100, 100, 30) };
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Common.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */