package inetsoft.report;

import java.awt.Image;
import java.io.Serializable;
import java.text.NumberFormat;

public class ChartDescriptor implements Serializable, Cloneable {
  public void setValueFormat(NumberFormat paramNumberFormat) { this.valueFmt = paramNumberFormat; }
  
  public NumberFormat getValueFormat() { return this.valueFmt; }
  
  public void setSecondaryYAxisFormat(NumberFormat paramNumberFormat) { this.yFmt2 = paramNumberFormat; }
  
  public NumberFormat getSecondaryYAxisFormat() { return this.yFmt2; }
  
  public void setYAxisFormat(NumberFormat paramNumberFormat) { this.yFmt = paramNumberFormat; }
  
  public NumberFormat getYAxisFormat() { return this.yFmt; }
  
  public void setLineChartLineWidth(float paramFloat) { this.lineW = paramFloat; }
  
  public float getLineChartLineWidth() { return this.lineW; }
  
  public void setPointSize(float paramFloat) { this.pointW = paramFloat; }
  
  public float getPointSize() { return this.pointW; }
  
  public void setPointStyle(int paramInt1, int paramInt2) { this.pstyles[paramInt1 % this.pstyles.length] = paramInt2; }
  
  public int getPointStyle(int paramInt) { return this.pstyles[paramInt % this.pstyles.length]; }
  
  public void setXLabelRotation(double paramDouble) { this.xangle = paramDouble; }
  
  public double getXLabelRotation() { return this.xangle; }
  
  public void setBarBorder(boolean paramBoolean) { this.barBorder = paramBoolean; }
  
  public boolean isBarBorder() { return this.barBorder; }
  
  public void setFirstDatasetOfSecondaryAxis(int paramInt) { this.secondary = paramInt; }
  
  public int getFirstDatasetOfSecondaryAxis() { return this.secondary; }
  
  public int getVerticalGridStyle() { return this.vgrid; }
  
  public void setVerticalGridStyle(int paramInt) { this.vgrid = paramInt; }
  
  public boolean isLogarithmicYScale() { return this.logY; }
  
  public void setLogarithmicYScale(boolean paramBoolean) { this.logY = paramBoolean; }
  
  public boolean isSecondaryLogarithmicYScale() { return this.logY2; }
  
  public void setSecondaryLogarithmicYScale(boolean paramBoolean) { this.logY2 = paramBoolean; }
  
  public Number getSecondaryMaximum() { return this.max; }
  
  public void setSecondaryMaximum(Number paramNumber) { this.max = paramNumber; }
  
  public Number getSecondaryMinimum() { return this.min; }
  
  public void setSecondaryMinimum(Number paramNumber) { this.min = paramNumber; }
  
  public Number getSecondaryIncrement() { return this.incr; }
  
  public void setSecondaryIncrement(Number paramNumber) { this.incr = paramNumber; }
  
  public Number getSecondaryMinorIncrement() { return this.mincr; }
  
  public void setSecondaryMinorIncrement(Number paramNumber) { this.mincr = paramNumber; }
  
  public String getSecondaryYTitle() { return this.ytitle; }
  
  public void setSecondaryYTitle(String paramString) { this.ytitle = paramString; }
  
  public Number getXMaximum() { return this.xmax; }
  
  public void setXMaximum(Number paramNumber) { this.xmax = paramNumber; }
  
  public Number getXMinimum() { return this.xmin; }
  
  public void setXMinimum(Number paramNumber) { this.xmin = paramNumber; }
  
  public Number getXIncrement() { return this.xincr; }
  
  public void setXIncrement(Number paramNumber) { this.xincr = paramNumber; }
  
  public Number getXMinorIncrement() { return this.xmincr; }
  
  public void setXMinorIncrement(Number paramNumber) { this.xmincr = paramNumber; }
  
  public boolean isLogarithmicXScale() { return this.logX; }
  
  public void setLogarithmicXScale(boolean paramBoolean) { this.logX = paramBoolean; }
  
  public void setXAxisFormat(NumberFormat paramNumberFormat) { this.xFmt = paramNumberFormat; }
  
  public NumberFormat getXAxisFormat() { return this.xFmt; }
  
  public void setBackgroundImage(Image paramImage) { this.bgImage = paramImage; }
  
  public Image getBackgroundImage() { return this.bgImage; }
  
  public Object clone() {
    try {
      return super.clone();
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      return null;
    } 
  }
  
  NumberFormat valueFmt = null;
  
  NumberFormat yFmt = null;
  
  NumberFormat yFmt2 = null;
  
  NumberFormat xFmt = null;
  
  float lineW = 1.0F;
  
  float pointW = 6.0F;
  
  double xangle = 0.0D;
  
  boolean barBorder = false;
  
  int secondary = -1;
  
  int vgrid = 0;
  
  boolean logY = false;
  
  boolean logY2 = false;
  
  Number min = null, max = null;
  
  Number mincr = null;
  
  Number incr = null;
  
  String ytitle = null;
  
  Image bgImage = null;
  
  int[] pstyles = { 
      908, 904, 907, 902, 906, 910, 900, 901, 905, 909, 
      903 };
  
  boolean logX = false;
  
  Number xmin = null, xmax = null;
  
  Number xmincr = null, xincr = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\ChartDescriptor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */