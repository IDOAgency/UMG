/*     */ package inetsoft.report;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.io.Serializable;
/*     */ import java.text.NumberFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChartDescriptor
/*     */   implements Serializable, Cloneable
/*     */ {
/*  31 */   public void setValueFormat(NumberFormat paramNumberFormat) { this.valueFmt = paramNumberFormat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   public NumberFormat getValueFormat() { return this.valueFmt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public void setSecondaryYAxisFormat(NumberFormat paramNumberFormat) { this.yFmt2 = paramNumberFormat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public NumberFormat getSecondaryYAxisFormat() { return this.yFmt2; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public void setYAxisFormat(NumberFormat paramNumberFormat) { this.yFmt = paramNumberFormat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public NumberFormat getYAxisFormat() { return this.yFmt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public void setLineChartLineWidth(float paramFloat) { this.lineW = paramFloat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public float getLineChartLineWidth() { return this.lineW; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public void setPointSize(float paramFloat) { this.pointW = paramFloat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public float getPointSize() { return this.pointW; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void setPointStyle(int paramInt1, int paramInt2) { this.pstyles[paramInt1 % this.pstyles.length] = paramInt2; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public int getPointStyle(int paramInt) { return this.pstyles[paramInt % this.pstyles.length]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public void setXLabelRotation(double paramDouble) { this.xangle = paramDouble; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public double getXLabelRotation() { return this.xangle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public void setBarBorder(boolean paramBoolean) { this.barBorder = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public boolean isBarBorder() { return this.barBorder; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public void setFirstDatasetOfSecondaryAxis(int paramInt) { this.secondary = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public int getFirstDatasetOfSecondaryAxis() { return this.secondary; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public int getVerticalGridStyle() { return this.vgrid; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public void setVerticalGridStyle(int paramInt) { this.vgrid = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 190 */   public boolean isLogarithmicYScale() { return this.logY; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   public void setLogarithmicYScale(boolean paramBoolean) { this.logY = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 206 */   public boolean isSecondaryLogarithmicYScale() { return this.logY2; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 214 */   public void setSecondaryLogarithmicYScale(boolean paramBoolean) { this.logY2 = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 223 */   public Number getSecondaryMaximum() { return this.max; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public void setSecondaryMaximum(Number paramNumber) { this.max = paramNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 240 */   public Number getSecondaryMinimum() { return this.min; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   public void setSecondaryMinimum(Number paramNumber) { this.min = paramNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 256 */   public Number getSecondaryIncrement() { return this.incr; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 264 */   public void setSecondaryIncrement(Number paramNumber) { this.incr = paramNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 273 */   public Number getSecondaryMinorIncrement() { return this.mincr; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 281 */   public void setSecondaryMinorIncrement(Number paramNumber) { this.mincr = paramNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 289 */   public String getSecondaryYTitle() { return this.ytitle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 297 */   public void setSecondaryYTitle(String paramString) { this.ytitle = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 306 */   public Number getXMaximum() { return this.xmax; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 314 */   public void setXMaximum(Number paramNumber) { this.xmax = paramNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 323 */   public Number getXMinimum() { return this.xmin; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 331 */   public void setXMinimum(Number paramNumber) { this.xmin = paramNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 340 */   public Number getXIncrement() { return this.xincr; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 348 */   public void setXIncrement(Number paramNumber) { this.xincr = paramNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 357 */   public Number getXMinorIncrement() { return this.xmincr; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 365 */   public void setXMinorIncrement(Number paramNumber) { this.xmincr = paramNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 373 */   public boolean isLogarithmicXScale() { return this.logX; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 381 */   public void setLogarithmicXScale(boolean paramBoolean) { this.logX = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 388 */   public void setXAxisFormat(NumberFormat paramNumberFormat) { this.xFmt = paramNumberFormat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 395 */   public NumberFormat getXAxisFormat() { return this.xFmt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 402 */   public void setBackgroundImage(Image paramImage) { this.bgImage = paramImage; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 409 */   public Image getBackgroundImage() { return this.bgImage; }
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 414 */       return super.clone();
/* 415 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */ 
/*     */       
/* 418 */       return null;
/*     */     } 
/*     */   }
/* 421 */   NumberFormat valueFmt = null;
/* 422 */   NumberFormat yFmt = null; NumberFormat yFmt2 = null; NumberFormat xFmt = null;
/* 423 */   float lineW = 1.0F;
/* 424 */   float pointW = 6.0F;
/* 425 */   double xangle = 0.0D;
/*     */   boolean barBorder = false;
/* 427 */   int secondary = -1;
/* 428 */   int vgrid = 0;
/*     */   boolean logY = false;
/*     */   boolean logY2 = false;
/* 431 */   Number min = null, max = null;
/* 432 */   Number mincr = null; Number incr = null;
/* 433 */   String ytitle = null;
/* 434 */   Image bgImage = null;
/*     */   int[] pstyles = { 
/* 436 */       908, 904, 907, 902, 906, 910, 900, 901, 905, 909, 903 };
/*     */ 
/*     */ 
/*     */   
/*     */   boolean logX = false;
/*     */ 
/*     */ 
/*     */   
/* 444 */   Number xmin = null, xmax = null;
/* 445 */   Number xmincr = null, xincr = null;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\ChartDescriptor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */