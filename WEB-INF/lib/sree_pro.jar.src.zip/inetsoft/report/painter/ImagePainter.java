package inetsoft.report.painter;

import inetsoft.report.Common;
import inetsoft.report.Painter;
import inetsoft.report.internal.Encoder;
import inetsoft.report.internal.MetaImage;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ImagePainter implements Painter {
  private Image image;
  
  private Dimension isize;
  
  private boolean fit;
  
  public ImagePainter(Image paramImage) {
    this.fit = true;
    setImage(paramImage);
  }
  
  public ImagePainter(Image paramImage, boolean paramBoolean) {
    this(paramImage);
    this.fit = paramBoolean;
  }
  
  public Dimension getPreferredSize() { return (this.isize.width < 0 || this.isize.height < 0) ? new Dimension(20, 20) : new Dimension(this.isize); }
  
  public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Image image1 = (this.image instanceof MetaImage) ? ((MetaImage)this.image).getImage() : this.image;
    if (image1 == null || this.isize.width < 0 || this.isize.height < 0) {
      Color color = paramGraphics.getColor();
      paramGraphics.setColor(Color.gray);
      paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
      paramGraphics.setColor(color);
    } else if (this.fit) {
      Common.drawImage(paramGraphics, image1, paramInt1, paramInt2, paramInt3, paramInt4, null);
    } else {
      Common.drawImage(paramGraphics, image1, paramInt1, paramInt2, 0.0F, 0.0F, null);
    } 
  }
  
  public boolean isScalable() { return false; }
  
  public Image getImage() { return this.image; }
  
  public void setImage(Image paramImage) {
    this.image = paramImage;
    if (paramImage == null) {
      this.isize = new Dimension(50, 50);
    } else {
      Common.waitForImage(paramImage);
      this.isize = new Dimension(paramImage.getWidth(null), paramImage.getHeight(null));
    } 
  }
  
  public boolean isFit() { return this.fit; }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
    paramObjectInputStream.defaultReadObject();
    byte[] arrayOfByte = (byte[])paramObjectInputStream.readObject();
    if (arrayOfByte != null) {
      int i = paramObjectInputStream.readInt();
      int j = paramObjectInputStream.readInt();
      if (i > 0 && j > 0)
        this.image = Encoder.decodeImage(i, j, arrayOfByte); 
    } 
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    paramObjectOutputStream.defaultWriteObject();
    byte[] arrayOfByte = (this.image != null) ? Encoder.encodeImage(this.image) : null;
    paramObjectOutputStream.writeObject(arrayOfByte);
    if (arrayOfByte != null) {
      paramObjectOutputStream.writeInt(this.image.getWidth(null));
      paramObjectOutputStream.writeInt(this.image.getHeight(null));
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\ImagePainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */