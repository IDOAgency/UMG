/*     */ package inetsoft.report.painter;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.Presenter;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Shape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IconCounterPresenter
/*     */   implements Presenter
/*     */ {
/*  40 */   public IconCounterPresenter(Image paramImage) { this.icon = paramImage; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics paramGraphics, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  53 */     loadImages();
/*     */     
/*  55 */     if (this.icon != null && paramObject != null && paramObject instanceof Number) {
/*  56 */       Shape shape = paramGraphics.getClip();
/*  57 */       paramGraphics.clipRect(paramInt1, paramInt2, paramInt3, paramInt4);
/*  58 */       int i = ((Number)paramObject).intValue();
/*  59 */       int j = this.icon.getWidth(null), k = this.icon.getHeight(null);
/*  60 */       paramInt1 += 2;
/*  61 */       paramInt2 += (paramInt4 - k) / 2;
/*     */       
/*  63 */       for (byte b = 0; b < i; b++, paramInt1 += j + 2) {
/*  64 */         paramGraphics.drawImage(this.icon, paramInt1, paramInt2, null);
/*     */       }
/*  66 */       paramGraphics.setClip(shape);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object paramObject) {
/*  76 */     loadImages();
/*     */     
/*  78 */     if (this.icon != null && paramObject != null && paramObject instanceof Number) {
/*  79 */       int i = ((Number)paramObject).intValue();
/*  80 */       return new Dimension(i * (this.icon.getWidth(null) + 2) + 2, this.icon.getHeight(null) + 2);
/*     */     } 
/*     */ 
/*     */     
/*  84 */     return new Dimension(0, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public boolean isPresenterOf(Class paramClass) { return Number.class.isAssignableFrom(paramClass); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadImages() {
/* 100 */     if (this.icon == null) {
/*     */       try {
/* 102 */         this.icon = Common.getImage(this, "images/beancount.gif");
/*     */       } catch (Exception exception) {
/* 104 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 108 */     if (this.icon != null) {
/* 109 */       Common.waitForImage(this.icon);
/*     */     }
/*     */   }
/*     */   
/* 113 */   private Image icon = null;
/*     */   
/*     */   public IconCounterPresenter() {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\IconCounterPresenter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */