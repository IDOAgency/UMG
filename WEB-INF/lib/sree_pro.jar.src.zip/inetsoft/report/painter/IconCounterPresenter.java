package inetsoft.report.painter;

import inetsoft.report.Common;
import inetsoft.report.Presenter;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Shape;

public class IconCounterPresenter implements Presenter {
  public IconCounterPresenter(Image paramImage) { this.icon = paramImage; }
  
  public void paint(Graphics paramGraphics, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    loadImages();
    if (this.icon != null && paramObject != null && paramObject instanceof Number) {
      Shape shape = paramGraphics.getClip();
      paramGraphics.clipRect(paramInt1, paramInt2, paramInt3, paramInt4);
      int i = ((Number)paramObject).intValue();
      int j = this.icon.getWidth(null), k = this.icon.getHeight(null);
      paramInt1 += 2;
      paramInt2 += (paramInt4 - k) / 2;
      for (byte b = 0; b < i; b++, paramInt1 += j + 2)
        paramGraphics.drawImage(this.icon, paramInt1, paramInt2, null); 
      paramGraphics.setClip(shape);
    } 
  }
  
  public Dimension getPreferredSize(Object paramObject) {
    loadImages();
    if (this.icon != null && paramObject != null && paramObject instanceof Number) {
      int i = ((Number)paramObject).intValue();
      return new Dimension(i * (this.icon.getWidth(null) + 2) + 2, this.icon.getHeight(null) + 2);
    } 
    return new Dimension(0, 0);
  }
  
  public boolean isPresenterOf(Class paramClass) { return Number.class.isAssignableFrom(paramClass); }
  
  private void loadImages() {
    if (this.icon == null)
      try {
        this.icon = Common.getImage(this, "images/beancount.gif");
      } catch (Exception exception) {
        exception.printStackTrace();
      }  
    if (this.icon != null)
      Common.waitForImage(this.icon); 
  }
  
  private Image icon = null;
  
  public IconCounterPresenter() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\IconCounterPresenter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */