/*     */ package inetsoft.report.painter;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.Presenter;
/*     */ import inetsoft.report.StyleConstants;
/*     */ import inetsoft.report.internal.Bounds;
/*     */ import inetsoft.report.internal.Util;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShadowPresenter
/*     */   implements Presenter, StyleConstants
/*     */ {
/*     */   public ShadowPresenter() {}
/*     */   
/*  39 */   public ShadowPresenter(Font paramFont) { this.font = paramFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public void setFont(Font paramFont) { this.font = paramFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public Font getFont() { return this.font; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public void setShading(Color paramColor) { this.shading = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public Color getShading() { return this.shading; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public void setTextColor(Color paramColor) { this.textC = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public Color getTextColor() { return this.textC; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics paramGraphics, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 101 */     Color color = paramGraphics.getColor();
/* 102 */     Font font1 = paramGraphics.getFont();
/*     */     
/* 104 */     paramGraphics.setColor(Color.white);
/* 105 */     paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 106 */     paramGraphics.setColor(Color.black);
/* 107 */     paramGraphics.fillRect(paramInt1 + this.shadow, paramInt2 + this.shadow, paramInt3 - this.shadow, paramInt4 - this.shadow);
/* 108 */     paramGraphics.setColor(this.shading);
/* 109 */     paramGraphics.fillRect(paramInt1, paramInt2, paramInt3 - this.shadow, paramInt4 - this.shadow);
/* 110 */     paramGraphics.setColor(Color.black);
/* 111 */     paramGraphics.drawRect(paramInt1, paramInt2, paramInt3 - this.shadow, paramInt4 - this.shadow);
/*     */     
/* 113 */     if (paramObject != null) {
/* 114 */       paramGraphics.setColor(this.textC);
/* 115 */       paramGraphics.setFont(this.font);
/* 116 */       Common.paintText(paramGraphics, Util.toString(paramObject), new Bounds(paramInt1, paramInt2, (paramInt3 - this.shadow), (paramInt4 - this.shadow)), 18, true, false, 0);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 121 */     paramGraphics.setColor(color);
/* 122 */     paramGraphics.setFont(font1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object paramObject) {
/* 131 */     if (paramObject == null) {
/* 132 */       return new Dimension(0, 0);
/*     */     }
/*     */     
/* 135 */     return new Dimension(this.fm.stringWidth(Util.toString(paramObject)) + this.shadow + 8, this.fm.getHeight() + this.shadow + 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public boolean isPresenterOf(Class paramClass) { return true; }
/*     */ 
/*     */   
/* 148 */   private Font font = new Font("Serif", 1, 10);
/* 149 */   private FontMetrics fm = Common.getFontMetrics(this.font);
/* 150 */   private int shadow = 4;
/* 151 */   private Color textC = Color.black;
/* 152 */   private Color shading = Color.white;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\ShadowPresenter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */