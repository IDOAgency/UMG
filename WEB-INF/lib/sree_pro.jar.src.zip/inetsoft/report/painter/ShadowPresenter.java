package inetsoft.report.painter;

import inetsoft.report.Common;
import inetsoft.report.Presenter;
import inetsoft.report.StyleConstants;
import inetsoft.report.internal.Bounds;
import inetsoft.report.internal.Util;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

public class ShadowPresenter implements Presenter, StyleConstants {
  public ShadowPresenter() {}
  
  public ShadowPresenter(Font paramFont) { this.font = paramFont; }
  
  public void setFont(Font paramFont) { this.font = paramFont; }
  
  public Font getFont() { return this.font; }
  
  public void setShading(Color paramColor) { this.shading = paramColor; }
  
  public Color getShading() { return this.shading; }
  
  public void setTextColor(Color paramColor) { this.textC = paramColor; }
  
  public Color getTextColor() { return this.textC; }
  
  public void paint(Graphics paramGraphics, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Color color = paramGraphics.getColor();
    Font font1 = paramGraphics.getFont();
    paramGraphics.setColor(Color.white);
    paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
    paramGraphics.setColor(Color.black);
    paramGraphics.fillRect(paramInt1 + this.shadow, paramInt2 + this.shadow, paramInt3 - this.shadow, paramInt4 - this.shadow);
    paramGraphics.setColor(this.shading);
    paramGraphics.fillRect(paramInt1, paramInt2, paramInt3 - this.shadow, paramInt4 - this.shadow);
    paramGraphics.setColor(Color.black);
    paramGraphics.drawRect(paramInt1, paramInt2, paramInt3 - this.shadow, paramInt4 - this.shadow);
    if (paramObject != null) {
      paramGraphics.setColor(this.textC);
      paramGraphics.setFont(this.font);
      Common.paintText(paramGraphics, Util.toString(paramObject), new Bounds(paramInt1, paramInt2, (paramInt3 - this.shadow), (paramInt4 - this.shadow)), 18, true, false, 0);
    } 
    paramGraphics.setColor(color);
    paramGraphics.setFont(font1);
  }
  
  public Dimension getPreferredSize(Object paramObject) {
    if (paramObject == null)
      return new Dimension(0, 0); 
    return new Dimension(this.fm.stringWidth(Util.toString(paramObject)) + this.shadow + 8, this.fm.getHeight() + this.shadow + 2);
  }
  
  public boolean isPresenterOf(Class paramClass) { return true; }
  
  private Font font = new Font("Serif", 1, 10);
  
  private FontMetrics fm = Common.getFontMetrics(this.font);
  
  private int shadow = 4;
  
  private Color textC = Color.black;
  
  private Color shading = Color.white;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\ShadowPresenter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */