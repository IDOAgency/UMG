package inetsoft.report.painter;

import inetsoft.report.Presenter;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Shape;

public class BarPresenter implements Presenter {
  public BarPresenter(double paramDouble, Color paramColor) {
    this.max = paramDouble;
    this.color = paramColor;
  }
  
  public void paint(Graphics paramGraphics, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramObject != null && paramObject instanceof Number) {
      Shape shape = paramGraphics.getClip();
      Color color1 = paramGraphics.getColor();
      paramGraphics.clipRect(paramInt1, paramInt2, paramInt3, paramInt4);
      double d = ((Number)paramObject).doubleValue();
      paramGraphics.setColor(this.color);
      paramGraphics.fillRect(paramInt1, paramInt2 + 2, (int)(d * paramInt3 / this.max), paramInt4 - 4);
      paramGraphics.setColor(color1);
      paramGraphics.setClip(shape);
    } 
  }
  
  public Dimension getPreferredSize(Object paramObject) { return this.psize; }
  
  public void setPreferredSize(Dimension paramDimension) { paramDimension = new Dimension(paramDimension); }
  
  public boolean isPresenterOf(Class paramClass) { return Number.class.isAssignableFrom(paramClass); }
  
  private Color color = Color.gray;
  
  private double max = 100.0D;
  
  private Dimension psize = new Dimension(60, 20);
  
  public BarPresenter() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\BarPresenter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */