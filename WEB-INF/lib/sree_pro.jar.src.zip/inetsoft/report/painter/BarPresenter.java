/*    */ package inetsoft.report.painter;
/*    */ 
/*    */ import inetsoft.report.Presenter;
/*    */ import java.awt.Color;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BarPresenter
/*    */   implements Presenter
/*    */ {
/*    */   public BarPresenter(double paramDouble, Color paramColor) {
/* 41 */     this.max = paramDouble;
/* 42 */     this.color = paramColor;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void paint(Graphics paramGraphics, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 55 */     if (paramObject != null && paramObject instanceof Number) {
/* 56 */       Shape shape = paramGraphics.getClip();
/* 57 */       Color color1 = paramGraphics.getColor();
/* 58 */       paramGraphics.clipRect(paramInt1, paramInt2, paramInt3, paramInt4);
/*    */       
/* 60 */       double d = ((Number)paramObject).doubleValue();
/* 61 */       paramGraphics.setColor(this.color);
/* 62 */       paramGraphics.fillRect(paramInt1, paramInt2 + 2, (int)(d * paramInt3 / this.max), paramInt4 - 4);
/*    */       
/* 64 */       paramGraphics.setColor(color1);
/* 65 */       paramGraphics.setClip(shape);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 75 */   public Dimension getPreferredSize(Object paramObject) { return this.psize; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 82 */   public void setPreferredSize(Dimension paramDimension) { paramDimension = new Dimension(paramDimension); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 91 */   public boolean isPresenterOf(Class paramClass) { return Number.class.isAssignableFrom(paramClass); }
/*    */ 
/*    */   
/* 94 */   private Color color = Color.gray;
/* 95 */   private double max = 100.0D;
/* 96 */   private Dimension psize = new Dimension(60, 20);
/*    */   
/*    */   public BarPresenter() {}
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\BarPresenter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */