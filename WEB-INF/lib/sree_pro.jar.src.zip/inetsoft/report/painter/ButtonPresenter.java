/*     */ package inetsoft.report.painter;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.Presenter;
/*     */ import inetsoft.report.StyleConstants;
/*     */ import inetsoft.report.internal.Bounds;
/*     */ import inetsoft.report.internal.Util;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ButtonPresenter
/*     */   implements Presenter, StyleConstants
/*     */ {
/*     */   public ButtonPresenter() {}
/*     */   
/*     */   public ButtonPresenter(Color paramColor, Font paramFont) {
/*  40 */     this.color = paramColor;
/*  41 */     this.font = paramFont;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public void setColor(Color paramColor) { this.color = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public Color getColor() { return this.color; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public void setFont(Font paramFont) { this.font = paramFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public Font getFont() { return this.font; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics paramGraphics, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  86 */     Color color1 = paramGraphics.getColor();
/*  87 */     Font font1 = paramGraphics.getFont();
/*     */     
/*  89 */     paramGraphics.setColor(this.color);
/*  90 */     paramGraphics.fill3DRect(paramInt1, paramInt2, paramInt3, paramInt4, true);
/*     */     
/*  92 */     if (paramObject != null) {
/*  93 */       paramGraphics.setColor(Color.black);
/*  94 */       paramGraphics.setFont(this.font);
/*  95 */       Common.paintText(paramGraphics, Util.toString(paramObject), new Bounds(paramInt1, paramInt2, paramInt3, paramInt4), 18, true, false, 0);
/*     */     } 
/*     */ 
/*     */     
/*  99 */     paramGraphics.setColor(color1);
/* 100 */     paramGraphics.setFont(font1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object paramObject) {
/* 109 */     if (paramObject == null) {
/* 110 */       return new Dimension(0, 0);
/*     */     }
/*     */     
/* 113 */     return new Dimension(this.fm.stringWidth(Util.toString(paramObject)) + 4, this.fm.getHeight() + 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public boolean isPresenterOf(Class paramClass) { return true; }
/*     */ 
/*     */   
/* 126 */   private Color color = Color.lightGray;
/* 127 */   private Font font = new Font("Dialog", 1, 10);
/* 128 */   FontMetrics fm = Common.getFontMetrics(this.font);
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\ButtonPresenter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */