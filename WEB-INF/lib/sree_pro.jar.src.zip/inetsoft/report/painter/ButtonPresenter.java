package inetsoft.report.painter;

import inetsoft.report.Common;
import inetsoft.report.Presenter;
import inetsoft.report.StyleConstants;
import inetsoft.report.internal.Bounds;
import inetsoft.report.internal.Util;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

public class ButtonPresenter implements Presenter, StyleConstants {
  public ButtonPresenter() {}
  
  public ButtonPresenter(Color paramColor, Font paramFont) {
    this.color = paramColor;
    this.font = paramFont;
  }
  
  public void setColor(Color paramColor) { this.color = paramColor; }
  
  public Color getColor() { return this.color; }
  
  public void setFont(Font paramFont) { this.font = paramFont; }
  
  public Font getFont() { return this.font; }
  
  public void paint(Graphics paramGraphics, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Color color1 = paramGraphics.getColor();
    Font font1 = paramGraphics.getFont();
    paramGraphics.setColor(this.color);
    paramGraphics.fill3DRect(paramInt1, paramInt2, paramInt3, paramInt4, true);
    if (paramObject != null) {
      paramGraphics.setColor(Color.black);
      paramGraphics.setFont(this.font);
      Common.paintText(paramGraphics, Util.toString(paramObject), new Bounds(paramInt1, paramInt2, paramInt3, paramInt4), 18, true, false, 0);
    } 
    paramGraphics.setColor(color1);
    paramGraphics.setFont(font1);
  }
  
  public Dimension getPreferredSize(Object paramObject) {
    if (paramObject == null)
      return new Dimension(0, 0); 
    return new Dimension(this.fm.stringWidth(Util.toString(paramObject)) + 4, this.fm.getHeight() + 4);
  }
  
  public boolean isPresenterOf(Class paramClass) { return true; }
  
  private Color color = Color.lightGray;
  
  private Font font = new Font("Dialog", 1, 10);
  
  FontMetrics fm = Common.getFontMetrics(this.font);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\ButtonPresenter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */