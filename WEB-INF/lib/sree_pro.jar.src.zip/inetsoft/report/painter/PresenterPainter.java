package inetsoft.report.painter;

import inetsoft.report.Painter;
import inetsoft.report.Presenter;
import java.awt.Dimension;
import java.awt.Graphics;

public class PresenterPainter implements Painter {
  private Presenter presenter;
  
  private Object obj;
  
  public PresenterPainter(Object paramObject, Presenter paramPresenter) {
    this.obj = paramObject;
    this.presenter = paramPresenter;
  }
  
  public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.presenter.paint(paramGraphics, this.obj, paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public Dimension getPreferredSize() { return this.presenter.getPreferredSize(this.obj); }
  
  public boolean isScalable() { return false; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\PresenterPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */