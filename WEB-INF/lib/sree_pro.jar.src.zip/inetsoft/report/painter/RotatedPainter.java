/*    */ package inetsoft.report.painter;
/*    */ 
/*    */ import inetsoft.report.Common;
/*    */ import inetsoft.report.Painter;
/*    */ import java.awt.Component;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RotatedPainter
/*    */   implements Painter
/*    */ {
/*    */   private Painter painter;
/*    */   
/* 32 */   public RotatedPainter(Component paramComponent) { this.painter = new ComponentPainter(paramComponent); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   public RotatedPainter(Image paramImage) { this(new ImagePainter(paramImage)); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public RotatedPainter(Painter paramPainter) { this.painter = paramPainter; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Dimension getPreferredSize() {
/* 56 */     Dimension dimension = this.painter.getPreferredSize();
/* 57 */     return new Dimension(dimension.height, dimension.width);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 69 */   public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) { Common.paintRotate(this.painter, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 76 */   public boolean isScalable() { return this.painter.isScalable(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\RotatedPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */