/*     */ package inetsoft.report.painter;
/*     */ 
/*     */ import inetsoft.report.Presenter;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Shape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Bar2Presenter
/*     */   implements Presenter
/*     */ {
/*     */   public Bar2Presenter(double paramDouble, Color paramColor1, Color paramColor2) {
/*  45 */     this.max = paramDouble;
/*  46 */     this.color = paramColor1;
/*  47 */     this.neg = paramColor2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics paramGraphics, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  60 */     if (paramObject != null && paramObject instanceof Number) {
/*  61 */       Shape shape = paramGraphics.getClip();
/*  62 */       Color color1 = paramGraphics.getColor();
/*  63 */       paramGraphics.clipRect(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */       
/*  65 */       paramInt1 += paramInt3 / 2;
/*  66 */       double d = ((Number)paramObject).doubleValue();
/*     */       
/*  68 */       if (d < 0.0D) {
/*  69 */         paramGraphics.setColor(this.neg);
/*  70 */         int i = (int)(-d * paramInt3 / 2.0D * this.max);
/*  71 */         paramGraphics.fillRect(paramInt1 - i, paramInt2 + 2, i, paramInt4 - 4);
/*     */       } else {
/*     */         
/*  74 */         paramGraphics.setColor(this.color);
/*  75 */         paramGraphics.fillRect(paramInt1, paramInt2 + 2, (int)(d * paramInt3 / 2.0D * this.max), paramInt4 - 4);
/*     */       } 
/*     */       
/*  78 */       paramGraphics.setColor(color1);
/*  79 */       paramGraphics.setClip(shape);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public Dimension getPreferredSize(Object paramObject) { return this.psize; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public void setPreferredSize(Dimension paramDimension) { paramDimension = new Dimension(paramDimension); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public boolean isPresenterOf(Class paramClass) { return Number.class.isAssignableFrom(paramClass); }
/*     */ 
/*     */   
/* 108 */   private Color color = Color.darkGray; private Color neg = Color.red;
/* 109 */   private double max = 100.0D;
/* 110 */   private Dimension psize = new Dimension(80, 20);
/*     */   
/*     */   public Bar2Presenter() {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\Bar2Presenter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */