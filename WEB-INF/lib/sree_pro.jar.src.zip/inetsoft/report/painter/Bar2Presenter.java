package inetsoft.report.painter;

import inetsoft.report.Presenter;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Shape;

public class Bar2Presenter implements Presenter {
  public Bar2Presenter(double paramDouble, Color paramColor1, Color paramColor2) {
    this.max = paramDouble;
    this.color = paramColor1;
    this.neg = paramColor2;
  }
  
  public void paint(Graphics paramGraphics, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramObject != null && paramObject instanceof Number) {
      Shape shape = paramGraphics.getClip();
      Color color1 = paramGraphics.getColor();
      paramGraphics.clipRect(paramInt1, paramInt2, paramInt3, paramInt4);
      paramInt1 += paramInt3 / 2;
      double d = ((Number)paramObject).doubleValue();
      if (d < 0.0D) {
        paramGraphics.setColor(this.neg);
        int i = (int)(-d * paramInt3 / 2.0D * this.max);
        paramGraphics.fillRect(paramInt1 - i, paramInt2 + 2, i, paramInt4 - 4);
      } else {
        paramGraphics.setColor(this.color);
        paramGraphics.fillRect(paramInt1, paramInt2 + 2, (int)(d * paramInt3 / 2.0D * this.max), paramInt4 - 4);
      } 
      paramGraphics.setColor(color1);
      paramGraphics.setClip(shape);
    } 
  }
  
  public Dimension getPreferredSize(Object paramObject) { return this.psize; }
  
  public void setPreferredSize(Dimension paramDimension) { paramDimension = new Dimension(paramDimension); }
  
  public boolean isPresenterOf(Class paramClass) { return Number.class.isAssignableFrom(paramClass); }
  
  private Color color = Color.darkGray;
  
  private Color neg = Color.red;
  
  private double max = 100.0D;
  
  private Dimension psize = new Dimension(80, 20);
  
  public Bar2Presenter() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\Bar2Presenter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */