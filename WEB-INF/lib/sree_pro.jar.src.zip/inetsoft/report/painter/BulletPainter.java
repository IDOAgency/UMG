/*    */ package inetsoft.report.painter;
/*    */ 
/*    */ import inetsoft.report.Common;
/*    */ import inetsoft.report.ScaledPainter;
/*    */ import inetsoft.report.Size;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Image;
/*    */ import java.awt.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BulletPainter
/*    */   implements ScaledPainter
/*    */ {
/*    */   public BulletPainter() {}
/*    */   
/*    */   public BulletPainter(Image paramImage) {
/* 43 */     this.icon = paramImage;
/*    */     
/* 45 */     Common.waitForImage(paramImage);
/* 46 */     this.size = new Dimension(paramImage.getWidth(null), paramImage.getHeight(null));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   public Dimension getPreferredSize() { return new Dimension((int)(this.size.width * 1.6D), (int)(this.size.height * 1.6D)); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 61 */   public Size getSize() { return new Size(0.22222222F, 0.22222222F); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 68 */   public boolean isScalable() { return false; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 80 */     Shape shape = paramGraphics.getClip();
/* 81 */     paramGraphics.clipRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 82 */     int i = (int)(paramInt4 * 0.4D);
/* 83 */     paramInt1 += (paramInt3 - i) / 2;
/* 84 */     paramInt2 += (paramInt4 - i) / 2;
/*    */     
/* 86 */     if (this.icon == null) {
/* 87 */       paramGraphics.fillOval(paramInt1, paramInt2, i, i);
/*    */     } else {
/*    */       
/* 90 */       paramGraphics.drawImage(this.icon, paramInt1, paramInt2, null);
/*    */     } 
/*    */     
/* 93 */     paramGraphics.setClip(shape);
/*    */   }
/*    */   
/* 96 */   private Image icon = null;
/* 97 */   private Dimension size = new Dimension(40, 40);
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\BulletPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */