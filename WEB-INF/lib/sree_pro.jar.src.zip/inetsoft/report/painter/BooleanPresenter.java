package inetsoft.report.painter;

import inetsoft.report.Common;
import inetsoft.report.Presenter;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Shape;

public class BooleanPresenter implements Presenter {
  public BooleanPresenter() {
    try {
      this.true_mark = Common.getImage(this, "images/checkon.gif");
      this.false_mark = Common.getImage(this, "images/checkoff.gif");
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    loadImages();
  }
  
  public BooleanPresenter(Image paramImage1, Image paramImage2) {
    this.true_mark = paramImage1;
    this.false_mark = paramImage2;
    loadImages();
  }
  
  public void paint(Graphics paramGraphics, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Image image = ((Boolean)paramObject).booleanValue() ? this.true_mark : this.false_mark;
    if (image != null) {
      int i = image.getWidth(null), j = image.getHeight(null);
      Shape shape = paramGraphics.getClip();
      paramGraphics.clipRect(paramInt1, paramInt2, paramInt3, paramInt4);
      paramInt1 += (paramInt3 - i) / 2;
      paramInt2 += (paramInt4 - j) / 2;
      paramGraphics.drawImage(image, paramInt1, paramInt2, null);
      paramGraphics.setClip(shape);
    } 
  }
  
  public Dimension getPreferredSize(Object paramObject) { return (this.true_mark != null) ? new Dimension(this.true_mark.getWidth(null), this.true_mark.getHeight(null)) : ((this.false_mark != null) ? new Dimension(this.false_mark.getWidth(null), this.false_mark.getHeight(null)) : new Dimension(0, 0)); }
  
  public boolean isPresenterOf(Class paramClass) { return Boolean.class.isAssignableFrom(paramClass); }
  
  private void loadImages() {
    Common.waitForImage(this.true_mark);
    Common.waitForImage(this.false_mark);
  }
  
  private Image true_mark = null;
  
  private Image false_mark = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\BooleanPresenter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */