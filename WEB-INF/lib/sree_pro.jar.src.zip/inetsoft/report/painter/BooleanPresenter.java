/*     */ package inetsoft.report.painter;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.Presenter;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Shape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanPresenter
/*     */   implements Presenter
/*     */ {
/*     */   public BooleanPresenter() {
/*     */     try {
/*  35 */       this.true_mark = Common.getImage(this, "images/checkon.gif");
/*  36 */       this.false_mark = Common.getImage(this, "images/checkoff.gif");
/*     */     } catch (Exception exception) {
/*  38 */       exception.printStackTrace();
/*     */     } 
/*     */     
/*  41 */     loadImages();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanPresenter(Image paramImage1, Image paramImage2) {
/*  50 */     this.true_mark = paramImage1;
/*  51 */     this.false_mark = paramImage2;
/*  52 */     loadImages();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics paramGraphics, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  65 */     Image image = ((Boolean)paramObject).booleanValue() ? this.true_mark : this.false_mark;
/*     */     
/*  67 */     if (image != null) {
/*  68 */       int i = image.getWidth(null), j = image.getHeight(null);
/*  69 */       Shape shape = paramGraphics.getClip();
/*  70 */       paramGraphics.clipRect(paramInt1, paramInt2, paramInt3, paramInt4);
/*  71 */       paramInt1 += (paramInt3 - i) / 2;
/*  72 */       paramInt2 += (paramInt4 - j) / 2;
/*  73 */       paramGraphics.drawImage(image, paramInt1, paramInt2, null);
/*  74 */       paramGraphics.setClip(shape);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public Dimension getPreferredSize(Object paramObject) { return (this.true_mark != null) ? new Dimension(this.true_mark.getWidth(null), this.true_mark.getHeight(null)) : ((this.false_mark != null) ? new Dimension(this.false_mark.getWidth(null), this.false_mark.getHeight(null)) : new Dimension(0, 0)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public boolean isPresenterOf(Class paramClass) { return Boolean.class.isAssignableFrom(paramClass); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadImages() {
/* 105 */     Common.waitForImage(this.true_mark);
/* 106 */     Common.waitForImage(this.false_mark);
/*     */   }
/*     */   
/* 109 */   private Image true_mark = null;
/* 110 */   private Image false_mark = null;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\BooleanPresenter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */