/*     */ package inetsoft.report.painter;
/*     */ 
/*     */ import inetsoft.report.Painter;
/*     */ import inetsoft.report.internal.Util;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Shape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentPainter
/*     */   implements Painter
/*     */ {
/*     */   public static final int DEFAULT = 0;
/*     */   public static final int PRINTALL = 1;
/*     */   public static final int PAINTALL = 2;
/*     */   public static final int PRINT = 3;
/*     */   public static final int PAINT = 4;
/*     */   private Component comp;
/*     */   private int opt;
/*     */   
/*     */   public ComponentPainter(Component paramComponent) {
/* 145 */     this.opt = 0; this.comp = paramComponent; } public ComponentPainter(Component paramComponent, int paramInt) { this.opt = 0;
/*     */     this.comp = paramComponent;
/*     */     this.opt = paramInt; }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize() { return this.comp.getSize(); }
/*     */   
/*     */   public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*     */     Shape shape = paramGraphics.getClip();
/*     */     paramGraphics.translate(paramInt1, paramInt2);
/*     */     paramGraphics.clipRect(-1, -1, paramInt3, paramInt4);
/*     */     switch (this.opt) {
/*     */       case 0:
/*     */         if (Util.isLightWeight(this.comp)) {
/*     */           this.comp.paintAll(paramGraphics);
/*     */           break;
/*     */         } 
/*     */         try {
/*     */           this.comp.printAll(paramGraphics);
/*     */         } catch (Exception exception) {
/*     */           this.comp.update(paramGraphics);
/*     */         } 
/*     */         break;
/*     */       case 1:
/*     */         this.comp.printAll(paramGraphics);
/*     */         break;
/*     */       case 2:
/*     */         this.comp.paintAll(paramGraphics);
/*     */         break;
/*     */       case 3:
/*     */         this.comp.print(paramGraphics);
/*     */         break;
/*     */       case 4:
/*     */         this.comp.paint(paramGraphics);
/*     */         break;
/*     */     } 
/*     */     paramGraphics.translate(-paramInt1, -paramInt2);
/*     */     paramGraphics.setClip(shape);
/*     */   }
/*     */   
/*     */   public boolean isScalable() { return false; }
/*     */   
/*     */   public Component getComponent() { return this.comp; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\painter\ComponentPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */