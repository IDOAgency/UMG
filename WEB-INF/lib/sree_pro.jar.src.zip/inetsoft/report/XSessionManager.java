/*     */ package inetsoft.report;
/*     */ 
/*     */ import inetsoft.report.internal.ChartXElement;
/*     */ import inetsoft.report.internal.DatasetAttr;
/*     */ import inetsoft.report.internal.ScriptEnv;
/*     */ import inetsoft.report.lens.ChartTable;
/*     */ import inetsoft.report.lens.TableChartLens;
/*     */ import inetsoft.report.lens.xnode.XNodeFormLens;
/*     */ import inetsoft.report.lens.xnode.XNodeTableLens;
/*     */ import inetsoft.report.lens.xnode.XNodeTextLens;
/*     */ import inetsoft.uql.VariableTable;
/*     */ import inetsoft.uql.XDataService;
/*     */ import inetsoft.uql.XEnv;
/*     */ import inetsoft.uql.XFactory;
/*     */ import inetsoft.uql.XLog;
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.XTableNode;
/*     */ import inetsoft.uql.builder.VariableEntry;
/*     */ import inetsoft.uql.path.XNodePath;
/*     */ import inetsoft.uql.schema.UserVariable;
/*     */ import inetsoft.uql.util.expr.Expr;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XSessionManager
/*     */ {
/*  44 */   static XSessionManager manager = null;
/*     */   XDataService service;
/*     */   Object session;
/*     */   boolean uniqName;
/*     */   
/*     */   public static XSessionManager getSessionManager() throws RemoteException {
/*  50 */     if (manager == null) {
/*  51 */       manager = new XSessionManager();
/*  52 */       manager.bind(System.getProperty("user.name"));
/*     */     } 
/*     */     
/*  55 */     return manager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XSessionManager() throws RemoteException {
/*     */     setVariableNameUnique(XEnv.getProperty("query.variable.unique", "true").equalsIgnoreCase("true"));
/* 387 */     this.uniqName = true; this.service = XFactory.getDataService(); } public XSessionManager(XDataService paramXDataService, Object paramObject) { setVariableNameUnique(XEnv.getProperty("query.variable.unique", "true").equalsIgnoreCase("true")); this.uniqName = true;
/*     */     this.service = paramXDataService;
/*     */     this.session = paramObject; }
/*     */ 
/*     */   
/*     */   public XDataService getDataService() { return this.service; }
/*     */   
/*     */   public void setDataService(XDataService paramXDataService) { this.service = paramXDataService; }
/*     */   
/*     */   public Object getSession() { return this.session; }
/*     */   
/*     */   public void setSession(Object paramObject) { this.session = paramObject; }
/*     */   
/*     */   public boolean isVariableNameUnique() { return this.uniqName; }
/*     */   
/*     */   public void setVariableNameUnique(boolean paramBoolean) { this.uniqName = paramBoolean; }
/*     */   
/*     */   public void bind(Object paramObject) { this.session = this.service.bind((paramObject == null) ? System.getProperty("user.name") : paramObject); }
/*     */   
/*     */   public UserVariable[] getQueryParameters(StyleSheet paramStyleSheet, boolean paramBoolean) throws RemoteException {
/*     */     Hashtable hashtable = new Hashtable();
/*     */     Vector vector = getAllElements(paramStyleSheet);
/*     */     for (byte b1 = 0; b1 < vector.size(); b1++)
/*     */       getQueryParameters((ReportElement)vector.elementAt(b1), hashtable, paramBoolean); 
/*     */     if (hashtable.size() == 0)
/*     */       return null; 
/*     */     Enumeration enumeration = hashtable.elements();
/*     */     UserVariable[] arrayOfUserVariable = new UserVariable[hashtable.size()];
/*     */     for (byte b2 = 0; enumeration.hasMoreElements(); b2++)
/*     */       arrayOfUserVariable[b2] = (UserVariable)enumeration.nextElement(); 
/*     */     return arrayOfUserVariable;
/*     */   }
/*     */   
/*     */   public boolean execute(StyleSheet paramStyleSheet) throws Exception {
/*     */     UserVariable[] arrayOfUserVariable = getQueryParameters(paramStyleSheet, true);
/*     */     VariableTable variableTable = new VariableTable();
/*     */     if (arrayOfUserVariable != null && arrayOfUserVariable.length > 0) {
/*     */       variableTable = VariableEntry.show(arrayOfUserVariable);
/*     */       if (variableTable == null)
/*     */         return false; 
/*     */     } 
/*     */     execute(paramStyleSheet, variableTable);
/*     */     return true;
/*     */   }
/*     */   
/*     */   public void execute(StyleSheet paramStyleSheet, VariableTable paramVariableTable) throws Exception {
/*     */     Vector vector1 = getAllElements(paramStyleSheet);
/*     */     Hashtable hashtable = new Hashtable();
/*     */     Vector vector2 = new Vector();
/*     */     Vector vector3 = new Vector();
/*     */     ScriptEnv scriptEnv = paramStyleSheet.getScriptEnv();
/*     */     if (scriptEnv != null)
/*     */       scriptEnv.put("parameter", paramVariableTable); 
/*     */     paramStyleSheet.runOnLoad();
/*     */     for (byte b1 = 0; b1 < vector1.size(); b1++) {
/*     */       ReportElement reportElement = (ReportElement)vector1.elementAt(b1);
/*     */       String str = reportElement.getProperty("query");
/*     */       if (str != null)
/*     */         if (str.startsWith("chart::")) {
/*     */           vector3.addElement(reportElement);
/*     */         } else if (str.startsWith("variable::")) {
/*     */           Object object = paramVariableTable.get(str.substring(10));
/*     */           if (object == null)
/*     */             object = ""; 
/*     */           if (reportElement instanceof TextElement) {
/*     */             ((TextElement)reportElement).setText(object.toString());
/*     */           } else if (reportElement instanceof TextBoxElement) {
/*     */             ((TextBoxElement)reportElement).setText(object.toString());
/*     */           } 
/*     */         } else {
/*     */           XNode xNode = (XNode)hashtable.get(str);
/*     */           if (xNode == null) {
/*     */             VariableTable variableTable = paramVariableTable.getSubset(str + ".");
/*     */             xNode = this.service.execute(this.session, str, variableTable);
/*     */             if (xNode != null) {
/*     */               vector2.addElement(xNode);
/*     */               if (!(xNode instanceof XTableNode) || ((XTableNode)xNode).isRewindable())
/*     */                 hashtable.put(str, xNode); 
/*     */             } 
/*     */           } else if (xNode instanceof XTableNode) {
/*     */             ((XTableNode)xNode).rewind();
/*     */           } 
/*     */           if (xNode != null) {
/*     */             String str1 = reportElement.getProperty("aggregate");
/*     */             String str2 = reportElement.getProperty("xnodepath");
/*     */             if (str2 != null) {
/*     */               XNodePath xNodePath = XNodePath.parse(str2);
/*     */               xNode = xNodePath.select(xNode, paramVariableTable.getSubset(str + "."));
/*     */             } 
/*     */             if (str1 != null) {
/*     */               XNode xNode1 = new XNode(xNode.getName());
/*     */               xNode1.setValue(Expr.aggregate(str1, Expr.toArray(xNode)));
/*     */               xNode = xNode1;
/*     */             } 
/*     */             if (reportElement instanceof ChartElement) {
/*     */               DatasetAttr datasetAttr = (reportElement instanceof ChartXElement) ? ((ChartXElement)reportElement).getDataset() : null;
/*     */               TableFilter tableFilter = new XNodeTableLens(xNode);
/*     */               if (datasetAttr != null)
/*     */                 tableFilter = datasetAttr.createFilter(tableFilter); 
/*     */               TableChartLens tableChartLens = new TableChartLens(tableFilter);
/*     */               if (datasetAttr != null)
/*     */                 tableChartLens.setLabelFormat(datasetAttr.getLabelFormat()); 
/*     */               ((ChartElement)reportElement).setChart(tableChartLens);
/*     */             } else if (reportElement instanceof FormElement) {
/*     */               ((FormElement)reportElement).setForm(new XNodeFormLens(xNode));
/*     */             } else if (reportElement instanceof TableElement) {
/*     */               ((TableElement)reportElement).setTable(new XNodeTableLens(xNode));
/*     */             } else if (reportElement instanceof SectionElement) {
/*     */               ((SectionElement)reportElement).setTable(new XNodeTableLens(xNode));
/*     */             } else if (reportElement instanceof TextElement) {
/*     */               ((TextElement)reportElement).setText(new XNodeTextLens(xNode));
/*     */             } else if (reportElement instanceof TextBoxElement) {
/*     */               ((TextBoxElement)reportElement).setText(new XNodeTextLens(xNode));
/*     */             } 
/*     */           } 
/*     */         }  
/*     */     } 
/*     */     for (byte b2 = 0; b2 < vector3.size(); b2++) {
/*     */       TableElement tableElement = (TableElement)vector3.elementAt(b2);
/*     */       ChartElement chartElement = (ChartElement)paramStyleSheet.getElement(tableElement.getProperty("query").substring(7));
/*     */       if (chartElement != null)
/*     */         tableElement.setTable(new ChartTable(chartElement.getChart())); 
/*     */     } 
/*     */     for (byte b3 = 0; b3 < vector2.size(); b3++)
/*     */       ((XNode)vector2.elementAt(b3)).removeAllChildren(); 
/*     */   }
/*     */   
/*     */   protected Vector getAllElements(StyleSheet paramStyleSheet) {
/*     */     Vector vector = new Vector();
/*     */     Vector[] arrayOfVector = { paramStyleSheet.getAllElements(), paramStyleSheet.getAllHeaderElements(), paramStyleSheet.getAllFooterElements() };
/*     */     for (byte b = 0; b < arrayOfVector.length; b++) {
/*     */       for (byte b1 = 0; b1 < arrayOfVector[b].size(); b1++) {
/*     */         Object object = arrayOfVector[b].elementAt(b1);
/*     */         if (object instanceof Vector) {
/*     */           Vector vector1 = (Vector)object;
/*     */           for (byte b2 = 0; b2 < vector1.size(); b2++)
/*     */             vector.addElement(vector1.elementAt(b2)); 
/*     */         } else if (object instanceof FixedContainer) {
/*     */           FixedContainer fixedContainer = (FixedContainer)object;
/*     */           for (byte b2 = 0; b2 < fixedContainer.getElementCount(); b2++)
/*     */             vector.addElement(fixedContainer.getElement(b2)); 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     return vector;
/*     */   }
/*     */   
/*     */   private void getQueryParameters(ReportElement paramReportElement, Hashtable paramHashtable, boolean paramBoolean) throws RemoteException {
/*     */     String str = paramReportElement.getProperty("query");
/*     */     if (str != null && str.indexOf("::") < 0) {
/*     */       UserVariable[] arrayOfUserVariable = this.service.getQueryParameters(this.session, str, paramBoolean);
/*     */       if (arrayOfUserVariable == null)
/*     */         return; 
/*     */       for (byte b = 0; b < arrayOfUserVariable.length; b++) {
/*     */         try {
/*     */           arrayOfUserVariable[b] = (UserVariable)arrayOfUserVariable[b].clone();
/*     */           if (this.uniqName) {
/*     */             arrayOfUserVariable[b].setName(arrayOfUserVariable[b].getName());
/*     */           } else {
/*     */             arrayOfUserVariable[b].setName(str + "." + arrayOfUserVariable[b].getName());
/*     */           } 
/*     */           paramHashtable.put(arrayOfUserVariable[b].getName(), arrayOfUserVariable[b]);
/*     */         } catch (Exception exception) {
/*     */           XLog.print(exception);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\XSessionManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */