package inetsoft.report;

import java.io.Serializable;

public interface SectionLens extends Serializable, Cloneable {
  SectionBand getSectionHeader();
  
  Object getSectionContent();
  
  SectionBand getSectionFooter();
  
  Object clone();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\SectionLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */