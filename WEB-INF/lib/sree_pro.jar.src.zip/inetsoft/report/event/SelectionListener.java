package inetsoft.report.event;

import java.util.EventListener;

public interface SelectionListener extends EventListener {
  void valueChanged(SelectionEvent paramSelectionEvent);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\event\SelectionListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */