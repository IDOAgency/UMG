package inetsoft.report.event;

import java.awt.event.MouseEvent;

public class SectionSelectionEvent extends SelectionEvent {
  int row;
  
  public SectionSelectionEvent(Object paramObject1, String paramString, Object paramObject2, int paramInt1, MouseEvent paramMouseEvent, int paramInt2) {
    super(paramObject1, paramString, paramObject2, paramInt1, paramMouseEvent);
    this.row = paramInt2;
  }
  
  public int getRow() { return this.row; }
  
  public String toString() { return "SectionSelectionEvent[" + getSource() + "," + this.eid + "," + this.item + "," + this.clickCount + "," + this.row + "," + "]"; }
  
  public boolean equals(Object paramObject) {
    if (super.equals(paramObject) && paramObject instanceof SectionSelectionEvent) {
      SectionSelectionEvent sectionSelectionEvent = (SectionSelectionEvent)paramObject;
      return (this.row == sectionSelectionEvent.row);
    } 
    return false;
  }
  
  public boolean matches(SelectionEvent paramSelectionEvent) {
    if (!super.matches(paramSelectionEvent))
      return false; 
    if (paramSelectionEvent instanceof SectionSelectionEvent) {
      SectionSelectionEvent sectionSelectionEvent = (SectionSelectionEvent)paramSelectionEvent;
      return (this.row == sectionSelectionEvent.row || this.row == -1 || sectionSelectionEvent.row == -1);
    } 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\event\SectionSelectionEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */