/*     */ package inetsoft.report.event;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.EventObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectionEvent
/*     */   extends EventObject
/*     */ {
/*     */   Object item;
/*     */   String eid;
/*     */   int clickCount;
/*     */   MouseEvent mouseEvent;
/*     */   
/*     */   public SelectionEvent(Object paramObject1, String paramString, Object paramObject2, int paramInt, MouseEvent paramMouseEvent) {
/*  34 */     super(paramObject1);
/*  35 */     this.item = paramObject2;
/*  36 */     this.eid = paramString;
/*  37 */     this.clickCount = paramInt;
/*  38 */     this.mouseEvent = paramMouseEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public String getElementID() { return this.eid; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public Object getItem() { return this.item; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public int getClickCount() { return this.clickCount; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public MouseEvent getMouseEvent() { return this.mouseEvent; }
/*     */ 
/*     */ 
/*     */   
/*  73 */   public String toString() { return "SelectionEvent[" + getSource() + ", " + this.eid + ", " + this.item + ", " + this.clickCount + "]"; }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  78 */     if (paramObject instanceof SelectionEvent) {
/*  79 */       SelectionEvent selectionEvent = (SelectionEvent)paramObject;
/*  80 */       return (this.eid.equals(selectionEvent.eid) && this.clickCount == selectionEvent.clickCount && ((this.item == null && selectionEvent.item == null) || (this.item != null && selectionEvent.item != null && this.item.equals(selectionEvent.item))));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  85 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(SelectionEvent paramSelectionEvent) {
/*  93 */     if (this.eid.equals(paramSelectionEvent.eid) && this.clickCount == paramSelectionEvent.clickCount) {
/*  94 */       if (this.item == null || paramSelectionEvent.item == null) {
/*  95 */         return true;
/*     */       }
/*     */       
/*  98 */       if (this.item != null && paramSelectionEvent.item != null) {
/*     */         try {
/* 100 */           Point point1 = (Point)this.item;
/* 101 */           Point point2 = (Point)paramSelectionEvent.item;
/*     */           
/* 103 */           return ((point1.x == point2.x || point1.x == -1 || point2.y == -1) && (point1.y == point2.y || point1.y == -1 || point2.y == -1));
/*     */         } catch (Exception exception) {
/*     */           
/* 106 */           return this.item.equals(paramSelectionEvent.item);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 111 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\event\SelectionEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */