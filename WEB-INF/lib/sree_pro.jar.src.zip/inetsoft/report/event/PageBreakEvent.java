package inetsoft.report.event;

import java.awt.Rectangle;
import java.util.EventObject;

public class PageBreakEvent extends EventObject {
  String eid;
  
  String first_eid;
  
  Rectangle reg;
  
  Rectangle first_reg;
  
  boolean lastpg;
  
  public PageBreakEvent(Object paramObject, String paramString1, Rectangle paramRectangle1, String paramString2, Rectangle paramRectangle2, boolean paramBoolean) {
    super(paramObject);
    this.reg = null;
    this.first_reg = null;
    this.lastpg = false;
    this.eid = paramString1;
    this.reg = paramRectangle1;
    this.first_eid = paramString2;
    this.first_reg = paramRectangle2;
    this.lastpg = paramBoolean;
  }
  
  public String getElementID() { return this.eid; }
  
  public Rectangle getRegion() { return this.reg; }
  
  public String getFirstElementID() { return this.first_eid; }
  
  public Rectangle getFirstRegion() { return this.first_reg; }
  
  public boolean isLastPage() { return this.lastpg; }
  
  public String toString() { return "PageBreakEvent[" + getSource() + ", " + this.eid + ", " + this.reg + "]"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\event\PageBreakEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */