/*     */ package inetsoft.report;
/*     */ 
/*     */ import inetsoft.report.internal.TextBoxElementDef;
/*     */ import inetsoft.report.internal.TextElementDef;
/*     */ import inetsoft.report.lens.DefaultTextLens;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SectionBand
/*     */   extends FixedContainer
/*     */ {
/*     */   private float height;
/*     */   private boolean shrink;
/*     */   private boolean pageBefore;
/*     */   private boolean pageAfter;
/*     */   private int topBorder;
/*     */   private int leftBorder;
/*     */   private int bottomBorder;
/*     */   private int rightBorder;
/*     */   private boolean visible;
/*     */   private Hashtable bindingmap;
/*     */   
/*     */   public SectionBand(StyleSheet paramStyleSheet) {
/*  36 */     super(paramStyleSheet);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 247 */     this.height = 0.3F;
/* 248 */     this.shrink = false;
/* 249 */     this.pageBefore = false;
/* 250 */     this.pageAfter = false;
/*     */     
/* 252 */     this.visible = true;
/* 253 */     this.bindingmap = new Hashtable();
/*     */   }
/*     */   
/*     */   public float getHeight() { return this.height; }
/*     */   
/*     */   public void setHeight(float paramFloat) { this.height = paramFloat; }
/*     */   
/*     */   public boolean isShrinkToFit() { return this.shrink; }
/*     */   
/*     */   public void setShrinkToFit(boolean paramBoolean) { this.shrink = paramBoolean; }
/*     */   
/*     */   public String getBinding(String paramString) { return (String)this.bindingmap.get(paramString); }
/*     */   
/*     */   public void setBinding(String paramString1, String paramString2) {
/*     */     if (paramString2 == null) {
/*     */       this.bindingmap.remove(paramString1);
/*     */     } else {
/*     */       this.bindingmap.put(paramString1, paramString2);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isVisible() { return this.visible; }
/*     */   
/*     */   public void setVisible(boolean paramBoolean) { this.visible = paramBoolean; }
/*     */   
/*     */   public boolean isPageBefore() { return this.pageBefore; }
/*     */   
/*     */   public void setPageBefore(boolean paramBoolean) { this.pageBefore = paramBoolean; }
/*     */   
/*     */   public boolean isPageAfter() { return this.pageAfter; }
/*     */   
/*     */   public void setPageAfter(boolean paramBoolean) { this.pageAfter = paramBoolean; }
/*     */   
/*     */   public int getTopBorder() { return this.topBorder; }
/*     */   
/*     */   public void setTopBorder(int paramInt) { this.topBorder = paramInt; }
/*     */   
/*     */   public int getLeftBorder() { return this.leftBorder; }
/*     */   
/*     */   public void setLeftBorder(int paramInt) { this.leftBorder = paramInt; }
/*     */   
/*     */   public int getBottomBorder() { return this.bottomBorder; }
/*     */   
/*     */   public void setBottomBorder(int paramInt) { this.bottomBorder = paramInt; }
/*     */   
/*     */   public int getRightBorder() { return this.rightBorder; }
/*     */   
/*     */   public void setRightBorder(int paramInt) { this.rightBorder = paramInt; }
/*     */   
/*     */   public String addText(String paramString1, String paramString2, Rectangle paramRectangle) {
/*     */     TextElementDef textElementDef = new TextElementDef(this.parent, new DefaultTextLens(paramString2));
/*     */     String str = addElement(textElementDef, paramRectangle);
/*     */     setBinding(str, paramString1);
/*     */     return str;
/*     */   }
/*     */   
/*     */   public String addTextBox(String paramString1, String paramString2, int paramInt1, int paramInt2, Rectangle paramRectangle) {
/*     */     TextBoxElementDef textBoxElementDef = new TextBoxElementDef(this.parent, new DefaultTextLens(paramString2));
/*     */     textBoxElementDef.setBorder(paramInt1);
/*     */     textBoxElementDef.setTextAlignment(paramInt2);
/*     */     String str = addElement(textBoxElementDef, paramRectangle);
/*     */     setBinding(str, paramString1);
/*     */     return str;
/*     */   }
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException {
/*     */     SectionBand sectionBand = (SectionBand)super.clone();
/*     */     sectionBand.bindingmap = (Hashtable)this.bindingmap.clone();
/*     */     return sectionBand;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\SectionBand.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */