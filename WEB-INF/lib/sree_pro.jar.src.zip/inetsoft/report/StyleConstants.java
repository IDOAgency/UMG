package inetsoft.report;

import java.io.Serializable;

public interface StyleConstants extends Serializable {
  public static final int LANDSCAPE = 0;
  
  public static final int PORTRAIT = 1;
  
  public static final int WIDTH_MASK = 15;
  
  public static final int DASH_MASK = 240;
  
  public static final int SOLID_MASK = 4096;
  
  public static final int DOUBLE_MASK = 8192;
  
  public static final int RAISED_MASK = 16384;
  
  public static final int LOWERED_MASK = 32768;
  
  public static final int FRACTION_WIDTH_MASK = 983040;
  
  public static final int NO_BORDER = 0;
  
  public static final int ULTRA_THIN_LINE = 266240;
  
  public static final int THIN_THIN_LINE = 528384;
  
  public static final int THIN_LINE = 4097;
  
  public static final int MEDIUM_LINE = 4098;
  
  public static final int THICK_LINE = 4099;
  
  public static final int DOUBLE_LINE = 8195;
  
  public static final int RAISED_3D = 24578;
  
  public static final int LOWERED_3D = 40962;
  
  public static final int DOUBLE_3D_RAISED = 24579;
  
  public static final int DOUBLE_3D_LOWERED = 40963;
  
  public static final int DOT_LINE = 4113;
  
  public static final int DASH_LINE = 4145;
  
  public static final int MEDIUM_DASH = 4193;
  
  public static final int LARGE_DASH = 4241;
  
  public static final int H_ALIGN_MASK = 7;
  
  public static final int V_ALIGN_MASK = 56;
  
  public static final int H_LEFT = 1;
  
  public static final int H_CENTER = 2;
  
  public static final int H_RIGHT = 4;
  
  public static final int V_TOP = 8;
  
  public static final int V_CENTER = 16;
  
  public static final int V_BOTTOM = 32;
  
  public static final int V_BASELINE = 64;
  
  public static final int FILL = 0;
  
  public static final int LEFT = 1;
  
  public static final int CENTER = 2;
  
  public static final int RIGHT = 4;
  
  public static final int REMAINDER = 0;
  
  public static final int TRAY_UPPER = 1;
  
  public static final int TRAY_ONLYONE = 1;
  
  public static final int TRAY_LOWER = 2;
  
  public static final int TRAY_MIDDLE = 3;
  
  public static final int TRAY_MANUAL = 4;
  
  public static final int TRAY_ENVELOPE = 5;
  
  public static final int TRAY_ENVMANUAL = 6;
  
  public static final int TRAY_AUTO = 7;
  
  public static final int TRAY_TRACTOR = 8;
  
  public static final int TRAY_SMALLFMT = 9;
  
  public static final int TRAY_LARGEFMT = 10;
  
  public static final int TRAY_LARGECAPACITY = 11;
  
  public static final int TRAY_CASSETTE = 14;
  
  public static final int TRAY_FORMSOURCE = 15;
  
  public static final int COLOR_CHART = 4096;
  
  public static final int CHART_NOLABEL_MASK = 8192;
  
  public static final int CHART_STYLE_MASK = 255;
  
  public static final int POINT_MASK = 1024;
  
  public static final int CHART_LINE = 5122;
  
  public static final int CHART_POINT = 5124;
  
  public static final int CHART_BAR = 1;
  
  public static final int CHART_STACKBAR = 3;
  
  public static final int CHART_PIE = 6;
  
  public static final int CHART_PIE_NOLABEL = 8198;
  
  public static final int CHART_BAR3D = 5;
  
  public static final int CHART_STACKBAR3D = 7;
  
  public static final int CHART_PIE3D = 8;
  
  public static final int CHART_PIE3D_NOLABEL = 8200;
  
  public static final int CHART_BAR3D3D = 9;
  
  public static final int CHART_STOCK = 4106;
  
  public static final int CHART_STICK = 4107;
  
  public static final int CHART_AREA = 12;
  
  public static final int CHART_STACKAREA = 14;
  
  public static final int INVERTED_MASK = 256;
  
  public static final int CHART_INVERTED_BAR = 257;
  
  public static final int CHART_INVERTED_STACKBAR = 259;
  
  public static final int CHART_INVERTED_LINE = 5378;
  
  public static final int CHART_INVERTED_POINT = 5380;
  
  public static final int X_MASK = 512;
  
  public static final int CHART_XYSCATTER = 5636;
  
  public static final int CHART_XYLINE = 5634;
  
  public static final int CHART_BUBBLE = 528;
  
  public static final int CHART_RADAR = 1041;
  
  public static final int CHART_FILLED_RADAR = 18;
  
  public static final int CHART_CANDLE = 20;
  
  public static final int NONE = 0;
  
  public static final Size PAPER_LETTER = new Size(8.5D, 11.0D);
  
  public static final Size PAPER_LETTERSMALL = new Size(8.5D, 11.0D);
  
  public static final Size PAPER_TABLOID = new Size(11.0F, 17.0F);
  
  public static final Size PAPER_LEDGER = new Size(17.0F, 11.0F);
  
  public static final Size PAPER_LEGAL = new Size(8.5D, 14.0D);
  
  public static final Size PAPER_STATEMENT = new Size(5.5D, 8.5D);
  
  public static final Size PAPER_EXECUTIVE = new Size(7.25D, 10.5D);
  
  public static final Size PAPER_A3 = new Size(11.693455D, 16.5362D);
  
  public static final Size PAPER_A4 = new Size(8.2681D, 11.693455D);
  
  public static final Size PAPER_A4SMALL = new Size(8.2681D, 11.693455D);
  
  public static final Size PAPER_A5 = new Size(5.827042D, 8.2681D);
  
  public static final Size PAPER_B4 = new Size(9.842976D, 13.937654D);
  
  public static final Size PAPER_B5 = new Size(7.165687D, 10.118579D);
  
  public static final Size PAPER_FOLIO = new Size(8.5D, 13.0D);
  
  public static final Size PAPER_QUARTO = new Size(8.464959D, 10.827274D);
  
  public static final Size PAPER_10X14 = new Size(11.0F, 14.0F);
  
  public static final Size PAPER_11X17 = new Size(11.0F, 17.0F);
  
  public static final Size PAPER_NOTE = new Size(8.5D, 11.0D);
  
  public static final Size PAPER_ENV_9 = new Size(3.875D, 8.875D);
  
  public static final Size PAPER_ENV_10 = new Size(4.125D, 9.5D);
  
  public static final Size PAPER_ENV_11 = new Size(4.5D, 10.375D);
  
  public static final Size PAPER_ENV_12 = new Size(4.75D, 11.0D);
  
  public static final Size PAPER_ENV_14 = new Size(5.0D, 11.5D);
  
  public static final Size PAPER_CSHEET = new Size(17.0F, 22.0F);
  
  public static final Size PAPER_DSHEET = new Size(22.0F, 34.0F);
  
  public static final Size PAPER_ESHEET = new Size(34.0F, 44.0F);
  
  public static final Size PAPER_ENV_DL = new Size(4.330909D, 8.661819D);
  
  public static final Size PAPER_ENV_C5 = new Size(6.378248D, 9.016166D);
  
  public static final Size PAPER_ENV_C3 = new Size(12.756497D, 18.032332D);
  
  public static final Size PAPER_ENV_C4 = new Size(9.016166D, 12.756497D);
  
  public static final Size PAPER_ENV_C6 = new Size(4.488397D, 6.378248D);
  
  public static final Size PAPER_ENV_C65 = new Size(4.488397D, 9.016166D);
  
  public static final Size PAPER_ENV_B4 = new Size(9.842976D, 13.898282D);
  
  public static final Size PAPER_ENV_B5 = new Size(6.929455D, 9.842976D);
  
  public static final Size PAPER_ENV_B6 = new Size(6.929455D, 4.921488D);
  
  public static final Size PAPER_ENV_ITALY = new Size(4.330909D, 9.055538D);
  
  public static final Size PAPER_ENV_MONARCH = new Size(3.875D, 7.5D);
  
  public static final Size PAPER_ENV_PERSONAL = new Size(3.625D, 6.5D);
  
  public static final Size PAPER_FANFOLD_US = new Size(14.875D, 11.0D);
  
  public static final Size PAPER_FANFOLD_STD_GERMAN = new Size(8.5D, 12.0D);
  
  public static final Size PAPER_FANFOLD_LGL_GERMAN = new Size(8.5D, 13.0D);
  
  public static final Size PAPER_ISO_B4 = new Size(9.84375D, 13.90625D);
  
  public static final Size PAPER_JAPANESE_POSTCARD = new Size(5.5D, 5.828125D);
  
  public static final Size PAPER_9X11 = new Size(9.0F, 11.0F);
  
  public static final Size PAPER_10X11 = new Size(10.0F, 11.0F);
  
  public static final Size PAPER_15X11 = new Size(15.0F, 11.0F);
  
  public static final Size PAPER_ENV_INVITE = new Size(8.661819D, 8.661819D);
  
  public static final Size PAPER_LETTER_EXTRA = new Size(9.5D, 12.0D);
  
  public static final Size PAPER_LEGAL_EXTRA = new Size(9.5D, 15.0D);
  
  public static final Size PAPER_TABLOID_EXTRA = new Size(11.69D, 18.0D);
  
  public static final Size PAPER_A4_EXTRA = new Size(9.24D, 12.69D);
  
  public static final Size PAPER_LETTER_TRANSVERSE = new Size(8.5D, 11.0D);
  
  public static final Size PAPER_A4_TRANSVERSE = new Size(8.5D, 11.7D);
  
  public static final Size PAPER_LETTER_EXTRA_TRANSVERSE = new Size(9.5D, 12.0D);
  
  public static final Size PAPER_A_PLUS = new Size(8.9375D, 14.0D);
  
  public static final Size PAPER_B_PLUS = new Size(12.0D, 19.171875D);
  
  public static final Size PAPER_LETTER_PLUS = new Size(8.5D, 12.69D);
  
  public static final Size PAPER_A4_PLUS = new Size(8.5D, 13.0D);
  
  public static final Size PAPER_A5_TRANSVERSE = new Size(5.8D, 8.5D);
  
  public static final Size PAPER_B5_TRANSVERSE = new Size(7.171875D, 10.125D);
  
  public static final Size PAPER_A3_EXTRA = new Size(12.6875D, 17.5D);
  
  public static final Size PAPER_A5_EXTRA = new Size(6.85D, 9.25D);
  
  public static final Size PAPER_B5_EXTRA = new Size(7.090625D, 10.859375D);
  
  public static final Size PAPER_A2 = new Size(16.5D, 23.375D);
  
  public static final Size PAPER_A3_TRANSVERSE = new Size(11.625D, 16.75D);
  
  public static final Size PAPER_A3_EXTRA_TRANSVERSE = new Size(12.6875D, 17.5D);
  
  public static final int CIRCLE = 900;
  
  public static final int TRIANGLE = 901;
  
  public static final int SQUARE = 902;
  
  public static final int CROSS = 903;
  
  public static final int STAR = 904;
  
  public static final int DIAMOND = 905;
  
  public static final int X = 906;
  
  public static final int FILLED_CIRCLE = 907;
  
  public static final int FILLED_TRIANGLE = 908;
  
  public static final int FILLED_SQUARE = 909;
  
  public static final int FILLED_DIAMOND = 910;
  
  public static final int BOX_RECTANGLE = 1;
  
  public static final int BOX_ROUNDED_RECTANGLE = 2;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\StyleConstants.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */