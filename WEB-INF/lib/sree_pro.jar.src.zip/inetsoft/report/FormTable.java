/*     */ package inetsoft.report;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormTable
/*     */   implements TableLens, StyleConstants
/*     */ {
/*     */   FormLens form;
/*     */   
/*  33 */   public FormTable(FormLens paramFormLens) { this.form = paramFormLens; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   public FormLens getForm() { return this.form; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   public int getRowCount() { return (int)Math.ceil(this.form.getFieldCount() / this.form.getFieldPerRow()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public int getColCount() { return 2 * this.form.getFieldPerRow(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public int getHeaderRowCount() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public int getHeaderColCount() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public int getRowHeight(int paramInt) { return -1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public int getColWidth(int paramInt) { return this.form.getWidth(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public Color getRowBorderColor(int paramInt1, int paramInt2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public Color getColBorderColor(int paramInt1, int paramInt2) { return Color.white; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowBorder(int paramInt1, int paramInt2) {
/* 129 */     int i = paramInt1 * this.form.getFieldPerRow() + paramInt2 / 2;
/* 130 */     return (i < this.form.getFieldCount() && paramInt1 >= 0 && paramInt2 % 2 == 1) ? this.form.getUnderline() : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public int getColBorder(int paramInt1, int paramInt2) { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public Insets getInsets(int paramInt1, int paramInt2) { return (paramInt2 % 2 == 0) ? new Insets(2, 2, 0, 4) : new Insets(2, 2, 0, 2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   public Dimension getSpan(int paramInt1, int paramInt2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   public int getAlignment(int paramInt1, int paramInt2) { return (paramInt2 % 2 == 0) ? 36 : 33; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getFont(int paramInt1, int paramInt2) {
/* 188 */     int i = paramInt1 * this.form.getFieldPerRow() + paramInt2 / 2;
/* 189 */     return (i < this.form.getFieldCount()) ? ((paramInt2 % 2 == 0) ? this.form.getLabelFont(i) : this.form.getFont(i)) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   public boolean isLineWrap(int paramInt1, int paramInt2) { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getForeground(int paramInt1, int paramInt2) {
/* 213 */     int i = paramInt1 * this.form.getFieldPerRow() + paramInt2 / 2;
/* 214 */     return (i < this.form.getFieldCount()) ? ((paramInt2 % 2 == 0) ? this.form.getLabelForeground(i) : this.form.getForeground(i)) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getBackground(int paramInt1, int paramInt2) {
/* 227 */     int i = paramInt1 * this.form.getFieldPerRow() + paramInt2 / 2;
/* 228 */     return (i < this.form.getFieldCount()) ? ((paramInt2 % 2 == 0) ? this.form.getLabelBackground(i) : this.form.getBackground(i)) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObject(int paramInt1, int paramInt2) {
/* 240 */     int i = paramInt1 * this.form.getFieldPerRow() + paramInt2 / 2;
/* 241 */     return (i < this.form.getFieldCount()) ? ((paramInt2 % 2 == 0) ? this.form.getLabel(i) : this.form.getField(i)) : null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\FormTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */