package inetsoft.report;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

public class FormTable implements TableLens, StyleConstants {
  FormLens form;
  
  public FormTable(FormLens paramFormLens) { this.form = paramFormLens; }
  
  public FormLens getForm() { return this.form; }
  
  public int getRowCount() { return (int)Math.ceil(this.form.getFieldCount() / this.form.getFieldPerRow()); }
  
  public int getColCount() { return 2 * this.form.getFieldPerRow(); }
  
  public int getHeaderRowCount() { return 0; }
  
  public int getHeaderColCount() { return 0; }
  
  public int getRowHeight(int paramInt) { return -1; }
  
  public int getColWidth(int paramInt) { return this.form.getWidth(paramInt); }
  
  public Color getRowBorderColor(int paramInt1, int paramInt2) { return Color.black; }
  
  public Color getColBorderColor(int paramInt1, int paramInt2) { return Color.white; }
  
  public int getRowBorder(int paramInt1, int paramInt2) {
    int i = paramInt1 * this.form.getFieldPerRow() + paramInt2 / 2;
    return (i < this.form.getFieldCount() && paramInt1 >= 0 && paramInt2 % 2 == 1) ? this.form.getUnderline() : 0;
  }
  
  public int getColBorder(int paramInt1, int paramInt2) { return 0; }
  
  public Insets getInsets(int paramInt1, int paramInt2) { return (paramInt2 % 2 == 0) ? new Insets(2, 2, 0, 4) : new Insets(2, 2, 0, 2); }
  
  public Dimension getSpan(int paramInt1, int paramInt2) { return null; }
  
  public int getAlignment(int paramInt1, int paramInt2) { return (paramInt2 % 2 == 0) ? 36 : 33; }
  
  public Font getFont(int paramInt1, int paramInt2) {
    int i = paramInt1 * this.form.getFieldPerRow() + paramInt2 / 2;
    return (i < this.form.getFieldCount()) ? ((paramInt2 % 2 == 0) ? this.form.getLabelFont(i) : this.form.getFont(i)) : null;
  }
  
  public boolean isLineWrap(int paramInt1, int paramInt2) { return false; }
  
  public Color getForeground(int paramInt1, int paramInt2) {
    int i = paramInt1 * this.form.getFieldPerRow() + paramInt2 / 2;
    return (i < this.form.getFieldCount()) ? ((paramInt2 % 2 == 0) ? this.form.getLabelForeground(i) : this.form.getForeground(i)) : null;
  }
  
  public Color getBackground(int paramInt1, int paramInt2) {
    int i = paramInt1 * this.form.getFieldPerRow() + paramInt2 / 2;
    return (i < this.form.getFieldCount()) ? ((paramInt2 % 2 == 0) ? this.form.getLabelBackground(i) : this.form.getBackground(i)) : null;
  }
  
  public Object getObject(int paramInt1, int paramInt2) {
    int i = paramInt1 * this.form.getFieldPerRow() + paramInt2 / 2;
    return (i < this.form.getFieldCount()) ? ((paramInt2 % 2 == 0) ? this.form.getLabel(i) : this.form.getField(i)) : null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\FormTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */