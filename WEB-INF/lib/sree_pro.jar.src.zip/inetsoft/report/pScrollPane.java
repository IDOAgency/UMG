/*     */ package inetsoft.report;
/*     */ 
/*     */ import java.awt.Adjustable;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.Scrollbar;
/*     */ import java.awt.event.AdjustmentEvent;
/*     */ import java.awt.event.AdjustmentListener;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class pScrollPane
/*     */   extends SContainer
/*     */ {
/*     */   public static final int H_SCROLL = 1;
/*     */   public static final int H_FILL = 2;
/*     */   public static final int V_SCROLL = 4;
/*     */   public static final int V_FILL = 8;
/*     */   Image buffer;
/*     */   Dimension bSize;
/*     */   int sopt;
/*     */   boolean auto;
/*     */   Dimension pSize;
/*     */   Container pnl;
/*     */   Container hscrollPanel;
/*     */   Adjustable vscroll;
/*     */   Adjustable hscroll;
/*     */   PlaceHolder placeHolder;
/*     */   Component comp;
/*     */   Dimension compSize;
/*     */   Adjustable defvscroll;
/*     */   Adjustable defhscroll;
/*     */   private ScrollListener adjListener;
/*     */   
/*     */   public pScrollPane(Component paramComponent) {
/*     */     this();
/*     */     setComponent(paramComponent);
/*     */   }
/*     */   
/*     */   public pScrollPane(Component paramComponent, boolean paramBoolean) {
/*     */     this(paramComponent);
/*     */     this.auto = paramBoolean;
/*     */   }
/*     */   
/*     */   public pScrollPane(Component paramComponent, boolean paramBoolean, int paramInt1, int paramInt2) {
/*     */     this(paramComponent, paramBoolean);
/*     */     this.pSize = new Dimension(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public void setForce(boolean paramBoolean) { this.auto = !paramBoolean; }
/*     */   
/*     */   public boolean isForce() { return !this.auto; }
/*     */   
/*     */   public void sync() {
/*     */     this.adjListener.adjustmentValueChanged(new AdjustmentEvent(this.hscroll, 601, 0, this.hscroll.getValue()));
/*     */     this.adjListener.adjustmentValueChanged(new AdjustmentEvent(this.vscroll, 601, 0, this.vscroll.getValue()));
/*     */   }
/*     */   
/*     */   public void setPreferredSize(int paramInt1, int paramInt2) { this.pSize = new Dimension(paramInt1, paramInt2); }
/*     */   
/*     */   public Component add(Component paramComponent) {
/*     */     setComponent(paramComponent);
/*     */     return paramComponent;
/*     */   }
/*     */   
/*     */   public void add(Component paramComponent, Object paramObject) { add(paramComponent); }
/*     */   
/*     */   public void setComponent(Component paramComponent) {
/*     */     this.comp = paramComponent;
/*     */     removeAll();
/*     */     this.pnl = new SContainer(true);
/*     */     this.pnl.setLayout(null);
/*     */     this.pnl.add(paramComponent);
/*     */     paramComponent.setLocation(0, 0);
/*     */     super.add(this.pnl, "Center");
/*     */     validate();
/*     */   }
/*     */   
/*     */   public Container getViewport() { return this.pnl; }
/*     */   
/*     */   public Component getComponent() { return (getComponentCount() > 0) ? getComponent(0) : null; }
/*     */   
/*     */   public void validate() {
/*     */     Dimension dimension = this.compSize;
/*     */     super.validate();
/*     */     if (this.compSize != null && (dimension == null || dimension.width != this.compSize.width || dimension.height != this.compSize.height)) {
/*     */       checkScroll();
/*     */       setValues();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getScrollOption() { return this.sopt; }
/*     */   
/*     */   public void setScrollOption(int paramInt) {
/*     */     if (paramInt != this.sopt) {
/*     */       this.sopt = paramInt;
/*     */       doLayout();
/*     */       checkScroll();
/*     */       setValues();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setUnitIncrement(int paramInt1, int paramInt2) {
/*     */     Adjustable adjustable = (paramInt1 == 0) ? this.hscroll : this.vscroll;
/*     */     if (adjustable != null)
/*     */       adjustable.setUnitIncrement(paramInt2); 
/*     */   }
/*     */   
/*     */   public void setBlockIncrement(int paramInt1, int paramInt2) {
/*     */     Adjustable adjustable = (paramInt1 == 0) ? this.hscroll : this.vscroll;
/*     */     if (adjustable != null)
/*     */       adjustable.setBlockIncrement(paramInt2); 
/*     */   }
/*     */   
/*     */   public void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*     */     super.setBounds(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     validate();
/*     */     doLayout();
/*     */     checkScroll();
/*     */     setValues();
/*     */   }
/*     */   
/*     */   public void doLayout() {
/*     */     super.doLayout();
/*     */     if (this.comp != null) {
/*     */       Dimension dimension1 = new Dimension(-1, -1);
/*     */       Dimension dimension2 = this.comp.getPreferredSize();
/*     */       for (byte b = 0; b < 3 && (dimension2.width != dimension1.width || dimension2.height != dimension1.height); b++, dimension2 = this.comp.getPreferredSize()) {
/*     */         dimension1 = dimension2;
/*     */         Point point = this.comp.getLocation();
/*     */         Dimension dimension = getViewportSize();
/*     */         if ((this.sopt & 0x2) != 0)
/*     */           dimension2.width = Math.max(dimension.width, dimension2.width + 20); 
/*     */         if ((this.sopt & 0x8) != 0)
/*     */           dimension2.height = Math.max(dimension.height, dimension2.height + 20); 
/*     */         this.comp.setBounds(point.x, point.y, dimension2.width, dimension2.height);
/*     */         this.comp.validate();
/*     */         this.compSize = this.comp.getSize();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Dimension getViewportSize() {
/*     */     Dimension dimension = getSize();
/*     */     return new Dimension(dimension.width - ((this.vscroll != null) ? (((Component)this.vscroll).getSize()).width : 0), dimension.height - ((this.hscroll != null) ? (((Component)this.hscroll).getSize()).height : 0));
/*     */   }
/*     */   
/*     */   public Adjustable getVAdjustable() { return this.defvscroll; }
/*     */   
/*     */   public Adjustable getHAdjustable() { return this.defhscroll; }
/*     */   
/*     */   public Dimension getPreferredSize() { return (this.pSize != null) ? this.pSize : ((this.comp == null) ? new Dimension(20, 20) : this.comp.getPreferredSize()); }
/*     */   
/*     */   public Adjustable createHorizontalScrollBar() { return new Scrollbar(0); }
/*     */   
/*     */   public Adjustable createVerticalScrollBar() { return new Scrollbar(1); }
/*     */   
/*     */   private void checkScroll() {
/*     */     if (this.comp == null)
/*     */       return; 
/*     */     Dimension dimension = getSize();
/*     */     boolean bool1 = true, bool2 = true, bool3 = false;
/*     */     if (this.auto) {
/*     */       int i = (this.hscroll == null) ? 0 : (((Component)this.hscroll).getSize()).height;
/*     */       int j = (this.vscroll == null) ? 0 : (((Component)this.vscroll).getSize()).width;
/*     */       bool1 = (this.compSize.height > dimension.height - i) ? 1 : 0;
/*     */       bool2 = (this.compSize.width > dimension.width - j) ? 1 : 0;
/*     */     } 
/*     */     if (!bool1 && this.vscroll != null) {
/*     */       this.comp.setLocation((this.comp.getLocation()).x, 0);
/*     */       remove((Component)this.vscroll);
/*     */       this.vscroll = null;
/*     */       bool3 = true;
/*     */     } 
/*     */     if (!bool2 && this.hscroll != null) {
/*     */       this.comp.setLocation(0, (this.comp.getLocation()).y);
/*     */       remove(this.hscrollPanel);
/*     */       this.hscroll = null;
/*     */       this.placeHolder = null;
/*     */       bool3 = true;
/*     */     } 
/*     */     if ((!bool1 || !bool2) && this.placeHolder != null) {
/*     */       this.hscrollPanel.remove(this.placeHolder);
/*     */       this.placeHolder = null;
/*     */       bool3 = true;
/*     */     } 
/*     */     if (bool1 && this.vscroll == null) {
/*     */       this.vscroll = this.defvscroll;
/*     */       this.vscroll.setUnitIncrement(18);
/*     */       this.vscroll.addAdjustmentListener(this.adjListener);
/*     */       super.add((Component)this.vscroll, "East");
/*     */       bool3 = true;
/*     */     } 
/*     */     if (bool2 && this.hscroll == null) {
/*     */       this.hscrollPanel = new SContainer();
/*     */       this.hscrollPanel.setLayout(new BorderLayout());
/*     */       this.hscroll = this.defhscroll;
/*     */       this.hscroll.setUnitIncrement(18);
/*     */       this.hscroll.addAdjustmentListener(this.adjListener);
/*     */       this.hscrollPanel.add((Component)this.hscroll, "Center");
/*     */       super.add(this.hscrollPanel, "South");
/*     */       bool3 = true;
/*     */     } 
/*     */     if (this.vscroll != null && this.hscroll != null && this.placeHolder == null) {
/*     */       this.placeHolder = new PlaceHolder(this, (((Component)this.vscroll).getPreferredSize()).width, (((Component)this.hscroll).getPreferredSize()).height);
/*     */       this.hscrollPanel.add(this.placeHolder, "East");
/*     */       bool3 = true;
/*     */     } 
/*     */     if (bool3) {
/*     */       validate();
/*     */       checkScroll();
/*     */       return;
/*     */     } 
/*     */     setValues();
/*     */   }
/*     */   
/*     */   private void setValues() {
/*     */     if (this.comp == null || (this.pnl.getSize()).width <= 0 || (this.pnl.getSize()).height <= 0)
/*     */       return; 
/*     */     Dimension dimension = getSize();
/*     */     if (this.vscroll != null) {
/*     */       this.vscroll.setValue(-(this.comp.getLocation()).y);
/*     */       this.vscroll.setVisibleAmount((this.pnl.getSize()).height);
/*     */       this.vscroll.setMinimum(0);
/*     */       this.vscroll.setMaximum(this.compSize.height);
/*     */       this.vscroll.setBlockIncrement((this.pnl.getSize()).height);
/*     */     } 
/*     */     if (this.hscroll != null) {
/*     */       this.hscroll.setValue(-(this.comp.getLocation()).x);
/*     */       this.hscroll.setVisibleAmount((this.pnl.getSize()).width);
/*     */       this.hscroll.setMinimum(0);
/*     */       this.hscroll.setMaximum(this.compSize.width);
/*     */       this.hscroll.setBlockIncrement((this.pnl.getSize()).width);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paint(Graphics paramGraphics) {
/*     */     Dimension dimension = getSize();
/*     */     if (dimension.width <= 0 || dimension.height <= 0)
/*     */       return; 
/*     */     if (dimension.width != this.bSize.width || dimension.height != this.bSize.height) {
/*     */       this.buffer = createImage(dimension.width, dimension.height);
/*     */       this.bSize = dimension;
/*     */     } 
/*     */     Graphics graphics = this.buffer.getGraphics();
/*     */     graphics.clipRect(0, 0, dimension.width, dimension.height);
/*     */     super.paint(graphics);
/*     */     graphics.dispose();
/*     */     paramGraphics.drawImage(this.buffer, 0, 0, this);
/*     */   }
/*     */   
/*     */   public pScrollPane() {
/* 471 */     this.buffer = null;
/* 472 */     this.bSize = new Dimension(-1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 499 */     this.sopt = 6;
/* 500 */     this.auto = true;
/* 501 */     this.pSize = null;
/*     */ 
/*     */     
/* 504 */     this.vscroll = null; this.hscroll = null;
/* 505 */     this.placeHolder = null;
/*     */ 
/*     */     
/* 508 */     this.defvscroll = createVerticalScrollBar();
/* 509 */     this.defhscroll = createHorizontalScrollBar();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 514 */     this.adjListener = new ScrollListener(this);
/* 515 */     setLayout(new BorderLayout()); } public void update(Graphics paramGraphics) { paint(paramGraphics); } class ScrollListener implements AdjustmentListener, Serializable { ScrollListener(pScrollPane this$0) { this.this$0 = this$0; } private final pScrollPane this$0;
/*     */     public void adjustmentValueChanged(AdjustmentEvent param1AdjustmentEvent) {
/* 517 */       Adjustable adjustable = param1AdjustmentEvent.getAdjustable();
/*     */       
/* 519 */       (new pScrollPane$1(this, adjustable)).start();
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class PlaceHolder
/*     */     extends Component
/*     */   {
/*     */     private Dimension pSize;
/*     */ 
/*     */ 
/*     */     
/*     */     private final pScrollPane this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PlaceHolder(pScrollPane this$0, int param1Int1, int param1Int2) {
/* 540 */       this.this$0 = this$0;
/* 541 */       this.pSize = new Dimension(param1Int1, param1Int2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 549 */     public Dimension getPreferredSize() { return this.pSize; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 557 */     public Dimension getMinimumSize() { return this.pSize; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\pScrollPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */