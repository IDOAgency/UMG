package inetsoft.report;

import inetsoft.report.internal.Bounds;
import inetsoft.report.internal.DefaultContext;
import inetsoft.report.internal.Util;
import inetsoft.report.lens.DefaultChartLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.Shape;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.StringTokenizer;
import java.util.Vector;

public class ChartPainter implements Painter, StyleConstants {
  private double contrast;
  
  FontMetrics fm;
  
  FontMetrics fmt;
  
  int[] xPos;
  
  Vector areas;
  
  int xInc;
  
  int yHeight;
  
  int xWidth;
  
  Point center;
  
  Point zero;
  
  double yMin;
  
  double yMax;
  
  double xMin;
  
  double xMax;
  
  double logYMax;
  
  double logYMin;
  
  double logXMax;
  
  double logXMin;
  
  double ygap;
  
  int xgap;
  
  int ggap;
  
  double maxVal;
  
  double minVal;
  
  double xmaxVal;
  
  double xminVal;
  
  int startY;
  
  Point titleOff;
  
  Rectangle legendBox;
  
  Dimension legendDim;
  
  Insets legendSpace;
  
  int legendCnt;
  
  Vector legendLabels;
  
  static final int lgap = 3;
  
  ChartLens model;
  
  ChartDescriptor desc;
  
  ReportElement context;
  
  Dimension size;
  
  Point center2;
  
  double yMin2;
  
  double yMax2;
  
  double logYMax2;
  
  double logYMin2;
  
  double maxVal2;
  
  double minVal2;
  
  Point titleOff2;
  
  int yLabelWidth2;
  
  int[] styles;
  
  Vector fLine;
  
  Vector fPoint;
  
  Vector fBar;
  
  Vector fBar3D;
  
  Vector fBar3D3D;
  
  Vector fStackBar;
  
  Vector fStackBar3D;
  
  Vector fPie;
  
  Vector fPieNoLabel;
  
  Vector fPie3D;
  
  Vector fPie3DNoLabel;
  
  Vector fStock;
  
  Vector fStick;
  
  Vector fArea;
  
  Vector fStackArea;
  
  Vector fRadar;
  
  Vector fBubble;
  
  Vector fCandle;
  
  int PRIMARYY;
  
  int SECONDARYY;
  
  int PRIMARYX;
  
  int BUBBLESIZE;
  
  double maxBubble;
  
  double minBubble;
  
  Rectangle c3D;
  
  int xShift;
  
  int yShift;
  
  public ChartPainter(ChartLens paramChartLens, ReportElement paramReportElement) { this(paramChartLens, paramReportElement, null); }
  
  public ChartPainter(ChartLens paramChartLens, ReportElement paramReportElement, ChartDescriptor paramChartDescriptor) {
    this.contrast = 0.8D;
    this.fm = null;
    this.fmt = null;
    this.areas = new Vector();
    this.ygap = 0.05D;
    this.xgap = 5;
    this.ggap = 8;
    this.startY = 0;
    this.titleOff = new Point(0, 0);
    this.legendLabels = new Vector();
    this.desc = null;
    this.size = null;
    this.titleOff2 = new Point(0, 0);
    this.yLabelWidth2 = 0;
    this.fLine = new Vector();
    this.fPoint = new Vector();
    this.fBar = new Vector();
    this.fBar3D = new Vector();
    this.fBar3D3D = new Vector();
    this.fStackBar = new Vector();
    this.fStackBar3D = new Vector();
    this.fPie = new Vector();
    this.fPieNoLabel = new Vector();
    this.fPie3D = new Vector();
    this.fPie3DNoLabel = new Vector();
    this.fStock = new Vector();
    this.fStick = new Vector();
    this.fArea = new Vector();
    this.fStackArea = new Vector();
    this.fRadar = new Vector();
    this.fBubble = new Vector();
    this.fCandle = new Vector();
    this.PRIMARYY = 1;
    this.SECONDARYY = 2;
    this.PRIMARYX = 3;
    this.BUBBLESIZE = 4;
    this.c3D = null;
    this.xShift = 0;
    this.yShift = 0;
    this.model = paramChartLens;
    this.context = paramReportElement;
    this.desc = paramChartDescriptor;
    if (this.desc == null)
      this.desc = new ChartDescriptor(); 
  }
  
  public ChartLens getChart() { return this.model; }
  
  public ChartDescriptor getChartDescriptor() { return this.desc; }
  
  private int getDatasetRange() {
    if (this.desc != null && this.desc.getFirstDatasetOfSecondaryAxis() != -1)
      return Math.min(this.model.getDatasetCount(), this.desc.getFirstDatasetOfSecondaryAxis()); 
    return this.model.getDatasetCount();
  }
  
  private void getStyles() {
    int i = this.model.getDatasetCount();
    this.styles = new int[i];
    boolean bool = false;
    this.fLine.removeAllElements();
    this.fPoint.removeAllElements();
    this.fBar.removeAllElements();
    this.fBar3D.removeAllElements();
    this.fBar3D3D.removeAllElements();
    this.fStackBar.removeAllElements();
    this.fStackBar3D.removeAllElements();
    this.fPie.removeAllElements();
    this.fPieNoLabel.removeAllElements();
    this.fPie3D.removeAllElements();
    this.fPie3DNoLabel.removeAllElements();
    this.fStock.removeAllElements();
    this.fStick.removeAllElements();
    this.fArea.removeAllElements();
    this.fStackArea.removeAllElements();
    this.fRadar.removeAllElements();
    this.fBubble.removeAllElements();
    this.fCandle.removeAllElements();
    for (byte b = 0; b < i; b++) {
      this.styles[b] = (this.model.getStyle(b) != 0) ? this.model.getStyle(b) : this.model.getStyle();
      switch (this.styles[b]) {
        case 5634:
          if (b == 0 && i > 1)
            break; 
        case 5122:
        case 5378:
          this.fLine.addElement(new Integer(b));
          break;
        case 5636:
          if (b == 0 && i > 1)
            break; 
        case 5124:
        case 5380:
          this.fPoint.addElement(new Integer(b));
          break;
        case 1:
        case 257:
          this.fBar.addElement(new Integer(b));
          break;
        case 5:
          this.fBar3D.addElement(new Integer(b));
          break;
        case 9:
          this.fBar3D3D.addElement(new Integer(b));
          break;
        case 3:
        case 259:
          this.fStackBar.addElement(new Integer(b));
          break;
        case 7:
          this.fStackBar3D.addElement(new Integer(b));
          break;
        case 6:
          this.fPie.addElement(new Integer(b));
          break;
        case 8198:
          this.fPieNoLabel.addElement(new Integer(b));
          break;
        case 8:
          this.fPie3D.addElement(new Integer(b));
          break;
        case 8200:
          this.fPie3DNoLabel.addElement(new Integer(b));
          break;
        case 4106:
          this.fStock.addElement(new Integer(b));
          break;
        case 4107:
          this.fStick.addElement(new Integer(b));
          break;
        case 12:
          this.fArea.addElement(new Integer(b));
          break;
        case 14:
          this.fStackArea.addElement(new Integer(b));
          break;
        case 18:
        case 1041:
          this.fRadar.addElement(new Integer(b));
          break;
        case 528:
          if (b == 0 && this.model.getDatasetCount() % 2 == 1)
            break; 
          bool = true;
          this.fBubble.addElement(new Integer(b));
          break;
        case 20:
          this.fCandle.addElement(new Integer(b));
          break;
        default:
          System.err.println("Invalid Chart Type: " + this.styles[b]);
          System.err.println("You may need to recompile your program.");
          return;
      } 
    } 
    if (isXScaled())
      this.startY = 1; 
    if (bool && this.fBubble.size() < 1) {
      System.err.println("Error: Bubble chart need at least two datasets");
      return;
    } 
  }
  
  private double[] calcMaxMin(int paramInt) {
    int k, j;
    double[] arrayOfDouble = new double[2];
    arrayOfDouble[1] = 0.0D;
    arrayOfDouble[0] = 0.0D;
    boolean bool1 = true;
    boolean bool2 = false;
    int i = this.fBubble.isEmpty() ? 1 : 2;
    if (paramInt == this.BUBBLESIZE) {
      if (this.model.getDatasetCount() % 2 == 1) {
        j = 2;
      } else {
        j = 1;
      } 
      k = this.model.getDatasetCount();
    } else if (paramInt == this.PRIMARYY) {
      j = this.startY;
      k = getDatasetRange();
    } else {
      j = this.desc.getFirstDatasetOfSecondaryAxis();
      k = this.model.getDatasetCount();
    } 
    for (byte b = 0; b < this.model.getDatasetSize(); b++) {
      double d1 = 0.0D, d2 = 0.0D;
      for (int m = j; m < k; m += i) {
        Number number = this.model.getData(m, b);
        double d = (number == null) ? 0.0D : number.doubleValue();
        if (isStack(this.styles[m])) {
          if (d > 0.0D) {
            d1 += d;
          } else {
            d2 += d;
          } 
          bool2 = true;
        } else {
          if (bool1 || d > arrayOfDouble[1])
            arrayOfDouble[1] = d; 
          if (bool1 || d < arrayOfDouble[0])
            arrayOfDouble[0] = d; 
          bool1 = false;
        } 
      } 
      if (bool2) {
        if (d1 > arrayOfDouble[1])
          arrayOfDouble[1] = d1; 
        if (d2 != 0.0D && d2 < arrayOfDouble[0]) {
          arrayOfDouble[0] = d2;
        } else if (d1 < arrayOfDouble[0]) {
          arrayOfDouble[0] = d1;
        } 
      } 
    } 
    return arrayOfDouble;
  }
  
  private void calcRange() {
    if (getDatasetRange() <= 0) {
      this.maxVal = (this.model.getMaximum() == null) ? 1.0D : this.model.getMaximum().doubleValue();
      this.minVal = 0.0D;
      return;
    } 
    double[] arrayOfDouble = calcMaxMin(this.PRIMARYY);
    this.minVal = (this.model.getStyle() == 528 && arrayOfDouble[0] != 0.0D) ? (arrayOfDouble[0] - (arrayOfDouble[1] - arrayOfDouble[0]) / 3.0D) : arrayOfDouble[0];
    this.maxVal = (this.model.getStyle() == 528) ? (arrayOfDouble[1] + (arrayOfDouble[1] - arrayOfDouble[0]) / 3.0D) : arrayOfDouble[1];
    if (this.model.getMaximum() != null)
      this.maxVal = this.model.getMaximum().doubleValue(); 
    if (this.model.getMinimum() != null) {
      this.minVal = this.model.getMinimum().doubleValue();
    } else if (this.fStock.size() != 0 || this.fCandle.size() != 0) {
      this.minVal = this.desc.isLogarithmicYScale() ? 1.0D : 0.0D;
    } else {
      this.minVal = (this.desc.isLogarithmicYScale() && this.minVal == 0.0D) ? 1.0D : Math.min(this.minVal, (int)(this.maxVal / 2.0D));
    } 
    if (this.desc.isLogarithmicYScale() && this.minVal <= 0.0D) {
      System.err.println("Error: Negative or zero values cannot be plotted correctly on log chart for primary axis");
      return;
    } 
    this.maxVal = (this.maxVal == 0.0D) ? 1.0D : this.maxVal;
  }
  
  private void calcRange2() {
    if (this.model.getDatasetCount() <= 0) {
      this.maxVal2 = (this.desc.getSecondaryMaximum() == null) ? 1.0D : this.desc.getSecondaryMaximum().doubleValue();
      this.minVal2 = 0.0D;
      return;
    } 
    if (this.desc.getFirstDatasetOfSecondaryAxis() >= this.model.getDatasetCount()) {
      this.maxVal2 = this.maxVal;
      this.minVal2 = this.minVal;
      return;
    } 
    double[] arrayOfDouble = calcMaxMin(this.SECONDARYY);
    this.minVal2 = (this.model.getStyle() == 528 && arrayOfDouble[0] != 0.0D) ? (arrayOfDouble[0] - (arrayOfDouble[1] - arrayOfDouble[0]) / 3.0D) : arrayOfDouble[0];
    this.maxVal2 = (this.model.getStyle() == 528) ? (arrayOfDouble[1] + (arrayOfDouble[1] - arrayOfDouble[0]) / 3.0D) : arrayOfDouble[1];
    if (this.desc.getSecondaryMaximum() != null)
      this.maxVal2 = this.desc.getSecondaryMaximum().doubleValue(); 
    if (this.desc.getSecondaryMinimum() != null) {
      this.minVal2 = this.desc.getSecondaryMinimum().doubleValue();
    } else if (this.fStock.size() != 0 || this.fCandle.size() != 0) {
      this.minVal2 = this.desc.isSecondaryLogarithmicYScale() ? 1.0D : 0.0D;
    } else {
      this.minVal2 = (this.desc.isSecondaryLogarithmicYScale() && this.minVal2 == 0.0D) ? 1.0D : Math.min(this.minVal2, (int)(this.maxVal2 / 2.0D));
    } 
    if (this.desc.isSecondaryLogarithmicYScale() && this.minVal2 <= 0.0D) {
      System.err.println("Error: Negative or zero values cannot be plotted correctly on log chart");
      return;
    } 
    this.maxVal2 = (this.maxVal2 == 0.0D) ? 1.0D : this.maxVal2;
    if (this.model.getMaximum() == null && this.desc.getSecondaryMaximum() == null)
      if ((this.maxVal / this.maxVal2 <= 1.2D && this.maxVal2 / this.maxVal <= 1.2D) || Math.abs(this.maxVal - this.maxVal2) / Math.min(this.maxVal - this.minVal, this.maxVal2 - this.minVal2) < 0.1D)
        this.maxVal = this.maxVal2 = Math.max(this.maxVal, this.maxVal2);  
    if (this.model.getMinimum() == null && this.desc.getSecondaryMinimum() == null && this.minVal * this.minVal2 > 0.0D)
      if ((this.minVal / this.minVal2 <= 1.2D && this.minVal2 / this.minVal <= 1.2D) || Math.abs(this.minVal - this.minVal2) / Math.min(this.maxVal - this.minVal, this.maxVal2 - this.minVal2) < 0.1D)
        this.minVal = this.minVal2 = Math.min(this.minVal, this.minVal2);  
  }
  
  private void calcXRange() {
    this.xmaxVal = this.xminVal = 0.0D;
    boolean bool1 = true;
    boolean bool2 = false;
  }
  
  private void calcBubbleRange() {
    double[] arrayOfDouble = calcMaxMin(this.BUBBLESIZE);
    this.minBubble = arrayOfDouble[0];
    this.maxBubble = arrayOfDouble[1];
    this.maxBubble = (this.maxBubble == 0.0D) ? 1.0D : this.maxBubble;
  }
  
  private void doLayout() {
    Dimension dimension = getSize();
    if (this.fm == null || this.model.getDatasetCount() == 0 || this.model.getDatasetSize() == 0 || dimension.width <= 0 || dimension.height <= 0)
      return; 
    calcRange();
    if (isXScaled())
      calcXRange(); 
    if (!this.fBubble.isEmpty())
      calcBubbleRange(); 
    if (this.desc.getFirstDatasetOfSecondaryAxis() != -1)
      calcRange2(); 
    this.legendBox = new Rectangle();
    this.legendDim = new Dimension();
    if (this.model.getLegendPosition() != 0) {
      int k = this.model.getLegendPosition();
      boolean bool = (k == 1 || k == 4) ? 1 : 0;
      int m = 0;
      int n = (int)Common.getHeight(this.context.getFont(), null);
      if (Util.isFlatDatasetChart(this.model)) {
        this.legendCnt = this.model.getDatasetSize();
        this.legendLabels.setSize(this.legendCnt);
        for (byte b1 = 0; b1 < this.legendCnt; b1++)
          this.legendLabels.setElementAt(this.model.getLabel(b1), b1); 
      } else {
        int i3 = this.model.getDatasetCount() - this.startY;
        this.legendCnt = this.fBubble.isEmpty() ? i3 : (i3 / 2);
        int i4 = this.fBubble.isEmpty() ? 1 : 2;
        this.legendLabels.setSize(this.legendCnt);
        int i5;
        byte b1;
        for (i5 = this.startY, b1 = 0; i5 < i3 + this.startY; i5 += i4, b1++)
          this.legendLabels.setElementAt(this.model.getDatasetLabel(i5), b1); 
      } 
      for (byte b = 0; b < this.legendCnt; b++) {
        String str = (String)this.legendLabels.elementAt(b);
        m = Math.max(m, (int)Common.stringWidth(str, this.context.getFont()));
      } 
      m += 3 * this.ggap;
      m = Math.min(m, (bool ? (dimension.width / 2) : dimension.width) - 40);
      int i1 = this.desc.getFirstDatasetOfSecondaryAxis();
      int i2 = this.legendCnt;
      if (i1 != -1 && i1 >= 0 && i1 < this.model.getDatasetCount()) {
        m = Math.max(m, (int)Common.stringWidth("Secondary Y: ", this.context.getFont()));
        i2 = this.legendCnt + 2;
      } 
      if (bool) {
        int i3 = dimension.height - 2 * this.ggap;
        byte b1;
        for (b1 = 0; b1 < i2; b1++) {
          i3 -= n;
          if (i3 < n)
            break; 
        } 
        if (i3 >= n) {
          this.legendDim.width = 1;
          this.legendDim.height = i2;
          if (k == 1) {
            this.legendBox = new Rectangle(this.ggap, i3 / 2 + this.ggap, m, dimension.height - i3 - 2 * this.ggap);
          } else {
            this.legendBox = new Rectangle(dimension.width - m - this.ggap, i3 / 2 + this.ggap, m, dimension.height - i3 - 2 * this.ggap);
          } 
        } else {
          this.legendDim.height = b1;
          this.legendDim.width = (int)Math.ceil(i2 / b1);
          this.legendBox = new Rectangle(this.ggap, this.ggap, m * this.legendDim.width, dimension.height - 2 * this.ggap);
          if (k == 4)
            this.legendBox.x = dimension.width - this.legendBox.width - 2 * this.ggap; 
        } 
      } else {
        int i3 = dimension.width - 2 * this.ggap;
        byte b1;
        for (b1 = 0; b1 < i2 && i3 >= m; b1++)
          i3 -= m; 
        if (i3 >= m) {
          this.legendDim.height = 1;
          this.legendDim.width = i2;
          if (k == 8) {
            this.legendBox = new Rectangle(i3 / 2 + this.ggap, this.ggap, dimension.width - i3 - 2 * this.ggap, n + this.ggap);
          } else {
            this.legendBox = new Rectangle(i3 / 2 + this.ggap, dimension.height - n - 2 * this.ggap, dimension.width - i3 - 2 * this.ggap, n + this.ggap);
          } 
        } else {
          this.legendDim.width = b1;
          this.legendDim.height = (int)Math.ceil(i2 / b1);
          this.legendBox = new Rectangle(this.ggap, this.ggap, m * this.legendDim.width, n * this.legendDim.height + this.ggap);
          if (k == 32)
            this.legendBox.y = dimension.height - this.legendBox.height - 2 * this.ggap; 
        } 
        this.legendBox.x = (dimension.width - this.legendBox.width) / 2;
      } 
      switch (k) {
        case 1:
          this.legendSpace = new Insets(0, this.legendBox.x + this.legendBox.width, 0, 0);
          break;
        case 4:
          this.legendSpace = new Insets(0, 0, 0, dimension.width - this.legendBox.x);
          break;
        case 8:
          this.legendSpace = new Insets(this.legendBox.y + this.legendBox.height, 0, 0, 0);
          break;
        case 32:
          this.legendSpace = new Insets(0, 0, dimension.height - this.legendBox.y, 0);
          break;
      } 
    } else {
      this.legendSpace = new Insets(0, 0, 0, 0);
    } 
    String str1 = isInverted() ? this.model.getXTitle() : this.model.getYTitle();
    String str2 = isInverted() ? this.model.getYTitle() : this.model.getXTitle();
    String str3 = this.desc.getSecondaryYTitle();
    Font font = this.model.getTitleFont();
    if (font == null)
      font = this.context.getFont(); 
    FontMetrics fontMetrics = Common.getFontMetrics(font);
    this.titleOff = new Point(0, (str2 == null || str2.length() == 0) ? 0 : (fontMetrics.getHeight() + this.ggap));
    double d1 = (this.desc != null) ? this.desc.getXLabelRotation() : 0.0D;
    if (d1 != 0.0D) {
      int k = 0;
      for (byte b = 0; b < this.model.getDatasetSize(); b++)
        k = (int)Math.max(Common.stringWidth(this.model.getLabel(b), font, fontMetrics), k); 
      this.titleOff.y = (int)(k * Math.sin(d1)) + this.ggap;
    } 
    if (str1 != null && str1.length() > 0) {
      StringTokenizer stringTokenizer = new StringTokenizer(str1);
      int k = 0;
      while (stringTokenizer.hasMoreElements())
        k = Math.max(k, (int)Common.stringWidth(stringTokenizer.nextElement().toString(), font, fontMetrics)); 
      this.titleOff.x = k + 2 * this.ggap;
    } 
    if (str3 != null && str3.length() > 0)
      if (isInverted()) {
        this.titleOff2.y = fontMetrics.getHeight() + 2 * this.ggap;
      } else {
        StringTokenizer stringTokenizer = new StringTokenizer(str3);
        int k = 0;
        while (stringTokenizer.hasMoreElements())
          k = Math.max(k, (int)Common.stringWidth(stringTokenizer.nextElement().toString(), font, fontMetrics)); 
        this.titleOff2.x = k + 2 * this.ggap;
      }  
    NumberFormat numberFormat1 = this.desc.getYAxisFormat();
    NumberFormat numberFormat2 = this.desc.getXAxisFormat();
    String str4 = (numberFormat1 != null) ? numberFormat1.format(new Double(this.maxVal)) : toString(new Double(this.maxVal));
    String str5 = (numberFormat1 != null) ? numberFormat1.format(new Double(this.minVal)) : toString(new Double(this.minVal));
    String str6 = (numberFormat2 != null) ? numberFormat2.format(new Double(this.xmaxVal)) : toString(new Double(this.xmaxVal));
    String str7 = (numberFormat2 != null) ? numberFormat2.format(new Double(this.xminVal)) : toString(new Double(this.xminVal));
    int i = 0;
    if (isInverted()) {
      if (isXScaled()) {
        i = Math.max(this.fm.stringWidth(str6), this.fm.stringWidth(str7)) + this.fm.charWidth('M') + this.xgap;
      } else {
        for (byte b = 0; b < this.model.getDatasetSize(); b++) {
          String str = this.model.getLabel(b);
          str = (str == null) ? "" : str;
          i = Math.max(i, this.fm.stringWidth(str) + this.fm.charWidth('M') + this.xgap);
        } 
      } 
    } else {
      i = Math.max(this.fm.stringWidth(str4), this.fm.stringWidth(str5)) + this.fm.charWidth('M') + this.xgap;
      NumberFormat numberFormat = this.desc.getSecondaryYAxisFormat();
      String str9 = (numberFormat != null) ? numberFormat.format(new Double(this.maxVal2)) : toString(new Double(this.maxVal2));
      String str10 = (numberFormat != null) ? numberFormat.format(new Double(this.minVal2)) : toString(new Double(this.minVal2));
      this.yLabelWidth2 = Math.max(this.fm.stringWidth(str9), this.fm.stringWidth(str10)) + this.fm.charWidth('M') + this.xgap;
    } 
    String str8 = this.model.getLabel(this.model.getDatasetSize() - 1);
    int j = i + this.ggap + this.xgap + this.titleOff.x + this.legendSpace.left;
    this.xWidth = dimension.width - j - this.ggap - this.legendSpace.right;
    if (this.desc.getFirstDatasetOfSecondaryAxis() != -1)
      this.xWidth -= this.yLabelWidth2 + this.titleOff2.x + this.xgap; 
    if (str8 != null)
      this.xWidth -= ((d1 == 0.0D) ? (this.fm.stringWidth(str8) / 2) : (int)(this.fm.stringWidth(str8) * Math.cos(d1))); 
    this.center = new Point(j - this.xgap, dimension.height - this.fm.getHeight() - this.ggap - this.titleOff.y - this.legendSpace.bottom);
    this.yHeight = this.center.y - this.ggap - this.legendSpace.top - (this.model.isShowValue() ? this.fm.getHeight() : 0);
    if (this.desc.getFirstDatasetOfSecondaryAxis() != -1 && isInverted() && str3 != null && str3.length() > 0)
      this.yHeight -= this.titleOff2.y; 
    if (!isXScaled()) {
      int k = (this.fBar3D3D.size() != 0 || this.fStackBar3D.size() != 0 || this.fBar3D.size() != 0) ? 1 : 0;
      if (this.fBar3D3D.size() != 0)
        k += this.fBar3D3D.size() / 4; 
      int m = this.model.getDatasetSize();
      if (this.fBar.size() != 0 || this.fBar3D.size() != 0 || this.fStick.size() != 0) {
        int i3 = this.fBar.size() + this.fBar3D.size() + this.fStick.size();
        i3 += ((this.fBar3D3D.size() != 0 || this.fStackBar.size() != 0 || this.fStackBar3D.size() != 0) ? 1 : 0);
        m = m * i3 + 1;
      } else if (this.fBar3D3D.size() != 0 || this.fStackBar.size() != 0 || this.fStackBar3D.size() != 0 || this.fCandle.size() != 0) {
        m++;
      } else if (this.fBubble.size() != 0) {
        m += 2;
      } 
      k += m;
      this.xInc = Math.max(this.xWidth / Math.max(k - 1, 1), 1);
      this.xWidth = isInverted() ? this.xWidth : (this.xInc * m);
      if (this.fBar3D3D.size() != 0) {
        int i3 = this.yHeight - (this.fBar3D3D.size() + 1) * this.xInc / 4;
        if (i3 < 50) {
          this.xInc = (this.yHeight - 50) * 4 / (this.fBar3D3D.size() + 1);
          this.yHeight = 50;
        } else {
          this.yHeight = i3;
        } 
      } else if (this.fBar3D.size() != 0 || this.fStackBar3D.size() != 0) {
        this.yHeight -= this.xInc / 2;
      } 
      int n = 1;
      if (isInverted()) {
        int i3 = this.xWidth;
        this.xWidth = this.yHeight;
        this.yHeight = i3 - (this.model.isShowValue() ? (Math.max(this.fm.stringWidth(str4), this.fm.stringWidth(str5)) + this.fm.charWidth('M') - this.fm.getHeight()) : 0);
        this.xInc = Math.max(this.xWidth / Math.max(k - 1, 1), 1);
        this.xWidth = this.xInc * m;
        j = this.center.y - this.xgap;
        n = -1;
      } 
      int i1 = (this.fBubble.size() == 0) ? 0 : 1;
      this.xPos = new int[m - i1];
      for (int i2 = 0; i2 < m - i1; i2++)
        this.xPos[i2] = j + n * this.xWidth * (i2 + i1) / m; 
      if (isInverted()) {
        this.center2 = new Point(this.center.x, this.xPos[this.xPos.length - 1] - this.xgap);
      } else if (this.fBar3D.size() != 0 || this.fStackBar3D.size() != 0 || this.fBar3D3D.size() != 0) {
        int i3 = ((this.fBar3D3D.size() != 0) ? this.fBar3D3D.size() : 1) + 1;
        this.center2 = new Point(this.xPos[this.xPos.length - 1] + this.xgap + i3 * this.xInc / 4, this.center.y - i3 * this.xInc / 4);
      } else {
        this.center2 = new Point(this.xPos[this.xPos.length - 1] + this.xgap, this.center.y);
      } 
    } else if (isInverted()) {
      int k = this.xWidth;
      this.xWidth = this.yHeight;
      this.yHeight = k - (this.model.isShowValue() ? (Math.max(this.fm.stringWidth(str4), this.fm.stringWidth(str5)) + this.fm.charWidth('M') - this.fm.getHeight()) : 0);
      this.center2 = new Point(this.center.x, this.center.y - this.yHeight);
    } else {
      this.center2 = new Point(this.center.x + this.xWidth, this.center.y);
    } 
    double d2 = (this.maxVal - this.minVal) * this.ygap;
    if (this.desc.isLogarithmicYScale()) {
      this.yMax = adjustLogVal(this.maxVal, true) + d2;
      this.yMin = adjustLogVal(this.minVal, false);
      if (this.yMax - this.yMin < 10.0D)
        this.yMax = this.yMin + 10.0D; 
      this.logYMax = log(this.yMax);
      this.logYMin = log(this.yMin);
      if (this.logYMin == this.logYMax)
        this.logYMax = this.logYMin + 1.0D; 
    } else {
      this.yMin = (this.minVal > 0.0D) ? (this.minVal - d2) : this.minVal;
      this.yMax = this.maxVal + d2;
      if (this.yMin == this.yMax)
        this.yMax = this.yMin + 1.0D; 
    } 
    if (isXScaled()) {
      double d = (this.xmaxVal - this.xminVal) * this.ygap;
      if (this.desc.isLogarithmicXScale()) {
        this.xMax = adjustLogVal(this.xmaxVal, true) + d;
        this.xMin = adjustLogVal(this.xminVal, false);
        if (this.xMax - this.xMin < 10.0D)
          this.xMax = this.xMin + 10.0D; 
        this.logXMax = log(this.xMax);
        this.logXMin = log(this.xMin);
        if (this.logXMin == this.logXMax)
          this.logXMax = this.logXMin + 1.0D; 
      } else {
        this.xMin = (this.xminVal > 0.0D) ? (this.xminVal - d) : this.xminVal;
        this.xMax = this.xmaxVal + d;
        if (this.xMin == this.xMax)
          this.xMax = this.xMin + 1.0D; 
      } 
    } 
    if (this.desc.getFirstDatasetOfSecondaryAxis() != -1) {
      d2 = (this.maxVal2 - this.minVal2) * this.ygap;
      if (this.desc.isSecondaryLogarithmicYScale()) {
        this.yMax2 = adjustLogVal(this.maxVal2, true) + d2;
        this.yMin2 = adjustLogVal(this.minVal2, false);
        if (this.yMax2 - this.yMin2 < 10.0D)
          this.yMax2 = this.yMin2 + 10.0D; 
        this.logYMax2 = log(this.yMax2);
        this.logYMin2 = log(this.yMin2);
        if (this.logYMin2 == this.logYMax2)
          this.logYMax2 = this.logYMin2 + 1.0D; 
      } else {
        this.yMin2 = (this.minVal2 > 0.0D) ? (this.minVal2 - d2) : this.minVal2;
        this.yMax2 = this.maxVal2 + d2;
        if (this.yMin2 == this.yMax2)
          this.yMax2 = this.yMin2 + 1.0D; 
      } 
    } 
    if (isInverted()) {
      if (this.desc.isLogarithmicYScale()) {
        this.zero = (this.logYMin >= 0.0D) ? new Point(this.center) : new Point(translate(new Integer(1), -2), this.center.y);
      } else {
        this.zero = (this.yMin >= 0.0D) ? new Point(this.center) : new Point(translate(new Integer(0), -2), this.center.y);
      } 
      if (isXScaled() && (this.xMin < 0.0D || (this.desc.isLogarithmicXScale() && this.logXMin < 0.0D)))
        this.zero.y = this.desc.isLogarithmicXScale() ? translateX(new Integer(1)) : translateX(new Integer(0)); 
    } else {
      if (this.desc.isLogarithmicYScale()) {
        this.zero = (this.logYMin >= 0.0D) ? new Point(this.center) : new Point(this.center.x, translate(new Integer(1), -2));
      } else {
        this.zero = (this.yMin >= 0.0D) ? new Point(this.center) : new Point(this.center.x, translate(new Integer(0), -2));
      } 
      if (isXScaled() && (this.xMin < 0.0D || (this.desc.isLogarithmicXScale() && this.logXMin < 0.0D)))
        this.zero.x = this.desc.isLogarithmicXScale() ? translateX(new Integer(1)) : translateX(new Integer(0)); 
    } 
  }
  
  protected double adjustLogVal(double paramDouble, boolean paramBoolean) {
    double d = 1.0D;
    int i = paramBoolean ? (int)Math.ceil(log(paramDouble)) : (int)Math.floor(log(paramDouble));
    if (i > 0) {
      for (byte b = 0; b < i; b++)
        d *= 10.0D; 
    } else {
      for (byte b = 0; b < -i; b++)
        d /= 10.0D; 
    } 
    return d;
  }
  
  protected int translate(Number paramNumber, int paramInt) {
    double d1 = (paramNumber == null) ? 0.0D : paramNumber.doubleValue();
    double d2 = isInverted() ? -1.0D : 1.0D;
    if (this.desc.getFirstDatasetOfSecondaryAxis() != -1 && paramInt >= this.desc.getFirstDatasetOfSecondaryAxis()) {
      int j = isInverted() ? this.center2.x : this.center2.y;
      d2 *= (this.desc.isSecondaryLogarithmicYScale() ? ((log(d1) - this.logYMin2) / (this.logYMax2 - this.logYMin2)) : ((d1 - this.yMin2) / (this.yMax2 - this.yMin2)));
      return (int)(j - d2 * this.yHeight);
    } 
    int i = isInverted() ? this.center.x : this.center.y;
    d2 *= (this.desc.isLogarithmicYScale() ? ((log(d1) - this.logYMin) / (this.logYMax - this.logYMin)) : ((d1 - this.yMin) / (this.yMax - this.yMin)));
    return (int)(i - d2 * this.yHeight);
  }
  
  protected int translateX(Number paramNumber) {
    double d1 = (paramNumber == null) ? 0.0D : paramNumber.doubleValue();
    double d2 = isInverted() ? -1.0D : 1.0D;
    int i = isInverted() ? this.center.y : this.center.x;
    d2 *= (this.desc.isLogarithmicXScale() ? ((log(d1) - this.logXMin) / (this.logXMax - this.logXMin)) : ((d1 - this.xMin) / (this.xMax - this.xMin)));
    return (int)(i + d2 * this.xWidth);
  }
  
  protected int translateB(Number paramNumber) {
    double d = (paramNumber == null) ? 0.0D : paramNumber.doubleValue();
    return (int)((d - this.minBubble) / (this.maxBubble - this.minBubble) * Math.min(this.xWidth / 3.0D, this.yHeight / 3.0D)) + 6;
  }
  
  protected double translateL(Number paramNumber) {
    double d = (paramNumber == null) ? 0.0D : paramNumber.doubleValue();
    return this.yHeight * (this.desc.isLogarithmicXScale() ? ((log(d) - this.logYMin) / (this.logYMax - this.logYMin)) : ((d - this.yMin) / (this.yMax - this.yMin)));
  }
  
  private void paintCoord1(Graphics paramGraphics) {
    float f = Common.getLineAdjustment(paramGraphics);
    if (isXScaled()) {
      Common.drawHLine(paramGraphics, this.zero.y + f, this.center.x, (this.center.x + this.xWidth), 4097, 0, 0);
    } else {
      Common.drawHLine(paramGraphics, this.zero.y + f, this.center.x, (this.xPos[this.xPos.length - 1] + this.xgap), 4097, 0, 0);
    } 
    Common.drawVLine(paramGraphics, this.zero.x + f, this.center.y, (this.center.y - this.yHeight), 4097, 0, 0);
    String str1 = this.model.getXTitle();
    String str2 = this.model.getYTitle();
    if (this.model.getTitleFont() != null) {
      paramGraphics.setFont(this.model.getTitleFont());
    } else {
      paramGraphics.setFont(this.context.getFont());
    } 
    if (str1 != null)
      Common.drawString(paramGraphics, str1, ((this.xWidth - this.fm.stringWidth(str1)) / 2 + this.center.x), ((getSize()).height - this.fm.getHeight() - this.legendSpace.bottom + this.fm.getDescent())); 
    if (str2 != null) {
      Bounds bounds = new Bounds((this.legendSpace.left + this.ggap), (this.center.y - this.yHeight), this.titleOff.x, this.yHeight);
      Common.paintText(paramGraphics, str2, bounds, 18, true, false, 0);
    } 
    paramGraphics.setFont(this.context.getFont());
    if (!isXScaled() && (this.fBar3D.size() != 0 || this.fStackBar3D.size() != 0 || this.fBar3D3D.size() != 0)) {
      int i = ((this.fBar3D3D.size() != 0) ? this.fBar3D3D.size() : 1) + 1;
      this.c3D = new Rectangle(this.center.x + i * this.xInc / 4, this.center.y - this.yHeight + i * this.xInc / 4, this.xPos[this.xPos.length - 1] + this.xgap - this.center.x, this.yHeight);
      this.xShift = this.c3D.x - this.center.x;
      this.yShift = this.center.y - this.c3D.y - this.yHeight;
      int[] arrayOfInt1 = { this.zero.x, this.c3D.x, this.c3D.x + this.c3D.width, this.zero.x + this.c3D.width };
      int[] arrayOfInt2 = { this.zero.y, this.zero.y - this.yShift, this.zero.y - this.yShift, this.zero.y };
      paramGraphics.drawPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length);
      Color color = this.context.getBackground();
      if (color == null)
        color = Color.white; 
      paramGraphics.setColor((Color)darker(color));
      paramGraphics.fillPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length);
      paramGraphics.setColor(this.context.getForeground());
      Common.drawLine(paramGraphics, this.center.x, (this.center.y - this.c3D.height), this.c3D.x, this.c3D.y);
      paramGraphics.drawRect(this.c3D.x, this.c3D.y, this.c3D.width, this.c3D.height);
    } 
    if (this.desc.getVerticalGridStyle() != 0)
      if (isXScaled()) {
        paintGrid(paramGraphics, this.xMax, this.xMin, this.PRIMARYX, 0, 0, null);
      } else {
        byte b;
        int i;
        for (b = 0, i = 0; b < this.model.getDatasetSize(); b++) {
          int j;
          if (this.fBar3D.size() != 0 || this.fBar.size() != 0 || this.fStick.size() != 0) {
            j = i + this.fBar3D.size() + this.fBar.size() + this.fStick.size();
            j += ((this.fStackBar.size() != 0 || this.fBar3D3D.size() != 0 || this.fStackBar3D.size() != 0) ? 1 : 0);
          } else {
            j = i + 1;
          } 
          int k = this.xPos[i];
          if (this.fBar.size() != 0 || this.fBar3D.size() != 0 || this.fStackBar.size() != 0 || this.fStackBar3D.size() != 0 || this.fBar3D3D.size() != 0 || this.fCandle.size() != 0)
            k = this.xPos[i] + this.xInc * (j - i) / 2; 
          if (k != this.zero.x)
            if (this.c3D != null) {
              Common.drawVLine(paramGraphics, (k + this.xShift) + f, this.c3D.y, (this.c3D.y + this.c3D.height), this.desc.getVerticalGridStyle(), 0, 0);
            } else {
              Common.drawVLine(paramGraphics, k + f, this.center.y, (this.center.y - this.yHeight), this.desc.getVerticalGridStyle(), 0, 0);
            }  
          i = j;
        } 
      }  
    if (this.model.getGridStyle() != 0)
      paintGrid(paramGraphics, this.yMax, this.yMin, this.PRIMARYY, this.xShift, this.yShift, this.c3D); 
    if (this.desc.getFirstDatasetOfSecondaryAxis() != -1)
      paintSecondaryYAxis(paramGraphics, this.xShift, this.yShift); 
    paramGraphics.setFont(this.context.getFont());
  }
  
  private void paintGrid(Graphics paramGraphics, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, int paramInt3, Rectangle paramRectangle) {
    float f = Common.getLineAdjustment(paramGraphics);
    Number number1 = null, number2 = null;
    if (paramInt1 == this.PRIMARYY) {
      number1 = this.model.getMinimum();
      number2 = this.model.getIncrement();
    } else {
      number1 = this.desc.getXMinimum();
      number2 = this.desc.getXIncrement();
    } 
    double d1 = getYInc(number2, paramDouble1, paramDouble2, paramInt1);
    double d2 = getYs(number1, paramDouble1, paramDouble2, d1, paramInt1);
    while (d2 < paramDouble1) {
      int i;
      if (paramInt1 == this.PRIMARYY) {
        i = translate(new Double(d2), -2);
      } else {
        i = translateX(new Double(d2));
      } 
      if (!isInverted()) {
        if (paramInt1 == this.PRIMARYY) {
          if (this.model.getGridStyle() != 0 && i != this.zero.y && this.fRadar.size() == 0)
            if (paramRectangle != null) {
              Common.drawLine(paramGraphics, this.center.x, i, (this.center.x + paramInt2), (i - paramInt3));
              Common.drawHLine(paramGraphics, (i - paramInt3) + f, paramRectangle.x, (paramRectangle.x + paramRectangle.width), this.model.getGridStyle(), 0, 0);
            } else if (isXScaled()) {
              Common.drawHLine(paramGraphics, i + f, this.center.x, (this.center.x + this.xWidth), this.model.getGridStyle(), 0, 0);
            } else {
              Common.drawHLine(paramGraphics, i + f, this.center.x, (this.xPos[this.xPos.length - 1] + this.xgap), this.model.getGridStyle(), 0, 0);
            }  
        } else if (this.desc.getVerticalGridStyle() != 0) {
          int j = i;
          if (j != this.zero.x)
            Common.drawVLine(paramGraphics, j + f, this.center.y, (this.center.y - this.yHeight), this.desc.getVerticalGridStyle(), 0, 0); 
        } 
      } else if (paramInt1 == this.PRIMARYY && this.desc.getVerticalGridStyle() != 0 && i != this.zero.x) {
        Common.drawVLine(paramGraphics, i + f, this.center.y, (this.xPos[this.xPos.length - 1] - this.xgap), this.desc.getVerticalGridStyle(), 0, 0);
      } 
      d2 = ((paramInt1 == this.PRIMARYY && this.desc.isLogarithmicYScale()) || (paramInt1 == this.SECONDARYY && this.desc.isSecondaryLogarithmicYScale()) || (paramInt1 == this.PRIMARYX && this.desc.isLogarithmicXScale())) ? (d2 * d1) : (d2 + d1);
    } 
  }
  
  private void paintXLabelTick(Graphics paramGraphics) {
    float f = Common.getLineAdjustment(paramGraphics);
    paramGraphics.setFont(this.context.getFont());
    if (isXScaled()) {
      paintYLabelTick(paramGraphics, this.xMax, this.xMin, this.PRIMARYX, 0, 0, null);
    } else {
      int i = 0;
      double d = (this.desc != null) ? this.desc.getXLabelRotation() : 0.0D;
      byte b;
      int j;
      for (b = 0, j = 0; b < this.model.getDatasetSize(); b++) {
        int k;
        String str = this.model.getLabel(b);
        if (this.fBar3D.size() != 0 || this.fBar.size() != 0 || this.fStick.size() != 0) {
          k = j + this.fBar3D.size() + this.fBar.size() + this.fStick.size();
          k += ((this.fStackBar.size() != 0 || this.fBar3D3D.size() != 0 || this.fStackBar3D.size() != 0) ? 1 : 0);
        } else {
          k = j + 1;
        } 
        int m = (str == null) ? 1 : (int)Common.stringWidth(str, paramGraphics.getFont(), this.fm);
        int n = this.xPos[j];
        if (this.fBar.size() != 0 || this.fBar3D.size() != 0 || this.fStackBar.size() != 0 || this.fStackBar3D.size() != 0 || this.fBar3D3D.size() != 0 || this.fCandle.size() != 0)
          n = this.xPos[j] + this.xInc * (k - j) / 2; 
        int i1 = n - m / 2;
        if (d != 0.0D) {
          Graphics graphics = paramGraphics.create();
          graphics.translate(n, this.zero.y + this.fm.getAscent() + 3);
          Common.rotate(graphics, d);
          Common.drawString(graphics, str, 0.0F, 0.0F);
          graphics.dispose();
        } else if (i1 >= i + 2 && str != null) {
          Common.drawString(paramGraphics, str, i1, (this.zero.y + this.fm.getAscent() + 3));
          i = i1 + m;
        } 
        Common.drawVLine(paramGraphics, n + f, this.zero.y, (this.zero.y + 3), 4097, 0, 0);
        j = k;
      } 
    } 
    paintYLabelTick(paramGraphics, this.yMax, this.yMin, this.PRIMARYY, this.xShift, this.yShift, this.c3D);
    if (this.desc.getFirstDatasetOfSecondaryAxis() != -1)
      paintSecondaryYAxis(paramGraphics, this.xShift, this.yShift); 
  }
  
  private void paintYLabelTick(Graphics paramGraphics, double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, int paramInt3, Rectangle paramRectangle) {
    float f = Common.getLineAdjustment(paramGraphics);
    paramGraphics.setFont(this.context.getFont());
    Number number1 = null;
    Number number2 = null, number3 = null;
    if (paramInt1 == this.PRIMARYY) {
      number1 = this.model.getMinimum();
      number2 = this.model.getMinorIncrement();
      number3 = this.model.getIncrement();
    } else if (paramInt1 == this.SECONDARYY) {
      number1 = this.desc.getSecondaryMinimum();
      number2 = this.desc.getSecondaryMinorIncrement();
      number3 = this.desc.getSecondaryIncrement();
    } else {
      number1 = this.desc.getXMinimum();
      number2 = this.desc.getXMinorIncrement();
      number3 = this.desc.getXIncrement();
    } 
    double d1 = getYInc(number3, paramDouble1, paramDouble2, paramInt1);
    double d2 = getYs(number1, paramDouble1, paramDouble2, d1, paramInt1);
    NumberFormat numberFormat = (paramInt1 == this.PRIMARYX) ? this.desc.getXAxisFormat() : this.desc.getYAxisFormat();
    while (d2 < paramDouble1) {
      int i;
      if (paramInt1 == this.PRIMARYY) {
        i = translate(new Double(d2), -2);
      } else if (paramInt1 == this.SECONDARYY) {
        i = translate(new Double(d2), this.desc.getFirstDatasetOfSecondaryAxis());
      } else {
        i = translateX(new Double(d2));
      } 
      d2 = Math.round(d2 * 10000.0D) / 10000.0D;
      String str = (numberFormat != null) ? numberFormat.format(new Double(d2)) : ((Math.ceil(d2) == d2) ? Integer.toString((int)d2) : Double.toString(d2));
      if (numberFormat == null && str.length() > 4) {
        boolean bool = false;
        int j;
        for (j = 0; j < str.length() && (str.charAt(j) == '0' || str.charAt(j) == '.'); j++)
          bool = true; 
        if (!bool)
          j = str.indexOf('.') + 1; 
        if (j > 0) {
          str = str.substring(0, Math.min(j + 3, str.length()));
          if (str.indexOf('.') >= 0)
            for (int k = str.length() - 1; k >= 0; k--) {
              if (str.charAt(k) != '0') {
                str = str.substring(0, k + 1);
                break;
              } 
            }  
        } 
      } 
      if (!isInverted()) {
        if (paramInt1 == this.PRIMARYY) {
          if (i != this.zero.y && this.fRadar.size() == 0)
            Common.drawHLine(paramGraphics, i + f, this.zero.x, (this.zero.x - 3), 4097, 0, 0); 
          Common.drawString(paramGraphics, str, (this.zero.x - this.fm.stringWidth(str) - this.ggap), (i + this.fm.getHeight() / 2));
          if (number2 != null && this.fRadar.size() == 0) {
            double d3 = number2.doubleValue();
            for (double d4 = d2; d4 < d2 + d1 && d4 < paramDouble1; d4 += d3) {
              int j = (paramInt1 == this.PRIMARYY) ? translate(new Double(d4), -2) : translate(new Double(d4), this.desc.getFirstDatasetOfSecondaryAxis());
              Common.drawHLine(paramGraphics, j + f, this.center.x, (this.center.x - 3), 4097, 0, 0);
            } 
          } 
        } else if (paramInt1 == this.SECONDARYY) {
          if (i != this.zero.y + this.center2.y - this.center.y)
            Common.drawHLine(paramGraphics, i + f, this.center2.x, (this.center2.x + 3), 4097, 0, 0); 
          Common.drawString(paramGraphics, str, (this.center2.x + this.ggap), (i + this.fm.getHeight() / 2));
          if (number2 != null) {
            double d3 = number2.doubleValue();
            for (double d4 = d2; d4 < d2 + d1 && d4 < paramDouble1; d4 += d3) {
              int j = translate(new Double(d4), this.desc.getFirstDatasetOfSecondaryAxis());
              Common.drawHLine(paramGraphics, j + f, this.center2.x, (this.center2.x + 3), 4097, 0, 0);
            } 
          } 
        } else {
          int j = 0;
          double d = (this.desc != null) ? this.desc.getXLabelRotation() : 0.0D;
          int k = (str == null) ? 1 : (int)Common.stringWidth(str, paramGraphics.getFont(), this.fm);
          int m = i;
          int n = m - k / 2;
          if (d != 0.0D) {
            Graphics graphics = paramGraphics.create();
            graphics.translate(m, this.zero.y + this.fm.getAscent() + 3);
            Common.rotate(graphics, d);
            Common.drawString(graphics, str, 0.0F, 0.0F);
            graphics.dispose();
          } else if (n >= j + 2 && str != null) {
            Common.drawString(paramGraphics, str, n, (this.zero.y + this.fm.getAscent() + 3));
            j = n + k;
          } 
          if (m != this.zero.x)
            Common.drawVLine(paramGraphics, m + f, this.zero.y, (this.zero.y + 3), 4097, 0, 0); 
          if (number2 != null) {
            double d3 = number2.doubleValue();
            for (double d4 = d2; d4 < d2 + d1 && d4 < paramDouble1; d4 += d3) {
              int i1 = translateX(new Double(d4));
              if (i1 != this.zero.x)
                Common.drawVLine(paramGraphics, i1 + f, this.zero.y, (this.zero.y + 3), 4097, 0, 0); 
            } 
          } 
        } 
      } else if (paramInt1 == this.PRIMARYY) {
        if (i != this.zero.x)
          Common.drawVLine(paramGraphics, i + f, this.center.y, (this.center.y + 3), 4097, 0, 0); 
        Common.drawString(paramGraphics, str, (i - this.fm.stringWidth(str) / 2), (this.center.y + this.fm.getAscent() + 3));
        if (number2 != null) {
          double d3 = number2.doubleValue();
          for (double d4 = d2; d4 < d2 + d1 && d4 < paramDouble1; d4 += d3) {
            int j = translate(new Double(d4), -2);
            Common.drawVLine(paramGraphics, j + f, this.center.y, (this.center.y + 3), 4097, 0, 0);
          } 
        } 
      } else if (paramInt1 == this.SECONDARYY) {
        if (i != this.zero.x)
          Common.drawVLine(paramGraphics, i + f, this.center2.y, (this.center2.y - 3), 4097, 0, 0); 
        Common.drawString(paramGraphics, str, (i - this.fm.stringWidth(str) / 2), (this.center2.y - 3 - this.xgap));
        if (number2 != null) {
          double d3 = number2.doubleValue();
          for (double d4 = d2; d4 < d2 + d1 && d4 < paramDouble1; d4 += d3) {
            int j = translate(new Double(d4), this.desc.getFirstDatasetOfSecondaryAxis());
            Common.drawVLine(paramGraphics, j + f, this.center2.y, (this.center2.y - 3), 4097, 0, 0);
          } 
        } 
      } 
      d2 = ((paramInt1 == this.PRIMARYY && this.desc.isLogarithmicYScale()) || (paramInt1 == this.SECONDARYY && this.desc.isSecondaryLogarithmicYScale()) || (paramInt1 == this.PRIMARYX && this.desc.isLogarithmicXScale())) ? (d2 * d1) : (d2 + d1);
    } 
  }
  
  private void paintInvertedCoord1(Graphics paramGraphics) {
    float f = Common.getLineAdjustment(paramGraphics);
    Common.drawHLine(paramGraphics, this.zero.y + f, this.center.x, (this.center.x + this.yHeight), 4097, 0, 0);
    if (isXScaled()) {
      Common.drawVLine(paramGraphics, this.zero.x + f, this.center.y, (this.center.x - this.xWidth), 4097, 0, 0);
    } else {
      Common.drawVLine(paramGraphics, this.zero.x + f, this.center.y, (this.xPos[this.xPos.length - 1] - this.xgap), 4097, 0, 0);
    } 
    String str1 = this.model.getXTitle();
    String str2 = this.model.getYTitle();
    if (this.model.getTitleFont() != null) {
      paramGraphics.setFont(this.model.getTitleFont());
    } else {
      paramGraphics.setFont(this.context.getFont());
    } 
    if (str1 != null) {
      Bounds bounds = new Bounds((this.legendSpace.left + this.ggap), (this.center.y - this.xWidth), this.titleOff.x, this.xWidth);
      Common.paintText(paramGraphics, str1, bounds, 18, true, false, 0);
    } 
    if (str2 != null)
      Common.drawString(paramGraphics, str2, ((this.yHeight - this.fm.stringWidth(str2)) / 2 + this.center.x), ((getSize()).height - this.fm.getHeight() - this.legendSpace.bottom + this.fm.getDescent())); 
    if (this.model.getGridStyle() != 0) {
      byte b;
      int i;
      for (b = 0, i = 0; b < this.model.getDatasetSize(); b++) {
        int j;
        if (this.fBar3D.size() != 0 || this.fBar.size() != 0 || this.fStick.size() != 0) {
          j = i + this.fBar3D.size() + this.fBar.size() + this.fStick.size();
          j += ((this.fStackBar.size() != 0 || this.fBar3D3D.size() != 0 || this.fStackBar3D.size() != 0) ? 1 : 0);
        } else {
          j = i + 1;
        } 
        int k = this.xPos[i];
        if (this.fBar.size() != 0 || this.fBar3D.size() != 0 || this.fStackBar.size() != 0 || this.fStackBar3D.size() != 0 || this.fBar3D3D.size() != 0)
          k = this.xPos[i] - this.xInc * (j - i) / 2; 
        if (k != this.zero.x)
          Common.drawHLine(paramGraphics, k + f, this.center.x, (this.center.x + this.yHeight), this.model.getGridStyle(), 0, 0); 
        i = j;
      } 
    } 
    if (this.desc.getVerticalGridStyle() != 0)
      paintGrid(paramGraphics, this.yMax, this.yMin, this.PRIMARYY, 0, 0, null); 
    if (this.desc.getFirstDatasetOfSecondaryAxis() != -1)
      paintSecondaryYAxis(paramGraphics, this.xShift, this.yShift); 
    paramGraphics.setFont(this.context.getFont());
  }
  
  private void paintInvertedXLabelTick(Graphics paramGraphics) {
    float f = Common.getLineAdjustment(paramGraphics);
    paramGraphics.setFont(this.context.getFont());
    boolean bool = false;
    double d = (this.desc != null) ? this.desc.getXLabelRotation() : 0.0D;
    byte b;
    int i;
    for (b = 0, i = 0; b < this.model.getDatasetSize(); b++) {
      int j;
      String str = this.model.getLabel(b);
      if (this.fBar3D.size() != 0 || this.fBar.size() != 0 || this.fStick.size() != 0) {
        j = i + this.fBar3D.size() + this.fBar.size() + this.fStick.size();
        j += ((this.fStackBar.size() != 0 || this.fBar3D3D.size() != 0 || this.fStackBar3D.size() != 0) ? 1 : 0);
      } else {
        j = i + 1;
      } 
      int k = (str == null) ? 1 : (int)Common.stringWidth(str, paramGraphics.getFont(), this.fm);
      int m = this.xPos[i];
      if (this.fBar.size() != 0 || this.fBar3D.size() != 0 || this.fStackBar.size() != 0 || this.fStackBar3D.size() != 0 || this.fBar3D3D.size() != 0)
        m = this.xPos[i] - this.xInc * (j - i) / 2; 
      Common.drawString(paramGraphics, str, (this.zero.x - k - this.xgap - 3), (m + this.fm.getDescent()));
      Common.drawHLine(paramGraphics, m + f, this.zero.x, (this.zero.x - 3), 4097, 0, 0);
      i = j;
    } 
    paintYLabelTick(paramGraphics, this.yMax, this.yMin, this.PRIMARYY, 0, 0, null);
  }
  
  private void paintSecondaryYAxis(Graphics paramGraphics, int paramInt1, int paramInt2) {
    float f = Common.getLineAdjustment(paramGraphics);
    if (isInverted()) {
      Common.drawHLine(paramGraphics, this.center2.y + f, this.center2.x, (this.center2.x + this.yHeight), 4097, 0, 0);
    } else {
      Common.drawVLine(paramGraphics, this.center2.x + f, this.center2.y, (this.center2.y - this.yHeight), 4097, 0, 0);
    } 
    String str = this.desc.getSecondaryYTitle();
    Font font = this.model.getTitleFont();
    if (font == null)
      font = this.context.getFont(); 
    paramGraphics.setFont(font);
    FontMetrics fontMetrics = Common.getFontMetrics(font);
    if (str != null)
      if (isInverted()) {
        Common.drawString(paramGraphics, str, ((this.yHeight - this.fm.stringWidth(str)) / 2 + this.center.x), (this.fm.getHeight() + this.legendSpace.top + this.fm.getDescent()));
      } else {
        Bounds bounds = new Bounds((this.center2.x + this.yLabelWidth2 + this.ggap + 3), (this.center2.y - this.yHeight), this.titleOff2.x, this.yHeight);
        Common.paintText(paramGraphics, str, bounds, 18, true, false, 0);
      }  
    paintYLabelTick(paramGraphics, this.yMax2, this.yMin2, this.SECONDARYY, paramInt1, paramInt2, null);
  }
  
  private double getYInc(Number paramNumber, double paramDouble1, double paramDouble2, int paramInt) {
    double d = 1.0D;
    if (paramNumber == null) {
      if ((paramInt == this.PRIMARYY && this.desc.isLogarithmicYScale()) || (paramInt == this.SECONDARYY && this.desc.isSecondaryLogarithmicYScale()) || (paramInt == this.PRIMARYX && this.desc.isLogarithmicXScale())) {
        double d1;
        if (paramInt == this.PRIMARYY) {
          d1 = (this.logYMax - this.logYMin) / 6.0D;
        } else if (paramInt == this.SECONDARYY) {
          d1 = (this.logYMax2 - this.logYMin2) / 6.0D;
        } else {
          d1 = (this.logXMax - this.logXMin) / 6.0D;
        } 
        if (d1 >= 1.0D) {
          for (byte b = 0; b < d1; ) {
            d *= 10.0D;
            b++;
          } 
        } else {
          d = 10.0D;
        } 
      } else {
        double d1 = (paramDouble1 - paramDouble2) / 6.0D;
        if (d1 >= 1.0D) {
          for (d = 1.0D; d < d1; d *= 2.0D);
        } else if (d1 > 0.0D) {
          for (d = 0.5D; d > d1; d /= 5.0D);
          d *= 5.0D;
        } else {
          d = 0.5D;
        } 
      } 
    } else {
      d = paramNumber.doubleValue();
      if ((paramInt == this.PRIMARYY && this.desc.isLogarithmicYScale()) || (paramInt == this.SECONDARYY && this.desc.isSecondaryLogarithmicYScale()) || (paramInt == this.PRIMARYX && this.desc.isLogarithmicXScale()))
        d = (d <= 10.0D) ? 10.0D : adjustLogVal(d, true); 
    } 
    return d;
  }
  
  private double getYs(Number paramNumber, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt) {
    double d = 0.0D;
    if (paramNumber == null) {
      if ((paramInt == this.PRIMARYY && this.desc.isLogarithmicYScale()) || (paramInt == this.SECONDARYY && this.desc.isSecondaryLogarithmicYScale()) || (paramInt == this.PRIMARYX && this.desc.isLogarithmicXScale())) {
        d = paramDouble2;
      } else {
        while ((paramDouble2 < 0.0D && d > paramDouble2 + paramDouble3) || (paramDouble2 > 0.0D && d < paramDouble2))
          d += ((paramDouble2 >= 0.0D) ? paramDouble3 : -paramDouble3); 
      } 
    } else {
      d = paramNumber.doubleValue();
    } 
    return d;
  }
  
  private int getXShift() {
    if (this.fBar.size() != 0 || this.fBar3D.size() != 0 || this.fBar3D3D.size() != 0 || this.fStackBar.size() != 0 || this.fStackBar3D.size() != 0 || this.fCandle.size() != 0)
      return this.xInc * getXStep() / 2; 
    return 0;
  }
  
  private int getXStep() {
    int i = this.fBar.size() + this.fBar3D.size() + this.fStick.size();
    i += ((this.fBar3D3D.size() != 0 || this.fStackBar.size() != 0 || this.fStackBar3D.size() != 0) ? 1 : 0);
    return (i == 0) ? 1 : i;
  }
  
  private void paintPoint(Graphics paramGraphics, boolean paramBoolean) {
    Color color = paramGraphics.getColor();
    Vector vector = paramBoolean ? this.fPoint : this.fBubble;
    byte b1 = paramBoolean ? 1 : 2;
    byte b2 = 0;
    int i = (int)this.desc.getPointSize();
    int j = getXShift();
    int k = getXStep();
    for (byte b3 = 0; b3 < vector.size(); b3 += b1) {
      int m = ((Integer)vector.elementAt(b3)).intValue();
      byte b4 = paramBoolean ? 0 : ((Integer)vector.elementAt(b3 + 1)).intValue();
      byte b5;
      int n;
      for (b5 = 0, n = 0; b5 < this.model.getDatasetSize(); b5++, n += k) {
        Rectangle rectangle;
        if (paramBoolean) {
          paramGraphics.setColor((Color)this.model.getColor(m - this.startY));
        } else {
          paramGraphics.setColor((Color)this.model.getColor(b2));
        } 
        i = paramBoolean ? i : translateB(this.model.getData(b4, b5));
        int i1 = i / 2;
        if (isInverted()) {
          rectangle = isXScaled() ? new Rectangle(translate(this.model.getData(m, b5), m) - i1, translateX(this.model.getData(0, b5)) - i1 - j, i, i) : new Rectangle(translate(this.model.getData(m, b5), m) - i1, this.xPos[n] - i1 - j, i, i);
        } else {
          rectangle = isXScaled() ? new Rectangle(translateX(this.model.getData(0, b5)) - i1 + j, translate(this.model.getData(m, b5), m) - i1, i, i) : new Rectangle(this.xPos[n] - i1 + j, translate(this.model.getData(m, b5), m) - i1, i, i);
        } 
        if (paramBoolean) {
          Util.drawPoint(paramGraphics, rectangle.x + i1, rectangle.y + i1, i, this.desc.getPointStyle(m - this.startY));
        } else {
          Util.drawPoint(paramGraphics, rectangle.x + i1, rectangle.y + i1, i, 907);
          paramGraphics.setColor(color);
          paramGraphics.drawArc(rectangle.x, rectangle.y, i, i, 0, 360);
        } 
        rectangle.x--;
        rectangle.y--;
        rectangle.width++;
        rectangle.height++;
        this.areas.addElement(new GraphArea(this, b5, m, rectangle));
        if (this.model.isShowValue()) {
          String str = toString(this.model.getData(m, b5));
          paramGraphics.setColor(this.context.getForeground());
          if (isInverted()) {
            Common.drawString(paramGraphics, str, (rectangle.x + i + 1), (rectangle.y + i1 + this.fm.getDescent()));
          } else {
            Common.drawString(paramGraphics, str, (rectangle.x - this.fm.stringWidth(str) / 2), (rectangle.y - this.fm.getDescent()));
          } 
        } 
      } 
      b2++;
    } 
    paramGraphics.setColor(color);
  }
  
  private void paintStock(Graphics paramGraphics) {
    if (this.fStock.size() < 2)
      return; 
    Color color = paramGraphics.getColor();
    int i = Math.min(2, (this.xPos.length > 1) ? (this.xPos[1] - this.xPos[0] - 2) : 2);
    i = Math.max(i, 1);
    int j = getXShift();
    int k = getXStep();
    byte b;
    int m;
    for (b = 0, m = 0; b < this.model.getDatasetSize(); b++, m += k) {
      int n = ((Integer)this.fStock.elementAt(1)).intValue();
      int i1 = translate(this.model.getData(n, b), -2);
      n = ((Integer)this.fStock.elementAt(0)).intValue();
      Rectangle rectangle = new Rectangle(this.xPos[m] + j, i1, i, translate(this.model.getData(n, b), -2) - i1);
      paramGraphics.setColor((Color)this.model.getColor(0));
      Common.drawLine(paramGraphics, rectangle.x, rectangle.y, rectangle.x, (rectangle.y + rectangle.height));
      if (this.fStock.size() > 2) {
        n = ((Integer)this.fStock.elementAt(2)).intValue();
        int i2 = translate(this.model.getData(n, b), -2);
        Common.drawLine(paramGraphics, rectangle.x, i2, (rectangle.x + rectangle.width), i2);
      } 
      this.areas.addElement(new GraphArea(this, b, 0, rectangle));
    } 
    paramGraphics.setColor(color);
  }
  
  private void paintCandle(Graphics paramGraphics) {
    if (this.fCandle.size() < 4) {
      System.err.println("Warning: Candle chart requires four series datasets");
      return;
    } 
    Color color = paramGraphics.getColor();
    int i = this.model.getGap();
    int j = this.xPos[1] - this.xPos[0] - i;
    int k = Math.max(j / 4, 1);
    int m = getXStep();
    int n = getXShift();
    n = (n == 0) ? (k / 2) : n;
    byte b;
    int i1;
    for (b = 0, i1 = 0; b < this.model.getDatasetSize(); b++, i1 += m) {
      int i2 = ((Integer)this.fCandle.elementAt(1)).intValue();
      int i3 = translate(this.model.getData(i2, b), i2);
      i2 = ((Integer)this.fCandle.elementAt(2)).intValue();
      int i4 = translate(this.model.getData(i2, b), i2);
      Rectangle rectangle = new Rectangle(this.xPos[i1] + n, (i4 > i3) ? i4 : i3, k, Math.abs(i4 - i3));
      paramGraphics.setColor(Color.black);
      Common.drawLine(paramGraphics, rectangle.x, rectangle.y, rectangle.x, (rectangle.y - rectangle.height));
      this.areas.addElement(new GraphArea(this, b, 0, rectangle));
      i2 = ((Integer)this.fCandle.elementAt(0)).intValue();
      i3 = translate(this.model.getData(i2, b), i2);
      i2 = ((Integer)this.fCandle.elementAt(3)).intValue();
      i4 = translate(this.model.getData(i2, b), i2);
      rectangle = new Rectangle(this.xPos[i1] + i / 2 + (j - k) / 2, (i4 > i3) ? i3 : i4, k, Math.abs(i3 - i4));
      if (i3 > i4) {
        Common.fill(paramGraphics, rectangle, Color.white);
      } else {
        Common.fill(paramGraphics, rectangle, Color.black);
      } 
      paramGraphics.setColor(this.context.getForeground());
      paramGraphics.drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
      this.areas.addElement(new GraphArea(this, b, 1, rectangle));
    } 
    paramGraphics.setColor(color);
  }
  
  private void paintStick(Graphics paramGraphics) {
    Color color = paramGraphics.getColor();
    int i = getXStep() - this.fStick.size();
    int j = (this.fBar3D3D.size() == 0) ? 0 : 1;
    j += ((this.fStackBar.size() != 0 || this.fStackBar3D.size() != 0) ? 1 : 0);
    j += this.fBar3D.size() + this.fBar.size();
    for (byte b = 0; b < this.model.getDatasetSize(); b++, j += i) {
      for (byte b1 = 0; b1 < this.fStick.size(); b1++, j++) {
        int k = ((Integer)this.fStick.elementAt(b1)).intValue();
        paramGraphics.setColor((Color)this.model.getColor(k));
        int m = translate(this.model.getData(k, b), k);
        Rectangle rectangle = new Rectangle(this.xPos[j], m, 2, this.zero.y - m);
        Common.drawLine(paramGraphics, rectangle.x, rectangle.y, rectangle.x, (rectangle.y + rectangle.height));
        this.areas.addElement(new GraphArea(this, b, 0, rectangle));
      } 
    } 
    paramGraphics.setColor(color);
  }
  
  private void paintLine(Graphics paramGraphics) {
    Color color = paramGraphics.getColor();
    char c = (this.desc == null) ? 4097 : ((int)this.desc.getLineChartLineWidth() | 0x1000);
    int i = (int)this.desc.getPointSize();
    int j = getXShift();
    int k = getXStep();
    for (byte b = 0; b < this.fLine.size(); b++) {
      int m = ((Integer)this.fLine.elementAt(b)).intValue();
      paramGraphics.setColor((Color)this.model.getColor(m - this.startY));
      byte b1;
      int n;
      for (b1 = 1, n = k; b1 < this.model.getDatasetSize(); b1++, n += k) {
        int i4, i3, i2, i1;
        if (isInverted()) {
          i2 = (isXScaled() ? translateX(this.model.getData(0, b1 - true)) : this.xPos[n - k]) - j;
          i1 = translate(this.model.getData(m, b1 - true), m);
          i4 = (isXScaled() ? translateX(this.model.getData(0, b1)) : this.xPos[n]) - j;
          i3 = translate(this.model.getData(m, b1), m);
        } else {
          i1 = (isXScaled() ? translateX(this.model.getData(0, b1 - 1)) : this.xPos[n - k]) + j;
          i2 = translate(this.model.getData(m, b1 - 1), m);
          i3 = (isXScaled() ? translateX(this.model.getData(0, b1)) : this.xPos[n]) + j;
          i4 = translate(this.model.getData(m, b1), m);
        } 
        if (this.model.getData(m, b1 - true) != null && this.model.getData(m, b1) != null)
          Common.drawLine(paramGraphics, i1, i2, i3, i4, c); 
        int[] arrayOfInt1 = { i1, i3, i3, i1 };
        int[] arrayOfInt2 = { i2 - 2, i4 - 2, i4 + 2, i2 + 2 };
        this.areas.addElement(new GraphArea(this, b1, m, new Polygon(arrayOfInt1, arrayOfInt2, 4)));
        Util.drawPoint(paramGraphics, i1, i2, i, this.desc.getPointStyle(m - this.startY));
        if (b1 == this.model.getDatasetSize() - 1)
          Util.drawPoint(paramGraphics, i3, i4, i, this.desc.getPointStyle(m - this.startY)); 
        Color color1 = paramGraphics.getColor();
        if (this.model.isShowValue()) {
          String str = toString(this.model.getData(m, b1 - 1));
          paramGraphics.setColor(this.context.getForeground());
          if (isInverted()) {
            Common.drawString(paramGraphics, str, (i1 + i / 2 + 1), (i2 + this.fm.getDescent()));
            if (b1 == this.model.getDatasetSize() - 1) {
              str = toString(this.model.getData(m, b1));
              Common.drawString(paramGraphics, str, (i3 + i / 2 + 1), (i4 + this.fm.getDescent()));
            } 
          } else {
            Common.drawString(paramGraphics, str, (i1 - this.fm.stringWidth(str) / 2), (i2 - this.fm.getDescent()));
            if (b1 == this.model.getDatasetSize() - 1) {
              str = toString(this.model.getData(m, b1));
              Common.drawString(paramGraphics, str, (i3 - this.fm.stringWidth(str) / 2), (i4 - this.fm.getDescent()));
            } 
          } 
        } 
        paramGraphics.setColor(color1);
      } 
    } 
    paramGraphics.setColor(color);
  }
  
  private void paintArea(Graphics paramGraphics) {
    Color color = paramGraphics.getColor();
    int i = getXShift();
    int j = getXStep();
    for (int k = this.fArea.size() - 1; k >= 0; k--) {
      int m = ((Integer)this.fArea.elementAt(k)).intValue();
      Polygon polygon = new Polygon();
      byte b;
      int n;
      for (b = 1, n = j; b < this.model.getDatasetSize(); b++, n += j) {
        int i1 = this.xPos[n - j] + i;
        int i2 = translate(this.model.getData(m, b - true), m);
        int i3 = this.xPos[n] + i;
        int i4 = translate(this.model.getData(m, b), m);
        if (b == 1) {
          polygon.addPoint(i1, this.zero.y);
          polygon.addPoint(i1, i2);
        } 
        polygon.addPoint(i3, i4);
        if (b == this.model.getDatasetSize() - 1)
          polygon.addPoint(i3, this.zero.y); 
        int[] arrayOfInt1 = { i1, i1, i3, i3 };
        int[] arrayOfInt2 = { this.zero.y, i2, i4, this.zero.y };
        this.areas.addElement(new GraphArea(this, b, m, new Polygon(arrayOfInt1, arrayOfInt2, 4)));
      } 
      Common.fill(paramGraphics, polygon, this.model.getColor(m));
    } 
    paramGraphics.setColor(this.context.getForeground());
    if (this.model.isShowValue())
      for (byte b = 0; b < this.fArea.size(); b++) {
        int m = ((Integer)this.fArea.elementAt(b)).intValue();
        byte b1;
        int n;
        for (b1 = 0, n = 0; b1 < this.model.getDatasetSize(); b1++, n += j) {
          int i1 = this.xPos[n] - 1;
          int i2 = translate(this.model.getData(m, b1), m);
          String str = toString(this.model.getData(m, b1));
          Common.drawString(paramGraphics, str, (i1 - this.fm.stringWidth(str) / 2), (i2 - this.fm.getDescent()));
        } 
      }  
    paramGraphics.setColor(color);
  }
  
  private void paintStackArea(Graphics paramGraphics) {
    Color color = paramGraphics.getColor();
    int i = getXShift();
    int j = getXStep();
    Point[][] arrayOfPoint = new Point[this.fStackArea.size() + 1][this.model.getDatasetSize()];
    byte b1;
    int k;
    for (b1 = 0, k = 0; b1 < arrayOfPoint[0].length; b1++, k += j)
      arrayOfPoint[0][b1] = new Point(this.xPos[k] + i, this.zero.y); 
    byte b2;
    int m;
    for (b2 = 0, m = 0; b2 < this.model.getDatasetSize(); b2++, m += j) {
      double d = 0.0D;
      for (byte b = 0; b < this.fStackArea.size(); b++) {
        int n = ((Integer)this.fStackArea.elementAt(b)).intValue();
        Number number = this.model.getData(n, b2);
        d += ((number == null) ? 0.0D : number.doubleValue());
        arrayOfPoint[n + 1][b2] = new Point(this.xPos[m] + i, translate(new Double(d), n));
      } 
    } 
    for (byte b3 = 1; b3 < arrayOfPoint.length; b3++) {
      Polygon polygon = new Polygon();
      for (byte b = 0; b < arrayOfPoint[b3].length; b++) {
        polygon.addPoint((arrayOfPoint[b3][b]).x, (arrayOfPoint[b3][b]).y);
        if (b) {
          int[] arrayOfInt1 = { (arrayOfPoint[b3][b - true]).x, (arrayOfPoint[b3][b]).x, (arrayOfPoint[b3 - true][b]).x, (arrayOfPoint[b3 - true][b - true]).x };
          int[] arrayOfInt2 = { (arrayOfPoint[b3][b - true]).y, (arrayOfPoint[b3][b]).y, (arrayOfPoint[b3 - true][b]).y, (arrayOfPoint[b3 - true][b - true]).y };
          this.areas.addElement(new GraphArea(this, b, b3 - true, new Polygon(arrayOfInt1, arrayOfInt2, 4)));
        } 
      } 
      for (int n = arrayOfPoint[b3].length - 1; n >= 0; n--)
        polygon.addPoint((arrayOfPoint[b3 - true][n]).x, (arrayOfPoint[b3 - true][n]).y); 
      Common.fill(paramGraphics, polygon, this.model.getColor(b3 - true));
    } 
    paramGraphics.setColor(this.context.getForeground());
    if (this.model.isShowValue())
      for (byte b = 1; b < arrayOfPoint.length; b++) {
        for (byte b4 = 0; b4 < arrayOfPoint[b].length; b4++) {
          String str = toString(this.model.getData(b - true, b4));
          Common.drawString(paramGraphics, str, ((arrayOfPoint[b][b4]).x - this.fm.stringWidth(str) / 2), ((arrayOfPoint[b][b4]).y - this.fm.getDescent()));
        } 
      }  
    paramGraphics.setColor(color);
  }
  
  private void paintBar(Graphics paramGraphics) {
    boolean bool1 = Util.isFlatDatasetChart(this.model);
    Color color = paramGraphics.getColor();
    int i = getXStep() - this.fBar.size();
    int j = (this.fBar3D3D.size() == 0) ? 0 : 1;
    j += ((this.fStackBar.size() != 0 || this.fStackBar3D.size() != 0) ? 1 : 0);
    j += this.fBar3D.size();
    int k = this.model.getGap();
    int m = Math.max(1, Math.abs(this.xPos[1] - this.xPos[0]) - k);
    boolean bool2 = (this.desc != null) ? this.desc.isBarBorder() : 0;
    for (byte b = 0; b < this.model.getDatasetSize(); b++, j += i) {
      for (byte b1 = 0; b1 < this.fBar.size(); b1++, j++) {
        int n = ((Integer)this.fBar.elementAt(b1)).intValue();
        int i1 = translate(this.model.getData(n, b), n);
        Rectangle rectangle = null;
        if (isInverted()) {
          if (i1 < this.zero.x) {
            rectangle = new Rectangle(i1, this.xPos[j] - k / 2 - m, this.zero.x - i1, m);
          } else {
            rectangle = new Rectangle(this.zero.x, this.xPos[j] - k / 2 - m, i1 - this.zero.x, m);
          } 
        } else if (i1 < this.zero.y) {
          rectangle = new Rectangle(this.xPos[j] + k / 2, i1, m, this.zero.y - i1);
        } else {
          rectangle = new Rectangle(this.xPos[j] + k / 2, this.zero.y, m, i1 - this.zero.y);
        } 
        this.areas.addElement(new GraphArea(this, b, n, rectangle));
        Object object = this.model.getColor(bool1 ? b : n);
        if (object instanceof Image) {
          Image image = (Image)object;
          Shape shape = paramGraphics.getClip();
          paramGraphics.setClip(rectangle);
          int i2 = image.getHeight(null);
          int i3 = image.getWidth(null);
          if (i2 < 0)
            i2 = i3 = rectangle.width - 2; 
          int i4 = rectangle.x + (rectangle.width - i3) / 2;
          for (int i5 = rectangle.y + rectangle.height; i5 > rectangle.y; i5 -= i2)
            paramGraphics.drawImage(image, i4, i5 - i2, null); 
          paramGraphics.setClip(shape);
        } else {
          Common.fill(paramGraphics, rectangle, object);
        } 
        if (bool2) {
          paramGraphics.setColor(this.context.getForeground());
          paramGraphics.drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
        } 
        if (this.model.isShowValue()) {
          String str = toString(this.model.getData(n, b));
          paramGraphics.setColor(this.context.getForeground());
          if (isInverted()) {
            Common.drawString(paramGraphics, str, (rectangle.x + rectangle.width + 1), (rectangle.y + rectangle.height / 2 + this.fm.getDescent()));
          } else {
            Common.drawString(paramGraphics, str, (rectangle.x + (rectangle.width - this.fm.stringWidth(str)) / 2), (rectangle.y - this.fm.getDescent()));
          } 
        } 
      } 
    } 
    paramGraphics.setColor(color);
  }
  
  private void paintBar3D(Graphics paramGraphics) {
    boolean bool = Util.isFlatDatasetChart(this.model);
    Color color = paramGraphics.getColor();
    int i = getXStep() - this.fBar3D.size();
    int j = (this.fBar3D3D.size() == 0) ? 0 : 1;
    j += ((this.fStackBar.size() != 0 || this.fStackBar3D.size() != 0) ? 1 : 0);
    for (byte b = 0; b < this.model.getDatasetSize(); b++, j += i) {
      for (byte b1 = 0; b1 < this.fBar3D.size(); b1++, j++) {
        int k = ((Integer)this.fBar3D.elementAt(b1)).intValue();
        int m = translate(this.model.getData(k, b), k);
        Rectangle rectangle = null;
        if (m < this.zero.y) {
          rectangle = new Rectangle(this.xPos[j], m, this.xInc, this.zero.y - m);
        } else {
          rectangle = new Rectangle(this.xPos[j], this.zero.y, this.xInc, m - this.zero.y);
        } 
        draw3DBar(paramGraphics, rectangle.x, rectangle.y, rectangle.width, rectangle.height, this.model.getColor(bool ? b : k), b, k);
        if (this.model.isShowValue()) {
          String str = toString(this.model.getData(k, b));
          paramGraphics.setColor(this.context.getForeground());
          Common.drawString(paramGraphics, str, (this.xPos[j] + (this.xInc - this.fm.stringWidth(str)) / 2), (m - this.fm.getDescent()));
        } 
      } 
    } 
    paramGraphics.setColor(color);
  }
  
  private void paintBar3D3D(Graphics paramGraphics) {
    Color color = paramGraphics.getColor();
    int i = getXStep();
    boolean bool = Util.isFlatDatasetChart(this.model);
    int j = this.xInc / 4;
    int k = this.xInc / 4;
    for (int m = this.fBar3D3D.size() - 1; m >= 0; m--) {
      int n = ((Integer)this.fBar3D3D.elementAt(m)).intValue();
      byte b;
      int i1;
      for (b = 0, i1 = 0; b < this.model.getDatasetSize(); b++, i1 += i) {
        int i2 = translate(this.model.getData(n, b), n);
        Object object = null;
        if (i2 < this.zero.y) {
          draw3DBar(paramGraphics, this.xPos[i1] + m * j, i2 - m * k, this.xInc, this.zero.y - i2, this.model.getColor(bool ? b : n), b, n);
        } else {
          draw3DBar(paramGraphics, this.xPos[i1] + m * j, this.zero.y - m * k, this.xInc, i2 - this.zero.y, this.model.getColor(bool ? b : n), b, n);
        } 
        if (this.model.isShowValue()) {
          String str = toString(this.model.getData(n, b));
          paramGraphics.setColor(this.context.getForeground());
          Common.drawString(paramGraphics, str, (this.xPos[i1] + n * j + (this.xInc - this.fm.stringWidth(str)) / 2), (i2 - n * k - this.fm.getDescent()));
        } 
      } 
    } 
    paramGraphics.setColor(color);
  }
  
  private void draw3DBar(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Object paramObject, int paramInt5, int paramInt6) {
    int i = (this.model.getGap() >= paramInt3) ? 0 : this.model.getGap();
    paramInt1 += i / 2;
    Rectangle rectangle = new Rectangle(paramInt1, paramInt2, paramInt3 - i, paramInt4);
    Common.fill(paramGraphics, rectangle, darker(paramObject));
    this.areas.addElement(new GraphArea(this, paramInt5, paramInt6, rectangle));
    int[] arrayOfInt1 = { paramInt1, paramInt1 + paramInt3 / 4, paramInt1 + paramInt3 + paramInt3 / 4 - i, paramInt1 + paramInt3 - i };
    int[] arrayOfInt2 = { paramInt2, paramInt2 - paramInt3 / 4, paramInt2 - paramInt3 / 4, paramInt2 };
    Polygon polygon1 = new Polygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length);
    Common.fill(paramGraphics, polygon1, brighter(paramObject));
    this.areas.addElement(new GraphArea(this, paramInt5, paramInt6, polygon1));
    int[] arrayOfInt3 = { paramInt1 + paramInt3 - i, paramInt1 + paramInt3 - i + paramInt3 / 4, paramInt1 + paramInt3 - i + paramInt3 / 4, paramInt1 + paramInt3 - i };
    int[] arrayOfInt4 = { paramInt2, paramInt2 - paramInt3 / 4, paramInt2 + paramInt4 - paramInt3 / 4, paramInt2 + paramInt4 };
    Polygon polygon2 = new Polygon(arrayOfInt3, arrayOfInt4, arrayOfInt3.length);
    Common.fill(paramGraphics, polygon2, darker(darker(paramObject)));
    this.areas.addElement(new GraphArea(this, paramInt5, paramInt6, polygon2));
  }
  
  private void paintStackBar(Graphics paramGraphics) {
    boolean bool1 = Util.isFlatDatasetChart(this.model);
    Color color = paramGraphics.getColor();
    int i = getXStep();
    i = (i == 0) ? 1 : i;
    int j = (this.fBar3D3D.size() != 0) ? 1 : 0;
    int k = this.model.getGap();
    boolean bool2 = this.desc.isBarBorder();
    for (byte b = 0; b < this.model.getDatasetSize(); b++, j += i) {
      int n;
      int m;
      if (isInverted()) {
        m = n = this.zero.x;
      } else {
        m = n = this.zero.y;
      } 
      for (byte b1 = 0; b1 < this.fStackBar.size(); b1++) {
        int i1 = ((Integer)this.fStackBar.elementAt(b1)).intValue();
        Number number = this.model.getData(i1, b);
        int i2 = (number != null && number.doubleValue() >= 0.0D) ? m : n;
        Rectangle rectangle = null;
        int i3 = Math.max(1, Math.abs(this.xPos[j + true] - this.xPos[j]) - k);
        if (isInverted()) {
          if (number != null && number.doubleValue() >= 0.0D) {
            m += translate(number, i1) - this.zero.x;
            rectangle = new Rectangle(i2, this.xPos[j] - k / 2 - i3, m - i2, i3);
          } else {
            n += translate(number, i1) - this.zero.x;
            rectangle = new Rectangle(n, this.xPos[j] - k / 2 - i3, i2 - n, i3);
          } 
        } else if (number != null && number.doubleValue() >= 0.0D) {
          m += translate(number, i1) - this.zero.y;
          rectangle = new Rectangle(this.xPos[j] + k / 2, m, i3, i2 - m);
        } else {
          n += translate(number, i1) - this.zero.y;
          rectangle = new Rectangle(this.xPos[j] + k / 2, i2, i3, n - i2);
        } 
        if (this.model.getGap() == 0) {
          paramGraphics.setColor(this.context.getForeground());
          paramGraphics.drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
          rectangle.x++;
          rectangle.y++;
          rectangle.width--;
          rectangle.height--;
        } 
        Common.fill(paramGraphics, rectangle, this.model.getColor(bool1 ? b : i1));
        this.areas.addElement(new GraphArea(this, b, i1, rectangle));
        if (bool2) {
          paramGraphics.setColor(this.context.getForeground());
          paramGraphics.drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
        } 
        if (this.model.isShowValue()) {
          String str = toString(this.model.getData(i1, b));
          paramGraphics.setColor(this.context.getForeground());
          Common.drawString(paramGraphics, str, (rectangle.x + (rectangle.width - this.fm.stringWidth(str)) / 2), (rectangle.y + (rectangle.height - this.fm.getHeight()) / 2 + this.fm.getAscent()));
        } 
      } 
    } 
    paramGraphics.setColor(color);
  }
  
  private void paintStackBar3D(Graphics paramGraphics) {
    boolean bool = Util.isFlatDatasetChart(this.model);
    Color color = paramGraphics.getColor();
    int i = getXStep();
    int j = (this.fBar3D3D.size() != 0) ? 1 : 0;
    int k = (this.model.getGap() >= this.xInc) ? 0 : this.model.getGap();
    int m = k / 2;
    for (byte b = 0; b < this.model.getDatasetSize(); b++, j += i) {
      int n = this.zero.y, i1 = this.zero.y;
      for (byte b1 = 0; b1 < this.fStackBar3D.size(); b1++) {
        int i2 = ((Integer)this.fStackBar3D.elementAt(b1)).intValue();
        Number number = this.model.getData(i2, b);
        int i3 = (number != null && number.doubleValue() >= 0.0D) ? n : i1;
        Object object = this.model.getColor(bool ? b : i2);
        Rectangle rectangle1 = null;
        if (number != null && number.doubleValue() >= 0.0D) {
          n = translate(this.model.getData(i2, b), i2) - this.zero.y + n;
          rectangle1 = new Rectangle(this.xPos[j] + m, n, this.xInc, i3 - n);
        } else {
          i1 = translate(this.model.getData(i2, b), i2) - this.zero.y + i1;
          rectangle1 = new Rectangle(this.xPos[j] + m, i3, this.xInc, i1 - i3);
        } 
        Rectangle rectangle2 = new Rectangle(rectangle1);
        rectangle2.width -= k;
        Common.fill(paramGraphics, rectangle2, darker(object));
        this.areas.addElement(new GraphArea(this, b, i2, rectangle2));
        int[] arrayOfInt1 = { this.xPos[j] + m, this.xPos[j] + m + this.xInc / 4, this.xPos[j + true] + this.xInc / 4 - m, this.xPos[j + true] - m };
        int[] arrayOfInt2 = { n, n - this.xInc / 4, n - this.xInc / 4, n };
        Polygon polygon1 = new Polygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length);
        Common.fill(paramGraphics, polygon1, brighter(object));
        this.areas.addElement(new GraphArea(this, b, i2, polygon1));
        int[] arrayOfInt3 = { this.xPos[j + true] - m, this.xPos[j + true] - m + this.xInc / 4, this.xPos[j + true] - m + this.xInc / 4, this.xPos[j + true] - m };
        int[] arrayOfInt4 = { rectangle1.y, rectangle1.y - this.xInc / 4, rectangle1.y + rectangle1.height - this.xInc / 4, rectangle1.y + rectangle1.height };
        Polygon polygon2 = new Polygon(arrayOfInt3, arrayOfInt4, arrayOfInt3.length);
        Common.fill(paramGraphics, polygon2, darker(darker(object)));
        this.areas.addElement(new GraphArea(this, b, i2, polygon2));
        if (this.model.isShowValue()) {
          String str = toString(this.model.getData(i2, b));
          paramGraphics.setColor(this.context.getForeground());
          Common.drawString(paramGraphics, str, (rectangle1.x + (rectangle1.width - this.fm.stringWidth(str)) / 2), (rectangle1.y + (rectangle1.height - this.fm.getHeight()) / 2 + this.fm.getAscent()));
        } 
      } 
    } 
    paramGraphics.setColor(color);
  }
  
  private void paintPie(Graphics paramGraphics, boolean paramBoolean1, boolean paramBoolean2) {
    double d1 = paramBoolean1 ? 60.0D : 0.0D;
    int i = 0;
    int j = 3;
    Dimension dimension = getSize();
    double d2 = 0.0D;
    double[] arrayOfDouble1 = new double[this.model.getDatasetSize() + 1];
    double[] arrayOfDouble2 = new double[arrayOfDouble1.length - 1];
    Vector vector = new Vector();
    for (byte b1 = 0; b1 < this.model.getDatasetSize(); b1++) {
      Number number = this.model.getData(0, b1);
      d2 += ((number == null) ? 0.0D : number.doubleValue());
    } 
    d2 = (d2 == 0.0D) ? 1.0D : d2;
    double d3 = 0.0D;
    for (byte b2 = 0; b2 < this.model.getDatasetSize(); b2++) {
      Number number = this.model.getData(0, b2);
      double d = (number == null) ? 0.0D : number.doubleValue();
      arrayOfDouble1[b2] = d3;
      arrayOfDouble2[b2] = d / d2 * 360.0D;
      d3 += arrayOfDouble2[b2];
      if (arrayOfDouble2[b2] >= 54.0D)
        vector.addElement(new Integer(b2)); 
    } 
    arrayOfDouble1[arrayOfDouble1.length - 1] = 360.0D;
    int k = dimension.width - this.legendSpace.left - this.legendSpace.right;
    int m = dimension.height - this.legendSpace.top - this.legendSpace.bottom;
    Point point = new Point(this.legendSpace.left + k / 2, this.legendSpace.top + m / 2);
    double d4 = 0.005555555555555556D;
    double d5 = Math.cos(d1 * Math.PI / 180.0D);
    int n = !paramBoolean2 ? 0 : (this.fm.stringWidth(String.valueOf(this.model.getLabel(0))) + j);
    int i1 = (int)(m / d5) / 2 - this.fm.getHeight() * 2;
    if (paramBoolean1)
      i1 -= i1 / 5; 
    int i2 = Math.min(k / 2 - n, i1) - 2 * j;
    if (paramBoolean1)
      point.y -= i2 / 10; 
    i2 = Math.abs(i2);
    if (paramBoolean1 && arrayOfDouble1.length > 1) {
      i = i2 / 5;
      if (Common.isJava2() || paramGraphics instanceof inetsoft.report.internal.CustomGraphics)
        for (byte b = 0; b < arrayOfDouble1.length - 1; b++) {
          if (arrayOfDouble1[b + true] >= 180.0D)
            Common.fillArc(paramGraphics, (point.x - i2), (float)(point.y - i2 * d5) + i, (2 * i2), (float)((2 * i2) * d5), (float)arrayOfDouble1[b], (float)(arrayOfDouble1[b + true] - arrayOfDouble1[b]), darker(this.model.getColor(b))); 
        }  
      byte b4 = 0;
      for (; b4 < arrayOfDouble1.length && arrayOfDouble1[b4] <= 180.0D; b4++);
      double d = 180.0D;
      for (byte b5 = b4; b5 < arrayOfDouble1.length; b5++) {
        Polygon polygon1 = new Polygon();
        Polygon polygon2 = new Polygon();
        Point point1 = new Point(point.x + (int)(i2 * Math.cos(d * Math.PI / 180.0D)), point.y - (int)(i2 * Math.sin(d * Math.PI / 180.0D) * d5));
        Point point2 = new Point(point.x + (int)(i2 * Math.cos(arrayOfDouble1[b5] * Math.PI / 180.0D)), point.y - (int)(i2 * Math.sin(arrayOfDouble1[b5] * Math.PI / 180.0D) * d5));
        for (; d < arrayOfDouble1[b5]; d += d4)
          polygon1.addPoint(point.x + (int)(i2 * Math.cos(d * Math.PI / 180.0D)), point.y - (int)(i2 * Math.sin(d * Math.PI / 180.0D) * d5)); 
        d = arrayOfDouble1[b5];
        polygon1.addPoint(point.x + (int)(i2 * Math.cos(d * Math.PI / 180.0D)), point.y - (int)(i2 * Math.sin(d * Math.PI / 180.0D) * d5));
        for (int i3 = polygon1.npoints - 1; i3 >= 0; i3--)
          polygon1.addPoint(polygon1.xpoints[i3], polygon1.ypoints[i3] + i); 
        this.areas.addElement(new GraphArea(this, b5 - 1, 0, polygon1));
        if (Common.isJava2()) {
          polygon2.addPoint(point1.x, point1.y);
          polygon2.addPoint(point1.x, point1.y + i);
          polygon2.addPoint(point2.x, point2.y + i);
          polygon2.addPoint(point2.x, point2.y);
          polygon2.addPoint(point1.x, point1.y);
          Common.fill(paramGraphics, polygon2, darker(this.model.getColor(b5 - 1)));
        } else {
          Common.fill(paramGraphics, polygon1, darker(this.model.getColor(b5 - 1)));
        } 
      } 
    } 
    for (byte b3 = 0; b3 < arrayOfDouble1.length - 1; b3++) {
      Polygon polygon = new Polygon();
      polygon.addPoint(point.x, point.y);
      for (double d = arrayOfDouble1[b3]; d < arrayOfDouble1[b3 + true]; d += d4)
        polygon.addPoint(point.x + (int)(i2 * Math.cos(d * Math.PI / 180.0D)), point.y - (int)(i2 * Math.sin(d * Math.PI / 180.0D) * d5)); 
      polygon.addPoint(point.x + (int)(i2 * Math.cos(arrayOfDouble1[b3 + true] * Math.PI / 180.0D)), point.y - (int)(i2 * Math.sin(arrayOfDouble1[b3 + true] * Math.PI / 180.0D) * d5));
      Common.fillArc(paramGraphics, (point.x - i2), (float)(point.y - i2 * d5), (2 * i2), (float)((2 * i2) * d5), (float)arrayOfDouble1[b3], (float)(arrayOfDouble1[b3 + true] - arrayOfDouble1[b3]), this.model.getColor(b3));
      this.areas.addElement(new GraphArea(this, b3, 0, polygon));
    } 
    if (paramBoolean2 || this.model.isShowValue()) {
      if (vector.size() > 0) {
        boolean bool = false;
        double d = 12.0D / i2 / 72.0D;
        for (byte b4 = 0; b4 < arrayOfDouble2.length; b4++) {
          if (arrayOfDouble2[b4] < d) {
            double d6 = d - arrayOfDouble2[b4];
            arrayOfDouble2[b4] = arrayOfDouble2[b4] + d6;
            bool = true;
            double d7 = d6 / vector.size();
            for (byte b5 = 0; b5 < vector.size(); b5++) {
              int i3 = ((Integer)vector.elementAt(b5)).intValue();
              arrayOfDouble2[i3] = arrayOfDouble2[i3] - d7;
            } 
          } 
        } 
        if (bool)
          for (byte b5 = 0; b5 < arrayOfDouble2.length; b5++)
            arrayOfDouble1[b5 + true] = arrayOfDouble1[b5] + arrayOfDouble2[b5];  
      } 
      paramGraphics.setColor(this.context.getForeground());
      for (byte b = 0; b < arrayOfDouble1.length - 1 && b < this.model.getDatasetSize(); b++) {
        String str = this.model.getLabel(b);
        double d6 = (arrayOfDouble1[b] + arrayOfDouble1[b + 1]) / 2.0D;
        double d7 = Math.cos(d6 * Math.PI / 180.0D);
        double d8 = Math.sin(d6 * Math.PI / 180.0D);
        double d9 = (d7 > 0.0D) ? j : (-this.fm.stringWidth((str == null) ? "" : str) - j);
        double d10 = (d8 > 0.0D) ? this.fm.getDescent() : this.fm.getAscent();
        int i3 = (d8 > 0.0D) ? 0 : i;
        if (paramBoolean2)
          Common.drawString(paramGraphics, this.model.getLabel(b), (point.x + (int)(i2 * d7 + d9)), (point.y - (int)(i2 * d8 * Math.cos(d1 * Math.PI / 180.0D) + d10 * d8) + i3)); 
        if (this.model.isShowValue()) {
          String str1 = toString(this.model.getData(0, b));
          Common.drawString(paramGraphics, str1, (point.x + (int)((i2 * 2 / 3) * d7) - this.fm.stringWidth(str1) / 2), (point.y - (int)((i2 * 2 / 3) * d8 * Math.cos(d1 * Math.PI / 180.0D) + d10 * d8)));
        } 
      } 
    } 
  }
  
  private void paintRadar(Graphics paramGraphics) {
    Color color = paramGraphics.getColor();
    Dimension dimension = getSize();
    paramGraphics.setFont(this.context.getFont());
    double d1 = 360.0D / ((this.model.getDatasetSize() == 0) ? 1.0D : this.model.getDatasetSize());
    int i = dimension.width - this.legendSpace.left - this.legendSpace.right;
    int j = dimension.height - this.legendSpace.top - this.legendSpace.bottom;
    this.center = new Point(this.legendSpace.left + i / 2, this.legendSpace.top + j / 2);
    this.zero = new Point(this.center);
    int k = Math.min(i / 2 - this.fm.stringWidth(String.valueOf(this.model.getLabel(0))) - this.fm.stringWidth(String.valueOf(this.maxVal)) - this.xgap, j / 2 - 2 * this.fm.getHeight()) - this.xgap;
    k = Math.abs(k);
    this.yHeight = k;
    if (this.model.getStyle() == 18)
      drawRadar(paramGraphics, d1); 
    paintYLabelTick(paramGraphics, this.yMax, this.yMin, this.PRIMARYY, 0, 0, null);
    Number number1 = this.model.getMinimum();
    Number number2 = this.model.getMinorIncrement();
    Number number3 = this.model.getIncrement();
    double d2 = getYInc(number3, this.yMax, this.yMin, this.PRIMARYY);
    double d3 = getYs(number1, this.yMax, this.yMin, d2, this.PRIMARYY);
    for (byte b = 0; b < this.model.getDatasetSize(); b++) {
      double d8, d7, d4 = (90.0D + b * d1) * Math.PI / 180.0D;
      double d5 = Math.cos(d4);
      double d6 = Math.sin(d4);
      int m = (int)(k * d5);
      int n = (int)(k * d6);
      String str = this.model.getLabel(b);
      Common.drawLine(paramGraphics, this.center.x, this.center.y, (this.center.x + m), (this.center.y - n), 4097);
      if (m > 0) {
        d7 = this.xgap;
      } else if (m == 0) {
        d7 = (-this.fm.stringWidth((str == null) ? "" : str) / 2);
      } else {
        d7 = (-this.fm.stringWidth((str == null) ? "" : str) - this.xgap);
      } 
      if (n > 0) {
        d8 = (-this.fm.getDescent() - ((m == 0) ? this.xgap : 0));
      } else if (n == 0) {
        d8 = (this.fm.getAscent() / 2);
      } else {
        d8 = (this.fm.getAscent() + ((m == 0) ? this.xgap : 0));
      } 
      Common.drawString(paramGraphics, str, (this.center.x + m + (int)d7), (this.center.y - n + (int)d8));
      if (number2 != null || this.model.getGridStyle() == 0)
        for (double d = d3; d < this.yMax; ) {
          if (number2 != null) {
            double d9 = number2.doubleValue();
            for (double d10 = d + d9; d10 < d + d2 && d10 < this.yMax; d10 += d9) {
              double d11 = translateL(new Double(d10));
              Common.drawLine(paramGraphics, (int)(this.center.x + d11 * d5 - 2.0D * d6), (int)(this.center.y - d11 * d6 - 2.0D * d5), (int)(this.center.x + d11 * d5 + 2.0D * d6), (int)(this.center.y - d11 * d6 + 2.0D * d5), 4097);
            } 
          } 
          if (this.model.getGridStyle() == 0 && d > this.yMin) {
            double d9 = translateL(new Double(d));
            Common.drawLine(paramGraphics, (int)(this.center.x + d9 * d5 - 3.0D * d6), (int)(this.center.y - d9 * d6 - 3.0D * d5), (int)(this.center.x + d9 * d5 + 3.0D * d6), (int)(this.center.y - d9 * d6 + 3.0D * d5), 4097);
          } 
          d = this.desc.isLogarithmicYScale() ? (d * d2) : (d + d2);
        }  
    } 
    if (this.model.getGridStyle() != 0)
      for (double d = d3; d < this.yMax; ) {
        double d4 = translateL(new Double(d));
        for (byte b1 = 1; b1 <= this.model.getDatasetSize(); b1++) {
          double d5 = (90.0D + (b1 - true) * d1) * Math.PI / 180.0D;
          double d6 = (90.0D + b1 * d1) * Math.PI / 180.0D;
          int m = this.center.x + (int)(d4 * Math.cos(d5));
          int n = this.center.y - (int)(d4 * Math.sin(d5));
          int i1 = this.center.x + (int)(d4 * Math.cos(d6));
          int i2 = this.center.y - (int)(d4 * Math.sin(d6));
          Common.drawLine(paramGraphics, m, n, i1, i2, this.model.getGridStyle());
        } 
        d = this.desc.isLogarithmicYScale() ? (d * d2) : (d + d2);
      }  
    if (this.model.getStyle() != 18)
      drawRadar(paramGraphics, d1); 
  }
  
  private void drawRadar(Graphics paramGraphics, double paramDouble) {
    Color color = paramGraphics.getColor();
    char c = (this.desc == null) ? 4097 : ((int)this.desc.getLineChartLineWidth() | 0x1000);
    int i = (int)this.desc.getPointSize();
    for (byte b = 0; b < this.fRadar.size(); b++) {
      int j = ((Integer)this.fRadar.elementAt(b)).intValue();
      paramGraphics.setColor((Color)this.model.getColor(j));
      Polygon polygon = new Polygon();
      for (byte b1 = 1; b1 < this.model.getDatasetSize(); b1++) {
        double d1 = translateL(this.model.getData(j, b1 - true));
        double d2 = translateL(this.model.getData(j, b1));
        double d3 = (90.0D + (b1 - 1) * paramDouble) * Math.PI / 180.0D;
        double d4 = (90.0D + b1 * paramDouble) * Math.PI / 180.0D;
        int k = this.center.x + (int)(d1 * Math.cos(d3));
        int m = this.center.y - (int)(d1 * Math.sin(d3));
        int n = this.center.x + (int)(d2 * Math.cos(d4));
        int i1 = this.center.y - (int)(d2 * Math.sin(d4));
        if (this.model.getStyle() == 18) {
          polygon.addPoint(k, m);
          polygon.addPoint(n, i1);
          int[] arrayOfInt1 = { k, n, this.center.x };
          int[] arrayOfInt2 = { m, i1, this.center.y };
          this.areas.addElement(new GraphArea(this, b1, j, new Polygon(arrayOfInt1, arrayOfInt2, 3)));
        } else {
          Common.drawLine(paramGraphics, k, m, n, i1, c);
          Util.drawPoint(paramGraphics, k, m, i, this.desc.getPointStyle(j));
          int[] arrayOfInt1 = { k, n, n, k };
          int[] arrayOfInt2 = { m - 2, i1 - 2, i1 + 2, m + 2 };
          this.areas.addElement(new GraphArea(this, b1, j, new Polygon(arrayOfInt1, arrayOfInt2, 4)));
          if (b1 == this.model.getDatasetSize() - 1) {
            d1 = translateL(this.model.getData(j, 0));
            int i2 = this.center.x + (int)(d1 * Math.cos(1.5707963267948966D));
            int i3 = this.center.y - (int)(d1 * Math.sin(1.5707963267948966D));
            Common.drawLine(paramGraphics, i2, i3, n, i1, c);
            Util.drawPoint(paramGraphics, n, i1, i, this.desc.getPointStyle(j));
          } 
        } 
        if (this.model.getStyle() == 18)
          Common.fill(paramGraphics, polygon, (Color)this.model.getColor(j)); 
        Color color1 = paramGraphics.getColor();
        if (this.model.isShowValue()) {
          String str = toString(this.model.getData(j, b1 - 1));
          paramGraphics.setColor(this.context.getForeground());
          Common.drawString(paramGraphics, str, (k - this.fm.stringWidth(str) / 2), (m - this.fm.getDescent()));
          if (b1 == this.model.getDatasetSize() - 1) {
            str = toString(this.model.getData(j, b1));
            Common.drawString(paramGraphics, str, (n - this.fm.stringWidth(str) / 2), (i1 - this.fm.getDescent()));
          } 
        } 
        paramGraphics.setColor(color1);
      } 
    } 
    paramGraphics.setColor(color);
  }
  
  public Dimension getPreferredSize() { return new Dimension(-1000, -500); }
  
  public boolean isScalable() { return true; }
  
  public Dimension getSize() { return this.size; }
  
  public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.fm == null)
      this.fm = Common.getFontMetrics(this.context.getFont()); 
    if (this.model.getDatasetCount() == 0 || this.model.getDatasetSize() == 0 || paramInt3 <= 0 || paramInt4 <= 0)
      return; 
    this.size = new Dimension(paramInt3, paramInt4);
    getStyles();
    doLayout();
    Graphics graphics = paramGraphics.create(paramInt1, paramInt2, paramInt3, paramInt4);
    Color color = this.context.getBackground();
    this.c3D = null;
    if (color != null) {
      graphics.setColor(color);
      graphics.fillRect(0, 0, paramInt3, paramInt4);
    } 
    graphics.setColor(this.context.getForeground());
    graphics.setFont(this.context.getFont());
    try {
      Image image = this.desc.getBackgroundImage();
      if (image != null) {
        Common.waitForImage(image);
        int i = image.getWidth(null);
        int j = image.getHeight(null);
        for (int k = 0; k < paramInt3; k += i) {
          for (int m = 0; m < paramInt4; m += j)
            graphics.drawImage(image, k, m, null); 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    if (!isPie())
      if (isInverted()) {
        paintInvertedCoord1(graphics);
      } else {
        paintCoord1(graphics);
      }  
    this.areas.removeAllElements();
    Shape shape = graphics.getClip();
    if (!isPie())
      graphics.clipRect(0, 0, paramInt3, this.center.y); 
    if (this.fPie.size() != 0) {
      paintPie(graphics, false, true);
    } else if (this.fPieNoLabel.size() != 0) {
      paintPie(graphics, false, false);
    } else if (this.fPie3D.size() != 0) {
      paintPie(graphics, true, true);
    } else if (this.fPie3DNoLabel.size() != 0) {
      paintPie(graphics, true, false);
    } else if (this.fBubble.size() != 0) {
      paintPoint(graphics, false);
    } else if (this.fRadar.size() != 0) {
      paintRadar(graphics);
    } else {
      if (this.fBar3D3D.size() != 0)
        paintBar3D3D(graphics); 
      if (this.fStackBar3D.size() != 0 || this.fStackBar.size() != 0 || this.fStackArea.size() != 0)
        if (this.fStackBar3D.size() != 0) {
          paintStackBar3D(graphics);
        } else if (this.fStackBar.size() != 0) {
          paintStackBar(graphics);
        } else {
          paintStackArea(graphics);
        }  
      if (this.fBar3D.size() != 0)
        paintBar3D(graphics); 
      if (this.fArea.size() != 0)
        paintArea(graphics); 
      if (this.fBar.size() != 0)
        paintBar(graphics); 
      if (this.fCandle.size() != 0)
        paintCandle(graphics); 
      if (this.fStick.size() != 0)
        paintStick(graphics); 
      if (this.fStock.size() != 0)
        paintStock(graphics); 
      if (this.fLine.size() != 0)
        paintLine(graphics); 
      if (this.fPoint.size() != 0)
        paintPoint(graphics, true); 
    } 
    graphics.setClip(shape);
    if (!isPie())
      if (isInverted()) {
        paintInvertedXLabelTick(graphics);
      } else {
        paintXLabelTick(graphics);
      }  
    if (this.model.getBorderStyle() != 0) {
      int i = this.model.getBorderStyle();
      float f1 = Common.getLineWidth(i) + 1.0F;
      float f2 = Common.getLineAdjustment(graphics);
      Common.drawHLine(graphics, f2, 0.0F, paramInt3 - f1, i, 0, i);
      Common.drawVLine(graphics, f2, 0.0F, paramInt4 - f1, i, 0, i);
      Common.drawHLine(graphics, f2, paramInt3 - f1, (paramInt3 - 2), i, 0, i);
      Common.drawVLine(graphics, f2, paramInt4 - f1, (paramInt4 - 2), i, 0, i);
      if ((i & 0x4000) != 0) {
        i &= 0xFFFFBFFF;
        i |= 0x8000;
      } else if ((i & 0x8000) != 0) {
        i &= 0xFFFF7FFF;
        i |= 0x4000;
      } 
      Common.drawHLine(graphics, paramInt4 - f1 + f2, 0.0F, paramInt3 - f1, i, i, 0);
      Common.drawVLine(graphics, paramInt3 + f2 - f1, 0.0F, paramInt4 - f1, i, i, 0);
      Common.drawVLine(graphics, paramInt3 - f1 + f2, paramInt4 - f1, (paramInt4 - 2), i, i, 0);
      Common.drawHLine(graphics, paramInt4 - f1 + f2, paramInt3 - f1, (paramInt3 - 2), i, i, 0);
    } 
    if (this.model.getLegendPosition() != 0)
      paintLegend(graphics); 
    graphics.dispose();
  }
  
  public Point locate(int paramInt1, int paramInt2) {
    for (int i = this.areas.size() - 1; i >= 0; i--) {
      GraphArea graphArea = (GraphArea)this.areas.elementAt(i);
      if (graphArea.contains(paramInt1, paramInt2))
        return new Point(graphArea.x, graphArea.y); 
    } 
    return null;
  }
  
  public Shape[] getShapes(int paramInt1, int paramInt2) {
    Vector vector = new Vector();
    for (int i = this.areas.size() - 1; i >= 0; i--) {
      GraphArea graphArea = (GraphArea)this.areas.elementAt(i);
      if (graphArea.x == paramInt2 && graphArea.y == paramInt1)
        vector.addElement(graphArea.getShape()); 
    } 
    Shape[] arrayOfShape = new Shape[vector.size()];
    vector.copyInto(arrayOfShape);
    return arrayOfShape;
  }
  
  private void paintLegend(Graphics paramGraphics) {
    Dimension dimension = new Dimension(this.legendBox.width, this.legendBox.height);
    Graphics graphics = paramGraphics.create(this.legendBox.x, this.legendBox.y, this.legendBox.width, this.legendBox.height);
    Color color = this.context.getBackground();
    if (color == null)
      color = Color.white; 
    graphics.setColor(color);
    graphics.fillRect(0, 0, dimension.width, dimension.height);
    graphics.setColor(this.context.getForeground());
    graphics.drawRect(0, 0, dimension.width - 1, dimension.height - 1);
    graphics.setFont(this.context.getFont());
    int i = 0;
    for (byte b1 = 0; b1 < this.legendCnt; b1++) {
      String str = (String)this.legendLabels.elementAt(b1);
      i = Math.max(i, (int)Common.stringWidth(str, graphics.getFont()));
    } 
    i = Math.max(i + 3 * this.ggap, (int)Common.stringWidth("Secondary Y: ", this.context.getFont())) - 3 * this.ggap;
    int j = this.legendDim.height, k = this.legendDim.width;
    if (j <= 0 || k <= 0)
      return; 
    int m = (dimension.width - 3 * (k + 1)) / k;
    int n = (dimension.height - 3 * (j + 1)) / j;
    int i1 = Math.max(Math.min(m - i - 9, n - 6), 5);
    byte b2 = 0, b3 = 0;
    int i2 = isXScaled() ? (this.desc.getFirstDatasetOfSecondaryAxis() - 1) : this.desc.getFirstDatasetOfSecondaryAxis();
    i2 = (this.fBubble.size() == 0) ? i2 : (i2 / 2);
    boolean bool = false;
    int i3;
    label69: for (i3 = 0; i3 < j; i3++) {
      for (int i4 = 0; i4 < k; i4++) {
        if (b2 >= this.legendCnt)
          break label69; 
        int i5 = i4 * (m + 3) + 3;
        int i6 = i3 * (n + 3) + 3;
        if (i3 == 0 && i4 == 0 && i2 > 0 && i2 < this.model.getDatasetCount() && this.desc.getFirstDatasetOfSecondaryAxis() != -1 && this.desc.getFirstDatasetOfSecondaryAxis() <= this.model.getDatasetCount() - this.startY) {
          Common.drawString(graphics, "Primary Y:", i5, (i6 + (n - this.fm.getHeight()) / 2 + this.fm.getAscent()));
        } else if (!bool && i2 == b2 && i2 < this.model.getDatasetCount() && this.desc.getFirstDatasetOfSecondaryAxis() != -1) {
          Common.drawString(graphics, "Secondary Y: ", i5, (i6 + (n - this.fm.getHeight()) / 2 + this.fm.getAscent()));
          bool = true;
        } else {
          Rectangle rectangle = new Rectangle(i5, i6 + (n - i1) / 2, i1, i1);
          Object object = this.model.getColor(b2);
          if (object instanceof Image) {
            Image image = (Image)object;
            Shape shape = graphics.getClip();
            graphics.setClip(rectangle);
            graphics.drawImage(image, rectangle.x, rectangle.y, i1, i1, null);
            graphics.setClip(shape);
          } else if ((this.styles[b3] & 0x400) != 0) {
            graphics.setColor((Color)object);
            Util.drawPoint(graphics, rectangle.x + i1 / 2, rectangle.y + i1 / 2, i1, this.desc.getPointStyle(b2));
          } else if (this.styles[b3] == 528) {
            graphics.setColor((Color)object);
            Util.drawPoint(graphics, rectangle.x + i1 / 2, rectangle.y + i1 / 2, i1, 907);
          } else if (this.styles[b3] != 4106 && this.styles[b3] != 20) {
            Common.fill(graphics, rectangle, object);
          } 
          graphics.setColor(this.context.getForeground());
          Common.drawString(graphics, (String)this.legendLabels.elementAt(b2), (i5 + i1 + 3), (i6 + (n - this.fm.getHeight()) / 2 + this.fm.getAscent()));
          b2++;
          b3 += (Util.isFlatDatasetChart(this.model) ? 0 : 1);
        } 
      } 
    } 
    graphics.dispose();
  }
  
  private boolean isPie() { return (this.fPie.size() != 0 || this.fPieNoLabel.size() != 0 || this.fPie3D.size() != 0 || this.fPie3DNoLabel.size() != 0 || this.fRadar.size() != 0); }
  
  private boolean isInverted() { return ((this.model.getStyle() & 0x100) != 0); }
  
  private boolean isStack(int paramInt) { return (paramInt == 3 || paramInt == 7 || paramInt == 14 || paramInt == 259); }
  
  private boolean isXScaled() { return ((this.model.getStyle() & 0x200) != 0 && this.model.getDatasetCount() > 1 && (this.fPoint.size() != 0 || this.fLine.size() != 0 || (!this.fBubble.isEmpty() && this.model.getDatasetCount() % 2 == 1))); }
  
  private Object brighter(Object paramObject) {
    if (paramObject instanceof Color) {
      Color color = (Color)paramObject;
      return new Color(Math.min((int)(color.getRed() * 1.0D / this.contrast), 255), Math.min((int)(color.getGreen() * 1.0D / this.contrast), 255), Math.min((int)(color.getBlue() * 1.0D / this.contrast), 255));
    } 
    return paramObject;
  }
  
  private Object darker(Object paramObject) {
    if (paramObject instanceof Color) {
      Color color = (Color)paramObject;
      return new Color(Math.max((int)(color.getRed() * this.contrast), 0), Math.max((int)(color.getGreen() * this.contrast), 0), Math.max((int)(color.getBlue() * this.contrast), 0));
    } 
    return paramObject;
  }
  
  private String toString(Number paramNumber) {
    if (paramNumber == null)
      return ""; 
    NumberFormat numberFormat = (this.desc == null) ? null : this.desc.getValueFormat();
    return (numberFormat != null) ? numberFormat.format(paramNumber) : ((this.model.getPrecision() > 0) ? Util.toString(paramNumber, this.model.getPrecision()) : Util.toString(paramNumber));
  }
  
  private double log(double paramDouble) { return (paramDouble == 0.0D) ? 0.0D : (Math.log(paramDouble) / 2.302585092994046D); }
  
  class GraphArea implements Serializable {
    int x;
    
    int y;
    
    private Shape area;
    
    private final ChartPainter this$0;
    
    public GraphArea(ChartPainter this$0, int param1Int1, int param1Int2, Shape param1Shape) {
      this.this$0 = this$0;
      this.x = param1Int1;
      this.y = param1Int2;
      this.area = param1Shape;
    }
    
    public boolean contains(int param1Int1, int param1Int2) {
      if (this.area instanceof Polygon)
        return ((Polygon)this.area).contains(param1Int1, param1Int2); 
      if (this.area instanceof Rectangle)
        return ((Rectangle)this.area).contains(param1Int1, param1Int2); 
      return false;
    }
    
    public Shape getShape() { return this.area; }
    
    public String toString() { return this.x + "," + this.y + " at " + this.area; }
  }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
    paramObjectInputStream.defaultReadObject();
    int i = paramObjectInputStream.readInt();
    int j = paramObjectInputStream.readInt();
    DefaultChartLens defaultChartLens = new DefaultChartLens(i, j);
    for (byte b1 = 0; b1 < defaultChartLens.getDatasetSize(); b1++) {
      defaultChartLens.setLabel(b1, (String)paramObjectInputStream.readObject());
      defaultChartLens.setColor(b1, paramObjectInputStream.readObject());
    } 
    for (byte b2 = 0; b2 < defaultChartLens.getDatasetCount(); b2++)
      defaultChartLens.setDatasetLabel(b2, (String)paramObjectInputStream.readObject()); 
    for (byte b3 = 0; b3 < defaultChartLens.getDatasetCount(); b3++) {
      for (byte b = 0; b < defaultChartLens.getDatasetSize(); b++)
        defaultChartLens.setData(b3, b, (Number)paramObjectInputStream.readObject()); 
    } 
    defaultChartLens.setStyle(paramObjectInputStream.readInt());
    defaultChartLens.setMaximum((Number)paramObjectInputStream.readObject());
    defaultChartLens.setMinimum((Number)paramObjectInputStream.readObject());
    defaultChartLens.setIncrement((Number)paramObjectInputStream.readObject());
    defaultChartLens.setMinorIncrement((Number)paramObjectInputStream.readObject());
    defaultChartLens.setGap(paramObjectInputStream.readInt());
    defaultChartLens.setXTitle((String)paramObjectInputStream.readObject());
    defaultChartLens.setYTitle((String)paramObjectInputStream.readObject());
    defaultChartLens.setTitleFont((Font)paramObjectInputStream.readObject());
    defaultChartLens.setGridStyle(paramObjectInputStream.readInt());
    defaultChartLens.setBorderStyle(paramObjectInputStream.readInt());
    defaultChartLens.setShowValue(paramObjectInputStream.readBoolean());
    defaultChartLens.setPrecision(paramObjectInputStream.readInt());
    defaultChartLens.setLegendPosition(paramObjectInputStream.readInt());
    this.model = defaultChartLens;
    this.context = new DefaultContext();
    ((DefaultContext)this.context).read(paramObjectInputStream);
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    paramObjectOutputStream.defaultWriteObject();
    paramObjectOutputStream.writeInt(this.model.getDatasetCount());
    paramObjectOutputStream.writeInt(this.model.getDatasetSize());
    for (byte b1 = 0; b1 < this.model.getDatasetSize(); b1++) {
      paramObjectOutputStream.writeObject(this.model.getLabel(b1));
      paramObjectOutputStream.writeObject(this.model.getColor(b1));
    } 
    for (byte b2 = 0; b2 < this.model.getDatasetCount(); b2++)
      paramObjectOutputStream.writeObject(this.model.getDatasetLabel(b2)); 
    for (byte b3 = 0; b3 < this.model.getDatasetCount(); b3++) {
      for (byte b = 0; b < this.model.getDatasetSize(); b++)
        paramObjectOutputStream.writeObject(this.model.getData(b3, b)); 
    } 
    paramObjectOutputStream.writeInt(this.model.getStyle());
    paramObjectOutputStream.writeObject(this.model.getMaximum());
    paramObjectOutputStream.writeObject(this.model.getMinimum());
    paramObjectOutputStream.writeObject(this.model.getIncrement());
    paramObjectOutputStream.writeObject(this.model.getMinorIncrement());
    paramObjectOutputStream.writeInt(this.model.getGap());
    paramObjectOutputStream.writeObject(this.model.getXTitle());
    paramObjectOutputStream.writeObject(this.model.getYTitle());
    paramObjectOutputStream.writeObject(this.model.getTitleFont());
    paramObjectOutputStream.writeInt(this.model.getGridStyle());
    paramObjectOutputStream.writeInt(this.model.getBorderStyle());
    paramObjectOutputStream.writeBoolean(this.model.isShowValue());
    paramObjectOutputStream.writeInt(this.model.getPrecision());
    paramObjectOutputStream.writeInt(this.model.getLegendPosition());
    DefaultContext.write(paramObjectOutputStream, this.context);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\ChartPainter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */