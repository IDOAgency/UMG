package inetsoft.report;

public interface TabElement extends ReportElement {
  int getFillStyle();
  
  void setFillStyle(int paramInt);
  
  double[] getTabStops();
  
  void setTabStops(double[] paramArrayOfDouble);
  
  boolean isRightTab();
  
  void setRightTab(boolean paramBoolean);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\TabElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */