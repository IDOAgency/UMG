package inetsoft.report;

import inetsoft.report.event.PageBreakEvent;
import inetsoft.report.event.PageBreakListener;
import inetsoft.report.internal.AreaBreakElementDef;
import inetsoft.report.internal.BaseElement;
import inetsoft.report.internal.ChartElementDef;
import inetsoft.report.internal.CompositeElementDef;
import inetsoft.report.internal.CondPageBreakElementDef;
import inetsoft.report.internal.FormElementDef;
import inetsoft.report.internal.HFTextFormatter;
import inetsoft.report.internal.HeadingElementDef;
import inetsoft.report.internal.MessageDialog;
import inetsoft.report.internal.NewlineElementDef;
import inetsoft.report.internal.PageBreakElementDef;
import inetsoft.report.internal.PageLayoutElementDef;
import inetsoft.report.internal.PainterElementDef;
import inetsoft.report.internal.ScriptEnv;
import inetsoft.report.internal.SectionElementDef;
import inetsoft.report.internal.SeparatorElementDef;
import inetsoft.report.internal.SpaceElementDef;
import inetsoft.report.internal.StyleCore;
import inetsoft.report.internal.TOCElementDef;
import inetsoft.report.internal.TabElementDef;
import inetsoft.report.internal.TableElementDef;
import inetsoft.report.internal.TablePaintable;
import inetsoft.report.internal.TextBoxElementDef;
import inetsoft.report.internal.TextElementDef;
import inetsoft.report.internal.Util;
import inetsoft.report.lens.DefaultTextLens;
import inetsoft.report.painter.BulletPainter;
import inetsoft.report.painter.ComponentPainter;
import inetsoft.report.painter.ImagePainter;
import inetsoft.report.painter.PresenterPainter;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.PrintJob;
import java.awt.Rectangle;
import java.awt.image.ImageProducer;
import java.net.URL;
import java.text.Format;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;

public class StyleSheet extends StyleCore {
  public static final int TABLE_FIT_CONTENT = 0;
  
  public static final int TABLE_FIT_PAGE = 1;
  
  public static final int TABLE_EQUAL_WIDTH = 2;
  
  public static final int TABLE_FIT_CONTENT_1PP = 3;
  
  public static final int TABLE_FIT_CONTENT_PAGE = 4;
  
  public static final int PAINTER_NON_BREAK = 0;
  
  public static final int PAINTER_BREAKABLE = 1;
  
  public static final int DEFAULT_HEADER = 256;
  
  public static final int FIRST_PAGE_HEADER = 257;
  
  public static final int EVEN_PAGE_HEADER = 258;
  
  public static final int ODD_PAGE_HEADER = 259;
  
  public static final int DEFAULT_FOOTER = 512;
  
  public static final int FIRST_PAGE_FOOTER = 513;
  
  public static final int EVEN_PAGE_FOOTER = 514;
  
  public static final int ODD_PAGE_FOOTER = 515;
  
  public static final int BODY = 0;
  
  public static final int WRAP_NONE = 0;
  
  public static final int WRAP_LEFT = 1;
  
  public static final int WRAP_RIGHT = 2;
  
  public static final int WRAP_BOTH = 3;
  
  public static final int WRAP_TOP_BOTTOM = 256;
  
  public static StyleSheet createStyleSheet() { return Common.createStyleSheet(); }
  
  public void setMargin(Margin paramMargin) { this.margin = paramMargin; }
  
  public Margin getMargin() { return this.margin; }
  
  public Object getBackground() { return this.bg; }
  
  public void setBackground(Object paramObject) { this.bg = paramObject; }
  
  public void setHeaderFromEdge(double paramDouble) { this.headerFromEdge = paramDouble; }
  
  public double getHeaderFromEdge() { return this.headerFromEdge; }
  
  public void setFooterFromEdge(double paramDouble) { this.footerFromEdge = paramDouble; }
  
  public double getFooterFromEdge() { return this.footerFromEdge; }
  
  public Rectangle getHeaderBounds(Dimension paramDimension, int paramInt) { return new Rectangle((int)((this.margin.left - this.pmargin.left) * paramInt), (int)((this.headerFromEdge - this.pmargin.top) * paramInt), paramDimension.width - (int)((this.margin.left + this.margin.right) * paramInt), (int)((this.margin.top - this.headerFromEdge) * paramInt)); }
  
  public Rectangle getFooterBounds(Dimension paramDimension, int paramInt) { return new Rectangle((int)((this.margin.left - this.pmargin.left) * paramInt), paramDimension.height - (int)(this.footerFromEdge * paramInt), paramDimension.width - (int)((this.margin.left + this.margin.right) * paramInt), paramDimension.height - this.printBox.y); }
  
  public void setPageNumberingStart(int paramInt) { this.pgStart = paramInt; }
  
  public int getPageNumberingStart() { return this.pgStart; }
  
  public void setHorizontalWrap(boolean paramBoolean) { this.horFlow = paramBoolean; }
  
  public boolean isHorizontalWrap() { return this.horFlow; }
  
  public void saveContext(String paramString) { this.contexts.put(paramString, new Context(this)); }
  
  public void selectContext(String paramString) {
    Context context = (Context)this.contexts.get(paramString);
    if (context != null)
      context.restore(); 
  }
  
  public void removeContext(String paramString) { this.contexts.remove(paramString); }
  
  public String setPageAreas(PageArea[] paramArrayOfPageArea) { return setPageAreas(paramArrayOfPageArea, (ReportElement)null); }
  
  public String setPageAreas(PageArea[] paramArrayOfPageArea, ReportElement paramReportElement) {
    if (paramReportElement == null)
      return addElement(new PageLayoutElementDef(this, paramArrayOfPageArea)); 
    if (paramReportElement instanceof PageLayoutElement) {
      ((PageLayoutElement)paramReportElement).setPageAreas(paramArrayOfPageArea);
      return paramReportElement.getID();
    } 
    return insertElement(getElementIndex(paramReportElement), new PageLayoutElementDef(this, paramArrayOfPageArea));
  }
  
  public void setPageAreas(PageArea[] paramArrayOfPageArea, String paramString) {
    if (paramArrayOfPageArea == null) {
      this.areamap.remove(paramString);
    } else {
      this.areamap.put(paramString, paramArrayOfPageArea);
    } 
  }
  
  public String setPageColumns(int paramInt) { return setPageColumns(paramInt, null); }
  
  public String setPageColumns(int paramInt, ReportElement paramReportElement) {
    PageArea[] arrayOfPageArea = new PageArea[paramInt];
    double d1 = 0.02D;
    double d2 = (1.0D - d1 * (paramInt - 1.0D)) / paramInt;
    for (byte b = 0; b < arrayOfPageArea.length; b++)
      arrayOfPageArea[b] = new PageArea((d1 + d2) * b, 0.0D, d2, 1.0D, true); 
    return setPageAreas(arrayOfPageArea, paramReportElement);
  }
  
  public void setCurrentAlignment(int paramInt) { this.alignment = paramInt; }
  
  public int getCurrentAlignment() { return this.alignment; }
  
  public void setCurrentIndent(double paramDouble) { this.indent = paramDouble; }
  
  public double getCurrentIndent() { return this.indent; }
  
  public void setCurrentTabStops(double[] paramArrayOfDouble) { this.tabStops = paramArrayOfDouble; }
  
  public double[] getCurrentTabStops() { return this.tabStops; }
  
  public void setCurrentWrapping(int paramInt) { this.wrapping = paramInt; }
  
  public int getCurrentWrapping() { return this.wrapping; }
  
  public void moveAnchor(Position paramPosition) { this.anchor = paramPosition; }
  
  public void setCurrentLineSpacing(int paramInt) { this.spacing = paramInt; }
  
  public int getCurrentLineSpacing() { return this.spacing; }
  
  public void setCurrentFont(Font paramFont) { this.font = paramFont; }
  
  public Font getCurrentFont() { return this.font; }
  
  public void setCurrentForeground(Color paramColor) { this.foreground = paramColor; }
  
  public Color getCurrentForeground() { return this.foreground; }
  
  public void setCurrentBackground(Color paramColor) { this.background = paramColor; }
  
  public Color getCurrentBackground() { return this.background; }
  
  public void setCurrentTableLayout(int paramInt) { this.autosize = paramInt; }
  
  public int getCurrentTableLayout() { return this.autosize; }
  
  public void setCurrentPainterLayout(int paramInt) { this.painterLayout = paramInt; }
  
  public int getCurrentPainterLayout() { return this.painterLayout; }
  
  public void setCurrentPainterMargin(Insets paramInsets) { this.painterMargin = paramInsets; }
  
  public Insets getCurrentPainterMargin() { return this.painterMargin; }
  
  public void setCurrentChartDescriptor(ChartDescriptor paramChartDescriptor) { this.chartinfo = (paramChartDescriptor == null) ? null : (ChartDescriptor)paramChartDescriptor.clone(); }
  
  public ChartDescriptor getCurrentChartDescriptor() { return this.chartinfo; }
  
  public void setCurrentCellPadding(Insets paramInsets) { this.padding = paramInsets; }
  
  public Insets getCurrentCellPadding() { return this.padding; }
  
  public void setCurrentTableWidth(double paramDouble) { this.tableW = paramDouble; }
  
  public double getCurrentTableWidth() { return this.tableW; }
  
  public void setCurrentJustify(boolean paramBoolean) { this.justify = paramBoolean; }
  
  public boolean isCurrentJustify() { return this.justify; }
  
  public void setCurrentTextAdvance(int paramInt) { this.textadv = paramInt; }
  
  public int getCurrentTextAdvance() { return this.textadv; }
  
  public void setCurrentSeparatorAdvance(int paramInt) { this.sepadv = paramInt; }
  
  public int getCurrentSeparatorAdvance() { return this.sepadv; }
  
  public void setCurrentTableAdvance(int paramInt) { this.tableadv = paramInt; }
  
  public int getCurrentTableAdvance() { return this.tableadv; }
  
  public void setCurrentTableOrphanControl(boolean paramBoolean) { this.tableorphan = paramBoolean; }
  
  public boolean isCurrentTableOrphanControl() { return this.tableorphan; }
  
  public void setCurrentOrphanControl(boolean paramBoolean) { this.orphan = paramBoolean; }
  
  public boolean isCurrentOrphanControl() { return this.orphan; }
  
  public void addPresenter(Class paramClass, Presenter paramPresenter) { this.presentermap.put(paramClass, paramPresenter); }
  
  public Presenter getPresenter(Class paramClass) { return StyleCore.getPresenter(this.presentermap, paramClass); }
  
  public void removePresenter(Class paramClass) { this.presentermap.remove(paramClass); }
  
  public void clearPresenter() { this.presentermap.clear(); }
  
  public void addFormat(Class paramClass, Format paramFormat) { this.formatmap.put(paramClass, paramFormat); }
  
  public Format getFormat(Class paramClass) {
    Format format = null;
    while (paramClass != null && (format = (Format)this.formatmap.get(paramClass)) == null)
      paramClass = paramClass.getSuperclass(); 
    return format;
  }
  
  public void removeFormat(Class paramClass) { this.formatmap.remove(paramClass); }
  
  public void clearFormat() { this.formatmap.clear(); }
  
  public String addObject(Object paramObject) {
    Presenter presenter = (Presenter)this.presentermap.get(paramObject.getClass());
    String str = null;
    if (presenter != null) {
      str = addElement(new PainterElementDef(this, new PresenterPainter(paramObject, presenter)));
    } else {
      Format format = getFormat(paramObject.getClass());
      str = addText((format != null) ? format.format(paramObject) : Util.toString(paramObject));
    } 
    return str;
  }
  
  public String addText(String paramString) { return addText(new DefaultTextLens(paramString)); }
  
  public String addText(TextLens paramTextLens) {
    if (paramTextLens instanceof HeadingLens)
      return addElement(new HeadingElementDef(this, (HeadingLens)paramTextLens)); 
    return addElement(new TextElementDef(this, paramTextLens));
  }
  
  public String addTextBox(TextLens paramTextLens) { return addElement(new TextBoxElementDef(this, paramTextLens)); }
  
  public String addTextBox(String paramString) { return addText(new DefaultTextLens(paramString)); }
  
  public String addTextBox(TextLens paramTextLens, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) {
    TextBoxElementDef textBoxElementDef = new TextBoxElementDef(this, paramTextLens, paramDouble1, paramDouble2);
    textBoxElementDef.setBorder(paramInt1);
    textBoxElementDef.setTextAlignment(paramInt2);
    return addElement(textBoxElementDef);
  }
  
  public String addTextBox(String paramString, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) { return addTextBox(new DefaultTextLens(paramString), paramInt1, paramDouble1, paramDouble2, paramInt2); }
  
  public String addPainter(Painter paramPainter) {
    if (paramPainter instanceof ScaledPainter) {
      Size size = ((ScaledPainter)paramPainter).getSize();
      return addPainter(paramPainter, size.width, size.height);
    } 
    return addElement(new PainterElementDef(this, paramPainter));
  }
  
  public String addPainter(Painter paramPainter, double paramDouble1, double paramDouble2) { return addElement(new PainterElementDef(this, paramPainter, paramDouble1, paramDouble2)); }
  
  public String addChart(ChartLens paramChartLens) { return addElement(new ChartElementDef(this, paramChartLens)); }
  
  public String addChart(ChartLens paramChartLens, double paramDouble1, double paramDouble2) { return addElement(new ChartElementDef(this, paramChartLens, paramDouble1, paramDouble2)); }
  
  public String addComponent(Component paramComponent) { return addPainter(new ComponentPainter(paramComponent)); }
  
  public String addComponent(Component paramComponent, double paramDouble1, double paramDouble2) { return addPainter(new ComponentPainter(paramComponent), paramDouble1, paramDouble2); }
  
  public String addImage(Image paramImage) { return addPainter(new ImagePainter(paramImage)); }
  
  public String addImage(Image paramImage, double paramDouble1, double paramDouble2) { return addPainter(new ImagePainter(paramImage), paramDouble1, paramDouble2); }
  
  public String addImage(URL paramURL) {
    try {
      return addImage(Common.getToolkit().createImage((ImageProducer)paramURL.getContent()));
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public String addBullet() {
    BulletPainter bulletPainter = new BulletPainter();
    String str = addPainter(bulletPainter);
    this.hindent = (int)((bulletPainter.getSize()).width * this.resolution);
    return str;
  }
  
  public String addBullet(Image paramImage) {
    BulletPainter bulletPainter = new BulletPainter(paramImage);
    String str = addPainter(bulletPainter);
    this.hindent = (int)((bulletPainter.getSize()).width * this.resolution);
    return str;
  }
  
  public String addSpace(int paramInt) { return addElement(new SpaceElementDef(this, paramInt)); }
  
  public String addNewline(int paramInt) { return addElement(new NewlineElementDef(this, paramInt, false)); }
  
  public String addBreak() { return addElement(new NewlineElementDef(this, 1, true)); }
  
  public String addPageBreak() { return addElement(new PageBreakElementDef(this)); }
  
  public String addAreaBreak() { return addElement(new AreaBreakElementDef(this)); }
  
  public String addConditionalPageBreak(int paramInt) { return addElement(new CondPageBreakElementDef(this, paramInt)); }
  
  public String addConditionalPageBreak(double paramDouble) { return addElement(new CondPageBreakElementDef(this, paramDouble)); }
  
  public String addSeparator(int paramInt) { return addElement(new SeparatorElementDef(this, paramInt)); }
  
  public String addTab(int paramInt) { return addElement(new TabElementDef(this, paramInt)); }
  
  public String addRightTab() { return addElement(new TabElementDef(this, true)); }
  
  public String addTable(TableLens paramTableLens) { return addElement(new TableElementDef(this, paramTableLens)); }
  
  public String addForm(FormLens paramFormLens) { return addElement(new FormElementDef(this, paramFormLens)); }
  
  public String addTOC(TOC paramTOC) { return addElement(new TOCElementDef(this, paramTOC)); }
  
  public String addComposite(CompositeLens paramCompositeLens) { return addElement(new CompositeElementDef(this, paramCompositeLens)); }
  
  public String addSection(SectionLens paramSectionLens) { return addElement(new SectionElementDef(this, paramSectionLens, null)); }
  
  public String addSection(SectionLens paramSectionLens, TableLens paramTableLens) { return addElement(new SectionElementDef(this, paramSectionLens, paramTableLens)); }
  
  public void setCurrentHeader(int paramInt) {
    switch (paramInt) {
      case 256:
        this.currHeader = this.headerElements;
        break;
      case 257:
        this.currHeader = (this.firstHeader == null) ? (this.firstHeader = new Vector()) : this.firstHeader;
        break;
      case 258:
        this.currHeader = (this.evenHeader == null) ? (this.evenHeader = new Vector()) : this.evenHeader;
        break;
      case 259:
        this.currHeader = (this.oddHeader == null) ? (this.oddHeader = new Vector()) : this.oddHeader;
        break;
    } 
  }
  
  public void setCurrentHeader(String paramString) {
    this.currHeader = (Vector)this.elemHeader.get(paramString);
    if (this.currHeader == null)
      this.elemHeader.put(paramString, this.currHeader = new Vector()); 
  }
  
  public void setCurrentFooter(int paramInt) {
    switch (paramInt) {
      case 512:
        this.currFooter = this.footerElements;
        break;
      case 513:
        this.currFooter = (this.firstFooter == null) ? (this.firstFooter = new Vector()) : this.firstFooter;
        break;
      case 514:
        this.currFooter = (this.evenFooter == null) ? (this.evenFooter = new Vector()) : this.evenFooter;
        break;
      case 515:
        this.currFooter = (this.oddFooter == null) ? (this.oddFooter = new Vector()) : this.oddFooter;
        break;
    } 
  }
  
  public void setCurrentFooter(String paramString) {
    this.currFooter = (Vector)this.elemFooter.get(paramString);
    if (this.currFooter == null)
      this.elemFooter.put(paramString, this.currFooter = new Vector()); 
  }
  
  public String addHeaderObject(Object paramObject) {
    Presenter presenter = (Presenter)this.presentermap.get(paramObject.getClass());
    String str = null;
    if (presenter != null) {
      str = addHeaderElement(new PainterElementDef(this, new PresenterPainter(paramObject, presenter)));
    } else {
      Format format = getFormat(paramObject.getClass());
      str = addHeaderText((format != null) ? format.format(paramObject) : Util.toString(paramObject));
    } 
    return str;
  }
  
  public String addHeaderText(String paramString) { return addHeaderText(new DefaultTextLens(paramString)); }
  
  public String addHeaderText(TextLens paramTextLens) { return addHeaderElement(new TextElementDef(this, paramTextLens)); }
  
  public String addHeaderTextBox(TextLens paramTextLens) { return addHeaderElement(new TextBoxElementDef(this, paramTextLens)); }
  
  public String addHeaderTextBox(TextLens paramTextLens, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) {
    TextBoxElementDef textBoxElementDef = new TextBoxElementDef(this, paramTextLens, paramDouble1, paramDouble2);
    textBoxElementDef.setBorder(paramInt1);
    textBoxElementDef.setTextAlignment(paramInt2);
    return addHeaderElement(textBoxElementDef);
  }
  
  public String addHeaderPainter(Painter paramPainter) {
    if (paramPainter instanceof ScaledPainter) {
      Size size = ((ScaledPainter)paramPainter).getSize();
      return addHeaderPainter(paramPainter, size.width, size.height);
    } 
    return addHeaderElement(new PainterElementDef(this, paramPainter));
  }
  
  public String addHeaderPainter(Painter paramPainter, double paramDouble1, double paramDouble2) { return addHeaderElement(new PainterElementDef(this, paramPainter, paramDouble1, paramDouble2)); }
  
  public String addHeaderImage(Image paramImage) { return addHeaderPainter(new ImagePainter(paramImage)); }
  
  public String addHeaderImage(Image paramImage, double paramDouble1, double paramDouble2) { return addHeaderPainter(new ImagePainter(paramImage), paramDouble1, paramDouble2); }
  
  public String addHeaderImage(URL paramURL) {
    try {
      return addHeaderImage(Common.getToolkit().createImage((ImageProducer)paramURL.getContent()));
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public String addHeaderSpace(int paramInt) { return addHeaderElement(new SpaceElementDef(this, paramInt)); }
  
  public String addHeaderNewline(int paramInt) { return addHeaderElement(new NewlineElementDef(this, paramInt, false)); }
  
  public String addHeaderBreak() { return addHeaderElement(new NewlineElementDef(this, 1, true)); }
  
  public String addHeaderSeparator(int paramInt) { return addHeaderElement(new SeparatorElementDef(this, paramInt)); }
  
  public String addHeaderTab(int paramInt) { return addHeaderElement(new TabElementDef(this, paramInt)); }
  
  public String addHeaderRightTab() { return addHeaderElement(new TabElementDef(this, true)); }
  
  public String addHeaderTable(TableLens paramTableLens) { return addHeaderElement(new TableElementDef(this, paramTableLens)); }
  
  public String addFooterObject(Object paramObject) {
    Presenter presenter = (Presenter)this.presentermap.get(paramObject.getClass());
    String str = null;
    if (presenter != null) {
      str = addFooterElement(new PainterElementDef(this, new PresenterPainter(paramObject, presenter)));
    } else {
      Format format = getFormat(paramObject.getClass());
      str = addFooterText((format != null) ? format.format(paramObject) : Util.toString(paramObject));
    } 
    return str;
  }
  
  public String addFooterText(String paramString) { return addFooterText(new DefaultTextLens(paramString)); }
  
  public String addFooterText(TextLens paramTextLens) { return addFooterElement(new TextElementDef(this, paramTextLens)); }
  
  public String addFooterTextBox(TextLens paramTextLens) { return addFooterElement(new TextBoxElementDef(this, paramTextLens)); }
  
  public String addFooterTextBox(TextLens paramTextLens, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) {
    TextBoxElementDef textBoxElementDef = new TextBoxElementDef(this, paramTextLens, paramDouble1, paramDouble2);
    textBoxElementDef.setBorder(paramInt1);
    textBoxElementDef.setTextAlignment(paramInt2);
    return addFooterElement(textBoxElementDef);
  }
  
  public String addFooterPainter(Painter paramPainter) {
    if (paramPainter instanceof ScaledPainter) {
      Size size = ((ScaledPainter)paramPainter).getSize();
      return addFooterPainter(paramPainter, size.width, size.height);
    } 
    return addFooterElement(new PainterElementDef(this, paramPainter));
  }
  
  public String addFooterPainter(Painter paramPainter, double paramDouble1, double paramDouble2) { return addFooterElement(new PainterElementDef(this, paramPainter, paramDouble1, paramDouble2)); }
  
  public String addFooterImage(Image paramImage) { return addFooterPainter(new ImagePainter(paramImage)); }
  
  public String addFooterImage(Image paramImage, double paramDouble1, double paramDouble2) { return addFooterPainter(new ImagePainter(paramImage), paramDouble1, paramDouble2); }
  
  public String addFooterImage(URL paramURL) {
    try {
      return addFooterImage(Common.getToolkit().createImage((ImageProducer)paramURL.getContent()));
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public String addFooterSpace(int paramInt) { return addFooterElement(new SpaceElementDef(this, paramInt)); }
  
  public String addFooterNewline(int paramInt) { return addFooterElement(new NewlineElementDef(this, paramInt, false)); }
  
  public String addFooterBreak() { return addFooterElement(new NewlineElementDef(this, 1, true)); }
  
  public String addFooterSeparator(int paramInt) { return addFooterElement(new SeparatorElementDef(this, paramInt)); }
  
  public String addFooterTab(int paramInt) { return addFooterElement(new TabElementDef(this, paramInt)); }
  
  public String addFooterRightTab() { return addFooterElement(new TabElementDef(this, true)); }
  
  public String addFooterTable(TableLens paramTableLens) { return addFooterElement(new TableElementDef(this, paramTableLens)); }
  
  public ReportElement getElement(String paramString) {
    Vector[] arrayOfVector = { this.elements, this.headerElements, this.footerElements, this.firstHeader, this.firstFooter, this.evenHeader, this.evenFooter, this.oddHeader, this.oddFooter };
    for (byte b1 = 0; b1 < arrayOfVector.length; b1++) {
      if (arrayOfVector[b1] != null)
        for (byte b = 0; b < arrayOfVector[b1].size(); b++) {
          ReportElement reportElement = (ReportElement)arrayOfVector[b1].elementAt(b);
          if (reportElement.getID() != null && reportElement.getID().equals(paramString))
            return reportElement; 
        }  
    } 
    Enumeration[] arrayOfEnumeration = { this.elemHeader.elements(), this.elemFooter.elements() };
    for (byte b2 = 0; b2 < arrayOfEnumeration.length; b2++) {
      while (arrayOfEnumeration[b2].hasMoreElements()) {
        Vector vector = (Vector)arrayOfEnumeration[b2].nextElement();
        for (byte b = 0; b < vector.size(); b++) {
          ReportElement reportElement = (ReportElement)vector.elementAt(b);
          if (reportElement.getID() != null && reportElement.getID().equals(paramString))
            return reportElement; 
        } 
      } 
    } 
    for (byte b3 = 0; b3 < this.elements.size(); b3++) {
      if (this.elements.elementAt(b3) instanceof PageLayoutElement) {
        PageArea[] arrayOfPageArea = ((PageLayoutElement)this.elements.elementAt(b3)).getPageAreas();
        for (byte b = 0; b < arrayOfPageArea.length; b++) {
          FixedContainer fixedContainer = arrayOfPageArea[b].getElements();
          if (fixedContainer != null)
            for (byte b4 = 0; b4 < fixedContainer.getElementCount(); b4++) {
              if (fixedContainer.getElement(b4).getID().equals(paramString))
                return fixedContainer.getElement(b4); 
            }  
        } 
      } 
    } 
    return null;
  }
  
  public String addElement(ReportElement paramReportElement) {
    BaseElement baseElement = (BaseElement)paramReportElement;
    if (baseElement.isNewline() && !baseElement.isContinuation())
      this.hindent = 0; 
    baseElement.setStyleSheet(this);
    this.elements.addElement(paramReportElement);
    return paramReportElement.getID();
  }
  
  public int getElementCount() { return this.elements.size(); }
  
  public ReportElement getElement(int paramInt) { return (ReportElement)this.elements.elementAt(paramInt); }
  
  public int getElementIndex(ReportElement paramReportElement) { return this.elements.indexOf(paramReportElement, 0); }
  
  public void removeElement(int paramInt) {
    synchronized (this.elements) {
      if (paramInt >= 0 && paramInt < this.elements.size())
        this.elements.removeElementAt(paramInt); 
    } 
  }
  
  public String insertElement(int paramInt, ReportElement paramReportElement) {
    this.hindent = 0;
    synchronized (this.elements) {
      if (paramInt >= 0 && paramInt < this.elements.size())
        this.elements.insertElementAt(paramReportElement, paramInt); 
    } 
    return paramReportElement.getID();
  }
  
  public String addHeaderElement(ReportElement paramReportElement) {
    ((BaseElement)paramReportElement).setStyleSheet(this);
    this.currHeader.addElement(paramReportElement);
    return paramReportElement.getID();
  }
  
  public int getHeaderElementCount() { return this.currHeader.size(); }
  
  public ReportElement getHeaderElement(int paramInt) { return (ReportElement)this.currHeader.elementAt(paramInt); }
  
  public int getHeaderElementIndex(ReportElement paramReportElement) { return this.currHeader.indexOf(paramReportElement, 0); }
  
  public void removeHeaderElement(int paramInt) {
    synchronized (this.currHeader) {
      if (paramInt >= 0 && paramInt < this.currHeader.size())
        this.currHeader.removeElementAt(paramInt); 
    } 
  }
  
  public void insertHeaderElement(int paramInt, ReportElement paramReportElement) {
    synchronized (this.currHeader) {
      if (paramInt >= 0 && paramInt < this.currHeader.size())
        this.currHeader.insertElementAt(paramReportElement, paramInt); 
    } 
  }
  
  public String addFooterElement(ReportElement paramReportElement) {
    ((BaseElement)paramReportElement).setStyleSheet(this);
    this.currFooter.addElement(paramReportElement);
    return paramReportElement.getID();
  }
  
  public int getFooterElementCount() { return this.currFooter.size(); }
  
  public ReportElement getFooterElement(int paramInt) { return (ReportElement)this.currFooter.elementAt(paramInt); }
  
  public int getFooterElementIndex(ReportElement paramReportElement) { return this.currFooter.indexOf(paramReportElement, 0); }
  
  public void removeFooterElement(int paramInt) {
    synchronized (this.currFooter) {
      if (paramInt >= 0 && paramInt < this.currFooter.size())
        this.currFooter.removeElementAt(paramInt); 
    } 
  }
  
  public void insertFooterElement(int paramInt, ReportElement paramReportElement) {
    synchronized (this.currFooter) {
      if (paramInt >= 0 && paramInt < this.currFooter.size())
        this.currFooter.insertElementAt(paramReportElement, paramInt); 
    } 
  }
  
  public Vector getElements(int paramInt) {
    switch (paramInt) {
      case 256:
        return this.headerElements;
      case 257:
        return this.firstHeader;
      case 258:
        return this.evenHeader;
      case 259:
        return this.oddHeader;
      case 512:
        return this.footerElements;
      case 513:
        return this.firstFooter;
      case 514:
        return this.evenFooter;
      case 515:
        return this.oddFooter;
    } 
    return this.elements;
  }
  
  public void print() { Common.print(this); }
  
  public void print(PrintJob paramPrintJob) {
    boolean bool = true;
    Vector vector = new Vector();
    Dimension dimension = paramPrintJob.getPageDimension();
    this.resolution = 72;
    reset();
    while (bool) {
      StylePage stylePage = new StylePage(dimension, this.resolution);
      bool = printNext(stylePage);
      vector.addElement(stylePage);
    } 
    for (byte b = 0; b < vector.size(); b++) {
      StylePage stylePage = (StylePage)vector.elementAt(b);
      Graphics graphics = paramPrintJob.getGraphics();
      stylePage.print(graphics);
      graphics.dispose();
    } 
  }
  
  public boolean printNext(StylePage paramStylePage) {
    Dimension dimension = paramStylePage.getPageDimension();
    this.pmargin = getPrinterMargin();
    this.resolution = paramStylePage.getPageResolution();
    this.printBox = new Rectangle((int)((this.margin.left - this.pmargin.left) * this.resolution), (int)((this.margin.top - this.pmargin.top) * this.resolution), dimension.width - (int)((this.margin.left + this.margin.right) * this.resolution), dimension.height - (int)((this.margin.top + this.margin.bottom) * this.resolution));
    this.pageBox = this.printBox;
    this.frames = this.npframes = null;
    boolean bool = false;
    if (this.current == 0 && !this.designtime)
      runOnLoad(); 
    while (this.current < this.elements.size() && this.elements.elementAt(this.current) instanceof PageLayoutElement) {
      ((BaseElement)this.elements.elementAt(this.current++)).print(paramStylePage);
      bool = true;
    } 
    paramStylePage.setBackground(this.bg);
    if (!bool && this.current < this.elements.size()) {
      PageArea[] arrayOfPageArea = (PageArea[])this.areamap.get(getElement(this.current).getID());
      if (arrayOfPageArea != null) {
        this.areas = arrayOfPageArea;
        bool = true;
      } else if (this.npareas != null) {
        this.areas = this.npareas;
        bool = true;
      } 
    } 
    this.npareas = null;
    if (this.areas != null && this.areas.length > 0) {
      this.frames = getFrames(this.areas);
      paramStylePage.setPageAreas(this.areas);
      printNonFlowAreas(paramStylePage, this.areas, bool);
    } 
    if (this.frames == null || this.frames.length == 0)
      this.frames = new Rectangle[] { this.printBox }; 
    if (this.current >= this.elements.size()) {
      if (this.current == 0 || (this.current == 1 && bool))
        firePageBreakEvent(paramStylePage, false); 
      return false;
    } 
    for (this.currFrame = 0; this.currFrame < this.frames.length; this.currFrame++) {
      this.printBox = this.frames[this.currFrame];
      this.printHead.x = this.printHead.y = 0.0F;
      if (!printNextArea(paramStylePage, this.elements)) {
        firePageBreakEvent(paramStylePage, false);
        return false;
      } 
      if (this.current > 0 && this.elements.elementAt(this.current - 1) instanceof PageBreakElement) {
        firePageBreakEvent(paramStylePage, true);
        return true;
      } 
    } 
    firePageBreakEvent(paramStylePage, true);
    return true;
  }
  
  protected boolean printNextArea(StylePage paramStylePage, Vector paramVector) {
    do {
    
    } while (this.printHead.y < this.printBox.height && this.current < paramVector.size() && 
      !printNextLine(paramStylePage, paramVector));
    return (this.current < paramVector.size());
  }
  
  protected boolean printNextLine(StylePage paramStylePage, Vector paramVector) {
    if (this.current >= paramVector.size())
      return true; 
    int i = this.current;
    for (i = this.current; i < paramVector.size(); i++) {
      BaseElement baseElement1 = (BaseElement)paramVector.elementAt(i);
      baseElement1.setStyleSheet(this);
      if (baseElement1.isBlock() || (baseElement1.isNewline() && i > this.current))
        break; 
    } 
    BaseElement baseElement = (BaseElement)paramVector.elementAt(this.current);
    if (baseElement instanceof PainterElement) {
      PainterElementDef painterElementDef = (PainterElementDef)baseElement;
      if (painterElementDef.getAnchor() != null && (painterElementDef.getAnchor()).y - painterElementDef.getAnchorDepth() > 0.0F) {
        if (this.current > 0)
          painterElementDef.setAnchorElement((ReportElement)paramVector.elementAt(this.current - 1)); 
        float f = this.printHead.y;
        this.printHead.y += ((painterElementDef.getAnchor()).y - painterElementDef.getAnchorDepth()) * this.resolution;
        if (this.printHead.y > this.printBox.height) {
          painterElementDef.setAnchorDepth(painterElementDef.getAnchorDepth() + (this.printBox.height - f) / this.resolution);
          return true;
        } 
      } 
    } 
    this.lineH = 0.0F;
    if (i == this.current) {
      BaseElement baseElement1 = (BaseElement)paramVector.elementAt(this.current);
      if (!baseElement1.isVisible()) {
        this.current++;
        return false;
      } 
      FontMetrics fontMetrics = Common.getFontMetrics(baseElement1.getFont());
      this.printHead.x = 0.0F;
      if (baseElement1 instanceof CondPageBreakElement) {
        int j = ((CondPageBreakElementDef)baseElement1).getMinimumHeight();
        this.current++;
        baseElement1.print(paramStylePage);
        return (j + this.printHead.y > this.printBox.height);
      } 
      if (baseElement1 instanceof AreaBreakElement) {
        baseElement1.print(paramStylePage);
        this.current++;
        return true;
      } 
      if (baseElement1 instanceof PageLayoutElement)
        return true; 
      if (baseElement1 instanceof TableElement) {
        boolean bool = true;
        TableElementDef tableElementDef = (TableElementDef)baseElement1;
        tableElementDef.validate(paramStylePage);
        do {
          int j = tableElementDef.fitNext(this.printBox.height - this.printHead.y);
          if (j < 0) {
            if (bool && this.printHead.y > 0.0F)
              return true; 
            this.current++;
            return false;
          } 
          if (j == 0 && this.printHead.y > 0.0F)
            return true; 
          bool = tableElementDef.print(paramStylePage);
          if (bool && tableElementDef.getLayout() == 3)
            return true; 
        } while (bool);
      } else {
        if (!baseElement1.isBreakable()) {
          Size size = baseElement1.getPreferredSize();
          if (this.printHead.y + size.height > this.printBox.height && this.printHead.y > 0.0F)
            return true; 
        } 
        if (baseElement1 instanceof PainterElement)
          this.printHead.x = ((PainterElementDef)baseElement1).getAnchorX(); 
        if (baseElement1.print(paramStylePage))
          return true; 
      } 
      this.current++;
    } else {
      int j = -1;
      float f = 0.0F;
      for (int k = this.current; k < i; k++) {
        ReportElement reportElement = (ReportElement)paramVector.elementAt(k);
        if (reportElement instanceof PainterElement) {
          PainterElementDef painterElementDef = (PainterElementDef)reportElement;
          if (painterElementDef.getAnchor() != null) {
            j = k;
            if (painterElementDef.getAnchorX() + (painterElementDef.getPreferredSize()).width > this.printBox.width) {
              i = k + 1;
              break;
            } 
          } 
        } 
      } 
      if (j >= 0) {
        for (int m = this.current; m < i; m++) {
          BaseElement baseElement1 = (BaseElement)paramVector.elementAt(m);
          if (baseElement1 instanceof PainterElement) {
            PainterElementDef painterElementDef = (PainterElementDef)baseElement1;
            Size size = baseElement1.getPreferredSize();
            float f1 = (painterElementDef.getAnchor() == null || (painterElementDef.getAnchor()).y >= 0.0F) ? 0.0F : (-(painterElementDef.getAnchor()).y * this.resolution);
            size.height += f1;
            if (this.printHead.y + f1 >= this.printBox.height && this.printHead.y > 0.0F)
              return true; 
            if (this.printHead.y + size.height > (this.printBox.height + 1) && 
              !painterElementDef.isBreakable() && this.printHead.y > 0.0F) {
              painterElementDef.setAnchorDepth(painterElementDef.getAnchorDepth() + this.printHead.y / this.resolution);
              return true;
            } 
            f = Math.max(f, size.height);
          } 
        } 
        Position position = new Position(this.printHead);
        Vector vector1 = new Vector();
        Vector vector2 = new Vector();
        Vector vector3 = new Vector();
        Vector vector4 = this.horFlow ? null : new Vector();
        for (int n = this.current; n < i; n++) {
          BaseElement baseElement1 = (BaseElement)paramVector.elementAt(n);
          if (baseElement1 instanceof PainterElement && ((PainterElement)baseElement1).getAnchor() != null) {
            PainterElementDef painterElementDef = (PainterElementDef)baseElement1;
            float f1 = painterElementDef.getAnchorX();
            if (n > this.current)
              painterElementDef.setAnchorElement((ReportElement)paramVector.elementAt(this.current)); 
            Size size = painterElementDef.getPreferredSize();
            float f2 = f1 + Math.min(this.printBox.width - f1, size.width);
            if (this.horFlow) {
              float f3 = this.printHead.y + this.printBox.y - (painterElementDef.getAnchor()).y * this.resolution;
              float f4 = f1 + this.printBox.x;
              vector1.addElement(new Rectangle((int)f4, (int)f3, (int)size.width, (int)size.height));
            } else {
              Rectangle rectangle1 = new Rectangle((int)(this.printHead.x + this.printBox.x), (int)(this.printHead.y + this.printBox.y), (int)(f1 - this.printHead.x), (int)f);
              vector1.addElement(rectangle1);
            } 
            if (!this.horFlow) {
              vector2.addElement(vector4);
              vector4 = new Vector();
            } 
            vector3.addElement(baseElement1);
            if (painterElementDef.getWrapping() != 0)
              this.printHead.x = f2; 
          } else {
            (this.horFlow ? vector2 : vector4).addElement(baseElement1);
          } 
        } 
        if (!this.horFlow) {
          Rectangle rectangle1 = new Rectangle((int)(this.printHead.x + this.printBox.x), (int)(this.printHead.y + this.printBox.y), (int)(this.printBox.width - this.printHead.x), (int)f);
          vector1.addElement(rectangle1);
          vector2.addElement(vector4);
        } 
        int i1 = i;
        Vector vector5 = paramVector;
        Rectangle rectangle = this.printBox;
        for (byte b = 0; b < vector3.size(); b++) {
          PainterElementDef painterElementDef = (PainterElementDef)vector3.elementAt(b);
          Position position1 = this.printHead;
          Rectangle rectangle1 = this.printBox;
          float f1 = position.y;
          if ((painterElementDef.getAnchor()).y < 0.0F)
            f1 += -(painterElementDef.getAnchor()).y * this.resolution; 
          this.printBox = rectangle;
          this.printHead = new Position(painterElementDef.getAnchorX(), f1);
          painterElementDef.print(paramStylePage);
          this.printHead = position1;
          this.printBox = rectangle1;
        } 
        boolean bool = false;
        if (this.horFlow) {
          Rectangle[][] arrayOfRectangle = calcGrid(position.x + rectangle.x, position.y + rectangle.y, rectangle.width, f, vector1);
          vector5 = vector2;
          this.current = 0;
          for (byte b1 = 0; b1 < arrayOfRectangle.length; b1++) {
            if (arrayOfRectangle[b1].length != 0) {
              int i2 = 0;
              for (byte b2 = 0; b2 < arrayOfRectangle[b1].length; b2++) {
                this.printHead = new Position(0.0F, 0.0F);
                this.printBox = arrayOfRectangle[b1][b2];
                boolean bool1 = printNextLine(paramStylePage, vector5);
                i2 = Math.max(i2, (int)this.printHead.y);
              } 
              for (byte b3 = 0; b3 < arrayOfRectangle[b1].length; b3++) {
                (arrayOfRectangle[b1][b3]).y += i2;
                (arrayOfRectangle[b1][b3]).height -= i2;
              } 
              if (i2 > 0 && arrayOfRectangle[b1].length > 0 && (arrayOfRectangle[b1][0]).height > 0)
                b1--; 
            } 
          } 
          bool = (this.current < paramVector.size());
        } else {
          int i2 = 0;
          for (byte b1 = 0; b1 < vector2.size(); b1++) {
            vector4 = (Vector)vector2.elementAt(b1);
            if (vector4.size() > 0) {
              boolean bool1 = i2;
              i2 = Math.max(i2, b1);
              if (i2 == 0 || bool1 != i2) {
                this.printHead.x = this.printHead.y = 0.0F;
                this.printBox = (Rectangle)vector1.elementAt(i2);
              } 
              vector5 = vector4;
              this.current = 0;
              while ((bool = printNextArea(paramStylePage, vector5)) && i2 < vector1.size() - 1) {
                this.printHead.x = this.printHead.y = 0.0F;
                this.printBox = (Rectangle)vector1.elementAt(++i2);
              } 
            } 
          } 
        } 
        this.printBox = rectangle;
        this.printHead = new Position(0.0F, position.y + f);
        if (bool)
          if (printNextArea(paramStylePage, vector5)) {
            Object object = vector5.elementAt(this.current);
            int i2 = paramVector.indexOf(object);
            if (i2 >= 0)
              i1 = i2; 
          }  
        this.current = i1;
      } else {
        for (int m = this.current; m < i; ) {
          int n = 0;
          for (; m < i; m++) {
            BaseElement baseElement1 = (BaseElement)paramVector.elementAt(m);
            int i4 = baseElement1.getAlignment() & 0x7;
            if ((i4 < n && !baseElement1.isFlowControl()) || (baseElement1.isNewline() && m > this.current))
              break; 
            if (baseElement1.isLastOnLine()) {
              m++;
              break;
            } 
            if (!baseElement1.isFlowControl())
              n = i4; 
          } 
          this.printHead.x = 0.0F;
          float f1 = this.printHead.y;
          float f2 = 0.0F;
          float f3 = 0.0F, f4 = 0.0F, f5 = 0.0F;
          this.lineH = 0.0F;
          for (int i1 = this.current; i1 < m; i1++) {
            BaseElement baseElement1 = (BaseElement)paramVector.elementAt(i1);
            Size size = baseElement1.getPreferredSize();
            if (!baseElement1.isBreakable() && this.printHead.y + size.height > this.printBox.height) {
              boolean bool = (this.printHead.y > 0.0F) ? 1 : 0;
              if (!bool) {
                for (byte b = 0; b < this.frames.length; b++) {
                  if ((this.frames[b]).height > size.height) {
                    bool = true;
                    break;
                  } 
                } 
                if (!bool && this.npframes != null)
                  for (byte b1 = 0; b1 < this.npframes.length; b1++) {
                    if ((this.npframes[b1]).height > size.height) {
                      bool = true;
                      break;
                    } 
                  }  
              } 
              if (bool)
                return true; 
            } 
            if (i1 == j) {
              PainterElementDef painterElementDef = (PainterElementDef)baseElement1;
              float f9 = painterElementDef.getAnchorX();
              f3 = f9 + size.width;
            } else {
              f3 += size.width;
            } 
            if (i1 > j && this.printHead.x + f3 > this.printBox.width && !(baseElement1 instanceof TextElement)) {
              boolean bool = (!(baseElement1 instanceof PainterElement) && baseElement1.isBreakable()) ? 1 : 0;
              m = Math.max(bool ? (i1 + 1) : i1, this.current + 1);
            } 
            m = Math.min(m, paramVector.size());
            if (i1 < m) {
              if ((baseElement1.getAlignment() & 0x2) != 0) {
                f4 += size.width;
              } else if ((baseElement1.getAlignment() & 0x4) != 0) {
                f5 += size.width;
              } 
              if (baseElement1 instanceof PainterElement) {
                PainterElementDef painterElementDef = (PainterElementDef)baseElement1;
                if (painterElementDef.getAnchor() != null && (painterElementDef.getAnchor()).y < 0.0F)
                  size.height += -(painterElementDef.getAnchor()).y * this.resolution; 
              } 
              f = Math.max(f, size.height);
            } 
          } 
          float f6 = this.printHead.x;
          float f7 = Math.max((this.printBox.width - f4) / 2.0F, 0.0F);
          float f8 = Math.max(this.printBox.width - f5, 0.0F);
          int i2 = paramStylePage.getPaintableCount();
          this.lastHead = new Position(this.printHead);
          for (int i3 = this.current; i3 < m; i3++) {
            BaseElement baseElement1 = (BaseElement)paramVector.elementAt(i3);
            byte b = 0;
            this.printHead.y = f1;
            if ((baseElement1.getAlignment() & true) != 0 && f6 >= this.printHead.x) {
              this.printHead.x = f6;
              b = 0;
            } else if ((baseElement1.getAlignment() & 0x2) != 0 && f7 >= this.printHead.x) {
              this.printHead.x = f7;
              b = 1;
            } else if ((baseElement1.getAlignment() & 0x4) != 0 && f8 >= this.printHead.x) {
              this.printHead.x = f8;
              b = 2;
            } 
            if (this.printHead.x >= this.printBox.width) {
              advance(0.0F, this.lineH);
              f1 = this.printHead.y;
              this.lineH = 0.0F;
              f6 = f7 = f8 = 0.0F;
              alignLine(i2, paramStylePage.getPaintableCount(), paramStylePage, this.lineH);
              i2 = paramStylePage.getPaintableCount();
            } 
            int i4 = paramStylePage.getPaintableCount();
            if (baseElement1.print(paramStylePage)) {
              this.current = i3;
              this.printHead.y = Math.max(this.printHead.y, f1 + this.lineH);
              return (this.printHead.y >= this.printBox.height || i4 == paramStylePage.getPaintableCount());
            } 
            if (baseElement1 instanceof PainterElement)
              this.lastHead = new Position(this.printHead); 
            f2 = this.printHead.x;
            switch (b) {
              case 0:
                f6 = this.printHead.x;
                break;
              case 1:
                f7 = this.printHead.x;
                break;
              case 2:
                f8 = this.printHead.x;
                break;
            } 
            if (this.advanceLine > 0.0F) {
              float f9 = f1;
              f1 = this.printHead.y - this.advanceLine;
              this.lineH = Math.max(f9 + this.lineH - f1, this.advanceLine);
              alignLine(i2, i4 + 1, paramStylePage, this.lineH);
              i2 = paramStylePage.getPaintableCount() - 1;
            } else {
              this.lineH = Math.max(this.lineH, this.printHead.y - f1);
            } 
          } 
          alignLine(i2, paramStylePage.getPaintableCount(), paramStylePage, this.lineH);
          this.printHead.y = f1;
          this.printHead.x = f2;
          this.current = m;
          if (this.lineH > 0.0F && this.current < paramVector.size() && !(paramVector.elementAt(this.current - 1) instanceof NewlineElement) && paramVector.elementAt(this.current) instanceof NewlineElement) {
            NewlineElementDef newlineElementDef = (NewlineElementDef)paramVector.elementAt(this.current);
            newlineElementDef.skip();
            if (newlineElementDef.getRemain() <= 0) {
              Size size = newlineElementDef.getPreferredSize();
              this.printHead.y += this.lineH - size.height - 1.0F;
              newlineElementDef.print(paramStylePage);
              this.printHead.y = f1;
              this.current++;
            } 
          } 
          advance(0.0F, this.lineH);
        } 
      } 
    } 
    return false;
  }
  
  protected void printHeaderFooter(StylePage paramStylePage) {
    Vector vector1 = null;
    int i = this.current;
    Dimension dimension = paramStylePage.getPageDimension();
    this.resolution = paramStylePage.getPageResolution();
    Vector vector2 = null;
    Vector vector3 = null, vector4 = null;
    if (this.hfFmt == null)
      this.hfFmt = new HFTextFormatter(new Date(), this.pgStart); 
    int j = this.hfFmt.getPageNumber();
    int k = this.hfFmt.getPageIndex();
    for (byte b = 0; b < paramStylePage.getPaintableCount(); b++) {
      BaseElement baseElement = (BaseElement)paramStylePage.getPaintable(b).getElement();
      if (baseElement instanceof HeadingElement)
        this.headingMap.put(baseElement, new Integer(j)); 
      if (baseElement != null) {
        Vector vector = (Vector)this.elemHeader.get(baseElement.getID());
        if (vector != null)
          vector3 = vector; 
      } 
      if (baseElement != null) {
        Vector vector = (Vector)this.elemFooter.get(baseElement.getID());
        if (vector != null)
          vector4 = vector; 
      } 
    } 
    this.printBox = getHeaderBounds(dimension, this.resolution);
    this.frames = new Rectangle[] { this.printBox };
    this.npframes = null;
    this.currFrame = 0;
    this.printHead.x = this.printHead.y = 0.0F;
    if (!this.designtime && vector3 != null)
      vector2 = this.overrideHeader = (Vector)vector3.clone(); 
    if (this.overrideHeader != null) {
      vector2 = this.overrideHeader;
    } else if (k == 0 && this.firstHeader != null && this.firstHeader.size() > 0) {
      vector2 = (Vector)this.firstHeader.clone();
    } else if (k % 2 == 0 && this.oddHeader != null && this.oddHeader.size() > 0) {
      vector2 = (Vector)this.oddHeader.clone();
    } else if (k % 2 == 1 && this.evenHeader != null && this.evenHeader.size() > 0) {
      vector2 = (Vector)this.evenHeader.clone();
    } else {
      vector2 = (Vector)this.headerElements.clone();
    } 
    processHF(vector2);
    vector1 = vector2;
    this.current = 0;
    printNextArea(paramStylePage, vector1);
    this.printBox = getFooterBounds(dimension, this.resolution);
    this.frames = new Rectangle[] { this.printBox };
    this.npframes = null;
    this.currFrame = 0;
    this.printHead.x = this.printHead.y = 0.0F;
    if (!this.designtime && vector4 != null)
      vector2 = this.overrideFooter = (Vector)vector4.clone(); 
    if (this.overrideFooter != null) {
      vector2 = this.overrideFooter;
    } else if (k == 0 && this.firstFooter != null && this.firstFooter.size() > 0) {
      vector2 = (Vector)this.firstFooter.clone();
    } else if (k % 2 == 0 && this.oddFooter != null && this.oddFooter.size() > 0) {
      vector2 = (Vector)this.oddFooter.clone();
    } else if (k % 2 == 1 && this.evenFooter != null && this.evenFooter.size() > 0) {
      vector2 = (Vector)this.evenFooter.clone();
    } else {
      vector2 = (Vector)this.footerElements.clone();
    } 
    processHF(vector2);
    vector1 = vector2;
    this.current = 0;
    printNextArea(paramStylePage, vector1);
    this.current = i;
  }
  
  protected void printNonFlowAreas(StylePage paramStylePage, PageArea[] paramArrayOfPageArea, boolean paramBoolean) {
    for (byte b = 0; b < paramArrayOfPageArea.length; b++) {
      if (paramArrayOfPageArea[b].getBorder() != 0) {
        Rectangle rectangle = paramArrayOfPageArea[b].getBounds(this.pageBox, this.resolution);
        Common.drawRect(paramStylePage, rectangle.x, rectangle.y, rectangle.width, rectangle.height, paramArrayOfPageArea[b].getBorder(), paramArrayOfPageArea[b].getBorderColor());
      } 
      if (!paramArrayOfPageArea[b].isFlow() && paramArrayOfPageArea[b].getElements() != null) {
        FixedContainer fixedContainer = paramArrayOfPageArea[b].getElements();
        Rectangle rectangle = paramArrayOfPageArea[b].getPrintArea(this.printBox, 72);
        printFixedContainer(paramStylePage, fixedContainer, rectangle, (paramBoolean || paramArrayOfPageArea[b].isRepeat()));
      } 
    } 
  }
  
  Vector listeners = new Vector();
  
  public void addPageBreakListener(PageBreakListener paramPageBreakListener) { this.listeners.addElement(paramPageBreakListener); }
  
  public void removePageBreakListener(PageBreakListener paramPageBreakListener) { this.listeners.removeElement(paramPageBreakListener); }
  
  public String getOnPageBreak() { return this.pagebreakCmd; }
  
  public void setOnPageBreak(String paramString) {
    this.pagebreakCmd = paramString;
    this.pagebreakScript = null;
  }
  
  public String getOnLoad() { return this.loadCmd; }
  
  public void setOnLoad(String paramString) {
    this.loadCmd = paramString;
    this.loadScript = null;
  }
  
  public void firePageBreakEvent(StylePage paramStylePage, boolean paramBoolean) {
    try {
      if (paramStylePage.getPaintableCount() > 1 && this.current > 0 && this.current < this.elements.size()) {
        int i = paramStylePage.getPaintableCount() - 1;
        Paintable paintable = paramStylePage.getPaintable(i);
        if (paintable.getElement().isKeepWithNext()) {
          Paintable paintable1 = paramStylePage.getPaintable(0);
          ReportElement reportElement = paintable.getElement();
          String str = reportElement.getID();
          if (!paintable1.getElement().getID().equals(str)) {
            for (; i >= 0 && paramStylePage.getPaintable(i).getElement().getID().equals(str); 
              i--)
              paramStylePage.removePaintable(i); 
            ((BaseElement)reportElement).reset();
            int j = this.current;
            while (j > 0 && !this.elements.elementAt(j).equals(reportElement))
              j--; 
            if (j > 0)
              this.current = j; 
          } 
        } 
      } 
      if (paramStylePage.getPaintableCount() > 0) {
        Vector vector = (Vector)this.listeners.clone();
        Paintable paintable1 = paramStylePage.getPaintable(paramStylePage.getPaintableCount() - 1);
        Rectangle rectangle1 = null;
        String str1 = (paintable1.getElement() != null) ? paintable1.getElement().getID() : "";
        Paintable paintable2 = paramStylePage.getPaintable(0);
        Rectangle rectangle2 = null;
        String str2 = (paintable2.getElement() != null) ? paintable2.getElement().getID() : "";
        if (paintable1 instanceof TablePaintable)
          rectangle1 = ((TablePaintable)paintable1).getTableRegion(); 
        if (paintable2 instanceof TablePaintable)
          rectangle2 = ((TablePaintable)paintable2).getTableRegion(); 
        PageBreakEvent pageBreakEvent = new PageBreakEvent(paramStylePage, str1, rectangle1, str2, rectangle2, !paramBoolean);
        for (int i = vector.size() - 1; i >= 0; i--)
          ((PageBreakListener)vector.elementAt(i)).valueChanged(pageBreakEvent); 
        String str3 = getOnPageBreak();
        if (str3 != null && !this.designtime) {
          ScriptEnv scriptEnv = getScriptEnv();
          if (scriptEnv != null) {
            if (this.pagebreakScript == null)
              this.pagebreakScript = scriptEnv.compile(str3); 
            scriptEnv.put("event", pageBreakEvent);
            try {
              scriptEnv.exec(null, this.pagebreakScript, null);
            } catch (Exception exception) {
              if (this.designtime) {
                MessageDialog.show(exception + "\n" + str3);
              } else {
                System.err.println("onPageBreak script failed: " + exception);
              } 
            } 
          } 
        } 
      } 
      printHeaderFooter(paramStylePage);
      this.hfFmt.nextPage(paramBoolean);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public void clear() {
    checkLimit();
    this.elements.removeAllElements();
    Vector[] arrayOfVector = { this.headerElements, this.footerElements, this.firstHeader, this.firstFooter, this.evenHeader, this.evenFooter, this.oddHeader, this.oddFooter };
    for (byte b = 0; b < arrayOfVector.length; b++) {
      if (arrayOfVector[b] != null)
        arrayOfVector[b].removeAllElements(); 
    } 
    this.elemHeader.clear();
    this.elemFooter.clear();
    if (this.scriptenv != null) {
      this.scriptenv.reset();
      this.scriptenv = null;
    } 
  }
  
  public void finalize() { clear(); }
  
  public void reset() {
    this.current = 0;
    this.areas = this.npareas = null;
    this.npframes = null;
    this.hfFmt = null;
    this.loadCalled = false;
    if (this.scriptenv != null)
      this.scriptenv.reset(); 
    if (!this.designtime)
      this.overrideHeader = this.overrideFooter = null; 
    for (byte b1 = 0; b1 < this.headingCnt.length; b1++)
      this.headingCnt[b1] = 0; 
    for (byte b2 = 0; b2 < this.elements.size(); b2++)
      ((BaseElement)this.elements.elementAt(b2)).reset(); 
    Vector[] arrayOfVector = { this.headerElements, this.footerElements, this.firstHeader, this.firstFooter, this.evenHeader, this.evenFooter, this.oddHeader, this.oddFooter };
    for (byte b3 = 0; b3 < arrayOfVector.length; b3++) {
      if (arrayOfVector[b3] != null)
        for (byte b = 0; b < arrayOfVector[b3].size(); b++)
          ((BaseElement)arrayOfVector[b3].elementAt(b)).reset();  
    } 
    Enumeration[] arrayOfEnumeration = { this.elemHeader.elements(), this.elemFooter.elements() };
    for (byte b4 = 0; b4 < arrayOfEnumeration.length; b4++) {
      while (arrayOfEnumeration[b4].hasMoreElements()) {
        Vector vector = (Vector)arrayOfEnumeration[b4].nextElement();
        for (byte b = 0; b < vector.size(); b++)
          ((BaseElement)vector.elementAt(b)).reset(); 
      } 
    } 
    this.pagebreakScript = null;
  }
  
  public void setVisible(String paramString, boolean paramBoolean) {
    ReportElement reportElement = getElement(paramString);
    if (reportElement != null)
      reportElement.setVisible(paramBoolean); 
  }
  
  public String getProperty(String paramString) { return this.prop.getProperty(paramString); }
  
  public void setProperty(String paramString1, String paramString2) { this.prop.put(paramString1, paramString2); }
  
  public static void setPrinterMargin(Margin paramMargin) { StyleCore.g_pmargin = paramMargin; }
  
  public static Margin getPrinterMargin() { return StyleCore.g_pmargin; }
  
  public static String getVersion() { return version; }
  
  private static String version = "3.5.1";
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\StyleSheet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */