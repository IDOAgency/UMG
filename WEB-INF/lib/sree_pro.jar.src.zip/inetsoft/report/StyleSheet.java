/*      */ package inetsoft.report;
/*      */ 
/*      */ import inetsoft.report.event.PageBreakEvent;
/*      */ import inetsoft.report.event.PageBreakListener;
/*      */ import inetsoft.report.internal.AreaBreakElementDef;
/*      */ import inetsoft.report.internal.BaseElement;
/*      */ import inetsoft.report.internal.ChartElementDef;
/*      */ import inetsoft.report.internal.CompositeElementDef;
/*      */ import inetsoft.report.internal.CondPageBreakElementDef;
/*      */ import inetsoft.report.internal.FormElementDef;
/*      */ import inetsoft.report.internal.HFTextFormatter;
/*      */ import inetsoft.report.internal.HeadingElementDef;
/*      */ import inetsoft.report.internal.MessageDialog;
/*      */ import inetsoft.report.internal.NewlineElementDef;
/*      */ import inetsoft.report.internal.PageBreakElementDef;
/*      */ import inetsoft.report.internal.PageLayoutElementDef;
/*      */ import inetsoft.report.internal.PainterElementDef;
/*      */ import inetsoft.report.internal.ScriptEnv;
/*      */ import inetsoft.report.internal.SectionElementDef;
/*      */ import inetsoft.report.internal.SeparatorElementDef;
/*      */ import inetsoft.report.internal.SpaceElementDef;
/*      */ import inetsoft.report.internal.StyleCore;
/*      */ import inetsoft.report.internal.TOCElementDef;
/*      */ import inetsoft.report.internal.TabElementDef;
/*      */ import inetsoft.report.internal.TableElementDef;
/*      */ import inetsoft.report.internal.TablePaintable;
/*      */ import inetsoft.report.internal.TextBoxElementDef;
/*      */ import inetsoft.report.internal.TextElementDef;
/*      */ import inetsoft.report.internal.Util;
/*      */ import inetsoft.report.lens.DefaultTextLens;
/*      */ import inetsoft.report.painter.BulletPainter;
/*      */ import inetsoft.report.painter.ComponentPainter;
/*      */ import inetsoft.report.painter.ImagePainter;
/*      */ import inetsoft.report.painter.PresenterPainter;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.PrintJob;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.image.ImageProducer;
/*      */ import java.net.URL;
/*      */ import java.text.Format;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StyleSheet
/*      */   extends StyleCore
/*      */ {
/*      */   public static final int TABLE_FIT_CONTENT = 0;
/*      */   public static final int TABLE_FIT_PAGE = 1;
/*      */   public static final int TABLE_EQUAL_WIDTH = 2;
/*      */   public static final int TABLE_FIT_CONTENT_1PP = 3;
/*      */   public static final int TABLE_FIT_CONTENT_PAGE = 4;
/*      */   public static final int PAINTER_NON_BREAK = 0;
/*      */   public static final int PAINTER_BREAKABLE = 1;
/*      */   public static final int DEFAULT_HEADER = 256;
/*      */   public static final int FIRST_PAGE_HEADER = 257;
/*      */   public static final int EVEN_PAGE_HEADER = 258;
/*      */   public static final int ODD_PAGE_HEADER = 259;
/*      */   public static final int DEFAULT_FOOTER = 512;
/*      */   public static final int FIRST_PAGE_FOOTER = 513;
/*      */   public static final int EVEN_PAGE_FOOTER = 514;
/*      */   public static final int ODD_PAGE_FOOTER = 515;
/*      */   public static final int BODY = 0;
/*      */   public static final int WRAP_NONE = 0;
/*      */   public static final int WRAP_LEFT = 1;
/*      */   public static final int WRAP_RIGHT = 2;
/*      */   public static final int WRAP_BOTH = 3;
/*      */   public static final int WRAP_TOP_BOTTOM = 256;
/*      */   
/*  178 */   public static StyleSheet createStyleSheet() { return Common.createStyleSheet(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  186 */   public void setMargin(Margin paramMargin) { this.margin = paramMargin; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  194 */   public Margin getMargin() { return this.margin; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  201 */   public Object getBackground() { return this.bg; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  210 */   public void setBackground(Object paramObject) { this.bg = paramObject; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  219 */   public void setHeaderFromEdge(double paramDouble) { this.headerFromEdge = paramDouble; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  228 */   public double getHeaderFromEdge() { return this.headerFromEdge; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  237 */   public void setFooterFromEdge(double paramDouble) { this.footerFromEdge = paramDouble; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  246 */   public double getFooterFromEdge() { return this.footerFromEdge; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  256 */   public Rectangle getHeaderBounds(Dimension paramDimension, int paramInt) { return new Rectangle((int)((this.margin.left - this.pmargin.left) * paramInt), (int)((this.headerFromEdge - this.pmargin.top) * paramInt), paramDimension.width - (int)((this.margin.left + this.margin.right) * paramInt), (int)((this.margin.top - this.headerFromEdge) * paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  269 */   public Rectangle getFooterBounds(Dimension paramDimension, int paramInt) { return new Rectangle((int)((this.margin.left - this.pmargin.left) * paramInt), paramDimension.height - (int)(this.footerFromEdge * paramInt), paramDimension.width - (int)((this.margin.left + this.margin.right) * paramInt), paramDimension.height - this.printBox.y); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  281 */   public void setPageNumberingStart(int paramInt) { this.pgStart = paramInt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  289 */   public int getPageNumberingStart() { return this.pgStart; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  301 */   public void setHorizontalWrap(boolean paramBoolean) { this.horFlow = paramBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  308 */   public boolean isHorizontalWrap() { return this.horFlow; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  319 */   public void saveContext(String paramString) { this.contexts.put(paramString, new Context(this)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void selectContext(String paramString) {
/*  328 */     Context context = (Context)this.contexts.get(paramString);
/*  329 */     if (context != null) {
/*  330 */       context.restore();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  339 */   public void removeContext(String paramString) { this.contexts.remove(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  357 */   public String setPageAreas(PageArea[] paramArrayOfPageArea) { return setPageAreas(paramArrayOfPageArea, (ReportElement)null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String setPageAreas(PageArea[] paramArrayOfPageArea, ReportElement paramReportElement) {
/*  372 */     if (paramReportElement == null) {
/*  373 */       return addElement(new PageLayoutElementDef(this, paramArrayOfPageArea));
/*      */     }
/*  375 */     if (paramReportElement instanceof PageLayoutElement) {
/*  376 */       ((PageLayoutElement)paramReportElement).setPageAreas(paramArrayOfPageArea);
/*  377 */       return paramReportElement.getID();
/*      */     } 
/*      */     
/*  380 */     return insertElement(getElementIndex(paramReportElement), new PageLayoutElementDef(this, paramArrayOfPageArea));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPageAreas(PageArea[] paramArrayOfPageArea, String paramString) {
/*  395 */     if (paramArrayOfPageArea == null) {
/*  396 */       this.areamap.remove(paramString);
/*      */     } else {
/*      */       
/*  399 */       this.areamap.put(paramString, paramArrayOfPageArea);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  411 */   public String setPageColumns(int paramInt) { return setPageColumns(paramInt, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String setPageColumns(int paramInt, ReportElement paramReportElement) {
/*  425 */     PageArea[] arrayOfPageArea = new PageArea[paramInt];
/*  426 */     double d1 = 0.02D;
/*  427 */     double d2 = (1.0D - d1 * (paramInt - 1.0D)) / paramInt;
/*      */     
/*  429 */     for (byte b = 0; b < arrayOfPageArea.length; b++) {
/*  430 */       arrayOfPageArea[b] = new PageArea((d1 + d2) * b, 0.0D, d2, 1.0D, true);
/*      */     }
/*      */     
/*  433 */     return setPageAreas(arrayOfPageArea, paramReportElement);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  444 */   public void setCurrentAlignment(int paramInt) { this.alignment = paramInt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  452 */   public int getCurrentAlignment() { return this.alignment; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  462 */   public void setCurrentIndent(double paramDouble) { this.indent = paramDouble; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  470 */   public double getCurrentIndent() { return this.indent; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  478 */   public void setCurrentTabStops(double[] paramArrayOfDouble) { this.tabStops = paramArrayOfDouble; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  486 */   public double[] getCurrentTabStops() { return this.tabStops; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  496 */   public void setCurrentWrapping(int paramInt) { this.wrapping = paramInt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  504 */   public int getCurrentWrapping() { return this.wrapping; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  519 */   public void moveAnchor(Position paramPosition) { this.anchor = paramPosition; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  530 */   public void setCurrentLineSpacing(int paramInt) { this.spacing = paramInt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  538 */   public int getCurrentLineSpacing() { return this.spacing; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  551 */   public void setCurrentFont(Font paramFont) { this.font = paramFont; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  559 */   public Font getCurrentFont() { return this.font; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  569 */   public void setCurrentForeground(Color paramColor) { this.foreground = paramColor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  577 */   public Color getCurrentForeground() { return this.foreground; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  587 */   public void setCurrentBackground(Color paramColor) { this.background = paramColor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  595 */   public Color getCurrentBackground() { return this.background; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  630 */   public void setCurrentTableLayout(int paramInt) { this.autosize = paramInt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  638 */   public int getCurrentTableLayout() { return this.autosize; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  652 */   public void setCurrentPainterLayout(int paramInt) { this.painterLayout = paramInt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  660 */   public int getCurrentPainterLayout() { return this.painterLayout; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  669 */   public void setCurrentPainterMargin(Insets paramInsets) { this.painterMargin = paramInsets; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  677 */   public Insets getCurrentPainterMargin() { return this.painterMargin; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  684 */   public void setCurrentChartDescriptor(ChartDescriptor paramChartDescriptor) { this.chartinfo = (paramChartDescriptor == null) ? null : (ChartDescriptor)paramChartDescriptor.clone(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  692 */   public ChartDescriptor getCurrentChartDescriptor() { return this.chartinfo; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  708 */   public void setCurrentCellPadding(Insets paramInsets) { this.padding = paramInsets; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  716 */   public Insets getCurrentCellPadding() { return this.padding; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  725 */   public void setCurrentTableWidth(double paramDouble) { this.tableW = paramDouble; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  733 */   public double getCurrentTableWidth() { return this.tableW; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  741 */   public void setCurrentJustify(boolean paramBoolean) { this.justify = paramBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  749 */   public boolean isCurrentJustify() { return this.justify; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  758 */   public void setCurrentTextAdvance(int paramInt) { this.textadv = paramInt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  766 */   public int getCurrentTextAdvance() { return this.textadv; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  775 */   public void setCurrentSeparatorAdvance(int paramInt) { this.sepadv = paramInt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  783 */   public int getCurrentSeparatorAdvance() { return this.sepadv; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  792 */   public void setCurrentTableAdvance(int paramInt) { this.tableadv = paramInt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  800 */   public int getCurrentTableAdvance() { return this.tableadv; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  808 */   public void setCurrentTableOrphanControl(boolean paramBoolean) { this.tableorphan = paramBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  816 */   public boolean isCurrentTableOrphanControl() { return this.tableorphan; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  824 */   public void setCurrentOrphanControl(boolean paramBoolean) { this.orphan = paramBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  832 */   public boolean isCurrentOrphanControl() { return this.orphan; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  847 */   public void addPresenter(Class paramClass, Presenter paramPresenter) { this.presentermap.put(paramClass, paramPresenter); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  857 */   public Presenter getPresenter(Class paramClass) { return StyleCore.getPresenter(this.presentermap, paramClass); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  866 */   public void removePresenter(Class paramClass) { this.presentermap.remove(paramClass); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  873 */   public void clearPresenter() { this.presentermap.clear(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  884 */   public void addFormat(Class paramClass, Format paramFormat) { this.formatmap.put(paramClass, paramFormat); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Format getFormat(Class paramClass) {
/*  894 */     Format format = null;
/*  895 */     while (paramClass != null && (format = (Format)this.formatmap.get(paramClass)) == null) {
/*  896 */       paramClass = paramClass.getSuperclass();
/*      */     }
/*      */     
/*  899 */     return format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  908 */   public void removeFormat(Class paramClass) { this.formatmap.remove(paramClass); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  915 */   public void clearFormat() { this.formatmap.clear(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addObject(Object paramObject) {
/*  940 */     Presenter presenter = (Presenter)this.presentermap.get(paramObject.getClass());
/*  941 */     String str = null;
/*      */     
/*  943 */     if (presenter != null) {
/*  944 */       str = addElement(new PainterElementDef(this, new PresenterPainter(paramObject, presenter)));
/*      */     }
/*      */     else {
/*      */       
/*  948 */       Format format = getFormat(paramObject.getClass());
/*  949 */       str = addText((format != null) ? format.format(paramObject) : Util.toString(paramObject));
/*      */     } 
/*      */     
/*  952 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  963 */   public String addText(String paramString) { return addText(new DefaultTextLens(paramString)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addText(TextLens paramTextLens) {
/*  980 */     if (paramTextLens instanceof HeadingLens) {
/*  981 */       return addElement(new HeadingElementDef(this, (HeadingLens)paramTextLens));
/*      */     }
/*      */     
/*  984 */     return addElement(new TextElementDef(this, paramTextLens));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  998 */   public String addTextBox(TextLens paramTextLens) { return addElement(new TextBoxElementDef(this, paramTextLens)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1012 */   public String addTextBox(String paramString) { return addText(new DefaultTextLens(paramString)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addTextBox(TextLens paramTextLens, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) {
/* 1032 */     TextBoxElementDef textBoxElementDef = new TextBoxElementDef(this, paramTextLens, paramDouble1, paramDouble2);
/* 1033 */     textBoxElementDef.setBorder(paramInt1);
/* 1034 */     textBoxElementDef.setTextAlignment(paramInt2);
/* 1035 */     return addElement(textBoxElementDef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1055 */   public String addTextBox(String paramString, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) { return addTextBox(new DefaultTextLens(paramString), paramInt1, paramDouble1, paramDouble2, paramInt2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addPainter(Painter paramPainter) {
/* 1071 */     if (paramPainter instanceof ScaledPainter) {
/* 1072 */       Size size = ((ScaledPainter)paramPainter).getSize();
/* 1073 */       return addPainter(paramPainter, size.width, size.height);
/*      */     } 
/*      */     
/* 1076 */     return addElement(new PainterElementDef(this, paramPainter));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1094 */   public String addPainter(Painter paramPainter, double paramDouble1, double paramDouble2) { return addElement(new PainterElementDef(this, paramPainter, paramDouble1, paramDouble2)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1105 */   public String addChart(ChartLens paramChartLens) { return addElement(new ChartElementDef(this, paramChartLens)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1123 */   public String addChart(ChartLens paramChartLens, double paramDouble1, double paramDouble2) { return addElement(new ChartElementDef(this, paramChartLens, paramDouble1, paramDouble2)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1133 */   public String addComponent(Component paramComponent) { return addPainter(new ComponentPainter(paramComponent)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1151 */   public String addComponent(Component paramComponent, double paramDouble1, double paramDouble2) { return addPainter(new ComponentPainter(paramComponent), paramDouble1, paramDouble2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1160 */   public String addImage(Image paramImage) { return addPainter(new ImagePainter(paramImage)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1178 */   public String addImage(Image paramImage, double paramDouble1, double paramDouble2) { return addPainter(new ImagePainter(paramImage), paramDouble1, paramDouble2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addImage(URL paramURL) {
/*      */     try {
/* 1188 */       return addImage(Common.getToolkit().createImage((ImageProducer)paramURL.getContent()));
/*      */     } catch (Exception exception) {
/*      */       
/* 1191 */       exception.printStackTrace();
/*      */ 
/*      */       
/* 1194 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addBullet() {
/* 1207 */     BulletPainter bulletPainter = new BulletPainter();
/* 1208 */     String str = addPainter(bulletPainter);
/* 1209 */     this.hindent = (int)((bulletPainter.getSize()).width * this.resolution);
/* 1210 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addBullet(Image paramImage) {
/* 1220 */     BulletPainter bulletPainter = new BulletPainter(paramImage);
/* 1221 */     String str = addPainter(bulletPainter);
/* 1222 */     this.hindent = (int)((bulletPainter.getSize()).width * this.resolution);
/* 1223 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1233 */   public String addSpace(int paramInt) { return addElement(new SpaceElementDef(this, paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1242 */   public String addNewline(int paramInt) { return addElement(new NewlineElementDef(this, paramInt, false)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1252 */   public String addBreak() { return addElement(new NewlineElementDef(this, 1, true)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1261 */   public String addPageBreak() { return addElement(new PageBreakElementDef(this)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1271 */   public String addAreaBreak() { return addElement(new AreaBreakElementDef(this)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1282 */   public String addConditionalPageBreak(int paramInt) { return addElement(new CondPageBreakElementDef(this, paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1293 */   public String addConditionalPageBreak(double paramDouble) { return addElement(new CondPageBreakElementDef(this, paramDouble)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1303 */   public String addSeparator(int paramInt) { return addElement(new SeparatorElementDef(this, paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1312 */   public String addTab(int paramInt) { return addElement(new TabElementDef(this, paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1321 */   public String addRightTab() { return addElement(new TabElementDef(this, true)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1333 */   public String addTable(TableLens paramTableLens) { return addElement(new TableElementDef(this, paramTableLens)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1344 */   public String addForm(FormLens paramFormLens) { return addElement(new FormElementDef(this, paramFormLens)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1356 */   public String addTOC(TOC paramTOC) { return addElement(new TOCElementDef(this, paramTOC)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1370 */   public String addComposite(CompositeLens paramCompositeLens) { return addElement(new CompositeElementDef(this, paramCompositeLens)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1379 */   public String addSection(SectionLens paramSectionLens) { return addElement(new SectionElementDef(this, paramSectionLens, null)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1390 */   public String addSection(SectionLens paramSectionLens, TableLens paramTableLens) { return addElement(new SectionElementDef(this, paramSectionLens, paramTableLens)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCurrentHeader(int paramInt) {
/* 1401 */     switch (paramInt) {
/*      */       case 256:
/* 1403 */         this.currHeader = this.headerElements;
/*      */         break;
/*      */       case 257:
/* 1406 */         this.currHeader = (this.firstHeader == null) ? (this.firstHeader = new Vector()) : this.firstHeader;
/*      */         break;
/*      */       
/*      */       case 258:
/* 1410 */         this.currHeader = (this.evenHeader == null) ? (this.evenHeader = new Vector()) : this.evenHeader;
/*      */         break;
/*      */       
/*      */       case 259:
/* 1414 */         this.currHeader = (this.oddHeader == null) ? (this.oddHeader = new Vector()) : this.oddHeader;
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCurrentHeader(String paramString) {
/* 1429 */     this.currHeader = (Vector)this.elemHeader.get(paramString);
/*      */     
/* 1431 */     if (this.currHeader == null) {
/* 1432 */       this.elemHeader.put(paramString, this.currHeader = new Vector());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCurrentFooter(int paramInt) {
/* 1444 */     switch (paramInt) {
/*      */       case 512:
/* 1446 */         this.currFooter = this.footerElements;
/*      */         break;
/*      */       case 513:
/* 1449 */         this.currFooter = (this.firstFooter == null) ? (this.firstFooter = new Vector()) : this.firstFooter;
/*      */         break;
/*      */       
/*      */       case 514:
/* 1453 */         this.currFooter = (this.evenFooter == null) ? (this.evenFooter = new Vector()) : this.evenFooter;
/*      */         break;
/*      */       
/*      */       case 515:
/* 1457 */         this.currFooter = (this.oddFooter == null) ? (this.oddFooter = new Vector()) : this.oddFooter;
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCurrentFooter(String paramString) {
/* 1472 */     this.currFooter = (Vector)this.elemFooter.get(paramString);
/*      */     
/* 1474 */     if (this.currFooter == null) {
/* 1475 */       this.elemFooter.put(paramString, this.currFooter = new Vector());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addHeaderObject(Object paramObject) {
/* 1497 */     Presenter presenter = (Presenter)this.presentermap.get(paramObject.getClass());
/* 1498 */     String str = null;
/*      */     
/* 1500 */     if (presenter != null) {
/* 1501 */       str = addHeaderElement(new PainterElementDef(this, new PresenterPainter(paramObject, presenter)));
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1506 */       Format format = getFormat(paramObject.getClass());
/* 1507 */       str = addHeaderText((format != null) ? format.format(paramObject) : Util.toString(paramObject));
/*      */     } 
/*      */     
/* 1510 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1541 */   public String addHeaderText(String paramString) { return addHeaderText(new DefaultTextLens(paramString)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1552 */   public String addHeaderText(TextLens paramTextLens) { return addHeaderElement(new TextElementDef(this, paramTextLens)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1567 */   public String addHeaderTextBox(TextLens paramTextLens) { return addHeaderElement(new TextBoxElementDef(this, paramTextLens)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addHeaderTextBox(TextLens paramTextLens, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) {
/* 1588 */     TextBoxElementDef textBoxElementDef = new TextBoxElementDef(this, paramTextLens, paramDouble1, paramDouble2);
/* 1589 */     textBoxElementDef.setBorder(paramInt1);
/* 1590 */     textBoxElementDef.setTextAlignment(paramInt2);
/* 1591 */     return addHeaderElement(textBoxElementDef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addHeaderPainter(Painter paramPainter) {
/* 1607 */     if (paramPainter instanceof ScaledPainter) {
/* 1608 */       Size size = ((ScaledPainter)paramPainter).getSize();
/* 1609 */       return addHeaderPainter(paramPainter, size.width, size.height);
/*      */     } 
/*      */     
/* 1612 */     return addHeaderElement(new PainterElementDef(this, paramPainter));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1630 */   public String addHeaderPainter(Painter paramPainter, double paramDouble1, double paramDouble2) { return addHeaderElement(new PainterElementDef(this, paramPainter, paramDouble1, paramDouble2)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1639 */   public String addHeaderImage(Image paramImage) { return addHeaderPainter(new ImagePainter(paramImage)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1657 */   public String addHeaderImage(Image paramImage, double paramDouble1, double paramDouble2) { return addHeaderPainter(new ImagePainter(paramImage), paramDouble1, paramDouble2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addHeaderImage(URL paramURL) {
/*      */     try {
/* 1667 */       return addHeaderImage(Common.getToolkit().createImage((ImageProducer)paramURL.getContent()));
/*      */     } catch (Exception exception) {
/*      */       
/* 1670 */       exception.printStackTrace();
/*      */ 
/*      */       
/* 1673 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1683 */   public String addHeaderSpace(int paramInt) { return addHeaderElement(new SpaceElementDef(this, paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1692 */   public String addHeaderNewline(int paramInt) { return addHeaderElement(new NewlineElementDef(this, paramInt, false)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1700 */   public String addHeaderBreak() { return addHeaderElement(new NewlineElementDef(this, 1, true)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1710 */   public String addHeaderSeparator(int paramInt) { return addHeaderElement(new SeparatorElementDef(this, paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1719 */   public String addHeaderTab(int paramInt) { return addHeaderElement(new TabElementDef(this, paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1728 */   public String addHeaderRightTab() { return addHeaderElement(new TabElementDef(this, true)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1739 */   public String addHeaderTable(TableLens paramTableLens) { return addHeaderElement(new TableElementDef(this, paramTableLens)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addFooterObject(Object paramObject) {
/* 1760 */     Presenter presenter = (Presenter)this.presentermap.get(paramObject.getClass());
/* 1761 */     String str = null;
/*      */     
/* 1763 */     if (presenter != null) {
/* 1764 */       str = addFooterElement(new PainterElementDef(this, new PresenterPainter(paramObject, presenter)));
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1769 */       Format format = getFormat(paramObject.getClass());
/* 1770 */       str = addFooterText((format != null) ? format.format(paramObject) : Util.toString(paramObject));
/*      */     } 
/*      */     
/* 1773 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1804 */   public String addFooterText(String paramString) { return addFooterText(new DefaultTextLens(paramString)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1815 */   public String addFooterText(TextLens paramTextLens) { return addFooterElement(new TextElementDef(this, paramTextLens)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1830 */   public String addFooterTextBox(TextLens paramTextLens) { return addFooterElement(new TextBoxElementDef(this, paramTextLens)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addFooterTextBox(TextLens paramTextLens, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) {
/* 1851 */     TextBoxElementDef textBoxElementDef = new TextBoxElementDef(this, paramTextLens, paramDouble1, paramDouble2);
/* 1852 */     textBoxElementDef.setBorder(paramInt1);
/* 1853 */     textBoxElementDef.setTextAlignment(paramInt2);
/* 1854 */     return addFooterElement(textBoxElementDef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addFooterPainter(Painter paramPainter) {
/* 1870 */     if (paramPainter instanceof ScaledPainter) {
/* 1871 */       Size size = ((ScaledPainter)paramPainter).getSize();
/* 1872 */       return addFooterPainter(paramPainter, size.width, size.height);
/*      */     } 
/*      */     
/* 1875 */     return addFooterElement(new PainterElementDef(this, paramPainter));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1893 */   public String addFooterPainter(Painter paramPainter, double paramDouble1, double paramDouble2) { return addFooterElement(new PainterElementDef(this, paramPainter, paramDouble1, paramDouble2)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1902 */   public String addFooterImage(Image paramImage) { return addFooterPainter(new ImagePainter(paramImage)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1920 */   public String addFooterImage(Image paramImage, double paramDouble1, double paramDouble2) { return addFooterPainter(new ImagePainter(paramImage), paramDouble1, paramDouble2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addFooterImage(URL paramURL) {
/*      */     try {
/* 1930 */       return addFooterImage(Common.getToolkit().createImage((ImageProducer)paramURL.getContent()));
/*      */     } catch (Exception exception) {
/*      */       
/* 1933 */       exception.printStackTrace();
/*      */ 
/*      */       
/* 1936 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1946 */   public String addFooterSpace(int paramInt) { return addFooterElement(new SpaceElementDef(this, paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1955 */   public String addFooterNewline(int paramInt) { return addFooterElement(new NewlineElementDef(this, paramInt, false)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1963 */   public String addFooterBreak() { return addFooterElement(new NewlineElementDef(this, 1, true)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1973 */   public String addFooterSeparator(int paramInt) { return addFooterElement(new SeparatorElementDef(this, paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1982 */   public String addFooterTab(int paramInt) { return addFooterElement(new TabElementDef(this, paramInt)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1991 */   public String addFooterRightTab() { return addFooterElement(new TabElementDef(this, true)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2002 */   public String addFooterTable(TableLens paramTableLens) { return addFooterElement(new TableElementDef(this, paramTableLens)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReportElement getElement(String paramString) {
/* 2012 */     Vector[] arrayOfVector = { this.elements, this.headerElements, this.footerElements, this.firstHeader, this.firstFooter, this.evenHeader, this.evenFooter, this.oddHeader, this.oddFooter };
/*      */ 
/*      */ 
/*      */     
/* 2016 */     for (byte b1 = 0; b1 < arrayOfVector.length; b1++) {
/*      */       
/* 2018 */       if (arrayOfVector[b1] != null)
/*      */       {
/*      */ 
/*      */         
/* 2022 */         for (byte b = 0; b < arrayOfVector[b1].size(); b++) {
/* 2023 */           ReportElement reportElement = (ReportElement)arrayOfVector[b1].elementAt(b);
/* 2024 */           if (reportElement.getID() != null && reportElement.getID().equals(paramString)) {
/* 2025 */             return reportElement;
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/* 2031 */     Enumeration[] arrayOfEnumeration = { this.elemHeader.elements(), this.elemFooter.elements() };
/* 2032 */     for (byte b2 = 0; b2 < arrayOfEnumeration.length; b2++) {
/* 2033 */       while (arrayOfEnumeration[b2].hasMoreElements()) {
/* 2034 */         Vector vector = (Vector)arrayOfEnumeration[b2].nextElement();
/*      */         
/* 2036 */         for (byte b = 0; b < vector.size(); b++) {
/* 2037 */           ReportElement reportElement = (ReportElement)vector.elementAt(b);
/* 2038 */           if (reportElement.getID() != null && reportElement.getID().equals(paramString)) {
/* 2039 */             return reportElement;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2046 */     for (byte b3 = 0; b3 < this.elements.size(); b3++) {
/* 2047 */       if (this.elements.elementAt(b3) instanceof PageLayoutElement) {
/* 2048 */         PageArea[] arrayOfPageArea = ((PageLayoutElement)this.elements.elementAt(b3)).getPageAreas();
/*      */ 
/*      */         
/* 2051 */         for (byte b = 0; b < arrayOfPageArea.length; b++) {
/* 2052 */           FixedContainer fixedContainer = arrayOfPageArea[b].getElements();
/*      */           
/* 2054 */           if (fixedContainer != null) {
/* 2055 */             for (byte b4 = 0; b4 < fixedContainer.getElementCount(); b4++) {
/* 2056 */               if (fixedContainer.getElement(b4).getID().equals(paramString)) {
/* 2057 */                 return fixedContainer.getElement(b4);
/*      */               }
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 2065 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addElement(ReportElement paramReportElement) {
/* 2076 */     BaseElement baseElement = (BaseElement)paramReportElement;
/* 2077 */     if (baseElement.isNewline() && !baseElement.isContinuation()) {
/* 2078 */       this.hindent = 0;
/*      */     }
/*      */     
/* 2081 */     baseElement.setStyleSheet(this);
/* 2082 */     this.elements.addElement(paramReportElement);
/* 2083 */     return paramReportElement.getID();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2091 */   public int getElementCount() { return this.elements.size(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2100 */   public ReportElement getElement(int paramInt) { return (ReportElement)this.elements.elementAt(paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2109 */   public int getElementIndex(ReportElement paramReportElement) { return this.elements.indexOf(paramReportElement, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeElement(int paramInt) {
/* 2117 */     synchronized (this.elements) {
/* 2118 */       if (paramInt >= 0 && paramInt < this.elements.size()) {
/* 2119 */         this.elements.removeElementAt(paramInt);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String insertElement(int paramInt, ReportElement paramReportElement) {
/* 2131 */     this.hindent = 0;
/*      */     
/* 2133 */     synchronized (this.elements) {
/* 2134 */       if (paramInt >= 0 && paramInt < this.elements.size()) {
/* 2135 */         this.elements.insertElementAt(paramReportElement, paramInt);
/*      */       }
/*      */     } 
/* 2138 */     return paramReportElement.getID();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addHeaderElement(ReportElement paramReportElement) {
/* 2149 */     ((BaseElement)paramReportElement).setStyleSheet(this);
/* 2150 */     this.currHeader.addElement(paramReportElement);
/* 2151 */     return paramReportElement.getID();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2159 */   public int getHeaderElementCount() { return this.currHeader.size(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2168 */   public ReportElement getHeaderElement(int paramInt) { return (ReportElement)this.currHeader.elementAt(paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2177 */   public int getHeaderElementIndex(ReportElement paramReportElement) { return this.currHeader.indexOf(paramReportElement, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeHeaderElement(int paramInt) {
/* 2185 */     synchronized (this.currHeader) {
/* 2186 */       if (paramInt >= 0 && paramInt < this.currHeader.size()) {
/* 2187 */         this.currHeader.removeElementAt(paramInt);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertHeaderElement(int paramInt, ReportElement paramReportElement) {
/* 2198 */     synchronized (this.currHeader) {
/* 2199 */       if (paramInt >= 0 && paramInt < this.currHeader.size()) {
/* 2200 */         this.currHeader.insertElementAt(paramReportElement, paramInt);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addFooterElement(ReportElement paramReportElement) {
/* 2213 */     ((BaseElement)paramReportElement).setStyleSheet(this);
/* 2214 */     this.currFooter.addElement(paramReportElement);
/* 2215 */     return paramReportElement.getID();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2223 */   public int getFooterElementCount() { return this.currFooter.size(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2232 */   public ReportElement getFooterElement(int paramInt) { return (ReportElement)this.currFooter.elementAt(paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2241 */   public int getFooterElementIndex(ReportElement paramReportElement) { return this.currFooter.indexOf(paramReportElement, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeFooterElement(int paramInt) {
/* 2249 */     synchronized (this.currFooter) {
/* 2250 */       if (paramInt >= 0 && paramInt < this.currFooter.size()) {
/* 2251 */         this.currFooter.removeElementAt(paramInt);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertFooterElement(int paramInt, ReportElement paramReportElement) {
/* 2262 */     synchronized (this.currFooter) {
/* 2263 */       if (paramInt >= 0 && paramInt < this.currFooter.size()) {
/* 2264 */         this.currFooter.insertElementAt(paramReportElement, paramInt);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vector getElements(int paramInt) {
/* 2276 */     switch (paramInt) {
/*      */       case 256:
/* 2278 */         return this.headerElements;
/*      */       case 257:
/* 2280 */         return this.firstHeader;
/*      */       case 258:
/* 2282 */         return this.evenHeader;
/*      */       case 259:
/* 2284 */         return this.oddHeader;
/*      */       case 512:
/* 2286 */         return this.footerElements;
/*      */       case 513:
/* 2288 */         return this.firstFooter;
/*      */       case 514:
/* 2290 */         return this.evenFooter;
/*      */       case 515:
/* 2292 */         return this.oddFooter;
/*      */     } 
/*      */     
/* 2295 */     return this.elements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2306 */   public void print() { Common.print(this); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void print(PrintJob paramPrintJob) {
/* 2315 */     boolean bool = true;
/* 2316 */     Vector vector = new Vector();
/*      */     
/* 2318 */     Dimension dimension = paramPrintJob.getPageDimension();
/* 2319 */     this.resolution = 72;
/*      */     
/* 2321 */     reset();
/*      */ 
/*      */     
/* 2324 */     while (bool) {
/* 2325 */       StylePage stylePage = new StylePage(dimension, this.resolution);
/* 2326 */       bool = printNext(stylePage);
/* 2327 */       vector.addElement(stylePage);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2332 */     for (byte b = 0; b < vector.size(); b++) {
/* 2333 */       StylePage stylePage = (StylePage)vector.elementAt(b);
/* 2334 */       Graphics graphics = paramPrintJob.getGraphics();
/* 2335 */       stylePage.print(graphics);
/* 2336 */       graphics.dispose();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean printNext(StylePage paramStylePage) {
/* 2352 */     Dimension dimension = paramStylePage.getPageDimension();
/* 2353 */     this.pmargin = getPrinterMargin();
/* 2354 */     this.resolution = paramStylePage.getPageResolution();
/* 2355 */     this.printBox = new Rectangle((int)((this.margin.left - this.pmargin.left) * this.resolution), (int)((this.margin.top - this.pmargin.top) * this.resolution), dimension.width - (int)((this.margin.left + this.margin.right) * this.resolution), dimension.height - (int)((this.margin.top + this.margin.bottom) * this.resolution));
/*      */ 
/*      */ 
/*      */     
/* 2359 */     this.pageBox = this.printBox;
/* 2360 */     this.frames = this.npframes = null;
/* 2361 */     boolean bool = false;
/*      */ 
/*      */     
/* 2364 */     if (this.current == 0 && !this.designtime) {
/* 2365 */       runOnLoad();
/*      */     }
/*      */ 
/*      */     
/* 2369 */     while (this.current < this.elements.size() && this.elements.elementAt(this.current) instanceof PageLayoutElement) {
/*      */       
/* 2371 */       ((BaseElement)this.elements.elementAt(this.current++)).print(paramStylePage);
/* 2372 */       bool = true;
/*      */     } 
/*      */     
/* 2375 */     paramStylePage.setBackground(this.bg);
/*      */ 
/*      */     
/* 2378 */     if (!bool && this.current < this.elements.size()) {
/*      */       
/* 2380 */       PageArea[] arrayOfPageArea = (PageArea[])this.areamap.get(getElement(this.current).getID());
/*      */ 
/*      */       
/* 2383 */       if (arrayOfPageArea != null) {
/* 2384 */         this.areas = arrayOfPageArea;
/* 2385 */         bool = true;
/*      */       
/*      */       }
/* 2388 */       else if (this.npareas != null) {
/* 2389 */         this.areas = this.npareas;
/* 2390 */         bool = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2395 */     this.npareas = null;
/*      */ 
/*      */     
/* 2398 */     if (this.areas != null && this.areas.length > 0) {
/* 2399 */       this.frames = getFrames(this.areas);
/* 2400 */       paramStylePage.setPageAreas(this.areas);
/* 2401 */       printNonFlowAreas(paramStylePage, this.areas, bool);
/*      */     } 
/*      */ 
/*      */     
/* 2405 */     if (this.frames == null || this.frames.length == 0) {
/* 2406 */       this.frames = new Rectangle[] { this.printBox };
/*      */     }
/*      */ 
/*      */     
/* 2410 */     if (this.current >= this.elements.size()) {
/*      */       
/* 2412 */       if (this.current == 0 || (this.current == 1 && bool)) {
/* 2413 */         firePageBreakEvent(paramStylePage, false);
/*      */       }
/*      */       
/* 2416 */       return false;
/*      */     } 
/*      */     
/* 2419 */     for (this.currFrame = 0; this.currFrame < this.frames.length; this.currFrame++) {
/* 2420 */       this.printBox = this.frames[this.currFrame];
/* 2421 */       this.printHead.x = this.printHead.y = 0.0F;
/*      */       
/* 2423 */       if (!printNextArea(paramStylePage, this.elements)) {
/* 2424 */         firePageBreakEvent(paramStylePage, false);
/* 2425 */         return false;
/*      */       } 
/*      */ 
/*      */       
/* 2429 */       if (this.current > 0 && this.elements.elementAt(this.current - 1) instanceof PageBreakElement) {
/*      */         
/* 2431 */         firePageBreakEvent(paramStylePage, true);
/* 2432 */         return true;
/*      */       } 
/*      */     } 
/*      */     
/* 2436 */     firePageBreakEvent(paramStylePage, true);
/* 2437 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean printNextArea(StylePage paramStylePage, Vector paramVector) {
/*      */     do {
/*      */     
/* 2449 */     } while (this.printHead.y < this.printBox.height && this.current < paramVector.size() && 
/* 2450 */       !printNextLine(paramStylePage, paramVector));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2455 */     return (this.current < paramVector.size());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean printNextLine(StylePage paramStylePage, Vector paramVector) {
/* 2463 */     if (this.current >= paramVector.size()) {
/* 2464 */       return true;
/*      */     }
/*      */     
/* 2467 */     int i = this.current;
/*      */ 
/*      */     
/* 2470 */     for (i = this.current; i < paramVector.size(); i++) {
/* 2471 */       BaseElement baseElement1 = (BaseElement)paramVector.elementAt(i);
/*      */       
/* 2473 */       baseElement1.setStyleSheet(this);
/*      */ 
/*      */       
/* 2476 */       if (baseElement1.isBlock() || (baseElement1.isNewline() && i > this.current)) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 2482 */     BaseElement baseElement = (BaseElement)paramVector.elementAt(this.current);
/* 2483 */     if (baseElement instanceof PainterElement) {
/* 2484 */       PainterElementDef painterElementDef = (PainterElementDef)baseElement;
/* 2485 */       if (painterElementDef.getAnchor() != null && (painterElementDef.getAnchor()).y - painterElementDef.getAnchorDepth() > 0.0F) {
/*      */ 
/*      */         
/* 2488 */         if (this.current > 0) {
/* 2489 */           painterElementDef.setAnchorElement((ReportElement)paramVector.elementAt(this.current - 1));
/*      */         }
/*      */ 
/*      */         
/* 2493 */         float f = this.printHead.y;
/* 2494 */         this.printHead.y += ((painterElementDef.getAnchor()).y - painterElementDef.getAnchorDepth()) * this.resolution;
/*      */         
/* 2496 */         if (this.printHead.y > this.printBox.height) {
/* 2497 */           painterElementDef.setAnchorDepth(painterElementDef.getAnchorDepth() + (this.printBox.height - f) / this.resolution);
/*      */           
/* 2499 */           return true;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2505 */     this.lineH = 0.0F;
/*      */ 
/*      */     
/* 2508 */     if (i == this.current) {
/* 2509 */       BaseElement baseElement1 = (BaseElement)paramVector.elementAt(this.current);
/*      */       
/* 2511 */       if (!baseElement1.isVisible()) {
/* 2512 */         this.current++;
/* 2513 */         return false;
/*      */       } 
/*      */       
/* 2516 */       FontMetrics fontMetrics = Common.getFontMetrics(baseElement1.getFont());
/* 2517 */       this.printHead.x = 0.0F;
/*      */ 
/*      */       
/* 2520 */       if (baseElement1 instanceof CondPageBreakElement) {
/* 2521 */         int j = ((CondPageBreakElementDef)baseElement1).getMinimumHeight();
/*      */         
/* 2523 */         this.current++;
/* 2524 */         baseElement1.print(paramStylePage);
/*      */         
/* 2526 */         return (j + this.printHead.y > this.printBox.height);
/*      */       } 
/*      */ 
/*      */       
/* 2530 */       if (baseElement1 instanceof AreaBreakElement) {
/* 2531 */         baseElement1.print(paramStylePage);
/* 2532 */         this.current++;
/* 2533 */         return true;
/*      */       } 
/*      */       
/* 2536 */       if (baseElement1 instanceof PageLayoutElement) {
/* 2537 */         return true;
/*      */       }
/*      */       
/* 2540 */       if (baseElement1 instanceof TableElement) {
/* 2541 */         boolean bool = true;
/* 2542 */         TableElementDef tableElementDef = (TableElementDef)baseElement1;
/* 2543 */         tableElementDef.validate(paramStylePage);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         do {
/* 2550 */           int j = tableElementDef.fitNext(this.printBox.height - this.printHead.y);
/*      */           
/* 2552 */           if (j < 0) {
/*      */ 
/*      */ 
/*      */             
/* 2556 */             if (bool && this.printHead.y > 0.0F) {
/* 2557 */               return true;
/*      */             }
/*      */             
/* 2560 */             this.current++;
/* 2561 */             return false;
/*      */           } 
/* 2563 */           if (j == 0 && this.printHead.y > 0.0F)
/*      */           {
/* 2565 */             return true;
/*      */           }
/*      */           
/* 2568 */           bool = tableElementDef.print(paramStylePage);
/*      */ 
/*      */           
/* 2571 */           if (bool && tableElementDef.getLayout() == 3) {
/* 2572 */             return true;
/*      */           }
/* 2574 */         } while (bool);
/*      */       } else {
/*      */         
/* 2577 */         if (!baseElement1.isBreakable()) {
/* 2578 */           Size size = baseElement1.getPreferredSize();
/*      */ 
/*      */ 
/*      */           
/* 2582 */           if (this.printHead.y + size.height > this.printBox.height && this.printHead.y > 0.0F)
/*      */           {
/* 2584 */             return true;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/* 2589 */         if (baseElement1 instanceof PainterElement) {
/* 2590 */           this.printHead.x = ((PainterElementDef)baseElement1).getAnchorX();
/*      */         }
/*      */ 
/*      */         
/* 2594 */         if (baseElement1.print(paramStylePage)) {
/* 2595 */           return true;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 2600 */       this.current++;
/*      */     }
/*      */     else {
/*      */       
/* 2604 */       int j = -1;
/* 2605 */       float f = 0.0F;
/*      */ 
/*      */       
/* 2608 */       for (int k = this.current; k < i; k++) {
/* 2609 */         ReportElement reportElement = (ReportElement)paramVector.elementAt(k);
/* 2610 */         if (reportElement instanceof PainterElement) {
/* 2611 */           PainterElementDef painterElementDef = (PainterElementDef)reportElement;
/*      */ 
/*      */           
/* 2614 */           if (painterElementDef.getAnchor() != null) {
/* 2615 */             j = k;
/*      */             
/* 2617 */             if (painterElementDef.getAnchorX() + (painterElementDef.getPreferredSize()).width > this.printBox.width) {
/*      */               
/* 2619 */               i = k + 1;
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 2627 */       if (j >= 0) {
/*      */         
/* 2629 */         for (int m = this.current; m < i; m++) {
/* 2630 */           BaseElement baseElement1 = (BaseElement)paramVector.elementAt(m);
/*      */           
/* 2632 */           if (baseElement1 instanceof PainterElement) {
/* 2633 */             PainterElementDef painterElementDef = (PainterElementDef)baseElement1;
/* 2634 */             Size size = baseElement1.getPreferredSize();
/* 2635 */             float f1 = (painterElementDef.getAnchor() == null || (painterElementDef.getAnchor()).y >= 0.0F) ? 0.0F : (-(painterElementDef.getAnchor()).y * this.resolution);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2640 */             size.height += f1;
/*      */ 
/*      */ 
/*      */             
/* 2644 */             if (this.printHead.y + f1 >= this.printBox.height && this.printHead.y > 0.0F) {
/* 2645 */               return true;
/*      */             }
/*      */ 
/*      */             
/* 2649 */             if (this.printHead.y + size.height > (this.printBox.height + 1) && 
/* 2650 */               !painterElementDef.isBreakable() && this.printHead.y > 0.0F) {
/*      */               
/* 2652 */               painterElementDef.setAnchorDepth(painterElementDef.getAnchorDepth() + this.printHead.y / this.resolution);
/*      */               
/* 2654 */               return true;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2660 */             f = Math.max(f, size.height);
/*      */           } 
/*      */         } 
/*      */         
/* 2664 */         Position position = new Position(this.printHead);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2669 */         Vector vector1 = new Vector();
/*      */         
/* 2671 */         Vector vector2 = new Vector();
/* 2672 */         Vector vector3 = new Vector();
/* 2673 */         Vector vector4 = this.horFlow ? null : new Vector();
/*      */ 
/*      */         
/* 2676 */         for (int n = this.current; n < i; n++) {
/* 2677 */           BaseElement baseElement1 = (BaseElement)paramVector.elementAt(n);
/*      */           
/* 2679 */           if (baseElement1 instanceof PainterElement && ((PainterElement)baseElement1).getAnchor() != null) {
/*      */             
/* 2681 */             PainterElementDef painterElementDef = (PainterElementDef)baseElement1;
/*      */             
/* 2683 */             float f1 = painterElementDef.getAnchorX();
/*      */ 
/*      */             
/* 2686 */             if (n > this.current) {
/* 2687 */               painterElementDef.setAnchorElement((ReportElement)paramVector.elementAt(this.current));
/*      */             }
/*      */ 
/*      */             
/* 2691 */             Size size = painterElementDef.getPreferredSize();
/*      */             
/* 2693 */             float f2 = f1 + Math.min(this.printBox.width - f1, size.width);
/*      */             
/* 2695 */             if (this.horFlow) {
/* 2696 */               float f3 = this.printHead.y + this.printBox.y - (painterElementDef.getAnchor()).y * this.resolution;
/*      */               
/* 2698 */               float f4 = f1 + this.printBox.x;
/* 2699 */               vector1.addElement(new Rectangle((int)f4, (int)f3, (int)size.width, (int)size.height));
/*      */             
/*      */             }
/*      */             else {
/*      */ 
/*      */               
/* 2705 */               Rectangle rectangle1 = new Rectangle((int)(this.printHead.x + this.printBox.x), (int)(this.printHead.y + this.printBox.y), (int)(f1 - this.printHead.x), (int)f);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 2710 */               vector1.addElement(rectangle1);
/*      */             } 
/*      */             
/* 2713 */             if (!this.horFlow) {
/* 2714 */               vector2.addElement(vector4);
/* 2715 */               vector4 = new Vector();
/*      */             } 
/*      */             
/* 2718 */             vector3.addElement(baseElement1);
/*      */             
/* 2720 */             if (painterElementDef.getWrapping() != 0) {
/* 2721 */               this.printHead.x = f2;
/*      */             }
/*      */           } else {
/*      */             
/* 2725 */             (this.horFlow ? vector2 : vector4).addElement(baseElement1);
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 2730 */         if (!this.horFlow) {
/* 2731 */           Rectangle rectangle1 = new Rectangle((int)(this.printHead.x + this.printBox.x), (int)(this.printHead.y + this.printBox.y), (int)(this.printBox.width - this.printHead.x), (int)f);
/*      */ 
/*      */ 
/*      */           
/* 2735 */           vector1.addElement(rectangle1);
/* 2736 */           vector2.addElement(vector4);
/*      */         } 
/*      */ 
/*      */         
/* 2740 */         int i1 = i;
/* 2741 */         Vector vector5 = paramVector;
/* 2742 */         Rectangle rectangle = this.printBox;
/*      */ 
/*      */         
/* 2745 */         for (byte b = 0; b < vector3.size(); b++) {
/* 2746 */           PainterElementDef painterElementDef = (PainterElementDef)vector3.elementAt(b);
/*      */           
/* 2748 */           Position position1 = this.printHead;
/* 2749 */           Rectangle rectangle1 = this.printBox;
/* 2750 */           float f1 = position.y;
/*      */           
/* 2752 */           if ((painterElementDef.getAnchor()).y < 0.0F) {
/* 2753 */             f1 += -(painterElementDef.getAnchor()).y * this.resolution;
/*      */           }
/*      */           
/* 2756 */           this.printBox = rectangle;
/* 2757 */           this.printHead = new Position(painterElementDef.getAnchorX(), f1);
/* 2758 */           painterElementDef.print(paramStylePage);
/*      */           
/* 2760 */           this.printHead = position1;
/* 2761 */           this.printBox = rectangle1;
/*      */         } 
/*      */         
/* 2764 */         boolean bool = false;
/*      */ 
/*      */         
/* 2767 */         if (this.horFlow) {
/* 2768 */           Rectangle[][] arrayOfRectangle = calcGrid(position.x + rectangle.x, position.y + rectangle.y, rectangle.width, f, vector1);
/*      */ 
/*      */           
/* 2771 */           vector5 = vector2;
/* 2772 */           this.current = 0;
/*      */ 
/*      */           
/* 2775 */           for (byte b1 = 0; b1 < arrayOfRectangle.length; b1++) {
/* 2776 */             if (arrayOfRectangle[b1].length != 0) {
/*      */ 
/*      */ 
/*      */               
/* 2780 */               int i2 = 0;
/*      */ 
/*      */               
/* 2783 */               for (byte b2 = 0; b2 < arrayOfRectangle[b1].length; b2++) {
/* 2784 */                 this.printHead = new Position(0.0F, 0.0F);
/* 2785 */                 this.printBox = arrayOfRectangle[b1][b2];
/*      */                 
/* 2787 */                 boolean bool1 = printNextLine(paramStylePage, vector5);
/* 2788 */                 i2 = Math.max(i2, (int)this.printHead.y);
/*      */               } 
/*      */ 
/*      */               
/* 2792 */               for (byte b3 = 0; b3 < arrayOfRectangle[b1].length; b3++) {
/* 2793 */                 (arrayOfRectangle[b1][b3]).y += i2;
/* 2794 */                 (arrayOfRectangle[b1][b3]).height -= i2;
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/* 2799 */               if (i2 > 0 && arrayOfRectangle[b1].length > 0 && (arrayOfRectangle[b1][0]).height > 0) {
/* 2800 */                 b1--;
/*      */               }
/*      */             } 
/*      */           } 
/*      */           
/* 2805 */           bool = (this.current < paramVector.size());
/*      */         }
/*      */         else {
/*      */           
/* 2809 */           int i2 = 0;
/*      */ 
/*      */           
/* 2812 */           for (byte b1 = 0; b1 < vector2.size(); b1++) {
/* 2813 */             vector4 = (Vector)vector2.elementAt(b1);
/*      */ 
/*      */             
/* 2816 */             if (vector4.size() > 0) {
/* 2817 */               boolean bool1 = i2;
/* 2818 */               i2 = Math.max(i2, b1);
/*      */               
/* 2820 */               if (i2 == 0 || bool1 != i2) {
/* 2821 */                 this.printHead.x = this.printHead.y = 0.0F;
/* 2822 */                 this.printBox = (Rectangle)vector1.elementAt(i2);
/*      */               } 
/*      */               
/* 2825 */               vector5 = vector4;
/* 2826 */               this.current = 0;
/*      */ 
/*      */               
/* 2829 */               while ((bool = printNextArea(paramStylePage, vector5)) && i2 < vector1.size() - 1) {
/* 2830 */                 this.printHead.x = this.printHead.y = 0.0F;
/* 2831 */                 this.printBox = (Rectangle)vector1.elementAt(++i2);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/* 2837 */         this.printBox = rectangle;
/* 2838 */         this.printHead = new Position(0.0F, position.y + f);
/*      */ 
/*      */         
/* 2841 */         if (bool)
/*      */         {
/*      */           
/* 2844 */           if (printNextArea(paramStylePage, vector5)) {
/* 2845 */             Object object = vector5.elementAt(this.current);
/* 2846 */             int i2 = paramVector.indexOf(object);
/*      */ 
/*      */             
/* 2849 */             if (i2 >= 0) {
/* 2850 */               i1 = i2;
/*      */             }
/*      */           } 
/*      */         }
/*      */         
/* 2855 */         this.current = i1;
/*      */       }
/*      */       else {
/*      */         
/* 2859 */         for (int m = this.current; m < i; ) {
/* 2860 */           int n = 0;
/*      */ 
/*      */           
/* 2863 */           for (; m < i; m++) {
/* 2864 */             BaseElement baseElement1 = (BaseElement)paramVector.elementAt(m);
/* 2865 */             int i4 = baseElement1.getAlignment() & 0x7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2871 */             if ((i4 < n && !baseElement1.isFlowControl()) || (baseElement1.isNewline() && m > this.current)) {
/*      */               break;
/*      */             }
/*      */ 
/*      */             
/* 2876 */             if (baseElement1.isLastOnLine()) {
/* 2877 */               m++;
/*      */               
/*      */               break;
/*      */             } 
/* 2881 */             if (!baseElement1.isFlowControl()) {
/* 2882 */               n = i4;
/*      */             }
/*      */           } 
/*      */           
/* 2886 */           this.printHead.x = 0.0F;
/* 2887 */           float f1 = this.printHead.y;
/* 2888 */           float f2 = 0.0F;
/* 2889 */           float f3 = 0.0F, f4 = 0.0F, f5 = 0.0F;
/*      */ 
/*      */ 
/*      */           
/* 2893 */           this.lineH = 0.0F;
/*      */ 
/*      */           
/* 2896 */           for (int i1 = this.current; i1 < m; i1++) {
/* 2897 */             BaseElement baseElement1 = (BaseElement)paramVector.elementAt(i1);
/* 2898 */             Size size = baseElement1.getPreferredSize();
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2903 */             if (!baseElement1.isBreakable() && this.printHead.y + size.height > this.printBox.height) {
/* 2904 */               boolean bool = (this.printHead.y > 0.0F) ? 1 : 0;
/*      */ 
/*      */ 
/*      */               
/* 2908 */               if (!bool) {
/*      */ 
/*      */                 
/* 2911 */                 for (byte b = 0; b < this.frames.length; b++) {
/* 2912 */                   if ((this.frames[b]).height > size.height) {
/* 2913 */                     bool = true;
/*      */                     
/*      */                     break;
/*      */                   } 
/*      */                 } 
/* 2918 */                 if (!bool && this.npframes != null) {
/* 2919 */                   for (byte b1 = 0; b1 < this.npframes.length; b1++) {
/* 2920 */                     if ((this.npframes[b1]).height > size.height) {
/* 2921 */                       bool = true;
/*      */                       
/*      */                       break;
/*      */                     } 
/*      */                   } 
/*      */                 }
/*      */               } 
/*      */               
/* 2929 */               if (bool) {
/* 2930 */                 return true;
/*      */               }
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/* 2936 */             if (i1 == j) {
/* 2937 */               PainterElementDef painterElementDef = (PainterElementDef)baseElement1;
/* 2938 */               float f9 = painterElementDef.getAnchorX();
/*      */               
/* 2940 */               f3 = f9 + size.width;
/*      */             } else {
/*      */               
/* 2943 */               f3 += size.width;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2950 */             if (i1 > j && this.printHead.x + f3 > this.printBox.width && !(baseElement1 instanceof TextElement)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 2957 */               boolean bool = (!(baseElement1 instanceof PainterElement) && baseElement1.isBreakable()) ? 1 : 0;
/*      */               
/* 2959 */               m = Math.max(bool ? (i1 + 1) : i1, this.current + 1);
/*      */             } 
/*      */ 
/*      */             
/* 2963 */             m = Math.min(m, paramVector.size());
/*      */ 
/*      */             
/* 2966 */             if (i1 < m) {
/* 2967 */               if ((baseElement1.getAlignment() & 0x2) != 0) {
/* 2968 */                 f4 += size.width;
/*      */               }
/* 2970 */               else if ((baseElement1.getAlignment() & 0x4) != 0) {
/* 2971 */                 f5 += size.width;
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/* 2976 */               if (baseElement1 instanceof PainterElement) {
/* 2977 */                 PainterElementDef painterElementDef = (PainterElementDef)baseElement1;
/* 2978 */                 if (painterElementDef.getAnchor() != null && (painterElementDef.getAnchor()).y < 0.0F) {
/* 2979 */                   size.height += -(painterElementDef.getAnchor()).y * this.resolution;
/*      */                 }
/*      */               } 
/*      */               
/* 2983 */               f = Math.max(f, size.height);
/*      */             } 
/*      */           } 
/*      */           
/* 2987 */           float f6 = this.printHead.x;
/* 2988 */           float f7 = Math.max((this.printBox.width - f4) / 2.0F, 0.0F);
/* 2989 */           float f8 = Math.max(this.printBox.width - f5, 0.0F);
/* 2990 */           int i2 = paramStylePage.getPaintableCount();
/* 2991 */           this.lastHead = new Position(this.printHead);
/*      */ 
/*      */           
/* 2994 */           for (int i3 = this.current; i3 < m; i3++) {
/* 2995 */             BaseElement baseElement1 = (BaseElement)paramVector.elementAt(i3);
/* 2996 */             byte b = 0;
/* 2997 */             this.printHead.y = f1;
/*      */             
/* 2999 */             if ((baseElement1.getAlignment() & true) != 0 && f6 >= this.printHead.x) {
/* 3000 */               this.printHead.x = f6;
/* 3001 */               b = 0;
/*      */             }
/* 3003 */             else if ((baseElement1.getAlignment() & 0x2) != 0 && f7 >= this.printHead.x) {
/*      */               
/* 3005 */               this.printHead.x = f7;
/* 3006 */               b = 1;
/*      */             }
/* 3008 */             else if ((baseElement1.getAlignment() & 0x4) != 0 && f8 >= this.printHead.x) {
/*      */               
/* 3010 */               this.printHead.x = f8;
/* 3011 */               b = 2;
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/* 3016 */             if (this.printHead.x >= this.printBox.width) {
/* 3017 */               advance(0.0F, this.lineH);
/* 3018 */               f1 = this.printHead.y;
/* 3019 */               this.lineH = 0.0F;
/* 3020 */               f6 = f7 = f8 = 0.0F;
/* 3021 */               alignLine(i2, paramStylePage.getPaintableCount(), paramStylePage, this.lineH);
/* 3022 */               i2 = paramStylePage.getPaintableCount();
/*      */             } 
/*      */ 
/*      */             
/* 3026 */             int i4 = paramStylePage.getPaintableCount();
/*      */ 
/*      */             
/* 3029 */             if (baseElement1.print(paramStylePage)) {
/* 3030 */               this.current = i3;
/* 3031 */               this.printHead.y = Math.max(this.printHead.y, f1 + this.lineH);
/*      */               
/* 3033 */               return (this.printHead.y >= this.printBox.height || i4 == paramStylePage.getPaintableCount());
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 3039 */             if (baseElement1 instanceof PainterElement) {
/* 3040 */               this.lastHead = new Position(this.printHead);
/*      */             }
/*      */             
/* 3043 */             f2 = this.printHead.x;
/*      */             
/* 3045 */             switch (b) { case 0:
/* 3046 */                 f6 = this.printHead.x; break;
/* 3047 */               case 1: f7 = this.printHead.x; break;
/*      */               case 2:
/* 3049 */                 f8 = this.printHead.x;
/*      */                 break; }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 3055 */             if (this.advanceLine > 0.0F) {
/* 3056 */               float f9 = f1;
/* 3057 */               f1 = this.printHead.y - this.advanceLine;
/* 3058 */               this.lineH = Math.max(f9 + this.lineH - f1, this.advanceLine);
/* 3059 */               alignLine(i2, i4 + 1, paramStylePage, this.lineH);
/* 3060 */               i2 = paramStylePage.getPaintableCount() - 1;
/*      */             } else {
/*      */               
/* 3063 */               this.lineH = Math.max(this.lineH, this.printHead.y - f1);
/*      */             } 
/*      */           } 
/*      */           
/* 3067 */           alignLine(i2, paramStylePage.getPaintableCount(), paramStylePage, this.lineH);
/*      */ 
/*      */           
/* 3070 */           this.printHead.y = f1;
/* 3071 */           this.printHead.x = f2;
/* 3072 */           this.current = m;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3079 */           if (this.lineH > 0.0F && this.current < paramVector.size() && !(paramVector.elementAt(this.current - 1) instanceof NewlineElement) && paramVector.elementAt(this.current) instanceof NewlineElement) {
/*      */ 
/*      */             
/* 3082 */             NewlineElementDef newlineElementDef = (NewlineElementDef)paramVector.elementAt(this.current);
/*      */             
/* 3084 */             newlineElementDef.skip();
/*      */             
/* 3086 */             if (newlineElementDef.getRemain() <= 0) {
/*      */ 
/*      */               
/* 3089 */               Size size = newlineElementDef.getPreferredSize();
/* 3090 */               this.printHead.y += this.lineH - size.height - 1.0F;
/* 3091 */               newlineElementDef.print(paramStylePage);
/*      */               
/* 3093 */               this.printHead.y = f1;
/*      */               
/* 3095 */               this.current++;
/*      */             } 
/*      */           } 
/*      */           
/* 3099 */           advance(0.0F, this.lineH);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 3104 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void printHeaderFooter(StylePage paramStylePage) {
/* 3114 */     Vector vector1 = null;
/* 3115 */     int i = this.current;
/* 3116 */     Dimension dimension = paramStylePage.getPageDimension();
/* 3117 */     this.resolution = paramStylePage.getPageResolution();
/* 3118 */     Vector vector2 = null;
/*      */     
/* 3120 */     Vector vector3 = null, vector4 = null;
/*      */     
/* 3122 */     if (this.hfFmt == null) {
/* 3123 */       this.hfFmt = new HFTextFormatter(new Date(), this.pgStart);
/*      */     }
/*      */     
/* 3126 */     int j = this.hfFmt.getPageNumber();
/* 3127 */     int k = this.hfFmt.getPageIndex();
/*      */ 
/*      */     
/* 3130 */     for (byte b = 0; b < paramStylePage.getPaintableCount(); b++) {
/* 3131 */       BaseElement baseElement = (BaseElement)paramStylePage.getPaintable(b).getElement();
/*      */       
/* 3133 */       if (baseElement instanceof HeadingElement) {
/* 3134 */         this.headingMap.put(baseElement, new Integer(j));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3139 */       if (baseElement != null) {
/* 3140 */         Vector vector = (Vector)this.elemHeader.get(baseElement.getID());
/* 3141 */         if (vector != null) {
/* 3142 */           vector3 = vector;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 3147 */       if (baseElement != null) {
/* 3148 */         Vector vector = (Vector)this.elemFooter.get(baseElement.getID());
/* 3149 */         if (vector != null) {
/* 3150 */           vector4 = vector;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3157 */     this.printBox = getHeaderBounds(dimension, this.resolution);
/* 3158 */     this.frames = new Rectangle[] { this.printBox };
/* 3159 */     this.npframes = null;
/* 3160 */     this.currFrame = 0;
/* 3161 */     this.printHead.x = this.printHead.y = 0.0F;
/*      */ 
/*      */     
/* 3164 */     if (!this.designtime && vector3 != null) {
/* 3165 */       vector2 = this.overrideHeader = (Vector)vector3.clone();
/*      */     }
/*      */     
/* 3168 */     if (this.overrideHeader != null) {
/* 3169 */       vector2 = this.overrideHeader;
/*      */     
/*      */     }
/* 3172 */     else if (k == 0 && this.firstHeader != null && this.firstHeader.size() > 0) {
/* 3173 */       vector2 = (Vector)this.firstHeader.clone();
/*      */     
/*      */     }
/* 3176 */     else if (k % 2 == 0 && this.oddHeader != null && this.oddHeader.size() > 0) {
/* 3177 */       vector2 = (Vector)this.oddHeader.clone();
/*      */     }
/* 3179 */     else if (k % 2 == 1 && this.evenHeader != null && this.evenHeader.size() > 0) {
/* 3180 */       vector2 = (Vector)this.evenHeader.clone();
/*      */     } else {
/*      */       
/* 3183 */       vector2 = (Vector)this.headerElements.clone();
/*      */     } 
/*      */     
/* 3186 */     processHF(vector2);
/* 3187 */     vector1 = vector2;
/* 3188 */     this.current = 0;
/*      */     
/* 3190 */     printNextArea(paramStylePage, vector1);
/*      */     
/* 3192 */     this.printBox = getFooterBounds(dimension, this.resolution);
/* 3193 */     this.frames = new Rectangle[] { this.printBox };
/* 3194 */     this.npframes = null;
/* 3195 */     this.currFrame = 0;
/* 3196 */     this.printHead.x = this.printHead.y = 0.0F;
/*      */ 
/*      */     
/* 3199 */     if (!this.designtime && vector4 != null) {
/* 3200 */       vector2 = this.overrideFooter = (Vector)vector4.clone();
/*      */     }
/*      */     
/* 3203 */     if (this.overrideFooter != null) {
/* 3204 */       vector2 = this.overrideFooter;
/*      */     
/*      */     }
/* 3207 */     else if (k == 0 && this.firstFooter != null && this.firstFooter.size() > 0) {
/* 3208 */       vector2 = (Vector)this.firstFooter.clone();
/*      */     
/*      */     }
/* 3211 */     else if (k % 2 == 0 && this.oddFooter != null && this.oddFooter.size() > 0) {
/* 3212 */       vector2 = (Vector)this.oddFooter.clone();
/*      */     }
/* 3214 */     else if (k % 2 == 1 && this.evenFooter != null && this.evenFooter.size() > 0) {
/* 3215 */       vector2 = (Vector)this.evenFooter.clone();
/*      */     } else {
/*      */       
/* 3218 */       vector2 = (Vector)this.footerElements.clone();
/*      */     } 
/*      */     
/* 3221 */     processHF(vector2);
/* 3222 */     vector1 = vector2;
/* 3223 */     this.current = 0;
/*      */     
/* 3225 */     printNextArea(paramStylePage, vector1);
/*      */     
/* 3227 */     this.current = i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void printNonFlowAreas(StylePage paramStylePage, PageArea[] paramArrayOfPageArea, boolean paramBoolean) {
/* 3236 */     for (byte b = 0; b < paramArrayOfPageArea.length; b++) {
/* 3237 */       if (paramArrayOfPageArea[b].getBorder() != 0) {
/* 3238 */         Rectangle rectangle = paramArrayOfPageArea[b].getBounds(this.pageBox, this.resolution);
/* 3239 */         Common.drawRect(paramStylePage, rectangle.x, rectangle.y, rectangle.width, rectangle.height, paramArrayOfPageArea[b].getBorder(), paramArrayOfPageArea[b].getBorderColor());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3244 */       if (!paramArrayOfPageArea[b].isFlow() && paramArrayOfPageArea[b].getElements() != null) {
/* 3245 */         FixedContainer fixedContainer = paramArrayOfPageArea[b].getElements();
/* 3246 */         Rectangle rectangle = paramArrayOfPageArea[b].getPrintArea(this.printBox, 72);
/*      */         
/* 3248 */         printFixedContainer(paramStylePage, fixedContainer, rectangle, (paramBoolean || paramArrayOfPageArea[b].isRepeat()));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 3254 */   Vector listeners = new Vector();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3259 */   public void addPageBreakListener(PageBreakListener paramPageBreakListener) { this.listeners.addElement(paramPageBreakListener); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3266 */   public void removePageBreakListener(PageBreakListener paramPageBreakListener) { this.listeners.removeElement(paramPageBreakListener); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3273 */   public String getOnPageBreak() { return this.pagebreakCmd; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOnPageBreak(String paramString) {
/* 3280 */     this.pagebreakCmd = paramString;
/* 3281 */     this.pagebreakScript = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3288 */   public String getOnLoad() { return this.loadCmd; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOnLoad(String paramString) {
/* 3295 */     this.loadCmd = paramString;
/* 3296 */     this.loadScript = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void firePageBreakEvent(StylePage paramStylePage, boolean paramBoolean) {
/*      */     try {
/* 3305 */       if (paramStylePage.getPaintableCount() > 1 && this.current > 0 && this.current < this.elements.size()) {
/*      */         
/* 3307 */         int i = paramStylePage.getPaintableCount() - 1;
/* 3308 */         Paintable paintable = paramStylePage.getPaintable(i);
/*      */         
/* 3310 */         if (paintable.getElement().isKeepWithNext()) {
/* 3311 */           Paintable paintable1 = paramStylePage.getPaintable(0);
/* 3312 */           ReportElement reportElement = paintable.getElement();
/* 3313 */           String str = reportElement.getID();
/*      */ 
/*      */           
/* 3316 */           if (!paintable1.getElement().getID().equals(str)) {
/* 3317 */             for (; i >= 0 && paramStylePage.getPaintable(i).getElement().getID().equals(str); 
/* 3318 */               i--) {
/* 3319 */               paramStylePage.removePaintable(i);
/*      */             }
/*      */             
/* 3322 */             ((BaseElement)reportElement).reset();
/* 3323 */             int j = this.current;
/* 3324 */             while (j > 0 && !this.elements.elementAt(j).equals(reportElement)) {
/* 3325 */               j--;
/*      */             }
/*      */ 
/*      */ 
/*      */             
/* 3330 */             if (j > 0) {
/* 3331 */               this.current = j;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 3337 */       if (paramStylePage.getPaintableCount() > 0) {
/* 3338 */         Vector vector = (Vector)this.listeners.clone();
/* 3339 */         Paintable paintable1 = paramStylePage.getPaintable(paramStylePage.getPaintableCount() - 1);
/* 3340 */         Rectangle rectangle1 = null;
/* 3341 */         String str1 = (paintable1.getElement() != null) ? paintable1.getElement().getID() : "";
/* 3342 */         Paintable paintable2 = paramStylePage.getPaintable(0);
/* 3343 */         Rectangle rectangle2 = null;
/* 3344 */         String str2 = (paintable2.getElement() != null) ? paintable2.getElement().getID() : "";
/*      */ 
/*      */         
/* 3347 */         if (paintable1 instanceof TablePaintable) {
/* 3348 */           rectangle1 = ((TablePaintable)paintable1).getTableRegion();
/*      */         }
/*      */         
/* 3351 */         if (paintable2 instanceof TablePaintable) {
/* 3352 */           rectangle2 = ((TablePaintable)paintable2).getTableRegion();
/*      */         }
/*      */         
/* 3355 */         PageBreakEvent pageBreakEvent = new PageBreakEvent(paramStylePage, str1, rectangle1, str2, rectangle2, !paramBoolean);
/*      */ 
/*      */         
/* 3358 */         for (int i = vector.size() - 1; i >= 0; i--) {
/* 3359 */           ((PageBreakListener)vector.elementAt(i)).valueChanged(pageBreakEvent);
/*      */         }
/*      */         
/* 3362 */         String str3 = getOnPageBreak();
/* 3363 */         if (str3 != null && !this.designtime) {
/* 3364 */           ScriptEnv scriptEnv = getScriptEnv();
/*      */           
/* 3366 */           if (scriptEnv != null) {
/* 3367 */             if (this.pagebreakScript == null) {
/* 3368 */               this.pagebreakScript = scriptEnv.compile(str3);
/*      */             }
/*      */             
/* 3371 */             scriptEnv.put("event", pageBreakEvent);
/*      */             
/*      */             try {
/* 3374 */               scriptEnv.exec(null, this.pagebreakScript, null);
/*      */             } catch (Exception exception) {
/* 3376 */               if (this.designtime) {
/* 3377 */                 MessageDialog.show(exception + "\n" + str3);
/*      */               } else {
/*      */                 
/* 3380 */                 System.err.println("onPageBreak script failed: " + exception);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 3388 */       printHeaderFooter(paramStylePage);
/* 3389 */       this.hfFmt.nextPage(paramBoolean);
/*      */     } catch (Exception exception) {
/* 3391 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clear() {
/* 3399 */     checkLimit();
/*      */     
/* 3401 */     this.elements.removeAllElements();
/*      */ 
/*      */     
/* 3404 */     Vector[] arrayOfVector = { this.headerElements, this.footerElements, this.firstHeader, this.firstFooter, this.evenHeader, this.evenFooter, this.oddHeader, this.oddFooter };
/*      */ 
/*      */     
/* 3407 */     for (byte b = 0; b < arrayOfVector.length; b++) {
/* 3408 */       if (arrayOfVector[b] != null) {
/* 3409 */         arrayOfVector[b].removeAllElements();
/*      */       }
/*      */     } 
/*      */     
/* 3413 */     this.elemHeader.clear();
/* 3414 */     this.elemFooter.clear();
/*      */     
/* 3416 */     if (this.scriptenv != null) {
/* 3417 */       this.scriptenv.reset();
/* 3418 */       this.scriptenv = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 3423 */   public void finalize() { clear(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset() {
/* 3432 */     this.current = 0;
/* 3433 */     this.areas = this.npareas = null;
/* 3434 */     this.npframes = null;
/* 3435 */     this.hfFmt = null;
/* 3436 */     this.loadCalled = false;
/*      */     
/* 3438 */     if (this.scriptenv != null) {
/* 3439 */       this.scriptenv.reset();
/*      */     }
/*      */ 
/*      */     
/* 3443 */     if (!this.designtime) {
/* 3444 */       this.overrideHeader = this.overrideFooter = null;
/*      */     }
/*      */ 
/*      */     
/* 3448 */     for (byte b1 = 0; b1 < this.headingCnt.length; b1++) {
/* 3449 */       this.headingCnt[b1] = 0;
/*      */     }
/*      */ 
/*      */     
/* 3453 */     for (byte b2 = 0; b2 < this.elements.size(); b2++) {
/* 3454 */       ((BaseElement)this.elements.elementAt(b2)).reset();
/*      */     }
/*      */ 
/*      */     
/* 3458 */     Vector[] arrayOfVector = { this.headerElements, this.footerElements, this.firstHeader, this.firstFooter, this.evenHeader, this.evenFooter, this.oddHeader, this.oddFooter };
/*      */ 
/*      */     
/* 3461 */     for (byte b3 = 0; b3 < arrayOfVector.length; b3++) {
/* 3462 */       if (arrayOfVector[b3] != null) {
/* 3463 */         for (byte b = 0; b < arrayOfVector[b3].size(); b++) {
/* 3464 */           ((BaseElement)arrayOfVector[b3].elementAt(b)).reset();
/*      */         }
/*      */       }
/*      */     } 
/*      */     
/* 3469 */     Enumeration[] arrayOfEnumeration = { this.elemHeader.elements(), this.elemFooter.elements() };
/* 3470 */     for (byte b4 = 0; b4 < arrayOfEnumeration.length; b4++) {
/* 3471 */       while (arrayOfEnumeration[b4].hasMoreElements()) {
/* 3472 */         Vector vector = (Vector)arrayOfEnumeration[b4].nextElement();
/* 3473 */         for (byte b = 0; b < vector.size(); b++) {
/* 3474 */           ((BaseElement)vector.elementAt(b)).reset();
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 3479 */     this.pagebreakScript = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVisible(String paramString, boolean paramBoolean) {
/* 3488 */     ReportElement reportElement = getElement(paramString);
/* 3489 */     if (reportElement != null) {
/* 3490 */       reportElement.setVisible(paramBoolean);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3500 */   public String getProperty(String paramString) { return this.prop.getProperty(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3522 */   public void setProperty(String paramString1, String paramString2) { this.prop.put(paramString1, paramString2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3543 */   public static void setPrinterMargin(Margin paramMargin) { StyleCore.g_pmargin = paramMargin; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3550 */   public static Margin getPrinterMargin() { return StyleCore.g_pmargin; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3559 */   public static String getVersion() { return version; }
/*      */ 
/*      */   
/* 3562 */   private static String version = "3.5.1";
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\StyleSheet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */