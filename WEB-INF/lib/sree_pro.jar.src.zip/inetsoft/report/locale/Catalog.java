package inetsoft.report.locale;

import inetsoft.report.ReportEnv;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;
import java.util.ResourceBundle;

public class Catalog {
  public static String getString(String paramString) {
    String str = paramString.replace(' ', '_');
    str = str.replace('\n', '_');
    str = str.replace('\t', '_');
    Object object = (prop.size() > 0) ? prop.get(str) : null;
    return (String)((object == null) ? paramString : object);
  }
  
  public static void put(String paramString, Object paramObject) { prop.put(paramString, paramObject); }
  
  public static void loadProperty(String paramString) throws IOException {
    try {
      loadProperty(Catalog.class.getResourceAsStream(paramString));
    } catch (IOException iOException) {
      throw iOException;
    } catch (Exception exception) {
      throw new IOException("Failed to load properties: " + paramString);
    } 
  }
  
  public static void loadProperty(InputStream paramInputStream) throws IOException { prop.load(paramInputStream); }
  
  public static void loadResourceBundle(String paramString) throws IOException { loadResourceBundle(ResourceBundle.getBundle(paramString)); }
  
  public static void loadResourceBundle(ResourceBundle paramResourceBundle) {
    Enumeration enumeration = paramResourceBundle.getKeys();
    while (enumeration.hasMoreElements()) {
      try {
        String str = (String)enumeration.nextElement();
        prop.put(str, paramResourceBundle.getObject(str));
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
  }
  
  private static Properties prop = new Properties();
  
  static  {
    try {
      String str = ReportEnv.getProperty("StyleReport.locale.resource");
      if (str != null)
        loadResourceBundle(str); 
    } catch (Throwable throwable) {}
    try {
      String str = ReportEnv.getProperty("StyleReport.locale.properties");
      if (str != null)
        loadProperty(str); 
    } catch (Throwable throwable) {}
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\locale\Catalog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */