/*     */ package inetsoft.report.locale;
/*     */ 
/*     */ import inetsoft.report.ReportEnv;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Catalog
/*     */ {
/*     */   public static String getString(String paramString) {
/*  42 */     String str = paramString.replace(' ', '_');
/*  43 */     str = str.replace('\n', '_');
/*  44 */     str = str.replace('\t', '_');
/*     */     
/*  46 */     Object object = (prop.size() > 0) ? prop.get(str) : null;
/*  47 */     return (String)((object == null) ? paramString : object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static void put(String paramString, Object paramObject) { prop.put(paramString, paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void loadProperty(String paramString) throws IOException {
/*     */     try {
/*  67 */       loadProperty(Catalog.class.getResourceAsStream(paramString));
/*     */     } catch (IOException iOException) {
/*  69 */       throw iOException;
/*     */     } catch (Exception exception) {
/*  71 */       throw new IOException("Failed to load properties: " + paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public static void loadProperty(InputStream paramInputStream) throws IOException { prop.load(paramInputStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public static void loadResourceBundle(String paramString) throws IOException { loadResourceBundle(ResourceBundle.getBundle(paramString)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void loadResourceBundle(ResourceBundle paramResourceBundle) {
/*  98 */     Enumeration enumeration = paramResourceBundle.getKeys();
/*     */     
/* 100 */     while (enumeration.hasMoreElements()) {
/*     */       try {
/* 102 */         String str = (String)enumeration.nextElement();
/* 103 */         prop.put(str, paramResourceBundle.getObject(str));
/*     */       } catch (Exception exception) {
/* 105 */         exception.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/* 110 */   private static Properties prop = new Properties();
/*     */   static  {
/*     */     try {
/* 113 */       String str = ReportEnv.getProperty("StyleReport.locale.resource");
/* 114 */       if (str != null) {
/* 115 */         loadResourceBundle(str);
/*     */       }
/* 117 */     } catch (Throwable throwable) {}
/*     */ 
/*     */     
/*     */     try {
/* 121 */       String str = ReportEnv.getProperty("StyleReport.locale.properties");
/* 122 */       if (str != null) {
/* 123 */         loadProperty(str);
/*     */       }
/* 125 */     } catch (Throwable throwable) {}
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\locale\Catalog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */