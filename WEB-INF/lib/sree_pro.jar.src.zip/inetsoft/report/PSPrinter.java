package inetsoft.report;

import inetsoft.report.internal.PSGraphics;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.PrintGraphics;
import java.awt.PrintJob;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class PSPrinter extends PSGraphics implements PrintGraphics {
  Printer job;
  
  public PSPrinter(File paramFile) throws IOException { this(new FileOutputStream(paramFile)); }
  
  public PSPrinter(String paramString) throws IOException { this(Runtime.getRuntime().exec(paramString).getOutputStream()); }
  
  public PSPrinter(OutputStream paramOutputStream) { super(paramOutputStream); }
  
  protected PSPrinter() {}
  
  public void setOutput(OutputStream paramOutputStream) { super.setOutput(paramOutputStream); }
  
  public void setCompressImage(boolean paramBoolean) { super.setCompressImage(paramBoolean); }
  
  public boolean isCompressImage() { return super.isCompressImage(); }
  
  public void setPageSize(double paramDouble1, double paramDouble2) { super.setPageSize(paramDouble1, paramDouble2); }
  
  public void setPageSize(Size paramSize) { setPageSize(paramSize.width, paramSize.height); }
  
  public Size getPageSize() {
    Dimension dimension = getPageDimension();
    return new Size(dimension.width / 72.0D, dimension.height / 72.0D);
  }
  
  public Dimension getPageDimension() { return super.getPageDimension(); }
  
  public void setOrientation(int paramInt) { super.setOrientation(paramInt); }
  
  public int getOrientation() { return super.getOrientation(); }
  
  public PrintJob getPrintJob() {
    if (this.job == null) {
      this.job = new Printer(this);
      startDoc();
    } 
    return this.job;
  }
  
  class Printer extends PrintJob {
    private final PSPrinter this$0;
    
    Printer(PSPrinter this$0) { this.this$0 = this$0; }
    
    public Graphics getGraphics() {
      this.this$0.reset();
      return this.this$0;
    }
    
    public Dimension getPageDimension() { return this.this$0.getPageDimension(); }
    
    public int getPageResolution() { return 72; }
    
    public boolean lastPageFirst() { return false; }
    
    public void end() { this.this$0.close(); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\PSPrinter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */