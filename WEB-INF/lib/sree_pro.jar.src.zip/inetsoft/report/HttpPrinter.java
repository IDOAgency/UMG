package inetsoft.report;

import java.awt.PrintJob;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class HttpPrinter implements Serializable {
  PDFPrinter printer;
  
  URL url;
  
  URL context;
  
  String spec;
  
  URLConnection conn;
  
  public HttpPrinter(String paramString) throws IOException { this(null, paramString); }
  
  public HttpPrinter(URL paramURL, String paramString) throws IOException {
    this.url = new URL(paramURL, paramString);
    this.context = paramURL;
    this.spec = paramString;
    this.conn = this.url.openConnection();
    this.conn.setDoOutput(true);
    if (this.conn instanceof HttpURLConnection) {
      ((HttpURLConnection)this.conn).setRequestMethod("POST");
      ((HttpURLConnection)this.conn).setRequestProperty("Content-type", "application/pdf");
    } 
  }
  
  public PrintJob getPrintJob() throws IOException {
    if (this.printer == null)
      this.printer = new PDFPrinter(this.conn.getOutputStream()); 
    return this.printer.getPrintJob();
  }
  
  public PDFPrinter getPrinter() throws IOException {
    if (this.printer == null)
      this.printer = new PDFPrinter(this.conn.getOutputStream()); 
    return this.printer;
  }
  
  public URL getURL() {
    if (this.printer != null) {
      this.printer.close();
      this.printer = null;
    } 
    String str = null;
    try {
      this.conn.connect();
      BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.conn.getInputStream()));
      str = bufferedReader.readLine();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    try {
      return new URL(this.context, this.spec + "?report=" + str);
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\HttpPrinter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */