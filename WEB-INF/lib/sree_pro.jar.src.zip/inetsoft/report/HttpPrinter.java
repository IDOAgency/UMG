/*     */ package inetsoft.report;
/*     */ 
/*     */ import java.awt.PrintJob;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Serializable;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpPrinter
/*     */   implements Serializable
/*     */ {
/*     */   PDFPrinter printer;
/*     */   URL url;
/*     */   URL context;
/*     */   String spec;
/*     */   URLConnection conn;
/*     */   
/*  42 */   public HttpPrinter(String paramString) throws IOException { this(null, paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpPrinter(URL paramURL, String paramString) throws IOException {
/*  54 */     this.url = new URL(paramURL, paramString);
/*  55 */     this.context = paramURL;
/*  56 */     this.spec = paramString;
/*     */     
/*  58 */     this.conn = this.url.openConnection();
/*  59 */     this.conn.setDoOutput(true);
/*  60 */     if (this.conn instanceof HttpURLConnection) {
/*  61 */       ((HttpURLConnection)this.conn).setRequestMethod("POST");
/*  62 */       ((HttpURLConnection)this.conn).setRequestProperty("Content-type", "application/pdf");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintJob getPrintJob() throws IOException {
/*  71 */     if (this.printer == null) {
/*  72 */       this.printer = new PDFPrinter(this.conn.getOutputStream());
/*     */     }
/*     */     
/*  75 */     return this.printer.getPrintJob();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PDFPrinter getPrinter() throws IOException {
/*  83 */     if (this.printer == null) {
/*  84 */       this.printer = new PDFPrinter(this.conn.getOutputStream());
/*     */     }
/*     */     
/*  87 */     return this.printer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getURL() {
/*  94 */     if (this.printer != null) {
/*  95 */       this.printer.close();
/*  96 */       this.printer = null;
/*     */     } 
/*     */     
/*  99 */     String str = null;
/*     */     try {
/* 101 */       this.conn.connect();
/*     */       
/* 103 */       BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.conn.getInputStream()));
/*     */       
/* 105 */       str = bufferedReader.readLine();
/*     */     } catch (Exception exception) {
/* 107 */       exception.printStackTrace();
/*     */     } 
/*     */     
/*     */     try {
/* 111 */       return new URL(this.context, this.spec + "?report=" + str);
/*     */     } catch (Exception exception) {
/* 113 */       exception.printStackTrace();
/*     */ 
/*     */       
/* 116 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\HttpPrinter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */