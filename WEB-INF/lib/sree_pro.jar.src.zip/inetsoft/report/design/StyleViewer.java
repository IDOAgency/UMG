package inetsoft.report.design;

import inetsoft.report.PreviewView;
import inetsoft.report.Previewer;
import inetsoft.report.StyleFont;
import inetsoft.report.StyleSheet;
import inetsoft.report.lens.DefaultTableLens;
import inetsoft.report.locale.Catalog;
import inetsoft.report.style.TableStyle;
import inetsoft.report.style.XTableStyle;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

public class StyleViewer extends JPanel {
  StyleTree styles;
  
  JPanel tablePane;
  
  TableView table;
  
  DefaultTableLens model;
  
  JCheckBox borderColorCB;
  
  JCheckBox rowBorderCB;
  
  JCheckBox colBorderCB;
  
  JCheckBox alignCB;
  
  JCheckBox fontCB;
  
  JCheckBox colorCB;
  
  JCheckBox shadeCB;
  
  JCheckBox firstRowCB;
  
  JCheckBox firstColCB;
  
  JCheckBox lastRowCB;
  
  JCheckBox lastColCB;
  
  JButton newB;
  
  JButton editB;
  
  JButton removeB;
  
  ItemListener optListener;
  
  Object[][] table_data;
  
  static Frame root;
  
  public StyleViewer(Window paramWindow) {
    this.tablePane = new JPanel();
    this.borderColorCB = new JCheckBox(Catalog.getString("Border Color"), true);
    this.rowBorderCB = new JCheckBox(Catalog.getString("Horizontal Border"), true);
    this.colBorderCB = new JCheckBox(Catalog.getString("Vertical Border"), true);
    this.alignCB = new JCheckBox(Catalog.getString("Alignment"), false);
    this.fontCB = new JCheckBox(Catalog.getString("Font"), true);
    this.colorCB = new JCheckBox(Catalog.getString("Color"), true);
    this.shadeCB = new JCheckBox(Catalog.getString("Shading"), true);
    this.firstRowCB = new JCheckBox(Catalog.getString("Heading Row"), true);
    this.firstColCB = new JCheckBox(Catalog.getString("Heading Column"), true);
    this.lastRowCB = new JCheckBox(Catalog.getString("Trailing Row"), false);
    this.lastColCB = new JCheckBox(Catalog.getString("Trailing Column"), false);
    this.newB = new JButton(Catalog.getString("New"));
    this.editB = new JButton(Catalog.getString("Edit"));
    this.removeB = new JButton(Catalog.getString("Remove"));
    this.optListener = new ItemListener(this) {
        private final StyleViewer this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          if (this.this$0.table.getTable() instanceof TableStyle) {
            TableStyle tableStyle = (TableStyle)this.this$0.table.getTable();
            tableStyle.setApplyRowBorderColor(this.this$0.borderColorCB.isSelected());
            tableStyle.setApplyColBorderColor(this.this$0.borderColorCB.isSelected());
            tableStyle.setApplyRowBorder(this.this$0.rowBorderCB.isSelected());
            tableStyle.setApplyColBorder(this.this$0.colBorderCB.isSelected());
            tableStyle.setApplyAlignment(this.this$0.alignCB.isSelected());
            tableStyle.setApplyFont(this.this$0.fontCB.isSelected());
            tableStyle.setApplyForeground(this.this$0.colorCB.isSelected());
            tableStyle.setApplyBackground(this.this$0.shadeCB.isSelected());
            tableStyle.setFormatFirstRow(this.this$0.firstRowCB.isSelected());
            tableStyle.setFormatFirstCol(this.this$0.firstColCB.isSelected());
            tableStyle.setFormatLastRow(this.this$0.lastRowCB.isSelected());
            tableStyle.setFormatLastCol(this.this$0.lastColCB.isSelected());
            this.this$0.table.reprint();
            this.this$0.validate();
            this.this$0.table.repaint(100L);
          } 
        }
      };
    this.table_data = new Object[][] { { "Region", "1st Qtr", "2nd Qtr", "Total" }, { "East", "$200", "$300", "$500" }, { "Central", "$60", "$50", "$110" }, { "West", "$180", "$400", "$580" }, { "Total", "$440", "$750", "$1190" } };
    this.titlefont = new StyleFont("Serif", 17, 14, 8195);
    this.deffont = new Font("Dialog", 0, 10);
    setLayout(new BorderLayout(5, 20));
    this.model = new DefaultTableLens();
    this.model.setData(this.table_data);
    this.model.setHeaderRowCount(1);
    this.model.setHeaderColCount(1);
    this.table = new TableView(5.0D);
    this.table.setTable(this.model);
    this.tablePane.setBackground(Color.white);
    this.tablePane.add(this.table);
    JScrollPane jScrollPane = new JScrollPane(this.tablePane);
    jScrollPane.setPreferredSize(new Dimension(380, 150));
    add(jScrollPane, "Center");
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(new BorderLayout(20, 20));
    add(jPanel1, "South");
    try {
      this.styles = new StyleTree(getClass().getResourceAsStream("style.tree"));
    } catch (Exception exception) {
      exception.printStackTrace();
      JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
      System.exit(1);
    } 
    this.styles.addTreeSelectionListener(new TreeSelectionListener(this) {
          private final StyleViewer this$0;
          
          public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
            String str = this.this$0.styles.getSelectedStyle();
            TableStyle tableStyle = null;
            if (this.this$0.styles.getSelectionCount() == 1 && str != null) {
              tableStyle = StyleTree.get(str);
              if (tableStyle != null)
                this.this$0.setTableStyle(tableStyle); 
            } else {
              this.this$0.setTableStyle(null);
            } 
            this.this$0.editB.setEnabled(tableStyle instanceof XTableStyle);
            this.this$0.removeB.setEnabled(tableStyle instanceof XTableStyle);
          }
        });
    add(jScrollPane = new JScrollPane(this.styles), "West");
    jScrollPane.setPreferredSize(new Dimension(180, 150));
    JPanel jPanel2 = new JPanel();
    jPanel2.setLayout(new GridLayout(0, 3));
    jPanel2.add(this.borderColorCB);
    jPanel2.add(this.rowBorderCB);
    jPanel2.add(this.colBorderCB);
    jPanel2.add(this.alignCB);
    jPanel2.add(this.fontCB);
    jPanel2.add(this.colorCB);
    jPanel2.add(this.shadeCB);
    jPanel2.add(this.firstRowCB);
    jPanel2.add(this.firstColCB);
    jPanel2.add(this.lastRowCB);
    jPanel2.add(this.lastColCB);
    jPanel1.add(jPanel2, "Center");
    JPanel jPanel3 = new JPanel();
    jPanel1.add(jPanel3, "South");
    if (paramWindow instanceof Frame) {
      JButton jButton1 = new JButton(Catalog.getString("Select All"));
      jPanel3.add(jButton1);
      jButton1.addActionListener(new ActionListener(this) {
            private final StyleViewer this$0;
            
            public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.styles.selectAll(); }
          });
      JButton jButton2 = new JButton(Catalog.getString("Preview"));
      jPanel3.add(jButton2);
      jButton2.addActionListener(new ActionListener(this) {
            private final StyleViewer this$0;
            
            public void actionPerformed(ActionEvent param1ActionEvent) {
              StyleSheet styleSheet = this.this$0.createReport();
              PreviewView previewView = Previewer.createPreviewer();
              previewView.print(styleSheet);
              previewView.pack();
              previewView.setVisible(true);
            }
          });
      JButton jButton3 = new JButton(Catalog.getString("Quit"));
      jPanel3.add(jButton3);
      jButton3.addActionListener(new ActionListener(this) {
            private final StyleViewer this$0;
            
            public void actionPerformed(ActionEvent param1ActionEvent) { System.exit(0); }
          });
    } else {
      jPanel3.add(this.newB);
      this.newB.addActionListener(new ActionListener(this) {
            private final StyleViewer this$0;
            
            public void actionPerformed(ActionEvent param1ActionEvent) {
              XTableStyle xTableStyle = StyleDesigner.show(null, null);
              if (xTableStyle != null) {
                StyleTree.put(xTableStyle.getName(), xTableStyle);
                this.this$0.styles.populateUserStyles();
                this.this$0.styles.setSelectedStyle(xTableStyle);
              } 
            }
          });
      this.editB.setEnabled(false);
      jPanel3.add(this.editB);
      this.editB.addActionListener(new ActionListener(this) {
            private final StyleViewer this$0;
            
            public void actionPerformed(ActionEvent param1ActionEvent) {
              String str = this.this$0.styles.getSelectedStyle();
              if (str != null) {
                TableStyle tableStyle = StyleTree.get(str);
                if (tableStyle != null && tableStyle instanceof XTableStyle) {
                  XTableStyle xTableStyle = StyleDesigner.show(StyleViewer.root, (XTableStyle)tableStyle);
                  if (xTableStyle != null) {
                    String str1 = xTableStyle.getName();
                    StyleTree.put(str1, xTableStyle);
                    this.this$0.setTableStyle(xTableStyle);
                    if (!str.equals(str1)) {
                      StyleTree.remove(str);
                      this.this$0.styles.populateUserStyles();
                    } 
                  } 
                } 
              } 
            }
          });
      this.removeB.setEnabled(false);
      jPanel3.add(this.removeB);
      this.removeB.addActionListener(new ActionListener(this) {
            private final StyleViewer this$0;
            
            public void actionPerformed(ActionEvent param1ActionEvent) {
              String str = this.this$0.styles.getSelectedStyle();
              switch (JOptionPane.showConfirmDialog(this.this$0, StyleViewer.removeMsg)) {
                case 1:
                case 2:
                  return;
              } 
              if (str != null) {
                StyleTree.remove(str);
                this.this$0.styles.populateUserStyles();
              } 
            }
          });
      if (paramWindow != null) {
        JButton jButton1 = new JButton(Catalog.getString("OK"));
        jPanel3.add(jButton1);
        jButton1.addActionListener(new ActionListener(this, paramWindow) {
              private final Window val$win;
              
              private final StyleViewer this$0;
              
              public void actionPerformed(ActionEvent param1ActionEvent) { this.val$win.dispose(); }
            });
        JButton jButton2 = new JButton(Catalog.getString("Cancel"));
        jPanel3.add(jButton2);
        jButton2.addActionListener(new ActionListener(this, paramWindow) {
              private final Window val$win;
              
              private final StyleViewer this$0;
              
              public void actionPerformed(ActionEvent param1ActionEvent) {
                this.this$0.styles.clearSelection();
                this.val$win.dispose();
              }
            });
      } 
    } 
    this.borderColorCB.addItemListener(this.optListener);
    this.rowBorderCB.addItemListener(this.optListener);
    this.colBorderCB.addItemListener(this.optListener);
    this.alignCB.addItemListener(this.optListener);
    this.fontCB.addItemListener(this.optListener);
    this.colorCB.addItemListener(this.optListener);
    this.shadeCB.addItemListener(this.optListener);
    this.firstRowCB.addItemListener(this.optListener);
    this.firstColCB.addItemListener(this.optListener);
    this.lastRowCB.addItemListener(this.optListener);
    this.lastColCB.addItemListener(this.optListener);
  }
  
  public static TableStyle show(Frame paramFrame, TableStyle paramTableStyle) {
    JDialog jDialog = new JDialog(root = paramFrame, Catalog.getString("Style Viewer"), true);
    StyleViewer styleViewer = new StyleViewer(jDialog);
    if (paramTableStyle != null)
      styleViewer.setSelectedStyle((TableStyle)paramTableStyle.clone()); 
    jDialog.getContentPane().add(styleViewer, "Center");
    jDialog.pack();
    jDialog.setVisible(true);
    jDialog.addWindowListener(new WindowAdapter(jDialog) {
          private final JDialog val$win;
          
          public void windowClosing(WindowEvent param1WindowEvent) { this.val$win.dispose(); }
        });
    return styleViewer.getSelectedStyle();
  }
  
  public void setTableStyle(TableStyle paramTableStyle) {
    if (paramTableStyle != null) {
      paramTableStyle.setTable(this.model);
      this.table.setTable(paramTableStyle);
    } else {
      this.table.setTable(this.model);
    } 
    this.optListener.itemStateChanged(null);
    validate();
    this.table.repaint(100L);
  }
  
  public TableStyle getSelectedStyle() { return (this.table.getTable() instanceof TableStyle) ? (TableStyle)this.table.getTable() : null; }
  
  public void setSelectedStyle(TableStyle paramTableStyle) {
    this.borderColorCB.setSelected(paramTableStyle.isApplyRowBorderColor());
    this.borderColorCB.setSelected(paramTableStyle.isApplyColBorderColor());
    this.rowBorderCB.setSelected(paramTableStyle.isApplyRowBorder());
    this.colBorderCB.setSelected(paramTableStyle.isApplyColBorder());
    this.alignCB.setSelected(paramTableStyle.isApplyAlignment());
    this.fontCB.setSelected(paramTableStyle.isApplyFont());
    this.colorCB.setSelected(paramTableStyle.isApplyForeground());
    this.shadeCB.setSelected(paramTableStyle.isApplyBackground());
    this.firstRowCB.setSelected(paramTableStyle.isFormatFirstRow());
    this.firstColCB.setSelected(paramTableStyle.isFormatFirstCol());
    this.lastRowCB.setSelected(paramTableStyle.isFormatLastRow());
    this.lastColCB.setSelected(paramTableStyle.isFormatLastCol());
    this.styles.setSelectedStyle(paramTableStyle);
    setTableStyle(paramTableStyle);
  }
  
  StyleSheet createReport() {
    StyleSheet styleSheet = new StyleSheet();
    styleSheet.setCurrentAlignment(2);
    styleSheet.addHeaderText("JTable Report, Page {P} of {N}");
    styleSheet.addFooterText("This is an example of using StyleSheet, {D,MM/dd/yyyy} {T}");
    String[] arrayOfString = this.styles.getSelectedStyles();
    for (byte b = 0; b < arrayOfString.length; b++) {
      TableStyle tableStyle = StyleTree.get((String)arrayOfString[b]);
      tableStyle.setApplyRowBorderColor(this.borderColorCB.isSelected());
      tableStyle.setApplyColBorderColor(this.borderColorCB.isSelected());
      tableStyle.setApplyRowBorder(this.rowBorderCB.isSelected());
      tableStyle.setApplyColBorder(this.colBorderCB.isSelected());
      tableStyle.setApplyAlignment(this.alignCB.isSelected());
      tableStyle.setApplyFont(this.fontCB.isSelected());
      tableStyle.setApplyForeground(this.colorCB.isSelected());
      tableStyle.setApplyBackground(this.shadeCB.isSelected());
      tableStyle.setFormatFirstRow(this.firstRowCB.isSelected());
      tableStyle.setFormatFirstCol(this.firstColCB.isSelected());
      tableStyle.setFormatLastRow(this.lastRowCB.isSelected());
      tableStyle.setFormatLastCol(this.lastColCB.isSelected());
      styleSheet.setCurrentAlignment(2);
      styleSheet.setCurrentFont(this.titlefont);
      styleSheet.addNewline(2);
      styleSheet.addConditionalPageBreak(0.5D);
      styleSheet.addText(arrayOfString[b] + " " + Catalog.getString("Table Style"));
      styleSheet.addNewline(2);
      styleSheet.setCurrentAlignment(1);
      styleSheet.setCurrentTableLayout(1);
      styleSheet.setCurrentFont(this.deffont);
      tableStyle.setTable(this.model);
      styleSheet.addConditionalPageBreak(2.0D);
      styleSheet.addTable(tableStyle);
    } 
    return styleSheet;
  }
  
  public static void main(String[] paramArrayOfString) {
    JFrame jFrame = new JFrame(Catalog.getString("Style Viewer"));
    StyleViewer styleViewer = new StyleViewer(jFrame);
    jFrame.getContentPane().add(styleViewer, "Center");
    jFrame.pack();
    jFrame.setVisible(true);
    jFrame.addWindowListener(new WindowAdapter() {
          public void windowClosing(WindowEvent param1WindowEvent) { System.exit(0); }
        });
  }
  
  static final String removeMsg = Catalog.getString("Remove the selected style?");
  
  StyleFont titlefont;
  
  Font deffont;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\design\StyleViewer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */