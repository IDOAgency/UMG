package inetsoft.report.design;

import inetsoft.report.locale.Catalog;
import inetsoft.report.style.TableStyle;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

public class StyleTree extends JTree {
  public StyleTree(InputStream paramInputStream) throws IOException {
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
    DefaultMutableTreeNode defaultMutableTreeNode = new DefaultMutableTreeNode(Catalog.getString("Default"));
    String str;
    while ((str = bufferedReader.readLine()) != null) {
      if (str.charAt(0) != '\t') {
        defaultMutableTreeNode = new DefaultMutableTreeNode(str);
        this.top.add(defaultMutableTreeNode);
        continue;
      } 
      defaultMutableTreeNode.add(new DefaultMutableTreeNode(str.trim()));
    } 
    this.top.add(this.user);
    populateUserStyles();
  }
  
  public String getSelectedStyle() {
    TreePath[] arrayOfTreePath = getSelectionPaths();
    if (arrayOfTreePath != null)
      for (byte b = 0; b < arrayOfTreePath.length; b++) {
        TreeNode treeNode = (TreeNode)arrayOfTreePath[b].getLastPathComponent();
        if (treeNode.isLeaf())
          return treeNode.toString(); 
      }  
    return null;
  }
  
  public String[] getSelectedStyles() {
    TreePath[] arrayOfTreePath = getSelectionPaths();
    if (arrayOfTreePath == null)
      return new String[0]; 
    Vector vector = new Vector();
    for (byte b = 0; b < arrayOfTreePath.length; b++) {
      TreeNode treeNode = (TreeNode)arrayOfTreePath[b].getLastPathComponent();
      if (treeNode.isLeaf())
        vector.addElement(treeNode.toString()); 
    } 
    String[] arrayOfString = new String[vector.size()];
    vector.copyInto(arrayOfString);
    return arrayOfString;
  }
  
  public void setSelectedStyle(TableStyle paramTableStyle) {
    clearSelection();
    Enumeration enumeration = this.top.breadthFirstEnumeration();
    while (enumeration.hasMoreElements()) {
      DefaultMutableTreeNode defaultMutableTreeNode = (DefaultMutableTreeNode)enumeration.nextElement();
      if (defaultMutableTreeNode.toString().equals(paramTableStyle.getName())) {
        addSelectionPath(new TreePath(defaultMutableTreeNode.getPath()));
        break;
      } 
    } 
  }
  
  public void populateUserStyles() {
    Enumeration enumeration = stylemap.keys();
    this.user.removeAllChildren();
    while (enumeration.hasMoreElements()) {
      Object object = enumeration.nextElement();
      this.user.add(new DefaultMutableTreeNode(object));
    } 
    setModel(new DefaultTreeModel(this.top, false));
  }
  
  public void selectAll() {
    clearSelection();
    Enumeration enumeration = this.top.breadthFirstEnumeration();
    while (enumeration.hasMoreElements()) {
      DefaultMutableTreeNode defaultMutableTreeNode = (DefaultMutableTreeNode)enumeration.nextElement();
      if (defaultMutableTreeNode.isLeaf() && defaultMutableTreeNode != this.user)
        addSelectionPath(new TreePath(defaultMutableTreeNode.getPath())); 
    } 
  }
  
  public static void put(String paramString, TableStyle paramTableStyle) { stylemap.put(paramString, paramTableStyle); }
  
  public static void remove(String paramString) { stylemap.remove(paramString); }
  
  public static TableStyle get(String paramString) {
    TableStyle tableStyle = (TableStyle)stylemap.get(paramString);
    if (tableStyle == null) {
      try {
        paramString = "inetsoft.report.style." + paramString;
        tableStyle = (TableStyle)Class.forName(paramString).newInstance();
      } catch (Exception exception) {}
    } else {
      tableStyle = (TableStyle)tableStyle.clone();
    } 
    return tableStyle;
  }
  
  public static void addUserStyles(Vector paramVector) {
    for (byte b = 0; b < paramVector.size(); b++) {
      TableStyle tableStyle = (TableStyle)paramVector.elementAt(b);
      put(tableStyle.getName(), tableStyle);
    } 
  }
  
  public static Vector getUserStyles() {
    Vector vector = new Vector();
    Enumeration enumeration = stylemap.elements();
    while (enumeration.hasMoreElements()) {
      Object object = enumeration.nextElement();
      if (object instanceof inetsoft.report.style.XTableStyle)
        vector.addElement(object); 
    } 
    return vector;
  }
  
  DefaultMutableTreeNode top = new DefaultMutableTreeNode(Catalog.getString("Style"));
  
  DefaultMutableTreeNode user = new DefaultMutableTreeNode(Catalog.getString("User Defined"));
  
  static Hashtable stylemap = new Hashtable();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\design\StyleTree.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */