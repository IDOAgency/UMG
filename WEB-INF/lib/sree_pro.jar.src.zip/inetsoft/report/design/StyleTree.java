/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.report.style.TableStyle;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.tree.DefaultMutableTreeNode;
/*     */ import javax.swing.tree.DefaultTreeModel;
/*     */ import javax.swing.tree.TreeNode;
/*     */ import javax.swing.tree.TreePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StyleTree
/*     */   extends JTree
/*     */ {
/*     */   public StyleTree(InputStream paramInputStream) throws IOException {
/*  38 */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
/*     */ 
/*     */     
/*  41 */     DefaultMutableTreeNode defaultMutableTreeNode = new DefaultMutableTreeNode(Catalog.getString("Default"));
/*     */     
/*     */     String str;
/*  44 */     while ((str = bufferedReader.readLine()) != null) {
/*  45 */       if (str.charAt(0) != '\t') {
/*  46 */         defaultMutableTreeNode = new DefaultMutableTreeNode(str);
/*  47 */         this.top.add(defaultMutableTreeNode);
/*     */         continue;
/*     */       } 
/*  50 */       defaultMutableTreeNode.add(new DefaultMutableTreeNode(str.trim()));
/*     */     } 
/*     */ 
/*     */     
/*  54 */     this.top.add(this.user);
/*  55 */     populateUserStyles();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSelectedStyle() {
/*  63 */     TreePath[] arrayOfTreePath = getSelectionPaths();
/*  64 */     if (arrayOfTreePath != null) {
/*  65 */       for (byte b = 0; b < arrayOfTreePath.length; b++) {
/*  66 */         TreeNode treeNode = (TreeNode)arrayOfTreePath[b].getLastPathComponent();
/*  67 */         if (treeNode.isLeaf()) {
/*  68 */           return treeNode.toString();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*  73 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getSelectedStyles() {
/*  81 */     TreePath[] arrayOfTreePath = getSelectionPaths();
/*  82 */     if (arrayOfTreePath == null) {
/*  83 */       return new String[0];
/*     */     }
/*     */     
/*  86 */     Vector vector = new Vector();
/*     */     
/*  88 */     for (byte b = 0; b < arrayOfTreePath.length; b++) {
/*  89 */       TreeNode treeNode = (TreeNode)arrayOfTreePath[b].getLastPathComponent();
/*  90 */       if (treeNode.isLeaf()) {
/*  91 */         vector.addElement(treeNode.toString());
/*     */       }
/*     */     } 
/*     */     
/*  95 */     String[] arrayOfString = new String[vector.size()];
/*  96 */     vector.copyInto(arrayOfString);
/*  97 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectedStyle(TableStyle paramTableStyle) {
/* 105 */     clearSelection();
/*     */     
/* 107 */     Enumeration enumeration = this.top.breadthFirstEnumeration();
/* 108 */     while (enumeration.hasMoreElements()) {
/* 109 */       DefaultMutableTreeNode defaultMutableTreeNode = (DefaultMutableTreeNode)enumeration.nextElement();
/*     */       
/* 111 */       if (defaultMutableTreeNode.toString().equals(paramTableStyle.getName())) {
/* 112 */         addSelectionPath(new TreePath(defaultMutableTreeNode.getPath()));
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void populateUserStyles() {
/* 122 */     Enumeration enumeration = stylemap.keys();
/* 123 */     this.user.removeAllChildren();
/*     */     
/* 125 */     while (enumeration.hasMoreElements()) {
/* 126 */       Object object = enumeration.nextElement();
/* 127 */       this.user.add(new DefaultMutableTreeNode(object));
/*     */     } 
/*     */     
/* 130 */     setModel(new DefaultTreeModel(this.top, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectAll() {
/* 137 */     clearSelection();
/*     */     
/* 139 */     Enumeration enumeration = this.top.breadthFirstEnumeration();
/* 140 */     while (enumeration.hasMoreElements()) {
/* 141 */       DefaultMutableTreeNode defaultMutableTreeNode = (DefaultMutableTreeNode)enumeration.nextElement();
/*     */ 
/*     */       
/* 144 */       if (defaultMutableTreeNode.isLeaf() && defaultMutableTreeNode != this.user) {
/* 145 */         addSelectionPath(new TreePath(defaultMutableTreeNode.getPath()));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public static void put(String paramString, TableStyle paramTableStyle) { stylemap.put(paramString, paramTableStyle); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   public static void remove(String paramString) { stylemap.remove(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TableStyle get(String paramString) {
/* 175 */     TableStyle tableStyle = (TableStyle)stylemap.get(paramString);
/*     */     
/* 177 */     if (tableStyle == null) {
/*     */       try {
/* 179 */         paramString = "inetsoft.report.style." + paramString;
/* 180 */         tableStyle = (TableStyle)Class.forName(paramString).newInstance();
/* 181 */       } catch (Exception exception) {}
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 187 */       tableStyle = (TableStyle)tableStyle.clone();
/*     */     } 
/*     */     
/* 190 */     return tableStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addUserStyles(Vector paramVector) {
/* 198 */     for (byte b = 0; b < paramVector.size(); b++) {
/* 199 */       TableStyle tableStyle = (TableStyle)paramVector.elementAt(b);
/* 200 */       put(tableStyle.getName(), tableStyle);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector getUserStyles() {
/* 209 */     Vector vector = new Vector();
/* 210 */     Enumeration enumeration = stylemap.elements();
/*     */     
/* 212 */     while (enumeration.hasMoreElements()) {
/* 213 */       Object object = enumeration.nextElement();
/*     */       
/* 215 */       if (object instanceof inetsoft.report.style.XTableStyle) {
/* 216 */         vector.addElement(object);
/*     */       }
/*     */     } 
/*     */     
/* 220 */     return vector;
/*     */   }
/*     */   
/* 223 */   DefaultMutableTreeNode top = new DefaultMutableTreeNode(Catalog.getString("Style"));
/*     */   
/* 225 */   DefaultMutableTreeNode user = new DefaultMutableTreeNode(Catalog.getString("User Defined"));
/*     */   
/* 227 */   static Hashtable stylemap = new Hashtable();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\design\StyleTree.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */