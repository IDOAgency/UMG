/*    */ package inetsoft.report;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SContainer
/*    */   extends Container
/*    */ {
/*    */   boolean bg;
/*    */   
/* 24 */   public SContainer() { this(false); }
/*    */ 
/*    */ 
/*    */   
/* 28 */   public SContainer(boolean paramBoolean) { this.bg = paramBoolean; }
/*    */ 
/*    */   
/*    */   public void paint(Graphics paramGraphics) {
/* 32 */     if (this.bg) {
/* 33 */       Dimension dimension = getSize();
/* 34 */       paramGraphics.setColor(getBackground());
/* 35 */       paramGraphics.fillRect(0, 0, dimension.width, dimension.height);
/* 36 */       paramGraphics.setColor(getForeground());
/*    */     } 
/*    */     
/* 39 */     super.paint(paramGraphics);
/*    */   }
/*    */ 
/*    */   
/* 43 */   public void update(Graphics paramGraphics) { paint(paramGraphics); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\SContainer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */