package inetsoft.report;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;

class SContainer extends Container {
  boolean bg;
  
  public SContainer() { this(false); }
  
  public SContainer(boolean paramBoolean) { this.bg = paramBoolean; }
  
  public void paint(Graphics paramGraphics) {
    if (this.bg) {
      Dimension dimension = getSize();
      paramGraphics.setColor(getBackground());
      paramGraphics.fillRect(0, 0, dimension.width, dimension.height);
      paramGraphics.setColor(getForeground());
    } 
    super.paint(paramGraphics);
  }
  
  public void update(Graphics paramGraphics) { paint(paramGraphics); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\SContainer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */