package inetsoft.report;

public interface TOCElement extends CompositeElement {
  TOC getTOC();
  
  void setTOC(TOC paramTOC);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\TOCElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */