package inetsoft.report.lens.vcafe;

import inetsoft.report.lens.AbstractTableLens;
import inetsoft.report.lens.AttributeTableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import symantec.itools.db.awt.BasicCell;
import symantec.itools.db.awt.TableCell;
import symantec.itools.db.awt.TableView;

public class TableViewLens extends AttributeTableLens {
  TableView table;
  
  TableCell cell;
  
  public TableViewLens(TableView paramTableView) {
    setTable(new Table(this));
    this.table = paramTableView;
    this.cell = new BasicCell(paramTableView, paramTableView.getDataSource());
  }
  
  class Table extends AbstractTableLens {
    private final TableViewLens this$0;
    
    Table(TableViewLens this$0) { this.this$0 = this$0; }
    
    public int getRowCount() { return this.this$0.table.rows() + this.this$0.getHeaderRow(); }
    
    public int getColCount() { return this.this$0.table.cols() + this.this$0.getHeaderCol(); }
    
    public int getHeaderRowCount() { return this.this$0.getHeaderRow(); }
    
    public int getHeaderColCount() { return this.this$0.getHeaderCol(); }
    
    public int getRowHeight(int param1Int) { return (param1Int < this.this$0.getHeaderRow()) ? this.this$0.table.getHeadingHeight() : this.this$0.table.getRowHeight(this.this$0.rowIndex(param1Int)); }
    
    public int getColWidth(int param1Int) { return (param1Int < this.this$0.getHeaderCol()) ? this.this$0.table.getRowHeadingWidth() : this.this$0.table.getColumnWidth(this.this$0.colIndex(param1Int)); }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return this.this$0.table.getColumnHorizontalLineColor(Math.max(this.this$0.colIndex(param1Int2), 1)); }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return this.this$0.table.getColumnLeftLineColor(Math.max(this.this$0.colIndex(param1Int2), 1)); }
    
    public int getRowBorder(int param1Int1, int param1Int2) {
      int i = this.this$0.table.getColumnHorizontalLineStyle(Math.max(this.this$0.colIndex(param1Int2), 1));
      return this.this$0.convertStyle(i);
    }
    
    public int getColBorder(int param1Int1, int param1Int2) {
      int i = this.this$0.table.getColumnLeftLineStyle(Math.max(this.this$0.colIndex(param1Int2), 1));
      return this.this$0.convertStyle(i);
    }
    
    public Insets getInsets(int param1Int1, int param1Int2) { return null; }
    
    public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
    
    public int getAlignment(int param1Int1, int param1Int2) {
      this.this$0.setCell(param1Int1, param1Int2);
      int i = this.this$0.table.getCellAlignment(this.this$0.cell);
      switch (i) {
        case 0:
          return 17;
        case 1:
          return 18;
        case 2:
          return 20;
      } 
      return 18;
    }
    
    public Font getFont(int param1Int1, int param1Int2) {
      this.this$0.setCell(param1Int1, param1Int2);
      return this.this$0.table.getCellFont(this.this$0.cell);
    }
    
    public Color getForeground(int param1Int1, int param1Int2) {
      this.this$0.setCell(param1Int1, param1Int2);
      return this.this$0.table.getCellFG(this.this$0.cell);
    }
    
    public Color getBackground(int param1Int1, int param1Int2) {
      this.this$0.setCell(param1Int1, param1Int2);
      return this.this$0.table.getCellBG(this.this$0.cell);
    }
    
    public Object getObject(int param1Int1, int param1Int2) {
      try {
        return (param1Int1 < this.this$0.getHeaderRow()) ? this.this$0.table.getHeading(this.this$0.colIndex(param1Int2)) : this.this$0.table.getCellText(this.this$0.rowIndex(param1Int1), this.this$0.colIndex(param1Int2));
      } catch (Exception exception) {
        exception.printStackTrace();
        return null;
      } 
    }
  }
  
  protected int getHeaderRow() { return 1; }
  
  protected int getHeaderCol() { return this.table.isUsingRowHeadings() ? 1 : 0; }
  
  protected int rowIndex(int paramInt) { return paramInt - getHeaderRow() + 1; }
  
  protected int colIndex(int paramInt) { return paramInt - getHeaderCol() + 1; }
  
  protected int convertStyle(int paramInt) {
    switch (paramInt) {
      case 0:
        return 0;
      case 1:
        return 4097;
      case 2:
        return 4099;
    } 
    return 4097;
  }
  
  void setCell(int paramInt1, int paramInt2) {
    if (paramInt1 < getHeaderRow()) {
      this.cell.type(1);
    } else if (paramInt1 < getHeaderCol()) {
      this.cell.type(2);
    } else {
      this.cell.setRow(rowIndex(paramInt1));
      this.cell.setCol(colIndex(paramInt2));
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\vcafe\TableViewLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */