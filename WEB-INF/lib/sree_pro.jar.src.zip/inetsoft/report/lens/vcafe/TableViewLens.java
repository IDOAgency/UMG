/*     */ package inetsoft.report.lens.vcafe;
/*     */ 
/*     */ import inetsoft.report.lens.AbstractTableLens;
/*     */ import inetsoft.report.lens.AttributeTableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import symantec.itools.db.awt.BasicCell;
/*     */ import symantec.itools.db.awt.TableCell;
/*     */ import symantec.itools.db.awt.TableView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableViewLens
/*     */   extends AttributeTableLens
/*     */ {
/*     */   TableView table;
/*     */   TableCell cell;
/*     */   
/*     */   public TableViewLens(TableView paramTableView) {
/*  35 */     setTable(new Table(this));
/*  36 */     this.table = paramTableView;
/*  37 */     this.cell = new BasicCell(paramTableView, paramTableView.getDataSource());
/*     */   }
/*     */   
/*  40 */   class Table extends AbstractTableLens { Table(TableViewLens this$0) { this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */     
/*     */     private final TableViewLens this$0;
/*     */ 
/*     */     
/*  47 */     public int getRowCount() { return this.this$0.table.rows() + this.this$0.getHeaderRow(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     public int getColCount() { return this.this$0.table.cols() + this.this$0.getHeaderCol(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     public int getHeaderRowCount() { return this.this$0.getHeaderRow(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     public int getHeaderColCount() { return this.this$0.getHeaderCol(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     public int getRowHeight(int param1Int) { return (param1Int < this.this$0.getHeaderRow()) ? this.this$0.table.getHeadingHeight() : this.this$0.table.getRowHeight(this.this$0.rowIndex(param1Int)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     public int getColWidth(int param1Int) { return (param1Int < this.this$0.getHeaderCol()) ? this.this$0.table.getRowHeadingWidth() : this.this$0.table.getColumnWidth(this.this$0.colIndex(param1Int)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return this.this$0.table.getColumnHorizontalLineColor(Math.max(this.this$0.colIndex(param1Int2), 1)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return this.this$0.table.getColumnLeftLineColor(Math.max(this.this$0.colIndex(param1Int2), 1)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getRowBorder(int param1Int1, int param1Int2) {
/* 131 */       int i = this.this$0.table.getColumnHorizontalLineStyle(Math.max(this.this$0.colIndex(param1Int2), 1));
/*     */       
/* 133 */       return this.this$0.convertStyle(i);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getColBorder(int param1Int1, int param1Int2) {
/* 146 */       int i = this.this$0.table.getColumnLeftLineStyle(Math.max(this.this$0.colIndex(param1Int2), 1));
/*     */       
/* 148 */       return this.this$0.convertStyle(i);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     public Insets getInsets(int param1Int1, int param1Int2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getAlignment(int param1Int1, int param1Int2) {
/* 182 */       this.this$0.setCell(param1Int1, param1Int2);
/* 183 */       int i = this.this$0.table.getCellAlignment(this.this$0.cell);
/* 184 */       switch (i) { case 0:
/* 185 */           return 17;
/* 186 */         case 1: return 18;
/* 187 */         case 2: return 20; }
/*     */ 
/*     */       
/* 190 */       return 18;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int1, int param1Int2) {
/* 200 */       this.this$0.setCell(param1Int1, param1Int2);
/* 201 */       return this.this$0.table.getCellFont(this.this$0.cell);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Color getForeground(int param1Int1, int param1Int2) {
/* 212 */       this.this$0.setCell(param1Int1, param1Int2);
/* 213 */       return this.this$0.table.getCellFG(this.this$0.cell);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Color getBackground(int param1Int1, int param1Int2) {
/* 224 */       this.this$0.setCell(param1Int1, param1Int2);
/* 225 */       return this.this$0.table.getCellBG(this.this$0.cell);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getObject(int param1Int1, int param1Int2) {
/*     */       try {
/* 236 */         return (param1Int1 < this.this$0.getHeaderRow()) ? this.this$0.table.getHeading(this.this$0.colIndex(param1Int2)) : this.this$0.table.getCellText(this.this$0.rowIndex(param1Int1), this.this$0.colIndex(param1Int2));
/*     */       } catch (Exception exception) {
/*     */         
/* 239 */         exception.printStackTrace();
/*     */ 
/*     */         
/* 242 */         return null;
/*     */       } 
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/* 248 */   protected int getHeaderRow() { return 1; }
/*     */ 
/*     */ 
/*     */   
/* 252 */   protected int getHeaderCol() { return this.table.isUsingRowHeadings() ? 1 : 0; }
/*     */ 
/*     */ 
/*     */   
/* 256 */   protected int rowIndex(int paramInt) { return paramInt - getHeaderRow() + 1; }
/*     */ 
/*     */ 
/*     */   
/* 260 */   protected int colIndex(int paramInt) { return paramInt - getHeaderCol() + 1; }
/*     */ 
/*     */   
/*     */   protected int convertStyle(int paramInt) {
/* 264 */     switch (paramInt) {
/*     */       case 0:
/* 266 */         return 0;
/*     */       case 1:
/* 268 */         return 4097;
/*     */       case 2:
/* 270 */         return 4099;
/*     */     } 
/*     */     
/* 273 */     return 4097;
/*     */   }
/*     */   
/*     */   void setCell(int paramInt1, int paramInt2) {
/* 277 */     if (paramInt1 < getHeaderRow()) {
/* 278 */       this.cell.type(1);
/*     */     }
/* 280 */     else if (paramInt1 < getHeaderCol()) {
/* 281 */       this.cell.type(2);
/*     */     } else {
/*     */       
/* 284 */       this.cell.setRow(rowIndex(paramInt1));
/* 285 */       this.cell.setCol(colIndex(paramInt2));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\vcafe\TableViewLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */