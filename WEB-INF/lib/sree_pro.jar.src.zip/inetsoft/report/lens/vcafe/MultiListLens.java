/*     */ package inetsoft.report.lens.vcafe;
/*     */ 
/*     */ import inetsoft.report.lens.AbstractTableLens;
/*     */ import inetsoft.report.lens.AttributeTableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import symantec.itools.awt.MultiList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiListLens
/*     */   extends AttributeTableLens
/*     */ {
/*     */   MultiList table;
/*     */   
/*     */   public MultiListLens(MultiList paramMultiList) {
/*  35 */     setTable(new Table(this));
/*  36 */     this.table = paramMultiList;
/*     */   }
/*     */   
/*  39 */   class Table extends AbstractTableLens { Table(MultiListLens this$0) { this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */     
/*     */     private final MultiListLens this$0;
/*     */ 
/*     */     
/*  46 */     public int getRowCount() { return this.this$0.table.getNumberOfRows() + getHeaderRow(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     public int getColCount() { return this.this$0.table.getNumberOfCols(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     public int getHeaderRowCount() { return getHeaderRow(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     public int getHeaderColCount() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     public int getRowHeight(int param1Int) { return -1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     public int getColWidth(int param1Int) { return this.this$0.table.getColumnSize(param1Int); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.lightGray; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.lightGray; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getRowBorder(int param1Int1, int param1Int2) {
/* 127 */       if (param1Int1 >= 0 && param1Int1 < getHeaderRow()) {
/* 128 */         return 24578;
/*     */       }
/*     */       
/* 131 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     public int getColBorder(int param1Int1, int param1Int2) { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     public Insets getInsets(int param1Int1, int param1Int2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getAlignment(int param1Int1, int param1Int2) {
/* 178 */       if (param1Int1 >= getHeaderRow()) {
/* 179 */         int i = this.this$0.table.getColumnAlignment(param1Int2);
/* 180 */         switch (i) { case 0:
/* 181 */             return 17;
/* 182 */           case 1: return 18;
/* 183 */           case 2: return 20; }
/*     */ 
/*     */       
/*     */       } 
/* 187 */       return 18;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int1, int param1Int2) {
/* 197 */       if (param1Int1 < getHeaderRow()) {
/* 198 */         return this.this$0.table.getHeadingFont();
/*     */       }
/*     */       
/* 201 */       return this.this$0.table.getCellFont();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 212 */     public Color getForeground(int param1Int1, int param1Int2) { return (param1Int1 < getHeaderRow()) ? this.this$0.table.getHeadingFg() : this.this$0.table.getCellFg(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     public Color getBackground(int param1Int1, int param1Int2) { return (param1Int1 < getHeaderRow()) ? this.this$0.table.getHeadingBg() : this.this$0.table.getCellBg(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     public Object getObject(int param1Int1, int param1Int2) { return (param1Int1 < getHeaderRow()) ? this.this$0.table.getHeading(param1Int2) : this.this$0.table.getCellText(param1Int1 - getHeaderRow(), param1Int2); }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 238 */     protected int getHeaderRow() { return this.this$0.table.isHeadingVisible() ? 1 : 0; } }
/*     */ 
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\vcafe\MultiListLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */