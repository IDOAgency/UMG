package inetsoft.report.lens.vcafe;

import inetsoft.report.lens.AbstractTableLens;
import inetsoft.report.lens.AttributeTableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import symantec.itools.awt.MultiList;

public class MultiListLens extends AttributeTableLens {
  MultiList table;
  
  public MultiListLens(MultiList paramMultiList) {
    setTable(new Table(this));
    this.table = paramMultiList;
  }
  
  class Table extends AbstractTableLens {
    private final MultiListLens this$0;
    
    Table(MultiListLens this$0) { this.this$0 = this$0; }
    
    public int getRowCount() { return this.this$0.table.getNumberOfRows() + getHeaderRow(); }
    
    public int getColCount() { return this.this$0.table.getNumberOfCols(); }
    
    public int getHeaderRowCount() { return getHeaderRow(); }
    
    public int getHeaderColCount() { return 0; }
    
    public int getRowHeight(int param1Int) { return -1; }
    
    public int getColWidth(int param1Int) { return this.this$0.table.getColumnSize(param1Int); }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.lightGray; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.lightGray; }
    
    public int getRowBorder(int param1Int1, int param1Int2) {
      if (param1Int1 >= 0 && param1Int1 < getHeaderRow())
        return 24578; 
      return 0;
    }
    
    public int getColBorder(int param1Int1, int param1Int2) { return 0; }
    
    public Insets getInsets(int param1Int1, int param1Int2) { return null; }
    
    public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
    
    public int getAlignment(int param1Int1, int param1Int2) {
      if (param1Int1 >= getHeaderRow()) {
        int i = this.this$0.table.getColumnAlignment(param1Int2);
        switch (i) {
          case 0:
            return 17;
          case 1:
            return 18;
          case 2:
            return 20;
        } 
      } 
      return 18;
    }
    
    public Font getFont(int param1Int1, int param1Int2) {
      if (param1Int1 < getHeaderRow())
        return this.this$0.table.getHeadingFont(); 
      return this.this$0.table.getCellFont();
    }
    
    public Color getForeground(int param1Int1, int param1Int2) { return (param1Int1 < getHeaderRow()) ? this.this$0.table.getHeadingFg() : this.this$0.table.getCellFg(); }
    
    public Color getBackground(int param1Int1, int param1Int2) { return (param1Int1 < getHeaderRow()) ? this.this$0.table.getHeadingBg() : this.this$0.table.getCellBg(); }
    
    public Object getObject(int param1Int1, int param1Int2) { return (param1Int1 < getHeaderRow()) ? this.this$0.table.getHeading(param1Int2) : this.this$0.table.getCellText(param1Int1 - getHeaderRow(), param1Int2); }
    
    protected int getHeaderRow() { return this.this$0.table.isHeadingVisible() ? 1 : 0; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\vcafe\MultiListLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */