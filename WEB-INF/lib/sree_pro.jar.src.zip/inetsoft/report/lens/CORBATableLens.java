package inetsoft.report.lens;

import java.lang.reflect.Field;
import java.util.Hashtable;
import java.util.Vector;

public class CORBATableLens extends AttributeTableLens {
  public CORBATableLens(Vector paramVector) {
    Object[] arrayOfObject = new Object[paramVector.size()];
    paramVector.copyInto(arrayOfObject);
    setTable(new CORBATable(this, arrayOfObject));
  }
  
  public CORBATableLens(Object[] paramArrayOfObject) { setTable(new CORBATable(this, paramArrayOfObject)); }
  
  public void setColumns(int[] paramArrayOfInt) { this.columns = paramArrayOfInt; }
  
  public int[] getColumns() { return this.columns; }
  
  public void addNameMapping(String paramString1, String paramString2) { this.namemap.put(paramString1, paramString2); }
  
  public String getName(String paramString) {
    String str = (String)this.namemap.get(paramString);
    return (str == null) ? paramString : str;
  }
  
  class CORBATable extends AbstractTableLens {
    Object[] data;
    
    Field[] fields;
    
    private final CORBATableLens this$0;
    
    public CORBATable(CORBATableLens this$0, Object[] param1ArrayOfObject) {
      this.this$0 = this$0;
      this.data = param1ArrayOfObject;
      this.fields = param1ArrayOfObject.getClass().getComponentType().getFields();
      if (this$0.columns == null) {
        this$0.columns = new int[this.fields.length];
        for (byte b = 0; b < this$0.columns.length; b++)
          this$0.columns[b] = b; 
      } 
    }
    
    public int getRowCount() { return this.data.length + 1; }
    
    public int getColCount() { return this.this$0.columns.length; }
    
    public int getHeaderRowCount() { return 1; }
    
    public int getHeaderColCount() { return 0; }
    
    public Object getObject(int param1Int1, int param1Int2) {
      if (param1Int1 == 0)
        return this.this$0.getName(this.fields[this.this$0.columns[param1Int2]].getName()); 
      try {
        return this.fields[this.this$0.columns[param1Int2]].get(this.data[param1Int1 - 1]);
      } catch (Exception exception) {
        exception.printStackTrace();
        return null;
      } 
    }
  }
  
  Hashtable namemap = new Hashtable();
  
  int[] columns;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\CORBATableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */