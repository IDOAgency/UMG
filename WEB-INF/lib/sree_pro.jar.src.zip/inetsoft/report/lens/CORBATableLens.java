/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CORBATableLens
/*     */   extends AttributeTableLens
/*     */ {
/*     */   public CORBATableLens(Vector paramVector) {
/*  55 */     Object[] arrayOfObject = new Object[paramVector.size()];
/*  56 */     paramVector.copyInto(arrayOfObject);
/*  57 */     setTable(new CORBATable(this, arrayOfObject));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public CORBATableLens(Object[] paramArrayOfObject) { setTable(new CORBATable(this, paramArrayOfObject)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public void setColumns(int[] paramArrayOfInt) { this.columns = paramArrayOfInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public int[] getColumns() { return this.columns; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public void addNameMapping(String paramString1, String paramString2) { this.namemap.put(paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName(String paramString) {
/* 101 */     String str = (String)this.namemap.get(paramString);
/* 102 */     return (str == null) ? paramString : str;
/*     */   }
/*     */ 
/*     */   
/*     */   class CORBATable
/*     */     extends AbstractTableLens
/*     */   {
/*     */     Object[] data;
/*     */     Field[] fields;
/*     */     private final CORBATableLens this$0;
/*     */     
/*     */     public CORBATable(CORBATableLens this$0, Object[] param1ArrayOfObject) {
/* 114 */       this.this$0 = this$0;
/* 115 */       this.data = param1ArrayOfObject;
/* 116 */       this.fields = param1ArrayOfObject.getClass().getComponentType().getFields();
/*     */       
/* 118 */       if (this$0.columns == null) {
/* 119 */         this$0.columns = new int[this.fields.length];
/*     */         
/* 121 */         for (byte b = 0; b < this$0.columns.length; b++) {
/* 122 */           this$0.columns[b] = b;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     public int getRowCount() { return this.data.length + 1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     public int getColCount() { return this.this$0.columns.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     public int getHeaderRowCount() { return 1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     public int getHeaderColCount() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getObject(int param1Int1, int param1Int2) {
/* 169 */       if (param1Int1 == 0) {
/* 170 */         return this.this$0.getName(this.fields[this.this$0.columns[param1Int2]].getName());
/*     */       }
/*     */       
/*     */       try {
/* 174 */         return this.fields[this.this$0.columns[param1Int2]].get(this.data[param1Int1 - 1]);
/*     */       } catch (Exception exception) {
/* 176 */         exception.printStackTrace();
/*     */ 
/*     */         
/* 179 */         return null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 186 */   Hashtable namemap = new Hashtable();
/*     */   int[] columns;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\CORBATableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */