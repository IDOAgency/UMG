/*    */ package inetsoft.report.lens;
/*    */ 
/*    */ import inetsoft.report.TextLens;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParagraphLens
/*    */   implements TextLens
/*    */ {
/*    */   private TextLens text;
/*    */   
/* 35 */   public ParagraphLens(TextLens paramTextLens) { this.text = paramTextLens; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getText() {
/* 43 */     String str = this.text.getText();
/* 44 */     StringBuffer stringBuffer = new StringBuffer(str.length());
/*    */     
/* 46 */     for (byte b = 0; b < str.length(); b++) {
/* 47 */       if (str.charAt(b) == '\n') {
/* 48 */         boolean bool = false;
/* 49 */         byte b1 = b + 1;
/* 50 */         for (; b1 < str.length() && str.charAt(b1) == '\n'; b1++) {
/* 51 */           bool = true;
/*    */         }
/*    */         
/* 54 */         if (bool) {
/* 55 */           stringBuffer.append('\n');
/* 56 */           stringBuffer.append('\n');
/* 57 */           b = b1 - 1;
/*    */         } else {
/*    */           
/* 60 */           stringBuffer.append(' ');
/*    */         } 
/*    */       } else {
/*    */         
/* 64 */         stringBuffer.append(str.charAt(b));
/*    */       } 
/*    */     } 
/*    */     
/* 68 */     return stringBuffer.toString();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\ParagraphLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */