package inetsoft.report.lens;

import inetsoft.report.TextLens;

public class ParagraphLens implements TextLens {
  private TextLens text;
  
  public ParagraphLens(TextLens paramTextLens) { this.text = paramTextLens; }
  
  public String getText() {
    String str = this.text.getText();
    StringBuffer stringBuffer = new StringBuffer(str.length());
    for (byte b = 0; b < str.length(); b++) {
      if (str.charAt(b) == '\n') {
        boolean bool = false;
        byte b1 = b + 1;
        for (; b1 < str.length() && str.charAt(b1) == '\n'; b1++)
          bool = true; 
        if (bool) {
          stringBuffer.append('\n');
          stringBuffer.append('\n');
          b = b1 - 1;
        } else {
          stringBuffer.append(' ');
        } 
      } else {
        stringBuffer.append(str.charAt(b));
      } 
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\ParagraphLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */