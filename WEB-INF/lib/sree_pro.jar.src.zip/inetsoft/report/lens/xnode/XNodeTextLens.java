/*    */ package inetsoft.report.lens.xnode;
/*    */ 
/*    */ import inetsoft.report.TextLens;
/*    */ import inetsoft.uql.XNode;
/*    */ import inetsoft.uql.XTableNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XNodeTextLens
/*    */   implements TextLens
/*    */ {
/*    */   String text;
/*    */   
/*    */   public XNodeTextLens(XNode paramXNode) {
/* 32 */     if (paramXNode instanceof XTableNode) {
/* 33 */       XTableNode xTableNode = (XTableNode)paramXNode;
/* 34 */       xTableNode.rewind();
/*    */       
/* 36 */       if (xTableNode.next() && xTableNode.getColCount() > 0) {
/* 37 */         Object object = xTableNode.getObject(0);
/* 38 */         if (object != null) {
/* 39 */           this.text = object.toString();
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 44 */     if (this.text == null)
/*    */     {
/* 46 */       for (; paramXNode != null; paramXNode = (paramXNode.getChildCount() > 0) ? paramXNode.getChild(0) : null) {
/*    */         
/* 48 */         Object object = paramXNode.getValue();
/* 49 */         if (object != null) {
/* 50 */           this.text = object.toString();
/*    */           break;
/*    */         } 
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   public String getText() { return this.text; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\xnode\XNodeTextLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */