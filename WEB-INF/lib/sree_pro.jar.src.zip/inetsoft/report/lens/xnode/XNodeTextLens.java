package inetsoft.report.lens.xnode;

import inetsoft.report.TextLens;
import inetsoft.uql.XNode;
import inetsoft.uql.XTableNode;

public class XNodeTextLens implements TextLens {
  String text;
  
  public XNodeTextLens(XNode paramXNode) {
    if (paramXNode instanceof XTableNode) {
      XTableNode xTableNode = (XTableNode)paramXNode;
      xTableNode.rewind();
      if (xTableNode.next() && xTableNode.getColCount() > 0) {
        Object object = xTableNode.getObject(0);
        if (object != null)
          this.text = object.toString(); 
      } 
    } 
    if (this.text == null)
      for (; paramXNode != null; paramXNode = (paramXNode.getChildCount() > 0) ? paramXNode.getChild(0) : null) {
        Object object = paramXNode.getValue();
        if (object != null) {
          this.text = object.toString();
          break;
        } 
      }  
  }
  
  public String getText() { return this.text; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\xnode\XNodeTextLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */