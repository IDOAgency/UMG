/*     */ package inetsoft.report.lens.xnode;
/*     */ 
/*     */ import inetsoft.report.lens.AbstractTableLens;
/*     */ import inetsoft.report.lens.AttributeTableLens;
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.XSequenceNode;
/*     */ import inetsoft.uql.XTableNode;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XNodeTableLens
/*     */   extends AttributeTableLens
/*     */ {
/*  31 */   public XNodeTableLens(XNode paramXNode) { setNode(paramXNode); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   public void setNode(XNode paramXNode) { setTable(new Table(this, paramXNode)); }
/*     */   
/*     */   class Table extends AbstractTableLens {
/*     */     public Table(XNodeTableLens this$0, XNode param1XNode) {
/*  42 */       this.this$0 = this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 123 */       this.rows = new Vector();
/*     */       if (param1XNode instanceof XTableNode) {
/*     */         XTableNode xTableNode = (XTableNode)param1XNode;
/*     */         this.ncol = xTableNode.getColCount();
/*     */         Object[] arrayOfObject = new Object[xTableNode.getColCount()];
/*     */         for (byte b = 0; b < arrayOfObject.length; b++)
/*     */           arrayOfObject[b] = xTableNode.getName(b); 
/*     */         this.rows.addElement(arrayOfObject);
/*     */         while (xTableNode.next()) {
/*     */           arrayOfObject = new Object[xTableNode.getColCount()];
/*     */           for (byte b1 = 0; b1 < xTableNode.getColCount(); b1++)
/*     */             arrayOfObject[b1] = xTableNode.getObject(b1); 
/*     */           this.rows.addElement(arrayOfObject);
/*     */         } 
/*     */       } else {
/*     */         XSequenceNode xSequenceNode;
/*     */         if (!(param1XNode instanceof XSequenceNode)) {
/*     */           XSequenceNode xSequenceNode1 = new XSequenceNode();
/*     */           xSequenceNode1.addChild(param1XNode);
/*     */           xSequenceNode = xSequenceNode1;
/*     */         } 
/*     */         Object[] arrayOfObject = null;
/*     */         for (byte b = 0; b < xSequenceNode.getChildCount(); b++) {
/*     */           XNode xNode = xSequenceNode.getChild(b);
/*     */           if (arrayOfObject == null) {
/*     */             this.ncol = xNode.getChildCount();
/*     */             arrayOfObject = new Object[this.ncol];
/*     */             for (byte b2 = 0; b2 < arrayOfObject.length; b2++)
/*     */               arrayOfObject[b2] = xNode.getChild(b2).getName(); 
/*     */           } 
/*     */           Object[] arrayOfObject1 = new Object[this.ncol];
/*     */           for (byte b1 = 0; b1 < arrayOfObject1.length && b1 < xNode.getChildCount(); b1++) {
/*     */             XNode xNode1 = xNode.getChild(b1);
/*     */             if (xNode1 instanceof XSequenceNode && xNode1.getChildCount() > 0)
/*     */               xNode1 = xNode1.getChild(0); 
/*     */             arrayOfObject1[b1] = xNode1.getValue();
/*     */           } 
/*     */           this.rows.addElement(arrayOfObject1);
/*     */         } 
/*     */         if (arrayOfObject != null)
/*     */           this.rows.insertElementAt(arrayOfObject, 0); 
/*     */       } 
/*     */     }
/*     */     
/*     */     int ncol;
/*     */     Vector rows;
/*     */     private final XNodeTableLens this$0;
/*     */     
/*     */     public int getRowCount() { return this.rows.size(); }
/*     */     
/*     */     public int getColCount() { return this.ncol; }
/*     */     
/*     */     public int getHeaderRowCount() { return Math.min(1, this.rows.size()); }
/*     */     
/*     */     public int getHeaderColCount() { return 0; }
/*     */     
/*     */     public Object getObject(int param1Int1, int param1Int2) { return (Object[])this.rows.elementAt(param1Int1)[param1Int2]; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\xnode\XNodeTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */