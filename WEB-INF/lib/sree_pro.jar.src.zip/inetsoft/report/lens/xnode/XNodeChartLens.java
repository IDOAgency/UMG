/*     */ package inetsoft.report.lens.xnode;
/*     */ 
/*     */ import inetsoft.report.lens.AbstractChartLens;
/*     */ import inetsoft.report.lens.AttributeChartLens;
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.XSequenceNode;
/*     */ import inetsoft.uql.XTableNode;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XNodeChartLens
/*     */   extends AttributeChartLens
/*     */ {
/*  31 */   public XNodeChartLens(XNode paramXNode) { setNode(paramXNode); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   public void setNode(XNode paramXNode) { setChart(new Chart(this, paramXNode)); }
/*     */   
/*     */   class Chart extends AbstractChartLens {
/*     */     int ncol;
/*     */     int nrow;
/*     */     
/*     */     public Chart(XNodeChartLens this$0, XNode param1XNode) {
/*  45 */       this.this$0 = this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 131 */       this.rows = new Vector();
/*     */       if (param1XNode instanceof XTableNode) {
/*     */         XTableNode xTableNode = (XTableNode)param1XNode;
/*     */         this.ncol = xTableNode.getColCount();
/*     */         this.labels = new String[xTableNode.getColCount()];
/*     */         for (byte b = 0; b < this.labels.length; b++)
/*     */           this.labels[b] = xTableNode.getName(b); 
/*     */         while (xTableNode.next()) {
/*     */           Number[] arrayOfNumber = new Number[xTableNode.getColCount()];
/*     */           for (byte b1 = 0; b1 < xTableNode.getColCount(); b1++)
/*     */             arrayOfNumber[b1] = getNumber(xTableNode.getObject(b1)); 
/*     */           this.rows.addElement(arrayOfNumber);
/*     */         } 
/*     */       } else {
/*     */         XSequenceNode xSequenceNode;
/*     */         if (!(param1XNode instanceof XSequenceNode)) {
/*     */           XSequenceNode xSequenceNode1 = new XSequenceNode();
/*     */           xSequenceNode1.addChild(param1XNode);
/*     */           xSequenceNode = xSequenceNode1;
/*     */         } 
/*     */         for (byte b = 0; b < xSequenceNode.getChildCount(); b++) {
/*     */           XNode xNode = xSequenceNode.getChild(b);
/*     */           if (this.labels == null) {
/*     */             this.ncol = xNode.getChildCount();
/*     */             this.labels = new String[this.ncol];
/*     */             for (byte b2 = 0; b2 < this.labels.length; b2++)
/*     */               this.labels[b2] = xNode.getChild(b2).getName(); 
/*     */           } 
/*     */           Number[] arrayOfNumber = new Number[this.ncol];
/*     */           for (byte b1 = 0; b1 < arrayOfNumber.length && b1 < xNode.getChildCount(); b1++)
/*     */             arrayOfNumber[b1] = getNumber(xNode.getChild(b1).getValue()); 
/*     */           this.rows.addElement(arrayOfNumber);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     String[] labels;
/*     */     Vector rows;
/*     */     private final XNodeChartLens this$0;
/*     */     
/*     */     public int getDatasetCount() { return this.ncol; }
/*     */     
/*     */     public int getDatasetSize() { return this.rows.size(); }
/*     */     
/*     */     public Number getData(int param1Int1, int param1Int2) { return (Number[])this.rows.elementAt(param1Int2)[param1Int1]; }
/*     */     
/*     */     public String getLabel(int param1Int) { return Integer.toString(param1Int + 1); }
/*     */     
/*     */     public String getDatasetLabel(int param1Int) { return this.labels[param1Int]; }
/*     */     
/*     */     private Number getNumber(Object param1Object) {
/*     */       if (param1Object == null)
/*     */         return new Double(0.0D); 
/*     */       if (param1Object instanceof Number)
/*     */         return (Number)param1Object; 
/*     */       try {
/*     */         return Double.valueOf(param1Object.toString());
/*     */       } catch (Exception exception) {
/*     */         return new Double(0.0D);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\xnode\XNodeChartLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */