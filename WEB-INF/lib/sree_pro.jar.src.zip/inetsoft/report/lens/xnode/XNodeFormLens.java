/*    */ package inetsoft.report.lens.xnode;
/*    */ 
/*    */ import inetsoft.report.lens.AbstractFormLens;
/*    */ import inetsoft.report.lens.AttributeFormLens;
/*    */ import inetsoft.uql.XNode;
/*    */ import inetsoft.uql.XTableNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XNodeFormLens
/*    */   extends AttributeFormLens
/*    */ {
/* 31 */   public XNodeFormLens(XNode paramXNode) { setNode(paramXNode); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   public void setNode(XNode paramXNode) { setForm(new Form(this, paramXNode)); }
/*    */   class Form extends AbstractFormLens { String[] labels;
/*    */     
/*    */     public Form(XNodeFormLens this$0, XNode param1XNode) {
/* 42 */       this.this$0 = this$0;
/* 43 */       if (param1XNode instanceof XTableNode) {
/* 44 */         XTableNode xTableNode = (XTableNode)param1XNode;
/* 45 */         int i = xTableNode.getColCount();
/*    */         
/* 47 */         this.labels = new String[i];
/* 48 */         this.values = new Object[i];
/*    */         
/* 50 */         for (byte b = 0; b < this.labels.length; b++) {
/* 51 */           this.labels[b] = xTableNode.getName(b);
/*    */         }
/*    */         
/* 54 */         if (xTableNode.next()) {
/* 55 */           for (byte b1 = 0; b1 < i; b1++) {
/* 56 */             this.values[b1] = xTableNode.getObject(b1);
/*    */           }
/*    */         }
/*    */       } else {
/*    */         
/* 61 */         if (param1XNode instanceof inetsoft.uql.XSequenceNode && param1XNode.getChildCount() > 0)
/*    */         {
/* 63 */           param1XNode = param1XNode.getChild(0);
/*    */         }
/*    */ 
/*    */         
/* 67 */         if (param1XNode != null) {
/* 68 */           this.labels = new String[param1XNode.getChildCount()];
/* 69 */           this.values = new Object[param1XNode.getChildCount()];
/*    */           
/* 71 */           for (byte b = 0; b < param1XNode.getChildCount(); b++) {
/* 72 */             XNode xNode = param1XNode.getChild(b);
/*    */             
/* 74 */             this.labels[b] = xNode.getName();
/* 75 */             this.values[b] = xNode.getValue();
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     }
/*    */     Object[] values; private final XNodeFormLens this$0;
/*    */     
/* 82 */     public int getFieldCount() { return this.labels.length; }
/*    */ 
/*    */ 
/*    */     
/* 86 */     public Object getField(int param1Int) { return this.values[param1Int]; }
/*    */ 
/*    */ 
/*    */     
/* 90 */     public Object getLabel(int param1Int) { return this.labels[param1Int]; } }
/*    */ 
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\xnode\XNodeFormLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */