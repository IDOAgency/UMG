package inetsoft.report.lens.xnode;

import inetsoft.report.lens.AbstractFormLens;
import inetsoft.report.lens.AttributeFormLens;
import inetsoft.uql.XNode;
import inetsoft.uql.XTableNode;

public class XNodeFormLens extends AttributeFormLens {
  public XNodeFormLens(XNode paramXNode) { setNode(paramXNode); }
  
  public void setNode(XNode paramXNode) { setForm(new Form(this, paramXNode)); }
  
  class Form extends AbstractFormLens {
    String[] labels;
    
    Object[] values;
    
    private final XNodeFormLens this$0;
    
    public Form(XNodeFormLens this$0, XNode param1XNode) {
      this.this$0 = this$0;
      if (param1XNode instanceof XTableNode) {
        XTableNode xTableNode = (XTableNode)param1XNode;
        int i = xTableNode.getColCount();
        this.labels = new String[i];
        this.values = new Object[i];
        for (byte b = 0; b < this.labels.length; b++)
          this.labels[b] = xTableNode.getName(b); 
        if (xTableNode.next())
          for (byte b1 = 0; b1 < i; b1++)
            this.values[b1] = xTableNode.getObject(b1);  
      } else {
        if (param1XNode instanceof inetsoft.uql.XSequenceNode && param1XNode.getChildCount() > 0)
          param1XNode = param1XNode.getChild(0); 
        if (param1XNode != null) {
          this.labels = new String[param1XNode.getChildCount()];
          this.values = new Object[param1XNode.getChildCount()];
          for (byte b = 0; b < param1XNode.getChildCount(); b++) {
            XNode xNode = param1XNode.getChild(b);
            this.labels[b] = xNode.getName();
            this.values[b] = xNode.getValue();
          } 
        } 
      } 
    }
    
    public int getFieldCount() { return this.labels.length; }
    
    public Object getField(int param1Int) { return this.values[param1Int]; }
    
    public Object getLabel(int param1Int) { return this.labels[param1Int]; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\xnode\XNodeFormLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */