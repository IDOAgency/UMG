package inetsoft.report.lens;

import inetsoft.report.TableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

public abstract class AbstractTableLens implements TableLens {
  public abstract int getRowCount();
  
  public abstract int getColCount();
  
  public abstract Object getObject(int paramInt1, int paramInt2);
  
  public int getHeaderRowCount() { return 0; }
  
  public int getHeaderColCount() { return 0; }
  
  public int getRowHeight(int paramInt) { return -1; }
  
  public int getColWidth(int paramInt) { return -1; }
  
  public Color getRowBorderColor(int paramInt1, int paramInt2) { return Color.black; }
  
  public Color getColBorderColor(int paramInt1, int paramInt2) { return Color.black; }
  
  public int getRowBorder(int paramInt1, int paramInt2) { return 4097; }
  
  public int getColBorder(int paramInt1, int paramInt2) { return 4097; }
  
  public Insets getInsets(int paramInt1, int paramInt2) { return null; }
  
  public Dimension getSpan(int paramInt1, int paramInt2) { return null; }
  
  public int getAlignment(int paramInt1, int paramInt2) { return 17; }
  
  public Font getFont(int paramInt1, int paramInt2) { return null; }
  
  public boolean isLineWrap(int paramInt1, int paramInt2) { return true; }
  
  public Color getForeground(int paramInt1, int paramInt2) { return null; }
  
  public Color getBackground(int paramInt1, int paramInt2) { return null; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\AbstractTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */