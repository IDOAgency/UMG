package inetsoft.report.lens.swing11;

import inetsoft.report.lens.AbstractTableLens;
import inetsoft.report.lens.AttributeTableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import javax.swing.table.TableModel;

public class TableModelLens extends AttributeTableLens {
  TableModel tbl;
  
  boolean header;
  
  public TableModelLens(TableModel paramTableModel) {
    this.header = true;
    setTable(new Table(this, paramTableModel));
  }
  
  public TableModelLens(TableModel paramTableModel, boolean paramBoolean) {
    this(paramTableModel);
    this.header = paramBoolean;
  }
  
  class Table extends AbstractTableLens {
    private final TableModelLens this$0;
    
    public Table(TableModelLens this$0, TableModel param1TableModel) {
      this.this$0 = this$0;
      this$0.tbl = param1TableModel;
    }
    
    public int getRowCount() { return this.this$0.tbl.getRowCount() + (this.this$0.header ? 1 : 0); }
    
    public int getColCount() { return this.this$0.tbl.getColumnCount(); }
    
    public int getHeaderRowCount() { return this.this$0.header ? 1 : 0; }
    
    public int getHeaderColCount() { return 0; }
    
    public int getRowHeight(int param1Int) { return -1; }
    
    public int getColWidth(int param1Int) { return -1; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return 4097; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return 4097; }
    
    public Insets getInsets(int param1Int1, int param1Int2) { return null; }
    
    public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
    
    public int getAlignment(int param1Int1, int param1Int2) { return (param1Int1 == 0) ? 18 : 17; }
    
    public Font getFont(int param1Int1, int param1Int2) { return null; }
    
    public Color getBackground(int param1Int1, int param1Int2) { return (param1Int1 < this.this$0.getHeaderRowCount()) ? Color.lightGray : null; }
    
    public Object getObject(int param1Int1, int param1Int2) { return (param1Int1 < getHeaderRowCount()) ? this.this$0.tbl.getColumnName(param1Int2) : this.this$0.tbl.getValueAt(param1Int1 - getHeaderRowCount(), param1Int2); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\swing11\TableModelLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */