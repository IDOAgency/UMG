package inetsoft.report.lens.swing11;

import inetsoft.report.lens.AbstractTableLens;
import inetsoft.report.lens.AttributeTableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;

public class JTableLens extends AttributeTableLens {
  JTable tbl;
  
  public JTableLens(JTable paramJTable) { setTable(new Table(this, paramJTable)); }
  
  public void setTable(JTable paramJTable) { setTable(new Table(this, paramJTable)); }
  
  class Table extends AbstractTableLens {
    private final JTableLens this$0;
    
    public Table(JTableLens this$0, JTable param1JTable) {
      this.this$0 = this$0;
      this$0.tbl = param1JTable;
    }
    
    public int getRowCount() { return this.this$0.tbl.getRowCount() + 1; }
    
    public int getColCount() { return this.this$0.tbl.getColumnModel().getColumnCount(); }
    
    public int getHeaderRowCount() { return 1; }
    
    public int getHeaderColCount() { return 0; }
    
    public int getRowHeight(int param1Int) { return this.this$0.tbl.getRowHeight() + (this.this$0.tbl.getIntercellSpacing()).height; }
    
    public int getColWidth(int param1Int) {
      TableColumnModel tableColumnModel = this.this$0.tbl.getColumnModel();
      return tableColumnModel.getColumn(param1Int).getWidth();
    }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return this.this$0.tbl.getGridColor(); }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return this.this$0.tbl.getGridColor(); }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return this.this$0.tbl.getShowHorizontalLines() ? 4097 : 0; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return this.this$0.tbl.getShowVerticalLines() ? 4097 : 0; }
    
    public Insets getInsets(int param1Int1, int param1Int2) {
      Dimension dimension = this.this$0.tbl.getIntercellSpacing();
      return (param1Int1 > 0) ? new Insets(dimension.height / 2, dimension.width / 2, dimension.height / 2, dimension.width / 2) : null;
    }
    
    public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
    
    public int getAlignment(int param1Int1, int param1Int2) {
      int i = this.this$0.tbl.convertColumnIndexToModel(param1Int2);
      TableColumnModel tableColumnModel = this.this$0.tbl.getColumnModel();
      if (i >= tableColumnModel.getColumnCount())
        return 17; 
      TableCellRenderer tableCellRenderer = tableColumnModel.getColumn(i).getCellRenderer();
      if (tableCellRenderer instanceof JLabel)
        switch (((JLabel)tableCellRenderer).getHorizontalAlignment()) {
          case 2:
            return 17;
          case 0:
            return 18;
          case 4:
            return 20;
        }  
      return (param1Int1 == 0) ? 18 : 17;
    }
    
    public Font getFont(int param1Int1, int param1Int2) { return this.this$0.tbl.getFont(); }
    
    public Color getForeground(int param1Int1, int param1Int2) { return this.this$0.tbl.getForeground(); }
    
    public Color getBackground(int param1Int1, int param1Int2) { return (param1Int1 < this.this$0.getHeaderRowCount()) ? Color.lightGray : this.this$0.tbl.getBackground(); }
    
    public Object getObject(int param1Int1, int param1Int2) { return (param1Int1 == 0) ? this.this$0.tbl.getColumnName(param1Int2) : this.this$0.tbl.getValueAt(param1Int1 - 1, param1Int2); }
    
    public boolean isLineWrap(int param1Int1, int param1Int2) { return false; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\swing11\JTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */