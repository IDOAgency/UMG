package inetsoft.report.lens;

import inetsoft.report.TextLens;

public class DefaultTextLens implements TextLens {
  private String text;
  
  public DefaultTextLens() {}
  
  public DefaultTextLens(String paramString) { this.text = paramString; }
  
  public String getText() { return this.text; }
  
  public void setText(String paramString) { this.text = paramString; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\DefaultTextLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */