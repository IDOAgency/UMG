package inetsoft.report.lens;

import inetsoft.report.FormLens;
import java.awt.Color;
import java.awt.Font;

public abstract class AbstractFormLens implements FormLens {
  public abstract int getFieldCount();
  
  public abstract Object getField(int paramInt);
  
  public abstract Object getLabel(int paramInt);
  
  public int getFieldPerRow() { return 2; }
  
  public int getWidth(int paramInt) { return (paramInt % 2 == 0) ? -1 : 0; }
  
  public Font getLabelFont(int paramInt) { return null; }
  
  public Color getLabelForeground(int paramInt) { return null; }
  
  public Color getLabelBackground(int paramInt) { return null; }
  
  public Font getFont(int paramInt) { return null; }
  
  public Color getForeground(int paramInt) { return null; }
  
  public Color getBackground(int paramInt) { return null; }
  
  public int getUnderline() { return 4097; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\AbstractFormLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */