/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import inetsoft.report.ChartDescriptor;
/*     */ import inetsoft.report.ChartLens;
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.Painter;
/*     */ import inetsoft.report.internal.Util;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChartTable
/*     */   extends AbstractTableLens
/*     */ {
/*  36 */   public static int NO_HEADER = 0;
/*     */ 
/*     */ 
/*     */   
/*  40 */   public static int TEXT_HEADER = 1;
/*     */ 
/*     */ 
/*     */   
/*  44 */   public static int LEGEND_HEADER = 3;
/*     */   
/*     */   int opt;
/*     */   boolean row;
/*     */   ChartLens chart;
/*     */   Font headerFN;
/*     */   FontMetrics headerFM;
/*     */   
/*  52 */   public ChartTable(ChartLens paramChartLens) { this(paramChartLens, LEGEND_HEADER); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChartTable(ChartLens paramChartLens, int paramInt) {
/* 250 */     this.opt = LEGEND_HEADER;
/* 251 */     this.row = true;
/*     */     
/* 253 */     this.headerFN = new Font("Serif", 1, 10);
/* 254 */     this.headerFM = Common.getFontMetrics(this.headerFN);
/*     */     this.chart = paramChartLens;
/*     */     this.opt = paramInt;
/*     */   }
/*     */   
/*     */   public void setRowMajor(boolean paramBoolean) { this.row = paramBoolean; }
/*     */   
/*     */   public boolean isRowMajor() { return this.row; }
/*     */   
/*     */   public void setHeaderFont(Font paramFont) {
/*     */     this.headerFN = paramFont;
/*     */     this.headerFM = Common.getFontMetrics(this.headerFN);
/*     */   }
/*     */   
/*     */   public Font getHeaderFont() { return this.headerFN; }
/*     */   
/*     */   public int getRowCount() { return this.row ? (this.chart.getDatasetCount() + 1) : (this.chart.getDatasetSize() + getHeaderColCount()); }
/*     */   
/*     */   public int getColCount() { return !this.row ? (this.chart.getDatasetCount() + 1) : (this.chart.getDatasetSize() + getHeaderColCount()); }
/*     */   
/*     */   public int getHeaderRowCount() { return this.row ? 1 : (this.opt & true); }
/*     */   
/*     */   public int getHeaderColCount() { return !this.row ? 1 : (this.opt & true); }
/*     */   
/*     */   public Object getObject(int paramInt1, int paramInt2) {
/*     */     if (!this.row) {
/*     */       int i = paramInt1;
/*     */       paramInt1 = paramInt2;
/*     */       paramInt2 = i;
/*     */     } 
/*     */     if (paramInt1 == 0) {
/*     */       String str = (paramInt2 < getHeaderColCount()) ? null : this.chart.getLabel(paramInt2 - getHeaderColCount());
/*     */       if (str != null && this.opt == LEGEND_HEADER && Util.isFlatDatasetChart(this.chart)) {
/*     */         int i = paramInt2 - getHeaderColCount();
/*     */         return new HeaderPainter(this, str, this.chart.getColor(i), i);
/*     */       } 
/*     */       return str;
/*     */     } 
/*     */     if (paramInt2 < getHeaderColCount()) {
/*     */       String str = this.chart.getDatasetLabel(paramInt1 - 1);
/*     */       if (this.opt == LEGEND_HEADER && !Util.isFlatDatasetChart(this.chart))
/*     */         return new HeaderPainter(this, str, this.chart.getColor(paramInt1 - 1), paramInt1 - 1); 
/*     */       return str;
/*     */     } 
/*     */     Number number = this.chart.getData(paramInt1 - 1, paramInt2 - getHeaderColCount());
/*     */     if (this.chart.getPrecision() > 0) {
/*     */       String str = Util.toString(number, this.chart.getPrecision());
/*     */       if (number != null && str.length() != number.toString().length())
/*     */         return Double.valueOf(str); 
/*     */     } 
/*     */     return number;
/*     */   }
/*     */   
/*     */   class HeaderPainter implements Painter {
/*     */     String hd;
/*     */     Object color;
/*     */     int idx;
/*     */     private final ChartTable this$0;
/*     */     
/*     */     public HeaderPainter(ChartTable this$0, String param1String, Object param1Object, int param1Int) {
/*     */       this.this$0 = this$0;
/*     */       this.hd = (param1String == null) ? "" : param1String;
/*     */       this.color = param1Object;
/*     */       this.idx = param1Int;
/*     */     }
/*     */     
/*     */     public void paint(Graphics param1Graphics, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/*     */       Graphics graphics = param1Graphics.create(param1Int1, param1Int2, param1Int3, param1Int4);
/*     */       graphics.setColor(Color.white);
/*     */       graphics.fillRect(0, 0, param1Int3, param1Int4);
/*     */       int i = param1Int4 - 8;
/*     */       Rectangle rectangle = new Rectangle(4, 4, i, i);
/*     */       ChartDescriptor chartDescriptor = new ChartDescriptor();
/*     */       int j = (this.this$0.chart.getStyle(this.idx) != 0) ? this.this$0.chart.getStyle(this.idx) : this.this$0.chart.getStyle();
/*     */       if (this.color instanceof Image) {
/*     */         Image image = (Image)this.color;
/*     */         Shape shape = param1Graphics.getClip();
/*     */         graphics.setClip(rectangle);
/*     */         graphics.drawImage(image, rectangle.x, rectangle.y, i, i, null);
/*     */         graphics.setClip(shape);
/*     */       } else if ((j & 0x400) != 0) {
/*     */         this.idx = ((j & 0x200) != 0 && this.this$0.chart.getDatasetCount() > 1) ? (this.idx - 1) : this.idx;
/*     */         if ((j & 0x200) == 0 || ((j & 0x200) != 0 && this.idx != -1)) {
/*     */           param1Graphics.setColor((Color)this.this$0.chart.getColor(this.idx));
/*     */           Util.drawPoint(param1Graphics, rectangle.x + i / 2, rectangle.y + i / 2, i, chartDescriptor.getPointStyle(this.idx));
/*     */         } 
/*     */       } else if (j != 4106 && j != 528 && j != 20) {
/*     */         Common.fill(graphics, rectangle, this.color);
/*     */       } 
/*     */       if (this.hd != null && this.hd.length() > 0) {
/*     */         graphics.setColor(Color.black);
/*     */         graphics.setFont(this.this$0.headerFN);
/*     */         graphics.drawString(this.hd, 6 + i, (param1Int4 - this.this$0.headerFM.getHeight()) / 2 + this.this$0.headerFM.getAscent());
/*     */       } 
/*     */       graphics.dispose();
/*     */     }
/*     */     
/*     */     public Dimension getPreferredSize() { return new Dimension(this.this$0.headerFM.stringWidth(this.hd) + this.this$0.headerFM.getHeight() + 6, this.this$0.headerFM.getHeight() + 2); }
/*     */     
/*     */     public boolean isScalable() { return true; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\ChartTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */