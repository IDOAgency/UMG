package inetsoft.report.lens;

import inetsoft.report.ChartLens;
import inetsoft.report.Common;
import inetsoft.report.locale.Catalog;
import java.awt.Font;

public abstract class AbstractChartLens implements ChartLens {
  public abstract int getDatasetCount();
  
  public abstract int getDatasetSize();
  
  public abstract Number getData(int paramInt1, int paramInt2);
  
  public String getLabel(int paramInt) { return Integer.toString(paramInt); }
  
  public String getDatasetLabel(int paramInt) { return Catalog.getString("Data") + " " + paramInt; }
  
  public int getStyle() { return 5; }
  
  public Number getMaximum() { return null; }
  
  public Number getMinimum() { return null; }
  
  public Number getIncrement() { return null; }
  
  public Number getMinorIncrement() { return null; }
  
  public int getGap() { return 2; }
  
  public Object getColor(int paramInt) { return Common.getColor(paramInt); }
  
  public String getXTitle() { return null; }
  
  public String getYTitle() { return null; }
  
  public Font getTitleFont() { return null; }
  
  public int getGridStyle() { return 4113; }
  
  public int getBorderStyle() { return 0; }
  
  public boolean isShowValue() { return false; }
  
  public int getPrecision() { return 2; }
  
  public int getLegendPosition() { return 32; }
  
  public int getStyle(int paramInt) { return 1; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\AbstractChartLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */