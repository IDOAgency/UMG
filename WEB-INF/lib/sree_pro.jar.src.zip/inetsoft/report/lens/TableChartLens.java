/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import java.text.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableChartLens
/*     */   extends AttributeChartLens
/*     */ {
/*     */   TableLens table;
/*     */   final Double ZERO;
/*     */   String[] labels;
/*     */   String[] dlabels;
/*     */   String xtitle;
/*     */   String ytitle;
/*     */   Format labelfmt;
/*     */   boolean roworder;
/*     */   
/*  42 */   public TableChartLens(TableLens paramTableLens) { this(paramTableLens, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableChartLens(TableLens paramTableLens, boolean paramBoolean) {
/* 254 */     this.ZERO = new Double(0.0D);
/*     */ 
/*     */     
/* 257 */     this.labelfmt = null;
/* 258 */     this.roworder = true;
/*     */     this.table = paramTableLens;
/*     */     this.roworder = paramBoolean;
/*     */     setChart(new Chart(this));
/*     */   }
/*     */   
/*     */   public TableLens getTable() { return this.table; }
/*     */   
/*     */   public void setLabel(int paramInt, String paramString) { this.labels[paramInt] = paramString; }
/*     */   
/*     */   public void setLabels(String[] paramArrayOfString) {
/*     */     for (byte b = 0; b < paramArrayOfString.length; b++)
/*     */       setLabel(b, paramArrayOfString[b]); 
/*     */   }
/*     */   
/*     */   public void setDatasetLabel(int paramInt, String paramString) { this.dlabels[paramInt] = paramString; }
/*     */   
/*     */   public void setDatasetLabels(String[] paramArrayOfString) {
/*     */     for (byte b = 0; b < paramArrayOfString.length; b++)
/*     */       setDatasetLabel(b, paramArrayOfString[b]); 
/*     */   }
/*     */   
/*     */   public void setLabelFormat(Format paramFormat) { this.labelfmt = paramFormat; }
/*     */   
/*     */   public Format getLabelFormat() { return this.labelfmt; }
/*     */   
/*     */   public void setXTitle(String paramString) { this.xtitle = paramString; }
/*     */   
/*     */   public void setYTitle(String paramString) { this.ytitle = paramString; }
/*     */   
/*     */   class Chart extends AbstractChartLens {
/*     */     private final TableChartLens this$0;
/*     */     
/*     */     public Chart(TableChartLens this$0) {
/*     */       this.this$0 = this$0;
/*     */       this$0.labels = new String[getDatasetSize()];
/*     */       this$0.dlabels = new String[getDatasetCount()];
/*     */     }
/*     */     
/*     */     public int getDatasetCount() { return this.this$0.roworder ? (this.this$0.table.getRowCount() - this.this$0.table.getHeaderRowCount()) : (this.this$0.table.getColCount() - this.this$0.table.getHeaderColCount()); }
/*     */     
/*     */     public int getDatasetSize() { return this.this$0.roworder ? (this.this$0.table.getColCount() - this.this$0.table.getHeaderColCount()) : (this.this$0.table.getRowCount() - this.this$0.table.getHeaderRowCount()); }
/*     */     
/*     */     public Number getData(int param1Int1, int param1Int2) {
/*     */       Object object = this.this$0.roworder ? this.this$0.table.getObject(param1Int1 + this.this$0.table.getHeaderRowCount(), param1Int2 + this.this$0.table.getHeaderColCount()) : this.this$0.table.getObject(param1Int2 + this.this$0.table.getHeaderRowCount(), param1Int1 + this.this$0.table.getHeaderColCount());
/*     */       if (object instanceof Number)
/*     */         return (Number)object; 
/*     */       if (object == null)
/*     */         return null; 
/*     */       try {
/*     */         return Double.valueOf(object.toString());
/*     */       } catch (Exception exception) {
/*     */         return this.this$0.ZERO;
/*     */       } 
/*     */     }
/*     */     
/*     */     public String getLabel(int param1Int) {
/*     */       if (param1Int < this.this$0.labels.length && this.this$0.labels[param1Int] != null)
/*     */         return this.this$0.labels[param1Int]; 
/*     */       Object object = null;
/*     */       if (this.this$0.roworder && this.this$0.table.getHeaderRowCount() > 0) {
/*     */         object = this.this$0.table.getObject(0, param1Int + this.this$0.table.getHeaderColCount());
/*     */       } else if (!this.this$0.roworder && this.this$0.table.getHeaderColCount() > 0) {
/*     */         object = this.this$0.table.getObject(param1Int + this.this$0.table.getHeaderRowCount(), 0);
/*     */       } 
/*     */       try {
/*     */         if (object != null && this.this$0.labelfmt != null)
/*     */           return this.this$0.labelfmt.format(object); 
/*     */       } catch (Exception exception) {}
/*     */       return (object != null) ? object.toString() : Integer.toString(param1Int);
/*     */     }
/*     */     
/*     */     public String getDatasetLabel(int param1Int) {
/*     */       if (param1Int < this.this$0.dlabels.length && this.this$0.dlabels[param1Int] != null)
/*     */         return this.this$0.dlabels[param1Int]; 
/*     */       if (this.this$0.roworder && this.this$0.table.getHeaderColCount() > 0) {
/*     */         Object object = this.this$0.table.getObject(param1Int + this.this$0.table.getHeaderRowCount(), 0);
/*     */         return (object == null) ? Integer.toString(param1Int) : object.toString();
/*     */       } 
/*     */       if (!this.this$0.roworder && this.this$0.table.getHeaderRowCount() > 0) {
/*     */         Object object = this.this$0.table.getObject(0, param1Int + this.this$0.table.getHeaderColCount());
/*     */         return (object == null) ? Integer.toString(param1Int) : object.toString();
/*     */       } 
/*     */       return Integer.toString(param1Int);
/*     */     }
/*     */     
/*     */     public String getXTitle() { return this.this$0.xtitle; }
/*     */     
/*     */     public String getYTitle() { return this.this$0.ytitle; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\TableChartLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */