package inetsoft.report.lens;

import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Rectangle;

public class SubTableLens implements TableFilter {
  private TableLens table;
  
  private int[] rows;
  
  private int[] cols;
  
  public SubTableLens(TableLens paramTableLens, int[] paramArrayOfInt1, int[] paramArrayOfInt2) {
    this.table = paramTableLens;
    this.rows = paramArrayOfInt1;
    this.cols = paramArrayOfInt2;
    adjustHeader();
  }
  
  public SubTableLens(TableLens paramTableLens, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.table = paramTableLens;
    if (paramInt1 >= 0) {
      this.rows = new int[paramInt3];
      for (int i = 0; i < paramInt3; i++)
        this.rows[i] = i + paramInt1; 
    } 
    if (paramInt2 >= 0) {
      this.cols = new int[paramInt4];
      for (int i = 0; i < paramInt4; i++)
        this.cols[i] = i + paramInt2; 
    } 
    adjustHeader();
  }
  
  public SubTableLens(TableLens paramTableLens, Rectangle paramRectangle) { this(paramTableLens, paramRectangle.y, paramRectangle.x, paramRectangle.height, paramRectangle.width); }
  
  public TableLens getTable() { return this.table; }
  
  public void refresh() {
    if (this.table instanceof TableFilter)
      ((TableFilter)this.table).refresh(); 
  }
  
  public int getRowCount() { return (this.rows != null) ? this.rows.length : this.table.getRowCount(); }
  
  public int getColCount() { return (this.cols != null) ? this.cols.length : this.table.getColCount(); }
  
  public int getHeaderRowCount() {
    if (this.rows == null)
      return this.table.getHeaderRowCount(); 
    for (byte b = 0; b < this.rows.length && this.rows[b] < this.table.getHeaderRowCount(); b++);
    return b;
  }
  
  public int getHeaderColCount() {
    if (this.cols == null)
      return this.table.getHeaderColCount(); 
    for (byte b = 0; b < this.cols.length && this.cols[b] < this.table.getHeaderColCount(); b++);
    return b;
  }
  
  public int getRowHeight(int paramInt) { return this.table.getRowHeight(getR(paramInt)); }
  
  public int getColWidth(int paramInt) { return this.table.getColWidth(getC(paramInt)); }
  
  public Color getRowBorderColor(int paramInt1, int paramInt2) { return this.table.getRowBorderColor(getR(paramInt1), getC(paramInt2)); }
  
  public Color getColBorderColor(int paramInt1, int paramInt2) { return this.table.getColBorderColor(getR(paramInt1), getC(paramInt2)); }
  
  public int getRowBorder(int paramInt1, int paramInt2) { return this.table.getRowBorder(getR(paramInt1), getC(paramInt2)); }
  
  public int getColBorder(int paramInt1, int paramInt2) { return this.table.getColBorder(getR(paramInt1), getC(paramInt2)); }
  
  public Insets getInsets(int paramInt1, int paramInt2) { return this.table.getInsets(getR(paramInt1), getC(paramInt2)); }
  
  public Dimension getSpan(int paramInt1, int paramInt2) { return this.table.getSpan(getR(paramInt1), getC(paramInt2)); }
  
  public int getAlignment(int paramInt1, int paramInt2) { return this.table.getAlignment(getR(paramInt1), getC(paramInt2)); }
  
  public Font getFont(int paramInt1, int paramInt2) { return this.table.getFont(getR(paramInt1), getC(paramInt2)); }
  
  public boolean isLineWrap(int paramInt1, int paramInt2) { return this.table.isLineWrap(getR(paramInt1), getC(paramInt2)); }
  
  public Color getForeground(int paramInt1, int paramInt2) { return this.table.getForeground(getR(paramInt1), getC(paramInt2)); }
  
  public Color getBackground(int paramInt1, int paramInt2) { return this.table.getBackground(getR(paramInt1), getC(paramInt2)); }
  
  public Object getObject(int paramInt1, int paramInt2) { return this.table.getObject(getR(paramInt1), getC(paramInt2)); }
  
  private int getR(int paramInt) { return (this.rows == null) ? paramInt : ((paramInt < 0) ? paramInt : this.rows[paramInt]); }
  
  private int getC(int paramInt) { return (this.cols == null) ? paramInt : ((paramInt < 0) ? paramInt : this.cols[paramInt]); }
  
  private void adjustHeader() {
    int i = this.table.getHeaderRowCount();
    if (this.rows != null && i > 0 && this.rows[0] >= i) {
      int[] arrayOfInt = new int[this.rows.length + i];
      System.arraycopy(this.rows, 0, arrayOfInt, i, this.rows.length);
      for (byte b = 0; b < i; b++)
        arrayOfInt[b] = b; 
      this.rows = arrayOfInt;
    } 
    int j = this.table.getHeaderColCount();
    if (this.cols != null && j > 0 && this.cols[0] >= j) {
      int[] arrayOfInt = new int[this.cols.length + j];
      System.arraycopy(this.cols, 0, arrayOfInt, j, this.cols.length);
      for (byte b = 0; b < j; b++)
        arrayOfInt[b] = b; 
      this.cols = arrayOfInt;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\SubTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */