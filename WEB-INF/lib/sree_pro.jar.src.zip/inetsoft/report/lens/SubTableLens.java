/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import inetsoft.report.TableFilter;
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubTableLens
/*     */   implements TableFilter
/*     */ {
/*     */   private TableLens table;
/*     */   private int[] rows;
/*     */   private int[] cols;
/*     */   
/*     */   public SubTableLens(TableLens paramTableLens, int[] paramArrayOfInt1, int[] paramArrayOfInt2) {
/*  38 */     this.table = paramTableLens;
/*  39 */     this.rows = paramArrayOfInt1;
/*  40 */     this.cols = paramArrayOfInt2;
/*  41 */     adjustHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubTableLens(TableLens paramTableLens, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  54 */     this.table = paramTableLens;
/*     */     
/*  56 */     if (paramInt1 >= 0) {
/*  57 */       this.rows = new int[paramInt3];
/*  58 */       for (int i = 0; i < paramInt3; i++) {
/*  59 */         this.rows[i] = i + paramInt1;
/*     */       }
/*     */     } 
/*     */     
/*  63 */     if (paramInt2 >= 0) {
/*  64 */       this.cols = new int[paramInt4];
/*  65 */       for (int i = 0; i < paramInt4; i++) {
/*  66 */         this.cols[i] = i + paramInt2;
/*     */       }
/*     */     } 
/*     */     
/*  70 */     adjustHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public SubTableLens(TableLens paramTableLens, Rectangle paramRectangle) { this(paramTableLens, paramRectangle.y, paramRectangle.x, paramRectangle.height, paramRectangle.width); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public TableLens getTable() { return this.table; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/*  94 */     if (this.table instanceof TableFilter) {
/*  95 */       ((TableFilter)this.table).refresh();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public int getRowCount() { return (this.rows != null) ? this.rows.length : this.table.getRowCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public int getColCount() { return (this.cols != null) ? this.cols.length : this.table.getColCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeaderRowCount() {
/* 123 */     if (this.rows == null) {
/* 124 */       return this.table.getHeaderRowCount();
/*     */     }
/*     */ 
/*     */     
/* 128 */     for (byte b = 0; b < this.rows.length && this.rows[b] < this.table.getHeaderRowCount(); b++);
/*     */     
/* 130 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeaderColCount() {
/* 138 */     if (this.cols == null) {
/* 139 */       return this.table.getHeaderColCount();
/*     */     }
/*     */ 
/*     */     
/* 143 */     for (byte b = 0; b < this.cols.length && this.cols[b] < this.table.getHeaderColCount(); b++);
/*     */     
/* 145 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public int getRowHeight(int paramInt) { return this.table.getRowHeight(getR(paramInt)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 167 */   public int getColWidth(int paramInt) { return this.table.getColWidth(getC(paramInt)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 177 */   public Color getRowBorderColor(int paramInt1, int paramInt2) { return this.table.getRowBorderColor(getR(paramInt1), getC(paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 187 */   public Color getColBorderColor(int paramInt1, int paramInt2) { return this.table.getColBorderColor(getR(paramInt1), getC(paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 200 */   public int getRowBorder(int paramInt1, int paramInt2) { return this.table.getRowBorder(getR(paramInt1), getC(paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 213 */   public int getColBorder(int paramInt1, int paramInt2) { return this.table.getColBorder(getR(paramInt1), getC(paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 223 */   public Insets getInsets(int paramInt1, int paramInt2) { return this.table.getInsets(getR(paramInt1), getC(paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 237 */   public Dimension getSpan(int paramInt1, int paramInt2) { return this.table.getSpan(getR(paramInt1), getC(paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 247 */   public int getAlignment(int paramInt1, int paramInt2) { return this.table.getAlignment(getR(paramInt1), getC(paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 257 */   public Font getFont(int paramInt1, int paramInt2) { return this.table.getFont(getR(paramInt1), getC(paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 269 */   public boolean isLineWrap(int paramInt1, int paramInt2) { return this.table.isLineWrap(getR(paramInt1), getC(paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 280 */   public Color getForeground(int paramInt1, int paramInt2) { return this.table.getForeground(getR(paramInt1), getC(paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 291 */   public Color getBackground(int paramInt1, int paramInt2) { return this.table.getBackground(getR(paramInt1), getC(paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 301 */   public Object getObject(int paramInt1, int paramInt2) { return this.table.getObject(getR(paramInt1), getC(paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 308 */   private int getR(int paramInt) { return (this.rows == null) ? paramInt : ((paramInt < 0) ? paramInt : this.rows[paramInt]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 315 */   private int getC(int paramInt) { return (this.cols == null) ? paramInt : ((paramInt < 0) ? paramInt : this.cols[paramInt]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void adjustHeader() {
/* 322 */     int i = this.table.getHeaderRowCount();
/* 323 */     if (this.rows != null && i > 0 && this.rows[0] >= i) {
/* 324 */       int[] arrayOfInt = new int[this.rows.length + i];
/* 325 */       System.arraycopy(this.rows, 0, arrayOfInt, i, this.rows.length);
/* 326 */       for (byte b = 0; b < i; b++) {
/* 327 */         arrayOfInt[b] = b;
/*     */       }
/* 329 */       this.rows = arrayOfInt;
/*     */     } 
/*     */     
/* 332 */     int j = this.table.getHeaderColCount();
/* 333 */     if (this.cols != null && j > 0 && this.cols[0] >= j) {
/* 334 */       int[] arrayOfInt = new int[this.cols.length + j];
/* 335 */       System.arraycopy(this.cols, 0, arrayOfInt, j, this.cols.length);
/* 336 */       for (byte b = 0; b < j; b++) {
/* 337 */         arrayOfInt[b] = b;
/*     */       }
/* 339 */       this.cols = arrayOfInt;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\SubTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */