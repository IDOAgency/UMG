package inetsoft.report.lens;

import inetsoft.report.FormLens;
import java.awt.Color;
import java.awt.Font;
import java.util.Vector;

public class AttributeFormLens implements FormLens {
  Font labelFont;
  
  Font font;
  
  Color labelFG;
  
  Color labelBG;
  
  Color foreground;
  
  Color background;
  
  public AttributeFormLens() {}
  
  public AttributeFormLens(FormLens paramFormLens) { this.form = paramFormLens; }
  
  public void setForm(FormLens paramFormLens) { this.form = paramFormLens; }
  
  public FormLens getForm() { return this.form; }
  
  public int getFieldCount() { return this.form.getFieldCount(); }
  
  public Object getField(int paramInt) { return this.form.getField(paramInt); }
  
  public Object getLabel(int paramInt) { return this.form.getLabel(paramInt); }
  
  public int getFieldPerRow() { return (this.fieldPerRow != null) ? this.fieldPerRow.intValue() : this.form.getFieldPerRow(); }
  
  public void setFieldPerRow(int paramInt) { this.fieldPerRow = (paramInt <= 0) ? null : new Integer(paramInt); }
  
  public int getWidth(int paramInt) { return (paramInt < this.widths.size() && this.widths.elementAt(paramInt) != null) ? ((Integer)this.widths.elementAt(paramInt)).intValue() : this.form.getWidth(paramInt); }
  
  public void setWidth(int paramInt1, int paramInt2) {
    if (this.widths.size() <= paramInt1)
      this.widths.setSize(paramInt1 + 1); 
    this.widths.setElementAt(new Integer(paramInt2), paramInt1);
  }
  
  public Font getLabelFont(int paramInt) { return (this.labelFont != null) ? this.labelFont : this.form.getLabelFont(paramInt); }
  
  public void setLabelFont(Font paramFont) { this.labelFont = paramFont; }
  
  public Color getLabelForeground(int paramInt) { return (this.labelFG != null) ? this.labelFG : this.form.getLabelForeground(paramInt); }
  
  public void setLabelForeground(Color paramColor) { this.labelFG = paramColor; }
  
  public Color getLabelBackground(int paramInt) { return (this.labelBG != null) ? this.labelBG : this.form.getLabelBackground(paramInt); }
  
  public void setLabelBackground(Color paramColor) { this.labelBG = paramColor; }
  
  public Font getFont(int paramInt) { return (this.font != null) ? this.font : this.form.getFont(paramInt); }
  
  public void setFont(Font paramFont) { this.font = paramFont; }
  
  public Color getForeground(int paramInt) { return (this.foreground != null) ? this.foreground : this.form.getForeground(paramInt); }
  
  public void setForeground(Color paramColor) { this.foreground = paramColor; }
  
  public Color getBackground(int paramInt) { return (this.background != null) ? this.background : this.form.getBackground(paramInt); }
  
  public void setBackground(Color paramColor) { this.background = paramColor; }
  
  public int getUnderline() { return (this.underline != null) ? this.underline.intValue() : this.form.getUnderline(); }
  
  public void setUnderline(int paramInt) { this.underline = new Integer(paramInt); }
  
  public Object clone() throws CloneNotSupportedException { return super.clone(); }
  
  Vector widths = new Vector();
  
  Integer fieldPerRow;
  
  Integer underline = null;
  
  FormLens form;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\AttributeFormLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */