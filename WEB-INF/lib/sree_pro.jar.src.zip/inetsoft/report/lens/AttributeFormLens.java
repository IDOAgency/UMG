/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import inetsoft.report.FormLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributeFormLens
/*     */   implements FormLens
/*     */ {
/*     */   Font labelFont;
/*     */   Font font;
/*     */   Color labelFG;
/*     */   Color labelBG;
/*     */   Color foreground;
/*     */   Color background;
/*     */   
/*     */   public AttributeFormLens() {}
/*     */   
/*  40 */   public AttributeFormLens(FormLens paramFormLens) { this.form = paramFormLens; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   public void setForm(FormLens paramFormLens) { this.form = paramFormLens; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public FormLens getForm() { return this.form; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public int getFieldCount() { return this.form.getFieldCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public Object getField(int paramInt) { return this.form.getField(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public Object getLabel(int paramInt) { return this.form.getLabel(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public int getFieldPerRow() { return (this.fieldPerRow != null) ? this.fieldPerRow.intValue() : this.form.getFieldPerRow(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public void setFieldPerRow(int paramInt) { this.fieldPerRow = (paramInt <= 0) ? null : new Integer(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public int getWidth(int paramInt) { return (paramInt < this.widths.size() && this.widths.elementAt(paramInt) != null) ? ((Integer)this.widths.elementAt(paramInt)).intValue() : this.form.getWidth(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWidth(int paramInt1, int paramInt2) {
/* 118 */     if (this.widths.size() <= paramInt1) {
/* 119 */       this.widths.setSize(paramInt1 + 1);
/*     */     }
/*     */     
/* 122 */     this.widths.setElementAt(new Integer(paramInt2), paramInt1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public Font getLabelFont(int paramInt) { return (this.labelFont != null) ? this.labelFont : this.form.getLabelFont(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   public void setLabelFont(Font paramFont) { this.labelFont = paramFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   public Color getLabelForeground(int paramInt) { return (this.labelFG != null) ? this.labelFG : this.form.getLabelForeground(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public void setLabelForeground(Color paramColor) { this.labelFG = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   public Color getLabelBackground(int paramInt) { return (this.labelBG != null) ? this.labelBG : this.form.getLabelBackground(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public void setLabelBackground(Color paramColor) { this.labelBG = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public Font getFont(int paramInt) { return (this.font != null) ? this.font : this.form.getFont(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 190 */   public void setFont(Font paramFont) { this.font = paramFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 199 */   public Color getForeground(int paramInt) { return (this.foreground != null) ? this.foreground : this.form.getForeground(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 207 */   public void setForeground(Color paramColor) { this.foreground = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 216 */   public Color getBackground(int paramInt) { return (this.background != null) ? this.background : this.form.getBackground(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 224 */   public void setBackground(Color paramColor) { this.background = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 233 */   public int getUnderline() { return (this.underline != null) ? this.underline.intValue() : this.form.getUnderline(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 241 */   public void setUnderline(int paramInt) { this.underline = new Integer(paramInt); }
/*     */ 
/*     */ 
/*     */   
/* 245 */   public Object clone() throws CloneNotSupportedException { return super.clone(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 250 */   Vector widths = new Vector();
/*     */   Integer fieldPerRow;
/* 252 */   Integer underline = null;
/*     */   FormLens form;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\AttributeFormLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */