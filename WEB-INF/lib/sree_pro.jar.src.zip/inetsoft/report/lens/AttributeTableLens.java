/*      */ package inetsoft.report.lens;
/*      */ 
/*      */ import inetsoft.report.Presenter;
/*      */ import inetsoft.report.TableFilter;
/*      */ import inetsoft.report.TableLens;
/*      */ import inetsoft.report.painter.PresenterPainter;
/*      */ import java.awt.Color;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Point;
/*      */ import java.io.Serializable;
/*      */ import java.text.Format;
/*      */ import java.util.Hashtable;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class AttributeTableLens
/*      */   implements TableFilter
/*      */ {
/*      */   TableLens table;
/*      */   
/*      */   public AttributeTableLens() {}
/*      */   
/*   52 */   public AttributeTableLens(TableLens paramTableLens) { setTable(paramTableLens); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTable(TableLens paramTableLens) {
/*   60 */     this.table = paramTableLens;
/*   61 */     this.cache = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   69 */   public TableLens getTable() { return this.table; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refresh() {
/*   77 */     if (this.table instanceof TableFilter) {
/*   78 */       ((TableFilter)this.table).refresh();
/*      */     }
/*      */     
/*   81 */     if (this.cache_it) {
/*      */       
/*   83 */       this.cache = new Object[this.table.getRowCount()][this.table.getColCount()];
/*   84 */       for (byte b = 0; b < this.cache.length; b++) {
/*   85 */         for (byte b1 = 0; b1 < this.cache[b].length; b1++) {
/*   86 */           this.cache[b][b1] = getObject0(b, b1);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   97 */   public void setCached(boolean paramBoolean) { this.cache_it = paramBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  105 */   public boolean isCached() { return this.cache_it; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  114 */   public int getRowCount() { return this.table.getRowCount(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  123 */   public int getColCount() { return this.table.getColCount(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  133 */   public Object getObject(int paramInt1, int paramInt2) { return (this.cache != null && paramInt1 < this.cache.length && paramInt2 < this.cache[paramInt1].length) ? this.cache[paramInt1][paramInt2] : getObject0(paramInt1, paramInt2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject0(int paramInt1, int paramInt2) {
/*  144 */     Object object = this.table.getObject(paramInt1, paramInt2);
/*      */     
/*  146 */     if (this.check && object != null) {
/*  147 */       Presenter presenter = getPresenter(paramInt1, paramInt2);
/*  148 */       if (presenter != null && presenter.isPresenterOf(object.getClass())) {
/*  149 */         return new PresenterPainter(object, presenter);
/*      */       }
/*      */       
/*  152 */       Format format = getFormat(paramInt1, paramInt2);
/*  153 */       if (format != null) {
/*      */         try {
/*  155 */           return format.format(object);
/*  156 */         } catch (Exception exception) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  161 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  170 */   public int getHeaderRowCount() { return (this.headerRow == null) ? this.table.getHeaderRowCount() : this.headerRow.intValue(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  179 */   public void setHeaderRowCount(int paramInt) { this.headerRow = new Integer(paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  187 */   public int getHeaderColCount() { return (this.headerCol == null) ? this.table.getHeaderColCount() : this.headerCol.intValue(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  196 */   public void setHeaderColCount(int paramInt) { this.headerCol = new Integer(paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRowHeight(int paramInt) {
/*  207 */     Integer integer = (Integer)get(this.rowHeights, paramInt);
/*  208 */     if (integer != null) {
/*  209 */       return integer.intValue();
/*      */     }
/*      */     
/*  212 */     return (this.rowHeight == null) ? (this.autorow ? -1 : this.table.getRowHeight(paramInt)) : this.rowHeight.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  222 */   public void setRowAutoSize(boolean paramBoolean) { this.autorow = paramBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  232 */   public void setRowHeight(int paramInt) { this.rowHeight = (paramInt > 0) ? new Integer(paramInt) : null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  241 */   public void setRowHeight(int paramInt1, int paramInt2) { set(this.rowHeights, paramInt1, new Integer(paramInt2)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getColWidth(int paramInt) {
/*  252 */     Integer integer = (Integer)get(this.colWidth, paramInt);
/*  253 */     if (integer != null) {
/*  254 */       return integer.intValue();
/*      */     }
/*      */     
/*  257 */     return this.autocol ? -1 : this.table.getColWidth(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  266 */   public void setColAutoSize(boolean paramBoolean) { this.autocol = paramBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  278 */   public void setColWidth(int paramInt1, int paramInt2) { set(this.colWidth, paramInt1, new Integer(paramInt2)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getRowBorderColor(int paramInt1, int paramInt2) {
/*  288 */     Color color = (Color)get(this.rowborderCmap, paramInt1 + 1, paramInt2 + 1);
/*  289 */     if (color != null) {
/*  290 */       return color;
/*      */     }
/*      */     
/*  293 */     color = (Color)get(this.rowborderC, paramInt1 + 1);
/*      */     
/*  295 */     if (color != null) {
/*  296 */       return color;
/*      */     }
/*      */     
/*  299 */     color = this.tableRowBorderColor;
/*  300 */     return (color == null) ? this.table.getRowBorderColor(paramInt1, paramInt2) : color;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  308 */   public void setRowBorderColor(Color paramColor) { this.tableRowBorderColor = paramColor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  317 */   public void setRowBorderColor(int paramInt, Color paramColor) { set(this.rowborderC, paramInt + 1, paramColor); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  328 */   public void setRowBorderColor(int paramInt1, int paramInt2, Color paramColor) { set(this.rowborderCmap, paramInt1 + 1, paramInt2 + 1, paramColor); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getColBorderColor(int paramInt1, int paramInt2) {
/*  338 */     Color color = (Color)get(this.colborderCmap, paramInt1 + 1, paramInt2 + 1);
/*  339 */     if (color != null) {
/*  340 */       return color;
/*      */     }
/*      */     
/*  343 */     color = (Color)get(this.colborderC, paramInt2 + 1);
/*      */     
/*  345 */     if (color != null) {
/*  346 */       return color;
/*      */     }
/*      */     
/*  349 */     color = this.tableColBorderColor;
/*      */     
/*  351 */     return (color == null) ? this.table.getColBorderColor(paramInt1, paramInt2) : color;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  359 */   public void setColBorderColor(Color paramColor) { this.tableColBorderColor = paramColor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  368 */   public void setColBorderColor(int paramInt, Color paramColor) { set(this.colborderC, paramInt + 1, paramColor); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  378 */   public void setColBorderColor(int paramInt1, int paramInt2, Color paramColor) { set(this.colborderCmap, paramInt1 + 1, paramInt2 + 1, paramColor); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRowBorder(int paramInt1, int paramInt2) {
/*  391 */     Integer integer = (Integer)get(this.rowbordermap, paramInt1 + 1, paramInt2 + 1);
/*  392 */     if (integer != null) {
/*  393 */       return integer.intValue();
/*      */     }
/*      */     
/*  396 */     integer = (Integer)get(this.rowborder, paramInt1 + 1);
/*      */     
/*  398 */     if (integer != null) {
/*  399 */       return integer.intValue();
/*      */     }
/*      */     
/*  402 */     integer = this.tableRowBorder;
/*      */     
/*  404 */     return (integer == null) ? this.table.getRowBorder(paramInt1, paramInt2) : integer.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  412 */   public void setRowBorder(int paramInt) { this.tableRowBorder = new Integer(paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  421 */   public void setRowBorder(int paramInt1, int paramInt2) { set(this.rowborder, paramInt1 + 1, new Integer(paramInt2)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  430 */   public void setRowBorder(int paramInt1, int paramInt2, int paramInt3) { set(this.rowbordermap, paramInt1 + 1, paramInt2 + 1, new Integer(paramInt3)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getColBorder(int paramInt1, int paramInt2) {
/*  443 */     Integer integer = (Integer)get(this.colbordermap, paramInt1 + 1, paramInt2 + 1);
/*  444 */     if (integer != null) {
/*  445 */       return integer.intValue();
/*      */     }
/*      */     
/*  448 */     integer = (Integer)get(this.colborder, paramInt2 + 1);
/*      */     
/*  450 */     if (integer != null) {
/*  451 */       return integer.intValue();
/*      */     }
/*      */     
/*  454 */     integer = this.tableColBorder;
/*      */     
/*  456 */     return (integer == null) ? this.table.getColBorder(paramInt1, paramInt2) : integer.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  464 */   public void setColBorder(int paramInt) { this.tableColBorder = new Integer(paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  473 */   public void setColBorder(int paramInt1, int paramInt2) { set(this.colborder, paramInt1 + 1, new Integer(paramInt2)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  483 */   public void setColBorder(int paramInt1, int paramInt2, int paramInt3) { set(this.colbordermap, paramInt1 + 1, paramInt2 + 1, new Integer(paramInt3)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Insets getInsets(int paramInt1, int paramInt2) {
/*  493 */     Insets insets = (Insets)get(this.insetsmap, paramInt1, paramInt2);
/*  494 */     if (insets != null) {
/*  495 */       return insets;
/*      */     }
/*      */     
/*  498 */     insets = (Insets)get(this.rowinsets, paramInt1);
/*      */     
/*  500 */     if (insets != null) {
/*  501 */       return insets;
/*      */     }
/*      */     
/*  504 */     insets = (Insets)get(this.colinsets, paramInt2);
/*      */     
/*  506 */     if (insets != null) {
/*  507 */       return insets;
/*      */     }
/*      */     
/*  510 */     insets = this.tableGap;
/*      */     
/*  512 */     return (insets == null) ? this.table.getInsets(paramInt1, paramInt2) : insets;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  520 */   public void setInsets(Insets paramInsets) { this.tableGap = paramInsets; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  530 */   public void setInsets(int paramInt1, int paramInt2, Insets paramInsets) { set(this.insetsmap, paramInt1, paramInt2, paramInsets); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  539 */   public void setRowInsets(int paramInt, Insets paramInsets) { set(this.rowinsets, paramInt, paramInsets); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  548 */   public void setColInsets(int paramInt, Insets paramInsets) { set(this.colinsets, paramInt, paramInsets); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Dimension getSpan(int paramInt1, int paramInt2) {
/*  562 */     Dimension dimension = (Dimension)get(this.spanmap, paramInt1, paramInt2);
/*  563 */     return (dimension == null) ? this.table.getSpan(paramInt1, paramInt2) : dimension;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  573 */   public void setSpan(int paramInt1, int paramInt2, Dimension paramDimension) { set(this.spanmap, paramInt1, paramInt2, paramDimension); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAlignment(int paramInt1, int paramInt2) {
/*  583 */     Integer integer = (Integer)get(this.alignmap, paramInt1, paramInt2);
/*      */     
/*  585 */     if (integer != null) {
/*  586 */       return integer.intValue();
/*      */     }
/*      */     
/*  589 */     integer = (Integer)get(this.rowalign, paramInt1);
/*      */     
/*  591 */     if (integer != null) {
/*  592 */       return integer.intValue();
/*      */     }
/*      */     
/*  595 */     integer = (Integer)get(this.colalign, paramInt2);
/*      */     
/*  597 */     if (integer != null) {
/*  598 */       return integer.intValue();
/*      */     }
/*      */     
/*  601 */     integer = this.tableAlign;
/*      */     
/*  603 */     return (integer == null) ? this.table.getAlignment(paramInt1, paramInt2) : integer.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  611 */   public void setAlignment(int paramInt) { this.tableAlign = new Integer(paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  621 */   public void setAlignment(int paramInt1, int paramInt2, int paramInt3) { set(this.alignmap, paramInt1, paramInt2, new Integer(paramInt3)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  630 */   public void setRowAlignment(int paramInt1, int paramInt2) { set(this.rowalign, paramInt1, new Integer(paramInt2)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  639 */   public void setColAlignment(int paramInt1, int paramInt2) { set(this.colalign, paramInt1, new Integer(paramInt2)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getFont(int paramInt1, int paramInt2) {
/*  649 */     Font font = (Font)get(this.fontmap, paramInt1, paramInt2);
/*  650 */     if (font != null) {
/*  651 */       return font;
/*      */     }
/*      */     
/*  654 */     font = (Font)get(this.rowfont, paramInt1);
/*      */     
/*  656 */     if (font != null) {
/*  657 */       return font;
/*      */     }
/*      */     
/*  660 */     font = (Font)get(this.colfont, paramInt2);
/*      */     
/*  662 */     if (font != null) {
/*  663 */       return font;
/*      */     }
/*      */     
/*  666 */     font = this.tableFont;
/*      */     
/*  668 */     return (font == null) ? this.table.getFont(paramInt1, paramInt2) : font;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  678 */   public void setFont(int paramInt1, int paramInt2, Font paramFont) { set(this.fontmap, paramInt1, paramInt2, paramFont); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  686 */   public void setFont(Font paramFont) { this.tableFont = paramFont; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  695 */   public void setRowFont(int paramInt, Font paramFont) { set(this.rowfont, paramInt, paramFont); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  704 */   public void setColFont(int paramInt, Font paramFont) { set(this.colfont, paramInt, paramFont); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLineWrap(int paramInt1, int paramInt2) {
/*  716 */     Boolean bool = (Boolean)get(this.wrapmap, paramInt1, paramInt2);
/*      */     
/*  718 */     if (bool != null) {
/*  719 */       return bool.booleanValue();
/*      */     }
/*      */     
/*  722 */     bool = (Boolean)get(this.rowwrap, paramInt1);
/*      */     
/*  724 */     if (bool != null) {
/*  725 */       return bool.booleanValue();
/*      */     }
/*      */     
/*  728 */     bool = (Boolean)get(this.colwrap, paramInt2);
/*      */     
/*  730 */     if (bool != null) {
/*  731 */       return bool.booleanValue();
/*      */     }
/*      */     
/*  734 */     bool = this.tablewrap;
/*      */     
/*  736 */     return (bool == null) ? this.table.isLineWrap(paramInt1, paramInt2) : bool.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  744 */   public void setLineWrap(boolean paramBoolean) { this.tablewrap = new Boolean(paramBoolean); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  754 */   public void setLineWrap(int paramInt1, int paramInt2, boolean paramBoolean) { set(this.wrapmap, paramInt1, paramInt2, new Boolean(paramBoolean)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  763 */   public void setRowLineWrap(int paramInt, boolean paramBoolean) { set(this.rowwrap, paramInt, new Boolean(paramBoolean)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  772 */   public void setColLineWrap(int paramInt, boolean paramBoolean) { set(this.colwrap, paramInt, new Boolean(paramBoolean)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getForeground(int paramInt1, int paramInt2) {
/*  783 */     Color color = (Color)get(this.foregroundmap, paramInt1, paramInt2);
/*      */     
/*  785 */     if (color != null) {
/*  786 */       return color;
/*      */     }
/*      */     
/*  789 */     color = (Color)get(this.rowforeground, paramInt1);
/*      */     
/*  791 */     if (color != null) {
/*  792 */       return color;
/*      */     }
/*      */     
/*  795 */     color = (Color)get(this.colforeground, paramInt2);
/*      */     
/*  797 */     return (color == null) ? this.table.getForeground(paramInt1, paramInt2) : color;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  807 */   public void setForeground(int paramInt1, int paramInt2, Color paramColor) { set(this.foregroundmap, paramInt1, paramInt2, paramColor); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  816 */   public void setRowForeground(int paramInt, Color paramColor) { set(this.rowforeground, paramInt, paramColor); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  825 */   public void setColForeground(int paramInt, Color paramColor) { set(this.colforeground, paramInt, paramColor); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getBackground(int paramInt1, int paramInt2) {
/*  836 */     Color color = (Color)get(this.backgroundmap, paramInt1, paramInt2);
/*  837 */     if (color != null) {
/*  838 */       return color;
/*      */     }
/*      */     
/*  841 */     color = (Color)get(this.rowbackground, paramInt1);
/*      */     
/*  843 */     if (color != null) {
/*  844 */       return color;
/*      */     }
/*      */     
/*  847 */     color = (Color)get(this.colbackground, paramInt2);
/*      */     
/*  849 */     return (color == null) ? this.table.getBackground(paramInt1, paramInt2) : color;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  859 */   public void setBackground(int paramInt1, int paramInt2, Color paramColor) { set(this.backgroundmap, paramInt1, paramInt2, paramColor); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  868 */   public void setRowBackground(int paramInt, Color paramColor) { set(this.rowbackground, paramInt, paramColor); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  877 */   public void setColBackground(int paramInt, Color paramColor) { set(this.colbackground, paramInt, paramColor); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Presenter getPresenter(int paramInt1, int paramInt2) {
/*  887 */     Presenter presenter = (Presenter)get(this.rpresenters, paramInt1);
/*  888 */     return (presenter == null) ? getPresenter(paramInt2) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  897 */   public Presenter getPresenter(int paramInt) { return (Presenter)get(this.presenters, paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPresenter(String paramString, Presenter paramPresenter) {
/*  908 */     int i = findColumn(paramString);
/*  909 */     if (i >= 0) {
/*  910 */       setPresenter(i, paramPresenter);
/*      */     } else {
/*      */       
/*  913 */       throw new NoSuchElementException(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPresenter(int paramInt, Presenter paramPresenter) {
/*  924 */     set(this.presenters, paramInt, paramPresenter);
/*  925 */     this.check = true;
/*  926 */     this.cache = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowPresenter(int paramInt, Presenter paramPresenter) {
/*  937 */     set(this.rpresenters, paramInt, paramPresenter);
/*  938 */     this.check = true;
/*  939 */     this.cache = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Format getFormat(int paramInt1, int paramInt2) {
/*  949 */     Format format = (Format)get(this.rformats, paramInt1);
/*  950 */     return (format == null) ? getFormat(paramInt2) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  959 */   public Format getFormat(int paramInt) { return (Format)get(this.formats, paramInt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFormat(String paramString, Format paramFormat) {
/*  971 */     int i = findColumn(paramString);
/*  972 */     if (i >= 0) {
/*  973 */       setFormat(i, paramFormat);
/*      */     } else {
/*      */       
/*  976 */       throw new NoSuchElementException(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFormat(int paramInt, Format paramFormat) {
/*  987 */     set(this.formats, paramInt, paramFormat);
/*  988 */     this.check = true;
/*  989 */     this.cache = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowFormat(int paramInt, Format paramFormat) {
/*  999 */     set(this.rformats, paramInt, paramFormat);
/* 1000 */     this.check = true;
/* 1001 */     this.cache = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String paramString) {
/* 1009 */     if (getHeaderRowCount() > 0) {
/* 1010 */       for (byte b = 0; b < getColCount(); b++) {
/* 1011 */         if (paramString.equals(getObject(0, b))) {
/* 1012 */           return b;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 1017 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object get(VectorHolder paramVectorHolder, int paramInt) {
/* 1028 */     if (paramVectorHolder.vector == null || paramVectorHolder.vector.size() <= paramInt) {
/* 1029 */       return null;
/*      */     }
/*      */     
/* 1032 */     return paramVectorHolder.vector.elementAt(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void set(VectorHolder paramVectorHolder, int paramInt, Object paramObject) {
/* 1043 */     if (paramObject == null && (paramVectorHolder.vector == null || paramVectorHolder.vector.size() <= paramInt)) {
/*      */       return;
/*      */     }
/* 1046 */     if (paramVectorHolder.vector == null) {
/* 1047 */       paramVectorHolder.vector = new Vector();
/*      */     }
/*      */     
/* 1050 */     if (paramVectorHolder.vector.size() <= paramInt) {
/* 1051 */       paramVectorHolder.vector.setSize(paramInt + 1);
/*      */     }
/*      */     
/* 1054 */     paramVectorHolder.vector.setElementAt(paramObject, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1064 */   private Object get(HashtableHolder paramHashtableHolder, int paramInt1, int paramInt2) { return (paramHashtableHolder.map != null && paramHashtableHolder.map.size() > 0) ? paramHashtableHolder.map.get(new Point(paramInt2, paramInt1)) : null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void set(HashtableHolder paramHashtableHolder, int paramInt1, int paramInt2, Object paramObject) {
/* 1076 */     if (paramObject == null) {
/* 1077 */       if (paramHashtableHolder.map != null) {
/* 1078 */         paramHashtableHolder.map.remove(new Point(paramInt2, paramInt1));
/*      */       }
/*      */     } else {
/*      */       
/* 1082 */       if (paramHashtableHolder.map == null) {
/* 1083 */         paramHashtableHolder.map = new Hashtable();
/*      */       }
/*      */       
/* 1086 */       paramHashtableHolder.map.put(new Point(paramInt2, paramInt1), paramObject);
/*      */     } 
/*      */   }
/*      */   
/*      */   static class VectorHolder
/*      */     implements Serializable {
/*      */     Vector vector;
/*      */   }
/*      */   
/*      */   static class HashtableHolder
/*      */     implements Serializable {
/*      */     Hashtable map;
/*      */   }
/*      */   boolean cache_it = true;
/*      */   Object[][] cache;
/*      */   boolean autorow;
/*      */   boolean autocol;
/* 1103 */   VectorHolder colWidth = new VectorHolder();
/* 1104 */   Integer headerRow = null;
/* 1105 */   Integer headerCol = null;
/* 1106 */   VectorHolder rowforeground = new VectorHolder();
/* 1107 */   VectorHolder rowbackground = new VectorHolder();
/* 1108 */   VectorHolder colforeground = new VectorHolder();
/* 1109 */   VectorHolder colbackground = new VectorHolder();
/* 1110 */   HashtableHolder foregroundmap = new HashtableHolder();
/* 1111 */   HashtableHolder backgroundmap = new HashtableHolder();
/* 1112 */   VectorHolder rowborder = new VectorHolder();
/* 1113 */   VectorHolder colborder = new VectorHolder();
/* 1114 */   VectorHolder rowborderC = new VectorHolder();
/* 1115 */   VectorHolder colborderC = new VectorHolder();
/* 1116 */   HashtableHolder rowbordermap = new HashtableHolder();
/* 1117 */   HashtableHolder colbordermap = new HashtableHolder();
/* 1118 */   HashtableHolder rowborderCmap = new HashtableHolder();
/* 1119 */   HashtableHolder colborderCmap = new HashtableHolder();
/* 1120 */   VectorHolder rowalign = new VectorHolder();
/* 1121 */   VectorHolder colalign = new VectorHolder();
/* 1122 */   HashtableHolder alignmap = new HashtableHolder();
/* 1123 */   Font tableFont = null;
/* 1124 */   VectorHolder rowfont = new VectorHolder();
/* 1125 */   VectorHolder colfont = new VectorHolder();
/* 1126 */   HashtableHolder fontmap = new HashtableHolder();
/* 1127 */   Boolean tablewrap = null;
/* 1128 */   VectorHolder rowwrap = new VectorHolder();
/* 1129 */   VectorHolder colwrap = new VectorHolder();
/* 1130 */   HashtableHolder wrapmap = new HashtableHolder();
/* 1131 */   HashtableHolder spanmap = new HashtableHolder();
/* 1132 */   VectorHolder rowinsets = new VectorHolder();
/* 1133 */   VectorHolder colinsets = new VectorHolder();
/* 1134 */   HashtableHolder insetsmap = new HashtableHolder();
/* 1135 */   VectorHolder presenters = new VectorHolder();
/* 1136 */   VectorHolder formats = new VectorHolder();
/*      */   boolean check = false;
/* 1138 */   Integer rowHeight = null;
/* 1139 */   VectorHolder rowHeights = new VectorHolder();
/* 1140 */   VectorHolder rpresenters = new VectorHolder();
/* 1141 */   VectorHolder rformats = new VectorHolder();
/* 1142 */   Color tableRowBorderColor = null;
/* 1143 */   Color tableColBorderColor = null;
/* 1144 */   Integer tableRowBorder = null;
/* 1145 */   Integer tableColBorder = null;
/* 1146 */   Insets tableGap = null;
/* 1147 */   Integer tableAlign = null;
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\AttributeTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */