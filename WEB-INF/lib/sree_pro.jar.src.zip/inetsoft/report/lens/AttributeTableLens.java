package inetsoft.report.lens;

import inetsoft.report.Presenter;
import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import inetsoft.report.painter.PresenterPainter;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Point;
import java.io.Serializable;
import java.text.Format;
import java.util.Hashtable;
import java.util.NoSuchElementException;
import java.util.Vector;

public class AttributeTableLens implements TableFilter {
  TableLens table;
  
  public AttributeTableLens() {}
  
  public AttributeTableLens(TableLens paramTableLens) { setTable(paramTableLens); }
  
  public void setTable(TableLens paramTableLens) {
    this.table = paramTableLens;
    this.cache = null;
  }
  
  public TableLens getTable() { return this.table; }
  
  public void refresh() {
    if (this.table instanceof TableFilter)
      ((TableFilter)this.table).refresh(); 
    if (this.cache_it) {
      this.cache = new Object[this.table.getRowCount()][this.table.getColCount()];
      for (byte b = 0; b < this.cache.length; b++) {
        for (byte b1 = 0; b1 < this.cache[b].length; b1++)
          this.cache[b][b1] = getObject0(b, b1); 
      } 
    } 
  }
  
  public void setCached(boolean paramBoolean) { this.cache_it = paramBoolean; }
  
  public boolean isCached() { return this.cache_it; }
  
  public int getRowCount() { return this.table.getRowCount(); }
  
  public int getColCount() { return this.table.getColCount(); }
  
  public Object getObject(int paramInt1, int paramInt2) { return (this.cache != null && paramInt1 < this.cache.length && paramInt2 < this.cache[paramInt1].length) ? this.cache[paramInt1][paramInt2] : getObject0(paramInt1, paramInt2); }
  
  public Object getObject0(int paramInt1, int paramInt2) {
    Object object = this.table.getObject(paramInt1, paramInt2);
    if (this.check && object != null) {
      Presenter presenter = getPresenter(paramInt1, paramInt2);
      if (presenter != null && presenter.isPresenterOf(object.getClass()))
        return new PresenterPainter(object, presenter); 
      Format format = getFormat(paramInt1, paramInt2);
      if (format != null)
        try {
          return format.format(object);
        } catch (Exception exception) {} 
    } 
    return object;
  }
  
  public int getHeaderRowCount() { return (this.headerRow == null) ? this.table.getHeaderRowCount() : this.headerRow.intValue(); }
  
  public void setHeaderRowCount(int paramInt) { this.headerRow = new Integer(paramInt); }
  
  public int getHeaderColCount() { return (this.headerCol == null) ? this.table.getHeaderColCount() : this.headerCol.intValue(); }
  
  public void setHeaderColCount(int paramInt) { this.headerCol = new Integer(paramInt); }
  
  public int getRowHeight(int paramInt) {
    Integer integer = (Integer)get(this.rowHeights, paramInt);
    if (integer != null)
      return integer.intValue(); 
    return (this.rowHeight == null) ? (this.autorow ? -1 : this.table.getRowHeight(paramInt)) : this.rowHeight.intValue();
  }
  
  public void setRowAutoSize(boolean paramBoolean) { this.autorow = paramBoolean; }
  
  public void setRowHeight(int paramInt) { this.rowHeight = (paramInt > 0) ? new Integer(paramInt) : null; }
  
  public void setRowHeight(int paramInt1, int paramInt2) { set(this.rowHeights, paramInt1, new Integer(paramInt2)); }
  
  public int getColWidth(int paramInt) {
    Integer integer = (Integer)get(this.colWidth, paramInt);
    if (integer != null)
      return integer.intValue(); 
    return this.autocol ? -1 : this.table.getColWidth(paramInt);
  }
  
  public void setColAutoSize(boolean paramBoolean) { this.autocol = paramBoolean; }
  
  public void setColWidth(int paramInt1, int paramInt2) { set(this.colWidth, paramInt1, new Integer(paramInt2)); }
  
  public Color getRowBorderColor(int paramInt1, int paramInt2) {
    Color color = (Color)get(this.rowborderCmap, paramInt1 + 1, paramInt2 + 1);
    if (color != null)
      return color; 
    color = (Color)get(this.rowborderC, paramInt1 + 1);
    if (color != null)
      return color; 
    color = this.tableRowBorderColor;
    return (color == null) ? this.table.getRowBorderColor(paramInt1, paramInt2) : color;
  }
  
  public void setRowBorderColor(Color paramColor) { this.tableRowBorderColor = paramColor; }
  
  public void setRowBorderColor(int paramInt, Color paramColor) { set(this.rowborderC, paramInt + 1, paramColor); }
  
  public void setRowBorderColor(int paramInt1, int paramInt2, Color paramColor) { set(this.rowborderCmap, paramInt1 + 1, paramInt2 + 1, paramColor); }
  
  public Color getColBorderColor(int paramInt1, int paramInt2) {
    Color color = (Color)get(this.colborderCmap, paramInt1 + 1, paramInt2 + 1);
    if (color != null)
      return color; 
    color = (Color)get(this.colborderC, paramInt2 + 1);
    if (color != null)
      return color; 
    color = this.tableColBorderColor;
    return (color == null) ? this.table.getColBorderColor(paramInt1, paramInt2) : color;
  }
  
  public void setColBorderColor(Color paramColor) { this.tableColBorderColor = paramColor; }
  
  public void setColBorderColor(int paramInt, Color paramColor) { set(this.colborderC, paramInt + 1, paramColor); }
  
  public void setColBorderColor(int paramInt1, int paramInt2, Color paramColor) { set(this.colborderCmap, paramInt1 + 1, paramInt2 + 1, paramColor); }
  
  public int getRowBorder(int paramInt1, int paramInt2) {
    Integer integer = (Integer)get(this.rowbordermap, paramInt1 + 1, paramInt2 + 1);
    if (integer != null)
      return integer.intValue(); 
    integer = (Integer)get(this.rowborder, paramInt1 + 1);
    if (integer != null)
      return integer.intValue(); 
    integer = this.tableRowBorder;
    return (integer == null) ? this.table.getRowBorder(paramInt1, paramInt2) : integer.intValue();
  }
  
  public void setRowBorder(int paramInt) { this.tableRowBorder = new Integer(paramInt); }
  
  public void setRowBorder(int paramInt1, int paramInt2) { set(this.rowborder, paramInt1 + 1, new Integer(paramInt2)); }
  
  public void setRowBorder(int paramInt1, int paramInt2, int paramInt3) { set(this.rowbordermap, paramInt1 + 1, paramInt2 + 1, new Integer(paramInt3)); }
  
  public int getColBorder(int paramInt1, int paramInt2) {
    Integer integer = (Integer)get(this.colbordermap, paramInt1 + 1, paramInt2 + 1);
    if (integer != null)
      return integer.intValue(); 
    integer = (Integer)get(this.colborder, paramInt2 + 1);
    if (integer != null)
      return integer.intValue(); 
    integer = this.tableColBorder;
    return (integer == null) ? this.table.getColBorder(paramInt1, paramInt2) : integer.intValue();
  }
  
  public void setColBorder(int paramInt) { this.tableColBorder = new Integer(paramInt); }
  
  public void setColBorder(int paramInt1, int paramInt2) { set(this.colborder, paramInt1 + 1, new Integer(paramInt2)); }
  
  public void setColBorder(int paramInt1, int paramInt2, int paramInt3) { set(this.colbordermap, paramInt1 + 1, paramInt2 + 1, new Integer(paramInt3)); }
  
  public Insets getInsets(int paramInt1, int paramInt2) {
    Insets insets = (Insets)get(this.insetsmap, paramInt1, paramInt2);
    if (insets != null)
      return insets; 
    insets = (Insets)get(this.rowinsets, paramInt1);
    if (insets != null)
      return insets; 
    insets = (Insets)get(this.colinsets, paramInt2);
    if (insets != null)
      return insets; 
    insets = this.tableGap;
    return (insets == null) ? this.table.getInsets(paramInt1, paramInt2) : insets;
  }
  
  public void setInsets(Insets paramInsets) { this.tableGap = paramInsets; }
  
  public void setInsets(int paramInt1, int paramInt2, Insets paramInsets) { set(this.insetsmap, paramInt1, paramInt2, paramInsets); }
  
  public void setRowInsets(int paramInt, Insets paramInsets) { set(this.rowinsets, paramInt, paramInsets); }
  
  public void setColInsets(int paramInt, Insets paramInsets) { set(this.colinsets, paramInt, paramInsets); }
  
  public Dimension getSpan(int paramInt1, int paramInt2) {
    Dimension dimension = (Dimension)get(this.spanmap, paramInt1, paramInt2);
    return (dimension == null) ? this.table.getSpan(paramInt1, paramInt2) : dimension;
  }
  
  public void setSpan(int paramInt1, int paramInt2, Dimension paramDimension) { set(this.spanmap, paramInt1, paramInt2, paramDimension); }
  
  public int getAlignment(int paramInt1, int paramInt2) {
    Integer integer = (Integer)get(this.alignmap, paramInt1, paramInt2);
    if (integer != null)
      return integer.intValue(); 
    integer = (Integer)get(this.rowalign, paramInt1);
    if (integer != null)
      return integer.intValue(); 
    integer = (Integer)get(this.colalign, paramInt2);
    if (integer != null)
      return integer.intValue(); 
    integer = this.tableAlign;
    return (integer == null) ? this.table.getAlignment(paramInt1, paramInt2) : integer.intValue();
  }
  
  public void setAlignment(int paramInt) { this.tableAlign = new Integer(paramInt); }
  
  public void setAlignment(int paramInt1, int paramInt2, int paramInt3) { set(this.alignmap, paramInt1, paramInt2, new Integer(paramInt3)); }
  
  public void setRowAlignment(int paramInt1, int paramInt2) { set(this.rowalign, paramInt1, new Integer(paramInt2)); }
  
  public void setColAlignment(int paramInt1, int paramInt2) { set(this.colalign, paramInt1, new Integer(paramInt2)); }
  
  public Font getFont(int paramInt1, int paramInt2) {
    Font font = (Font)get(this.fontmap, paramInt1, paramInt2);
    if (font != null)
      return font; 
    font = (Font)get(this.rowfont, paramInt1);
    if (font != null)
      return font; 
    font = (Font)get(this.colfont, paramInt2);
    if (font != null)
      return font; 
    font = this.tableFont;
    return (font == null) ? this.table.getFont(paramInt1, paramInt2) : font;
  }
  
  public void setFont(int paramInt1, int paramInt2, Font paramFont) { set(this.fontmap, paramInt1, paramInt2, paramFont); }
  
  public void setFont(Font paramFont) { this.tableFont = paramFont; }
  
  public void setRowFont(int paramInt, Font paramFont) { set(this.rowfont, paramInt, paramFont); }
  
  public void setColFont(int paramInt, Font paramFont) { set(this.colfont, paramInt, paramFont); }
  
  public boolean isLineWrap(int paramInt1, int paramInt2) {
    Boolean bool = (Boolean)get(this.wrapmap, paramInt1, paramInt2);
    if (bool != null)
      return bool.booleanValue(); 
    bool = (Boolean)get(this.rowwrap, paramInt1);
    if (bool != null)
      return bool.booleanValue(); 
    bool = (Boolean)get(this.colwrap, paramInt2);
    if (bool != null)
      return bool.booleanValue(); 
    bool = this.tablewrap;
    return (bool == null) ? this.table.isLineWrap(paramInt1, paramInt2) : bool.booleanValue();
  }
  
  public void setLineWrap(boolean paramBoolean) { this.tablewrap = new Boolean(paramBoolean); }
  
  public void setLineWrap(int paramInt1, int paramInt2, boolean paramBoolean) { set(this.wrapmap, paramInt1, paramInt2, new Boolean(paramBoolean)); }
  
  public void setRowLineWrap(int paramInt, boolean paramBoolean) { set(this.rowwrap, paramInt, new Boolean(paramBoolean)); }
  
  public void setColLineWrap(int paramInt, boolean paramBoolean) { set(this.colwrap, paramInt, new Boolean(paramBoolean)); }
  
  public Color getForeground(int paramInt1, int paramInt2) {
    Color color = (Color)get(this.foregroundmap, paramInt1, paramInt2);
    if (color != null)
      return color; 
    color = (Color)get(this.rowforeground, paramInt1);
    if (color != null)
      return color; 
    color = (Color)get(this.colforeground, paramInt2);
    return (color == null) ? this.table.getForeground(paramInt1, paramInt2) : color;
  }
  
  public void setForeground(int paramInt1, int paramInt2, Color paramColor) { set(this.foregroundmap, paramInt1, paramInt2, paramColor); }
  
  public void setRowForeground(int paramInt, Color paramColor) { set(this.rowforeground, paramInt, paramColor); }
  
  public void setColForeground(int paramInt, Color paramColor) { set(this.colforeground, paramInt, paramColor); }
  
  public Color getBackground(int paramInt1, int paramInt2) {
    Color color = (Color)get(this.backgroundmap, paramInt1, paramInt2);
    if (color != null)
      return color; 
    color = (Color)get(this.rowbackground, paramInt1);
    if (color != null)
      return color; 
    color = (Color)get(this.colbackground, paramInt2);
    return (color == null) ? this.table.getBackground(paramInt1, paramInt2) : color;
  }
  
  public void setBackground(int paramInt1, int paramInt2, Color paramColor) { set(this.backgroundmap, paramInt1, paramInt2, paramColor); }
  
  public void setRowBackground(int paramInt, Color paramColor) { set(this.rowbackground, paramInt, paramColor); }
  
  public void setColBackground(int paramInt, Color paramColor) { set(this.colbackground, paramInt, paramColor); }
  
  public Presenter getPresenter(int paramInt1, int paramInt2) {
    Presenter presenter = (Presenter)get(this.rpresenters, paramInt1);
    return (presenter == null) ? getPresenter(paramInt2) : null;
  }
  
  public Presenter getPresenter(int paramInt) { return (Presenter)get(this.presenters, paramInt); }
  
  public void setPresenter(String paramString, Presenter paramPresenter) {
    int i = findColumn(paramString);
    if (i >= 0) {
      setPresenter(i, paramPresenter);
    } else {
      throw new NoSuchElementException(paramString);
    } 
  }
  
  public void setPresenter(int paramInt, Presenter paramPresenter) {
    set(this.presenters, paramInt, paramPresenter);
    this.check = true;
    this.cache = null;
  }
  
  public void setRowPresenter(int paramInt, Presenter paramPresenter) {
    set(this.rpresenters, paramInt, paramPresenter);
    this.check = true;
    this.cache = null;
  }
  
  public Format getFormat(int paramInt1, int paramInt2) {
    Format format = (Format)get(this.rformats, paramInt1);
    return (format == null) ? getFormat(paramInt2) : null;
  }
  
  public Format getFormat(int paramInt) { return (Format)get(this.formats, paramInt); }
  
  public void setFormat(String paramString, Format paramFormat) {
    int i = findColumn(paramString);
    if (i >= 0) {
      setFormat(i, paramFormat);
    } else {
      throw new NoSuchElementException(paramString);
    } 
  }
  
  public void setFormat(int paramInt, Format paramFormat) {
    set(this.formats, paramInt, paramFormat);
    this.check = true;
    this.cache = null;
  }
  
  public void setRowFormat(int paramInt, Format paramFormat) {
    set(this.rformats, paramInt, paramFormat);
    this.check = true;
    this.cache = null;
  }
  
  public int findColumn(String paramString) {
    if (getHeaderRowCount() > 0)
      for (byte b = 0; b < getColCount(); b++) {
        if (paramString.equals(getObject(0, b)))
          return b; 
      }  
    return -1;
  }
  
  private Object get(VectorHolder paramVectorHolder, int paramInt) {
    if (paramVectorHolder.vector == null || paramVectorHolder.vector.size() <= paramInt)
      return null; 
    return paramVectorHolder.vector.elementAt(paramInt);
  }
  
  private void set(VectorHolder paramVectorHolder, int paramInt, Object paramObject) {
    if (paramObject == null && (paramVectorHolder.vector == null || paramVectorHolder.vector.size() <= paramInt))
      return; 
    if (paramVectorHolder.vector == null)
      paramVectorHolder.vector = new Vector(); 
    if (paramVectorHolder.vector.size() <= paramInt)
      paramVectorHolder.vector.setSize(paramInt + 1); 
    paramVectorHolder.vector.setElementAt(paramObject, paramInt);
  }
  
  private Object get(HashtableHolder paramHashtableHolder, int paramInt1, int paramInt2) { return (paramHashtableHolder.map != null && paramHashtableHolder.map.size() > 0) ? paramHashtableHolder.map.get(new Point(paramInt2, paramInt1)) : null; }
  
  private void set(HashtableHolder paramHashtableHolder, int paramInt1, int paramInt2, Object paramObject) {
    if (paramObject == null) {
      if (paramHashtableHolder.map != null)
        paramHashtableHolder.map.remove(new Point(paramInt2, paramInt1)); 
    } else {
      if (paramHashtableHolder.map == null)
        paramHashtableHolder.map = new Hashtable(); 
      paramHashtableHolder.map.put(new Point(paramInt2, paramInt1), paramObject);
    } 
  }
  
  static class VectorHolder implements Serializable {
    Vector vector;
  }
  
  static class HashtableHolder implements Serializable {
    Hashtable map;
  }
  
  boolean cache_it = true;
  
  Object[][] cache;
  
  boolean autorow;
  
  boolean autocol;
  
  VectorHolder colWidth = new VectorHolder();
  
  Integer headerRow = null;
  
  Integer headerCol = null;
  
  VectorHolder rowforeground = new VectorHolder();
  
  VectorHolder rowbackground = new VectorHolder();
  
  VectorHolder colforeground = new VectorHolder();
  
  VectorHolder colbackground = new VectorHolder();
  
  HashtableHolder foregroundmap = new HashtableHolder();
  
  HashtableHolder backgroundmap = new HashtableHolder();
  
  VectorHolder rowborder = new VectorHolder();
  
  VectorHolder colborder = new VectorHolder();
  
  VectorHolder rowborderC = new VectorHolder();
  
  VectorHolder colborderC = new VectorHolder();
  
  HashtableHolder rowbordermap = new HashtableHolder();
  
  HashtableHolder colbordermap = new HashtableHolder();
  
  HashtableHolder rowborderCmap = new HashtableHolder();
  
  HashtableHolder colborderCmap = new HashtableHolder();
  
  VectorHolder rowalign = new VectorHolder();
  
  VectorHolder colalign = new VectorHolder();
  
  HashtableHolder alignmap = new HashtableHolder();
  
  Font tableFont = null;
  
  VectorHolder rowfont = new VectorHolder();
  
  VectorHolder colfont = new VectorHolder();
  
  HashtableHolder fontmap = new HashtableHolder();
  
  Boolean tablewrap = null;
  
  VectorHolder rowwrap = new VectorHolder();
  
  VectorHolder colwrap = new VectorHolder();
  
  HashtableHolder wrapmap = new HashtableHolder();
  
  HashtableHolder spanmap = new HashtableHolder();
  
  VectorHolder rowinsets = new VectorHolder();
  
  VectorHolder colinsets = new VectorHolder();
  
  HashtableHolder insetsmap = new HashtableHolder();
  
  VectorHolder presenters = new VectorHolder();
  
  VectorHolder formats = new VectorHolder();
  
  boolean check = false;
  
  Integer rowHeight = null;
  
  VectorHolder rowHeights = new VectorHolder();
  
  VectorHolder rpresenters = new VectorHolder();
  
  VectorHolder rformats = new VectorHolder();
  
  Color tableRowBorderColor = null;
  
  Color tableColBorderColor = null;
  
  Integer tableRowBorder = null;
  
  Integer tableColBorder = null;
  
  Insets tableGap = null;
  
  Integer tableAlign = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\AttributeTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */