/*    */ package inetsoft.report.lens.swing;
/*    */ 
/*    */ import inetsoft.report.lens.swing11.JTableRendererLens;
/*    */ import javax.swing.JTable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JTableRendererLens
/*    */   extends JTableRendererLens
/*    */ {
/* 41 */   public JTableRendererLens(JTable paramJTable) { super(paramJTable); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\swing\JTableRendererLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */