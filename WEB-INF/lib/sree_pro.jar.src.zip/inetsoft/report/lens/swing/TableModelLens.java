/*    */ package inetsoft.report.lens.swing;
/*    */ 
/*    */ import inetsoft.report.lens.swing11.TableModelLens;
/*    */ import javax.swing.table.TableModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TableModelLens
/*    */   extends TableModelLens
/*    */ {
/* 39 */   public TableModelLens(TableModel paramTableModel) { super(paramTableModel); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public TableModelLens(TableModel paramTableModel, boolean paramBoolean) { super(paramTableModel, paramBoolean); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\swing\TableModelLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */