/*    */ package inetsoft.report.lens.swing;
/*    */ 
/*    */ import inetsoft.report.lens.swing11.JTableLens;
/*    */ import javax.swing.JTable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JTableLens
/*    */   extends JTableLens
/*    */ {
/* 32 */   public JTableLens(JTable paramJTable) { super(paramJTable); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\swing\JTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */