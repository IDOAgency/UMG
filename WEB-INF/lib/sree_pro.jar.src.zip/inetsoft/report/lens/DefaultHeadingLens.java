/*    */ package inetsoft.report.lens;
/*    */ 
/*    */ import inetsoft.report.HeadingLens;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultHeadingLens
/*    */   extends DefaultTextLens
/*    */   implements HeadingLens
/*    */ {
/*    */   private int level;
/*    */   
/*    */   public DefaultHeadingLens(String paramString, int paramInt) {
/* 33 */     super(paramString);
/* 34 */     this.level = paramInt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public int getLevel() { return this.level; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public void setLevel(int paramInt) { this.level = paramInt; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 60 */   public String format(String paramString) { return paramString; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\DefaultHeadingLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */