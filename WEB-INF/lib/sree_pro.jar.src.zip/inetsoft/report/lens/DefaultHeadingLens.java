package inetsoft.report.lens;

import inetsoft.report.HeadingLens;

public class DefaultHeadingLens extends DefaultTextLens implements HeadingLens {
  private int level;
  
  public DefaultHeadingLens(String paramString, int paramInt) {
    super(paramString);
    this.level = paramInt;
  }
  
  public int getLevel() { return this.level; }
  
  public void setLevel(int paramInt) { this.level = paramInt; }
  
  public String format(String paramString) { return paramString; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\DefaultHeadingLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */