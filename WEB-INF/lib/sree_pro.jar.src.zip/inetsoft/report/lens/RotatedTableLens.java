/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import inetsoft.report.TableFilter;
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RotatedTableLens
/*     */   implements TableFilter
/*     */ {
/*     */   private TableLens table;
/*     */   
/*  35 */   public RotatedTableLens(TableLens paramTableLens) { this.table = paramTableLens; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   public TableLens getTable() { return this.table; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/*  50 */     if (this.table instanceof TableFilter) {
/*  51 */       ((TableFilter)this.table).refresh();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public int getRowCount() { return this.table.getColCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public int getColCount() { return this.table.getRowCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public int getHeaderRowCount() { return this.table.getHeaderColCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public int getHeaderColCount() { return this.table.getHeaderRowCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public int getRowHeight(int paramInt) { return -1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public int getColWidth(int paramInt) { return -1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public Color getRowBorderColor(int paramInt1, int paramInt2) { return this.table.getColBorderColor(paramInt2, paramInt1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public Color getColBorderColor(int paramInt1, int paramInt2) { return this.table.getRowBorderColor(paramInt2, paramInt1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public int getRowBorder(int paramInt1, int paramInt2) { return this.table.getColBorder(paramInt2, paramInt1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public int getColBorder(int paramInt1, int paramInt2) { return this.table.getRowBorder(paramInt2, paramInt1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   public Insets getInsets(int paramInt1, int paramInt2) { return this.table.getInsets(paramInt2, paramInt1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getSpan(int paramInt1, int paramInt2) {
/* 179 */     Dimension dimension = this.table.getSpan(paramInt2, paramInt1);
/* 180 */     return (dimension == null) ? dimension : new Dimension(dimension.height, dimension.width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 190 */   public int getAlignment(int paramInt1, int paramInt2) { return this.table.getAlignment(paramInt2, paramInt1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 200 */   public Font getFont(int paramInt1, int paramInt2) { return this.table.getFont(paramInt2, paramInt1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 212 */   public boolean isLineWrap(int paramInt1, int paramInt2) { return this.table.isLineWrap(paramInt2, paramInt1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 223 */   public Color getForeground(int paramInt1, int paramInt2) { return this.table.getForeground(paramInt2, paramInt1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 234 */   public Color getBackground(int paramInt1, int paramInt2) { return this.table.getBackground(paramInt2, paramInt1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 244 */   public Object getObject(int paramInt1, int paramInt2) { return this.table.getObject(paramInt2, paramInt1); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\RotatedTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */