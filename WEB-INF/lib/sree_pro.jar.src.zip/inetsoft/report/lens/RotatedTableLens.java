package inetsoft.report.lens;

import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

public class RotatedTableLens implements TableFilter {
  private TableLens table;
  
  public RotatedTableLens(TableLens paramTableLens) { this.table = paramTableLens; }
  
  public TableLens getTable() { return this.table; }
  
  public void refresh() {
    if (this.table instanceof TableFilter)
      ((TableFilter)this.table).refresh(); 
  }
  
  public int getRowCount() { return this.table.getColCount(); }
  
  public int getColCount() { return this.table.getRowCount(); }
  
  public int getHeaderRowCount() { return this.table.getHeaderColCount(); }
  
  public int getHeaderColCount() { return this.table.getHeaderRowCount(); }
  
  public int getRowHeight(int paramInt) { return -1; }
  
  public int getColWidth(int paramInt) { return -1; }
  
  public Color getRowBorderColor(int paramInt1, int paramInt2) { return this.table.getColBorderColor(paramInt2, paramInt1); }
  
  public Color getColBorderColor(int paramInt1, int paramInt2) { return this.table.getRowBorderColor(paramInt2, paramInt1); }
  
  public int getRowBorder(int paramInt1, int paramInt2) { return this.table.getColBorder(paramInt2, paramInt1); }
  
  public int getColBorder(int paramInt1, int paramInt2) { return this.table.getRowBorder(paramInt2, paramInt1); }
  
  public Insets getInsets(int paramInt1, int paramInt2) { return this.table.getInsets(paramInt2, paramInt1); }
  
  public Dimension getSpan(int paramInt1, int paramInt2) {
    Dimension dimension = this.table.getSpan(paramInt2, paramInt1);
    return (dimension == null) ? dimension : new Dimension(dimension.height, dimension.width);
  }
  
  public int getAlignment(int paramInt1, int paramInt2) { return this.table.getAlignment(paramInt2, paramInt1); }
  
  public Font getFont(int paramInt1, int paramInt2) { return this.table.getFont(paramInt2, paramInt1); }
  
  public boolean isLineWrap(int paramInt1, int paramInt2) { return this.table.isLineWrap(paramInt2, paramInt1); }
  
  public Color getForeground(int paramInt1, int paramInt2) { return this.table.getForeground(paramInt2, paramInt1); }
  
  public Color getBackground(int paramInt1, int paramInt2) { return this.table.getBackground(paramInt2, paramInt1); }
  
  public Object getObject(int paramInt1, int paramInt2) { return this.table.getObject(paramInt2, paramInt1); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\RotatedTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */