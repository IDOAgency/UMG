/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import inetsoft.report.TableFilter;
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeTableLens
/*     */   implements TableFilter
/*     */ {
/*     */   private TableLens[] table;
/*     */   private int gap;
/*     */   
/*     */   public CompositeTableLens(TableLens paramTableLens1, TableLens paramTableLens2) {
/* 384 */     this.table = new TableLens[2];
/* 385 */     this.gap = 10;
/*     */     this.table[0] = paramTableLens1;
/*     */     this.table[1] = paramTableLens2;
/*     */   }
/*     */   
/*     */   public TableLens getTable() { return this; }
/*     */   
/*     */   public void setGap(int paramInt) { this.gap = paramInt; }
/*     */   
/*     */   public int getGap() { return this.gap; }
/*     */   
/*     */   public void refresh() {
/*     */     for (byte b = 0; b < this.table.length; b++) {
/*     */       if (this.table[b] instanceof TableFilter)
/*     */         ((TableFilter)this.table[b]).refresh(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getRowCount() { return Math.max(this.table[0].getRowCount(), this.table[1].getRowCount()); }
/*     */   
/*     */   public int getColCount() { return this.table[0].getColCount() + this.table[1].getColCount() + ((this.gap > 0) ? 1 : 0); }
/*     */   
/*     */   public int getHeaderRowCount() { return Math.min(this.table[0].getHeaderRowCount(), this.table[1].getHeaderRowCount()); }
/*     */   
/*     */   public int getHeaderColCount() { return this.table[0].getHeaderRowCount(); }
/*     */   
/*     */   public int getRowHeight(int paramInt) {
/*     */     int i = (paramInt < this.table[0].getRowCount()) ? this.table[0].getRowHeight(paramInt) : -1;
/*     */     int j = (paramInt < this.table[1].getRowCount()) ? this.table[1].getRowHeight(paramInt) : -1;
/*     */     return Math.max(i, j);
/*     */   }
/*     */   
/*     */   public int getColWidth(int paramInt) {
/*     */     if (paramInt < this.table[0].getColCount())
/*     */       return this.table[0].getColWidth(paramInt); 
/*     */     paramInt -= this.table[0].getColCount();
/*     */     if (paramInt == 0 && this.gap > 0)
/*     */       return this.gap; 
/*     */     return this.table[1].getColWidth(paramInt - ((this.gap > 0) ? 1 : 0));
/*     */   }
/*     */   
/*     */   public Color getRowBorderColor(int paramInt1, int paramInt2) {
/*     */     Index index = getIndex(paramInt1, paramInt2, new Point(0, 1));
/*     */     if (index == null)
/*     */       return null; 
/*     */     return this.table[index.table].getRowBorderColor(index.row, index.col);
/*     */   }
/*     */   
/*     */   public Color getColBorderColor(int paramInt1, int paramInt2) {
/*     */     Index index = getIndex(paramInt1, paramInt2, new Point(1, 0));
/*     */     if (index == null)
/*     */       return null; 
/*     */     return this.table[index.table].getColBorderColor(index.row, index.col);
/*     */   }
/*     */   
/*     */   public int getRowBorder(int paramInt1, int paramInt2) {
/*     */     Index index = getIndex(paramInt1, paramInt2, new Point(0, 1));
/*     */     if (index == null)
/*     */       return 0; 
/*     */     return this.table[index.table].getRowBorder(index.row, index.col);
/*     */   }
/*     */   
/*     */   public int getColBorder(int paramInt1, int paramInt2) {
/*     */     Index index = getIndex(paramInt1, paramInt2, new Point(1, 0));
/*     */     if (index == null)
/*     */       return 0; 
/*     */     return this.table[index.table].getColBorder(index.row, index.col);
/*     */   }
/*     */   
/*     */   public Insets getInsets(int paramInt1, int paramInt2) {
/*     */     Index index = getIndex(paramInt1, paramInt2, new Point(0, 0));
/*     */     if (index == null)
/*     */       return null; 
/*     */     return this.table[index.table].getInsets(index.row, index.col);
/*     */   }
/*     */   
/*     */   public Dimension getSpan(int paramInt1, int paramInt2) {
/*     */     Index index = getIndex(paramInt1, paramInt2, new Point(0, 0));
/*     */     if (index == null)
/*     */       return null; 
/*     */     return this.table[index.table].getSpan(index.row, index.col);
/*     */   }
/*     */   
/*     */   public int getAlignment(int paramInt1, int paramInt2) {
/*     */     Index index = getIndex(paramInt1, paramInt2, new Point(0, 0));
/*     */     if (index == null)
/*     */       return 2; 
/*     */     return this.table[index.table].getAlignment(index.row, index.col);
/*     */   }
/*     */   
/*     */   public Font getFont(int paramInt1, int paramInt2) {
/*     */     Index index = getIndex(paramInt1, paramInt2, new Point(0, 0));
/*     */     if (index == null)
/*     */       return null; 
/*     */     return this.table[index.table].getFont(index.row, index.col);
/*     */   }
/*     */   
/*     */   public boolean isLineWrap(int paramInt1, int paramInt2) {
/*     */     Index index = getIndex(paramInt1, paramInt2, new Point(0, 0));
/*     */     if (index == null)
/*     */       return false; 
/*     */     return this.table[index.table].isLineWrap(index.row, index.col);
/*     */   }
/*     */   
/*     */   public Color getForeground(int paramInt1, int paramInt2) {
/*     */     Index index = getIndex(paramInt1, paramInt2, new Point(0, 0));
/*     */     if (index == null)
/*     */       return null; 
/*     */     return this.table[index.table].getForeground(index.row, index.col);
/*     */   }
/*     */   
/*     */   public Color getBackground(int paramInt1, int paramInt2) {
/*     */     Index index = getIndex(paramInt1, paramInt2, new Point(0, 0));
/*     */     if (index == null)
/*     */       return null; 
/*     */     return this.table[index.table].getBackground(index.row, index.col);
/*     */   }
/*     */   
/*     */   public Object getObject(int paramInt1, int paramInt2) {
/*     */     Index index = getIndex(paramInt1, paramInt2, new Point(0, 0));
/*     */     if (index == null)
/*     */       return null; 
/*     */     return this.table[index.table].getObject(index.row, index.col);
/*     */   }
/*     */   
/*     */   Index getIndex(int paramInt1, int paramInt2, Point paramPoint) {
/*     */     Index index = new Index();
/*     */     if (paramInt2 < this.table[0].getColCount()) {
/*     */       index.table = 0;
/*     */       index.col = paramInt2;
/*     */     } else {
/*     */       paramInt2 -= this.table[0].getColCount() + ((this.gap > 0) ? 1 : 0);
/*     */       if (paramInt2 + paramPoint.x >= 0) {
/*     */         index.table = 1;
/*     */         index.col = paramInt2;
/*     */       } else {
/*     */         return null;
/*     */       } 
/*     */     } 
/*     */     if (paramInt1 < this.table[index.table].getRowCount()) {
/*     */       index.row = paramInt1;
/*     */       return index;
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   static class Index {
/*     */     int table;
/*     */     int row;
/*     */     int col;
/*     */     
/*     */     public String toString() { return "Index[" + this.table + " @ " + this.row + "," + this.col + "]"; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\CompositeTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */