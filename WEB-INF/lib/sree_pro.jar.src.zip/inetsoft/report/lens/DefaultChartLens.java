/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultChartLens
/*     */   extends AttributeChartLens
/*     */ {
/*     */   Number[][] values;
/*     */   String[] labels;
/*     */   String[] dlabels;
/*     */   String xtitle;
/*     */   String ytitle;
/*     */   
/*  31 */   public DefaultChartLens() { this(1, 5); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   public DefaultChartLens(int paramInt1, int paramInt2) { setChart(new Chart(this, paramInt1, paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultChartLens(String[] paramArrayOfString, Number[][] paramArrayOfNumber) {
/*  49 */     setData(paramArrayOfNumber);
/*  50 */     setLabels(paramArrayOfString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatasetCount(int paramInt) {
/*  59 */     Number[][] arrayOfNumber = new Number[paramInt][getDatasetSize()];
/*  60 */     String[] arrayOfString = new String[paramInt];
/*     */     
/*  62 */     for (byte b = 0; b < paramInt && b < this.values.length; b++) {
/*  63 */       System.arraycopy(this.values[b], 0, arrayOfNumber[b], 0, this.values[b].length);
/*     */     }
/*     */     
/*  66 */     System.arraycopy(this.dlabels, 0, arrayOfString, 0, Math.min(this.dlabels.length, arrayOfString.length));
/*     */ 
/*     */     
/*  69 */     this.values = arrayOfNumber;
/*  70 */     this.dlabels = arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatasetSize(int paramInt) {
/*  78 */     Number[][] arrayOfNumber = new Number[getDatasetCount()][paramInt];
/*  79 */     String[] arrayOfString = new String[paramInt];
/*     */     
/*  81 */     for (byte b = 0; b < this.values.length; b++) {
/*  82 */       System.arraycopy(this.values[b], 0, arrayOfNumber[b], 0, Math.min(arrayOfNumber[b].length, this.values[b].length));
/*     */     }
/*     */ 
/*     */     
/*  86 */     System.arraycopy(this.labels, 0, arrayOfString, 0, Math.min(this.labels.length, arrayOfString.length));
/*     */ 
/*     */     
/*  89 */     this.values = arrayOfNumber;
/*  90 */     this.labels = arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public void setData(int paramInt1, int paramInt2, Number paramNumber) { this.values[paramInt1][paramInt2] = paramNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setData(Number[][] paramArrayOfNumber) {
/* 109 */     setChart(new Chart(this, paramArrayOfNumber.length, paramArrayOfNumber[0].length));
/*     */     
/* 111 */     for (byte b = 0; b < paramArrayOfNumber.length; b++) {
/* 112 */       for (byte b1 = 0; b1 < paramArrayOfNumber[b].length; b1++) {
/* 113 */         setData(b, b1, paramArrayOfNumber[b][b1]);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public void setLabel(int paramInt, String paramString) { this.labels[paramInt] = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabels(String[] paramArrayOfString) {
/* 132 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 133 */       setLabel(b, paramArrayOfString[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   public void setDatasetLabel(int paramInt, String paramString) { this.dlabels[paramInt] = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatasetLabels(String[] paramArrayOfString) {
/* 151 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 152 */       setDatasetLabel(b, paramArrayOfString[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public void setXTitle(String paramString) { this.xtitle = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   public void setYTitle(String paramString) { this.ytitle = paramString; }
/*     */   
/*     */   class Chart extends AbstractChartLens {
/*     */     public Chart(DefaultChartLens this$0, int param1Int1, int param1Int2) {
/* 173 */       this.this$0 = this$0;
/* 174 */       this$0.values = new Number[param1Int1][param1Int2];
/* 175 */       this$0.labels = new String[param1Int2];
/* 176 */       this$0.dlabels = new String[param1Int1];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private final DefaultChartLens this$0;
/*     */ 
/*     */     
/* 184 */     public int getDatasetCount() { return this.this$0.values.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     public int getDatasetSize() { return this.this$0.values[0].length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 203 */     public Number getData(int param1Int1, int param1Int2) { return this.this$0.values[param1Int1][param1Int2]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     public String getLabel(int param1Int) { return this.this$0.labels[param1Int]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 220 */     public String getDatasetLabel(int param1Int) { return this.this$0.dlabels[param1Int]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     public String getXTitle() { return this.this$0.xtitle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 236 */     public String getYTitle() { return this.this$0.ytitle; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\DefaultChartLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */