package inetsoft.report.lens;

public class DefaultChartLens extends AttributeChartLens {
  Number[][] values;
  
  String[] labels;
  
  String[] dlabels;
  
  String xtitle;
  
  String ytitle;
  
  public DefaultChartLens() { this(1, 5); }
  
  public DefaultChartLens(int paramInt1, int paramInt2) { setChart(new Chart(this, paramInt1, paramInt2)); }
  
  public DefaultChartLens(String[] paramArrayOfString, Number[][] paramArrayOfNumber) {
    setData(paramArrayOfNumber);
    setLabels(paramArrayOfString);
  }
  
  public void setDatasetCount(int paramInt) {
    Number[][] arrayOfNumber = new Number[paramInt][getDatasetSize()];
    String[] arrayOfString = new String[paramInt];
    for (byte b = 0; b < paramInt && b < this.values.length; b++)
      System.arraycopy(this.values[b], 0, arrayOfNumber[b], 0, this.values[b].length); 
    System.arraycopy(this.dlabels, 0, arrayOfString, 0, Math.min(this.dlabels.length, arrayOfString.length));
    this.values = arrayOfNumber;
    this.dlabels = arrayOfString;
  }
  
  public void setDatasetSize(int paramInt) {
    Number[][] arrayOfNumber = new Number[getDatasetCount()][paramInt];
    String[] arrayOfString = new String[paramInt];
    for (byte b = 0; b < this.values.length; b++)
      System.arraycopy(this.values[b], 0, arrayOfNumber[b], 0, Math.min(arrayOfNumber[b].length, this.values[b].length)); 
    System.arraycopy(this.labels, 0, arrayOfString, 0, Math.min(this.labels.length, arrayOfString.length));
    this.values = arrayOfNumber;
    this.labels = arrayOfString;
  }
  
  public void setData(int paramInt1, int paramInt2, Number paramNumber) { this.values[paramInt1][paramInt2] = paramNumber; }
  
  public void setData(Number[][] paramArrayOfNumber) {
    setChart(new Chart(this, paramArrayOfNumber.length, paramArrayOfNumber[0].length));
    for (byte b = 0; b < paramArrayOfNumber.length; b++) {
      for (byte b1 = 0; b1 < paramArrayOfNumber[b].length; b1++)
        setData(b, b1, paramArrayOfNumber[b][b1]); 
    } 
  }
  
  public void setLabel(int paramInt, String paramString) { this.labels[paramInt] = paramString; }
  
  public void setLabels(String[] paramArrayOfString) {
    for (byte b = 0; b < paramArrayOfString.length; b++)
      setLabel(b, paramArrayOfString[b]); 
  }
  
  public void setDatasetLabel(int paramInt, String paramString) { this.dlabels[paramInt] = paramString; }
  
  public void setDatasetLabels(String[] paramArrayOfString) {
    for (byte b = 0; b < paramArrayOfString.length; b++)
      setDatasetLabel(b, paramArrayOfString[b]); 
  }
  
  public void setXTitle(String paramString) { this.xtitle = paramString; }
  
  public void setYTitle(String paramString) { this.ytitle = paramString; }
  
  class Chart extends AbstractChartLens {
    private final DefaultChartLens this$0;
    
    public Chart(DefaultChartLens this$0, int param1Int1, int param1Int2) {
      this.this$0 = this$0;
      this$0.values = new Number[param1Int1][param1Int2];
      this$0.labels = new String[param1Int2];
      this$0.dlabels = new String[param1Int1];
    }
    
    public int getDatasetCount() { return this.this$0.values.length; }
    
    public int getDatasetSize() { return this.this$0.values[0].length; }
    
    public Number getData(int param1Int1, int param1Int2) { return this.this$0.values[param1Int1][param1Int2]; }
    
    public String getLabel(int param1Int) { return this.this$0.labels[param1Int]; }
    
    public String getDatasetLabel(int param1Int) { return this.this$0.dlabels[param1Int]; }
    
    public String getXTitle() { return this.this$0.xtitle; }
    
    public String getYTitle() { return this.this$0.ytitle; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\DefaultChartLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */