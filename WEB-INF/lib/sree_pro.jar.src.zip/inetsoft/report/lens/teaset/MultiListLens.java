/*     */ package inetsoft.report.lens.teaset;
/*     */ 
/*     */ import inetsoft.report.lens.AbstractTableLens;
/*     */ import inetsoft.report.lens.AttributeTableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import tea.set.MultiList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiListLens
/*     */   extends AttributeTableLens
/*     */ {
/*  35 */   public MultiListLens(MultiList paramMultiList) { setTable(new Table(this, paramMultiList)); }
/*     */   
/*     */   class Table extends AbstractTableLens {
/*     */     public Table(MultiListLens this$0, MultiList param1MultiList) {
/*  39 */       this.this$0 = this$0;
/*  40 */       this.mlist = param1MultiList;
/*     */     }
/*     */ 
/*     */     
/*     */     private MultiList mlist;
/*     */     
/*     */     private final MultiListLens this$0;
/*     */     
/*  48 */     public int getRowCount() { return this.mlist.getRowCount() + ((this.mlist.getHeader() != null) ? 1 : 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     public int getColCount() { return this.mlist.getColCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     public int getHeaderRowCount() { return (this.mlist.getHeader() != null) ? 1 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     public int getHeaderColCount() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     public int getRowHeight(int param1Int) { return this.mlist.getRowHeight(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     public int getColWidth(int param1Int) { return this.mlist.getColWidth()[param1Int]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.gray; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.gray; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 <= 0 || param1Int1 == getRowCount() - 1) ? 24578 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     public int getColBorder(int param1Int1, int param1Int2) { return (param1Int2 < 0 || param1Int2 == getColCount() - 1) ? 24578 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     public Insets getInsets(int param1Int1, int param1Int2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     public int getAlignment(int param1Int1, int param1Int2) { return 17; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int1, int param1Int2) {
/* 186 */       param1Int1 -= ((this.mlist.getHeader() == null) ? 0 : 1);
/* 187 */       return (param1Int1 >= 0) ? this.mlist.getCellFont(param1Int1, param1Int2) : null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Color getForeground(int param1Int1, int param1Int2) {
/* 198 */       param1Int1 -= ((this.mlist.getHeader() == null) ? 0 : 1);
/* 199 */       return (param1Int1 >= 0) ? this.mlist.getCellForeground(param1Int1, param1Int2) : null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Color getBackground(int param1Int1, int param1Int2) {
/* 210 */       param1Int1 -= ((this.mlist.getHeader() == null) ? 0 : 1);
/* 211 */       Color color = (param1Int1 >= 0) ? this.mlist.getCellBackground(param1Int1, param1Int2) : null;
/*     */       
/* 213 */       if (color == null) {
/* 214 */         color = this.mlist.getColBackground(param1Int2);
/*     */       }
/*     */       
/* 217 */       return color;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getObject(int param1Int1, int param1Int2) {
/* 227 */       if (param1Int1 == 0 && this.mlist.getHeader() != null) {
/* 228 */         return this.mlist.getHeader()[param1Int2];
/*     */       }
/*     */       
/* 231 */       param1Int1 -= ((this.mlist.getHeader() == null) ? 0 : 1);
/* 232 */       return this.mlist.getObject(param1Int1, param1Int2);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\teaset\MultiListLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */