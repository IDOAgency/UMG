package inetsoft.report.lens.teaset;

import inetsoft.report.lens.AbstractTableLens;
import inetsoft.report.lens.AttributeTableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import tea.set.MultiList;

public class MultiListLens extends AttributeTableLens {
  public MultiListLens(MultiList paramMultiList) { setTable(new Table(this, paramMultiList)); }
  
  class Table extends AbstractTableLens {
    private MultiList mlist;
    
    private final MultiListLens this$0;
    
    public Table(MultiListLens this$0, MultiList param1MultiList) {
      this.this$0 = this$0;
      this.mlist = param1MultiList;
    }
    
    public int getRowCount() { return this.mlist.getRowCount() + ((this.mlist.getHeader() != null) ? 1 : 0); }
    
    public int getColCount() { return this.mlist.getColCount(); }
    
    public int getHeaderRowCount() { return (this.mlist.getHeader() != null) ? 1 : 0; }
    
    public int getHeaderColCount() { return 0; }
    
    public int getRowHeight(int param1Int) { return this.mlist.getRowHeight(); }
    
    public int getColWidth(int param1Int) { return this.mlist.getColWidth()[param1Int]; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.gray; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.gray; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 <= 0 || param1Int1 == getRowCount() - 1) ? 24578 : 0; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return (param1Int2 < 0 || param1Int2 == getColCount() - 1) ? 24578 : 0; }
    
    public Insets getInsets(int param1Int1, int param1Int2) { return null; }
    
    public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
    
    public int getAlignment(int param1Int1, int param1Int2) { return 17; }
    
    public Font getFont(int param1Int1, int param1Int2) {
      param1Int1 -= ((this.mlist.getHeader() == null) ? 0 : 1);
      return (param1Int1 >= 0) ? this.mlist.getCellFont(param1Int1, param1Int2) : null;
    }
    
    public Color getForeground(int param1Int1, int param1Int2) {
      param1Int1 -= ((this.mlist.getHeader() == null) ? 0 : 1);
      return (param1Int1 >= 0) ? this.mlist.getCellForeground(param1Int1, param1Int2) : null;
    }
    
    public Color getBackground(int param1Int1, int param1Int2) {
      param1Int1 -= ((this.mlist.getHeader() == null) ? 0 : 1);
      Color color = (param1Int1 >= 0) ? this.mlist.getCellBackground(param1Int1, param1Int2) : null;
      if (color == null)
        color = this.mlist.getColBackground(param1Int2); 
      return color;
    }
    
    public Object getObject(int param1Int1, int param1Int2) {
      if (param1Int1 == 0 && this.mlist.getHeader() != null)
        return this.mlist.getHeader()[param1Int2]; 
      param1Int1 -= ((this.mlist.getHeader() == null) ? 0 : 1);
      return this.mlist.getObject(param1Int1, param1Int2);
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\teaset\MultiListLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */