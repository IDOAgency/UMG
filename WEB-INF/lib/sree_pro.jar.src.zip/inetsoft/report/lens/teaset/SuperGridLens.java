package inetsoft.report.lens.teaset;

import inetsoft.report.lens.AbstractTableLens;
import inetsoft.report.lens.AttributeTableLens;
import inetsoft.report.painter.ButtonPresenter;
import inetsoft.report.painter.PresenterPainter;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import tea.set.SuperGrid;

public class SuperGridLens extends AttributeTableLens {
  boolean header3d;
  
  public SuperGridLens(SuperGrid paramSuperGrid) {
    this.header3d = false;
    setTable(new Table(this, paramSuperGrid));
  }
  
  public void setShow3DHeader(boolean paramBoolean) { this.header3d = paramBoolean; }
  
  public boolean isShow3DHeader() { return this.header3d; }
  
  class Table extends AbstractTableLens {
    private SuperGrid grid;
    
    private final SuperGridLens this$0;
    
    public Table(SuperGridLens this$0, SuperGrid param1SuperGrid) {
      this.this$0 = this$0;
      this.grid = param1SuperGrid;
    }
    
    public int getRowCount() { return this.grid.getRowCount() + this.grid.getHeaderRowCount(); }
    
    public int getColCount() { return this.grid.getColCount() + this.grid.getHeaderColCount(); }
    
    public int getHeaderRowCount() { return this.grid.getHeaderRowCount(); }
    
    public int getHeaderColCount() { return this.grid.getHeaderColCount(); }
    
    public int getRowHeight(int param1Int) { return this.grid.getRowHeight(param1Int - this.grid.getHeaderRowCount()) + 2; }
    
    public int getColWidth(int param1Int) { return this.grid.getColWidth(param1Int - this.grid.getHeaderColCount()); }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.gray; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.gray; }
    
    public int getRowBorder(int param1Int1, int param1Int2) {
      if (param1Int1 == -1)
        return getRowBorder(getRowCount() - 1, param1Int2); 
      int i = this.grid.getRuling(param1Int1 - this.grid.getHeaderRowCount(), param1Int2 - this.grid.getHeaderColCount());
      if ((i & true) == 0)
        return 0; 
      switch (this.grid.get3D()) {
        case 0:
          return 4097;
        case 1:
        case 8:
          return 24578;
        case 2:
        case 16:
          return 40962;
        case 4:
          return 4113;
      } 
      return 0;
    }
    
    public int getColBorder(int param1Int1, int param1Int2) {
      if (param1Int2 == -1)
        return getColBorder(param1Int1, getColCount() - 1); 
      int i = this.grid.getRuling(param1Int1 - this.grid.getHeaderRowCount(), param1Int2 - this.grid.getHeaderColCount());
      if ((i & 0x2) == 0)
        return 0; 
      switch (this.grid.get3D()) {
        case 0:
          return 4097;
        case 1:
        case 8:
          return 24578;
        case 2:
        case 16:
          return 40962;
        case 4:
          return 4113;
      } 
      return 0;
    }
    
    public Insets getInsets(int param1Int1, int param1Int2) { return this.grid.getGap(param1Int1 - this.grid.getHeaderRowCount(), param1Int2 - this.grid.getHeaderColCount()); }
    
    public Dimension getSpan(int param1Int1, int param1Int2) { return this.grid.getSpanning(param1Int1 - this.grid.getHeaderRowCount(), param1Int2 - this.grid.getHeaderColCount()); }
    
    public int getAlignment(int param1Int1, int param1Int2) {
      if (param1Int1 < this.grid.getHeaderRowCount() || param1Int2 < this.grid.getHeaderColCount())
        return 0; 
      return this.grid.getAlignment(param1Int1 - this.grid.getHeaderRowCount(), param1Int2 - this.grid.getHeaderColCount());
    }
    
    public Font getFont(int param1Int1, int param1Int2) { return this.grid.getFont(param1Int1 - this.grid.getHeaderRowCount(), param1Int2 - this.grid.getHeaderColCount()); }
    
    public Color getForeground(int param1Int1, int param1Int2) { return this.grid.getForeground(param1Int1 - this.grid.getHeaderRowCount(), param1Int2 - this.grid.getHeaderColCount()); }
    
    public Color getBackground(int param1Int1, int param1Int2) {
      if (param1Int1 < this.grid.getHeaderRowCount())
        return Color.lightGray; 
      Color color = this.grid.getBackground(param1Int1 - this.grid.getHeaderRowCount(), param1Int2 - this.grid.getHeaderColCount());
      return !color.equals(this.grid.getBackground()) ? color : null;
    }
    
    public Object getObject(int param1Int1, int param1Int2) {
      if (param1Int1 < this.grid.getHeaderRowCount() || param1Int2 < this.grid.getHeaderColCount()) {
        String str = this.grid.getHeader(param1Int1 - this.grid.getHeaderRowCount(), param1Int2 - this.grid.getHeaderColCount());
        if (this.this$0.header3d)
          return new PresenterPainter(str, new ButtonPresenter()); 
        return str;
      } 
      return this.grid.getObject(param1Int1 - this.grid.getHeaderRowCount(), param1Int2 - this.grid.getHeaderColCount());
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\teaset\SuperGridLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */