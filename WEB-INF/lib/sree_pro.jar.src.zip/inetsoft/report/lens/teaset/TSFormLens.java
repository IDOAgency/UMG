package inetsoft.report.lens.teaset;

import inetsoft.report.FormLens;
import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import tea.set.Form;

public class TSFormLens implements FormLens {
  private Form form;
  
  public TSFormLens(Form paramForm) { this.form = paramForm; }
  
  public int getFieldCount() { return this.form.getField().length; }
  
  public int getFieldPerRow() { return this.form.getRowColCount(); }
  
  public int getWidth(int paramInt) { return this.form.getColWidth(paramInt); }
  
  public Font getLabelFont(int paramInt) {
    Point point = this.form.getPosition(paramInt);
    return this.form.getFont(point.y, point.x - 1);
  }
  
  public Color getLabelForeground(int paramInt) {
    Point point = this.form.getPosition(paramInt);
    return this.form.getForeground(point.y, point.x - 1);
  }
  
  public Color getLabelBackground(int paramInt) {
    Point point = this.form.getPosition(paramInt);
    return this.form.getBackground(point.y, point.x - 1);
  }
  
  public Font getFont(int paramInt) {
    Point point = this.form.getPosition(paramInt);
    return this.form.getFont(point.y, point.x);
  }
  
  public Color getForeground(int paramInt) {
    Point point = this.form.getPosition(paramInt);
    return this.form.getForeground(point.y, point.x);
  }
  
  public Color getBackground(int paramInt) {
    Point point = this.form.getPosition(paramInt);
    return this.form.getBackground(point.y, point.x);
  }
  
  public Object getField(int paramInt) { return this.form.getObject(paramInt); }
  
  public Object getLabel(int paramInt) { return this.form.getField(paramInt); }
  
  public int getUnderline() { return 4097; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\teaset\TSFormLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */