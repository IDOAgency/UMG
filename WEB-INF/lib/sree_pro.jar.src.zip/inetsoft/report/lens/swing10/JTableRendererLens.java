package inetsoft.report.lens.swing10;

import com.sun.java.swing.CellRendererPane;
import com.sun.java.swing.JCheckBox;
import com.sun.java.swing.JLabel;
import com.sun.java.swing.JTable;
import com.sun.java.swing.table.TableCellRenderer;
import com.sun.java.swing.table.TableColumnModel;
import inetsoft.report.Painter;
import inetsoft.report.lens.AbstractTableLens;
import inetsoft.report.lens.AttributeTableLens;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;

public class JTableRendererLens extends AttributeTableLens {
  JTable tbl;
  
  CellRendererPane pane;
  
  public JTableRendererLens(JTable paramJTable) {
    this.pane = new CellRendererPane();
    setTable(new Table(this, paramJTable));
    setCached(false);
  }
  
  public void setTable(JTable paramJTable) { setTable(new Table(this, paramJTable)); }
  
  class Table extends AbstractTableLens {
    private final JTableRendererLens this$0;
    
    public Table(JTableRendererLens this$0, JTable param1JTable) {
      this.this$0 = this$0;
      this$0.tbl = param1JTable;
    }
    
    public int getRowCount() { return this.this$0.tbl.getRowCount() + 1; }
    
    public int getColCount() { return this.this$0.tbl.getColumnModel().getColumnCount(); }
    
    public int getHeaderRowCount() { return 1; }
    
    public int getHeaderColCount() { return 0; }
    
    public int getRowHeight(int param1Int) { return (param1Int == 0) ? -1 : this.this$0.tbl.getRowHeight(); }
    
    public int getColWidth(int param1Int) {
      TableColumnModel tableColumnModel = this.this$0.tbl.getColumnModel();
      return tableColumnModel.getColumn(param1Int).getWidth();
    }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return this.this$0.tbl.getGridColor(); }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return this.this$0.tbl.getGridColor(); }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 > 0 && this.this$0.tbl.getShowHorizontalLines()) ? 4097 : 0; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return (param1Int1 > 0 && this.this$0.tbl.getShowVerticalLines()) ? 4097 : 0; }
    
    public Insets getInsets(int param1Int1, int param1Int2) {
      Dimension dimension = this.this$0.tbl.getIntercellSpacing();
      return (param1Int1 > 0) ? new Insets(dimension.height, dimension.width, dimension.height, dimension.width) : null;
    }
    
    public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
    
    public int getAlignment(int param1Int1, int param1Int2) {
      if (param1Int1 == 0)
        return 0; 
      int i = this.this$0.tbl.convertColumnIndexToModel(param1Int2);
      TableColumnModel tableColumnModel = this.this$0.tbl.getColumnModel();
      if (i >= tableColumnModel.getColumnCount())
        return 17; 
      TableCellRenderer tableCellRenderer = tableColumnModel.getColumn(i).getCellRenderer();
      if (tableCellRenderer instanceof JLabel)
        switch (((JLabel)tableCellRenderer).getHorizontalAlignment()) {
          case 2:
            return 17;
          case 0:
            return 18;
          case 4:
            return 20;
        }  
      return 17;
    }
    
    public Font getFont(int param1Int1, int param1Int2) { return this.this$0.tbl.getFont(); }
    
    public Color getForeground(int param1Int1, int param1Int2) { return this.this$0.tbl.getForeground(); }
    
    public Color getBackground(int param1Int1, int param1Int2) { return (param1Int1 == 0) ? Color.lightGray : this.this$0.tbl.getBackground(); }
    
    public Object getObject(int param1Int1, int param1Int2) {
      TableColumnModel tableColumnModel = this.this$0.tbl.getColumnModel();
      Object object = null;
      if (param1Int1 == 0) {
        object = this.this$0.tbl.getColumnName(param1Int2);
        TableCellRenderer tableCellRenderer = tableColumnModel.getColumn(param1Int2).getHeaderRenderer();
        if (tableCellRenderer != null)
          Component component = tableCellRenderer.getTableCellRendererComponent(this.this$0.tbl, object, false, false, param1Int1 - 1, param1Int2); 
      } else {
        object = this.this$0.tbl.getValueAt(param1Int1 - 1, param1Int2);
        TableCellRenderer tableCellRenderer = tableColumnModel.getColumn(param1Int2).getCellRenderer();
        if (tableCellRenderer == null && object != null) {
          Class clazz = this.this$0.tbl.getColumnClass(param1Int2);
          tableCellRenderer = this.this$0.tbl.getDefaultRenderer((clazz == null) ? object.getClass() : clazz);
        } 
        if (tableCellRenderer != null)
          object = tableCellRenderer.getTableCellRendererComponent(this.this$0.tbl, object, false, false, param1Int1 - 1, param1Int2); 
      } 
      if (object instanceof JCheckBox) {
        JCheckBox jCheckBox = (JCheckBox)object;
        if (jCheckBox.getText() != null && jCheckBox.getText().length() == 0)
          jCheckBox.setText(" "); 
      } 
      return (object instanceof Component) ? new JTableRendererLens.RenderPainter(this.this$0, object) : object;
    }
    
    public boolean isLineWrap(int param1Int1, int param1Int2) { return false; }
  }
  
  class RenderPainter implements Painter {
    Component comp;
    
    private final JTableRendererLens this$0;
    
    public RenderPainter(JTableRendererLens this$0, Object param1Object) {
      this.this$0 = this$0;
      this.comp = (Component)param1Object;
    }
    
    public void paint(Graphics param1Graphics, int param1Int1, int param1Int2, int param1Int3, int param1Int4) { this.this$0.pane.paintComponent(param1Graphics, this.comp, this.this$0.tbl, param1Int1, param1Int2, param1Int3, param1Int4, true); }
    
    public Dimension getPreferredSize() { return this.comp.getPreferredSize(); }
    
    public boolean isScalable() { return true; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\swing10\JTableRendererLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */