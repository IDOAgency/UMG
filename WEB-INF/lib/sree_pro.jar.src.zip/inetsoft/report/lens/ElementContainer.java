/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import inetsoft.report.ChartLens;
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.CompositeLens;
/*     */ import inetsoft.report.Context;
/*     */ import inetsoft.report.FormLens;
/*     */ import inetsoft.report.HeadingLens;
/*     */ import inetsoft.report.Painter;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.ScaledPainter;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.TOC;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.TextLens;
/*     */ import inetsoft.report.internal.AreaBreakElementDef;
/*     */ import inetsoft.report.internal.BaseElement;
/*     */ import inetsoft.report.internal.ChartElementDef;
/*     */ import inetsoft.report.internal.CondPageBreakElementDef;
/*     */ import inetsoft.report.internal.FormElementDef;
/*     */ import inetsoft.report.internal.HeadingElementDef;
/*     */ import inetsoft.report.internal.NewlineElementDef;
/*     */ import inetsoft.report.internal.PageBreakElementDef;
/*     */ import inetsoft.report.internal.PainterElementDef;
/*     */ import inetsoft.report.internal.SeparatorElementDef;
/*     */ import inetsoft.report.internal.SpaceElementDef;
/*     */ import inetsoft.report.internal.TOCElementDef;
/*     */ import inetsoft.report.internal.TabElementDef;
/*     */ import inetsoft.report.internal.TableElementDef;
/*     */ import inetsoft.report.internal.TextBoxElementDef;
/*     */ import inetsoft.report.internal.TextElementDef;
/*     */ import inetsoft.report.painter.BulletPainter;
/*     */ import inetsoft.report.painter.ComponentPainter;
/*     */ import inetsoft.report.painter.ImagePainter;
/*     */ import java.awt.Component;
/*     */ import java.awt.Image;
/*     */ import java.awt.image.ImageProducer;
/*     */ import java.io.Serializable;
/*     */ import java.net.URL;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementContainer
/*     */   implements CompositeLens, Serializable
/*     */ {
/*     */   protected StyleSheet parent;
/*     */   Vector elements;
/*     */   int index;
/*     */   
/*     */   public ElementContainer(StyleSheet paramStyleSheet) {
/* 477 */     this.parent = null;
/*     */     
/* 479 */     this.elements = new Vector();
/* 480 */     this.index = 0;
/*     */     this.parent = paramStyleSheet;
/*     */   }
/*     */   
/*     */   public String addText(String paramString) { return addText(new DefaultTextLens(paramString)); }
/*     */   
/*     */   public String addText(TextLens paramTextLens) {
/*     */     if (paramTextLens instanceof HeadingLens)
/*     */       return addElement(new HeadingElementDef(this.parent, (HeadingLens)paramTextLens)); 
/*     */     return addElement(new TextElementDef(this.parent, paramTextLens));
/*     */   }
/*     */   
/*     */   public String addTextBox(TextLens paramTextLens) { return addElement(new TextBoxElementDef(this.parent, paramTextLens)); }
/*     */   
/*     */   public String addTextBox(TextLens paramTextLens, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) {
/*     */     TextBoxElementDef textBoxElementDef = new TextBoxElementDef(this.parent, paramTextLens, paramDouble1, paramDouble2);
/*     */     textBoxElementDef.setBorder(paramInt1);
/*     */     textBoxElementDef.setTextAlignment(paramInt2);
/*     */     return addElement(textBoxElementDef);
/*     */   }
/*     */   
/*     */   public String addTextBox(String paramString, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) { return addTextBox(new DefaultTextLens(paramString), paramInt1, paramDouble1, paramDouble2, paramInt2); }
/*     */   
/*     */   public String addPainter(Painter paramPainter) {
/*     */     if (paramPainter instanceof ScaledPainter) {
/*     */       Size size = ((ScaledPainter)paramPainter).getSize();
/*     */       return addPainter(paramPainter, size.width, size.height);
/*     */     } 
/*     */     return addElement(new PainterElementDef(this.parent, paramPainter));
/*     */   }
/*     */   
/*     */   public String addPainter(Painter paramPainter, double paramDouble1, double paramDouble2) { return addElement(new PainterElementDef(this.parent, paramPainter, paramDouble1, paramDouble2)); }
/*     */   
/*     */   public String addChart(ChartLens paramChartLens) { return addElement(new ChartElementDef(this.parent, paramChartLens)); }
/*     */   
/*     */   public String addChart(ChartLens paramChartLens, double paramDouble1, double paramDouble2) { return addElement(new ChartElementDef(this.parent, paramChartLens, paramDouble1, paramDouble2)); }
/*     */   
/*     */   public String addComponent(Component paramComponent) { return addPainter(new ComponentPainter(paramComponent)); }
/*     */   
/*     */   public String addComponent(Component paramComponent, double paramDouble1, double paramDouble2) { return addPainter(new ComponentPainter(paramComponent), paramDouble1, paramDouble2); }
/*     */   
/*     */   public String addImage(Image paramImage) { return addPainter(new ImagePainter(paramImage)); }
/*     */   
/*     */   public String addImage(Image paramImage, double paramDouble1, double paramDouble2) { return addPainter(new ImagePainter(paramImage), paramDouble1, paramDouble2); }
/*     */   
/*     */   public String addImage(URL paramURL) {
/*     */     try {
/*     */       return addImage(Common.getToolkit().createImage((ImageProducer)paramURL.getContent()));
/*     */     } catch (Exception exception) {
/*     */       exception.printStackTrace();
/*     */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String addBullet() {
/*     */     BulletPainter bulletPainter = new BulletPainter();
/*     */     this.parent.setHindent((int)((bulletPainter.getSize()).width * 72.0F));
/*     */     return addPainter(bulletPainter);
/*     */   }
/*     */   
/*     */   public String addBullet(Image paramImage) {
/*     */     BulletPainter bulletPainter = new BulletPainter(paramImage);
/*     */     this.parent.setHindent((int)((bulletPainter.getSize()).width * 72.0F));
/*     */     return addPainter(bulletPainter);
/*     */   }
/*     */   
/*     */   public String addSpace(int paramInt) { return addElement(new SpaceElementDef(this.parent, paramInt)); }
/*     */   
/*     */   public String addNewline(int paramInt) { return addElement(new NewlineElementDef(this.parent, paramInt, false)); }
/*     */   
/*     */   public String addBreak() { return addElement(new NewlineElementDef(this.parent, 1, true)); }
/*     */   
/*     */   public String addPageBreak() { return addElement(new PageBreakElementDef(this.parent)); }
/*     */   
/*     */   public String addAreaBreak() { return addElement(new AreaBreakElementDef(this.parent)); }
/*     */   
/*     */   public String addConditionalPageBreak(int paramInt) { return addElement(new CondPageBreakElementDef(this.parent, paramInt)); }
/*     */   
/*     */   public String addConditionalPageBreak(double paramDouble) { return addElement(new CondPageBreakElementDef(this.parent, paramDouble)); }
/*     */   
/*     */   public String addSeparator(int paramInt) { return addElement(new SeparatorElementDef(this.parent, paramInt)); }
/*     */   
/*     */   public String addTab(int paramInt) { return addElement(new TabElementDef(this.parent, paramInt)); }
/*     */   
/*     */   public String addTable(TableLens paramTableLens) { return addElement(new TableElementDef(this.parent, paramTableLens)); }
/*     */   
/*     */   public String addForm(FormLens paramFormLens) { return addElement(new FormElementDef(this.parent, paramFormLens)); }
/*     */   
/*     */   public String addTOC(TOC paramTOC) { return addElement(new TOCElementDef(this.parent, paramTOC)); }
/*     */   
/*     */   public String addElement(ReportElement paramReportElement) {
/*     */     if (((BaseElement)paramReportElement).isNewline() && !((BaseElement)paramReportElement).isContinuation())
/*     */       this.parent.setHindent(0); 
/*     */     this.elements.addElement(paramReportElement);
/*     */     return paramReportElement.getID();
/*     */   }
/*     */   
/*     */   public int getElementCount() { return this.elements.size(); }
/*     */   
/*     */   public ReportElement getElement(int paramInt) { return (ReportElement)this.elements.elementAt(paramInt); }
/*     */   
/*     */   public void removeElement(int paramInt) { this.elements.removeElementAt(paramInt); }
/*     */   
/*     */   public void removeAllElements() { this.elements.removeAllElements(); }
/*     */   
/*     */   public Object nextElement(Context paramContext) { return (this.index < this.elements.size()) ? getElement(this.index++) : null; }
/*     */   
/*     */   public void reset() {
/*     */     this.index = 0;
/*     */     for (byte b = 0; b < this.elements.size(); b++)
/*     */       ((BaseElement)getElement(b)).reset(); 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\ElementContainer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */