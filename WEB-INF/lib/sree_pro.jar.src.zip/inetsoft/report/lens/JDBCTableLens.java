/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Insets;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBCTableLens
/*     */   extends AttributeTableLens
/*     */ {
/*  63 */   public void setHeaders(String[] paramArrayOfString) { this.hdrs = paramArrayOfString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMapping(String[][] paramArrayOfString) {
/*  72 */     Hashtable hashtable = new Hashtable();
/*     */     
/*  74 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*  75 */       hashtable.put(paramArrayOfString[b][0], paramArrayOfString[b][1]);
/*     */     }
/*     */     
/*  78 */     setMapping(hashtable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMapping(Hashtable paramHashtable) {
/*  87 */     if (this.rows.size() > 0) {
/*  88 */       Vector vector = (Vector)this.rows.elementAt(0);
/*     */       
/*  90 */       for (byte b = 0; b < vector.size(); b++) {
/*  91 */         Object object = vector.elementAt(b);
/*     */ 
/*     */         
/*  94 */         if (object != null) {
/*  95 */           object = paramHashtable.get(object);
/*     */           
/*  97 */           if (object != null) {
/*  98 */             vector.setElementAt(object, b);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trim() {
/* 109 */     for (byte b = 0; b < this.rows.size(); b++) {
/* 110 */       Vector vector = (Vector)this.rows.elementAt(b);
/*     */       
/* 112 */       for (byte b1 = 0; b1 < vector.size(); b1++) {
/* 113 */         Object object = vector.elementAt(b1);
/*     */         
/* 115 */         if (object instanceof String) {
/* 116 */           vector.setElementAt(((String)object).trim(), b1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   class JDBCTable
/*     */     extends AbstractTableLens
/*     */   {
/*     */     private int charW;
/*     */     private int ncol;
/*     */     private int[] colwidth;
/*     */     private final JDBCTableLens this$0;
/*     */     
/*     */     public JDBCTable(JDBCTableLens this$0, ResultSet param1ResultSet) {
/* 131 */       this.this$0 = this$0;
/*     */       try {
/* 133 */         ResultSetMetaData resultSetMetaData = param1ResultSet.getMetaData();
/* 134 */         this.ncol = resultSetMetaData.getColumnCount();
/*     */ 
/*     */         
/* 137 */         Vector vector = new Vector();
/* 138 */         for (byte b1 = 0; b1 < this.ncol; b1++) {
/* 139 */           String str = resultSetMetaData.getColumnLabel(b1 + true);
/* 140 */           vector.addElement(str);
/*     */         } 
/* 142 */         this$0.rows.addElement(vector);
/*     */ 
/*     */         
/* 145 */         while (param1ResultSet.next()) {
/* 146 */           Vector vector1 = new Vector();
/*     */           
/* 148 */           for (byte b = 0; b < this.ncol; b++) {
/* 149 */             vector1.addElement(param1ResultSet.getObject(b + true));
/*     */           }
/*     */           
/* 152 */           this$0.rows.addElement(vector1);
/*     */         } 
/*     */         
/* 155 */         this.colwidth = new int[resultSetMetaData.getColumnCount()];
/* 156 */         for (byte b2 = 0; b2 < this.colwidth.length; b2++) {
/* 157 */           this.colwidth[b2] = resultSetMetaData.getColumnDisplaySize(b2 + true) * this.charW;
/*     */ 
/*     */           
/* 160 */           if (this.colwidth[b2] == 0) {
/* 161 */             this.colwidth[b2] = -1;
/*     */           }
/*     */         } 
/*     */       } catch (Exception exception) {
/* 165 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     public int getRowCount() { return this.this$0.rows.size(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     public int getColCount() { return this.ncol; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     public int getHeaderRowCount() { return 1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 201 */     public int getHeaderColCount() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 212 */     public int getRowHeight(int param1Int) { return -1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     public int getColWidth(int param1Int) { return this.colwidth[param1Int]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 256 */     public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 == 0) ? 8195 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 269 */     public int getColBorder(int param1Int1, int param1Int2) { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 279 */     public Insets getInsets(int param1Int1, int param1Int2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 293 */     public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 303 */     public int getAlignment(int param1Int1, int param1Int2) { return 17; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     public Font getFont(int param1Int1, int param1Int2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 323 */     public Object getObject(int param1Int1, int param1Int2) { return (param1Int1 == 0 && this.this$0.hdrs != null && param1Int2 < this.this$0.hdrs.length) ? this.this$0.hdrs[param1Int2] : ((Vector)this.this$0.rows.elementAt(param1Int1)).elementAt(param1Int2); }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 332 */   private Vector rows = new Vector();
/* 333 */   private String[] hdrs = null;
/*     */   int charW;
/*     */   
/* 336 */   public JDBCTableLens(String paramString1, String paramString2, String paramString3, String paramString4) throws SQLException { Font font = new Font("Dialog", 0, 10);
/* 337 */     FontMetrics fontMetrics = Common.getFontMetrics(font);
/* 338 */     this.charW = fontMetrics.charWidth('M'); Connection connection = DriverManager.getConnection(paramString1, paramString2, paramString3); Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery(paramString4); setTable(new JDBCTable(this, resultSet)); } public JDBCTableLens(ResultSet paramResultSet) { Font font = new Font("Dialog", 0, 10); FontMetrics fontMetrics = Common.getFontMetrics(font); this.charW = fontMetrics.charWidth('M');
/*     */     setTable(new JDBCTable(this, paramResultSet)); }
/*     */ 
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\JDBCTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */