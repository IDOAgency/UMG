package inetsoft.report.lens;

import inetsoft.report.Common;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

public class JDBCTableLens extends AttributeTableLens {
  public void setHeaders(String[] paramArrayOfString) { this.hdrs = paramArrayOfString; }
  
  public void setMapping(String[][] paramArrayOfString) {
    Hashtable hashtable = new Hashtable();
    for (byte b = 0; b < paramArrayOfString.length; b++)
      hashtable.put(paramArrayOfString[b][0], paramArrayOfString[b][1]); 
    setMapping(hashtable);
  }
  
  public void setMapping(Hashtable paramHashtable) {
    if (this.rows.size() > 0) {
      Vector vector = (Vector)this.rows.elementAt(0);
      for (byte b = 0; b < vector.size(); b++) {
        Object object = vector.elementAt(b);
        if (object != null) {
          object = paramHashtable.get(object);
          if (object != null)
            vector.setElementAt(object, b); 
        } 
      } 
    } 
  }
  
  public void trim() {
    for (byte b = 0; b < this.rows.size(); b++) {
      Vector vector = (Vector)this.rows.elementAt(b);
      for (byte b1 = 0; b1 < vector.size(); b1++) {
        Object object = vector.elementAt(b1);
        if (object instanceof String)
          vector.setElementAt(((String)object).trim(), b1); 
      } 
    } 
  }
  
  class JDBCTable extends AbstractTableLens {
    private int charW;
    
    private int ncol;
    
    private int[] colwidth;
    
    private final JDBCTableLens this$0;
    
    public JDBCTable(JDBCTableLens this$0, ResultSet param1ResultSet) {
      this.this$0 = this$0;
      try {
        ResultSetMetaData resultSetMetaData = param1ResultSet.getMetaData();
        this.ncol = resultSetMetaData.getColumnCount();
        Vector vector = new Vector();
        for (byte b1 = 0; b1 < this.ncol; b1++) {
          String str = resultSetMetaData.getColumnLabel(b1 + true);
          vector.addElement(str);
        } 
        this$0.rows.addElement(vector);
        while (param1ResultSet.next()) {
          Vector vector1 = new Vector();
          for (byte b = 0; b < this.ncol; b++)
            vector1.addElement(param1ResultSet.getObject(b + true)); 
          this$0.rows.addElement(vector1);
        } 
        this.colwidth = new int[resultSetMetaData.getColumnCount()];
        for (byte b2 = 0; b2 < this.colwidth.length; b2++) {
          this.colwidth[b2] = resultSetMetaData.getColumnDisplaySize(b2 + true) * this.charW;
          if (this.colwidth[b2] == 0)
            this.colwidth[b2] = -1; 
        } 
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    }
    
    public int getRowCount() { return this.this$0.rows.size(); }
    
    public int getColCount() { return this.ncol; }
    
    public int getHeaderRowCount() { return 1; }
    
    public int getHeaderColCount() { return 0; }
    
    public int getRowHeight(int param1Int) { return -1; }
    
    public int getColWidth(int param1Int) { return this.colwidth[param1Int]; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 == 0) ? 8195 : 0; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return 0; }
    
    public Insets getInsets(int param1Int1, int param1Int2) { return null; }
    
    public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
    
    public int getAlignment(int param1Int1, int param1Int2) { return 17; }
    
    public Font getFont(int param1Int1, int param1Int2) { return null; }
    
    public Object getObject(int param1Int1, int param1Int2) { return (param1Int1 == 0 && this.this$0.hdrs != null && param1Int2 < this.this$0.hdrs.length) ? this.this$0.hdrs[param1Int2] : ((Vector)this.this$0.rows.elementAt(param1Int1)).elementAt(param1Int2); }
  }
  
  private Vector rows = new Vector();
  
  private String[] hdrs = null;
  
  int charW;
  
  public JDBCTableLens(String paramString1, String paramString2, String paramString3, String paramString4) throws SQLException {
    Font font = new Font("Dialog", 0, 10);
    FontMetrics fontMetrics = Common.getFontMetrics(font);
    this.charW = fontMetrics.charWidth('M');
    Connection connection = DriverManager.getConnection(paramString1, paramString2, paramString3);
    Statement statement = connection.createStatement();
    ResultSet resultSet = statement.executeQuery(paramString4);
    setTable(new JDBCTable(this, resultSet));
  }
  
  public JDBCTableLens(ResultSet paramResultSet) {
    Font font = new Font("Dialog", 0, 10);
    FontMetrics fontMetrics = Common.getFontMetrics(font);
    this.charW = fontMetrics.charWidth('M');
    setTable(new JDBCTable(this, paramResultSet));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\JDBCTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */