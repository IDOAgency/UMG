package inetsoft.report.lens;

import inetsoft.report.TextLens;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;

public class StreamTextLens implements TextLens {
  public StreamTextLens(InputStream paramInputStream) throws IOException { this(new InputStreamReader(paramInputStream)); }
  
  public StreamTextLens(File paramFile) throws IOException { this(new FileReader(paramFile)); }
  
  public StreamTextLens(URL paramURL) throws IOException { this(paramURL.openStream()); }
  
  public StreamTextLens(Reader paramReader) throws IOException {
    BufferedReader bufferedReader = new BufferedReader(paramReader);
    String str;
    while ((str = bufferedReader.readLine()) != null)
      this.text += str + "\n"; 
  }
  
  public String getText() { return this.text; }
  
  private String text = "";
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\StreamTextLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */