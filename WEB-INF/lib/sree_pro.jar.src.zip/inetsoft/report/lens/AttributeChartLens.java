package inetsoft.report.lens;

import inetsoft.report.ChartLens;
import inetsoft.report.Common;
import inetsoft.report.internal.Util;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.util.Vector;

public class AttributeChartLens implements ChartLens {
  ChartLens chart;
  
  public AttributeChartLens() {}
  
  public AttributeChartLens(ChartLens paramChartLens) { setChart(paramChartLens); }
  
  public void reset() {
    int i = Math.max(this.chart.getDatasetCount(), this.chart.getDatasetSize());
    this.colors = new Object[i];
    this.images = new Image[i];
    this.labels.removeAllElements();
    this.dlabels.removeAllElements();
    this.xtitle = this.ytitle = null;
    this.style = null;
    this.max = this.min = this.incr = this.mincr = null;
    this.font = null;
    this.grid = null;
    this.show = null;
    this.precision = this.lpos = this.gap = this.border = null;
  }
  
  public void setChart(ChartLens paramChartLens) {
    this.chart = paramChartLens;
    int i = Math.max(paramChartLens.getDatasetCount(), paramChartLens.getDatasetSize());
  }
  
  public ChartLens getChart() { return this.chart; }
  
  public int getDatasetCount() { return this.chart.getDatasetCount(); }
  
  public int getDatasetSize() { return this.chart.getDatasetSize(); }
  
  public Number getData(int paramInt1, int paramInt2) { return this.chart.getData(paramInt1, paramInt2); }
  
  public String getLabel(int paramInt) { return (paramInt < this.labels.size() && this.labels.elementAt(paramInt) != null) ? (String)this.labels.elementAt(paramInt) : this.chart.getLabel(paramInt); }
  
  public void setLabel(int paramInt, String paramString) {
    if (this.labels.size() <= paramInt)
      this.labels.setSize(paramInt + 1); 
    this.labels.setElementAt(paramString, paramInt);
  }
  
  public String getDatasetLabel(int paramInt) { return (paramInt < this.dlabels.size() && this.dlabels.elementAt(paramInt) != null) ? (String)this.dlabels.elementAt(paramInt) : this.chart.getDatasetLabel(paramInt); }
  
  public void setDatasetLabel(int paramInt, String paramString) {
    if (this.dlabels.size() <= paramInt)
      this.dlabels.setSize(paramInt + 1); 
    this.dlabels.setElementAt(paramString, paramInt);
  }
  
  public int getStyle() { return (this.style == null) ? this.chart.getStyle() : this.style.intValue(); }
  
  public void setStyle(int paramInt) { this.style = new Integer(paramInt); }
  
  public Number getMaximum() { return (this.max == null) ? this.chart.getMaximum() : this.max; }
  
  public void setMaximum(Number paramNumber) { this.max = paramNumber; }
  
  public Number getMinimum() { return (this.min == null) ? this.chart.getMinimum() : this.min; }
  
  public void setMinimum(Number paramNumber) { this.min = paramNumber; }
  
  public Number getIncrement() { return (this.incr == null) ? this.chart.getIncrement() : this.incr; }
  
  public void setIncrement(Number paramNumber) { this.incr = paramNumber; }
  
  public Number getMinorIncrement() { return (this.mincr == null) ? this.chart.getMinorIncrement() : this.mincr; }
  
  public void setMinorIncrement(Number paramNumber) { this.mincr = paramNumber; }
  
  public int getGap() { return (this.gap == null) ? this.chart.getGap() : this.gap.intValue(); }
  
  public void setGap(int paramInt) { this.gap = new Integer(paramInt); }
  
  public void setBarAsOneDataset(boolean paramBoolean) { this.showOne = paramBoolean; }
  
  public boolean isBarAsOneDataset() { return this.showOne; }
  
  public Object getColor(int paramInt) {
    int i = getStyle();
    if (this.showOne && Util.isFlatDatasetChart(this))
      paramInt = 0; 
    if (i == 1 && paramInt < this.images.length && this.images[paramInt] != null)
      return this.images[paramInt]; 
    if (this.b_w && (i & 0x1000) == 0)
      return Common.getPaint(paramInt); 
    return (paramInt < this.colors.length && this.colors[paramInt] != null) ? this.colors[paramInt] : this.chart.getColor(paramInt);
  }
  
  public void setColor(int paramInt, Object paramObject) {
    if (paramInt >= this.colors.length) {
      Color[] arrayOfColor = new Color[paramInt + 1];
      System.arraycopy(this.colors, 0, arrayOfColor, 0, this.colors.length);
      this.colors = arrayOfColor;
    } 
    this.colors[paramInt] = paramObject;
  }
  
  public void setBlackWhite(boolean paramBoolean) { this.b_w = paramBoolean; }
  
  public boolean isBlackWhite() { return this.b_w; }
  
  public String getXTitle() { return (this.xtitle == null) ? this.chart.getXTitle() : this.xtitle; }
  
  public void setXTitle(String paramString) { this.xtitle = paramString; }
  
  public String getYTitle() { return (this.ytitle == null) ? this.chart.getYTitle() : this.ytitle; }
  
  public void setYTitle(String paramString) { this.ytitle = paramString; }
  
  public Font getTitleFont() { return (this.font == null) ? this.chart.getTitleFont() : this.font; }
  
  public void setTitleFont(Font paramFont) { this.font = paramFont; }
  
  public int getGridStyle() { return (this.grid == null) ? this.chart.getGridStyle() : this.grid.intValue(); }
  
  public void setGridStyle(int paramInt) { this.grid = new Integer(paramInt); }
  
  public int getBorderStyle() { return (this.border == null) ? this.chart.getBorderStyle() : this.border.intValue(); }
  
  public void setBorderStyle(int paramInt) { this.border = new Integer(paramInt); }
  
  public boolean isShowValue() { return (this.show == null) ? this.chart.isShowValue() : this.show.booleanValue(); }
  
  public void setShowValue(boolean paramBoolean) { this.show = new Boolean(paramBoolean); }
  
  public int getPrecision() { return (this.precision == null) ? this.chart.getPrecision() : this.precision.intValue(); }
  
  public void setPrecision(int paramInt) { this.precision = new Integer(paramInt); }
  
  public void setBarImage(int paramInt, Image paramImage) {
    if (paramInt >= this.images.length) {
      Image[] arrayOfImage = new Image[paramInt + 1];
      System.arraycopy(this.images, 0, arrayOfImage, 0, this.images.length);
      this.images = arrayOfImage;
    } 
    this.images[paramInt] = paramImage;
  }
  
  public int getLegendPosition() { return (this.lpos == null) ? this.chart.getLegendPosition() : this.lpos.intValue(); }
  
  public void setLegendPosition(int paramInt) { this.lpos = new Integer(paramInt); }
  
  public int getStyle(int paramInt) { return (paramInt < this.styles.length) ? this.styles[paramInt % this.styles.length] : 0; }
  
  public void setStyle(int paramInt1, int paramInt2) {
    if (this.styles.length <= paramInt1) {
      int[] arrayOfInt = new int[paramInt1 + 1];
      System.arraycopy(this.styles, 0, arrayOfInt, 0, this.styles.length);
      this.styles = new int[paramInt1 + 1];
      System.arraycopy(arrayOfInt, 0, this.styles, 0, paramInt1);
    } 
    this.styles[paramInt1] = paramInt2;
  }
  
  public Object clone() throws CloneNotSupportedException { return super.clone(); }
  
  Object[] colors = new Object[0];
  
  Vector labels = new Vector();
  
  Vector dlabels = new Vector();
  
  String xtitle;
  
  String ytitle;
  
  Integer style;
  
  Number max;
  
  Number min;
  
  Number incr;
  
  Number mincr;
  
  Font font;
  
  Integer grid;
  
  Boolean show;
  
  Integer precision;
  
  Image[] images = new Image[0];
  
  Integer lpos;
  
  Integer gap;
  
  Integer border;
  
  boolean b_w = false;
  
  boolean showOne = false;
  
  int[] styles = new int[0];
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\AttributeChartLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */