/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import inetsoft.report.ChartLens;
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.internal.Util;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Image;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributeChartLens
/*     */   implements ChartLens
/*     */ {
/*     */   ChartLens chart;
/*     */   
/*     */   public AttributeChartLens() {}
/*     */   
/*  43 */   public AttributeChartLens(ChartLens paramChartLens) { setChart(paramChartLens); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/*  50 */     int i = Math.max(this.chart.getDatasetCount(), this.chart.getDatasetSize());
/*  51 */     this.colors = new Object[i];
/*  52 */     this.images = new Image[i];
/*     */     
/*  54 */     this.labels.removeAllElements();
/*  55 */     this.dlabels.removeAllElements();
/*     */     
/*  57 */     this.xtitle = this.ytitle = null;
/*  58 */     this.style = null;
/*  59 */     this.max = this.min = this.incr = this.mincr = null;
/*  60 */     this.font = null;
/*  61 */     this.grid = null;
/*  62 */     this.show = null;
/*  63 */     this.precision = this.lpos = this.gap = this.border = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChart(ChartLens paramChartLens) {
/*  71 */     this.chart = paramChartLens;
/*  72 */     int i = Math.max(paramChartLens.getDatasetCount(), paramChartLens.getDatasetSize());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public ChartLens getChart() { return this.chart; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public int getDatasetCount() { return this.chart.getDatasetCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public int getDatasetSize() { return this.chart.getDatasetSize(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public Number getData(int paramInt1, int paramInt2) { return this.chart.getData(paramInt1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public String getLabel(int paramInt) { return (paramInt < this.labels.size() && this.labels.elementAt(paramInt) != null) ? (String)this.labels.elementAt(paramInt) : this.chart.getLabel(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabel(int paramInt, String paramString) {
/* 126 */     if (this.labels.size() <= paramInt) {
/* 127 */       this.labels.setSize(paramInt + 1);
/*     */     }
/*     */     
/* 130 */     this.labels.setElementAt(paramString, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public String getDatasetLabel(int paramInt) { return (paramInt < this.dlabels.size() && this.dlabels.elementAt(paramInt) != null) ? (String)this.dlabels.elementAt(paramInt) : this.chart.getDatasetLabel(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatasetLabel(int paramInt, String paramString) {
/* 147 */     if (this.dlabels.size() <= paramInt) {
/* 148 */       this.dlabels.setSize(paramInt + 1);
/*     */     }
/*     */     
/* 151 */     this.dlabels.setElementAt(paramString, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public int getStyle() { return (this.style == null) ? this.chart.getStyle() : this.style.intValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   public void setStyle(int paramInt) { this.style = new Integer(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   public Number getMaximum() { return (this.max == null) ? this.chart.getMaximum() : this.max; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 186 */   public void setMaximum(Number paramNumber) { this.max = paramNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   public Number getMinimum() { return (this.min == null) ? this.chart.getMinimum() : this.min; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   public void setMinimum(Number paramNumber) { this.min = paramNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 212 */   public Number getIncrement() { return (this.incr == null) ? this.chart.getIncrement() : this.incr; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 220 */   public void setIncrement(Number paramNumber) { this.incr = paramNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 229 */   public Number getMinorIncrement() { return (this.mincr == null) ? this.chart.getMinorIncrement() : this.mincr; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 237 */   public void setMinorIncrement(Number paramNumber) { this.mincr = paramNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 246 */   public int getGap() { return (this.gap == null) ? this.chart.getGap() : this.gap.intValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   public void setGap(int paramInt) { this.gap = new Integer(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 270 */   public void setBarAsOneDataset(boolean paramBoolean) { this.showOne = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 277 */   public boolean isBarAsOneDataset() { return this.showOne; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getColor(int paramInt) {
/* 293 */     int i = getStyle();
/*     */ 
/*     */     
/* 296 */     if (this.showOne && Util.isFlatDatasetChart(this)) {
/* 297 */       paramInt = 0;
/*     */     }
/*     */     
/* 300 */     if (i == 1 && paramInt < this.images.length && this.images[paramInt] != null)
/*     */     {
/* 302 */       return this.images[paramInt];
/*     */     }
/*     */     
/* 305 */     if (this.b_w && (i & 0x1000) == 0) {
/* 306 */       return Common.getPaint(paramInt);
/*     */     }
/*     */     
/* 309 */     return (paramInt < this.colors.length && this.colors[paramInt] != null) ? this.colors[paramInt] : this.chart.getColor(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColor(int paramInt, Object paramObject) {
/* 319 */     if (paramInt >= this.colors.length) {
/* 320 */       Color[] arrayOfColor = new Color[paramInt + 1];
/* 321 */       System.arraycopy(this.colors, 0, arrayOfColor, 0, this.colors.length);
/* 322 */       this.colors = arrayOfColor;
/*     */     } 
/*     */     
/* 325 */     this.colors[paramInt] = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 336 */   public void setBlackWhite(boolean paramBoolean) { this.b_w = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 344 */   public boolean isBlackWhite() { return this.b_w; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 352 */   public String getXTitle() { return (this.xtitle == null) ? this.chart.getXTitle() : this.xtitle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 360 */   public void setXTitle(String paramString) { this.xtitle = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 368 */   public String getYTitle() { return (this.ytitle == null) ? this.chart.getYTitle() : this.ytitle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 376 */   public void setYTitle(String paramString) { this.ytitle = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 385 */   public Font getTitleFont() { return (this.font == null) ? this.chart.getTitleFont() : this.font; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 393 */   public void setTitleFont(Font paramFont) { this.font = paramFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 404 */   public int getGridStyle() { return (this.grid == null) ? this.chart.getGridStyle() : this.grid.intValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 412 */   public void setGridStyle(int paramInt) { this.grid = new Integer(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 421 */   public int getBorderStyle() { return (this.border == null) ? this.chart.getBorderStyle() : this.border.intValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 429 */   public void setBorderStyle(int paramInt) { this.border = new Integer(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 438 */   public boolean isShowValue() { return (this.show == null) ? this.chart.isShowValue() : this.show.booleanValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 446 */   public void setShowValue(boolean paramBoolean) { this.show = new Boolean(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 455 */   public int getPrecision() { return (this.precision == null) ? this.chart.getPrecision() : this.precision.intValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 463 */   public void setPrecision(int paramInt) { this.precision = new Integer(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBarImage(int paramInt, Image paramImage) {
/* 472 */     if (paramInt >= this.images.length) {
/* 473 */       Image[] arrayOfImage = new Image[paramInt + 1];
/* 474 */       System.arraycopy(this.images, 0, arrayOfImage, 0, this.images.length);
/* 475 */       this.images = arrayOfImage;
/*     */     } 
/*     */     
/* 478 */     this.images[paramInt] = paramImage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 487 */   public int getLegendPosition() { return (this.lpos == null) ? this.chart.getLegendPosition() : this.lpos.intValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 495 */   public void setLegendPosition(int paramInt) { this.lpos = new Integer(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 505 */   public int getStyle(int paramInt) { return (paramInt < this.styles.length) ? this.styles[paramInt % this.styles.length] : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStyle(int paramInt1, int paramInt2) {
/* 514 */     if (this.styles.length <= paramInt1) {
/* 515 */       int[] arrayOfInt = new int[paramInt1 + 1];
/* 516 */       System.arraycopy(this.styles, 0, arrayOfInt, 0, this.styles.length);
/* 517 */       this.styles = new int[paramInt1 + 1];
/* 518 */       System.arraycopy(arrayOfInt, 0, this.styles, 0, paramInt1);
/*     */     } 
/* 520 */     this.styles[paramInt1] = paramInt2;
/*     */   }
/*     */ 
/*     */   
/* 524 */   public Object clone() throws CloneNotSupportedException { return super.clone(); }
/*     */ 
/*     */ 
/*     */   
/* 528 */   Object[] colors = new Object[0];
/* 529 */   Vector labels = new Vector();
/* 530 */   Vector dlabels = new Vector();
/*     */   
/*     */   String xtitle;
/*     */   
/*     */   String ytitle;
/*     */   Integer style;
/*     */   Number max;
/*     */   Number min;
/* 538 */   Image[] images = new Image[0]; Number incr; Number mincr; Font font; Integer grid; Boolean show; Integer precision;
/*     */   Integer lpos;
/*     */   Integer gap;
/*     */   Integer border;
/*     */   boolean b_w = false;
/*     */   boolean showOne = false;
/* 544 */   int[] styles = new int[0];
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\AttributeChartLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */