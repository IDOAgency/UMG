package inetsoft.report.lens.jbcl30;

import com.borland.jbcl.control.GridControl;
import inetsoft.report.lens.AbstractTableLens;
import inetsoft.report.lens.AttributeTableLens;
import inetsoft.report.painter.ButtonPresenter;
import inetsoft.report.painter.PresenterPainter;
import java.awt.Color;
import java.awt.Font;

public class GridControlLens extends AttributeTableLens {
  protected GridControl table;
  
  boolean header3d;
  
  boolean tostring;
  
  public GridControlLens(GridControl paramGridControl) {
    this.header3d = false;
    this.tostring = true;
    setTable(new Table(this));
    this.table = paramGridControl;
  }
  
  public void setShow3DHeader(boolean paramBoolean) { this.header3d = paramBoolean; }
  
  public boolean isShow3DHeader() { return this.header3d; }
  
  public void setForceString(boolean paramBoolean) { this.tostring = paramBoolean; }
  
  public boolean isForceString() { return this.tostring; }
  
  class Table extends AbstractTableLens {
    private final GridControlLens this$0;
    
    Table(GridControlLens this$0) { this.this$0 = this$0; }
    
    public int getRowCount() { return this.this$0.table.getRowCount() + getHeaderRowCount(); }
    
    public int getColCount() { return this.this$0.table.getColumnCount() + getHeaderColCount(); }
    
    public int getHeaderRowCount() { return this.this$0.table.isColumnHeaderVisible() ? 1 : 0; }
    
    public int getHeaderColCount() { return this.this$0.table.isRowHeaderVisible() ? 1 : 0; }
    
    public int getRowHeight(int param1Int) { return (param1Int < getHeaderRowCount()) ? this.this$0.table.getColumnHeaderHeight() : this.this$0.table.getRowSizes().getSize(rowIndex(param1Int)); }
    
    public int getColWidth(int param1Int) { return (param1Int < getHeaderColCount()) ? this.this$0.table.getRowHeaderWidth() : this.this$0.table.getColumnSizes().getSize(colIndex(param1Int)); }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return this.this$0.table.getGridLineColor(); }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return this.this$0.table.getGridLineColor(); }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return (this.this$0.table.isHorizontalLines() && this.this$0.table.isGridVisible()) ? 4097 : 0; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return (this.this$0.table.isVerticalLines() && this.this$0.table.isGridVisible()) ? 4097 : 0; }
    
    public Font getFont(int param1Int1, int param1Int2) { return this.this$0.table.getFont(); }
    
    public Color getForeground(int param1Int1, int param1Int2) { return this.this$0.table.getForeground(); }
    
    public Color getBackground(int param1Int1, int param1Int2) {
      if (param1Int1 < getHeaderRowCount() || param1Int2 < getHeaderColCount())
        return Color.lightGray; 
      return this.this$0.table.getBackground();
    }
    
    public Object getObject(int param1Int1, int param1Int2) {
      Object object;
      if (param1Int2 < getHeaderColCount() && param1Int1 < getHeaderRowCount()) {
        object = "";
      } else if (param1Int2 < getHeaderColCount()) {
        object = this.this$0.table.getRowHeaderView().getModel().get(rowIndex(param1Int1));
        object = (object == null) ? Integer.toString(rowIndex(param1Int2)) : object;
        if (this.this$0.header3d)
          object = new PresenterPainter(object, new ButtonPresenter()); 
      } else if (param1Int1 < getHeaderRowCount()) {
        object = this.this$0.table.getColumnHeaderView().getModel().get(colIndex(param1Int2));
        object = (object == null) ? ("Column " + colIndex(param1Int2)) : object;
        if (this.this$0.header3d)
          object = new PresenterPainter(object, new ButtonPresenter()); 
      } else {
        object = this.this$0.table.getModel().get(rowIndex(param1Int1), colIndex(param1Int2));
      } 
      if (!this.this$0.tostring)
        return object; 
      if (object == null)
        return null; 
      String str = object.getClass().getName();
      if (str.startsWith("[") || str.startsWith("java.") || str.startsWith("inetsoft.report"))
        return object; 
      return object.toString();
    }
    
    protected int rowIndex(int param1Int) { return param1Int - getHeaderRowCount(); }
    
    protected int colIndex(int param1Int) { return param1Int - getHeaderColCount(); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\jbcl30\GridControlLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */