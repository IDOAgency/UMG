/*     */ package inetsoft.report.lens.jbcl30;
/*     */ 
/*     */ import com.borland.dx.dataset.Column;
/*     */ import com.borland.dx.dataset.DataSet;
/*     */ import com.borland.dx.dataset.DataSetException;
/*     */ import com.borland.dx.dataset.Variant;
/*     */ import com.borland.dx.text.VariantFormatter;
/*     */ import inetsoft.report.lens.AbstractTableLens;
/*     */ import inetsoft.report.lens.AttributeTableLens;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSetLens
/*     */   extends AttributeTableLens
/*     */ {
/*     */   protected DataSet table;
/*     */   protected boolean caption;
/*     */   protected boolean useFormatter;
/*     */   protected int[] colmap;
/*     */   
/*     */   public DataSetLens(DataSet paramDataSet) {
/* 207 */     this.caption = false;
/* 208 */     this.useFormatter = false;
/*     */     setTable(new Table(this));
/*     */     this.table = paramDataSet;
/*     */     try {
/*     */       paramDataSet.open();
/*     */       Vector vector = new Vector();
/*     */       int i = paramDataSet.getColumnCount();
/*     */       for (byte b1 = 0; b1 < i; b1++) {
/*     */         Column column = paramDataSet.getColumn(b1);
/*     */         if (column.getVisible() != 0)
/*     */           vector.addElement(new Integer(b1)); 
/*     */       } 
/*     */       this.colmap = new int[vector.size()];
/*     */       for (byte b2 = 0; b2 < this.colmap.length; b2++)
/*     */         this.colmap[b2] = ((Integer)vector.elementAt(b2)).intValue(); 
/*     */     } catch (DataSetException dataSetException) {
/*     */       dataSetException.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public DataSetLens(DataSet paramDataSet, boolean paramBoolean) {
/*     */     this(paramDataSet);
/*     */     this.caption = paramBoolean;
/*     */   }
/*     */   
/*     */   public void setUseFormatter(boolean paramBoolean) { this.useFormatter = paramBoolean; }
/*     */   
/*     */   public boolean isUseFormatter() { return this.useFormatter; }
/*     */   
/*     */   public void setUseCaption(boolean paramBoolean) { this.caption = paramBoolean; }
/*     */   
/*     */   public boolean isUseCaption() { return this.caption; }
/*     */   
/*     */   class Table extends AbstractTableLens {
/*     */     private final DataSetLens this$0;
/*     */     
/*     */     Table(DataSetLens this$0) { this.this$0 = this$0; }
/*     */     
/*     */     public int getRowCount() {
/*     */       try {
/*     */         return this.this$0.table.getRowCount() + getHeaderRowCount();
/*     */       } catch (Exception exception) {
/*     */         exception.printStackTrace();
/*     */         return 1;
/*     */       } 
/*     */     }
/*     */     
/*     */     public int getColCount() { return this.this$0.colmap.length + getHeaderColCount(); }
/*     */     
/*     */     public int getHeaderRowCount() { return 1; }
/*     */     
/*     */     public int getHeaderColCount() { return 0; }
/*     */     
/*     */     public Object getObject(int param1Int1, int param1Int2) {
/*     */       try {
/*     */         if (param1Int1 < getHeaderRowCount())
/*     */           return this.this$0.caption ? this.this$0.table.getColumn(colIndex(param1Int2)).getCaption() : this.this$0.table.getColumn(colIndex(param1Int2)).getColumnName(); 
/*     */         if (param1Int2 < getHeaderColCount())
/*     */           return Integer.toString(rowIndex(param1Int1)); 
/*     */         Variant variant = new Variant();
/*     */         this.this$0.table.getDisplayVariant(colIndex(param1Int2), rowIndex(param1Int1), variant);
/*     */         if (this.this$0.useFormatter) {
/*     */           VariantFormatter variantFormatter = this.this$0.table.getColumn(colIndex(param1Int2)).getFormatter();
/*     */           if (variantFormatter != null && variantFormatter instanceof VariantFormatter)
/*     */             return variantFormatter.format(variant); 
/*     */         } 
/*     */         return variant.getDisplayValue();
/*     */       } catch (Exception exception) {
/*     */         exception.printStackTrace();
/*     */         return null;
/*     */       } 
/*     */     }
/*     */     
/*     */     protected int rowIndex(int param1Int) { return param1Int - getHeaderRowCount(); }
/*     */     
/*     */     protected int colIndex(int param1Int) { return this.this$0.colmap[param1Int - getHeaderColCount()]; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\jbcl30\DataSetLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */