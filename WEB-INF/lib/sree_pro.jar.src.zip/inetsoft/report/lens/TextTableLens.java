package inetsoft.report.lens;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.text.Format;
import java.util.StringTokenizer;
import java.util.Vector;

public class TextTableLens extends AttributeTableLens {
  public TextTableLens(InputStream paramInputStream) throws IOException { this(paramInputStream, null, null, null); }
  
  public TextTableLens(InputStream paramInputStream, String paramString) throws IOException { this(paramInputStream, paramString, null, null); }
  
  public TextTableLens(InputStream paramInputStream, String paramString, int[] paramArrayOfInt) throws IOException { this(paramInputStream, paramString, paramArrayOfInt, null); }
  
  public TextTableLens(InputStream paramInputStream, String paramString, int[] paramArrayOfInt, Format[] paramArrayOfFormat) throws IOException { this(new InputStreamReader(paramInputStream), paramString, paramArrayOfInt, paramArrayOfFormat); }
  
  public TextTableLens(Reader paramReader, String paramString, int[] paramArrayOfInt, Format[] paramArrayOfFormat) throws IOException {
    if (paramString != null)
      this.delim = paramString; 
    if (paramArrayOfInt != null) {
      int i = 0;
      for (byte b1 = 0; b1 < paramArrayOfInt.length; b1++)
        i = Math.max(i, paramArrayOfInt[b1]); 
      this.colsmask = new boolean[i + 1];
      for (byte b2 = 0; b2 < paramArrayOfInt.length; b2++)
        this.colsmask[paramArrayOfInt[b2]] = true; 
    } 
    this.fmts = paramArrayOfFormat;
    setTable(new TextTable(this, paramReader));
  }
  
  public void setHeaderRowCount(int paramInt) { this.hrow = paramInt; }
  
  public void setheaderColCount(int paramInt) { this.hcol = paramInt; }
  
  class TextTable extends AbstractTableLens {
    private final TextTableLens this$0;
    
    public TextTable(TextTableLens this$0, Reader param1Reader) throws IOException {
      this.this$0 = this$0;
      BufferedReader bufferedReader = new BufferedReader(param1Reader);
      try {
        String str;
        while ((str = bufferedReader.readLine()) != null) {
          Vector vector = new Vector();
          StringTokenizer stringTokenizer = new StringTokenizer(str, this$0.delim);
          for (byte b = 0; stringTokenizer.hasMoreTokens(); b++) {
            String str1 = stringTokenizer.nextToken();
            if (str1.equals("null"))
              str1 = null; 
            if (this$0.includeColumn(b))
              if (this$0.fmts != null && b < this$0.fmts.length && this$0.fmts[b] != null) {
                try {
                  Object object = this$0.fmts[b].parseObject(str1);
                  vector.addElement(str1);
                } catch (Exception exception) {
                  vector.addElement(str1);
                } 
              } else {
                vector.addElement(str1);
              }  
          } 
          this$0.rows.addElement(vector);
          this$0.ncol = Math.max(vector.size(), this$0.ncol);
          if (this$0.maxr > 0 && this$0.rows.size() >= this$0.maxr)
            break; 
        } 
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    }
    
    public int getRowCount() { return this.this$0.rows.size(); }
    
    public int getColCount() { return this.this$0.ncol; }
    
    public int getHeaderRowCount() { return this.this$0.hrow; }
    
    public int getHeaderColCount() { return this.this$0.hcol; }
    
    public int getRowHeight(int param1Int) { return -1; }
    
    public int getColWidth(int param1Int) { return -1; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 == 0) ? 8195 : 0; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return 0; }
    
    public Insets getInsets(int param1Int1, int param1Int2) { return null; }
    
    public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
    
    public int getAlignment(int param1Int1, int param1Int2) { return 17; }
    
    public Font getFont(int param1Int1, int param1Int2) { return null; }
    
    public Object getObject(int param1Int1, int param1Int2) {
      Vector vector = (Vector)this.this$0.rows.elementAt(param1Int1);
      return (param1Int2 < vector.size()) ? vector.elementAt(param1Int2) : null;
    }
  }
  
  boolean includeColumn(int paramInt) { return (this.colsmask == null || (paramInt < this.colsmask.length && this.colsmask[paramInt])); }
  
  Vector rows = new Vector();
  
  Format[] fmts = null;
  
  int ncol = 0;
  
  int hrow = 0, hcol = 0;
  
  int maxr = 0;
  
  String delim = "\t";
  
  boolean[] colsmask;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\TextTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */