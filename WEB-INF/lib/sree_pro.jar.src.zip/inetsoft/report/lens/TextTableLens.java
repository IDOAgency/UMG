/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.text.Format;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextTableLens
/*     */   extends AttributeTableLens
/*     */ {
/*  37 */   public TextTableLens(InputStream paramInputStream) throws IOException { this(paramInputStream, null, null, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public TextTableLens(InputStream paramInputStream, String paramString) throws IOException { this(paramInputStream, paramString, null, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public TextTableLens(InputStream paramInputStream, String paramString, int[] paramArrayOfInt) throws IOException { this(paramInputStream, paramString, paramArrayOfInt, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public TextTableLens(InputStream paramInputStream, String paramString, int[] paramArrayOfInt, Format[] paramArrayOfFormat) throws IOException { this(new InputStreamReader(paramInputStream), paramString, paramArrayOfInt, paramArrayOfFormat); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextTableLens(Reader paramReader, String paramString, int[] paramArrayOfInt, Format[] paramArrayOfFormat) throws IOException {
/*  84 */     if (paramString != null) {
/*  85 */       this.delim = paramString;
/*     */     }
/*     */     
/*  88 */     if (paramArrayOfInt != null) {
/*  89 */       int i = 0;
/*  90 */       for (byte b1 = 0; b1 < paramArrayOfInt.length; b1++) {
/*  91 */         i = Math.max(i, paramArrayOfInt[b1]);
/*     */       }
/*     */       
/*  94 */       this.colsmask = new boolean[i + 1];
/*  95 */       for (byte b2 = 0; b2 < paramArrayOfInt.length; b2++) {
/*  96 */         this.colsmask[paramArrayOfInt[b2]] = true;
/*     */       }
/*     */     } 
/*     */     
/* 100 */     this.fmts = paramArrayOfFormat;
/* 101 */     setTable(new TextTable(this, paramReader));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public void setHeaderRowCount(int paramInt) { this.hrow = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public void setheaderColCount(int paramInt) { this.hcol = paramInt; }
/*     */ 
/*     */ 
/*     */   
/*     */   class TextTable
/*     */     extends AbstractTableLens
/*     */   {
/*     */     private final TextTableLens this$0;
/*     */ 
/*     */ 
/*     */     
/*     */     public TextTable(TextTableLens this$0, Reader param1Reader) throws IOException {
/* 129 */       this.this$0 = this$0;
/* 130 */       BufferedReader bufferedReader = new BufferedReader(param1Reader);
/*     */       
/*     */       try {
/*     */         String str;
/*     */         
/* 135 */         while ((str = bufferedReader.readLine()) != null) {
/* 136 */           Vector vector = new Vector();
/*     */           
/* 138 */           StringTokenizer stringTokenizer = new StringTokenizer(str, this$0.delim);
/* 139 */           for (byte b = 0; stringTokenizer.hasMoreTokens(); b++) {
/* 140 */             String str1 = stringTokenizer.nextToken();
/* 141 */             if (str1.equals("null")) {
/* 142 */               str1 = null;
/*     */             }
/*     */             
/* 145 */             if (this$0.includeColumn(b)) {
/* 146 */               if (this$0.fmts != null && b < this$0.fmts.length && this$0.fmts[b] != null) {
/*     */                 try {
/* 148 */                   Object object = this$0.fmts[b].parseObject(str1);
/* 149 */                   vector.addElement(str1);
/*     */                 } catch (Exception exception) {
/* 151 */                   vector.addElement(str1);
/*     */                 } 
/*     */               } else {
/*     */                 
/* 155 */                 vector.addElement(str1);
/*     */               } 
/*     */             }
/*     */           } 
/*     */           
/* 160 */           this$0.rows.addElement(vector);
/* 161 */           this$0.ncol = Math.max(vector.size(), this$0.ncol);
/*     */           
/* 163 */           if (this$0.maxr > 0 && this$0.rows.size() >= this$0.maxr) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } catch (Exception exception) {
/* 168 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     public int getRowCount() { return this.this$0.rows.size(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     public int getColCount() { return this.this$0.ncol; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     public int getHeaderRowCount() { return this.this$0.hrow; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     public int getHeaderColCount() { return this.this$0.hcol; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     public int getRowHeight(int param1Int) { return -1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 226 */     public int getColWidth(int param1Int) { return -1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 236 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 246 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 259 */     public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 == 0) ? 8195 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 272 */     public int getColBorder(int param1Int1, int param1Int2) { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 282 */     public Insets getInsets(int param1Int1, int param1Int2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 296 */     public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 306 */     public int getAlignment(int param1Int1, int param1Int2) { return 17; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 316 */     public Font getFont(int param1Int1, int param1Int2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getObject(int param1Int1, int param1Int2) {
/* 326 */       Vector vector = (Vector)this.this$0.rows.elementAt(param1Int1);
/* 327 */       return (param1Int2 < vector.size()) ? vector.elementAt(param1Int2) : null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 335 */   boolean includeColumn(int paramInt) { return (this.colsmask == null || (paramInt < this.colsmask.length && this.colsmask[paramInt])); }
/*     */ 
/*     */   
/* 338 */   Vector rows = new Vector();
/* 339 */   Format[] fmts = null;
/* 340 */   int ncol = 0;
/* 341 */   int hrow = 0, hcol = 0;
/* 342 */   int maxr = 0;
/* 343 */   String delim = "\t";
/*     */   boolean[] colsmask;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\TextTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */