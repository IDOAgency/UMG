/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultTableLens
/*     */   extends AttributeTableLens
/*     */ {
/*     */   Object[][] values;
/*     */   int nrow;
/*     */   int ncol;
/*     */   int hrow;
/*     */   int hcol;
/*     */   
/*  32 */   public DefaultTableLens() { this(0, 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultTableLens(int paramInt1, int paramInt2) {
/*  41 */     super.setTable(new Table(this, paramInt1, paramInt2));
/*  42 */     setCached(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultTableLens(TableLens paramTableLens) {
/*  49 */     super.setTable(new Table(this, paramTableLens.getRowCount(), paramTableLens.getColCount()));
/*  50 */     setCached(false);
/*     */     
/*  52 */     for (byte b = 0; b < paramTableLens.getRowCount(); b++) {
/*  53 */       for (byte b1 = 0; b1 < paramTableLens.getColCount(); b1++) {
/*  54 */         if (!b) {
/*  55 */           setColWidth(b1, paramTableLens.getColWidth(b1));
/*     */         }
/*     */         
/*  58 */         setObject(b, b1, paramTableLens.getObject(b, b1));
/*  59 */         setRowBorder(b, b1, paramTableLens.getRowBorder(b, b1));
/*  60 */         setColBorder(b, b1, paramTableLens.getColBorder(b, b1));
/*  61 */         setRowBorderColor(b, b1, paramTableLens.getRowBorderColor(b, b1));
/*  62 */         setColBorderColor(b, b1, paramTableLens.getColBorderColor(b, b1));
/*  63 */         setInsets(b, b1, paramTableLens.getInsets(b, b1));
/*  64 */         setAlignment(b, b1, paramTableLens.getAlignment(b, b1));
/*  65 */         setFont(b, b1, paramTableLens.getFont(b, b1));
/*  66 */         setLineWrap(b, b1, paramTableLens.isLineWrap(b, b1));
/*  67 */         setForeground(b, b1, paramTableLens.getForeground(b, b1));
/*  68 */         setBackground(b, b1, paramTableLens.getBackground(b, b1));
/*     */       } 
/*     */       
/*  71 */       setRowHeight(b, paramTableLens.getRowHeight(b));
/*     */     } 
/*     */     
/*  74 */     setHeaderRowCount(paramTableLens.getHeaderRowCount());
/*  75 */     setHeaderColCount(paramTableLens.getHeaderColCount());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultTableLens(Object[][] paramArrayOfObject) {
/*  84 */     setCached(false);
/*  85 */     setData(paramArrayOfObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public void setTable(TableLens paramTableLens) { throw new RuntimeException("setTable() not allowed on DefaultTableLens"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDimension(int paramInt1, int paramInt2) {
/* 102 */     if (paramInt1 != getRowCount() || paramInt2 != getColCount()) {
/* 103 */       super.setTable(new Table(this, paramInt1, paramInt2));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowCount(int paramInt) {
/* 112 */     if (paramInt != getRowCount()) {
/* 113 */       super.setTable(new Table(this, paramInt, getColCount()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColCount(int paramInt) {
/* 122 */     if (paramInt != getColCount()) {
/* 123 */       super.setTable(new Table(this, getRowCount(), paramInt));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public void setHeaderRowCount(int paramInt) { this.hrow = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public void setHeaderColCount(int paramInt) { this.hcol = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public void setObject(int paramInt1, int paramInt2, Object paramObject) { this.values[paramInt1][paramInt2] = paramObject; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setData(Object[][] paramArrayOfObject) {
/* 159 */     int i = 0;
/* 160 */     for (byte b1 = 0; b1 < paramArrayOfObject.length; b1++) {
/* 161 */       i = Math.max(i, paramArrayOfObject[b1].length);
/*     */     }
/*     */     
/* 164 */     Object[][] arrayOfObject = this.values;
/* 165 */     super.setTable(new Table(this, paramArrayOfObject.length, i));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     if (arrayOfObject != null) {
/* 171 */       for (byte b = 0; b < this.values.length && b < arrayOfObject.length; b++) {
/* 172 */         System.arraycopy(arrayOfObject[b], 0, this.values[b], 0, Math.min(this.values[b].length, arrayOfObject[b].length));
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 178 */     for (byte b2 = 0; b2 < paramArrayOfObject.length; b2++) {
/* 179 */       for (byte b = 0; b < paramArrayOfObject[b2].length; b++)
/* 180 */         setObject(b2, b, paramArrayOfObject[b2][b]); 
/*     */     } 
/*     */   }
/*     */   
/*     */   class Table
/*     */     extends AbstractTableLens {
/*     */     public Table(DefaultTableLens this$0, int param1Int1, int param1Int2) {
/* 187 */       this.this$0 = this$0;
/* 188 */       this$0.values = new Object[this$0.nrow = param1Int1][this$0.ncol = param1Int2];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private final DefaultTableLens this$0;
/*     */ 
/*     */ 
/*     */     
/* 197 */     public int getRowCount() { return this.this$0.nrow; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 206 */     public int getColCount() { return this.this$0.ncol; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     public Object getObject(int param1Int1, int param1Int2) { return this.this$0.values[param1Int1][param1Int2]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     public int getHeaderRowCount() { return this.this$0.hrow; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     public int getHeaderColCount() { return this.this$0.hcol; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\DefaultTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */