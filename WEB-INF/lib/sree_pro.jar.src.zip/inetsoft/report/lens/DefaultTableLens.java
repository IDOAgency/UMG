package inetsoft.report.lens;

import inetsoft.report.TableLens;

public class DefaultTableLens extends AttributeTableLens {
  Object[][] values;
  
  int nrow;
  
  int ncol;
  
  int hrow;
  
  int hcol;
  
  public DefaultTableLens() { this(0, 0); }
  
  public DefaultTableLens(int paramInt1, int paramInt2) {
    super.setTable(new Table(this, paramInt1, paramInt2));
    setCached(false);
  }
  
  public DefaultTableLens(TableLens paramTableLens) {
    super.setTable(new Table(this, paramTableLens.getRowCount(), paramTableLens.getColCount()));
    setCached(false);
    for (byte b = 0; b < paramTableLens.getRowCount(); b++) {
      for (byte b1 = 0; b1 < paramTableLens.getColCount(); b1++) {
        if (!b)
          setColWidth(b1, paramTableLens.getColWidth(b1)); 
        setObject(b, b1, paramTableLens.getObject(b, b1));
        setRowBorder(b, b1, paramTableLens.getRowBorder(b, b1));
        setColBorder(b, b1, paramTableLens.getColBorder(b, b1));
        setRowBorderColor(b, b1, paramTableLens.getRowBorderColor(b, b1));
        setColBorderColor(b, b1, paramTableLens.getColBorderColor(b, b1));
        setInsets(b, b1, paramTableLens.getInsets(b, b1));
        setAlignment(b, b1, paramTableLens.getAlignment(b, b1));
        setFont(b, b1, paramTableLens.getFont(b, b1));
        setLineWrap(b, b1, paramTableLens.isLineWrap(b, b1));
        setForeground(b, b1, paramTableLens.getForeground(b, b1));
        setBackground(b, b1, paramTableLens.getBackground(b, b1));
      } 
      setRowHeight(b, paramTableLens.getRowHeight(b));
    } 
    setHeaderRowCount(paramTableLens.getHeaderRowCount());
    setHeaderColCount(paramTableLens.getHeaderColCount());
  }
  
  public DefaultTableLens(Object[][] paramArrayOfObject) {
    setCached(false);
    setData(paramArrayOfObject);
  }
  
  public void setTable(TableLens paramTableLens) { throw new RuntimeException("setTable() not allowed on DefaultTableLens"); }
  
  public void setDimension(int paramInt1, int paramInt2) {
    if (paramInt1 != getRowCount() || paramInt2 != getColCount())
      super.setTable(new Table(this, paramInt1, paramInt2)); 
  }
  
  public void setRowCount(int paramInt) {
    if (paramInt != getRowCount())
      super.setTable(new Table(this, paramInt, getColCount())); 
  }
  
  public void setColCount(int paramInt) {
    if (paramInt != getColCount())
      super.setTable(new Table(this, getRowCount(), paramInt)); 
  }
  
  public void setHeaderRowCount(int paramInt) { this.hrow = paramInt; }
  
  public void setHeaderColCount(int paramInt) { this.hcol = paramInt; }
  
  public void setObject(int paramInt1, int paramInt2, Object paramObject) { this.values[paramInt1][paramInt2] = paramObject; }
  
  public void setData(Object[][] paramArrayOfObject) {
    int i = 0;
    for (byte b1 = 0; b1 < paramArrayOfObject.length; b1++)
      i = Math.max(i, paramArrayOfObject[b1].length); 
    Object[][] arrayOfObject = this.values;
    super.setTable(new Table(this, paramArrayOfObject.length, i));
    if (arrayOfObject != null)
      for (byte b = 0; b < this.values.length && b < arrayOfObject.length; b++)
        System.arraycopy(arrayOfObject[b], 0, this.values[b], 0, Math.min(this.values[b].length, arrayOfObject[b].length));  
    for (byte b2 = 0; b2 < paramArrayOfObject.length; b2++) {
      for (byte b = 0; b < paramArrayOfObject[b2].length; b++)
        setObject(b2, b, paramArrayOfObject[b2][b]); 
    } 
  }
  
  class Table extends AbstractTableLens {
    private final DefaultTableLens this$0;
    
    public Table(DefaultTableLens this$0, int param1Int1, int param1Int2) {
      this.this$0 = this$0;
      this$0.values = new Object[this$0.nrow = param1Int1][this$0.ncol = param1Int2];
    }
    
    public int getRowCount() { return this.this$0.nrow; }
    
    public int getColCount() { return this.this$0.ncol; }
    
    public Object getObject(int param1Int1, int param1Int2) { return this.this$0.values[param1Int1][param1Int2]; }
    
    public int getHeaderRowCount() { return this.this$0.hrow; }
    
    public int getHeaderColCount() { return this.this$0.hcol; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\DefaultTableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */