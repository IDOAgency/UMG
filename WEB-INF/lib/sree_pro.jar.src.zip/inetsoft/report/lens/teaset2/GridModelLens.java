package inetsoft.report.lens.teaset2;

import inetsoft.grid.model.GridModel;
import inetsoft.report.lens.AbstractTableLens;
import inetsoft.report.lens.AttributeTableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

public class GridModelLens extends AttributeTableLens {
  GridModel tbl;
  
  public GridModelLens(GridModel paramGridModel) { setTable(new Table(this, paramGridModel)); }
  
  class Table extends AbstractTableLens {
    private final GridModelLens this$0;
    
    public Table(GridModelLens this$0, GridModel param1GridModel) {
      this.this$0 = this$0;
      this$0.tbl = param1GridModel;
    }
    
    public int getRowCount() { return this.this$0.tbl.getRowCount() + this.this$0.tbl.getHeaderRowCount(); }
    
    public int getColCount() { return this.this$0.tbl.getColCount() + this.this$0.tbl.getHeaderColCount(); }
    
    public int getHeaderRowCount() { return this.this$0.tbl.getHeaderRowCount(); }
    
    public int getHeaderColCount() { return this.this$0.tbl.getHeaderColCount(); }
    
    public int getRowHeight(int param1Int) { return -1; }
    
    public int getColWidth(int param1Int) { return -1; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return 4097; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return 4097; }
    
    public Insets getInsets(int param1Int1, int param1Int2) { return null; }
    
    public Dimension getSpan(int param1Int1, int param1Int2) { return null; }
    
    public int getAlignment(int param1Int1, int param1Int2) { return (param1Int1 == 0) ? 18 : 17; }
    
    public Font getFont(int param1Int1, int param1Int2) { return null; }
    
    public Color getBackground(int param1Int1, int param1Int2) { return (param1Int1 < this.this$0.getHeaderRowCount()) ? Color.lightGray : null; }
    
    public Object getObject(int param1Int1, int param1Int2) { return this.this$0.tbl.getObject(param1Int1 - this.this$0.tbl.getHeaderRowCount(), param1Int2 - this.this$0.tbl.getHeaderColCount()); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\teaset2\GridModelLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */