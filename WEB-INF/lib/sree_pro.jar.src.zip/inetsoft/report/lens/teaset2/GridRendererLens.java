/*    */ package inetsoft.report.lens.teaset2;
/*    */ 
/*    */ import inetsoft.grid.Grid;
/*    */ import inetsoft.grid.GridCellRenderer;
/*    */ import inetsoft.report.Painter;
/*    */ import java.awt.Component;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GridRendererLens
/*    */   extends GridLens
/*    */ {
/* 37 */   public GridRendererLens(Grid paramGrid) { setTable(new RendererTable(this, paramGrid)); }
/*    */   
/*    */   class RendererTable extends GridLens.Table { private final GridRendererLens this$0;
/*    */     
/*    */     public RendererTable(GridRendererLens this$0, Grid param1Grid) {
/* 42 */       super(this$0, param1Grid);
/*    */       this.this$0 = this$0;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public Object getObject(int param1Int1, int param1Int2) {
/* 52 */       int i = param1Int1 - this.grid.getHeaderRowCount();
/* 53 */       int j = param1Int2 - this.grid.getHeaderColCount();
/*    */       
/* 55 */       GridCellRenderer gridCellRenderer = this.grid.getRenderer(i, j);
/* 56 */       if (gridCellRenderer != null) {
/* 57 */         return new GridRendererLens.RenderPainter(this.this$0, gridCellRenderer, param1Int1, param1Int2, this.grid.getObject(i, j));
/*    */       }
/*    */       
/* 60 */       return super.getObject(param1Int1, param1Int2);
/*    */     } }
/*    */   class RenderPainter implements Painter { GridCellRenderer rdr; Object val;
/*    */     
/*    */     public RenderPainter(GridRendererLens this$0, GridCellRenderer param1GridCellRenderer, int param1Int1, int param1Int2, Object param1Object) {
/* 65 */       this.this$0 = this$0;
/* 66 */       this.rdr = param1GridCellRenderer;
/* 67 */       this.val = param1Object;
/* 68 */       this.row = param1Int1;
/* 69 */       this.col = param1Int2;
/*    */     }
/*    */     int row; int col; private final GridRendererLens this$0;
/*    */     public void paint(Graphics param1Graphics, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/* 73 */       this.rdr.setCellValue(this.row, this.col, this.val);
/* 74 */       Graphics graphics = param1Graphics.create(param1Int1, param1Int2, param1Int3, param1Int4);
/* 75 */       Component component = (Component)this.rdr;
/* 76 */       component.setBounds(0, 0, param1Int3, param1Int4);
/* 77 */       component.validate();
/* 78 */       component.paint(graphics);
/* 79 */       graphics.dispose();
/*    */     }
/*    */     
/*    */     public Dimension getPreferredSize() {
/* 83 */       this.rdr.setCellValue(this.row, this.col, this.val);
/* 84 */       return ((Component)this.rdr).getPreferredSize();
/*    */     }
/*    */ 
/*    */     
/* 88 */     public boolean isScalable() { return true; } }
/*    */ 
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\teaset2\GridRendererLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */