package inetsoft.report.lens.teaset2;

import inetsoft.grid.Grid;
import inetsoft.grid.GridCellRenderer;
import inetsoft.report.Painter;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;

public class GridRendererLens extends GridLens {
  public GridRendererLens(Grid paramGrid) { setTable(new RendererTable(this, paramGrid)); }
  
  class RendererTable extends GridLens.Table {
    private final GridRendererLens this$0;
    
    public RendererTable(GridRendererLens this$0, Grid param1Grid) {
      super(this$0, param1Grid);
      this.this$0 = this$0;
    }
    
    public Object getObject(int param1Int1, int param1Int2) {
      int i = param1Int1 - this.grid.getHeaderRowCount();
      int j = param1Int2 - this.grid.getHeaderColCount();
      GridCellRenderer gridCellRenderer = this.grid.getRenderer(i, j);
      if (gridCellRenderer != null)
        return new GridRendererLens.RenderPainter(this.this$0, gridCellRenderer, param1Int1, param1Int2, this.grid.getObject(i, j)); 
      return super.getObject(param1Int1, param1Int2);
    }
  }
  
  class RenderPainter implements Painter {
    GridCellRenderer rdr;
    
    Object val;
    
    int row;
    
    int col;
    
    private final GridRendererLens this$0;
    
    public RenderPainter(GridRendererLens this$0, GridCellRenderer param1GridCellRenderer, int param1Int1, int param1Int2, Object param1Object) {
      this.this$0 = this$0;
      this.rdr = param1GridCellRenderer;
      this.val = param1Object;
      this.row = param1Int1;
      this.col = param1Int2;
    }
    
    public void paint(Graphics param1Graphics, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.rdr.setCellValue(this.row, this.col, this.val);
      Graphics graphics = param1Graphics.create(param1Int1, param1Int2, param1Int3, param1Int4);
      Component component = (Component)this.rdr;
      component.setBounds(0, 0, param1Int3, param1Int4);
      component.validate();
      component.paint(graphics);
      graphics.dispose();
    }
    
    public Dimension getPreferredSize() {
      this.rdr.setCellValue(this.row, this.col, this.val);
      return ((Component)this.rdr).getPreferredSize();
    }
    
    public boolean isScalable() { return true; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\teaset2\GridRendererLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */