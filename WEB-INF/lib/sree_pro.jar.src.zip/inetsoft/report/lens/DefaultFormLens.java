/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultFormLens
/*     */   extends AttributeFormLens
/*     */ {
/*     */   private int fieldPerRow;
/*     */   private Vector width;
/*     */   private Vector fieldLabel;
/*     */   private Vector fieldValue;
/*     */   private Vector labelFont;
/*     */   private Vector labelForeground;
/*     */   private Vector labelBackground;
/*     */   private Vector fieldFont;
/*     */   private Vector fieldForeground;
/*     */   private Vector fieldBackground;
/*     */   private Font lfont;
/*     */   private Color lfg;
/*     */   private Color lbg;
/*     */   private Font ffont;
/*     */   private Color ffg;
/*     */   private Color fbg;
/*     */   
/*     */   public DefaultFormLens() {
/* 354 */     this.fieldPerRow = 2;
/* 355 */     this.width = new Vector();
/* 356 */     this.fieldLabel = new Vector();
/* 357 */     this.fieldValue = new Vector();
/* 358 */     this.labelFont = new Vector();
/* 359 */     this.labelForeground = new Vector();
/* 360 */     this.labelBackground = new Vector();
/* 361 */     this.fieldFont = new Vector();
/* 362 */     this.fieldForeground = new Vector();
/* 363 */     this.fieldBackground = new Vector();
/* 364 */     this.lfont = null;
/* 365 */     this.lfg = null;
/* 366 */     this.lbg = null;
/* 367 */     this.ffont = null;
/* 368 */     this.ffg = null;
/* 369 */     this.fbg = null;
/*     */     setForm(new Form(this));
/*     */     this.width.setSize(this.fieldPerRow * 2);
/*     */   }
/*     */   
/*     */   public DefaultFormLens(int paramInt) {
/*     */     this();
/*     */     setFieldCount(paramInt);
/*     */   }
/*     */   
/*     */   public DefaultFormLens(Object[] paramArrayOfObject1, Object[] paramArrayOfObject2) {
/*     */     this();
/*     */     setFieldCount(Math.max(paramArrayOfObject1.length, paramArrayOfObject2.length));
/*     */     for (byte b1 = 0; b1 < paramArrayOfObject1.length; b1++)
/*     */       setLabel(b1, paramArrayOfObject1[b1]); 
/*     */     for (byte b2 = 0; b2 < paramArrayOfObject2.length; b2++)
/*     */       setField(b2, paramArrayOfObject2[b2]); 
/*     */   }
/*     */   
/*     */   public DefaultFormLens(Object[] paramArrayOfObject) {
/*     */     this();
/*     */     setFieldCount((paramArrayOfObject.length + 1) / 2);
/*     */     byte b1 = 0;
/*     */     boolean bool = true;
/*     */     for (byte b2 = 0; b2 < paramArrayOfObject.length; b2++) {
/*     */       if (bool) {
/*     */         setLabel(b1, paramArrayOfObject[b2]);
/*     */       } else {
/*     */         setField(b1, paramArrayOfObject[b2]);
/*     */         b1++;
/*     */       } 
/*     */       bool = !bool ? 1 : 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   class Form extends AbstractFormLens {
/*     */     private final DefaultFormLens this$0;
/*     */     
/*     */     Form(DefaultFormLens this$0) { this.this$0 = this$0; }
/*     */     
/*     */     public int getFieldCount() { return this.this$0.fieldValue.size(); }
/*     */     
/*     */     public Object getField(int param1Int) { return this.this$0.fieldValue.elementAt(param1Int); }
/*     */     
/*     */     public Object getLabel(int param1Int) { return this.this$0.fieldLabel.elementAt(param1Int); }
/*     */     
/*     */     public int getFieldPerRow() { return this.this$0.fieldPerRow; }
/*     */     
/*     */     public int getWidth(int param1Int) {
/*     */       Integer integer = (param1Int < this.this$0.width.size()) ? (Integer)this.this$0.width.elementAt(param1Int) : null;
/*     */       return (integer == null) ? super.getWidth(param1Int) : integer.intValue();
/*     */     }
/*     */     
/*     */     public Font getLabelFont(int param1Int) { return (this.this$0.lfont != null) ? this.this$0.lfont : (Font)this.this$0.labelFont.elementAt(param1Int); }
/*     */     
/*     */     public Color getLabelForeground(int param1Int) { return (this.this$0.lfg != null) ? this.this$0.lfg : (Color)this.this$0.labelForeground.elementAt(param1Int); }
/*     */     
/*     */     public Color getLabelBackground(int param1Int) { return (this.this$0.lbg != null) ? this.this$0.lbg : (Color)this.this$0.labelBackground.elementAt(param1Int); }
/*     */     
/*     */     public Font getFont(int param1Int) { return (this.this$0.ffont != null) ? this.this$0.ffont : (Font)this.this$0.fieldFont.elementAt(param1Int); }
/*     */     
/*     */     public Color getForeground(int param1Int) { return (this.this$0.ffg != null) ? this.this$0.ffg : (Color)this.this$0.fieldForeground.elementAt(param1Int); }
/*     */     
/*     */     public Color getBackground(int param1Int) { return (this.this$0.fbg != null) ? this.this$0.fbg : (Color)this.this$0.fieldBackground.elementAt(param1Int); }
/*     */   }
/*     */   
/*     */   public void setField(int paramInt, Object paramObject) { this.fieldValue.setElementAt(paramObject, paramInt); }
/*     */   
/*     */   public void setFieldCount(int paramInt) {
/*     */     this.fieldValue.setSize(paramInt);
/*     */     this.fieldLabel.setSize(paramInt);
/*     */     this.labelFont.setSize(paramInt);
/*     */     this.labelForeground.setSize(paramInt);
/*     */     this.labelBackground.setSize(paramInt);
/*     */     this.fieldFont.setSize(paramInt);
/*     */     this.fieldForeground.setSize(paramInt);
/*     */     this.fieldBackground.setSize(paramInt);
/*     */   }
/*     */   
/*     */   public void setLabel(int paramInt, Object paramObject) { this.fieldLabel.setElementAt(paramObject, paramInt); }
/*     */   
/*     */   public void setFieldPerRow(int paramInt) {
/*     */     this.fieldPerRow = paramInt;
/*     */     this.width.setSize(paramInt * 2);
/*     */   }
/*     */   
/*     */   public void setWidth(int paramInt1, int paramInt2) { this.width.setElementAt(new Integer(paramInt2), paramInt1); }
/*     */   
/*     */   public void setLabelFont(Font paramFont) { this.lfont = paramFont; }
/*     */   
/*     */   public void setLabelFont(int paramInt, Font paramFont) { this.labelFont.setElementAt(paramFont, paramInt); }
/*     */   
/*     */   public void setLabelForeground(Color paramColor) { this.lfg = paramColor; }
/*     */   
/*     */   public void setLabelForeground(int paramInt, Color paramColor) { this.labelForeground.setElementAt(paramColor, paramInt); }
/*     */   
/*     */   public void setLabelBackground(Color paramColor) { this.lbg = paramColor; }
/*     */   
/*     */   public void setLabelBackground(int paramInt, Color paramColor) { this.labelBackground.setElementAt(paramColor, paramInt); }
/*     */   
/*     */   public void setFont(Font paramFont) { this.ffont = paramFont; }
/*     */   
/*     */   public void setFont(int paramInt, Font paramFont) { this.fieldFont.setElementAt(paramFont, paramInt); }
/*     */   
/*     */   public void setForeground(Color paramColor) { this.ffg = paramColor; }
/*     */   
/*     */   public void setForeground(int paramInt, Color paramColor) { this.fieldForeground.setElementAt(paramColor, paramInt); }
/*     */   
/*     */   public void setBackground(Color paramColor) { this.fbg = paramColor; }
/*     */   
/*     */   public void setBackground(int paramInt, Color paramColor) { this.fieldBackground.setElementAt(paramColor, paramInt); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\DefaultFormLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */